"""FastMCP server for Memex — machine interface."""

from __future__ import annotations

import atexit
import uuid

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from memex.utcnow import utcnow

load_dotenv()

from memex.models import Goal, GoalPriority, GoalStatus  # noqa: E402


def _resolve_store_path() -> str:
    from memex.paths import resolve_store_path

    return resolve_store_path()


def _make_fathom_store(path: str | None = None):
    from memex.fathom_facade import make_fathom_store

    return make_fathom_store(path or _resolve_store_path())


def create_app(store_path: str | None = None) -> FastMCP:
    """Create and configure the FastMCP application.

    The store is created once and reused across all tool/resource calls
    for the lifetime of the MCP process.
    """
    app = FastMCP("memex")
    store = _make_fathom_store(store_path)
    atexit.register(store.close)

    # Initialize embedding backend (optional)
    _embedding_backend = None
    try:
        from memex.memory.embeddings import get_embedding_backend

        _embedding_backend = get_embedding_backend()
    except Exception:
        pass

    # -- Tools -------------------------------------------------------------

    @app.tool()
    def memex_chat(message: str) -> str:
        """Send a message to Memex and get a response."""
        from memex.loop import run_turn
        from memex.session import load_session

        session = load_session(store)
        response, _session = run_turn(
            message,
            store,
            session,
            content_store=store.content,
            embedding_backend=_embedding_backend,
        )
        return response

    @app.tool()
    def memex_goal_list(include_all: bool = False) -> str:
        """List goals. Set include_all=True to include non-active goals."""
        if include_all:
            goals = store.list_goals()
        else:
            goals = store.list_goals(GoalStatus.ACTIVE)

        if not goals:
            return "No goals found."

        lines: list[str] = []
        for g in goals:
            status = f" [{g.status.value}]" if g.status != GoalStatus.ACTIVE else ""
            lines.append(f"- {g.title}{status} ({g.priority.value}) [{g.goal_id[:8]}]")
        return "\n".join(lines)

    @app.tool()
    def memex_goal_create(
        title: str,
        description: str = "",
        parent_id: str | None = None,
        priority: str = "medium",
        blocked_by_goal_id: str | None = None,
    ) -> str:
        """Create a new goal."""
        now = utcnow()
        goal = Goal(
            goal_id=str(uuid.uuid4()),
            parent_id=parent_id,
            title=title,
            description=description,
            priority=GoalPriority(priority),
            status=GoalStatus.ACTIVE,
            blocked_by_goal_id=blocked_by_goal_id,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        store.create_goal(goal)

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalCreated

            get_bus().publish(
                GoalCreated(
                    goal_id=goal.goal_id, title=goal.title, parent_id=goal.parent_id
                )
            )
        except Exception:
            pass

        return f"Created goal: {goal.title} [{goal.goal_id[:8]}]"

    @app.tool()
    def memex_goal_update(
        goal_id: str,
        status: str | None = None,
        title: str | None = None,
        priority: str | None = None,
        blocked_reason: str | None = None,
        blocked_by_goal_id: str | None = None,
    ) -> str:
        """Update an existing goal's status, title, or priority."""
        goal = store.get_goal(goal_id)
        if not goal:
            # Try prefix match
            all_goals = store.list_goals()
            matches = [g for g in all_goals if g.goal_id.startswith(goal_id)]
            if len(matches) == 1:
                goal = matches[0]
            else:
                return f"Goal not found: {goal_id}"

        old_status = goal.status.value
        now = utcnow()
        if status is not None:
            goal.status = GoalStatus(status)
        if title is not None:
            goal.title = title
        if priority is not None:
            goal.priority = GoalPriority(priority)
        if blocked_reason is not None:
            goal.blocked_reason = blocked_reason
        if blocked_by_goal_id is not None:
            goal.blocked_by_goal_id = blocked_by_goal_id
        goal.updated_at = now
        goal.last_touched_at = now
        store.update_goal(goal)

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalStatusChanged, GoalUpdated

            if status is not None:
                get_bus().publish(
                    GoalStatusChanged(
                        goal_id=goal.goal_id,
                        title=goal.title,
                        old_status=old_status,
                        new_status=goal.status.value,
                    )
                )
            else:
                get_bus().publish(GoalUpdated(goal_id=goal.goal_id, title=goal.title))
        except Exception:
            pass

        return f"Updated goal: {goal.title} [{goal.goal_id[:8]}]"

    @app.tool()
    def memex_status() -> str:
        """Get system status summary."""
        all_goals = store.list_goals()
        active = [g for g in all_goals if g.status == GoalStatus.ACTIVE]
        session = store.load_session()

        lines = [
            f"Goals: {len(all_goals)} total, {len(active)} active",
        ]
        if session:
            lines.append(
                f"Session: {session.session_id[:8]} ({session.turn_count} turns)"
            )
        return "\n".join(lines)

    # -- Resources ---------------------------------------------------------

    @app.resource("memex://goals")
    def resource_goals() -> str:
        """All goals as formatted text."""
        goals = store.list_goals()
        if not goals:
            return "No goals."
        lines: list[str] = []
        for g in goals:
            lines.append(
                f"[{g.goal_id[:8]}] {g.title} — {g.status.value} ({g.priority.value})"
            )
        return "\n".join(lines)

    @app.resource("memex://session")
    def resource_session() -> str:
        """Current session context as JSON."""
        session = store.load_session()
        if not session:
            return "{}"
        return session.model_dump_json(indent=2)

    return app


def main() -> None:
    """Run the MCP server with stdio transport."""
    app = create_app()
    app.run(transport="stdio")
