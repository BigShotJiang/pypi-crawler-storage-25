"""Relevance scoring for context window filtering. Pure math, no LLM."""

from __future__ import annotations

import math
from datetime import datetime, timezone

from memex.models import Goal, GoalPriority, PRIORITY_WEIGHTS

# Half-life for recency decay (7 days in seconds)
_HALF_LIFE_SECONDS = 7 * 24 * 3600

# Score weights
_W_RECENCY = 0.4
_W_PRIORITY = 0.3
_W_RELATION = 0.3


def recency_score(last_touched: datetime, now: datetime) -> float:
    """Exponential decay from last_touched_at. Half-life = 7 days."""
    # Ensure both are aware UTC for consistent comparison.
    if last_touched.tzinfo is None:
        last_touched = last_touched.replace(tzinfo=timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    delta = (now - last_touched).total_seconds()
    if delta <= 0:
        return 1.0
    return math.exp(-math.log(2) * delta / _HALF_LIFE_SECONDS)


def priority_score(priority: GoalPriority) -> float:
    """Map priority to weight."""
    return PRIORITY_WEIGHTS[priority]


def relation_score(
    goal: Goal,
    *,
    referenced_goal_id: str | None = None,
    referenced_parent_id: str | None = None,
    sibling_ids: set[str] | None = None,
) -> float:
    """Score based on how directly related a goal is to the current context.

    1.0 if directly referenced, 0.5 if parent/child of referenced, 0.2 if sibling, 0.0 otherwise.
    """
    if referenced_goal_id and goal.goal_id == referenced_goal_id:
        return 1.0
    if referenced_goal_id and goal.parent_id == referenced_goal_id:
        return 0.5
    if referenced_parent_id and goal.goal_id == referenced_parent_id:
        return 0.5
    if sibling_ids and goal.goal_id in sibling_ids:
        return 0.2
    return 0.0


def score_goal(
    goal: Goal,
    now: datetime,
    *,
    referenced_goal_id: str | None = None,
    referenced_parent_id: str | None = None,
    sibling_ids: set[str] | None = None,
) -> float:
    """Composite relevance score for a goal."""
    r = recency_score(goal.last_touched_at, now)
    p = priority_score(goal.priority)
    rel = relation_score(
        goal,
        referenced_goal_id=referenced_goal_id,
        referenced_parent_id=referenced_parent_id,
        sibling_ids=sibling_ids,
    )
    return _W_RECENCY * r + _W_PRIORITY * p + _W_RELATION * rel


def filter_goals(
    goals: list[Goal],
    now: datetime,
    *,
    referenced_goal_id: str | None = None,
    max_goals: int = 10,
) -> list[Goal]:
    """Select the most relevant goals for the context window.

    Always includes the directly-referenced goal if present.
    Hard cap at max_goals.
    """
    if not goals:
        return []

    # Determine parent/sibling context
    referenced_parent_id: str | None = None
    sibling_ids: set[str] = set()
    if referenced_goal_id:
        ref = next((g for g in goals if g.goal_id == referenced_goal_id), None)
        if ref and ref.parent_id:
            referenced_parent_id = ref.parent_id
            sibling_ids = {
                g.goal_id
                for g in goals
                if g.parent_id == ref.parent_id and g.goal_id != referenced_goal_id
            }

    scored = [
        (
            score_goal(
                g,
                now,
                referenced_goal_id=referenced_goal_id,
                referenced_parent_id=referenced_parent_id,
                sibling_ids=sibling_ids,
            ),
            g,
        )
        for g in goals
    ]
    scored.sort(key=lambda x: x[0], reverse=True)

    result = [g for _, g in scored[:max_goals]]

    # Ensure referenced goal is included
    if referenced_goal_id:
        ref_ids = {g.goal_id for g in result}
        if referenced_goal_id not in ref_ids:
            ref = next((g for g in goals if g.goal_id == referenced_goal_id), None)
            if ref:
                result = result[: max_goals - 1] + [ref]

    return result
