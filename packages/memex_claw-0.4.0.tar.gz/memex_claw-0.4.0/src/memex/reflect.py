"""Structured reflection — LLM call #3 (cheap model, structured output)."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime

from memex.llm import _get_cheap_model, chat_structured
from memex.models import (
    Goal,
    GoalStatus,
    InputClassification,
    ReflectResult,
    SessionContext,
)
from memex.store import MemexStore
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """\
You are the reflection module for Memex, a personal AI assistant.
After each conversation turn, you analyze what happened and determine:

1. Which goals were advanced (list their IDs)
2. Whether new sub-goals should be created
3. Whether any goals should be marked completed, paused, blocked, or failed
4. Any updates to session working memory (key observations, context to remember)
5. User preferences observed (e.g. "prefers concise answers", "uses Python") — \
only log when the user explicitly states a preference or you see a clear pattern
6. User constraints stated (e.g. "never auto-commit", "always ask before deleting") — \
only log explicit rules the user stated
7. Rejected approaches — if something was tried and failed or the user rejected an approach
8. Insights — cross-turn patterns you noticed (e.g. "user tends to work on X in the evening")
9. Topic shifts — if the user moved to a different domain mid-conversation
10. Retrieval feedback — if the user commented on retrieved knowledge (e.g. "that's exactly \
what I needed", "that article was outdated", "wrong topic"). Set feedback to "positive" or \
"negative" and include the topic that was retrieved.

Be precise. Only list goals that were actually discussed or advanced.
Only suggest sub-goals if the conversation clearly identified a concrete next step.
Only log preferences/constraints/insights when clearly evidenced — do not speculate.
Keep reflection_note to one sentence.

Respond with JSON matching the schema.
"""


def reflect(
    *,
    classification: InputClassification,
    assistant_response: str,
    relevant_goals: list[Goal],
    session: SessionContext,
    model: str | None = None,
) -> ReflectResult:
    """Run structured reflection. Falls back to no-op on failure."""
    messages: list[dict[str, str]] = [{"role": "system", "content": _SYSTEM_PROMPT}]

    # Build context
    context_parts: list[str] = []

    context_parts.append(f"Classification: {classification.classification.value}")
    if classification.goal_id:
        context_parts.append(f"Classified goal: {classification.goal_id}")

    if relevant_goals:
        goal_lines = [
            f"- [{g.goal_id[:8]}] {g.title} (status={g.status.value}, priority={g.priority.value})"
            for g in relevant_goals
        ]
        context_parts.append("Relevant goals:\n" + "\n".join(goal_lines))

    if session.active_task_context:
        context_parts.append(f"Active task: {session.active_task_context}")

    # Last human message + assistant response
    last_human = ""
    if session.conversation_history:
        for turn in reversed(session.conversation_history):
            if turn.role == "human":
                last_human = turn.content[:500]
                break

    context_parts.append(f"Human said: {last_human}")
    context_parts.append(f"Assistant responded: {assistant_response[:500]}")

    messages.append({"role": "user", "content": "\n\n".join(context_parts)})

    try:
        result = chat_structured(
            messages,
            ReflectResult,
            model=model or _get_cheap_model(),
        )
        logger.info(
            "reflect: advanced=%s, new_subgoals=%d, completed=%s — %s",
            result.intent_advanced,
            len(result.new_subgoals),
            result.goals_to_complete,
            result.reflection_note,
        )
        return result
    except Exception:
        logger.warning("Reflection failed, returning no-op", exc_info=True)
        return ReflectResult(reflection_note="reflection failed — no-op")


def _resolve_goal_id(
    gid: str, store: MemexStore, cache: dict[str, Goal] | None = None
) -> Goal | None:
    """Resolve a goal ID, supporting prefix matching.

    The LLM only sees 8-char prefixes in the prompt, so it may return
    prefixes instead of full UUIDs. An optional cache avoids repeated
    list_goals() calls during batch operations.
    """
    goal = store.get_goal(gid)
    if goal:
        return goal
    # Try prefix match using cache or fresh fetch
    if cache is not None:
        matches = [g for g in cache.values() if g.goal_id.startswith(gid)]
    else:
        all_goals = store.list_goals()
        matches = [g for g in all_goals if g.goal_id.startswith(gid)]
    if len(matches) == 1:
        return matches[0]
    return None


def _publish_event(event: object) -> None:
    """Publish a domain event. Never raises."""
    try:
        from memex.event_bus import get_bus

        get_bus().publish(event)
    except Exception:
        pass


def _make_goal_updated(goal_id: str, title: str) -> object | None:
    """Create a GoalUpdated event. Returns None if events module unavailable."""
    try:
        from memex.events import GoalUpdated

        return GoalUpdated(goal_id=goal_id, title=title)
    except Exception:
        return None


def _make_goal_created(
    goal_id: str, title: str, parent_id: str | None = None
) -> object | None:
    """Create a GoalCreated event. Returns None if events module unavailable."""
    try:
        from memex.events import GoalCreated

        return GoalCreated(goal_id=goal_id, title=title, parent_id=parent_id)
    except Exception:
        return None


def _make_goal_status_changed(
    goal_id: str, title: str, old_status: str, new_status: str
) -> object | None:
    """Create a GoalStatusChanged event. Returns None if events module unavailable."""
    try:
        from memex.events import GoalStatusChanged

        return GoalStatusChanged(
            goal_id=goal_id, title=title, old_status=old_status, new_status=new_status
        )
    except Exception:
        return None


def apply_reflect_result(
    result: ReflectResult,
    store: MemexStore,
    now: datetime | None = None,
) -> None:
    """Apply reflection results: create sub-goals, update statuses, touch goals."""
    now = now or utcnow()

    # Pre-fetch all goals once for prefix resolution
    _goal_cache = {g.goal_id: g for g in store.list_goals()}

    # Touch advanced goals
    for gid in result.intent_advanced:
        goal = _resolve_goal_id(gid, store, _goal_cache)
        if goal:
            goal.last_touched_at = now
            goal.updated_at = now
            store.update_goal(goal)
            evt = _make_goal_updated(goal.goal_id, goal.title)
            if evt:
                _publish_event(evt)

    # Create new sub-goals
    for sg in result.new_subgoals:
        new_goal = Goal(
            goal_id=str(uuid.uuid4()),
            parent_id=sg.parent_id,
            title=sg.title,
            description=sg.description,
            priority=sg.priority,
            status=GoalStatus.ACTIVE,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        store.create_goal(new_goal)
        evt = _make_goal_created(new_goal.goal_id, new_goal.title, new_goal.parent_id)
        if evt:
            _publish_event(evt)

    # Complete goals
    for gid in result.goals_to_complete:
        goal = _resolve_goal_id(gid, store, _goal_cache)
        if goal:
            old_status = goal.status.value
            goal.status = GoalStatus.COMPLETED
            goal.updated_at = now
            goal.last_touched_at = now
            store.update_goal(goal)
            evt = _make_goal_status_changed(
                goal.goal_id, goal.title, old_status, "completed"
            )
            if evt:
                _publish_event(evt)

    # Pause goals
    for gid in result.goals_to_pause:
        goal = _resolve_goal_id(gid, store, _goal_cache)
        if goal:
            old_status = goal.status.value
            goal.status = GoalStatus.PAUSED
            goal.updated_at = now
            goal.last_touched_at = now
            store.update_goal(goal)
            evt = _make_goal_status_changed(
                goal.goal_id, goal.title, old_status, "paused"
            )
            if evt:
                _publish_event(evt)

    # Block goals
    for block in result.goals_to_block:
        goal = _resolve_goal_id(block.goal_id, store, _goal_cache)
        if goal:
            old_status = goal.status.value
            goal.status = GoalStatus.BLOCKED
            goal.blocked_reason = block.reason
            goal.updated_at = now
            goal.last_touched_at = now
            store.update_goal(goal)
            evt = _make_goal_status_changed(
                goal.goal_id, goal.title, old_status, "blocked"
            )
            if evt:
                _publish_event(evt)

    # Fail goals
    for fail in result.goals_to_fail:
        goal = _resolve_goal_id(fail.goal_id, store, _goal_cache)
        if goal:
            old_status = goal.status.value
            goal.status = GoalStatus.FAILED
            goal.failure_reason = fail.reason
            goal.updated_at = now
            goal.last_touched_at = now
            store.update_goal(goal)
            evt = _make_goal_status_changed(
                goal.goal_id, goal.title, old_status, "failed"
            )
            if evt:
                _publish_event(evt)
