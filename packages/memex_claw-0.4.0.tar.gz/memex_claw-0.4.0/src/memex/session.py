"""Session management: working memory, sliding window, summarization."""

from __future__ import annotations

import logging
import uuid
from typing import Any, Literal

from memex.llm import _get_cheap_model, chat
from memex.models import (
    ConversationTurn,
    InputClassification,
    ReflectResult,
    SessionContext,
)
from memex.store import MemexStore
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

WINDOW_SIZE = 20

_SUMMARIZE_PROMPT = """\
Summarize the following conversation turns into a concise paragraph.
Focus on: what topics were discussed, what decisions were made, what goals
were worked on. Keep it under 200 words.

Turns:
{turns}

Existing summary to incorporate:
{existing_summary}
"""


def create_session() -> SessionContext:
    """Create a new empty session."""
    now = utcnow()
    return SessionContext(
        session_id=str(uuid.uuid4()),
        started_at=now,
    )


def add_turn(
    session: SessionContext,
    role: Literal["human", "assistant", "system", "tool_result"],
    content: str,
    *,
    classification: InputClassification | None = None,
    reflect_result: ReflectResult | None = None,
    store: MemexStore | None = None,
) -> None:
    """Append a turn to conversation history and optionally persist to conversation_log."""
    turn = ConversationTurn(
        role=role,
        content=content,
        timestamp=utcnow(),
        classification=classification,
        reflect_result=reflect_result,
    )
    session.conversation_history.append(turn)
    if role == "human":
        session.turn_count += 1
    if classification:
        session.last_classification = classification
    if reflect_result:
        session.last_reflect = reflect_result

    # Durable logging
    if store is not None:
        try:
            store.log_turn(session.session_id, turn)
        except Exception:
            import logging

            logging.getLogger(__name__).debug(
                "Failed to log turn to conversation_log", exc_info=True
            )


def window_history(session: SessionContext, *, use_llm: bool = True) -> None:
    """If history exceeds WINDOW_SIZE, summarize oldest turns and trim."""
    if len(session.conversation_history) <= WINDOW_SIZE:
        return

    overflow = len(session.conversation_history) - WINDOW_SIZE
    old_turns = session.conversation_history[:overflow]
    session.conversation_history = session.conversation_history[overflow:]

    _MAX_SUMMARY_CHARS = 4000

    if use_llm:
        try:
            turn_text = "\n".join(f"{t.role}: {t.content[:200]}" for t in old_turns)
            prompt = _SUMMARIZE_PROMPT.format(
                turns=turn_text,
                existing_summary=session.conversation_summary or "(none)",
            )
            session.conversation_summary = chat(
                [{"role": "user", "content": prompt}],
                model=_get_cheap_model(),
                max_tokens=512,
            )
        except Exception:
            logger.debug("Summarization failed, using fallback", exc_info=True)
            # Fallback: simple concatenation, capped to prevent unbounded growth
            snippets = [f"{t.role}: {t.content[:100]}" for t in old_turns]
            combined = session.conversation_summary + "\n" + "\n".join(snippets)
            session.conversation_summary = combined[-_MAX_SUMMARY_CHARS:]
    else:
        snippets = [f"{t.role}: {t.content[:100]}" for t in old_turns]
        if session.conversation_summary:
            combined = session.conversation_summary + "\n" + "\n".join(snippets)
            session.conversation_summary = combined[-_MAX_SUMMARY_CHARS:]
        else:
            session.conversation_summary = "\n".join(snippets)


def save_session(session: SessionContext, store: MemexStore) -> None:
    """Persist session to store."""
    store.save_session(session)


def load_session(store: MemexStore) -> SessionContext | None:
    """Load session from store."""
    return store.load_session()


def end_session(
    session: SessionContext,
    store: MemexStore,
    middleware_chain: Any | None = None,
) -> SessionContext:
    """End the current session and start a new one.

    Marks the old session with ended_at, persists it, and returns a fresh session.
    Emits session-end middleware events only through the middleware chain.
    """
    import logging

    session.ended_at = utcnow()
    save_session(session, store)

    if middleware_chain is not None:
        try:
            middleware_chain.after_session(session, store)
        except Exception:
            logging.getLogger(__name__).debug(
                "Middleware after_session failed", exc_info=True
            )

    return create_session()
