"""Security: capability gate, boundary tagging, injection scanning."""

from __future__ import annotations

import os
import re

from memex.models import ConnectorHealth, ToolDefinition


# ---------------------------------------------------------------------------
# Capability management
# ---------------------------------------------------------------------------

_CONNECTOR_CAPABILITIES: dict[str, set[str]] = {
    "http": {"network.outbound"},
    "claude_code": {"claude_code.read"},
    "filesystem": {"filesystem.read"},
}

_BASE_CAPABILITIES: set[str] = {"builtin.read", "builtin.write"}


def get_granted_capabilities(
    connector_health: list[ConnectorHealth],
) -> set[str]:
    """Return the set of capabilities granted based on connector health."""
    granted = set(_BASE_CAPABILITIES)
    for h in connector_health:
        if h.status == "connected":
            key = h.capability_prefix or h.name
            granted |= _CONNECTOR_CAPABILITIES.get(key, set())
    # claude_code.execute requires explicit opt-in via env var
    if os.environ.get("MEMEX_CLAUDE_CODE_WRITE") == "1":
        if "claude_code.read" in granted:
            granted.add("claude_code.execute")
    # filesystem.write granted only if at least one write-enabled filesystem server
    # is configured. Write tools are excluded at registration time for read-only
    # servers, and this capability gate provides a second layer of defense.
    if "filesystem.read" in granted:
        from memex.mcp_servers import servers_config_from_env

        _fs_cfg = servers_config_from_env()
        has_writable = len(_fs_cfg.filesystem_entries(write_only=True)) > 0
        if has_writable:
            granted.add("filesystem.write")
            granted.add("builtin.file_transform")
    return granted


def filter_permitted_tools(
    tools: list[ToolDefinition],
    granted: set[str],
) -> list[ToolDefinition]:
    """Presentation filter: only tools whose capability is granted."""
    return [t for t in tools if t.required_capability in granted]


def check_capability(capability: str, granted: set[str]) -> bool:
    """Execution gate: check if a capability is granted."""
    return capability in granted


# ---------------------------------------------------------------------------
# Boundary tagging
# ---------------------------------------------------------------------------

_EXTERNAL_TAG_RE = re.compile(r"</?external\b[^>]*>")


def _sanitize_source(source: str) -> str:
    """Sanitize source for safe inclusion in XML attribute."""
    return source.replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")


def _escape_boundary_tags(content: str) -> str:
    """Escape any literal <external> tags in content to prevent tag breakout."""
    return _EXTERNAL_TAG_RE.sub(lambda m: m.group(0).replace("<", "&lt;"), content)


def wrap_external(content: str, source: str) -> str:
    """Wrap external content in boundary tags.

    Escapes the source attribute and any nested boundary tags in content.
    """
    safe_source = _sanitize_source(source)
    safe_content = _escape_boundary_tags(content)
    return f'<external source="{safe_source}">{safe_content}</external>'


def strip_external_tags(content: str) -> str:
    """Strip external boundary tags for outbound sanitization."""
    return _EXTERNAL_TAG_RE.sub("", content)


# ---------------------------------------------------------------------------
# Injection scanning
# ---------------------------------------------------------------------------

_INJECTION_PATTERNS: list[str] = [
    "ignore previous instructions",
    "ignore all instructions",
    "disregard your instructions",
    "you are now",
    "new instructions:",
    "system prompt:",
    "override:",
    "</external>",
]


def scan_for_injection(content: str) -> list[str]:
    """Scan content for injection patterns. Returns matched patterns.

    Does NOT block — CONSTITUTION is the real defense. This is for logging.
    """
    lower = content.lower()
    return [p for p in _INJECTION_PATTERNS if p in lower]
