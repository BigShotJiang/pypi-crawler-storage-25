"""FathomStore — fathomdb-backed storage layer for Memex.

Single fathomdb Engine that owns all persistent state.

Sub-repositories:
  - admin: integrity checks, projection rebuilds, backup
  - operational: settings, connector health, audit log, and other
    high-churn bookkeeping via fathomdb operational collections
"""

from __future__ import annotations

import dataclasses
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

from fathomdb import (
    ChunkInsert,
    ChunkPolicy,
    EdgeInsert,
    Engine,
    LastAccessTouchRequest,
    NodeInsert,
    NodeRetire,
    OperationalAppend,
    OperationalCollectionKind,
    OperationalDelete,
    OperationalFilterClause,
    OperationalPut,
    OperationalReadRequest,
    OperationalRegisterRequest,
    ProjectionTarget,
    ProvenanceMode,
    TraverseDirection,
    WriteRequest,
    new_id,
    new_row_id,
)

from memex.meetings.models import (
    MeetingExtractionRun,
    MeetingIntelligenceArtifact,
    MeetingIntelligenceArtifactType,
    MeetingRecord,
    MeetingRecording,
    MeetingSegment,
    MeetingState,
)
from memex.models import (
    ActionType,
    Goal,
    GoalPriority,
    GoalStatus,
    Item,
    ItemType,
    Notification,
    NotificationPriority,
    PromptControlArtifact,
    Provenance,
    ScheduledTask,
    Summary,
    WorldModelAction,
    WorldModelClaimEvaluation,
    WorldModelCommitment,
    WorldModelEntity,
    WorldModelEntityType,
    WorldModelEvent,
    WorldModelGoal,
    WorldModelIntent,
    WorldModelKnowledgeEntityLink,
    WorldModelKnowledgeIngestRun,
    WorldModelKnowledgeObject,
    WorldModelKnowledgeRelationship,
    WorldModelObservation,
    WorldModelActionPlan,
    WorldModelPlanStep,
    WorldModelExecutionRecord,
    WorldModelPlanStepTransition,
    WorldModelSemanticMapping,
    WorldModelTask,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

# ── Edge kind constants ──────────────────────────────────────────────

EDGE_PARENT_OF = "PARENT_OF"
EDGE_BLOCKS = "BLOCKS"
EDGE_HAS_RUN = "HAS_RUN"
EDGE_HAS_RECORDING = "HAS_RECORDING"
EDGE_HAS_ARTIFACT = "HAS_ARTIFACT"
EDGE_HAS_EXTRACTION = "HAS_EXTRACTION"
EDGE_HAS_LINK = "HAS_LINK"
EDGE_TRAIL_CONTAINS = "TRAIL_CONTAINS"
EDGE_HAS_ACTION = "HAS_ACTION"
EDGE_HAS_OBSERVATION = "HAS_OBSERVATION"
EDGE_FOR_GOAL = "FOR_GOAL"
EDGE_HAS_STEP = "HAS_STEP"
EDGE_GOAL_ENTITY_LINK = "GOAL_ENTITY_LINK"
EDGE_MEETING_GOAL_LINK = "MEETING_GOAL_LINK"
EDGE_MEETING_ENTITY_LINK = "MEETING_ENTITY_LINK"

_MEETING_KIND = "Meeting"
_WM_ENTITY_KIND = "WMEntity"


# ── Shared helpers ───────────────────────────────────────────────────


def _node_to_dict(node: Any) -> dict[str, Any]:
    """Convert a fathomdb node to a plain dict with logical_id + all properties."""
    props = node.properties if isinstance(node.properties, dict) else {}
    result = {"logical_id": node.logical_id}
    result.update(props)
    if node.last_accessed_at is not None:
        result["last_accessed_at"] = node.last_accessed_at
    return result


def _check_degraded(rows: Any, context: str = "") -> None:
    """Log a warning if a query returned degraded results."""
    if getattr(rows, "was_degraded", False):
        logger.warning("Degraded query results%s", f" ({context})" if context else "")


def _get_one(engine: Engine, kind: str, logical_id: str) -> dict[str, Any] | None:
    """Fetch a single node by kind and logical_id, or return None."""
    rows = engine.nodes(kind).filter_logical_id_eq(logical_id).limit(1).execute()
    _check_degraded(rows, f"get_one {kind}")
    if not rows.nodes:
        return None
    return _node_to_dict(rows.nodes[0])


def _traverse_out(
    engine: Engine,
    kind: str,
    logical_id: str,
    edge_label: str,
    *,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Traverse OUT edges from a node and return the connected nodes as dicts."""
    rows = (
        engine.nodes(kind)
        .filter_logical_id_eq(logical_id)
        .traverse(direction=TraverseDirection.OUT, label=edge_label, max_depth=1)
        .limit(limit)
        .execute()
    )
    _check_degraded(rows, f"traverse {kind}->{edge_label}")
    return [_node_to_dict(n) for n in rows.nodes if n.logical_id != logical_id]


def _now_iso() -> str:
    return utcnow().isoformat()


def _parse_iso_str(s: str) -> datetime:
    """Parse an ISO datetime string, handling the Z suffix for Python 3.10 compat."""
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.fromisoformat(s)


def _parse_iso_fields(d: dict, *fields: str) -> None:
    """Parse ISO datetime strings to datetime objects in-place."""
    for field in fields:
        val = d.get(field)
        if isinstance(val, str):
            d[field] = _parse_iso_str(val)


def _default_timestamps(d: dict) -> None:
    """Default created_at <-> updated_at when one is missing."""
    if "updated_at" not in d and "created_at" in d:
        d["updated_at"] = d["created_at"]
    if "created_at" not in d and "updated_at" in d:
        d["created_at"] = d["updated_at"]


def _filter_to_dataclass_fields(d: dict[str, Any], cls: type) -> dict[str, Any]:
    """Return only the keys from *d* that are valid fields on dataclass *cls*."""
    valid = {f.name for f in dataclasses.fields(cls)}
    return {k: v for k, v in d.items() if k in valid}


def _get_raw_props(engine: Engine, kind: str, logical_id: str) -> dict[str, Any]:
    """Get mutable copy of node properties, or raise KeyError."""
    rows = engine.nodes(kind).filter_logical_id_eq(logical_id).limit(1).execute()
    if not rows.nodes:
        raise KeyError(f"No active {kind} node: {logical_id}")
    return dict(rows.nodes[0].properties or {})


# ── Collection definitions ────────────────────────────────────────────


def _make_collection(
    name: str,
    kind: OperationalCollectionKind,
    filter_fields: str = "[]",
) -> OperationalRegisterRequest:
    return OperationalRegisterRequest(
        name=name,
        kind=kind,
        schema_json="{}",
        retention_json="{}",
        filter_fields_json=filter_fields,
        validation_json='{"format_version":1,"mode":"disabled","fields":[]}',
        secondary_indexes_json="[]",
        format_version=1,
    )


_COLLECTIONS = [
    _make_collection(
        "user_settings",
        OperationalCollectionKind.LATEST_STATE,
        '[{"name":"key","type":"string","modes":["exact"]}]',
    ),
    _make_collection(
        "connector_health",
        OperationalCollectionKind.LATEST_STATE,
        '[{"name":"name","type":"string","modes":["exact"]}]',
    ),
    _make_collection(
        "audit_log",
        OperationalCollectionKind.APPEND_ONLY_LOG,
        (
            "["
            '{"name":"connector","type":"string","modes":["exact"]},'
            '{"name":"session_id","type":"string","modes":["exact"]},'
            '{"name":"goal_id","type":"string","modes":["exact"]}'
            "]"
        ),
    ),
    _make_collection("human_model", OperationalCollectionKind.LATEST_STATE),
    _make_collection("session_context", OperationalCollectionKind.LATEST_STATE),
    _make_collection(
        "auto_ingest_sources",
        OperationalCollectionKind.LATEST_STATE,
        '[{"name":"type","type":"string","modes":["exact"]}]',
    ),
    _make_collection(
        "intake_log",
        OperationalCollectionKind.LATEST_STATE,
        (
            "["
            '{"name":"source","type":"string","modes":["exact"]},'
            '{"name":"status","type":"string","modes":["exact"]}'
            "]"
        ),
    ),
    _make_collection(
        "tool_usage_stats",
        OperationalCollectionKind.LATEST_STATE,
        (
            "["
            '{"name":"tool_name","type":"string","modes":["exact"]},'
            '{"name":"keyword_matched","type":"string","modes":["exact"]}'
            "]"
        ),
    ),
    _make_collection("agent_self_model", OperationalCollectionKind.LATEST_STATE),
    _make_collection(
        "answer_observation",
        OperationalCollectionKind.APPEND_ONLY_LOG,
        '[{"name":"session_id","type":"string","modes":["exact"]},{"name":"resolved","type":"string","modes":["exact"]}]',
    ),
    _make_collection(
        "answer_feedback_signal",
        OperationalCollectionKind.APPEND_ONLY_LOG,
        '[{"name":"answer_id","type":"string","modes":["exact"]},{"name":"session_id","type":"string","modes":["exact"]}]',
    ),
    _make_collection(
        "answer_outcome",
        OperationalCollectionKind.LATEST_STATE,
        '[{"name":"answer_id","type":"string","modes":["exact"]}]',
    ),
]


# ── Admin sub-repository ──────────────────────────────────────────────


class AdminRepository:
    """Integrity checks, projection rebuilds, and recovery."""

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def check(self) -> Any:
        """Run integrity check. Returns IntegrityReport."""
        return self._engine.admin.check_integrity()

    def check_semantics(self) -> Any:
        """Run semantic check. Returns SemanticReport."""
        return self._engine.admin.check_semantics()

    def rebuild_projections(self) -> Any:
        """Rebuild all derived projections (FTS + vector)."""
        return self._engine.admin.rebuild(ProjectionTarget.ALL)

    def rebuild_missing(self) -> Any:
        """Rebuild only missing projection rows."""
        return self._engine.admin.rebuild_missing()

    def trace_source(self, source_ref: str) -> Any:
        """Trace all rows written by a source."""
        return self._engine.admin.trace_source(source_ref)

    def excise_source(self, source_ref: str) -> Any:
        """Remove all rows written by a source."""
        return self._engine.admin.excise_source(source_ref)

    def safe_export(self, path: str, *, force_checkpoint: bool = True) -> Any:
        """Export a backup copy of the database."""
        return self._engine.admin.safe_export(path, force_checkpoint=force_checkpoint)


# ── Operational sub-repository ────────────────────────────────────────


class OperationalRepository:
    """High-churn bookkeeping state via fathomdb operational collections.

    latest_state collections are read via trace_operational_collection
    (which returns current_rows). append_only_log collections are read via
    read_operational_collection (which supports filtered reads).
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Internal helpers ──────────────────────────────────────────────

    def _get_current(self, collection: str, record_key: str | None = None) -> list:
        """Read current rows from a latest_state collection."""
        traced = self._engine.admin.trace_operational_collection(collection, record_key)
        return traced.current_rows

    def _get_current_payload(
        self, collection: str, record_key: str
    ) -> dict[str, Any] | None:
        rows = self._get_current(collection, record_key)
        if not rows:
            return None
        return rows[0].payload_json

    def _list_current_payloads(self, collection: str) -> list[dict[str, Any]]:
        rows = self._get_current(collection)
        return [r.payload_json for r in rows]

    # ── Settings ──────────────────────────────────────────────────────

    def put_setting(self, key: str, value: str) -> None:
        """Store a user setting by key."""
        self._engine.write(
            WriteRequest(
                label="settings-put",
                operational_writes=[
                    OperationalPut(
                        collection="user_settings",
                        record_key=key,
                        payload_json={
                            "key": key,
                            "value": value,
                            "updated_at": _now_iso(),
                        },
                        source_ref="memex:settings",
                    )
                ],
            )
        )

    def get_setting(self, key: str) -> str | None:
        """Return a setting value by key, or None."""
        payload = self._get_current_payload("user_settings", key)
        if payload is None:
            return None
        return payload.get("value")

    def list_settings(self) -> list[dict[str, Any]]:
        """Return all user settings."""
        return self._list_current_payloads("user_settings")

    def delete_setting(self, key: str) -> None:
        """Delete a setting by key."""
        self._engine.write(
            WriteRequest(
                label="settings-delete",
                operational_writes=[
                    OperationalDelete(
                        collection="user_settings",
                        record_key=key,
                        source_ref="memex:settings",
                    )
                ],
            )
        )

    # ── Connector health ──────────────────────────────────────────────

    def put_connector_health(
        self,
        name: str,
        *,
        status: str = "healthy",
        error: str | None = None,
        tools_discovered: int = 0,
    ) -> None:
        """Store connector health status."""
        self._engine.write(
            WriteRequest(
                label="connector-health-put",
                operational_writes=[
                    OperationalPut(
                        collection="connector_health",
                        record_key=name,
                        payload_json={
                            "name": name,
                            "status": status,
                            "last_check": _now_iso(),
                            "error": error,
                            "tools_discovered": tools_discovered,
                        },
                        source_ref="memex:connector-health",
                    )
                ],
            )
        )

    def get_connector_health(self, name: str) -> dict[str, Any] | None:
        """Return health record for a connector."""
        return self._get_current_payload("connector_health", name)

    def list_connector_health(self) -> list[dict[str, Any]]:
        """Return all connector health records."""
        return self._list_current_payloads("connector_health")

    # ── Audit log ─────────────────────────────────────────────────────

    def append_audit(
        self,
        *,
        connector: str,
        action: str,
        granted: bool = True,
        goal_id: str | None = None,
        session_id: str | None = None,
        result_summary: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        """Append an entry to the audit log."""
        record_key = f"audit-{time.time_ns()}"
        payload: dict[str, Any] = {
            "connector": connector,
            "action": action,
            "granted": granted,
            "timestamp": _now_iso(),
        }
        if goal_id:
            payload["goal_id"] = goal_id
        if session_id:
            payload["session_id"] = session_id
        if result_summary:
            payload["result_summary"] = result_summary
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms

        self._engine.write(
            WriteRequest(
                label="audit-append",
                operational_writes=[
                    OperationalAppend(
                        collection="audit_log",
                        record_key=record_key,
                        payload_json=payload,
                        source_ref="memex:audit",
                    )
                ],
            )
        )

    def list_audit(
        self,
        *,
        connector: str | None = None,
        session_id: str | None = None,
        goal_id: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Return filtered audit log entries."""
        filters = []
        if connector:
            filters.append(OperationalFilterClause.exact("connector", connector))
        if session_id:
            filters.append(OperationalFilterClause.exact("session_id", session_id))
        if goal_id:
            filters.append(OperationalFilterClause.exact("goal_id", goal_id))

        if not filters:
            # read_operational_collection requires ≥1 filter; fall back to trace
            traced = self._engine.admin.trace_operational_collection("audit_log")
            rows = [m.payload_json for m in traced.mutations if m.op_kind != "delete"]
            return rows[:limit]

        report = self._engine.admin.read_operational_collection(
            OperationalReadRequest(
                collection_name="audit_log",
                filters=filters,
                limit=limit,
            )
        )
        return [r.payload_json for r in report.rows]

    # ── Human model (singleton) ───────────────────────────────────────

    def put_human_model(self, profile: dict[str, Any]) -> None:
        """Store the human partner model."""
        self._engine.write(
            WriteRequest(
                label="human-model-put",
                operational_writes=[
                    OperationalPut(
                        collection="human_model",
                        record_key="singleton",
                        payload_json=profile,
                        source_ref="memex:human-model",
                    )
                ],
            )
        )

    def get_human_model(self) -> dict[str, Any] | None:
        """Return the human partner model."""
        return self._get_current_payload("human_model", "singleton")

    # ── Session context (singleton) ───────────────────────────────────

    def put_session_context(self, ctx: dict[str, Any]) -> None:
        """Store session context."""
        self._engine.write(
            WriteRequest(
                label="session-context-put",
                operational_writes=[
                    OperationalPut(
                        collection="session_context",
                        record_key="singleton",
                        payload_json=ctx,
                        source_ref="memex:session-context",
                    )
                ],
            )
        )

    def get_session_context(self) -> dict[str, Any] | None:
        """Return current session context."""
        return self._get_current_payload("session_context", "singleton")

    # ── Auto-ingest sources ───────────────────────────────────────────

    def put_auto_ingest_source(self, source_id: str, config: dict[str, Any]) -> None:
        """Store an auto-ingest source config."""
        self._engine.write(
            WriteRequest(
                label="auto-ingest-put",
                operational_writes=[
                    OperationalPut(
                        collection="auto_ingest_sources",
                        record_key=source_id,
                        payload_json=config,
                        source_ref="memex:auto-ingest",
                    )
                ],
            )
        )

    def get_auto_ingest_source(self, source_id: str) -> dict[str, Any] | None:
        """Return auto-ingest source by ID."""
        return self._get_current_payload("auto_ingest_sources", source_id)

    def list_auto_ingest_sources(self) -> list[dict[str, Any]]:
        """Return all auto-ingest source configs."""
        return self._list_current_payloads("auto_ingest_sources")

    # ── Intake log ────────────────────────────────────────────────────

    def put_intake_log(
        self,
        record_id: str,
        *,
        source: str,
        status: str,
        action_type: str | None = None,
        action_data: str | None = None,
        error: str | None = None,
    ) -> None:
        """Store an intake log record."""
        payload: dict[str, Any] = {
            "source": source,
            "status": status,
            "received_at": _now_iso(),
        }
        if action_type:
            payload["action_type"] = action_type
        if action_data:
            payload["action_data"] = action_data
        if error:
            payload["error"] = error

        self._engine.write(
            WriteRequest(
                label="intake-log-put",
                operational_writes=[
                    OperationalPut(
                        collection="intake_log",
                        record_key=record_id,
                        payload_json=payload,
                        source_ref="memex:intake",
                    )
                ],
            )
        )

    def get_intake_log(self, record_id: str) -> dict[str, Any] | None:
        """Return an intake log record by ID."""
        return self._get_current_payload("intake_log", record_id)

    def list_intake_logs(self) -> list[dict[str, Any]]:
        """Return all intake log records with their record keys."""
        rows = self._get_current("intake_log")
        results = []
        for r in rows:
            entry = dict(r.payload_json)
            entry["_record_key"] = r.record_key
            results.append(entry)
        return results

    def update_intake_log_status(
        self,
        record_id: str,
        *,
        status: str,
        run_id: int | None = None,
        error: str | None = None,
    ) -> None:
        """Update the status of an existing intake log record."""
        current = self._get_current_payload("intake_log", record_id)
        if current is None:
            return
        payload = dict(current)
        payload["status"] = status
        if run_id is not None:
            payload["run_id"] = run_id
        if error is not None:
            payload["error"] = error
        self._engine.write(
            WriteRequest(
                label="intake-log-update",
                operational_writes=[
                    OperationalPut(
                        collection="intake_log",
                        record_key=record_id,
                        payload_json=payload,
                        source_ref="memex:intake",
                    )
                ],
            )
        )

    # ── Tool usage stats ──────────────────────────────────────────────

    def record_tool_usage(self, tool_name: str, keyword_matched: str) -> None:
        """Increment usage counter for a tool keyword."""
        composite_key = f"{tool_name}:{keyword_matched}"
        current = self._get_current_payload("tool_usage_stats", composite_key)
        count = (current.get("call_count", 0) if current else 0) + 1

        self._engine.write(
            WriteRequest(
                label="tool-usage-put",
                operational_writes=[
                    OperationalPut(
                        collection="tool_usage_stats",
                        record_key=composite_key,
                        payload_json={
                            "tool_name": tool_name,
                            "keyword_matched": keyword_matched,
                            "call_count": count,
                            "last_used": _now_iso(),
                        },
                        source_ref="memex:tool-usage",
                    )
                ],
            )
        )

    def get_tool_usage(
        self, tool_name: str, keyword_matched: str
    ) -> dict[str, Any] | None:
        """Return usage stats for a tool keyword pair."""
        return self._get_current_payload(
            "tool_usage_stats", f"{tool_name}:{keyword_matched}"
        )

    def get_tool_usage_stats(
        self, tool_name: str | None = None
    ) -> list[dict[str, Any]]:
        """Return all tool usage stats, optionally filtered by tool_name."""
        all_stats = self._list_current_payloads("tool_usage_stats")
        if tool_name is None:
            return all_stats
        return [s for s in all_stats if s.get("tool_name") == tool_name]

    # ── Agent self-model (singleton) ─────────────────────────────────

    def put_agent_self_model(self, model: dict) -> None:
        """Store the agent self-model."""
        self._engine.write(
            WriteRequest(
                label="agent-self-model-put",
                operational_writes=[
                    OperationalPut(
                        collection="agent_self_model",
                        record_key="singleton",
                        payload_json=model,
                        source_ref="memex:agent-self-model",
                    )
                ],
            )
        )

    def get_agent_self_model(self) -> dict | None:
        """Return the agent self-model."""
        return self._get_current_payload("agent_self_model", "singleton")


# ── Conversation sub-repository ───────────────────────────────────────


class ConversationRepository:
    """Conversation turns stored as fathomdb nodes with FTS-searchable chunks."""

    NODE_KIND = "ConversationTurn"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def log_turn(
        self,
        session_id: str,
        role: str,
        content: str,
        timestamp: datetime,
        *,
        classification: str | None = None,
        reflect_result: str | None = None,
    ) -> str:
        """Append a conversation turn. Returns the logical_id."""
        logical_id = f"turn:{new_id()}"
        row_id = new_row_id()
        ts_iso = timestamp.isoformat()

        props: dict[str, Any] = {
            "session_id": session_id,
            "role": role,
            "content": content,
            "timestamp": ts_iso,
        }
        if classification:
            props["classification"] = classification
        if reflect_result:
            props["reflect_result"] = reflect_result

        chunk_id = f"chunk:{logical_id}"

        self._engine.write(
            WriteRequest(
                label="conversation-log",
                nodes=[
                    NodeInsert(
                        row_id=row_id,
                        logical_id=logical_id,
                        kind=self.NODE_KIND,
                        properties=props,
                        source_ref=f"memex:conversation:{session_id}",
                        upsert=False,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
                chunks=[
                    ChunkInsert(
                        id=chunk_id,
                        node_logical_id=logical_id,
                        text_content=content,
                    )
                ],
            )
        )
        return logical_id

    def query(
        self,
        *,
        session_id: str | None = None,
        role: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query conversation turns, optionally filtered by session/role/since."""
        q = self._engine.nodes(self.NODE_KIND)
        if session_id:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if role:
            q = q.filter_json_text_eq("$.role", role)
        q = q.limit(limit)
        rows = q.execute()

        results = []
        since_iso = since.isoformat() if since else None
        for node in rows.nodes:
            if since_iso:
                ts = (node.properties or {}).get("timestamp", "")
                if ts < since_iso:
                    continue
            results.append(self._node_to_dict(node))
        return results

    def search(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        """FTS search over conversation turn content."""
        q = self._engine.nodes(self.NODE_KIND).text_search(query, limit=limit)
        rows = q.execute()
        return [self._node_to_dict(hit.node) for hit in rows.hits]

    def cleanup(self, *, before: datetime) -> int:
        """Retire conversation turns older than *before*. Returns count."""
        # Query all turns, filter client-side by ISO timestamp comparison
        q = self._engine.nodes(self.NODE_KIND).limit(10000)
        rows = q.execute()

        before_iso = before.isoformat()
        to_retire = [
            node
            for node in rows.nodes
            if (node.properties or {}).get("timestamp", "9") < before_iso
        ]
        if not to_retire:
            return 0

        retires = [
            NodeRetire(
                logical_id=node.logical_id,
                source_ref="memex:conversation:cleanup",
            )
            for node in to_retire
        ]
        self._engine.write(
            WriteRequest(
                label="conversation-cleanup",
                node_retires=retires,
            )
        )
        return len(retires)

    def get_conversation_context(
        self, logical_id: str, *, window: int = 5
    ) -> list[dict]:
        """Return *window* turns before and after the target turn (inclusive).

        Finds the target turn, gets its session_id, queries all turns for that
        session, locates the target, and returns the surrounding slice.
        """
        # Fetch the target turn to discover its session_id
        target = _get_one(self._engine, self.NODE_KIND, logical_id)
        if target is None:
            return []
        session_id = target.get("session_id", "")
        if not session_id:
            return []

        # Get all turns for this session (generous limit)
        all_turns = self.query(session_id=session_id, limit=10000)
        # Sort by timestamp so the window is chronological
        all_turns.sort(key=lambda t: t.get("timestamp", ""))

        # Find the position of the target turn
        idx = None
        for i, t in enumerate(all_turns):
            if t["logical_id"] == logical_id:
                idx = i
                break
        if idx is None:
            return []

        start = max(0, idx - window)
        end = min(len(all_turns), idx + window + 1)
        return all_turns[start:end]

    @staticmethod
    def _node_to_dict(node: Any) -> dict[str, Any]:
        """Conversation-specific dict with cherry-picked keys."""
        props = node.properties if isinstance(node.properties, dict) else {}
        return {
            "logical_id": node.logical_id,
            "session_id": props.get("session_id", ""),
            "role": props.get("role", ""),
            "content": props.get("content", ""),
            "timestamp": props.get("timestamp", ""),
        }


# ── Goals sub-repository ─────────────────────────────────────────────


class GoalsRepository:
    """Goal graph: nodes of kind ``Goal`` with parent-child and blocker edges."""

    NODE_KIND = "Goal"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Adapter ───────────────────────────────────────────────────────

    @staticmethod
    def _to_goal(d: dict[str, Any]) -> Goal:
        d = dict(d)  # copy to avoid mutating
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at", "last_touched_at", "deadline")
        # Coerce enums from strings
        if isinstance(d.get("status"), str):
            d["status"] = GoalStatus(d["status"])
        if isinstance(d.get("priority"), str):
            d["priority"] = GoalPriority(d["priority"])
        return Goal(**d)

    # ── Mutations ─────────────────────────────────────────────────────

    def create(
        self,
        goal_id: str,
        title: str,
        description: str,
        status: str,
        priority: str,
        *,
        parent_id: str | None = None,
        blocked_by_goal_id: str | None = None,
        deadline: str | None = None,
        metadata: dict[str, Any] | None = None,
        created_at: str | None = None,
        updated_at: str | None = None,
        last_touched_at: str | None = None,
    ) -> str:
        """Create a new Goal node.  Returns the logical_id."""
        logical_id = f"goal:{goal_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "goal_id": goal_id,
            "title": title,
            "description": description,
            "status": status,
            "priority": priority,
            "created_at": created_at or now,
            "updated_at": updated_at or now,
            "last_touched_at": last_touched_at or now,
        }
        if parent_id is not None:
            props["parent_id"] = parent_id
        if deadline is not None:
            props["deadline"] = deadline
        if metadata is not None:
            props["metadata"] = metadata

        edges: list[EdgeInsert] = []
        if parent_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:parent_of:{parent_id}:{goal_id}",
                    source_logical_id=f"goal:{parent_id}",
                    target_logical_id=logical_id,
                    kind=EDGE_PARENT_OF,
                    properties={},
                    source_ref="memex:goals",
                    upsert=True,
                )
            )
        if blocked_by_goal_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:blocks:{blocked_by_goal_id}:{goal_id}",
                    source_logical_id=f"goal:{blocked_by_goal_id}",
                    target_logical_id=logical_id,
                    kind=EDGE_BLOCKS,
                    properties={},
                    source_ref="memex:goals",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="goal-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.NODE_KIND,
                        properties=props,
                        source_ref="memex:goals",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def update(self, goal_id: str, **kwargs: Any) -> None:
        """Update a goal by merging *kwargs* into its current properties (upsert)."""
        lid = f"goal:{goal_id}"
        props = _get_raw_props(self._engine, self.NODE_KIND, lid)
        props.update(kwargs)
        now = _now_iso()
        props["updated_at"] = now
        props["last_touched_at"] = now
        # Serialize enums to strings
        for k, v in props.items():
            if hasattr(v, "value"):
                props[k] = v.value

        self._engine.write(
            WriteRequest(
                label="goal-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=lid,
                        kind=self.NODE_KIND,
                        properties=props,
                        source_ref="memex:goals",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Queries ───────────────────────────────────────────────────────

    def get(self, goal_id: str) -> Goal | None:
        """Return a goal by ID, or None."""
        d = _get_one(self._engine, self.NODE_KIND, f"goal:{goal_id}")
        if d is None:
            return None
        return self._to_goal(d)

    def list(self, *, status: str | None = None, limit: int = 100) -> list[Goal]:
        """Return goals, optionally filtered by status."""
        q = self._engine.nodes(self.NODE_KIND)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        q = q.limit(limit)
        rows = q.execute()
        return [self._to_goal(_node_to_dict(n)) for n in rows.nodes]

    def get_children(self, parent_id: str) -> list[Goal]:
        """Return direct children of *parent_id* via PARENT_OF edges."""
        dicts = _traverse_out(
            self._engine,
            self.NODE_KIND,
            f"goal:{parent_id}",
            EDGE_PARENT_OF,
        )
        return [self._to_goal(d) for d in dicts]

    def get_tree(self, root_id: str | None = None) -> list[Goal]:
        """Return a goal and all descendants via BFS with bulk-fetched goals.

        If *root_id* is None, return all goals.
        Uses a single bulk query to pre-load all goals and builds the
        children map from each goal's ``parent_id``, avoiding per-node
        edge traversals (N+1).
        """
        if root_id is None:
            return self.list()
        # Pre-load all goals in a single query
        all_goals = self.list()
        goals_by_id = {g.goal_id: g for g in all_goals}
        if root_id not in goals_by_id:
            return []
        # Build children map from parent_id rather than per-node traversals
        children_map: dict[str, list[str]] = {}
        for g in all_goals:
            if g.parent_id:
                children_map.setdefault(g.parent_id, []).append(g.goal_id)
        result: list[Goal] = []
        queue = [root_id]
        visited: set[str] = set()
        while queue:
            gid = queue.pop(0)
            if gid in visited:
                continue
            visited.add(gid)
            if gid in goals_by_id:
                result.append(goals_by_id[gid])
                queue.extend(children_map.get(gid, []))
        return result

    def get_stale_goals(self, threshold: datetime) -> list[Goal]:
        """Return active goals where updated_at < *threshold*."""
        active = self.list(status="active")
        threshold_iso = threshold.isoformat()
        return [g for g in active if g.updated_at.isoformat() < threshold_iso]

    def get_approaching_deadlines(self, horizon: datetime) -> list[Goal]:
        """Return active goals with a deadline before *horizon*."""
        active = self.list(status="active")
        horizon_iso = horizon.isoformat()
        return [
            g
            for g in active
            if g.deadline is not None and g.deadline.isoformat() < horizon_iso
        ]

    def create_goal_entity_link(
        self,
        goal_id: str,
        entity_id: str,
        relationship: str = "related",
    ) -> str:
        """Create a GOAL_ENTITY_LINK edge from a goal to a WMEntity node."""
        edge_lid = f"edge:goal_entity_link:{goal_id}:{entity_id}"
        self._engine.write(
            WriteRequest(
                label="goal-entity-link",
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"goal:{goal_id}",
                        target_logical_id=f"wm_entity:{entity_id}",
                        kind=EDGE_GOAL_ENTITY_LINK,
                        properties={
                            "goal_id": goal_id,
                            "entity_id": entity_id,
                            "relationship": relationship,
                            "created_at": _now_iso(),
                        },
                        source_ref="memex:goals",
                        upsert=True,
                    )
                ],
            )
        )
        return edge_lid

    def list_goal_entity_links(self, goal_id: str) -> list[dict]:
        """Traverse GOAL_ENTITY_LINK edges out from a goal."""
        rows = (
            self._engine.nodes(self.NODE_KIND)
            .filter_logical_id_eq(f"goal:{goal_id}")
            .traverse(
                direction=TraverseDirection.OUT,
                label=EDGE_GOAL_ENTITY_LINK,
                max_depth=1,
            )
            .limit(100)
            .execute()
        )
        _check_degraded(rows, "list_goal_entity_links")
        results: list[dict] = []
        for n in rows.nodes:
            if n.logical_id == f"goal:{goal_id}":
                continue
            d = _node_to_dict(n)
            results.append(d)
        return results

    def create_meeting_goal_link(
        self,
        meeting_id: str,
        goal_id: str,
        relationship: str = "explicit",
    ) -> str:
        """Create a MEETING_GOAL_LINK edge from a meeting to a goal.

        Also creates a lightweight link node so that traversal returns a
        node whose properties include ``relationship``.
        """
        now_iso = _now_iso()
        link_node_lid = f"goal:{goal_id}:{relationship}"
        edge_lid = f"edge:meeting_goal_link:{meeting_id}:{goal_id}:{relationship}"
        self._engine.write(
            WriteRequest(
                label="meeting-goal-link",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=link_node_lid,
                        kind="goal",
                        properties={
                            "goal_id": goal_id,
                            "meeting_id": meeting_id,
                            "relationship": relationship,
                            "created_at": now_iso,
                            "updated_at": now_iso,
                            "last_touched_at": now_iso,
                            "title": "",
                            "description": "",
                            "status": "active",
                            "priority": "medium",
                        },
                        source_ref="memex:goals",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"meeting:{meeting_id}",
                        target_logical_id=link_node_lid,
                        kind=EDGE_MEETING_GOAL_LINK,
                        properties={
                            "meeting_id": meeting_id,
                            "goal_id": goal_id,
                            "relationship": relationship,
                            "created_at": now_iso,
                        },
                        source_ref="memex:goals",
                        upsert=True,
                    )
                ],
            )
        )
        return edge_lid

    def list_meeting_goal_links(self, meeting_id: str) -> list[dict]:
        """Traverse MEETING_GOAL_LINK edges out from a meeting."""
        rows = (
            self._engine.nodes(_MEETING_KIND)
            .filter_logical_id_eq(f"meeting:{meeting_id}")
            .traverse(
                direction=TraverseDirection.OUT,
                label=EDGE_MEETING_GOAL_LINK,
                max_depth=1,
            )
            .limit(100)
            .execute()
        )
        _check_degraded(rows, "list_meeting_goal_links")
        results: list[dict] = []
        for n in rows.nodes:
            if n.logical_id == f"meeting:{meeting_id}":
                continue
            d = _node_to_dict(n)
            results.append(d)
        return results

    def delete_meeting_goal_link(
        self,
        meeting_id: str,
        goal_id: str,
        relationship: str = "explicit",
    ) -> None:
        """Retire a meeting-goal link node and its edge."""
        link_node_lid = f"goal:{goal_id}:{relationship}"
        self._engine.write(
            WriteRequest(
                label="meeting-goal-link-delete",
                node_retires=[
                    NodeRetire(
                        logical_id=link_node_lid,
                        source_ref="memex:goals",
                    )
                ],
            )
        )

    # ── Entity-to-goals reverse lookup ────────────────────────────────

    def list_goals_for_entity(self, entity_id: str) -> list[dict]:
        """Traverse IN on GOAL_ENTITY_LINK from a WMEntity to find linked goals."""
        rows = (
            self._engine.nodes(_WM_ENTITY_KIND)
            .filter_logical_id_eq(f"wm_entity:{entity_id}")
            .traverse(
                direction=TraverseDirection.IN,
                label=EDGE_GOAL_ENTITY_LINK,
                max_depth=1,
            )
            .limit(100)
            .execute()
        )
        _check_degraded(rows, "list_goals_for_entity")
        results: list[dict] = []
        for n in rows.nodes:
            if n.logical_id == f"wm_entity:{entity_id}":
                continue
            results.append(_node_to_dict(n))
        return results

    # ── Meeting-entity links ──────────────────────────────────────────

    def create_meeting_entity_link(
        self,
        meeting_id: str,
        entity_id: str,
        relationship: str = "attendee",
    ) -> str:
        """Create a MEETING_ENTITY_LINK edge from a meeting to a WMEntity."""
        edge_lid = f"edge:meeting_entity_link:{meeting_id}:{entity_id}"
        self._engine.write(
            WriteRequest(
                label="meeting-entity-link",
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"meeting:{meeting_id}",
                        target_logical_id=f"wm_entity:{entity_id}",
                        kind=EDGE_MEETING_ENTITY_LINK,
                        properties={
                            "meeting_id": meeting_id,
                            "entity_id": entity_id,
                            "relationship": relationship,
                            "created_at": _now_iso(),
                        },
                        source_ref="memex:goals",
                        upsert=True,
                    )
                ],
            )
        )
        return edge_lid

    def list_meeting_entity_links(self, meeting_id: str) -> list[dict]:
        """Traverse MEETING_ENTITY_LINK edges out from a meeting."""
        rows = (
            self._engine.nodes(_MEETING_KIND)
            .filter_logical_id_eq(f"meeting:{meeting_id}")
            .traverse(
                direction=TraverseDirection.OUT,
                label=EDGE_MEETING_ENTITY_LINK,
                max_depth=1,
            )
            .limit(100)
            .execute()
        )
        _check_degraded(rows, "list_meeting_entity_links")
        results: list[dict] = []
        for n in rows.nodes:
            if n.logical_id == f"meeting:{meeting_id}":
                continue
            results.append(_node_to_dict(n))
        return results

    # ── Calendar events ───────────────────────────────────────────────

    CALENDAR_EVENT_KIND = "CalendarEvent"

    def upsert_calendar_event(
        self,
        event_id: str,
        provider: str,
        title: str,
        starts_at: str,
        *,
        ends_at: str | None = None,
        attendees: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Create or update a CalendarEvent node. Returns the logical_id."""
        logical_id = f"calendar_event:{event_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "event_id": event_id,
            "provider": provider,
            "title": title,
            "starts_at": starts_at,
            "synced_at": now,
        }
        if ends_at is not None:
            props["ends_at"] = ends_at
        if attendees is not None:
            props["attendees"] = attendees
        if metadata is not None:
            props["metadata"] = metadata

        self._engine.write(
            WriteRequest(
                label="calendar-event-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.CALENDAR_EVENT_KIND,
                        properties=props,
                        source_ref="memex:calendar",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def list_upcoming_calendar_events(
        self,
        horizon: str,
    ) -> list[dict[str, Any]]:
        """Return CalendarEvent nodes with starts_at < horizon."""
        rows = self._engine.nodes(self.CALENDAR_EVENT_KIND).limit(500).execute()
        _check_degraded(rows, "list_upcoming_calendar_events")
        results: list[dict[str, Any]] = []
        for n in rows.nodes:
            d = _node_to_dict(n)
            starts = d.get("starts_at", "")
            if starts and starts < horizon:
                results.append(d)
        results.sort(key=lambda d: d.get("starts_at", ""))
        return results


# ── Scheduler sub-repository ─────────────────────────────────────────


class SchedulerRepository:
    """Scheduler tasks and task-runs as fathomdb graph nodes."""

    TASK_KIND = "SchedulerTask"
    RUN_KIND = "TaskRun"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Adapter ──────────────────────────────────────────────────────

    @staticmethod
    def _to_task(d: dict[str, Any]) -> ScheduledTask:
        d = dict(d)  # copy to avoid mutating
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        # Coerce action_type enum from string
        if isinstance(d.get("action_type"), str):
            d["action_type"] = ActionType(d["action_type"])
        return ScheduledTask(**d)

    # ── Task mutations ────────────────────────────────────────────────

    def create_task(
        self,
        task_id: str,
        name: str,
        cron_expr: str,
        action_type: str,
        *,
        enabled: bool = True,
        builtin: bool = False,
        action_data: dict[str, Any] | None = None,
        goal_id: str | None = None,
    ) -> str:
        """Create a new scheduler task."""
        logical_id = f"task:{task_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "task_id": task_id,
            "name": name,
            "cron_expr": cron_expr,
            "action_type": action_type,
            "enabled": enabled,
            "builtin": builtin,
            "created_at": now,
            "updated_at": now,
        }
        if action_data is not None:
            props["action_data"] = action_data
        if goal_id is not None:
            props["goal_id"] = goal_id

        self._engine.write(
            WriteRequest(
                label="task-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.TASK_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def toggle_task(self, task_id: str, enabled: bool) -> None:
        """Enable or disable a scheduler task."""
        lid = f"task:{task_id}"
        props = _get_raw_props(self._engine, self.TASK_KIND, lid)
        props["enabled"] = enabled
        props["updated_at"] = _now_iso()
        # Serialize enums to strings
        for k, v in props.items():
            if hasattr(v, "value"):
                props[k] = v.value

        self._engine.write(
            WriteRequest(
                label="task-toggle",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"task:{task_id}",
                        kind=self.TASK_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Task queries ──────────────────────────────────────────────────

    def get_task(self, task_id: str) -> ScheduledTask | None:
        """Return a task by ID, or None."""
        d = _get_one(self._engine, self.TASK_KIND, f"task:{task_id}")
        if d is None:
            return None
        return self._to_task(d)

    def list_tasks(
        self,
        *,
        enabled_only: bool = False,
        limit: int = 1000,
    ) -> list[ScheduledTask]:
        """Return tasks, optionally filtered to enabled only."""
        q = self._engine.nodes(self.TASK_KIND)
        if enabled_only:
            q = q.filter_json_bool_eq("$.enabled", True)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_tasks")
        return [self._to_task(_node_to_dict(n)) for n in rows.nodes]

    # ── Run mutations ─────────────────────────────────────────────────

    def record_run(
        self,
        task_id: str | None,
        *,
        status: str = "queued",
        queued_at: Any = None,
        action_type: str | None = None,
        action_data: dict | None = None,
        max_retries: int = 3,
        priority: int = 5,
    ) -> str:
        """Record a new task run. Returns run logical_id."""
        run_uid = new_id()
        logical_id = f"run:{run_uid}"
        props: dict[str, Any] = {
            "run_id": run_uid,
            "task_id": task_id,
            "status": status,
            "created_at": _now_iso(),
            "max_retries": max_retries,
            "priority": priority,
            "attempt": 0,
        }
        if queued_at is not None:
            props["queued_at"] = (
                queued_at.isoformat()
                if hasattr(queued_at, "isoformat")
                else str(queued_at)
            )
        if action_type is not None:
            props["action_type"] = action_type
        if action_data is not None:
            props["action_data"] = action_data

        self._engine.write(
            WriteRequest(
                label="task-run-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.RUN_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:task_run:{task_id}:{run_uid}",
                        source_logical_id=f"task:{task_id}",
                        target_logical_id=logical_id,
                        kind=EDGE_HAS_RUN,
                        properties={},
                        source_ref="memex:scheduler",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def complete_run(
        self,
        run_id: str,
        status: str = "completed",
        *,
        result: str = "",
        error: str | None = None,
    ) -> None:
        """Mark a task run as completed or failed."""
        # run_id is the full logical_id e.g. "run:abc123"
        props = _get_raw_props(self._engine, self.RUN_KIND, run_id)
        props["status"] = status
        props["completed_at"] = _now_iso()
        if result:
            props["result"] = result
        if error is not None:
            props["error"] = error

        self._engine.write(
            WriteRequest(
                label="task-run-complete",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=run_id,
                        kind=self.RUN_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Run queries ───────────────────────────────────────────────────

    def get_runs(self, task_id: str, *, limit: int = 10) -> list[dict[str, Any]]:
        """Get runs linked to *task_id* via HAS_RUN edges."""
        results = _traverse_out(
            self._engine,
            self.TASK_KIND,
            f"task:{task_id}",
            EDGE_HAS_RUN,
            limit=limit + 1,
        )
        return results[:limit]

    def update_task(self, task_id: str, **kwargs: Any) -> ScheduledTask:
        """Update a task by merging kwargs into its properties."""
        lid = f"task:{task_id}"
        props = _get_raw_props(self._engine, self.TASK_KIND, lid)
        props.update(kwargs)
        props["updated_at"] = _now_iso()
        # Serialize enums to strings
        for k, v in props.items():
            if hasattr(v, "value"):
                props[k] = v.value

        self._engine.write(
            WriteRequest(
                label="task-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"task:{task_id}",
                        kind=self.TASK_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return self.get_task(task_id)

    def record_adhoc_run(
        self,
        action_type: str,
        action_data: dict[str, Any],
        *,
        priority: int = 5,
        max_retries: int = 3,
    ) -> str:
        """Record an ad-hoc run (no parent task). Returns the logical_id."""
        run_uid = new_id()
        logical_id = f"run:{run_uid}"
        props: dict[str, Any] = {
            "run_id": run_uid,
            "task_id": None,
            "status": "queued",
            "action_type": action_type,
            "action_data": action_data,
            "priority": priority,
            "max_retries": max_retries,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="task-run-adhoc",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.RUN_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def get_queued_runs(self) -> list[dict[str, Any]]:
        """Return TaskRun nodes with status=='queued' and action_type is not None."""
        rows = (
            self._engine.nodes(self.RUN_KIND)
            .filter_json_text_eq("$.status", "queued")
            .limit(1000)
            .execute()
        )
        _check_degraded(rows, "get_queued_runs")
        results = []
        for n in rows.nodes:
            d = _node_to_dict(n)
            if d.get("action_type") is not None:
                results.append(d)
        return results

    def cleanup_stale_runs(self) -> int:
        """Mark stale running/retrying runs as failed."""
        stale = []
        for status in ("running", "retrying"):
            rows = (
                self._engine.nodes(self.RUN_KIND)
                .filter_json_text_eq("$.status", status)
                .limit(1000)
                .execute()
            )
            stale.extend(rows.nodes)
        if not stale:
            return 0
        now = _now_iso()
        nodes: list[NodeInsert] = []
        for n in stale:
            props = dict(n.properties or {})
            props["status"] = "failed"
            props["completed_at"] = now
            nodes.append(
                NodeInsert(
                    row_id=new_row_id(),
                    logical_id=n.logical_id,
                    kind=self.RUN_KIND,
                    properties=props,
                    source_ref="memex:scheduler",
                    upsert=True,
                    chunk_policy=ChunkPolicy.PRESERVE,
                )
            )
        self._engine.write(
            WriteRequest(
                label="task-run-cleanup",
                nodes=nodes,
            )
        )
        return len(stale)

    def seed_builtins(self, tasks: list[Any]) -> int:
        """Seed built-in tasks that do not yet exist.

        Accepts both dicts and ScheduledTask model objects.
        """
        created = 0
        for t in tasks:
            # Support both dict and model access
            if isinstance(t, dict):
                task_id = t["task_id"]
                name = t.get("name", task_id)
                cron_expr = t.get("cron_expr", "* * * * *")
                action_type = t.get("action_type", "notification")
                enabled = t.get("enabled", True)
                builtin = t.get("builtin", True)
                action_data = t.get("action_data")
            else:
                task_id = t.task_id
                name = t.name or task_id
                cron_expr = t.cron_expr
                at = t.action_type
                action_type = at.value if hasattr(at, "value") else str(at)
                enabled = t.enabled
                builtin = t.builtin
                action_data = t.action_data

            existing = self.get_task(task_id)
            if existing is None:
                self.create_task(
                    task_id=task_id,
                    name=name,
                    cron_expr=cron_expr,
                    action_type=action_type,
                    enabled=enabled,
                    builtin=builtin,
                    action_data=action_data,
                )
                created += 1
        return created

    def get_last_run(self, task_id: str) -> dict[str, Any] | None:
        """Get the most recent run for *task_id*, or None."""
        runs = self.get_runs(task_id, limit=1)
        return runs[0] if runs else None

    def get_all_runs(self, *, limit: int = 50) -> list[dict[str, Any]]:
        """List all TaskRun nodes."""
        rows = self._engine.nodes(self.RUN_KIND).limit(limit).execute()
        _check_degraded(rows, "get_all_runs")
        results = [_node_to_dict(n) for n in rows.nodes]
        results.sort(
            key=lambda d: d.get("started_at") or d.get("created_at") or "", reverse=True
        )
        return results

    def get_runs_by_action_type(
        self, action_type: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Filter TaskRun nodes by action_type property."""
        rows = (
            self._engine.nodes(self.RUN_KIND)
            .filter_json_text_eq("$.action_type", action_type)
            .limit(limit)
            .execute()
        )
        _check_degraded(rows, "get_runs_by_action_type")
        return [_node_to_dict(n) for n in rows.nodes]

    def update_run_status(
        self, run_id: str, status: str, *, attempt: int | None = None
    ) -> None:
        """Update a run's status (and optionally attempt) via read-merge-write."""
        props = _get_raw_props(self._engine, self.RUN_KIND, run_id)
        props["status"] = status
        if attempt is not None:
            props["attempt"] = attempt
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="task-run-update-status",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=run_id,
                        kind=self.RUN_KIND,
                        properties=props,
                        source_ref="memex:scheduler",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    def list_tasks_for_goal(self, goal_id: str) -> list[ScheduledTask]:
        """Return tasks whose goal_id property matches *goal_id*."""
        rows = (
            self._engine.nodes(self.TASK_KIND)
            .filter_json_text_eq("$.goal_id", goal_id)
            .limit(1000)
            .execute()
        )
        _check_degraded(rows, "list_tasks_for_goal")
        return [self._to_task(_node_to_dict(n)) for n in rows.nodes]


# ── Notifications sub-repository ─────────────────────────────────────


class NotificationsRepository:
    """Notification graph nodes with read/dismiss state."""

    NODE_KIND = "Notification"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Adapter ──────────────────────────────────────────────────────

    @staticmethod
    def _to_notification(d: dict[str, Any]) -> Notification:
        d = dict(d)  # copy to avoid mutating
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at")
        # Convert read (bool) + read_at (str|None) -> read_at (datetime|None)
        read_flag = d.pop("read", False)
        if "read_at" not in d:
            d["read_at"] = None
        if isinstance(d.get("read_at"), str):
            d["read_at"] = _parse_iso_str(d["read_at"])
        # If read flag is True but no read_at timestamp, use created_at as fallback
        if read_flag and d["read_at"] is None:
            d["read_at"] = d.get("created_at")
        # Convert dismissed (bool) + dismissed_at (str|None)
        # -> dismissed_at (datetime|None)
        dismissed_flag = d.pop("dismissed", False)
        if "dismissed_at" not in d:
            d["dismissed_at"] = None
        if isinstance(d.get("dismissed_at"), str):
            d["dismissed_at"] = _parse_iso_str(d["dismissed_at"])
        if dismissed_flag and d["dismissed_at"] is None:
            d["dismissed_at"] = d.get("created_at")
        # Coerce priority enum
        if isinstance(d.get("priority"), str):
            d["priority"] = NotificationPriority(d["priority"])
        return Notification(**d)

    # ── Mutations ─────────────────────────────────────────────────────

    def create(
        self,
        notification_id: str,
        title: str,
        *,
        body: str = "",
        priority: str = "normal",
        source: str = "",
        goal_id: str | None = None,
        action_type: str | None = None,
        action_data: dict[str, Any] | None = None,
    ) -> str:
        """Create a new notification."""
        logical_id = f"notification:{notification_id}"
        props: dict[str, Any] = {
            "notification_id": notification_id,
            "title": title,
            "body": body,
            "priority": priority,
            "source": source,
            "read": False,
            "dismissed": False,
            "created_at": _now_iso(),
        }
        if goal_id is not None:
            props["goal_id"] = goal_id
        if action_type is not None:
            props["action_type"] = action_type
        if action_data is not None:
            props["action_data"] = action_data

        self._engine.write(
            WriteRequest(
                label="notification-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.NODE_KIND,
                        properties=props,
                        source_ref="memex:notifications",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def mark_read(self, notification_id: str) -> None:
        """Mark a notification as read."""
        self._update_flag(notification_id, "read", True)

    def dismiss(self, notification_id: str) -> None:
        """Dismiss a notification."""
        self._update_flag(notification_id, "dismissed", True)

    def _update_flag(self, notification_id: str, flag: str, value: bool) -> None:
        logical_id = f"notification:{notification_id}"
        props = _get_raw_props(self._engine, self.NODE_KIND, logical_id)
        props[flag] = value
        # Store timestamp alongside the boolean flag
        timestamp_field = "read_at" if flag == "read" else "dismissed_at"
        if value:
            props[timestamp_field] = _now_iso()
        else:
            props[timestamp_field] = None
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label=f"notification-{flag}",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.NODE_KIND,
                        properties=props,
                        source_ref="memex:notifications",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Queries ───────────────────────────────────────────────────────

    def get(self, notification_id: str) -> Notification | None:
        """Return a notification by ID, or None."""
        d = _get_one(self._engine, self.NODE_KIND, f"notification:{notification_id}")
        if d is None:
            return None
        return self._to_notification(d)

    def list_pending(self, *, limit: int = 50) -> list[Notification]:
        """Return notifications that are neither read nor dismissed."""
        rows = (
            self._engine.nodes(self.NODE_KIND)
            .filter_json_bool_eq("$.read", False)
            .filter_json_bool_eq("$.dismissed", False)
            .limit(limit)
            .execute()
        )
        _check_degraded(rows, "list_pending")
        return [self._to_notification(_node_to_dict(n)) for n in rows.nodes]


# ── Meetings sub-repository ──────────────────────────────────────────


class MeetingsRepository:
    """Meeting graph: meetings, recordings, artifacts, and extraction runs."""

    MEETING_KIND = "Meeting"
    RECORDING_KIND = "MeetingRecording"
    ARTIFACT_KIND = "MeetingArtifact"
    EXTRACTION_KIND = "MeetingExtractionRun"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Adapters ────────────────────────────────────────────────────

    @staticmethod
    def _to_meeting(d: dict[str, Any]) -> MeetingRecord:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(
            d,
            "created_at",
            "updated_at",
            "started_at",
            "stopped_at",
            "transcribed_at",
            "ingested_at",
            "scheduled_for",
        )
        if isinstance(d.get("state"), str):
            try:
                d["state"] = MeetingState(d["state"])
            except ValueError:
                pass
        # Convert segment dicts to MeetingSegment objects
        raw_segs = d.get("segments")
        if isinstance(raw_segs, list):
            d["segments"] = [
                MeetingSegment(**s) if isinstance(s, dict) else s for s in raw_segs
            ]
        return MeetingRecord(**_filter_to_dataclass_fields(d, MeetingRecord))

    @staticmethod
    def _to_recording(d: dict[str, Any]) -> MeetingRecording:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(
            d,
            "created_at",
            "updated_at",
            "started_at",
            "stopped_at",
            "transcribed_at",
            "ingested_at",
        )
        if isinstance(d.get("state"), str):
            try:
                d["state"] = MeetingState(d["state"])
            except ValueError:
                pass
        # Convert segment dicts to MeetingSegment objects
        raw_segs = d.get("segments")
        if isinstance(raw_segs, list):
            d["segments"] = [
                MeetingSegment(**s) if isinstance(s, dict) else s for s in raw_segs
            ]
        return MeetingRecording(**_filter_to_dataclass_fields(d, MeetingRecording))

    @staticmethod
    def _to_artifact(d: dict[str, Any]) -> MeetingIntelligenceArtifact:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        if isinstance(d.get("artifact_type"), str):
            try:
                d["artifact_type"] = MeetingIntelligenceArtifactType(d["artifact_type"])
            except ValueError:
                pass
        d.setdefault("recording_id", None)
        return MeetingIntelligenceArtifact(
            **_filter_to_dataclass_fields(d, MeetingIntelligenceArtifact),
        )

    @staticmethod
    def _to_extraction_run(d: dict[str, Any]) -> MeetingExtractionRun:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        d.setdefault("recording_id", None)
        return MeetingExtractionRun(
            **_filter_to_dataclass_fields(d, MeetingExtractionRun),
        )

    # ── Meeting mutations ────────────────────────────────────────────

    def create_meeting(
        self,
        meeting_id: str,
        title: str,
        *,
        state: str = "created",
        attendees: list[str] | None = None,
        notes: str | None = None,
        scheduled_for: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Create a new meeting node."""
        logical_id = f"meeting:{meeting_id}"
        props: dict[str, Any] = {
            "meeting_id": meeting_id,
            "title": title,
            "state": state,
            "created_at": _now_iso(),
        }
        if attendees is not None:
            props["attendees"] = attendees
        if notes is not None:
            props["notes"] = notes
        if scheduled_for is not None:
            props["scheduled_for"] = scheduled_for
        # Store additional fields (action_items, item_id, etc.)
        for k, v in kwargs.items():
            if v is not None:
                props[k] = v

        self._engine.write(
            WriteRequest(
                label="meeting-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.MEETING_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def update_meeting(self, meeting_id: str, **kwargs: Any) -> None:
        """Update meeting properties."""
        lid = f"meeting:{meeting_id}"
        props = _get_raw_props(self._engine, self.MEETING_KIND, lid)
        props.update(kwargs)
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="meeting-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"meeting:{meeting_id}",
                        kind=self.MEETING_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Meeting queries ──────────────────────────────────────────────

    def get_meeting(self, meeting_id: str) -> MeetingRecord | None:
        """Return a meeting by ID, or None."""
        d = _get_one(self._engine, self.MEETING_KIND, f"meeting:{meeting_id}")
        if d is None:
            return None
        record = self._to_meeting(d)
        record.recordings = self.list_recordings(meeting_id)
        return record

    def list_meetings(
        self,
        *,
        state: str | None = None,
        limit: int = 50,
        include_all: bool = False,
    ) -> list[MeetingRecord]:
        """Return meetings, optionally filtered by state."""
        q = self._engine.nodes(self.MEETING_KIND)
        if not include_all and state is not None:
            q = q.filter_json_text_eq("$.state", state)
        q = q.limit(limit)
        rows = q.execute()
        return [self._to_meeting(_node_to_dict(n)) for n in rows.nodes]

    # ── Recording mutations ──────────────────────────────────────────

    def create_recording(
        self,
        recording_id: str,
        meeting_id: str,
        *,
        state: str = "recording",
        sequence_number: int = 1,
        sample_rate: int = 16000,
        audio_path: str = "",
    ) -> str:
        """Create a meeting recording node."""
        logical_id = f"recording:{recording_id}"
        props: dict[str, Any] = {
            "recording_id": recording_id,
            "meeting_id": meeting_id,
            "state": state,
            "sequence_number": sequence_number,
            "sample_rate": sample_rate,
            "created_at": _now_iso(),
        }
        if audio_path:
            props["audio_path"] = audio_path

        self._engine.write(
            WriteRequest(
                label="recording-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.RECORDING_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:meeting-recording:{meeting_id}:{recording_id}",
                        source_logical_id=f"meeting:{meeting_id}",
                        target_logical_id=logical_id,
                        kind=EDGE_HAS_RECORDING,
                        properties={},
                        source_ref="memex:meetings",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def update_recording(self, recording_id: str, **kwargs: Any) -> None:
        """Update recording properties."""
        lid = f"recording:{recording_id}"
        props = _get_raw_props(self._engine, self.RECORDING_KIND, lid)
        props.update(kwargs)
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="recording-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"recording:{recording_id}",
                        kind=self.RECORDING_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Recording queries ────────────────────────────────────────────

    def get_recording(self, recording_id: str) -> MeetingRecording | None:
        """Return a recording by ID, or None."""
        d = _get_one(
            self._engine,
            self.RECORDING_KIND,
            f"recording:{recording_id}",
        )
        if d is None:
            return None
        return self._to_recording(d)

    def list_recordings(self, meeting_id: str) -> list[MeetingRecording]:
        """Return recordings for a meeting."""
        dicts = _traverse_out(
            self._engine,
            self.MEETING_KIND,
            f"meeting:{meeting_id}",
            EDGE_HAS_RECORDING,
        )
        return [self._to_recording(d) for d in dicts]

    def get_recordings_for_cleanup(self, retention_days: int) -> list[MeetingRecord]:
        """Return meetings eligible for audio cleanup.

        Eligible means: state is INGESTED, audio_deleted is false, and
        stopped_at is older than *retention_days* ago.
        """
        cutoff = utcnow() - timedelta(days=retention_days)
        q = self._engine.nodes(self.MEETING_KIND).filter_json_text_eq(
            "$.state", MeetingState.INGESTED.value
        )
        rows = q.execute()
        results: list[MeetingRecord] = []
        for node in rows.nodes:
            d = _node_to_dict(node)
            meeting = self._to_meeting(d)
            if meeting.audio_deleted:
                continue
            if meeting.stopped_at is None or meeting.stopped_at >= cutoff:
                continue
            results.append(meeting)
        return results

    # ── Artifact mutations ───────────────────────────────────────────

    def create_artifact(
        self,
        artifact_id: str,
        meeting_id: str,
        artifact_type: str,
        *,
        title: str = "",
        content: str = "",
        recording_id: str | None = None,
        speaker: str | None = None,
        payload: dict[str, Any] | None = None,
        start_seconds: float | None = None,
        end_seconds: float | None = None,
    ) -> str:
        """Create or upsert a meeting artifact node.

        When the artifact already exists (upsert path), the original
        ``created_at`` timestamp is preserved.
        """
        logical_id = f"artifact:{artifact_id}"
        # Preserve created_at from existing artifact on upsert
        existing_created_at: str | None = None
        try:
            existing_props = _get_raw_props(
                self._engine, self.ARTIFACT_KIND, logical_id
            )
            existing_created_at = existing_props.get("created_at")
        except Exception:
            pass
        props: dict[str, Any] = {
            "artifact_id": artifact_id,
            "meeting_id": meeting_id,
            "artifact_type": artifact_type,
            "title": title,
            "content": content,
            "created_at": existing_created_at or _now_iso(),
        }
        if recording_id is not None:
            props["recording_id"] = recording_id
        if speaker is not None:
            props["speaker"] = speaker
        if payload is not None:
            props["payload"] = payload
        if start_seconds is not None:
            props["start_seconds"] = start_seconds
        if end_seconds is not None:
            props["end_seconds"] = end_seconds

        edges = [
            EdgeInsert(
                row_id=new_row_id(),
                logical_id=f"edge:meeting-artifact:{meeting_id}:{artifact_id}",
                source_logical_id=f"meeting:{meeting_id}",
                target_logical_id=logical_id,
                kind=EDGE_HAS_ARTIFACT,
                properties={},
                source_ref="memex:meetings",
                upsert=True,
            ),
        ]
        if recording_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:recording-artifact:{recording_id}:{artifact_id}",
                    source_logical_id=f"recording:{recording_id}",
                    target_logical_id=logical_id,
                    kind=EDGE_HAS_ARTIFACT,
                    properties={},
                    source_ref="memex:meetings",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="artifact-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.ARTIFACT_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def list_artifacts(
        self, meeting_id: str, *, artifact_type: str | None = None
    ) -> list[MeetingIntelligenceArtifact]:
        """Return artifacts for a meeting."""
        all_dicts = _traverse_out(
            self._engine,
            self.MEETING_KIND,
            f"meeting:{meeting_id}",
            EDGE_HAS_ARTIFACT,
            limit=1000,
        )
        if artifact_type is not None:
            all_dicts = [
                d for d in all_dicts if d.get("artifact_type") == artifact_type
            ]
        return [self._to_artifact(d) for d in all_dicts]

    def retire_artifacts(
        self,
        meeting_id: str,
        *,
        artifact_type: str | None = None,
        keep_ids: set[str] | None = None,
    ) -> int:
        """Retire (soft-delete) artifacts for a meeting.

        When *keep_ids* is given, only artifacts whose artifact_id is NOT in
        the set are retired.  When *artifact_type* is given, only artifacts of
        that type are considered.  Returns the number of retired artifacts.
        """
        existing = self.list_artifacts(meeting_id, artifact_type=artifact_type)
        retires: list[NodeRetire] = []
        for art in existing:
            if keep_ids and art.artifact_id in keep_ids:
                continue
            retires.append(
                NodeRetire(
                    logical_id=f"artifact:{art.artifact_id}",
                    source_ref="memex:meetings",
                )
            )
        if retires:
            self._engine.write(
                WriteRequest(
                    label="artifact-retire",
                    node_retires=retires,
                )
            )
        return len(retires)

    # ── Extraction run mutations ─────────────────────────────────────

    def create_extraction_run(
        self,
        run_id: str,
        meeting_id: str,
        run_type: str,
        *,
        status: str = "running",
        recording_id: str | None = None,
        model: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Create a meeting extraction run."""
        logical_id = f"extraction_run:{run_id}"
        props: dict[str, Any] = {
            "run_id": run_id,
            "meeting_id": meeting_id,
            "run_type": run_type,
            "status": status,
            "created_at": _now_iso(),
        }
        if recording_id is not None:
            props["recording_id"] = recording_id
        if model is not None:
            props["model"] = model
        if metadata is not None:
            props["metadata"] = metadata

        edges = [
            EdgeInsert(
                row_id=new_row_id(),
                logical_id=f"edge:meeting-extraction:{meeting_id}:{run_id}",
                source_logical_id=f"meeting:{meeting_id}",
                target_logical_id=logical_id,
                kind=EDGE_HAS_EXTRACTION,
                properties={},
                source_ref="memex:meetings",
                upsert=True,
            ),
        ]

        self._engine.write(
            WriteRequest(
                label="extraction-run-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.EXTRACTION_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def complete_extraction_run(
        self,
        run_id: str,
        *,
        status: str = "completed",
        artifact_count: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Mark an extraction run as completed."""
        logical_id = f"extraction_run:{run_id}"
        props = _get_raw_props(self._engine, self.EXTRACTION_KIND, logical_id)
        props["status"] = status
        props["artifact_count"] = artifact_count
        props["completed_at"] = _now_iso()
        if metadata is not None:
            existing = props.get("metadata") or {}
            existing.update(metadata)
            props["metadata"] = existing

        self._engine.write(
            WriteRequest(
                label="extraction-run-complete",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.EXTRACTION_KIND,
                        properties=props,
                        source_ref="memex:meetings",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    # ── Additional meeting queries (Phase 2c) ─────────────────────────

    def get_active_recording(
        self,
        meeting_id: str | None = None,
    ) -> MeetingRecording | None:
        """Find a recording in 'recording' state.

        When *meeting_id* is given, search that meeting only.
        When omitted, scan all recordings (compat with old MeetingStore).
        """
        if meeting_id is not None:
            recordings = self.list_recordings(meeting_id)
        else:
            rows = (
                self._engine.nodes(self.RECORDING_KIND)
                .filter_json_text_eq("$.state", "recording")
                .limit(1)
                .execute()
            )
            _check_degraded(rows, "get_active_recording")
            recordings = [self._to_recording(_node_to_dict(n)) for n in rows.nodes]
        for r in recordings:
            if r.state == MeetingState.RECORDING:
                return r
        return None

    def list_upcoming_meetings(self, horizon: str) -> list[MeetingRecord]:
        """Filter meetings with scheduled_for before horizon and state == 'created'."""
        meetings = self.list_meetings(state="created")
        results = []
        for m in meetings:
            scheduled = m.scheduled_for
            if scheduled is not None:
                # Compare as ISO strings if scheduled_for was parsed
                if isinstance(scheduled, datetime):
                    cmp = scheduled.isoformat()
                else:
                    cmp = scheduled
                if cmp < horizon:
                    results.append(m)
        return results

    def list_extraction_runs(self, meeting_id: str) -> list[MeetingExtractionRun]:
        """Traverse OUT from meeting via EDGE_HAS_EXTRACTION."""
        dicts = _traverse_out(
            self._engine,
            self.MEETING_KIND,
            f"meeting:{meeting_id}",
            EDGE_HAS_EXTRACTION,
        )
        return [self._to_extraction_run(d) for d in dicts]

    def get_latest_recording(self, meeting_id: str) -> MeetingRecording | None:
        """Return the recording with the highest sequence_number, or None."""
        recordings = self.list_recordings(meeting_id)
        if not recordings:
            return None
        recordings.sort(key=lambda r: r.sequence_number, reverse=True)
        return recordings[0]

    def next_recording_sequence(self, meeting_id: str) -> int:
        """Return count of existing recordings + 1."""
        recordings = self.list_recordings(meeting_id)
        return len(recordings) + 1

    def cleanup_stale_recordings(self) -> int:
        """Mark stale recordings as failed."""
        rows = (
            self._engine.nodes(self.RECORDING_KIND)
            .filter_json_text_eq("$.state", "recording")
            .limit(10000)
            .execute()
        )
        _check_degraded(rows, "cleanup_stale_recordings")
        if not rows.nodes:
            return 0
        now = _now_iso()
        nodes: list[NodeInsert] = []
        for n in rows.nodes:
            props = dict(n.properties or {})
            props["state"] = "failed"
            props["updated_at"] = now
            nodes.append(
                NodeInsert(
                    row_id=new_row_id(),
                    logical_id=n.logical_id,
                    kind=self.RECORDING_KIND,
                    properties=props,
                    source_ref="memex:meetings",
                    upsert=True,
                    chunk_policy=ChunkPolicy.PRESERVE,
                )
            )
        self._engine.write(
            WriteRequest(
                label="recording-cleanup",
                nodes=nodes,
            )
        )
        return len(nodes)

    # ── Delete ───────────────────────────────────────────────────────

    def delete_meeting(self, meeting_id: str) -> None:
        """Retire the meeting and all related nodes."""
        retires: list[NodeRetire] = []
        src = "memex:meetings:delete"
        lid = f"meeting:{meeting_id}"

        # Retire the meeting node itself
        retires.append(NodeRetire(logical_id=lid, source_ref=src))

        # Retire related nodes via edge traversals
        for label in (EDGE_HAS_RECORDING, EDGE_HAS_ARTIFACT, EDGE_HAS_EXTRACTION):
            rows = _traverse_out(
                self._engine,
                self.MEETING_KIND,
                lid,
                label,
                limit=1000,
            )
            retires.extend(
                NodeRetire(logical_id=r["logical_id"], source_ref=src) for r in rows
            )

        if retires:
            self._engine.write(
                WriteRequest(
                    label="meeting-delete",
                    node_retires=retires,
                )
            )
        # NOTE: Edges connecting these nodes are left dangling intentionally.
        # This matches fathomdb design: edge lifecycle is explicit but dangling
        # edges are not harmful and are detectable via check_semantics().dangling_edges.


# ── Knowledge sub-repository ────────────────────────────────────────


class KnowledgeRepository:
    """Knowledge graph: items, sources, links, trails, and forget/restore/purge."""

    ITEM_KIND = "KnowledgeItem"
    SOURCE_KIND = "KnowledgeSource"
    TRAIL_KIND = "KnowledgeTrail"
    LINK_KIND = "KnowledgeLink"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Adapter ──────────────────────────────────────────────────────

    @staticmethod
    def _to_item(d: dict[str, Any]) -> Item:  # noqa: C901
        d = dict(d)  # copy to avoid mutating
        d.pop("logical_id", None)
        _parse_iso_fields(d, "captured_at", "last_accessed")
        # fathomdb stores created_at; Item expects captured_at
        if "captured_at" not in d and "created_at" in d:
            created = d.pop("created_at")
            d["captured_at"] = (
                _parse_iso_str(created) if isinstance(created, str) else created
            )
        elif "created_at" in d:
            created = d.pop("created_at")
            # Keep captured_at from above, discard raw created_at
        # fathomdb last_accessed_at (from touch) -> last_accessed
        if "last_accessed" not in d:
            la = d.pop("last_accessed_at", None)
            if la is not None:
                if isinstance(la, str):
                    d["last_accessed"] = _parse_iso_str(la)
                elif isinstance(la, (int, float)):
                    d["last_accessed"] = datetime.fromtimestamp(la, tz=timezone.utc)
                else:
                    d["last_accessed"] = la
            else:
                # Fall back to captured_at
                d["last_accessed"] = d.get("captured_at", utcnow())
        # Map item_type -> type
        if "item_type" in d and "type" not in d:
            d["type"] = d.pop("item_type")
        elif "item_type" in d:
            d.pop("item_type")
        if isinstance(d.get("type"), str):
            d["type"] = ItemType(d["type"])
        # Wrap summary
        if "summary" in d and not isinstance(d["summary"], Summary):
            raw = d["summary"]
            if isinstance(raw, str):
                d["summary"] = Summary(text=raw)
            elif isinstance(raw, dict):
                d["summary"] = Summary(**raw)
            else:
                d["summary"] = Summary()
        # Wrap provenance
        if "provenance" in d and not isinstance(d["provenance"], Provenance):
            raw = d["provenance"]
            if isinstance(raw, dict):
                d["provenance"] = Provenance(**raw)
            else:
                d["provenance"] = Provenance()
        _parse_iso_fields(d, "expires_at", "deleted_at")
        if isinstance(d.get("updated_at"), str):
            d.pop("updated_at")  # Item model doesn't have updated_at
        return Item(**d)

    # ── Ingest / update ──────────────────────────────────────────────

    def ingest(
        self,
        item_id: str,
        title: str,
        body: str,
        item_type: str,
        *,
        source_url: str | None = None,
        author: str | None = None,
        tags: list[str] | None = None,
        summary: str | None = None,
        metadata: dict[str, Any] | None = None,
        pinned: bool = False,
        expires_at: str | None = None,
        provenance: dict[str, Any] | None = None,
    ) -> str:
        """Create a knowledge item with body as chunk for FTS. Returns logical_id."""
        logical_id = f"item:{item_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "item_id": item_id,
            "title": title,
            "body": body,
            "item_type": item_type,
            "pinned": pinned,
            "created_at": now,
        }
        if source_url is not None:
            props["source_url"] = source_url
        if author is not None:
            props["author"] = author
        if tags is not None:
            props["tags"] = tags
        if summary is not None:
            props["summary"] = summary
        if metadata is not None:
            props["metadata"] = metadata
        if expires_at is not None:
            props["expires_at"] = expires_at
        if provenance is not None:
            props["provenance"] = provenance

        self._engine.write(
            WriteRequest(
                label="knowledge-ingest",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.ITEM_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=False,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
                chunks=[
                    ChunkInsert(
                        id=f"chunk:item:{item_id}",
                        node_logical_id=logical_id,
                        text_content=body,
                    )
                ],
            )
        )
        return logical_id

    def update(self, item_id: str, **kwargs: Any) -> None:
        """Update a knowledge item. If body changes, replace the chunk too."""
        # Read raw dict from fathomdb to avoid round-trip conversion issues
        raw = _get_one(self._engine, self.ITEM_KIND, f"item:{item_id}")
        if raw is None:
            raise KeyError(f"KnowledgeItem {item_id!r} not found")
        props = dict(raw)
        props.pop("logical_id", None)
        props.update(kwargs)
        props["updated_at"] = _now_iso()

        body_changed = "body" in kwargs
        chunks: list[ChunkInsert] = []
        if body_changed:
            chunks.append(
                ChunkInsert(
                    id=f"chunk:item:{item_id}",
                    node_logical_id=f"item:{item_id}",
                    text_content=kwargs["body"],
                )
            )

        self._engine.write(
            WriteRequest(
                label="knowledge-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"item:{item_id}",
                        kind=self.ITEM_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=True,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
                chunks=chunks,
            )
        )

    # ── Queries ──────────────────────────────────────────────────────

    def get(self, item_id: str) -> Item | None:
        """Return a knowledge item by ID, or None. Excludes soft-deleted."""
        d = _get_one(self._engine, self.ITEM_KIND, f"item:{item_id}")
        if d is None:
            return None
        if d.get("deleted_at") is not None:
            return None
        return self._to_item(d)

    def list(
        self,
        *,
        item_type: str | None = None,
        pinned: bool | None = None,
        limit: int = 100,
    ) -> list[Item]:
        """Return knowledge items with optional filters. Excludes soft-deleted."""
        q = self._engine.nodes(self.ITEM_KIND)
        if item_type is not None:
            q = q.filter_json_text_eq("$.item_type", item_type)
        if pinned is not None:
            q = q.filter_json_bool_eq("$.pinned", pinned)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "knowledge.list")
        items = []
        for n in rows.nodes:
            d = _node_to_dict(n)
            if d.get("deleted_at") is not None:
                continue
            items.append(self._to_item(d))
        return items

    def search(self, query: str, *, limit: int = 20) -> list[Item]:
        """FTS text search over knowledge item chunks. Excludes soft-deleted."""
        rows = (
            self._engine.nodes(self.ITEM_KIND).text_search(query, limit=limit).execute()
        )
        items = []
        for hit in rows.hits:
            d = _node_to_dict(hit.node)
            if d.get("deleted_at") is not None:
                continue
            items.append(self._to_item(d))
        return items

    def find_by_url(self, url: str) -> Item | None:
        """Find a knowledge item by its source_url property."""
        rows = (
            self._engine.nodes(self.ITEM_KIND)
            .filter_json_text_eq("$.source_url", url)
            .limit(1)
            .execute()
        )
        if not rows.nodes:
            return None
        return self._to_item(_node_to_dict(rows.nodes[0]))

    # ── Sources ──────────────────────────────────────────────────────

    def create_source(
        self,
        source_id: str,
        name: str,
        domain: str,
        source_type: str,
        *,
        reputation: float = 0.5,
    ) -> str:
        """Create a knowledge source node."""
        logical_id = f"source:{source_id}"
        props: dict[str, Any] = {
            "source_id": source_id,
            "name": name,
            "domain": domain,
            "source_type": source_type,
            "reputation": reputation,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="knowledge-source-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.SOURCE_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def get_source(self, source_id: str) -> dict[str, Any] | None:
        """Return a knowledge source by ID."""
        return _get_one(self._engine, self.SOURCE_KIND, f"source:{source_id}")

    # ── Links (between knowledge items) ────────────────────────────

    def create_link(
        self,
        source_item_id: str,
        target_item_id: str,
        relationship: str,
        *,
        strength: float = 0.5,
        created_by: str = "auto",
    ) -> str:
        """Create a link between two knowledge items.

        Modelled as a KnowledgeLink node with HAS_LINK edges from/to both items,
        because fathomdb does not expose an edge query API.
        """
        link_lid = f"edge:knowledge-link:{source_item_id}:{target_item_id}"
        props: dict[str, Any] = {
            "source_item_id": source_item_id,
            "target_item_id": target_item_id,
            "relationship": relationship,
            "strength": strength,
            "created_by": created_by,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="knowledge-link-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=link_lid,
                        kind=self.LINK_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:has-link-from:{source_item_id}:{target_item_id}",
                        source_logical_id=f"item:{source_item_id}",
                        target_logical_id=link_lid,
                        kind=EDGE_HAS_LINK,
                        properties={},
                        source_ref="memex:knowledge",
                        upsert=True,
                    )
                ],
            )
        )
        return link_lid

    def get_links(self, item_id: str) -> list[dict[str, Any]]:
        """Get links originating from a knowledge item via HAS_LINK edges."""
        rows = (
            self._engine.nodes(self.ITEM_KIND)
            .filter_logical_id_eq(f"item:{item_id}")
            .traverse(direction=TraverseDirection.OUT, label=EDGE_HAS_LINK, max_depth=1)
            .limit(1000)
            .execute()
        )
        item_lid = f"item:{item_id}"
        results = []
        for node in rows.nodes:
            if node.logical_id == item_lid:
                continue
            props = node.properties if isinstance(node.properties, dict) else {}
            results.append(
                {
                    "source_item_id": props.get("source_item_id", ""),
                    "target_item_id": props.get("target_item_id", ""),
                    "relationship": props.get("relationship", ""),
                    "strength": props.get("strength", 0.5),
                    "created_by": props.get("created_by", "auto"),
                }
            )
        return results

    # ── Trails ───────────────────────────────────────────────────────

    def create_trail(
        self,
        trail_id: str,
        name: str,
        *,
        description: str = "",
    ) -> str:
        """Create a knowledge trail."""
        logical_id = f"trail:{trail_id}"
        props: dict[str, Any] = {
            "trail_id": trail_id,
            "name": name,
            "description": description,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="knowledge-trail-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.TRAIL_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def add_trail_item(
        self,
        trail_id: str,
        item_id: str,
        position: int,
        *,
        annotation: str = "",
    ) -> None:
        """Add an item to a trail at given position."""
        edge_lid = f"edge:trail-item:{trail_id}:{item_id}"
        self._engine.write(
            WriteRequest(
                label="knowledge-trail-add",
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"trail:{trail_id}",
                        target_logical_id=f"item:{item_id}",
                        kind=EDGE_TRAIL_CONTAINS,
                        properties={
                            "position": position,
                            "annotation": annotation,
                        },
                        source_ref="memex:knowledge",
                        upsert=True,
                    )
                ],
            )
        )

    def get_trail_items(self, trail_id: str) -> list[dict[str, Any]]:
        """Get items in a trail via TRAIL_CONTAINS edges."""
        return _traverse_out(
            self._engine,
            self.TRAIL_KIND,
            f"trail:{trail_id}",
            EDGE_TRAIL_CONTAINS,
            limit=1000,
        )

    # ── Additional knowledge queries (Phase 2d) ──────────────────────

    def get_items_batch(self, item_ids: list[str]) -> list[Item]:
        """Fetch multiple items by ID, skipping any that are not found."""
        results: list[Item] = []
        for iid in item_ids:
            item = self.get(iid)
            if item is not None:
                results.append(item)
        return results

    def upsert_item(
        self,
        item_id: str,
        title: str,
        body: str,
        item_type: str,
        **kwargs: Any,
    ) -> str:
        """Create or update a knowledge item (upsert=True). Returns logical_id."""
        logical_id = f"item:{item_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "item_id": item_id,
            "title": title,
            "body": body,
            "item_type": item_type,
            "created_at": now,
        }
        # Forward optional keyword args into properties
        for key in (
            "source_url",
            "author",
            "tags",
            "summary",
            "metadata",
            "pinned",
            "expires_at",
            "provenance",
        ):
            if key in kwargs:
                props[key] = kwargs[key]
        # Default pinned to False if not supplied
        props.setdefault("pinned", False)

        self._engine.write(
            WriteRequest(
                label="knowledge-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.ITEM_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=True,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
                chunks=[
                    ChunkInsert(
                        id=f"chunk:item:{item_id}",
                        node_logical_id=logical_id,
                        text_content=body,
                    )
                ],
            )
        )
        return logical_id

    def find_source_by_domain(self, domain: str) -> dict[str, Any] | None:
        """Query KnowledgeSource nodes, filter by domain property.

        Uses client-side filtering because KnowledgeSource is a low-cardinality
        node kind and filter_json_text_eq can behave unreliably on it.
        """
        rows = self._engine.nodes(self.SOURCE_KIND).limit(1000).execute()
        _check_degraded(rows, "find_source_by_domain")
        for n in rows.nodes:
            d = _node_to_dict(n)
            if d.get("domain") == domain:
                return d
        return None

    def update_source(self, source_id: str, **kwargs: Any) -> None:
        """Read-merge-write on a source node."""
        current = self.get_source(source_id)
        if current is None:
            raise KeyError(f"KnowledgeSource {source_id!r} not found")
        props = dict(current)
        props.pop("logical_id", None)
        props.update(kwargs)
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="knowledge-source-update",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"source:{source_id}",
                        kind=self.SOURCE_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    def list_trails(self) -> list[dict[str, Any]]:
        """Query all KnowledgeTrail nodes."""
        rows = self._engine.nodes(self.TRAIL_KIND).limit(1000).execute()
        _check_degraded(rows, "list_trails")
        return [_node_to_dict(n) for n in rows.nodes]

    def get_trail(self, trail_id: str) -> dict[str, Any] | None:
        """Get single trail by ID."""
        return _get_one(self._engine, self.TRAIL_KIND, f"trail:{trail_id}")

    def list_soft_deleted(self, *, limit: int = 50) -> list[Item]:
        """Return items that have been soft-deleted (deleted_at is set)."""
        rows = self._engine.nodes(self.ITEM_KIND).limit(limit).execute()
        _check_degraded(rows, "knowledge.list_soft_deleted")
        items = []
        for n in rows.nodes:
            d = _node_to_dict(n)
            if d.get("deleted_at") is not None:
                items.append(self._to_item(d))
        return items

    def delete_item(self, item_id: str) -> None:
        """Hard delete: retire + immediate purge."""
        self._engine.write(
            WriteRequest(
                label="knowledge-retire",
                node_retires=[
                    NodeRetire(
                        logical_id=f"item:{item_id}",
                        source_ref="memex:knowledge:forget",
                    )
                ],
            )
        )
        self._engine.admin.purge_logical_id(f"item:{item_id}")

    def count_auto_links(self, item_id: str) -> int:
        """Count links with created_by=='auto' for an item."""
        links = self.get_links(item_id)
        return sum(1 for lk in links if lk.get("created_by") == "auto")

    # ── Forget / restore / purge lifecycle ───────────────────────────

    def soft_delete(self, item_id: str) -> None:
        """Soft-delete by setting deleted_at property on the node."""
        raw = _get_one(self._engine, self.ITEM_KIND, f"item:{item_id}")
        if raw is None:
            return
        props = dict(raw)
        props.pop("logical_id", None)
        props["deleted_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="knowledge-soft-delete",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"item:{item_id}",
                        kind=self.ITEM_KIND,
                        properties=props,
                        source_ref="memex:knowledge:forget",
                        upsert=True,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
            )
        )

    def restore(self, item_id: str) -> None:
        """Restore a soft-deleted item by clearing deleted_at."""
        raw = _get_one(self._engine, self.ITEM_KIND, f"item:{item_id}")
        if raw is None:
            return
        props = dict(raw)
        props.pop("logical_id", None)
        props.pop("deleted_at", None)

        self._engine.write(
            WriteRequest(
                label="knowledge-restore",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"item:{item_id}",
                        kind=self.ITEM_KIND,
                        properties=props,
                        source_ref="memex:knowledge",
                        upsert=True,
                        chunk_policy=ChunkPolicy.REPLACE,
                    )
                ],
            )
        )

    def purge(self, item_id: str) -> None:
        """Permanently remove a node via retire + purge."""
        self._engine.write(
            WriteRequest(
                label="knowledge-retire",
                node_retires=[
                    NodeRetire(
                        logical_id=f"item:{item_id}",
                        source_ref="memex:knowledge:forget",
                    )
                ],
            )
        )
        self._engine.admin.purge_logical_id(f"item:{item_id}")

    def purge_soft_deleted(self, older_than: datetime) -> int:
        """Permanently remove soft-deleted items with deleted_at before cutoff."""
        rows = self._engine.nodes(self.ITEM_KIND).limit(1000).execute()
        count = 0
        for n in rows.nodes:
            d = _node_to_dict(n)
            deleted_at_raw = d.get("deleted_at")
            if deleted_at_raw is None:
                continue
            if isinstance(deleted_at_raw, str):
                deleted_at = datetime.fromisoformat(deleted_at_raw)
            elif isinstance(deleted_at_raw, datetime):
                deleted_at = deleted_at_raw
            else:
                continue
            if deleted_at <= older_than:
                item_id = d.get("item_id", "")
                if item_id:
                    self._engine.write(
                        WriteRequest(
                            label="knowledge-purge",
                            node_retires=[
                                NodeRetire(
                                    logical_id=f"item:{item_id}",
                                    source_ref="memex:knowledge:purge",
                                )
                            ],
                        )
                    )
                    self._engine.admin.purge_logical_id(f"item:{item_id}")
                    count += 1
        return count

    def touch(self, item_id: str) -> None:
        """Update last_accessed timestamp on a knowledge item."""
        lid = f"item:{item_id}"
        self._engine.touch_last_accessed(
            LastAccessTouchRequest(
                logical_ids=[lid],
                touched_at=int(utcnow().timestamp()),
                source_ref="memex:knowledge:touch",
            )
        )


# ── World Model sub-repository ──────────────────────────────────────


class WorldModelRepository:
    """World-model graph: entities, intents, actions, etc."""

    ENTITY_KIND = "WMEntity"
    INTENT_KIND = "WMIntent"
    ACTION_KIND = "WMAction"
    OBSERVATION_KIND = "WMObservation"
    PLAN_KIND = "WMPlan"
    PLAN_STEP_KIND = "WMPlanStep"
    EVENT_KIND = "WMEvent"
    EXECUTION_KIND = "WMExecutionRecord"
    WM_GOAL_KIND = "WMGoal"
    WM_TASK_KIND = "WMTask"
    WM_COMMITMENT_KIND = "WMCommitment"
    SEMANTIC_MAPPING_KIND = "WMSemanticMapping"
    KNOWLEDGE_OBJECT_KIND = "WMKnowledgeObject"
    PROMPT_CONTROL_KIND = "WMPromptControl"
    PROVENANCE_LINK_KIND = "WMProvenanceLink"
    CLAIM_EVALUATION_KIND = "WMClaimEvaluation"
    INGEST_RUN_KIND = "WMKnowledgeIngestRun"
    TRANSITION_KIND = "WMPlanStepTransition"
    KNOWLEDGE_ENTITY_LINK_KIND = "WMKnowledgeEntityLink"
    KNOWLEDGE_RELATIONSHIP_KIND = "WMKnowledgeRelationship"

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    # ── Pydantic adapters ───────────────────────────────────────────

    @staticmethod
    def _to_wm_goal(d: dict[str, Any]) -> WorldModelGoal:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelGoal(**d)

    @staticmethod
    def _to_wm_task(d: dict[str, Any]) -> WorldModelTask:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at", "due_at")
        _default_timestamps(d)
        return WorldModelTask(**d)

    @staticmethod
    def _to_wm_commitment(d: dict[str, Any]) -> WorldModelCommitment:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelCommitment(**d)

    @staticmethod
    def _to_semantic_mapping(d: dict[str, Any]) -> WorldModelSemanticMapping:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelSemanticMapping(**d)

    @staticmethod
    def _to_knowledge_object(d: dict[str, Any]) -> WorldModelKnowledgeObject:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelKnowledgeObject(**d)

    @staticmethod
    def _to_claim_evaluation(d: dict[str, Any]) -> WorldModelClaimEvaluation:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelClaimEvaluation(**d)

    @staticmethod
    def _to_prompt_control(d: dict[str, Any]) -> PromptControlArtifact:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return PromptControlArtifact(**d)

    @staticmethod
    def _to_entity(d: dict[str, Any]) -> WorldModelEntity:
        d = dict(d)
        d.pop("logical_id", None)
        d.pop("attributes", None)  # nested dict, not a model field
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if isinstance(d.get("entity_type"), str):
            try:
                d["entity_type"] = WorldModelEntityType(d["entity_type"])
            except ValueError:
                pass
        try:
            return WorldModelEntity(**d)
        except Exception:
            # Graceful fallback for non-enum entity_type strings
            return WorldModelEntity.model_construct(**d)

    @staticmethod
    def _to_intent(d: dict[str, Any]) -> WorldModelIntent:
        d = dict(d)
        d.pop("logical_id", None)
        # Normalise turn_id -> conversation_turn_id (int | None)
        if "turn_id" in d and "conversation_turn_id" not in d:
            raw = d.pop("turn_id")
            try:
                d["conversation_turn_id"] = int(raw) if raw is not None else None
            except (ValueError, TypeError):
                d["conversation_turn_id"] = None
        else:
            d.pop("turn_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        # Ensure list fields default properly
        for lf in ("unresolved_references", "missing_information"):
            if lf in d and not isinstance(d[lf], list):
                d[lf] = []
        return WorldModelIntent(**d)

    @staticmethod
    def _to_action(d: dict[str, Any]) -> WorldModelAction:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelAction(**d)

    @staticmethod
    def _to_observation(d: dict[str, Any]) -> WorldModelObservation:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelObservation(**d)

    @staticmethod
    def _to_event(d: dict[str, Any]) -> WorldModelEvent:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelEvent(**d)

    @staticmethod
    def _to_plan(d: dict[str, Any]) -> WorldModelActionPlan:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelActionPlan(**d)

    @staticmethod
    def _to_plan_step(d: dict[str, Any]) -> WorldModelPlanStep:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        for lf in ("depends_on_step_ids", "blocked_by_step_ids"):
            if lf in d and not isinstance(d[lf], list):
                d[lf] = []
        return WorldModelPlanStep(**d)

    @staticmethod
    def _to_execution_record(d: dict[str, Any]) -> WorldModelExecutionRecord:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelExecutionRecord(**d)

    @staticmethod
    def _to_ingest_run(d: dict[str, Any]) -> WorldModelKnowledgeIngestRun:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at", "finished_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        return WorldModelKnowledgeIngestRun(**d)

    @staticmethod
    def _to_transition(d: dict[str, Any]) -> WorldModelPlanStepTransition:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        if "payload" in d and not isinstance(d["payload"], dict):
            d["payload"] = {}
        for lf in ("blocked_by_step_ids",):
            if lf in d and not isinstance(d[lf], list):
                d[lf] = []
        return WorldModelPlanStepTransition(**d)

    @staticmethod
    def _to_knowledge_entity_link(d: dict[str, Any]) -> WorldModelKnowledgeEntityLink:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at")
        return WorldModelKnowledgeEntityLink(**d)

    @staticmethod
    def _to_knowledge_relationship(
        d: dict[str, Any],
    ) -> WorldModelKnowledgeRelationship:
        d = dict(d)
        d.pop("logical_id", None)
        _parse_iso_fields(d, "created_at", "updated_at")
        _default_timestamps(d)
        return WorldModelKnowledgeRelationship(**d)

    # ── Entities ─────────────────────────────────────────────────────

    def upsert_entity(
        self,
        entity_id: str,
        entity_type: str,
        display_name: str,
        *,
        canonical_key: str | None = None,
        status: str = "active",
        confidence: float = 1.0,
    ) -> str:
        """Create or update a world-model entity. Returns the logical_id."""
        logical_id = f"wm_entity:{entity_id}"
        props: dict[str, Any] = {
            "entity_id": entity_id,
            "entity_type": entity_type,
            "display_name": display_name,
            "status": status,
            "confidence": confidence,
            "updated_at": _now_iso(),
        }
        if canonical_key is not None:
            props["canonical_key"] = canonical_key

        # Preserve existing attributes if updating
        current = self._get_entity_raw(entity_id)
        if current is not None and "attributes" in current:
            props["attributes"] = current["attributes"]

        self._engine.write(
            WriteRequest(
                label="wm-entity-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.ENTITY_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def _get_entity_raw(self, entity_id: str) -> dict[str, Any] | None:
        """Return raw entity dict by ID (for internal use), or None."""
        return _get_one(self._engine, self.ENTITY_KIND, f"wm_entity:{entity_id}")

    def get_entity(self, entity_id: str) -> WorldModelEntity | None:
        """Return a typed entity by ID, or None."""
        d = self._get_entity_raw(entity_id)
        if d is None:
            return None
        return self._to_entity(d)

    def find_entity_by_canonical_key(
        self,
        entity_type: str,
        canonical_key: str,
    ) -> WorldModelEntity | None:
        """Look up an entity by type and canonical_key."""
        rows = (
            self._engine.nodes(self.ENTITY_KIND)
            .filter_json_text_eq("$.entity_type", entity_type)
            .filter_json_text_eq("$.canonical_key", canonical_key)
            .limit(1)
            .execute()
        )
        _check_degraded(rows, "find_entity_by_canonical_key")
        if not rows.nodes:
            return None
        return self._to_entity(_node_to_dict(rows.nodes[0]))

    def set_entity_attribute(
        self,
        entity_id: str,
        group: str,
        key: str,
        value: Any,
        *,
        confidence: float = 1.0,
    ) -> None:
        """Upsert an attribute on an entity (nested-dict approach)."""
        current = self._get_entity_raw(entity_id)
        if current is None:
            raise KeyError(f"WMEntity {entity_id!r} not found")

        props = dict(current)
        props.pop("logical_id", None)

        attributes: dict[str, Any] = props.get("attributes", {})
        # Key the attribute by group:key for uniqueness
        attr_key = f"{group}:{key}"
        attributes[attr_key] = {
            "group": group,
            "key": key,
            "value": value,
            "confidence": confidence,
        }
        props["attributes"] = attributes
        props["updated_at"] = _now_iso()

        self._engine.write(
            WriteRequest(
                label="wm-entity-attr",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=f"wm_entity:{entity_id}",
                        kind=self.ENTITY_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )

    def get_entity_attributes(self, entity_id: str) -> list[dict]:
        """Return the list of attribute dicts for an entity."""
        entity = self._get_entity_raw(entity_id)
        if entity is None:
            raise KeyError(f"WMEntity {entity_id!r} not found")
        attributes = entity.get("attributes", {})
        return list(attributes.values())

    # ── Intents ──────────────────────────────────────────────────────

    def record_intent(
        self,
        intent_id: str,
        session_id: str,
        raw_input: str,
        classification: str,
        selected_path: str,
        *,
        turn_id: str | None = None,
        confidence: float = 1.0,
        goal_id: str | None = None,
        conversation_turn_id: int | None = None,
        summary: str = "",
        rationale: str = "",
        status: str = "proposed",
        unresolved_references: list[str] | None = None,
        missing_information: list[str] | None = None,
        source_surface: str = "",
    ) -> str:
        """Record a per-turn intent frame. Returns the logical_id."""
        logical_id = f"wm_intent:{intent_id}"
        props: dict[str, Any] = {
            "intent_id": intent_id,
            "session_id": session_id,
            "raw_input": raw_input,
            "classification": classification,
            "selected_path": selected_path,
            "confidence": confidence,
            "status": status,
            "created_at": _now_iso(),
        }
        if turn_id is not None:
            props["turn_id"] = turn_id
        if goal_id is not None:
            props["goal_id"] = goal_id
        if conversation_turn_id is not None:
            props["conversation_turn_id"] = conversation_turn_id
        if summary:
            props["summary"] = summary
        if rationale:
            props["rationale"] = rationale
        if unresolved_references:
            props["unresolved_references"] = unresolved_references
        if missing_information:
            props["missing_information"] = missing_information
        if source_surface:
            props["source_surface"] = source_surface

        self._engine.write(
            WriteRequest(
                label="wm-intent-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.INTENT_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def get_intent(self, intent_id: str) -> WorldModelIntent | None:
        """Return a typed intent by ID, or None."""
        d = _get_one(self._engine, self.INTENT_KIND, f"wm_intent:{intent_id}")
        if d is None:
            return None
        return self._to_intent(d)

    def load_latest_intent(self, session_id: str) -> WorldModelIntent | None:
        """Return the most-recently created intent for *session_id*, or None."""
        rows = (
            self._engine.nodes(self.INTENT_KIND)
            .filter_json_text_eq("$.session_id", session_id)
            .limit(50)
            .execute()
        )
        _check_degraded(rows, "load_latest_intent")
        if not rows.nodes:
            return None
        # Pick the node with the latest created_at
        best: dict[str, Any] | None = None
        best_ts = ""
        for n in rows.nodes:
            d = _node_to_dict(n)
            ts = d.get("created_at", "")
            if ts >= best_ts:
                best_ts = ts
                best = d
        if best is None:
            return None
        return self._to_intent(best)

    # ── Actions ──────────────────────────────────────────────────────

    def record_action(
        self,
        action_id: str,
        session_id: str,
        action_kind: str,
        action_name: str,
        *,
        intent_id: str | None = None,
        status: str = "active",
        payload: dict[str, Any] | None = None,
        meeting_id: str | None = None,
        prompt_control_artifact_id: str | None = None,
        conversation_turn_id: int | None = None,
        source_surface: str = "",
    ) -> str:
        """Record an action (tool call, decision, reflection). Returns logical_id."""
        logical_id = f"wm_action:{action_id}"
        props: dict[str, Any] = {
            "action_id": action_id,
            "session_id": session_id,
            "action_kind": action_kind,
            "action_name": action_name,
            "status": status,
            "created_at": _now_iso(),
        }
        if intent_id is not None:
            props["intent_id"] = intent_id
        if payload is not None:
            props["payload"] = payload
        if meeting_id is not None:
            props["meeting_id"] = meeting_id
        if prompt_control_artifact_id is not None:
            props["prompt_control_artifact_id"] = prompt_control_artifact_id
        if conversation_turn_id is not None:
            props["conversation_turn_id"] = conversation_turn_id
        if source_surface:
            props["source_surface"] = source_surface

        edges: list[EdgeInsert] = []
        if intent_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:action-intent:{action_id}:{intent_id}",
                    source_logical_id=f"wm_intent:{intent_id}",
                    target_logical_id=logical_id,
                    kind=EDGE_HAS_ACTION,
                    properties={},
                    source_ref="memex:world-model",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="wm-action-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.ACTION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def list_actions(
        self,
        *,
        session_id: str | None = None,
        action_kind: str | None = None,
        limit: int = 50,
    ) -> list[WorldModelAction]:
        """Query WMAction nodes with optional filters, returning typed models."""
        q = self._engine.nodes(self.ACTION_KIND)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if action_kind is not None:
            q = q.filter_json_text_eq("$.action_kind", action_kind)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_actions")
        return [self._to_action(_node_to_dict(n)) for n in rows.nodes]

    def load_action(self, action_id: str) -> WorldModelAction | None:
        """Return a typed WMAction by ID via direct ``logical_id`` lookup.

        Used by ``load_canonical_outcome`` on the retrieval hot path; replaces
        the prior ``list_actions(limit=500)`` linear scan, which silently
        dropped any action not among the 500 most-recent.
        """
        d = _get_one(self._engine, self.ACTION_KIND, f"wm_action:{action_id}")
        if d is None:
            return None
        return self._to_action(d)

    def retire_action(self, action_id: str) -> None:
        """Retire (soft-delete) an action node."""
        self._engine.write(
            WriteRequest(
                label="wm-action-retire",
                node_retires=[
                    NodeRetire(
                        logical_id=f"wm_action:{action_id}",
                        source_ref="memex:world-model",
                    )
                ],
            )
        )

    # ── Observations ─────────────────────────────────────────────────

    def record_observation(
        self,
        observation_id: str,
        action_id: str,
        observation_kind: str,
        summary: str,
        *,
        status: str = "observed",
        payload: dict[str, Any] | None = None,
        session_id: str | None = None,
        meeting_id: str | None = None,
        source_surface: str = "",
    ) -> str:
        """Record an observation linked to an action."""
        logical_id = f"wm_observation:{observation_id}"
        props: dict[str, Any] = {
            "observation_id": observation_id,
            "action_id": action_id,
            "observation_kind": observation_kind,
            "summary": summary,
            "status": status,
            "created_at": _now_iso(),
        }
        if payload is not None:
            props["payload"] = payload
        if session_id is not None:
            props["session_id"] = session_id
        if meeting_id is not None:
            props["meeting_id"] = meeting_id
        if source_surface:
            props["source_surface"] = source_surface

        self._engine.write(
            WriteRequest(
                label="wm-observation-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.OBSERVATION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:action-obs:{action_id}:{observation_id}",
                        source_logical_id=f"wm_action:{action_id}",
                        target_logical_id=logical_id,
                        kind=EDGE_HAS_OBSERVATION,
                        properties={},
                        source_ref="memex:world-model",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def list_observations(
        self,
        *,
        action_id: str | None = None,
        session_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelObservation]:
        """Query WMObservation nodes with optional filters, returning typed models."""
        q = self._engine.nodes(self.OBSERVATION_KIND)
        if action_id is not None:
            q = q.filter_json_text_eq("$.action_id", action_id)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_observations")
        return [self._to_observation(_node_to_dict(n)) for n in rows.nodes]

    def retire_observation(self, observation_id: str) -> None:
        """Retire (soft-delete) an observation node."""
        self._engine.write(
            WriteRequest(
                label="wm-observation-retire",
                node_retires=[
                    NodeRetire(
                        logical_id=f"wm_observation:{observation_id}",
                        source_ref="memex:world-model",
                    )
                ],
            )
        )

    # ── Plans ────────────────────────────────────────────────────────

    def create_plan(
        self,
        plan_id: str,
        goal_id: str,
        title: str,
        *,
        status: str = "active",
    ) -> str:
        """Create a plan with FOR_GOAL edge to the goal. Returns logical_id."""
        logical_id = f"wm_plan:{plan_id}"
        props: dict[str, Any] = {
            "plan_id": plan_id,
            "goal_id": goal_id,
            "title": title,
            "status": status,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="wm-plan-create",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.PLAN_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:plan-goal:{plan_id}:{goal_id}",
                        source_logical_id=logical_id,
                        target_logical_id=f"goal:{goal_id}",
                        kind=EDGE_FOR_GOAL,
                        properties={},
                        source_ref="memex:world-model",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def get_plan(self, plan_id: str) -> dict[str, Any] | None:
        """Return a plan by ID, or None."""
        return _get_one(self._engine, self.PLAN_KIND, f"wm_plan:{plan_id}")

    def add_plan_step(
        self,
        step_id: str,
        plan_id: str,
        title: str,
        *,
        step_kind: str = "task",
        ordinal: int = 0,
        status: str = "active",
    ) -> str:
        """Add a step to a plan with HAS_STEP edge. Returns logical_id."""
        logical_id = f"wm_plan_step:{step_id}"
        props: dict[str, Any] = {
            "step_id": step_id,
            "plan_id": plan_id,
            "title": title,
            "step_kind": step_kind,
            "ordinal": ordinal,
            "status": status,
            "created_at": _now_iso(),
        }

        self._engine.write(
            WriteRequest(
                label="wm-plan-step-add",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.PLAN_STEP_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:plan-step:{plan_id}:{step_id}",
                        source_logical_id=f"wm_plan:{plan_id}",
                        target_logical_id=logical_id,
                        kind=EDGE_HAS_STEP,
                        properties={},
                        source_ref="memex:world-model",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def list_plan_steps(self, plan_id: str) -> list[dict[str, Any]]:
        """Get steps linked to a plan via HAS_STEP edges."""
        return _traverse_out(
            self._engine,
            self.PLAN_KIND,
            f"wm_plan:{plan_id}",
            EDGE_HAS_STEP,
            limit=1000,
        )

    # ── Plans (typed) ──────────────────────────────────────────────────

    def upsert_plan(self, plan: WorldModelActionPlan) -> str:
        """Create or update a WMPlan node. Returns the logical_id."""
        logical_id = f"wm_plan:{plan.plan_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "plan_id": plan.plan_id,
            "goal_id": plan.goal_id,
            "title": plan.title,
            "summary": plan.summary,
            "status": plan.status,
            "selected_step_id": plan.selected_step_id,
            "source_surface": plan.source_surface,
            "updated_at": now,
        }
        if plan.payload:
            props["payload"] = plan.payload

        edges: list[EdgeInsert] = []
        if plan.goal_id:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:plan-goal:{plan.plan_id}:{plan.goal_id}",
                    source_logical_id=logical_id,
                    target_logical_id=f"goal:{plan.goal_id}",
                    kind=EDGE_FOR_GOAL,
                    properties={},
                    source_ref="memex:world-model",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="wm-plan-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.PLAN_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def get_plan_typed(self, plan_id: str) -> WorldModelActionPlan | None:
        """Return a typed plan by ID, or None."""
        d = _get_one(self._engine, self.PLAN_KIND, f"wm_plan:{plan_id}")
        if d is None:
            return None
        return self._to_plan(d)

    def list_plans(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelActionPlan]:
        """Query WMPlan nodes with optional filters, returning typed models."""
        q = self._engine.nodes(self.PLAN_KIND)
        if goal_id is not None:
            q = q.filter_json_text_eq("$.goal_id", goal_id)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_plans")
        return [self._to_plan(_node_to_dict(n)) for n in rows.nodes]

    # ── Plan steps (typed) ─────────────────────────────────────────────

    def upsert_plan_step(self, step: WorldModelPlanStep) -> str:
        """Create or update a WMPlanStep node. Returns the logical_id."""
        logical_id = f"wm_plan_step:{step.step_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "step_id": step.step_id,
            "plan_id": step.plan_id,
            "goal_id": step.goal_id,
            "step_kind": step.step_kind,
            "title": step.title,
            "description": step.description,
            "status": step.status,
            "ordinal": step.ordinal,
            "blocked_reason": step.blocked_reason,
            "progress_pct": step.progress_pct,
            "depends_on_step_ids": step.depends_on_step_ids,
            "blocked_by_step_ids": step.blocked_by_step_ids,
            "source_surface": step.source_surface,
            "updated_at": now,
        }
        if step.payload:
            props["payload"] = step.payload

        self._engine.write(
            WriteRequest(
                label="wm-plan-step-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.PLAN_STEP_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=f"edge:plan-step:{step.plan_id}:{step.step_id}",
                        source_logical_id=f"wm_plan:{step.plan_id}",
                        target_logical_id=logical_id,
                        kind=EDGE_HAS_STEP,
                        properties={},
                        source_ref="memex:world-model",
                        upsert=True,
                    )
                ],
            )
        )
        return logical_id

    def load_plan_step(self, step_id: str) -> WorldModelPlanStep | None:
        """Return a typed plan step by ID, or None."""
        d = _get_one(
            self._engine,
            self.PLAN_STEP_KIND,
            f"wm_plan_step:{step_id}",
        )
        if d is None:
            return None
        return self._to_plan_step(d)

    def list_plan_steps_typed(
        self,
        *,
        plan_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStep]:
        """Query WMPlanStep nodes with optional filters, returning typed models."""
        q = self._engine.nodes(self.PLAN_STEP_KIND)
        if plan_id is not None:
            q = q.filter_json_text_eq("$.plan_id", plan_id)
        if goal_id is not None:
            q = q.filter_json_text_eq("$.goal_id", goal_id)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_plan_steps_typed")
        return [self._to_plan_step(_node_to_dict(n)) for n in rows.nodes]

    # ── Execution records (typed) ──────────────────────────────────────

    def upsert_execution(self, record: WorldModelExecutionRecord) -> str:
        """Create or update a WMExecutionRecord node. Returns the logical_id."""
        logical_id = f"wm_execution:{record.execution_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "execution_id": record.execution_id,
            "session_id": record.session_id,
            "conversation_turn_id": record.conversation_turn_id,
            "goal_id": record.goal_id,
            "plan_id": record.plan_id,
            "step_id": record.step_id,
            "execution_kind": record.execution_kind,
            "title": record.title,
            "summary": record.summary,
            "status": record.status,
            "source_record_type": record.source_record_type,
            "source_record_id": record.source_record_id,
            "source_surface": record.source_surface,
            "updated_at": now,
        }
        if record.payload:
            props["payload"] = record.payload

        edges: list[EdgeInsert] = []
        if record.goal_id:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:exec-goal:{record.execution_id}:{record.goal_id}",
                    source_logical_id=logical_id,
                    target_logical_id=f"goal:{record.goal_id}",
                    kind=EDGE_FOR_GOAL,
                    properties={},
                    source_ref="memex:world-model",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="wm-execution-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.EXECUTION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def load_execution(self, execution_id: str) -> WorldModelExecutionRecord | None:
        """Return a typed execution record by ID, or None."""
        d = _get_one(
            self._engine,
            self.EXECUTION_KIND,
            f"wm_execution:{execution_id}",
        )
        if d is None:
            return None
        return self._to_execution_record(d)

    def list_executions_typed(
        self,
        *,
        session_id: str | None = None,
        plan_id: str | None = None,
        step_id: str | None = None,
        source_record_type: str | None = None,
        source_record_id: str | None = None,
        execution_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelExecutionRecord]:
        """Query WMExecutionRecord nodes with optional filters."""
        q = self._engine.nodes(self.EXECUTION_KIND)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if plan_id is not None:
            q = q.filter_json_text_eq("$.plan_id", plan_id)
        if step_id is not None:
            q = q.filter_json_text_eq("$.step_id", step_id)
        if source_record_type is not None:
            q = q.filter_json_text_eq("$.source_record_type", source_record_type)
        if source_record_id is not None:
            q = q.filter_json_text_eq("$.source_record_id", source_record_id)
        if execution_kind is not None:
            q = q.filter_json_text_eq("$.execution_kind", execution_kind)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_executions_typed")
        dicts = [_node_to_dict(n) for n in rows.nodes]
        dicts.sort(
            key=lambda d: (d.get("created_at", ""), d.get("execution_id", "")),
            reverse=True,
        )
        return [self._to_execution_record(d) for d in dicts]

    # ── Knowledge ingest runs ─────────────────────────────────────────

    def upsert_ingest_run(self, run: WorldModelKnowledgeIngestRun) -> str:
        """Create or update a WMKnowledgeIngestRun node. Returns logical_id."""
        logical_id = f"wm_ingest_run:{run.ingest_run_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "ingest_run_id": run.ingest_run_id,
            "ingest_kind": run.ingest_kind,
            "trigger_surface": run.trigger_surface,
            "session_id": run.session_id,
            "source_ref": run.source_ref,
            "normalized_source_ref": run.normalized_source_ref,
            "requested_item_type": run.requested_item_type,
            "status": run.status,
            "phase": run.phase,
            "fallback_used": run.fallback_used,
            "item_id": run.item_id,
            "knowledge_id": run.knowledge_id,
            "summary_model": run.summary_model,
            "error": run.error,
            "source_surface": "memex:knowledge-ingest",
            "updated_at": now,
        }
        if run.payload:
            props["payload"] = run.payload
        if run.finished_at is not None:
            props["finished_at"] = run.finished_at.isoformat()

        self._engine.write(
            WriteRequest(
                label="wm-ingest-run-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.INGEST_RUN_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_ingest_run(
        self,
        ingest_run_id: str,
    ) -> WorldModelKnowledgeIngestRun | None:
        """Return a typed ingest run by ID, or None."""
        d = _get_one(
            self._engine,
            self.INGEST_RUN_KIND,
            f"wm_ingest_run:{ingest_run_id}",
        )
        if d is None:
            return None
        return self._to_ingest_run(d)

    def list_ingest_runs(
        self,
        *,
        session_id: str | None = None,
        source_ref: str | None = None,
        status: str | None = None,
        knowledge_id: str | None = None,
        item_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeIngestRun]:
        """Query WMKnowledgeIngestRun nodes with optional filters."""
        q = self._engine.nodes(self.INGEST_RUN_KIND)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if source_ref is not None:
            q = q.filter_json_text_eq("$.source_ref", source_ref)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        if knowledge_id is not None:
            q = q.filter_json_text_eq("$.knowledge_id", knowledge_id)
        if item_id is not None:
            q = q.filter_json_text_eq("$.item_id", item_id)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_ingest_runs")
        return [self._to_ingest_run(_node_to_dict(n)) for n in rows.nodes]

    # ── Plan step transitions ─────────────────────────────────────────

    def append_transition(
        self,
        transition: WorldModelPlanStepTransition,
    ) -> str:
        """Append a plan step transition. Returns the logical_id."""
        logical_id = f"wm_transition:{transition.transition_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "transition_id": transition.transition_id,
            "step_id": transition.step_id,
            "plan_id": transition.plan_id,
            "goal_id": transition.goal_id,
            "execution_id": transition.execution_id,
            "transition_kind": transition.transition_kind,
            "from_status": transition.from_status,
            "to_status": transition.to_status,
            "blocked_reason": transition.blocked_reason,
            "blocked_by_step_ids": transition.blocked_by_step_ids,
            "progress_pct": transition.progress_pct,
            "summary": transition.summary,
            "source_surface": transition.source_surface,
            "updated_at": now,
        }
        if transition.payload:
            props["payload"] = transition.payload

        self._engine.write(
            WriteRequest(
                label="wm-transition-append",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.TRANSITION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_transition(
        self,
        transition_id: str,
    ) -> WorldModelPlanStepTransition | None:
        """Return a typed transition by ID, or None."""
        d = _get_one(
            self._engine,
            self.TRANSITION_KIND,
            f"wm_transition:{transition_id}",
        )
        if d is None:
            return None
        return self._to_transition(d)

    def list_transitions(
        self,
        *,
        step_id: str | None = None,
        plan_id: str | None = None,
        execution_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelPlanStepTransition]:
        """Query WMPlanStepTransition nodes with optional filters."""
        q = self._engine.nodes(self.TRANSITION_KIND)
        if step_id is not None:
            q = q.filter_json_text_eq("$.step_id", step_id)
        if plan_id is not None:
            q = q.filter_json_text_eq("$.plan_id", plan_id)
        if execution_id is not None:
            q = q.filter_json_text_eq("$.execution_id", execution_id)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_transitions")
        return [self._to_transition(_node_to_dict(n)) for n in rows.nodes]

    # ── Provenance links ─────────────────────────────────────────────

    _PREFIX_MAP = {
        "WMEntity": "wm_entity",
        "WMIntent": "wm_intent",
        "WMAction": "wm_action",
        "WMObservation": "wm_observation",
        "WMPlan": "wm_plan",
        "WMPlanStep": "wm_plan_step",
        "WMEvent": "wm_event",
        "WMExecutionRecord": "wm_execution",
        "WMGoal": "wm_goal",
        "WMTask": "wm_task",
        "WMCommitment": "wm_commitment",
        "WMKnowledgeObject": "wm_knowledge_object",
        "WMPromptControl": "wm_prompt_control",
        "WMSemanticMapping": "wm_semantic_mapping",
        "WMClaimEvaluation": "wm_claim_evaluation",
        "WMKnowledgeIngestRun": "wm_ingest_run",
        "WMPlanStepTransition": "wm_transition",
        "WMKnowledgeEntityLink": "wm_knowledge_entity_link",
        "WMKnowledgeRelationship": "wm_knowledge_relationship",
        "WMProvenanceLink": "wm_provenance_link",
    }

    def create_provenance_link(
        self,
        source_type: str,
        source_id: str,
        target_type: str,
        target_id: str,
        relationship: str,
        *,
        source_title: str = "",
        source_status: str = "",
        target_title: str = "",
        target_status: str = "",
    ) -> str:
        """Create a provenance link between two nodes.

        ``source_title`` / ``source_status`` / ``target_title`` /
        ``target_status`` are optional denormalized fields that get
        indexed by m005's property FTS schema so ``search_dependency_documents``
        can use fathomdb property FTS instead of a Python-side scan. The
        facade resolves these at write time via
        ``_resolve_record_title_status``; direct low-level callers can
        leave them empty and the FTS entries for those paths simply
        won't match any query.
        """
        src_prefix = self._PREFIX_MAP.get(source_type, source_type.lower())
        tgt_prefix = self._PREFIX_MAP.get(target_type, target_type.lower())

        edge_lid = (
            f"edge:provenance:{source_type}:{source_id}"
            f":{relationship}:{target_type}:{target_id}"
        )
        now = _now_iso()

        # Also store as a queryable WMProvenanceLink node
        node_lid = (
            f"wm_provenance_link:{source_type}:{source_id}"
            f":{relationship}:{target_type}:{target_id}"
        )
        prov_node = NodeInsert(
            row_id=new_row_id(),
            logical_id=node_lid,
            kind=self.PROVENANCE_LINK_KIND,
            properties={
                "source_type": source_type,
                "source_id": source_id,
                "source_title": source_title,
                "source_status": source_status,
                "target_type": target_type,
                "target_id": target_id,
                "target_title": target_title,
                "target_status": target_status,
                "relationship": relationship,
                "created_at": now,
            },
            source_ref="memex:world-model",
            upsert=True,
            chunk_policy=ChunkPolicy.PRESERVE,
        )

        self._engine.write(
            WriteRequest(
                label="wm-provenance-link",
                nodes=[prov_node],
                edges=[
                    EdgeInsert(
                        row_id=new_row_id(),
                        logical_id=edge_lid,
                        source_logical_id=f"{src_prefix}:{source_id}",
                        target_logical_id=f"{tgt_prefix}:{target_id}",
                        kind=relationship,
                        properties={
                            "source_type": source_type,
                            "target_type": target_type,
                            "created_at": now,
                        },
                        source_ref="memex:world-model",
                        upsert=True,
                    )
                ],
            )
        )
        return edge_lid

    def list_provenance_links(
        self,
        *,
        source_type: str | None = None,
        source_id: str | None = None,
        target_type: str | None = None,
        target_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Query WMProvenanceLink nodes with optional filters."""
        q = self._engine.nodes(self.PROVENANCE_LINK_KIND)
        if source_type is not None:
            q = q.filter_json_text_eq("$.source_type", source_type)
        if source_id is not None:
            q = q.filter_json_text_eq("$.source_id", source_id)
        if target_type is not None:
            q = q.filter_json_text_eq("$.target_type", target_type)
        if target_id is not None:
            q = q.filter_json_text_eq("$.target_id", target_id)
        rows = q.limit(500).execute()
        _check_degraded(rows, "list_provenance_links")
        return [_node_to_dict(n) for n in rows.nodes]

    def delete_provenance_links_for_source(
        self,
        source_type: str,
        source_id: str,
    ) -> None:
        """Retire all provenance link nodes for a given source record."""
        existing = self.list_provenance_links(
            source_type=source_type, source_id=source_id
        )
        if not existing:
            return
        retires = []
        for d in existing:
            lid = d.get("logical_id")
            if lid:
                retires.append(
                    NodeRetire(logical_id=lid, source_ref="memex:world-model")
                )
        if retires:
            self._engine.write(
                WriteRequest(
                    label="wm-provenance-link-delete",
                    node_retires=retires,
                )
            )

    # ── Events (Group 1) ────────────────────────────────────────────

    def record_event(
        self,
        event_id: str,
        session_id: str,
        event_kind: str,
        title: str,
        *,
        summary: str = "",
        meeting_id: str | None = None,
        turn_id: str | None = None,
        payload: dict[str, Any] | None = None,
        conversation_turn_id: int | None = None,
        source_surface: str = "",
    ) -> str:
        """Record a WMEvent node. Returns the logical_id."""
        logical_id = f"wm_event:{event_id}"
        props: dict[str, Any] = {
            "event_id": event_id,
            "session_id": session_id,
            "event_kind": event_kind,
            "title": title,
            "summary": summary,
            "created_at": _now_iso(),
        }
        if meeting_id is not None:
            props["meeting_id"] = meeting_id
        if turn_id is not None:
            props["turn_id"] = turn_id
        if conversation_turn_id is not None:
            props["conversation_turn_id"] = conversation_turn_id
        if payload is not None:
            props["payload"] = payload
        if source_surface:
            props["source_surface"] = source_surface

        self._engine.write(
            WriteRequest(
                label="wm-event-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.EVENT_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def list_events(
        self,
        *,
        session_id: str | None = None,
        event_kind: str | None = None,
        limit: int = 50,
    ) -> list[WorldModelEvent]:
        """Query WMEvent nodes with optional filters, returning typed models."""
        q = self._engine.nodes(self.EVENT_KIND)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if event_kind is not None:
            q = q.filter_json_text_eq("$.event_kind", event_kind)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_events")
        return [self._to_event(_node_to_dict(n)) for n in rows.nodes]

    def load_event(self, event_id: str) -> WorldModelEvent | None:
        """Return a typed event by ID, or None."""
        d = _get_one(self._engine, self.EVENT_KIND, f"wm_event:{event_id}")
        if d is None:
            return None
        return self._to_event(d)

    # ── Execution records (Group 2) ─────────────────────────────────

    def record_execution(
        self,
        execution_id: str,
        session_id: str,
        execution_kind: str,
        title: str,
        *,
        goal_id: str | None = None,
        plan_id: str | None = None,
        step_id: str | None = None,
        source_record_type: str = "",
        source_record_id: str = "",
        payload: dict[str, Any] | None = None,
    ) -> str:
        """Record an execution with optional goal/step edges."""
        logical_id = f"wm_execution:{execution_id}"
        props: dict[str, Any] = {
            "execution_id": execution_id,
            "session_id": session_id,
            "execution_kind": execution_kind,
            "title": title,
            "source_record_type": source_record_type,
            "source_record_id": source_record_id,
            "created_at": _now_iso(),
        }
        if goal_id is not None:
            props["goal_id"] = goal_id
        if plan_id is not None:
            props["plan_id"] = plan_id
        if step_id is not None:
            props["step_id"] = step_id
        if payload is not None:
            props["payload"] = payload

        edges: list[EdgeInsert] = []
        if goal_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:exec-goal:{execution_id}:{goal_id}",
                    source_logical_id=logical_id,
                    target_logical_id=f"goal:{goal_id}",
                    kind=EDGE_FOR_GOAL,
                    properties={},
                    source_ref="memex:world-model",
                    upsert=True,
                )
            )
        if step_id is not None and plan_id is not None:
            edges.append(
                EdgeInsert(
                    row_id=new_row_id(),
                    logical_id=f"edge:exec-step:{execution_id}:{step_id}",
                    source_logical_id=logical_id,
                    target_logical_id=f"wm_plan_step:{step_id}",
                    kind=EDGE_HAS_STEP,
                    properties={},
                    source_ref="memex:world-model",
                    upsert=True,
                )
            )

        self._engine.write(
            WriteRequest(
                label="wm-execution-record",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.EXECUTION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
                edges=edges,
            )
        )
        return logical_id

    def list_executions(
        self,
        *,
        session_id: str | None = None,
        plan_id: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Query WMExecutionRecord nodes with optional filters."""
        q = self._engine.nodes(self.EXECUTION_KIND)
        if session_id is not None:
            q = q.filter_json_text_eq("$.session_id", session_id)
        if plan_id is not None:
            q = q.filter_json_text_eq("$.plan_id", plan_id)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_executions")
        return [_node_to_dict(n) for n in rows.nodes]

    # ── WM Goals (Group 3a) ─────────────────────────────────────────

    def upsert_wm_goal(
        self,
        goal_id: str,
        title: str,
        *,
        status: str = "active",
        priority: str = "medium",
        parent_goal_id: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Create or update a WMGoal node. Returns the logical_id."""
        logical_id = f"wm_goal:{goal_id}"
        props: dict[str, Any] = {
            "goal_id": goal_id,
            "title": title,
            "status": status,
            "priority": priority,
            "updated_at": _now_iso(),
        }
        if parent_goal_id is not None:
            props["parent_goal_id"] = parent_goal_id
        props.update(kwargs)

        self._engine.write(
            WriteRequest(
                label="wm-goal-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.WM_GOAL_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_wm_goal(self, goal_id: str) -> WorldModelGoal | None:
        """Return a world-model goal by ID."""
        d = _get_one(self._engine, self.WM_GOAL_KIND, f"wm_goal:{goal_id}")
        if d is None:
            return None
        return self._to_wm_goal(d)

    def list_wm_goals(
        self,
        *,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelGoal]:
        """Query WMGoal nodes with optional status filter."""
        q = self._engine.nodes(self.WM_GOAL_KIND)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_wm_goals")
        return [self._to_wm_goal(_node_to_dict(n)) for n in rows.nodes]

    # ── WM Tasks (Group 3b) ─────────────────────────────────────────

    def upsert_wm_task(
        self,
        task_id: str,
        task_kind: str,
        title: str,
        *,
        goal_id: str | None = None,
        status: str = "active",
        **kwargs: Any,
    ) -> str:
        """Create or update a WMTask node. Returns the logical_id."""
        logical_id = f"wm_task:{task_id}"
        props: dict[str, Any] = {
            "task_id": task_id,
            "task_kind": task_kind,
            "title": title,
            "status": status,
            "updated_at": _now_iso(),
        }
        if goal_id is not None:
            props["goal_id"] = goal_id
        props.update(kwargs)
        # Serialize datetime values to ISO strings
        for k, v in props.items():
            if isinstance(v, datetime):
                props[k] = v.isoformat()

        self._engine.write(
            WriteRequest(
                label="wm-task-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.WM_TASK_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_wm_task(self, task_id: str) -> WorldModelTask | None:
        """Return a world-model task by ID."""
        d = _get_one(self._engine, self.WM_TASK_KIND, f"wm_task:{task_id}")
        if d is None:
            return None
        return self._to_wm_task(d)

    def list_wm_tasks(
        self,
        *,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelTask]:
        """Query WMTask nodes with optional goal_id/status filters."""
        q = self._engine.nodes(self.WM_TASK_KIND)
        if goal_id is not None:
            q = q.filter_json_text_eq("$.goal_id", goal_id)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_wm_tasks")
        return [self._to_wm_task(_node_to_dict(n)) for n in rows.nodes]

    def delete_wm_task(self, task_id: str) -> None:
        """Retire a WMTask node."""
        logical_id = f"wm_task:{task_id}"
        self._engine.write(
            WriteRequest(
                label="wm-task-delete",
                node_retires=[
                    NodeRetire(
                        logical_id=logical_id,
                        source_ref="memex:world-model",
                    )
                ],
            )
        )

    # ── WM Commitments (Group 3c) ───────────────────────────────────

    def upsert_wm_commitment(
        self,
        commitment_id: str,
        title: str,
        *,
        meeting_id: str | None = None,
        goal_id: str | None = None,
        status: str = "active",
        **kwargs: Any,
    ) -> str:
        """Create or update a WMCommitment node. Returns the logical_id."""
        logical_id = f"wm_commitment:{commitment_id}"
        props: dict[str, Any] = {
            "commitment_id": commitment_id,
            "title": title,
            "status": status,
            "updated_at": _now_iso(),
        }
        if meeting_id is not None:
            props["meeting_id"] = meeting_id
        if goal_id is not None:
            props["goal_id"] = goal_id
        props.update(kwargs)

        self._engine.write(
            WriteRequest(
                label="wm-commitment-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.WM_COMMITMENT_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_wm_commitment(
        self,
        commitment_id: str,
    ) -> WorldModelCommitment | None:
        """Return a world-model commitment by ID."""
        d = _get_one(
            self._engine,
            self.WM_COMMITMENT_KIND,
            f"wm_commitment:{commitment_id}",
        )
        if d is None:
            return None
        return self._to_wm_commitment(d)

    def list_wm_commitments(
        self,
        *,
        meeting_id: str | None = None,
        goal_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelCommitment]:
        """Query WMCommitment nodes with optional filters."""
        q = self._engine.nodes(self.WM_COMMITMENT_KIND)
        if meeting_id is not None:
            q = q.filter_json_text_eq("$.meeting_id", meeting_id)
        if goal_id is not None:
            q = q.filter_json_text_eq("$.goal_id", goal_id)
        if status is not None:
            q = q.filter_json_text_eq("$.status", status)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_wm_commitments")
        return [self._to_wm_commitment(_node_to_dict(n)) for n in rows.nodes]

    def delete_wm_commitment(self, commitment_id: str) -> None:
        """Retire a WMCommitment node."""
        logical_id = f"wm_commitment:{commitment_id}"
        self._engine.write(
            WriteRequest(
                label="wm-commitment-delete",
                node_retires=[
                    NodeRetire(
                        logical_id=logical_id,
                        source_ref="memex:world-model",
                    )
                ],
            )
        )

    # ── Semantic mappings (Group 4) ─────────────────────────────────

    def replace_semantic_mappings(
        self,
        scope_type: str,
        scope_key: str,
        mappings: list[dict[str, Any]],
    ) -> int:
        """Replace semantic mappings for a scope."""
        # Find and retire existing mappings for this scope
        existing = self._list_semantic_mappings_raw(
            scope_type=scope_type,
            scope_key=scope_key,
        )
        retires = [
            NodeRetire(logical_id=m["logical_id"], source_ref="memex:world-model")
            for m in existing
        ]

        # Create new mapping nodes
        now = _now_iso()
        nodes: list[NodeInsert] = []
        for m in mappings:
            mapping_id = new_id()
            logical_id = f"wm_semantic_mapping:{mapping_id}"
            props: dict[str, Any] = {
                "mapping_id": mapping_id,
                "mapping_kind": m.get("mapping_kind", ""),
                "source_value": m.get("source_value", ""),
                "target_value": m.get("target_value", ""),
                "scope_type": scope_type,
                "scope_key": scope_key,
                "created_at": now,
                "updated_at": now,
            }
            nodes.append(
                NodeInsert(
                    row_id=new_row_id(),
                    logical_id=logical_id,
                    kind=self.SEMANTIC_MAPPING_KIND,
                    properties=props,
                    source_ref="memex:world-model",
                    upsert=False,
                    chunk_policy=ChunkPolicy.PRESERVE,
                )
            )

        self._engine.write(
            WriteRequest(
                label="wm-semantic-mapping-replace",
                nodes=nodes,
                node_retires=retires,
            )
        )
        return len(nodes)

    def _list_semantic_mappings_raw(
        self,
        *,
        scope_type: str | None = None,
        scope_key: str | None = None,
    ) -> list[dict[str, Any]]:
        """Internal: raw dicts with logical_id (used by replace_semantic_mappings)."""
        q = self._engine.nodes(self.SEMANTIC_MAPPING_KIND)
        if scope_type is not None:
            q = q.filter_json_text_eq("$.scope_type", scope_type)
        if scope_key is not None:
            q = q.filter_json_text_eq("$.scope_key", scope_key)
        rows = q.limit(500).execute()
        _check_degraded(rows, "list_semantic_mappings")
        return [_node_to_dict(n) for n in rows.nodes]

    def list_semantic_mappings(
        self,
        *,
        scope_type: str | None = None,
        scope_key: str | None = None,
    ) -> list[WorldModelSemanticMapping]:
        """Query WMSemanticMapping nodes with optional scope filters."""
        raw = self._list_semantic_mappings_raw(
            scope_type=scope_type,
            scope_key=scope_key,
        )
        return [self._to_semantic_mapping(d) for d in raw]

    def load_semantic_mapping(
        self,
        mapping_id: str,
    ) -> WorldModelSemanticMapping | None:
        """Return a semantic mapping by ID."""
        d = _get_one(
            self._engine,
            self.SEMANTIC_MAPPING_KIND,
            f"wm_semantic_mapping:{mapping_id}",
        )
        if d is None:
            return None
        return self._to_semantic_mapping(d)

    # ── Knowledge objects (Group 5) ─────────────────────────────────

    def upsert_knowledge_object(
        self,
        knowledge_id: str,
        item_id: str,
        knowledge_type: str,
        canonical_key: str,
        *,
        title: str = "",
        **kwargs: Any,
    ) -> str:
        """Create or update a WMKnowledgeObject node. Returns the logical_id."""
        logical_id = f"wm_knowledge_object:{knowledge_id}"
        props: dict[str, Any] = {
            "knowledge_id": knowledge_id,
            "item_id": item_id,
            "knowledge_type": knowledge_type,
            "canonical_key": canonical_key,
            "title": title,
            "updated_at": _now_iso(),
        }
        props.update(kwargs)

        self._engine.write(
            WriteRequest(
                label="wm-knowledge-object-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.KNOWLEDGE_OBJECT_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_knowledge_object(
        self,
        knowledge_id: str,
    ) -> WorldModelKnowledgeObject | None:
        """Return a knowledge object by ID."""
        d = _get_one(
            self._engine,
            self.KNOWLEDGE_OBJECT_KIND,
            f"wm_knowledge_object:{knowledge_id}",
        )
        if d is None:
            return None
        return self._to_knowledge_object(d)

    def load_knowledge_object_by_item_id(
        self,
        item_id: str,
    ) -> WorldModelKnowledgeObject | None:
        """Return a knowledge object by item_id, or None.

        Tries the canonical ``ki-{item_id}`` logical-id first (fast path),
        then falls back to a JSON property filter.  The fallback is needed
        for knowledge objects created with non-standard knowledge_id values.
        """
        # Fast path: canonical knowledge_id conventions
        for prefix in ("knowledge/", "ki-"):
            ko = self.load_knowledge_object(f"{prefix}{item_id}")
            if ko is not None:
                return ko
        # Fallback: JSON property scan
        rows = (
            self._engine.nodes(self.KNOWLEDGE_OBJECT_KIND)
            .filter_json_text_eq("$.item_id", item_id)
            .limit(1)
            .execute()
        )
        _check_degraded(rows, "load_knowledge_object_by_item_id")
        if not rows.nodes:
            return None
        return self._to_knowledge_object(_node_to_dict(rows.nodes[0]))

    def list_knowledge_objects(
        self,
        *,
        limit: int = 500,
    ) -> list[WorldModelKnowledgeObject]:
        """List all knowledge objects."""
        rows = self._engine.nodes(self.KNOWLEDGE_OBJECT_KIND).limit(limit).execute()
        _check_degraded(rows, "list_knowledge_objects")
        return [self._to_knowledge_object(_node_to_dict(n)) for n in rows.nodes]

    def list_knowledge_entity_links(
        self,
        knowledge_id: str,
        *,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeEntityLink]:
        """Query WMKnowledgeEntityLink nodes for a knowledge object."""
        rows = (
            self._engine.nodes(self.KNOWLEDGE_ENTITY_LINK_KIND)
            .filter_json_text_eq("$.knowledge_id", knowledge_id)
            .limit(limit)
            .execute()
        )
        _check_degraded(rows, "list_knowledge_entity_links")
        return [self._to_knowledge_entity_link(_node_to_dict(n)) for n in rows.nodes]

    def upsert_knowledge_entity_link(
        self,
        link_id: str,
        knowledge_id: str,
        entity_id: str,
        *,
        relationship: str = "mentions",
        confidence: float = 0.0,
        provenance_kind: str = "",
        provenance_ref: str = "",
    ) -> str:
        """Create or update a knowledge-entity link node. Returns logical_id."""
        logical_id = f"wm_knowledge_entity_link:{link_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "link_id": link_id,
            "knowledge_id": knowledge_id,
            "entity_id": entity_id,
            "relationship": relationship,
            "confidence": confidence,
            "provenance_kind": provenance_kind,
            "provenance_ref": provenance_ref,
            "created_at": now,
        }
        self._engine.write(
            WriteRequest(
                label="wm-knowledge-entity-link-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.KNOWLEDGE_ENTITY_LINK_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def list_knowledge_relationships(
        self,
        *,
        source_knowledge_id: str | None = None,
        target_knowledge_id: str | None = None,
        relationship_kind: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelKnowledgeRelationship]:
        """Query WMKnowledgeRelationship nodes with optional filters."""
        q = self._engine.nodes(self.KNOWLEDGE_RELATIONSHIP_KIND)
        if source_knowledge_id is not None:
            q = q.filter_json_text_eq("$.source_knowledge_id", source_knowledge_id)
        if target_knowledge_id is not None:
            q = q.filter_json_text_eq("$.target_knowledge_id", target_knowledge_id)
        if relationship_kind is not None:
            q = q.filter_json_text_eq("$.relationship_kind", relationship_kind)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_knowledge_relationships")
        return [self._to_knowledge_relationship(_node_to_dict(n)) for n in rows.nodes]

    def upsert_knowledge_relationship(
        self,
        relationship_id: str,
        source_knowledge_id: str,
        target_knowledge_id: str,
        relationship_kind: str,
        *,
        summary: str = "",
        confidence: float = 1.0,
        source_surface: str = "",
    ) -> str:
        """Create or update a knowledge relationship node. Returns logical_id."""
        logical_id = f"wm_knowledge_relationship:{relationship_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "relationship_id": relationship_id,
            "source_knowledge_id": source_knowledge_id,
            "target_knowledge_id": target_knowledge_id,
            "relationship_kind": relationship_kind,
            "summary": summary,
            "confidence": confidence,
            "source_surface": source_surface,
            "created_at": now,
            "updated_at": now,
        }
        self._engine.write(
            WriteRequest(
                label="wm-knowledge-relationship-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.KNOWLEDGE_RELATIONSHIP_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    # ── Claim evaluations ──────────────────────────────────────────

    def upsert_claim_evaluation(
        self,
        evaluation_id: str,
        knowledge_id: str,
        item_id: str,
        evaluation_kind: str,
        title: str,
        *,
        summary: str = "",
        status: str = "active",
        payload: dict[str, Any] | None = None,
        source_surface: str = "",
    ) -> str:
        """Create or update a WMClaimEvaluation node. Returns the logical_id."""
        logical_id = f"wm_claim_evaluation:{evaluation_id}"
        now = _now_iso()
        props: dict[str, Any] = {
            "evaluation_id": evaluation_id,
            "knowledge_id": knowledge_id,
            "item_id": item_id,
            "evaluation_kind": evaluation_kind,
            "title": title,
            "summary": summary,
            "status": status,
            "source_surface": source_surface,
            "created_at": now,
            "updated_at": now,
        }
        if payload is not None:
            props["payload"] = payload

        self._engine.write(
            WriteRequest(
                label="wm-claim-evaluation-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.CLAIM_EVALUATION_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_claim_evaluation(
        self,
        evaluation_id: str,
    ) -> WorldModelClaimEvaluation | None:
        """Return a claim evaluation by ID."""
        d = _get_one(
            self._engine,
            self.CLAIM_EVALUATION_KIND,
            f"wm_claim_evaluation:{evaluation_id}",
        )
        if d is None:
            return None
        return self._to_claim_evaluation(d)

    def list_claim_evaluations(
        self,
        *,
        knowledge_id: str | None = None,
        limit: int = 100,
    ) -> list[WorldModelClaimEvaluation]:
        """Query WMClaimEvaluation nodes with optional knowledge_id filter."""
        q = self._engine.nodes(self.CLAIM_EVALUATION_KIND)
        if knowledge_id is not None:
            q = q.filter_json_text_eq("$.knowledge_id", knowledge_id)
        rows = q.limit(limit).execute()
        _check_degraded(rows, "list_claim_evaluations")
        return [self._to_claim_evaluation(_node_to_dict(n)) for n in rows.nodes]

    # ── Prompt control (Group 6) ────────────────────────────────────

    def upsert_prompt_control_artifact(
        self,
        artifact_id: str,
        session_id: str,
        raw_input: str,
        classification: str,
        selected_path: str,
        route_profile: str,
        **kwargs: Any,
    ) -> str:
        """Create or update a WMPromptControl node. Returns the logical_id."""
        logical_id = f"wm_prompt_control:{artifact_id}"
        props: dict[str, Any] = {
            "artifact_id": artifact_id,
            "session_id": session_id,
            "raw_input": raw_input,
            "classification": classification,
            "selected_path": selected_path,
            "route_profile": route_profile,
            "created_at": _now_iso(),
        }
        props.update(kwargs)

        self._engine.write(
            WriteRequest(
                label="wm-prompt-control-upsert",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=logical_id,
                        kind=self.PROMPT_CONTROL_KIND,
                        properties=props,
                        source_ref="memex:world-model",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        return logical_id

    def load_latest_prompt_control(
        self,
        session_id: str,
    ) -> PromptControlArtifact | None:
        """Return the most recently created WMPromptControl for a session."""
        rows = (
            self._engine.nodes(self.PROMPT_CONTROL_KIND)
            .filter_json_text_eq("$.session_id", session_id)
            .limit(100)
            .execute()
        )
        _check_degraded(rows, "load_latest_prompt_control")
        if not rows.nodes:
            return None
        # Pick the node with the latest created_at
        dicts = [_node_to_dict(n) for n in rows.nodes]
        dicts.sort(key=lambda d: d.get("created_at", ""), reverse=True)
        return self._to_prompt_control(dicts[0])

    def list_prompt_control_artifacts(
        self,
        session_id: str,
        limit: int = 20,
    ) -> list[PromptControlArtifact]:
        """Query WMPromptControl nodes for a session, newest first."""
        rows = (
            self._engine.nodes(self.PROMPT_CONTROL_KIND)
            .filter_json_text_eq("$.session_id", session_id)
            .limit(limit)
            .execute()
        )
        _check_degraded(rows, "list_prompt_control_artifacts")
        dicts = [_node_to_dict(n) for n in rows.nodes]
        dicts.sort(key=lambda d: d.get("created_at", ""), reverse=True)
        return [self._to_prompt_control(d) for d in dicts]


# ── FathomStore ───────────────────────────────────────────────────────


class FathomStore:
    """Top-level fathomdb-backed store for Memex.

    All persistent state flows through this object.
    """

    def __init__(self, engine: Engine, path: str) -> None:
        self._engine = engine
        self._path = path
        self.admin = AdminRepository(engine)
        self.operational = OperationalRepository(engine)
        self.conversation = ConversationRepository(engine)
        self.goals = GoalsRepository(engine)
        self.scheduler = SchedulerRepository(engine)
        self.notifications = NotificationsRepository(engine)
        self.meetings = MeetingsRepository(engine)
        self.knowledge = KnowledgeRepository(engine)
        self.world_model = WorldModelRepository(engine)

    #: Embedding dimension used by fathomdb's read-time builtin embedder
    #: (BAAI/bge-small-en-v1.5 → 384, L2-normalized). Passed to Engine.open()
    #: so fathomdb creates per-kind vec tables for vector
    #: search. The Cargo feature ``default-embedder`` must be enabled in the
    #: wheel build; if it isn't, ``embedder="builtin"`` silently degrades to
    #: text-only (vector_hit_count==0 and was_degraded==True on every
    #: SearchRows).
    VECTOR_DIMENSION: int = 384

    @classmethod
    def open(cls, db_path: str) -> FathomStore:
        """Open or create a fathomdb database at *db_path*."""
        engine = Engine.open(
            db_path,
            provenance_mode=ProvenanceMode.WARN,
            vector_dimension=cls.VECTOR_DIMENSION,
            embedder="builtin",
        )
        # Register VecProfile on first open (idempotent)
        try:
            from fathomdb.embedders import BuiltinEmbedder

            if engine.admin.get_vec_profile("KnowledgeItem") is None:
                engine.admin.configure_vec(
                    BuiltinEmbedder(), agree_to_rebuild_impact=True
                )
                logger.info("VecProfile registered: BAAI/bge-small-en-v1.5 @ 384d")
        except Exception:
            logger.warning("VecProfile registration failed", exc_info=True)
        logger.warning(
            "Existing databases must run nightly_vec_regeneration to populate "
            "per-kind vec tables (vec_KnowledgeItem, vec_ConversationTurn). "
            "Fresh databases are auto-bootstrapped at startup."
        )
        # Log current VecProfile
        try:
            profile = engine.admin.get_vec_profile("KnowledgeItem")
            if profile is not None:
                logger.info(
                    "VecProfile: model=%s version=%s dimensions=%d",
                    profile.model_identity,
                    profile.model_version,
                    profile.dimensions,
                )
            else:
                logger.debug("VecProfile: not registered")
        except Exception:
            logger.debug("VecProfile check failed", exc_info=True)
        # Configure recall-optimized-english tokenizer for chunk-FTS kinds (idempotent).
        # Property-FTS kinds are handled by m006. These two use text_search() on chunk
        # storage and require a separate configure_fts call; the nightly fts_rebuild
        # scheduled task applies the actual rebuild.
        for _chunk_kind in ("KnowledgeItem", "ConversationTurn"):
            try:
                if engine.admin.get_fts_profile(_chunk_kind) is None:
                    engine.admin.configure_fts(
                        _chunk_kind,
                        "recall-optimized-english",
                        agree_to_rebuild_impact=True,
                    )
                    logger.info(
                        "FTS tokenizer configured: %s → recall-optimized-english",
                        _chunk_kind,
                    )
            except Exception:
                logger.warning(
                    "FTS tokenizer configuration failed for %s",
                    _chunk_kind,
                    exc_info=True,
                )
        # Fresh-DB vec bootstrap: for each vec-enabled kind, probe for any
        # existing nodes; if none, run regenerate_vector_embeddings once so
        # the per-kind vec tables (vec_KnowledgeItem, vec_ConversationTurn)
        # are populated at first open. No-op on non-empty databases.
        for _vec_kind in ("KnowledgeItem", "ConversationTurn"):
            try:
                probe = engine.nodes(_vec_kind).limit(1).execute()
                if probe.nodes:
                    continue
                from fathomdb import VectorRegenerationConfig

                engine.admin.regenerate_vector_embeddings(
                    VectorRegenerationConfig(
                        kind=_vec_kind,
                        profile="default",
                        chunking_policy="default",
                        preprocessing_policy="default",
                    )
                )
                logger.info("Fresh-DB vec bootstrap: %s", _vec_kind)
            except Exception:
                logger.debug(
                    "Fresh-DB vec bootstrap skipped for %s",
                    _vec_kind,
                    exc_info=True,
                )
        store = cls(engine, db_path)
        store._register_collections()
        store._run_migrations()
        return store

    @property
    def path(self) -> str:
        """Return the database path."""
        return self._path

    @property
    def engine(self) -> Engine:
        """Return the underlying fathomdb engine."""
        return self._engine

    def _register_collections(self) -> None:
        """Register all operational collections (idempotent)."""
        for coll in _COLLECTIONS:
            existing = self._engine.admin.describe_operational_collection(coll.name)
            if existing is not None:
                continue
            try:
                self._engine.admin.register_operational_collection(coll)
            except Exception:
                logger.debug(
                    "Collection %s registration failed",
                    coll.name,
                    exc_info=True,
                )

    def _run_migrations(self) -> None:
        """Apply any pending document migrations (idempotent)."""
        from memex.migrations.runner import run_pending_migrations

        try:
            run_pending_migrations(self._engine)
        except Exception:
            logger.error("Migration runner failed", exc_info=True)
            raise

    def get_resource_stats(self) -> dict[str, Any]:
        """Return fathomdb telemetry counters for resource monitoring."""
        snap = self._engine.telemetry_snapshot()
        return {
            "queries_total": snap.queries_total,
            "writes_total": snap.writes_total,
            "write_rows_total": snap.write_rows_total,
            "errors_total": snap.errors_total,
            "admin_ops_total": snap.admin_ops_total,
            "cache_hits": snap.cache_hits,
            "cache_misses": snap.cache_misses,
            "cache_writes": snap.cache_writes,
            "cache_spills": snap.cache_spills,
        }

    def close(self) -> None:
        """Close the underlying engine. Idempotent.

        Must call engine.close() explicitly before dropping the reference.
        engine.close() runs the Rust Drop inside py.allow_threads(), releasing
        the GIL so the writer thread can finish its pyo3-log calls.  Without
        this, Python GC drops the Rust object with the GIL held, and the
        writer thread's join() deadlocks waiting for the GIL.
        """
        engine = self._engine
        self._engine = None  # type: ignore[assignment]
        if engine is not None:
            engine.close()
