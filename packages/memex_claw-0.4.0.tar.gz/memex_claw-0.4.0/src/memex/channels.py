"""Channel abstraction for pluggable messaging platforms.

Channels are platform adapters (Telegram, Discord, Slack, etc.) with a
unified interface for receiving/sending messages, lifecycle management,
and message splitting.

Usage:
    mgr = ChannelManager(api=memex_api)
    mgr.register(TelegramChannel(config))
    await mgr.start_all()
    ...
    await mgr.stop_all()
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, Awaitable

logger = logging.getLogger(__name__)


@dataclass
class InboundMessage:
    """Message received from a channel."""

    text: str
    sender_id: str
    channel_id: str
    platform: str
    raw: Any = None  # platform-specific raw message object


@dataclass
class OutboundMessage:
    """Message to send via a channel."""

    text: str
    channel_id: str
    reply_to: str | None = None  # platform-specific reply reference


# Type for the handler callback that channels call when they receive a message
MessageHandler = Callable[[InboundMessage], Awaitable[str]]


class Channel(ABC):
    """Base class for messaging platform channels."""

    @property
    @abstractmethod
    def id(self) -> str:
        """Platform identifier (e.g., 'telegram', 'discord')."""

    @property
    def capabilities(self) -> set[str]:
        """Optional capabilities: 'streaming', 'threading', 'reactions'."""
        return set()

    @property
    def max_message_length(self) -> int:
        """Maximum outbound message length. Default 4096."""
        return 4096

    @abstractmethod
    async def start(self, on_message: MessageHandler) -> None:
        """Begin listening for messages. Calls on_message for each inbound message."""

    @abstractmethod
    async def stop(self) -> None:
        """Stop listening and clean up resources."""

    @abstractmethod
    async def send(self, message: OutboundMessage) -> None:
        """Send a message to the channel."""

    async def send_typing(self, channel_id: str) -> None:
        """Send a typing indicator. Optional — default is no-op."""

    def split_message(self, text: str) -> list[str]:
        """Split text at paragraph boundaries respecting max_message_length."""
        max_len = self.max_message_length
        if len(text) <= max_len:
            return [text]

        paragraphs = text.split("\n\n")
        chunks: list[str] = []
        current = ""

        for para in paragraphs:
            candidate = (current + "\n\n" + para).strip() if current else para
            if len(candidate) <= max_len:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                if len(para) > max_len:
                    while para:
                        chunks.append(para[:max_len])
                        para = para[max_len:]
                    current = ""
                else:
                    current = para

        if current:
            chunks.append(current)

        return chunks


class ChannelManager:
    """Manages channel registration and lifecycle.

    Connects channels to MemexAPI by creating a handler that routes
    inbound messages through the chat API.
    """

    def __init__(self, api: Any) -> None:
        self._api = api
        self._channels: list[Channel] = []
        self._running: list[Channel] = []
        self._allowed_users: dict[str, set[str]] = {}  # platform → set of sender_ids

    def register(
        self,
        channel: Channel,
        allowed_users: set[str] | None = None,
    ) -> None:
        """Register a channel. Optional per-platform user allowlist."""
        self._channels.append(channel)
        if allowed_users is not None:
            self._allowed_users[channel.id] = allowed_users

    async def start_all(self) -> None:
        """Start all registered channels."""
        for channel in self._channels:
            handler = self._make_handler(channel)
            try:
                await channel.start(handler)
                self._running.append(channel)
                logger.info("Channel started: %s", channel.id)
            except Exception:
                logger.error("Failed to start channel: %s", channel.id, exc_info=True)

    async def stop_all(self) -> None:
        """Stop all running channels."""
        for channel in reversed(self._running):
            try:
                await channel.stop()
                logger.info("Channel stopped: %s", channel.id)
            except Exception:
                logger.error("Failed to stop channel: %s", channel.id, exc_info=True)
        self._running.clear()

    @property
    def running(self) -> list[Channel]:
        return list(self._running)

    @property
    def registered(self) -> list[Channel]:
        return list(self._channels)

    def _make_handler(self, channel: Channel) -> MessageHandler:
        """Create a message handler that routes through MemexAPI."""
        from datetime import date

        from memex.interfaces.caller import CallerContext

        async def handler(msg: InboundMessage) -> str:
            # Auth check
            allowed = self._allowed_users.get(channel.id)
            if allowed is not None and msg.sender_id not in allowed:
                logger.warning(
                    "Rejected message from unauthorized user %s on %s",
                    msg.sender_id,
                    channel.id,
                )
                return ""

            session_id = f"{channel.id}_{date.today().isoformat()}"
            caller = CallerContext.owner(channel.id, session_id)

            response, _ = self._api.chat(msg.text, caller)
            return response

        return handler
