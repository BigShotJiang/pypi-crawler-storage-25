"""Provider system for credential management and setup wizards.

Providers represent external services (Anthropic, OpenAI, Ollama, etc.)
that require credentials. Each provider defines its setup flow, validation,
and environment variable mapping.

Usage:
    store = CredentialStore()
    prompter = CLIPrompter()
    provider = AnthropicProvider()
    result = provider.setup(prompter)
    if result.success:
        store.save(provider.id, result.credentials)
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ProviderCredential:
    """A single credential key-value pair."""

    key: str
    value: str
    env_var: str  # environment variable name to export as


@dataclass
class ProviderSetupResult:
    """Result of a provider setup flow."""

    success: bool
    credentials: list[ProviderCredential] = field(default_factory=list)
    message: str = ""


class SetupPrompter(ABC):
    """Abstract interface for interactive setup prompting."""

    @abstractmethod
    def text(self, message: str, *, default: str = "", secret: bool = False) -> str:
        """Prompt for text input."""

    @abstractmethod
    def select(self, message: str, choices: list[str]) -> str:
        """Prompt for a selection from choices."""

    @abstractmethod
    def confirm(self, message: str, *, default: bool = True) -> bool:
        """Prompt for yes/no confirmation."""

    @abstractmethod
    def info(self, message: str) -> None:
        """Display informational message."""

    def progress(self, message: str) -> None:
        """Display a progress/status message. Default delegates to info."""
        self.info(message)


class CLIPrompter(SetupPrompter):
    """Interactive CLI prompter using basic input()."""

    def text(self, message: str, *, default: str = "", secret: bool = False) -> str:
        prompt = f"{message}"
        if default:
            prompt += f" [{default}]"
        prompt += ": "

        if secret:
            import getpass

            value = getpass.getpass(prompt)
        else:
            value = input(prompt)

        return value.strip() or default

    def select(self, message: str, choices: list[str]) -> str:
        print(f"\n{message}")
        for i, choice in enumerate(choices, 1):
            print(f"  {i}. {choice}")

        while True:
            try:
                idx = int(input(f"Select (1-{len(choices)}): "))
                if 1 <= idx <= len(choices):
                    return choices[idx - 1]
            except (ValueError, IndexError):
                pass
            print(f"Please enter a number between 1 and {len(choices)}")

    def confirm(self, message: str, *, default: bool = True) -> bool:
        suffix = " [Y/n]" if default else " [y/N]"
        answer = input(f"{message}{suffix}: ").strip().lower()
        if not answer:
            return default
        return answer in ("y", "yes")

    def info(self, message: str) -> None:
        print(message)


class Provider(ABC):
    """Base class for service providers."""

    @property
    @abstractmethod
    def id(self) -> str:
        """Unique provider identifier."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name."""

    @property
    @abstractmethod
    def env_vars(self) -> list[str]:
        """List of environment variable names this provider manages."""

    @abstractmethod
    def setup(self, prompter: SetupPrompter) -> ProviderSetupResult:
        """Run interactive setup flow. Returns credentials on success."""

    def validate(self, credentials: list[ProviderCredential]) -> bool:
        """Validate that credentials are still working. Default returns True."""
        return True


class CredentialStore:
    """JSON-based credential storage.

    Stores credentials at ~/.config/memex/credentials.json.
    """

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or Path.home() / ".config" / "memex" / "credentials.json"

    @property
    def path(self) -> Path:
        return self._path

    def save(self, provider_id: str, credentials: list[ProviderCredential]) -> None:
        """Save credentials for a provider."""
        data = self._load_all()
        data[provider_id] = [
            {"key": c.key, "value": c.value, "env_var": c.env_var} for c in credentials
        ]
        self._write_all(data)

    def load(self, provider_id: str) -> list[ProviderCredential]:
        """Load credentials for a provider. Returns empty list if not found."""
        data = self._load_all()
        entries = data.get(provider_id, [])
        return [
            ProviderCredential(key=e["key"], value=e["value"], env_var=e["env_var"])
            for e in entries
        ]

    def list_providers(self) -> list[str]:
        """List provider IDs that have stored credentials."""
        return list(self._load_all().keys())

    def delete(self, provider_id: str) -> bool:
        """Delete credentials for a provider. Returns True if found."""
        data = self._load_all()
        if provider_id in data:
            del data[provider_id]
            self._write_all(data)
            return True
        return False

    def to_env_vars(self) -> dict[str, str]:
        """Export all stored credentials as environment variables."""
        env: dict[str, str] = {}
        data = self._load_all()
        for entries in data.values():
            for entry in entries:
                env[entry["env_var"]] = entry["value"]
        return env

    def _load_all(self) -> dict[str, list[dict[str, str]]]:
        if not self._path.exists():
            return {}
        try:
            return json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            logger.warning("Failed to read credentials file", exc_info=True)
            return {}

    def _write_all(self, data: dict[str, list[dict[str, str]]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(data, indent=2))
        # Restrict permissions
        try:
            self._path.chmod(0o600)
        except OSError:
            pass
