"""Google Keep integration — read-only access to notes (unofficial API)."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class GoogleKeepClient:
    """Read-only Google Keep client using gkeepapi (unofficial).

    Requires stored Google credentials with master token.
    """

    def __init__(self) -> None:
        self._keep: Any = None

    def authenticate(self) -> None:
        """Authenticate using stored credentials."""
        try:
            import gkeepapi
        except ImportError:
            raise ImportError(
                "gkeepapi is required for Google Keep integration. "
                "Install with: pip install memex-claw[google]"
            )

        from memex.auth.store import get_credentials

        creds = get_credentials("google_keep")
        if creds is None:
            raise RuntimeError(
                "Google Keep not authenticated. Run: memex auth setup google_keep"
            )

        keep = gkeepapi.Keep()
        master_token = creds.get("master_token", "")
        email = creds.get("email", "")

        if not master_token or not email:
            raise RuntimeError("Invalid Google Keep credentials. Re-authenticate.")

        keep.resume(email, master_token)
        self._keep = keep

    def get_notes(
        self,
        *,
        pinned: bool | None = None,
        archived: bool | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Get notes, optionally filtered by pinned/archived status."""
        if self._keep is None:
            raise RuntimeError("Not authenticated")

        notes = list(self._keep.all())

        if pinned is not None:
            notes = [n for n in notes if n.pinned == pinned]
        if archived is not None:
            notes = [n for n in notes if n.archived == archived]

        results: list[dict[str, Any]] = []
        for note in notes[:limit]:
            results.append(
                {
                    "id": note.id,
                    "title": note.title,
                    "text": note.text,
                    "pinned": note.pinned,
                    "archived": note.archived,
                    "labels": [lb.name for lb in note.labels.all()],
                    "color": str(note.color),
                }
            )

        return results

    def search_notes(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        """Search notes by text content."""
        if self._keep is None:
            raise RuntimeError("Not authenticated")

        query_lower = query.lower()
        results: list[dict[str, Any]] = []
        for note in self._keep.all():
            if (
                query_lower in (note.title or "").lower()
                or query_lower in (note.text or "").lower()
            ):
                results.append(
                    {
                        "id": note.id,
                        "title": note.title,
                        "text": note.text[:500],
                        "pinned": note.pinned,
                    }
                )
                if len(results) >= limit:
                    break

        return results
