"""OpenClaw MCP Bridge integration — Python middleware + service.

OpenClawBridgeMiddleware: TurnMiddleware that dispatches hooks to the
    Node.js bridge via _openclaw_hook_dispatch MCP tool.

OpenClawBridgeService: Service that manages the bridge process lifecycle.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from memex.middleware import TurnMiddleware
from memex.models import SessionContext
from memex.services import Service, ServiceContext
from memex.store import MemexStore

logger = logging.getLogger(__name__)


class OpenClawBridgeMiddleware(TurnMiddleware):
    """Dispatches all 7 extended hooks to the OpenClaw bridge via MCP.

    The bridge runs as a separate Node.js process. This middleware calls
    the _openclaw_hook_dispatch internal MCP tool for each hook event.
    """

    def __init__(self, mcp_client: Any = None) -> None:
        self._client = mcp_client

    def _dispatch(self, event: str, payload: dict[str, Any]) -> Any:
        """Call _openclaw_hook_dispatch on the bridge MCP server."""
        if self._client is None:
            return None
        try:
            call_result = self._client.call_tool(
                "_openclaw_hook_dispatch",
                {"event": event, "payload": json.dumps(payload)},
            )

            # Handle async MCPClient (returns coroutine)
            if asyncio.iscoroutine(call_result):
                from memex.connectors.mcp_client import run_async

                call_result = run_async(call_result)

            # MCPClient returns ToolResult with .content attr;
            # test mocks may return a plain string
            if call_result is None:
                return None
            if hasattr(call_result, "content"):
                raw = call_result.content
            elif isinstance(call_result, str):
                raw = call_result
            else:
                return None

            if raw:
                return json.loads(raw)
            return None
        except Exception:
            logger.debug("OpenClaw hook dispatch failed for %s", event, exc_info=True)
            return None

    # --- Transform hooks (return modified values) ---

    def on_message_received(self, session: SessionContext, user_input: str) -> str:
        result = self._dispatch(
            "on_message_received",
            {
                "session_id": session.session_id,
                "user_input": user_input,
            },
        )
        if result and isinstance(result, dict) and "user_input" in result:
            return result["user_input"]
        return user_input

    def on_message_sending(self, session: SessionContext, response: str) -> str:
        result = self._dispatch(
            "on_message_sending",
            {
                "session_id": session.session_id,
                "response": response,
            },
        )
        if result and isinstance(result, dict) and "response" in result:
            return result["response"]
        return response

    def before_prompt_build(self, session: SessionContext, store: MemexStore) -> str:
        result = self._dispatch(
            "before_prompt_build",
            {
                "session_id": session.session_id,
            },
        )
        if result and isinstance(result, dict) and "content" in result:
            return result["content"]
        return ""

    # --- Observe-only hooks (fire-and-forget) ---

    def on_llm_input(
        self, session: SessionContext, messages: list[dict[str, Any]]
    ) -> None:
        self._dispatch(
            "on_llm_input",
            {
                "session_id": session.session_id,
                "message_count": len(messages),
            },
        )

    def on_llm_output(
        self, session: SessionContext, response: str, tool_calls: list[dict[str, Any]]
    ) -> None:
        self._dispatch(
            "on_llm_output",
            {
                "session_id": session.session_id,
                "response_length": len(response),
                "tool_call_count": len(tool_calls),
            },
        )

    # --- Tool call hooks ---

    def before_tool_call(
        self, session: SessionContext, tool_name: str, arguments: dict[str, Any]
    ) -> tuple[dict[str, Any], bool]:
        result = self._dispatch(
            "before_tool_call",
            {
                "session_id": session.session_id,
                "tool_name": tool_name,
                "arguments": arguments,
            },
        )
        if result and isinstance(result, dict):
            blocked = result.get("blocked", False)
            args = result.get("arguments", arguments)
            return args, blocked
        return arguments, False

    def after_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
        result: Any,
    ) -> None:
        content = ""
        if hasattr(result, "content"):
            content = result.content[:500]
        elif isinstance(result, str):
            content = result[:500]
        self._dispatch(
            "after_tool_call",
            {
                "session_id": session.session_id,
                "tool_name": tool_name,
                "result_preview": content,
            },
        )


# NOTE (as of commit 1da7e0a): Bridge process lifecycle is managed by MCPClient
# via _connect_plugin_bridge() in loop.py, not by ServiceManager.
# This service skeleton remains for future use (e.g. health monitoring,
# hot-reload) and is covered by existing tests.
class OpenClawBridgeService(Service):
    """Manages the OpenClaw bridge Node.js process lifecycle."""

    @property
    def id(self) -> str:
        return "openclaw-bridge"

    @property
    def name(self) -> str:
        return "OpenClaw MCP Bridge"

    def start(self, ctx: ServiceContext) -> None:
        bridge_dir = ctx.config.get("bridge_dir")
        if not bridge_dir:
            ctx.logger.info("No bridge_dir configured, skipping OpenClaw bridge")
            return

        # The bridge is started as an MCP server via the existing connector system.
        # This service just validates config and logs readiness.
        ctx.logger.info("OpenClaw bridge configured at %s", bridge_dir)

    def stop(self, ctx: ServiceContext) -> None:
        ctx.logger.info("OpenClaw bridge service stopping")
