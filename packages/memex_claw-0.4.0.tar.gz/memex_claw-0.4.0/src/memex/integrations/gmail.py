"""Gmail integration — read-only access via official Google client libraries."""

from __future__ import annotations

import base64
import json
import logging
import os
from datetime import datetime
from typing import Any

logger = logging.getLogger(__name__)

_SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]


class GmailClient:
    """Read-only Gmail client using google-api-python-client."""

    def __init__(self) -> None:
        self._service: Any | None = None

    def setup_auth(self) -> dict:
        """Run interactive OAuth2 flow for Gmail.

        Returns token data dict suitable for auth.store.save_credentials().
        """
        client_id = os.environ.get("MEMEX_GOOGLE_CLIENT_ID", "")
        client_secret = os.environ.get("MEMEX_GOOGLE_CLIENT_SECRET", "")
        if not client_id or not client_secret:
            raise RuntimeError(
                "MEMEX_GOOGLE_CLIENT_ID and MEMEX_GOOGLE_CLIENT_SECRET not set. "
                "Create OAuth credentials at https://console.cloud.google.com"
            )

        from google_auth_oauthlib.flow import InstalledAppFlow

        client_config = {
            "installed": {
                "client_id": client_id,
                "client_secret": client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/v2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"],
            }
        }

        flow = InstalledAppFlow.from_client_config(client_config, scopes=_SCOPES)
        creds = flow.run_local_server(port=0)

        # Convert to dict for auth.store persistence
        token_data = json.loads(creds.to_json())
        from memex.auth.store import save_credentials

        save_credentials("gmail", token_data)
        return token_data

    def authenticate(self) -> None:
        """Load stored credentials and refresh if needed."""
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build

        from memex.auth.store import get_credentials, save_credentials

        creds_data = get_credentials("gmail")
        if creds_data is None:
            raise RuntimeError("Gmail not authenticated. Run: memex auth setup gmail")

        creds = Credentials.from_authorized_user_info(creds_data, scopes=_SCOPES)

        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            save_credentials("gmail", json.loads(creds.to_json()))

        if not creds.valid:
            raise RuntimeError(
                "Gmail credentials invalid. Re-authenticate with: memex auth setup gmail"
            )

        self._service = build("gmail", "v1", credentials=creds)

    def _require_service(self) -> Any:
        if self._service is None:
            raise RuntimeError("Not authenticated")
        return self._service

    def get_sent_messages(
        self,
        since: datetime | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Get sent messages, optionally filtered by date."""
        service = self._require_service()

        query = "in:sent"
        if since:
            query += f" after:{since.strftime('%Y/%m/%d')}"

        resp = (
            service.users()
            .messages()
            .list(userId="me", q=query, maxResults=limit)
            .execute()
        )
        message_ids = [m["id"] for m in resp.get("messages", [])]

        messages: list[dict[str, Any]] = []
        for msg_id in message_ids[:limit]:
            try:
                msg = self._get_message(msg_id)
                if msg:
                    messages.append(msg)
            except Exception as exc:
                logger.warning("Failed to fetch message %s: %s", msg_id, exc)

        return messages

    def _get_message(self, message_id: str) -> dict[str, Any] | None:
        """Fetch a single message by ID."""
        service = self._require_service()

        data = (
            service.users()
            .messages()
            .get(userId="me", id=message_id, format="full")
            .execute()
        )

        headers = {
            h.get("name", "").lower(): h.get("value", "")
            for h in data.get("payload", {}).get("headers", [])
        }
        payload = data.get("payload", {})
        body = self._extract_body(payload)
        audio_attachments = self._get_audio_attachments(payload)

        return {
            "id": message_id,
            "subject": headers.get("subject", ""),
            "from": headers.get("from", ""),
            "to": headers.get("to", ""),
            "date": headers.get("date", ""),
            "body": body,
            "audio_attachments": audio_attachments,
        }

    def _get_audio_attachments(self, payload: dict) -> list[dict[str, Any]]:
        """Walk the MIME payload tree and return metadata for audio attachments."""
        results: list[dict[str, Any]] = []
        mime = payload.get("mimeType", "")
        if mime.startswith("audio/") and payload.get("body", {}).get("attachmentId"):
            results.append(
                {
                    "filename": payload.get("filename", "attachment"),
                    "mime_type": mime,
                    "attachment_id": payload["body"]["attachmentId"],
                }
            )
        for part in payload.get("parts", []):
            results.extend(self._get_audio_attachments(part))
        return results

    def download_attachment(self, message_id: str, attachment_id: str) -> bytes:
        """Download raw attachment bytes from the Gmail API."""
        service = self._require_service()
        att = (
            service.users()
            .messages()
            .attachments()
            .get(userId="me", messageId=message_id, id=attachment_id)
            .execute()
        )
        return base64.urlsafe_b64decode(att["data"])

    def _extract_body(self, payload: dict) -> str:
        """Extract plain text body from Gmail message payload."""
        if payload.get("mimeType") == "text/plain":
            data = payload.get("body", {}).get("data", "")
            if data:
                decoded = base64.urlsafe_b64decode(data).decode(
                    "utf-8", errors="replace"
                )
                if decoded.strip():
                    return decoded

        for part in payload.get("parts", []):
            text = self._extract_body(part)
            if text:
                return text

        return ""

    def search_messages(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        """Search Gmail messages using Gmail query syntax."""
        service = self._require_service()

        resp = (
            service.users()
            .messages()
            .list(userId="me", q=query, maxResults=limit)
            .execute()
        )
        message_ids = [m["id"] for m in resp.get("messages", [])]

        messages: list[dict[str, Any]] = []
        for msg_id in message_ids[:limit]:
            try:
                msg = self._get_message(msg_id)
                if msg:
                    messages.append(msg)
            except Exception as exc:
                logger.warning("Failed to fetch message %s: %s", msg_id, exc)

        return messages
