"""Outlook M365 Calendar integration via Microsoft Graph API."""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_AUTH_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
_TOKEN_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
_SCOPES = ["Calendars.Read", "User.Read"]


class OutlookClient:
    """Read-only Outlook calendar client using Microsoft Graph API."""

    def __init__(self) -> None:
        self._access_token: str | None = None

    def setup_auth(self) -> dict:
        """Run interactive OAuth2 PKCE flow for Outlook/M365."""
        client_id = os.environ.get("MEMEX_OUTLOOK_CLIENT_ID", "")
        if not client_id:
            raise RuntimeError(
                "MEMEX_OUTLOOK_CLIENT_ID not set. "
                "Create an app registration at https://portal.azure.com"
            )

        from memex.auth.oauth import OAuth2Flow

        flow = OAuth2Flow(
            service="outlook",
            client_id=client_id,
            auth_url=_AUTH_URL,
            token_url=_TOKEN_URL,
            scopes=_SCOPES,
            use_pkce=True,
        )
        return flow.run_local_server()

    def authenticate(self) -> None:
        """Load stored credentials and refresh if needed."""
        from memex.auth.store import get_credentials, is_token_expired

        creds = get_credentials("outlook")
        if creds is None:
            raise RuntimeError(
                "Outlook not authenticated. Run: memex auth setup outlook"
            )

        if is_token_expired(creds):
            refresh_token = creds.get("refresh_token")
            if not refresh_token:
                raise RuntimeError(
                    "Outlook token expired and no refresh token. Re-authenticate."
                )

            client_id = os.environ.get("MEMEX_OUTLOOK_CLIENT_ID", "")
            client_secret = os.environ.get("MEMEX_OUTLOOK_CLIENT_SECRET", "")
            from memex.auth.oauth import OAuth2Flow

            flow = OAuth2Flow(
                service="outlook",
                client_id=client_id,
                client_secret=client_secret,
                auth_url=_AUTH_URL,
                token_url=_TOKEN_URL,
                scopes=_SCOPES,
            )
            creds = flow.refresh(refresh_token)

        self._access_token = creds.get("access_token")

    def _headers(self) -> dict[str, str]:
        if not self._access_token:
            raise RuntimeError("Not authenticated")
        return {"Authorization": f"Bearer {self._access_token}"}

    def get_events(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Get calendar events within a time range."""
        import httpx

        start = start or utcnow()
        end = end or start + timedelta(days=7)

        # Graph API requires timezone-aware datetimes.
        # Internal datetimes are naive UTC; add tzinfo at the API boundary.
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        params = {
            "startDateTime": start.isoformat(),
            "endDateTime": end.isoformat(),
            "$top": str(limit),
            "$orderby": "start/dateTime",
            "$select": "subject,start,end,location,organizer,isAllDay",
        }

        resp = httpx.get(
            f"{_GRAPH_BASE}/me/calendarview",
            headers=self._headers(),
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json().get("value", [])

    def get_today_events(self) -> list[dict[str, Any]]:
        """Get today's calendar events."""
        now = utcnow()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return self.get_events(start=start, end=end)
