"""Filesystem MCP server integration — read/write capability separation."""

from __future__ import annotations

from memex.connectors.mcp_client import MCPClient
from memex.models import ToolDefinition

# Tools that modify the filesystem require filesystem.write capability.
# All others default to filesystem.read.
_WRITE_TOOLS = {
    "write_file",
    "edit_file",
    "create_directory",
    "move_file",
}

_TOOL_KEYWORDS: dict[str, list[str]] = {
    "read_file": ["read", "file", "contents", "open", "cat", "show"],
    "read_multiple_files": ["read", "files", "batch", "multiple"],
    "write_file": ["write", "file", "create", "save", "output"],
    "edit_file": ["edit", "file", "modify", "change", "replace", "patch"],
    "create_directory": ["mkdir", "directory", "folder", "create"],
    "list_directory": ["ls", "list", "directory", "files", "folder"],
    "directory_tree": ["tree", "directory", "structure", "recursive"],
    "move_file": ["move", "rename", "mv", "file"],
    "search_files": ["search", "find", "glob", "pattern", "files"],
    "get_file_info": ["info", "stat", "size", "metadata", "file"],
    "list_allowed_directories": ["allowed", "roots", "directories", "scope"],
}


class FilesystemIntegration:
    """Wraps an MCP filesystem server client with read/write capability separation."""

    def __init__(self, client: MCPClient, *, write: bool = False) -> None:
        self._client = client
        self._write = write

    def get_tool_definitions(self) -> list[ToolDefinition]:
        """Return discovered tools with filesystem.read or filesystem.write capability.

        When write=False, write tools are excluded entirely (not registered).
        """
        result: list[ToolDefinition] = []
        for td in self._client.discovered_tools:
            is_write_tool = td.name in _WRITE_TOOLS
            if is_write_tool and not self._write:
                continue
            capability = "filesystem.write" if is_write_tool else "filesystem.read"
            keywords = _TOOL_KEYWORDS.get(td.name, [])
            result.append(
                td.model_copy(
                    update={
                        "required_capability": capability,
                        "keywords": keywords,
                    }
                )
            )
        return result
