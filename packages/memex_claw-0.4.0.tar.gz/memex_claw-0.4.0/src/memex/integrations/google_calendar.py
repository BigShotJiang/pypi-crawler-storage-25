"""Google Calendar integration — upcoming events via official Google client."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any

from memex.models import CalendarEvent
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_SCOPES = ["https://www.googleapis.com/auth/calendar.readonly"]


class GoogleCalendarClient:
    """Read-only Google Calendar client using google-api-python-client."""

    def __init__(self) -> None:
        self._service: Any | None = None

    def setup_auth(self) -> dict:
        """Run interactive OAuth2 flow for Google Calendar."""
        client_id = os.environ.get("MEMEX_GOOGLE_CLIENT_ID", "")
        client_secret = os.environ.get("MEMEX_GOOGLE_CLIENT_SECRET", "")
        if not client_id or not client_secret:
            raise RuntimeError(
                "MEMEX_GOOGLE_CLIENT_ID and MEMEX_GOOGLE_CLIENT_SECRET not set. "
                "Create OAuth credentials at https://console.cloud.google.com"
            )

        from google_auth_oauthlib.flow import InstalledAppFlow

        client_config = {
            "installed": {
                "client_id": client_id,
                "client_secret": client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/v2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"],
            }
        }

        flow = InstalledAppFlow.from_client_config(client_config, scopes=_SCOPES)
        creds = flow.run_local_server(port=0)

        token_data = json.loads(creds.to_json())
        from memex.auth.store import save_credentials

        save_credentials("google_calendar", token_data)
        return token_data

    def authenticate(self) -> None:
        """Load stored credentials and refresh if needed."""
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build

        from memex.auth.store import get_credentials, save_credentials

        creds_data = get_credentials("google_calendar")
        if creds_data is None:
            raise RuntimeError(
                "Google Calendar not authenticated. Run setup_auth() first."
            )

        creds = Credentials.from_authorized_user_info(creds_data, scopes=_SCOPES)

        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            save_credentials("google_calendar", json.loads(creds.to_json()))

        if not creds.valid:
            raise RuntimeError("Google Calendar credentials invalid.")

        self._service = build("calendar", "v3", credentials=creds)

    def _require_service(self) -> Any:
        if self._service is None:
            raise RuntimeError("Not authenticated")
        return self._service

    def list_upcoming_events(
        self,
        *,
        now: datetime,
        horizon: datetime,
        calendar_id: str = "primary",
        limit: int = 20,
    ) -> list[CalendarEvent]:
        """List upcoming events between now and horizon."""
        service = self._require_service()
        response = (
            service.events()
            .list(
                calendarId=calendar_id,
                timeMin=now.isoformat() + "Z",
                timeMax=horizon.isoformat() + "Z",
                singleEvents=True,
                orderBy="startTime",
                maxResults=limit,
            )
            .execute()
        )

        events: list[CalendarEvent] = []
        synced_at = utcnow()
        for item in response.get("items", []):
            start_raw = item.get("start", {}).get("dateTime")
            if not start_raw:
                continue
            end_raw = item.get("end", {}).get("dateTime")
            attendees = []
            for attendee in item.get("attendees", []) or []:
                name = attendee.get("displayName") or attendee.get("email") or ""
                if name:
                    attendees.append(name)
            events.append(
                CalendarEvent(
                    event_id=item.get("id", ""),
                    provider="google",
                    title=item.get("summary", "") or "Untitled Event",
                    starts_at=datetime.fromisoformat(start_raw.replace("Z", "+00:00")),
                    ends_at=datetime.fromisoformat(end_raw.replace("Z", "+00:00"))
                    if end_raw
                    else None,
                    attendees=attendees,
                    metadata={
                        "html_link": item.get("htmlLink", ""),
                        "status": item.get("status", ""),
                    },
                    synced_at=synced_at,
                )
            )
        return events
