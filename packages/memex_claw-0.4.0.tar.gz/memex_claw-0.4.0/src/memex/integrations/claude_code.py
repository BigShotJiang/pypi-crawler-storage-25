"""Claude Code integration — 5 tools for code tasks."""

from __future__ import annotations

from typing import Any

from memex.connectors.claude_code import ClaudeCodeClient
from memex.models import ToolDefinition, ToolResult

# Tool configurations: (allowed_tools, permission_mode, max_turns, capability)
_TOOL_CONFIGS: dict[str, dict[str, Any]] = {
    "claude_code_explain": {
        "description": "Explain code in a file or directory using Claude Code",
        "allowed_tools": ["Read", "Glob", "Grep"],
        "permission_mode": "plan",
        "max_turns": 3,
        "capability": "claude_code.read",
        "prompt_prefix": "Explain the following code clearly and concisely:\n\n",
        "keywords": ["explain", "understand", "what", "how", "code", "read"],
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What to explain (include file paths or patterns)",
                },
            },
            "required": ["prompt"],
        },
    },
    "claude_code_review": {
        "description": "Review code for issues, style, and improvements using Claude Code",
        "allowed_tools": ["Read", "Glob", "Grep"],
        "permission_mode": "plan",
        "max_turns": 3,
        "capability": "claude_code.read",
        "prompt_prefix": "Review the following code for bugs, style issues, and improvements:\n\n",
        "keywords": ["review", "check", "audit", "quality", "lint", "issues"],
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What to review (include file paths or patterns)",
                },
            },
            "required": ["prompt"],
        },
    },
    "claude_code_write": {
        "description": "Write new code or add features using Claude Code",
        "allowed_tools": ["Read", "Glob", "Grep", "Write", "Edit"],
        "permission_mode": "default",
        "max_turns": 10,
        "capability": "claude_code.execute",
        "prompt_prefix": "",
        "keywords": ["write", "create", "add", "implement", "build", "new"],
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What to write (be specific about files and requirements)",
                },
            },
            "required": ["prompt"],
        },
    },
    "claude_code_refactor": {
        "description": "Refactor existing code using Claude Code",
        "allowed_tools": ["Read", "Glob", "Grep", "Write", "Edit"],
        "permission_mode": "default",
        "max_turns": 10,
        "capability": "claude_code.execute",
        "prompt_prefix": "Refactor the following code:\n\n",
        "keywords": ["refactor", "rename", "restructure", "clean", "improve", "move"],
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What to refactor (include file paths and desired changes)",
                },
            },
            "required": ["prompt"],
        },
    },
    "claude_code_debug": {
        "description": "Debug issues in code using Claude Code (has shell access)",
        "allowed_tools": ["Read", "Glob", "Grep", "Bash", "Write", "Edit"],
        "permission_mode": "default",
        "max_turns": 10,
        "capability": "claude_code.execute",
        "prompt_prefix": "Debug the following issue:\n\n",
        "keywords": ["debug", "fix", "error", "bug", "crash", "failing", "broken"],
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "What to debug (include error messages and file paths)",
                },
            },
            "required": ["prompt"],
        },
    },
}


class ClaudeCodeIntegration:
    """High-level Claude Code interface wrapping ClaudeCodeClient."""

    def __init__(self, client: ClaudeCodeClient) -> None:
        self._client = client
        self._sessions: dict[str, str] = {}  # tool_name -> last session_id

    def get_tool_definitions(self) -> list[ToolDefinition]:
        """Return 5 tool definitions for Claude Code capabilities."""
        result: list[ToolDefinition] = []
        for name, config in _TOOL_CONFIGS.items():
            result.append(
                ToolDefinition(
                    name=name,
                    description=config["description"],
                    parameters=config["parameters"],
                    source=f"claude_code:{name}",
                    required_capability=config["capability"],
                    keywords=config["keywords"],
                )
            )
        return result

    def execute_tool(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> ToolResult:
        """Dispatch a tool call to the correct claude CLI invocation."""
        config = _TOOL_CONFIGS.get(tool_name)
        if not config:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error=f"Unknown Claude Code tool: {tool_name}",
                source="claude_code",
                duration_ms=0,
            )

        prompt = arguments.get("prompt", "")
        if not prompt:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error="Missing required parameter: prompt",
                source="claude_code",
                duration_ms=0,
            )

        # Prefix prompt with task-specific instruction (safe concatenation, no .format())
        formatted_prompt = config["prompt_prefix"] + prompt

        # Resume existing session if we have one for this tool
        existing_session = self._sessions.get(tool_name)
        if existing_session:
            result = self._client.resume(
                existing_session,
                formatted_prompt,
                allowed_tools=config["allowed_tools"],
                permission_mode=config["permission_mode"],
                max_turns=config["max_turns"],
            )
            # Clear stale session on failure so next call starts fresh
            if not result.success:
                del self._sessions[tool_name]
        else:
            result = self._client.execute(
                formatted_prompt,
                allowed_tools=config["allowed_tools"],
                permission_mode=config["permission_mode"],
                max_turns=config["max_turns"],
            )

        # Track session_id for write-capable tools so follow-ups can resume
        if result.success and self._client.last_session_id:
            if config["capability"] == "claude_code.execute":
                self._sessions[tool_name] = self._client.last_session_id

        return result
