"""iCloud Calendar integration via CalDAV."""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta
from typing import Any
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_ICLOUD_CALDAV_URL = "https://caldav.icloud.com"


class ICloudCalendarClient:
    """Read-only iCloud calendar client via CalDAV protocol."""

    def __init__(self) -> None:
        self._client: Any = None
        self._principal: Any = None

    def setup_auth(self) -> dict:
        """Store iCloud credentials (username + app-specific password)."""
        username = os.environ.get("MEMEX_ICLOUD_USERNAME", "")
        app_password = os.environ.get("MEMEX_ICLOUD_APP_PASSWORD", "")

        if not username or not app_password:
            raise RuntimeError(
                "MEMEX_ICLOUD_USERNAME and MEMEX_ICLOUD_APP_PASSWORD not set. "
                "Generate an app-specific password at https://appleid.apple.com"
            )

        from memex.auth.store import save_credentials

        creds = {
            "username": username,
            "app_password": app_password,
        }
        save_credentials("icloud", creds)
        return creds

    def authenticate(self) -> None:
        """Connect to iCloud CalDAV using stored credentials."""
        try:
            import caldav
        except ImportError:
            raise ImportError(
                "caldav is required for iCloud integration. "
                "Install with: pip install memex-claw[google]"
            )

        from memex.auth.store import get_credentials

        creds = get_credentials("icloud")
        if creds is None:
            raise RuntimeError("iCloud not authenticated. Run: memex auth setup icloud")

        username = creds.get("username", "")
        password = creds.get("app_password", "")

        self._client = caldav.DAVClient(
            url=_ICLOUD_CALDAV_URL,
            username=username,
            password=password,
        )
        self._principal = self._client.principal()

    def list_calendars(self) -> list[dict[str, str]]:
        """List available calendars."""
        if self._principal is None:
            raise RuntimeError("Not authenticated")

        calendars = self._principal.calendars()
        return [{"name": cal.name, "url": str(cal.url)} for cal in calendars]

    def get_events(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
        calendar_name: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get calendar events within a time range."""
        if self._principal is None:
            raise RuntimeError("Not authenticated")

        start = start or utcnow()
        end = end or start + timedelta(days=7)

        calendars = self._principal.calendars()
        if calendar_name:
            calendars = [c for c in calendars if c.name == calendar_name]

        events: list[dict[str, Any]] = []
        for cal in calendars:
            try:
                for event in cal.date_search(start=start, end=end, expand=True):
                    vobj = getattr(event, "vobject_instance", None)
                    if vobj is None:
                        continue
                    vevents = getattr(vobj, "vevent_list", None)
                    if vevents is None:
                        vevent = getattr(vobj, "vevent", None)
                        vevents = [vevent] if vevent is not None else []
                    for vevent in vevents:
                        dtstart = getattr(vevent, "dtstart", None)
                        dtend = getattr(vevent, "dtend", None)
                        events.append(
                            {
                                "summary": str(getattr(vevent, "summary", "")),
                                "start": str(dtstart.value) if dtstart else "",
                                "end": str(dtend.value) if dtend else "",
                                "location": str(getattr(vevent, "location", "")),
                                "calendar": cal.name,
                            }
                        )
            except Exception as exc:
                logger.warning("Failed to fetch events from %s: %s", cal.name, exc)

        return events
