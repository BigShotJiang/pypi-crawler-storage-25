"""PhaseGraph: declarative turn orchestration for Memex.

The phase graph replaces the monolithic ``run_turn()`` function with a
validated DAG of typed computation nodes.  It provides structural guarantees
— termination, deadlock-freedom, input completeness, deterministic
degradation — that are verified statically at graph-construction time.

Key modules:

- ``graph``        Data structures (PhaseNode, PhaseEdge, JoinBarrier, etc.)
- ``definition``   The Memex turn graph (``build_memex_turn_graph()``)
- ``executor``     Sequential dispatch engine
- ``validation``   Static O(V*E) checks run at construction time
- ``smp_validator`` Memex-specific conformance checks
- ``nodes/``       Phase implementations (classify, gather, respond, …)
"""

from memex.phase_graph.context import INITIAL_CONTEXT_KEYS, TurnContext
from memex.phase_graph.graph import (
    FallbackEdge,
    GraphDefinitionError,
    JoinBarrier,
    PhaseEdge,
    PhaseGraph,
    PhaseNode,
)
from memex.phase_graph.executor import GraphExecutor
from memex.phase_graph.retry import RetryPolicy
from memex.phase_graph.trace import PhaseTraceEntry, compute_phase_timings
from memex.phase_graph.events import PhaseCheckpointed, PhaseCompleted, PhaseStarted

__all__ = [
    "FallbackEdge",
    "GraphDefinitionError",
    "GraphExecutor",
    "INITIAL_CONTEXT_KEYS",
    "JoinBarrier",
    "PhaseCheckpointed",
    "PhaseCompleted",
    "PhaseEdge",
    "PhaseGraph",
    "PhaseNode",
    "PhaseStarted",
    "PhaseTraceEntry",
    "RetryPolicy",
    "TurnContext",
    "compute_phase_timings",
]
