"""Phase lifecycle events published to the event bus."""

from __future__ import annotations

from dataclasses import dataclass

from memex.events import DomainEvent


@dataclass(frozen=True)
class PhaseStarted(DomainEvent):
    node_name: str = ""
    turn_ordinal: int = 0


@dataclass(frozen=True)
class PhaseCompleted(DomainEvent):
    node_name: str = ""
    turn_ordinal: int = 0
    duration_ms: int = 0
    status: str = "completed"


@dataclass(frozen=True)
class PhaseCheckpointed(DomainEvent):
    node_name: str = ""
    turn_ordinal: int = 0
