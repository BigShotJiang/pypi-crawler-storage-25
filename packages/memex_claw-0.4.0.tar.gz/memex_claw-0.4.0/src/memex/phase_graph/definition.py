"""Assemble the full Memex turn graph.

build_memex_turn_graph() returns a PhaseGraph with all nodes, edges,
fallback edges, join barriers, and exclusive output pairs.  The graph
is NOT constructed at module load time — call the function when needed.
"""

from __future__ import annotations

from memex.phase_graph.context import TurnContext, _set_retrieval_defaults
from memex.phase_graph.graph import (
    FallbackEdge,
    JoinBarrier,
    PhaseEdge,
    PhaseGraph,
    PhaseNode,
)
from memex.phase_graph.retry import (
    RetryPolicy,
    _is_io_error,
    _is_llm_error,
    _is_network_error,
    _is_timeout,
)

# -- Node names ----------------------------------------------------------------

LOAD_CONTEXT = "LOAD_CONTEXT"
EVALUATE_PRIOR_ANSWER_FEEDBACK = "EVALUATE_PRIOR_ANSWER_FEEDBACK"
CLASSIFY = "CLASSIFY"
MIDDLEWARE_CLASSIFY = "MIDDLEWARE_CLASSIFY"
INTENT_FRAME = "INTENT_FRAME"
EARLY_EXIT = "EARLY_EXIT"
FILTER_GOALS = "FILTER_GOALS"
SELECT_TOOLS = "SELECT_TOOLS"
RETRIEVE = "RETRIEVE"
SKIP_RETRIEVE = "SKIP_RETRIEVE"
PROACTIVE_CONTEXT = "PROACTIVE_CONTEXT"
FACT_STORE = "FACT_STORE"
_GATHER_JOIN = "_GATHER_JOIN"
BUILD_PROMPT = "BUILD_PROMPT"
RECORD_HUMAN_TURN = "RECORD_HUMAN_TURN"
LLM_RESPOND = "LLM_RESPOND"
TOOL_LOOP = "TOOL_LOOP"
WINDOW_HISTORY = "WINDOW_HISTORY"
RETURN_RESPONSE = "RETURN_RESPONSE"
EXTRACT_REFLECT = "EXTRACT_REFLECT"
APPLY_EXTRACTION = "APPLY_EXTRACTION"
APPLY_REFLECT = "APPLY_REFLECT"
_POST_JOIN = "_POST_JOIN"
PROACTIVE_CHECK = "PROACTIVE_CHECK"
SAVE_SESSION = "SAVE_SESSION"

# Fallback node names
CLASSIFY_DEFAULT = "CLASSIFY_DEFAULT"
RETRIEVE_FALLBACK = "RETRIEVE_FALLBACK"
RETURN_ERROR = "RETURN_ERROR"
REFLECT_ONLY = "REFLECT_ONLY"
REFLECT_FALLBACK = "REFLECT_FALLBACK"
LOG_SAVE_FAILURE = "LOG_SAVE_FAILURE"
TOOL_LOOP_FALLBACK = "TOOL_LOOP_FALLBACK"


# -- Edge conditions -----------------------------------------------------------


def _is_early_exit(ctx: TurnContext) -> bool:
    from memex.models import IntentFramePath

    sac = ctx.get("selected_action_candidate")
    if sac is None:
        return False
    return sac.name in (IntentFramePath.CLARIFY.value, IntentFramePath.ABSTAIN.value)


def _is_normal_path(ctx: TurnContext) -> bool:
    return not _is_early_exit(ctx)


def _should_retrieve(ctx: TurnContext) -> bool:
    from memex.loop import _should_auto_retrieve_for_turn

    return _should_auto_retrieve_for_turn(
        ctx["classification"],
        prompt_control_artifact=ctx["session"].last_prompt_control,
        intent_frame=ctx["intent_frame"],
    )


def _should_skip_retrieve(ctx: TurnContext) -> bool:
    return not _should_retrieve(ctx)


def _has_tool_calls(ctx: TurnContext) -> bool:
    return bool(ctx.get("tool_calls"))


def _no_tool_calls(ctx: TurnContext) -> bool:
    return not _has_tool_calls(ctx)


def _is_early_save(ctx: TurnContext) -> bool:
    return ctx.get("early_exit_response") is not None


def _is_normal_return(ctx: TurnContext) -> bool:
    return ctx.get("early_exit_response") is None


def _has_extraction(ctx: TurnContext) -> bool:
    return ctx.get("extraction_result") is not None


# -- Noop for join barriers and skip nodes ------------------------------------


def _noop(ctx: TurnContext) -> None:
    pass


# -- Graph builder -------------------------------------------------------------


def build_memex_turn_graph() -> PhaseGraph:
    """Construct and return the validated Memex turn graph."""
    from memex.memory.answer_feedback import _phase_evaluate_prior_answer_feedback
    from memex.phase_graph.nodes.classify import (
        _phase_classify,
        _phase_load_context,
        _phase_middleware_classify,
    )
    from memex.phase_graph.nodes.fallbacks import (
        classify_default,
        log_save_failure,
        reflect_fallback,
        reflect_only,
        respond_error,
        tool_loop_fallback,
    )
    from memex.phase_graph.nodes.gather import (
        _phase_fact_store,
        _phase_filter_goals,
        _phase_proactive,
        _phase_retrieve,
        _phase_select_tools,
    )
    from memex.phase_graph.nodes.intent import _phase_early_exit, _phase_intent_frame
    from memex.phase_graph.nodes.persist import (
        _phase_return_response,
        _phase_save_session,
        _phase_window_history,
    )
    from memex.phase_graph.nodes.post_response import (
        _phase_apply_extraction,
        _phase_apply_reflect,
        _phase_extract_reflect,
        _phase_proactive_check,
    )
    from memex.phase_graph.nodes.prompt import _phase_build_prompt, _phase_record_human
    from memex.phase_graph.nodes.respond import _phase_llm_respond
    from memex.phase_graph.nodes.tool_loop import _phase_tool_loop

    # -- Nodes -----------------------------------------------------------------

    nodes = [
        PhaseNode(
            name=LOAD_CONTEXT,
            execute=_phase_load_context,
            inputs=frozenset({"store"}),
            outputs=frozenset(
                {
                    "governance",
                    "partner_prompt",
                    "agent_self_prompt",
                    "agent_self_model",
                    "all_goals",
                    "active_goals",
                    "turn_start",
                    "phase_timings_ms",
                    "prompt_metrics",
                    "turn_ordinal",
                    "tool_call_count",
                    "executed_tool_names",
                    "tool_failures",
                }
            ),
        ),
        PhaseNode(
            name=EVALUATE_PRIOR_ANSWER_FEEDBACK,
            execute=_phase_evaluate_prior_answer_feedback,
            inputs=frozenset({"store", "session", "user_input", "turn_ordinal"}),
            outputs=frozenset({"prior_answer_feedback_summary"}),
        ),
        # NOTE: classify_input() internally catches all exceptions and returns
        # CONVERSATIONAL. The retry and CLASSIFY_DEFAULT fallback serve as
        # defense-in-depth for non-LLM failures (e.g., filter_goals, plan snapshot).
        PhaseNode(
            name=CLASSIFY,
            execute=_phase_classify,
            inputs=frozenset({"session", "user_input", "all_goals", "active_goals"}),
            outputs=frozenset({"classification", "prompt_control_plan_snapshot"}),
            retry=RetryPolicy(
                max_attempts=2, backoff_base=1.0, retryable=_is_llm_error
            ),
            checkpoint=True,
        ),
        PhaseNode(
            name=MIDDLEWARE_CLASSIFY,
            execute=_phase_middleware_classify,
            inputs=frozenset({"session", "classification"}),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=INTENT_FRAME,
            execute=_phase_intent_frame,
            inputs=frozenset(
                {
                    "user_input",
                    "session",
                    "classification",
                    "active_goals",
                    "agent_self_model",
                    "turn_ordinal",
                }
            ),
            outputs=frozenset(
                {
                    "intent_frame",
                    "selected_action_candidate",
                    "intent_id",
                }
            ),
        ),
        PhaseNode(
            name=EARLY_EXIT,
            execute=_phase_early_exit,
            inputs=frozenset(
                {
                    "user_input",
                    "session",
                    "store",
                    "classification",
                    "intent_frame",
                    "intent_id",
                    "turn_ordinal",
                    "selected_action_candidate",
                }
            ),
            outputs=frozenset(
                {
                    "response",
                    "early_exit_response",
                    "turn_usage",
                    "tool_calls",
                    "tool_call_count",
                    "executed_tool_names",
                }
            ),
        ),
        PhaseNode(
            name=FILTER_GOALS,
            execute=_phase_filter_goals,
            inputs=frozenset(
                {
                    "store",
                    "classification",
                    "intent_frame",
                    "all_goals",
                    "active_goals",
                }
            ),
            outputs=frozenset({"relevant_goals", "prompt_control_plan_snapshot"}),
        ),
        PhaseNode(
            name=SELECT_TOOLS,
            execute=_phase_select_tools,
            inputs=frozenset(
                {
                    "store",
                    "session",
                    "user_input",
                    "classification",
                    "intent_frame",
                    "agent_self_model",
                    "selected_action_candidate",
                    "active_goals",
                    "turn_ordinal",
                    "intent_id",
                }
            ),
            outputs=frozenset({"available_tools", "granted_capabilities"}),
        ),
        PhaseNode(
            name=RETRIEVE,
            execute=_phase_retrieve,
            inputs=frozenset(
                {
                    "user_input",
                    "session",
                    "store",
                }
            ),
            outputs=frozenset({"retrieved_knowledge", "retrieved_document_ids"}),
            retry=RetryPolicy(max_attempts=2, backoff_base=1.0, retryable=_is_timeout),
        ),
        PhaseNode(
            name=SKIP_RETRIEVE,
            execute=_set_retrieval_defaults,
            inputs=frozenset(),
            outputs=frozenset(
                {
                    "retrieved_knowledge",
                    "retrieved_document_ids",
                    "proactive_context",
                }
            ),
        ),
        PhaseNode(
            name=PROACTIVE_CONTEXT,
            execute=_phase_proactive,
            inputs=frozenset(
                {
                    "user_input",
                    "classification",
                    "active_goals",
                    "retrieved_document_ids",
                }
            ),
            outputs=frozenset({"proactive_context"}),
        ),
        PhaseNode(
            name=FACT_STORE,
            execute=_phase_fact_store,
            inputs=frozenset(),
            outputs=frozenset(
                {
                    "fact_store",
                    "memory_block_text",
                    "documentation_text",
                }
            ),
        ),
        # Join barrier node (noop)
        PhaseNode(
            name=_GATHER_JOIN,
            execute=_noop,
            inputs=frozenset(),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=BUILD_PROMPT,
            execute=_phase_build_prompt,
            inputs=frozenset(
                {
                    "user_input",
                    "session",
                    "store",
                    "relevant_goals",
                    "retrieved_knowledge",
                    "memory_block_text",
                    "documentation_text",
                    "proactive_context",
                    "available_tools",
                    "governance",
                    "partner_prompt",
                    "agent_self_prompt",
                }
            ),
            outputs=frozenset(
                {
                    "messages",
                    "openai_tools",
                    "budgeted_prompt",
                    "use_cache",
                    "builder",
                    "prompt_metrics",
                }
            ),
        ),
        PhaseNode(
            name=RECORD_HUMAN_TURN,
            execute=_phase_record_human,
            inputs=frozenset({"user_input", "session", "classification", "store"}),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=LLM_RESPOND,
            execute=_phase_llm_respond,
            inputs=frozenset({"messages", "session"}),
            outputs=frozenset(
                {
                    "response",
                    "tool_calls",
                    "turn_usage",
                    "tool_call_count",
                    "tool_execution_ms",
                }
            ),
            retry=RetryPolicy(
                max_attempts=3, backoff_base=2.0, retryable=_is_network_error
            ),
            checkpoint=True,
        ),
        PhaseNode(
            name=TOOL_LOOP,
            execute=_phase_tool_loop,
            inputs=frozenset(
                {
                    "tool_calls",
                    "messages",
                    "session",
                    "store",
                }
            ),
            outputs=frozenset(
                {
                    "response",
                    "tool_calls",
                    "turn_usage",
                    "tool_call_count",
                    "executed_tool_names",
                    "tool_failures",
                    "tool_execution_ms",
                }
            ),
            checkpoint=True,
        ),
        PhaseNode(
            name=WINDOW_HISTORY,
            execute=_phase_window_history,
            inputs=frozenset({"response", "session", "store", "user_input"}),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=RETURN_RESPONSE,
            execute=_phase_return_response,
            inputs=frozenset({"session", "response"}),
            outputs=frozenset({"_pending_answer_observation"}),
        ),
        PhaseNode(
            name=EXTRACT_REFLECT,
            execute=_phase_extract_reflect,
            inputs=frozenset(
                {
                    "user_input",
                    "response",
                    "classification",
                    "session",
                    "store",
                }
            ),
            outputs=frozenset({"extraction_result", "reflect_result"}),
            retry=RetryPolicy(
                max_attempts=2, backoff_base=1.0, retryable=_is_llm_error
            ),
        ),
        # Barrier gate: extraction is applied inline in _phase_extract_reflect.
        # This node exists solely as a conditional input to _POST_JOIN.
        PhaseNode(
            name=APPLY_EXTRACTION,
            execute=_phase_apply_extraction,
            inputs=frozenset({"extraction_result"}),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=APPLY_REFLECT,
            execute=_phase_apply_reflect,
            inputs=frozenset({"reflect_result", "store", "session"}),
            outputs=frozenset(),
        ),
        # Post join barrier node (noop)
        PhaseNode(
            name=_POST_JOIN,
            execute=_noop,
            inputs=frozenset(),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=PROACTIVE_CHECK,
            execute=_phase_proactive_check,
            inputs=frozenset({"session", "store"}),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=SAVE_SESSION,
            execute=_phase_save_session,
            inputs=frozenset(
                {
                    "session",
                    "store",
                    "turn_ordinal",
                    "selected_action_candidate",
                    "intent_frame",
                    "intent_id",
                    "classification",
                }
            ),
            outputs=frozenset(),
            retry=RetryPolicy(max_attempts=3, backoff_base=1.0, retryable=_is_io_error),
            checkpoint=True,
        ),
        # -- Fallback nodes -------------------------------------------------------
        PhaseNode(
            name=CLASSIFY_DEFAULT,
            execute=classify_default,
            inputs=frozenset(),
            outputs=frozenset({"classification"}),
        ),
        PhaseNode(
            name=RETRIEVE_FALLBACK,
            execute=_set_retrieval_defaults,
            inputs=frozenset(),
            outputs=frozenset(
                {
                    "retrieved_knowledge",
                    "retrieved_document_ids",
                    "proactive_context",
                }
            ),
        ),
        PhaseNode(
            name=RETURN_ERROR,
            execute=respond_error,
            inputs=frozenset(),
            outputs=frozenset({"response", "tool_calls"}),
        ),
        PhaseNode(
            name=REFLECT_ONLY,
            execute=reflect_only,
            inputs=frozenset({"classification", "response", "session"}),
            outputs=frozenset({"reflect_result", "extraction_result"}),
        ),
        PhaseNode(
            name=REFLECT_FALLBACK,
            execute=reflect_fallback,
            inputs=frozenset(),
            outputs=frozenset({"reflect_result"}),
        ),
        PhaseNode(
            name=LOG_SAVE_FAILURE,
            execute=log_save_failure,
            inputs=frozenset(),
            outputs=frozenset(),
        ),
        PhaseNode(
            name=TOOL_LOOP_FALLBACK,
            execute=tool_loop_fallback,
            inputs=frozenset(),
            outputs=frozenset({"response", "tool_calls"}),
        ),
    ]

    # -- Edges -----------------------------------------------------------------

    edges = [
        # Linear: LOAD_CONTEXT -> EVALUATE_PRIOR_ANSWER_FEEDBACK -> CLASSIFY -> MIDDLEWARE_CLASSIFY -> INTENT_FRAME
        PhaseEdge(source=LOAD_CONTEXT, target=EVALUATE_PRIOR_ANSWER_FEEDBACK),
        PhaseEdge(source=EVALUATE_PRIOR_ANSWER_FEEDBACK, target=CLASSIFY),
        PhaseEdge(source=CLASSIFY, target=MIDDLEWARE_CLASSIFY),
        PhaseEdge(source=MIDDLEWARE_CLASSIFY, target=INTENT_FRAME),
        # Branch: INTENT_FRAME -> EARLY_EXIT or FILTER_GOALS
        PhaseEdge(
            source=INTENT_FRAME,
            target=EARLY_EXIT,
            condition=_is_early_exit,
            label="early-exit",
        ),
        PhaseEdge(
            source=INTENT_FRAME,
            target=FILTER_GOALS,
            condition=_is_normal_path,
            label="normal-path",
        ),
        # EARLY_EXIT -> WINDOW_HISTORY
        PhaseEdge(source=EARLY_EXIT, target=WINDOW_HISTORY, label="early-path"),
        # WINDOW_HISTORY -> RETURN_RESPONSE (unconditional: both normal and early-exit paths)
        PhaseEdge(
            source=WINDOW_HISTORY,
            target=RETURN_RESPONSE,
            label="normal-path",
        ),
        # Parallel gather: FILTER_GOALS -> SELECT_TOOLS, RETRIEVE/SKIP, FACT_STORE
        PhaseEdge(source=FILTER_GOALS, target=SELECT_TOOLS, parallel=True),
        PhaseEdge(
            source=FILTER_GOALS,
            target=RETRIEVE,
            condition=_should_retrieve,
            label="retrieve",
            parallel=True,
        ),
        PhaseEdge(
            source=FILTER_GOALS,
            target=SKIP_RETRIEVE,
            condition=_should_skip_retrieve,
            label="skip-retrieve",
            parallel=True,
        ),
        PhaseEdge(source=FILTER_GOALS, target=FACT_STORE, parallel=True),
        # Gather convergence
        PhaseEdge(source=SELECT_TOOLS, target=_GATHER_JOIN),
        PhaseEdge(source=RETRIEVE, target=PROACTIVE_CONTEXT),
        PhaseEdge(source=PROACTIVE_CONTEXT, target=_GATHER_JOIN),
        PhaseEdge(source=SKIP_RETRIEVE, target=_GATHER_JOIN),
        PhaseEdge(source=FACT_STORE, target=_GATHER_JOIN),
        # After gather
        PhaseEdge(source=_GATHER_JOIN, target=BUILD_PROMPT, label="barrier"),
        PhaseEdge(source=BUILD_PROMPT, target=RECORD_HUMAN_TURN),
        PhaseEdge(source=RECORD_HUMAN_TURN, target=LLM_RESPOND),
        # LLM -> TOOL_LOOP or WINDOW_HISTORY
        PhaseEdge(
            source=LLM_RESPOND,
            target=TOOL_LOOP,
            condition=_has_tool_calls,
            label="has-tools",
        ),
        PhaseEdge(
            source=LLM_RESPOND,
            target=WINDOW_HISTORY,
            condition=_no_tool_calls,
            label="no-tools",
        ),
        PhaseEdge(source=TOOL_LOOP, target=WINDOW_HISTORY),
        # Post-response background work
        PhaseEdge(
            source=RETURN_RESPONSE,
            target=SAVE_SESSION,
            condition=_is_early_save,
            label="early-save",
        ),
        PhaseEdge(
            source=RETURN_RESPONSE,
            target=EXTRACT_REFLECT,
            condition=_is_normal_return,
            label="bg-boundary",
        ),
        PhaseEdge(
            source=EXTRACT_REFLECT,
            target=APPLY_EXTRACTION,
            condition=_has_extraction,
        ),
        PhaseEdge(source=EXTRACT_REFLECT, target=APPLY_REFLECT),
        PhaseEdge(source=APPLY_EXTRACTION, target=_POST_JOIN),
        PhaseEdge(source=APPLY_REFLECT, target=_POST_JOIN),
        PhaseEdge(source=_POST_JOIN, target=PROACTIVE_CHECK, label="barrier"),
        PhaseEdge(source=PROACTIVE_CHECK, target=SAVE_SESSION),
        # Fallback continuation edges
        PhaseEdge(source=CLASSIFY_DEFAULT, target=MIDDLEWARE_CLASSIFY),
        PhaseEdge(source=RETRIEVE_FALLBACK, target=_GATHER_JOIN),
        PhaseEdge(source=RETURN_ERROR, target=WINDOW_HISTORY),
        PhaseEdge(source=REFLECT_ONLY, target=APPLY_REFLECT),
        PhaseEdge(source=REFLECT_FALLBACK, target=APPLY_REFLECT),
        PhaseEdge(source=TOOL_LOOP_FALLBACK, target=WINDOW_HISTORY),
        # LOG_SAVE_FAILURE has no continuation — terminal
    ]

    # -- Fallback edges --------------------------------------------------------

    fallbacks = [
        FallbackEdge(
            source=CLASSIFY, target=CLASSIFY_DEFAULT, label="default to CONVERSATIONAL"
        ),
        FallbackEdge(
            source=RETRIEVE, target=RETRIEVE_FALLBACK, label="skip retrieval+proactive"
        ),
        FallbackEdge(
            source=LLM_RESPOND, target=RETURN_ERROR, label="return error to user"
        ),
        FallbackEdge(
            source=EXTRACT_REFLECT,
            target=REFLECT_ONLY,
            label="reflect without extraction",
        ),
        FallbackEdge(
            source=REFLECT_ONLY,
            target=REFLECT_FALLBACK,
            label="reflection failed entirely",
        ),
        FallbackEdge(
            source=TOOL_LOOP,
            target=TOOL_LOOP_FALLBACK,
            label="return partial response",
        ),
        FallbackEdge(
            source=SAVE_SESSION,
            target=LOG_SAVE_FAILURE,
            label="log error, do not crash",
        ),
    ]

    # -- Join barriers ---------------------------------------------------------

    barriers = [
        JoinBarrier(
            name=_GATHER_JOIN,
            incoming=frozenset(
                {
                    SELECT_TOOLS,
                    PROACTIVE_CONTEXT,
                    SKIP_RETRIEVE,
                    FACT_STORE,
                }
            ),
        ),
        JoinBarrier(
            name=_POST_JOIN,
            incoming=frozenset({APPLY_EXTRACTION, APPLY_REFLECT}),
        ),
    ]

    # -- Exclusive output pairs ------------------------------------------------
    # Nodes that write the same keys but are on mutually exclusive paths.

    exclusive_output_pairs: set[frozenset[str]] = {
        frozenset({EARLY_EXIT, LLM_RESPOND}),
        frozenset({EARLY_EXIT, TOOL_LOOP}),
        frozenset({EARLY_EXIT, RETURN_ERROR}),
        frozenset({EARLY_EXIT, LOAD_CONTEXT}),
        frozenset({RETRIEVE, SKIP_RETRIEVE}),
        frozenset({RETRIEVE, RETRIEVE_FALLBACK}),
        frozenset({SKIP_RETRIEVE, RETRIEVE_FALLBACK}),
        frozenset({PROACTIVE_CONTEXT, SKIP_RETRIEVE}),
        frozenset({PROACTIVE_CONTEXT, RETRIEVE_FALLBACK}),
        frozenset({CLASSIFY, CLASSIFY_DEFAULT}),
        frozenset({LLM_RESPOND, TOOL_LOOP}),
        frozenset({LLM_RESPOND, RETURN_ERROR}),
        frozenset({TOOL_LOOP, RETURN_ERROR}),
        frozenset({EXTRACT_REFLECT, REFLECT_ONLY}),
        frozenset({EXTRACT_REFLECT, REFLECT_FALLBACK}),
        frozenset({REFLECT_ONLY, REFLECT_FALLBACK}),
        frozenset({LOAD_CONTEXT, TOOL_LOOP}),
        frozenset({LOAD_CONTEXT, LLM_RESPOND}),
        frozenset({LOAD_CONTEXT, RETURN_ERROR}),
        frozenset({CLASSIFY, FILTER_GOALS}),
        frozenset({CLASSIFY_DEFAULT, FILTER_GOALS}),
        frozenset({BUILD_PROMPT, LOAD_CONTEXT}),
        frozenset({EARLY_EXIT, TOOL_LOOP_FALLBACK}),
        frozenset({LLM_RESPOND, TOOL_LOOP_FALLBACK}),
        frozenset({TOOL_LOOP, TOOL_LOOP_FALLBACK}),
        frozenset({RETURN_ERROR, TOOL_LOOP_FALLBACK}),
    }

    return PhaseGraph(
        nodes=tuple(nodes),
        edges=tuple(edges),
        fallback_edges=tuple(fallbacks),
        join_barriers=tuple(barriers),
        entry_node=LOAD_CONTEXT,
        exclusive_output_pairs=frozenset(exclusive_output_pairs),
    )
