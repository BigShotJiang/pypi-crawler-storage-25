"""Memex-specific PhaseGraph topology validator.

Validates that a PhaseGraph conforms to the Memex turn graph specification
defined in the design doc (path-to-phasegraph-memex-2026-04-07.md).

This is a conformance check, not a structural check -- it verifies the
specific nodes, edges, retry policies, and barriers that the Memex
design requires, beyond the generic graph validation.
"""

from __future__ import annotations

import logging

from memex.phase_graph.graph import PhaseGraph, _always_false

logger = logging.getLogger(__name__)


class SMPValidationError(Exception):
    """Raised when the graph does not conform to the Memex PhaseGraph spec."""


# ---------------------------------------------------------------------------
# Spec constants
# ---------------------------------------------------------------------------

REQUIRED_NODES: frozenset[str] = frozenset(
    {
        "LOAD_CONTEXT",
        "EVALUATE_PRIOR_ANSWER_FEEDBACK",
        "CLASSIFY",
        "MIDDLEWARE_CLASSIFY",
        "INTENT_FRAME",
        "EARLY_EXIT",
        "FILTER_GOALS",
        "SELECT_TOOLS",
        "RETRIEVE",
        "SKIP_RETRIEVE",
        "PROACTIVE_CONTEXT",
        "FACT_STORE",
        "BUILD_PROMPT",
        "RECORD_HUMAN_TURN",
        "LLM_RESPOND",
        "TOOL_LOOP",
        "WINDOW_HISTORY",
        "RETURN_RESPONSE",
        "EXTRACT_REFLECT",
        "APPLY_EXTRACTION",
        "APPLY_REFLECT",
        "PROACTIVE_CHECK",
        "SAVE_SESSION",
        # Fallback nodes
        "CLASSIFY_DEFAULT",
        "RETRIEVE_FALLBACK",
        "RETURN_ERROR",
        "REFLECT_ONLY",
        "REFLECT_FALLBACK",
        "LOG_SAVE_FAILURE",
        "TOOL_LOOP_FALLBACK",
    }
)

REQUIRED_EDGES: list[tuple[str, str]] = [
    ("LOAD_CONTEXT", "EVALUATE_PRIOR_ANSWER_FEEDBACK"),
    ("EVALUATE_PRIOR_ANSWER_FEEDBACK", "CLASSIFY"),
    ("CLASSIFY", "MIDDLEWARE_CLASSIFY"),
    ("MIDDLEWARE_CLASSIFY", "INTENT_FRAME"),
    ("INTENT_FRAME", "EARLY_EXIT"),
    ("INTENT_FRAME", "FILTER_GOALS"),
    ("EARLY_EXIT", "WINDOW_HISTORY"),
    ("FILTER_GOALS", "SELECT_TOOLS"),
    ("FILTER_GOALS", "RETRIEVE"),
    ("FILTER_GOALS", "SKIP_RETRIEVE"),
    ("FILTER_GOALS", "FACT_STORE"),
    ("SELECT_TOOLS", "_GATHER_JOIN"),
    ("RETRIEVE", "PROACTIVE_CONTEXT"),
    ("PROACTIVE_CONTEXT", "_GATHER_JOIN"),
    ("SKIP_RETRIEVE", "_GATHER_JOIN"),
    ("FACT_STORE", "_GATHER_JOIN"),
    ("_GATHER_JOIN", "BUILD_PROMPT"),
    ("BUILD_PROMPT", "RECORD_HUMAN_TURN"),
    ("RECORD_HUMAN_TURN", "LLM_RESPOND"),
    ("LLM_RESPOND", "TOOL_LOOP"),
    ("LLM_RESPOND", "WINDOW_HISTORY"),
    ("TOOL_LOOP", "WINDOW_HISTORY"),
    ("WINDOW_HISTORY", "RETURN_RESPONSE"),
    ("RETURN_RESPONSE", "SAVE_SESSION"),
    ("RETURN_RESPONSE", "EXTRACT_REFLECT"),
    ("EXTRACT_REFLECT", "APPLY_EXTRACTION"),
    ("EXTRACT_REFLECT", "APPLY_REFLECT"),
    ("APPLY_EXTRACTION", "_POST_JOIN"),
    ("APPLY_REFLECT", "_POST_JOIN"),
    ("_POST_JOIN", "PROACTIVE_CHECK"),
    ("PROACTIVE_CHECK", "SAVE_SESSION"),
    # Fallback continuation edges
    ("CLASSIFY_DEFAULT", "MIDDLEWARE_CLASSIFY"),
    ("RETRIEVE_FALLBACK", "_GATHER_JOIN"),
    ("RETURN_ERROR", "WINDOW_HISTORY"),
    ("REFLECT_ONLY", "APPLY_REFLECT"),
    ("REFLECT_FALLBACK", "APPLY_REFLECT"),
    ("TOOL_LOOP_FALLBACK", "WINDOW_HISTORY"),
]

REQUIRED_FALLBACKS: list[tuple[str, str]] = [
    ("CLASSIFY", "CLASSIFY_DEFAULT"),
    ("RETRIEVE", "RETRIEVE_FALLBACK"),
    ("LLM_RESPOND", "RETURN_ERROR"),
    ("EXTRACT_REFLECT", "REFLECT_ONLY"),
    ("REFLECT_ONLY", "REFLECT_FALLBACK"),
    ("SAVE_SESSION", "LOG_SAVE_FAILURE"),
    ("TOOL_LOOP", "TOOL_LOOP_FALLBACK"),
]

EXPECTED_JOIN_BARRIERS: dict[str, frozenset[str]] = {
    "_GATHER_JOIN": frozenset(
        {"SELECT_TOOLS", "PROACTIVE_CONTEXT", "SKIP_RETRIEVE", "FACT_STORE"}
    ),
    "_POST_JOIN": frozenset({"APPLY_EXTRACTION", "APPLY_REFLECT"}),
}

# Critical path: happy path from LOAD_CONTEXT to SAVE_SESSION (no early exit,
# retrieval enabled, no tool calls, extraction present).
CRITICAL_PATH: list[str] = [
    "LOAD_CONTEXT",
    "EVALUATE_PRIOR_ANSWER_FEEDBACK",
    "CLASSIFY",
    "MIDDLEWARE_CLASSIFY",
    "INTENT_FRAME",
    "FILTER_GOALS",
    "SELECT_TOOLS",
    "_GATHER_JOIN",
    "BUILD_PROMPT",
    "RECORD_HUMAN_TURN",
    "LLM_RESPOND",
    "WINDOW_HISTORY",
    "RETURN_RESPONSE",
    "EXTRACT_REFLECT",
    "APPLY_REFLECT",
    "_POST_JOIN",
    "PROACTIVE_CHECK",
    "SAVE_SESSION",
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def validate_memex_turn_graph(graph: PhaseGraph) -> list[str]:
    """Validate graph against the Memex turn graph specification.

    Returns a list of warnings/violations. Raises SMPValidationError
    if critical violations found.
    """
    warnings: list[str] = []
    errors: list[str] = []

    _check_required_nodes(graph, errors, warnings)
    _check_required_edges(graph, errors, warnings)
    _check_required_fallbacks(graph, errors, warnings)
    _check_join_barriers(graph, errors, warnings)
    _check_retry_policies(graph, errors, warnings)
    _check_critical_path(graph, errors, warnings)

    if errors:
        raise SMPValidationError(
            f"Memex PhaseGraph spec violations ({len(errors)}):\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return warnings


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def _check_required_nodes(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    present = graph.node_names | graph.barrier_names
    missing = REQUIRED_NODES - present
    extra = present - REQUIRED_NODES - {"_GATHER_JOIN", "_POST_JOIN"}
    for name in sorted(missing):
        errors.append(f"missing required node: {name}")
    for name in sorted(extra):
        warnings.append(f"extra node not in spec: {name}")


def _check_required_edges(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    edge_set = {(e.source, e.target) for e in graph.edges}
    for source, target in REQUIRED_EDGES:
        if (source, target) not in edge_set:
            errors.append(f"missing required edge: {source} -> {target}")


def _check_required_fallbacks(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    fallback_set = {(f.source, f.target) for f in graph.fallback_edges}
    for source, target in REQUIRED_FALLBACKS:
        if (source, target) not in fallback_set:
            errors.append(f"missing required fallback: {source} -> {target}")


def _check_join_barriers(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    barrier_map = {jb.name: jb for jb in graph.join_barriers}
    for name, expected_incoming in EXPECTED_JOIN_BARRIERS.items():
        if name not in barrier_map:
            errors.append(f"missing join barrier: {name}")
            continue
        actual_incoming = barrier_map[name].incoming
        if actual_incoming != expected_incoming:
            missing = expected_incoming - actual_incoming
            extra = actual_incoming - expected_incoming
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if extra:
                parts.append(f"extra: {sorted(extra)}")
            errors.append(f"join barrier {name} incoming mismatch: {', '.join(parts)}")


def _check_retry_policies(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    node_map = {n.name: n for n in graph.nodes}

    # LLM_RESPOND must have max_attempts >= 2
    if "LLM_RESPOND" in node_map:
        node = node_map["LLM_RESPOND"]
        if node.retry.max_attempts < 2:
            errors.append(
                "LLM_RESPOND must have retry max_attempts >= 2, "
                f"got {node.retry.max_attempts}"
            )
        if node.retry.retryable is _always_false:
            warnings.append("LLM_RESPOND retry uses default _always_false predicate")

    # CLASSIFY should have retry
    if "CLASSIFY" in node_map:
        node = node_map["CLASSIFY"]
        if node.retry.max_attempts < 2:
            warnings.append(
                "CLASSIFY should have retry max_attempts >= 2, "
                f"got {node.retry.max_attempts}"
            )

    # SAVE_SESSION should have retry
    if "SAVE_SESSION" in node_map:
        node = node_map["SAVE_SESSION"]
        if node.retry.max_attempts < 2:
            warnings.append(
                "SAVE_SESSION should have retry max_attempts >= 2, "
                f"got {node.retry.max_attempts}"
            )


def _check_critical_path(
    graph: PhaseGraph, errors: list[str], warnings: list[str]
) -> None:
    edge_set = {(e.source, e.target) for e in graph.edges}
    for i in range(len(CRITICAL_PATH) - 1):
        src = CRITICAL_PATH[i]
        tgt = CRITICAL_PATH[i + 1]
        if (src, tgt) not in edge_set:
            errors.append(f"critical path broken: no edge {src} -> {tgt}")
