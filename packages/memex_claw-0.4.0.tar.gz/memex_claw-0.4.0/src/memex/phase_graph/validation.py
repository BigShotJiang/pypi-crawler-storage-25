"""Static validation checks for PhaseGraph definitions."""

from __future__ import annotations

import logging
from collections import defaultdict

from memex.phase_graph.context import INITIAL_CONTEXT_KEYS

logger = logging.getLogger(__name__)


def validate_graph(graph) -> None:  # noqa: ANN001
    """Run all static validation checks on a PhaseGraph."""
    from memex.phase_graph.graph import GraphDefinitionError

    errors: list[str] = []

    _check_reachability(graph, errors)
    _check_input_satisfaction(graph, errors)
    _check_output_conflicts(graph, errors)
    _check_join_completeness(graph, errors)
    _check_fallback_coverage(graph, errors)
    _check_cycles(graph, errors)

    if errors:
        raise GraphDefinitionError(
            f"Graph validation failed with {len(errors)} error(s):\n"
            + "\n".join(f"  - {e}" for e in errors)
        )


def _build_adjacency(graph) -> dict[str, set[str]]:  # noqa: ANN001
    """Build adjacency list from edges, treating barriers as pass-through."""
    adj: dict[str, set[str]] = defaultdict(set)

    for edge in graph.edges:
        adj[edge.source].add(edge.target)

    for fb in graph.fallback_edges:
        adj[fb.source].add(fb.target)

    # Barriers are pass-through: if an edge targets a barrier,
    # and another edge sources from that barrier, the barrier
    # connects them.  The adjacency already handles this because
    # edges with source=barrier_name are in the edge list.

    return adj


def _check_reachability(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 1: every node reachable from entry_node."""
    adj = _build_adjacency(graph)
    node_names = graph.node_names

    visited: set[str] = set()
    stack = [graph.entry_node]

    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        for target in adj.get(current, set()):
            stack.append(target)

    # Only check node names (barriers are not nodes)
    unreachable = node_names - visited
    if unreachable:
        errors.append(
            f"Unreachable nodes from entry '{graph.entry_node}': {sorted(unreachable)}"
        )


def _check_input_satisfaction(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 2: every node input is satisfiable."""
    adj = _build_adjacency(graph)
    node_map = {n.name: n for n in graph.nodes}

    # Build reverse adjacency (predecessors)
    rev_adj: dict[str, set[str]] = defaultdict(set)
    for src, targets in adj.items():
        for tgt in targets:
            rev_adj[tgt].add(src)

    for node in graph.nodes:
        if not node.inputs:
            continue

        # Collect all outputs from ALL transitive predecessors
        predecessor_outputs: set[str] = set()
        visited: set[str] = set()
        stack = list(rev_adj.get(node.name, set()))

        while stack:
            pred = stack.pop()
            if pred in visited:
                continue
            visited.add(pred)
            if pred in node_map:
                predecessor_outputs.update(node_map[pred].outputs)
            # Always walk further back through all predecessors
            stack.extend(rev_adj.get(pred, set()) - visited)

        unsatisfied = node.inputs - INITIAL_CONTEXT_KEYS - predecessor_outputs
        if unsatisfied:
            errors.append(
                f"Node '{node.name}' has unsatisfied inputs: {sorted(unsatisfied)}"
            )


def _check_output_conflicts(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 3: no two nodes share an output key unless in exclusive_output_pairs."""
    # Map output key -> list of nodes that produce it
    output_producers: dict[str, list[str]] = defaultdict(list)
    for node in graph.nodes:
        for key in node.outputs:
            output_producers[key].append(node.name)

    for key, producers in output_producers.items():
        if len(producers) < 2:
            continue
        # Check all pairs
        for i in range(len(producers)):
            for j in range(i + 1, len(producers)):
                pair = frozenset({producers[i], producers[j]})
                if pair not in graph.exclusive_output_pairs:
                    errors.append(
                        f"Output conflict: nodes {sorted(pair)} both produce "
                        f"'{key}' but are not in exclusive_output_pairs"
                    )


def _check_join_completeness(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 4: join barrier incoming sets match actual edges."""
    node_names = graph.node_names

    # Build map: barrier_name -> set of nodes that have edges targeting it
    edges_to_barrier: dict[str, set[str]] = defaultdict(set)
    for edge in graph.edges:
        if edge.target in graph.barrier_names:
            edges_to_barrier[edge.target].add(edge.source)

    for barrier in graph.join_barriers:
        # incoming must be subset of node names
        unknown = barrier.incoming - node_names
        if unknown:
            errors.append(
                f"JoinBarrier '{barrier.name}' references unknown nodes: "
                f"{sorted(unknown)}"
            )

        # Every node in incoming must have an edge to the barrier
        actual_sources = edges_to_barrier.get(barrier.name, set())
        missing = barrier.incoming - actual_sources
        if missing:
            errors.append(
                f"JoinBarrier '{barrier.name}' expects edges from "
                f"{sorted(missing)} but none exist"
            )


def _check_fallback_coverage(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 5: fallback edges reference existing nodes."""
    node_names = graph.node_names

    # Build outgoing edge set for each node
    outgoing: dict[str, int] = defaultdict(int)
    for edge in graph.edges:
        outgoing[edge.source] += 1

    for fb in graph.fallback_edges:
        if fb.source not in node_names:
            errors.append(f"FallbackEdge source '{fb.source}' is not a known node")
        if fb.target not in node_names:
            errors.append(f"FallbackEdge target '{fb.target}' is not a known node")


def _check_cycles(graph, errors: list[str]) -> None:  # noqa: ANN001
    """Check 6: the main graph (regular edges) must be a DAG."""
    # Build adjacency from regular edges only, treating barriers as pass-through
    adj: dict[str, set[str]] = defaultdict(set)
    for edge in graph.edges:
        adj[edge.source].add(edge.target)

    # All names that participate in the graph (nodes + barriers)
    all_names = graph.node_names | graph.barrier_names

    # DFS-based cycle detection
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = {name: WHITE for name in all_names}

    def dfs(node: str) -> bool:
        color[node] = GRAY
        for neighbor in adj.get(node, set()):
            if neighbor not in color:
                continue
            if color[neighbor] == GRAY:
                return True  # cycle found
            if color[neighbor] == WHITE and dfs(neighbor):
                return True
        color[node] = BLACK
        return False

    for name in all_names:
        if color[name] == WHITE:
            if dfs(name):
                errors.append("Cycle detected in the main graph edges")
                return
