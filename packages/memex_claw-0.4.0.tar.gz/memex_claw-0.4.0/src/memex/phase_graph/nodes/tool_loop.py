from __future__ import annotations

import json
import logging
import time
from typing import Any

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)

MAX_TOOL_ITERATIONS = 8
MAX_TOOL_CALLS_PER_RESPONSE = 10


def _phase_tool_loop(ctx: TurnContext) -> None:
    """Execute the tool-use loop up to MAX_TOOL_ITERATIONS.

    WARNING: This node is NOT retry-safe. It mutates ctx["messages"] in place,
    calls add_turn() and _persist_world_model_tool_execution() with side effects.
    Do NOT add a RetryPolicy to the TOOL_LOOP PhaseNode in definition.py.
    """
    from memex.llm import TokenUsage, _get_response_model, chat_with_tools_streaming
    from memex.loop import (
        _emit,
        _execute_tool_call,
        _extract_world_model_refs,
        _persist_world_model_tool_execution,
        _signals_continuation,
        _tool_result_summary,
        _track_session_item,
    )
    from memex.models import ToolCallCompleted, ToolCallStarted, ToolResult
    from memex.session import add_turn

    session = ctx["session"]
    store = ctx["store"]
    messages = ctx["messages"]
    tool_calls = ctx.get("tool_calls", [])
    openai_tools = ctx.get("openai_tools", [])
    tool_registry = ctx.get("tool_registry")
    granted = ctx.get("granted_capabilities", set())
    connector_clients = ctx.get("connector_clients") or {}
    chain = ctx.get("middleware_chain")
    on_event = ctx.get("on_event")
    on_token = ctx.get("on_token")
    caller = ctx.get("caller")
    intent_frame = ctx["intent_frame"]
    intent_id = ctx["intent_id"]
    classification = ctx["classification"]
    turn_ordinal = ctx["turn_ordinal"]
    active_goals = ctx.get("active_goals", [])

    turn_usage = ctx.get("turn_usage", TokenUsage())
    tool_call_count = ctx.get("tool_call_count", 0)
    executed_tool_names = ctx.get("executed_tool_names", [])
    tool_failures = ctx.get("tool_failures", [])
    tool_execution_ms = ctx.get("tool_execution_ms", 0)
    tool_loop_stats: list[dict[str, Any]] = []
    turn_planning_refs: list[dict[str, str]] = []

    use_cache = ctx.get("use_cache", False)
    builder = ctx.get("builder")

    response = ctx.get("response", "")
    goal_titles = [g.title for g in active_goals]

    def _accumulate_usage(usage: TokenUsage) -> None:
        nonlocal turn_usage
        turn_usage = TokenUsage(
            prompt_tokens=turn_usage.prompt_tokens + usage.prompt_tokens,
            completion_tokens=turn_usage.completion_tokens + usage.completion_tokens,
            total_tokens=turn_usage.total_tokens + usage.total_tokens,
            cost_usd=turn_usage.cost_usd + usage.cost_usd,
        )

    for _iteration in range(MAX_TOOL_ITERATIONS):
        iteration_start = time.monotonic()
        iteration_tool_execution_ms = 0
        iteration_llm_ms = 0
        tool_names = [tc["name"] for tc in tool_calls] if tool_calls else []
        logger.debug(
            "tool-loop iteration=%d, tool_calls=%d, tool_names=%s, response_len=%d",
            _iteration,
            len(tool_calls) if tool_calls else 0,
            tool_names,
            len(response) if response else 0,
        )
        if not tool_calls:
            if response and _signals_continuation(response):
                logger.debug("continuation signal detected, re-prompting")
                messages.append({"role": "assistant", "content": response})
                if use_cache and builder is not None:
                    builder._history.append({"role": "assistant", "content": response})
                llm_start = time.monotonic()
                response, tool_calls, usage = chat_with_tools_streaming(
                    messages,
                    openai_tools,
                    model=_get_response_model(),
                    on_token=on_token,
                )
                iteration_llm_ms += int((time.monotonic() - llm_start) * 1000)
                _accumulate_usage(usage)
            if not tool_calls:
                iteration_total_ms = int((time.monotonic() - iteration_start) * 1000)
                iteration_stats = {
                    "iteration": _iteration,
                    "tool_names": tool_names,
                    "tool_calls": len(tool_names),
                    "tool_execution_ms": iteration_tool_execution_ms,
                    "llm_ms": iteration_llm_ms,
                    "total_ms": iteration_total_ms,
                    "next_tool_names": [],
                    "response_len": len(response) if response else 0,
                }
                tool_loop_stats.append(iteration_stats)
                logger.debug(
                    "tool-loop iteration=%d complete no_tool_calls total_ms=%d llm_ms=%d",
                    _iteration,
                    iteration_total_ms,
                    iteration_llm_ms,
                )
                logger.info("tool-loop iteration stats: %s", iteration_stats)
                break

        # Cap tool calls per response
        if len(tool_calls) > MAX_TOOL_CALLS_PER_RESPONSE:
            logger.warning(
                "LLM returned %d tool calls, capping at %d",
                len(tool_calls),
                MAX_TOOL_CALLS_PER_RESPONSE,
            )
            tool_calls = tool_calls[:MAX_TOOL_CALLS_PER_RESPONSE]

        # Execute tool calls
        tool_results: list[tuple[dict[str, Any], ToolResult]] = []
        for tc in tool_calls:
            tc_args = tc["arguments"]

            # Middleware before_tool_call
            blocked = False
            if chain is not None:
                try:
                    tc_args, blocked = chain.before_tool_call(
                        session, tc["name"], tc_args
                    )
                except Exception:
                    logger.debug("Middleware before_tool_call failed", exc_info=True)

            if blocked:
                result = ToolResult(
                    content="",
                    success=False,
                    error=f"Tool call '{tc['name']}' blocked by middleware",
                )
                _emit(
                    on_event,
                    ToolCallCompleted(
                        tc["name"], False, 0, summary="blocked by middleware"
                    ),
                )
            else:
                _emit(on_event, ToolCallStarted(tc["name"], tc_args))
                tc_start = time.monotonic()
                result = _execute_tool_call(
                    tc["name"],
                    tc_args,
                    tool_registry,
                    granted,
                    store,
                    connector_clients,
                    session_id=session.session_id,
                    caller=caller,
                )
                tc_elapsed = int((time.monotonic() - tc_start) * 1000)
                tool_execution_ms += tc_elapsed
                iteration_tool_execution_ms += tc_elapsed
                _emit(
                    on_event,
                    ToolCallCompleted(
                        tc["name"],
                        result.success,
                        tc_elapsed,
                        summary=_tool_result_summary(tc["name"], result, tc_args),
                    ),
                )

            # Record tool usage stats
            try:
                _ctx = ctx["user_input"]
                for _gt in goal_titles:
                    _ctx += " " + _gt
                matched_kws = tool_registry.get_matched_keywords(tc["name"], _ctx)
                store.record_tool_usage(tc["name"], matched_kws)
            except Exception:
                logger.debug("Failed to record tool usage", exc_info=True)

            tool_call_count += 1
            executed_tool_names.append(tc["name"])

            # Middleware after_tool_call
            if chain is not None:
                try:
                    chain.after_tool_call(session, tc["name"], tc_args, result)
                except Exception:
                    logger.debug("Middleware after_tool_call failed", exc_info=True)

            tool_results.append((tc, result))

            # Track session items
            if result.success and tc["name"] in ("ingest_url", "gmail_search"):
                _track_session_item(session, tc["name"], tc_args, result)

            # Persist world model tool execution
            try:
                _persist_world_model_tool_execution(
                    store,
                    session_id=session.session_id,
                    turn_ordinal=turn_ordinal,
                    intent_id=intent_id,
                    goal_id=intent_frame.goal_id or classification.goal_id,
                    prompt_control_artifact_id=(
                        session.last_prompt_control.artifact_id
                        if session.last_prompt_control is not None
                        else None
                    ),
                    tool_call_id=str(tc.get("id") or tc["name"]),
                    tool_name=tc["name"],
                    arguments=tc_args,
                    result=result,
                )
            except Exception:
                logger.debug(
                    "Failed to persist tool execution to world-model backbone",
                    exc_info=True,
                )
            turn_planning_refs.extend(_extract_world_model_refs(result))

            add_turn(
                session,
                "tool_result",
                f"[{tc['name']}] {result.content[:500]}",
                store=store,
            )

            if not result.success:
                tool_failures.append(f"{tc['name']}: {result.error}")

        # Build assistant message with tool calls
        messages.append(
            {
                "role": "assistant",
                "content": response or None,
                "tool_calls": [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": json.dumps(tc["arguments"]),
                        },
                    }
                    for tc in tool_calls
                ],
            }
        )

        # Tool result messages
        for tc, result in tool_results:
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": (
                        result.content if result.success else (result.error or "Error")
                    ),
                }
            )

        # Mirror into builder
        if use_cache and builder is not None:
            builder.append_tool_exchange(
                [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": json.dumps(tc["arguments"]),
                        },
                    }
                    for tc in tool_calls
                ],
                [
                    {
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": (
                            result.content
                            if result.success
                            else (result.error or "Error")
                        ),
                    }
                    for tc, result in tool_results
                ],
                response_text=response or None,
            )

        # Re-prompt LLM with tool results
        llm_start = time.monotonic()
        response, tool_calls, usage = chat_with_tools_streaming(
            messages,
            openai_tools,
            model=_get_response_model(),
            on_token=on_token,
        )
        iteration_llm_ms += int((time.monotonic() - llm_start) * 1000)
        _accumulate_usage(usage)

        # Middleware on_llm_output for tool loop
        if chain is not None:
            try:
                chain.on_llm_output(session, response, tool_calls or [])
            except Exception:
                logger.debug("Middleware on_llm_output failed", exc_info=True)

        iteration_total_ms = int((time.monotonic() - iteration_start) * 1000)
        next_tool_names = [tc["name"] for tc in tool_calls] if tool_calls else []
        iteration_stats = {
            "iteration": _iteration,
            "tool_names": tool_names,
            "tool_calls": len(tool_names),
            "tool_execution_ms": iteration_tool_execution_ms,
            "llm_ms": iteration_llm_ms,
            "total_ms": iteration_total_ms,
            "next_tool_names": next_tool_names,
            "response_len": len(response) if response else 0,
        }
        tool_loop_stats.append(iteration_stats)
        logger.info("tool-loop iteration stats: %s", iteration_stats)

    ctx["response"] = response
    ctx["tool_calls"] = tool_calls if tool_calls else []
    ctx["turn_usage"] = turn_usage
    ctx["tool_call_count"] = tool_call_count
    ctx["executed_tool_names"] = executed_tool_names
    ctx["tool_failures"] = tool_failures
    ctx["tool_execution_ms"] = tool_execution_ms
    ctx["tool_loop_stats"] = tool_loop_stats
    ctx["turn_planning_refs"] = turn_planning_refs
