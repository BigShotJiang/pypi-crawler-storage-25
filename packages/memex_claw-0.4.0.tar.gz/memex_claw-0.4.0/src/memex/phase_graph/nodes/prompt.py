from __future__ import annotations

import logging

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_build_prompt(ctx: TurnContext) -> None:
    """Build the full prompt including system prompt, history, and tools."""
    from memex.llm import _get_response_model
    from memex.loop import (
        _build_budgeted_prompt_context,
        _build_messages,
        _build_system_prompt,
        _builders,
        _builders_lock,
        _MAX_BUILDERS,
        _message_content_to_text,
        _messages_char_count,
        _render_session_items_context,
        _render_world_model_prompt_context,
        _use_message_builder,
    )
    from memex.message_builder import MessageBuilder
    from memex.prompt_control import render_prompt_control_section
    from memex.tools import to_openai_tools

    session = ctx["session"]
    store = ctx["store"]
    user_input = ctx["user_input"]
    relevant = ctx.get("relevant_goals", [])
    retrieved_knowledge = ctx.get("retrieved_knowledge", "")
    memory_block_text = ctx.get("memory_block_text", "")
    documentation_text = ctx.get("documentation_text", "")
    proactive_context = ctx.get("proactive_context", "")
    connector_health = ctx.get("connector_health")
    chain = ctx.get("middleware_chain")
    project_root = ctx.get("project_root")
    prompt_mode = ctx.get("prompt_mode")
    caller = ctx.get("caller")
    available_tools = ctx.get("available_tools", [])

    use_cache = _use_message_builder()
    builder = None

    prompt_control_section = render_prompt_control_section(session.last_prompt_control)
    world_model_section = _render_world_model_prompt_context(store, session.session_id)

    prompt_build_extra = ""
    if chain is not None:
        try:
            prompt_build_extra = chain.before_prompt_build(session, store)
        except Exception:
            logger.debug("Middleware before_prompt_build failed", exc_info=True)

    skill_block = ""
    if chain and hasattr(chain, "skill_middleware") and chain.skill_middleware:
        try:
            skill_block = (
                chain.skill_middleware.get_skill_block(
                    user_input=user_input,
                    active_goals=[g.title for g in relevant],
                )
                or ""
            )
        except Exception:
            logger.debug("Skill block generation failed", exc_info=True)

    budgeted_prompt = _build_budgeted_prompt_context(
        governance=ctx.get("governance"),
        partner_prompt=ctx.get("partner_prompt", ""),
        agent_self_prompt=ctx.get("agent_self_prompt", ""),
        goals=relevant,
        session_summary=session.conversation_summary,
        retrieved_knowledge=retrieved_knowledge,
        prompt_control_section=prompt_control_section,
        world_model_section=world_model_section,
        response_format=ctx.get("response_format"),
        session_mode=ctx.get("session_mode"),
        caller=caller,
        connector_health=connector_health,
        memory_block_text=memory_block_text,
        documentation_text=documentation_text,
        prompt_build_extra=prompt_build_extra,
        proactive_context=proactive_context,
        session_items_section=_render_session_items_context(session),
        skill_block=skill_block,
        project_root=project_root,
        prompt_mode=prompt_mode,
        settings=getattr(store, "settings", None),
    )

    if use_cache:
        sid = session.session_id
        with _builders_lock:
            builder = _builders.get(sid)
        if builder is None or builder._model != _get_response_model():
            builder = MessageBuilder(_get_response_model())
            history = session.conversation_history
            i = 0
            while i < len(history) - 1:
                if history[i].role == "human" and history[i + 1].role == "assistant":
                    builder.append_turn(history[i].content, history[i + 1].content)
                    i += 2
                else:
                    i += 1
            builder._cache_breakpoint = session.cache_breakpoint
            builder._turns_since_write = session.turns_since_cache_write
            if session.last_knowledge_hash:
                builder._knowledge_hash = session.last_knowledge_hash
            with _builders_lock:
                _builders[sid] = builder
                if len(_builders) > _MAX_BUILDERS:
                    stale = [k for k in _builders if k != sid]
                    for k in stale[: len(_builders) - _MAX_BUILDERS]:
                        del _builders[k]

        builder.set_system_prefix(*budgeted_prompt.stable_parts)
        builder.set_system_dynamic(
            *budgeted_prompt.dynamic_parts,
            *budgeted_prompt.operator_parts,
        )
        builder.set_knowledge(budgeted_prompt.retrieval_text)
        messages = builder.build(user_input)
    else:
        system_prompt = _build_system_prompt(
            budgeted_prompt.stable_parts,
            budgeted_prompt.dynamic_parts,
            budgeted_prompt.operator_parts,
            retrieved_knowledge=budgeted_prompt.retrieval_text,
        )
        messages = _build_messages(
            system_prompt, session.conversation_history, user_input
        )

    openai_tools = to_openai_tools(available_tools) if available_tools else []

    prompt_metrics = {
        "system_prompt_chars": (
            len(_message_content_to_text(messages[0]["content"])) if messages else 0
        ),
        "total_prompt_chars": _messages_char_count(messages),
        "stable_prompt_chars": len("\n\n".join(budgeted_prompt.stable_parts)),
        "dynamic_prompt_chars": len("\n\n".join(budgeted_prompt.dynamic_parts)),
        "operator_prompt_chars": len("\n\n".join(budgeted_prompt.operator_parts)),
        "retrieval_prompt_chars": len(budgeted_prompt.retrieval_text),
        "history_prompt_chars": max(
            0,
            _messages_char_count(messages)
            - (len(_message_content_to_text(messages[0]["content"])) if messages else 0)
            - len(user_input),
        ),
    }
    if budgeted_prompt.usage:
        prompt_metrics["section_usage"] = [u.to_dict() for u in budgeted_prompt.usage]

    ctx["messages"] = messages
    ctx["openai_tools"] = openai_tools
    ctx["budgeted_prompt"] = budgeted_prompt
    ctx["use_cache"] = use_cache
    ctx["builder"] = builder
    ctx["prompt_metrics"] = prompt_metrics


def _phase_record_human(ctx: TurnContext) -> None:
    """Record the human turn before LLM call."""
    from memex.session import add_turn

    session = ctx["session"]
    add_turn(
        session,
        "human",
        ctx["user_input"],
        classification=ctx["classification"],
        store=ctx["store"],
    )
