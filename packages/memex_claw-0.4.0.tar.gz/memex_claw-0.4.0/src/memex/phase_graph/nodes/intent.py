from __future__ import annotations

import logging
import time

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_intent_frame(ctx: TurnContext) -> None:
    """Build intent frame and resolve selected action candidate."""
    from memex.intent_frame import build_intent_frame
    from memex.loop import _resolve_selected_action_candidate
    from memex.prompt_control import build_prompt_control_artifact
    from memex.world_model_backbone import build_world_model_intent_id

    session = ctx["session"]
    user_input = ctx["user_input"]
    classification = ctx["classification"]
    agent_self_model = ctx["agent_self_model"]
    turn_ordinal = ctx["turn_ordinal"]
    project_root = ctx.get("project_root")
    prompt_mode = ctx.get("prompt_mode")

    recent_turns = (
        session.conversation_history[-3:] if session.conversation_history else []
    )
    intent_frame = build_intent_frame(
        user_input,
        classification=classification,
        recent_turns=recent_turns,
        active_goals=ctx["active_goals"],
    )
    intent_id = build_world_model_intent_id(session.session_id, turn_ordinal)
    session.last_intent_frame = intent_frame

    # Build prompt control artifact (first time, no tools)
    session.last_prompt_control = build_prompt_control_artifact(
        session.session_id,
        user_input=user_input,
        classification=classification,
        intent_frame=intent_frame,
        agent_self_model=agent_self_model,
        plan_snapshot=ctx.get("prompt_control_plan_snapshot"),
        intent_id=intent_id,
        conversation_turn_id=turn_ordinal,
        project_root=project_root,
        prompt_mode=prompt_mode.value if prompt_mode is not None else "full",
    )
    selected_action_candidate = _resolve_selected_action_candidate(
        intent_frame=intent_frame,
        prompt_control_artifact=session.last_prompt_control,
    )
    session.working_memory["last_intent_path"] = selected_action_candidate.name
    session.working_memory["last_route_profile"] = (
        session.last_prompt_control.route_profile.value
        if session.last_prompt_control is not None
        else ""
    )

    # Persist prompt control artifact
    if session.last_prompt_control is not None:
        store = ctx["store"]
        try:
            store.upsert_prompt_control_artifact(session.last_prompt_control)
        except Exception:
            logger.debug("Failed to persist prompt control artifact", exc_info=True)

    ctx["intent_frame"] = intent_frame
    ctx["selected_action_candidate"] = selected_action_candidate
    ctx["intent_id"] = intent_id


def _phase_early_exit(ctx: TurnContext) -> None:
    """Handle clarify/abstain early exit path.

    Only sets up ctx for downstream WINDOW_HISTORY and SAVE_SESSION nodes.
    Does NOT duplicate work those nodes already perform (add_turn assistant,
    window_history, save_session, runtime stats, middleware, TurnFinished).
    """
    from memex.intent_frame import render_intent_response
    from memex.llm import TokenUsage, _get_response_model
    from memex.loop import (
        _build_selected_action_payload,
        _emit,
        _persist_world_model_decision_outcome,
    )
    from memex.models import TurnCompleted, TurnPhase
    from memex.session import add_turn

    session = ctx["session"]
    store = ctx["store"]
    on_event = ctx.get("on_event")
    classification = ctx["classification"]
    intent_frame = ctx["intent_frame"]
    intent_id = ctx["intent_id"]
    turn_ordinal = ctx["turn_ordinal"]
    selected_action_candidate = ctx["selected_action_candidate"]
    prompt_mode = ctx.get("prompt_mode")
    turn_start = ctx.get("turn_start", time.monotonic())

    response = render_intent_response(intent_frame)

    # Record human turn — RECORD_HUMAN_TURN doesn't run on the early exit path
    add_turn(
        session, "human", ctx["user_input"], classification=classification, store=store
    )

    # Emit thinking phase — LLM_RESPOND doesn't run on the early exit path
    _emit(on_event, TurnPhase("thinking", _get_response_model()))

    # Set session flags
    session.working_memory["_last_reflect_skipped"] = True
    session.working_memory.pop("last_tool_failures", None)
    session.working_memory["_turn_token_usage"] = {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "cost_usd": 0.0,
    }

    # Persist decision outcome for CLARIFY/ABSTAIN — SAVE_SESSION only handles
    # DIRECT_ANSWER/ACT, so this is early-exit-specific work.
    try:
        decision_payload = _build_selected_action_payload(
            decision_name=selected_action_candidate.name,
            status=selected_action_candidate.name,
            classification=classification.classification.value,
            intent_frame=intent_frame,
            prompt_control_artifact=session.last_prompt_control,
        )
        _persist_world_model_decision_outcome(
            store,
            session_id=session.session_id,
            turn_ordinal=turn_ordinal,
            intent_id=intent_id,
            goal_id=intent_frame.goal_id or classification.goal_id,
            prompt_control_artifact_id=(
                session.last_prompt_control.artifact_id
                if session.last_prompt_control is not None
                else None
            ),
            decision_name=selected_action_candidate.name,
            status=selected_action_candidate.name,
            response=response,
            payload=decision_payload,
        )
    except Exception:
        logger.debug("Failed to persist early-exit decision outcome", exc_info=True)

    # Emit TurnCompleted — RETURN_RESPONSE doesn't run on the early exit path
    turn_elapsed = int((time.monotonic() - turn_start) * 1000)
    _emit(
        on_event,
        TurnCompleted(
            duration_ms=turn_elapsed,
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
            cost_usd=0.0,
            model="",
            tool_call_count=0,
            route_profile=(
                session.last_prompt_control.route_profile.value
                if session.last_prompt_control
                else ""
            ),
            prompt_mode=prompt_mode.value if prompt_mode is not None else "full",
        ),
    )

    # Set ctx for downstream nodes
    ctx["response"] = response
    ctx["early_exit_response"] = response
    ctx["turn_usage"] = TokenUsage()
    ctx["tool_calls"] = []
    ctx["tool_call_count"] = 0
    ctx["executed_tool_names"] = []
