from __future__ import annotations

import logging

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_llm_respond(ctx: TurnContext) -> None:
    """Call the LLM to generate a response (with or without tools)."""
    from memex.llm import (
        TokenUsage,
        _get_response_model,
        chat_streaming,
        chat_with_tools_streaming,
        chat_with_usage,
    )
    from memex.loop import _emit
    from memex.models import TurnPhase

    session = ctx["session"]
    messages = ctx["messages"]
    on_event = ctx.get("on_event")
    on_token = ctx.get("on_token")
    chain = ctx.get("middleware_chain")
    available_tools = ctx.get("available_tools", [])
    openai_tools = ctx.get("openai_tools", [])

    response = ""
    tool_calls = []
    turn_usage = TokenUsage()

    _emit(on_event, TurnPhase("thinking", _get_response_model()))

    # Note: on_llm_input should only fire once, even if the executor retries this node.
    # Use a ctx flag to prevent double-fire.
    if not ctx.get("_llm_input_called"):
        if chain is not None:
            try:
                chain.on_llm_input(session, messages)
            except Exception:
                logger.debug("Middleware on_llm_input failed", exc_info=True)
        ctx["_llm_input_called"] = True

    if available_tools:
        response, tool_calls, usage = chat_with_tools_streaming(
            messages,
            openai_tools,
            model=_get_response_model(),
            on_token=on_token,
        )
        turn_usage = TokenUsage(
            prompt_tokens=turn_usage.prompt_tokens + usage.prompt_tokens,
            completion_tokens=turn_usage.completion_tokens + usage.completion_tokens,
            total_tokens=turn_usage.total_tokens + usage.total_tokens,
            cost_usd=turn_usage.cost_usd + usage.cost_usd,
        )

        # Middleware on_llm_output
        if chain is not None:
            try:
                chain.on_llm_output(session, response, tool_calls or [])
            except Exception:
                logger.debug("Middleware on_llm_output failed", exc_info=True)
    else:
        if on_token is not None:
            response, usage = chat_streaming(
                messages,
                model=_get_response_model(),
                on_token=on_token,
            )
        else:
            response, usage = chat_with_usage(messages, model=_get_response_model())
        turn_usage = TokenUsage(
            prompt_tokens=turn_usage.prompt_tokens + usage.prompt_tokens,
            completion_tokens=turn_usage.completion_tokens + usage.completion_tokens,
            total_tokens=turn_usage.total_tokens + usage.total_tokens,
            cost_usd=turn_usage.cost_usd + usage.cost_usd,
        )

        # Middleware on_llm_output (no-tool path)
        if chain is not None:
            try:
                chain.on_llm_output(session, response, [])
            except Exception:
                logger.debug("Middleware on_llm_output failed", exc_info=True)

    ctx["response"] = response
    ctx["tool_calls"] = tool_calls if tool_calls else []
    ctx["turn_usage"] = turn_usage
    ctx["tool_call_count"] = 0
    ctx["tool_execution_ms"] = 0
