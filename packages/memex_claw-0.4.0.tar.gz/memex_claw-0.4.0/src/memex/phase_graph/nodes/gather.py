from __future__ import annotations

import logging
import uuid
from pathlib import Path

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_filter_goals(ctx: TurnContext) -> None:
    """Handle NEW_GOAL creation and re-filter goals."""
    from memex.models import Goal, GoalStatus, InputClassificationType
    from memex.loop import _resolve_prompt_control_plan_snapshot
    from memex.relevance import filter_goals

    store = ctx["store"]
    now = ctx["now"]
    classification = ctx["classification"]
    intent_frame = ctx["intent_frame"]
    all_goals = ctx["all_goals"]
    active_goals = ctx["active_goals"]

    # Handle NEW_GOAL creation
    if classification.classification == InputClassificationType.NEW_GOAL:
        goal_title = classification.suggested_title or ctx["user_input"][:200]
        new_goal = Goal(
            goal_id=str(uuid.uuid4()),
            title=goal_title,
            description=ctx["user_input"],
            status=GoalStatus.ACTIVE,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        store.create_goal(new_goal)
        classification.goal_id = new_goal.goal_id
        intent_frame.goal_id = new_goal.goal_id
        all_goals.append(new_goal)
        active_goals.append(new_goal)
        logger.info("Created new goal: %s (%s)", new_goal.title, new_goal.goal_id[:8])

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalCreated

            get_bus().publish(
                GoalCreated(goal_id=new_goal.goal_id, title=new_goal.title)
            )
        except Exception:
            pass

    relevant = filter_goals(
        all_goals,
        now,
        referenced_goal_id=classification.goal_id,
    )
    prompt_control_plan_snapshot = _resolve_prompt_control_plan_snapshot(
        store,
        intent_goal_id=intent_frame.goal_id,
        classified_goal_id=classification.goal_id,
        relevant_goals=relevant,
    )

    ctx["relevant_goals"] = relevant
    ctx["prompt_control_plan_snapshot"] = prompt_control_plan_snapshot


def _phase_select_tools(ctx: TurnContext) -> None:
    """Select tools for context and rebuild prompt control artifact."""
    from memex.agent_self_model import blocked_tool_capability_tags
    from memex.prompt_control import build_prompt_control_artifact
    from memex.security import get_granted_capabilities

    store = ctx["store"]
    session = ctx["session"]
    tool_registry = ctx.get("tool_registry")
    connector_health = ctx.get("connector_health") or []
    classification = ctx["classification"]
    intent_frame = ctx["intent_frame"]
    agent_self_model = ctx["agent_self_model"]
    selected_action_candidate = ctx["selected_action_candidate"]
    active_goals = ctx["active_goals"]
    turn_ordinal = ctx["turn_ordinal"]
    intent_id = ctx["intent_id"]
    project_root = ctx.get("project_root")
    prompt_mode = ctx.get("prompt_mode")

    available_tools = []
    granted: set[str] = set()

    if tool_registry:
        granted = get_granted_capabilities(connector_health)
        goal_titles = [g.title for g in active_goals]

        # Load usage boosts
        usage_boosts: dict[str, int] = {}
        try:
            stats = store.get_tool_usage_stats()
            for row in stats:
                name = row["tool_name"]
                usage_boosts[name] = usage_boosts.get(name, 0) + row["call_count"]
        except Exception:
            pass

        available_tools = tool_registry.get_tools_for_context(
            ctx["user_input"],
            goal_titles,
            granted,
            classification=classification.classification.value,
            intent_path=selected_action_candidate.name,
            usage_boosts=usage_boosts,
            blocked_capability_tags=blocked_tool_capability_tags(agent_self_model),
        )
        session.last_prompt_control = build_prompt_control_artifact(
            session.session_id,
            user_input=ctx["user_input"],
            classification=classification,
            intent_frame=intent_frame,
            agent_self_model=agent_self_model,
            plan_snapshot=ctx.get("prompt_control_plan_snapshot"),
            tool_candidate_names=[tool.name for tool in available_tools],
            intent_id=intent_id,
            conversation_turn_id=turn_ordinal,
            project_root=project_root,
            prompt_mode=prompt_mode.value if prompt_mode is not None else "full",
        )
        session.working_memory["last_route_profile"] = (
            session.last_prompt_control.route_profile.value
        )
        try:
            store.upsert_prompt_control_artifact(session.last_prompt_control)
        except Exception:
            logger.debug(
                "Failed to persist prompt control artifact (tool-selection path)",
                exc_info=True,
            )

    ctx["available_tools"] = available_tools
    ctx["granted_capabilities"] = granted


def _phase_retrieve(ctx: TurnContext) -> None:
    """Retrieve knowledge for context."""
    from memex.memory.retrieval import retrieve_for_context

    session = ctx["session"]
    content_store = ctx.get("content_store")
    store = ctx["store"]
    now = ctx["now"]
    chain = ctx.get("middleware_chain")

    retrieved_knowledge = ""
    retrieved_document_ids: set[str] = set()

    if content_store is not None:
        budget = 3000
        retrieval = retrieve_for_context(
            ctx["user_input"],
            max_tokens=budget,
            content_store=content_store,
            world_model_store=store,
            route_profile=(
                session.last_prompt_control.route_profile
                if session.last_prompt_control is not None
                else None
            ),
            now=now,
        )
        retrieved_knowledge = retrieval.text
        retrieved_document_ids = retrieval.document_ids

        # Middleware after_retrieval
        if retrieved_knowledge and chain is not None:
            try:
                items_count = retrieved_knowledge.count("### [")
                chain.after_retrieval(
                    session,
                    query=ctx["user_input"][:200],
                    items_retrieved=items_count,
                )
            except Exception:
                logger.debug("Middleware after_retrieval failed", exc_info=True)

    ctx["retrieved_knowledge"] = retrieved_knowledge
    ctx["retrieved_document_ids"] = retrieved_document_ids


def _phase_proactive(ctx: TurnContext) -> None:
    """Surface proactive context based on entities."""
    content_store = ctx.get("content_store")
    proactive_context = ""

    if content_store is not None:
        try:
            from memex.memory.extraction_gate import check_extraction_gate as _pre_gate
            from memex.memory.proactive import surface_proactive_context

            classification = ctx["classification"]
            pre_gate = _pre_gate(ctx["user_input"], "", classification)
            if pre_gate.entities:
                proactive_context = surface_proactive_context(
                    ctx["user_input"],
                    pre_gate,
                    ctx["active_goals"],
                    content_store,
                    ctx.get("retrieved_document_ids", set()),
                )
        except Exception:
            logger.debug("Proactive context surfacing failed", exc_info=True)

    ctx["proactive_context"] = proactive_context


def _phase_fact_store(ctx: TurnContext) -> None:
    """Initialize FactStore and load memory block."""
    from memex.governance import load_documentation

    content_store = ctx.get("content_store")
    chain = ctx.get("middleware_chain")
    project_root = ctx.get("project_root")

    # FactStore owns its own embedding backend rather than reading from a
    # shared ctx key. This scopes the dependency cleanly — retrieval.py no
    # longer threads embedding_backend through its public surface, and the
    # ctx["embedding_backend"] key is gone.
    from memex.memory.embeddings import get_embedding_backend

    embedding_backend = get_embedding_backend()

    fact_store = None
    memory_block_text = ""

    if content_store is not None and embedding_backend is not None:
        try:
            from memex.memory.fact_store import FactStore

            fact_store = FactStore(content_store, embedding_backend)

            memory_block_path = Path.home() / ".memex" / "memory_block.md"
            if memory_block_path.exists():
                memory_block_text = memory_block_path.read_text().strip()
            else:
                memory_block_text = fact_store.render_memory_block()

            # Add consolidation middleware
            if chain is not None:
                try:
                    from memex.memory.consolidation_middleware import (
                        FactConsolidationMiddleware,
                    )

                    has_consolidation = any(
                        isinstance(m, FactConsolidationMiddleware)
                        for m in getattr(chain, "_middleware", [])
                    )
                    if not has_consolidation:
                        chain.add(
                            FactConsolidationMiddleware(
                                content_store, embedding_backend
                            )
                        )
                except Exception:
                    logger.debug(
                        "Failed to add FactConsolidationMiddleware", exc_info=True
                    )
        except Exception:
            logger.debug("FactStore initialization failed", exc_info=True)

    documentation_text = load_documentation(project_root) or ""

    ctx["fact_store"] = fact_store
    ctx["memory_block_text"] = memory_block_text
    ctx["documentation_text"] = documentation_text
