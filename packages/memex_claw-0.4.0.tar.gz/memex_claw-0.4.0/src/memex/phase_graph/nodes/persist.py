from __future__ import annotations

import logging
import time

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_window_history(ctx: TurnContext) -> None:
    """Record assistant turn, update builder state, and window history."""
    from memex.session import add_turn, window_history

    session = ctx["session"]
    response = ctx["response"]
    store = ctx["store"]
    use_cache = ctx.get("use_cache", False)
    builder = ctx.get("builder")
    user_input = ctx["user_input"]

    add_turn(session, "assistant", response, store=store)

    if use_cache and builder is not None:
        builder.append_turn(user_input, response)
        session.cache_breakpoint = builder._cache_breakpoint
        session.turns_since_cache_write = builder._turns_since_write
        session.last_knowledge_hash = builder._knowledge_hash

    window_history(session)


def _phase_return_response(ctx: TurnContext) -> None:
    """Emit TurnCompleted and store tool/token info in working memory."""
    from memex.loop import _emit
    from memex.llm import _get_response_model
    from memex.models import TurnCompleted

    session = ctx["session"]
    on_event = ctx.get("on_event")
    turn_usage = ctx.get("turn_usage")
    tool_call_count = ctx.get("tool_call_count", 0)
    tool_failures = ctx.get("tool_failures", [])
    prompt_mode = ctx.get("prompt_mode")
    turn_start = ctx.get("turn_start", time.monotonic())

    # Run on_message_sending BEFORE returning response to caller
    chain = ctx.get("middleware_chain")
    response = ctx["response"]
    if chain is not None:
        try:
            response = chain.on_message_sending(session, response)
            ctx["response"] = response
        except Exception:
            logger.debug("Middleware on_message_sending failed", exc_info=True)

    pre_reflect_elapsed = int((time.monotonic() - turn_start) * 1000)
    _emit(
        on_event,
        TurnCompleted(
            duration_ms=pre_reflect_elapsed,
            prompt_tokens=turn_usage.prompt_tokens if turn_usage else 0,
            completion_tokens=turn_usage.completion_tokens if turn_usage else 0,
            total_tokens=turn_usage.total_tokens if turn_usage else 0,
            cost_usd=turn_usage.cost_usd if turn_usage else 0.0,
            model=_get_response_model(),
            tool_call_count=tool_call_count,
            route_profile=(
                session.last_prompt_control.route_profile.value
                if session.last_prompt_control
                else ""
            ),
            prompt_mode=prompt_mode.value if prompt_mode is not None else "full",
        ),
    )

    # Store tool failures
    if tool_failures:
        session.working_memory["last_tool_failures"] = tool_failures[:10]
    else:
        session.working_memory.pop("last_tool_failures", None)

    # Store token usage
    if turn_usage:
        session.working_memory["_turn_token_usage"] = {
            "prompt_tokens": turn_usage.prompt_tokens,
            "completion_tokens": turn_usage.completion_tokens,
            "total_tokens": turn_usage.total_tokens,
            "cost_usd": turn_usage.cost_usd,
        }

    phase_timings_ms = ctx.get("phase_timings_ms", {})
    phase_timings_ms["total"] = int((time.monotonic() - turn_start) * 1000)

    # Assemble answer observation payload for persistence in SAVE_SESSION
    try:
        import uuid
        import datetime as _dt
        from memex.memory.answer_feedback import AnswerObservation

        response_text = ctx.get("response", "")
        excerpt = response_text[:500] if response_text else ""
        classification = ctx.get("classification")
        selected = ctx.get("selected_action_candidate")
        obs = AnswerObservation(
            answer_id=str(uuid.uuid4()),
            session_id=session.session_id,
            turn_ordinal=ctx.get("turn_ordinal", 0),
            created_at=_dt.datetime.utcnow().isoformat(),
            response_excerpt=excerpt,
            classification=classification.classification.value
            if classification
            else "",
            selected_path=selected.name if selected else "",
            tool_call_count=ctx.get("tool_call_count", 0),
            tool_names=list(ctx.get("executed_tool_names", [])),
            retrieved_document_ids=list(ctx.get("retrieved_document_ids", [])),
            route_profile=(
                session.last_prompt_control.route_profile.value
                if session.last_prompt_control
                else ""
            ),
            resolved=False,
            resolved_at=None,
        )
        ctx["_pending_answer_observation"] = obs
    except Exception:
        logger.debug("Failed to assemble answer observation", exc_info=True)


def _phase_save_session(ctx: TurnContext) -> None:
    """Record runtime stats, run after_turn middleware, persist session."""
    from memex.loop import (
        _build_selected_action_payload,
        _persist_world_model_decision_outcome,
        _persist_world_model_turn_event,
        _record_turn_runtime_stats,
    )
    from memex.models import IntentFramePath
    from memex.session import save_session

    session = ctx["session"]
    store = ctx["store"]
    chain = ctx.get("middleware_chain")
    caller = ctx.get("caller")
    turn_ordinal = ctx["turn_ordinal"]
    use_cache = ctx.get("use_cache", False)
    phase_timings_ms = ctx.get("phase_timings_ms", {})
    prompt_metrics = ctx.get("prompt_metrics", {})
    tool_call_count = ctx.get("tool_call_count", 0)
    tool_execution_ms = ctx.get("tool_execution_ms", 0)
    tool_loop_stats = ctx.get("tool_loop_stats", [])
    executed_tool_names = ctx.get("executed_tool_names", [])
    selected_action_candidate = ctx["selected_action_candidate"]
    intent_frame = ctx["intent_frame"]
    intent_id = ctx["intent_id"]
    classification = ctx["classification"]
    response = ctx.get("response", "")

    _record_turn_runtime_stats(
        session,
        turn_ordinal=turn_ordinal,
        used_cache=use_cache,
        phase_timings_ms=phase_timings_ms,
        prompt_metrics=prompt_metrics,
        tool_call_count=tool_call_count,
    )
    logger.info(
        "turn runtime stats: phase_timings_ms=%s prompt_metrics=%s tool_call_count=%d tool_execution_ms=%d executed_tool_names=%s",
        phase_timings_ms,
        prompt_metrics,
        tool_call_count,
        tool_execution_ms,
        executed_tool_names,
    )
    if tool_loop_stats:
        logger.info("turn tool-loop stats: %s", tool_loop_stats)

    # Middleware after_turn
    if chain is not None:
        try:
            chain.after_turn(session, response)
        except Exception:
            logger.debug("Middleware after_turn failed", exc_info=True)

    # Persist world model outcomes for normal path
    if tool_call_count == 0 and selected_action_candidate.name in (
        IntentFramePath.DIRECT_ANSWER.value,
        IntentFramePath.ACT.value,
    ):
        try:
            decision_payload = _build_selected_action_payload(
                decision_name=selected_action_candidate.name,
                status="succeeded",
                classification=classification.classification.value,
                intent_frame=intent_frame,
                prompt_control_artifact=session.last_prompt_control,
            )
            _persist_world_model_decision_outcome(
                store,
                session_id=session.session_id,
                turn_ordinal=turn_ordinal,
                intent_id=intent_id,
                goal_id=intent_frame.goal_id or classification.goal_id,
                prompt_control_artifact_id=(
                    session.last_prompt_control.artifact_id
                    if session.last_prompt_control is not None
                    else None
                ),
                decision_name=selected_action_candidate.name,
                status="succeeded",
                response=response,
                payload=decision_payload,
            )
        except Exception:
            logger.debug(
                "Failed to persist direct-answer decision outcome",
                exc_info=True,
            )

    # Persist turn event
    try:
        _persist_world_model_turn_event(
            store,
            session_id=session.session_id,
            turn_ordinal=turn_ordinal,
            intent_id=intent_id,
            goal_id=intent_frame.goal_id or classification.goal_id,
            prompt_control_artifact_id=(
                session.last_prompt_control.artifact_id
                if session.last_prompt_control is not None
                else None
            ),
            title=f"Turn event: {selected_action_candidate.name}",
            summary=response,
            payload={
                "selected_path": selected_action_candidate.name,
                "classification": classification.classification.value,
                "route_profile": (
                    session.last_prompt_control.route_profile.value
                    if session.last_prompt_control is not None
                    else ""
                ),
                "tool_call_count": tool_call_count,
                "tool_names": executed_tool_names,
            },
            planning_refs=ctx.get("turn_planning_refs"),
        )
    except Exception:
        logger.debug(
            "Failed to persist turn event to world-model backbone", exc_info=True
        )

    save_session(session, store)

    try:
        from memex.event_bus import get_bus
        from memex.events import TurnFinished

        get_bus().publish(
            TurnFinished(
                session_id=session.session_id,
                interface=caller.interface if caller else "",
            )
        )
    except Exception:
        pass

    # Persist pending answer observation
    pending_obs = ctx.pop("_pending_answer_observation", None)
    if pending_obs is not None:
        try:
            from memex.memory.answer_feedback import save_answer_observation

            save_answer_observation(store, pending_obs)
        except Exception:
            logger.debug("Failed to persist answer observation", exc_info=True)
