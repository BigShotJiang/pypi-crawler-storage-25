from __future__ import annotations

import logging
from pathlib import Path

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_extract_reflect(ctx: TurnContext) -> None:
    """Run extraction gate, extract_and_reflect, and apply extraction."""
    from memex.memory.extraction_gate import check_extraction_gate

    user_input = ctx["user_input"]
    response = ctx["response"]
    classification = ctx["classification"]
    session = ctx["session"]
    relevant = ctx.get("relevant_goals", [])
    content_store = ctx.get("content_store")
    fact_store = ctx.get("fact_store")
    store = ctx["store"]
    caller = ctx.get("caller")

    gate_result = check_extraction_gate(user_input, response, classification)

    # Check fast URL capture skip
    from memex.loop import _should_skip_sync_reflect_for_url_capture

    if _should_skip_sync_reflect_for_url_capture(user_input, caller):
        gate_result.should_extract = False
        gate_result.signals.add("fast_url_capture")

    extraction = None
    reflect_result = None

    if gate_result.should_extract:
        try:
            from memex.memory.conversation_extract import (
                apply_extraction,
                extract_and_reflect,
            )

            combined = extract_and_reflect(
                classification=classification,
                assistant_response=response,
                relevant_goals=relevant,
                session=session,
                signals=gate_result.signals,
                entities=gate_result.entities,
            )
            extraction = combined.to_extraction_result()
            reflect_result = combined.to_reflect_result()

            # Apply extraction
            if content_store is not None:
                try:
                    apply_extraction(
                        extraction,
                        content_store,
                        session,
                        memex_store=store,
                        fact_store=fact_store,
                    )
                    # Re-render memory block
                    if fact_store is not None:
                        try:
                            new_block = fact_store.render_memory_block()
                            if new_block:
                                memory_block_path = (
                                    Path.home() / ".memex" / "memory_block.md"
                                )
                                memory_block_path.parent.mkdir(
                                    parents=True, exist_ok=True
                                )
                                memory_block_path.write_text(new_block)
                        except Exception:
                            logger.debug("Memory block re-render failed", exc_info=True)
                except Exception:
                    logger.debug("Extraction apply failed", exc_info=True)
        except Exception:
            logger.debug("Combined extract+reflect failed", exc_info=True)
            raise  # Let graph-level fallback handle it
    else:
        session.working_memory["_last_reflect_skipped"] = True
        if "fast_url_capture" in gate_result.signals:
            session.working_memory["_last_reflect_skipped_reason"] = "fast_url_capture"
        else:
            session.working_memory.pop("_last_reflect_skipped_reason", None)

    ctx["extraction_result"] = extraction
    ctx["reflect_result"] = reflect_result


def _phase_apply_extraction(ctx: TurnContext) -> None:
    """No-op: extraction is applied inline in _phase_extract_reflect."""
    pass


def _phase_apply_reflect(ctx: TurnContext) -> None:
    """Apply reflect result to store and session."""
    from memex.reflect import apply_reflect_result

    reflect_result = ctx.get("reflect_result")
    if reflect_result is None:
        return

    store = ctx["store"]
    now = ctx["now"]
    session = ctx["session"]
    chain = ctx.get("middleware_chain")
    classification = ctx["classification"]

    apply_reflect_result(reflect_result, store, now)

    # Middleware after_reflect
    if chain is not None:
        try:
            chain.after_reflect(session, reflect_result, classification)
        except Exception:
            logger.debug("Middleware after_reflect failed", exc_info=True)

    # Update session
    session.last_reflect = reflect_result
    if reflect_result.session_context_update:
        session.working_memory.update(reflect_result.session_context_update)


def _phase_proactive_check(ctx: TurnContext) -> None:
    """Check for proactive messages and append to response."""
    from memex.scheduler import check_proactive
    from memex.session import add_turn

    session = ctx["session"]
    store = ctx["store"]
    now = ctx["now"]

    proactive = check_proactive(session, store, now)
    if proactive:
        response = ctx.get("response", "")
        response += f"\n\n---\n{proactive}"
        ctx["response"] = response
        add_turn(session, "system", proactive, store=store)
