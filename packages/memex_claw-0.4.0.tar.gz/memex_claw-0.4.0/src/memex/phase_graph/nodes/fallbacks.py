from __future__ import annotations

import logging

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def classify_default(ctx: TurnContext) -> None:
    """Fallback: assume conversational intent."""
    from memex.classify import InputClassification, InputClassificationType

    ctx["classification"] = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.0,
        goal_id=None,
        reasoning="classification failed, defaulting to conversational",
        suggested_title="",
    )


def respond_error(ctx: TurnContext) -> None:
    """Fallback: return error message to user."""
    ctx["response"] = (
        "I'm having trouble connecting right now. Could you try again in a moment?"
    )
    ctx["tool_calls"] = []


def tool_loop_fallback(ctx: TurnContext) -> None:
    """Fallback: return partial response when tool loop fails."""
    logger.error("Tool loop failed -- returning partial response")
    if not ctx.get("response", ""):
        ctx["response"] = (
            "I encountered an issue while processing tools. Here is what I have so far."
        )
    ctx["tool_calls"] = []


def reflect_only(ctx: TurnContext) -> None:
    """Fallback: reflect without extraction."""
    from memex.reflect import reflect

    ctx["reflect_result"] = reflect(
        classification=ctx["classification"],
        assistant_response=ctx["response"],
        relevant_goals=ctx.get("relevant_goals", []),
        session=ctx["session"],
    )
    ctx["extraction_result"] = None


def reflect_fallback(ctx: TurnContext) -> None:
    """Second-level fallback: reflection failed entirely."""
    ctx["reflect_result"] = None


def log_save_failure(ctx: TurnContext) -> None:
    """Terminal fallback: log error, do not crash."""
    logger.error("Session save failed -- data may be lost")
