from __future__ import annotations

import logging
import time

from memex.phase_graph.context import TurnContext

logger = logging.getLogger(__name__)


def _phase_load_context(ctx: TurnContext) -> None:
    """Load governance, profiles, goals, and initialize tracking."""
    from memex.agent_self_model import (
        format_for_prompt as format_agent_self_for_prompt,
        load_agent_self_model,
    )
    from memex.governance import load_governance
    from memex.human_model import (
        format_combined_partner_prompt,
        load_canonical_partner_profile,
    )
    from memex.models import GoalStatus

    store = ctx["store"]
    project_root = ctx.get("project_root")

    governance = load_governance(project_root)
    partner_profile = load_canonical_partner_profile(store)
    partner_prompt = format_combined_partner_prompt(
        partner_profile, project_root=project_root
    )
    agent_self_model = load_agent_self_model(store)
    agent_self_prompt = format_agent_self_for_prompt(agent_self_model)
    all_goals = store.list_goals()
    active_goals = [g for g in all_goals if g.status == GoalStatus.ACTIVE]

    ctx["governance"] = governance
    ctx["partner_prompt"] = partner_prompt
    ctx["agent_self_prompt"] = agent_self_prompt
    ctx["agent_self_model"] = agent_self_model
    ctx["all_goals"] = all_goals
    ctx["active_goals"] = active_goals

    # Initialize tracking
    ctx["turn_start"] = time.monotonic()
    ctx["phase_timings_ms"] = {}
    ctx["prompt_metrics"] = {
        "system_prompt_chars": 0,
        "total_prompt_chars": 0,
        "stable_prompt_chars": 0,
        "dynamic_prompt_chars": 0,
        "operator_prompt_chars": 0,
        "retrieval_prompt_chars": 0,
        "history_prompt_chars": 0,
    }
    session = ctx["session"]
    ctx["turn_ordinal"] = session.turn_count + 1
    ctx["tool_call_count"] = 0
    ctx["executed_tool_names"] = []
    ctx["tool_failures"] = []


def _phase_classify(ctx: TurnContext) -> None:
    """Classify user input and build pre-filter plan snapshot."""
    from memex.classify import classify_input
    from memex.loop import _emit, _resolve_prompt_control_plan_snapshot
    from memex.llm import _get_cheap_model
    from memex.models import TurnPhase
    from memex.relevance import filter_goals

    on_event = ctx.get("on_event")
    _emit(on_event, TurnPhase("classifying", _get_cheap_model()))

    session = ctx["session"]
    recent_turns = (
        session.conversation_history[-3:] if session.conversation_history else []
    )
    classification = classify_input(
        ctx["user_input"],
        active_goals=ctx["active_goals"],
        recent_turns=recent_turns,
    )
    now = ctx["now"]
    pre_relevant = filter_goals(
        ctx["all_goals"],
        now,
        referenced_goal_id=classification.goal_id,
    )
    store = ctx["store"]
    prompt_control_plan_snapshot = _resolve_prompt_control_plan_snapshot(
        store,
        intent_goal_id=None,
        classified_goal_id=classification.goal_id,
        relevant_goals=pre_relevant,
    )

    ctx["classification"] = classification
    ctx["prompt_control_plan_snapshot"] = prompt_control_plan_snapshot


def _phase_middleware_classify(ctx: TurnContext) -> None:
    """Run after_classify middleware."""
    chain = ctx.get("middleware_chain")
    if chain is not None:
        try:
            chain.after_classify(ctx["session"], ctx["classification"])
        except Exception:
            logger.debug("Middleware after_classify failed", exc_info=True)
