"""TurnContext type and shared helpers."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, TYPE_CHECKING

from typing_extensions import TypedDict

if TYPE_CHECKING:
    from memex.phase_graph.trace import PhaseTraceEntry


class TurnContext(TypedDict, total=False):
    # --- Inputs (set before graph starts) ---
    user_input: str
    store: Any  # MemexStore
    session: Any  # SessionContext
    tool_registry: Any  # ToolRegistry
    middleware_chain: Any  # MiddlewareChain
    connector_health: list[Any]
    connector_clients: dict[str, Any]
    content_store: Any
    on_event: Any  # Callable or None
    on_token: Any  # Callable or None
    prompt_mode: Any  # PromptMode
    project_root: Path | None
    caller: Any
    now: datetime
    response_format: Any
    session_mode: Any

    # --- Phase: Load Context ---
    governance: str
    partner_prompt: str
    agent_self_prompt: str
    agent_self_model: Any
    all_goals: list[Any]
    active_goals: list[Any]

    # --- Phase: Classify ---
    classification: Any  # InputClassification
    prompt_control_plan_snapshot: Any

    # --- Phase: Intent Frame ---
    intent_frame: Any  # IntentFrame
    selected_action_candidate: Any
    intent_id: str
    turn_ordinal: int

    # --- Phase: Early Exit ---
    early_exit_response: str | None

    # --- Phase: Filter Goals ---
    relevant_goals: list[Any]

    # --- Phase: Select Tools ---
    available_tools: list[Any]
    granted_capabilities: set[str]

    # --- Phase: Retrieve ---
    retrieved_knowledge: str
    retrieved_document_ids: set[str]

    # --- Phase: Proactive Context ---
    proactive_context: str

    # --- Phase: Fact Store ---
    fact_store: Any | None
    memory_block_text: str

    # --- Phase: Build Prompt ---
    messages: list[dict[str, Any]]
    openai_tools: list[dict[str, Any]]
    budgeted_prompt: Any

    # --- Phase: LLM + Tool Loop ---
    response: str
    tool_calls: list[dict[str, Any]]
    turn_usage: Any  # TokenUsage
    tool_call_count: int
    executed_tool_names: list[str]
    tool_failures: list[str]
    tool_results: list[Any]
    tool_execution_ms: int
    tool_loop_stats: list[dict[str, Any]]

    # --- Phase: Reflect ---
    reflect_result: Any | None
    extraction_result: Any | None

    # --- Observability ---
    phase_timings_ms: dict[str, int]
    prompt_metrics: dict[str, int]
    execution_trace: list[PhaseTraceEntry]

    # --- Internal bookkeeping ---
    turn_start: float
    use_cache: bool
    builder: Any  # MessageBuilder or None
    documentation_text: str


INITIAL_CONTEXT_KEYS: frozenset[str] = frozenset(
    {
        "user_input",
        "store",
        "session",
        "tool_registry",
        "middleware_chain",
        "connector_health",
        "connector_clients",
        "content_store",
        "now",
        "on_event",
        "on_token",
        "prompt_mode",
        "project_root",
        "caller",
        "response_format",
        "session_mode",
    }
)


def _record_human_turn(ctx: TurnContext) -> None:
    """Record the human turn in the session."""
    from memex.session import add_turn

    add_turn(
        ctx["session"],
        "human",
        ctx["user_input"],
        classification=ctx.get("classification"),
        store=ctx.get("store"),
    )


def _set_retrieval_defaults(ctx: TurnContext) -> None:
    """Set empty retrieval defaults (used by SKIP_RETRIEVE and RETRIEVE_FALLBACK)."""
    ctx["retrieved_knowledge"] = ""
    ctx["retrieved_document_ids"] = set()
    ctx["proactive_context"] = ""
