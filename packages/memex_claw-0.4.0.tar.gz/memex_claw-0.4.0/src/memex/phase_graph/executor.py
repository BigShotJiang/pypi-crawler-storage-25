"""GraphExecutor: sequential dispatch engine for PhaseGraph.

Walks the phase graph from the entry node using a ready-queue.  For each
node it validates inputs, executes with retry, routes to fallbacks on
failure, evaluates conditional outgoing edges, and waits at join barriers.
Supports ``run_to_boundary`` / ``run_remaining`` for returning results
before background work completes (whitepaper rule 2.9).
"""

from __future__ import annotations

import threading
import time
from collections import deque

from memex.phase_graph.context import TurnContext
from memex.phase_graph.events import PhaseCompleted, PhaseStarted
from memex.phase_graph.graph import PhaseGraph
from memex.phase_graph.trace import PhaseTraceEntry, compute_phase_timings


class GraphExecutor:
    def __init__(self, graph: PhaseGraph, context: TurnContext) -> None:
        self._graph = graph
        self._context = context
        self._completed_nodes: set[str] = set()
        self._failed_nodes: set[str] = set()
        self._cancelled_nodes: set[str] = set()
        self._scheduled_nodes: set[str] = set()
        self._execution_trace: list[PhaseTraceEntry] = []
        self._ready: deque[str] = deque()
        self._boundary: str | None = None
        self._boundary_hit = False
        self._lock = threading.Lock()

        # Seed with entry node
        entry = graph.entry_node
        if entry:
            self._ready.append(entry)
            self._scheduled_nodes.add(entry)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> TurnContext:
        self._boundary = None
        self._run_loop()
        self._finalize()
        return self._context

    def run_to_boundary(self, boundary: str) -> TurnContext:
        self._boundary = boundary
        self._boundary_hit = False
        self._run_loop()
        self._finalize()
        return self._context

    def remaining_nodes(self) -> list[str]:
        resolved = self._completed_nodes | self._failed_nodes | self._cancelled_nodes
        all_names = self._graph.node_names
        return sorted(all_names - resolved)

    def run_remaining(self) -> TurnContext:
        self._boundary = None
        self._boundary_hit = False
        self._run_loop()
        self._finalize()
        return self._context

    # ------------------------------------------------------------------
    # Core loop
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        while self._ready:
            name = self._ready.popleft()

            # Already resolved?
            if (
                name in self._completed_nodes
                or name in self._failed_nodes
                or name in self._cancelled_nodes
            ):
                continue

            # Is it a join barrier?
            barrier = self._graph.get_join_barrier(name)
            if barrier is not None:
                if self._is_barrier_satisfied(barrier):
                    self._evaluate_outgoing(name)
                else:
                    # Re-enqueue at back so we retry later
                    self._ready.append(name)
                    # Safety: if the only things left are unsatisfied barriers, break
                    if all(
                        self._graph.get_join_barrier(n) is not None for n in self._ready
                    ):
                        break
                continue

            # Regular node
            node = self._graph.get_node(name)
            if node is None:
                continue

            # Input validation
            for key in node.inputs:
                if key not in self._context:
                    raise RuntimeError(
                        f"Node '{node.name}' missing required input '{key}' in context"
                    )

            # Publish start event
            if node.emit_event:
                self._safe_publish_start(node.name)

            # Execute with retry
            start_t = time.monotonic()
            succeeded = False
            last_exc: Exception | None = None
            attempts = 0

            for attempt in range(node.retry.max_attempts):
                attempts = attempt
                try:
                    node.execute(self._context)
                    succeeded = True
                    break
                except Exception as exc:
                    # Let TurnCancelled propagate immediately — never retry or swallow
                    from memex.models import TurnCancelled

                    if isinstance(exc, TurnCancelled):
                        raise
                    last_exc = exc
                    if attempt < node.retry.max_attempts - 1 and node.retry.retryable(
                        exc
                    ):
                        time.sleep(node.retry.backoff_base**attempt)
                        continue
                    break

            end_t = time.monotonic()

            if succeeded:
                self._completed_nodes.add(node.name)
                entry = PhaseTraceEntry(
                    node_name=node.name,
                    started_at=start_t,
                    ended_at=end_t,
                    status="completed",
                    retry_count=attempts,
                )
                self._execution_trace.append(entry)
                self._update_trace_context()

                if node.emit_event:
                    self._safe_publish_completed(node.name, start_t, end_t)

                self._evaluate_outgoing(node.name)

                # Boundary check
                if self._boundary and node.name == self._boundary:
                    self._boundary_hit = True
                    return
            else:
                self._failed_nodes.add(node.name)
                entry = PhaseTraceEntry(
                    node_name=node.name,
                    started_at=start_t,
                    ended_at=end_t,
                    status="failed",
                    error=str(last_exc) if last_exc else None,
                    retry_count=attempts,
                )
                self._execution_trace.append(entry)
                self._update_trace_context()

                # Check fallback
                fb = self._graph.get_fallback_edge(node.name)
                if fb:
                    self._ready.appendleft(fb.target)
                    self._scheduled_nodes.add(fb.target)
                else:
                    self._cancel_descendants(node.name)

    # ------------------------------------------------------------------
    # Parallel execution
    # ------------------------------------------------------------------

    def _execute_parallel(self, targets: list[str]) -> None:
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=len(targets), thread_name_prefix="pg-gather"
        ) as pool:
            futures = [pool.submit(self._execute_chain, t) for t in targets]
            for f in concurrent.futures.as_completed(futures):
                f.result()  # re-raise thread exceptions in main thread

    def _execute_chain(self, name: str) -> None:
        node = self._graph.get_node(name)
        if node is None:
            return

        # Input validation (read-only, no lock needed)
        for key in node.inputs:
            if key not in self._context:
                raise RuntimeError(
                    f"Node '{node.name}' missing required input '{key}' in context"
                )

        # Execute with retry
        start_t = time.monotonic()
        succeeded = False
        last_exc: Exception | None = None
        attempts = 0

        for attempt in range(node.retry.max_attempts):
            attempts = attempt
            try:
                node.execute(self._context)
                succeeded = True
                break
            except Exception as exc:
                from memex.models import TurnCancelled

                if isinstance(exc, TurnCancelled):
                    raise
                last_exc = exc
                if attempt < node.retry.max_attempts - 1 and node.retry.retryable(exc):
                    time.sleep(node.retry.backoff_base**attempt)
                    continue
                break

        end_t = time.monotonic()

        if succeeded:
            with self._lock:
                self._completed_nodes.add(node.name)
                entry = PhaseTraceEntry(
                    node_name=node.name,
                    started_at=start_t,
                    ended_at=end_t,
                    status="completed",
                    retry_count=attempts,
                )
                self._execution_trace.append(entry)
            self._update_trace_context()

            # Evaluate outgoing edges within this thread
            self._evaluate_outgoing_chain(node.name)
        else:
            with self._lock:
                self._failed_nodes.add(node.name)
                entry = PhaseTraceEntry(
                    node_name=node.name,
                    started_at=start_t,
                    ended_at=end_t,
                    status="failed",
                    error=str(last_exc) if last_exc else None,
                    retry_count=attempts,
                )
                self._execution_trace.append(entry)
            self._update_trace_context()

            fb = self._graph.get_fallback_edge(node.name)
            if fb:
                with self._lock:
                    already = (
                        fb.target in self._completed_nodes
                        or fb.target in self._failed_nodes
                        or fb.target in self._cancelled_nodes
                        or fb.target in self._scheduled_nodes
                    )
                    if not already:
                        self._scheduled_nodes.add(fb.target)
                if not already:
                    self._execute_chain(fb.target)
            else:
                self._cancel_descendants(node.name)

    def _evaluate_outgoing_chain(self, source_name: str) -> None:
        edges = self._graph.get_outgoing_edges(source_name)
        sequential_targets: list[str] = []
        barrier_targets: list[str] = []

        for edge in edges:
            if edge.condition is not None and not edge.condition(self._context):
                continue
            barrier = self._graph.get_join_barrier(edge.target)
            with self._lock:
                already = (
                    edge.target in self._completed_nodes
                    or edge.target in self._failed_nodes
                    or edge.target in self._cancelled_nodes
                    or edge.target in self._scheduled_nodes
                )
                if not already:
                    self._scheduled_nodes.add(edge.target)
            if already:
                continue
            if barrier is not None:
                barrier_targets.append(edge.target)
            else:
                sequential_targets.append(edge.target)

        # Run sequential descendants within the same thread
        for target in sequential_targets:
            self._execute_chain(target)

        # Barrier targets go back to the main ready queue
        for target in barrier_targets:
            self._ready.append(target)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _evaluate_outgoing(self, source_name: str) -> None:
        edges = self._graph.get_outgoing_edges(source_name)
        parallel_targets: list[str] = []
        sequential_targets: list[str] = []

        for edge in edges:
            if edge.condition is None or edge.condition(self._context):
                with self._lock:
                    already = (
                        edge.target in self._completed_nodes
                        or edge.target in self._failed_nodes
                        or edge.target in self._cancelled_nodes
                        or edge.target in self._scheduled_nodes
                    )
                    if not already:
                        self._scheduled_nodes.add(edge.target)
                        if edge.parallel:
                            parallel_targets.append(edge.target)
                        else:
                            sequential_targets.append(edge.target)

        for target in sequential_targets:
            self._ready.append(target)

        if parallel_targets:
            self._execute_parallel(parallel_targets)

    def _is_barrier_satisfied(self, barrier) -> bool:
        for member in barrier.incoming:
            if member in self._completed_nodes:
                continue
            if member in self._failed_nodes:
                fb = self._graph.get_fallback_edge(member)
                if fb and fb.target in self._completed_nodes:
                    continue
                return False
            if member not in self._scheduled_nodes:
                # Vacuously complete
                continue
            # Still pending
            return False
        return True

    def _cancel_descendants(self, failed_node: str) -> None:
        # Find all nodes reachable from failed_node (read-only, no lock needed)
        reachable: set[str] = set()
        stack = [failed_node]
        while stack:
            current = stack.pop()
            for edge in self._graph.get_outgoing_edges(current):
                if (
                    edge.target not in reachable
                    and edge.target not in self._completed_nodes
                ):
                    reachable.add(edge.target)
                    stack.append(edge.target)

        # Only cancel nodes that have no other completed predecessor
        with self._lock:
            for name in reachable:
                if name in self._completed_nodes or name in self._failed_nodes:
                    continue
                # Check if any other completed node has an edge to this node
                has_other_path = False
                for edge in self._graph.edges:
                    if (
                        edge.target == name
                        and edge.source != failed_node
                        and edge.source in self._completed_nodes
                    ):
                        has_other_path = True
                        break
                if not has_other_path:
                    self._cancelled_nodes.add(name)
                    self._execution_trace.append(
                        PhaseTraceEntry(
                            node_name=name,
                            started_at=0.0,
                            ended_at=0.0,
                            status="cancelled",
                        )
                    )
        self._update_trace_context()

    def _finalize(self) -> None:
        self._update_trace_context()

    def _update_trace_context(self) -> None:
        self._context["execution_trace"] = list(self._execution_trace)
        self._context["phase_timings_ms"] = compute_phase_timings(self._execution_trace)

    def _safe_publish_start(self, node_name: str) -> None:
        from memex.event_bus import safe_publish

        safe_publish(
            PhaseStarted(
                node_name=node_name,
                turn_ordinal=self._context.get("turn_ordinal", 0),
            )
        )

    def _safe_publish_completed(
        self, node_name: str, start_t: float, end_t: float
    ) -> None:
        from memex.event_bus import safe_publish

        safe_publish(
            PhaseCompleted(
                node_name=node_name,
                turn_ordinal=self._context.get("turn_ordinal", 0),
                duration_ms=int((end_t - start_t) * 1000),
                status="completed",
            )
        )
