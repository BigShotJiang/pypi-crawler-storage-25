"""PhaseGraph data structures.

A phase graph is a directed acyclic graph (DAG) of computation nodes with
typed data flow, conditional edges, join barriers, fallback edges, and
boundary markers.  It synthesises workflow-net control flow, dataflow firing
semantics, FSM conditional transitions, and supervisory-control fallback
logic into a single structure suited to LLM agent orchestration.

See ``dev/notes/whitepaper-phase-graphs-for-llm-agents.md`` for the formal
background and design rules that this module implements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from collections.abc import Callable
from memex.phase_graph.retry import RetryPolicy


def _always_false(exc: Exception) -> bool:
    return False


@dataclass(frozen=True)
class PhaseNode:
    """A single computation step in the phase graph.

    ``inputs`` and ``outputs`` declare the context keys this node reads and
    writes.  The static validator uses these to prove input completeness and
    detect output conflicts at graph-construction time.
    """

    name: str
    execute: Callable[..., None]  # (TurnContext) -> None
    inputs: frozenset[str]
    outputs: frozenset[str]
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    checkpoint: bool = False
    emit_event: bool = True


@dataclass(frozen=True)
class PhaseEdge:
    """A directed edge between two nodes.

    When ``condition`` is set, the edge only fires if the predicate returns
    True for the current ``TurnContext``.  All edge predicates must be
    deterministic Python functions, never LLM calls (whitepaper rule 4.5).
    """

    source: str
    target: str
    condition: Callable[..., bool] | None = None
    label: str = ""
    parallel: bool = False


@dataclass(frozen=True)
class FallbackEdge:
    """Routes execution to a degraded-path node after retry exhaustion.

    Implements the supervisory-control "deterministic degradation" property:
    every uncontrollable failure leads to a legal terminal state rather than
    an unhandled exception (whitepaper rule 2.4 / Ramadge-Wonham).
    """

    source: str  # node that failed
    target: str  # fallback node to execute
    label: str = ""


@dataclass(frozen=True)
class JoinBarrier:
    """Synchronisation point that waits for all ``incoming`` branches.

    Modelled after the fork/join pattern in workflow nets (van der Aalst).
    A barrier is satisfied when every incoming node has either completed,
    completed via its fallback, or was never scheduled (vacuous completion).
    """

    name: str
    incoming: frozenset[str]  # node names that must complete


class GraphDefinitionError(Exception):
    """Raised when graph validation fails."""


@dataclass(frozen=True)
class PhaseGraph:
    """Immutable, validated phase graph definition.

    Construction triggers static validation (reachability, input completeness,
    output-conflict detection, join completeness, fallback coverage, cycle
    detection) so that an entire class of runtime failures becomes
    structurally impossible.
    """

    nodes: tuple[PhaseNode, ...]
    edges: tuple[PhaseEdge, ...]
    fallback_edges: tuple[FallbackEdge, ...] = ()
    join_barriers: tuple[JoinBarrier, ...] = ()
    entry_node: str = ""
    exclusive_output_pairs: frozenset[frozenset[str]] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        # Set entry_node to first node if not specified
        if not self.entry_node and self.nodes:
            object.__setattr__(self, "entry_node", self.nodes[0].name)
        # Run validation
        from memex.phase_graph.validation import validate_graph

        validate_graph(self)

    def get_node(self, name: str) -> PhaseNode | None:
        for n in self.nodes:
            if n.name == name:
                return n
        return None

    def get_outgoing_edges(self, node_name: str) -> list[PhaseEdge]:
        return [e for e in self.edges if e.source == node_name]

    def get_fallback_edge(self, node_name: str) -> FallbackEdge | None:
        for fe in self.fallback_edges:
            if fe.source == node_name:
                return fe
        return None

    def get_join_barrier(self, name: str) -> JoinBarrier | None:
        for jb in self.join_barriers:
            if jb.name == name:
                return jb
        return None

    @property
    def node_names(self) -> frozenset[str]:
        return frozenset(n.name for n in self.nodes)

    @property
    def barrier_names(self) -> frozenset[str]:
        return frozenset(jb.name for jb in self.join_barriers)
