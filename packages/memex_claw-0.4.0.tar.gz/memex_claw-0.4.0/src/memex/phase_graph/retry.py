"""Retry policies and predicate functions for PhaseGraph nodes."""

from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Callable


def _always_false(exc: Exception) -> bool:
    return False


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1  # 1 = no retry
    backoff_base: float = 2.0
    retryable: Callable[[Exception], bool] = _always_false


def _is_llm_error(exc: Exception) -> bool:
    """LiteLLM or network errors during LLM calls."""
    # Import lazily to avoid hard dependency
    try:
        from litellm.exceptions import APIError as LiteLLMError

        if isinstance(exc, LiteLLMError):
            return True
    except ImportError:
        pass
    return isinstance(exc, (ConnectionError, TimeoutError, OSError))


def _is_network_error(exc: Exception) -> bool:
    """Network errors (ConnectionError, Timeout, APIConnectionError, RateLimitError)."""
    try:
        from litellm.exceptions import (
            APIConnectionError,
            RateLimitError,
        )

        if isinstance(exc, (APIConnectionError, RateLimitError)):
            return True
    except ImportError:
        pass
    return isinstance(exc, (ConnectionError, TimeoutError))


def _is_timeout(exc: Exception) -> bool:
    return isinstance(exc, (TimeoutError, ConnectionError))


def _is_io_error(exc: Exception) -> bool:
    return isinstance(exc, (IOError, ConnectionError))
