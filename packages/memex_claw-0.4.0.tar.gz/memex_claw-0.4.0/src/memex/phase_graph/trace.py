"""Execution trace recording for PhaseGraph."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class PhaseTraceEntry:
    node_name: str
    started_at: float  # monotonic timestamp
    ended_at: float
    status: Literal["completed", "failed", "skipped", "fallback", "cancelled"]
    error: str | None = None
    retry_count: int = 0


# Map phase node names to the legacy phase_timings_ms keys used by run_turn()
_PHASE_TIMING_MAP: dict[str, str] = {
    "CLASSIFY": "classify",
    "SELECT_TOOLS": "tool_selection",
    "RETRIEVE": "retrieval",
    "PROACTIVE_CONTEXT": "proactive_context",
    "FACT_STORE": "fact_store",
    "BUILD_PROMPT": "prompt_build",
    "LLM_RESPOND": "llm",
    "TOOL_LOOP": "llm",  # tool loop time is part of llm timing
    "EXTRACT_REFLECT": "reflect",
    "APPLY_EXTRACTION": "reflect",
    "APPLY_REFLECT": "reflect",
}


def compute_phase_timings(trace: list[PhaseTraceEntry]) -> dict[str, int]:
    """Convert execution trace to legacy phase_timings_ms dict."""
    timings: dict[str, int] = {}
    for entry in trace:
        key = _PHASE_TIMING_MAP.get(entry.node_name)
        if key is None:
            continue
        ms = int((entry.ended_at - entry.started_at) * 1000)
        # Accumulate for nodes that share a timing key (e.g., reflect)
        timings[key] = timings.get(key, 0) + ms
    # Compute total from first to last entry
    if trace:
        total_ms = int((trace[-1].ended_at - trace[0].started_at) * 1000)
        timings["total"] = total_ms
    return timings
