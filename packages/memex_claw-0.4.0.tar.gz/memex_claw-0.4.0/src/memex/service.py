"""memex-service daemon — owns MemexAPI, Telegram, scheduler, and HttpGateway.

Start via: memex service
Managed by: systemctl --user start memex.service

This module blocks until SIGTERM or SIGINT. All resources are shut down cleanly
in the finally block.
"""

from __future__ import annotations

import json
import logging
import os
import queue
import signal
import threading
import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.session import SessionContext

logger = logging.getLogger(__name__)


class _ChatCancelled(Exception):
    """Raised inside on_token when a DELETE /v1/chat/{session_id} cancels a stream."""


class _ServiceState:
    """Shared mutable state for route handlers, extracted for testability."""

    def __init__(self) -> None:
        self.sessions: dict[str, SessionContext | None] = {}
        self.sessions_lock = threading.Lock()
        self.chat_cancel_events: dict[str, threading.Event] = {}
        self.chat_cancel_lock = threading.Lock()
        self.audio_captures: dict[str, Any] = {}
        self.audio_lock = threading.Lock()
        self.start_time: float = time.time()
        self.telegram_running = threading.Event()
        self.scheduler_started = threading.Event()

    def get_or_create_session(self, session_id: str) -> SessionContext | None:
        """Return the session for session_id, creating it if needed.

        Returns None if session creation fails (caller must handle).
        """
        with self.sessions_lock:
            if session_id not in self.sessions:
                try:
                    from memex.session import create_session

                    self.sessions[session_id] = create_session()
                except Exception:
                    logger.warning(
                        "Failed to create session %s; proceeding without session",
                        session_id,
                        exc_info=True,
                    )
                    self.sessions[session_id] = None
            return self.sessions[session_id]


def _register_routes(gateway: Any, api: Any, bridge: Any, state: _ServiceState) -> None:
    """Register all HTTP route handlers on *gateway*.

    Extracted from ``run()`` so that integration tests can boot the gateway
    with a mocked *api* and *bridge* without starting Telegram, the scheduler,
    or signal handlers.
    """
    from memex.http_gateway import HttpRequest, HttpResponse, HttpRoute
    from memex.interfaces.caller import CallerContext

    from memex.interfaces.json_util import model_to_dict as _to_dict

    def _make_caller(session_id: str = "service") -> CallerContext:
        return CallerContext(interface="service-http", session_id=session_id)

    def _parse_id(path: str, prefix: str) -> str:
        """Extract the first path segment after prefix."""
        return path[len(prefix) :].split("/")[0]

    def _req_json(req: HttpRequest) -> dict:
        try:
            return req.json or {}
        except Exception:
            logger.debug("_req_json: failed to parse request body", exc_info=True)
            return {}

    _GOAL_READONLY: frozenset[str] = frozenset(
        {"goal_id", "created_at", "updated_at", "last_touched_at"}
    )
    _MEETING_READONLY: frozenset[str] = frozenset(
        {"meeting_id", "created_at", "updated_at", "recordings"}
    )
    _RECORDING_READONLY: frozenset[str] = frozenset(
        {"recording_id", "meeting_id", "created_at", "updated_at"}
    )

    # Allowed mutable fields and their expected Python types
    _GOAL_FIELD_TYPES: dict[str, type] = {
        "title": str,
        "description": str,
        "status": str,
        "priority": str,
        "deadline": str,
        "blocked_reason": str,
        "failure_reason": str,
        "notes": str,
    }
    _MEETING_FIELD_TYPES: dict[str, type] = {
        "title": str,
        "notes": str,
        "attendees": list,
        "action_items": list,
        "scheduled_for": str,
    }
    _RECORDING_FIELD_TYPES: dict[str, type] = {
        "state": str,
        "error": str,
        "vad_threshold": float,
    }

    def _apply_validated_fields(
        obj: Any, body: dict, allowed_types: dict[str, type]
    ) -> list[str]:
        """Apply validated fields from body onto obj. Returns list of rejected field names."""
        rejected = []
        for k, v in body.items():
            if k not in allowed_types:
                rejected.append(k)
                continue
            expected = allowed_types[k]
            if not isinstance(v, (expected, type(None))):
                # Allow int where float is expected
                if expected is float and isinstance(v, int):
                    v = float(v)
                else:
                    rejected.append(k)
                    continue
            setattr(obj, k, v)
        return rejected

    # ------------------------------------------------------------------
    # Route handlers
    # ------------------------------------------------------------------

    # Health / Status
    def _health(req: HttpRequest) -> HttpResponse:
        return HttpResponse.json({"status": "ok"})

    def _status(req: HttpRequest) -> HttpResponse:
        return HttpResponse.json(
            {
                "version": _get_version(),
                "uptime_seconds": int(time.time() - state.start_time),
                "telegram_connected": state.telegram_running.is_set(),
                "scheduler_running": state.scheduler_started.is_set(),
                "active_sessions": len(state.sessions),
            }
        )

    # -- Goals --

    def _goals_collection(req: HttpRequest) -> HttpResponse:
        session_id = (
            _req_json(req).get("session_id", "service")
            if req.method == "POST"
            else "service"
        )
        caller = _make_caller(session_id)
        if req.method == "GET":
            query = req.query or ""
            include_all = "include_all=true" in query.lower()
            goals = api.intent(caller, include_all=include_all)
            return HttpResponse.json({"goals": _to_dict(goals)})
        # POST — create goal
        body = _req_json(req)
        try:
            from memex.models import Goal, GoalStatus

            now = utcnow()
            goal = Goal(
                goal_id=str(uuid.uuid4()),
                title=body.get("title", ""),
                description=body.get("description", ""),
                status=GoalStatus(body.get("status", "active")),
                created_at=now,
                updated_at=now,
                last_touched_at=now,
            )
            api.create_goal(goal)
            return HttpResponse.json(_to_dict(goal), status=201)
        except Exception as exc:
            return HttpResponse.error(str(exc), 400)

    def _goals_item(req: HttpRequest) -> HttpResponse:
        goal_id = _parse_id(req.path, "/v1/goals/")
        if req.method == "GET":
            goal = api.get_goal(goal_id)
            if goal is None:
                return HttpResponse.error("Not found", 404)
            return HttpResponse.json(_to_dict(goal))
        # PUT — update goal
        body = _req_json(req)
        try:
            goal = api.get_goal(goal_id)
            if goal is None:
                return HttpResponse.error("Not found", 404)
            rejected = _apply_validated_fields(goal, body, _GOAL_FIELD_TYPES)
            if rejected:
                return HttpResponse.error(
                    f"Unknown or invalid fields: {rejected}. Allowed: {list(_GOAL_FIELD_TYPES)}",
                    400,
                )
            goal.updated_at = utcnow()
            api.update_goal(goal)
            return HttpResponse.json(_to_dict(goal))
        except Exception as exc:
            return HttpResponse.error(str(exc), 400)

    # -- Meetings --

    def _meetings_collection(req: HttpRequest) -> HttpResponse:
        if req.method == "GET":
            meetings = api.list_meetings()
            return HttpResponse.json({"meetings": _to_dict(meetings)})
        # POST — create meeting
        body = _req_json(req)
        try:
            from memex.meetings.models import MeetingRecord, MeetingState

            now = utcnow()
            record = MeetingRecord(
                meeting_id=str(uuid.uuid4()),
                state=MeetingState.CREATED,
                title=body.get("title", ""),
                attendees=body.get("participants", body.get("attendees", [])),
                created_at=now,
                updated_at=now,
            )
            api.create_meeting(record)
            return HttpResponse.json(_to_dict(record), status=201)
        except Exception as exc:
            return HttpResponse.error(str(exc), 400)

    def _meetings_cleanup(req: HttpRequest) -> HttpResponse:
        count = api.cleanup_stale_recordings()
        return HttpResponse.json({"cleaned": count})

    def _meetings_item(req: HttpRequest) -> HttpResponse:
        """Handle /v1/meetings/{id} and /v1/meetings/{id}/record/start|stop|transcribe."""
        # Parse meeting_id and optional sub-path
        rest = req.path[len("/v1/meetings/") :]
        parts = rest.split("/", 1)
        meeting_id = parts[0]
        sub = parts[1] if len(parts) > 1 else ""

        if req.method == "GET" and not sub:
            meeting = api.get_meeting(meeting_id)
            if meeting is None:
                return HttpResponse.error("Not found", 404)
            return HttpResponse.json(_to_dict(meeting))

        if req.method == "PUT" and not sub:
            body = _req_json(req)
            try:
                meeting = api.get_meeting(meeting_id)
                if meeting is None:
                    return HttpResponse.error("Not found", 404)
                rejected = _apply_validated_fields(meeting, body, _MEETING_FIELD_TYPES)
                if rejected:
                    return HttpResponse.error(
                        f"Unknown or invalid fields: {rejected}. Allowed: {list(_MEETING_FIELD_TYPES)}",
                        400,
                    )
                meeting.updated_at = utcnow()
                api.update_meeting(meeting)
                return HttpResponse.json(_to_dict(meeting))
            except Exception as exc:
                return HttpResponse.error(str(exc), 400)

        if req.method == "DELETE" and not sub:
            api.delete_meeting(meeting_id)
            return HttpResponse(status=204)

        if req.method == "POST" and sub == "record/start":
            return _handle_record_start(meeting_id, api, state)

        if req.method == "POST" and sub == "record/stop":
            return _handle_record_stop(meeting_id, api, state)

        if req.method == "POST" and sub == "transcribe":
            return _handle_transcribe(meeting_id, api)

        return HttpResponse.error("Not found", 404)

    # -- Recordings --

    def _recordings_item(req: HttpRequest) -> HttpResponse:
        recording_id = _parse_id(req.path, "/v1/recordings/")
        if req.method == "GET":
            rec = api.get_recording(recording_id)
            if rec is None:
                return HttpResponse.error("Not found", 404)
            return HttpResponse.json(_to_dict(rec))
        if req.method == "PUT":
            body = _req_json(req)
            try:
                rec = api.get_recording(recording_id)
                if rec is None:
                    return HttpResponse.error("Not found", 404)
                rejected = _apply_validated_fields(rec, body, _RECORDING_FIELD_TYPES)
                if rejected:
                    return HttpResponse.error(
                        f"Unknown or invalid fields: {rejected}. Allowed: {list(_RECORDING_FIELD_TYPES)}",
                        400,
                    )
                rec.updated_at = utcnow()
                api.update_recording(rec)
                return HttpResponse.json(_to_dict(rec))
            except Exception as exc:
                return HttpResponse.error(str(exc), 400)
        return HttpResponse.error("Method not allowed", 405)

    # -- Scheduler --

    def _scheduler_tasks(req: HttpRequest) -> HttpResponse:
        tasks = api.list_tasks()
        return HttpResponse.json({"tasks": _to_dict(tasks)})

    def _scheduler_task_item(req: HttpRequest) -> HttpResponse:
        rest = req.path[len("/v1/scheduler/tasks/") :]
        parts = rest.split("/", 1)
        task_id = parts[0]
        sub = parts[1] if len(parts) > 1 else ""

        if req.method == "GET" and not sub:
            task = api.get_task(task_id)
            if task is None:
                return HttpResponse.error("Not found", 404)
            return HttpResponse.json(_to_dict(task))

        if req.method == "GET" and sub == "last-run":
            run_info = api.get_last_task_run(task_id)
            return HttpResponse.json(_to_dict(run_info))

        if req.method == "POST" and sub == "toggle":
            body = _req_json(req)
            enabled = bool(body.get("enabled", True))
            api.toggle_task(task_id, enabled)
            return HttpResponse.json({"status": "ok"})

        if req.method == "POST" and sub == "run":
            api.enqueue_work("scheduled_task", {"task_id": task_id})
            return HttpResponse.json({"status": "triggered"})

        return HttpResponse.error("Not found", 404)

    # -- Notifications --

    def _notifications_collection(req: HttpRequest) -> HttpResponse:
        query = req.query or ""
        unread_only = "unread_only=false" not in query.lower()
        notifs = api.list_notifications(unread_only=unread_only)
        return HttpResponse.json({"notifications": _to_dict(notifs)})

    def _notifications_item(req: HttpRequest) -> HttpResponse:
        notif_id = _parse_id(req.path, "/v1/notifications/")
        body = _req_json(req)
        action = body.get("action", "dismiss")
        api.act_on_notification(notif_id, action)
        return HttpResponse.json({"status": "ok"})

    # -- Meeting-Goal Links --

    def _meeting_goal_links(req: HttpRequest) -> HttpResponse:
        body = _req_json(req)
        try:
            from memex.models import MeetingGoalLink

            link = MeetingGoalLink(
                meeting_id=body.get("meeting_id", ""),
                goal_id=body.get("goal_id", ""),
                relationship=body.get("relationship", "explicit"),
                created_at=utcnow(),
            )
            api.create_meeting_goal_link(link)
            return HttpResponse.json(_to_dict(link), status=201)
        except Exception as exc:
            return HttpResponse.error(str(exc), 400)

    # -- Self-state / Search / Ingest --

    def _self_state(req: HttpRequest) -> HttpResponse:
        result = api.self_state(_make_caller())
        return HttpResponse.json(result)

    def _subagents(req: HttpRequest) -> HttpResponse:
        agents = api.list_subagents()
        return HttpResponse.json({"subagents": agents})

    def _sessions_item(req: HttpRequest) -> HttpResponse:
        session_id = _parse_id(req.path, "/v1/sessions/")
        if req.method == "DELETE":
            caller = _make_caller(session_id)
            api.end_session(caller)
            with state.sessions_lock:
                state.sessions.pop(session_id, None)
            return HttpResponse(status=204)
        return HttpResponse.error("Method not allowed", 405)

    def _search(req: HttpRequest) -> HttpResponse:
        body = _req_json(req)
        query = body.get("query", "")
        if not query:
            return HttpResponse.error("query required", 400)
        results = api.search(query, _make_caller())
        return HttpResponse.json({"results": results})

    def _ingest(req: HttpRequest) -> HttpResponse:
        body = _req_json(req)
        url = body.get("url")
        text = body.get("text")
        title = body.get("title")
        if url:
            result = api.ingest_url(url)
        elif text:
            result = api.ingest_content(text, title=title or "")
        else:
            return HttpResponse.error("url or text required", 400)
        return HttpResponse.json(result)

    # -- SSE: Chat --

    def _chat_sse(req: HttpRequest, send_event: Any) -> None:
        body = _req_json(req)
        message = body.get("message", "")
        session_id = body.get("session_id", str(uuid.uuid4()))

        if not message:
            send_event(
                "error", {"message": "message required", "code": "missing_message"}
            )
            return

        caller = _make_caller(session_id)
        session = state.get_or_create_session(session_id)
        if session is None:
            send_event(
                "error", {"message": "Session unavailable", "code": "session_error"}
            )
            return
        message_id = str(uuid.uuid4())

        cancel_event = threading.Event()
        with state.chat_cancel_lock:
            state.chat_cancel_events[session_id] = cancel_event

        def on_token(text: str) -> None:
            if cancel_event.is_set():
                raise _ChatCancelled()
            send_event("token", {"text": text})

        def on_event(event: Any) -> None:
            from memex.interfaces.event_bridge import _serialize_event

            event_type, data_json = _serialize_event(event)
            send_event(event_type, json.loads(data_json))

        try:
            _chat_t0 = time.monotonic()
            api.chat(
                message,
                caller,
                session=session,
                on_token=on_token,
                on_event=on_event,
            )
            logger.debug(
                "_chat_sse: api.chat returned in %.1fs, sending done",
                time.monotonic() - _chat_t0,
            )
            send_event("done", {"message_id": message_id, "session_id": session_id})
            logger.debug("_chat_sse: done event sent")
        except _ChatCancelled:
            send_event("interrupted", {})
        except Exception as exc:
            logger.error("Chat SSE error: %s", exc, exc_info=True)
            send_event("error", {"message": str(exc), "code": "chat_error"})
        finally:
            with state.chat_cancel_lock:
                state.chat_cancel_events.pop(session_id, None)

    def _chat_cancel(req: HttpRequest) -> HttpResponse:
        session_id = _parse_id(req.path, "/v1/chat/")
        with state.chat_cancel_lock:
            cancel_event = state.chat_cancel_events.get(session_id)
        if cancel_event is not None:
            cancel_event.set()
        return HttpResponse(status=204)

    # -- SSE: Domain events --

    _HEARTBEAT_INTERVAL = 25  # seconds

    def _events_sse(req: HttpRequest, send_event: Any) -> None:
        last_event_id_str = req.headers.get("Last-Event-ID") or req.headers.get(
            "last-event-id"
        )
        last_event_id: int | None = None
        if last_event_id_str:
            try:
                last_event_id = int(last_event_id_str)
            except ValueError:
                pass

        q: queue.SimpleQueue = queue.SimpleQueue()
        bridge.add_subscriber(q, last_event_id)

        try:
            last_heartbeat = time.time()
            while True:
                now = time.time()
                if now - last_heartbeat >= _HEARTBEAT_INTERVAL:
                    # Send heartbeat as SSE comment (no event: line)
                    send_event("heartbeat", {"ts": int(now)})
                    last_heartbeat = now

                try:
                    item = q.get(timeout=1.0)
                except queue.Empty:
                    continue

                if item is None:
                    # Shutdown sentinel
                    break

                event_type, data_json, event_id = item
                if event_type == "resync":
                    send_event("resync", json.loads(data_json), event_id)
                else:
                    payload = json.loads(data_json)
                    send_event(event_type, payload, event_id)
        finally:
            bridge.remove_subscriber(q)

    # ------------------------------------------------------------------
    # Register routes
    # ------------------------------------------------------------------

    # Health / Status
    gateway.register_route(HttpRoute("/v1/health", _health, methods={"GET"}))
    gateway.register_route(HttpRoute("/v1/status", _status, methods={"GET"}))

    # Resource telemetry
    def _telemetry_resources(req: HttpRequest) -> HttpResponse:
        from memex.resource_telemetry import get_telemetry_store

        store = get_telemetry_store()
        if store is None:
            return HttpResponse.json({"error": "telemetry not initialized"}, status=503)
        query = req.query or ""
        if "history=true" in query.lower():
            return HttpResponse.json({"snapshots": store.history()})
        return HttpResponse.json({"snapshot": store.latest()})

    gateway.register_route(
        HttpRoute("/v1/telemetry/resources", _telemetry_resources, methods={"GET"})
    )

    # Self-state / Search / Ingest
    gateway.register_route(HttpRoute("/v1/self-state", _self_state, methods={"GET"}))
    gateway.register_route(HttpRoute("/v1/search", _search, methods={"POST"}))
    gateway.register_route(HttpRoute("/v1/ingest", _ingest, methods={"POST"}))

    # Goals (exact collection, then prefix for ID-based)
    gateway.register_route(
        HttpRoute("/v1/goals", _goals_collection, methods={"GET", "POST"})
    )
    gateway.register_route(
        HttpRoute("/v1/goals/", _goals_item, methods={"GET", "PUT"}, match="prefix")
    )

    # Meetings (exact collection and cleanup, then prefix for ID-based)
    gateway.register_route(
        HttpRoute("/v1/meetings", _meetings_collection, methods={"GET", "POST"})
    )
    gateway.register_route(
        HttpRoute("/v1/meetings/cleanup", _meetings_cleanup, methods={"POST"})
    )
    gateway.register_route(
        HttpRoute(
            "/v1/meetings/",
            _meetings_item,
            methods={"GET", "PUT", "DELETE", "POST"},
            match="prefix",
        )
    )

    # Recordings
    gateway.register_route(
        HttpRoute(
            "/v1/recordings/", _recordings_item, methods={"GET", "PUT"}, match="prefix"
        )
    )

    # Scheduler
    gateway.register_route(
        HttpRoute("/v1/scheduler/tasks", _scheduler_tasks, methods={"GET"})
    )
    gateway.register_route(
        HttpRoute(
            "/v1/scheduler/tasks/",
            _scheduler_task_item,
            methods={"GET", "POST"},
            match="prefix",
        )
    )

    # Notifications
    gateway.register_route(
        HttpRoute("/v1/notifications", _notifications_collection, methods={"GET"})
    )
    gateway.register_route(
        HttpRoute(
            "/v1/notifications/", _notifications_item, methods={"POST"}, match="prefix"
        )
    )

    gateway.register_route(
        HttpRoute("/v1/meeting-goal-links", _meeting_goal_links, methods={"POST"})
    )

    # Subagents
    gateway.register_route(HttpRoute("/v1/subagents", _subagents, methods={"GET"}))

    # Sessions
    gateway.register_route(
        HttpRoute("/v1/sessions/", _sessions_item, methods={"DELETE"}, match="prefix")
    )

    # SSE: Chat and events
    gateway.register_route(
        HttpRoute("/v1/chat", methods={"POST"}, handler=None, sse_handler=_chat_sse)
    )
    gateway.register_route(
        HttpRoute("/v1/chat/", _chat_cancel, methods={"DELETE"}, match="prefix")
    )
    gateway.register_route(
        HttpRoute("/v1/events", methods={"GET"}, handler=None, sse_handler=_events_sse)
    )


def run(store_path: str, *, no_telegram: bool = False) -> None:
    """Start and run the memex service. Blocks until SIGTERM/SIGINT."""
    import fcntl
    import sys

    from memex.http_gateway import HttpGateway
    from memex.interfaces.api import MemexAPI
    from memex.interfaces.event_bridge import EventBridgeHandler
    from memex.paths import resolve_service_lock_file, resolve_service_url_file

    # --- exclusive instance lock (released automatically when process dies) ---
    lock_file = resolve_service_lock_file()
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    _lock_fd = lock_file.open("w")
    try:
        fcntl.flock(_lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print(
            f"Another memex service is already running "
            f"(lock held: {lock_file}).\n"
            "Stop it first, or check: systemctl --user status memex",
            file=sys.stderr,
        )
        _lock_fd.close()
        sys.exit(1)

    _shutdown = threading.Event()

    def _handle_signal(signum: int, frame: Any) -> None:
        logger.info("Signal %d received — initiating shutdown", signum)
        _shutdown.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    def _on_progress(msg: str) -> None:
        logger.info("startup: %s", msg)

    api = MemexAPI.create(store_path, on_progress=_on_progress)

    port = int(os.environ.get("MEMEX_SERVICE_PORT", "8321"))
    host = os.environ.get("MEMEX_SERVICE_HOST", "127.0.0.1")
    token = os.environ.get("MEMEX_SERVICE_TOKEN") or None

    gateway = HttpGateway(port=port, host=host, auth_token=token)
    bridge = EventBridgeHandler()
    state = _ServiceState()

    _register_routes(gateway, api, bridge, state)

    service_url = f"http://{host}:{port}"
    url_file = resolve_service_url_file()

    try:
        try:
            gateway.start()
        except OSError as exc:
            print(
                f"Cannot bind to {host}:{port}: {exc}\n"
                "Another process may already be using this port.\n"
                f"Override with MEMEX_SERVICE_PORT=<port>",
                file=sys.stderr,
            )
            sys.exit(1)  # finally block handles api.close() and lock release

        logger.info("Service HTTP gateway listening on %s:%d", host, port)

        url_file.parent.mkdir(parents=True, exist_ok=True)
        url_file.write_text(service_url + "\n")
        logger.info("Service URL written to %s", url_file)

        _start_scheduler(api, state.scheduler_started)
        logger.info("Scheduler started")

        # Initialize resource telemetry and take a baseline snapshot
        from memex.resource_telemetry import init_telemetry_store, run_collection

        rt_store = init_telemetry_store(runtime_registry=api.runtime_registry)
        fathom = getattr(api.store, "_fathom", None)
        try:
            run_collection(rt_store, fathom_store=fathom)
        except Exception:
            logger.debug("Initial resource telemetry collection failed", exc_info=True)

        if not no_telegram:
            _start_telegram(api, state.telegram_running)

        logger.info("Memex service ready")
        _sd_notify("READY=1")
        _watchdog_loop(_shutdown)

    finally:
        logger.info("Stopping Memex service...")
        _sd_notify("STOPPING=1")
        gateway.stop()
        api.close()
        url_file.unlink(missing_ok=True)
        _lock_fd.close()
        logger.info("Memex service stopped")


# ------------------------------------------------------------------
# systemd watchdog / notify helpers
# ------------------------------------------------------------------


def _sd_notify(state: str) -> None:
    """Send a sd_notify(3) message if $NOTIFY_SOCKET is set.

    Works without the ``systemd`` Python package by writing directly to the
    notify socket.  No-op when not running under systemd.
    """
    import socket

    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return
    try:
        if addr.startswith("@"):
            addr = "\0" + addr[1:]
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        try:
            sock.connect(addr)
            sock.sendall(state.encode())
        finally:
            sock.close()
    except Exception:
        logger.debug("sd_notify(%s) failed", state, exc_info=True)


def _watchdog_loop(shutdown_event: threading.Event) -> None:
    """Block until *shutdown_event* is set, pinging the systemd watchdog.

    If ``WATCHDOG_USEC`` is not set (i.e. not running under systemd with
    ``WatchdogSec``), this simply waits on the shutdown event.
    """
    watchdog_usec = os.environ.get("WATCHDOG_USEC")
    if not watchdog_usec:
        shutdown_event.wait()
        return
    # Ping at half the watchdog interval for safety margin.
    interval = int(watchdog_usec) / 1_000_000 / 2
    while not shutdown_event.is_set():
        _sd_notify("WATCHDOG=1")
        shutdown_event.wait(timeout=interval)


# ------------------------------------------------------------------
# Audio recording helpers
# ------------------------------------------------------------------


def _handle_record_start(
    meeting_id: str,
    api: Any,
    state: _ServiceState,
) -> Any:
    """Start audio capture for a meeting and update the recording row."""
    from memex.http_gateway import HttpResponse

    with state.audio_lock:
        if meeting_id in state.audio_captures:
            return HttpResponse.json({"status": "recording"})

    try:
        from memex.meetings.capture import AudioCapture
        from memex.meetings.models import MeetingRecording, MeetingState

        meeting = api.get_meeting(meeting_id)
        if meeting is None:
            return HttpResponse.error("Meeting not found", 404)

        store_path = api.db_path
        audio_dir = (
            Path(store_path).parent / "audio"
            if store_path
            else Path.home() / ".memex" / "audio"
        )
        settings = api.settings
        vad_threshold = settings.get_float("vad_threshold", default=0.1)
        device_val = settings.get_str("recording_device", default="")
        device: str | int | None = None
        if device_val:
            device = int(device_val) if device_val.lstrip("-").isdigit() else device_val

        capture = AudioCapture(audio_dir, sample_rate=16000, device=device)
        audio_path = capture.start(meeting_id)

        now = utcnow()
        meeting_store = api.store.meetings
        recording = MeetingRecording(
            recording_id=str(uuid.uuid4()),
            meeting_id=meeting_id,
            sequence_number=meeting_store.next_recording_sequence(meeting_id),
            state=MeetingState.RECORDING,
            audio_path=str(audio_path),
            sample_rate=16000,
            started_at=now,
            vad_threshold=vad_threshold,
            created_at=now,
            updated_at=now,
        )
        meeting_store.create_recording(recording)
        meeting.state = MeetingState.RECORDING
        meeting.started_at = meeting.started_at or now
        meeting.audio_path = str(audio_path)
        meeting_store.update_meeting(meeting)

        with state.audio_lock:
            state.audio_captures[meeting_id] = (capture, recording.recording_id)

        return HttpResponse.json(
            {"status": "recording", "recording_id": recording.recording_id}
        )

    except Exception as exc:
        logger.error(
            "Failed to start recording for meeting %s: %s",
            meeting_id,
            exc,
            exc_info=True,
        )
        return HttpResponse.error(str(exc), 500)


def _handle_record_stop(
    meeting_id: str,
    api: Any,
    state: _ServiceState,
) -> Any:
    """Stop audio capture for a meeting and update the recording row."""
    from memex.http_gateway import HttpResponse

    with state.audio_lock:
        entry = state.audio_captures.pop(meeting_id, None)

    if entry is None:
        return HttpResponse.error("No active recording for this meeting", 404)

    capture, recording_id = entry
    try:
        from memex.meetings.models import MeetingState

        path, duration = capture.stop()
        now = utcnow()
        meeting_store = api.store.meetings
        recording = meeting_store.get_recording(recording_id)
        if recording:
            recording.audio_path = str(path)
            recording.duration_seconds = duration
            recording.stopped_at = now
            recording.state = MeetingState.RECORDED
            meeting_store.update_recording(recording)

        meeting = api.get_meeting(meeting_id)
        if meeting:
            meeting.state = MeetingState.RECORDED
            meeting.stopped_at = now
            meeting.audio_path = str(path)
            meeting_store.update_meeting(meeting)

        return HttpResponse.json({"status": "stopped", "duration_seconds": duration})
    except Exception as exc:
        logger.error(
            "Failed to stop recording for meeting %s: %s",
            meeting_id,
            exc,
            exc_info=True,
        )
        return HttpResponse.error(str(exc), 500)


def _handle_transcribe(meeting_id: str, api: Any) -> Any:
    """Enqueue transcription for the latest recording of a meeting."""
    from memex.http_gateway import HttpResponse

    try:
        meeting = api.get_meeting(meeting_id)
        if meeting is None:
            return HttpResponse.error("Meeting not found", 404)

        # Find the most recent recorded recording
        recording = None
        for rec in reversed(meeting.recordings or []):
            from memex.meetings.models import MeetingState

            if rec.state == MeetingState.RECORDED:
                recording = rec
                break

        if recording is None:
            return HttpResponse.error("No recorded audio for this meeting", 404)

        api.enqueue_work(
            "transcribe_meeting",
            {"meeting_id": meeting_id, "recording_id": recording.recording_id},
        )
        return HttpResponse.json({"status": "queued"})
    except Exception as exc:
        return HttpResponse.error(str(exc), 500)


# ------------------------------------------------------------------
# Subsystem launchers
# ------------------------------------------------------------------


def _start_scheduler(api: Any, started: threading.Event) -> None:
    """Start the full SchedulerEngine — cron tick loop + work queue."""
    from memex.scheduler.engine import SchedulerEngine

    notification_store = getattr(api.store, "notifications", None)

    engine = SchedulerEngine(
        api.store.scheduler,
        api=api,
        memex_store=api.store,
        notification_store=notification_store,
        runtime_registry=api.runtime_registry,
    )
    engine.start()  # starts work queue + 60-second tick loop
    api.set_scheduler_engine(engine)
    started.set()


def _start_telegram(api: Any, running: threading.Event) -> None:
    """Start the Telegram bot in a background daemon thread."""
    from memex.interfaces.telegram import TelegramBot, config_from_env

    config = config_from_env()
    if config is None:
        logger.info("Telegram not configured (TELEGRAM_BOT_TOKEN unset) — skipping")
        return

    def _run() -> None:
        try:
            bot = TelegramBot(config, api)
            running.set()
            logger.info(
                "Telegram bot polling (%d allowed user(s))",
                len(config.allowed_user_ids),
            )
            bot.run()
        except Exception as exc:
            logger.error("Telegram bot exited with error: %s", exc, exc_info=True)
            try:
                ns = getattr(api, "notification_store", None)
                if ns is not None:
                    from memex.models import NotificationPriority
                    from memex.notifications import NotificationRouter

                    NotificationRouter(ns).notify(
                        title="Telegram bot crashed",
                        body=f"{type(exc).__name__}: {exc}",
                        priority=NotificationPriority.HIGH,
                        source="telegram:watchdog",
                    )
            except Exception:
                pass  # never block shutdown
        finally:
            running.clear()

    thread = threading.Thread(target=_run, daemon=True, name="memex-telegram")
    thread.start()


def _get_version() -> str:
    try:
        from memex import __version__

        return __version__
    except Exception:
        return "unknown"
