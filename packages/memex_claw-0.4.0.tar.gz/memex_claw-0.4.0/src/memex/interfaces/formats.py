"""ResponseFormat, SessionMode, and interface format presets."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


@dataclass(frozen=True)
class ResponseFormat:
    """Formatting constraints injected into the system prompt."""

    max_length: int = 0  # 0 = no limit
    verbosity: str = "normal"  # "terse", "normal", "verbose"
    markdown: bool = True
    emoji: bool | None = (
        None  # None = no constraint, False = no emoji, True = allow emoji
    )
    paragraph_hint: str = ""  # e.g. "Keep responses to 2-3 paragraphs"

    def as_prompt_section(self) -> str:
        """Render as a system prompt section."""
        parts: list[str] = ["## Response Format"]
        if self.max_length:
            parts.append(f"- Maximum response length: {self.max_length} characters")
        if self.verbosity == "terse":
            parts.append("- Be concise. Use short sentences. Skip pleasantries.")
        elif self.verbosity == "verbose":
            parts.append("- Be thorough. Explain reasoning. Provide examples.")
        if not self.markdown:
            parts.append("- Do NOT use markdown formatting. Use plain text only.")
        if self.emoji is False:
            parts.append("- Do NOT use emoji.")
        if self.paragraph_hint:
            parts.append(f"- {self.paragraph_hint}")
        if len(parts) == 1:
            return ""  # No constraints
        return "\n".join(parts)


class SessionMode(str, Enum):
    """Session interaction modes."""

    NORMAL = "normal"
    DEEP_WORK = "deep_work"
    REVIEW = "review"
    QUICK_CHECK = "quick_check"


_MODE_DESCRIPTIONS: dict[SessionMode, str] = {
    SessionMode.NORMAL: "Standard interaction — balanced conversation and goal tracking.",
    SessionMode.DEEP_WORK: (
        "Deep focus mode. Minimize interruptions. Surface only critical notifications. "
        "Defer approvals. Keep responses focused on the active task."
    ),
    SessionMode.DEEP_WORK: (
        "Deep focus mode. Minimize interruptions. Surface only critical notifications. "
        "Defer approvals. Keep responses focused on the active task."
    ),
    SessionMode.REVIEW: (
        "Review mode. Surface pending approvals, stale goals, and deferred items. "
        "Proactively suggest completions and cleanup."
    ),
    SessionMode.QUICK_CHECK: (
        "Quick check-in. Be terse. Lead with status updates and blockers. "
        "Skip detailed explanations unless asked."
    ),
}


def get_mode_description(mode: SessionMode) -> str:
    """Get the system prompt section for a session mode."""
    return _MODE_DESCRIPTIONS.get(mode, "")


def get_mode_prompt(mode: SessionMode) -> str:
    """Render mode as a system prompt section."""
    desc = get_mode_description(mode)
    if not desc:
        return ""
    return f"## Session Mode: {mode.value}\n{desc}"


# Preset formats per interface
INTERFACE_FORMATS: dict[str, ResponseFormat] = {
    "cli": ResponseFormat(
        verbosity="normal",
        markdown=True,
    ),
    "telegram": ResponseFormat(
        verbosity="normal",
        markdown=False,
    ),
    "tui": ResponseFormat(
        verbosity="normal",
        markdown=True,
    ),
    "mcp": ResponseFormat(
        verbosity="normal",
        markdown=True,
    ),
}
