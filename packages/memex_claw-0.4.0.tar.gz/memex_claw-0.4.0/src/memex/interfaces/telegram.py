"""Telegram bot interface for Memex — async check-ins and content capture.

Polling-based bot with user ID authentication and silent rejection.
Integrates with the existing run_turn loop for message handling.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import threading
from datetime import date
from typing import Any

from pydantic import BaseModel
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


class TelegramConfig(BaseModel):
    """Telegram bot configuration — loaded from environment variables."""

    bot_token: str
    allowed_user_ids: set[int]
    owner_chat_id: int | None = None
    poll_interval: float = 1.0
    poll_timeout: int = 10
    default_mode: str = "quick_check"
    batch_window_seconds: int = 30
    max_message_length: int = 4096


def config_from_env() -> TelegramConfig | None:
    """Build TelegramConfig from environment variables.

    Returns None if required variables are missing.
    """
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    user_id_str = os.environ.get("TELEGRAM_USER_ID")

    if not token or not user_id_str:
        return None

    try:
        user_ids = {int(uid.strip()) for uid in user_id_str.split(",") if uid.strip()}
    except ValueError:
        logger.warning("Invalid TELEGRAM_USER_ID: %s", user_id_str)
        return None

    if not user_ids:
        return None

    return TelegramConfig(
        bot_token=token,
        allowed_user_ids=user_ids,
        poll_interval=float(os.environ.get("MEMEX_TELEGRAM_POLL_INTERVAL", "1")),
        batch_window_seconds=int(os.environ.get("MEMEX_TELEGRAM_BATCH_WINDOW", "30")),
    )


def split_at_paragraphs(text: str, max_length: int = 4000) -> list[str]:
    """Split text at paragraph boundaries for Telegram's 4096-char limit.

    Preserves paragraph structure. Falls back to hard split if a single
    paragraph exceeds max_length.
    """
    if len(text) <= max_length:
        return [text]

    paragraphs = text.split("\n\n")
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        candidate = (current + "\n\n" + para).strip() if current else para
        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
            # If single paragraph exceeds limit, hard-split it
            if len(para) > max_length:
                while para:
                    chunks.append(para[:max_length])
                    para = para[max_length:]
                current = ""
            else:
                current = para

    if current:
        chunks.append(current)

    return chunks


_URL_PATTERN = re.compile(
    r"https?://[^\s<>\"\')]+",
    re.IGNORECASE,
)
_FAST_URL_CAPTURE_WORDS = {
    "article",
    "bookmark",
    "can",
    "keep",
    "later",
    "link",
    "me",
    "please",
    "pls",
    "remember",
    "save",
    "store",
    "this",
    "url",
    "you",
}


class TelegramBot:
    """Telegram bot that connects Memex to Telegram via long-polling.

    Uses MemexAPI for all core interactions.
    """

    _LLM_CHECK_TTL = 30.0  # seconds between health re-checks

    def __init__(
        self,
        config: TelegramConfig,
        api: Any,
    ) -> None:
        self.config = config
        self._api = api
        self._session: Any = None  # SessionContext, cached
        self._session_date: str = ""  # Track day for session reset
        self._app: Any = None  # telegram.ext.Application
        self._owner_lock = threading.Lock()
        self._llm_available: bool = True
        self._llm_check_ts: float = 0.0
        self._last_operation_stats: dict[str, Any] | None = None
        self._background_tasks: set[asyncio.Task[Any]] = set()

    def _get_caller(self) -> Any:
        """Get a CallerContext with per-day session scoping."""
        from memex.interfaces.caller import CallerContext

        today = date.today().isoformat()
        if today != self._session_date:
            self._session_date = today
            self._session = None  # Reset session on new day

        session_id = f"telegram_{today}"
        return CallerContext.owner("telegram", session_id)

    async def _auth_check(self, update: Any) -> bool:
        """Check if the user is authorized. Returns False for unauthorized."""
        user = update.effective_user
        if user is None or user.id not in self.config.allowed_user_ids:
            if user:
                # Log user ID only, never message content (C-P4.6-2)
                logger.warning("Rejected message from unauthorized user: %d", user.id)
            return False
        return True

    def _check_llm_available(self) -> bool:
        """Cached LLM availability check (re-probes at most every _LLM_CHECK_TTL seconds)."""
        import time
        from memex.llm import is_llm_available

        now = time.monotonic()
        if now - self._llm_check_ts >= self._LLM_CHECK_TTL:
            self._llm_available = is_llm_available()
            self._llm_check_ts = now
        return self._llm_available

    def _run_turn(self, text: str) -> str:
        """Run a turn through MemexAPI synchronously."""
        caller = self._get_caller()
        response, self._session = self._api.chat(
            text,
            caller,
            session=self._session,
        )
        return response

    async def _send_response(self, message: Any, response: str) -> None:
        """Send response, splitting at paragraph boundaries if needed."""
        chunks = split_at_paragraphs(response, max_length=4000)

        for i, chunk in enumerate(chunks):
            if len(chunks) > 1:
                suffix = f"\n\n({i + 1}/{len(chunks)})"
                chunk = chunk + suffix
            await message.reply_text(chunk)

    def _project_ingest_result(self, result: dict[str, Any]) -> dict[str, Any]:
        projected = {
            "item_id": result.get("item_id"),
            "document_id": result.get("document_id"),
            "title": result.get("title"),
            "source_url": result.get("source_url"),
            "ingest_run_id": result.get("ingest_run_id"),
            "fallback_used": bool(result.get("fallback_used", False)),
        }
        operation_stats = result.get("operation_stats")
        if isinstance(operation_stats, dict):
            projected["operation_stats"] = operation_stats
        return projected

    def _build_url_ingest_stats(
        self,
        *,
        urls: list[str],
        ingested: list[dict[str, Any]],
        failed: list[str],
        mode: str,
        status: str,
        phase_timings_ms: dict[str, int] | None = None,
    ) -> dict[str, Any]:
        per_url = [self._project_ingest_result(item) for item in ingested]
        aggregate_phase_timings = {"extract": 0, "project": 0, "summary": 0, "total": 0}
        aggregate_total_ms = 0
        for item in ingested:
            operation_stats = item.get("operation_stats")
            if not isinstance(operation_stats, dict):
                continue
            phase_timings = operation_stats.get("phase_timings_ms") or {}
            for key in aggregate_phase_timings:
                aggregate_phase_timings[key] += int(phase_timings.get(key, 0) or 0)
            aggregate_total_ms += int(operation_stats.get("total_ms", 0) or 0)
        stats = {
            "mode": mode,
            "status": status,
            "url_count": len(urls),
            "ingested_count": len(ingested),
            "failed_count": len(failed),
            "per_url": per_url,
            "failed_urls": list(failed),
            "aggregate_operation_stats": {
                "phase_timings_ms": aggregate_phase_timings,
                "total_ms": aggregate_total_ms,
            },
        }
        if phase_timings_ms is not None:
            stats["phase_timings_ms"] = dict(phase_timings_ms)
        return stats

    def _track_background_task(self, task: asyncio.Task[Any]) -> None:
        self._background_tasks.add(task)

        def _cleanup(done: asyncio.Task[Any]) -> None:
            self._background_tasks.discard(done)
            try:
                done.result()
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.warning("Telegram background task failed", exc_info=True)
                try:
                    ns = getattr(self._api, "notification_store", None)
                    if ns is not None:
                        from memex.models import NotificationPriority
                        from memex.notifications import NotificationRouter

                        NotificationRouter(ns).notify(
                            title="Telegram background task failed",
                            body=f"{type(exc).__name__}: {exc}",
                            priority=NotificationPriority.HIGH,
                            source="telegram:background",
                        )
                except Exception:
                    pass  # never block cleanup

        task.add_done_callback(_cleanup)

    async def _cancel_background_tasks(self) -> None:
        if not self._background_tasks:
            return
        tasks = list(self._background_tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self._background_tasks.clear()

    def _schedule_background_url_ingest(self, message: Any, urls: list[str]) -> None:
        task = asyncio.create_task(self._finish_background_url_ingest(message, urls))
        self._track_background_task(task)

    async def _finish_background_url_ingest(
        self,
        message: Any,
        urls: list[str],
    ) -> None:
        import time

        start = time.monotonic()
        loop = asyncio.get_event_loop()
        try:
            ingested, failed = await loop.run_in_executor(
                None,
                self._auto_ingest_urls_detailed,
                urls,
            )
        except Exception:
            logger.warning("Background Telegram URL ingest failed", exc_info=True)
            self._last_operation_stats = {
                **(self._last_operation_stats or {}),
                "url_ingest": self._build_url_ingest_stats(
                    urls=urls,
                    ingested=[],
                    failed=urls,
                    mode="background",
                    status="failed",
                    phase_timings_ms={"ingest": int((time.monotonic() - start) * 1000)},
                ),
            }
            return

        if ingested:
            titles = "\n".join(
                f"- {item.get('title') or item.get('source_url') or 'Untitled'}"
                for item in ingested
            )
            try:
                await message.reply_text(f"Auto-saved:\n{titles}")
            except Exception:
                logger.debug("Failed to send Telegram auto-save reply", exc_info=True)
        if failed:
            failed_list = "\n".join(f"- {u}" for u in failed)
            try:
                await message.reply_text(
                    f"Could not save {len(failed)} URL(s):\n{failed_list}"
                )
            except Exception:
                logger.debug(
                    "Failed to send Telegram auto-save failure reply", exc_info=True
                )

        updated_stats = dict(self._last_operation_stats or {})
        updated_stats["url_ingest"] = self._build_url_ingest_stats(
            urls=urls,
            ingested=ingested,
            failed=failed,
            mode="background",
            status="completed" if ingested or not failed else "failed",
            phase_timings_ms={"ingest": int((time.monotonic() - start) * 1000)},
        )
        self._last_operation_stats = updated_stats

    async def handle_message(self, update: Any, context: Any) -> None:
        """Handle plain text messages — the main conversational handler."""
        if not await self._auth_check(update):
            return

        message = update.message
        if not message or not message.text:
            return

        # Auto-capture chat ID on first message (thread-safe)
        with self._owner_lock:
            if self.config.owner_chat_id is None:
                self.config.owner_chat_id = message.chat_id
                logger.info("Registered owner chat ID: %d", message.chat_id)

        # Typing indicator
        try:
            await context.bot.send_chat_action(chat_id=message.chat_id, action="typing")
        except Exception:
            pass  # Non-critical — don't fail on typing indicator

        loop = asyncio.get_event_loop()

        # Record receipt in intake_log before any processing
        from memex.models import ActionType as _AT

        caller = self._get_caller()
        intake_id: int | None = await loop.run_in_executor(
            None,
            lambda: self._api.record_intake(
                "telegram",
                _AT.TELEGRAM_MESSAGE.value,
                {
                    "text": message.text,
                    "chat_id": message.chat_id,
                    "session_id": caller.session_id,
                },
            ),
        )

        urls = _URL_PATTERN.findall(message.text)
        if self._is_fast_url_capture_message(message.text, urls):
            await self._handle_fast_url_capture(
                message,
                loop,
                urls,
                intake_id=intake_id,
            )
            return

        # Pre-flight LLM check (cached, ≤30s stale)
        llm_up = await loop.run_in_executor(None, self._check_llm_available)
        if not llm_up:
            await self._queue_message(message, loop, intake_id=intake_id)
            return

        # Run turn in executor to avoid blocking the event loop
        try:
            response = await loop.run_in_executor(None, self._run_turn, message.text)
            runtime_stats = None
            if self._session is not None:
                runtime_stats = self._session.working_memory.get("_turn_runtime_stats")
            if urls:
                self._last_operation_stats = {
                    "path": "telegram_mixed_url_message",
                    "used_llm": True,
                    "turn_runtime_stats": runtime_stats,
                    "phase_timings_ms": dict(
                        (runtime_stats or {}).get("phase_timings_ms") or {}
                    ),
                    "url_ingest": {
                        "mode": "background",
                        "status": "scheduled",
                        "url_count": len(urls),
                        "ingested_count": 0,
                        "failed_count": 0,
                        "per_url": [],
                        "failed_urls": [],
                    },
                }
            else:
                self._last_operation_stats = runtime_stats
        except Exception as exc:
            logger.error("Error processing message: %s", exc)
            # Check if LLM went down during processing
            self._llm_check_ts = 0.0  # force re-check
            llm_still_up = await loop.run_in_executor(None, self._check_llm_available)
            if not llm_still_up:
                await self._queue_message(message, loop, intake_id=intake_id)
            else:
                if intake_id is not None:
                    err_msg = str(exc)
                    await loop.run_in_executor(
                        None,
                        lambda: self._api.update_intake_status(
                            intake_id, "failed", error=err_msg
                        ),
                    )
                await message.reply_text(
                    "Sorry, I encountered an error processing your message."
                )
            return

        # Mark as processed before sending response (failure to send is UI, not intake)
        if intake_id is not None:
            await loop.run_in_executor(
                None,
                lambda: self._api.update_intake_status(intake_id, "processed"),
            )

        await self._send_response(message, response)

        if urls:
            self._schedule_background_url_ingest(message, urls)

    async def _queue_message(
        self, message: Any, loop: Any, *, intake_id: int | None = None
    ) -> None:
        """Queue a Telegram message for retry when LLM becomes available."""
        from memex.models import ActionType

        action_data = {
            "text": message.text,
            "chat_id": message.chat_id,
            "session_id": self._get_caller().session_id,
            "intake_id": intake_id or 0,
        }
        run_id = await loop.run_in_executor(
            None,
            lambda: self._api.enqueue_work(
                ActionType.TELEGRAM_MESSAGE.value,
                action_data,
                priority=2,
            ),
        )
        if intake_id and run_id:
            await loop.run_in_executor(
                None,
                lambda: self._api.update_intake_status(
                    intake_id, "queued", run_id=run_id
                ),
            )
        from memex.llm import get_proxy_status

        proxy = get_proxy_status()
        if run_id is not None:
            if proxy["disabled"] and proxy["seconds_until_retry"] > 5:
                eta = int(proxy["seconds_until_retry"])
                reply = (
                    f"Message queued — AI proxy is temporarily unavailable "
                    f"(retry in ~{eta}s). Memex will respond automatically when it recovers."
                )
            else:
                reply = "Message queued — Memex will respond shortly."
        else:
            if proxy["disabled"]:
                reply = (
                    "AI is temporarily unavailable (proxy unreachable). "
                    "Message could not be queued — please try again shortly."
                )
            else:
                reply = (
                    "AI is temporarily unavailable. "
                    "Message could not be queued (scheduler not running). "
                    "Please try again shortly."
                )
        await message.reply_text(reply)

    def _is_fast_url_capture_message(
        self,
        text: str,
        urls: list[str] | None = None,
    ) -> bool:
        urls = urls if urls is not None else _URL_PATTERN.findall(text)
        if not urls:
            return False
        stripped = _URL_PATTERN.sub(" ", text.lower())
        words = re.findall(r"[a-z0-9']+", stripped)
        if not words:
            return True
        return len(words) <= 6 and all(
            word in _FAST_URL_CAPTURE_WORDS for word in words
        )

    def _build_fast_url_capture_reply(
        self,
        ingested: list[dict[str, Any]],
        *,
        failed: list[str],
    ) -> str:
        if not ingested:
            return (
                "I couldn't save that URL right now."
                if failed
                else "I couldn't save that URL."
            )

        if len(ingested) == 1:
            item = ingested[0]
            title = item.get("title") or item.get("source_url") or "Untitled"
            summary = (item.get("summary") or "").strip()
            if summary:
                return f'Saved "{title}".\n\n{summary}'
            return f'Saved "{title}" to your knowledge store.'

        lines = [f"Saved {len(ingested)} URLs to your knowledge store:"]
        for item in ingested[:5]:
            title = item.get("title") or item.get("source_url") or "Untitled"
            lines.append(f"- {title}")
        if len(ingested) > 5:
            lines.append(f"- and {len(ingested) - 5} more")
        return "\n".join(lines)

    async def _handle_fast_url_capture(
        self,
        message: Any,
        loop: Any,
        urls: list[str],
        *,
        intake_id: int | None = None,
    ) -> None:
        import time

        total_start = time.monotonic()
        await message.reply_text("Saving that URL now.")
        ingest_start = time.monotonic()
        ingested, failed = await loop.run_in_executor(
            None,
            self._auto_ingest_urls_detailed,
            urls,
        )
        ingest_ms = int((time.monotonic() - ingest_start) * 1000)

        if intake_id is not None:
            await loop.run_in_executor(
                None,
                lambda: self._api.update_intake_status(
                    intake_id,
                    "processed" if ingested else "failed",
                    error="" if ingested else "all URL ingests failed",
                ),
            )

        reply = self._build_fast_url_capture_reply(ingested, failed=failed)
        await self._send_response(message, reply)

        if ingested:
            titles = "\n".join(
                f"- {item.get('title') or item.get('source_url') or 'Untitled'}"
                for item in ingested
            )
            await message.reply_text(f"Auto-saved:\n{titles}")
        if failed:
            failed_list = "\n".join(f"- {u}" for u in failed)
            await message.reply_text(
                f"Could not save {len(failed)} URL(s):\n{failed_list}"
            )

        self._last_operation_stats = {
            "path": "telegram_url_capture",
            "used_llm": False,
            "url_count": len(urls),
            "ingested_count": len(ingested),
            "failed_count": len(failed),
            "phase_timings_ms": {
                "ingest": ingest_ms,
                "total": int((time.monotonic() - total_start) * 1000),
            },
            "url_ingest": self._build_url_ingest_stats(
                urls=urls,
                ingested=ingested,
                failed=failed,
                mode="inline",
                status="completed" if ingested or not failed else "failed",
                phase_timings_ms={
                    "ingest": ingest_ms,
                    "total": int((time.monotonic() - total_start) * 1000),
                },
            ),
        }

    def _auto_ingest_urls(self, urls: list[str]) -> tuple[list[str], list[str]]:
        """Ingest URLs into the knowledge store.

        Returns (ingested_titles, failed_urls).
        Dedup is handled by the intake pipeline (find_by_url).
        Failures are logged but never raised.
        """
        ingested, failed = self._auto_ingest_urls_detailed(urls)
        return [
            item.get("title") or item.get("source_url") or "Untitled"
            for item in ingested
        ], failed

    def _auto_ingest_urls_detailed(
        self,
        urls: list[str],
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """Ingest URLs and preserve structured result details for interface replies."""
        ingested: list[dict[str, Any]] = []
        failed: list[str] = []
        session_id = self._get_caller().session_id
        for url in urls:
            result = self._api.ingest_url(
                url,
                session_id=session_id,
                trigger_surface="telegram",
                ingest_kind="telegram_url",
            )
            if result:
                ingested.append(result)
            else:
                failed.append(url)
                logger.warning("Failed to auto-ingest URL: %s", url)
        return ingested, failed

    async def handle_audio(self, update: Any, context: Any) -> None:
        """Handle voice and audio file messages — classify then transcribe or discard."""
        if not await self._auth_check(update):
            return

        message = update.message
        if not message:
            return

        # voice = recorded in-app; audio = uploaded file
        tg_file_obj = message.voice or message.audio
        if tg_file_obj is None:
            return

        filename = (
            getattr(tg_file_obj, "file_name", None)
            or f"audio_{tg_file_obj.file_id}.ogg"
        )

        import tempfile
        from pathlib import Path
        from memex.auto_ingest.audio_classify import build_discard_note, classify_audio

        suffix = Path(filename).suffix.lower() or ".ogg"
        fd, tmp_name = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        tmp_path = Path(tmp_name)
        loop = asyncio.get_event_loop()

        try:
            await context.bot.send_chat_action(chat_id=message.chat_id, action="typing")
        except Exception:
            pass

        try:
            tg_file = await context.bot.get_file(tg_file_obj.file_id)
            await tg_file.download_to_drive(str(tmp_path))

            classified = await loop.run_in_executor(None, classify_audio, tmp_path)

            if classified.is_speech:
                import shutil
                import uuid

                from memex.meetings import submit_transcription
                from memex.meetings.models import MeetingRecord, MeetingState

                meeting_id = str(uuid.uuid4())
                now = utcnow()

                audio_dir = Path(self._api._store_path).parent / "audio"
                audio_dir.mkdir(parents=True, exist_ok=True)
                stable_path = audio_dir / f"{meeting_id}{suffix}"
                shutil.move(str(tmp_path), str(stable_path))
                tmp_path = stable_path  # noqa: PLW2901  (finally unlink is now a no-op)

                meeting_store = getattr(self._api._store, "meetings", None)
                if meeting_store is None:
                    logger.warning(
                        "Telegram audio skipped — no meeting store available"
                    )
                    return
                record = MeetingRecord(
                    meeting_id=meeting_id,
                    state=MeetingState.RECORDED,
                    title=f"Telegram voice — {now.strftime('%Y-%m-%d %H:%M')}",
                    audio_path=str(stable_path),
                    started_at=now,
                    stopped_at=now,
                    notes=f"telegram://audio/{tg_file_obj.file_id}|chat_id={message.chat_id}",
                )
                await loop.run_in_executor(None, meeting_store.create_meeting, record)

                engine = self._api._scheduler_engine
                if engine is not None:
                    run_id = await loop.run_in_executor(
                        None,
                        submit_transcription,
                        meeting_id,
                        engine.work_queue,
                        self._api._store.scheduler,
                    )
                    logger.info(
                        "Telegram audio %s queued for transcription (meeting %s, run %d)",
                        filename,
                        meeting_id[:8],
                        run_id,
                    )
                    await message.reply_text(
                        "Voice memo received — transcribing in the background. "
                        "I'll notify you when it's done."
                    )
                else:
                    logger.warning(
                        "Telegram audio %s: no scheduler engine, meeting created but not enqueued",
                        filename,
                    )
                    await message.reply_text(
                        "Voice memo saved — scheduler unavailable, "
                        "transcription will run on next restart."
                    )
            else:
                label, content = build_discard_note(classified)
                session_id = self._get_caller().session_id
                await loop.run_in_executor(
                    None,
                    lambda: self._api.ingest_content(
                        content,
                        title=label,
                        source_url=f"telegram://audio/{tg_file_obj.file_id}",
                        item_type="note",
                        tags=["audio-discard", "non-speech", "telegram"],
                        session_id=session_id,
                    ),
                )
                await message.reply_text(
                    f"Audio discarded: {label}\n"
                    f"Classified as non-voice (speech ratio: {classified.speech_ratio:.0%}). "
                    f"Tags saved."
                )
        except Exception as exc:
            logger.error("Audio handling failed for %s: %s", filename, exc)
            await message.reply_text("Failed to process audio file.")
        finally:
            tmp_path.unlink(missing_ok=True)

    async def handle_command_status(self, update: Any, context: Any) -> None:
        """Handle /status command — show system status."""
        if not await self._auth_check(update):
            return

        message = update.message
        if not message:
            return

        caller = self._get_caller()
        status = self._api.status(caller)

        lines = ["Memex Status\n"]

        for c in status.get("connectors", []):
            icon = "+" if c["status"] == "connected" else "-"
            detail = ""
            if c["tools"] > 0:
                detail = f" ({c['tools']} tools)"
            elif c["error"]:
                detail = f" ({c['error']})"
            lines.append(f"[{icon}] {c['name']}: {c['status']}{detail}")

        active = status.get("goals_active", 0)
        total = status.get("goals_total", 0)
        lines.append(f"\n{active} active goals ({total} total)")

        await message.reply_text("\n".join(lines))

    async def handle_command_search(self, update: Any, context: Any) -> None:
        """Handle /search <query> command."""
        if not await self._auth_check(update):
            return

        message = update.message
        if not message:
            return

        query = " ".join(context.args) if context.args else ""
        if not query:
            await message.reply_text("Usage: /search <query>")
            return

        # Use run_turn with a search-oriented prompt
        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None, self._run_turn, f"Search for: {query}"
            )
        except Exception as exc:
            logger.error("Search error: %s", exc)
            await message.reply_text("Search failed.")
            return

        await self._send_response(message, response)

    async def handle_forwarded(self, update: Any, context: Any) -> None:
        """Handle forwarded messages — ingest as content."""
        if not await self._auth_check(update):
            return

        message = update.message
        if not message:
            return

        content = message.text or message.caption or ""
        if not content:
            await message.reply_text("No text content to capture.")
            return

        # Ingest via run_turn with ingest-oriented prompt
        ingest_prompt = (
            f"Ingest the following content captured via Telegram forward:\n\n{content}"
        )

        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(None, self._run_turn, ingest_prompt)
        except Exception as exc:
            logger.error("Ingest error: %s", exc)
            await message.reply_text("Failed to capture content.")
            return

        await message.reply_text(f"Captured.\n\n{response[:500]}")

    def build_application(self) -> Any:
        """Build and return the telegram Application with handlers registered."""
        from telegram.ext import (
            Application,
            CommandHandler,
            MessageHandler,
            filters,
        )

        self._app = Application.builder().token(self.config.bot_token).build()

        # Command handlers
        self._app.add_handler(CommandHandler("status", self.handle_command_status))
        self._app.add_handler(CommandHandler("search", self.handle_command_search))

        # Forwarded messages → ingest
        self._app.add_handler(MessageHandler(filters.FORWARDED, self.handle_forwarded))

        # Voice and audio files → classify, then transcribe or discard
        self._app.add_handler(
            MessageHandler(filters.VOICE | filters.AUDIO, self.handle_audio)
        )

        # Plain text messages → conversational
        self._app.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message)
        )

        return self._app

    async def run_polling(self) -> None:
        """Start the bot with long-polling. Blocks until stopped."""
        app = self.build_application()

        await app.initialize()
        await app.start()
        await app.updater.start_polling(
            poll_interval=self.config.poll_interval,
            timeout=self.config.poll_timeout,
            allowed_updates=["message", "callback_query"],
        )

        logger.info("Telegram bot started (polling mode)")

        # Keep running until cancelled
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            pass
        finally:
            await self._cancel_background_tasks()
            await app.updater.stop()
            await app.stop()
            await app.shutdown()

    def run(self) -> None:
        """Synchronous entry point — runs the polling loop."""
        asyncio.run(self.run_polling())
