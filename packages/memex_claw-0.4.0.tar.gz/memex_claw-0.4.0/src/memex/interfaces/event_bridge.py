"""EventBridgeHandler — connects the in-process EventBus to SSE /v1/events clients.

Architecture:
  EventBus.publish(event)
      └── EventBridgeHandler.on_event(event)
              ├── serialize → (event_type, json_str)
              ├── assign monotonic event_id
              ├── append to ring buffer (maxlen=500)
              └── put into every active subscriber queue

Each connected SSE client owns a queue.SimpleQueue. The HTTP handler for
/v1/events blocks on its queue, writes events as they arrive, and calls
remove_subscriber() on disconnect.

Thread safety: all mutations to _subscribers and _ring_buffer are protected
by _lock. The queue.put() calls use the lock-protected snapshot so no
subscriber can be removed mid-broadcast.
"""

from __future__ import annotations

import dataclasses
import json
import logging
import queue
import re
import threading
from collections import deque

from memex.interfaces.json_util import coerce_json as _coerce_json

logger = logging.getLogger(__name__)

# Remove a subscriber whose queue depth exceeds this threshold; it is likely
# a slow or dead client that is accumulating events without consuming them.
_STALE_QUEUE_DEPTH = 200


class EventBridgeHandler:
    """Bridges EventBus events to all active SSE /v1/events subscribers.

    Usage::

        bridge = EventBridgeHandler()   # auto-subscribes to the global bus
        # pass to gateway SSE route handler via closure
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subscribers: list[queue.SimpleQueue] = []
        self._ring_buffer: deque[tuple[int, str, str]] = deque(maxlen=500)
        self._event_id = 0

        # Subscribe to ALL events via the base object type. EventBus dispatches
        # via isinstance(), and isinstance(anything, object) is always True.
        try:
            from memex.event_bus import get_bus

            get_bus().subscribe(object, self.on_event)
        except Exception:
            logger.debug("EventBridge: could not subscribe to event bus", exc_info=True)

    # ------------------------------------------------------------------
    # Subscriber management
    # ------------------------------------------------------------------

    def add_subscriber(
        self,
        q: queue.SimpleQueue,
        last_event_id: int | None = None,
    ) -> None:
        """Register a new SSE client queue.

        If *last_event_id* is given, replay buffered events with id >
        last_event_id before the client starts receiving live events. If the
        requested id is too old (not in the buffer) a resync sentinel is placed
        first.
        """
        with self._lock:
            self._subscribers.append(q)
            # Take a snapshot of the ring buffer while holding the lock.
            buffered = list(self._ring_buffer)

        if last_event_id is not None:
            # Detect ring-buffer overflow: oldest buffered event is newer than
            # last_event_id + 1, meaning some events were evicted before the
            # client reconnected.
            if buffered and buffered[0][0] > last_event_id + 1:
                q.put(("resync", json.dumps({"reason": "buffer_overflow"}), None))
            # Always replay buffered events the client hasn't seen yet.
            for eid, etype, edata in buffered:
                if eid > last_event_id:
                    q.put((etype, edata, eid))

    def remove_subscriber(self, q: queue.SimpleQueue) -> None:
        """Deregister an SSE client queue (called on disconnect)."""
        with self._lock:
            try:
                self._subscribers.remove(q)
            except ValueError:
                pass

    # ------------------------------------------------------------------
    # EventBus callback
    # ------------------------------------------------------------------

    def on_event(self, event: object) -> None:
        """Receive an EventBus event, serialize it, and broadcast to all SSE clients."""
        try:
            event_type, data_json = _serialize_event(event)
        except Exception:
            logger.debug(
                "EventBridge: serialization failed for %s",
                type(event).__name__,
                exc_info=True,
            )
            return

        with self._lock:
            self._event_id += 1
            eid = self._event_id
            self._ring_buffer.append((eid, event_type, data_json))
            snapshot = list(self._subscribers)

        stale: list[queue.SimpleQueue] = []
        for q in snapshot:
            # SimpleQueue.qsize() was added in Python 3.11; guard for older runtimes.
            if hasattr(q, "qsize") and q.qsize() > _STALE_QUEUE_DEPTH:
                logger.warning(
                    "EventBridge: subscriber queue depth %d exceeds threshold; removing stale subscriber",
                    q.qsize(),
                )
                stale.append(q)
                continue
            try:
                q.put((event_type, data_json, eid))
            except Exception:
                logger.debug(
                    "EventBridge: failed to enqueue event for subscriber", exc_info=True
                )

        if stale:
            with self._lock:
                for q in stale:
                    try:
                        self._subscribers.remove(q)
                    except ValueError:
                        pass


# ------------------------------------------------------------------
# Serialization helper
# ------------------------------------------------------------------


def _serialize_event(event: object) -> tuple[str, str]:
    """Return (event_type_name, json_string) for an EventBus event.

    Uses dataclasses.asdict() for dataclasses, vars() otherwise. Non-JSON-
    serializable fields are silently dropped.
    """
    event_type = re.sub(r"(?<!^)(?=[A-Z])", "_", type(event).__name__).lower()

    if dataclasses.is_dataclass(event) and not isinstance(event, type):
        raw = dataclasses.asdict(event)
    elif hasattr(event, "__dict__"):
        raw = dict(vars(event))
    else:
        raw = {}

    data = _coerce_json(raw)
    return event_type, json.dumps(data)
