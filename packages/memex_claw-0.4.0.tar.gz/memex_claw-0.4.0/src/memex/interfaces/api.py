"""Unified API — the single entry point to Memex core logic.

Every interface (CLI, Telegram, TUI, MCP) goes through MemexAPI.
Direct run_turn() calls are internal implementation details.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

from memex.interfaces.caller import CallerContext
from memex.interfaces.formats import (
    INTERFACE_FORMATS,
    ResponseFormat,
    SessionMode,
)
from memex.knowledge_ingest_runs import (
    build_ingest_result,
    followup_document_id_for_item,
)
from memex.models import GoalStatus, SessionContext, WorldModelKnowledgeIngestRun
from memex.prompt_budget import PromptMode
from memex.runtime_state import RuntimeStateRegistry
from memex.store import MemexStore
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


def _ensure_aware(dt: datetime) -> datetime:
    """Ensure a datetime is timezone-aware UTC (handles pre-migration naive values)."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _project_plugins(plugin_infos: list[Any]) -> dict[str, Any]:
    items = []
    for info in plugin_infos:
        manifest = info.manifest
        items.append(
            {
                "plugin_id": manifest.id,
                "name": manifest.name,
                "version": manifest.version,
                "kind": manifest.kind,
                "installed": True,
                "loaded": info.status == "loaded",
                "status": info.status,
                "error": info.error or "",
            }
        )
    items.sort(key=lambda item: item["plugin_id"])
    return {
        "installed_count": len(items),
        "loaded_count": sum(1 for item in items if item["loaded"]),
        "error_count": sum(1 for item in items if item["status"] == "error"),
        "items": items,
    }


class MemexAPI:
    """Unified API wrapping run_turn + store + connectors.

    All interface code should use this instead of calling run_turn directly.
    """

    def __init__(
        self,
        store: MemexStore,
        *,
        tool_registry: Any = None,
        connector_health: list[Any] | None = None,
        connector_clients: dict[str, Any] | None = None,
        content_store: Any = None,
        embedding_backend: Any = None,
        middleware_chain: Any = None,
        service_manager: Any = None,
        runtime_registry: RuntimeStateRegistry | None = None,
        store_path: str = "",
        fathom_store: Any = None,
    ) -> None:
        self._store = store
        self._fathom_store = fathom_store
        self._tool_registry = tool_registry
        self._connector_health = connector_health
        self._connector_clients = connector_clients
        self._content_store = content_store
        self._embedding_backend = embedding_backend
        self._middleware_chain = middleware_chain
        self._service_manager = service_manager
        self._runtime_registry = runtime_registry or RuntimeStateRegistry()
        self._store_path = store_path
        self._post_report: Any = None
        self._scheduler_engine: Any = None
        self._sessions: dict[str, SessionContext] = {}
        self._sessions_lock = threading.Lock()
        self._max_sessions = 100  # prevent unbounded memory growth
        self._closed = False
        self._runtime_registry.set_interface_state(
            "memex_api",
            enabled=True,
            running=True,
            status="running",
            owner="direct",
        )
        try:
            from memex.tools_builtin import configure_stores

            configure_stores(
                content_store=self._content_store,
                embedding_backend=self._embedding_backend,
                memex_store=self._store,
                scheduler_store=getattr(self._store, "scheduler", None),
                self_state_provider=self.self_state,
                intake_store=self._get_intake_store(),
                enqueue_fn=self.enqueue_work,
                diagnostics_provider=self.run_diagnostics,
                repair_provider=self.repair,
            )
        except Exception:
            logger.debug(
                "Failed to configure builtin self-state provider", exc_info=True
            )

    @classmethod
    def create(
        cls,
        store_path: str | None = None,
        on_progress: Callable[[str], None] | None = None,
    ) -> MemexAPI:
        """Factory: create a fully initialized MemexAPI.

        Handles store creation, knowledge retrieval init, startup health check,
        and power-on self-test (POST).

        ``on_progress`` is called with human-readable status messages at each
        major startup phase.  Pass ``None`` (default) for silent startup.
        """
        from memex.loop import startup_health_check

        def _report(msg: str) -> None:
            if on_progress is not None:
                on_progress(msg)

        from memex.paths import resolve_store_path

        path = store_path or resolve_store_path()
        _report("Opening store...")

        from pathlib import Path
        from memex.fathom_store import FathomStore
        from memex.fathom_facade import FathomMemexStore

        fathom_path = str(Path(path).parent / "fathom.db")
        fathom_store = FathomStore.open(fathom_path)
        store = FathomMemexStore(fathom_store)
        _report("FathomDB store opened")

        runtime_registry = RuntimeStateRegistry()
        runtime_registry.set_process_info(store_path=path)

        # Power-on self-test — runs at every startup, logs results
        _report("Running POST (power-on self-test)...")
        post_report = None
        try:
            from memex.doctor import startup_post

            post_report = startup_post()
            if post_report:
                ok = sum(1 for c in post_report.checks if c.status == "ok")
                total = len(post_report.checks)
                _report(f"  POST complete: {ok}/{total} checks passed")
        except Exception:
            logger.warning("POST (power-on self-test) failed", exc_info=True)
            _report("  POST failed — run `memex log` to investigate")

        # Initialize knowledge retrieval (optional)
        _report("Loading embedding backend...")
        embedding_backend = None
        try:
            from memex.memory.embeddings import get_embedding_backend

            embedding_backend = get_embedding_backend()
            if embedding_backend:
                _report("  Embedding backend ready")
            else:
                _report("  No embedding backend available")
        except Exception:
            logger.warning("Failed to initialize embedding backend", exc_info=True)
            _report("  Embedding backend unavailable")

        # Give builtin tools access to knowledge stores
        _report("Configuring builtin tools...")
        try:
            from memex.tools_builtin import configure_stores

            intake = getattr(store, "intake", None)

            configure_stores(
                content_store=store.content,
                embedding_backend=embedding_backend,
                memex_store=store,
                scheduler_store=store.scheduler,
                intake_store=intake,
            )
        except Exception:
            logger.warning("Failed to configure builtin tool stores", exc_info=True)

        # Start persistent MCP event loop — MCP sessions are bound to the
        # loop they were created on, so we keep one loop alive for the
        # lifetime of the API. run_async() dispatches tool calls here.
        import threading
        from memex.connectors.mcp_client import create_mcp_loop, set_mcp_loop

        mcp_loop = create_mcp_loop()
        _mcp_thread = threading.Thread(
            target=mcp_loop.run_forever,
            name="mcp-loop",
            daemon=True,
        )
        _mcp_thread.start()
        set_mcp_loop(mcp_loop)

        # Startup health check — connect all configured connectors
        _report("Connecting connectors...")
        tool_registry, connector_health, connector_clients = startup_health_check(
            store,
            on_progress=on_progress,
            runtime_registry=runtime_registry,
        )

        # Build middleware chain once for the API's lifetime
        _report("Building middleware chain...")
        middleware_chain = None
        try:
            from memex.loop import _build_middleware_chain

            middleware_chain = _build_middleware_chain(tool_registry)
        except Exception:
            logger.warning("Failed to build middleware chain", exc_info=True)

        # Initialize service manager
        _report("Starting services...")
        service_manager = None
        try:
            from memex.event_bus import get_bus
            from memex.services import ServiceManager

            service_manager = ServiceManager(
                store=store,
                event_bus=get_bus(),
                runtime_registry=runtime_registry,
            )
            service_manager.start_all()
        except Exception:
            logger.warning("Failed to initialize service manager", exc_info=True)

        _report("Ready.")

        api = cls(
            store,
            tool_registry=tool_registry,
            connector_health=connector_health,
            connector_clients=connector_clients,
            content_store=store.content,
            embedding_backend=embedding_backend,
            middleware_chain=middleware_chain,
            service_manager=service_manager,
            runtime_registry=runtime_registry,
            store_path=path,
            fathom_store=fathom_store,
        )
        api._post_report = post_report
        try:
            api._refresh_runtime_registry(CallerContext.owner("post", "startup"))
            api._observe_agent_self_model()
        except Exception:
            logger.debug("Failed to persist startup self-model refresh", exc_info=True)

        import atexit

        atexit.register(api.close)

        return api

    def set_scheduler_engine(self, engine: Any) -> None:
        """Register the scheduler engine for ad-hoc work enqueueing.

        Called by whoever creates the engine (TUI, service manager) after engine creation.
        """
        self._scheduler_engine = engine

    def _refresh_knowledge_bindings(self) -> None:
        """Refresh content/vector/tool bindings if the store swapped knowledge backends."""
        try:
            current_content = self._store.content
        except Exception:
            logger.debug("Failed to resolve current content store", exc_info=True)
            return

        if self._content_store is current_content:
            return

        self._content_store = current_content
        # Vector store binding is now managed by the FathomStore content adapter

        try:
            from memex.tools_builtin import configure_stores

            configure_stores(
                content_store=self._content_store,
                embedding_backend=self._embedding_backend,
                memex_store=self._store,
                scheduler_store=getattr(self._store, "scheduler", None),
                self_state_provider=self.self_state,
                intake_store=self._get_intake_store(),
                enqueue_fn=self.enqueue_work,
                diagnostics_provider=self.run_diagnostics,
                repair_provider=self.repair,
            )
        except Exception:
            logger.debug("Failed to refresh builtin store bindings", exc_info=True)

    def enqueue_work(
        self,
        action_type: str,
        action_data: dict,
        *,
        priority: int = 5,
        max_retries: int = 3,
    ) -> int | None:
        """Enqueue an ad-hoc work item. Returns run_id, or None if no engine is set."""
        if self._scheduler_engine is None:
            return None
        return self._scheduler_engine.enqueue_adhoc(
            action_type, action_data, priority=priority, max_retries=max_retries
        )

    def repair(self, action: str) -> dict:
        """Execute a narrow self-repair action. Returns {ok, action, detail}."""
        diagnostic_context = self._repair_diagnostic_context(action)
        result: dict[str, Any]
        if action == "reset_proxy":
            try:
                from memex.llm import reset_proxy_disabled

                reset_proxy_disabled()
                result = {
                    "ok": True,
                    "action": action,
                    "detail": "Proxy-disabled flag cleared. LLM will be re-probed on next use.",
                }
            except Exception as exc:
                result = {"ok": False, "action": action, "detail": f"Failed: {exc}"}

        elif action == "restart_queue":
            if self._scheduler_engine is None:
                result = {
                    "ok": False,
                    "action": action,
                    "detail": "Scheduler engine not registered.",
                }
            else:
                try:
                    self._scheduler_engine.work_queue.start()  # idempotent — returns early if running
                    result = {
                        "ok": True,
                        "action": action,
                        "detail": "Work queue start() called.",
                    }
                except Exception as exc:
                    result = {"ok": False, "action": action, "detail": f"Failed: {exc}"}

        else:
            result = {
                "ok": False,
                "action": action,
                "detail": f"Unknown action: {action!r}",
            }

        if diagnostic_context is not None:
            result["diagnostic"] = diagnostic_context
            result["detail"] = (
                f"Last diagnostics: {diagnostic_context.get('name')} "
                f"[{diagnostic_context.get('status')}]"
                f"{': ' + diagnostic_context.get('detail') if diagnostic_context.get('detail') else ''}. "
                f"{result['detail']}"
            )

        try:
            from memex.agent_self_model import observe_agent_self_model

            observe_agent_self_model(
                self._store,
                self._runtime_registry.snapshot(),
                last_repair=result,
            )
        except Exception:
            logger.debug(
                "Failed to observe agent self-model after repair", exc_info=True
            )
        return result

    def run_diagnostics(self, checks: list[str] | None = None) -> dict:
        """Run targeted diagnostic checks. checks=None runs all."""
        from memex.doctor import (
            DoctorReport,
            _check_fathomdb,
            _check_llm_api_key,
            _check_llm_proxy,
            _check_telegram,
        )

        report = DoctorReport()
        requested = (
            set(checks)
            if checks
            else {"llm_proxy", "scheduler", "db", "telegram_config", "env_vars"}
        )

        if "env_vars" in requested:
            report.checks.append(_check_llm_api_key(name="env_vars"))

        if "llm_proxy" in requested:
            report.checks.append(_check_llm_proxy(name="llm_proxy"))

        if "scheduler" in requested:
            if self._scheduler_engine is None:
                report.add("scheduler", "warn", "engine not registered")
            else:
                try:
                    wq = self._scheduler_engine.work_queue
                    status = "paused" if wq.is_paused else "running"
                    report.add(
                        "scheduler",
                        "ok" if not wq.is_paused else "warn",
                        f"{status} ({wq.pending_count} pending)",
                    )
                except Exception as exc:
                    report.add("scheduler", "fail", str(exc))

        if "db" in requested:
            report.checks.append(_check_fathomdb(self._store_path, name="db"))

        if "telegram_config" in requested:
            report.checks.append(_check_telegram(name="telegram_config"))

        result = {
            "ok": report.ok,
            "checks": [
                {"name": c.name, "status": c.status, "detail": c.detail}
                for c in report.checks
            ],
        }
        try:
            from memex.agent_self_model import observe_agent_self_model

            observe_agent_self_model(
                self._store,
                self._runtime_registry.snapshot(),
                diagnostics=result,
            )
        except Exception:
            logger.debug(
                "Failed to observe agent self-model after diagnostics", exc_info=True
            )
        return result

    def _repair_diagnostic_context(self, action: str) -> dict[str, Any] | None:
        from memex.agent_self_model import load_agent_self_model

        aliases_by_action = {
            "reset_proxy": {"llm_proxy", "LLM proxy"},
            "restart_queue": {"scheduler", "Scheduler"},
        }
        aliases = aliases_by_action.get(action)
        if not aliases:
            return None

        model = load_agent_self_model(self._store)
        for check in model.last_diagnostics.get("checks", []):
            if check.get("name") in aliases:
                return check
        return None

    def _get_intake_store(self) -> Any:
        """Return intake adapter, or None."""
        return getattr(self._store, "intake", None)

    def record_intake(
        self, source: str, action_type: str, action_data: dict
    ) -> int | None:
        """Write an intake_log entry at message receipt. Returns intake_id or None."""
        try:
            store = self._get_intake_store()
            if store is None:
                return None
            return store.record(source, action_type, action_data)
        except Exception:
            logger.debug("record_intake failed", exc_info=True)
            return None

    def update_intake_status(
        self,
        intake_id: int,
        status: str,
        *,
        error: str = "",
        run_id: int | None = None,
    ) -> None:
        """Update an intake_log entry's status (queued/processed/failed/dismissed)."""
        try:
            store = self._get_intake_store()
            if store is None:
                return
            if status == "queued" and run_id is not None:
                store.mark_queued(intake_id, run_id)
            elif status == "processed":
                store.mark_processed(intake_id)
            elif status == "failed":
                store.mark_failed(intake_id, error)
            elif status == "dismissed":
                store.mark_dismissed(intake_id)
        except Exception:
            logger.debug("update_intake_status failed", exc_info=True)

    @property
    def store(self) -> MemexStore:
        return self._store

    @property
    def post_report(self) -> Any:
        """DoctorReport from startup POST, or None if POST was skipped."""
        return self._post_report

    @property
    def connector_health(self) -> list[Any]:
        return self._connector_health or []

    @property
    def runtime_registry(self) -> RuntimeStateRegistry:
        return self._runtime_registry

    def _load_partner_profile(self) -> Any:
        from memex.human_model import load_canonical_partner_profile

        return load_canonical_partner_profile(self._store)

    def _observe_agent_self_model(self) -> Any:
        from memex.agent_self_model import observe_agent_self_model

        return observe_agent_self_model(
            self._store,
            self._runtime_registry.snapshot(),
        )

    def _project_agent_self_model(self) -> Any:
        from memex.agent_self_model import project_agent_self_model

        return project_agent_self_model(
            self._store,
            self._runtime_registry.snapshot(),
        )

    def _refresh_runtime_registry(
        self,
        caller: CallerContext,
        *,
        session_override: SessionContext | None = None,
    ) -> dict[str, Any]:
        all_goals = self._store.list_goals()
        active = [g for g in all_goals if g.status == GoalStatus.ACTIVE]
        blocked = [g for g in all_goals if g.status == GoalStatus.BLOCKED]
        completed = [g for g in all_goals if g.status == GoalStatus.COMPLETED]
        session = (
            session_override
            if session_override is not None
            else self._store.load_session()
        )

        degraded_modes = list(
            getattr(self._store, "knowledge_degraded_modes", []) or []
        )
        self._runtime_registry.set_process_info(
            store_path=self._store_path,
            degraded_modes=degraded_modes,
        )
        self._runtime_registry.set_goals(
            total=len(all_goals),
            active=len(active),
            blocked=len(blocked),
            completed=len(completed),
        )
        self._runtime_registry.set_session(
            session_id=session.session_id if session else None,
            turn_count=session.turn_count if session else 0,
            active_interface=caller.interface,
        )

        for h in self._connector_health or []:
            self._runtime_registry.set_connector_state(
                h.name,
                status=h.status,
                tools_discovered=h.tools_discovered,
                error=h.error or "",
                last_check=(
                    h.last_check.isoformat()
                    if getattr(h, "last_check", None) is not None
                    else ""
                ),
                degraded=h.status != "connected",
            )
            if h.name == "openclaw-bridge":
                self._runtime_registry.set_interface_state(
                    "openclaw_bridge",
                    enabled=True,
                    running=h.status == "connected",
                    status=h.status,
                    owner="connector",
                    last_error=h.error or "",
                )

        if self._service_manager is not None:
            for service in getattr(self._service_manager, "registered", []):
                self._runtime_registry.set_service_registered(service.id, service.name)
            running_ids = {
                service.id for service in getattr(self._service_manager, "running", [])
            }
            for service in getattr(self._service_manager, "registered", []):
                if service.id in running_ids:
                    self._runtime_registry.set_service_running(
                        service.id, name=service.name
                    )
                else:
                    self._runtime_registry.set_service_stopped(service.id)

        plugins = _project_plugins([])
        try:
            from memex.plugins import get_plugin_registry

            plugin_registry = get_plugin_registry()
            plugin_registry.scan()
            plugins = _project_plugins(plugin_registry.all_plugins())
        except Exception:
            logger.debug("Failed to refresh plugin state", exc_info=True)

        try:
            meeting_store = self._store.meetings
            active_recording = meeting_store.get_active_recording()
            current_recording = (
                self._runtime_registry.snapshot()["meetings"].get("active_recording")
                or {}
            )
            if active_recording is None:
                self._runtime_registry.set_active_recording(None)
            else:
                self._runtime_registry.set_active_recording(
                    {
                        "meeting_id": active_recording.meeting_id,
                        "recording_id": active_recording.recording_id,
                        "paused": current_recording.get("paused", False),
                        "started_at": (
                            active_recording.started_at.isoformat()
                            if active_recording.started_at is not None
                            else None
                        ),
                        "elapsed_seconds": (
                            max(
                                0.0,
                                (
                                    utcnow() - active_recording.started_at
                                ).total_seconds(),
                            )
                            if active_recording.started_at is not None
                            else 0.0
                        ),
                        "vad_threshold": current_recording.get(
                            "vad_threshold",
                            getattr(active_recording, "vad_threshold", 0.2),
                        ),
                        "level": current_recording.get("level", 0.0),
                    }
                )
        except Exception:
            logger.debug("Failed to refresh meeting runtime state", exc_info=True)

        try:
            from memex.llm import get_proxy_status

            proxy = get_proxy_status()
            self._runtime_registry.set_interface_state(
                "llm_proxy",
                enabled=True,
                running=not proxy["disabled"],
                status="ok" if not proxy["disabled"] else "degraded",
                owner="llm_module",
                details={
                    "proxy_url": proxy["proxy_url"] or "direct",
                    "seconds_until_retry": proxy["seconds_until_retry"],
                },
            )
        except Exception:
            logger.debug("Failed to enrich llm_proxy state", exc_info=True)

        if self._scheduler_engine is not None:
            try:
                wq = self._scheduler_engine.work_queue
                self._runtime_registry.set_queue_state(
                    "work_queue",
                    pending_count=wq.pending_count,
                    is_paused=wq.is_paused,
                    running_count=wq._running_count,
                    retrying_count=wq._retrying_count,
                    status="paused" if wq.is_paused else "running",
                )
            except Exception:
                logger.debug("Failed to enrich work_queue state", exc_info=True)

        return {"plugins": plugins}

    def chat(
        self,
        message: str,
        caller: CallerContext,
        *,
        session: SessionContext | None = None,
        mode: SessionMode | None = None,
        response_format: ResponseFormat | None = None,
        on_event: Any = None,
        on_token: Any = None,
        prompt_mode: Any | None = None,
    ) -> tuple[str, SessionContext]:
        """Send a message through the agentic loop.

        Optional callbacks:
          on_event — called with TurnEvent subclasses at key processing points
          on_token — called with each text chunk during streaming LLM response

        Returns (response_text, session).
        """
        from memex.loop import run_turn

        self._refresh_knowledge_bindings()

        # Resolve session
        if session is None:
            with self._sessions_lock:
                session = self._sessions.get(caller.session_id)

        # Resolve format: explicit > interface preset > default
        fmt = response_format or INTERFACE_FORMATS.get(caller.interface)

        # Resolve prompt mode: explicit > session mode inference > FULL
        resolved_prompt_mode = PromptMode.FULL
        if prompt_mode is not None:
            resolved_prompt_mode = prompt_mode
        elif mode == SessionMode.QUICK_CHECK:
            resolved_prompt_mode = PromptMode.MINIMAL

        response, session = run_turn(
            message,
            self._store,
            session,
            project_root=Path.cwd(),
            tool_registry=(
                self._tool_registry
                if self._tool_registry and self._tool_registry.all_tools()
                else None
            ),
            connector_health=self._connector_health or None,
            connector_clients=self._connector_clients or None,
            content_store=self._content_store,
            response_format=fmt,
            session_mode=mode,
            caller=caller,
            middleware_chain=self._middleware_chain,
            on_event=on_event,
            on_token=on_token,
            prompt_mode=resolved_prompt_mode,
        )

        # Cache session for future calls with same session_id (bounded)
        with self._sessions_lock:
            if len(self._sessions) >= self._max_sessions:
                # Evict oldest entry
                oldest = next(iter(self._sessions))
                del self._sessions[oldest]
            self._sessions[caller.session_id] = session

        try:
            self._refresh_runtime_registry(caller, session_override=session)
            self._observe_agent_self_model()
        except Exception:
            logger.debug("Failed to observe agent self-model after chat", exc_info=True)

        return response, session

    def search(self, query: str, caller: CallerContext) -> list[dict[str, Any]]:
        """Search knowledge store."""
        from memex.memory.retrieval import search_documents

        self._refresh_knowledge_bindings()
        if self._content_store is None:
            return []
        try:
            results = search_documents(
                query,
                content_store=self._content_store,
                world_model_store=self._store,
                max_items=10,
            )
            return [
                {
                    "document_id": result.document_id,
                    "title": result.title,
                    "type": result.document_family,
                    "snippet": result.snippet,
                }
                for result in results
            ]
        except Exception:
            logger.debug("Search failed", exc_info=True)
            return []

    def self_state(self, caller: CallerContext) -> dict[str, Any]:
        """Get rich runtime self-state."""
        runtime_extras = self._refresh_runtime_registry(caller)
        state = self._runtime_registry.snapshot()
        state["plugins"] = runtime_extras["plugins"]

        try:
            partner_profile = self._load_partner_profile()
            state["human_partner"] = partner_profile.model_dump(mode="json")
        except Exception:
            logger.debug("Failed to load partner profile for self_state", exc_info=True)
            state["human_partner"] = {}

        try:
            agent_self = self._project_agent_self_model()
            state["agent_self"] = agent_self.model_dump(mode="json")
        except Exception:
            logger.debug(
                "Failed to project agent self-model for self_state", exc_info=True
            )
            state["agent_self"] = {}

        # Available tools — so the LLM knows what capabilities are actually
        # registered (e.g. gmail_search, read_file) not just connectors.
        if self._tool_registry:
            state["available_tools"] = [t.name for t in self._tool_registry.all_tools()]

        # Include configured settings so the LLM can answer configuration
        # questions (e.g. "what device is set for recording?") from self_state
        # without needing a separate settings tool call.
        try:
            s = self._store.settings
            state["settings"] = {
                "recording_device": s.get_str(
                    "recording_device", default="system default"
                ),
                "vad_threshold": s.get_float("vad_threshold", 0.2),
            }
        except Exception:
            logger.debug("Failed to read settings for self_state", exc_info=True)

        # Prompt budget configuration and last-turn usage
        try:
            from memex.prompt_budget import load_prompt_budget_config

            config = load_prompt_budget_config(self._store.settings)
            budget_info: dict[str, Any] = {
                "configured": {
                    "stable_prefix_tokens": config.stable_prefix_tokens,
                    "dynamic_turn_tokens": config.dynamic_turn_tokens,
                    "retrieval_tokens": config.retrieval_tokens,
                    "operator_tokens": config.operator_tokens,
                },
            }
            session = self._store.load_session()
            if session:
                stats = session.working_memory.get("_turn_runtime_stats", {})
                pm = stats.get("prompt_metrics", {})
                if pm:
                    budget_info["last_turn"] = {
                        k: pm[k]
                        for k in (
                            "stable_prompt_chars",
                            "dynamic_prompt_chars",
                            "operator_prompt_chars",
                            "retrieval_prompt_chars",
                            "section_usage",
                        )
                        if k in pm
                    }
            state["prompt_budget"] = budget_info
        except Exception:
            logger.debug("Failed to load prompt budget for self_state", exc_info=True)

        return state

    def status(self, caller: CallerContext) -> dict[str, Any]:
        """Get compact backward-compatible system status."""
        try:
            all_goals = self._store.list_goals()
            active = [g for g in all_goals if g.status == GoalStatus.ACTIVE]
            session = self._store.load_session()
            connector_health = self._store.load_connector_health()
            if all_goals or session is not None or connector_health:
                return {
                    "goals_total": len(all_goals),
                    "goals_active": len(active),
                    "session_id": session.session_id[:8] if session else None,
                    "session_turns": session.turn_count if session else 0,
                    "connectors": [
                        {
                            "name": item.name,
                            "status": item.status,
                            "tools": item.tools_discovered,
                            "error": item.error or "",
                        }
                        for item in connector_health
                    ],
                }
        except Exception:
            logger.debug("Falling back to live self_state for status()", exc_info=True)

        state = self.self_state(caller)
        session = state["session"]
        return {
            "goals_total": state["goals"]["total"],
            "goals_active": state["goals"]["active"],
            "session_id": session["session_id"][:8] if session["session_id"] else None,
            "session_turns": session["turn_count"],
            "connectors": [
                {
                    "name": item["name"],
                    "status": item["status"],
                    "tools": item["tools_discovered"],
                    "error": item["error"],
                }
                for item in state["connectors"]
            ],
        }

    def intent(
        self, caller: CallerContext, *, include_all: bool = False
    ) -> list[dict[str, Any]]:
        """List goals/intents."""
        if include_all:
            goals = self._store.list_goals()
        else:
            goals = self._store.list_goals(GoalStatus.ACTIVE)

        return [
            {
                "goal_id": g.goal_id,
                "title": g.title,
                "status": g.status.value,
                "priority": g.priority.value,
                "parent_id": g.parent_id,
                "blocked_by_goal_id": g.blocked_by_goal_id,
                "deadline": g.deadline.isoformat() if g.deadline else None,
            }
            for g in goals
        ]

    def end_session(self, caller: CallerContext) -> SessionContext | None:
        """End the current session for a caller. Returns new session, or None."""
        from memex.session import end_session, save_session

        with self._sessions_lock:
            session = self._sessions.get(caller.session_id)
        if session is None:
            return None

        new_session = end_session(
            session, self._store, middleware_chain=self._middleware_chain
        )
        save_session(new_session, self._store)
        with self._sessions_lock:
            self._sessions[caller.session_id] = new_session
        return new_session

    def ingest_url(
        self,
        url: str,
        *,
        item_type: str = "article",
        session_id: str = "",
        trigger_surface: str = "api",
        ingest_kind: str = "url",
    ) -> dict[str, Any] | None:
        """Ingest a URL into the knowledge store.

        Returns a dict with item_id, title, and optional error on success,
        or None if the content store is not configured.
        Dedup is handled by the intake pipeline (find_by_url).
        """
        if self._closed:
            logger.debug("ingest_url ignored on closed MemexAPI for %s", url)
            return None
        self._refresh_knowledge_bindings()
        run = self._start_knowledge_ingest_run(
            ingest_kind=ingest_kind,
            trigger_surface=trigger_surface,
            source_ref=url,
            requested_item_type=item_type,
            session_id=session_id,
        )
        if self._content_store is None:
            logger.warning("ingest_url: no content store configured")
            run = self._update_knowledge_ingest_run(
                run,
                status="failed",
                phase="failed",
                error="no content store configured",
                payload_update={"operation_stats": {"total_ms": 0}},
                finished=True,
            )
            self._record_knowledge_ingest_operation(
                run=run,
            )
            return None

        existing_url_cache = self._existing_url_cache_state(url)
        cache_payload = {
            "reused_existing_item": False,
            "http_cache_policy": "miss",
            "http_conditional_request": False,
        }
        conditional_request_headers: dict[str, str] | None = None
        if existing_url_cache is not None:
            cache_payload.update(existing_url_cache["payload"])
            if existing_url_cache["reuse_without_fetch"]:
                item = existing_url_cache["item"]
                result = build_ingest_result(
                    item,
                    content_store=self._content_store,
                    world_model_store=self._store,
                    source_ref=url,
                )
                run = self._update_knowledge_ingest_run(
                    run,
                    status="completed",
                    phase="completed",
                    result=result,
                    payload_update={
                        **cache_payload,
                        "reused_existing_item": True,
                        "operation_stats": {
                            "phase_timings_ms": {
                                "extract": 0,
                                "project": 0,
                                "summary": 0,
                                "total": 0,
                            },
                            "total_ms": 0,
                        },
                    },
                    summary_model=item.summary.model or "existing_local_item",
                    finished=True,
                )
                result = self._enrich_ingest_result(result, run)
                self._record_knowledge_ingest_operation(
                    run=run,
                    result=result,
                )
                return result
            conditional_request_headers = existing_url_cache.get("request_headers")

        activity = None
        start = time.monotonic()
        try:
            from memex.memory.intake import ingest_extracted_content
            from memex.models import ItemType
            from memex.telemetry import start_activity
            from memex.memory.web_extract import (
                extract_from_fetch_result,
                fetch_url_result,
            )
            from memex.memory.youtube_extract import (
                extract_from_youtube,
                is_youtube_url,
            )

            activity = start_activity(
                f"Ingesting URL: {url}",
                source="ingest_url",
                session_id=session_id,
                background=True,
                runtime_registry=self._runtime_registry,
            )
            run = self._update_knowledge_ingest_run(
                run,
                status="extracting",
                phase="extracting",
                payload_update=cache_payload,
            )
            extract_started = time.monotonic()
            fetch_result = None
            fetch_content_type = ""
            fetch_format = "html"
            if is_youtube_url(url):
                extracted = extract_from_youtube(url)
                fetch_format = "youtube"
            else:
                fetch_result = fetch_url_result(
                    url,
                    request_headers=conditional_request_headers,
                )
                fetch_content_type = str(fetch_result.headers.get("content-type") or "")
                if fetch_content_type.lower().startswith(
                    (
                        "text/plain",
                        "text/markdown",
                        "text/x-markdown",
                        "application/markdown",
                    )
                ):
                    fetch_format = "text"
                if fetch_result.status_code == 304 and existing_url_cache is not None:
                    item = existing_url_cache["item"]
                    self._mark_url_ingest_refresh(
                        item.item_id,
                        refresh_mode="not_modified",
                        fetch_result=fetch_result,
                    )
                    result = build_ingest_result(
                        item,
                        content_store=self._content_store,
                        world_model_store=self._store,
                        source_ref=url,
                    )
                    run = self._update_knowledge_ingest_run(
                        run,
                        status="completed",
                        phase="completed",
                        result=result,
                        payload_update={
                            **cache_payload,
                            "reused_existing_item": True,
                            "http_cache_policy": "revalidated_not_modified",
                            "http_conditional_request": True,
                            "fetch_content_type": fetch_content_type,
                            "fetch_format": fetch_format,
                            "operation_stats": {
                                "phase_timings_ms": {
                                    "extract": int(
                                        (time.monotonic() - extract_started) * 1000
                                    ),
                                    "project": 0,
                                    "summary": 0,
                                    "total": int((time.monotonic() - start) * 1000),
                                },
                                "total_ms": int((time.monotonic() - start) * 1000),
                            },
                        },
                        summary_model=item.summary.model or "existing_local_item",
                        finished=True,
                    )
                    result = self._enrich_ingest_result(result, run)
                    self._record_knowledge_ingest_operation(
                        run=run,
                        result=result,
                    )
                    return result
                extracted = extract_from_fetch_result(fetch_result)
            extract_ms = int((time.monotonic() - extract_started) * 1000)
            if not extracted.is_substantial:
                raise ValueError(
                    f"Could not extract meaningful content from {url} "
                    f"({extracted.word_count} words, {extracted.raw_length} bytes HTML)"
                )
            run = self._update_knowledge_ingest_run(
                run,
                status="projecting",
                phase="projecting",
                summary_model="deterministic_extract",
                payload_update={
                    **cache_payload,
                    "http_cache_policy": (
                        "revalidated_changed" if conditional_request_headers else "miss"
                    ),
                    "http_conditional_request": bool(conditional_request_headers),
                    "summary_mode": "deterministic_extract",
                    "fetch_content_type": fetch_content_type,
                    "fetch_format": fetch_format,
                    "extracted_word_count": extracted.word_count,
                    "raw_length": extracted.raw_length,
                    "categories": list(extracted.categories),
                },
            )
            project_started = time.monotonic()
            item = ingest_extracted_content(
                extracted,
                type=ItemType(item_type),
                content_store=self._content_store,
                memex_store=self._store,
                generate_summary=False,
                session_id=session_id,
            )
            project_ms = int((time.monotonic() - project_started) * 1000)
            activity.finish(label=f"Ingested URL: {item.title or url}")
            result = build_ingest_result(
                item,
                content_store=self._content_store,
                world_model_store=self._store,
                source_ref=url,
            )
            self._mark_url_ingest_refresh(
                item.item_id,
                refresh_mode="full_extract",
                fetch_result=fetch_result,
            )
            run = self._update_knowledge_ingest_run(
                run,
                status="completed",
                phase="completed",
                result=result,
                payload_update={
                    **cache_payload,
                    "http_cache_policy": (
                        "revalidated_changed" if conditional_request_headers else "miss"
                    ),
                    "http_conditional_request": bool(conditional_request_headers),
                    "summary_mode": "deterministic_extract",
                    "fetch_content_type": fetch_content_type,
                    "fetch_format": fetch_format,
                    "operation_stats": {
                        "phase_timings_ms": {
                            "extract": extract_ms,
                            "project": project_ms,
                            "summary": 0,
                            "total": int((time.monotonic() - start) * 1000),
                        },
                        "total_ms": int((time.monotonic() - start) * 1000),
                    },
                },
                summary_model=item.summary.model or "deterministic_extract",
                finished=True,
            )
            result = self._enrich_ingest_result(result, run)
            self._record_knowledge_ingest_operation(
                run=run,
                result=result,
            )
            return result
        except ValueError as exc:
            # Extraction succeeded but content was too thin — try to save
            # whatever we got so the URL is at least recorded
            logger.info("ingest_url thin content for %s: %s", url, exc)
            if activity is not None:
                activity.update(f"Saving bookmark: {url}")
            run = self._update_knowledge_ingest_run(
                run,
                status="projecting",
                phase="projecting",
                summary_model="deterministic_extract",
            )
            result = self._ingest_url_fallback(url, item_type)
            if result is not None:
                self._mark_url_ingest_refresh(
                    result["item_id"],
                    refresh_mode="fallback_bookmark",
                )
            run = self._update_knowledge_ingest_run(
                run,
                status="fallback_completed" if result is not None else "failed",
                phase="completed" if result is not None else "failed",
                result=result,
                fallback_used=result is not None,
                error=str(exc) if result is None else "",
                payload_update={
                    **cache_payload,
                    "summary_mode": "deterministic_extract",
                    "operation_stats": {
                        "phase_timings_ms": {
                            "extract": int((time.monotonic() - start) * 1000),
                            "project": 0,
                            "summary": 0,
                            "total": int((time.monotonic() - start) * 1000),
                        },
                        "total_ms": int((time.monotonic() - start) * 1000),
                    },
                    "fallback_reason": str(exc),
                },
                summary_model="deterministic_extract",
                finished=True,
            )
            result = self._enrich_ingest_result(result, run)
            self._record_knowledge_ingest_operation(
                run=run,
                result=result,
            )
            return result
        except Exception:
            logger.warning("ingest_url failed for %s", url, exc_info=True)
            if activity is not None:
                activity.update(f"Falling back to bookmark: {url}")
            run = self._update_knowledge_ingest_run(
                run,
                status="projecting",
                phase="projecting",
                summary_model="deterministic_extract",
            )
            result = self._ingest_url_fallback(url, item_type)
            if result is not None:
                self._mark_url_ingest_refresh(
                    result["item_id"],
                    refresh_mode="fallback_bookmark",
                )
            run = self._update_knowledge_ingest_run(
                run,
                status="fallback_completed" if result is not None else "failed",
                phase="completed" if result is not None else "failed",
                result=result,
                fallback_used=result is not None,
                error="" if result is not None else "ingest_url failed",
                payload_update={
                    **cache_payload,
                    "summary_mode": "deterministic_extract",
                    "operation_stats": {
                        "phase_timings_ms": {
                            "extract": int((time.monotonic() - start) * 1000),
                            "project": 0,
                            "summary": 0,
                            "total": int((time.monotonic() - start) * 1000),
                        },
                        "total_ms": int((time.monotonic() - start) * 1000),
                    },
                },
                summary_model="deterministic_extract",
                finished=True,
            )
            result = self._enrich_ingest_result(result, run)
            self._record_knowledge_ingest_operation(
                run=run,
                result=result,
            )
            return result
        finally:
            if activity is not None:
                activity.finish()

    def _ingest_url_fallback(self, url: str, item_type: str) -> dict[str, Any] | None:
        """Fallback: store URL as a minimal bookmark when full extraction fails.

        Does NOT re-attempt extraction — the caller already tried and failed.
        Stores the URL so the knowledge store at least has a record of it.
        """
        self._refresh_knowledge_bindings()
        try:
            from memex.memory.intake import ingest
            from memex.models import ItemType

            item = ingest(
                url,
                type=ItemType(item_type),
                title=url,
                source_url=url,
                content_store=self._content_store,
                memex_store=self._store,
                generate_summary=False,
            )
            logger.info("ingest_url fallback saved bookmark for %s", url)
            return {
                "item_id": item.item_id,
                "document_id": self._followup_document_id_for_item(item.item_id),
                "title": item.title or url,
                "summary": "",
                "source_url": item.source_url or url,
            }
        except Exception:
            logger.warning("ingest_url fallback also failed for %s", url, exc_info=True)
            return None

    def ingest_content(
        self,
        content: str,
        *,
        title: str = "",
        source_url: str = "",
        item_type: str = "note",
        tags: list[str] | None = None,
        session_id: str = "",
        trigger_surface: str = "api",
        ingest_kind: str = "content",
    ) -> dict[str, Any] | None:
        """Ingest raw text content into the knowledge store.

        Returns a dict with item_id and title on success, or None if the
        content store is not configured.
        """
        self._refresh_knowledge_bindings()
        source_ref = source_url or title or content[:80]
        run = self._start_knowledge_ingest_run(
            ingest_kind=ingest_kind,
            trigger_surface=trigger_surface,
            source_ref=source_ref,
            requested_item_type=item_type,
            session_id=session_id,
        )
        if self._content_store is None:
            logger.warning("ingest_content: no content store configured")
            run = self._update_knowledge_ingest_run(
                run,
                status="failed",
                phase="failed",
                error="no content store configured",
                payload_update={"operation_stats": {"total_ms": 0}},
                finished=True,
            )
            self._record_knowledge_ingest_operation(
                run=run,
            )
            return None
        start = time.monotonic()
        try:
            from memex.memory.intake import ingest
            from memex.models import ItemType

            run = self._update_knowledge_ingest_run(
                run,
                status="projecting",
                phase="projecting",
            )
            item = ingest(
                content,
                type=ItemType(item_type),
                title=title or None,
                source_url=source_url or None,
                tags=tags,
                content_store=self._content_store,
                memex_store=self._store,
                generate_summary=False,
                session_id=session_id,
            )
            result = {
                "item_id": item.item_id,
                "document_id": self._followup_document_id_for_item(item.item_id),
                "title": item.title or title,
                "summary": item.summary.text or "",
                "source_url": item.source_url or source_url,
            }
            run = self._update_knowledge_ingest_run(
                run,
                status="completed",
                phase="completed",
                result=result,
                payload_update={
                    "operation_stats": {
                        "total_ms": int((time.monotonic() - start) * 1000)
                    }
                },
                finished=True,
            )
            self._record_knowledge_ingest_operation(
                run=run,
                result=result,
            )
            return result
        except Exception:
            logger.warning("ingest_content failed", exc_info=True)
            run = self._update_knowledge_ingest_run(
                run,
                status="failed",
                phase="failed",
                error="ingest_content failed",
                payload_update={
                    "operation_stats": {
                        "total_ms": int((time.monotonic() - start) * 1000)
                    }
                },
                finished=True,
            )
            self._record_knowledge_ingest_operation(
                run=run,
            )
            return None

    def _followup_document_id_for_item(self, item_id: str) -> str:
        if self._content_store is None:
            return f"content_item:{item_id}"
        return followup_document_id_for_item(
            item_id,
            content_store=self._content_store,
            world_model_store=self._store,
        )

    def _existing_url_cache_state(self, url: str) -> dict[str, Any] | None:
        if self._content_store is None or not url:
            return None
        item = self._content_store.find_by_url(url)
        if item is None or not self._is_reusable_existing_url_item(item, url):
            return None
        http_metadata = self._url_ingest_http_metadata(item)
        request_headers = self._conditional_request_headers(http_metadata)
        policy = self._http_cache_policy(http_metadata)
        return {
            "item": item,
            "reuse_without_fetch": policy == "fresh_local",
            "request_headers": request_headers,
            "payload": {
                "http_cache_policy": policy,
                "http_conditional_request": bool(request_headers)
                and policy != "fresh_local",
            },
        }

    def _url_ingest_http_metadata(self, item: Any) -> dict[str, Any]:
        metadata = (item.metadata or {}).get("url_ingest_http")
        return dict(metadata) if isinstance(metadata, dict) else {}

    def _http_cache_policy(self, metadata: dict[str, Any]) -> str:
        cache_control = str(metadata.get("cache_control") or "").lower()
        directives = {part.strip() for part in cache_control.split(",") if part.strip()}
        fetched_at = self._parse_datetime_value(metadata.get("fetched_at"))
        expires_at = self._parse_http_datetime(metadata.get("expires"))
        now = utcnow()

        if "no-store" in directives:
            return "miss"
        if "immutable" in directives and fetched_at is not None:
            return "fresh_local"

        max_age: int | None = None
        for directive in directives:
            if not directive.startswith("max-age="):
                continue
            try:
                max_age = int(directive.split("=", 1)[1])
            except ValueError:
                max_age = None
            break

        if (
            fetched_at is not None
            and max_age is not None
            and max_age > 0
            and now <= _ensure_aware(fetched_at) + timedelta(seconds=max_age)
            and "no-cache" not in directives
            and "must-revalidate" not in directives
        ):
            return "fresh_local"
        if expires_at is not None and now <= _ensure_aware(expires_at):
            return "fresh_local"
        if self._conditional_request_headers(metadata):
            return "stale_revalidate"
        return "miss"

    def _conditional_request_headers(
        self, metadata: dict[str, Any]
    ) -> dict[str, str] | None:
        headers: dict[str, str] = {}
        etag = str(metadata.get("etag") or "").strip()
        last_modified = str(metadata.get("last_modified") or "").strip()
        if etag:
            headers["If-None-Match"] = etag
        if last_modified:
            headers["If-Modified-Since"] = last_modified
        return headers or None

    def _parse_datetime_value(self, value: Any) -> datetime | None:
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value)
            except ValueError:
                return None
        return None

    def _parse_http_datetime(self, value: Any) -> datetime | None:
        if not value:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            try:
                return parsedate_to_datetime(value)
            except (TypeError, ValueError, IndexError):
                return None
        return None

    def _is_reusable_existing_url_item(self, item: Any, url: str) -> bool:
        title = (item.title or "").strip()
        body = (item.body or "").strip()
        summary = (item.summary.text or "").strip()
        if title == url and body == url and not summary:
            return False
        if len(body.split()) >= 20:
            return True
        return bool(summary and title != url)

    def _mark_url_ingest_refresh(
        self,
        item_id: str,
        *,
        refresh_mode: str,
        fetch_result: Any | None = None,
    ) -> None:
        if self._content_store is None:
            return
        item = self._content_store.get_item(item_id)
        if item is None:
            return
        metadata = dict(item.metadata or {})
        http_metadata = dict(metadata.get("url_ingest_http") or {})
        http_metadata["fetched_at"] = utcnow().isoformat()
        http_metadata["refresh_mode"] = refresh_mode
        if fetch_result is not None:
            headers = {
                str(key).lower(): str(value)
                for key, value in getattr(fetch_result, "headers", {}).items()
            }
            if headers:
                http_metadata["etag"] = headers.get(
                    "etag", http_metadata.get("etag", "")
                )
                http_metadata["last_modified"] = headers.get(
                    "last-modified",
                    http_metadata.get("last_modified", ""),
                )
                http_metadata["cache_control"] = headers.get(
                    "cache-control",
                    http_metadata.get("cache_control", ""),
                )
                http_metadata["expires"] = headers.get(
                    "expires",
                    http_metadata.get("expires", ""),
                )
            http_metadata["status_code"] = getattr(fetch_result, "status_code", 0)
            http_metadata["final_url"] = getattr(
                fetch_result, "url", item.source_url or ""
            )
        metadata["url_ingest_http"] = http_metadata
        item.metadata = metadata
        self._content_store.update_item(item)

    def _normalize_ingest_source_ref(self, source_ref: str) -> str:
        return source_ref.strip()

    def _knowledge_id_from_result(self, result: dict[str, Any] | None) -> str | None:
        if result is None:
            return None
        document_id = str(result.get("document_id") or "")
        if document_id.startswith("world_model_knowledge:"):
            return document_id.split(":", 1)[1]
        return None

    def _enrich_ingest_result(
        self,
        result: dict[str, Any] | None,
        run: WorldModelKnowledgeIngestRun,
    ) -> dict[str, Any] | None:
        if result is None:
            return None
        enriched = dict(result)
        enriched["ingest_run_id"] = run.ingest_run_id
        enriched["fallback_used"] = run.fallback_used
        operation_stats = dict(run.payload.get("operation_stats") or {})
        if operation_stats:
            enriched["operation_stats"] = operation_stats
        http_cache_policy = run.payload.get("http_cache_policy")
        if http_cache_policy:
            enriched["http_cache_policy"] = http_cache_policy
        return enriched

    def _start_knowledge_ingest_run(
        self,
        *,
        ingest_kind: str,
        trigger_surface: str,
        source_ref: str,
        requested_item_type: str,
        session_id: str = "",
    ) -> WorldModelKnowledgeIngestRun:
        from memex.world_model_backbone import build_world_model_knowledge_ingest_run

        run = build_world_model_knowledge_ingest_run(
            ingest_kind=ingest_kind,
            trigger_surface=trigger_surface,
            source_ref=source_ref,
            normalized_source_ref=self._normalize_ingest_source_ref(source_ref),
            requested_item_type=requested_item_type,
            session_id=session_id or None,
            payload={},
        )
        self._store.upsert_world_model_knowledge_ingest_run(run)
        return run

    def _update_knowledge_ingest_run(
        self,
        run: WorldModelKnowledgeIngestRun,
        *,
        status: str,
        phase: str,
        result: dict[str, Any] | None = None,
        fallback_used: bool | None = None,
        error: str | None = None,
        payload_update: dict[str, Any] | None = None,
        summary_model: str | None = None,
        finished: bool = False,
    ) -> WorldModelKnowledgeIngestRun:
        now = utcnow()
        payload = dict(run.payload)
        if payload_update:
            payload.update(payload_update)
        if result is not None:
            payload["result"] = dict(result)
        updated = run.model_copy(
            update={
                "status": status,
                "phase": phase,
                "fallback_used": run.fallback_used
                if fallback_used is None
                else fallback_used,
                "item_id": result.get("item_id") if result is not None else run.item_id,
                "knowledge_id": self._knowledge_id_from_result(result)
                or run.knowledge_id,
                "summary_model": run.summary_model
                if summary_model is None
                else summary_model,
                "error": run.error if error is None else error,
                "payload": payload,
                "updated_at": now,
                "finished_at": now if finished else run.finished_at,
            }
        )
        self._store.upsert_world_model_knowledge_ingest_run(updated)
        return updated

    def _record_knowledge_ingest_operation(
        self,
        *,
        run: WorldModelKnowledgeIngestRun,
        result: dict[str, Any] | None = None,
    ) -> None:
        try:
            from memex.world_model_backbone import (
                build_world_model_knowledge_ingest_action,
                build_world_model_knowledge_ingest_event,
                build_world_model_knowledge_ingest_observation,
                build_world_model_provenance_link,
            )

            payload = dict(run.payload)
            payload["run_id"] = run.ingest_run_id
            payload["source_ref"] = run.source_ref
            payload["item_type"] = run.requested_item_type
            payload["fallback_used"] = run.fallback_used
            payload["error"] = run.error
            summary = (
                f'Saved "{result.get("title") or run.source_ref}".'
                if run.status in {"completed", "fallback_completed"}
                and result is not None
                else f"Failed to ingest {run.source_ref}."
            )
            action = build_world_model_knowledge_ingest_action(
                ingest_kind=run.ingest_kind,
                session_id=run.session_id,
                source_ref=run.source_ref,
                item_type=run.requested_item_type,
                status="succeeded"
                if run.status in {"completed", "fallback_completed"}
                else "failed",
                payload=payload,
            )
            observation = build_world_model_knowledge_ingest_observation(
                action,
                summary=summary,
                status="succeeded"
                if run.status in {"completed", "fallback_completed"}
                else "failed",
                payload=payload,
            )
            event = build_world_model_knowledge_ingest_event(
                action,
                title=f"Knowledge ingest: {result.get('title') or run.source_ref}"
                if result
                else f"Knowledge ingest failed: {run.source_ref}",
                summary=summary,
                payload=payload,
            )
            self._store.upsert_world_model_action(action)
            self._store.upsert_world_model_observation(observation)
            self._store.upsert_world_model_event(event)
            self._store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_observation",
                    observation.observation_id,
                    "world_model_action",
                    action.action_id,
                    "observed_from",
                )
            )
            self._store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_action",
                    action.action_id,
                    "knowledge_ingest_run",
                    run.ingest_run_id,
                    "tracks_ingest_run",
                )
            )
            self._store.upsert_world_model_provenance_link(
                build_world_model_provenance_link(
                    "world_model_event",
                    event.event_id,
                    "knowledge_ingest_run",
                    run.ingest_run_id,
                    "records_ingest_run",
                )
            )
            if result is not None and run.knowledge_id:
                self._store.upsert_world_model_provenance_link(
                    build_world_model_provenance_link(
                        "knowledge_ingest_run",
                        run.ingest_run_id,
                        "world_model_knowledge",
                        run.knowledge_id,
                        (
                            "produced_fallback_bookmark"
                            if run.fallback_used
                            else "produced_knowledge"
                        ),
                    )
                )
            if result is not None:
                document_id = str(result.get("document_id") or "")
                if document_id.startswith("world_model_knowledge:"):
                    knowledge_id = document_id.split(":", 1)[1]
                    self._store.upsert_world_model_provenance_link(
                        build_world_model_provenance_link(
                            "world_model_action",
                            action.action_id,
                            "world_model_knowledge",
                            knowledge_id,
                            "ingested_knowledge",
                        )
                    )
                    self._store.upsert_world_model_provenance_link(
                        build_world_model_provenance_link(
                            "world_model_event",
                            event.event_id,
                            "world_model_knowledge",
                            knowledge_id,
                            "records_ingest_of",
                        )
                    )
        except Exception:
            logger.debug("Failed to record knowledge ingest operation", exc_info=True)

    @property
    def service_manager(self) -> Any:
        """ServiceManager instance, or None."""
        return self._service_manager

    # ------------------------------------------------------------------
    # MemexClientProtocol facade — thin delegation to store internals so
    # the TUI (and MemexServiceClient) share one clean interface contract.
    # ------------------------------------------------------------------

    @property
    def content_store(self) -> Any:
        return self._content_store

    @property
    def embedding_backend(self) -> Any:
        return self._embedding_backend

    @property
    def db_path(self) -> str:
        return getattr(self._store, "db_path", "")

    @property
    def settings(self) -> Any:
        return self._store.settings

    @property
    def notification_store(self) -> Any:
        """Return notification adapter."""
        return getattr(self._store, "notifications", None)

    # meetings
    def list_meetings(self, **kwargs: Any) -> list[Any]:
        return self._store.meetings.list_meetings(**kwargs)

    def get_meeting(self, meeting_id: str) -> Any:
        return self._store.meetings.get_meeting(meeting_id)

    def create_meeting(self, record: Any) -> Any:
        return self._store.meetings.create_meeting(record)

    def update_meeting(self, meeting: Any) -> None:
        self._store.meetings.update_meeting(meeting)

    def delete_meeting(self, meeting_id: str) -> None:
        self._store.meetings.delete_meeting(meeting_id)

    def get_recording(self, recording_id: str) -> Any:
        return self._store.meetings.get_recording(recording_id)

    def update_recording(self, recording: Any) -> None:
        self._store.meetings.update_recording(recording)

    def cleanup_stale_recordings(self) -> int:
        return self._store.meetings.cleanup_stale_recordings()

    def start_recording(self, meeting_id: str) -> dict[str, Any]:
        """Start audio capture — only meaningful in service mode.

        In local (TUI-embedded) mode the TUI owns AudioCapture directly.
        This facade exists so MemexAPI satisfies MemexClientProtocol.
        """
        raise NotImplementedError(
            "start_recording is handled by the TUI in local mode; "
            "use the service daemon for remote recording"
        )

    def stop_recording(self, meeting_id: str) -> dict[str, Any]:
        """Stop audio capture — see start_recording note."""
        raise NotImplementedError(
            "stop_recording is handled by the TUI in local mode; "
            "use the service daemon for remote recording"
        )

    def transcribe_meeting(self, meeting_id: str) -> dict[str, Any]:
        """Enqueue transcription via the local work queue."""
        self.enqueue_work(
            "transcribe_meeting",
            {"meeting_id": meeting_id},
        )
        return {"status": "queued"}

    # goals
    def create_goal(self, goal: Any) -> None:
        self._store.create_goal(goal)

    def update_goal(self, goal: Any) -> None:
        self._store.update_goal(goal)

    def get_goal(self, goal_id: str) -> Any:
        return self._store.get_goal(goal_id)

    def create_meeting_goal_link(self, link: Any) -> None:
        self._store.create_meeting_goal_link(link)

    # scheduler
    def list_tasks(self) -> list[Any]:
        return self._store.scheduler.list_tasks()

    def get_last_task_run(self, task_id: str) -> Any:
        return self._store.scheduler.get_last_run(task_id)

    def get_task(self, task_id: str) -> Any:
        return self._store.scheduler.get_task(task_id)

    def toggle_task(self, task_id: str, enabled: bool) -> None:
        self._store.scheduler.toggle_task(task_id, enabled)

    # notifications
    def list_notifications(self, unread_only: bool = True) -> list[Any]:
        try:
            ns = self.notification_store
            return ns.list_pending() if unread_only else ns.list_pending(limit=500)
        except Exception:
            logger.debug("Notification query failed", exc_info=True)
            return []

    def act_on_notification(self, notif_id: str, action: str) -> None:
        ns = self.notification_store
        if action == "dismiss":
            ns.dismiss(notif_id)
        else:
            # Facade adapter uses mark_read; legacy uses approve
            if hasattr(ns, "approve"):
                ns.approve(notif_id, action_taken=action)
            else:
                ns.mark_read(notif_id)

    # subagents
    def list_subagents(self) -> list[Any]:
        snapshot = self._runtime_registry.snapshot()
        return snapshot.get("subagents", {}).get("agents", [])

    def close(self) -> None:
        """Clean up resources."""
        if self._closed:
            return
        self._closed = True
        # Shut down the persistent MCP event loop
        try:
            from memex.connectors.mcp_client import get_mcp_loop, set_mcp_loop

            mcp_loop = get_mcp_loop()
            if mcp_loop is not None and mcp_loop.is_running():
                mcp_loop.call_soon_threadsafe(mcp_loop.stop)
                set_mcp_loop(None)
        except Exception:
            pass
        try:
            from memex.tools_builtin import release_stores

            release_stores(
                content_store=self._content_store,
                embedding_backend=self._embedding_backend,
                memex_store=self._store,
                scheduler_store=getattr(self._store, "scheduler", None),
                self_state_provider=self.self_state,
                intake_store=self._get_intake_store(),
                enqueue_fn=self.enqueue_work,
                diagnostics_provider=self.run_diagnostics,
                repair_provider=self.repair,
            )
        except Exception:
            logger.debug(
                "Failed to release builtin store bindings during close", exc_info=True
            )
        if self._service_manager is not None:
            try:
                self._service_manager.stop_all()
            except Exception:
                logger.warning("Failed to stop services during close", exc_info=True)
        if self._runtime_registry is not None:
            if getattr(self._runtime_registry, "snapshot", None) is not None:
                self._runtime_registry.set_interface_state(
                    "memex_api",
                    enabled=False,
                    running=False,
                    status="stopped",
                    owner="direct",
                )
        with self._sessions_lock:
            self._sessions.clear()
        if self._fathom_store is not None:
            try:
                self._fathom_store.close()
            except Exception:
                logger.debug("Failed to close FathomStore", exc_info=True)
        self._store.close()
