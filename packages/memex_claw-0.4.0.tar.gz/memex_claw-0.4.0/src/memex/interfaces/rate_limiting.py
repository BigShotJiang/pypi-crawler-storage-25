"""Rate limiting, circuit breaking, and cost guarding for external callers."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class ConnectionLimits:
    """Limits for a single MCP connection."""

    max_concurrent_calls: int = 5
    max_calls_per_minute: int = 30
    max_cost_per_hour_usd: float = 5.0


@dataclass
class CallerRateLimits:
    """Token-bucket rate limiter per caller."""

    max_tokens: int = 30
    refill_rate: float = 0.5  # tokens per second

    _tokens: float = field(init=False, default=0.0)
    _last_refill: float = field(init=False, default=0.0)

    def __post_init__(self) -> None:
        self._tokens = float(self.max_tokens)
        self._last_refill = time.monotonic()

    def allow(self) -> bool:
        """Check if a call is allowed, consuming one token."""
        self._refill()
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True
        return False

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.max_tokens, self._tokens + elapsed * self.refill_rate)
        self._last_refill = now


@dataclass
class ToolLimits:
    """Per-tool cost weights for cost guarding."""

    cost_weights: dict[str, float] = field(default_factory=dict)
    default_weight: float = 1.0

    def get_weight(self, tool_name: str) -> float:
        return self.cost_weights.get(tool_name, self.default_weight)


class CircuitBreaker:
    """Simple circuit breaker: opens after N consecutive failures."""

    def __init__(self, failure_threshold: int = 5, reset_timeout: float = 60.0) -> None:
        self._failure_threshold = failure_threshold
        self._reset_timeout = reset_timeout
        self._consecutive_failures = 0
        self._last_failure_time: float = 0.0
        self._open = False

    @property
    def is_open(self) -> bool:
        if (
            self._open
            and (time.monotonic() - self._last_failure_time) > self._reset_timeout
        ):
            self._open = False
            self._consecutive_failures = 0
        return self._open

    def record_success(self) -> None:
        self._consecutive_failures = 0
        self._open = False

    def record_failure(self) -> None:
        self._consecutive_failures += 1
        self._last_failure_time = time.monotonic()
        if self._consecutive_failures >= self._failure_threshold:
            self._open = True
            logger.warning(
                "Circuit breaker opened after %d failures", self._consecutive_failures
            )


class CostGuard:
    """Tracks cumulative cost and blocks when budget exceeded."""

    def __init__(self, max_cost_per_hour_usd: float = 5.0) -> None:
        self._max = max_cost_per_hour_usd
        self._entries: list[tuple[float, float]] = []  # (timestamp, cost)

    @property
    def current_hour_cost(self) -> float:
        cutoff = time.monotonic() - 3600
        self._entries = [(t, c) for t, c in self._entries if t > cutoff]
        return sum(c for _, c in self._entries)

    def check(self, estimated_cost: float = 0.0) -> bool:
        """Return True if the call is within budget."""
        return (self.current_hour_cost + estimated_cost) <= self._max

    def record(self, cost: float) -> None:
        now = time.monotonic()
        # Prune old entries on every write to bound memory growth
        cutoff = now - 3600
        if self._entries and self._entries[0][0] <= cutoff:
            self._entries = [(t, c) for t, c in self._entries if t > cutoff]
        self._entries.append((now, cost))
