"""Memex as an MCP server — expose capabilities to external agents.

Scoped tool sets: read_only, collaborative, full.
Uses FastMCP (already a dependency).
"""

from __future__ import annotations

import atexit
import json
import os
import uuid

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from memex.utcnow import utcnow

load_dotenv()

from memex.interfaces.api import MemexAPI  # noqa: E402
from memex.interfaces.caller import CallerContext  # noqa: E402
from memex.interfaces.rate_limiting import CallerRateLimits, CircuitBreaker, CostGuard  # noqa: E402
from memex.models import GoalPriority, GoalStatus  # noqa: E402

# Scope definitions
_READ_ONLY_TOOLS = {
    "memex_status",
    "memex_self_state",
    "memex_goal_list",
    "memex_goal_show",
    "memex_search",
}
_COLLABORATIVE_TOOLS = _READ_ONLY_TOOLS | {"memex_chat", "memex_goal_create"}
_FULL_TOOLS = _COLLABORATIVE_TOOLS | {
    "memex_goal_update",
    "memex_ingest",
    "memex_ingest_url",
}


def create_app(
    *,
    scope: str = "read_only",
    store_path: str | None = None,
) -> FastMCP:
    """Create and configure the external MCP server.

    Args:
        scope: Tool scope — "read_only", "collaborative", or "full".
        store_path: Override store path.
    """
    api = MemexAPI.create(store_path)
    atexit.register(api.close)

    app = FastMCP("memex")
    rate_limiter = CallerRateLimits()
    circuit = CircuitBreaker()
    cost_guard = CostGuard()

    allowed = {
        "read_only": _READ_ONLY_TOOLS,
        "collaborative": _COLLABORATIVE_TOOLS,
        "full": _FULL_TOOLS,
    }.get(scope, _READ_ONLY_TOOLS)

    def _caller() -> CallerContext:
        return CallerContext.owner("mcp", f"mcp_{utcnow().strftime('%Y%m%d')}")

    def _gate(tool_name: str) -> str | None:
        """Return error string if call should be blocked, None if OK."""
        if tool_name not in allowed:
            return f"Tool '{tool_name}' not available in '{scope}' scope"
        if circuit.is_open:
            return "Service temporarily unavailable (circuit breaker open)"
        if not rate_limiter.allow():
            return "Rate limit exceeded"
        if not cost_guard.check():
            return "Hourly cost budget exceeded"
        return None

    # -- Tools ---------------------------------------------------------

    @app.tool()
    def memex_status() -> str:
        """Get Memex system status — goals, session, connectors."""
        err = _gate("memex_status")
        if err:
            return err
        status = api.status(_caller())
        lines = [
            f"Goals: {status['goals_total']} total, {status['goals_active']} active",
        ]
        if status["session_id"]:
            lines.append(
                f"Session: {status['session_id']} ({status['session_turns']} turns)"
            )
        for c in status.get("connectors", []):
            icon = "+" if c["status"] == "connected" else "-"
            lines.append(f"  [{icon}] {c['name']}: {c['status']}")
        circuit.record_success()
        return "\n".join(lines)

    @app.tool()
    def memex_self_state() -> str:
        """Get rich Memex runtime self-state as JSON."""
        err = _gate("memex_self_state")
        if err:
            return err
        state = api.self_state(_caller())
        circuit.record_success()
        return json.dumps(state, indent=2, sort_keys=True, default=str)

    @app.tool()
    def memex_goal_list(include_all: bool = False) -> str:
        """List goals. Set include_all=True for non-active goals too."""
        err = _gate("memex_goal_list")
        if err:
            return err
        intents = api.intent(_caller(), include_all=include_all)
        if not intents:
            return "No goals found."
        lines = []
        for g in intents:
            status_str = f" [{g['status']}]" if g["status"] != "active" else ""
            lines.append(
                f"- {g['title']}{status_str} ({g['priority']}) [{g['goal_id'][:8]}]"
            )
        circuit.record_success()
        return "\n".join(lines)

    @app.tool()
    def memex_goal_show(goal_id: str) -> str:
        """Show details of a specific goal."""
        err = _gate("memex_goal_show")
        if err:
            return err
        goal = api.store.get_goal(goal_id)
        if not goal:
            # Try prefix match
            all_goals = api.store.list_goals()
            matches = [g for g in all_goals if g.goal_id.startswith(goal_id)]
            if len(matches) == 1:
                goal = matches[0]
            else:
                return f"Goal not found: {goal_id}"
        circuit.record_success()
        return (
            f"Title: {goal.title}\n"
            f"Status: {goal.status.value}\n"
            f"Priority: {goal.priority.value}\n"
            f"Description: {goal.description or '(none)'}\n"
            f"Created: {goal.created_at}"
        )

    @app.tool()
    def memex_search(query: str) -> str:
        """Search Memex knowledge store."""
        err = _gate("memex_search")
        if err:
            return err
        results = api.search(query, _caller())
        if not results:
            return "No results found."
        lines = []
        for r in results:
            lines.append(f"- [{r['type']}] {r['title']}: {r['snippet']}")
        circuit.record_success()
        return "\n".join(lines)

    @app.tool()
    def memex_chat(message: str) -> str:
        """Send a conversational message to Memex."""
        err = _gate("memex_chat")
        if err:
            return err
        try:
            response, _ = api.chat(message, _caller())
            circuit.record_success()
            return response
        except Exception as exc:
            circuit.record_failure()
            return f"Error: {exc}"

    @app.tool()
    def memex_goal_create(
        title: str,
        description: str = "",
        parent_id: str | None = None,
        priority: str = "medium",
        blocked_by_goal_id: str | None = None,
    ) -> str:
        """Create a new goal in Memex."""
        err = _gate("memex_goal_create")
        if err:
            return err
        from memex.models import Goal

        now = utcnow()
        goal = Goal(
            goal_id=str(uuid.uuid4()),
            parent_id=parent_id,
            title=title,
            description=description,
            priority=GoalPriority(priority),
            status=GoalStatus.ACTIVE,
            blocked_by_goal_id=blocked_by_goal_id,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        api.store.create_goal(goal)
        circuit.record_success()

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalCreated

            get_bus().publish(
                GoalCreated(
                    goal_id=goal.goal_id, title=goal.title, parent_id=goal.parent_id
                )
            )
        except Exception:
            pass

        return f"Created goal: {goal.title} [{goal.goal_id[:8]}]"

    @app.tool()
    def memex_goal_update(
        goal_id: str,
        status: str | None = None,
        title: str | None = None,
        priority: str | None = None,
        blocked_by_goal_id: str | None = None,
    ) -> str:
        """Update an existing goal."""
        err = _gate("memex_goal_update")
        if err:
            return err
        goal = api.store.get_goal(goal_id)
        if not goal:
            return f"Goal not found: {goal_id}"
        old_status = goal.status.value
        now = utcnow()
        if status is not None:
            goal.status = GoalStatus(status)
        if title is not None:
            goal.title = title
        if priority is not None:
            goal.priority = GoalPriority(priority)
        if blocked_by_goal_id is not None:
            goal.blocked_by_goal_id = blocked_by_goal_id
        goal.updated_at = now
        goal.last_touched_at = now
        api.store.update_goal(goal)
        circuit.record_success()

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalStatusChanged, GoalUpdated

            if status is not None:
                get_bus().publish(
                    GoalStatusChanged(
                        goal_id=goal.goal_id,
                        title=goal.title,
                        old_status=old_status,
                        new_status=goal.status.value,
                    )
                )
            else:
                get_bus().publish(GoalUpdated(goal_id=goal.goal_id, title=goal.title))
        except Exception:
            pass

        return f"Updated goal: {goal.title} [{goal.goal_id[:8]}]"

    @app.tool()
    def memex_ingest(content: str, title: str = "", item_type: str = "note") -> str:
        """Ingest content into the Memex knowledge store."""
        err = _gate("memex_ingest")
        if err:
            return err
        try:
            from memex.memory.intake import ingest
            from memex.models import ItemType

            item = ingest(
                content,
                type=ItemType(item_type),
                title=title or content[:50],
                content_store=api.store.content,
                memex_store=api.store,
                generate_summary=False,
            )
            circuit.record_success()
            return f"Ingested: {item.title} [{item.item_id[:8]}]"
        except Exception as exc:
            circuit.record_failure()
            return f"Ingest failed: {exc}"

    @app.tool()
    def memex_ingest_url(url: str, tags: str = "", item_type: str = "article") -> str:
        """Fetch a URL, extract its content, and save to the knowledge store."""
        err = _gate("memex_ingest_url")
        if err:
            return err
        try:
            from memex.memory.intake import ingest_from_url
            from memex.models import ItemType

            tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
            item = ingest_from_url(
                url,
                tags=tag_list,
                item_type=ItemType(item_type),
                content_store=api.store.content,
                memex_store=api.store,
            )
            circuit.record_success()
            return (
                f"Ingested: {item.title} [{item.item_id[:8]}]\n"
                f"Type: {item.type.value} | Words: {len(item.body.split())}"
            )
        except ValueError as exc:
            circuit.record_failure()
            return f"Extraction failed: {exc}"
        except Exception as exc:
            circuit.record_failure()
            return f"Ingest failed: {exc}"

    # -- Resources -----------------------------------------------------

    @app.resource("memex://goals")
    def resource_goals() -> str:
        """All goals as formatted text."""
        intents = api.intent(_caller())
        if not intents:
            return "No goals."
        return "\n".join(
            f"[{g['goal_id'][:8]}] {g['title']} — {g['status']} ({g['priority']})"
            for g in intents
        )

    return app


def main() -> None:
    """Run the external MCP server with stdio transport."""
    scope = os.environ.get("MEMEX_MCP_SCOPE", "read_only")
    app = create_app(scope=scope)
    app.run(transport="stdio")
