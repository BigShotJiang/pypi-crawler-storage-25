"""Shared JSON serialization helpers for the memex service interfaces.

These functions are used by service.py, event_bridge.py, and service_client.py
to convert model objects to JSON-safe dicts and coerce non-serializable values.
"""

from __future__ import annotations

import dataclasses
from typing import Any


def coerce_json(obj: Any) -> Any:
    """Recursively coerce *obj* to a JSON-serializable value.

    Conversion rules (in order):
    - dict  → recurse over values
    - list/tuple → recurse, always return list
    - objects with .isoformat() (datetime, date, time) → ISO string
    - str, int, float, bool, None → unchanged
    - anything else → str(obj), or None if str() also raises
    """
    if isinstance(obj, dict):
        return {k: coerce_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [coerce_json(v) for v in obj]
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    try:
        return str(obj)
    except Exception:
        return None


def model_to_dict(obj: Any) -> Any:
    """Serialize a model object to a JSON-compatible value.

    Conversion rules (in order):
    - None  → None
    - list  → recursively convert each element
    - dataclass → dataclasses.asdict()
    - Pydantic v2 (model_dump) → .model_dump()
    - Pydantic v1 (dict) → .dict()
    - generic object → vars()
    - anything else (primitive, enum, …) → returned unchanged

    The result is always passed through coerce_json() to ensure all nested
    values are JSON-safe.
    """
    if obj is None:
        return None
    if isinstance(obj, list):
        return [model_to_dict(item) for item in obj]
    if isinstance(obj, dict):
        return coerce_json(obj)
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        raw = dataclasses.asdict(obj)
    elif hasattr(obj, "model_dump"):
        raw = obj.model_dump()
    elif hasattr(obj, "dict") and callable(obj.dict):
        raw = obj.dict()
    elif hasattr(obj, "__dict__"):
        raw = dict(vars(obj))
    else:
        return obj
    return coerce_json(raw)
