"""CallerContext — frozen identity for every API call."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from memex.utcnow import utcnow


@dataclass(frozen=True)
class CallerContext:
    """Immutable identity attached to every MemexAPI call.

    Captures *who* is calling (interface), *which* session, and
    when the call was made. Used for audit enrichment and
    format selection.
    """

    interface: str  # "cli", "telegram", "tui", "mcp", "test"
    session_id: str
    user_id: str = ""
    created_at: datetime = field(default_factory=utcnow)

    @classmethod
    def owner(
        cls, interface: str, session_id: str, *, user_id: str = ""
    ) -> CallerContext:
        """Convenience factory for human-owner callers."""
        return cls(interface=interface, session_id=session_id, user_id=user_id)
