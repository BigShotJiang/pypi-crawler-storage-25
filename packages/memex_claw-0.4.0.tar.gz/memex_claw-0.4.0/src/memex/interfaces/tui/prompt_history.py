"""Persistent prompt history for TUI input bar."""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from memex.utcnow import utcnow


_HISTORY_FILE = "tui_prompt_history.json"
_MAX_ENTRIES = 20
_MAX_AGE_HOURS = 48


class PromptHistory:
    """Stores recent prompts as JSON, pruning old entries on load."""

    def __init__(self, path: Path | None = None) -> None:
        if path is None:
            path = Path("~/.memex").expanduser() / _HISTORY_FILE
        self._path = path
        self._entries: list[dict] = []

    def load(self) -> None:
        """Read history file, prune stale entries, trim to cap."""
        try:
            data = json.loads(self._path.read_text())
            if not isinstance(data, list):
                data = []
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            data = []

        cutoff = utcnow() - timedelta(hours=_MAX_AGE_HOURS)
        pruned = []
        for entry in data:
            if not isinstance(entry, dict) or "text" not in entry:
                continue
            ts_str = entry.get("ts", "")
            try:
                ts = datetime.fromisoformat(ts_str)
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                if ts < cutoff:
                    continue
            except (ValueError, TypeError):
                continue
            pruned.append(entry)

        self._entries = pruned[-_MAX_ENTRIES:]

    def save(self) -> None:
        """Write history to file with restrictive permissions."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(self._entries))
        os.chmod(self._path, 0o600)

    def add(self, text: str) -> None:
        """Append entry, skip consecutive duplicates, enforce cap, auto-save."""
        text = text.strip()
        if not text:
            return
        if self._entries and self._entries[-1]["text"] == text:
            return
        self._entries.append(
            {
                "text": text,
                "ts": utcnow().isoformat(),
            }
        )
        self._entries = self._entries[-_MAX_ENTRIES:]
        self.save()

    @property
    def entries(self) -> list[str]:
        """Return entry texts, oldest first."""
        return [e["text"] for e in self._entries]
