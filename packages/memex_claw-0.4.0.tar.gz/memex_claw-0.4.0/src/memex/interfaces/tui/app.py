"""Memex TUI — Full-width conversation with bottom drawers.

Layout:
  HeaderBar (top, 1 line)
  ConversationPanel (fills remaining space)
  IntentDrawer (bottom, 40%, toggled by Ctrl+N)
  AttentionDrawer (bottom, 40%, toggled by Ctrl+A)
  InputBar (bottom, 3-10 lines)
  FooterBar (bottom, 1 line)
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.interfaces.protocol import MemexClientProtocol

from textual import on, work
from textual.actions import SkipAction
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.events import Key
from textual.screen import ModalScreen
from textual.widgets import (
    Input,
    Label,
    ListView,
    ListItem,
    RadioSet,
    RadioButton,
    TextArea,
)

from memex.interfaces.tui.styles import APP_CSS
from memex.models import TurnCancelled
from memex.interfaces.tui.commands import SlashCommand, SlashCommandRegistry
from memex.interfaces.tui.widgets.attention_drawer import AttentionDrawer
from memex.interfaces.tui.widgets.base_drawer import BaseDrawer
from memex.interfaces.tui.widgets.command_hints import CommandHintPanel
from memex.interfaces.tui.widgets.conversation import ConversationPanel
from memex.interfaces.tui.widgets.footer_bar import FooterBar
from memex.interfaces.tui.widgets.header_bar import HeaderBar
from memex.interfaces.tui.widgets.input_bar import InputBar
from memex.interfaces.tui.widgets.intent_drawer import IntentDrawer
from memex.interfaces.tui.widgets.meeting_drawer import MeetingDrawer
from memex.interfaces.tui.widgets.scheduler_drawer import SchedulerDrawer
from memex.interfaces.tui.widgets.subagent_drawer import SubAgentDrawer

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Mode selector dialog
# ---------------------------------------------------------------------------


class ModeSelector(ModalScreen[str]):
    """Session mode selection dialog at startup."""

    DEFAULT_CSS = """
    ModeSelector {
        align: center middle;
    }

    #mode-dialog {
        width: 50;
        height: auto;
        max-height: 16;
        border: double $primary;
        padding: 1 2;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="mode-dialog"):
            yield Label("Select Session Mode", classes="title")
            yield RadioSet(
                RadioButton("Normal — balanced conversation", id="normal", value=True),
                RadioButton("Deep Work — minimize interruptions", id="deep_work"),
                RadioButton("Review — surface pending items", id="review"),
                RadioButton("Quick Check — terse status updates", id="quick_check"),
                id="mode-set",
            )

    @on(RadioSet.Changed)
    def on_mode_selected(self, event: RadioSet.Changed) -> None:
        mode_map = {0: "normal", 1: "deep_work", 2: "review", 3: "quick_check"}
        self.dismiss(mode_map.get(event.radio_set.pressed_index, "normal"))


# ---------------------------------------------------------------------------
# Meeting dialogs
# ---------------------------------------------------------------------------


class NewMeetingDialog(ModalScreen):
    """Dialog for creating a new meeting — title, attendees, and optional schedule."""

    DEFAULT_CSS = """
    NewMeetingDialog {
        align: center middle;
    }
    #new-meeting-dialog {
        width: 62;
        height: auto;
        border: double $primary;
        padding: 1 2;
    }
    #nm-hint {
        color: $text-muted;
        margin-top: 1;
    }
    """

    @staticmethod
    def _default_scheduled_for(now: datetime | None = None) -> datetime:
        current = now or utcnow()
        floored_minute = current.minute - (current.minute % 15)
        return current.replace(minute=floored_minute, second=0, microsecond=0)

    @staticmethod
    def _format_scheduled_for(value: datetime) -> str:
        return value.strftime("%Y-%m-%d %H:%M")

    @classmethod
    def _parse_scheduled_for(cls, raw: str) -> datetime | None:
        text = raw.strip()
        if not text:
            return None
        try:
            return datetime.fromisoformat(text)
        except ValueError:
            pass
        try:
            import dateparser

            return dateparser.parse(text)
        except Exception:
            return None

    def compose(self) -> ComposeResult:
        with Vertical(id="new-meeting-dialog"):
            yield Label("New Meeting")
            yield Input(placeholder="Meeting title (required)", id="nm-title")
            yield Input(
                placeholder="Attendees, comma-separated (optional)", id="nm-attendees"
            )
            yield Input(
                placeholder="When? (optional, e.g. 2026-03-20 14:00)", id="nm-scheduled"
            )
            yield Label(
                "Enter to create · Esc to cancel · Up/Down on time changes by 15 min",
                id="nm-hint",
            )

    def on_mount(self) -> None:
        scheduled = self.query_one("#nm-scheduled", Input)
        scheduled.value = self._format_scheduled_for(self._default_scheduled_for())
        self.query_one("#nm-title", Input).focus()

    @on(Input.Submitted, "#nm-title")
    def on_title_submitted(self, _event: Input.Submitted) -> None:
        self.query_one("#nm-attendees", Input).focus()

    @on(Input.Submitted, "#nm-attendees")
    def on_attendees_submitted(self, _event: Input.Submitted) -> None:
        self.query_one("#nm-scheduled", Input).focus()

    @on(Input.Submitted, "#nm-scheduled")
    def on_scheduled_submitted(self, _event: Input.Submitted) -> None:
        self._submit()

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.dismiss(None)
            return

        focused = self.focused
        if (
            getattr(focused, "id", None) == "nm-scheduled"
            and hasattr(focused, "value")
            and event.key in ("up", "down")
        ):
            event.prevent_default()
            delta = timedelta(minutes=15 if event.key == "up" else -15)
            current = (
                self._parse_scheduled_for(focused.value)
                or self._default_scheduled_for()
            )
            focused.value = self._format_scheduled_for(current + delta)

    def _submit(self) -> None:
        title = self.query_one("#nm-title", Input).value.strip()
        if not title:
            return
        attendees_raw = self.query_one("#nm-attendees", Input).value.strip()
        attendees = [a.strip() for a in attendees_raw.split(",") if a.strip()]
        scheduled_for = self.query_one("#nm-scheduled", Input).value.strip()
        self.dismiss(
            {
                "title": title,
                "attendees": attendees,
                "scheduled_for": scheduled_for or None,
            }
        )


class GoalParentDialog(ModalScreen):
    """Dialog for choosing whether a promoted action item becomes a sub-goal."""

    DEFAULT_CSS = """
    GoalParentDialog {
        align: center middle;
    }
    #goal-parent-dialog {
        width: 72;
        height: auto;
        max-height: 20;
        border: double $primary;
        padding: 1 2;
    }
    #goal-parent-list {
        height: 10;
        border: solid $secondary;
        margin: 1 0;
    }
    #goal-parent-hint {
        color: $text-muted;
    }
    """

    def __init__(
        self, goals: list[Any], selected_goal_id: str | None = None, **kwargs
    ) -> None:
        super().__init__(**kwargs)
        self._goals = goals
        self._selected_goal_id = selected_goal_id

    def compose(self) -> ComposeResult:
        with Vertical(id="goal-parent-dialog"):
            yield Label("Promote Action Item")
            yield Label("Choose a parent goal or keep it top-level.")
            yield ListView(id="goal-parent-list")
            yield Label("Enter select · Esc cancel", id="goal-parent-hint")

    def on_mount(self) -> None:
        lv = self.query_one("#goal-parent-list", ListView)
        lv.append(ListItem(Label("Top-level goal")))
        selected_index = 0
        for idx, goal in enumerate(self._goals, start=1):
            prefix = "• "
            if goal.goal_id == self._selected_goal_id:
                selected_index = idx
                prefix = "→ "
            lv.append(ListItem(Label(f"{prefix}{goal.title} [{goal.goal_id[:8]}]")))
        lv.index = selected_index
        lv.focus()

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.dismiss("__cancel__")

    @on(ListView.Selected, "#goal-parent-list")
    def on_selected(self, event: ListView.Selected) -> None:
        idx = event.list_view.index or 0
        if idx == 0:
            self.dismiss("__top_level__")
            return
        goal = self._goals[idx - 1]
        self.dismiss(goal.goal_id)


class ConfirmDialog(ModalScreen):
    """Simple yes/no confirmation dialog."""

    DEFAULT_CSS = """
    ConfirmDialog {
        align: center middle;
    }
    #confirm-dialog {
        width: 50;
        height: auto;
        border: double $primary;
        padding: 1 2;
    }
    #confirm-hint {
        color: $text-muted;
        margin-top: 1;
    }
    """

    def __init__(self, message: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self._message = message

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-dialog"):
            yield Label(self._message)
            yield Label("y/Enter) confirm  n/Esc) cancel", id="confirm-hint")

    def on_key(self, event: Key) -> None:
        if event.key in ("y", "enter"):
            event.prevent_default()
            event.stop()
            self.dismiss(True)
        elif event.key in ("n", "escape"):
            event.prevent_default()
            event.stop()
            self.dismiss(False)


class AddActionItemDialog(ModalScreen):
    """Dialog to add a manual action item to a meeting."""

    DEFAULT_CSS = """
    AddActionItemDialog {
        align: center middle;
    }
    #add-item-dialog {
        width: 62;
        height: auto;
        border: double $primary;
        padding: 1 2;
    }
    #ai-hint {
        color: $text-muted;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="add-item-dialog"):
            yield Label("Add Action Item")
            yield Input(placeholder="Action item text (required)", id="ai-text")
            yield Input(placeholder="Assignee (optional)", id="ai-assignee")
            yield Label("Enter to add · Esc to cancel", id="ai-hint")

    def on_mount(self) -> None:
        self.query_one("#ai-text", Input).focus()

    @on(Input.Submitted, "#ai-text")
    def on_text_submitted(self, _event: Input.Submitted) -> None:
        self.query_one("#ai-assignee", Input).focus()

    @on(Input.Submitted, "#ai-assignee")
    def on_assignee_submitted(self, _event: Input.Submitted) -> None:
        self._submit()

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.dismiss(None)

    def _submit(self) -> None:
        text = self.query_one("#ai-text", Input).value.strip()
        if not text:
            return
        assignee = self.query_one("#ai-assignee", Input).value.strip()
        self.dismiss(
            {
                "text": text,
                "assignee": assignee,
                "deadline": "",
                "promoted_goal_id": None,
            }
        )


class MeetingDetailScreen(ModalScreen):
    """Meeting detail — view metadata, edit notes, manage action items."""

    DEFAULT_CSS = """
    MeetingDetailScreen {
        align: center middle;
    }
    #detail-container {
        width: 72;
        height: 28;
        border: double $primary;
        padding: 0 1;
    }
    #detail-title {
        text-style: bold;
        padding: 0 0 1 0;
    }
    #detail-notes {
        height: 5;
        border: solid $secondary;
        margin: 0 0 1 0;
    }
    #detail-recording-list {
        height: 6;
        border: solid $secondary;
        margin: 0 0 1 0;
    }
    #detail-action-list {
        height: 5;
        border: solid $secondary;
        margin: 0 0 1 0;
    }
    #detail-hints {
        color: $text-muted;
    }
    """

    BINDINGS = [
        Binding("escape", "close_detail", "Close"),
    ]

    def __init__(self, meeting: Any, store: Any, **kwargs) -> None:
        super().__init__(**kwargs)
        self._meeting = meeting
        self._store = store
        self._action_items: list[dict] = list(meeting.action_items)
        self._recordings: list[Any] = list(meeting.recordings)

    def compose(self) -> ComposeResult:
        m = self._meeting
        started = m.started_at.strftime("%Y-%m-%d %H:%M") if m.started_at else "—"
        if m.duration_seconds:
            mins = int(m.duration_seconds // 60)
            secs = int(m.duration_seconds % 60)
            dur = f"{mins}m{secs:02d}s" if mins else f"{secs}s"
        else:
            dur = "—"
        attendees_str = ", ".join(m.attendees) if m.attendees else "none"

        with Vertical(id="detail-container"):
            yield Label(f"{m.title or 'Untitled'} — {m.state.value}", id="detail-title")
            yield Label(
                f"Started: {started}  Duration: {dur}"
                f"  Speakers: {m.speaker_count or '—'}  Language: {m.language or '—'}"
            )
            yield Label(f"Attendees: {attendees_str}")
            yield Label(
                "── Recordings ────────────────────────────────────────────────"
            )
            yield ListView(id="detail-recording-list")
            yield Label(
                "── Notes ──────────────────────────────────────────────────────"
            )
            yield TextArea(m.notes or "", id="detail-notes")
            yield Label(
                "── Action Items ───────────────────────────────────────────────"
            )
            yield ListView(id="detail-action-list")
            yield Label(
                "t)retry recording  e)edit notes  i)add item  g)→goal  Tab cycle  Esc close",
                id="detail-hints",
            )

    def on_mount(self) -> None:
        self._refresh_recording_list()
        self._refresh_action_list()
        self.query_one("#detail-recording-list", ListView).focus()

    @staticmethod
    def _format_duration(seconds: float) -> str:
        if not seconds:
            return "—"
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m{secs:02d}s" if mins else f"{secs}s"

    def _refresh_recording_list(self) -> None:
        lv = self.query_one("#detail-recording-list", ListView)
        lv.clear()
        for rec in self._recordings:
            language = rec.language or "—"
            model = rec.whisper_model or "—"
            error = f"  ! {rec.error}" if rec.error else ""
            display = (
                f"#{rec.sequence_number}  {rec.state.value:<12}  "
                f"{self._format_duration(rec.duration_seconds):>6}  "
                f"{language:<4}  {model}{error}"
            )
            lv.append(ListItem(Label(display)))

    def _refresh_action_list(self) -> None:
        lv = self.query_one("#detail-action-list", ListView)
        lv.clear()
        for item in self._action_items:
            promoted = "→" if item.get("promoted_goal_id") else " "
            parent_hint = ""
            if item.get("promoted_goal_id") == "__pending__" and item.get(
                "promote_parent_goal_id"
            ):
                parent_hint = " ↳ sub-goal"
            assignee = item.get("assignee", "")
            text = item.get("text", "")
            display = (
                f"[{promoted}] {assignee + ': ' if assignee else ''}{text}{parent_hint}"
            )
            lv.append(ListItem(Label(display)))

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.action_close_detail()
            return

        focused = self.focused
        if isinstance(focused, TextArea):
            return
        # Not in TextArea
        if event.key == "e":
            event.prevent_default()
            self.query_one("#detail-notes", TextArea).focus()
        elif event.key == "i":
            event.prevent_default()
            self.push_screen(AddActionItemDialog(), self._on_action_item_added)
        elif event.key == "g":
            event.prevent_default()
            self._promote_selected_to_goal()
        elif event.key == "t":
            event.prevent_default()
            self._retry_selected_recording()

    def action_close_detail(self) -> None:
        notes = self.query_one("#detail-notes", TextArea).text
        self.dismiss({"notes": notes, "action_items": self._action_items})

    def _dismiss_with_retry(self, recording_id: str) -> None:
        notes = self.query_one("#detail-notes", TextArea).text
        self.dismiss(
            {
                "notes": notes,
                "action_items": self._action_items,
                "retry_recording_id": recording_id,
            }
        )

    def _on_action_item_added(self, result: dict | None) -> None:
        if result is None:
            return
        self._action_items.append(result)
        self._refresh_action_list()

    def _retry_selected_recording(self) -> None:
        lv = self.query_one("#detail-recording-list", ListView)
        idx = lv.index
        if idx is None or idx >= len(self._recordings):
            return
        recording = self._recordings[idx]
        if not getattr(recording, "audio_path", ""):
            return
        if recording.state.value not in {
            "failed",
            "recorded",
            "transcribed",
            "transcribed_poor",
            "ingested",
        }:
            return
        self._dismiss_with_retry(recording.recording_id)

    def _promote_selected_to_goal(self) -> None:
        """Mark the selected action item as pending promotion.

        Actual goal creation happens in app.py's _on_meeting_detail_closed()
        callback after the screen dismisses, where the store and event bus
        are both available for proper error handling and drawer refresh.
        """
        lv = self.query_one("#detail-action-list", ListView)
        idx = lv.index
        if idx is None or idx >= len(self._action_items):
            return
        item = self._action_items[idx]
        if item.get("promoted_goal_id"):
            return  # Already promoted or pending
        try:
            from memex.models import GoalStatus

            goals = self._store.list_goals(GoalStatus.ACTIVE)
            selected_goal_id = None
            app = self.app
            if hasattr(app, "_focal_goal_id"):
                selected_goal_id = getattr(app, "_focal_goal_id")
        except Exception:
            goals = []
            selected_goal_id = None

        if not goals:
            self._action_items[idx] = {
                **item,
                "promoted_goal_id": "__pending__",
                "promote_parent_goal_id": None,
            }
            self._refresh_action_list()
            return

        self.push_screen(
            GoalParentDialog(goals, selected_goal_id=selected_goal_id),
            lambda parent_goal_id, row_idx=idx: self._on_goal_parent_selected(
                row_idx, parent_goal_id
            ),
        )

    def _on_goal_parent_selected(self, idx: int, parent_goal_id: str | None) -> None:
        if idx >= len(self._action_items):
            return
        if parent_goal_id == "__cancel__":
            return
        if parent_goal_id == "__top_level__":
            parent_goal_id = None
        item = self._action_items[idx]
        if item.get("promoted_goal_id"):
            return
        self._action_items[idx] = {
            **item,
            "promoted_goal_id": "__pending__",
            "promote_parent_goal_id": parent_goal_id,
        }
        self._refresh_action_list()


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------


class MemexApp(App):
    """Memex TUI application — full-width conversation with bottom drawers."""

    TITLE = "Memex"
    CSS = APP_CSS

    BINDINGS = [
        Binding("escape", "cancel_turn", "Cancel", show=False, priority=True),
        Binding("f1", "help", "Help", priority=True),
        Binding("q", "quit_app", "Quit", priority=True),
        Binding("ctrl+q", "quit_app", "Quit", show=False, priority=True),
        Binding("ctrl+n", "toggle_intents", "Intents", priority=True),
        Binding("ctrl+a", "toggle_attention", "Attention", priority=True),
        Binding("ctrl+s", "toggle_scheduler", "Scheduler", priority=True),
        Binding("ctrl+e", "toggle_meetings", "Meetings", priority=True),
        Binding(
            "ctrl+p",
            "pause_recording_hotkey",
            "Pause Recording",
            show=False,
            priority=True,
        ),
        Binding(
            "ctrl+r",
            "stop_recording_hotkey",
            "Stop Recording",
            show=False,
            priority=True,
        ),
        Binding("ctrl+g", "toggle_subagents", "Sub-Agents", priority=True),
        Binding("ctrl+y", "copy_recent", "Copy", priority=True),
        Binding("a", "add_goal", "Add Goal"),
        Binding("tab", "focus_next", "Next Panel", show=False),
        Binding("shift+tab", "focus_previous", "Prev Panel", show=False),
    ]

    def __init__(
        self,
        api: MemexClientProtocol | None = None,
        mode: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._api = api
        self._mode = mode
        self._session = None
        self._session_id = str(uuid.uuid4())
        self._shutdown_event = threading.Event()
        self._cancel_event = threading.Event()
        self._turn_active = False
        self._last_esc_time: float = 0.0
        self._interrupted = False
        self._expire_timer: Any = (
            None  # Timer returned by set_timer; cancelled on new interrupt
        )
        self._focal_goal_id: str | None = None
        self._focal_goal_title: str = ""

        self._pending_skill_install: dict | None = None
        self._session_cost_usd: float = 0.0
        self._background_activities: dict[str, str] = {}
        self._audio_capture = None  # AudioCapture instance during recording
        self._recording_meeting_id: str | None = None
        self._recording_id: str | None = None
        self._recording_timer = None  # set_interval handle for level meter
        self._transcription_engine = None
        self._transcription_engine_error: str | None = None
        self._meeting_dialog_active: bool = False  # guard against duplicate dialogs
        self._service_connected: bool = (
            True  # tracks service reachability (service mode only)
        )
        self._notifications_cache: dict[
            str, dict
        ] = {}  # keyed by notification_id, used in service mode

        from memex.agents import SubAgentManager

        self._sub_agent_manager = SubAgentManager(
            runtime_registry=api.runtime_registry if api is not None else None,
        )

        self._command_registry = SlashCommandRegistry()
        self._register_commands()

    @property
    def _has_local_store(self) -> bool:
        """True when the api is a local MemexAPI with a direct store."""
        return hasattr(self._api, "store")

    def compose(self) -> ComposeResult:
        yield HeaderBar(id="header-bar")
        yield ConversationPanel(id="conversation")
        yield IntentDrawer(id="intent-drawer")
        yield AttentionDrawer(id="attention-drawer")
        yield SchedulerDrawer(id="scheduler-drawer")
        yield MeetingDrawer(id="meeting-drawer")
        yield SubAgentDrawer(id="subagent-drawer")
        with Vertical(id="input-area"):
            yield CommandHintPanel(id="command-hints")
            yield InputBar(id="input-bar")
        yield FooterBar(id="footer-bar")

    def on_mount(self) -> None:
        """Initialize on mount — load data, set mode, start background services."""
        self._load_initial_data()

        if self._mode is None:
            self.push_screen(ModeSelector(), self._on_mode_selected)
        else:
            self._set_mode(self._mode)

        self._subscribe_events()
        if not self._has_local_store:
            self._start_service_event_worker()
            footer = self.query_one("#footer-bar", FooterBar)
            footer.service_mode = True
        input_bar = self.query_one("#input-bar", InputBar)
        input_bar._hint_panel = self.query_one("#command-hints", CommandHintPanel)
        input_bar._match_commands = self._command_registry.match
        input_bar.focus()

    def on_key(self, event: Key) -> None:
        """Allow plain recording hotkeys when not typing."""
        if self._audio_capture is None or event.key not in ("r", "s", "p"):
            return
        if isinstance(self.screen, ModalScreen):
            return
        if isinstance(self.focused, (Input, TextArea)):
            return
        event.prevent_default()
        event.stop()
        if event.key in ("r", "s"):
            self._stop_recording()
        else:
            self._toggle_pause_recording()

    def _on_mode_selected(self, mode: str | None) -> None:
        if mode:
            self._set_mode(mode)

    def _set_mode(self, mode: str) -> None:
        self._mode = mode
        header = self.query_one("#header-bar", HeaderBar)
        header.update_mode(mode)

        conversation = self.query_one("#conversation", ConversationPanel)
        from memex.interfaces.formats import SessionMode, get_mode_description

        try:
            session_mode = SessionMode(mode)
            desc = get_mode_description(session_mode)
            if desc:
                conversation.add_message("system", f"Mode: {mode} — {desc}")
        except ValueError:
            conversation.add_message("system", f"Mode: {mode}")

    def _load_initial_data(self) -> None:
        """Load goals and status into widgets."""
        if self._api is None:
            return

        # Sweep stale recordings left by a previous crashed session.
        # AudioCapture is in-process; when the process dies the stream/file are
        # reclaimed by the OS — only the DB row survives.
        # RECORDING → FAILED, TRANSCRIBING → RECORDED (audio intact, re-runnable).
        try:
            cleaned = self._api.cleanup_stale_recordings()
            if cleaned:
                logger.debug("Startup: cleaned %d stale recording(s)", cleaned)
            else:
                logger.debug("Startup: state sweep found no stale recording(s)")
        except Exception:
            logger.debug("Failed to clean stale recordings on startup", exc_info=True)

        # Load goals into intent drawer
        try:
            intents = self._api.intent(self._make_caller())
            drawer = self.query_one("#intent-drawer", IntentDrawer)
            drawer.load_goals(intents)
        except Exception:
            logger.debug("Failed to load goals into intent drawer", exc_info=True)

        # Load notifications into attention drawer
        self._load_attention_data()

        # Update header bar with status
        try:
            status = self._api.status(self._make_caller())
            header = self.query_one("#header-bar", HeaderBar)
            header.update_mode(self._mode or "normal")
            active = status.get("goals_active", 0)
            if active > 0:
                header.update_goal(f"{active} active goals")
        except Exception:
            logger.debug("Failed to update header bar status", exc_info=True)

    # ── Domain event subscriptions ──

    def _subscribe_events(self) -> None:
        """Subscribe to domain events for reactive TUI updates.

        In service mode the local EventBus is never fired — the SSE event
        worker (``_start_service_event_worker``) handles remote events instead.
        """
        if not self._has_local_store:
            return
        try:
            from memex.event_bus import get_bus
            from memex.events import (
                GoalChanged,
                NotificationCreated,
                NotificationDismissed,
                TaskRunCompleted,
                MeetingStateChanged,
                MeetingTranscribed,
                ItemIngested,
                SubAgentStarted,
                SubAgentCompleted,
                SubAgentCancelled,
                ActivityStarted,
                ActivityUpdated,
                ActivityFinished,
                UsageRecorded,
            )

            bus = get_bus()
            bus.subscribe(GoalChanged, self._on_goal_event)
            bus.subscribe(NotificationCreated, self._on_notification_event)
            bus.subscribe(NotificationDismissed, self._on_notification_event)
            bus.subscribe(TaskRunCompleted, self._on_scheduler_event)
            bus.subscribe(MeetingStateChanged, self._on_meeting_event)
            bus.subscribe(MeetingTranscribed, self._on_meeting_event)
            bus.subscribe(ItemIngested, self._on_item_event)
            bus.subscribe(SubAgentStarted, self._on_subagent_event)
            bus.subscribe(SubAgentCompleted, self._on_subagent_event)
            bus.subscribe(SubAgentCancelled, self._on_subagent_event)
            bus.subscribe(ActivityStarted, self._on_activity_event)
            bus.subscribe(ActivityUpdated, self._on_activity_event)
            bus.subscribe(ActivityFinished, self._on_activity_event)
            bus.subscribe(UsageRecorded, self._on_usage_event)
        except Exception:
            logger.debug("Failed to subscribe to domain events", exc_info=True)

    def _on_goal_event(self, event: object) -> None:
        """Refresh intent drawer when goals change."""
        try:
            self.call_from_thread(self._refresh_intent_drawer)
        except Exception:
            logger.debug("Failed to refresh intents from event", exc_info=True)

    def _refresh_intent_drawer(self) -> None:
        """Reload goals into intent drawer and update header count. Runs on main thread."""
        if self._api is None:
            return
        try:
            intents = self._api.intent(self._make_caller())
            drawer = self.query_one("#intent-drawer", IntentDrawer)
            drawer.load_goals(intents)

            # Update header bar goal count
            active = sum(1 for g in intents if g.get("status") == "active")
            header = self.query_one("#header-bar", HeaderBar)
            header.update_goal(f"{active} active goals")
        except Exception:
            logger.debug("Failed to refresh intent drawer", exc_info=True)

    def _on_notification_event(self, event: object) -> None:
        """Refresh attention drawer when notifications change."""
        try:
            if self._api is None:
                return
            self.call_from_thread(self._load_attention_data)
        except Exception:
            logger.debug("Failed to refresh attention from event", exc_info=True)

    def _on_scheduler_event(self, event: object) -> None:
        """Refresh scheduler drawer when task runs complete."""
        try:
            self.call_from_thread(self._load_scheduler_data)
        except Exception:
            logger.debug("Failed to refresh scheduler from event", exc_info=True)

    def _on_meeting_event(self, event: object) -> None:
        """Refresh meeting drawer when meetings are transcribed."""
        try:
            self.call_from_thread(self._load_meeting_data)
        except Exception:
            logger.debug("Failed to refresh meetings from event", exc_info=True)

    def _on_item_event(self, event: object) -> None:
        """Surface item ingestion in conversation if relevant."""
        try:
            from memex.events import ItemIngested

            if isinstance(event, ItemIngested) and not event.is_update:
                conversation = self.query_one("#conversation", ConversationPanel)
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Ingested: {event.title} ({event.item_type})",
                )
        except Exception:
            logger.debug("Failed to surface item event", exc_info=True)

    def _on_subagent_event(self, event: object) -> None:
        """Update header badge and refresh drawer on sub-agent events."""
        try:
            self.call_from_thread(self._refresh_subagent_state)
        except Exception:
            logger.debug("Failed to handle sub-agent event", exc_info=True)

    def _on_activity_event(self, event: object) -> None:
        """Refresh header activity badge on background activity changes."""
        try:
            self.call_from_thread(self._refresh_activity_state, event)
        except Exception:
            logger.debug("Failed to handle activity event", exc_info=True)

    def _on_usage_event(self, event: object) -> None:
        """Update header cost when background work reports usage."""
        try:
            self.call_from_thread(self._apply_usage_event, event)
        except Exception:
            logger.debug("Failed to handle usage event", exc_info=True)

    def _refresh_subagent_state(self) -> None:
        """Update header QQ badge and refresh drawer if open. Runs on main thread."""
        header = self.query_one("#header-bar", HeaderBar)
        header.agent_count = self._sub_agent_manager.running_count
        drawer = self.query_one("#subagent-drawer", SubAgentDrawer)
        if drawer.is_open:
            self._load_subagent_data()

    def _refresh_activity_state(self, event: object) -> None:
        """Update header activity badge from activity events. Runs on main thread."""
        from memex.events import ActivityFinished, ActivityStarted, ActivityUpdated

        if isinstance(event, ActivityStarted) and event.background:
            self._background_activities[event.activity_id] = event.label
        elif isinstance(event, ActivityUpdated) and event.background:
            if event.activity_id in self._background_activities:
                self._background_activities[event.activity_id] = event.label
        elif isinstance(event, ActivityFinished):
            self._background_activities.pop(event.activity_id, None)

        header = self.query_one("#header-bar", HeaderBar)
        labels = list(self._background_activities.values())
        latest = labels[-1] if labels else ""
        header.update_activity(len(self._background_activities), latest)

    def _apply_usage_event(self, event: object) -> None:
        """Update session cost for background usage tied to this TUI session."""
        from memex.events import UsageRecorded

        if not isinstance(event, UsageRecorded):
            return
        if event.session_id and event.session_id != self._session_id:
            return
        if event.cost_usd <= 0:
            return

        self._session_cost_usd += event.cost_usd
        header = self.query_one("#header-bar", HeaderBar)
        header.update_cost(f"${self._session_cost_usd:.2f}")
        self._sync_session_runtime_state()

    def _load_attention_data(self) -> None:
        """Load notifications into the attention drawer."""
        if self._api is None:
            return
        try:
            if self._has_local_store:
                ns = self._api.notification_store
                notifications = ns.list_pending(limit=20)
                notif_data = []
                for n in notifications:
                    notif_data.append(
                        {
                            "notification_id": n.notification_id,
                            "title": n.title,
                            "body": n.body,
                            "priority": n.priority.value,
                            "source": n.source,
                            "created_at": n.created_at.strftime("%Y-%m-%d %H:%M"),
                            "action_type": n.action_type,
                            "action_data": n.action_data,
                        }
                    )
            else:
                # Service mode: fetch via protocol
                notif_data = self._api.list_notifications(unread_only=True)

            self._notifications_cache = {
                n.get("notification_id", ""): n
                for n in notif_data
                if n.get("notification_id")
            }
            drawer = self.query_one("#attention-drawer", AttentionDrawer)
            drawer.load_notifications(notif_data)
        except Exception:
            logger.warning("Failed to load attention data", exc_info=True)
            try:
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system",
                    "⚠ Could not load notifications — use /search_logs to investigate.",
                )
            except Exception:
                pass

    # ── Caller identity ──

    def _make_caller(self):
        from memex.interfaces.caller import CallerContext

        return CallerContext.owner("tui", self._session_id)

    def _runtime_registry(self):
        if self._api is None or not hasattr(self._api, "runtime_registry"):
            return None
        return self._api.runtime_registry

    def _set_interface_state(self, name: str, **kwargs) -> None:
        registry = self._runtime_registry()
        if registry is not None:
            registry.set_interface_state(name, **kwargs)

    def _sync_session_runtime_state(self) -> None:
        registry = self._runtime_registry()
        if registry is not None:
            registry.set_session(
                session_id=self._session_id,
                turn_count=self._session.turn_count if self._session is not None else 0,
                active_interface="tui",
                session_cost_usd=self._session_cost_usd,
            )

    def _set_active_recording_state(
        self, *, paused: bool, level: float | None = None
    ) -> None:
        registry = self._runtime_registry()
        if registry is None:
            return
        if self._recording_meeting_id is None or self._recording_id is None:
            registry.set_active_recording(None)
            return
        registry.set_active_recording(
            {
                "meeting_id": self._recording_meeting_id,
                "recording_id": self._recording_id,
                "paused": paused,
                "level": 0.0 if level is None else level,
            }
        )

    # ── Input handling ──

    @on(InputBar.UserInput)
    def on_user_input(self, event: InputBar.UserInput) -> None:
        """Handle user input from the input bar."""
        if event.is_command:
            self._handle_command(event.value)
        else:
            self._handle_message(event.value, is_paste=event.is_paste)

    def _register_commands(self) -> None:
        """Register all slash commands in the registry."""
        r = self._command_registry

        def _cmd_help(app, args):
            conversation = app.query_one("#conversation", ConversationPanel)
            lines = ["Commands:"]
            lines.extend(app._command_registry.help_lines())
            lines.append("")
            lines.append(
                "Keys: F1 help · Esc interrupt · Ctrl+N intents · Ctrl+A attention "
                "· Ctrl+E meetings · Ctrl+G agents · Ctrl+Y copy · a add goal · q quit"
            )
            conversation.add_message("system", "\n".join(lines))

        def _cmd_status(app, args):
            conversation = app.query_one("#conversation", ConversationPanel)
            if app._api:
                status = app._api.status(app._make_caller())
                conversation.add_message(
                    "system",
                    f"Goals: {status['goals_active']} active / {status['goals_total']} total",
                )
            else:
                conversation.add_message("system", "No API configured.")

        def _cmd_mode(app, args):
            conversation = app.query_one("#conversation", ConversationPanel)
            if args:
                app._set_mode(args)
            else:
                conversation.add_message("system", f"Current mode: {app._mode}")

        def _cmd_search(app, args):
            if args:
                app._do_search(args)
            else:
                app.query_one("#conversation", ConversationPanel).add_message(
                    "system", "Usage: /search <query>"
                )

        def _cmd_goals(app, args):
            app.action_toggle_intents()

        def _cmd_attn(app, args):
            app.action_toggle_attention()

        def _cmd_schedule(app, args):
            app.action_toggle_scheduler()

        def _cmd_meetings(app, args):
            app.action_toggle_meetings()

        def _cmd_gmail(app, args):
            if not args:
                conversation = app.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system",
                    "Usage: /gmail <query>\n"
                    "Examples: /gmail from:alice@co.com  ·  /gmail subject:invoice after:2025/01/01",
                )
            else:
                app._do_gmail_search(args)

        def _cmd_qq(app, args):
            app._handle_qq_command(args)

        def _cmd_model(app, args):
            app._handle_model_command(args)

        def _cmd_skill(app, args):
            app._handle_skill_command(args)

        def _cmd_plugin(app, args):
            app._handle_plugin_command(args)

        def _cmd_clear(app, args):
            # Clear the LLM context window
            if app._session is not None:
                app._session.conversation_history.clear()
                app._session.conversation_summary = ""
            # Clear the display
            conversation = app.query_one("#conversation", ConversationPanel)
            conversation.clear_messages()

        def _cmd_quit(app, args):
            app.action_quit_app()

        r.register(SlashCommand("/clear", _cmd_clear, (), "— clear conversation"))
        r.register(SlashCommand("/help", _cmd_help, ("/h", "/?"), "— show this help"))
        r.register(SlashCommand("/status", _cmd_status, (), "— show system status"))
        r.register(SlashCommand("/mode", _cmd_mode, (), "<mode> — set session mode"))
        r.register(
            SlashCommand("/search", _cmd_search, (), "<query> — search knowledge")
        )
        r.register(SlashCommand("/goals", _cmd_goals, (), "— toggle goals drawer"))
        r.register(SlashCommand("/attn", _cmd_attn, (), "— toggle attention drawer"))
        r.register(
            SlashCommand("/schedule", _cmd_schedule, (), "— toggle scheduler drawer")
        )
        r.register(
            SlashCommand(
                "/meetings", _cmd_meetings, ("/meeting",), "— toggle meetings drawer"
            )
        )
        r.register(SlashCommand("/gmail", _cmd_gmail, (), "<query> — search Gmail"))
        r.register(SlashCommand("/qq", _cmd_qq, (), "<question> — quick sub-agent"))
        r.register(
            SlashCommand("/model", _cmd_model, (), "[model] [effort] — set model")
        )
        r.register(SlashCommand("/skill", _cmd_skill, (), "install <url> | list"))
        r.register(SlashCommand("/plugin", _cmd_plugin, (), "install <url> | list"))

        def _cmd_bench(app, args):
            app._handle_bench(args)

        r.register(
            SlashCommand(
                "/bench",
                _cmd_bench,
                (),
                "[msg] — time a message through the full pipeline",
            )
        )
        r.register(SlashCommand("/quit", _cmd_quit, ("/q", "/exit"), "— quit"))

    def _handle_command(self, command: str) -> None:
        """Process / commands via the registry."""
        if self._command_registry.dispatch(self, command):
            return
        conversation = self.query_one("#conversation", ConversationPanel)
        parts = command.split(None, 1)
        cmd = parts[0].lower()
        conversation.add_message("system", f"Unknown command: {cmd}")

    def _handle_model_command(self, args: str | None) -> None:
        """Handle /model command: show or set model and reasoning effort.

        Usage:
          /model                          — show current config
          /model list                     — list available models
          /model opus-4-6                 — set response model
          /model opus-4-6 high            — set model + reasoning effort
          /model thinking high            — set reasoning effort only
          /model thinking off             — disable reasoning effort
          /model cheap haiku-4-5          — set cheap model
        """
        from memex.llm import (
            get_available_models,
            get_model_info,
            model_supports_thinking,
            set_cheap_model,
            set_reasoning_effort,
            set_response_model,
        )

        conversation = self.query_one("#conversation", ConversationPanel)

        if not args:
            info = get_model_info()
            effort = info["reasoning_effort"] or "off"
            conversation.add_message(
                "system",
                f"Response model: {info['response_model']}\n"
                f"Cheap model: {info['cheap_model']}\n"
                f"Reasoning effort: {effort}",
            )
            return

        tokens = args.strip().split()
        effort_levels = {"low", "medium", "high", "off"}

        # /model list
        if tokens[0] == "list":
            models = get_available_models()
            lines = ["Available models:", ""]
            for short, full, thinks in models:
                thinking_tag = " (thinking)" if thinks else ""
                lines.append(f"  {short:<14} {full}{thinking_tag}")
            lines.append("")
            lines.append("Usage: /model <name> [low|medium|high|off]")
            conversation.add_message("system", "\n".join(lines))
            return

        # /model thinking <level|off>
        if tokens[0] == "thinking":
            if len(tokens) < 2 or tokens[1] not in effort_levels:
                conversation.add_message(
                    "system", "Usage: /model thinking <low|medium|high|off>"
                )
                return
            level = None if tokens[1] == "off" else tokens[1]
            set_reasoning_effort(level)
            conversation.add_message("system", f"Reasoning effort: {tokens[1]}")
            return

        # /model cheap <model>
        if tokens[0] == "cheap":
            if len(tokens) < 2:
                conversation.add_message("system", "Usage: /model cheap <model-name>")
                return
            model = self._resolve_model_name(tokens[1])
            set_cheap_model(model)
            conversation.add_message("system", f"Cheap model: {model}")
            return

        # /model <model> [effort]
        model = self._resolve_model_name(tokens[0])
        set_response_model(model)
        msg = f"Response model: {model}"

        if len(tokens) > 1 and tokens[1] in effort_levels:
            level = None if tokens[1] == "off" else tokens[1]
            if level and not model_supports_thinking(model):
                conversation.add_message(
                    "system",
                    f"Response model: {model}\n"
                    f"Warning: {model} does not support thinking — reasoning effort ignored",
                )
                return
            set_reasoning_effort(level)
            msg += f"\nReasoning effort: {tokens[1]}"

        conversation.add_message("system", msg)

    def _handle_skill_command(self, args: str | None) -> None:
        """Handle /skill command.

        Usage:
          /skill install <url>   — install a skill from a GitHub SKILL.md URL
          /skill install --clawdbot  — install pending Clawdbot version
          /skill install --openclaw  — install pending OpenClaw version
          /skill install --cancel    — cancel pending skill install
          /skill list            — list installed skills
        """
        conversation = self.query_one("#conversation", ConversationPanel)

        if not args:
            conversation.add_message(
                "system",
                "Usage:\n"
                "  /skill install <url>  — install from GitHub SKILL.md URL\n"
                "  /skill list           — list installed skills",
            )
            return

        tokens = args.strip().split(None, 1)
        sub = tokens[0].lower()

        if sub == "list":
            self._skill_list(conversation)
        elif sub == "install":
            if len(tokens) < 2:
                conversation.add_message("system", "Usage: /skill install <url>")
                return
            install_arg = tokens[1].strip()
            # Handle pending-choice flags for clawdbot/openclaw decision
            if install_arg == "--clawdbot":
                self._skill_install_resolve("clawdbot", conversation)
            elif install_arg == "--openclaw":
                self._skill_install_resolve("openclaw", conversation)
            elif install_arg == "--cancel":
                self._skill_install_resolve("cancel", conversation)
            else:
                self._skill_install(install_arg, conversation)
        else:
            conversation.add_message("system", f"Unknown skill subcommand: {sub}")

    def _skill_list(self, conversation: ConversationPanel) -> None:
        """List all loaded skills."""
        mw = getattr(self._api, "_middleware_chain", None) if self._api else None
        skill_mw = getattr(mw, "skill_middleware", None) if mw else None
        if not skill_mw:
            conversation.add_message("system", "No skill registry available.")
            return
        skills = skill_mw._registry.all_skills()
        if not skills:
            conversation.add_message("system", "No skills installed.")
            return
        lines = [f"Installed skills ({len(skills)}):"]
        for s in skills:
            emoji = f"{s.emoji} " if s.emoji else ""
            lines.append(f"  {emoji}{s.name} — {s.description}")
        conversation.add_message("system", "\n".join(lines))

    def _skill_install(self, url: str, conversation: ConversationPanel) -> None:
        """Download and install a skill from a GitHub SKILL.md URL."""
        import re
        import urllib.request

        from memex.skills.install import (
            InstallAction,
            evaluate_skill,
        )

        # Convert GitHub blob URL to raw URL
        raw_url = url
        gh_match = re.match(r"https://github\.com/([^/]+/[^/]+)/blob/(.+)", url)
        if gh_match:
            raw_url = f"https://raw.githubusercontent.com/{gh_match.group(1)}/{gh_match.group(2)}"

        # Derive skill name from URL path
        # e.g. .../skills/matanle51/agentic-paper-digest/SKILL.md → agentic-paper-digest
        path_parts = url.rstrip("/").split("/")
        try:
            md_idx = path_parts.index("SKILL.md")
            skill_name = path_parts[md_idx - 1]
        except (ValueError, IndexError):
            skill_name = "unknown-skill"

        # Download
        try:
            req = urllib.request.Request(raw_url, headers={"User-Agent": "memex"})
            with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 — validated GitHub URL
                content = resp.read().decode("utf-8")
        except Exception as e:
            conversation.add_message("system", f"Failed to download: {e}")
            return

        # Evaluate for clawdbot/openclaw compatibility
        evaluation = evaluate_skill(content, skill_name)

        if evaluation.action == InstallAction.PROCEED:
            # Standard openclaw or no-namespace skill — install directly
            self._skill_write_and_register(content, skill_name, conversation)

        elif evaluation.action == InstallAction.PROCEED_OPENCLAW:
            # Clawdbot skill with a >= 90% similar OpenClaw version available
            conversation.add_message("system", evaluation.message)
            if evaluation.comparison is None:
                return
            self._skill_write_and_register(
                evaluation.comparison.openclaw_content,
                skill_name,
                conversation,
            )

        elif evaluation.action == InstallAction.PROCEED_CLAWDBOT_ONLY:
            # Clawdbot skill, no OpenClaw equivalent found
            conversation.add_message("system", evaluation.message)
            self._skill_write_and_register(content, skill_name, conversation)

        elif evaluation.action == InstallAction.CHOOSE:
            # Clawdbot skill with a different OpenClaw version — user must choose
            self._pending_skill_install = {
                "skill_name": skill_name,
                "clawdbot_content": content,
                "evaluation": evaluation,
            }
            conversation.add_message("system", evaluation.message)

    def _skill_install_resolve(
        self, choice: str, conversation: ConversationPanel
    ) -> None:
        """Resolve a pending clawdbot/openclaw install choice."""
        pending = self._pending_skill_install
        if pending is None:
            conversation.add_message("system", "No pending skill install to resolve.")
            return

        self._pending_skill_install = None
        skill_name = pending["skill_name"]
        evaluation = pending["evaluation"]

        if choice == "cancel":
            conversation.add_message("system", f"Cancelled install of '{skill_name}'.")
        elif choice == "clawdbot":
            conversation.add_message(
                "system",
                f"Installing Clawdbot version of '{skill_name}'.",
            )
            self._skill_write_and_register(
                pending["clawdbot_content"],
                skill_name,
                conversation,
            )
        elif choice == "openclaw":
            if evaluation.comparison is None:
                conversation.add_message("system", "No OpenClaw version available.")
                return
            conversation.add_message(
                "system",
                f"Installing OpenClaw version of '{skill_name}'.",
            )
            self._skill_write_and_register(
                evaluation.comparison.openclaw_content,
                skill_name,
                conversation,
            )

    def _skill_write_and_register(
        self,
        content: str,
        skill_name: str,
        conversation: ConversationPanel,
    ) -> None:
        """Write a SKILL.md to disk and register it in the live registry."""
        from pathlib import Path

        from memex.skills.loader import SkillLoader

        skill_dir = Path.home() / ".memex" / "skills" / skill_name
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text(content, encoding="utf-8")

        # Parse and register into live registry
        loader = SkillLoader([skill_dir.parent])
        loaded = loader.load_all()
        skill_def = next(
            (s for s in loaded if s.name == skill_name or s.base_dir == skill_dir),
            None,
        )

        if not skill_def:
            conversation.add_message(
                "system",
                f"Saved to {skill_file} but failed to parse. "
                "Check skill requirements or restart Memex.",
            )
            return

        # Register into live skill registry if available
        mw = getattr(self._api, "_middleware_chain", None) if self._api else None
        skill_mw = getattr(mw, "skill_middleware", None) if mw else None
        if skill_mw:
            skill_mw._registry.register(skill_def)

        emoji = f" {skill_def.emoji}" if skill_def.emoji else ""
        conversation.add_message(
            "system",
            f"Installed{emoji} {skill_def.name} — {skill_def.description}",
        )

    def _handle_plugin_command(self, args: str | None) -> None:
        """Handle /plugin command.

        Usage:
          /plugin install <url>  — install an OpenClaw plugin from a GitHub repo URL
          /plugin list           — list installed plugins
        """
        conversation = self.query_one("#conversation", ConversationPanel)

        if not args:
            conversation.add_message(
                "system",
                "Usage:\n"
                "  /plugin install <url>  — install from GitHub repo URL\n"
                "  /plugin list           — list installed plugins",
            )
            return

        tokens = args.strip().split(None, 1)
        sub = tokens[0].lower()

        if sub == "list":
            self._plugin_list(conversation)
        elif sub == "install":
            if len(tokens) < 2:
                conversation.add_message("system", "Usage: /plugin install <url>")
                return
            self._plugin_install(tokens[1].strip(), conversation)
        else:
            conversation.add_message("system", f"Unknown plugin subcommand: {sub}")

    def _plugin_list(self, conversation: ConversationPanel) -> None:
        """List installed OpenClaw plugins."""
        from memex.plugins import get_plugin_registry

        registry = get_plugin_registry()
        registry.scan()
        plugins = registry.all_plugins()
        if not plugins:
            conversation.add_message("system", "No plugins installed.")
            return
        lines = [f"Installed plugins ({len(plugins)}):"]
        for p in plugins:
            status_tag = f" [{p.status}]" if p.status != "installed" else ""
            lines.append(
                f"  {p.manifest.name} v{p.manifest.version}{status_tag} — {p.manifest.description}"
            )
        conversation.add_message("system", "\n".join(lines))

    def _plugin_install(self, url: str, conversation: ConversationPanel) -> None:
        """Install an OpenClaw plugin from a GitHub repo URL."""
        import re
        import shutil
        import subprocess
        import tempfile
        from pathlib import Path

        from memex.plugins import PluginInfo, get_plugin_registry, parse_manifest

        # Derive plugin name from URL
        # e.g. https://github.com/user/my-plugin → my-plugin
        # e.g. https://github.com/openclaw/plugins/tree/main/plugins/my-plugin → my-plugin
        url_clean = url.rstrip("/")

        # Detect subdirectory URLs (tree/main/...)
        tree_match = re.match(
            r"https://github\.com/([^/]+/[^/]+)/tree/([^/]+)/(.*)", url_clean
        )
        if tree_match:
            repo_url = f"https://github.com/{tree_match.group(1)}"
            branch = tree_match.group(2)
            subpath = tree_match.group(3)
            plugin_name = subpath.rstrip("/").split("/")[-1]
        else:
            repo_url = url_clean
            if repo_url.endswith(".git"):
                repo_url = repo_url[:-4]
            branch = None
            subpath = None
            plugin_name = url_clean.split("/")[-1]

        plugin_dir = Path.home() / ".memex" / "plugins" / plugin_name

        if plugin_dir.exists():
            conversation.add_message(
                "system", f"Plugin directory already exists: {plugin_dir}"
            )
            return

        # Clone the repo
        conversation.add_message("system", f"Installing {plugin_name}...")

        try:
            if subpath:
                # Clone full repo to temp, copy subpath
                with tempfile.TemporaryDirectory() as tmp:
                    cmd = ["git", "clone", "--depth", "1"]
                    if branch:
                        cmd += ["--branch", branch]
                    cmd += [repo_url, tmp + "/repo"]
                    subprocess.run(cmd, capture_output=True, check=True, timeout=60)
                    src = Path(tmp) / "repo" / subpath
                    if not src.is_dir():
                        conversation.add_message(
                            "system", f"Subdirectory not found: {subpath}"
                        )
                        return
                    plugin_dir.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(src, plugin_dir)
            else:
                # Clone directly
                plugin_dir.parent.mkdir(parents=True, exist_ok=True)
                cmd = ["git", "clone", "--depth", "1"]
                if branch:
                    cmd += ["--branch", branch]
                cmd += [repo_url, str(plugin_dir)]
                subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode(errors="replace") if e.stderr else str(e)
            conversation.add_message("system", f"Git clone failed: {stderr}")
            return
        except Exception as e:
            conversation.add_message("system", f"Install failed: {e}")
            return

        # Verify openclaw.plugin.json exists
        manifest_path = plugin_dir / "openclaw.plugin.json"
        if not manifest_path.is_file():
            shutil.rmtree(plugin_dir, ignore_errors=True)
            conversation.add_message(
                "system",
                f"No openclaw.plugin.json found — not a valid OpenClaw plugin. Removed {plugin_dir}.",
            )
            return

        # Parse manifest and register
        try:
            manifest = parse_manifest(manifest_path)
        except Exception as e:
            conversation.add_message("system", f"Failed to parse manifest: {e}")
            return

        registry = get_plugin_registry()
        info = PluginInfo(manifest=manifest)
        registry.register(info)

        # Publish event
        try:
            from memex.event_bus import safe_publish
            from memex.events import PluginInstalled

            safe_publish(
                PluginInstalled(
                    plugin_id=manifest.id,
                    name=manifest.name,
                    version=manifest.version,
                )
            )
        except Exception:
            pass

        # Check if npm install is needed
        has_package_json = (plugin_dir / "package.json").is_file()
        npm_note = ""
        if has_package_json:
            try:
                subprocess.run(
                    ["npm", "install", "--production"],
                    cwd=str(plugin_dir),
                    capture_output=True,
                    check=True,
                    timeout=120,
                )
            except Exception:
                npm_note = "\nNote: npm install failed — plugin may not work without dependencies."

        conversation.add_message(
            "system",
            f"Installed {manifest.name} v{manifest.version} — {manifest.description}\n"
            f"Restart Memex to load the plugin into the bridge.{npm_note}",
        )

    @staticmethod
    def _resolve_model_name(name: str) -> str:
        """Resolve short model names to full litellm model strings.

        Checks the known models registry first, then falls back to
        'anthropic/claude-<name>' for unregistered shortcuts.
        """
        from memex.llm import resolve_model_shortcut

        # Already fully qualified
        if "/" in name:
            return name
        # Check known models registry
        resolved = resolve_model_shortcut(name)
        if resolved:
            return resolved
        # Fallback: add claude- prefix if missing
        if not name.startswith("claude-"):
            name = f"claude-{name}"
        return f"anthropic/{name}"

    @staticmethod
    def _short_model(model: str) -> str:
        """Shorten model name for display: 'anthropic/claude-sonnet-4-20250514' → 'sonnet-4'."""
        name = model.rsplit("/", 1)[-1]  # strip provider prefix
        # Strip date suffix (e.g. -20250514)
        parts = name.split("-")
        # Find where the date suffix starts (8 consecutive digits)
        cleaned = []
        for part in parts:
            if len(part) == 8 and part.isdigit():
                continue
            cleaned.append(part)
        name = "-".join(cleaned)
        # Strip "claude-" prefix
        if name.startswith("claude-"):
            name = name[7:]
        return name

    @work(thread=True)
    def _handle_message(self, text: str, is_paste: bool = False) -> None:
        """Send message through API (in worker thread to avoid blocking)."""
        self._cancel_event.clear()
        self._turn_active = True
        self._interrupted = False
        conversation = self.query_one("#conversation", ConversationPanel)

        # Finalize any interrupted content from previous turn so it stays
        # visible as context for this follow-up message.
        # Partial text is visual-only — intentionally not in session history (#40).
        self.call_from_thread(conversation.finalize_interrupted)

        if is_paste:
            line_count = text.count("\n") + 1
            char_count = len(text)
            display = f"[PASTED: {line_count} ROWS, {char_count} CHARACTERS]"
            self.call_from_thread(conversation.add_message, "human", display)
        else:
            self.call_from_thread(conversation.add_message, "human", text)

        if self._api is None:
            self.call_from_thread(
                conversation.add_message,
                "system",
                "No API configured — running in demo mode.",
            )
            self._turn_active = False
            return

        try:
            from memex.interfaces.formats import SessionMode
            from memex.models import (
                TurnEvent,
                TurnPhase,
                ToolCallStarted,
                ToolCallCompleted,
                TurnCompleted,
            )

            mode = None
            try:
                mode = SessionMode(self._mode)
            except ValueError:
                pass

            # Track streaming state
            streaming_accumulated = []

            def on_event(event: TurnEvent) -> None:
                if self._cancel_event.is_set():
                    raise TurnCancelled()
                if isinstance(event, TurnPhase):
                    model_short = self._short_model(event.model) if event.model else ""
                    label = f"{event.phase}..." + (
                        f" ({model_short})" if model_short else ""
                    )
                    self.call_from_thread(conversation.show_processing, label)
                elif isinstance(event, ToolCallStarted):
                    self.call_from_thread(
                        conversation.add_tool_call, event.tool_name, event.arguments
                    )
                elif isinstance(event, ToolCallCompleted):
                    self.call_from_thread(
                        conversation.complete_tool_call,
                        event.tool_name,
                        event.success,
                        event.duration_ms,
                        event.summary,
                    )
                elif isinstance(event, TurnCompleted):
                    self.call_from_thread(conversation.hide_processing)
                    self.call_from_thread(self._update_header_from_turn, event)
                    self.call_from_thread(
                        conversation.add_turn_summary,
                        event.duration_ms,
                        event.tool_call_count,
                        event.cost_usd,
                        event.total_tokens,
                    )

            def on_token(chunk: str) -> None:
                if self._cancel_event.is_set():
                    raise TurnCancelled()
                streaming_accumulated.append(chunk)
                full = "".join(streaming_accumulated)
                self.call_from_thread(conversation.append_streaming, full)

            # Start streaming widget before the API call
            self.call_from_thread(conversation.start_streaming)

            response, self._session = self._api.chat(
                text,
                self._make_caller(),
                session=self._session,
                mode=mode,
                on_event=on_event,
                on_token=on_token,
            )

            # Check cancellation after API call returns (in case no callbacks fired)
            if self._cancel_event.is_set():
                raise TurnCancelled()

            # Finalize: remove streaming widget and write final response in one call
            # to prevent layout reflow between removal and content write
            def _finalize_turn():
                conversation.finish_streaming()
                conversation.add_message("assistant", response)

            self.call_from_thread(_finalize_turn)

            # Refresh intent drawer after conversation
            try:
                intents = self._api.intent(self._make_caller())
                drawer = self.query_one("#intent-drawer", IntentDrawer)
                self.call_from_thread(drawer.load_goals, intents)
            except Exception:
                logger.debug("Failed to refresh intent drawer", exc_info=True)
        except TurnCancelled:
            # action_cancel_turn handles UI cleanup on the main thread, but for
            # the hard-cancel case there is a race: start_streaming may have been
            # queued before _cancel_event was set and executes after action_cancel_turn
            # already ran finish_streaming (no-op at that point), leaving a zombie
            # streaming widget. Queuing finish_streaming here ensures it runs after
            # any pending start_streaming callback.
            if not self._interrupted:
                self.call_from_thread(conversation.hide_processing)
                self.call_from_thread(conversation.finish_streaming)
        except Exception as exc:
            self._interrupted = False
            self.call_from_thread(conversation.hide_processing)
            self.call_from_thread(conversation.finish_streaming)
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"Error: {exc}",
            )
        finally:
            self._turn_active = False

    @work(thread=True)
    def _handle_bench(self, args: str | None) -> None:
        """Run one or more messages through the full chat pipeline with timing.

        Uses the exact same api.chat() path as _handle_message — identical
        callbacks, session handling, and streaming.  Prints per-phase timing
        to the conversation panel.

        Usage:
          /bench                          — run default test suite
          /bench hi there                 — time a single message
          /bench 3 hi there              — repeat 3 times (warm-cache test)
        """
        import time as _time

        conversation = self.query_one("#conversation", ConversationPanel)

        _DEFAULT_SUITE = [
            "hi",
            "What do you know about my goals?",
            "What's Corey's current project?",
            "Remember that I like dark mode",
        ]

        # Parse args: optional repeat count + message
        repeat = 1
        messages: list[str] = []
        if not args:
            messages = _DEFAULT_SUITE
        else:
            parts = args.strip().split(None, 1)
            if parts[0].isdigit() and len(parts) > 1:
                repeat = int(parts[0])
                messages = [parts[1]]
            else:
                messages = [args.strip()]

        if self._api is None:
            self.call_from_thread(
                conversation.add_message, "system", "No API configured."
            )
            return

        from memex.models import TurnEvent, TurnPhase, ToolCallStarted, TurnCompleted

        results: list[str] = []
        for msg in messages:
            for r in range(repeat):
                label = msg[:40] + ("..." if len(msg) > 40 else "")
                if repeat > 1:
                    label = f"[{r + 1}/{repeat}] {label}"

                # Timing state captured by callbacks
                t_start = _time.monotonic()
                t_first_token = [0.0]
                t_phases: list[str] = []
                tool_names: list[str] = []
                turn_data: list[dict] = []

                def on_event(event: TurnEvent) -> None:
                    elapsed = int((_time.monotonic() - t_start) * 1000)
                    if isinstance(event, TurnPhase):
                        t_phases.append(f"{event.phase}@{elapsed}ms")
                    elif isinstance(event, ToolCallStarted):
                        tool_names.append(event.tool_name)
                    elif isinstance(event, TurnCompleted):
                        turn_data.append(
                            {
                                "total_ms": event.duration_ms,
                                "tokens": event.total_tokens,
                                "cost": event.cost_usd,
                                "tools": event.tool_call_count,
                            }
                        )

                def on_token(chunk: str) -> None:
                    if t_first_token[0] == 0.0:
                        t_first_token[0] = _time.monotonic()

                self.call_from_thread(
                    conversation.add_message, "human", f"[bench] {msg}"
                )
                self.call_from_thread(conversation.show_processing, "benchmarking...")

                try:
                    response, self._session = self._api.chat(
                        msg,
                        self._make_caller(),
                        session=self._session,
                        on_event=on_event,
                        on_token=on_token,
                    )
                except Exception as exc:
                    self.call_from_thread(conversation.hide_processing)
                    results.append(f"{label}: ERROR {exc}")
                    continue

                t_end = _time.monotonic()
                wall_ms = int((t_end - t_start) * 1000)
                ttft_ms = (
                    int((t_first_token[0] - t_start) * 1000) if t_first_token[0] else 0
                )

                self.call_from_thread(conversation.hide_processing)
                self.call_from_thread(conversation.add_message, "assistant", response)

                td = turn_data[0] if turn_data else {}
                line = (
                    f"{label}\n"
                    f"  wall={wall_ms}ms  ttft={ttft_ms}ms  server={td.get('total_ms', '?')}ms\n"
                    f"  phases: {', '.join(t_phases)}\n"
                    f"  tools({len(tool_names)}): {', '.join(tool_names) or 'none'}"
                )
                results.append(line)
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"[bench] {line}",
                )

        # Summary
        self.call_from_thread(
            conversation.add_message,
            "system",
            "--- Bench Results ---\n" + "\n\n".join(results),
        )

    def _update_header_from_turn(self, event: Any) -> None:
        """Update header bar with turn completion data."""
        from memex.prompt_budget import abbreviate_route

        header = self.query_one("#header-bar", HeaderBar)
        header.update_model(self._short_model(event.model))
        self._session_cost_usd += event.cost_usd
        header.update_cost(f"${self._session_cost_usd:.2f}")
        route_label = abbreviate_route(
            getattr(event, "route_profile", ""),
            getattr(event, "prompt_mode", "full"),
        )
        if route_label:
            header.update_route(route_label)
        self._sync_session_runtime_state()

    @work(thread=True)
    def _do_search(self, query: str) -> None:
        """Search knowledge store."""
        conversation = self.query_one("#conversation", ConversationPanel)
        if not self._api:
            self.call_from_thread(
                conversation.add_message, "system", "No API configured."
            )
            return

        results = self._api.search(query, self._make_caller())
        if not results:
            self.call_from_thread(
                conversation.add_message, "system", "No results found."
            )
            return

        lines = [f"Search results for '{query}':"]
        for r in results:
            lines.append(f"  [{r['type']}] {r['title']}")
        self.call_from_thread(conversation.add_message, "system", "\n".join(lines))

    @work(thread=True)
    def _do_gmail_search(self, query: str) -> None:
        """Search Gmail and ingest matching messages."""
        conversation = self.query_one("#conversation", ConversationPanel)
        from memex.telemetry import start_activity

        activity = start_activity(
            f"Gmail search: {query}",
            source="gmail_search",
            session_id=self._session_id,
            background=True,
            runtime_registry=self._api.runtime_registry
            if self._api is not None
            else None,
        )
        self.call_from_thread(
            conversation.add_message, "system", f"Searching Gmail: {query}..."
        )

        try:
            from memex.integrations.gmail import GmailClient

            client = GmailClient()
            client.authenticate()
            messages = client.search_messages(query)

            if not messages:
                activity.finish(label="Gmail search: 0 results")
                self.call_from_thread(
                    conversation.add_message, "system", "No messages found."
                )
                return

            activity.update(f"Gmail ingest: {len(messages)} messages")
            lines = [f"Found {len(messages)} messages:"]
            for m in messages:
                lines.append(
                    f"  {m.get('date', '')} — {m.get('subject', '(no subject)')}"
                )

            cs = (
                self._api.content_store
                if (self._api and self._has_local_store)
                else None
            )
            if cs is not None:
                # Build notification router for >3 URL notifications
                notification_router = None
                try:
                    from memex.notifications import NotificationRouter

                    ns = self._api.notification_store
                    notification_router = NotificationRouter(ns)
                except Exception:
                    pass

                from memex.auto_ingest.gmail import ingest_gmail_messages

                result = ingest_gmail_messages(
                    messages,
                    content_store=cs,
                    memex_store=getattr(self._api, "store", None)
                    if self._api
                    else None,
                    notification_router=notification_router,
                    tags=["gmail", "search", "manual"],
                    session_id=self._session_id,
                    activity_id=activity.activity_id,
                )
                lines.append(f"\nIngested {result.ingested}/{result.total} messages.")

            activity.finish(label=f"Gmail search complete: {len(messages)} messages")
            self.call_from_thread(conversation.add_message, "system", "\n".join(lines))
        except Exception as exc:
            activity.finish(success=False, label=f"Gmail search failed: {query}")
            self.call_from_thread(
                conversation.add_message, "system", f"Gmail search failed: {exc}"
            )

    # ── Sub-agent support ──

    def _handle_qq_command(self, args: str | None) -> None:
        """Handle /qq command: spawn, list, kill, or view sub-agents."""
        conversation = self.query_one("#conversation", ConversationPanel)

        if not args:
            conversation.add_message(
                "system",
                "Usage: /qq <question> — spawn quick sub-agent\n"
                "       /qq list — show active sub-agents\n"
                "       /qq kill <id> — cancel a sub-agent\n"
                "       /qq <N> — view completed sub-agent response",
            )
            return

        tokens = args.strip().split(None, 1)
        subcmd = tokens[0].lower()

        if subcmd == "list":
            agents = self._sub_agent_manager.list_agents()
            if not agents:
                conversation.add_message("system", "No sub-agents.")
                return
            lines = ["Sub-agents:"]
            for a in agents:
                lines.append(
                    f"  {a.agent_id}  [{a.status}]  {a.elapsed_display}  {a.label}"
                )
            conversation.add_message("system", "\n".join(lines))
            return

        if subcmd == "kill" and len(tokens) > 1:
            agent_id = tokens[1].strip()
            if self._sub_agent_manager.cancel(agent_id):
                conversation.add_message("system", f"Cancelled {agent_id}.")
                try:
                    from memex.event_bus import get_bus
                    from memex.events import SubAgentCancelled

                    agent = self._sub_agent_manager.get(agent_id)
                    get_bus().publish(
                        SubAgentCancelled(
                            agent_id=agent_id,
                            label=agent.label if agent else "",
                        )
                    )
                except Exception:
                    pass
            else:
                conversation.add_message(
                    "system", f"No running sub-agent with id '{agent_id}'."
                )
            return

        # /qq <N> — view by number, e.g. /qq 1 -> qq-1
        if subcmd.isdigit():
            agent_id = f"qq-{subcmd}"
            agent = self._sub_agent_manager.get(agent_id)
            if agent is None:
                conversation.add_message("system", f"No sub-agent '{agent_id}'.")
            elif agent.status == "running":
                conversation.add_message(
                    "system", f"{agent_id} is still running ({agent.elapsed_display})."
                )
            elif agent.status == "error":
                conversation.add_message("system", f"{agent_id} failed: {agent.error}")
            elif agent.status == "cancelled":
                conversation.add_message("system", f"{agent_id} was cancelled.")
            else:
                conversation.add_message(
                    "system",
                    f"[{agent_id}] {agent.label}\n({agent.elapsed_display})\n\n{agent.response or '(empty)'}",
                )
            return

        # Default: spawn a new sub-agent with the full args as the question
        question = args.strip()
        self._spawn_sub_agent(question)

    def _spawn_sub_agent(self, question: str) -> None:
        """Spawn a sub-agent worker for a quick question."""
        conversation = self.query_one("#conversation", ConversationPanel)

        if self._api is None:
            conversation.add_message(
                "system", "No API configured — cannot spawn sub-agent."
            )
            return

        try:
            session_id = str(uuid.uuid4())
            agent = self._sub_agent_manager.spawn(question, session_id)
        except RuntimeError as exc:
            conversation.add_message("system", str(exc))
            return

        conversation.add_message(
            "system", f'[{agent.agent_id} started] "{agent.label}"'
        )

        try:
            from memex.event_bus import get_bus
            from memex.events import SubAgentStarted

            get_bus().publish(
                SubAgentStarted(agent_id=agent.agent_id, label=agent.label)
            )
        except Exception:
            pass

        self._run_sub_agent(agent.agent_id, question, session_id)

    @work(thread=True)
    def _run_sub_agent(self, agent_id: str, question: str, session_id: str) -> None:
        """Worker thread for a sub-agent. Mirrors _handle_message pattern."""
        agent = self._sub_agent_manager.get(agent_id)
        if agent is None:
            return

        conversation = self.query_one("#conversation", ConversationPanel)

        try:
            from memex.interfaces.caller import CallerContext
            from memex.interfaces.formats import SessionMode
            from memex.models import TurnCancelled

            caller = CallerContext.owner("tui-qq", session_id)

            def on_event(event: object) -> None:
                if agent.cancel_event.is_set():
                    raise TurnCancelled()

            response, _ = self._api.chat(
                question,
                caller,
                mode=SessionMode("quick_check"),
                on_event=on_event,
            )

            if agent.cancel_event.is_set():
                raise TurnCancelled()

            self._sub_agent_manager.complete(agent_id, response)

            def _notify_done():
                conversation.add_message(
                    "system",
                    f'[{agent_id} done] ({agent.elapsed_display}) "{agent.label}"\n'
                    f"View with /qq {agent_id.split('-')[1]}",
                )

            self.call_from_thread(_notify_done)

            try:
                from memex.event_bus import get_bus
                from memex.events import SubAgentCompleted

                get_bus().publish(
                    SubAgentCompleted(
                        agent_id=agent_id,
                        label=agent.label,
                        response=response[:200],
                        success=True,
                        duration_ms=agent.elapsed_ms,
                    )
                )
            except Exception:
                pass

        except TurnCancelled:
            pass  # cancel already handled by _handle_qq_command
        except Exception as exc:
            self._sub_agent_manager.fail(agent_id, str(exc))
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"[{agent_id} error] {exc}",
            )
            try:
                from memex.event_bus import get_bus
                from memex.events import SubAgentCompleted

                get_bus().publish(
                    SubAgentCompleted(
                        agent_id=agent_id,
                        label=agent.label,
                        response="",
                        success=False,
                        duration_ms=agent.elapsed_ms,
                    )
                )
            except Exception:
                pass

    def _load_subagent_data(self) -> None:
        """Load sub-agent data into the drawer."""
        agents = self._sub_agent_manager.list_agents()
        data = [
            {
                "agent_id": a.agent_id,
                "label": a.label,
                "status": a.status,
                "elapsed": a.elapsed_display,
            }
            for a in agents
        ]
        drawer = self.query_one("#subagent-drawer", SubAgentDrawer)
        drawer.load_agents(data)

    # ── Drawer toggle actions ──

    def _close_all_drawers_except(self, *keep: str) -> None:
        """Close all drawers except the named ones. Intent is always preserved."""
        all_keep = set(keep) | {
            "intent"
        }  # never force-close intent when opening other drawers
        drawers = {
            "intent": self.query_one("#intent-drawer", IntentDrawer),
            "attention": self.query_one("#attention-drawer", AttentionDrawer),
            "scheduler": self.query_one("#scheduler-drawer", SchedulerDrawer),
            "meetings": self.query_one("#meeting-drawer", MeetingDrawer),
            "subagents": self.query_one("#subagent-drawer", SubAgentDrawer),
        }
        for name, drawer in drawers.items():
            if name not in all_keep and drawer.is_open:
                drawer.toggle()

    def action_toggle_intents(self) -> None:
        """Toggle intent drawer. Closes other drawers if open."""
        self._close_all_drawers_except("intent")
        intent = self.query_one("#intent-drawer", IntentDrawer)
        footer = self.query_one("#footer-bar", FooterBar)

        intent.toggle()

        if intent.is_open:
            self._refresh_intent_drawer()
            footer.set_context("intents")
            intent.focus()
        else:
            footer.set_context("default")
            self.query_one("#input-bar", InputBar).focus()

    def action_toggle_attention(self) -> None:
        """Toggle attention drawer. Closes other drawers if open."""
        self._close_all_drawers_except("attention")
        attn = self.query_one("#attention-drawer", AttentionDrawer)
        footer = self.query_one("#footer-bar", FooterBar)

        attn.toggle()

        if attn.is_open:
            footer.set_context("attention")
            attn.focus()
        else:
            footer.set_context("default")
            self.query_one("#input-bar", InputBar).focus()

    def action_toggle_scheduler(self) -> None:
        """Toggle scheduler drawer. Closes other drawers if open."""
        self._close_all_drawers_except("scheduler")
        sched = self.query_one("#scheduler-drawer", SchedulerDrawer)
        footer = self.query_one("#footer-bar", FooterBar)

        sched.toggle()

        if sched.is_open:
            footer.set_context("scheduler")
            self._load_scheduler_data()
            sched.focus()
        else:
            footer.set_context("default")
            self.query_one("#input-bar", InputBar).focus()

    def action_toggle_meetings(self) -> None:
        """Toggle meeting drawer. Closes other drawers if open."""
        self._close_all_drawers_except("meetings")
        meetings = self.query_one("#meeting-drawer", MeetingDrawer)
        footer = self.query_one("#footer-bar", FooterBar)

        meetings.toggle()

        if meetings.is_open:
            if meetings.is_recording:
                footer.set_context(
                    "meetings_paused" if meetings.is_paused else "meetings_recording"
                )
            else:
                footer.set_context("meetings")
            self._load_meeting_data()
            meetings.focus_table()
        else:
            footer.set_context("default")
            self.query_one("#input-bar", InputBar).focus()

    def action_stop_recording_hotkey(self) -> None:
        """Stop an active meeting recording from anywhere in the TUI."""
        if self._audio_capture is None:
            return
        self._stop_recording()

    def action_pause_recording_hotkey(self) -> None:
        """Pause or resume an active meeting recording from anywhere in the TUI."""
        if self._audio_capture is None:
            return
        self._toggle_pause_recording()

    def action_toggle_subagents(self) -> None:
        """Toggle sub-agent drawer. Closes other drawers if open."""
        self._close_all_drawers_except("subagents")
        drawer = self.query_one("#subagent-drawer", SubAgentDrawer)
        footer = self.query_one("#footer-bar", FooterBar)

        drawer.toggle()

        if drawer.is_open:
            footer.set_context("subagents")
            self._load_subagent_data()
            drawer.focus()
        else:
            footer.set_context("default")
            self.query_one("#input-bar", InputBar).focus()

    def _load_scheduler_data(self) -> None:
        """Load scheduler tasks into the drawer."""
        if self._api is None:
            return
        try:
            from memex.scheduler.cron_utils import (
                format_cron_human,
                format_human_readable,
                next_fire_time,
            )

            tasks = self._api.list_tasks()
            task_data = []
            for t in tasks:
                last_run = self._api.get_last_task_run(t.task_id)
                nxt = next_fire_time(t.cron_expr)
                task_data.append(
                    {
                        "task_id": t.task_id,
                        "name": t.name,
                        "enabled": t.enabled,
                        "cron_expr": t.cron_expr,
                        "schedule_human": format_cron_human(t.cron_expr),
                        "next_run_human": format_human_readable(nxt),
                        "last_run_status": last_run.status if last_run else "never",
                    }
                )
            drawer = self.query_one("#scheduler-drawer", SchedulerDrawer)
            drawer.load_tasks(task_data)
        except Exception:
            logger.warning("Failed to load scheduler data", exc_info=True)
            try:
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system",
                    "⚠ Could not load scheduler tasks — use /search_logs to investigate.",
                )
            except Exception:
                pass

    def _load_meeting_data(self) -> None:
        """Load meeting data into the drawer."""
        if self._api is None:
            return

        def _mget(m: Any, key: str, default: Any = None) -> Any:
            """Read from dict (service mode) or object attribute (local mode)."""
            if isinstance(m, dict):
                return m.get(key, default)
            return getattr(m, key, default)

        def _parse_dt(val: Any) -> Any:
            """Return a datetime from an object or ISO string, or None."""
            if val is None:
                return None
            if hasattr(val, "strftime"):
                return val
            try:
                from datetime import datetime

                return datetime.fromisoformat(str(val).replace("Z", "+00:00"))
            except Exception:
                return None

        try:
            meetings = self._api.list_meetings(include_all=True, limit=20)
            meeting_data = []
            for m in meetings:
                dur = ""
                duration_seconds = _mget(m, "duration_seconds")
                if duration_seconds:
                    mins = int(duration_seconds // 60)
                    secs = int(duration_seconds % 60)
                    dur = f"{mins}m{secs:02d}s" if mins else f"{secs}s"
                started_at = _parse_dt(_mget(m, "started_at"))
                scheduled_for = _parse_dt(_mget(m, "scheduled_for"))
                if started_at:
                    started = started_at.strftime("%Y-%m-%d %H:%M")
                elif scheduled_for:
                    started = f"@ {scheduled_for.strftime('%Y-%m-%d %H:%M')}"
                else:
                    started = "—"
                meeting_id = _mget(m, "meeting_id", "")
                # state may be an enum (local) or a string (service dict)
                raw_state = _mget(m, "state", "")
                state_val = (
                    raw_state.value if hasattr(raw_state, "value") else str(raw_state)
                )
                recordings = _mget(m, "recordings", []) or []
                meeting_data.append(
                    {
                        "meeting_id": meeting_id,
                        "state": (
                            "recording (paused)"
                            if (
                                meeting_id == self._recording_meeting_id
                                and self._audio_capture is not None
                                and getattr(self._audio_capture, "is_paused", False)
                            )
                            else state_val
                        ),
                        "title": _mget(m, "title") or "Untitled",
                        "duration_human": dur or "—",
                        "speaker_count": _mget(m, "speaker_count"),
                        "language": _mget(m, "language"),
                        "started_human": started,
                        "recording_count": len(recordings),
                        "action_item_count": len(_mget(m, "action_items", None) or []),
                    }
                )
            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.load_meetings(meeting_data)
        except Exception:
            logger.warning("Failed to load meeting data", exc_info=True)
            try:
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system",
                    "⚠ Could not load meetings — use /search_logs to investigate.",
                )
            except Exception:
                pass

    # ── Drawer message handlers ──

    @on(IntentDrawer.FocalGoalSelected)
    def on_focal_goal(self, event: IntentDrawer.FocalGoalSelected) -> None:
        """Update header bar when a focal goal is selected."""
        self._focal_goal_id = event.goal_id
        self._focal_goal_title = event.title
        header = self.query_one("#header-bar", HeaderBar)
        header.update_goal(event.title)

    _DRAWER_TOGGLE = {
        "intent": "action_toggle_intents",
        "attention": "action_toggle_attention",
        "scheduler": "action_toggle_scheduler",
        "meetings": "action_toggle_meetings",
        "subagents": "action_toggle_subagents",
    }

    @on(BaseDrawer.DrawerClose)
    def on_drawer_close(self, event: BaseDrawer.DrawerClose) -> None:
        """Unified handler — all drawers now post BaseDrawer.DrawerClose."""
        method = self._DRAWER_TOGGLE.get(event.drawer)
        if method:
            getattr(self, method)()

    @on(SubAgentDrawer.AgentAction)
    def on_subagent_action(self, event: SubAgentDrawer.AgentAction) -> None:
        """Handle sub-agent actions from the drawer."""
        conversation = self.query_one("#conversation", ConversationPanel)
        if event.action == "view":
            agent = self._sub_agent_manager.get(event.agent_id)
            if agent and agent.status == "done":
                conversation.add_message(
                    "system",
                    f"[{agent.agent_id}] {agent.label}\n({agent.elapsed_display})\n\n{agent.response or '(empty)'}",
                )
            elif agent:
                conversation.add_message("system", f"{agent.agent_id}: {agent.status}")
        elif event.action == "kill":
            self._handle_qq_command(f"kill {event.agent_id}")

    @on(MeetingDrawer.MeetingAction)
    def on_meeting_action(self, event: MeetingDrawer.MeetingAction) -> None:
        """Handle meeting actions from the meeting drawer."""
        if not self._api:
            return
        try:
            conversation = self.query_one("#conversation", ConversationPanel)
            if event.action == "new_meeting":
                if self._meeting_dialog_active:
                    return
                self._meeting_dialog_active = True
                self.push_screen(NewMeetingDialog(), self._on_new_meeting_dialog)
            elif event.action == "record_selected":
                if self._meeting_dialog_active:
                    return
                meeting_id = event.meeting_id
                if not meeting_id:
                    return
                record = self._api.get_meeting(meeting_id)
                if record is None:
                    return
                self._meeting_dialog_active = True
                has_recordings = bool(record.recordings)
                label = (
                    f"Add another recording to '{record.title}'?"
                    if has_recordings
                    else f"Start recording '{record.title}'?"
                )
                self.push_screen(
                    ConfirmDialog(label),
                    lambda confirmed, mid=meeting_id: self._on_confirm_record(
                        confirmed, mid
                    ),
                )
            elif event.action == "view":
                if not event.meeting_id:
                    return
                meeting = self._api.get_meeting(event.meeting_id)
                if meeting:
                    self.push_screen(
                        MeetingDetailScreen(meeting, getattr(self._api, "store", None)),
                        lambda result, mid=event.meeting_id: (
                            self._on_meeting_detail_closed(result, mid)
                        ),
                    )
            elif event.action == "transcribe":
                self._do_transcribe_meeting(event.meeting_id)
            elif event.action == "delete":
                if self._meeting_dialog_active:
                    return
                if not event.meeting_id:
                    return
                meeting = self._api.get_meeting(event.meeting_id)
                if meeting is None:
                    return
                if meeting.state.value in {"recording", "queued", "transcribing"}:
                    conversation.add_message(
                        "system",
                        f"Cannot delete '{meeting.title or 'Untitled'}' while it is {meeting.state.value}.",
                    )
                    return
                self._meeting_dialog_active = True
                title = meeting.title or "Untitled"
                self.push_screen(
                    ConfirmDialog(f"Delete meeting '{title}'?"),
                    lambda confirmed, mid=event.meeting_id: (
                        self._on_confirm_delete_meeting(confirmed, mid)
                    ),
                )
            elif event.action == "start_recording":
                # Meeting action routes directly to the preserved recording flow.
                self._start_recording()
            elif event.action == "pause_recording":
                self._pause_recording()
            elif event.action == "resume_recording":
                self._resume_recording()
            elif event.action == "stop_recording":
                self._stop_recording()
        except Exception as exc:
            logger.debug("Failed to handle meeting action: %s", exc)

    @on(MeetingDrawer.VadThresholdChanged)
    def on_vad_threshold_changed(
        self, event: MeetingDrawer.VadThresholdChanged
    ) -> None:
        """Update VAD threshold on the meeting record when adjusted during recording."""
        if self._recording_id and self._api:
            try:
                recording = self._api.get_recording(self._recording_id)
                if recording:
                    recording.vad_threshold = event.threshold
                    self._api.update_recording(recording)
            except Exception:
                logger.debug("Failed to update VAD threshold", exc_info=True)

    def _on_new_meeting_dialog(self, result: dict | None) -> None:
        """Callback after NewMeetingDialog closes."""
        self._meeting_dialog_active = False
        if result is None:
            return
        self._create_meeting(
            result["title"],
            result["attendees"],
            scheduled_for_raw=result.get("scheduled_for"),
        )

    def _parse_optional_datetime(self, value: str | None) -> Any:
        if not value:
            return None
        try:
            import dateparser

            return dateparser.parse(
                value,
                settings={"PREFER_DATES_FROM": "future"},
            )
        except Exception:
            logger.debug("Failed to parse datetime %r", value, exc_info=True)
            return None

    def _create_meeting(
        self,
        title: str,
        attendees: list[str],
        *,
        scheduled_for_raw: str | None = None,
    ) -> None:
        """Create a new meeting in CREATED state and refresh the drawer."""
        if not self._api:
            return
        try:
            from memex.meetings.models import MeetingRecord, MeetingState

            meeting_id = str(uuid.uuid4())
            now = utcnow()
            scheduled_for = self._parse_optional_datetime(scheduled_for_raw)
            record = MeetingRecord(
                meeting_id=meeting_id,
                state=MeetingState.CREATED,
                title=title,
                scheduled_for=scheduled_for,
                calendar_source="memex",
                attendees=attendees,
                created_at=now,
                updated_at=now,
            )
            self._api.create_meeting(record)
            try:
                if self._has_local_store:
                    from memex.meetings.upcoming import sync_meeting_attendee_links

                    sync_meeting_attendee_links(self._api.store, record)
            except Exception:
                logger.debug("Failed to sync meeting attendee links", exc_info=True)
            self._load_meeting_data()
            conversation = self.query_one("#conversation", ConversationPanel)
            attendees_str = f" ({', '.join(attendees)})" if attendees else ""
            when_str = (
                f"\nScheduled for: {scheduled_for.strftime('%Y-%m-%d %H:%M')}"
                if scheduled_for
                else ""
            )
            conversation.add_message(
                "system",
                f"Meeting created: '{title}'{attendees_str}{when_str}\nSelect it and press r to record.",
            )
        except Exception as exc:
            logger.debug("Failed to create meeting: %s", exc)

    def _on_confirm_record(self, confirmed: bool, meeting_id: str) -> None:
        """Callback after ConfirmDialog for recording a selected meeting."""
        self._meeting_dialog_active = False
        if not confirmed:
            return
        self._start_recording(meeting_id)

    def _on_confirm_delete_meeting(self, confirmed: bool, meeting_id: str) -> None:
        """Callback after ConfirmDialog for deleting a selected meeting."""
        self._meeting_dialog_active = False
        if not confirmed or not self._api:
            return
        try:
            conversation = self.query_one("#conversation", ConversationPanel)
            meeting = self._api.get_meeting(meeting_id)
            if meeting is None:
                return
            if meeting.state.value in {"recording", "queued", "transcribing"}:
                conversation.add_message(
                    "system",
                    f"Cannot delete '{meeting.title or 'Untitled'}' while it is {meeting.state.value}.",
                )
                return
            deleted = self._api.delete_meeting(meeting_id)
            if not deleted:
                return
            self._load_meeting_data()
            conversation.add_message(
                "system",
                f"Deleted meeting: '{meeting.title or 'Untitled'}'.",
            )
        except Exception:
            logger.debug("Failed to delete meeting %s", meeting_id, exc_info=True)

    def _on_meeting_detail_closed(self, result: dict | None, meeting_id: str) -> None:
        """Callback after MeetingDetailScreen closes.

        Saves notes and action items.  Any action item with
        promoted_goal_id == "__pending__" is promoted to a Goal here,
        where the store, event bus, and conversation panel are all available.
        """
        if result is None or not self._api:
            return
        try:
            record = self._api.get_meeting(meeting_id)
            if not record:
                return
            record.notes = result.get("notes", record.notes)
            action_items = result.get("action_items", record.action_items)

            # Resolve pending promotions
            for i, item in enumerate(action_items):
                if item.get("promoted_goal_id") == "__pending__":
                    try:
                        from memex.models import (
                            Goal,
                            GoalPriority,
                            GoalStatus,
                            MeetingGoalLink,
                        )
                        from memex.event_bus import get_bus
                        from memex.events import GoalCreated

                        now = utcnow()
                        goal_id = str(uuid.uuid4())
                        deadline = self._parse_optional_datetime(item.get("deadline"))
                        goal = Goal(
                            goal_id=goal_id,
                            parent_id=item.get("promote_parent_goal_id"),
                            title=item.get("text", ""),
                            description=item.get("notes", ""),
                            status=GoalStatus.ACTIVE,
                            priority=GoalPriority.MEDIUM,
                            created_at=now,
                            updated_at=now,
                            last_touched_at=now,
                            deadline=deadline,
                            metadata={
                                "source": "meeting_action_item",
                                "meeting_id": meeting_id,
                            },
                        )
                        self._api.create_goal(goal)
                        self._api.create_meeting_goal_link(
                            MeetingGoalLink(
                                meeting_id=meeting_id,
                                goal_id=goal_id,
                                relationship="explicit",
                                created_at=now,
                            )
                        )
                        action_items[i] = {
                            **item,
                            "promoted_goal_id": goal_id,
                            "promote_parent_goal_id": item.get(
                                "promote_parent_goal_id"
                            ),
                        }
                        get_bus().publish(
                            GoalCreated(
                                goal_id=goal_id,
                                title=goal.title,
                                parent_id=goal.parent_id,
                            )
                        )
                    except Exception:
                        # Reset to unpromoted so user can retry
                        action_items[i] = {
                            **item,
                            "promoted_goal_id": None,
                            "promote_parent_goal_id": None,
                        }
                        logger.warning(
                            "Failed to promote action item to goal", exc_info=True
                        )
                        try:
                            conversation = self.query_one(
                                "#conversation", ConversationPanel
                            )
                            conversation.add_message(
                                "system",
                                f"⚠ Could not promote '{item.get('text', '')}' to goal — use /search_logs to investigate.",
                            )
                        except Exception:
                            pass

            record.action_items = action_items
            self._api.update_meeting(record)
            try:
                if self._has_local_store:
                    from memex.meetings.upcoming import sync_meeting_attendee_links

                    sync_meeting_attendee_links(self._api.store, record)
            except Exception:
                logger.debug("Failed to sync meeting attendee links", exc_info=True)
            try:
                if self._has_local_store:
                    from memex.meetings.semantic_projection import (
                        sync_meeting_item_projection,
                    )

                    sync_meeting_item_projection(
                        record,
                        meeting_store=self._api.store.meetings,
                        content_store=self._api.content_store,
                        memex_store=self._api.store,
                        bump_version=True,
                        sync_reason="meeting_detail_save",
                    )
            except Exception:
                logger.debug("Failed to sync meeting item projection", exc_info=True)
            self._load_meeting_data()
            retry_recording_id = result.get("retry_recording_id")
            if retry_recording_id:
                self._do_transcribe_recording(retry_recording_id)
        except Exception:
            logger.debug("Failed to save meeting detail", exc_info=True)

    def _start_recording(self, meeting_id: str | None = None) -> None:
        """Start audio recording from the TUI.

        In service mode, delegates to ``POST /v1/meetings/{id}/record/start``
        (audio is captured on the service host).  In local mode, creates a
        local ``AudioCapture`` instance as before.
        """
        if self._audio_capture is not None:
            return
        # Service mode: delegate to the daemon
        if not self._has_local_store:
            self._start_recording_service(meeting_id)
            return
        try:
            from pathlib import Path

            from memex.meetings.capture import AudioCapture
            from memex.meetings.models import (
                MeetingRecord,
                MeetingRecording,
                MeetingState,
            )

            meeting_store = self._api.store.meetings

            # Defensive cleanup: startup already swept stale rows, but guard
            # against any mid-session edge case (e.g. scheduler-spawned recording).
            cleaned = meeting_store.cleanup_stale_recordings()
            if cleaned:
                logger.debug("_start_recording: cleared %d stale recording(s)", cleaned)

            store_path = self._api.db_path
            audio_dir = (
                Path(store_path).parent / "audio"
                if store_path
                else Path.home() / ".memex" / "audio"
            )

            # Resolve VAD threshold and recording device from settings (table → env → default)
            settings = self._api.settings
            vad_threshold = settings.get_float("vad_threshold", default=0.1)
            device_val = settings.get_str("recording_device", default="")
            device: str | int | None = None
            if device_val:
                device = (
                    int(device_val) if device_val.lstrip("-").isdigit() else device_val
                )

            capture = AudioCapture(audio_dir, sample_rate=16000, device=device)

            now = utcnow()

            if meeting_id:
                record = meeting_store.get_meeting(meeting_id)
                if record is None:
                    raise ValueError(f"Meeting {meeting_id} not found")
                audio_path = capture.start(meeting_id)
                recording = MeetingRecording(
                    recording_id=str(uuid.uuid4()),
                    meeting_id=meeting_id,
                    sequence_number=meeting_store.next_recording_sequence(meeting_id),
                    state=MeetingState.RECORDING,
                    audio_path=str(audio_path),
                    sample_rate=16000,
                    started_at=now,
                    vad_threshold=vad_threshold,
                    created_at=now,
                    updated_at=now,
                )
                meeting_store.create_recording(recording)
                record.state = MeetingState.RECORDING
                record.started_at = record.started_at or now
                record.stopped_at = None
                record.audio_path = str(audio_path)
                record.vad_threshold = vad_threshold
                meeting_store.update_meeting(record)
            else:
                # Legacy path: create a bare meeting record immediately
                meeting_id = str(uuid.uuid4())
                record = MeetingRecord(
                    meeting_id=meeting_id,
                    state=MeetingState.RECORDING,
                    title="",
                    sample_rate=16000,
                    vad_threshold=vad_threshold,
                    started_at=now,
                    created_at=now,
                    updated_at=now,
                )
                audio_path = capture.start(meeting_id)
                record.audio_path = str(audio_path)
                meeting_store.create_meeting(record)
                recording = meeting_store.get_latest_recording(meeting_id)
                if recording is None:
                    raise RuntimeError("Recording row was not created")

            # Update UI before committing app state — if any widget update fails,
            # stop the capture immediately so no resource is leaked and no
            # stale _audio_capture prevents future recordings.
            try:
                drawer = self.query_one("#meeting-drawer", MeetingDrawer)
                drawer.set_recording(True, vad_threshold, paused=False)
                self._load_meeting_data()
                drawer.focus_table()
                header = self.query_one("#header-bar", HeaderBar)
                header.update_recording(True)
            except Exception:
                capture.stop()
                raise

            # All widget updates succeeded — commit app state
            self._audio_capture = capture
            self._recording_meeting_id = meeting_id
            self._recording_id = recording.recording_id
            self._set_active_recording_state(paused=False, level=0.0)

            # Poll level at 10Hz
            self._recording_timer = self.set_interval(0.1, self._poll_recording_level)

            conversation = self.query_one("#conversation", ConversationPanel)
            title = record.title or meeting_id[:8]
            conversation.add_message("system", f"Recording started: {title}")

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings_recording")
        except Exception as exc:
            logger.debug("Failed to start recording: %s", exc)
            conversation = self.query_one("#conversation", ConversationPanel)
            conversation.add_message("system", f"Recording failed: {exc}")

    def _start_recording_service(self, meeting_id: str | None) -> None:
        """Start recording via the service daemon (service mode only).

        Audio is captured on the service host. The TUI tracks the meeting_id
        and recording_id but does not own the AudioCapture instance, so
        pause/resume and level metering are not available.
        """
        conversation = self.query_one("#conversation", ConversationPanel)
        if not meeting_id:
            conversation.add_message(
                "system",
                "In service mode, select a meeting first then press r to record.",
            )
            return
        try:
            result = self._api.start_recording(meeting_id)
            recording_id = result.get("recording_id", "")

            self._recording_meeting_id = meeting_id
            self._recording_id = recording_id

            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.set_recording(True, 0.1, paused=False)
            self._load_meeting_data()
            drawer.focus_table()

            header = self.query_one("#header-bar", HeaderBar)
            header.update_recording(True)

            record = self._api.get_meeting(meeting_id)
            title = (
                record.get("title")
                if isinstance(record, dict)
                else getattr(record, "title", "")
            ) or meeting_id[:8]
            conversation.add_message("system", f"Recording started (service): {title}")

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings_recording")
        except Exception as exc:
            logger.debug("Failed to start recording via service: %s", exc)
            conversation.add_message("system", f"Recording failed: {exc}")

    def _ensure_transcription_engine(self):
        """Lazily create a work-queue-backed scheduler engine for transcriptions."""
        if self._transcription_engine is not None:
            return self._transcription_engine
        if not self._api or not self._has_local_store:
            return None  # transcription engine requires local store; not available in service mode
        try:
            from memex.scheduler.engine import SchedulerEngine

            try:
                notification_store = self._api.notification_store
            except Exception:
                notification_store = None

            engine = SchedulerEngine(
                self._api.store.scheduler,
                memex_store=self._api.store,
                notification_store=notification_store,
                runtime_registry=self._api.runtime_registry,
            )
            engine.work_queue.start()
            self._transcription_engine = engine
            self._transcription_engine_error = None
            self._api.set_scheduler_engine(engine)
            self._set_interface_state(
                "transcription_engine",
                enabled=True,
                running=True,
                status="running",
                owner="tui_local",
            )
            return engine
        except Exception as exc:
            self._transcription_engine_error = str(exc)
            logger.warning(
                "Failed to initialize transcription engine: %s", exc, exc_info=True
            )
            self._set_interface_state(
                "transcription_engine",
                enabled=True,
                running=False,
                status="error",
                owner="tui_local",
            )
            return None

    def _stop_recording(self) -> None:
        """Stop audio recording from the TUI."""
        # Service mode: delegate to the daemon
        if not self._has_local_store:
            self._stop_recording_service()
            return
        if self._audio_capture is None:
            return
        try:
            from memex.meetings import submit_transcription
            from memex.meetings.models import MeetingState

            # Stop the level meter timer
            if self._recording_timer is not None:
                self._recording_timer.stop()
                self._recording_timer = None

            path, duration = self._audio_capture.stop()
            self._audio_capture = None

            meeting_store = self._api.store.meetings
            recording = (
                meeting_store.get_recording(self._recording_id)
                if self._recording_id
                else None
            )
            if recording:
                recording.audio_path = str(path)
                recording.duration_seconds = duration
                recording.stopped_at = utcnow()
                recording.state = MeetingState.RECORDED
                meeting_store.update_recording(recording)

            record = meeting_store.get_meeting(self._recording_meeting_id)
            if record:
                record.audio_path = str(path)
                record.duration_seconds = sum(
                    r.duration_seconds for r in record.recordings
                )
                record.stopped_at = utcnow()
                record.state = MeetingState.RECORDED
                meeting_store.update_meeting(record)

            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.set_recording(False)
            self._load_meeting_data()

            header = self.query_one("#header-bar", HeaderBar)
            header.update_recording(False)

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings")

            conversation = self.query_one("#conversation", ConversationPanel)
            run_id = None
            enqueue_error: str | None = None
            engine = self._ensure_transcription_engine()
            if engine is None:
                enqueue_error = (
                    self._transcription_engine_error or "scheduler engine unavailable"
                )
            if engine is not None and self._recording_meeting_id:
                try:
                    run_id = submit_transcription(
                        self._recording_meeting_id,
                        engine.work_queue,
                        self._api.store.scheduler,
                    )
                except Exception as exc:
                    enqueue_error = str(exc)
                    logger.warning(
                        "Failed to enqueue meeting transcription: %s",
                        exc,
                        exc_info=True,
                    )
            if run_id is not None:
                conversation.add_message(
                    "system",
                    f"Recording stopped: {duration:.1f}s\nQueued transcription for this meeting (run {run_id}).",
                )
            else:
                detail = f" ({enqueue_error})" if enqueue_error else ""
                conversation.add_message(
                    "system",
                    f"Recording stopped: {duration:.1f}s\nCould not queue transcription automatically{detail}; press t to transcribe.",
                )
            self._recording_meeting_id = None
            self._recording_id = None
            self._set_active_recording_state(paused=False, level=0.0)
        except Exception as exc:
            logger.error("Failed to stop recording: %s", exc, exc_info=True)
            self._audio_capture = None
            self._recording_meeting_id = None
            self._recording_id = None
            self._set_active_recording_state(paused=False, level=0.0)
            try:
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system",
                    f"⚠ Recording stopped but cleanup failed: {type(exc).__name__}. Check the meetings drawer.",
                )
            except Exception:
                pass

    def _stop_recording_service(self) -> None:
        """Stop recording via the service daemon (service mode only)."""
        if not self._recording_meeting_id:
            return
        conversation = self.query_one("#conversation", ConversationPanel)
        try:
            result = self._api.stop_recording(self._recording_meeting_id)
            duration = result.get("duration_seconds", 0.0)

            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.set_recording(False)
            self._load_meeting_data()

            header = self.query_one("#header-bar", HeaderBar)
            header.update_recording(False)

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings")

            # Auto-enqueue transcription on the service
            try:
                self._api.transcribe_meeting(self._recording_meeting_id)
                conversation.add_message(
                    "system",
                    f"Recording stopped (service): {duration:.1f}s — transcription queued.",
                )
            except Exception:
                conversation.add_message(
                    "system",
                    f"Recording stopped (service): {duration:.1f}s — press t to transcribe.",
                )
        except Exception as exc:
            logger.debug("Failed to stop recording via service: %s", exc)
            conversation.add_message("system", f"Stop recording failed: {exc}")
        finally:
            self._recording_meeting_id = None
            self._recording_id = None
            self._set_active_recording_state(paused=False, level=0.0)

    def _pause_recording(self) -> None:
        """Pause an active audio recording without ending the meeting."""
        if not self._has_local_store:
            # Pause/resume not available over HTTP — audio runs on the service host.
            return
        if self._audio_capture is None or getattr(
            self._audio_capture, "is_paused", False
        ):
            return
        try:
            self._audio_capture.pause()
            if self._recording_timer is not None:
                self._recording_timer.stop()
                self._recording_timer = None

            meeting_store = self._api.store.meetings
            recording = (
                meeting_store.get_recording(self._recording_id)
                if self._recording_id
                else None
            )
            vad_threshold = recording.vad_threshold if recording else 0.2

            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.set_recording(True, vad_threshold, paused=True)
            self._load_meeting_data()
            self._set_active_recording_state(paused=True, level=0.0)

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings_paused")

            conversation = self.query_one("#conversation", ConversationPanel)
            conversation.add_message(
                "system",
                "Recording paused. The meeting is still active; press p to resume or r to stop.",
            )
        except Exception as exc:
            logger.debug("Failed to pause recording: %s", exc)

    def _resume_recording(self) -> None:
        """Resume a paused audio recording."""
        if not self._has_local_store:
            return
        if self._audio_capture is None or not getattr(
            self._audio_capture, "is_paused", False
        ):
            return
        try:
            self._audio_capture.resume()
            if self._recording_timer is None:
                self._recording_timer = self.set_interval(
                    0.1, self._poll_recording_level
                )

            meeting_store = self._api.store.meetings
            recording = (
                meeting_store.get_recording(self._recording_id)
                if self._recording_id
                else None
            )
            vad_threshold = recording.vad_threshold if recording else 0.2

            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.set_recording(True, vad_threshold, paused=False)
            self._load_meeting_data()
            self._set_active_recording_state(
                paused=False,
                level=getattr(self._audio_capture, "level", 0.0),
            )

            footer = self.query_one("#footer-bar", FooterBar)
            footer.set_context("meetings_recording")

            conversation = self.query_one("#conversation", ConversationPanel)
            conversation.add_message("system", "Recording resumed.")
        except Exception as exc:
            logger.debug("Failed to resume recording: %s", exc)

    def _toggle_pause_recording(self) -> None:
        """Toggle pause/resume for the active recording."""
        if self._audio_capture is None:
            return
        if getattr(self._audio_capture, "is_paused", False):
            self._resume_recording()
        else:
            self._pause_recording()

    def _stop_recording_quiet(self) -> None:
        """Finalize an active recording without touching the UI.

        Safe to call during shutdown when the DOM may be partially torn down.
        Stops the level-meter timer, finalizes the audio file, and persists
        the meeting and child recording rows.
        """
        if self._audio_capture is None:
            return

        if self._recording_timer is not None:
            self._recording_timer.stop()
            self._recording_timer = None

        try:
            path, duration = self._audio_capture.stop()
        except Exception:
            logger.debug("Audio capture stop failed during shutdown", exc_info=True)
            return
        finally:
            self._audio_capture = None

        if self._api and self._recording_meeting_id:
            try:
                from memex.meetings.models import MeetingState

                recording = (
                    self._api.get_recording(self._recording_id)
                    if self._recording_id
                    else None
                )
                if recording:
                    recording.audio_path = str(path)
                    recording.duration_seconds = duration
                    recording.stopped_at = utcnow()
                    recording.state = MeetingState.RECORDED
                    self._api.update_recording(recording)
                record = self._api.get_meeting(self._recording_meeting_id)
                if record:
                    record.audio_path = str(path)
                    record.duration_seconds = sum(
                        r.duration_seconds for r in record.recordings
                    )
                    record.stopped_at = utcnow()
                    record.state = MeetingState.RECORDED
                    self._api.update_meeting(record)
            except Exception:
                logger.debug("Failed to persist meeting on shutdown", exc_info=True)
            finally:
                self._recording_meeting_id = None
                self._recording_id = None
                self._set_active_recording_state(paused=False, level=0.0)

    def _poll_recording_level(self) -> None:
        """Poll audio capture level and update the meter widget."""
        if self._audio_capture is None:
            return
        try:
            level = self._audio_capture.level
            drawer = self.query_one("#meeting-drawer", MeetingDrawer)
            drawer.update_level(level)
            header = self.query_one("#header-bar", HeaderBar)
            header.update_level(level)
            self._set_active_recording_state(
                paused=getattr(self._audio_capture, "is_paused", False),
                level=level,
            )
        except Exception:
            pass  # DOM teardown during shutdown; timer will be cancelled shortly

    @work(thread=True)
    def _do_transcribe_meeting(self, meeting_id: str) -> None:
        """Transcribe a meeting in a background worker thread."""
        if not self._api:
            return

        conversation = self.query_one("#conversation", ConversationPanel)

        # Service mode: delegate to the daemon
        if not self._has_local_store:
            try:
                self._api.transcribe_meeting(meeting_id)
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Transcription queued on service for meeting {meeting_id[:8]}.",
                )
            except Exception as exc:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Transcription failed: {exc}",
                )
            return

        try:
            from memex.meetings.transcribe import orchestrate_transcription

            meeting_store = self._api.store.meetings
            record = meeting_store.get_meeting(meeting_id)
            if not record:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Meeting not found: {meeting_id[:8]}",
                )
                return
            from memex.meetings.models import MeetingState as MS

            if record.state not in (MS.RECORDED, MS.FAILED):
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Meeting {meeting_id[:8]} is {record.state.value} — cannot transcribe.",
                )
                return

            title = record.title or meeting_id[:8]
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"Transcribing {title}... (this may take a few minutes)",
            )

            try:
                ns = self._api.notification_store
            except Exception:
                ns = None

            item = orchestrate_transcription(
                meeting_id,
                meeting_store=meeting_store,
                content_store=self._api.content_store,
                embedding_backend=self._api.embedding_backend,
                notification_store=ns,
            )

            # MeetingTranscribed event auto-refreshes the drawer via _on_meeting_event
            if item:
                updated = meeting_store.get_meeting(meeting_id)
                speakers = updated.speaker_count if updated else "?"
                lang = updated.language if updated else "?"
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Transcribed: {item.title}\n  {speakers} speakers, {lang}",
                )
            else:
                self.call_from_thread(
                    conversation.add_message, "system", "Transcription complete."
                )
        except Exception as exc:
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"Transcription failed: {exc}",
            )
            logger.debug("Transcription failed", exc_info=True)

    @work(thread=True)
    def _do_transcribe_recording(self, recording_id: str) -> None:
        """Retry transcription for a single meeting recording."""
        if not self._api:
            return

        conversation = self.query_one("#conversation", ConversationPanel)

        # Service mode: delegate to the daemon (use meeting-level transcribe)
        if not self._has_local_store:
            try:
                recording = self._api.get_recording(recording_id)
                mid = (
                    recording.get("meeting_id")
                    if isinstance(recording, dict)
                    else getattr(recording, "meeting_id", None)
                )
                if mid:
                    self._api.transcribe_meeting(mid)
                    self.call_from_thread(
                        conversation.add_message,
                        "system",
                        f"Transcription queued on service for recording {recording_id[:8]}.",
                    )
                else:
                    self.call_from_thread(
                        conversation.add_message,
                        "system",
                        f"Could not determine meeting for recording {recording_id[:8]}.",
                    )
            except Exception as exc:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Transcription retry failed: {exc}",
                )
            return

        try:
            from memex.meetings.models import MeetingState as MS
            from memex.meetings.transcribe import orchestrate_transcription

            meeting_store = self._api.store.meetings
            recording = meeting_store.get_recording(recording_id)
            if not recording:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Recording not found: {recording_id[:8]}",
                )
                return
            if not recording.audio_path:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Recording {recording.sequence_number} has no audio file to transcribe.",
                )
                return
            if recording.state not in (
                MS.FAILED,
                MS.RECORDED,
                MS.TRANSCRIBED,
                MS.TRANSCRIBED_POOR,
                MS.INGESTED,
            ):
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Recording {recording.sequence_number} is {recording.state.value} — cannot retry transcription.",
                )
                return

            meeting = meeting_store.get_meeting(recording.meeting_id)
            title = meeting.title if meeting else recording.meeting_id[:8]
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"Retrying transcription for recording {recording.sequence_number} of {title}...",
            )

            try:
                ns = self._api.notification_store
            except Exception:
                ns = None

            item = orchestrate_transcription(
                recording.meeting_id,
                meeting_store=meeting_store,
                content_store=self._api.content_store,
                embedding_backend=self._api.embedding_backend,
                notification_store=ns,
                recording_id=recording.recording_id,
            )

            updated = meeting_store.get_meeting(recording.meeting_id)
            if item is not None:
                speakers = updated.speaker_count if updated else "?"
                lang = updated.language if updated else "?"
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Retried recording {recording.sequence_number}: {item.title}\n  {speakers} speakers, {lang}",
                )
            else:
                self.call_from_thread(
                    conversation.add_message,
                    "system",
                    f"Recording {recording.sequence_number} transcription complete.",
                )
        except Exception as exc:
            self.call_from_thread(
                conversation.add_message,
                "system",
                f"Recording retry failed: {exc}",
            )
            logger.debug("Recording transcription retry failed", exc_info=True)

    @on(SchedulerDrawer.TaskAction)
    def on_scheduler_task_action(self, event: SchedulerDrawer.TaskAction) -> None:
        """Handle scheduler task actions."""
        if not self._api:
            return
        try:
            if event.action == "toggle_enable":
                task = self._api.get_task(event.task_id)
                if task:
                    self._api.toggle_task(event.task_id, not task.enabled)
                    self._load_scheduler_data()
            elif event.action == "run_now":
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message(
                    "system", f"Running task {event.task_id[:8]}..."
                )
        except Exception as exc:
            logger.debug("Failed to handle scheduler action: %s", exc)

    @on(IntentDrawer.GoalAction)
    def on_goal_action(self, event: IntentDrawer.GoalAction) -> None:
        """Handle goal actions from the intent drawer."""
        if event.action == "add":
            input_bar = self.query_one("#input-bar", InputBar)
            input_bar.focus()
            input_bar.value = "I want to "
            input_bar.cursor_position = len(input_bar.value)
        elif self._api and event.action in ("complete", "pause", "blocked", "abandon"):
            try:
                from memex.models import GoalStatus

                goal = self._api.get_goal(event.goal_id)
                if goal is None:
                    return
                status_map = {
                    "complete": GoalStatus.COMPLETED,
                    "pause": GoalStatus.PAUSED,
                    "blocked": GoalStatus.BLOCKED,
                    "abandon": GoalStatus.ABANDONED,
                }
                old_status = goal.status.value
                goal.status = status_map[event.action]
                goal.updated_at = utcnow()
                goal.last_touched_at = utcnow()
                self._api.update_goal(goal)

                try:
                    from memex.event_bus import get_bus
                    from memex.events import GoalStatusChanged

                    get_bus().publish(
                        GoalStatusChanged(
                            goal_id=goal.goal_id,
                            title=goal.title,
                            old_status=old_status,
                            new_status=goal.status.value,
                        )
                    )
                except Exception:
                    pass
            except Exception as exc:
                conversation = self.query_one("#conversation", ConversationPanel)
                conversation.add_message("system", f"Error: {exc}")

    @on(AttentionDrawer.NotificationAction)
    def on_notification_action(self, event: AttentionDrawer.NotificationAction) -> None:
        """Handle notification actions from the attention drawer."""
        if not self._api:
            return
        if not self._has_local_store:
            # Service mode: use protocol methods and cached notification data
            notif = self._notifications_cache.get(event.notification_id, {})
            try:
                conversation = self.query_one("#conversation", ConversationPanel)
                if event.action in ("dismiss", "reject"):
                    self._api.act_on_notification(event.notification_id, "dismiss")
                    self._load_attention_data()
                elif event.action == "view":
                    self._api.act_on_notification(event.notification_id, "view")
                    action_type = notif.get("action_type")
                    if action_type == "url_review":
                        action_data = notif.get("action_data", {})
                        urls = action_data.get("urls", [])
                        body = f"URLs from: {action_data.get('email_subject', '')}\n\n"
                        body += "\n".join(f"  {i + 1}. {u}" for i, u in enumerate(urls))
                        conversation.add_message("system", body)
                    elif notif:
                        conversation.add_message(
                            "system", notif.get("body") or notif.get("title", "")
                        )
                    self._load_attention_data()
                elif event.action == "approve":
                    if notif.get("action_type") == "url_review":
                        self._approve_url_review(
                            event.notification_id, notif.get("action_data", {})
                        )
                    else:
                        self._api.act_on_notification(event.notification_id, "dismiss")
                        self._load_attention_data()
                elif event.action == "defer":
                    conversation.add_message("system", "Notification deferred.")
            except Exception:
                logger.debug(
                    "Failed to handle notification action in service mode",
                    exc_info=True,
                )
            return
        try:
            ns = self._api.notification_store
            notification = ns.get(event.notification_id)
            conversation = self.query_one("#conversation", ConversationPanel)

            if event.action in ("dismiss", "reject"):
                ns.dismiss(event.notification_id)
                self._load_attention_data()

            elif event.action == "view":
                ns.mark_read(event.notification_id)
                if notification and notification.action_type == "url_review":
                    urls = notification.action_data.get("urls", [])
                    body = f"URLs from: {notification.action_data.get('email_subject', '')}\n\n"
                    body += "\n".join(f"  {i + 1}. {u}" for i, u in enumerate(urls))
                    conversation.add_message("system", body)
                elif notification:
                    conversation.add_message(
                        "system", notification.body or notification.title
                    )
                self._load_attention_data()

            elif event.action == "approve":
                if notification and notification.action_type == "url_review":
                    self._approve_url_review(
                        event.notification_id, notification.action_data
                    )
                else:
                    ns.dismiss(event.notification_id)
                    self._load_attention_data()

            elif event.action == "defer":
                conversation.add_message("system", "Notification deferred.")

        except Exception:
            logger.debug("Failed to handle notification action", exc_info=True)

    @work(thread=True)
    def _approve_url_review(self, notification_id: str, action_data: dict) -> None:
        """Ingest all URLs from a url_review notification."""
        conversation = self.query_one("#conversation", ConversationPanel)
        urls = action_data.get("urls", [])
        if not urls:
            return

        self.call_from_thread(
            conversation.add_message, "system", f"Ingesting {len(urls)} URLs..."
        )

        ingested = 0
        failed = 0
        for url in urls:
            try:
                self._api.ingest_url(url, session_id=self._session_id)
                ingested += 1
            except Exception as exc:
                logger.warning("Failed to ingest URL %s: %s", url, exc)
                failed += 1

        self.call_from_thread(
            conversation.add_message,
            "system",
            f"Ingested {ingested}/{len(urls)} URLs."
            + (f" ({failed} failed)" if failed else ""),
        )

        if self._has_local_store:
            self._api.notification_store.dismiss(notification_id)
        else:
            try:
                self._api.act_on_notification(notification_id, "dismiss")
            except Exception:
                logger.debug(
                    "Failed to dismiss notification in service mode", exc_info=True
                )
        self.call_from_thread(self._load_attention_data)

    # ── Standard actions ──

    def action_cancel_turn(self) -> None:
        """Two-tier cancel: first Esc interrupts (keeps partial), Esc again discards."""
        # When any modal screen is active, skip this binding so the modal's
        # on_key handler handles Escape (forward_target becomes the modal screen itself).
        if isinstance(self.screen, ModalScreen):
            raise SkipAction()

        # If command hint panel is visible, Esc just hides it
        try:
            hint_panel = self.query_one("#command-hints", CommandHintPanel)
            if hint_panel.display:
                hint_panel.display = False
                return
        except Exception:
            pass

        now = time.monotonic()

        # Second Esc within window → hard cancel (discard partial output)
        if self._interrupted and (now - self._last_esc_time) < 1.5:
            self._interrupted = False
            if self._expire_timer is not None:
                self._expire_timer.stop()
                self._expire_timer = None
            self._cancel_event.clear()
            conversation = self.query_one("#conversation", ConversationPanel)
            conversation.discard_interrupted()
            conversation.add_message("system", "Cancelled.")
            return

        if not self._turn_active:
            raise SkipAction()

        # First Esc → soft interrupt (keep partial output visible)
        self._cancel_event.set()
        self._last_esc_time = now

        conversation = self.query_one("#conversation", ConversationPanel)
        conversation.hide_processing()
        has_content = conversation.get_streaming_content() is not None

        if has_content:
            # Keep streaming widget visible, add label below it
            conversation.interrupt_streaming()
            self._interrupted = True
            # Cancel any prior expire timer (prevents stale timer from
            # prematurely collapsing the new interrupt window)
            if self._expire_timer is not None:
                self._expire_timer.stop()
            self._expire_timer = self.set_timer(1.5, self._expire_interrupt_label)
        else:
            # Nothing streamed yet → immediate cancel
            conversation.finish_streaming()
            conversation.add_message("system", "Cancelled.")

    def _expire_interrupt_label(self) -> None:
        """Update the interrupted label after the double-Esc window expires."""
        self._expire_timer = None
        if not self._interrupted:
            return
        self._interrupted = False
        conversation = self.query_one("#conversation", ConversationPanel)
        conversation.update_interrupted_label("Interrupted.")

    def action_quit_app(self) -> None:
        """Quit the application with visible shutdown feedback."""
        conversation = self.query_one("#conversation", ConversationPanel)
        conversation.add_message("system", "Exiting...")
        # Signal all background threads and any active LLM streaming to stop.
        self._shutdown_event.set()
        self._cancel_event.set()
        self._stop_recording_quiet()
        if self._transcription_engine is not None:
            try:
                self._transcription_engine.stop(timeout=2)
            except Exception:
                logger.debug(
                    "Failed to stop transcription engine on exit", exc_info=True
                )
            finally:
                self._transcription_engine = None
                self._set_interface_state(
                    "transcription_engine",
                    enabled=True,
                    running=False,
                    status="stopped",
                    owner="tui_local",
                )
        self._end_session_on_exit()
        # Close service client so the SSE event worker unblocks immediately.
        if hasattr(self._api, "close"):
            try:
                self._api.close()
            except Exception:
                pass
        # Start a countdown thread that prints after Textual restores the
        # terminal.  The executor shutdown (joining @work threads) happens
        # after the alternate screen is released, so this provides feedback
        # during that otherwise-silent wait.
        self._shutdown_countdown_done = threading.Event()
        self._start_shutdown_countdown()
        self.exit()

    def signal_shutdown_complete(self) -> None:
        """Signal that post-exit cleanup is done, clearing the countdown."""
        done = getattr(self, "_shutdown_countdown_done", None)
        if done is not None:
            done.set()

    _ANSI_CLEAR_LINE = "\r\033[K"
    _COUNTDOWN_INITIAL_DELAY = 0.3  # allow Textual to restore the terminal

    def _start_shutdown_countdown(self) -> None:
        """Print a countdown to stderr while the executor drains @work threads."""
        done = self._shutdown_countdown_done

        def _countdown() -> None:
            time.sleep(self._COUNTDOWN_INITIAL_DELAY)
            for remaining in range(6, 0, -1):
                if done.is_set():
                    sys.stderr.write(self._ANSI_CLEAR_LINE)
                    sys.stderr.flush()
                    return
                sys.stderr.write(f"\rClosing connections, please wait... {remaining}")
                sys.stderr.flush()
                done.wait(timeout=1.0)
            sys.stderr.write(self._ANSI_CLEAR_LINE)
            sys.stderr.flush()

        t = threading.Thread(target=_countdown, daemon=True, name="shutdown-countdown")
        t.start()

    def _end_session_on_exit(self) -> None:
        """Save session state before exit without blocking on LLM middleware."""
        if self._api is None or self._session is None or not self._has_local_store:
            return
        try:
            # Save session directly without running after_session middleware
            # (which can make blocking LLM calls). Middleware runs at natural
            # session boundaries; exit is an abrupt teardown.
            from memex.session import save_session

            self._session.ended_at = __import__("datetime").utcnow()
            save_session(self._session, self._api.store)
        except Exception:
            logger.debug("Failed to save session on exit", exc_info=True)

    def action_add_goal(self) -> None:
        """Focus input bar with goal creation command."""
        input_bar = self.query_one("#input-bar", InputBar)
        input_bar.focus()
        input_bar.value = "I want to "
        input_bar.cursor_position = len(input_bar.value)

    def _copy_to_system_clipboard(self, text: str) -> bool:
        """Copy text to system clipboard with platform-specific fallbacks.

        Tries clip.exe (WSL), pbcopy (macOS), xclip, xsel in order.
        Falls back to Textual's OSC 52 method.
        Returns True if a native clipboard tool was used.
        """
        for cmd in ("clip.exe", "pbcopy", "xclip", "xsel"):
            path = shutil.which(cmd)
            if path is None:
                continue
            try:
                args = [path]
                if cmd == "xclip":
                    args += ["-selection", "clipboard"]
                elif cmd == "xsel":
                    args += ["--clipboard", "--input"]
                subprocess.run(
                    args,
                    input=text.encode(),
                    check=True,
                    timeout=5,
                    stderr=subprocess.DEVNULL,
                )
                return True
            except Exception:
                continue
        # Fallback to Textual OSC 52
        self.copy_to_clipboard(text)
        return False

    def action_copy_recent(self) -> None:
        """Copy last 1-3 request/response pairs to system clipboard."""
        conversation = self.query_one("#conversation", ConversationPanel)
        pairs = conversation.get_recent_pairs(3)
        if not pairs:
            conversation.add_message("system", "Nothing to copy.")
            return

        lines: list[str] = []
        for human_text, assistant_text in pairs:
            lines.append(f"> {human_text}")
            lines.append("")
            lines.append(assistant_text)
            lines.append("")
            lines.append("---")
            lines.append("")
        # Remove trailing separator
        if lines and lines[-1] == "":
            lines.pop()
        if lines and lines[-1] == "---":
            lines.pop()

        text = "\n".join(lines)
        self._copy_to_system_clipboard(text)
        count = len(pairs)
        conversation.add_message(
            "system",
            f"Copied {count} exchange{'s' if count != 1 else ''} to clipboard.",
        )

    def action_help(self) -> None:
        """Show help."""
        conversation = self.query_one("#conversation", ConversationPanel)
        conversation.add_message(
            "system",
            "Memex TUI Help\n"
            "  Service: memex service must be running before starting the TUI\n"
            "           start: systemctl --user start memex  |  or: memex service\n"
            "           remote: memex tui --service http://host:8321\n"
            "\n"
            "  Escape — interrupt turn (keep partial), Esc again to discard\n"
            "  Ctrl+N — toggle intents drawer\n"
            "  Ctrl+A — toggle attention drawer\n"
            "  Ctrl+S — toggle scheduler drawer\n"
            "  Ctrl+E — toggle meetings drawer\n"
            "  Ctrl+Y — copy last 3 exchanges to clipboard\n"
            "  Tab / Shift+Tab — cycle focus\n"
            "  a — add goal\n"
            "  q — quit\n"
            "  F1 — this help\n"
            "  Shift+click-drag — select text (terminal native)\n"
            "  Type messages to chat. Use /commands for actions.",
        )

    # ------------------------------------------------------------------
    # Service-mode event worker
    # ------------------------------------------------------------------

    @work(thread=True, name="service-events", exit_on_error=False)
    def _start_service_event_worker(self) -> None:
        """Subscribe to /v1/events SSE when running against a service daemon.

        Translates domain events from the server into TUI data refreshes,
        replacing the local EventBus subscriptions that are not available
        in service mode. Reconnects automatically with exponential backoff.
        """
        from memex.interfaces.service_client import MemexServiceClient

        if not isinstance(self._api, MemexServiceClient):
            return

        delay = 1.0
        while not self._shutdown_event.is_set():
            try:
                for event_type, _ in self._api.stream_events():
                    if not self._service_connected:
                        self._service_connected = True
                        self.call_from_thread(self._update_service_status, True)
                    if event_type == "resync":
                        self.call_from_thread(self._load_initial_data)
                    elif event_type in {
                        "MeetingTranscribed",
                        "MeetingUpdated",
                        "MeetingCreated",
                        "MeetingDeleted",
                    }:
                        self.call_from_thread(self._load_meeting_data)
                    elif event_type in {
                        "GoalChanged",
                        "GoalCreated",
                        "GoalStatusChanged",
                        "GoalUpdated",
                    }:
                        self.call_from_thread(self._load_intent_data)
                delay = 1.0  # reset on clean stream end
            except Exception:
                self._service_connected = False
                self.call_from_thread(self._update_service_status, False)
                logger.debug(
                    "Service event worker disconnected; retrying in %.0fs",
                    delay,
                    exc_info=True,
                )
            if not self._shutdown_event.is_set():
                self._shutdown_event.wait(timeout=delay)
                delay = min(delay * 2, 30.0)

    def _update_service_status(self, connected: bool) -> None:
        """Update the footer bar with the current service connection state."""
        try:
            footer = self.query_one("#footer-bar", FooterBar)
            footer.service_connected = connected
        except Exception:
            pass
