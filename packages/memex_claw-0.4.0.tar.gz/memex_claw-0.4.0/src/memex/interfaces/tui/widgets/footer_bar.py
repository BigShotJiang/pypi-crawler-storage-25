"""Footer bar widget — context-dependent key hints."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


# Key hints per context
_HINTS = {
    "default": (
        "Tab focus · Enter send · /commands"
        " · Ctrl+N intents · Ctrl+A attn"
        " · Ctrl+E meetings · Ctrl+S sched · Ctrl+G agents"
    ),
    "intents": (
        "↑↓ navigate · Enter set focus"
        " · a)dd c)omplete p)ause b)locked x)abandon"
        " · Esc/Ctrl+N close"
    ),
    "attention": (
        "↑↓ navigate · a)pprove r)eject d)efer v)iew x)dismiss · Esc/Ctrl+A close"
    ),
    "meetings": (
        "↑↓ navigate · n)ew r)ecord t)ranscribe v)iew d)elete · Esc/Ctrl+E close"
    ),
    "meetings_recording": (
        "p/Ctrl+P pause · r/s/Ctrl+R stop recording · +/- VAD threshold"
        " · Esc/Ctrl+E close"
    ),
    "meetings_paused": (
        "p/Ctrl+P resume · r/s/Ctrl+R stop recording · Esc/Ctrl+E close"
    ),
    "scheduler": ("↑↓ navigate · e) toggle enable · r)un now · Esc/Ctrl+S close"),
    "subagents": ("↑↓ navigate · v)iew response · k)ill agent · Esc/Ctrl+G close"),
}


class FooterBar(Static):
    """Single-line footer with context-dependent key hints."""

    DEFAULT_CSS = """
    FooterBar {
        dock: bottom;
        height: 1;
        background: $panel;
        color: $text-muted;
    }
    """

    context: reactive[str] = reactive("default")
    service_connected: reactive[bool] = reactive(True)
    service_mode: reactive[bool] = reactive(False)

    def render(self) -> str:
        hints = _HINTS.get(self.context, _HINTS["default"])
        if self.service_mode and not self.service_connected:
            return " [bold red]Service disconnected — reconnecting...[/] " + hints
        return " " + hints

    def set_context(self, context: str) -> None:
        self.context = context
