"""Header bar widget — focal goal, mode, model, cost, attention badge."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

_VU_WIDTH = 10
_VU_BLOCKS = "░▒▓█"


def _vu_bar(level: float) -> str:
    """Compact 10-char VU bar using block characters, 0.0–1.0 input."""
    filled = int(min(level, 1.0) * _VU_WIDTH)
    if filled == 0 and level > 0:
        filled = 1
    return "█" * filled + "░" * (_VU_WIDTH - filled)


class HeaderBar(Static):
    """Single-line header bar docked at the top of the screen."""

    DEFAULT_CSS = """
    HeaderBar {
        dock: top;
        height: 1;
        background: $primary;
        color: $text;
    }
    """

    focal_goal: reactive[str] = reactive("")
    mode: reactive[str] = reactive("normal")
    model: reactive[str] = reactive("")
    cost: reactive[str] = reactive("")
    attn_count: reactive[int] = reactive(0)
    attn_urgency: reactive[str] = reactive("ok")  # ok | warning | error
    agent_count: reactive[int] = reactive(0)
    recording: reactive[bool] = reactive(False)
    recording_level: reactive[float] = reactive(0.0)
    route: reactive[str] = reactive("")
    activity_count: reactive[int] = reactive(0)
    activity_label: reactive[str] = reactive("")

    def render(self) -> str:
        parts = [" MEMEX "]

        if self.recording:
            bar = _vu_bar(self.recording_level)
            parts.append(f" ● REC {bar}")

        if self.focal_goal:
            parts.append(f" ◈ {self.focal_goal}")

        parts.append(f" {self.mode}")

        if self.route:
            parts.append(f"[{self.route}]")

        if self.model:
            parts.append(f"│ {self.model}")

        if self.cost:
            parts.append(f"│ {self.cost}")

        parts.append(f" ATTN:{self.attn_count}")

        if self.activity_count > 0:
            parts.append(f"ACT:{self.activity_count}")
            if self.activity_label:
                parts.append(f"[{self.activity_label}]")

        if self.agent_count > 0:
            parts.append(f"QQ:{self.agent_count}")

        return "  ".join(parts)

    def update_goal(self, title: str) -> None:
        self.focal_goal = title

    def update_mode(self, mode: str) -> None:
        self.mode = mode

    def update_model(self, model: str) -> None:
        self.model = model

    def update_cost(self, cost: str) -> None:
        self.cost = cost

    def update_attention(self, count: int, urgency: str = "ok") -> None:
        self.attn_count = count
        self.attn_urgency = urgency

    def update_recording(self, is_recording: bool) -> None:
        self.recording = is_recording
        if not is_recording:
            self.recording_level = 0.0

    def update_level(self, level: float) -> None:
        """Update the live audio level displayed in the VU bar."""
        self.recording_level = level

    def update_route(self, route: str) -> None:
        self.route = route

    def update_activity(self, count: int, label: str = "") -> None:
        self.activity_count = count
        self.activity_label = label
