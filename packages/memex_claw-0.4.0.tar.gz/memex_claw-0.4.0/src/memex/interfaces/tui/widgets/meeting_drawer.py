"""Meeting drawer — bottom panel showing recent meetings and their status."""

from __future__ import annotations

import logging
from typing import Any

from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.message import Message
from textual.widgets import DataTable, Label, Static

from memex.interfaces.tui.widgets.base_drawer import BaseDrawer

logger = logging.getLogger(__name__)


class LevelMeter(Static):
    """Live audio level meter with VAD threshold marker."""

    DEFAULT_CSS = """
    LevelMeter {
        height: 1;
        padding: 0 1;
        background: $surface;
        display: none;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__("", **kwargs)
        self._level: float = 0.0
        self._vad_threshold: float = 0.2
        self._bar_width: int = 30

    def update_level(self, level: float) -> None:
        self._level = level
        self._render_bar()

    def set_vad_threshold(self, threshold: float) -> None:
        self._vad_threshold = max(0.05, min(0.95, threshold))
        self._render_bar()

    @property
    def vad_threshold(self) -> float:
        return self._vad_threshold

    def _render_bar(self) -> None:
        filled = int(self._level * self._bar_width)
        bar_chars = list("░" * self._bar_width)
        for i in range(min(filled, self._bar_width)):
            bar_chars[i] = "█"
        vad_pos = int(self._vad_threshold * self._bar_width)
        if 0 <= vad_pos < self._bar_width:
            bar_chars[vad_pos] = "▼"
        bar = "".join(bar_chars)
        self.update(
            f"REC  {bar} {self._level:.2f}  VAD {self._vad_threshold:.2f}  [+/-] adjust  [r/s] stop"
        )


class MeetingDrawer(BaseDrawer):
    """Bottom drawer showing recent meetings with state, duration, and speaker info."""

    DRAWER_NAME = "meetings"

    DEFAULT_CSS = """
    MeetingDrawer #meeting-title {
        text-style: bold;
        padding: 0 1;
        color: $text;
        background: $surface;
    }

    MeetingDrawer DataTable {
        height: 1fr;
    }
    """

    BINDINGS = [
        Binding("enter", "view", "View", show=False),
        Binding("n", "new_meeting", "New", show=True),
        Binding("t", "transcribe", "Transcribe", show=True),
        Binding("v", "view", "View", show=True),
        Binding("d", "delete_meeting", "Delete", show=True),
        Binding("delete", "delete_meeting", "Delete", show=False),
        Binding("r", "record", "Record", show=True),
        Binding("s", "stop_recording", "Stop", show=True),
        Binding("p", "pause_toggle", "Pause", show=True),
        Binding("plus", "vad_up", "+VAD", show=False),
        Binding("equals_sign", "vad_up", "+VAD", show=False),
        Binding("minus", "vad_down", "-VAD", show=False),
        Binding("underscore", "vad_down", "-VAD", show=False),
        Binding("escape", "close_drawer", "Close", show=True),
    ]

    class MeetingAction(Message):
        def __init__(self, action: str, meeting_id: str = "", **kwargs) -> None:
            super().__init__()
            self.action = action
            self.meeting_id = meeting_id
            self.extra = kwargs

    class VadThresholdChanged(Message):
        def __init__(self, threshold: float) -> None:
            super().__init__()
            self.threshold = threshold

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._meetings: list[dict[str, Any]] = []
        self._is_recording = False
        self._is_paused = False

    @property
    def is_recording(self) -> bool:
        return self._is_recording

    @property
    def is_paused(self) -> bool:
        return self._is_paused

    def compose(self) -> ComposeResult:
        yield Label("Meetings", id="meeting-title")
        yield LevelMeter(id="level-meter")
        table = DataTable(id="meeting-table", cursor_type="row")
        table.add_columns(
            "State", "Title", "Recs", "Duration", "Speakers", "Language", "Started"
        )
        yield table

    def load_meetings(self, meetings: list[dict[str, Any]]) -> None:
        """Load meeting data into the table."""
        self._meetings = meetings
        table = self.query_one("#meeting-table", DataTable)
        table.clear()

        for m in meetings:
            state = m.get("state", "")
            state_display = (
                Text("poor transcript", style="bold yellow")
                if state == "transcribed_poor"
                else state
            )
            title = m.get("title", "Untitled") or "Untitled"
            recording_count = int(m.get("recording_count", 0) or 0)
            if recording_count:
                title = f"{title} [{recording_count} rec]"
            action_count = int(m.get("action_item_count", 0) or 0)
            if action_count:
                title = f"{title} \u26a1{action_count}"
            recordings = str(recording_count or "—")
            duration = m.get("duration_human", "—")
            speakers = str(m.get("speaker_count", 0)) if m.get("speaker_count") else "—"
            language = m.get("language", "") or "—"
            started = m.get("started_human", "—")
            table.add_row(
                state_display,
                title,
                recordings,
                duration,
                speakers,
                language,
                started,
                key=m.get("meeting_id", ""),
            )

    def focus_table(self) -> None:
        """Move focus to the meeting table for keyboard navigation."""
        self.query_one("#meeting-table", DataTable).focus()

    def _selected_meeting(self) -> dict[str, Any] | None:
        table = self.query_one("#meeting-table", DataTable)
        if table.cursor_row is None or table.cursor_row >= len(self._meetings):
            return None
        return self._meetings[table.cursor_row]

    def set_recording(
        self,
        is_recording: bool,
        vad_threshold: float = 0.2,
        *,
        paused: bool = False,
    ) -> None:
        """Toggle recording state and level meter visibility."""
        self._is_recording = is_recording
        self._is_paused = is_recording and paused
        meter = self.query_one("#level-meter", LevelMeter)
        meter.display = is_recording
        if is_recording:
            meter.set_vad_threshold(vad_threshold)
            if paused:
                meter.update("PAUSED  press p to resume  ·  press r or s to stop")
                self.query_one("#meeting-title", Label).update(
                    "Meetings — RECORDING PAUSED"
                )
            else:
                meter.update_level(0.0)
                self.query_one("#meeting-title", Label).update("Meetings — RECORDING")
        else:
            self.query_one("#meeting-title", Label).update("Meetings")

    def update_level(self, level: float) -> None:
        """Update the level meter with current audio RMS."""
        if self._is_recording and not self._is_paused:
            self.query_one("#level-meter", LevelMeter).update_level(level)

    def action_transcribe(self) -> None:
        meeting = self._selected_meeting()
        if meeting is not None:
            self.post_message(self.MeetingAction("transcribe", meeting["meeting_id"]))

    def action_view(self) -> None:
        meeting = self._selected_meeting()
        if meeting is not None:
            self.post_message(self.MeetingAction("view", meeting["meeting_id"]))

    def action_delete_meeting(self) -> None:
        meeting = self._selected_meeting()
        if meeting is not None:
            self.post_message(self.MeetingAction("delete", meeting["meeting_id"]))

    def action_new_meeting(self) -> None:
        """Open dialog to create a new meeting (title + attendees, no immediate recording)."""
        self.post_message(self.MeetingAction("new_meeting"))

    def action_record(self) -> None:
        if self._is_recording:
            self.post_message(self.MeetingAction("stop_recording"))
            return
        meeting = self._selected_meeting()
        if meeting is not None:
            self.post_message(
                self.MeetingAction("record_selected", meeting_id=meeting["meeting_id"])
            )
        else:
            self.post_message(self.MeetingAction("new_meeting"))

    def action_stop_recording(self) -> None:
        if self._is_recording:
            self.post_message(self.MeetingAction("stop_recording"))

    def action_pause_toggle(self) -> None:
        if not self._is_recording:
            return
        if self._is_paused:
            self.post_message(self.MeetingAction("resume_recording"))
        else:
            self.post_message(self.MeetingAction("pause_recording"))

    def action_vad_up(self) -> None:
        if self._is_recording:
            meter = self.query_one("#level-meter", LevelMeter)
            meter.set_vad_threshold(meter.vad_threshold + 0.05)
            self.post_message(self.VadThresholdChanged(meter.vad_threshold))

    def action_vad_down(self) -> None:
        if self._is_recording:
            meter = self.query_one("#level-meter", LevelMeter)
            meter.set_vad_threshold(meter.vad_threshold - 0.05)
            self.post_message(self.VadThresholdChanged(meter.vad_threshold))
