"""Attention drawer — bottom drawer with notifications, toggled by Ctrl+A."""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.events import Key
from textual.message import Message
from textual.widgets import Label, ListView, ListItem

from memex.interfaces.tui.widgets.base_drawer import BaseDrawer


PRIORITY_ICONS = {
    "critical": "‼",
    "high": "!",
    "normal": "─",
    "low": "·",
}


class AttentionDrawer(BaseDrawer):
    """Bottom drawer displaying notifications and approvals."""

    DRAWER_NAME = "attention"

    class NotificationAction(Message):
        def __init__(self, action: str, notification_id: str) -> None:
            super().__init__()
            self.action = action
            self.notification_id = notification_id

    def compose(self) -> ComposeResult:
        yield Label(" ATTENTION", classes="display")
        yield ListView(id="attention-list")

    def load_notifications(
        self,
        pending: list[dict[str, Any]] | None = None,
        completed: list[dict[str, Any]] | None = None,
    ) -> None:
        lv = self.query_one("#attention-list", ListView)
        lv.clear()

        if pending:
            lv.append(ListItem(Label("── NEEDS ACTION ──")))
            for n in pending:
                icon = PRIORITY_ICONS.get(n.get("priority", "normal"), "─")
                label = f" {icon} {n.get('title', '')}"
                item = ListItem(Label(label))
                item._notification = n  # type: ignore[attr-defined]
                lv.append(item)

        if completed:
            lv.append(ListItem(Label("── COMPLETED ──")))
            for n in completed:
                label = f" ✓ {n.get('title', '')}"
                item = ListItem(Label(label))
                item._notification = n  # type: ignore[attr-defined]
                lv.append(item)

    def get_count_and_urgency(
        self,
        notifications: list[dict[str, Any]] | None = None,
    ) -> tuple[int, str]:
        """Return (count, urgency) for the header bar badge.

        urgency: 'error' if any critical, 'warning' if any high, else 'ok'.
        """
        if not notifications:
            return 0, "ok"

        count = len(notifications)
        priorities = {n.get("priority", "normal") for n in notifications}

        if "critical" in priorities:
            urgency = "error"
        elif "high" in priorities:
            urgency = "warning"
        else:
            urgency = "ok"

        return count, urgency

    def on_key(self, event: Key) -> None:
        if not self.is_open:
            return

        lv = self.query_one("#attention-list", ListView)
        highlighted = lv.highlighted_child
        if highlighted is None:
            if event.key == "escape":
                event.prevent_default()
                event.stop()
                self.action_close_drawer()
            return

        notification = getattr(highlighted, "_notification", None)
        if notification is None:
            if event.key == "escape":
                event.prevent_default()
                event.stop()
                self.action_close_drawer()
            return

        nid = notification.get("notification_id", "")
        action_map = {
            "a": "approve",
            "r": "reject",
            "d": "defer",
            "v": "view",
            "x": "dismiss",
        }

        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.action_close_drawer()
        elif event.key.lower() in action_map:
            self.post_message(
                self.NotificationAction(action_map[event.key.lower()], nid)
            )
