"""Sub-agent drawer — bottom panel showing active/recent sub-agents."""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.message import Message
from textual.widgets import DataTable, Label

from memex.interfaces.tui.widgets.base_drawer import BaseDrawer


class SubAgentDrawer(BaseDrawer):
    """Bottom drawer showing sub-agent status and results."""

    DRAWER_NAME = "subagents"

    DEFAULT_CSS = """
    SubAgentDrawer #subagent-title {
        text-style: bold;
        padding: 0 1;
        color: $text;
        background: $surface;
    }

    SubAgentDrawer DataTable {
        height: 1fr;
    }
    """

    BINDINGS = [
        Binding("v", "view_response", "View", show=True),
        Binding("k", "kill_agent", "Kill", show=True),
        Binding("escape", "close_drawer", "Close", show=True),
    ]

    class AgentAction(Message):
        def __init__(self, action: str, agent_id: str) -> None:
            super().__init__()
            self.action = action
            self.agent_id = agent_id

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._agents: list[dict[str, Any]] = []

    def compose(self) -> ComposeResult:
        yield Label("Sub-Agents (QQ)", id="subagent-title")
        table = DataTable(id="subagent-table")
        table.add_columns("ID", "Question", "Status", "Elapsed")
        yield table

    def load_agents(self, agents: list[dict[str, Any]]) -> None:
        """Load agent data into the table."""
        self._agents = agents
        table = self.query_one("#subagent-table", DataTable)
        table.clear()

        status_icons = {
            "running": "...",
            "done": "[OK]",
            "error": "[ERR]",
            "cancelled": "[X]",
        }
        for agent in agents:
            status = status_icons.get(agent.get("status", ""), "?")
            table.add_row(
                agent.get("agent_id", ""),
                agent.get("label", "")[:50],
                status,
                agent.get("elapsed", ""),
                key=agent.get("agent_id", ""),
            )

    def action_view_response(self) -> None:
        table = self.query_one("#subagent-table", DataTable)
        if table.cursor_row is not None and table.cursor_row < len(self._agents):
            agent = self._agents[table.cursor_row]
            self.post_message(self.AgentAction("view", agent["agent_id"]))

    def action_kill_agent(self) -> None:
        table = self.query_one("#subagent-table", DataTable)
        if table.cursor_row is not None and table.cursor_row < len(self._agents):
            agent = self._agents[table.cursor_row]
            self.post_message(self.AgentAction("kill", agent["agent_id"]))
