"""Intent drawer — bottom drawer with goal hierarchy, toggled by Ctrl+N."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from textual.app import ComposeResult
from textual.events import Key
from textual.message import Message
from textual.widgets import Label, Tree

from memex.interfaces.tui.widgets.base_drawer import BaseDrawer
from memex.utcnow import utcnow


def _urgency_suffix(g: dict) -> str:
    """Return a compact urgency/deadline hint for a goal row."""
    status = g.get("status", "")
    if status == "blocked":
        return " (blocked)"
    if status == "failed":
        return " (failed)"

    deadline_raw = g.get("deadline")
    if not deadline_raw:
        return ""
    try:
        deadline = datetime.fromisoformat(deadline_raw)
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=timezone.utc)
        now = utcnow()
        delta = deadline - now
        days = delta.days
        if days < 0:
            return " \u26a0 OVERDUE"
        if days == 0:
            return " \U0001f534 DUE TODAY"
        if days <= 3:
            return f" \u23f0 {days}d"
        if days <= 7:
            return f" ({days}d)"
    except (ValueError, OverflowError):
        pass
    return ""


STATUS_ICONS = {
    "active": "●",
    "completed": "✓",
    "paused": "⊘",
    "blocked": "○",
    "failed": "✗",
    "abandoned": "◌",
}


class IntentDrawer(BaseDrawer):
    """Right-sidebar drawer displaying goal intent tree."""

    DRAWER_NAME = "intent"

    DEFAULT_CSS = """
    IntentDrawer {
        dock: right;
        width: 30%;
        height: 100%;
        display: none;
        border-left: solid $secondary;
    }
    """

    def compose(self) -> ComposeResult:
        yield Label(" INTENTS", classes="display")
        yield Tree("Goals", id="intent-tree-inner")

    class FocalGoalSelected(Message):
        def __init__(self, goal_id: str, title: str) -> None:
            super().__init__()
            self.goal_id = goal_id
            self.title = title

    class GoalAction(Message):
        def __init__(self, action: str, goal_id: str) -> None:
            super().__init__()
            self.action = action
            self.goal_id = goal_id

    def load_goals(self, goals: list[dict[str, Any]]) -> None:
        tree = self.query_one("#intent-tree-inner", Tree)
        tree.clear()
        root = tree.root

        children_map: dict[str | None, list[dict]] = {}
        for g in goals:
            children_map.setdefault(g.get("parent_id"), []).append(g)

        def add_children(parent_node, parent_id):
            for g in children_map.get(parent_id, []):
                icon = STATUS_ICONS.get(g.get("status", ""), "?")
                priority = g.get("priority", "")[:3]
                suffix = _urgency_suffix(g)
                label = f"{icon} {g.get('title', '(untitled)')} ({priority}){suffix}"
                node = parent_node.add(label, data=g)
                add_children(node, g.get("goal_id"))

        add_children(root, None)
        root.expand()

    def on_tree_node_selected(self, event: Tree.NodeSelected) -> None:
        data = event.node.data
        if data and isinstance(data, dict):
            self.post_message(self.FocalGoalSelected(data["goal_id"], data["title"]))

    def on_key(self, event: Key) -> None:
        if not self.is_open:
            return

        if event.key == "escape":
            event.prevent_default()
            event.stop()
            self.action_close_drawer()
            return

        tree = self.query_one("#intent-tree-inner", Tree)
        node = tree.cursor_node
        if node is None or not isinstance(node.data, dict):
            return

        goal_id = node.data["goal_id"]
        action_map = {
            "a": "add",
            "c": "complete",
            "p": "pause",
            "b": "blocked",
            "x": "abandon",
        }

        if event.key in action_map:
            self.post_message(self.GoalAction(action_map[event.key], goal_id))
