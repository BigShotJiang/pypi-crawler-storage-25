"""Command hint panel — filterable slash command suggestions above the input bar."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.widgets import Static

if TYPE_CHECKING:
    from memex.interfaces.tui.commands import SlashCommand


class CommandHintPanel(Static):
    """Displays a filterable list of slash commands above the input bar."""

    DEFAULT_CSS = """
    CommandHintPanel {
        height: auto;
        max-height: 16;
        display: none;
        background: $surface;
        color: $text;
        padding: 0 1;
    }
    """

    can_focus = False

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._items: list[SlashCommand] = []
        self._highlight: int = -1

    def update_suggestions(self, commands: list[SlashCommand]) -> None:
        """Set the command list, reset highlight, and re-render."""
        self._items = list(commands)
        self._highlight = -1
        self._render_list()

    def move_highlight(self, delta: int) -> None:
        """Move the highlight by delta with wrap-around."""
        if not self._items:
            return
        n = len(self._items)
        if self._highlight < 0:
            # First movement from no-highlight state
            self._highlight = 0 if delta > 0 else n - 1
        else:
            self._highlight = (self._highlight + delta) % n
        self._render_list()

    @property
    def highlighted_command(self) -> SlashCommand | None:
        """Return the currently highlighted command, or None."""
        if 0 <= self._highlight < len(self._items):
            return self._items[self._highlight]
        return None

    def _render_list(self) -> None:
        """Format and display the command list."""
        lines = []
        for i, cmd in enumerate(self._items):
            marker = "▸" if i == self._highlight else " "
            alias_str = ""
            if cmd.aliases:
                alias_str = "  (" + ", ".join(cmd.aliases) + ")"
            usage = f"  {cmd.usage}" if cmd.usage else ""
            lines.append(f"{marker} {cmd.name}{alias_str}{usage}")
        # Explicitly set height so Textual doesn't clip content when
        # transitioning from display:none (height=0) to visible.
        self.styles.height = len(lines)
        self.update("\n".join(lines))
