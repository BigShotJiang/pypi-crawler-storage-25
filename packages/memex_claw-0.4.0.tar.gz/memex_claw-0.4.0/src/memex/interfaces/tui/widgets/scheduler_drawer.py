"""Scheduler drawer — bottom panel showing scheduled tasks and their status."""

from __future__ import annotations

import logging
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.message import Message
from textual.widgets import DataTable, Label

from memex.interfaces.tui.widgets.base_drawer import BaseDrawer

logger = logging.getLogger(__name__)


class SchedulerDrawer(BaseDrawer):
    """Bottom drawer showing scheduled tasks with status and next fire time."""

    DRAWER_NAME = "scheduler"

    DEFAULT_CSS = """
    SchedulerDrawer #scheduler-title {
        text-style: bold;
        padding: 0 1;
        color: $text;
        background: $surface;
    }

    SchedulerDrawer DataTable {
        height: 1fr;
    }
    """

    BINDINGS = [
        Binding("e", "toggle_enable", "Enable/Disable", show=True),
        Binding("r", "run_now", "Run Now", show=True),
        Binding("escape", "close_drawer", "Close", show=True),
    ]

    class TaskAction(Message):
        def __init__(self, action: str, task_id: str) -> None:
            super().__init__()
            self.action = action
            self.task_id = task_id

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._tasks: list[dict[str, Any]] = []

    def compose(self) -> ComposeResult:
        yield Label("Scheduler", id="scheduler-title")
        table = DataTable(id="scheduler-table")
        table.add_columns("Status", "Name", "Schedule", "Next Run", "Last Run")
        yield table

    def load_tasks(self, tasks: list[dict[str, Any]]) -> None:
        """Load task data into the table."""
        self._tasks = tasks
        table = self.query_one("#scheduler-table", DataTable)
        table.clear()

        for task in tasks:
            status = "[ON]" if task.get("enabled", True) else "[OFF]"
            name = task.get("name", "")
            schedule = task.get("schedule_human", task.get("cron_expr", ""))
            next_run = task.get("next_run_human", "—")
            last_run = task.get("last_run_status", "never")
            table.add_row(
                status, name, schedule, next_run, last_run, key=task.get("task_id", "")
            )

    def action_toggle_enable(self) -> None:
        table = self.query_one("#scheduler-table", DataTable)
        if table.cursor_row is not None and table.cursor_row < len(self._tasks):
            task = self._tasks[table.cursor_row]
            self.post_message(self.TaskAction("toggle_enable", task["task_id"]))

    def action_run_now(self) -> None:
        table = self.query_one("#scheduler-table", DataTable)
        if table.cursor_row is not None and table.cursor_row < len(self._tasks):
            task = self._tasks[table.cursor_row]
            self.post_message(self.TaskAction("run_now", task["task_id"]))
