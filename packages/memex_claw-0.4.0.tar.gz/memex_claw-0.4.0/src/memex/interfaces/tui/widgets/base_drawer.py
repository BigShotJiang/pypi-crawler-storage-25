"""BaseDrawer — shared foundation for all bottom-docked drawer panels.

Contract
--------
- Subclasses set DRAWER_NAME (used in DrawerClose.drawer).
- BaseDrawer owns: open/close state, display toggle, DrawerClose message,
  action_close_drawer(), and the common dock CSS.
- Data hydration is the app's responsibility: app.py calls load_*() after
  toggle() so the drawer stays decoupled from the store.
"""

from __future__ import annotations

from typing import ClassVar

from textual.containers import Vertical
from textual.message import Message


class BaseDrawer(Vertical):
    """Common bottom-dock drawer: open/close toggle, DrawerClose message."""

    DRAWER_NAME: ClassVar[str] = ""

    DEFAULT_CSS = """
    BaseDrawer {
        dock: bottom;
        height: 40%;
        display: none;
        border-top: solid $secondary;
    }
    """

    class DrawerClose(Message):
        """Posted when the drawer requests to be closed.

        ``drawer`` is set from the subclass DRAWER_NAME so app.py can route
        a single ``@on(BaseDrawer.DrawerClose)`` handler to the right toggle.
        """

        def __init__(self, drawer: str = "") -> None:
            super().__init__()
            self.drawer = drawer

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._open: bool = False

    @property
    def is_open(self) -> bool:
        return self._open

    def toggle(self) -> None:
        """Flip open/close state and update display visibility."""
        self._open = not self._open
        self.display = self._open

    def action_close_drawer(self) -> None:
        """Post DrawerClose so the app can toggle the drawer off."""
        self.post_message(self.DrawerClose(self.DRAWER_NAME))
