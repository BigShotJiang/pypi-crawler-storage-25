"""Conversation panel — RichLog-based chat with markdown, processing indicators, and streaming."""

from __future__ import annotations

from typing import Any

from rich.highlighter import ReprHighlighter
from rich.markdown import Markdown as RichMarkdown
from rich.text import Text

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.timer import Timer
from textual.widgets import RichLog, Static

_URL_HIGHLIGHTER = ReprHighlighter()


# ---------------------------------------------------------------------------
# Braille spinner frames
# ---------------------------------------------------------------------------

_SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


# ---------------------------------------------------------------------------
# Processing indicator — braille spinner with status text
# ---------------------------------------------------------------------------


class ProcessingIndicator(Static):
    """Animated braille spinner shown during LLM processing."""

    DEFAULT_CSS = """
    ProcessingIndicator {
        color: $secondary;
        height: 1;
        margin: 0;
    }
    """

    def __init__(self, text: str = "thinking...", **kwargs) -> None:
        super().__init__("", **kwargs)
        self._text = text
        self._frame = 0
        self._timer: Timer | None = None

    def on_mount(self) -> None:
        self._timer = self.set_interval(0.08, self._tick)
        self._render_frame()

    def _tick(self) -> None:
        self._frame = (self._frame + 1) % len(_SPINNER_FRAMES)
        self._render_frame()

    def _render_frame(self) -> None:
        char = _SPINNER_FRAMES[self._frame]
        self.update(f"{char} {self._text}")

    def update_text(self, text: str) -> None:
        """Change the status text mid-animation."""
        self._text = text
        self._render_frame()

    def stop(self) -> None:
        """Stop animation and remove from DOM."""
        if self._timer is not None:
            self._timer.stop()
            self._timer = None
        self.remove()


# ---------------------------------------------------------------------------
# Tool args formatter (module-level helper)
# ---------------------------------------------------------------------------


def _format_tool_args(arguments: dict[str, Any] | None) -> str:
    if not arguments:
        return ""
    parts = []
    for k, v in arguments.items():
        val = str(v)
        if len(val) > 60:
            val = val[:57] + "..."
        parts.append(f"{k}={val}")
    result = ", ".join(parts)
    if len(result) > 120:
        result = result[:117] + "..."
    return result


# Tool name → (verb, primary_arg_key) mapping for human-readable status lines
_TOOL_DISPLAY: dict[str, tuple[str, str | None]] = {
    "search_knowledge": ("Searched knowledge", "query"),
    "search_conversations": ("Searched conversations", "query"),
    "gmail_search": ("Searched Gmail", "query"),
    "ingest_url": ("Ingesting", "url"),
    "web_fetch": ("Fetching", "url"),
    "remember": ("Remembering", "text"),
    "forget": ("Forgetting", "query"),
    "list_goals": ("Listing goals", None),
    "list_reminders": ("Listing reminders", None),
    "self_state": ("Inspecting self-state", None),
    "cost_report": ("Checking costs", None),
    "file_transform": ("Transforming file", "instruction"),
    "get_item": ("Retrieving item", "id"),
}


def _format_tool_start(tool_name: str, arguments: dict[str, Any] | None) -> str:
    """Format a tool-call-started line using human verbs."""
    display = _TOOL_DISPLAY.get(tool_name)
    if display:
        verb, primary_key = display
        if primary_key and arguments and primary_key in arguments:
            val = str(arguments[primary_key])
            if len(val) > 60:
                val = val[:57] + "..."
            return f'{verb}: "{val}"'
        return verb
    # Fallback for unknown tools (MCP, plugins, etc.)
    args_str = _format_tool_args(arguments)
    return f"{tool_name}({args_str})"


def _format_duration(ms: int) -> str:
    """Format duration: '1.2s' for >= 1000ms, '340ms' for < 1000ms, '' for 0."""
    if ms <= 0:
        return ""
    if ms >= 1000:
        return f"{ms / 1000:.1f}s"
    return f"{ms}ms"


# ---------------------------------------------------------------------------
# Conversation panel — Vertical with RichLog + dynamic overlays
# ---------------------------------------------------------------------------


class ConversationPanel(Vertical):
    """Scrollable conversation display using RichLog.

    Messages are written as Rich renderables. Processing indicators and
    streaming content are mounted as temporary sibling widgets below the log.
    """

    DEFAULT_CSS = """
    ConversationPanel {
        height: 1fr;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._processing: ProcessingIndicator | None = None
        self._processing_suppressed = False
        self._streaming_static: Static | None = None
        self._streaming_content: str = ""
        self._interrupted_label: Static | None = None
        self._message_buffer: list[tuple[str, str]] = []
        self._spacer_filled = False

    def compose(self) -> ComposeResult:
        yield RichLog(id="chat-log", wrap=True, markup=False)

    @property
    def _log(self) -> RichLog:
        return self.query_one("#chat-log", RichLog)

    def _ensure_bottom_aligned(self) -> None:
        """Fill the RichLog with blank lines so real content starts at the bottom.

        Called lazily before the first real message is written, so spacer lines
        always precede content regardless of mount/layout timing.
        """
        if self._spacer_filled:
            return
        self._spacer_filled = True
        log = self._log
        height = log.size.height
        if height <= 0:
            height = 40  # reasonable default before first layout
        for _ in range(height):
            log.write(Text(""))

    # ── Messages ──

    def add_message(self, role: str, content: str) -> None:
        """Write a message to the log and record it in the buffer."""
        self._ensure_bottom_aligned()
        self._message_buffer.append((role, content))
        log = self._log
        if role == "assistant":
            log.write(RichMarkdown(content))
            log.write(Text(""))
        elif role == "human":
            text = Text(f"❯ {content}", style="bold #4a9eff")
            _URL_HIGHLIGHTER.highlight(text)
            log.write(text)
        elif role == "system":
            text = Text(f"--- {content}", style="italic #666666")
            _URL_HIGHLIGHTER.highlight(text)
            log.write(text)
        else:
            text = Text(content)
            _URL_HIGHLIGHTER.highlight(text)
            log.write(text)
        log.scroll_end(animate=False)

    # ── Processing indicator ──

    def show_processing(self, text: str = "thinking...") -> None:
        """Show or update the processing spinner."""
        if self._processing_suppressed:
            return  # Suppress queued call_from_thread callbacks after cancel
        if self._processing is not None:
            self._processing.update_text(text)
        else:
            self._processing = ProcessingIndicator(text)
            self.mount(self._processing)

    def update_processing(self, text: str) -> None:
        """Update processing indicator text."""
        if self._processing is not None:
            self._processing.update_text(text)

    def hide_processing(self) -> None:
        """Remove the processing spinner and suppress queued show_processing calls."""
        self._processing_suppressed = True
        if self._processing is not None:
            self._processing.stop()
            self._processing = None
            self._log.scroll_end(animate=False)

    # ── Tool calls ──

    def add_tool_call(
        self, tool_name: str, arguments: dict[str, Any] | None = None
    ) -> None:
        """Write a tool-call-started line to the log."""
        display = _format_tool_start(tool_name, arguments)
        log = self._log
        log.write(Text(f"  ● {display}", style="#a080d0"))
        log.scroll_end(animate=False)

    def complete_tool_call(
        self, tool_name: str, success: bool, duration_ms: int, summary: str = ""
    ) -> None:
        """Write a tool-call-completed line to the log."""
        log = self._log
        dur = _format_duration(duration_ms)
        dur_suffix = f" ({dur})" if dur else ""

        verb = _TOOL_DISPLAY.get(tool_name, (tool_name, None))[0]

        if success:
            display = summary[:80] if summary else "ok"
            log.write(Text(f"  ✓ {verb} → {display}{dur_suffix}", style="#a080d0"))
        else:
            # Error: first line is status, second line is error detail
            display = summary[:80] if summary else "error"
            log.write(Text(f"  ✗ {verb} → {display}{dur_suffix}", style="#ff4444"))
            # If summary is longer, add error detail on second line
            if summary and len(summary) > 80:
                detail = summary[80:200].strip()
                if detail:
                    log.write(Text(f"    {detail}", style="dim #ff4444"))
        log.scroll_end(animate=False)

    # ── Turn summary ──

    def add_turn_summary(
        self, duration_ms: int, tool_calls: int, cost_usd: float, total_tokens: int
    ) -> None:
        """Write a turn summary line to the log."""
        parts = [f"{duration_ms / 1000:.1f}s"]
        if tool_calls > 0:
            parts.append(f"{tool_calls} tool call{'s' if tool_calls != 1 else ''}")
        if cost_usd > 0:
            parts.append(f"${cost_usd:.4f}")
        if total_tokens > 0:
            if total_tokens >= 1000:
                parts.append(f"{total_tokens / 1000:.1f}k tokens")
            else:
                parts.append(f"{total_tokens} tokens")
        log = self._log
        log.write(Text("  ✻ " + " · ".join(parts), style="dim"))
        log.scroll_end(animate=False)

    # ── Streaming ──

    def start_streaming(self, role: str = "assistant") -> None:
        """Mount a temporary Static for streaming token-by-token updates."""
        self._processing_suppressed = False  # New turn — allow processing again
        self._streaming_content = ""
        self._streaming_static = Static("", classes="message-assistant")
        self.mount(self._streaming_static)

    def append_streaming(self, accumulated: str) -> None:
        """Update the streaming widget with plain text (markdown rendered on finalize)."""
        if self._streaming_static is not None:
            self._streaming_content = accumulated
            self._streaming_static.update(accumulated)

    def finish_streaming(self) -> None:
        """Remove the temporary streaming widget and scroll to bottom."""
        if self._streaming_static is not None:
            self._streaming_static.remove()
            self._streaming_static = None
        self._streaming_content = ""
        if self._interrupted_label is not None:
            self._interrupted_label.remove()
            self._interrupted_label = None
        self._log.scroll_end(animate=False)

    def get_streaming_content(self) -> str | None:
        """Return current streaming text, or None if not streaming."""
        if self._streaming_static is not None:
            content = self._streaming_content
            return content if content and content.strip() else None
        return None

    def interrupt_streaming(self) -> None:
        """Mark streaming as interrupted — keep partial text, add label below."""
        self._interrupted_label = Static(
            Text("Interrupted — Esc again to discard.", style="italic #666666"),
        )
        self.mount(self._interrupted_label)
        self._log.scroll_end(animate=False)

    def update_interrupted_label(self, text: str) -> None:
        """Update the interrupted label text (e.g. after double-Esc window expires)."""
        if self._interrupted_label is not None:
            self._interrupted_label.update(
                Text(text, style="italic #666666"),
            )

    def discard_interrupted(self) -> None:
        """Remove partial text and interrupted label (hard cancel)."""
        if self._streaming_static is not None:
            self._streaming_static.remove()
            self._streaming_static = None
        self._streaming_content = ""
        if self._interrupted_label is not None:
            self._interrupted_label.remove()
            self._interrupted_label = None
        self._log.scroll_end(animate=False)

    def finalize_interrupted(self) -> str | None:
        """Accept interrupted text — move to message log, remove widgets.

        Called when the user sends a new message after an interrupt,
        so the partial response remains visible as context.

        Note: the partial text is added to the RichLog for visual context only.
        It is intentionally NOT added to session conversation_history — the
        partial response is incomplete and the session contract requires chat()
        to manage history. See #40.
        """
        content = self.get_streaming_content()
        if self._streaming_static is not None:
            self._streaming_static.remove()
            self._streaming_static = None
        self._streaming_content = ""
        if self._interrupted_label is not None:
            self._interrupted_label.remove()
            self._interrupted_label = None
        if content:
            self.add_message("assistant", content)
        return content

    # ── Copy support ──

    def get_recent_pairs(self, n: int = 3) -> list[tuple[str, str]]:
        """Get last n human/assistant request-response pairs.

        Returns list of (human_text, assistant_text) tuples, oldest first.
        """
        pairs: list[tuple[str, str]] = []
        i = len(self._message_buffer) - 1
        while i >= 0 and len(pairs) < n:
            role, content = self._message_buffer[i]
            if role == "assistant":
                # Scan backward for the preceding human message
                j = i - 1
                while j >= 0 and self._message_buffer[j][0] != "human":
                    j -= 1
                if j >= 0:
                    pairs.append((self._message_buffer[j][1], content))
                    i = j - 1
                else:
                    i -= 1
            else:
                i -= 1
        pairs.reverse()
        return pairs

    # ── Clear ──

    def clear_messages(self) -> None:
        """Remove all messages."""
        self._log.clear()
        self._message_buffer.clear()
        if self._processing is not None:
            self._processing.stop()
            self._processing = None
        if self._streaming_static is not None:
            self._streaming_static.remove()
            self._streaming_static = None
        self._streaming_content = ""
        if self._interrupted_label is not None:
            self._interrupted_label.remove()
            self._interrupted_label = None
        # Next add_message will re-fill the spacer
        self._spacer_filled = False
