"""Input bar widget — multi-line message/command entry with paste detection."""

from __future__ import annotations

from textual.events import Key
from textual.message import Message  # Used by UserInput
from textual.widgets import TextArea
from textual.widgets._text_area import Selection

from memex.interfaces.tui.prompt_history import PromptHistory


_PASTE_LINE_THRESHOLD = 6
_MAX_VISIBLE_LINES = 8
_MIN_HEIGHT = 6  # 4 content lines + 2 border

_PROMPT = "❯ "


class InputBar(TextArea):
    """Multi-line message input with command detection and paste handling.

    Grows up to 8 visible lines. Pastes exceeding 6 lines are sent but
    displayed as a summary in the conversation panel.
    """

    DEFAULT_CSS = """
    InputBar {
        height: 6;
        max-height: 12;
        border: solid $primary;
    }
    """

    class UserInput(Message):
        """Fired when user submits input."""

        def __init__(
            self, value: str, is_command: bool, is_paste: bool = False
        ) -> None:
            super().__init__()
            self.value = value
            self.is_command = is_command
            self.is_paste = is_paste

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._pending_paste: bool = False
        self._prev_line_count: int = 1
        self._history = PromptHistory()
        self._history_index: int = 0
        self._draft: str | None = None
        self._hint_panel = None  # Set by app after compose
        self._match_commands = None  # Callable[[str], list[SlashCommand]] | None

    def on_mount(self) -> None:
        self.show_line_numbers = False
        self._history.load()
        self._history_index = len(self._history.entries)
        self._insert_prompt()

    def on_focus(self) -> None:
        """Clamp cursor after the prompt when InputBar regains focus.

        Tab/Shift+Tab navigation can leave the cursor at column 0 or create a
        selection spanning from inside the prompt outward.  Either case allows
        backspace to delete the ❯ marker.  We collapse any such selection and
        move the cursor to the first editable column.
        """
        sel = self.selection
        cursor_row, cursor_col = self.cursor_location
        in_prompt = (cursor_row == 0 and cursor_col < len(_PROMPT)) or (
            not sel.is_empty and sel.start[0] == 0 and sel.start[1] < len(_PROMPT)
        )
        if in_prompt:
            self.selection = Selection((0, len(_PROMPT)), (0, len(_PROMPT)))

    def _insert_prompt(self) -> None:
        """Insert the prompt marker if the buffer is empty."""
        if not self.text:
            self.insert(_PROMPT)

    def _get_user_text(self) -> str:
        """Return current buffer text without the prompt prefix."""
        raw = self.text
        if raw.startswith(_PROMPT):
            raw = raw[len(_PROMPT) :]
        return raw

    def _replace_buffer(self, text: str) -> None:
        """Replace buffer content with text, preserving prompt."""
        self.clear()
        self._insert_prompt()
        self.insert(text)

    def _history_up(self) -> None:
        """Navigate to previous history entry."""
        entries = self._history.entries
        if not entries:
            return
        if self._history_index == len(entries):
            self._draft = self._get_user_text()
        self._history_index = max(0, self._history_index - 1)
        self._replace_buffer(entries[self._history_index])

    def _history_down(self) -> None:
        """Navigate to next history entry or restore draft."""
        entries = self._history.entries
        if self._history_index >= len(entries):
            return
        self._history_index += 1
        if self._history_index == len(entries):
            self._replace_buffer(self._draft or "")
            self._draft = None
        else:
            self._replace_buffer(entries[self._history_index])

    def _content_width(self) -> int:
        """Return the visible text width inside the widget (excluding borders)."""
        # size.width includes border (1 char each side for solid border)
        return max(self.size.width - 2, 1)

    def _cursor_at_first_visual_line(self) -> bool:
        """Check if the cursor is on the first visual line, accounting for soft wrap."""
        row, col = self.cursor_location
        if row > 0:
            return False
        return col < self._content_width()

    def _cursor_at_last_visual_line(self) -> bool:
        """Check if the cursor is on the last visual line, accounting for soft wrap."""
        row, col = self.cursor_location
        last_row = self.document.line_count - 1
        if row < last_row:
            return False
        width = self._content_width()
        line_text = self.document.get_line(last_row)
        last_visual = (len(line_text) - 1) // width if line_text else 0
        current_visual = col // width
        return current_visual >= last_visual

    async def _on_key(self, event: Key) -> None:
        """Submit on Enter, insert newline on Shift+Enter, history on Up/Down."""
        # Command hint panel interception
        if self._hint_panel is not None and self._hint_panel.display:
            if event.key == "up":
                event.prevent_default()
                event.stop()
                self._hint_panel.move_highlight(-1)
                return
            elif event.key == "down":
                event.prevent_default()
                event.stop()
                self._hint_panel.move_highlight(1)
                return
            elif event.key == "tab":
                event.prevent_default()
                event.stop()
                cmd = self._hint_panel.highlighted_command
                if cmd:
                    self._replace_buffer(cmd.name + " ")
                self._hint_panel.display = False
                return
            elif event.key == "escape":
                event.prevent_default()
                event.stop()
                self._hint_panel.display = False
                return
            elif event.key == "enter":
                cmd = self._hint_panel.highlighted_command
                if cmd:
                    self._replace_buffer(cmd.name)
                self._hint_panel.display = False
                # fall through to existing enter handler which calls _submit()

        if event.key == "shift+enter":
            event.prevent_default()
            event.stop()
            self.insert("\n")
        elif event.key == "enter":
            event.prevent_default()
            event.stop()
            self._submit()
        elif event.key == "up":
            if self._cursor_at_first_visual_line():
                event.prevent_default()
                event.stop()
                self._history_up()
        elif event.key == "down":
            if self._cursor_at_last_visual_line():
                event.prevent_default()
                event.stop()
                self._history_down()
        elif event.key == "left":
            row, col = self.cursor_location
            if row == 0 and col <= len(_PROMPT):
                event.prevent_default()
                event.stop()
        elif event.key == "home":
            row, _ = self.cursor_location
            if row == 0:
                # Jump to just after the prompt, not column 0
                event.prevent_default()
                event.stop()
                self.cursor_location = (0, len(_PROMPT))
        elif event.key == "backspace":
            # Prevent deleting the prompt on the first line
            row, col = self.cursor_location
            if row == 0 and col <= len(_PROMPT):
                event.prevent_default()
                event.stop()
            elif not self.selection.is_empty:
                # Selection spanning into the prompt: block (cursor is past the
                # prompt but selection.start is inside it)
                start_row, start_col = self.selection.start
                if start_row == 0 and start_col < len(_PROMPT):
                    event.prevent_default()
                    event.stop()
        elif event.key == "delete":
            # Prevent forward-deleting the prompt characters
            row, col = self.cursor_location
            if row == 0 and col < len(_PROMPT):
                event.prevent_default()
                event.stop()
            elif not self.selection.is_empty:
                start_row, start_col = self.selection.start
                if start_row == 0 and start_col < len(_PROMPT):
                    event.prevent_default()
                    event.stop()

    def on_text_area_changed(self, _event: TextArea.Changed) -> None:
        """Resize height based on content lines and detect paste."""
        line_count = self.document.line_count

        # Detect paste: many lines appeared at once
        if line_count - self._prev_line_count > _PASTE_LINE_THRESHOLD:
            self._pending_paste = True

        self._prev_line_count = line_count

        new_height = min(line_count + 2, _MAX_VISIBLE_LINES + 2)  # +2 for border
        new_height = max(new_height, _MIN_HEIGHT)
        self.styles.height = new_height

        self._update_hint_panel()

    def _update_hint_panel(self) -> None:
        """Show/hide and filter the command hint panel based on current text."""
        if self._hint_panel is None or self._match_commands is None:
            return
        text = self._get_user_text()
        if text.startswith("/") and " " not in text:
            matches = self._match_commands(text)
            if matches:
                self._hint_panel.update_suggestions(matches)
                self._hint_panel.display = True
                return
        self._hint_panel.display = False

    def _submit(self) -> None:
        """Submit the current content (stripping the prompt prefix)."""
        raw = self.text
        # Strip the prompt prefix from the first line
        if raw.startswith(_PROMPT):
            raw = raw[len(_PROMPT) :]
        value = raw.strip()
        if not value:
            return

        is_command = value.startswith("/")
        is_paste = self._pending_paste

        self.post_message(InputBar.UserInput(value, is_command, is_paste))
        self._history.add(value)
        self._history_index = len(self._history.entries)
        self._draft = None
        self.clear()
        self._insert_prompt()
        self.styles.height = _MIN_HEIGHT
        self._pending_paste = False
        self._prev_line_count = 1
