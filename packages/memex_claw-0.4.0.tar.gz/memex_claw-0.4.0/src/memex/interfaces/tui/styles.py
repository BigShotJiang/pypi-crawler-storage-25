"""TCSS styles and semantic color tokens for Memex TUI.

Full-width conversation with bottom drawers layout.
- HeaderBar (top, 1 line) + ConversationPanel (1fr) + Drawers + InputBar + FooterBar
"""

APP_CSS = """\
/* ── Semantic Color Tokens ── */
$primary: #4a9eff;
$secondary: #7c8fa0;
$tertiary: #a080d0;
$error: #ff4444;
$neutral: #666666;

$status-ok: #44cc44;
$status-error: #ff4444;
$status-warning: #ffaa00;
$status-dim: #555555;

$surface: $surface;
$panel: $panel;

/* ── Full-Width Layout ── */

Screen {
    layout: vertical;
}

#conversation {
    height: 1fr;
    padding: 0 2;
    border-top: solid $primary;
    border-left: solid $primary;
    border-right: solid $primary;
}

#chat-log {
    height: 1fr;
}

#input-area {
    dock: bottom;
    height: auto;
}

#input-bar {
    height: 6;
    border: solid $primary;
}

/* ── Typography ── */

.display {
    text-style: bold;
}

.title {
    text-style: bold;
}

.body {
    text-style: none;
}

.label {
    color: $neutral;
}

/* ── Interactive States ── */

.focused {
    text-style: reverse;
}

/* ── Conversation Messages ── */

.message-human {
    color: $primary;
    margin: 0 0 1 0;
}

.message-assistant {
    margin: 0 0 1 0;
}

.message-system {
    color: $neutral;
    text-style: italic;
    margin: 0 0 1 0;
}

/* ── Processing & Tool Calls ── */

.processing-indicator {
    color: $secondary;
    margin: 0;
}

.tool-call {
    color: $tertiary;
    margin: 0;
}

.tool-call-error {
    color: $error;
}

.turn-summary {
    color: $secondary;
    margin: 0 0 1 0;
}
"""
