"""Slash command registry for the Memex TUI.

Provides a lightweight registry that _handle_command() delegates to.
Handlers receive (app, args_str) — they need access to app._api,
app.query_one(...), etc. Passing the app directly is honest about the coupling.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable, NamedTuple

if TYPE_CHECKING:
    from memex.interfaces.tui.app import MemexApp

logger = logging.getLogger(__name__)


class SlashCommand(NamedTuple):
    name: str
    handler: Callable[[MemexApp, str | None], None]
    aliases: tuple[str, ...] = ()
    usage: str = ""


class SlashCommandRegistry:
    """First-match registry for TUI slash commands."""

    def __init__(self) -> None:
        self._commands: list[SlashCommand] = []
        self._lookup: dict[str, SlashCommand] = {}

    def register(self, cmd: SlashCommand) -> None:
        self._commands.append(cmd)
        self._lookup[cmd.name] = cmd
        for alias in cmd.aliases:
            self._lookup[alias] = cmd

    def dispatch(self, app: MemexApp, command_str: str) -> bool:
        """Parse command_str and dispatch to a registered handler.

        Returns True if a handler was found and called, False otherwise.
        """
        parts = command_str.split(None, 1)
        cmd = parts[0].lower()
        args_str = parts[1] if len(parts) > 1 else None

        entry = self._lookup.get(cmd)
        if entry is None:
            return False

        try:
            entry.handler(app, args_str)
        except Exception:
            logger.exception("Slash command %s failed", cmd)
        return True

    def match(self, prefix: str) -> list[SlashCommand]:
        """Return commands matching prefix on name or aliases, deduped by name."""
        prefix = prefix.lower()
        seen: set[str] = set()
        result: list[SlashCommand] = []
        for cmd in self._commands:
            if cmd.name in seen:
                continue
            if cmd.name.startswith(prefix):
                seen.add(cmd.name)
                result.append(cmd)
                continue
            for alias in cmd.aliases:
                if alias.startswith(prefix):
                    seen.add(cmd.name)
                    result.append(cmd)
                    break
        return result

    def help_lines(self) -> list[str]:
        """Return formatted help lines for all registered commands."""
        lines = []
        for cmd in self._commands:
            alias_str = ""
            if cmd.aliases:
                alias_str = " (" + ", ".join(cmd.aliases) + ")"
            usage = f" {cmd.usage}" if cmd.usage else ""
            lines.append(f"  {cmd.name}{alias_str}{usage}")
        return lines
