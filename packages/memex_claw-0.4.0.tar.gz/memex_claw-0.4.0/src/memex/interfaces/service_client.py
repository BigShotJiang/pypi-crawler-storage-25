"""MemexServiceClient — satisfies MemexClientProtocol over HTTP.

Wraps the memex service REST + SSE API so the TUI (Phase 4+) can use it
identically to MemexAPI. Both implement MemexClientProtocol via structural
subtyping — no explicit inheritance required.

Usage::

    client = MemexServiceClient("http://127.0.0.1:8321", token=None)
    # Use identically to MemexAPI in the TUI constructor
    app = MemexApp(api=client, ...)

httpx is used for all HTTP/SSE calls. REST calls are synchronous (10 s timeout).
SSE streams use httpx.Timeout(connect=5, read=None) and are called from Textual
worker threads — never from the async event loop.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from typing import Any, Callable, Iterator

from memex.interfaces.json_util import model_to_dict as _model_to_dict
from memex.models import (
    ToolCallCompleted,
    ToolCallStarted,
    TurnCompleted,
    TurnPhase,
)

_SSE_EVENT_TYPES: dict[str, Any] = {
    "turn_phase": lambda p: TurnPhase(phase=p["phase"], model=p.get("model", "")),
    "tool_call_started": lambda p: ToolCallStarted(
        tool_name=p["tool_name"], arguments=p.get("arguments", {})
    ),
    "tool_call_completed": lambda p: ToolCallCompleted(
        tool_name=p["tool_name"],
        success=p["success"],
        duration_ms=p["duration_ms"],
        summary=p.get("summary", ""),
    ),
    "turn_completed": lambda p: TurnCompleted(
        duration_ms=p["duration_ms"],
        prompt_tokens=p["prompt_tokens"],
        completion_tokens=p["completion_tokens"],
        total_tokens=p["total_tokens"],
        cost_usd=p["cost_usd"],
        model=p["model"],
        tool_call_count=p["tool_call_count"],
    ),
}

logger = logging.getLogger(__name__)

_TRANSIENT_RETRIES = 2
_RETRY_BACKOFF = (0.5, 1.0)


class MemexServiceClient:
    """HTTP client that satisfies MemexClientProtocol.

    All data methods delegate to the running memex service via REST. The
    ``chat()`` method opens an SSE connection to ``POST /v1/chat`` and calls
    *on_token* / *on_event* callbacks exactly as MemexAPI does.
    """

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8321",
        token: str | None = None,
        session_id: str | None = None,
    ) -> None:
        import httpx

        self._base_url = base_url.rstrip("/")
        self._session_id = session_id or str(uuid.uuid4())
        headers: dict[str, str] = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=headers,
            timeout=10,
        )

    # ------------------------------------------------------------------
    # Session ID
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._session_id

    # ------------------------------------------------------------------
    # MemexClientProtocol: runtime
    # ------------------------------------------------------------------

    @property
    def runtime_registry(self) -> Any:
        return None  # owned by service process

    def set_scheduler_engine(self, engine: Any) -> None:
        pass  # no-op; service owns the scheduler

    def close(self) -> None:
        """Close the underlying httpx client."""
        try:
            self._client.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Internal: retrying request helper
    # ------------------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Make an HTTP request with automatic retry on transient errors.

        Retries on 5xx responses, connection errors, and timeouts. Non-retryable
        errors (4xx) are raised immediately.
        """
        import httpx

        # Use the method-specific shortcut (get/post/put/delete) so that
        # existing mocks in tests continue to work.
        http_fn = getattr(self._client, method.lower(), self._client.request)
        use_positional = http_fn is not self._client.request

        last_exc: Exception | None = None
        for attempt in range(_TRANSIENT_RETRIES + 1):
            try:
                r = (
                    http_fn(path, **kwargs)
                    if use_positional
                    else http_fn(method, path, **kwargs)
                )
                if r.status_code >= 500 and attempt < _TRANSIENT_RETRIES:
                    logger.debug(
                        "Transient %d from %s %s; retrying", r.status_code, method, path
                    )
                    time.sleep(_RETRY_BACKOFF[attempt])
                    continue
                return r
            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_exc = exc
                if attempt < _TRANSIENT_RETRIES:
                    logger.debug(
                        "%s on %s %s; retrying in %.1fs",
                        type(exc).__name__,
                        method,
                        path,
                        _RETRY_BACKOFF[attempt],
                    )
                    time.sleep(_RETRY_BACKOFF[attempt])
                    continue
                raise
        # Should not reach here, but satisfy type checker
        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------
    # MemexClientProtocol: core chat
    # ------------------------------------------------------------------

    def chat(
        self,
        message: str,
        caller: Any,
        *,
        session: Any | None = None,
        mode: Any | None = None,
        response_format: Any | None = None,
        on_event: Any | None = None,
        on_token: Callable[[str], None] | None = None,
    ) -> tuple[str, Any]:
        """POST /v1/chat and consume the SSE response stream.

        Calls *on_token* for each token event and *on_event* for all other
        event types. Returns (accumulated_response_text, {}).
        """
        import httpx

        accumulated: list[str] = []

        try:
            with self._client.stream(
                "POST",
                "/v1/chat",
                json={"message": message, "session_id": self._session_id},
                timeout=httpx.Timeout(None, connect=5.0),
            ) as r:
                r.raise_for_status()
                event_type = "token"
                for line in r.iter_lines():
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:"):
                        payload = json.loads(line[5:].strip())
                        if event_type == "token":
                            text = payload.get("text", "")
                            accumulated.append(text)
                            if on_token:
                                on_token(text)
                        elif event_type == "done":
                            break
                        else:
                            if on_event:
                                builder = _SSE_EVENT_TYPES.get(event_type)
                                if builder:
                                    try:
                                        on_event(builder(payload))
                                    except Exception:
                                        logger.debug(
                                            "on_event(%s) failed",
                                            event_type,
                                            exc_info=True,
                                        )
                    elif line == "":
                        event_type = "token"
        except Exception as exc:
            logger.error("MemexServiceClient.chat error: %s", exc, exc_info=True)
            raise

        return "".join(accumulated), {}

    def cancel_chat(self, session_id: str) -> None:
        """DELETE /v1/chat/{session_id} — interrupt an in-flight chat stream."""
        r = self._request("DELETE", f"/v1/chat/{session_id}")
        r.raise_for_status()

    def intent(self, caller: Any, *, include_all: bool = False) -> list[dict[str, Any]]:
        """GET /v1/goals → active goal list."""
        params = {"include_all": "true"} if include_all else {}
        r = self._request("GET", "/v1/goals", params=params)
        r.raise_for_status()
        return r.json().get("goals", [])

    def search(self, query: str, caller: Any) -> list[dict[str, Any]]:
        """POST /v1/search."""
        r = self._request("POST", "/v1/search", json={"query": query})
        r.raise_for_status()
        return r.json().get("results", [])

    def ingest_url(self, url: str, **kwargs: Any) -> dict[str, Any]:
        """POST /v1/ingest with URL."""
        r = self._request("POST", "/v1/ingest", json={"url": url})
        r.raise_for_status()
        return r.json()

    def ingest_content(self, text: str, **kwargs: Any) -> dict[str, Any]:
        """POST /v1/ingest with raw text."""
        body: dict[str, Any] = {"text": text}
        if "title" in kwargs:
            body["title"] = kwargs["title"]
        r = self._request("POST", "/v1/ingest", json=body)
        r.raise_for_status()
        return r.json()

    def end_session(self, caller: Any) -> Any:
        """DELETE /v1/sessions/{session_id} — clean up server-side session state."""
        session_id = getattr(caller, "session_id", None) or self._session_id
        if session_id:
            r = self._request("DELETE", f"/v1/sessions/{session_id}")
            r.raise_for_status()
        return None

    def enqueue_work(
        self, action_type: Any, action_data: dict[str, Any], **kwargs: Any
    ) -> Any:
        """No-op for the client — enqueuing is a service-internal operation."""
        return None

    def status(self, caller: Any) -> dict[str, Any]:
        """GET /v1/status."""
        r = self._request("GET", "/v1/status")
        r.raise_for_status()
        return r.json()

    def self_state(self, caller: Any) -> dict[str, Any]:
        """GET /v1/self-state."""
        r = self._request("GET", "/v1/self-state")
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------------
    # MemexClientProtocol: storage (not available over HTTP)
    # ------------------------------------------------------------------

    @property
    def content_store(self) -> Any:
        raise NotImplementedError(
            "content_store is not available on MemexServiceClient"
        )

    @property
    def embedding_backend(self) -> Any:
        raise NotImplementedError(
            "embedding_backend is not available on MemexServiceClient"
        )

    @property
    def db_path(self) -> str:
        raise NotImplementedError("db_path is not available on MemexServiceClient")

    @property
    def settings(self) -> Any:
        raise NotImplementedError("settings is not available on MemexServiceClient")

    @property
    def notification_store(self) -> Any:
        raise NotImplementedError(
            "notification_store is not available on MemexServiceClient"
        )

    # ------------------------------------------------------------------
    # MemexClientProtocol: meetings
    # ------------------------------------------------------------------

    def list_meetings(self, **kwargs: Any) -> list[Any]:
        r = self._request("GET", "/v1/meetings")
        r.raise_for_status()
        return r.json().get("meetings", [])

    def get_meeting(self, meeting_id: str) -> Any:
        r = self._request("GET", f"/v1/meetings/{meeting_id}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def create_meeting(self, record: Any) -> Any:
        body = _model_to_dict(record)
        r = self._request("POST", "/v1/meetings", json=body)
        r.raise_for_status()
        return r.json()

    def update_meeting(self, meeting: Any) -> None:
        mid = _get_id(meeting, "meeting_id")
        body = _model_to_dict(meeting)
        r = self._request("PUT", f"/v1/meetings/{mid}", json=body)
        r.raise_for_status()

    def delete_meeting(self, meeting_id: str) -> None:
        r = self._request("DELETE", f"/v1/meetings/{meeting_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def get_recording(self, recording_id: str) -> Any:
        r = self._request("GET", f"/v1/recordings/{recording_id}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def update_recording(self, recording: Any) -> None:
        rid = _get_id(recording, "recording_id")
        body = _model_to_dict(recording)
        r = self._request("PUT", f"/v1/recordings/{rid}", json=body)
        r.raise_for_status()

    def cleanup_stale_recordings(self) -> int:
        r = self._request("POST", "/v1/meetings/cleanup")
        r.raise_for_status()
        return r.json().get("cleaned", 0)

    def start_recording(self, meeting_id: str) -> dict[str, Any]:
        """POST /v1/meetings/{meeting_id}/record/start — start audio capture on the service."""
        r = self._request("POST", f"/v1/meetings/{meeting_id}/record/start")
        r.raise_for_status()
        return r.json()

    def stop_recording(self, meeting_id: str) -> dict[str, Any]:
        """POST /v1/meetings/{meeting_id}/record/stop — stop audio capture on the service."""
        r = self._request("POST", f"/v1/meetings/{meeting_id}/record/stop")
        r.raise_for_status()
        return r.json()

    def transcribe_meeting(self, meeting_id: str) -> dict[str, Any]:
        """POST /v1/meetings/{meeting_id}/transcribe — enqueue transcription on the service."""
        r = self._request("POST", f"/v1/meetings/{meeting_id}/transcribe")
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------------
    # MemexClientProtocol: goals
    # ------------------------------------------------------------------

    def create_goal(self, goal: Any) -> None:
        body = _model_to_dict(goal)
        r = self._request("POST", "/v1/goals", json=body)
        r.raise_for_status()

    def update_goal(self, goal: Any) -> None:
        gid = _get_id(goal, "goal_id")
        body = _model_to_dict(goal)
        r = self._request("PUT", f"/v1/goals/{gid}", json=body)
        r.raise_for_status()

    def get_goal(self, goal_id: str) -> Any:
        r = self._request("GET", f"/v1/goals/{goal_id}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def create_meeting_goal_link(self, link: Any) -> None:
        body = _model_to_dict(link)
        r = self._request("POST", "/v1/meeting-goal-links", json=body)
        r.raise_for_status()

    # ------------------------------------------------------------------
    # MemexClientProtocol: scheduler
    # ------------------------------------------------------------------

    def list_tasks(self) -> list[Any]:
        r = self._request("GET", "/v1/scheduler/tasks")
        r.raise_for_status()
        return r.json().get("tasks", [])

    def get_last_task_run(self, task_id: str) -> Any:
        r = self._request("GET", f"/v1/scheduler/tasks/{task_id}/last-run")
        r.raise_for_status()
        return r.json()

    def get_task(self, task_id: str) -> Any:
        r = self._request("GET", f"/v1/scheduler/tasks/{task_id}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def toggle_task(self, task_id: str, enabled: bool) -> None:
        r = self._request(
            "POST",
            f"/v1/scheduler/tasks/{task_id}/toggle",
            json={"enabled": enabled},
        )
        r.raise_for_status()

    # ------------------------------------------------------------------
    # MemexClientProtocol: notifications
    # ------------------------------------------------------------------

    def list_notifications(self, unread_only: bool = True) -> list[Any]:
        params = {} if unread_only else {"unread_only": "false"}
        r = self._request("GET", "/v1/notifications", params=params)
        r.raise_for_status()
        return r.json().get("notifications", [])

    def act_on_notification(self, notif_id: str, action: str) -> None:
        r = self._request(
            "POST",
            f"/v1/notifications/{notif_id}/action",
            json={"action": action},
        )
        r.raise_for_status()

    # ------------------------------------------------------------------
    # Subagents
    # ------------------------------------------------------------------

    def list_subagents(self) -> list[Any]:
        """GET /v1/subagents."""
        r = self._request("GET", "/v1/subagents")
        r.raise_for_status()
        return r.json().get("subagents", [])

    # ------------------------------------------------------------------
    # Extra: domain event SSE stream (for Phase 4 TUI event worker)
    # ------------------------------------------------------------------

    def stream_events(
        self, last_event_id: int | None = None
    ) -> Iterator[tuple[str, dict]]:
        """Consume GET /v1/events SSE and yield (event_type, payload) tuples.

        Blocks until the connection closes. Intended to be called from a
        Textual worker thread (``run_worker(thread=True)``).
        """
        import httpx

        headers: dict[str, str] = {}
        if last_event_id is not None:
            headers["Last-Event-ID"] = str(last_event_id)

        with self._client.stream(
            "GET",
            "/v1/events",
            headers=headers,
            timeout=httpx.Timeout(None, connect=5.0),
        ) as r:
            r.raise_for_status()
            event_type = "heartbeat"
            for line in r.iter_lines():
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    payload = json.loads(line[5:].strip())
                    yield event_type, payload
                elif line == "":
                    event_type = "heartbeat"


# ------------------------------------------------------------------
# Serialization helpers
# ------------------------------------------------------------------


def _get_id(obj: Any, id_field: str) -> str:
    """Extract the ID field from a model object or dict."""
    if isinstance(obj, dict):
        return obj.get(id_field, "")
    return getattr(obj, id_field, "")
