"""Plugin registry — tracks installed OpenClaw plugins.

Scans ~/.memex/plugins/ for directories containing openclaw.plugin.json
manifests. The registry is a Python-side metadata tracker; actual plugin
loading happens in the Node.js bridge process.
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PluginManifest:
    """Parsed openclaw.plugin.json metadata."""

    id: str
    name: str
    description: str
    version: str
    kind: str = ""  # "tool", "memory", "channel", "provider", "multi"
    path: Path = field(default_factory=lambda: Path("."))


@dataclass
class PluginInfo:
    """Runtime state for one plugin."""

    manifest: PluginManifest
    status: str = "installed"  # "installed", "loaded", "error"
    error: str | None = None


class PluginRegistry:
    """Tracks installed OpenClaw plugins."""

    def __init__(self, plugin_dir: Path | None = None) -> None:
        self._plugin_dir = plugin_dir or (Path.home() / ".memex" / "plugins")
        self._plugins: dict[str, PluginInfo] = {}

    @property
    def plugin_dir(self) -> Path:
        return self._plugin_dir

    def scan(self) -> list[PluginInfo]:
        """Scan plugin_dir for openclaw.plugin.json manifests.

        Returns list of discovered plugins. Idempotent — safe to call
        multiple times.
        """
        if not self._plugin_dir.is_dir():
            self._plugins.clear()
            return []

        discovered: dict[str, PluginInfo] = {}
        for child in sorted(self._plugin_dir.iterdir()):
            if not child.is_dir():
                continue
            manifest_path = child / "openclaw.plugin.json"
            if not manifest_path.is_file():
                continue
            try:
                manifest = parse_manifest(manifest_path)
                info = self._plugins.get(manifest.id)
                if info is None:
                    info = PluginInfo(manifest=manifest)
                else:
                    info.manifest = manifest
                discovered[manifest.id] = info
            except Exception:
                logger.debug("Failed to parse %s", manifest_path, exc_info=True)

        self._plugins = discovered
        return list(self._plugins.values())

    def get(self, plugin_id: str) -> PluginInfo | None:
        return self._plugins.get(plugin_id)

    def all_plugins(self) -> list[PluginInfo]:
        return list(self._plugins.values())

    def mark_loaded(self, plugin_id: str) -> None:
        info = self._plugins.get(plugin_id)
        if info:
            info.status = "loaded"

    def mark_error(self, plugin_id: str, error: str) -> None:
        info = self._plugins.get(plugin_id)
        if info:
            info.status = "error"
            info.error = error

    def installed_paths(self) -> list[str]:
        """Return filesystem paths for all installed plugin dirs."""
        return [str(p.manifest.path) for p in self._plugins.values()]

    def register(self, info: PluginInfo) -> None:
        """Register a plugin directly (e.g. after install)."""
        self._plugins[info.manifest.id] = info


def parse_manifest(path: Path) -> PluginManifest:
    """Parse an openclaw.plugin.json file."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    return PluginManifest(
        id=raw["id"],
        name=raw.get("name", raw["id"]),
        description=raw.get("description", ""),
        version=raw.get("version", "0.0.0"),
        kind=raw.get("kind", ""),
        path=path.parent,
    )


# ---------------------------------------------------------------------------
# Module-level singleton (matches get_bus() pattern)
# ---------------------------------------------------------------------------

_registry: PluginRegistry | None = None
_lock = threading.Lock()


def get_plugin_registry(
    plugin_dir: Path | None = None,
) -> PluginRegistry:
    """Get or create the process-global plugin registry."""
    global _registry
    with _lock:
        if _registry is None:
            _registry = PluginRegistry(plugin_dir)
        return _registry


def reset_plugin_registry() -> None:
    """Reset singleton (for tests)."""
    global _registry
    with _lock:
        _registry = None
