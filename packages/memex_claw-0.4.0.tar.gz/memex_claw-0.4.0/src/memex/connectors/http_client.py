"""HTTP client wrapper with logging. Never raises — returns ToolResult."""

from __future__ import annotations

import time
from typing import Any

from memex.models import ToolResult


class HttpClient:
    """Wraps httpx with lazy client creation, timeout, and error handling."""

    def __init__(self, *, timeout: float = 30.0, source: str = "http") -> None:
        self._timeout = timeout
        self._source = source
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            import httpx

            self._client = httpx.Client(timeout=self._timeout)
        return self._client

    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, str] | None = None,
        json_body: Any = None,
        headers: dict[str, str] | None = None,
    ) -> ToolResult:
        """Make an HTTP request. Never raises."""
        start = time.monotonic()
        try:
            client = self._get_client()
            resp = client.request(
                method,
                url,
                params=params,
                json=json_body,
                headers=headers,
            )
            elapsed_ms = int((time.monotonic() - start) * 1000)

            if resp.status_code >= 400:
                return ToolResult(
                    tool_name=f"{method} {url}",
                    success=False,
                    content=resp.text,
                    error=f"HTTP {resp.status_code}",
                    source=self._source,
                    duration_ms=elapsed_ms,
                )

            return ToolResult(
                tool_name=f"{method} {url}",
                success=True,
                content=resp.text,
                source=self._source,
                duration_ms=elapsed_ms,
            )
        except Exception as exc:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            return ToolResult(
                tool_name=f"{method} {url}",
                success=False,
                content="",
                error=str(exc),
                source=self._source,
                duration_ms=elapsed_ms,
            )

    def get(self, url: str, **kwargs: Any) -> ToolResult:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> ToolResult:
        return self.request("POST", url, **kwargs)

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None
