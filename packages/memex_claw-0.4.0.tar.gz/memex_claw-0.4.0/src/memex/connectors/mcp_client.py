"""MCP client with timeout, reconnect, and graceful degradation."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

from pydantic import BaseModel

from memex.models import ConnectorHealth, ToolDefinition, ToolResult
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


class _LoggerTextIO:
    """File-like object that redirects writes to a logger.

    Used to capture MCP server stderr output (e.g. "Secure MCP Filesystem
    Server running on stdio") into the log file instead of the console.
    """

    def __init__(self, server_name: str) -> None:
        self._logger = logging.getLogger(f"memex.mcp.{server_name}")
        self._buffer = ""

    def write(self, text: str) -> int:
        self._buffer += text
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            line = line.strip()
            if line:
                self._logger.debug("stderr: %s", line)
        return len(text)

    def flush(self) -> None:
        if self._buffer.strip():
            self._logger.debug("stderr: %s", self._buffer.strip())
            self._buffer = ""


class MCPClientConfig(BaseModel):
    name: str
    command: str
    args: list[str] = []
    env: dict[str, str] | None = None
    timeout_seconds: float = 30.0
    capability_prefix: str = ""  # e.g. "wake" -> "wake.read"


class MCPClient:
    """Async MCP client that connects to a subprocess via stdio.

    Not thread-safe. Use from a single thread or protect with a lock.
    """

    def __init__(self, config: MCPClientConfig) -> None:
        self.config = config
        self._session: Any = None
        self._cm: Any = None  # context manager for stdio_client
        self._session_cm: Any = None
        self._discovered_tools: list[ToolDefinition] = []
        self._available = False
        self._errlog_file: Any = None

    @property
    def available(self) -> bool:
        return self._available

    @property
    def discovered_tools(self) -> list[ToolDefinition]:
        return list(self._discovered_tools)

    async def connect(self) -> ConnectorHealth:
        """Start subprocess, MCP handshake, discover tools."""
        # Clean up any previous connection first
        if self._cm is not None:
            await self.disconnect()

        try:
            return await asyncio.wait_for(
                self._do_connect(),
                timeout=self.config.timeout_seconds,
            )
        except Exception as exc:
            # Clean up partially-initialized resources on failure
            await self.disconnect()
            return ConnectorHealth(
                name=self.config.name,
                status="unavailable",
                last_check=utcnow(),
                error=str(exc),
                tools_discovered=0,
                capability_prefix=self.config.capability_prefix,
            )

    async def _do_connect(self) -> ConnectorHealth:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        server_params = StdioServerParameters(
            command=self.config.command,
            args=self.config.args,
            env=self.config.env,
        )

        # Redirect MCP server stderr to a real file so anyio.open_process
        # gets a valid file descriptor (TextIO-like objects without fileno()
        # cause "'_LoggerTextIO' object has no attribute 'fileno'" errors).
        import os
        import tempfile

        self._errlog_file = open(
            os.path.join(
                tempfile.gettempdir(),
                f"memex-mcp-{self.config.name}.stderr.log",
            ),
            "w",
        )
        self._cm = stdio_client(server_params, errlog=self._errlog_file)
        read_stream, write_stream = await self._cm.__aenter__()

        try:
            self._session_cm = ClientSession(read_stream, write_stream)
            self._session = await self._session_cm.__aenter__()
            await self._session.initialize()
        except Exception:
            # Clean up stdio if session init fails
            try:
                await self._cm.__aexit__(None, None, None)
            except Exception:
                pass
            self._cm = None
            self._session_cm = None
            self._session = None
            raise

        # Discover tools
        tools_result = await self._session.list_tools()
        self._discovered_tools = []
        for mcp_tool in tools_result.tools:
            td = ToolDefinition(
                name=mcp_tool.name,
                description=mcp_tool.description or "",
                parameters=mcp_tool.inputSchema or {},
                source=f"mcp:{self.config.name}",
                required_capability=f"{self.config.capability_prefix}.read"
                if self.config.capability_prefix
                else "builtin.read",
            )
            self._discovered_tools.append(td)

        self._available = True
        return ConnectorHealth(
            name=self.config.name,
            status="connected",
            last_check=utcnow(),
            tools_discovered=len(self._discovered_tools),
            capability_prefix=self.config.capability_prefix,
        )

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any] | None = None
    ) -> ToolResult:
        """Call a tool with timeout. One reconnect attempt on connection error."""
        if not self._available or not self._session:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error="Client not connected",
                source=f"mcp:{self.config.name}",
                duration_ms=0,
            )

        try:
            return await asyncio.wait_for(
                self._do_call(tool_name, arguments),
                timeout=self.config.timeout_seconds,
            )
        except asyncio.TimeoutError:
            return ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error=f"Timeout after {self.config.timeout_seconds}s",
                source=f"mcp:{self.config.name}",
                duration_ms=int(self.config.timeout_seconds * 1000),
            )
        except Exception as original_exc:
            # One reconnect attempt
            try:
                await self.disconnect()
                await self.connect()
                if self._available:
                    return await asyncio.wait_for(
                        self._do_call(tool_name, arguments),
                        timeout=self.config.timeout_seconds,
                    )
            except Exception as retry_exc:
                logger.warning("Retry for %s also failed: %s", tool_name, retry_exc)

            self._available = False
            return ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error=f"Connection lost: {original_exc}",
                source=f"mcp:{self.config.name}",
                duration_ms=0,
            )

    async def _do_call(
        self, tool_name: str, arguments: dict[str, Any] | None
    ) -> ToolResult:
        start = time.monotonic()
        result = await self._session.call_tool(tool_name, arguments or {})
        elapsed_ms = int((time.monotonic() - start) * 1000)

        # Extract text content
        content_parts = []
        for item in result.content or []:
            if hasattr(item, "text"):
                content_parts.append(item.text)
            elif hasattr(item, "data"):
                content_parts.append(
                    json.dumps(item.data)
                    if isinstance(item.data, dict)
                    else str(item.data)
                )
        content = "\n".join(content_parts)

        return ToolResult(
            tool_name=tool_name,
            success=not result.isError,
            content=content,
            error=content if result.isError else None,
            source=f"mcp:{self.config.name}",
            duration_ms=elapsed_ms,
        )

    async def health_check(self) -> ConnectorHealth:
        """Quick health check."""
        if not self._available or not self._session:
            return ConnectorHealth(
                name=self.config.name,
                status="unavailable",
                last_check=utcnow(),
                capability_prefix=self.config.capability_prefix,
            )
        try:
            await asyncio.wait_for(
                self._session.list_tools(),
                timeout=5.0,
            )
            return ConnectorHealth(
                name=self.config.name,
                status="connected",
                last_check=utcnow(),
                tools_discovered=len(self._discovered_tools),
                capability_prefix=self.config.capability_prefix,
            )
        except Exception as exc:
            self._available = False
            return ConnectorHealth(
                name=self.config.name,
                status="unavailable",
                last_check=utcnow(),
                error=str(exc),
                capability_prefix=self.config.capability_prefix,
            )

    async def disconnect(self) -> None:
        """Clean up session and subprocess."""
        try:
            if self._session_cm:
                await self._session_cm.__aexit__(None, None, None)
        except Exception:
            pass
        try:
            if self._cm:
                await self._cm.__aexit__(None, None, None)
        except Exception:
            pass
        self._session = None
        self._session_cm = None
        self._cm = None
        self._available = False
        self._discovered_tools = []
        try:
            if hasattr(self, "_errlog_file") and self._errlog_file:
                self._errlog_file.close()
                self._errlog_file = None
        except Exception:
            pass


def _make_loop() -> asyncio.AbstractEventLoop:
    """Create a new event loop with a suppressed exception handler for the
    anyio cancel-scope-finalization error.

    When an MCP stdio_client async generator is garbage-collected by asyncio
    during loop shutdown, anyio raises RuntimeError('Attempted to exit cancel
    scope in a different task than it was entered in').  This is cosmetic —
    the subprocess is already being cleaned up — but it floods stderr with a
    spurious ERROR log.  The handler below downgrades that specific pattern to
    a debug trace and forwards everything else to the default handler.
    """
    loop = asyncio.new_event_loop()

    def _handler(loop: asyncio.AbstractEventLoop, context: dict) -> None:
        exc = context.get("exception")
        if isinstance(exc, RuntimeError) and "cancel scope" in str(exc):
            logger.debug(
                "Suppressed anyio cancel-scope finalization error during MCP cleanup",
                exc_info=exc,
            )
            return
        loop.default_exception_handler(context)

    loop.set_exception_handler(_handler)
    return loop


# ---------------------------------------------------------------------------
# MCP event loop — persistent loop for MCP session operations
# ---------------------------------------------------------------------------

_mcp_loop: asyncio.AbstractEventLoop | None = None
_MCP_DISPATCH_TIMEOUT = 30.0  # seconds


def create_mcp_loop() -> asyncio.AbstractEventLoop:
    """Create a new event loop suitable for MCP operations.

    Public factory so callers don't need to import the private _make_loop.
    """
    return _make_loop()


def get_mcp_loop() -> asyncio.AbstractEventLoop | None:
    """Return the registered MCP event loop, or None."""
    return _mcp_loop


def set_mcp_loop(loop: asyncio.AbstractEventLoop | None) -> None:
    """Register (or clear) the persistent MCP event loop.

    Called at service startup after connecting MCP clients, so that
    subsequent run_async() calls dispatch onto the loop where MCP
    sessions live.
    """
    global _mcp_loop
    _mcp_loop = loop


def run_async(coro: Any, *, timeout: float | None = None) -> Any:
    """Sync wrapper for async coroutines.

    Dispatch strategy (in priority order):

    1. If an MCP loop is registered via set_mcp_loop(), dispatch to it
       with run_coroutine_threadsafe.  This keeps MCP session references
       on the loop where they were created.
    2. If no MCP loop and no running loop in this thread, create a fresh
       event loop (startup path, tests, CLI).
    3. If a loop is running in this thread (should not happen with option 1),
       fall back to a thread-pool dispatch.
    """
    effective_timeout = timeout if timeout is not None else _MCP_DISPATCH_TIMEOUT

    # 1. Dispatch to persistent MCP loop if available
    if _mcp_loop is not None and _mcp_loop.is_running():
        future = asyncio.run_coroutine_threadsafe(coro, _mcp_loop)
        try:
            return future.result(timeout=effective_timeout)
        except TimeoutError:
            future.cancel()
            raise
        except Exception as exc:
            import concurrent.futures as _cf

            if isinstance(exc, _cf.TimeoutError):
                future.cancel()
                raise TimeoutError(str(exc)) from exc
            raise

    # 2. No MCP loop — try creating a fresh one (startup / CLI / tests)
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        loop = _make_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    # 3. Loop running in this thread — thread-pool fallback (legacy path)
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(1) as pool:
        return pool.submit(asyncio.run, coro).result(timeout=effective_timeout)
