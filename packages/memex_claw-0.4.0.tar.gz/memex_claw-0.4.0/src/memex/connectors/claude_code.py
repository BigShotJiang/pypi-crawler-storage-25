"""Claude Code CLI connector — subprocess-based, one-shot invocation."""

from __future__ import annotations

import json
import logging
import subprocess
import threading
import time

from pydantic import BaseModel

from memex.models import ClaudeCodeResult, ConnectorHealth, ToolResult
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


class ClaudeCodeConfig(BaseModel):
    claude_binary: str = "claude"
    default_max_turns: int = 5
    default_permission_mode: str = "plan"
    default_allowed_tools: list[str] = []
    default_timeout_seconds: float = 300.0
    default_working_directory: str | None = None
    max_cost_per_call_usd: float = 1.0
    max_cost_per_session_usd: float = 10.0
    system_prompt_append: str = ""


class ClaudeCodeClient:
    """Synchronous client that invokes claude CLI as a subprocess.

    Never raises — all errors are returned as failed ToolResult.
    """

    def __init__(self, config: ClaudeCodeConfig | None = None) -> None:
        self.config = config or ClaudeCodeConfig()
        self._session_costs: dict[str, float] = {}
        self._cost_lock = threading.Lock()
        self._last_session_id: str | None = None

    @property
    def last_session_id(self) -> str | None:
        """Session ID from the most recent successful parse."""
        return self._last_session_id

    def execute(
        self,
        prompt: str,
        *,
        max_turns: int | None = None,
        allowed_tools: list[str] | None = None,
        permission_mode: str | None = None,
        working_directory: str | None = None,
        system_prompt: str | None = None,
        timeout: float | None = None,
    ) -> ToolResult:
        """Run a one-shot claude CLI invocation."""
        cmd = self._build_command(
            prompt,
            max_turns=max_turns,
            allowed_tools=allowed_tools,
            permission_mode=permission_mode,
            system_prompt=system_prompt,
        )
        effective_timeout = timeout or self.config.default_timeout_seconds
        cwd = self._resolve_working_directory(working_directory)
        return self._run_subprocess(cmd, effective_timeout, cwd=cwd)

    def resume(
        self,
        session_id: str,
        prompt: str,
        *,
        max_turns: int | None = None,
        allowed_tools: list[str] | None = None,
        permission_mode: str | None = None,
        working_directory: str | None = None,
        system_prompt: str | None = None,
        timeout: float | None = None,
    ) -> ToolResult:
        """Resume an existing claude session."""
        budget_error = self._check_session_budget(session_id)
        if budget_error:
            return budget_error

        cmd = self._build_command(
            prompt,
            max_turns=max_turns,
            allowed_tools=allowed_tools,
            permission_mode=permission_mode,
            system_prompt=system_prompt,
            session_id=session_id,
        )
        effective_timeout = timeout or self.config.default_timeout_seconds
        cwd = self._resolve_working_directory(working_directory)
        return self._run_subprocess(cmd, effective_timeout, cwd=cwd)

    def health_check(self) -> ConnectorHealth:
        """Check if claude CLI is available by running --version."""
        try:
            proc = subprocess.run(
                [self.config.claude_binary, "--version"],
                capture_output=True,
                text=True,
                timeout=10.0,
            )
            if proc.returncode == 0:
                return ConnectorHealth(
                    name="claude_code",
                    status="connected",
                    last_check=utcnow(),
                    tools_discovered=5,
                )
            return ConnectorHealth(
                name="claude_code",
                status="unavailable",
                last_check=utcnow(),
                error=f"Exit code {proc.returncode}: {proc.stderr.strip()}",
            )
        except FileNotFoundError:
            return ConnectorHealth(
                name="claude_code",
                status="unavailable",
                last_check=utcnow(),
                error=f"Binary not found: {self.config.claude_binary}",
            )
        except Exception as exc:
            return ConnectorHealth(
                name="claude_code",
                status="unavailable",
                last_check=utcnow(),
                error=str(exc),
            )

    def _build_command(
        self,
        prompt: str,
        *,
        max_turns: int | None = None,
        allowed_tools: list[str] | None = None,
        permission_mode: str | None = None,
        system_prompt: str | None = None,
        session_id: str | None = None,
    ) -> list[str]:
        """Assemble CLI args. Always includes --output-format json."""
        cmd = [self.config.claude_binary, "-p", prompt, "--output-format", "json"]

        turns = max_turns or self.config.default_max_turns
        cmd.extend(["--max-turns", str(turns)])

        mode = permission_mode or self.config.default_permission_mode
        cmd.extend(["--permission-mode", mode])

        tools = (
            allowed_tools
            if allowed_tools is not None
            else self.config.default_allowed_tools
        )
        if tools:
            cmd.append("--allowedTools")
            cmd.extend(tools)

        effective_system = system_prompt or ""
        if self.config.system_prompt_append:
            effective_system = (
                f"{effective_system}\n{self.config.system_prompt_append}".strip()
            )
        if effective_system:
            cmd.extend(["--system-prompt", effective_system])

        if session_id:
            cmd.extend(["--resume", session_id])

        return cmd

    def _resolve_working_directory(self, working_directory: str | None) -> str | None:
        """Resolve working directory for subprocess.run cwd parameter."""
        return working_directory or self.config.default_working_directory

    def _check_session_budget(self, session_id: str) -> ToolResult | None:
        """Return a failure ToolResult if session is already over budget, else None."""
        with self._cost_lock:
            total = self._session_costs.get(session_id, 0.0)
        if total > self.config.max_cost_per_session_usd:
            return ToolResult(
                tool_name="claude_code",
                success=False,
                content="",
                error=f"Session {session_id[:8]} cost limit already exceeded: ${total:.2f} > ${self.config.max_cost_per_session_usd:.2f}",
                source="claude_code",
                duration_ms=0,
            )
        return None

    def _run_subprocess(
        self, cmd: list[str], timeout: float, *, cwd: str | None = None
    ) -> ToolResult:
        """Execute subprocess, parse JSON output, enforce cost limits."""
        start = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
        except subprocess.TimeoutExpired:
            elapsed = int((time.monotonic() - start) * 1000)
            return ToolResult(
                tool_name="claude_code",
                success=False,
                content="",
                error=f"Timeout after {timeout}s",
                source="claude_code",
                duration_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - start) * 1000)
            return ToolResult(
                tool_name="claude_code",
                success=False,
                content="",
                error=str(exc),
                source="claude_code",
                duration_ms=elapsed,
            )

        elapsed = int((time.monotonic() - start) * 1000)

        # Parse JSON output
        try:
            data = json.loads(proc.stdout)
        except (json.JSONDecodeError, TypeError):
            return ToolResult(
                tool_name="claude_code",
                success=False,
                content=proc.stdout or "",
                error=f"Invalid JSON output: {proc.stderr.strip() or 'parse error'}",
                source="claude_code",
                duration_ms=elapsed,
            )

        if not isinstance(data, dict):
            return ToolResult(
                tool_name="claude_code",
                success=False,
                content=str(data),
                error="Unexpected JSON output: expected object",
                source="claude_code",
                duration_ms=elapsed,
            )

        parsed = self._parse_result(data, elapsed)
        if parsed.session_id:
            self._last_session_id = parsed.session_id

        # Cost limit enforcement
        cost = parsed.total_cost_usd
        if cost > self.config.max_cost_per_call_usd:
            logger.warning(
                "Claude Code call cost $%.4f exceeds per-call limit $%.2f",
                cost,
                self.config.max_cost_per_call_usd,
            )

        session_id = parsed.session_id
        if session_id:
            with self._cost_lock:
                self._session_costs[session_id] = (
                    self._session_costs.get(session_id, 0.0) + cost
                )
                session_total = self._session_costs[session_id]
            if session_total > self.config.max_cost_per_session_usd:
                logger.warning(
                    "Claude Code session %s total $%.4f exceeds session limit $%.2f",
                    session_id[:8],
                    session_total,
                    self.config.max_cost_per_session_usd,
                )
                return ToolResult(
                    tool_name="claude_code",
                    success=False,
                    content=parsed.result,
                    error=f"Session cost limit exceeded: ${session_total:.2f} > ${self.config.max_cost_per_session_usd:.2f}",
                    source="claude_code",
                    duration_ms=elapsed,
                )

        return ToolResult(
            tool_name="claude_code",
            success=not parsed.is_error,
            content=parsed.result,
            error=parsed.result if parsed.is_error else None,
            source="claude_code",
            duration_ms=elapsed,
        )

    def _parse_result(self, data: dict, elapsed_ms: int) -> ClaudeCodeResult:
        """Parse claude CLI JSON output into ClaudeCodeResult."""
        return ClaudeCodeResult(
            result=data.get("result", ""),
            session_id=data.get("session_id", ""),
            total_cost_usd=data.get("cost_usd", 0.0),
            duration_ms=data.get("duration_ms", elapsed_ms),
            num_turns=data.get("num_turns", 0),
            is_error=data.get("is_error", False),
        )
