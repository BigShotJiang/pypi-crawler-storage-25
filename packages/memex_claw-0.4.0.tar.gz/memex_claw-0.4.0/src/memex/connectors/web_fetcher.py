"""Web page fetcher abstraction — swappable backends for bot-resistant fetching.

Backends:
    curl_cffi  — lightweight, impersonates browser TLS fingerprints (primary)
    httpx      — plain httpx, no anti-bot measures (fallback / testing)

Strategy chains try backends in sequence, escalating when bot challenges are
detected.  Configure via MEMEX_FETCH_STRATEGY env var or pass strategy name
to get_strategy().  Default: ``escalate``.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Protocol

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30
_DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


@dataclass(frozen=True)
class FetchResult:
    """Uniform result from any fetcher backend."""

    url: str
    status_code: int
    text: str
    ok: bool
    error: str = ""
    headers: dict[str, str] = field(default_factory=dict)


class WebFetcher(Protocol):
    """Interface that all fetcher backends implement."""

    def fetch(
        self,
        url: str,
        *,
        timeout: int = _DEFAULT_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> FetchResult: ...

    def close(self) -> None: ...


# ---------------------------------------------------------------------------
# Backend: curl_cffi
# ---------------------------------------------------------------------------


class CurlCffiFetcher:
    """Uses curl_cffi to impersonate a real browser's TLS fingerprint."""

    def __init__(self) -> None:
        self._session: object | None = None

    def _get_session(self):  # noqa: ANN202
        if self._session is None:
            from curl_cffi import requests as curl_requests

            from memex.connectors.cookies import get_cookie_provider

            jar = get_cookie_provider().get_jar()
            self._session = curl_requests.Session(impersonate="chrome", cookies=jar)
        return self._session

    def fetch(
        self,
        url: str,
        *,
        timeout: int = _DEFAULT_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> FetchResult:
        try:
            session = self._get_session()
            resp = session.get(
                url,
                timeout=timeout,
                allow_redirects=True,
                headers=headers or None,
            )
            return FetchResult(
                url=str(resp.url),
                status_code=resp.status_code,
                text=resp.text,
                ok=resp.status_code < 400,
                headers={str(k).lower(): str(v) for k, v in resp.headers.items()},
            )
        except Exception as exc:
            logger.debug("curl_cffi fetch failed for %s: %s", url, exc)
            return FetchResult(
                url=url, status_code=0, text="", ok=False, error=str(exc)
            )

    def close(self) -> None:
        if self._session is not None:
            self._session.close()
            self._session = None


# ---------------------------------------------------------------------------
# Backend: httpx (browser-like headers, no TLS impersonation)
# ---------------------------------------------------------------------------

# Full header set that mimics a real Chrome navigation request.  httpx can't
# fake the TLS fingerprint, but matching the header order and values avoids
# the simplest server-side heuristics (missing Accept-Language, wrong
# Sec-Fetch-* values, etc.).
_BROWSER_HEADERS: dict[str, str] = {
    "User-Agent": _DEFAULT_USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Sec-Ch-Ua": '"Chromium";v="131", "Not_A Brand";v="24"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Linux"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "Cache-Control": "max-age=0",
}


class HttpxFetcher:
    """httpx with browser-like headers. No TLS impersonation but passes basic
    header-based bot checks."""

    def __init__(self) -> None:
        self._client: object | None = None

    def _get_client(self):  # noqa: ANN202
        if self._client is None:
            import httpx

            from memex.connectors.cookies import get_cookie_provider

            jar = get_cookie_provider().get_jar()
            self._client = httpx.Client(
                timeout=_DEFAULT_TIMEOUT,
                headers=_BROWSER_HEADERS,
                follow_redirects=True,
                http2=True,
                cookies=jar,
            )
        return self._client

    def fetch(
        self,
        url: str,
        *,
        timeout: int = _DEFAULT_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> FetchResult:
        try:
            import httpx

            client = self._get_client()
            merged_headers = dict(_BROWSER_HEADERS)
            if headers:
                merged_headers.update(headers)
            resp = client.get(
                url, timeout=httpx.Timeout(timeout), headers=merged_headers
            )
            return FetchResult(
                url=str(resp.url),
                status_code=resp.status_code,
                text=resp.text,
                ok=resp.status_code < 400,
                headers={str(k).lower(): str(v) for k, v in resp.headers.items()},
            )
        except Exception as exc:
            logger.debug("httpx fetch failed for %s: %s", url, exc)
            return FetchResult(
                url=url, status_code=0, text="", ok=False, error=str(exc)
            )

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None


# ---------------------------------------------------------------------------
# Bot-challenge detection
# ---------------------------------------------------------------------------

_BOT_CHALLENGE_SIGNALS = [
    # Cloudflare
    "cf-browser-verification",
    "cf_chl_opt",
    "challenge-platform",
    "Checking your browser",
    "Just a moment...",
    "challenges.cloudflare.com",
    # DataDome
    "_dd_s",
    "datadome.co/captcha",
    "dd.datadome",
    "geo.captcha-delivery.com",
    # PerimeterX
    "perimeterx.com",
    "px-captcha",
    # Generic
    "Please verify you are a human",
    "Access denied",
]

_MIN_CONTENT_LENGTH = 512


def _has_content(result: FetchResult) -> bool:
    """Return True if *result* looks like real page content (not a bot wall)."""
    if not result.ok:
        return False
    if len(result.text) < _MIN_CONTENT_LENGTH:
        return False
    head = result.text[:4096].lower()
    return not any(sig.lower() in head for sig in _BOT_CHALLENGE_SIGNALS)


# ---------------------------------------------------------------------------
# Strategy chain
# ---------------------------------------------------------------------------


class FetchStrategy:
    """Try backends in order, escalating when a bot challenge is detected.

    Satisfies the ``WebFetcher`` protocol so it can be used anywhere a single
    backend is expected.
    """

    def __init__(self, backends: list[WebFetcher]) -> None:
        if not backends:
            raise ValueError("FetchStrategy requires at least one backend")
        self._backends = backends

    def fetch(
        self,
        url: str,
        *,
        timeout: int = _DEFAULT_TIMEOUT,
        headers: dict[str, str] | None = None,
    ) -> FetchResult:
        last: FetchResult | None = None
        for backend in self._backends:
            last = backend.fetch(url, timeout=timeout, headers=headers)
            if _has_content(last):
                return last
            if last.status_code == 304:
                return last
            logger.debug(
                "Backend %s did not yield content for %s, trying next",
                type(backend).__name__,
                url,
            )
        assert last is not None  # backends list is non-empty
        return last

    def close(self) -> None:
        for backend in self._backends:
            backend.close()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

_BACKENDS: dict[str, type[WebFetcher]] = {
    "curl_cffi": CurlCffiFetcher,
    "httpx": HttpxFetcher,
}

_STRATEGY_CHAINS: dict[str, list[str]] = {
    "escalate": ["curl_cffi", "httpx"],
    "curl-first": ["curl_cffi", "httpx"],  # alias for escalate
    "httpx-only": ["httpx"],
}

# Module-level singleton so callers share one strategy.
_strategy: FetchStrategy | None = None


def _make_backend(name: str) -> WebFetcher | None:
    """Instantiate a backend, returning None if its dependency is missing."""
    if name == "curl_cffi":
        try:
            import curl_cffi  # noqa: F401

            return CurlCffiFetcher()
        except ImportError:
            return None
    if name == "httpx":
        return HttpxFetcher()
    return None


def get_strategy(strategy: str | None = None) -> FetchStrategy:
    """Return a shared ``FetchStrategy`` (singleton).

    Strategy resolution order:
    1. Explicit ``strategy`` argument
    2. ``MEMEX_FETCH_STRATEGY`` env var
    3. ``"escalate"``

    A single backend name (e.g. ``"httpx"``) is also accepted and wrapped in
    a one-element chain.
    """
    global _strategy

    if _strategy is not None and strategy is None:
        return _strategy

    requested = (
        strategy
        or os.environ.get("MEMEX_FETCH_STRATEGY", "").strip().lower()
        or "escalate"
    )

    # Single backend name → wrap in a chain.
    if requested in _BACKENDS:
        chain_names = [requested]
    elif requested in _STRATEGY_CHAINS:
        chain_names = _STRATEGY_CHAINS[requested]
    else:
        logger.warning(
            "Unknown MEMEX_FETCH_STRATEGY=%r, falling back to escalate",
            requested,
        )
        chain_names = _STRATEGY_CHAINS["escalate"]

    backends: list[WebFetcher] = []
    for name in chain_names:
        b = _make_backend(name)
        if b is not None:
            backends.append(b)
        else:
            logger.debug("Backend %s unavailable, skipping", name)

    # Always ensure at least httpx.
    if not backends:
        backends.append(HttpxFetcher())

    new_strategy = FetchStrategy(backends)
    logger.info(
        "Web fetch strategy: %s → %s", requested, [type(b).__name__ for b in backends]
    )

    if strategy is None:
        # Only cache when using default resolution (no explicit override).
        if _strategy is not None:
            _strategy.close()
        _strategy = new_strategy

    return new_strategy


def get_fetcher(backend: str | None = None) -> WebFetcher:
    """Backward-compatible alias — returns a ``FetchStrategy``."""
    return get_strategy(backend)


def refresh_cookies() -> None:
    """Clear cookie cache and close strategy singleton so sessions rebuild with fresh cookies."""
    global _strategy

    from memex.connectors.cookies import get_cookie_provider

    get_cookie_provider().refresh()
    if _strategy is not None:
        _strategy.close()
        _strategy = None
