"""Cookie provider for paywalled web fetching.

Two cookie sources:
1. Chromium DB (desktop active) — yt-dlp extracts encrypted cookies.
   Requires MEMEX_IMPORT_COOKIES_FROM_CHROMIUM to be set (user opt-in).
2. cookies.txt (headless fallback) — Netscape-format file via stdlib MozillaCookieJar.
   Always available; user places the file manually at ~/.memex/cookies.txt.

No new dependencies: yt-dlp (already required) handles Chromium cookie decryption;
MozillaCookieJar is stdlib.
"""

from __future__ import annotations

import logging
import os
import time
from http.cookiejar import MozillaCookieJar
from pathlib import Path

logger = logging.getLogger(__name__)

_DEFAULT_COOKIES_PATH = Path.home() / ".memex" / "cookies.txt"
_DEFAULT_BROWSER = "chromium"
_DEFAULT_TTL = 1800  # 30 minutes

_TRUTHY = {"1", "true", "yes", "on"}


def _browser_from_env() -> str | None:
    """Return browser name if MEMEX_IMPORT_COOKIES_FROM_CHROMIUM is set, else None.

    Value can be a browser name (chromium, chrome, brave) or any truthy value
    (1, true, yes, on) which defaults to chromium.
    """
    val = os.environ.get("MEMEX_IMPORT_COOKIES_FROM_CHROMIUM", "").strip().lower()
    if not val:
        return None
    return _DEFAULT_BROWSER if val in _TRUTHY else val


class CookieProvider:
    """Loads cookies from Chromium DB or cookies.txt for authenticated fetching.

    Browser cookie extraction only runs when the user has opted in via
    MEMEX_IMPORT_COOKIES_FROM_CHROMIUM. Without it, only a manually placed
    ~/.memex/cookies.txt is used.
    """

    def __init__(
        self,
        cookies_path: Path | None = None,
        browser: str | None = None,
        ttl: int = _DEFAULT_TTL,
    ) -> None:
        self._cookies_path = cookies_path or _DEFAULT_COOKIES_PATH
        # None means browser extraction is disabled (user has not opted in)
        self._browser = browser
        self._ttl = ttl
        self._jar: MozillaCookieJar | None = None
        self._loaded_at: float = 0.0
        self._attempted: bool = False

    def get_jar(self) -> MozillaCookieJar | None:
        """Return a cookie jar, using cache if TTL not expired.

        Returns None if no cookies available (fetchers work anonymously).
        """
        if self._attempted and (time.monotonic() - self._loaded_at) < self._ttl:
            return self._jar

        # Re-export from browser if file is missing or stale (and user opted in)
        if self._file_is_stale():
            self._export_from_browser()

        jar = self._load_from_file()

        self._jar = jar
        self._loaded_at = time.monotonic()
        self._attempted = True
        return jar

    def _file_is_stale(self) -> bool:
        """Return True if cookies.txt is missing or older than TTL."""
        if not self._cookies_path.exists():
            return True
        age = time.time() - self._cookies_path.stat().st_mtime
        return age > self._ttl

    def _load_from_file(self) -> MozillaCookieJar | None:
        """Load cookies from Netscape-format cookies.txt."""
        if not self._cookies_path.exists():
            return None
        try:
            jar = MozillaCookieJar(str(self._cookies_path))
            jar.load(ignore_discard=True, ignore_expires=True)
            logger.debug("Loaded %d cookies from %s", len(jar), self._cookies_path)
            return jar
        except Exception as e:
            logger.warning("Failed to load cookies from %s: %s", self._cookies_path, e)
            return None

    def _export_from_browser(self) -> bool:
        """Export cookies from browser DB via yt-dlp. Returns False on failure.

        No-ops if user has not opted in via MEMEX_IMPORT_COOKIES_FROM_CHROMIUM.
        """
        if self._browser is None:
            return False
        if not self._browser_db_exists():
            logger.debug(
                "Skipping browser cookie export for %s: cookie database not found",
                self._browser,
            )
            return False
        try:
            import yt_dlp

            opts = {
                "quiet": True,
                "no_warnings": True,
                "cookiesfrombrowser": (self._browser,),
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                jar = ydl.cookiejar
                if not isinstance(jar, MozillaCookieJar):
                    # Wrap in MozillaCookieJar for save()
                    mjar = MozillaCookieJar(str(self._cookies_path))
                    for cookie in jar:
                        mjar.set_cookie(cookie)
                    jar = mjar
                else:
                    jar.filename = str(self._cookies_path)

                self._cookies_path.parent.mkdir(parents=True, exist_ok=True)
                jar.save(ignore_discard=True, ignore_expires=True)
                os.chmod(self._cookies_path, 0o600)
                logger.info(
                    "Exported %d cookies from %s to %s",
                    len(jar),
                    self._browser,
                    self._cookies_path,
                )
                return True
        except Exception as e:
            logger.debug("Browser cookie export failed: %s", e)
            return False

    def get_yt_dlp_opts(self) -> dict:
        """Return yt-dlp cookie options dict.

        Prefers cookiesfrombrowser (live Chromium DB) when user has opted in and
        the browser DB exists, falls back to cookiefile (cookies.txt).
        """
        if self._browser is not None and self._browser_db_exists():
            return {"cookiesfrombrowser": (self._browser,)}

        if self._cookies_path.exists():
            return {"cookiefile": str(self._cookies_path)}

        return {}

    def _browser_db_exists(self) -> bool:
        """Check if the browser's cookie database file exists."""
        if self._browser is None:
            return False
        # Chromium-based browsers store cookies in ~/.config/<browser>/Default/Cookies
        browser_dirs = {
            "chromium": "chromium",
            "chrome": "google-chrome",
            "brave": "BraveSoftware/Brave-Browser",
        }
        dirname = browser_dirs.get(self._browser, self._browser)
        db_path = Path.home() / ".config" / dirname / "Default" / "Cookies"
        return db_path.exists()

    def refresh(self) -> None:
        """Clear cached jar and timestamp so next get_jar() reloads."""
        self._jar = None
        self._loaded_at = 0.0
        self._attempted = False


_provider: CookieProvider | None = None


def get_cookie_provider() -> CookieProvider:
    """Return the module-level CookieProvider singleton.

    Browser extraction is enabled only when MEMEX_IMPORT_COOKIES_FROM_CHROMIUM is set.
    Set it to a browser name (chromium, chrome, brave) or any truthy value (1, true)
    to default to chromium.
    """
    global _provider
    if _provider is None:
        _provider = CookieProvider(browser=_browser_from_env())
    return _provider
