"""Typed knowledge stubs.

These functions previously operated on raw sqlite3 connections.
They are no-ops until ported to FathomDB.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def seed_typed_knowledge_metadata(*args: Any, **kwargs: Any) -> None:
    pass


def sync_item_projection_if_needed(
    memex_store: Any,
    content_store: Any,
    item: Any,
    **kwargs: Any,
) -> None:
    if memex_store is None:
        return
    try:
        memex_store.sync_world_model_knowledge_from_item(item)
    except Exception:
        logger.debug(
            "sync_item_projection_if_needed failed for %s",
            getattr(item, "item_id", "?"),
            exc_info=True,
        )


def structured_knowledge_search_texts(payload: dict[str, Any]) -> tuple[str, ...]:
    return ()


def typed_semantic_summary_from_payload(payload: dict[str, Any]) -> str:
    for key in ("summary_text", "body_excerpt", "statement"):
        value = str(payload.get(key) or "").strip()
        if value:
            return value
    steps = payload.get("steps")
    if isinstance(steps, list) and steps:
        return "\n".join(f"- {s}" for s in steps)
    return ""


def meeting_semantic_summary_from_payload(payload: dict[str, Any]) -> str:
    return ""
