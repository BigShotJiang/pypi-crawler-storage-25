"""Tier 1 Self-Improvement: Behavioral observations and pattern detection.

The system observes its own behavior across sessions and records patterns
without taking any action. Observations are surfaced as LOW-priority
notifications for human review.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field
from memex.utcnow import utcnow


class BehavioralObservation(BaseModel):
    """A single observed behavioral pattern."""

    observation_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    pattern: str  # Short description of the pattern
    evidence: list[str] = Field(default_factory=list)  # Session IDs or turn references
    frequency: int = 1
    first_seen: datetime = Field(default_factory=utcnow)
    last_seen: datetime = Field(default_factory=utcnow)
    category: str = ""  # "response_style", "goal_tracking", "tool_usage", etc.
    confidence: float = 0.0


class ObservationStore:
    """In-memory observation storage (persisted to working memory)."""

    def __init__(self) -> None:
        self._observations: dict[str, BehavioralObservation] = {}

    def record(
        self, pattern: str, *, evidence: str = "", category: str = ""
    ) -> BehavioralObservation:
        """Record an observation, merging with existing if pattern matches."""
        for obs in self._observations.values():
            if obs.pattern == pattern:
                obs.frequency += 1
                obs.last_seen = utcnow()
                if evidence:
                    obs.evidence.append(evidence)
                    obs.evidence = obs.evidence[-10:]  # Keep last 10
                return obs

        obs = BehavioralObservation(
            pattern=pattern,
            evidence=[evidence] if evidence else [],
            category=category,
        )
        self._observations[obs.observation_id] = obs
        return obs

    def list_observations(
        self, *, min_frequency: int = 1
    ) -> list[BehavioralObservation]:
        """List observations with at least min_frequency occurrences."""
        return sorted(
            [o for o in self._observations.values() if o.frequency >= min_frequency],
            key=lambda o: o.frequency,
            reverse=True,
        )

    def to_dict(self) -> list[dict[str, Any]]:
        """Serialize for working memory persistence."""
        return [o.model_dump(mode="json") for o in self._observations.values()]

    @classmethod
    def from_dict(cls, data: list[dict[str, Any]]) -> ObservationStore:
        """Deserialize from working memory."""
        store = cls()
        for item in data:
            obs = BehavioralObservation(**item)
            store._observations[obs.observation_id] = obs
        return store


def detect_patterns(
    session_data: dict[str, Any],
    observation_store: ObservationStore,
) -> list[BehavioralObservation]:
    """Detect behavioral patterns from a completed session.

    This is called during the reflect step. Returns newly recorded observations.
    """
    new_observations: list[BehavioralObservation] = []

    turn_count = session_data.get("turn_count", 0)
    tool_failures = session_data.get("last_tool_failures", [])
    session_id = session_data.get("session_id", "unknown")

    # Pattern: High tool failure rate
    if tool_failures:
        obs = observation_store.record(
            f"Tool failures in session ({len(tool_failures)} failures)",
            evidence=session_id,
            category="tool_usage",
        )
        if obs.frequency == 1:
            new_observations.append(obs)

    # Pattern: Very short sessions (< 3 turns)
    if 0 < turn_count < 3:
        obs = observation_store.record(
            "Very short session (< 3 turns)",
            evidence=session_id,
            category="session_behavior",
        )
        if obs.frequency == 1:
            new_observations.append(obs)

    # Pattern: Very long sessions (> 30 turns)
    if turn_count > 30:
        obs = observation_store.record(
            "Very long session (> 30 turns)",
            evidence=session_id,
            category="session_behavior",
        )
        if obs.frequency == 1:
            new_observations.append(obs)

    return new_observations
