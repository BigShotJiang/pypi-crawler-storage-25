"""Tier 2 Self-Improvement: Configuration tuning proposals.

The system can propose changes to its own configuration parameters,
subject to a human-maintained allowlist with value ranges.
All proposals require human approval.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class ConfigProposal(BaseModel):
    """A proposed configuration change."""

    parameter: str
    current_value: Any
    proposed_value: Any
    reason: str
    confidence: float = 0.0
    approved: bool | None = None  # None = pending


class AllowedParameter(BaseModel):
    """A parameter that the system is allowed to propose changes to."""

    name: str
    type: str  # "int", "float", "str"
    min_value: float | None = None
    max_value: float | None = None
    allowed_values: list[str] | None = None


def load_allowed_proposals(path: Path | None = None) -> list[AllowedParameter]:
    """Load the allowed proposals configuration.

    Returns empty list if file doesn't exist (no proposals allowed).
    """
    if path is None:
        path = Path(
            os.environ.get(
                "MEMEX_ALLOWED_PROPOSALS",
                "self_improvement/allowed_proposals.yaml",
            )
        )

    if not path.exists():
        return []

    try:
        import yaml

        with open(path) as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict) or "parameters" not in data:
            return []

        return [AllowedParameter(**p) for p in data["parameters"]]
    except Exception:
        logger.debug("Failed to load allowed proposals from %s", path, exc_info=True)
        return []


def validate_proposal(
    proposal: ConfigProposal,
    allowed: list[AllowedParameter],
) -> str | None:
    """Validate a proposal against the allowlist.

    Returns None if valid, error string if invalid.
    """
    param = next((a for a in allowed if a.name == proposal.parameter), None)
    if param is None:
        return f"Parameter '{proposal.parameter}' is not in the allowlist"

    value = proposal.proposed_value

    if param.type == "int":
        try:
            value = int(value)
        except (TypeError, ValueError):
            return f"Value must be an integer, got {type(value).__name__}"

    if param.type == "float":
        try:
            value = float(value)
        except (TypeError, ValueError):
            return f"Value must be a float, got {type(value).__name__}"

    if param.min_value is not None and float(value) < param.min_value:
        return f"Value {value} is below minimum {param.min_value}"

    if param.max_value is not None and float(value) > param.max_value:
        return f"Value {value} is above maximum {param.max_value}"

    if param.allowed_values is not None and str(value) not in param.allowed_values:
        return f"Value '{value}' is not in allowed values: {param.allowed_values}"

    return None
