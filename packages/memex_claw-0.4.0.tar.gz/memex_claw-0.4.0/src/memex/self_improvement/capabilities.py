"""Tier 3 Self-Improvement: Capability proposals.

The system can generate structured proposals for new capabilities,
stored as documents in the content store for human review.
No automatic execution — purely advisory.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, Field
from memex.utcnow import utcnow


class CapabilityProposal(BaseModel):
    """A structured proposal for a new capability or improvement."""

    proposal_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    rationale: str = ""
    estimated_complexity: str = "medium"  # "low", "medium", "high"
    category: str = ""  # "tool_integration", "workflow", "knowledge", etc.
    related_observations: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utcnow)
    status: str = "proposed"  # "proposed", "accepted", "rejected", "deferred"


def generate_proposal(
    title: str,
    description: str,
    *,
    rationale: str = "",
    category: str = "",
    related_observations: list[str] | None = None,
    complexity: str = "medium",
) -> CapabilityProposal:
    """Create a new capability proposal."""
    return CapabilityProposal(
        title=title,
        description=description,
        rationale=rationale,
        estimated_complexity=complexity,
        category=category,
        related_observations=related_observations or [],
    )


def proposal_to_document(proposal: CapabilityProposal) -> str:
    """Render a proposal as a human-readable document."""
    lines = [
        f"# Capability Proposal: {proposal.title}",
        "",
        f"**ID:** {proposal.proposal_id}",
        f"**Category:** {proposal.category or 'general'}",
        f"**Complexity:** {proposal.estimated_complexity}",
        f"**Status:** {proposal.status}",
        f"**Created:** {proposal.created_at.isoformat()}",
        "",
        "## Description",
        "",
        proposal.description,
    ]

    if proposal.rationale:
        lines.extend(
            [
                "",
                "## Rationale",
                "",
                proposal.rationale,
            ]
        )

    if proposal.related_observations:
        lines.extend(
            [
                "",
                "## Related Observations",
                "",
            ]
        )
        for obs_id in proposal.related_observations:
            lines.append(f"- {obs_id}")

    return "\n".join(lines)
