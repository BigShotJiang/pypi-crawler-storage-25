"""Turn lifecycle middleware — named interception points for cross-cutting concerns.

Each method corresponds to a real call site in loop.py and session.py.

Usage:
    chain = MiddlewareChain([
        AuditMiddleware(audit_log),        # future
        CostGuardMiddleware(cost_guard),   # future
    ])

    # In loop.py:
    brief = chain.before_session(session)
    chain.after_classify(session, classification)
    chain.after_reflect(session, reflect_result, classification)
    chain.after_turn(session, response)

    # In session.py:
    chain.after_session(session, store)

Methods that return values (before_session → str) are aggregated by the chain.
Methods that return None are fire-and-forget. All methods catch exceptions
internally — middleware never aborts the loop.
"""

from __future__ import annotations

import logging
from typing import Any

from memex.models import InputClassification, ReflectResult, SessionContext
from memex.store import MemexStore

logger = logging.getLogger(__name__)


class TurnMiddleware:
    """Base class for turn lifecycle middleware.

    Implement any subset of these methods. Methods not overridden are no-ops.
    All methods receive the session and relevant turn data.

    Lifecycle hooks (original):
      before_session  — called once when session starts (turn_count == 0)
      after_classify  — called after LLM classification (step 2)
      after_reflect   — called after LLM reflection (step 8)
      after_turn      — called at the end of every turn
      after_session   — called when session ends

    Extended hooks:
      on_message_received  — transform user input before processing
      on_message_sending   — transform response before delivery
      before_prompt_build  — inject system prompt content every turn
      on_llm_input         — observe final messages before LLM call
      on_llm_output        — observe raw LLM response
      before_tool_call     — modify/block tool calls
      after_tool_call      — observe tool results
    """

    def before_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> str:
        """Called on the first turn of a session.

        Returns a string to prepend to the system prompt, or "".
        """
        return ""

    def after_classify(
        self,
        session: SessionContext,
        classification: InputClassification,
    ) -> None:
        """Called after the classify step (LLM #1)."""

    def after_reflect(
        self,
        session: SessionContext,
        reflect_result: ReflectResult,
        classification: InputClassification,
    ) -> None:
        """Called after the reflect step (LLM #3)."""

    def after_turn(
        self,
        session: SessionContext,
        response: str,
    ) -> None:
        """Called at the end of every turn, after all processing."""

    def after_retrieval(
        self,
        session: SessionContext,
        *,
        query: str,
        items_retrieved: int,
        avg_relevance: float = 0.0,
    ) -> None:
        """Called after turn-time retrieval uses knowledge for the response."""

    def after_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> None:
        """Called when a session ends."""

    # --- Extended hooks ---

    def on_message_received(
        self,
        session: SessionContext,
        user_input: str,
    ) -> str:
        """Transform user input before processing.

        Returns the (possibly modified) input string.
        Called sequentially; each middleware transforms the result of the previous.
        """
        return user_input

    def on_message_sending(
        self,
        session: SessionContext,
        response: str,
    ) -> str:
        """Transform response before delivery.

        Returns the (possibly modified) response string.
        Called sequentially; each middleware transforms the result of the previous.
        """
        return response

    def before_prompt_build(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> str:
        """Inject system prompt content every turn (not just first).

        Returns a string to include in the system prompt, or "".
        """
        return ""

    def on_llm_input(
        self,
        session: SessionContext,
        messages: list[dict[str, Any]],
    ) -> None:
        """Observe final messages before LLM call. Fire-and-forget."""

    def on_llm_output(
        self,
        session: SessionContext,
        response: str,
        tool_calls: list[dict[str, Any]],
    ) -> None:
        """Observe raw LLM response and tool calls. Fire-and-forget."""

    def before_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Modify or block a tool call before execution.

        Returns (arguments, blocked). If blocked=True, the tool call is skipped
        and an error result is returned.
        """
        return arguments, False

    def after_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
        result: Any,
    ) -> None:
        """Observe tool result after execution. Fire-and-forget."""


class MiddlewareChain:
    """Runs a list of TurnMiddleware in order, catching exceptions.

    For before_session (which returns strings), results are concatenated.
    For void methods, exceptions are logged and swallowed — middleware
    never aborts the loop.
    """

    def __init__(self, middleware: list[TurnMiddleware] | None = None) -> None:
        self._middleware = middleware or []

    def add(self, mw: TurnMiddleware) -> None:
        """Append a middleware to the chain."""
        self._middleware.append(mw)

    def before_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> str:
        """Run all before_session hooks. Concatenate returned strings."""
        parts: list[str] = []
        for mw in self._middleware:
            try:
                result = mw.before_session(session, store)
                if result:
                    parts.append(result)
            except Exception:
                logger.debug(
                    "%s.before_session failed", type(mw).__name__, exc_info=True
                )
        return "\n\n".join(parts) if parts else ""

    def after_classify(
        self,
        session: SessionContext,
        classification: InputClassification,
    ) -> None:
        """Run all after_classify hooks."""
        for mw in self._middleware:
            try:
                mw.after_classify(session, classification)
            except Exception:
                logger.debug(
                    "%s.after_classify failed", type(mw).__name__, exc_info=True
                )

    def after_reflect(
        self,
        session: SessionContext,
        reflect_result: ReflectResult,
        classification: InputClassification,
    ) -> None:
        """Run all after_reflect hooks."""
        for mw in self._middleware:
            try:
                mw.after_reflect(session, reflect_result, classification)
            except Exception:
                logger.debug(
                    "%s.after_reflect failed", type(mw).__name__, exc_info=True
                )

    def after_turn(
        self,
        session: SessionContext,
        response: str,
    ) -> None:
        """Run all after_turn hooks."""
        for mw in self._middleware:
            try:
                mw.after_turn(session, response)
            except Exception:
                logger.debug("%s.after_turn failed", type(mw).__name__, exc_info=True)

    def after_retrieval(
        self,
        session: SessionContext,
        *,
        query: str,
        items_retrieved: int,
        avg_relevance: float = 0.0,
    ) -> None:
        """Run all after_retrieval hooks."""
        for mw in self._middleware:
            try:
                mw.after_retrieval(
                    session,
                    query=query,
                    items_retrieved=items_retrieved,
                    avg_relevance=avg_relevance,
                )
            except Exception:
                logger.debug(
                    "%s.after_retrieval failed", type(mw).__name__, exc_info=True
                )

    def after_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> None:
        """Run all after_session hooks."""
        for mw in self._middleware:
            try:
                mw.after_session(session, store)
            except Exception:
                logger.debug(
                    "%s.after_session failed", type(mw).__name__, exc_info=True
                )

    # --- Extended hook dispatchers ---

    def on_message_received(
        self,
        session: SessionContext,
        user_input: str,
    ) -> str:
        """Run all on_message_received hooks. Sequential transform."""
        result = user_input
        for mw in self._middleware:
            try:
                result = mw.on_message_received(session, result)
            except Exception:
                logger.debug(
                    "%s.on_message_received failed", type(mw).__name__, exc_info=True
                )
        return result

    def on_message_sending(
        self,
        session: SessionContext,
        response: str,
    ) -> str:
        """Run all on_message_sending hooks. Sequential transform."""
        result = response
        for mw in self._middleware:
            try:
                result = mw.on_message_sending(session, result)
            except Exception:
                logger.debug(
                    "%s.on_message_sending failed", type(mw).__name__, exc_info=True
                )
        return result

    def before_prompt_build(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> str:
        """Run all before_prompt_build hooks. Concatenate non-empty returns."""
        parts: list[str] = []
        for mw in self._middleware:
            try:
                result = mw.before_prompt_build(session, store)
                if result:
                    parts.append(result)
            except Exception:
                logger.debug(
                    "%s.before_prompt_build failed", type(mw).__name__, exc_info=True
                )
        return "\n\n".join(parts) if parts else ""

    def on_llm_input(
        self,
        session: SessionContext,
        messages: list[dict[str, Any]],
    ) -> None:
        """Run all on_llm_input hooks. Fire-and-forget."""
        for mw in self._middleware:
            try:
                mw.on_llm_input(session, messages)
            except Exception:
                logger.debug("%s.on_llm_input failed", type(mw).__name__, exc_info=True)

    def on_llm_output(
        self,
        session: SessionContext,
        response: str,
        tool_calls: list[dict[str, Any]],
    ) -> None:
        """Run all on_llm_output hooks. Fire-and-forget."""
        for mw in self._middleware:
            try:
                mw.on_llm_output(session, response, tool_calls)
            except Exception:
                logger.debug(
                    "%s.on_llm_output failed", type(mw).__name__, exc_info=True
                )

    def before_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Run all before_tool_call hooks. First blocked=True wins."""
        args = arguments
        for mw in self._middleware:
            try:
                args, blocked = mw.before_tool_call(session, tool_name, args)
                if blocked:
                    return args, True
            except Exception:
                logger.debug(
                    "%s.before_tool_call failed", type(mw).__name__, exc_info=True
                )
        return args, False

    def after_tool_call(
        self,
        session: SessionContext,
        tool_name: str,
        arguments: dict[str, Any],
        result: Any,
    ) -> None:
        """Run all after_tool_call hooks. Fire-and-forget."""
        for mw in self._middleware:
            try:
                mw.after_tool_call(session, tool_name, arguments, result)
            except Exception:
                logger.debug(
                    "%s.after_tool_call failed", type(mw).__name__, exc_info=True
                )
