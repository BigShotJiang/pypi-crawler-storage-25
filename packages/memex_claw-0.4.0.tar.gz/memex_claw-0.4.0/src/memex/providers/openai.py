"""OpenAI API provider."""

from __future__ import annotations

from memex.providers_base import (
    Provider,
    ProviderCredential,
    ProviderSetupResult,
    SetupPrompter,
)


class OpenAIProvider(Provider):
    @property
    def id(self) -> str:
        return "openai"

    @property
    def name(self) -> str:
        return "OpenAI (GPT)"

    @property
    def env_vars(self) -> list[str]:
        return ["OPENAI_API_KEY"]

    def setup(self, prompter: SetupPrompter) -> ProviderSetupResult:
        prompter.info("Set up OpenAI API access for GPT models.")
        prompter.info("Get your API key at https://platform.openai.com/api-keys")

        api_key = prompter.text("OpenAI API key", secret=True)
        if not api_key:
            return ProviderSetupResult(success=False, message="No API key provided")

        credentials = [
            ProviderCredential(key="api_key", value=api_key, env_var="OPENAI_API_KEY"),
        ]

        return ProviderSetupResult(
            success=True,
            credentials=credentials,
            message="OpenAI API key saved",
        )
