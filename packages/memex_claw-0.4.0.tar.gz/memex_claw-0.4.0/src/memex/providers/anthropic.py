"""Anthropic API provider."""

from __future__ import annotations

from memex.providers_base import (
    Provider,
    ProviderCredential,
    ProviderSetupResult,
    SetupPrompter,
)


class AnthropicProvider(Provider):
    @property
    def id(self) -> str:
        return "anthropic"

    @property
    def name(self) -> str:
        return "Anthropic (Claude)"

    @property
    def env_vars(self) -> list[str]:
        return ["ANTHROPIC_API_KEY"]

    def setup(self, prompter: SetupPrompter) -> ProviderSetupResult:
        prompter.info("Set up Anthropic API access for Claude models.")
        prompter.info("Get your API key at https://console.anthropic.com/")

        api_key = prompter.text("Anthropic API key", secret=True)
        if not api_key:
            return ProviderSetupResult(success=False, message="No API key provided")

        credentials = [
            ProviderCredential(
                key="api_key", value=api_key, env_var="ANTHROPIC_API_KEY"
            ),
        ]

        return ProviderSetupResult(
            success=True,
            credentials=credentials,
            message="Anthropic API key saved",
        )

    def validate(self, credentials: list[ProviderCredential]) -> bool:
        # Basic format check — starts with sk-ant-
        for c in credentials:
            if c.key == "api_key" and c.value.startswith("sk-ant-"):
                return True
        return False
