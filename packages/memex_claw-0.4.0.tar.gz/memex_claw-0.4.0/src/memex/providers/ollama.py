"""Ollama local provider — auto-detects local Ollama installation."""

from __future__ import annotations

import urllib.request
import urllib.error

from memex.providers_base import (
    Provider,
    ProviderCredential,
    ProviderSetupResult,
    SetupPrompter,
)


class OllamaProvider(Provider):
    @property
    def id(self) -> str:
        return "ollama"

    @property
    def name(self) -> str:
        return "Ollama (Local)"

    @property
    def env_vars(self) -> list[str]:
        return ["OLLAMA_BASE_URL"]

    def setup(self, prompter: SetupPrompter) -> ProviderSetupResult:
        prompter.info("Set up Ollama for local model inference.")

        default_url = "http://localhost:11434"
        base_url = prompter.text("Ollama base URL", default=default_url)

        # Auto-detect
        prompter.progress("Checking Ollama connection...")
        try:
            req = urllib.request.Request(f"{base_url}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=3) as resp:  # nosec B310 — user-provided Ollama URL
                if resp.status == 200:
                    prompter.info("Ollama detected and responding.")
                else:
                    prompter.info(f"Ollama responded with status {resp.status}")
        except Exception:
            if not prompter.confirm(
                "Could not connect to Ollama. Save config anyway?", default=False
            ):
                return ProviderSetupResult(
                    success=False, message="Ollama not reachable"
                )

        credentials = [
            ProviderCredential(
                key="base_url", value=base_url, env_var="OLLAMA_BASE_URL"
            ),
        ]

        return ProviderSetupResult(
            success=True,
            credentials=credentials,
            message=f"Ollama configured at {base_url}",
        )
