# ruff: noqa: E402
"""The agentic loop — heart of Memex.

Each human turn:
1. GET INPUT
2. CLASSIFY (LLM #1)
3. FILTER GOALS (heuristic)
3.5 SELECT TOOLS (Phase 2)
3.7 RETRIEVE KNOWLEDGE (Phase 3)
4. BUILD PROMPT
5. CALL LLM (#2)
6. RECORD TURNS
6.5 TOOL-USE LOOP (Phase 2, max 3 iterations)
7. WINDOW HISTORY
8. REFLECT (LLM #3)
9. DISPLAY
10. CHECK PROACTIVE
"""

from __future__ import annotations

import concurrent.futures
import logging
import os
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from memex.governance import load_identity
from memex.message_builder import MessageBuilder
from memex.prompt_budget import (
    DEFAULT_PROMPT_BUDGET,
    PromptBudgetSection,
    PromptMode,
    budget_prompt_context,
    filter_sections_for_mode,
    load_prompt_budget_config,
)
from memex.world_model_backbone import (
    build_world_model_decision_outcome_action,
    build_world_model_provenance_link,
    build_world_model_response_observation,
    build_world_model_turn_event,
    build_world_model_tool_action,
    build_world_model_tool_observation,
)
from memex.utcnow import utcnow

# Session-scoped MessageBuilder instances, keyed by session_id.
# Persists across turns within a session so cache state accumulates.
# Bounded: only the most recent session's builder is kept.
_builders: dict[str, MessageBuilder] = {}
_builders_lock = threading.Lock()
_MAX_BUILDERS = 5  # 1 main + 3 sub-agents + 1 handoff
from memex.models import (
    AuditEntry,
    ConnectorHealth,
    Goal,
    GoalStatus,
    IntentFrame,
    InputClassificationType,
    IntentActionCandidate,
    IntentFramePath,
    PromptControlPlanSnapshot,
    PromptControlPlanStepSnapshot,
    SessionContext,
    ToolResult,
    TurnCancelled,
    TurnEvent,
    WorldModelExecutionRecord,
    WorldModelPlanStepTransition,
)
from memex.security import check_capability, scan_for_injection, wrap_external
from memex.session import create_session
from memex.store import MemexStore
from memex.tools import ToolRegistry

logger = logging.getLogger(__name__)

MAX_TOOL_ITERATIONS = 8
MAX_TOOL_CALLS_PER_RESPONSE = 10


def _should_auto_retrieve_for_turn(
    classification: Any,
    *,
    prompt_control_artifact: Any | None,
    intent_frame: Any | None,
) -> bool:
    """Decide whether canonical retrieval should run for this turn."""
    if intent_frame is not None and getattr(intent_frame, "selected_path", None) in (
        IntentFramePath.CLARIFY,
        IntentFramePath.ABSTAIN,
    ):
        return False

    if classification.classification == InputClassificationType.KNOWLEDGE_QUERY:
        return True

    if prompt_control_artifact is None:
        return False

    memory_policy = getattr(prompt_control_artifact, "memory_policy", "")
    return memory_policy not in {"no_memory_by_default", "user_requested_only"}


def _build_selected_action_payload(
    *,
    decision_name: str,
    status: str,
    classification: str,
    intent_frame: IntentFrame,
    prompt_control_artifact: Any | None,
) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    slot_states = [slot.model_dump() for slot in intent_frame.slot_states]
    required_slots = [slot["name"] for slot in slot_states if slot.get("required")]
    unresolved_required_slots = [
        slot["name"]
        for slot in slot_states
        if slot.get("required") and slot.get("status") != "resolved"
    ]

    def add_candidate(
        name: str,
        *,
        kind: str = "response_path",
        selected: bool = False,
        rationale: str | None = None,
        tool_candidates: list[str] | None = None,
        required_slots_override: list[str] | None = None,
        unresolved_required_slots_override: list[str] | None = None,
    ) -> None:
        if name in seen:
            return
        seen.add(name)
        candidate = IntentActionCandidate(
            name=name,
            kind=kind,
            selected=selected,
            rationale=rationale,
            tool_candidates=list(tool_candidates or []),
            required_slots=list(required_slots_override or []),
            unresolved_required_slots=list(unresolved_required_slots_override or []),
        )
        candidates.append(candidate.model_dump(exclude_none=True))

    selected_candidate = _resolve_selected_action_candidate(
        intent_frame=intent_frame,
        prompt_control_artifact=prompt_control_artifact,
    )

    add_candidate(
        selected_candidate.name,
        kind=selected_candidate.kind,
        selected=True,
        rationale=selected_candidate.rationale or intent_frame.rationale,
        tool_candidates=selected_candidate.tool_candidates,
        required_slots_override=selected_candidate.required_slots,
        unresolved_required_slots_override=selected_candidate.unresolved_required_slots,
    )
    if selected_candidate.name != IntentFramePath.DIRECT_ANSWER.value:
        add_candidate(
            "direct_answer", rationale="answer directly without tool execution"
        )
    if (
        selected_candidate.name != IntentFramePath.CLARIFY.value
        and unresolved_required_slots
    ):
        add_candidate(
            "clarify",
            rationale="request the remaining required information before acting",
            required_slots_override=required_slots,
            unresolved_required_slots_override=unresolved_required_slots,
        )
    if (
        prompt_control_artifact is not None
        and prompt_control_artifact.tool_candidate_names
        and selected_candidate.name != IntentFramePath.ACT.value
    ):
        add_candidate(
            "act",
            kind="tool_path",
            rationale="tool execution remained available under the active route policy",
            tool_candidates=list(prompt_control_artifact.tool_candidate_names),
        )
    if selected_candidate.name != IntentFramePath.ABSTAIN.value and (
        classification == InputClassificationType.CONVERSATIONAL.value
        or intent_frame.confidence < 0.6
    ):
        add_candidate(
            "abstain",
            rationale="decline action when confidence or context is insufficient",
        )

    return {
        "selected_path": selected_candidate.name,
        "classification": classification,
        "selected_action": {
            "name": selected_candidate.name,
            "kind": selected_candidate.kind,
            "selected": True,
            "status": status,
            "rationale": selected_candidate.rationale or intent_frame.rationale,
            "confidence": intent_frame.confidence,
            "required_slots": list(selected_candidate.required_slots),
            "unresolved_required_slots": list(
                selected_candidate.unresolved_required_slots
            ),
        },
        "action_candidates": candidates,
        "unresolved_references": list(intent_frame.unresolved_references),
        "missing_information": list(intent_frame.missing_information),
        "slot_states": slot_states,
        "route_profile": (
            prompt_control_artifact.route_profile.value
            if prompt_control_artifact is not None
            else ""
        ),
        "tool_policy": (
            prompt_control_artifact.tool_policy
            if prompt_control_artifact is not None
            else ""
        ),
        "validation_policy": (
            prompt_control_artifact.validation_policy
            if prompt_control_artifact is not None
            else ""
        ),
        "memory_policy": (
            prompt_control_artifact.memory_policy
            if prompt_control_artifact is not None
            else ""
        ),
        "response_contract": (
            prompt_control_artifact.response_contract
            if prompt_control_artifact is not None
            else ""
        ),
    }


def _resolve_selected_action_candidate(
    *,
    intent_frame: IntentFrame,
    prompt_control_artifact: Any | None,
) -> IntentActionCandidate:
    required_slots = [slot.name for slot in intent_frame.slot_states if slot.required]
    unresolved_required_slots = [
        slot.name
        for slot in intent_frame.slot_states
        if slot.required and slot.status != "resolved"
    ]
    selected_candidate = intent_frame.selected_action_candidate
    if selected_candidate is None:
        selected_candidate = IntentActionCandidate(
            name=intent_frame.selected_path.value,
            kind="tool_path"
            if intent_frame.selected_path == IntentFramePath.ACT
            else "response_path",
            selected=True,
            rationale=intent_frame.rationale,
        )

    candidate = selected_candidate.model_copy(deep=True)
    candidate.selected = True
    if not candidate.rationale:
        candidate.rationale = intent_frame.rationale
    if not candidate.required_slots:
        candidate.required_slots = list(required_slots)
    if not candidate.unresolved_required_slots:
        candidate.unresolved_required_slots = list(unresolved_required_slots)
    if candidate.name == IntentFramePath.ACT.value:
        candidate.kind = "tool_path"
        if prompt_control_artifact is not None:
            candidate.tool_candidates = list(
                prompt_control_artifact.tool_candidate_names
            )
    else:
        candidate.kind = "response_path"
    return candidate


def _use_message_builder() -> bool:
    """Check if the MessageBuilder cache path is enabled via feature flag."""
    return os.environ.get("MEMEX_CACHE_ENABLED") == "1"


# Callback types for turn events
if TYPE_CHECKING:
    from collections.abc import Callable

    _EventCallback = Callable[[TurnEvent], None] | None
    _TokenCallback = Callable[[str], None] | None
else:
    _EventCallback = Any
    _TokenCallback = Any


# Patterns that signal the LLM intends to continue with more tool calls
# but didn't emit them in the same response.
_CONTINUATION_RE = re.compile(
    r"(?i)\b(?:let me (?:try|search|look|fetch|check|find|get|also)|"
    r"I(?:'ll| will) (?:also |now |next )?(?:try|search|look|fetch|check|find|get)|"
    r"now (?:let me|I'll)|"
    r"searching for|looking for|fetching)\b"
)


def _signals_continuation(text: str) -> bool:
    """Check if response text signals intent to do more work.

    Returns True if the last ~200 chars of the response contain
    continuation language, suggesting the LLM wanted to make more
    tool calls but didn't emit them.
    """
    # Only check the tail — continuation signals appear at the end
    tail = text[-200:] if len(text) > 200 else text
    return bool(_CONTINUATION_RE.search(tail))


def _emit(on_event: _EventCallback, event: TurnEvent) -> None:
    """Safely emit a turn event to the callback."""
    if on_event is not None:
        try:
            on_event(event)
        except TurnCancelled:
            raise
        except Exception:
            logger.debug(
                "on_event callback failed for %s", type(event).__name__, exc_info=True
            )


def _track_session_item(
    session: SessionContext, tool_name: str, args: dict, result: ToolResult
) -> None:
    """Record items touched by tools in session working_memory for context awareness."""
    items = session.working_memory.setdefault("session_items", [])

    if tool_name == "ingest_url":
        # Parse "Ingested: Title [id_prefix]\nType: type | Words: N"
        content = result.content
        title = ""
        item_id = ""
        item_type = ""

        first_line = content.split("\n", 1)[0]
        if "Ingested: " in first_line:
            rest = first_line.split("Ingested: ", 1)[1]
            # Extract [id_prefix] from end
            if "[" in rest and rest.rstrip().endswith("]"):
                bracket_start = rest.rindex("[")
                item_id = rest[bracket_start + 1 : -1]
                title = rest[:bracket_start].strip()

        second_line = content.split("\n")[1] if "\n" in content else ""
        if "Type: " in second_line:
            item_type = second_line.split("Type: ")[1].split(" |")[0].strip()

        if title:
            items.append(
                {
                    "id": item_id,
                    "title": title,
                    "type": item_type,
                    "action": "ingested",
                }
            )

    elif tool_name == "gmail_search":
        # Parse "Found N messages, ingested M:"
        first_line = result.content.split("\n", 1)[0]
        items.append(
            {
                "title": first_line,
                "type": "gmail",
                "action": "searched",
            }
        )

    # Cap session items to prevent unbounded growth
    if len(items) > 20:
        session.working_memory["session_items"] = items[-20:]


_DEFAULT_IDENTITY = (
    "You are Memex, a personal AI partner with persistent memory. "
    "You help the human track goals, think through problems, and make progress on what matters to them.\n"
    "\n"
    "Do NOT claim you lack persistent memory or that you start fresh each conversation. "
    "You are not a stateless chatbot — you are a persistent partner.\n"
    "\n"
    "## Your Capabilities\n"
    "\n"
    "### Knowledge & Memory\n"
    "- You have a persistent knowledge store (items, notes, articles, conversations, meetings). "
    "Information from conversations, tool results, and ingested content is stored and retrievable in future sessions.\n"
    "- Retrieval uses full-text search AND semantic (embedding) similarity. "
    "Items decay over time based on half-life; sources have reputation scores that affect ranking. Expired items are filtered out.\n"
    "- Items are automatically cross-linked by semantic similarity. "
    "Related items surface together during retrieval.\n"
    "- You understand natural language time expressions. Questions like "
    '"what was I working on last Tuesday?" or "goals from 3 days ago" '
    "trigger temporal search across conversations, goals, and items.\n"
    "\n"
    "### Conversation & Session\n"
    "- Conversation history is windowed at ~20 turns; older turns are automatically summarized so context is never fully lost.\n"
    "- Working memory (key-value context on the session) persists across turns within a session.\n"
    "- You maintain a persistent human model: name, timezone, communication style, preferences. "
    "If you don't know the user's name or timezone, ask.\n"
    "- Session modes: **normal** (balanced), **deep_work** (minimize interruptions), "
    "**review** (surface pending items), **quick_check** (terse status). "
    "You can suggest switching modes when appropriate.\n"
    "\n"
    "### Proactive Behavior\n"
    "- You detect approaching deadlines (next 24h), stale goals (untouched >14 days), and blocked goals. "
    'These surface as "Heads up:" messages appended to your responses.\n'
    "- You can create persistent, priority-sorted notifications (critical/high/normal/low) "
    "that appear in the user's attention panel.\n"
    "- Your self-improvement system observes behavioral patterns across sessions and surfaces insights as notifications.\n"
    "\n"
    "### Content Ingestion\n"
    "- Auto-ingest sources: watch folder (~/.memex/inbox/ for .txt/.md/.html/.json), RSS feeds, Gmail sent messages. "
    "Suggest these for passive knowledge capture.\n"
    "- Meeting support: audio capture and transcription via `memex meeting` CLI commands.\n"
    "\n"
    "### Governance\n"
    "- If CONSTITUTION.md or SOUL.md exist in the project root, their rules are loaded as highest-priority instructions. "
    "Suggest creating these if the user wants to set persistent behavioral rules."
)


def _build_identity_and_capabilities(project_root: Path | None = None) -> str:
    """Core identity and capabilities section for the system prompt.

    Loads IDENTITY.md from project root if it exists, otherwise falls back
    to the built-in default identity string.
    """
    external = load_identity(project_root)
    if external is not None:
        return external
    return _DEFAULT_IDENTITY


def _build_interface_context(
    caller: Any | None,
    connector_health: list[ConnectorHealth] | None,
) -> str:
    """Build a system prompt section describing the current interface and active services."""
    lines: list[str] = ["## Your Interfaces and Capabilities"]

    if caller is not None:
        interface_names = {
            "cli": "command-line interface (CLI)",
            "telegram": "Telegram messenger",
            "tui": "text user interface (TUI dashboard)",
            "mcp": "MCP protocol (external agent)",
        }
        iface_name = interface_names.get(caller.interface, caller.interface)
        lines.append(f"- This message arrived via: **{iface_name}**")

    # Describe active services based on what's configured
    # Telegram — check if config is available (bot is running or could run)
    try:
        from memex.interfaces.telegram import config_from_env

        tg_config = config_from_env()
        if tg_config is not None:
            lines.append(
                "- You have an integrated Telegram bot that receives messages from the user. "
                "Messages sent to your Telegram bot are processed through the same conversational loop."
            )
            if caller and caller.interface == "telegram":
                lines.append(
                    "- Telegram Bot API does not support re-fetching previous message history. "
                    "Use search_conversations to find past messages across all interfaces."
                )
    except Exception:
        pass

    # Connected tool connectors
    if connector_health:
        connected = [h for h in connector_health if h.status == "connected"]
        if connected:
            names = ", ".join(h.name for h in connected)
            lines.append(f"- Connected tool services: {names}")
            connected_names = {h.name for h in connected}
            # Describe each connector's capabilities
            if "claude_code" in connected_names:
                lines.append(
                    "- **Claude Code**: Delegate coding tasks to a separate Claude instance via tools "
                    "(claude_code_explain, claude_code_review, claude_code_write, claude_code_refactor, claude_code_debug). "
                    "Use these to read, analyze, write, or debug code on the user's machine. "
                    "When asked to inspect code, always follow through — call the tool, then summarize the findings."
                )
            if "filesystem" in connected_names:
                lines.append(
                    "- **Filesystem**: Read, write, edit, and search files on the user's machine. "
                    "Capability-gated: read operations always available, write operations require explicit grant.\n"
                    "  **Prefer `edit_file` over `write_file`** when modifying existing files. "
                    "`edit_file` sends only the changed portion (old_text → new_text), which is faster, "
                    "cheaper, and avoids response truncation on large files. "
                    "Reserve `write_file` for creating new files or complete rewrites of small files.\n"
                    "  **For large file operations** (merging multiple files, consolidating tables, "
                    "reformatting long documents), use the `file_transform` tool instead. "
                    "It reads files and writes output server-side via a dedicated LLM call, "
                    "keeping large content out of this conversation."
                )

    if len(lines) <= 1:
        return ""
    return "\n".join(lines)


def _prompt_plan_for_goal(store: MemexStore, goal_id: str) -> tuple[Any, Any | None]:
    plans = store.list_world_model_action_plans(goal_id=goal_id, limit=10)
    plan = next(
        (
            candidate
            for candidate in plans
            if candidate.status not in {"done", "completed"}
        ),
        None,
    )
    if plan is None:
        return None, None
    step = (
        store.load_world_model_plan_step(plan.selected_step_id)
        if plan.selected_step_id
        else None
    )
    return plan, step


def _resolve_prompt_control_plan_snapshot(
    store: MemexStore,
    *,
    intent_goal_id: str | None,
    classified_goal_id: str | None,
    relevant_goals: list[Goal],
) -> PromptControlPlanSnapshot | None:
    preferred_goal_ids: list[str] = []
    for goal_id in (intent_goal_id, classified_goal_id):
        if goal_id and goal_id not in preferred_goal_ids:
            preferred_goal_ids.append(goal_id)
    for goal in relevant_goals:
        if goal.goal_id not in preferred_goal_ids:
            preferred_goal_ids.append(goal.goal_id)

    for goal_id in preferred_goal_ids:
        plan, step = _prompt_plan_for_goal(store, goal_id)
        if plan is None:
            continue
        selected_step = None
        if step is not None:
            selected_step = PromptControlPlanStepSnapshot(
                step_id=step.step_id,
                step_kind=step.step_kind,
                title=step.title,
                status=step.status,
                progress_pct=step.progress_pct,
                blocked_reason=step.blocked_reason,
            )
        return PromptControlPlanSnapshot(
            goal_id=plan.goal_id,
            plan_id=plan.plan_id,
            title=plan.title,
            status=plan.status,
            selected_step=selected_step,
        )
    return None


def _build_goal_section(
    goals: list[Goal],
) -> str:
    """Format active goals for inclusion in the system prompt."""
    if not goals:
        return ""
    section = "## Current Goals"
    for g in goals:
        status = f" [{g.status.value}]" if g.status != GoalStatus.ACTIVE else ""
        section += (
            f"\n- **{g.title}**{status} (id: {g.goal_id[:8]}, {g.priority.value})"
        )
        if g.description:
            section += f"\n  {g.description[:200]}"
    return section


def _render_world_model_prompt_context(
    store: MemexStore,
    session_id: str,
    *,
    action_limit: int = 3,
) -> str:
    actions = store.list_world_model_actions(session_id=session_id, limit=action_limit)
    if not actions:
        return ""

    observations = store.list_world_model_observations(
        session_id=session_id,
        limit=max(action_limit * 4, 12),
    )
    observations_by_action: dict[str, list[Any]] = {}
    for observation in observations:
        observations_by_action.setdefault(observation.action_id, []).append(observation)

    lines = ["## Recent Canonical Outcomes"]
    for action in actions[:action_limit]:
        turn_label = (
            action.conversation_turn_id
            if action.conversation_turn_id is not None
            else "-"
        )
        lines.append(
            f"- turn {turn_label} | {action.action_kind} {action.action_name} | {action.status}"
        )
        action_links = sorted(
            store.list_world_model_provenance_links(
                source_record_id=action.action_id,
                source_record_type="world_model_action",
            ),
            key=lambda link: (
                link.relationship,
                link.target_record_type,
                link.target_record_id,
            ),
        )
        for link in action_links:
            lines.append(
                f"  provenance {link.relationship} {link.target_record_type} | "
                f"{link.target_record_id}"
            )
        for observation in observations_by_action.get(action.action_id, [])[:2]:
            summary = observation.summary or "-"
            lines.append(
                f"  observed {observation.observation_kind} | {observation.status} | {summary}"
            )
            observation_links = sorted(
                store.list_world_model_provenance_links(
                    source_record_id=observation.observation_id,
                    source_record_type="world_model_observation",
                ),
                key=lambda link: (
                    link.relationship,
                    link.target_record_type,
                    link.target_record_id,
                ),
            )
            for link in observation_links:
                lines.append(
                    f"    provenance {link.relationship} {link.target_record_type} | "
                    f"{link.target_record_id}"
                )
    return "\n".join(lines)


def _build_system_prompt(
    stable_parts: list[str],
    dynamic_parts: list[str],
    operator_parts: list[str],
    retrieved_knowledge: str = "",
) -> str:
    """Assemble the system prompt from canonical runtime context and session state."""
    parts: list[str] = [*stable_parts, *dynamic_parts, *operator_parts]
    if retrieved_knowledge:
        parts.append(retrieved_knowledge)
    return "\n\n".join(parts)


def _render_session_items_context(session: SessionContext) -> str:
    session_items = session.working_memory.get("session_items")
    if not session_items:
        return ""
    lines = ["## Items in This Session"]
    for si in session_items[-10:]:
        id_part = f" [{si['id']}]" if si.get("id") else ""
        lines.append(
            f"- {si.get('title', 'untitled')}{id_part} "
            f"({si.get('type', '?')}, {si.get('action', '?')})"
        )
    return "\n".join(lines)


def _build_budgeted_prompt_context(
    *,
    governance: str,
    partner_prompt: str,
    agent_self_prompt: str,
    goals: list[Goal],
    session_summary: str,
    retrieved_knowledge: str,
    prompt_control_section: str,
    world_model_section: str,
    response_format: Any | None,
    session_mode: Any | None,
    caller: Any | None,
    connector_health: list[ConnectorHealth] | None,
    memory_block_text: str,
    documentation_text: str,
    prompt_build_extra: str,
    proactive_context: str,
    session_items_section: str,
    skill_block: str,
    project_root: Path | None = None,
    prompt_mode: PromptMode = PromptMode.FULL,
    settings: Any | None = None,
):
    interface_section = _build_interface_context(caller, connector_health)
    mode_prompt = ""
    if session_mode is not None:
        from memex.interfaces.formats import get_mode_prompt

        mode_prompt = get_mode_prompt(session_mode) or ""

    response_format_section = ""
    if response_format is not None:
        response_format_section = response_format.as_prompt_section() or ""

    stable_sections = [
        PromptBudgetSection("governance", governance, 600),
        PromptBudgetSection(
            "identity", _build_identity_and_capabilities(project_root), 240
        ),
        PromptBudgetSection("agent_self", agent_self_prompt, 160),
        PromptBudgetSection("partner", partner_prompt, 220),
        PromptBudgetSection("interface", interface_section, 220),
        PromptBudgetSection("mode", mode_prompt, 120),
        PromptBudgetSection("memory_block", memory_block_text, 250),
        PromptBudgetSection("documentation", documentation_text, 200),
    ]
    dynamic_sections = [
        PromptBudgetSection("prompt_control", prompt_control_section, 220),
        PromptBudgetSection("goals", _build_goal_section(goals), 220),
        PromptBudgetSection(
            "session_summary",
            f"## Earlier in this session\n{session_summary}" if session_summary else "",
            180,
        ),
        PromptBudgetSection("response_format", response_format_section, 150),
        PromptBudgetSection("middleware_extra", prompt_build_extra, 180),
        PromptBudgetSection("proactive_context", proactive_context, 160),
        PromptBudgetSection("skill_block", skill_block, 180),
        PromptBudgetSection("session_items", session_items_section, 160),
    ]
    operator_sections = [
        PromptBudgetSection("world_model", world_model_section, 180),
    ]

    stable_sections = filter_sections_for_mode(stable_sections, mode=prompt_mode)
    dynamic_sections = filter_sections_for_mode(dynamic_sections, mode=prompt_mode)
    operator_sections = filter_sections_for_mode(operator_sections, mode=prompt_mode)

    budget_config = load_prompt_budget_config(settings, base=DEFAULT_PROMPT_BUDGET)

    return budget_prompt_context(
        stable_sections=stable_sections,
        dynamic_sections=dynamic_sections,
        operator_sections=operator_sections,
        retrieval_text=retrieved_knowledge,
        config=budget_config,
    )


def _build_messages(
    system_prompt: str,
    session_history: list,
    user_input: str,
) -> list[dict[str, Any]]:
    """Build the messages list for the main LLM call."""
    messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]

    for turn in session_history:
        if turn.role in ("human", "assistant"):
            role = "user" if turn.role == "human" else "assistant"
            messages.append({"role": role, "content": turn.content})

    messages.append({"role": "user", "content": user_input})
    return messages


def _message_content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
        return "\n".join(parts)
    return str(content or "")


def _messages_char_count(messages: list[dict[str, Any]]) -> int:
    return sum(
        len(_message_content_to_text(message.get("content"))) for message in messages
    )


_URL_CAPTURE_PATTERN = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)
_FAST_URL_CAPTURE_WORD_THRESHOLD = 4


def _should_skip_sync_reflect_for_url_capture(
    user_input: str,
    caller: Any | None,
) -> bool:
    if caller is None or getattr(caller, "interface", "") != "telegram":
        return False
    if not _URL_CAPTURE_PATTERN.search(user_input):
        return False
    stripped = _URL_CAPTURE_PATTERN.sub(" ", user_input)
    residual_words = re.findall(r"\b[\w'-]+\b", stripped.lower())
    return len(residual_words) <= _FAST_URL_CAPTURE_WORD_THRESHOLD


def _record_turn_runtime_stats(
    session: SessionContext,
    *,
    turn_ordinal: int,
    used_cache: bool,
    phase_timings_ms: dict[str, int],
    prompt_metrics: dict[str, int],
    tool_call_count: int,
) -> None:
    stats = {
        "turn_ordinal": turn_ordinal,
        "used_cache": used_cache,
        "phase_timings_ms": dict(phase_timings_ms),
        "prompt_metrics": dict(prompt_metrics),
        "tool_call_count": tool_call_count,
    }
    session.working_memory["_turn_runtime_stats"] = stats
    recent = list(session.working_memory.get("_recent_turn_runtime_stats", []))
    recent.append(stats)
    session.working_memory["_recent_turn_runtime_stats"] = recent[-10:]


def _tool_result_summary(
    tool_name: str, result: ToolResult, arguments: dict[str, Any]
) -> str:
    """Generate a human-readable summary for a tool result."""
    if not result.success:
        return result.error or "failed"

    content = result.content

    if tool_name == "search_knowledge":
        # Count "### [" headers to determine result count
        count = content.count("### [")
        if count == 0:
            return "no results"
        return f"{count} result{'s' if count != 1 else ''}"

    if tool_name == "search_conversations":
        count = content.count("### [") + content.count("**[")
        if count == 0:
            return "no results"
        return f"{count} result{'s' if count != 1 else ''}"

    if tool_name == "gmail_search":
        # Content starts with "Found N messages, ingested M:"
        first_line = content.split("\n", 1)[0]
        return first_line if len(first_line) <= 80 else first_line[:77] + "..."

    if tool_name == "ingest_url":
        # Content: "Ingested: Title [id]\nType: ... | Words: ..."
        first_line = content.split("\n", 1)[0]
        # Strip the "Ingested: " prefix since the verb is already shown
        if first_line.startswith("Ingested: "):
            return first_line[10:]
        return first_line[:80]

    if tool_name == "web_fetch":
        # Show domain + char count
        first_line = content.split("\n", 1)[0]
        return first_line[:80] if first_line else "fetched"

    if tool_name == "list_goals":
        count = content.count("- [")
        if count == 0:
            return "no active goals"
        return f"{count} goal{'s' if count != 1 else ''}"

    if tool_name == "list_reminders":
        count = content.count("- ")
        if count == 0:
            return "no reminders"
        return f"{count} reminder{'s' if count != 1 else ''}"

    if tool_name == "remember":
        return "saved"

    if tool_name == "forget":
        first_line = content.split("\n", 1)[0]
        return first_line[:80]

    if tool_name == "get_item":
        first_line = content.split("\n", 1)[0]
        return first_line[:80]

    if tool_name == "cost_report":
        first_line = content.split("\n", 1)[0]
        return first_line[:80]

    # Fallback: first line or first 80 chars
    first_line = content.split("\n", 1)[0] if content else "ok"
    return first_line[:80] if first_line else "ok"


def _persist_world_model_tool_execution(
    store: MemexStore,
    *,
    session_id: str,
    turn_ordinal: int,
    intent_id: str | None,
    goal_id: str | None,
    prompt_control_artifact_id: str | None,
    tool_call_id: str,
    tool_name: str,
    arguments: dict[str, Any],
    result: ToolResult,
) -> None:
    transition_spec = _extract_plan_step_transition_spec(result=result)
    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        store,
        goal_id=goal_id,
        transition_spec=transition_spec,
    )
    action = build_world_model_tool_action(
        session_id,
        conversation_turn_id=turn_ordinal,
        intent_id=intent_id,
        prompt_control_artifact_id=prompt_control_artifact_id,
        tool_call_id=tool_call_id,
        tool_name=tool_name,
        arguments=arguments,
        result=result,
    )
    observation = build_world_model_tool_observation(action, result)
    store.upsert_world_model_action(action)
    store.upsert_world_model_observation(observation)
    if intent_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "world_model_intent",
                intent_id,
                "selected_for_intent",
            )
        )
    if prompt_control_artifact_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "prompt_control_artifact",
                prompt_control_artifact_id,
                "governed_by",
            )
        )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_observation",
            observation.observation_id,
            "world_model_action",
            action.action_id,
            "observed_from",
        )
    )
    _persist_execution_planning_refs(
        store,
        source_record_type="world_model_action",
        source_record_id=action.action_id,
        goal_id=resolved_goal_id,
        result=result,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
    )
    _persist_canonical_execution_record(
        store,
        session_id=session_id,
        turn_ordinal=turn_ordinal,
        goal_id=resolved_goal_id,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
        source_record_type="world_model_action",
        source_record_id=action.action_id,
        execution_kind="tool_call",
        title=tool_name,
        summary=_execution_summary(result.content),
        status="succeeded" if result.success else "failed",
        payload={
            "tool_name": tool_name,
            "arguments": arguments,
            "result_metadata": dict(result.metadata),
        },
        source_surface="c08_execution_record",
        result=result,
        transition_spec=transition_spec,
    )


def _persist_world_model_decision_outcome(
    store: MemexStore,
    *,
    session_id: str,
    turn_ordinal: int,
    intent_id: str | None,
    goal_id: str | None,
    prompt_control_artifact_id: str | None,
    decision_name: str,
    status: str,
    response: str,
    payload: dict[str, Any] | None = None,
) -> None:
    transition_spec = _extract_plan_step_transition_spec(payload=payload)
    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        store,
        goal_id=goal_id,
        transition_spec=transition_spec,
    )
    action = build_world_model_decision_outcome_action(
        session_id,
        conversation_turn_id=turn_ordinal,
        intent_id=intent_id,
        prompt_control_artifact_id=prompt_control_artifact_id,
        decision_name=decision_name,
        status=status,
        payload=payload,
    )
    observation = build_world_model_response_observation(
        action,
        response,
        payload={"decision_name": decision_name, **(payload or {})},
    )
    store.upsert_world_model_action(action)
    store.upsert_world_model_observation(observation)
    if intent_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "world_model_intent",
                intent_id,
                "selected_for_intent",
            )
        )
    if prompt_control_artifact_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                action.action_id,
                "prompt_control_artifact",
                prompt_control_artifact_id,
                "governed_by",
            )
        )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_observation",
            observation.observation_id,
            "world_model_action",
            action.action_id,
            "observed_from",
        )
    )
    _persist_execution_planning_refs(
        store,
        source_record_type="world_model_action",
        source_record_id=action.action_id,
        goal_id=resolved_goal_id,
        result=None,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
    )
    _persist_canonical_execution_record(
        store,
        session_id=session_id,
        turn_ordinal=turn_ordinal,
        goal_id=resolved_goal_id,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
        source_record_type="world_model_action",
        source_record_id=action.action_id,
        execution_kind="decision_outcome",
        title=decision_name,
        summary=_execution_summary(response),
        status=status,
        payload=dict(payload or {}),
        source_surface="c08_execution_record",
        transition_spec=transition_spec,
    )


def _persist_world_model_turn_event(
    store: MemexStore,
    *,
    session_id: str,
    turn_ordinal: int,
    intent_id: str | None,
    goal_id: str | None,
    prompt_control_artifact_id: str | None,
    title: str,
    summary: str,
    payload: dict[str, Any] | None = None,
    planning_refs: list[dict[str, str]] | None = None,
) -> None:
    transition_spec = _extract_plan_step_transition_spec(payload=payload)
    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        store,
        goal_id=goal_id,
        transition_spec=transition_spec,
    )
    event = build_world_model_turn_event(
        session_id,
        conversation_turn_id=turn_ordinal,
        title=title,
        summary=summary,
        payload=payload,
    )
    store.upsert_world_model_event(event)
    if intent_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_event",
                event.event_id,
                "world_model_intent",
                intent_id,
                "selected_for_intent",
            )
        )
    if prompt_control_artifact_id:
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_event",
                event.event_id,
                "prompt_control_artifact",
                prompt_control_artifact_id,
                "governed_by",
            )
        )
    _persist_execution_planning_refs(
        store,
        source_record_type="world_model_event",
        source_record_id=event.event_id,
        goal_id=resolved_goal_id,
        result=None,
        planning_refs=planning_refs,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
    )
    _persist_canonical_execution_record(
        store,
        session_id=session_id,
        turn_ordinal=turn_ordinal,
        goal_id=resolved_goal_id,
        plan_id=resolved_plan_id,
        step_id=resolved_step_id,
        source_record_type="world_model_event",
        source_record_id=event.event_id,
        execution_kind="turn_event",
        title=title,
        summary=summary,
        status=event.event_kind,
        payload=dict(payload or {}),
        source_surface="c08_execution_record",
        planning_refs=planning_refs,
        transition_spec=transition_spec,
    )


def _persist_execution_planning_refs(
    store: MemexStore,
    *,
    source_record_type: str,
    source_record_id: str,
    goal_id: str | None,
    result: ToolResult | None,
    planning_refs: list[dict[str, str]] | None = None,
    plan_id: str | None = None,
    step_id: str | None = None,
) -> None:
    seen: set[tuple[str, str, str]] = set()

    def add_ref(relationship: str, record_type: str, record_id: str) -> None:
        relationship = str(relationship or "").strip()
        record_type = str(record_type or "").strip()
        record_id = str(record_id or "").strip()
        if not relationship or not record_type or not record_id:
            return
        key = (relationship, record_type, record_id)
        if key in seen:
            return
        seen.add(key)
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                source_record_type,
                source_record_id,
                record_type,
                record_id,
                relationship,
            )
        )

    if goal_id:
        add_ref("for_goal", "world_model_goal", goal_id)
    _, resolved_plan_id, resolved_step_id = _resolve_goal_plan_step_context(
        store,
        goal_id=goal_id,
        plan_id=plan_id,
        step_id=step_id,
    )
    if resolved_plan_id:
        add_ref("for_plan", "world_model_action_plan", resolved_plan_id)
    if resolved_step_id:
        add_ref("executes_step", "world_model_plan_step", resolved_step_id)

    metadata_refs = _extract_world_model_refs(result)
    extra_refs = planning_refs or []
    for ref in [*metadata_refs, *extra_refs]:
        add_ref(
            str(ref.get("relationship") or ""),
            str(ref.get("record_type") or ""),
            str(ref.get("record_id") or ""),
        )


def _extract_world_model_refs(result: ToolResult | None) -> list[dict[str, str]]:
    if result is None or not isinstance(result.metadata, dict):
        return []
    candidate_refs = result.metadata.get("world_model_refs")
    if not isinstance(candidate_refs, list):
        return []
    return [ref for ref in candidate_refs if isinstance(ref, dict)]


def _extract_plan_step_transition_spec(
    *,
    result: ToolResult | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if result is not None and isinstance(result.metadata, dict):
        candidate = result.metadata.get("plan_step_transition")
        if isinstance(candidate, dict):
            return dict(candidate)
    if isinstance(payload, dict):
        candidate = payload.get("plan_step_transition")
        if isinstance(candidate, dict):
            return dict(candidate)
    return None


def _resolve_execution_authority(
    store: MemexStore,
    *,
    goal_id: str | None,
    transition_spec: dict[str, Any] | None,
) -> tuple[str | None, str | None, str | None]:
    explicit_goal_id: str | None = None
    explicit_plan_id: str | None = None
    explicit_step_id: str | None = None
    if isinstance(transition_spec, dict):
        explicit_goal_id = str(transition_spec.get("goal_id") or "").strip() or None
        explicit_plan_id = str(transition_spec.get("plan_id") or "").strip() or None
        explicit_step_id = str(transition_spec.get("step_id") or "").strip() or None

    return _resolve_goal_plan_step_context(
        store,
        goal_id=explicit_goal_id or goal_id,
        plan_id=explicit_plan_id,
        step_id=explicit_step_id,
    )


def _resolve_goal_plan_step_context(
    store: MemexStore,
    *,
    goal_id: str | None,
    plan_id: str | None = None,
    step_id: str | None = None,
) -> tuple[str | None, str | None, str | None]:
    resolved_goal_id = str(goal_id or "").strip() or None
    resolved_plan_id = str(plan_id or "").strip() or None
    resolved_step_id = str(step_id or "").strip() or None

    if resolved_step_id:
        step = store.load_world_model_plan_step(resolved_step_id)
        if step is not None:
            resolved_plan_id = step.plan_id
            if step.goal_id:
                resolved_goal_id = step.goal_id

    if resolved_plan_id:
        plan = store.load_world_model_action_plan(resolved_plan_id)
        if plan is not None:
            if resolved_goal_id is None and plan.goal_id:
                resolved_goal_id = plan.goal_id
            if resolved_step_id is None and plan.selected_step_id:
                resolved_step_id = plan.selected_step_id

    if resolved_goal_id and (resolved_plan_id is None or resolved_step_id is None):
        active_plans = store.list_world_model_action_plans(
            goal_id=resolved_goal_id,
            status="active",
            limit=1,
        )
        if active_plans:
            active_plan = active_plans[0]
            if resolved_plan_id is None:
                resolved_plan_id = active_plan.plan_id
            if resolved_step_id is None:
                resolved_step_id = active_plan.selected_step_id

    return resolved_goal_id, resolved_plan_id, resolved_step_id


def _execution_summary(text: str) -> str:
    summary = str(text or "").strip().split("\n", 1)[0]
    return summary[:160]


def _build_plan_step_transition(
    store: MemexStore,
    *,
    execution_id: str,
    goal_id: str | None,
    plan_id: str | None,
    step_id: str | None,
    transition_spec: dict[str, Any] | None,
    source_surface: str,
    now: datetime,
) -> WorldModelPlanStepTransition | None:
    if not transition_spec or not plan_id or not step_id:
        return None
    step = store.load_world_model_plan_step(step_id)
    transition_kind = (
        str(transition_spec.get("transition_kind") or "").strip() or "progress_update"
    )
    transition_id = (
        str(transition_spec.get("transition_id") or "").strip()
        or f"{execution_id}:{transition_kind}:{step_id}"
    )
    to_status_value = transition_spec.get("to_status", transition_spec.get("status"))
    to_status = str(to_status_value).strip() if to_status_value is not None else None
    if to_status is None:
        if transition_kind == "blocked":
            to_status = "blocked"
        elif transition_kind in {"done", "completed"}:
            to_status = "done"
        elif transition_kind in {"started", "progress_update"}:
            to_status = "in_progress"
    blocked_reason = None
    if "blocked_reason" in transition_spec:
        blocked_reason = str(transition_spec.get("blocked_reason") or "")
    blocked_by_step_ids = None
    if "blocked_by_step_ids" in transition_spec:
        raw_step_ids = transition_spec.get("blocked_by_step_ids")
        if isinstance(raw_step_ids, list):
            blocked_by_step_ids = [
                str(value).strip() for value in raw_step_ids if str(value).strip()
            ]
        else:
            blocked_by_step_ids = []
    progress_pct: int | None = None
    if "progress_pct" in transition_spec:
        try:
            progress_pct = int(transition_spec.get("progress_pct"))
        except (TypeError, ValueError):
            progress_pct = None
    if progress_pct is None and to_status in {"done", "completed"}:
        progress_pct = 100
    if progress_pct is not None:
        progress_pct = max(0, min(100, progress_pct))
    return WorldModelPlanStepTransition(
        transition_id=transition_id,
        step_id=step_id,
        plan_id=plan_id,
        goal_id=goal_id,
        execution_id=execution_id,
        transition_kind=transition_kind,
        from_status=step.status if step is not None else None,
        to_status=to_status,
        blocked_reason=blocked_reason,
        blocked_by_step_ids=blocked_by_step_ids,
        progress_pct=progress_pct,
        summary=str(transition_spec.get("summary") or "").strip(),
        payload=dict(transition_spec),
        source_surface=source_surface,
        created_at=now,
        updated_at=now,
    )


def _persist_canonical_execution_record(
    store: MemexStore,
    *,
    session_id: str,
    turn_ordinal: int,
    goal_id: str | None,
    plan_id: str | None,
    step_id: str | None,
    source_record_type: str,
    source_record_id: str,
    execution_kind: str,
    title: str,
    summary: str,
    status: str,
    payload: dict[str, Any],
    source_surface: str,
    result: ToolResult | None = None,
    planning_refs: list[dict[str, str]] | None = None,
    transition_spec: dict[str, Any] | None = None,
) -> None:
    now = utcnow()
    execution_id = f"{source_record_type}:{source_record_id}"
    record = WorldModelExecutionRecord(
        execution_id=execution_id,
        session_id=session_id,
        conversation_turn_id=turn_ordinal,
        goal_id=goal_id,
        plan_id=plan_id,
        step_id=step_id,
        execution_kind=execution_kind,
        title=title,
        summary=summary,
        status=status,
        source_record_type=source_record_type,
        source_record_id=source_record_id,
        payload=payload,
        source_surface=source_surface,
        created_at=now,
        updated_at=now,
    )
    store.upsert_world_model_execution_record(record)
    _persist_execution_planning_refs(
        store,
        source_record_type="world_model_execution_record",
        source_record_id=record.execution_id,
        goal_id=goal_id,
        result=result,
        planning_refs=planning_refs,
        plan_id=plan_id,
        step_id=step_id,
    )
    transition = _build_plan_step_transition(
        store,
        execution_id=execution_id,
        goal_id=goal_id,
        plan_id=plan_id,
        step_id=step_id,
        transition_spec=transition_spec,
        source_surface=source_surface,
        now=now,
    )
    if transition is not None:
        store.append_world_model_plan_step_transition(transition)
        # Promote unblocked dependent steps after a step completes.
        if transition.to_status in {"done", "completed"} and plan_id and step_id:
            _promote_unblocked_dependent_step(
                store,
                plan_id=plan_id,
                completed_step_id=step_id,
                updated_at=now,
            )


def _promote_unblocked_dependent_step(
    store: MemexStore,
    *,
    plan_id: str,
    completed_step_id: str,
    updated_at: datetime,
) -> None:
    """After a step completes, unblock dependents and advance selected_step_id."""
    plan = store.load_world_model_action_plan(plan_id)
    if plan is None:
        return
    steps = store.list_world_model_plan_steps(plan_id=plan_id, limit=1000)
    if not steps:
        return
    done_ids = {s.step_id for s in steps if s.status in {"done", "completed"}}

    # Unblock dependent steps whose blocking dependencies are now satisfied.
    for s in steps:
        if s.status != "blocked":
            continue
        required = {
            sid.strip()
            for sid in [*s.depends_on_step_ids, *s.blocked_by_step_ids]
            if sid.strip()
        }
        if completed_step_id not in required:
            continue
        if not required.issubset(done_ids):
            continue
        store.upsert_world_model_plan_step(
            s.model_copy(
                update={
                    "status": "active",
                    "blocked_reason": "",
                    "blocked_by_step_ids": [],
                    "updated_at": updated_at,
                }
            )
        )

    # Re-read steps and refresh plan selected_step_id.
    steps = store.list_world_model_plan_steps(plan_id=plan_id, limit=1000)
    incomplete = [s for s in steps if s.status not in {"done", "completed"}]

    if not incomplete:
        store.upsert_world_model_action_plan(
            plan.model_copy(
                update={
                    "status": "done",
                    "selected_step_id": None,
                    "updated_at": updated_at,
                }
            )
        )
        return

    # Prefer in_progress > active > blocked, ordered by ordinal.
    sorted_steps = sorted(incomplete, key=lambda s: s.ordinal)
    selected = next(
        (s.step_id for s in sorted_steps if s.status == "in_progress"), None
    )
    if selected is None:
        selected = next((s.step_id for s in sorted_steps if s.status == "active"), None)
    if selected is None:
        selected = sorted_steps[0].step_id

    plan_status = "active"
    if selected and all(s.status == "blocked" for s in incomplete):
        plan_status = "blocked"

    store.upsert_world_model_action_plan(
        plan.model_copy(
            update={
                "status": plan_status,
                "selected_step_id": selected,
                "updated_at": updated_at,
            }
        )
    )


def _execute_tool_call(
    tool_name: str,
    arguments: dict[str, Any],
    registry: ToolRegistry,
    granted: set[str],
    store: MemexStore,
    connector_clients: dict[str, Any],
    session_id: str | None = None,
    caller: Any | None = None,
) -> ToolResult:
    """Execute a single tool call with security gate and audit."""
    tool_def = registry.get_tool(tool_name)
    if not tool_def:
        return ToolResult(
            tool_name=tool_name,
            success=False,
            content="",
            error=f"Unknown tool: {tool_name}",
            source="unknown",
            duration_ms=0,
        )

    # Execution gate
    if not check_capability(tool_def.required_capability, granted):
        store.log_audit(
            AuditEntry(
                timestamp=utcnow(),
                connector=tool_def.source,
                action=tool_name,
                capability_required=tool_def.required_capability,
                granted=False,
                session_id=session_id,
            )
        )
        return ToolResult(
            tool_name=tool_name,
            success=False,
            content="",
            error=f"Capability denied: {tool_def.required_capability}",
            source=tool_def.source,
            duration_ms=0,
        )

    # Execute via connector
    start = time.monotonic()
    try:
        if tool_def.source.startswith("mcp:"):
            from memex.connectors.mcp_client import run_async

            connector_name = tool_def.source.split(":", 1)[1]
            client = connector_clients.get(connector_name)
            if client:
                result = run_async(client.call_tool(tool_def.name, arguments))
            else:
                result = ToolResult(
                    tool_name=tool_name,
                    success=False,
                    content="",
                    error=f"No client for connector: {connector_name}",
                    source=tool_def.source,
                    duration_ms=int((time.monotonic() - start) * 1000),
                )
        elif tool_def.source.startswith("claude_code:"):
            integration = connector_clients.get("claude_code_integration")
            if integration:
                result = integration.execute_tool(tool_def.name, arguments)
            else:
                result = ToolResult(
                    tool_name=tool_name,
                    success=False,
                    content="",
                    error="No Claude Code client configured",
                    source=tool_def.source,
                    duration_ms=int((time.monotonic() - start) * 1000),
                )
        elif tool_def.source == "builtin":
            from memex.tools_builtin import execute_builtin

            result = execute_builtin(tool_def.name, arguments, caller=caller)
        else:
            result = ToolResult(
                tool_name=tool_name,
                success=False,
                content="",
                error=f"Unsupported source: {tool_def.source}",
                source=tool_def.source,
                duration_ms=int((time.monotonic() - start) * 1000),
            )
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        result = ToolResult(
            tool_name=tool_name,
            success=False,
            content="",
            error=str(exc),
            source=tool_def.source,
            duration_ms=elapsed,
        )

    # Audit
    store.log_audit(
        AuditEntry(
            timestamp=utcnow(),
            connector=tool_def.source,
            action=tool_name,
            capability_required=tool_def.required_capability,
            granted=True,
            session_id=session_id,
            result_summary="ok" if result.success else (result.error or "failed"),
            duration_ms=result.duration_ms,
        )
    )

    # Boundary tagging & injection scan
    if result.success and result.content:
        injections = scan_for_injection(result.content)
        if injections:
            logger.warning("Injection patterns in %s result: %s", tool_name, injections)
        result = result.model_copy(
            update={
                "content": wrap_external(result.content, tool_def.source),
                "boundary_tagged": True,
            }
        )

    return result


def _connect_mcp(
    name: str,
    command: str,
    capability_prefix: str,
    timeout: float,
    store: MemexStore,
    registry: ToolRegistry,
    connector_clients: dict[str, Any],
    health_list: list[ConnectorHealth],
    runtime_registry: Any | None = None,
) -> None:
    """Connect a single MCP connector. Mutates registry, connector_clients, health_list."""
    from memex.connectors.mcp_client import MCPClient, MCPClientConfig, run_async

    client = MCPClient(
        MCPClientConfig(
            name=name,
            command=command,
            timeout_seconds=timeout,
            capability_prefix=capability_prefix,
        )
    )
    try:
        health = run_async(client.connect())

        if not client.available:
            health_list.append(health)
            store.save_connector_health(health)
            if runtime_registry is not None:
                runtime_registry.set_connector_state(
                    name,
                    status=health.status,
                    tools_discovered=health.tools_discovered,
                    error=health.error or "",
                    last_check=health.last_check.isoformat(),
                    degraded=health.status != "connected",
                )
            return

        connector_clients[name] = client

        # Register discovered tools
        for td in client.discovered_tools:
            registry.register(td)

        # Only report "connected" after tools are successfully registered
        health_list.append(health)
        store.save_connector_health(health)
        if runtime_registry is not None:
            runtime_registry.set_connector_state(
                name,
                status=health.status,
                tools_discovered=health.tools_discovered,
                error=health.error or "",
                last_check=health.last_check.isoformat(),
                degraded=health.status != "connected",
            )
    except Exception:
        # Clean up the partially-connected client
        try:
            run_async(client.disconnect())
        except Exception:
            pass
        connector_clients.pop(name, None)
        raise


def startup_health_check(
    store: MemexStore,
    *,
    on_progress: Callable[[str], None] | None = None,
    runtime_registry: Any | None = None,
) -> tuple[ToolRegistry, list[ConnectorHealth], dict[str, Any]]:
    """Connect to configured connectors, discover tools, save health.

    Returns (registry, health_list, connector_clients). Never crashes.
    """

    def _report(msg: str) -> None:
        if on_progress is not None:
            on_progress(msg)

    registry = ToolRegistry()
    health_list: list[ConnectorHealth] = []
    connector_clients: dict[str, Any] = {}

    # Built-in tools (web_fetch, etc.)
    try:
        from memex.tools_builtin import BUILTIN_TOOLS

        for tool in BUILTIN_TOOLS:
            registry.register(tool)
        _report(f"  Registered {len(BUILTIN_TOOLS)} builtin tools")
    except Exception as exc:
        logger.warning("Failed to register builtin tools: %s", exc)

    # Claude Code — only attempt if explicitly enabled
    if os.environ.get("MEMEX_CLAUDE_CODE_ENABLED") == "1":
        _report("  Connecting Claude Code...")
        try:
            _connect_claude_code(
                store,
                registry,
                connector_clients,
                health_list,
                runtime_registry=runtime_registry,
            )
            _report("  [+] Claude Code connected")
        except Exception as exc:
            logger.warning("Claude Code connection failed: %s", exc)
            health_list.append(
                ConnectorHealth(
                    name="claude_code",
                    status="unavailable",
                    last_check=utcnow(),
                    error=str(exc),
                )
            )
            if runtime_registry is not None:
                runtime_registry.set_connector_state(
                    "claude_code",
                    status="unavailable",
                    error=str(exc),
                    last_check=utcnow().isoformat(),
                    degraded=True,
                )
            _report(f"  [-] Claude Code unavailable: {exc}")

    # Config-driven MCP servers (filesystem, ecosystem)
    _connect_configured_servers(
        store,
        registry,
        connector_clients,
        health_list,
        runtime_registry=runtime_registry,
    )

    # OpenClaw plugin bridge — connect if plugins are installed
    _connect_plugin_bridge(
        store,
        registry,
        connector_clients,
        health_list,
        _report,
        runtime_registry=runtime_registry,
    )

    return registry, health_list, connector_clients


def _connect_claude_code(
    store: MemexStore,
    registry: ToolRegistry,
    connector_clients: dict[str, Any],
    health_list: list[ConnectorHealth],
    runtime_registry: Any | None = None,
) -> None:
    """Connect Claude Code connector. Mutates registry, connector_clients, health_list."""
    from memex.connectors.claude_code import ClaudeCodeClient, ClaudeCodeConfig
    from memex.integrations.claude_code import ClaudeCodeIntegration

    config = ClaudeCodeConfig(
        claude_binary=os.environ.get("CLAUDE_CODE_BINARY", "claude"),
        default_max_turns=int(os.environ.get("MEMEX_CLAUDE_CODE_MAX_TURNS", "5")),
        default_timeout_seconds=float(
            os.environ.get("MEMEX_CLAUDE_CODE_TIMEOUT", "300")
        ),
        default_working_directory=os.environ.get("MEMEX_CLAUDE_CODE_CWD"),
        max_cost_per_call_usd=float(
            os.environ.get("MEMEX_CLAUDE_CODE_MAX_COST_CALL", "1.0")
        ),
        max_cost_per_session_usd=float(
            os.environ.get("MEMEX_CLAUDE_CODE_MAX_COST_SESSION", "10.0")
        ),
    )

    client = ClaudeCodeClient(config)
    health = client.health_check()
    health_list.append(health)
    store.save_connector_health(health)
    if runtime_registry is not None:
        runtime_registry.set_connector_state(
            "claude_code",
            status=health.status,
            tools_discovered=health.tools_discovered,
            error=health.error or "",
            last_check=health.last_check.isoformat(),
            degraded=health.status != "connected",
        )

    if health.status != "connected":
        return

    integration = ClaudeCodeIntegration(client)
    connector_clients["claude_code_integration"] = integration

    for td in integration.get_tool_definitions():
        registry.register(td)


def _connect_configured_servers(
    store: MemexStore,
    registry: ToolRegistry,
    connector_clients: dict[str, Any],
    health_list: list[ConnectorHealth],
    runtime_registry: Any | None = None,
) -> None:
    """Connect config-driven MCP servers. Never crashes."""
    from memex.mcp_servers import servers_config_from_env

    config = servers_config_from_env()

    for entry in config.servers:
        if not entry.enabled:
            continue
        # Skip servers already connected by hardcoded blocks (e.g. claude_code)
        if entry.name in connector_clients:
            continue
        try:
            _connect_mcp_server_entry(
                entry,
                store,
                registry,
                connector_clients,
                health_list,
                runtime_registry=runtime_registry,
            )
        except Exception as exc:
            logger.warning("MCP server '%s' connection failed: %s", entry.name, exc)
            health_list.append(
                ConnectorHealth(
                    name=entry.name,
                    status="unavailable",
                    last_check=utcnow(),
                    error=str(exc),
                )
            )
            if runtime_registry is not None:
                runtime_registry.set_connector_state(
                    entry.name,
                    status="unavailable",
                    error=str(exc),
                    last_check=utcnow().isoformat(),
                    degraded=True,
                )


def _connect_mcp_server_entry(
    entry: Any,
    store: MemexStore,
    registry: ToolRegistry,
    connector_clients: dict[str, Any],
    health_list: list[ConnectorHealth],
    runtime_registry: Any | None = None,
) -> None:
    """Connect a single config-driven MCP server entry."""
    from memex.connectors.mcp_client import MCPClient, MCPClientConfig, run_async

    # Ensure the command's parent dir is on PATH so shebangs like
    # #!/usr/bin/env node resolve correctly (e.g. nvm-managed npx).
    server_env = dict(entry.env) if entry.env else None
    if os.path.isabs(entry.command):
        cmd_dir = str(Path(entry.command).parent)
        current_path = os.environ.get("PATH", "")
        if cmd_dir not in current_path.split(":"):
            server_env = server_env or {}
            server_env["PATH"] = f"{cmd_dir}:{current_path}"

    client = MCPClient(
        MCPClientConfig(
            name=entry.name,
            command=entry.command,
            args=entry.args,
            env=server_env,
            timeout_seconds=entry.timeout_seconds,
            capability_prefix=entry.capability_prefix,
        )
    )

    health = run_async(client.connect())

    if not client.available:
        health_list.append(health)
        store.save_connector_health(health)
        if runtime_registry is not None:
            runtime_registry.set_connector_state(
                entry.name,
                status=health.status,
                tools_discovered=health.tools_discovered,
                error=health.error or "",
                last_check=health.last_check.isoformat(),
                degraded=health.status != "connected",
            )
        return

    connector_clients[entry.name] = client

    # Use integration-specific tool registration if available
    if entry.integration == "filesystem":
        from memex.integrations.filesystem import FilesystemIntegration

        for td in FilesystemIntegration(
            client, write=entry.write
        ).get_tool_definitions():
            registry.register(td)
    else:
        # Generic: register discovered tools directly
        for td in client.discovered_tools:
            registry.register(td)

    health_list.append(health)
    store.save_connector_health(health)
    if runtime_registry is not None:
        runtime_registry.set_connector_state(
            entry.name,
            status=health.status,
            tools_discovered=health.tools_discovered,
            error=health.error or "",
            last_check=health.last_check.isoformat(),
            degraded=health.status != "connected",
        )
        runtime_registry.set_interface_state(
            entry.name.replace("-", "_"),
            enabled=True,
            running=health.status == "connected",
            status=health.status,
            owner="connector",
            last_error=health.error or "",
        )


def _connect_plugin_bridge(
    store: MemexStore,
    registry: ToolRegistry,
    connector_clients: dict[str, Any],
    health_list: list[ConnectorHealth],
    _report: Any = lambda msg: None,
    runtime_registry: Any | None = None,
) -> None:
    """Connect the OpenClaw bridge if plugins are installed. Never crashes."""
    try:
        from memex.plugins import get_plugin_registry

        plugin_registry = get_plugin_registry()
        plugins = plugin_registry.scan()
        if not plugins:
            return
        if runtime_registry is not None:
            runtime_registry.set_connector_state(
                "openclaw-bridge",
                status="configured",
                tools_discovered=0,
                degraded=True,
            )
            runtime_registry.set_interface_state(
                "openclaw_bridge",
                enabled=True,
                running=False,
                status="configured",
                owner="connector",
            )

        plugin_paths = plugin_registry.installed_paths()

        # Locate bridge entry point (env override or relative to package)
        bridge_dir_env = os.environ.get("MEMEX_OPENCLAW_BRIDGE_DIR")
        if bridge_dir_env:
            bridge_js = Path(bridge_dir_env) / "dist" / "index.js"
        else:
            project_root = Path(__file__).resolve().parent.parent.parent
            bridge_js = (
                project_root / "tools" / "openclaw-mcp-bridge" / "dist" / "index.js"
            )
        if not bridge_js.is_file():
            logger.info(
                "OpenClaw bridge not built (%s missing), skipping %d plugin(s)",
                bridge_js,
                len(plugins),
            )
            if runtime_registry is not None:
                runtime_registry.set_connector_state(
                    "openclaw-bridge",
                    status="unavailable",
                    tools_discovered=0,
                    error=f"bridge not built: {bridge_js}",
                    last_check=utcnow().isoformat(),
                    degraded=True,
                )
                runtime_registry.set_interface_state(
                    "openclaw_bridge",
                    enabled=True,
                    running=False,
                    status="unavailable",
                    owner="connector",
                    last_error=f"bridge not built: {bridge_js}",
                )
            return

        from memex.mcp_servers import MCPServerEntry

        entry = MCPServerEntry(
            name="openclaw-bridge",
            command="node",
            args=[str(bridge_js)] + plugin_paths,
            capability_prefix="openclaw",
            timeout_seconds=30.0,
        )

        _report(f"  Connecting OpenClaw bridge ({len(plugins)} plugin(s))...")
        _connect_mcp_server_entry(
            entry,
            store,
            registry,
            connector_clients,
            health_list,
            runtime_registry=runtime_registry,
        )

        if "openclaw-bridge" in connector_clients:
            for p in plugins:
                plugin_registry.mark_loaded(p.manifest.id)
            if runtime_registry is not None:
                client = connector_clients.get("openclaw-bridge")
                runtime_registry.set_connector_state(
                    "openclaw-bridge",
                    status="connected",
                    tools_discovered=len(getattr(client, "discovered_tools", []) or []),
                    error="",
                    last_check=utcnow().isoformat(),
                    degraded=False,
                )
                runtime_registry.set_interface_state(
                    "openclaw_bridge",
                    enabled=True,
                    running=True,
                    status="connected",
                    owner="connector",
                )
            _report(f"  [+] OpenClaw bridge: {len(plugins)} plugin(s) loaded")
        else:
            if runtime_registry is not None:
                runtime_registry.set_interface_state(
                    "openclaw_bridge",
                    enabled=True,
                    running=False,
                    status="unavailable",
                    owner="connector",
                    last_error="bridge failed to connect",
                )
            _report("  [-] OpenClaw bridge: failed to connect")
    except Exception as exc:
        logger.warning("OpenClaw plugin bridge failed: %s", exc)
        if runtime_registry is not None:
            runtime_registry.set_connector_state(
                "openclaw-bridge",
                status="error",
                tools_discovered=0,
                error=str(exc),
                last_check=utcnow().isoformat(),
                degraded=True,
            )
            runtime_registry.set_interface_state(
                "openclaw_bridge",
                enabled=True,
                running=False,
                status="error",
                owner="connector",
                last_error=str(exc),
            )


def _resolve_skill_dirs() -> list[Path]:
    """Return skill directories in precedence order (lowest first)."""
    dirs: list[Path] = []
    # Bundled skills (lowest precedence)
    bundled = Path(__file__).parent / "skills" / "bundled"
    if bundled.is_dir():
        dirs.append(bundled)
    # User-installed skills
    user_dir = Path.home() / ".memex" / "skills"
    if user_dir.is_dir():
        dirs.append(user_dir)
    # Workspace skills (highest precedence)
    workspace = Path.cwd() / "skills"
    if workspace.is_dir():
        dirs.append(workspace)
    # Extra dirs from env
    extra = os.environ.get("MEMEX_SKILLS_EXTRA_DIRS", "")
    for p in extra.split(":"):
        p = p.strip()
        if p:
            dirs.append(Path(p))
    return dirs


def _build_middleware_chain(
    registry: ToolRegistry | None = None,
    connector_clients: dict[str, Any] | None = None,
) -> Any:
    """Build the default middleware chain. Returns MiddlewareChain or None."""
    try:
        from memex.middleware import MiddlewareChain

        chain = MiddlewareChain([])
    except Exception:
        return None

    # Session summary middleware — generates LDB conversation summaries on session end
    try:
        from memex.session_summary import SessionSummaryMiddleware

        chain.add(SessionSummaryMiddleware())
    except Exception:
        logger.debug("Failed to add SessionSummaryMiddleware", exc_info=True)

    # Load skills into the chain
    try:
        from memex.skills.aliases import apply_openclaw_aliases
        from memex.skills.loader import SkillLoader
        from memex.skills.middleware import SkillMiddleware
        from memex.skills.registry import SkillRegistry

        if registry is not None:
            apply_openclaw_aliases(registry)

        skill_dirs = _resolve_skill_dirs()
        loader = SkillLoader(skill_dirs)
        skill_registry = SkillRegistry()
        for skill in loader.load_all():
            skill_registry.register(skill)
            logger.info("Loaded skill: %s (%s)", skill.name, skill.description)

        tool_reg = registry or ToolRegistry()
        skill_mw = SkillMiddleware(skill_registry, tool_reg)
        chain.add(skill_mw)
        chain.skill_middleware = skill_mw  # type: ignore[attr-defined]
    except Exception:
        logger.debug("Skill loading failed", exc_info=True)

    # OpenClaw bridge middleware — hooks dispatch to the Node.js bridge
    if connector_clients and "openclaw-bridge" in connector_clients:
        try:
            from memex.integrations.openclaw import OpenClawBridgeMiddleware

            bridge_client = connector_clients["openclaw-bridge"]
            chain.add(OpenClawBridgeMiddleware(mcp_client=bridge_client))
        except Exception:
            logger.debug("OpenClaw bridge middleware failed", exc_info=True)

    return chain


def run_turn(
    user_input: str,
    store: MemexStore,
    session: SessionContext | None = None,
    *,
    project_root: Path | None = None,
    tool_registry: ToolRegistry | None = None,
    connector_health: list[ConnectorHealth] | None = None,
    connector_clients: dict[str, Any] | None = None,
    content_store: Any | None = None,
    response_format: Any | None = None,
    session_mode: Any | None = None,
    caller: Any | None = None,
    middleware_chain: Any | None = None,
    on_event: _EventCallback = None,
    on_token: _TokenCallback = None,
    prompt_mode: PromptMode = PromptMode.FULL,
) -> tuple[str, SessionContext]:
    """Execute one turn of the agentic loop.

    Returns (assistant_response, session).

    Optional callbacks:
      on_event — called with TurnEvent subclasses at key processing points
      on_token — called with each text chunk during streaming LLM response
    """
    from memex.phase_graph.definition import build_memex_turn_graph
    from memex.phase_graph.executor import GraphExecutor

    now = utcnow()

    # Ensure session
    if session is None or not isinstance(session, SessionContext):
        session = create_session()

    # Middleware chain — build default if not provided
    chain = middleware_chain or _build_middleware_chain(
        registry=tool_registry,
        connector_clients=connector_clients,
    )

    # 0. MIDDLEWARE — transform input
    if chain is not None:
        try:
            user_input = chain.on_message_received(session, user_input)
        except Exception:
            logger.debug("Middleware on_message_received failed", exc_info=True)

    # Build TurnContext from arguments
    ctx: dict = {
        "user_input": user_input,
        "store": store,
        "session": session,
        "tool_registry": tool_registry,
        "middleware_chain": chain,
        "connector_health": connector_health or [],
        "connector_clients": connector_clients or {},
        "content_store": content_store,
        "now": now,
        "on_event": on_event,
        "on_token": on_token,
        "prompt_mode": prompt_mode,
        "project_root": project_root,
        "caller": caller,
        "response_format": response_format,
        "session_mode": session_mode,
    }

    # Build and execute graph
    graph = build_memex_turn_graph()
    executor = GraphExecutor(graph, ctx)
    ctx = executor.run_to_boundary("RETURN_RESPONSE")

    response = ctx["response"]
    session = ctx["session"]

    # Schedule post-response work (background or inline for tests)
    # NOTE: run_remaining() mutates ctx and session in the background thread.
    # Callers must not inspect the returned session until post-response work
    # completes (or use _SYNCHRONOUS_POST_RESPONSE=True in tests).
    # This matches the original run_turn() threading model.
    if _SYNCHRONOUS_POST_RESPONSE:
        executor.run_remaining()
    else:
        _fut = _POST_RESPONSE_POOL.submit(executor.run_remaining)
        with _POST_RESPONSE_FUTURES_LOCK:
            _POST_RESPONSE_FUTURES[:] = [
                f for f in _POST_RESPONSE_FUTURES if not f.done()
            ]
            _POST_RESPONSE_FUTURES.append(_fut)

    return response, session


# ---------------------------------------------------------------------------
# Post-response background work (extraction, reflection, persistence)
# ---------------------------------------------------------------------------

_POST_RESPONSE_POOL = concurrent.futures.ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix="post-response",
)
_POST_RESPONSE_FUTURES: list[concurrent.futures.Future] = []
_POST_RESPONSE_FUTURES_LOCK = threading.Lock()

# When True, post-response work runs synchronously instead of in the thread
# pool.  Set by test fixtures so assertions can observe the side-effects
# immediately after ``run_turn`` returns.
_SYNCHRONOUS_POST_RESPONSE = False


def drain_post_response_work(timeout: float = 30.0) -> None:
    """Wait for all pending post-response background futures to complete.

    Call this before closing the FathomDB engine to avoid 'engine is closed'
    errors from in-flight background work.
    """
    with _POST_RESPONSE_FUTURES_LOCK:
        futures = list(_POST_RESPONSE_FUTURES)
        _POST_RESPONSE_FUTURES.clear()
    if futures:
        concurrent.futures.wait(futures, timeout=timeout)
