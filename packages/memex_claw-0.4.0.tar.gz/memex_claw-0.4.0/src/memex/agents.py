"""Sub-agent manager — tracks state for concurrent lightweight agents.

The manager does NOT run agents. It tracks their lifecycle state.
The TUI (or other interface) spawns actual worker threads.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime

from memex.runtime_state import RuntimeStateRegistry
from memex.utcnow import utcnow


@dataclass
class SubAgent:
    """State for a single sub-agent."""

    agent_id: str  # short id like "qq-1"
    label: str  # truncated question
    session_id: str  # unique session for this agent
    status: str = "running"  # "running" | "done" | "error" | "cancelled"
    response: str | None = None
    started_at: datetime = field(default_factory=lambda: utcnow())
    finished_at: datetime | None = None
    cancel_event: threading.Event = field(default_factory=threading.Event)
    error: str | None = None

    @property
    def elapsed_ms(self) -> int:
        end = self.finished_at or utcnow()
        return int((end - self.started_at).total_seconds() * 1000)

    @property
    def elapsed_display(self) -> str:
        ms = self.elapsed_ms
        if ms < 1000:
            return f"{ms}ms"
        return f"{ms / 1000:.1f}s"


class SubAgentManager:
    """Thread-safe state tracker for concurrent sub-agents."""

    MAX_AGENTS = 3
    _CLEANUP_AGE_SECONDS = 300  # evict finished agents after 5 min

    def __init__(self, runtime_registry: RuntimeStateRegistry | None = None) -> None:
        self._agents: dict[str, SubAgent] = {}
        self._lock = threading.Lock()
        self._counter = 0
        self._runtime_registry = runtime_registry

    def _sync_runtime_state_locked(self) -> None:
        registry = self._runtime_registry
        if registry is not None:
            registry.sync_subagents(list(self._agents.values()))

    def spawn(self, question: str, session_id: str) -> SubAgent:
        """Create and register a new sub-agent. Raises RuntimeError if full."""
        with self._lock:
            self._cleanup_finished_locked()
            running = sum(1 for a in self._agents.values() if a.status == "running")
            if running >= self.MAX_AGENTS:
                raise RuntimeError(
                    f"Max {self.MAX_AGENTS} concurrent sub-agents. "
                    "Wait for one to finish or cancel with /qq kill <id>."
                )
            self._counter += 1
            agent_id = f"qq-{self._counter}"
            label = question[:60] + ("..." if len(question) > 60 else "")
            agent = SubAgent(
                agent_id=agent_id,
                label=label,
                session_id=session_id,
            )
            self._agents[agent_id] = agent
            self._sync_runtime_state_locked()
            return agent

    def complete(self, agent_id: str, response: str) -> None:
        """Mark an agent as done with its response."""
        with self._lock:
            agent = self._agents.get(agent_id)
            if agent and agent.status == "running":
                agent.status = "done"
                agent.response = response
                agent.finished_at = utcnow()
            self._sync_runtime_state_locked()

    def fail(self, agent_id: str, error: str) -> None:
        """Mark an agent as errored."""
        with self._lock:
            agent = self._agents.get(agent_id)
            if agent and agent.status == "running":
                agent.status = "error"
                agent.error = error
                agent.finished_at = utcnow()
            self._sync_runtime_state_locked()

    def cancel(self, agent_id: str) -> bool:
        """Cancel a running agent. Returns True if it was running."""
        with self._lock:
            agent = self._agents.get(agent_id)
            if agent and agent.status == "running":
                agent.cancel_event.set()
                agent.status = "cancelled"
                agent.finished_at = utcnow()
                self._sync_runtime_state_locked()
                return True
            self._sync_runtime_state_locked()
            return False

    def get(self, agent_id: str) -> SubAgent | None:
        with self._lock:
            return self._agents.get(agent_id)

    def list_agents(self) -> list[SubAgent]:
        with self._lock:
            return list(self._agents.values())

    @property
    def running_count(self) -> int:
        with self._lock:
            return sum(1 for a in self._agents.values() if a.status == "running")

    def _cleanup_finished_locked(self) -> None:
        """Evict finished agents older than _CLEANUP_AGE_SECONDS. Must hold _lock."""
        now = time.time()
        to_remove = []
        for aid, agent in self._agents.items():
            if agent.status in ("done", "error", "cancelled") and agent.finished_at:
                age = now - agent.finished_at.timestamp()
                if age > self._CLEANUP_AGE_SECONDS:
                    to_remove.append(aid)
        for aid in to_remove:
            del self._agents[aid]
        self._sync_runtime_state_locked()
