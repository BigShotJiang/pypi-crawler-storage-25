"""Config-driven MCP server connection — connect any server via YAML config.

Config file: MEMEX_MCP_SERVERS_CONFIG env var or default location.
Each server entry maps to an MCPClientConfig for stdio transport.
"""

from __future__ import annotations

import logging
from pathlib import Path
from pydantic import BaseModel, field_validator

logger = logging.getLogger(__name__)


_FS_PACKAGE = "@modelcontextprotocol/server-filesystem"


class MCPServerEntry(BaseModel):
    """One MCP server definition from config."""

    name: str
    transport: str = "stdio"
    command: str
    args: list[str] = []
    env: dict[str, str] | None = None
    capability_prefix: str = ""
    timeout_seconds: float = 30.0
    integration: str | None = None  # e.g. "filesystem"
    write: bool = False  # for filesystem integration: allow write tools
    enabled: bool = True

    @field_validator("transport")
    @classmethod
    def validate_transport(cls, v: str) -> str:
        if v != "stdio":
            raise ValueError(f"Only 'stdio' transport is supported, got '{v}'")
        return v

    @property
    def roots(self) -> list[str]:
        """Extract filesystem root paths from args (skip package name and flags)."""
        return [a for a in self.args if not a.startswith("-") and a != _FS_PACKAGE]


class MCPServersConfig(BaseModel):
    """Top-level config holding a list of MCP server entries."""

    servers: list[MCPServerEntry] = []

    def filesystem_entries(self, *, write_only: bool = False) -> list[MCPServerEntry]:
        """Return enabled filesystem server entries, optionally filtered to writable."""
        return [
            s
            for s in self.servers
            if s.integration == "filesystem"
            and s.enabled
            and (not write_only or s.write)
        ]

    def filesystem_roots(self, *, write_only: bool = False) -> list[str]:
        """Return all root paths from filesystem server entries."""
        roots: list[str] = []
        for entry in self.filesystem_entries(write_only=write_only):
            roots.extend(entry.roots)
        return roots


def load_servers_config(config_path: str | Path | None = None) -> MCPServersConfig:
    """Load MCP servers config from a YAML file.

    Returns empty config if file doesn't exist or can't be parsed.
    Never raises — logs warnings and returns safe default.
    """
    if config_path is None:
        return MCPServersConfig()

    path = Path(config_path)
    if not path.exists():
        logger.debug("MCP servers config not found: %s", path)
        return MCPServersConfig()

    try:
        import yaml
    except ImportError:
        logger.warning("PyYAML not installed — cannot load MCP servers config")
        return MCPServersConfig()

    try:
        text = path.read_text()
        raw = yaml.safe_load(text)
        if not isinstance(raw, dict):
            logger.warning("MCP servers config is not a dict: %s", path)
            return MCPServersConfig()
        return MCPServersConfig.model_validate(raw)
    except Exception as exc:
        logger.warning("Failed to parse MCP servers config %s: %s", path, exc)
        return MCPServersConfig()


_cached_config: MCPServersConfig | None = None


def servers_config_from_env(env: dict[str, str] | None = None) -> MCPServersConfig:
    """Build MCPServersConfig from environment variables.

    Reads MEMEX_MCP_SERVERS_CONFIG — path to YAML file with server definitions.
    Result is cached when called without an env override since config is
    static at runtime.
    """
    global _cached_config

    use_cache = env is None
    if use_cache and _cached_config is not None:
        return _cached_config

    import os

    env = dict(os.environ) if env is None else env

    yaml_path = env.get("MEMEX_MCP_SERVERS_CONFIG")
    config = load_servers_config(yaml_path)

    if use_cache:
        _cached_config = config

    return config
