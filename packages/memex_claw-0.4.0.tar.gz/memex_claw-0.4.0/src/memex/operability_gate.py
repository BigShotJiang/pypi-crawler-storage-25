"""Repeatable operability gate for preserved Memex operator surfaces."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

OPERABILITY_TESTS: tuple[str, ...] = (
    "tests/test_doctor.py",
    "tests/test_status.py",
    "tests/test_api.py",
    "tests/test_operational_smoke.py",
    "tests/test_ingest_url.py",
    "tests/test_cookies.py",
    "tests/test_web_fetcher.py",
    "tests/e2e/test_preservation_guardrails.py",
    "tests/e2e/test_meeting_pipeline.py",
    "tests/test_tools.py",
    "tests/test_scheduler_engine.py",
    "tests/test_telegram.py",
    "tests/test_meeting_transcribe.py",
    "tests/test_cli.py",
    "tests/test_loop.py",
    "tests/test_openclaw_bridge.py",
)


def repo_root() -> Path:
    """Return the repository root for this checkout."""
    return Path(__file__).resolve().parents[2]


def build_command(extra_args: list[str] | None = None) -> list[str]:
    """Return the uv/pytest command for the operability gate."""
    command = [
        "uv",
        "run",
        "--with",
        "pytest",
        "--with",
        "pytest-asyncio",
        "python",
        "-m",
        "pytest",
        *OPERABILITY_TESTS,
    ]
    if extra_args:
        command.extend(extra_args)
    return command


def main(argv: list[str] | None = None) -> int:
    """Run the operability gate and return the pytest exit code.

    Pass --realtelegram to also run live Telegram e2e tests (required for
    release sign-off).  All other extra args are forwarded to pytest.
    """
    if argv is None:
        argv = sys.argv[1:]
    result = subprocess.run(build_command(list(argv)), cwd=repo_root(), check=False)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
