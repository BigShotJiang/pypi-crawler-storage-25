"""Built-in tools that execute in-process (no external connector needed)."""

from __future__ import annotations

import json
import logging
import time
from datetime import timedelta
from typing import TYPE_CHECKING, Any, Callable

from memex.models import ToolDefinition, ToolResult
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.interfaces.caller import CallerContext
    from memex.store import MemexStore

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Store references for tools that need knowledge store access
# ---------------------------------------------------------------------------

_STORES: dict[str, Any] = {}
_EXECUTION_CONTEXT: dict[str, Any] = {}


def configure_stores(
    content_store: Any = None,
    embedding_backend: Any = None,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
    event_store: Any = None,
    self_state_provider: Callable[["CallerContext"], dict[str, Any]] | None = None,
    intake_store: Any = None,
    enqueue_fn: Any = None,
    diagnostics_provider: Callable[[list[str] | None], dict[str, Any]] | None = None,
    repair_provider: Callable[[str], dict[str, Any]] | None = None,
) -> None:
    """Called during startup to give builtin tools access to stores."""
    if content_store is not None:
        _STORES["content"] = content_store
    if embedding_backend is not None:
        _STORES["embedding"] = embedding_backend
    if memex_store is not None:
        _STORES["goal"] = memex_store
        try:
            _STORES["settings"] = memex_store.settings
        except Exception:
            pass
    if scheduler_store is not None:
        _STORES["scheduler"] = scheduler_store
    if event_store is not None:
        _STORES["event"] = event_store
    if self_state_provider is not None:
        _STORES["self_state_provider"] = self_state_provider
    if intake_store is not None:
        _STORES["intake"] = intake_store
    if enqueue_fn is not None:
        _STORES["enqueue_fn"] = enqueue_fn
    if diagnostics_provider is not None:
        _STORES["diagnostics_provider"] = diagnostics_provider
    if repair_provider is not None:
        _STORES["repair_provider"] = repair_provider


def release_stores(
    *,
    content_store: Any = None,
    embedding_backend: Any = None,
    memex_store: MemexStore | None = None,
    scheduler_store: Any = None,
    event_store: Any = None,
    self_state_provider: Callable[["CallerContext"], dict[str, Any]] | None = None,
    intake_store: Any = None,
    enqueue_fn: Any = None,
    diagnostics_provider: Callable[[list[str] | None], dict[str, Any]] | None = None,
    repair_provider: Callable[[str], dict[str, Any]] | None = None,
) -> None:
    """Release builtin tool references that still point at a shutting-down API."""

    def _release(key: str, value: Any) -> None:
        if value is None:
            return
        if _STORES.get(key) is value:
            _STORES.pop(key, None)

    _release("content", content_store)
    _release("embedding", embedding_backend)
    _release("goal", memex_store)
    _release("scheduler", scheduler_store)
    _release("event", event_store)
    _release("self_state_provider", self_state_provider)
    _release("intake", intake_store)
    _release("enqueue_fn", enqueue_fn)
    _release("diagnostics_provider", diagnostics_provider)
    _release("repair_provider", repair_provider)

    if memex_store is not None:
        try:
            if _STORES.get("settings") is memex_store.settings:
                _STORES.pop("settings", None)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Tool handler registry
# ---------------------------------------------------------------------------

_HANDLERS: dict[str, Any] = {}


def _handler(name: str):
    """Decorator to register a builtin tool handler."""

    def decorator(fn):
        _HANDLERS[name] = fn
        return fn

    return decorator


def execute_builtin(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    caller: "CallerContext | None" = None,
) -> ToolResult:
    """Dispatch a builtin tool call. Returns ToolResult."""
    handler = _HANDLERS.get(tool_name)
    if handler is None:
        return ToolResult(
            tool_name=tool_name,
            success=False,
            content="",
            error=f"Unknown builtin tool: {tool_name}",
            source="builtin",
            duration_ms=0,
        )

    start = time.monotonic()
    try:
        _EXECUTION_CONTEXT["caller"] = caller
        result = handler(arguments)
        elapsed = int((time.monotonic() - start) * 1000)
        if isinstance(result, ToolResult):
            return result.model_copy(update={"duration_ms": elapsed})
        return ToolResult(
            tool_name=tool_name,
            success=True,
            content=str(result),
            source="builtin",
            duration_ms=elapsed,
        )
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        return ToolResult(
            tool_name=tool_name,
            success=False,
            content="",
            error=str(exc),
            source="builtin",
            duration_ms=elapsed,
        )
    finally:
        _EXECUTION_CONTEXT.pop("caller", None)


def _resolve_caller() -> "CallerContext":
    caller = _EXECUTION_CONTEXT.get("caller")
    if caller is not None:
        return caller

    from memex.interfaces.caller import CallerContext

    return CallerContext.owner("builtin", "builtin_self_state")


def _followup_document_id_for_item(item_id: str) -> str:
    content_store = _STORES.get("content")
    memex_store = _STORES.get("goal")
    if content_store is not None:
        try:
            from memex.memory.world_model_reads import resolve_world_model_reads

            reads = resolve_world_model_reads(
                content_store=content_store,
                world_model_store=memex_store,
            )
            if reads is not None:
                document_id = reads.canonical_document_id_for_item(item_id)
                if document_id:
                    return document_id
        except Exception:
            logger.debug(
                "Failed to resolve canonical follow-up document ID", exc_info=True
            )
    return f"content_item:{item_id}"


# ---------------------------------------------------------------------------
# web_fetch — fetch a URL and return its content
# ---------------------------------------------------------------------------

_MAX_RESPONSE_CHARS = 50_000  # Truncate large responses


@_handler("web_fetch")
def _web_fetch(arguments: dict[str, Any]) -> ToolResult:
    """Fetch a URL (or YouTube video) and return extracted text content with metadata."""
    url = arguments.get("url", "")
    if not url:
        return ToolResult(
            tool_name="web_fetch",
            success=False,
            content="",
            error="Missing required parameter: url",
            source="builtin",
            duration_ms=0,
        )

    # Route YouTube URLs through the YouTube extractor
    from memex.memory.youtube_extract import is_youtube_url

    if is_youtube_url(url):
        from memex.memory.youtube_extract import extract_from_youtube

        try:
            extracted = extract_from_youtube(url)
        except Exception as exc:
            logger.debug("YouTube extraction failed for %s", url, exc_info=True)
            return ToolResult(
                tool_name="web_fetch",
                success=False,
                content="",
                error=f"YouTube extraction failed: {exc}",
                source="builtin",
                duration_ms=0,
            )
    else:
        from memex.memory.web_extract import extract_from_url

        extracted = extract_from_url(url)

    if not extracted.body:
        return ToolResult(
            tool_name="web_fetch",
            success=False,
            content="",
            error=f"Could not extract content from {url}",
            source="builtin",
            duration_ms=0,
        )

    # Build structured output: metadata header + body
    header_parts = []
    if extracted.title:
        header_parts.append(f"Title: {extracted.title}")
    if extracted.author:
        header_parts.append(f"Author: {extracted.author}")
    if extracted.date:
        header_parts.append(f"Date: {extracted.date}")
    if extracted.sitename:
        header_parts.append(f"Source: {extracted.sitename}")
    header_parts.append(f"URL: {extracted.url}")
    header_parts.append(f"Words: {extracted.word_count}")

    header = "\n".join(header_parts)
    content = f"{header}\n\n---\n\n{extracted.body}"

    if len(content) > _MAX_RESPONSE_CHARS:
        content = (
            content[:_MAX_RESPONSE_CHARS]
            + f"\n\n[Truncated at {_MAX_RESPONSE_CHARS} chars]"
        )

    return ToolResult(
        tool_name="web_fetch",
        success=True,
        content=content,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# ingest_url — fetch, extract, and ingest a URL into the knowledge store
# ---------------------------------------------------------------------------


@_handler("ingest_url")
def _ingest_url(arguments: dict[str, Any]) -> ToolResult:
    """Fetch a URL, extract content, and ingest into the knowledge store."""
    from memex.memory.intake import ingest_from_url
    from memex.models import ItemType

    url = arguments.get("url", "")
    if not url:
        return ToolResult(
            tool_name="ingest_url",
            success=False,
            content="",
            error="Missing required parameter: url",
            source="builtin",
            duration_ms=0,
        )

    content_store = _STORES.get("content")
    if content_store is None:
        return ToolResult(
            tool_name="ingest_url",
            success=False,
            content="",
            error="Knowledge store not configured",
            source="builtin",
            duration_ms=0,
        )

    tags = arguments.get("tags") or []
    item_type_str = arguments.get("item_type", "article")
    try:
        item_type = ItemType(item_type_str)
    except ValueError:
        item_type = ItemType.ARTICLE

    item = ingest_from_url(
        url,
        tags=tags,
        item_type=item_type,
        content_store=content_store,
        memex_store=_STORES.get("goal"),
        embedding_backend=_STORES.get("embedding"),
    )

    return ToolResult(
        tool_name="ingest_url",
        success=True,
        content=(
            f"Ingested: {item.title}\n"
            f"ID: {_followup_document_id_for_item(item.item_id)}\n"
            f"Type: {item.type.value} | Words: {len(item.body.split())}"
        ),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# gmail_search — search Gmail and ingest matching messages
# ---------------------------------------------------------------------------


@_handler("gmail_search")
def _gmail_search(arguments: dict[str, Any]) -> ToolResult:
    """Search Gmail, ingest matching messages, and extract URLs from bodies."""
    # Build Gmail query from structured parameters
    parts: list[str] = []

    from_addr = arguments.get("from_address", "")
    if from_addr:
        parts.append(f"from:{from_addr}")

    to_addr = arguments.get("to_address", "")
    if to_addr:
        parts.append(f"to:{to_addr}")

    subject = arguments.get("subject", "")
    if subject:
        parts.append(f"subject:{subject}")

    after = arguments.get("after", "")
    if after:
        parts.append(f"after:{after}")

    before = arguments.get("before", "")
    if before:
        parts.append(f"before:{before}")

    newer_than = arguments.get("newer_than", "")
    if newer_than:
        parts.append(f"newer_than:{newer_than}")

    extra_query = arguments.get("query", "")
    if extra_query:
        parts.append(extra_query)

    if not parts:
        return ToolResult(
            tool_name="gmail_search",
            success=False,
            content="",
            error="At least one search parameter is required (from_address, subject, after, newer_than, or query)",
            source="builtin",
            duration_ms=0,
        )

    content_store = _STORES.get("content")
    if content_store is None:
        return ToolResult(
            tool_name="gmail_search",
            success=False,
            content="",
            error="Knowledge store not configured",
            source="builtin",
            duration_ms=0,
        )

    import os

    query = " ".join(parts)
    label = os.environ.get("MEMEX_GMAIL_LABEL", "")
    if label:
        query = f"label:{label} {query}"

    limit = min(arguments.get("limit", 10), 50)

    from memex.integrations.gmail import GmailClient

    client = GmailClient()
    client.authenticate()
    messages = client.search_messages(query, limit=limit)

    if not messages:
        return ToolResult(
            tool_name="gmail_search",
            success=True,
            content="No messages found.",
            source="builtin",
            duration_ms=0,
        )

    # Build notification router if possible
    notification_router = None
    memex_store = _STORES.get("goal")
    if memex_store is not None:
        try:
            from memex.notifications import NotificationRouter

            ns = getattr(memex_store, "notifications", None)
            if ns is not None:
                notification_router = NotificationRouter(ns)
        except Exception:
            pass

    from memex.auto_ingest.gmail import ingest_gmail_messages

    caller = _resolve_caller()

    result = ingest_gmail_messages(
        messages,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=_STORES.get("embedding"),
        notification_router=notification_router,
        tags=["gmail", "search", "auto-ingest"],
        session_id=caller.session_id,
        trigger_surface="tool",
    )

    lines = [
        f"- {m.get('date', '')} — {m.get('subject', '(no subject)')}" for m in messages
    ]
    summary = (
        f"Found {result.total} messages, ingested {result.ingested}:\n"
        + "\n".join(lines)
    )
    return ToolResult(
        tool_name="gmail_search",
        success=True,
        content=summary,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# file_transform — server-side file read/transform/write via dedicated LLM call
# ---------------------------------------------------------------------------

_MAX_INPUT_BYTES = 2 * 1024 * 1024  # 2 MB total input cap
_MAX_FILE_BYTES = 512 * 1024  # 512 KB per file


def _resolve_and_validate_path(path: str, allowed_roots: list[str]) -> str:
    """Resolve a path and check it's within allowed filesystem roots.

    Expands ~ and resolves to absolute. Returns the resolved path string.
    Raises ValueError if the path is outside all allowed roots.
    """
    from pathlib import Path as P

    resolved = P(path).expanduser().resolve()
    for root in allowed_roots:
        root_resolved = P(root).expanduser().resolve()
        try:
            resolved.relative_to(root_resolved)
            return str(resolved)
        except ValueError:
            continue
    raise ValueError(
        f"Path {path} is outside allowed filesystem roots: {allowed_roots}"
    )


def _strip_outer_code_fence(text: str) -> str:
    """Strip a single outer markdown code fence wrapping the entire output.

    Only strips if the text starts with ``` and the *last* line is ```.
    Inner code fences (legitimate content) are preserved.
    """
    stripped = text.strip()
    if not stripped.startswith("```"):
        return stripped
    # Find the opening fence line
    first_newline = stripped.find("\n")
    if first_newline == -1:
        return stripped
    # Check if the last line is a closing fence
    last_newline = stripped.rfind("\n")
    if last_newline == first_newline:
        # Only one newline — can't be a proper fence wrapper
        return stripped
    closing = stripped[last_newline + 1 :].strip()
    if closing == "```":
        return stripped[first_newline + 1 : last_newline]
    return stripped


@_handler("file_transform")
def _file_transform(arguments: dict[str, Any]) -> ToolResult:
    """Read files, transform via dedicated LLM call, write result."""
    from pathlib import Path

    from memex.llm import chat_with_usage, get_response_model

    input_paths = arguments.get("input_paths")
    output_path = arguments.get("output_path")
    instructions = arguments.get("instructions")
    model = arguments.get("model")

    # Validate required params
    if not input_paths or not isinstance(input_paths, list):
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="Missing required parameter: input_paths (list of file paths)",
            source="builtin",
            duration_ms=0,
        )
    if not output_path:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="Missing required parameter: output_path",
            source="builtin",
            duration_ms=0,
        )
    if not instructions:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="Missing required parameter: instructions",
            source="builtin",
            duration_ms=0,
        )

    from memex.mcp_servers import servers_config_from_env

    _config = servers_config_from_env()
    all_roots = _config.filesystem_roots()
    write_roots = _config.filesystem_roots(write_only=True)
    if not all_roots:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="No filesystem servers configured — add entries with integration: filesystem to your MCP servers YAML config",
            source="builtin",
            duration_ms=0,
        )
    if not write_roots:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="No writable filesystem servers configured — set write: true on a filesystem server entry in your MCP servers YAML config",
            source="builtin",
            duration_ms=0,
        )

    try:
        resolved_inputs = [
            _resolve_and_validate_path(p, all_roots) for p in input_paths
        ]
        resolved_output = _resolve_and_validate_path(output_path, write_roots)
    except ValueError as exc:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error=str(exc),
            source="builtin",
            duration_ms=0,
        )

    # Read input files
    file_contents: list[tuple[str, str, int]] = []  # (path, content, size)
    total_bytes = 0
    for rpath in resolved_inputs:
        p = Path(rpath)
        if not p.exists():
            return ToolResult(
                tool_name="file_transform",
                success=False,
                content="",
                error=f"Input file not found: {rpath}",
                source="builtin",
                duration_ms=0,
            )
        if not p.is_file():
            return ToolResult(
                tool_name="file_transform",
                success=False,
                content="",
                error=f"Not a file: {rpath}",
                source="builtin",
                duration_ms=0,
            )
        size = p.stat().st_size
        if size > _MAX_FILE_BYTES:
            return ToolResult(
                tool_name="file_transform",
                success=False,
                content="",
                error=f"File too large: {rpath} ({size:,} bytes, max {_MAX_FILE_BYTES:,})",
                source="builtin",
                duration_ms=0,
            )
        total_bytes += size
        if total_bytes > _MAX_INPUT_BYTES:
            return ToolResult(
                tool_name="file_transform",
                success=False,
                content="",
                error=f"Total input exceeds {_MAX_INPUT_BYTES:,} bytes",
                source="builtin",
                duration_ms=0,
            )
        # Reject likely binary files
        raw = p.read_bytes()
        if b"\x00" in raw[:8192]:
            return ToolResult(
                tool_name="file_transform",
                success=False,
                content="",
                error=f"Binary file detected: {rpath}",
                source="builtin",
                duration_ms=0,
            )
        file_contents.append((rpath, raw.decode("utf-8", errors="replace"), size))

    # Build the dedicated LLM prompt
    file_sections = []
    for fpath, content, _ in file_contents:
        file_sections.append(f"## File: {fpath}\n```\n{content}\n```")
    files_text = "\n\n".join(file_sections)

    messages = [
        {
            "role": "system",
            "content": (
                "You are a precise file transformation tool. "
                "Apply the user's instructions to the provided file content(s). "
                "Output ONLY the transformed content — no explanations, no commentary, "
                "no wrapping markdown fences. Your entire response becomes the output file."
            ),
        },
        {
            "role": "user",
            "content": f"## Instructions\n{instructions}\n\n## Input Files\n\n{files_text}",
        },
    ]

    use_model = model or get_response_model()

    try:
        llm_result, usage = chat_with_usage(
            messages,
            model=use_model,
            temperature=0.2,
            max_tokens=16384,
        )
    except Exception as exc:
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error=f"LLM call failed: {exc}",
            source="builtin",
            duration_ms=0,
        )

    if not llm_result or not llm_result.strip():
        return ToolResult(
            tool_name="file_transform",
            success=False,
            content="",
            error="LLM returned empty response",
            source="builtin",
            duration_ms=0,
        )

    # Strip outer code fence the LLM may have added despite instructions
    output_content = _strip_outer_code_fence(llm_result)

    # Write output
    out = Path(resolved_output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(output_content, encoding="utf-8")

    # Build summary (NOT the full content)
    input_summary = ", ".join(
        f"{Path(fp).name} ({sz:,}B)" for fp, _, sz in file_contents
    )
    output_bytes = len(output_content.encode("utf-8"))
    output_lines = output_content.count("\n") + 1

    summary = (
        f"Transformed {len(file_contents)} file(s) → {resolved_output}\n"
        f"Input: {input_summary}\n"
        f"Output: {output_bytes:,} bytes, {output_lines} lines\n"
        f"Model: {use_model}\n"
        f"Tokens: {usage.prompt_tokens} prompt + {usage.completion_tokens} completion"
    )
    if usage.cost_usd:
        summary += f" (${usage.cost_usd:.4f})"

    logger.info("file_transform: %s", summary.replace("\n", " | "))

    return ToolResult(
        tool_name="file_transform",
        success=True,
        content=summary,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# remember — store facts, context, or reminders to long-term memory
# ---------------------------------------------------------------------------


@_handler("remember")
def _remember(arguments: dict[str, Any]) -> ToolResult:
    """Classify intent and store the appropriate memory type."""
    from memex.remember import execute_remember

    text = arguments.get("text", "")
    if not text:
        return ToolResult(
            tool_name="remember",
            success=False,
            content="",
            error="Missing required parameter: text",
            source="builtin",
            duration_ms=0,
        )

    content_store = _STORES.get("content")
    if content_store is None:
        return ToolResult(
            tool_name="remember",
            success=False,
            content="",
            error="Knowledge store not configured",
            source="builtin",
            duration_ms=0,
        )

    memex_store = _STORES.get("goal")
    scheduler_store = _STORES.get("scheduler")

    # Load session once — used for both summary (classification) and context capture
    session = None
    session_summary = ""
    if memex_store is not None:
        try:
            session = memex_store.load_session()
            if session:
                session_summary = session.conversation_summary or ""
        except Exception:
            pass

    result = execute_remember(
        text,
        content_store=content_store,
        memex_store=memex_store,
        scheduler_store=scheduler_store,
        session_id="",
        session_summary=session_summary,
        session=session,
    )

    # Format response
    intent = result["intent"]
    if intent == "fact":
        content = (
            f'Remembered: "{result["title"]}"\n'
            f"ID: {_followup_document_id_for_item(result['item_id'])}\n"
            f"Tags: {', '.join('#' + t for t in result.get('tags', []))}"
        )
    elif intent == "context":
        content = (
            f'Captured session context: "{result["title"]}"\n'
            f"ID: {_followup_document_id_for_item(result['item_id'])}\n"
            f"Includes: {result.get('turn_count', 0)} recent turns, working memory"
        )
    elif intent == "reminder":
        content = (
            f'Reminder set: "{result["title"]}"\n'
            f"ID: world_model_task:{result['task_id']}"
        )
        metadata_refs: list[dict[str, str]] = [
            {
                "relationship": "creates_task",
                "record_type": "world_model_task",
                "record_id": str(result["task_id"]),
            }
        ]
        if result.get("remind_at"):
            content += f"\nWhen: {result['remind_at']}"
        if result.get("is_recurring"):
            content += " (recurring)"
        else:
            content += " (one-time)"
        if result.get("goal_id"):
            content += (
                f'\nGoal created: "{result["title"]}"\n'
                f"Goal ID: world_model_goal:{result['goal_id']}"
            )
            metadata_refs.append(
                {
                    "relationship": (
                        "creates_goal" if result.get("goal_created") else "for_goal"
                    ),
                    "record_type": "world_model_goal",
                    "record_id": str(result["goal_id"]),
                }
            )
    else:
        content = f"Remembered ({intent})"

    return ToolResult(
        tool_name="remember",
        success=True,
        content=content,
        source="builtin",
        duration_ms=0,
        metadata={"world_model_refs": metadata_refs} if intent == "reminder" else {},
    )


# ---------------------------------------------------------------------------
# forget — search, soft-delete, and restore items
# ---------------------------------------------------------------------------


@_handler("forget")
def _forget(arguments: dict[str, Any]) -> ToolResult:
    """Multi-step forget workflow: search, select, or undo."""
    from memex.forget import forget_items, restore_items, search_candidates

    action = arguments.get("action", "search")
    query = arguments.get("query", "")
    ids = arguments.get("ids", [])

    content_store = _STORES.get("content")
    memex_store = _STORES.get("goal")
    scheduler_store = _STORES.get("scheduler")

    if action == "search":
        if not query:
            return ToolResult(
                tool_name="forget",
                success=False,
                content="",
                error="Missing required parameter: query",
                source="builtin",
                duration_ms=0,
            )

        candidates = search_candidates(
            query,
            content_store,
            memex_store,
            scheduler_store,
        )

        if not candidates:
            return ToolResult(
                tool_name="forget",
                success=True,
                content=f'No items found matching "{query}".',
                source="builtin",
                duration_ms=0,
            )

        # Group by type
        groups: dict[str, list] = {}
        for c in candidates:
            groups.setdefault(c.type, []).append(c)

        lines = [f'Found {len(candidates)} item(s) matching "{query}":\n']
        for type_name, items in groups.items():
            label = {
                "item": "Items",
                "goal": "Goals",
                "scheduled_task": "Reminders",
            }.get(type_name, type_name.title())
            lines.append(f"  {label}:")
            for c in items:
                date_str = c.created_at.strftime("%b %d, %Y") if c.created_at else ""
                lines.append(f'    [{c.id}] "{c.title}"')
                if date_str:
                    lines.append(f"             {c.type} | {date_str}")
                if c.snippet:
                    lines.append(f'             Preview: "{c.snippet[:100]}..."')
            lines.append("")

        lines.append("Reply with which IDs to forget, or refine your search.")

        return ToolResult(
            tool_name="forget",
            success=True,
            content="\n".join(lines),
            source="builtin",
            duration_ms=0,
        )

    elif action == "select":
        if not ids:
            return ToolResult(
                tool_name="forget",
                success=False,
                content="",
                error="Missing required parameter: ids",
                source="builtin",
                duration_ms=0,
            )

        messages = forget_items(
            ids,
            content_store,
            memex_store,
            scheduler_store,
        )

        content = "\n".join(messages)
        content += (
            "\n\nThese items are hidden from all searches and will be permanently "
            "deleted in 1 hour. To restore, use the forget tool with action='undo'."
        )

        return ToolResult(
            tool_name="forget",
            success=True,
            content=content,
            source="builtin",
            duration_ms=0,
        )

    elif action == "undo":
        if not ids:
            return ToolResult(
                tool_name="forget",
                success=False,
                content="",
                error="Missing required parameter: ids",
                source="builtin",
                duration_ms=0,
            )

        messages = restore_items(
            ids,
            content_store,
            memex_store,
            scheduler_store,
        )

        return ToolResult(
            tool_name="forget",
            success=True,
            content="\n".join(messages),
            source="builtin",
            duration_ms=0,
        )

    else:
        return ToolResult(
            tool_name="forget",
            success=False,
            content="",
            error=f"Unknown action: {action}. Must be 'search', 'select', or 'undo'.",
            source="builtin",
            duration_ms=0,
        )


# ---------------------------------------------------------------------------
# search_conversations — full-text search across conversation history
# ---------------------------------------------------------------------------


@_handler("search_conversations")
def _search_conversations(arguments: dict[str, Any]) -> ToolResult:
    """Search past conversations across all interfaces via FTS5."""
    query = arguments.get("query", "")
    if not query:
        return ToolResult(
            tool_name="search_conversations",
            success=False,
            content="",
            error="Missing required parameter: query",
            source="builtin",
            duration_ms=0,
        )

    memex_store = _STORES.get("goal")
    if memex_store is None:
        return ToolResult(
            tool_name="search_conversations",
            success=False,
            content="",
            error="Store not configured",
            source="builtin",
            duration_ms=0,
        )

    _MAX_CONVERSATION_RESULTS = 50  # Cap to avoid prompt bloat
    min(max(1, arguments.get("limit", 20)), _MAX_CONVERSATION_RESULTS)
    days_back = arguments.get("days_back")
    if days_back is not None:
        from datetime import timedelta

        utcnow() - timedelta(days=int(days_back))

    # TODO(phase-4g): implement conversation search via fathomdb adapter
    return ToolResult(
        tool_name="search_conversations",
        success=True,
        content="Conversation search is not yet available via fathomdb. Use goal/knowledge search instead.",
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# search_knowledge — explicit knowledge store query
# ---------------------------------------------------------------------------


@_handler("search_knowledge")
def _search_knowledge(arguments: dict[str, Any]) -> ToolResult:
    """Search the knowledge store and return matching items."""
    from memex.memory.retrieval import retrieve_for_context

    query = arguments.get("query", "")
    if not query:
        return ToolResult(
            tool_name="search_knowledge",
            success=False,
            content="",
            error="Missing required parameter: query",
            source="builtin",
            duration_ms=0,
        )

    content_store = _STORES.get("content")
    if content_store is None:
        return ToolResult(
            tool_name="search_knowledge",
            success=False,
            content="",
            error="Knowledge store not configured",
            source="builtin",
            duration_ms=0,
        )

    max_results = arguments.get("limit", 10)
    max_results = min(max(1, max_results), 25)

    # Use the full retrieval pipeline: FTS + semantic + ranking
    import os

    search_budget = int(os.environ.get("MEMEX_SEARCH_BUDGET", "3000"))
    memex_store = _STORES.get("goal")
    retrieval = retrieve_for_context(
        query,
        max_tokens=search_budget,
        content_store=content_store,
        world_model_store=memex_store,
        max_items=max_results,
        include_document_ids=True,
    )
    result_text = retrieval.text

    # Fallback: when the retrieval pipeline finds nothing, search content
    # items directly so that items without world-model projections are still
    # discoverable.  Try FTS first, then fall back to a client-side scan of
    # recent items so that freshly created items are always reachable.
    if not result_text:
        fallback_items: list[tuple[Any, float]] = []
        try:
            fts_raw = content_store.fts_search(query, limit=max_results)
            fallback_items = list(fts_raw)
        except Exception:
            pass
        if not fallback_items:
            try:
                query_lower = query.lower()
                all_items = content_store.list_items(limit=200)
                for it in all_items:
                    title = (it.title or "").lower()
                    body = (it.body or "").lower()
                    if query_lower in title or query_lower in body:
                        fallback_items.append((it, 1.0))
                    elif any(w in title or w in body for w in query_lower.split()):
                        fallback_items.append((it, 0.5))
                fallback_items = fallback_items[:max_results]
            except Exception:
                pass
        if fallback_items:
            parts = ["## Retrieved Knowledge\n"]
            for i, (item, score) in enumerate(fallback_items, 1):
                relevance_pct = int(min(score, 1.0) * 100)
                header = f"### [{i}] {item.title} (relevance: {relevance_pct}%)"
                doc_id = f"content_item:{item.item_id}"
                # Check if a canonical knowledge object exists
                if memex_store is not None:
                    try:
                        ko = memex_store.load_world_model_knowledge_object_by_item_id(
                            item.item_id
                        )
                        if ko is not None and not getattr(
                            ko, "knowledge_id", ""
                        ).startswith("ki-"):
                            doc_id = f"world_model_knowledge:{ko.knowledge_id}"
                    except Exception:
                        pass
                entry_parts = [header, f"ID: {doc_id}"]
                body = item.body or ""
                max_body_chars = search_budget * 4
                if len(body) > max_body_chars:
                    body = body[:max_body_chars] + "..."
                entry_parts.append(body)
                parts.append("\n".join(entry_parts))
            result_text = "\n\n".join(parts)

    if not result_text:
        return ToolResult(
            tool_name="search_knowledge",
            success=True,
            content=f'No items found matching "{query}".',
            source="builtin",
            duration_ms=0,
        )

    return ToolResult(
        tool_name="search_knowledge",
        success=True,
        content=result_text,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# get_item — retrieve a specific item by ID
# ---------------------------------------------------------------------------


@_handler("get_item")
def _get_item(arguments: dict[str, Any]) -> ToolResult:
    """Retrieve a knowledge item by its ID."""
    item_id = arguments.get("id", "")
    if not item_id:
        return ToolResult(
            tool_name="get_item",
            success=False,
            content="",
            error="Missing required parameter: id",
            source="builtin",
            duration_ms=0,
        )

    content_store = _STORES.get("content")
    if content_store is None:
        return ToolResult(
            tool_name="get_item",
            success=False,
            content="",
            error="Knowledge store not configured",
            source="builtin",
            duration_ms=0,
        )

    if (
        item_id.startswith("knowledge_ingest_run:")
        or item_id.startswith("world_model_knowledge:")
        or item_id.startswith("world_model_action:")
        or item_id.startswith("world_model_event:")
        or item_id.startswith("world_model_dependency:")
        or item_id.startswith("world_model_goal:")
        or item_id.startswith("world_model_mapping:")
        or item_id.startswith("world_model_action_plan:")
        or item_id.startswith("world_model_plan_step:")
        or item_id.startswith("world_model_execution_record:")
        or item_id.startswith("world_model_plan_step_transition:")
        or item_id.startswith("world_model_task:")
        or item_id.startswith("world_model_commitment:")
        or item_id.startswith("world_model_claim_evaluation:")
        or item_id.startswith("content_item:")
    ):
        memex_store = _STORES.get("goal")

        if item_id.startswith("knowledge_ingest_run:"):
            if memex_store is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error="World-model store not configured",
                    source="builtin",
                    duration_ms=0,
                )
            run_id = item_id.split(":", 1)[1]
            run = memex_store.load_world_model_knowledge_ingest_run(run_id)
            if run is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            links = memex_store.list_world_model_provenance_links(
                source_record_type="knowledge_ingest_run",
                source_record_id=run.ingest_run_id,
            )
            parts = [f"# Knowledge ingest run: {run.ingest_kind}"]
            parts.append(f"Type: knowledge_ingest_run | ID: {item_id}")
            parts.append(f"Surface: {run.trigger_surface}")
            parts.append(f"Status: {run.status}")
            parts.append(f"Phase: {run.phase}")
            parts.append(f"Requested item: {run.requested_item_type}")
            parts.append(f"Source: {run.source_ref}")
            if (
                run.normalized_source_ref
                and run.normalized_source_ref != run.source_ref
            ):
                parts.append(f"Normalized source: {run.normalized_source_ref}")
            if run.session_id:
                parts.append(f"Session: {run.session_id}")
            parts.append(f"Fallback: {'yes' if run.fallback_used else 'no'}")
            if run.item_id:
                parts.append(f"Item: {run.item_id}")
            if run.knowledge_id:
                parts.append(f"Knowledge: {run.knowledge_id}")
            if run.summary_model:
                parts.append(f"Summary model: {run.summary_model}")
            if run.error:
                parts.append(f"Error: {run.error}")
            total_ms = run.payload.get("operation_stats", {}).get("total_ms")
            if total_ms is not None:
                parts.append(f"Duration: {total_ms}ms")
            for link in links:
                parts.append(
                    f"{link.relationship} -> {link.target_record_type}:{link.target_record_id}"
                )
            return ToolResult(
                tool_name="get_item",
                success=True,
                content="\n".join(parts),
                source="builtin",
                duration_ms=0,
            )

        from memex.memory.retrieval_documents import (
            resolve_retrieval_document,
            resolve_world_model_action_plan_document,
            resolve_world_model_execution_record_document,
            resolve_world_model_claim_evaluation_document,
            resolve_world_model_commitment_document,
            resolve_world_model_dependency_document,
            resolve_world_model_goal_document,
            resolve_world_model_plan_step_document,
            resolve_world_model_plan_step_transition_document,
            resolve_semantic_mapping_document,
            resolve_world_model_task_document,
            resolve_world_model_event_document,
            resolve_world_model_action_document,
        )
        from memex.memory.world_model_reads import (
            CanonicalActionPlanHit,
            CanonicalExecutionRecordHit,
            CanonicalClaimEvaluationHit,
            CanonicalPlanStepHit,
            CanonicalPlanStepTransitionHit,
            CanonicalSemanticMappingHit,
            resolve_world_model_reads,
        )

        if item_id.startswith("content_item:"):
            content_item_id = item_id.split(":", 1)[1]
            item = content_store.get_item(content_item_id)
            if item is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No content item found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=_render_item_detail(item, display_id=item_id),
                source="builtin",
                duration_ms=0,
            )

        try:
            reads = resolve_world_model_reads(
                content_store=content_store,
                world_model_store=_STORES.get("goal"),
            )
        except ValueError as exc:
            return ToolResult(
                tool_name="get_item",
                success=False,
                content="",
                error=str(exc),
                source="builtin",
                duration_ms=0,
            )
        if reads is None:
            return ToolResult(
                tool_name="get_item",
                success=False,
                content="",
                error=f"No canonical document found with ID: {item_id}",
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_knowledge:"):
            knowledge_id = item_id.split(":", 1)[1]
            knowledge_hit = reads.load_knowledge_document_hit(knowledge_id)
            if knowledge_hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            knowledge = knowledge_hit.knowledge
            backing_item = (
                content_store.get_item(knowledge.item_id) if knowledge.item_id else None
            )
            document = resolve_retrieval_document(
                item_id=knowledge.item_id,
                item=backing_item,
                knowledge=knowledge,
                knowledge_relationships=knowledge_hit.relationships,
                relevance=1.0,
                route_profile=None,
                reputation_display="unrated",
            )
            raw_title = knowledge.title or (
                backing_item.title if backing_item else knowledge.canonical_key
            )
            parts = [f"# {raw_title}"]
            parts.append(
                f"Type: {knowledge.knowledge_type} | ID: {document.document_id}"
            )
            if document.source_url:
                parts.append(f"Source: {document.source_url}")
            parts.extend(document.world_model_context_lines)
            if backing_item is not None and backing_item.tags:
                parts.append(f"Tags: {', '.join(backing_item.tags)}")
            if backing_item is not None and backing_item.captured_at:
                parts.append(
                    f"Created: {backing_item.captured_at.strftime('%Y-%m-%d %H:%M')}"
                )
            if backing_item is not None and backing_item.type.value == "meeting":
                _append_meeting_promotion_audit(parts, backing_item)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_mapping:"):
            mapping_id = item_id.split(":", 1)[1]
            mapping = (
                memex_store.load_world_model_semantic_mapping(mapping_id)
                if memex_store is not None
                else None
            )
            if mapping is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_semantic_mapping_document(
                CanonicalSemanticMappingHit(mapping=mapping, score=1.0)
            )
            parts = [f"# {document.title}"]
            parts.append(f"Type: semantic_mapping | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_action_plan:"):
            plan_id = item_id.split(":", 1)[1]
            hit = reads.load_action_plan_document(plan_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_action_plan_document(
                CanonicalActionPlanHit(
                    plan=hit.plan,
                    score=1.0,
                    provenance=hit.provenance,
                    incoming_links=hit.incoming_links,
                )
            )
            parts = [f"# {document.title}"]
            parts.append(f"Type: action_plan | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_plan_step:"):
            step_id = item_id.split(":", 1)[1]
            hit = reads.load_plan_step_document(step_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_plan_step_document(
                CanonicalPlanStepHit(
                    step=hit.step,
                    score=1.0,
                    provenance=hit.provenance,
                    incoming_links=hit.incoming_links,
                )
            )
            parts = [f"# {document.title}"]
            parts.append(f"Type: {hit.step.step_kind} | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_execution_record:"):
            execution_id = item_id.split(":", 1)[1]
            hit = reads.load_execution_record_document(execution_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_execution_record_document(
                CanonicalExecutionRecordHit(
                    record=hit.record,
                    score=1.0,
                    provenance=hit.provenance,
                )
            )
            parts = [f"# {document.title}"]
            parts.append(f"Type: execution_record | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_plan_step_transition:"):
            transition_id = item_id.split(":", 1)[1]
            hit = reads.load_plan_step_transition_document(transition_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_plan_step_transition_document(
                CanonicalPlanStepTransitionHit(
                    transition=hit.transition,
                    score=1.0,
                    provenance=hit.provenance,
                )
            )
            parts = [f"# {document.title}"]
            parts.append(f"Type: plan_step_transition | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_task:"):
            task_id = item_id.split(":", 1)[1]
            hit = reads.load_task_document(task_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            task = hit.task
            document = resolve_world_model_task_document(hit)
            parts = [f"# {document.title}"]
            parts.append(f"Type: {task.task_kind} | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            if task.goal_id:
                parts.append(f"Goal: {task.goal_id}")
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_goal:"):
            goal_id = item_id.split(":", 1)[1]
            hit = reads.load_goal_document(goal_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_goal_document(hit)
            parts = [f"# {document.title}"]
            parts.append(f"Type: goal | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_commitment:"):
            commitment_id = item_id.split(":", 1)[1]
            hit = reads.load_commitment_document(commitment_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_commitment_document(hit)
            parts = [f"# {document.title}"]
            parts.append(f"Type: commitment | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            if hit.commitment.meeting_id:
                parts.append(f"Meeting: {hit.commitment.meeting_id}")
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_dependency:"):
            link_id = item_id.split(":", 1)[1]
            hit = reads.load_dependency_document(link_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_dependency_document(hit)
            parts = [f"# {document.title}"]
            parts.append(f"Type: dependency | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_claim_evaluation:"):
            evaluation_id = item_id.split(":", 1)[1]
            evaluation = (
                memex_store.load_world_model_claim_evaluation(evaluation_id)
                if memex_store is not None
                else None
            )
            if evaluation is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_claim_evaluation_document(
                CanonicalClaimEvaluationHit(evaluation=evaluation, score=1.0)
            )
            parts = [f"# {document.title}"]
            parts.append(
                f"Type: {evaluation.evaluation_kind} | ID: {document.document_id}"
            )
            parts.extend(document.world_model_context_lines)
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        if item_id.startswith("world_model_event:"):
            event_id = item_id.split(":", 1)[1]
            hit = reads.load_event_document(event_id)
            if hit is None:
                return ToolResult(
                    tool_name="get_item",
                    success=False,
                    content="",
                    error=f"No canonical document found with ID: {item_id}",
                    source="builtin",
                    duration_ms=0,
                )
            document = resolve_world_model_event_document(hit)
            parts = [f"# {document.title}"]
            parts.append(f"Type: {hit.event.event_kind} | ID: {document.document_id}")
            parts.extend(document.world_model_context_lines)
            for link in hit.provenance:
                rel = str(link.get("relationship") or "").strip()
                target_type = str(link.get("target_record_type") or "").strip()
                target_id = str(link.get("target_record_id") or "").strip()
                if rel and target_type and target_id:
                    parts.append(f"{rel} -> {target_type}:{target_id}")
            result_text = "\n".join(parts) + "\n\n" + document.body_text
            return ToolResult(
                tool_name="get_item",
                success=True,
                content=result_text,
                source="builtin",
                duration_ms=0,
            )

        action_id = item_id.split(":", 1)[1]
        hit = reads.load_canonical_outcome(action_id)
        if hit is None:
            return ToolResult(
                tool_name="get_item",
                success=False,
                content="",
                error=f"No canonical document found with ID: {item_id}",
                source="builtin",
                duration_ms=0,
            )
        document = resolve_world_model_action_document(hit, route_profile=None)
        parts = [f"# {document.title}"]
        parts.append(f"Type: {hit.action_kind} | ID: {document.document_id}")
        parts.append(f"Status: {hit.status}")
        if hit.meeting_id is not None:
            parts.append(f"Meeting: {hit.meeting_id}")
        if hit.conversation_turn_id is not None:
            parts.append(f"Turn: {hit.conversation_turn_id}")
        if hit.action_kind == "selected_action":
            selected = (
                hit.payload.get("selected_action")
                if isinstance(hit.payload, dict)
                else {}
            )
            if isinstance(selected, dict):
                rationale = str(selected.get("rationale") or "").strip()
                if rationale:
                    parts.append(f"Rationale: {rationale}")
            candidates = (
                hit.payload.get("action_candidates")
                if isinstance(hit.payload, dict)
                else None
            )
            if isinstance(candidates, list) and candidates:
                rendered: list[str] = []
                for candidate in candidates:
                    if not isinstance(candidate, dict):
                        continue
                    name = str(candidate.get("name") or "").strip()
                    if not name:
                        continue
                    rendered.append(
                        f"{name}[selected]" if candidate.get("selected") else name
                    )
                if rendered:
                    parts.append(f"Candidates: {', '.join(rendered)}")
        elif hit.action_kind == "meeting_extraction":
            run_id = (
                str(hit.payload.get("run_id") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if run_id:
                parts.append(f"Run: {run_id}")
            recording_id = (
                str(hit.payload.get("recording_id") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if recording_id:
                parts.append(f"Recording: {recording_id}")
            artifact_count = (
                hit.payload.get("artifact_count")
                if isinstance(hit.payload, dict)
                else None
            )
            if artifact_count is not None:
                parts.append(f"Artifact count: {artifact_count}")
        elif hit.action_kind == "meeting_semantic_sync":
            item_id = (
                str(hit.payload.get("item_id") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if item_id:
                parts.append(f"Item: {item_id}")
            sync_reason = (
                str(hit.payload.get("sync_reason") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if sync_reason:
                parts.append(f"Sync reason: {sync_reason}")
        elif hit.action_kind == "knowledge_ingest":
            source_ref = (
                str(hit.payload.get("source_ref") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            run_id = (
                str(hit.payload.get("run_id") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if run_id:
                parts.append(f"Run: {run_id}")
            if source_ref:
                parts.append(f"Source: {source_ref}")
            item_id = (
                str(hit.payload.get("item_id") or "").strip()
                if isinstance(hit.payload, dict)
                else ""
            )
            if item_id:
                parts.append(f"Item: {item_id}")
            if isinstance(hit.payload, dict) and hit.payload.get("fallback_used"):
                parts.append("Fallback: bookmark")
            stats = (
                hit.payload.get("operation_stats")
                if isinstance(hit.payload, dict)
                else None
            )
            if isinstance(stats, dict):
                total_ms = stats.get("total_ms")
                if total_ms is not None:
                    parts.append(f"Duration: {total_ms}ms")
        for link in hit.provenance:
            rel = str(link.get("relationship") or "").strip()
            target_type = str(link.get("target_record_type") or "").strip()
            target_id = str(link.get("target_record_id") or "").strip()
            if rel and target_type and target_id:
                parts.append(f"{rel} -> {target_type}:{target_id}")
        result_text = "\n".join(parts) + "\n\n" + document.body_text
        return ToolResult(
            tool_name="get_item",
            success=True,
            content=result_text,
            source="builtin",
            duration_ms=0,
        )

    item = content_store.get_item(item_id)

    if item is None:
        return ToolResult(
            tool_name="get_item",
            success=False,
            content="",
            error=f"No item found with ID: {item_id}",
            source="builtin",
            duration_ms=0,
        )

    return ToolResult(
        tool_name="get_item",
        success=True,
        content=_render_item_detail(item),
        source="builtin",
        duration_ms=0,
    )


def _render_item_detail(item, *, display_id: str | None = None) -> str:
    # Build response with metadata + body (truncated to token budget)
    import os

    max_chars = int(os.environ.get("MEMEX_SEARCH_BUDGET", "3000")) * 4

    parts = [f"# {item.title}"]
    parts.append(f"Type: {item.type.value} | ID: {display_id or item.item_id}")
    if item.source_url:
        parts.append(f"Source: {item.source_url}")
    if item.tags:
        parts.append(f"Tags: {', '.join(item.tags)}")
    if item.captured_at:
        parts.append(f"Created: {item.captured_at.strftime('%Y-%m-%d %H:%M')}")

    if item.type.value == "meeting":
        _append_meeting_promotion_audit(parts, item)
        _append_meeting_activity_audit(parts, item)

    header = "\n".join(parts)
    remaining = max_chars - len(header) - 10  # leave margin

    body = item.body or "(no content)"
    if len(body) > remaining:
        body = body[:remaining] + "..."

    return header + "\n\n" + body


def _append_meeting_promotion_audit(parts: list[str], item) -> None:
    meeting_meta = (
        item.metadata.get("meeting") if isinstance(item.metadata, dict) else None
    )
    semantic = meeting_meta.get("semantic") if isinstance(meeting_meta, dict) else None
    audit_rows = (
        semantic.get("canonical_promotion_audit")
        if isinstance(semantic, dict)
        else None
    )
    if not isinstance(audit_rows, list) or not audit_rows:
        return
    parts.append("")
    parts.append("## Meeting Promotion Audit")
    for row in audit_rows:
        artifact_type = str(row.get("artifact_type") or "").strip() or "promotion"
        status = str(row.get("status") or "").strip() or "unknown"
        parts.append(f"- {artifact_type} | {status}")
        for relationship in row.get("relationships", []):
            rel = str(relationship.get("relationship") or "").strip()
            target_type = str(relationship.get("target_record_type") or "").strip()
            target_id = str(relationship.get("target_record_id") or "").strip()
            if rel and target_type and target_id:
                parts.append(f"  {rel} -> {target_type}:{target_id}")
        for observation in row.get("observations", []):
            kind = str(observation.get("observation_kind") or "").strip()
            obs_status = str(observation.get("status") or "").strip()
            summary = str(observation.get("summary") or "").strip()
            parts.append(f"  {kind} | {obs_status} | {summary or '-'}")


def _append_meeting_activity_audit(parts: list[str], item) -> None:
    meeting_meta = (
        item.metadata.get("meeting") if isinstance(item.metadata, dict) else None
    )
    semantic = meeting_meta.get("semantic") if isinstance(meeting_meta, dict) else None
    audit_rows = (
        semantic.get("canonical_activity_audit") if isinstance(semantic, dict) else None
    )
    if not isinstance(audit_rows, list) or not audit_rows:
        return
    parts.append("")
    parts.append("## Meeting Activity Audit")
    for row in audit_rows:
        action_kind = str(row.get("action_kind") or "").strip() or "activity"
        action_name = str(row.get("action_name") or "").strip() or "-"
        status = str(row.get("status") or "").strip() or "unknown"
        parts.append(f"- {action_kind}:{action_name} | {status}")
        for relationship in row.get("relationships", []):
            rel = str(relationship.get("relationship") or "").strip()
            target_type = str(relationship.get("target_record_type") or "").strip()
            target_id = str(relationship.get("target_record_id") or "").strip()
            if rel and target_type and target_id:
                parts.append(f"  {rel} -> {target_type}:{target_id}")
        for observation in row.get("observations", []):
            kind = str(observation.get("observation_kind") or "").strip()
            obs_status = str(observation.get("status") or "").strip()
            summary = str(observation.get("summary") or "").strip()
            parts.append(f"  {kind} | {obs_status} | {summary or '-'}")


# ---------------------------------------------------------------------------
# list_goals — show active goals/intents
# ---------------------------------------------------------------------------


@_handler("list_goals")
def _list_goals(arguments: dict[str, Any]) -> ToolResult:
    """List goals, optionally filtered by status."""
    memex_store = _STORES.get("goal")
    if memex_store is None:
        return ToolResult(
            tool_name="list_goals",
            success=False,
            content="",
            error="Goal store not configured",
            source="builtin",
            duration_ms=0,
        )

    include_all = arguments.get("include_all", False)

    try:
        if include_all:
            goals = memex_store.list_goals()
        else:
            from memex.models import GoalStatus

            goals = memex_store.list_goals(GoalStatus.ACTIVE)
    except Exception as exc:
        return ToolResult(
            tool_name="list_goals",
            success=False,
            content="",
            error=f"Failed to list goals: {exc}",
            source="builtin",
            duration_ms=0,
        )

    if not goals:
        label = "goals" if include_all else "active goals"
        return ToolResult(
            tool_name="list_goals",
            success=True,
            content=f"No {label} found.",
            source="builtin",
            duration_ms=0,
        )

    lines = [f"{'All' if include_all else 'Active'} goals ({len(goals)}):\n"]
    for g in goals:
        status = g.status.value if hasattr(g.status, "value") else str(g.status)
        line = f"  [{g.goal_id[:8]}] {g.title}"
        if include_all:
            line += f" ({status})"
        if g.priority:
            prio = g.priority.value if hasattr(g.priority, "value") else str(g.priority)
            line += f" — priority: {prio}"
        lines.append(line)
        if g.description:
            lines.append(f"             {g.description[:120]}")
        if g.deadline:
            lines.append(f"             Deadline: {g.deadline.strftime('%b %d, %Y')}")
    lines.append("")

    return ToolResult(
        tool_name="list_goals",
        success=True,
        content="\n".join(lines),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# list_reminders — show scheduled tasks/reminders
# ---------------------------------------------------------------------------


@_handler("list_reminders")
def _list_reminders(arguments: dict[str, Any]) -> ToolResult:
    """List scheduled tasks and reminders."""
    scheduler_store = _STORES.get("scheduler")
    if scheduler_store is None:
        return ToolResult(
            tool_name="list_reminders",
            success=False,
            content="",
            error="Scheduler store not configured",
            source="builtin",
            duration_ms=0,
        )

    include_disabled = arguments.get("include_disabled", False)

    try:
        tasks = scheduler_store.list_tasks(enabled_only=not include_disabled)
    except Exception as exc:
        return ToolResult(
            tool_name="list_reminders",
            success=False,
            content="",
            error=f"Failed to list tasks: {exc}",
            source="builtin",
            duration_ms=0,
        )

    # Filter out builtins — only show user-created reminders/tasks
    user_tasks = [t for t in tasks if not t.builtin]

    if not user_tasks:
        return ToolResult(
            tool_name="list_reminders",
            success=True,
            content="No reminders or scheduled tasks found.",
            source="builtin",
            duration_ms=0,
        )

    lines = [f"Reminders and scheduled tasks ({len(user_tasks)}):\n"]
    for t in user_tasks:
        status = "enabled" if t.enabled else "disabled"
        lines.append(f"  [{t.task_id[:8]}] {t.name} ({status})")
        if t.description:
            lines.append(f"             {t.description[:120]}")
        lines.append(f"             Schedule: {t.cron_expr}")
        if t.last_run_at:
            lines.append(
                f"             Last run: {t.last_run_at.strftime('%b %d, %Y %H:%M')}"
            )
    lines.append("")

    return ToolResult(
        tool_name="list_reminders",
        success=True,
        content="\n".join(lines),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# self_state — rich runtime self-state snapshot
# ---------------------------------------------------------------------------


@_handler("self_state")
def _self_state(arguments: dict[str, Any]) -> ToolResult:
    """Return rich runtime self-state for Memex itself."""
    del arguments  # No parameters currently supported.

    provider = _STORES.get("self_state_provider")
    if provider is None:
        return ToolResult(
            tool_name="self_state",
            success=False,
            content="",
            error="Self-state provider not configured",
            source="builtin",
            duration_ms=0,
        )

    state = provider(_resolve_caller())
    return ToolResult(
        tool_name="self_state",
        success=True,
        content=json.dumps(state, indent=2, sort_keys=True, default=str),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# cost_report — historical cost/spending query
# ---------------------------------------------------------------------------


@_handler("cost_report")
def _cost_report(arguments: dict[str, Any]) -> ToolResult:
    """Query historical LLM spending from the event store."""
    days = arguments.get("days", 7)
    days = max(1, min(days, 365))

    return ToolResult(
        tool_name="cost_report",
        success=False,
        content="",
        error="Event store not available (quickstarter removed)",
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# search_logs — search Memex's own log files
# ---------------------------------------------------------------------------

_LOG_LEVEL_ORDER = {"DEBUG": 0, "INFO": 1, "WARNING": 2, "ERROR": 3}
_LOG_LINE_RE = __import__("re").compile(
    r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+(DEBUG|INFO|WARNING|ERROR)\s+"
)


@_handler("search_logs")
def _search_logs(arguments: dict[str, Any]) -> ToolResult:
    """Search Memex log files for errors, warnings, and diagnostic events."""
    import os
    from pathlib import Path

    query = arguments.get("query", "").strip()
    if not query:
        return ToolResult(
            tool_name="search_logs",
            success=False,
            content="",
            error="Missing required parameter: query",
            source="builtin",
            duration_ms=0,
        )

    level_str = (arguments.get("level") or "WARNING").upper()
    min_level = _LOG_LEVEL_ORDER.get(level_str, _LOG_LEVEL_ORDER["WARNING"])
    hours = int(arguments.get("hours") or 24)
    context_lines = int(arguments.get("context_lines") or 2)

    log_dir = Path(os.environ.get("MEMEX_LOG_DIR", str(Path.cwd() / "log")))
    if not log_dir.exists():
        return ToolResult(
            tool_name="search_logs",
            success=True,
            content=f"Log directory not found: {log_dir}",
            source="builtin",
            duration_ms=0,
        )

    cutoff = utcnow() - timedelta(hours=hours)
    log_files = sorted(
        (
            f
            for f in log_dir.glob("*-memex.log")
            if f.stat().st_mtime >= cutoff.timestamp()
        ),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )

    if not log_files:
        return ToolResult(
            tool_name="search_logs",
            success=True,
            content=f"No log files found in {log_dir} within the last {hours}h.",
            source="builtin",
            duration_ms=0,
        )

    results: list[str] = []
    total_matches = 0
    MAX_MATCHES = 100
    MAX_CHARS = 40_000
    query_lower = query.lower()

    for log_file in log_files:
        try:
            lines = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            continue

        file_results: list[str] = []
        line_buffer: list[str] = []  # rolling context window

        i = 0
        while i < len(lines) and total_matches < MAX_MATCHES:
            line = lines[i]
            m = _LOG_LINE_RE.match(line)

            if m:
                level_name = m.group(2)
                line_level = _LOG_LEVEL_ORDER.get(level_name, 0)
                passes_level = line_level >= min_level
                passes_query = query_lower in line.lower()

                if passes_level and passes_query:
                    # Include context lines before match
                    block: list[str] = (
                        list(line_buffer[-context_lines:]) if context_lines else []
                    )
                    block.append(line)
                    # Capture continuation lines (traceback / wrapped lines)
                    j = i + 1
                    while j < len(lines) and not _LOG_LINE_RE.match(lines[j]):
                        block.append(lines[j])
                        j += 1
                    file_results.append("\n".join(block))
                    total_matches += 1
                    i = j
                    line_buffer = []
                    continue

                # Update rolling context buffer (only timestamped lines)
                if len(line_buffer) >= context_lines:
                    line_buffer = line_buffer[-(context_lines - 1) :]
                line_buffer.append(line)
            else:
                # Non-timestamped continuation line — add to buffer (but don't count as context)
                if len(line_buffer) >= context_lines:
                    line_buffer = line_buffer[-(context_lines - 1) :]
                line_buffer.append(line)

            i += 1

        if file_results:
            results.append(f"[{log_file.name}]")
            results.extend(file_results)

    if not results:
        return ToolResult(
            tool_name="search_logs",
            success=True,
            content=f"No matches for {query!r} at level>={level_str} in the last {hours}h.",
            source="builtin",
            duration_ms=0,
        )

    output = "\n\n".join(results)
    if len(output) > MAX_CHARS:
        output = output[:MAX_CHARS] + f"\n... [truncated at {MAX_CHARS} chars]"
    if total_matches >= MAX_MATCHES:
        output += f"\n\n[Showing first {MAX_MATCHES} matches — narrow your query for more specific results]"

    return ToolResult(
        tool_name="search_logs",
        success=True,
        content=output,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# replay — inspect and reprocess the incoming message backlog (all sources)
# ---------------------------------------------------------------------------


@_handler("replay")
def _replay_messages(arguments: dict[str, Any]) -> ToolResult:
    """Inspect and reprocess the incoming message backlog across all sources."""
    action = arguments.get("action", "list")
    hours = int(arguments.get("hours") or 24)
    limit = int(arguments.get("limit") or 20)
    source_filter = arguments.get("source")
    intake_ids = arguments.get("intake_ids") or []
    statuses_filter = arguments.get("statuses")

    intake = _STORES.get("intake")
    scheduler = _STORES.get("scheduler")
    memex_store = _STORES.get("goal")

    if action == "prompt_control":
        if memex_store is None:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="Goal store not available for prompt-control replay",
                source="builtin",
                duration_ms=0,
            )
        session_id = str(arguments.get("session_id") or "").strip()
        if not session_id:
            current = memex_store.load_session()
            session_id = current.session_id if current is not None else ""
        if not session_id:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="session_id required when no current session is loaded",
                source="builtin",
                duration_ms=0,
            )
        artifacts = memex_store.list_prompt_control_artifacts(session_id, limit=limit)
        if not artifacts:
            return ToolResult(
                tool_name="replay",
                success=True,
                content=f"No prompt-control artifacts found for session {session_id}.",
                source="builtin",
                duration_ms=0,
            )
        actions = memex_store.list_world_model_actions(
            session_id=session_id, limit=max(limit * 5, 20)
        )
        observations = memex_store.list_world_model_observations(
            session_id=session_id,
            limit=max(limit * 10, 20),
        )
        observations_by_action: dict[str, list[Any]] = {}
        for observation in observations:
            observations_by_action.setdefault(observation.action_id, []).append(
                observation
            )
        action_provenance_by_id: dict[str, list[Any]] = {}
        observation_provenance_by_id: dict[str, list[Any]] = {}
        for action_row in actions:
            action_provenance_by_id[action_row.action_id] = (
                memex_store.list_world_model_provenance_links(
                    source_record_id=action_row.action_id,
                    source_record_type="world_model_action",
                )
            )
        for observation in observations:
            observation_provenance_by_id[observation.observation_id] = (
                memex_store.list_world_model_provenance_links(
                    source_record_id=observation.observation_id,
                    source_record_type="world_model_observation",
                )
            )

        lines = [f"Prompt-control replay for session {session_id}\n"]
        for artifact in artifacts:
            tools = ", ".join(artifact.tool_candidate_names) or "-"
            lines.append(
                f"turn={artifact.conversation_turn_id or '-'} | "
                f"route={artifact.route_profile.value} | "
                f"path={artifact.selected_path} | "
                f"tools={tools}"
            )
            lines.append(f"  input: {artifact.raw_input}")
            if artifact.route_rationale:
                lines.append(f"  rationale: {artifact.route_rationale}")
            if artifact.plan_snapshot is not None:
                lines.append(
                    "  plan: "
                    f"{artifact.plan_snapshot.title} [{artifact.plan_snapshot.status}]"
                )
                if artifact.plan_snapshot.selected_step is not None:
                    selected_step = artifact.plan_snapshot.selected_step
                    bits = [selected_step.status]
                    if selected_step.progress_pct > 0:
                        bits.append(f"{selected_step.progress_pct}%")
                    lines.append(f"  step: {selected_step.title} [{', '.join(bits)}]")
                    if selected_step.blocked_reason:
                        lines.append(f"  blocker: {selected_step.blocked_reason}")
            artifact_actions = [
                action_row
                for action_row in actions
                if action_row.prompt_control_artifact_id == artifact.artifact_id
            ]
            if not artifact_actions:
                lines.append("  actions: none")
                continue
            for action_row in artifact_actions:
                lines.append(
                    f"  action {action_row.action_name} | {action_row.status} | "
                    f"kind={action_row.action_kind}"
                )
                lines.append(f"    id: world_model_action:{action_row.action_id}")
                payload = (
                    action_row.payload if isinstance(action_row.payload, dict) else {}
                )
                selected_action = payload.get("selected_action")
                if isinstance(selected_action, dict):
                    selected_kind = (
                        str(selected_action.get("kind") or "").strip() or "-"
                    )
                    selected_name = (
                        str(selected_action.get("name") or "").strip() or "-"
                    )
                    lines.append(f"    selected {selected_kind} | {selected_name}")
                action_candidates = payload.get("action_candidates")
                if isinstance(action_candidates, list) and action_candidates:
                    rendered_candidates: list[str] = []
                    for candidate in action_candidates:
                        if not isinstance(candidate, dict):
                            continue
                        name = str(candidate.get("name") or "").strip()
                        if not name:
                            continue
                        rendered_candidates.append(
                            f"{name}[selected]" if candidate.get("selected") else name
                        )
                    if rendered_candidates:
                        lines.append(
                            f"    candidates: {', '.join(rendered_candidates)}"
                        )
                for link in sorted(
                    action_provenance_by_id.get(action_row.action_id, []),
                    key=lambda item: (
                        item.relationship,
                        item.target_record_type,
                        item.target_record_id,
                    ),
                ):
                    lines.append(
                        f"    provenance {link.relationship} {link.target_record_type} | "
                        f"{link.target_record_id}"
                    )
                for observation in observations_by_action.get(action_row.action_id, []):
                    summary = observation.summary or "-"
                    lines.append(
                        f"    observation {observation.observation_kind} | "
                        f"{observation.status} | {summary}"
                    )
                    for link in sorted(
                        observation_provenance_by_id.get(
                            observation.observation_id, []
                        ),
                        key=lambda item: (
                            item.relationship,
                            item.target_record_type,
                            item.target_record_id,
                        ),
                    ):
                        lines.append(
                            f"      provenance {link.relationship} {link.target_record_type} | "
                            f"{link.target_record_id}"
                        )
            lines.append("")

        return ToolResult(
            tool_name="replay",
            success=True,
            content="\n".join(lines).rstrip(),
            source="builtin",
            duration_ms=0,
        )

    # Neither store available — can't do anything
    if intake is None and scheduler is None:
        return ToolResult(
            tool_name="replay",
            success=False,
            content="",
            error="Intake store not available",
            source="builtin",
            duration_ms=0,
        )

    # --- reprocess action ---
    if action == "reprocess":
        if not intake_ids:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="intake_ids required for reprocess action",
                source="builtin",
                duration_ms=0,
            )
        enqueue_fn = _STORES.get("enqueue_fn")
        if intake is None or enqueue_fn is None:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="Intake store and enqueue function required for reprocess",
                source="builtin",
                duration_ms=0,
            )
        requeued = 0
        for iid in intake_ids:
            try:
                entry = intake.get(int(iid))
                if entry is None:
                    continue
                # Don't re-enqueue entries that are already handled or in-flight
                if entry["status"] in ("processed", "dismissed", "queued"):
                    continue
                ad = json.loads(entry["action_data"] or "{}")
                ad["intake_id"] = int(iid)
                run_id = enqueue_fn(entry["action_type"], ad)
                if run_id is not None:
                    intake.mark_queued(int(iid), run_id)
                    requeued += 1
            except Exception:
                logger.debug("Failed to requeue intake_id=%s", iid, exc_info=True)
        return ToolResult(
            tool_name="replay",
            success=True,
            content=f"Requeued {requeued} message(s) for processing.",
            source="builtin",
            duration_ms=0,
        )

    # --- dismiss action ---
    if action == "dismiss":
        if not intake_ids:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="intake_ids required for dismiss action",
                source="builtin",
                duration_ms=0,
            )
        if intake is None:
            return ToolResult(
                tool_name="replay",
                success=False,
                content="",
                error="Intake store not available for dismiss",
                source="builtin",
                duration_ms=0,
            )
        dismissed = 0
        for iid in intake_ids:
            try:
                intake.mark_dismissed(int(iid))
                dismissed += 1
            except Exception:
                pass
        return ToolResult(
            tool_name="replay",
            success=True,
            content=f"Dismissed {dismissed} message(s) from backlog.",
            source="builtin",
            duration_ms=0,
        )

    # --- list action (default) ---
    if intake is not None:
        # Primary path: query intake_log
        # "received" is transient (milliseconds between record and mark_processed);
        # excluding it by default prevents stuck-in-transit entries from showing as
        # actionable backlog items.
        default_statuses = ["queued", "failed"]
        query_statuses = statuses_filter if statuses_filter else default_statuses
        rows = intake.get_recent(
            source=source_filter,
            statuses=query_statuses,
            hours=hours,
            limit=limit,
        )

        if not rows:
            source_label = f" from {source_filter}" if source_filter else ""
            return ToolResult(
                tool_name="replay",
                success=True,
                content=f"No pending messages{source_label} in the last {hours}h.",
                source="builtin",
                duration_ms=0,
            )

        by_status: dict[str, list[dict]] = {}
        for r in rows:
            by_status.setdefault(r["status"], []).append(r)

        source_label = f" ({source_filter})" if source_filter else ""
        lines = [f"Incoming Message Backlog{source_label} (last {hours}h)\n"]

        for status_key in ("failed", "queued", "received"):
            group = by_status.get(status_key, [])
            if not group:
                continue
            label = {
                "failed": "FAILED — exhausted retries, won't retry automatically",
                "queued": "QUEUED — pending automatic retry",
                "received": "RECEIVED — not yet processed",
            }.get(status_key, status_key.upper())
            lines.append(f"{label} ({len(group)}):")
            for r in group:
                ad = json.loads(r["action_data"] or "{}")
                ts = (r["received_at"] or "")[:16]
                src = r["source"]
                iid = r["id"]
                # Show relevant content preview based on source
                preview = (
                    ad.get("text") or ad.get("title") or ad.get("source_url") or ""
                )
                preview = preview[:100]
                lines.append(f"  intake_id={iid} | {src} | {ts} | {preview!r}")
                err = r.get("error") or ""
                if err:
                    lines.append(f"    error: {err[:80]}")
            lines.append("")

        sample_ids = ", ".join(str(r["id"]) for r in rows[:3])
        lines.append(
            f'replay(action="reprocess", intake_ids=[{sample_ids}...]) to re-run failed messages.\n'
            f'replay(action="dismiss", intake_ids=[{sample_ids}...]) to clear from backlog.'
        )
    else:
        # Fallback: query task_runs directly when intake_store is not configured.
        rows_tr = scheduler.get_runs_by_action_type(
            "telegram_message",
            statuses=["queued", "failed"],
            hours=hours,
            limit=limit,
        )
        if not rows_tr:
            return ToolResult(
                tool_name="replay",
                success=True,
                content=f"No pending Telegram messages in the last {hours}h.",
                source="builtin",
                duration_ms=0,
            )

        failed = [r for r in rows_tr if r["status"] == "failed"]
        queued = [r for r in rows_tr if r["status"] == "queued"]
        lines = [f"Telegram Message Backlog (last {hours}h)\n"]

        if failed:
            lines.append(
                f"FAILED ({len(failed)}) — exhausted retries, won't retry automatically:"
            )
            for r in failed:
                data = json.loads(r["action_data"] or "{}")
                text = data.get("text", "")[:120]
                ts = (r["queued_at"] or "")[:16]
                err = (r["error"] or "")[:80]
                lines.append(f"  run_id={r['run_id']} | {ts} | {text!r}")
                if err:
                    lines.append(f"    error: {err}")
            lines.append("")

        if queued:
            lines.append(f"QUEUED ({len(queued)}) — pending automatic retry:")
            for r in queued:
                data = json.loads(r["action_data"] or "{}")
                text = data.get("text", "")[:120]
                ts = (r["queued_at"] or "")[:16]
                lines.append(f"  run_id={r['run_id']} | {ts} | {text!r}")
            lines.append("")

        lines.append(
            "Use ingest_url, remember, or other tools to act on these messages.\n"
            "Note: dismiss is unavailable without intake_store (upgrade required)."
        )

    return ToolResult(
        tool_name="replay",
        success=True,
        content="\n".join(lines),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# self_diagnostics — structured read-only health check
# ---------------------------------------------------------------------------


@_handler("settings")
def _settings(arguments: dict[str, Any]) -> ToolResult:
    action = arguments.get("action", "list")
    store = _STORES.get("settings")

    if action == "list_devices":
        try:
            import sounddevice as sd

            devices = sd.query_devices()
            lines = ["Available audio input devices:"]
            for i, d in enumerate(devices):
                if d["max_input_channels"] > 0:
                    default = " ← default" if i == sd.default.device[0] else ""
                    lines.append(f"  [{i}] {d['name']}{default}")
            return ToolResult(
                tool_name="settings",
                success=True,
                content="\n".join(lines),
                source="builtin",
                duration_ms=0,
            )
        except ImportError:
            return ToolResult(
                tool_name="settings",
                success=False,
                content="",
                error="sounddevice not installed (pip install memex-claw[audio])",
                source="builtin",
                duration_ms=0,
            )
        except Exception as exc:
            return ToolResult(
                tool_name="settings",
                success=False,
                content="",
                error=str(exc),
                source="builtin",
                duration_ms=0,
            )

    if store is None:
        return ToolResult(
            tool_name="settings",
            success=False,
            content="",
            error="Settings store not available",
            source="builtin",
            duration_ms=0,
        )

    key = arguments.get("key", "").strip()
    value = arguments.get("value", "")

    if action == "list":
        rows = store.list_all()
        if not rows:
            return ToolResult(
                tool_name="settings",
                success=True,
                content="No settings stored (all values are defaults).",
                source="builtin",
                duration_ms=0,
            )
        lines = ["Stored settings (override env vars and defaults):"]
        for r in rows:
            lines.append(f"  {r['key']} = {r['value']}")
        return ToolResult(
            tool_name="settings",
            success=True,
            content="\n".join(lines),
            source="builtin",
            duration_ms=0,
        )

    if not key:
        return ToolResult(
            tool_name="settings",
            success=False,
            content="",
            error="Missing required parameter: key",
            source="builtin",
            duration_ms=0,
        )

    if action == "get":
        current = store.get(key)
        if current is None:
            return ToolResult(
                tool_name="settings",
                success=True,
                content=f"{key} is not set (using env/default)",
                source="builtin",
                duration_ms=0,
            )
        return ToolResult(
            tool_name="settings",
            success=True,
            content=f"{key} = {current}",
            source="builtin",
            duration_ms=0,
        )

    if action == "set":
        if value == "":
            return ToolResult(
                tool_name="settings",
                success=False,
                content="",
                error="Missing required parameter: value",
                source="builtin",
                duration_ms=0,
            )
        store.set(key, value)
        return ToolResult(
            tool_name="settings",
            success=True,
            content=f"Set {key} = {value}",
            source="builtin",
            duration_ms=0,
        )

    if action == "delete":
        existed = store.delete(key)
        msg = f"Deleted {key}" if existed else f"{key} was not set"
        return ToolResult(
            tool_name="settings",
            success=True,
            content=msg,
            source="builtin",
            duration_ms=0,
        )

    return ToolResult(
        tool_name="settings",
        success=False,
        content="",
        error=f"Unknown action: {action}",
        source="builtin",
        duration_ms=0,
    )


@_handler("self_diagnostics")
def _self_diagnostics(arguments: dict[str, Any]) -> ToolResult:
    provider = _STORES.get("diagnostics_provider")
    if provider is None:
        return ToolResult(
            tool_name="self_diagnostics",
            success=False,
            content="",
            error="Diagnostics provider not configured",
            source="builtin",
            duration_ms=0,
        )
    checks = arguments.get("checks")
    if checks is not None and not isinstance(checks, list):
        checks = None
    result = provider(checks)
    icons = {"ok": "+", "warn": "!", "fail": "X"}
    lines = ["System Diagnostics:"]
    for c in result.get("checks", []):
        icon = icons.get(c["status"], "?")
        line = f"  [{icon}] {c['name']}"
        if c["detail"]:
            line += f": {c['detail']}"
        lines.append(line)
    lines.append(
        "\nAll checks passed." if result.get("ok") else "\nSome checks need attention."
    )
    return ToolResult(
        tool_name="self_diagnostics",
        success=True,
        content="\n".join(lines),
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# self_repair — narrow self-repair actions
# ---------------------------------------------------------------------------


@_handler("self_repair")
def _self_repair(arguments: dict[str, Any]) -> ToolResult:
    provider = _STORES.get("repair_provider")
    if provider is None:
        return ToolResult(
            tool_name="self_repair",
            success=False,
            content="",
            error="Repair provider not configured",
            source="builtin",
            duration_ms=0,
        )
    action = arguments.get("action", "")
    if not action:
        return ToolResult(
            tool_name="self_repair",
            success=False,
            content="",
            error="Missing required parameter: action",
            source="builtin",
            duration_ms=0,
        )
    result = provider(action)
    icon = "+" if result.get("ok") else "X"
    content = f"[{icon}] {result.get('action', action)}: {result.get('detail', '')}"
    return ToolResult(
        tool_name="self_repair",
        success=result.get("ok", False),
        content=content,
        source="builtin",
        duration_ms=0,
    )


# ---------------------------------------------------------------------------
# Tool definitions for registration
# ---------------------------------------------------------------------------

BUILTIN_TOOLS: list[ToolDefinition] = [
    ToolDefinition(
        name="ingest_url",
        description=(
            "Fetch a web page or YouTube video, extract its content, and save it to the knowledge store. "
            "Supports regular web pages (via trafilatura) and YouTube URLs (extracts transcript + metadata via yt-dlp). "
            "Use this when the user shares a URL or YouTube link they want summarized, remembered, or referenced later. "
            "Returns the extracted title and item ID."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch and ingest",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional tags to categorize the content",
                },
                "item_type": {
                    "type": "string",
                    "enum": ["article", "note", "reference", "snippet"],
                    "description": "Content type (default: article)",
                },
            },
            "required": ["url"],
        },
        source="builtin",
        required_capability="builtin.write",
        capability_tags=["content.web", "memory.write"],
        supported_intent_paths=["act"],
        keywords=[
            "ingest",
            "save",
            "bookmark",
            "capture",
            "url",
            "link",
            "article",
            "read_later",
            "remember",
            "store",
            "youtube",
            "video",
            "transcript",
            "yt",
        ],
    ),
    ToolDefinition(
        name="gmail_search",
        description=(
            "Search Gmail messages and ingest them into the knowledge store. "
            "Use the structured parameters below — the Gmail query is built automatically. "
            "Label filter is auto-applied. URLs in email bodies are extracted and ingested."
        ),
        parameters={
            "type": "object",
            "properties": {
                "from_address": {
                    "type": "string",
                    "description": "Sender email address to filter by. Use the exact address the user provides.",
                },
                "to_address": {
                    "type": "string",
                    "description": "Recipient email address to filter by.",
                },
                "subject": {
                    "type": "string",
                    "description": "Words to match in the subject line.",
                },
                "after": {
                    "type": "string",
                    "description": "Only messages after this date (YYYY/MM/DD format).",
                },
                "before": {
                    "type": "string",
                    "description": "Only messages before this date (YYYY/MM/DD format).",
                },
                "newer_than": {
                    "type": "string",
                    "description": "Messages from the last N days/months (e.g. '7d', '1m').",
                },
                "query": {
                    "type": "string",
                    "description": "Additional raw Gmail search terms (has:attachment, filename:pdf, etc.).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of messages to fetch (default: 10, max: 50).",
                    "default": 10,
                },
            },
        },
        source="builtin",
        required_capability="builtin.write",
        capability_tags=["comm.gmail", "memory.write"],
        supported_intent_paths=["act"],
        keywords=[
            "gmail",
            "email",
            "mail",
            "inbox",
            "sent",
            "messages",
            "label",
            "notes",
        ],
    ),
    ToolDefinition(
        name="web_fetch",
        description=(
            "Fetch a web page or YouTube video and return its extracted text content. "
            "Supports regular web pages (via trafilatura) and YouTube URLs (extracts transcript). "
            "Use for retrieving information from URLs without saving to the knowledge store."
        ),
        parameters={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to fetch",
                },
            },
            "required": ["url"],
        },
        source="builtin",
        required_capability="builtin.read",
        capability_tags=["content.web", "web.fetch"],
        preferred_classifications=["knowledge_query"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "url",
            "web",
            "fetch",
            "http",
            "page",
            "website",
            "link",
            "browse",
            "download",
            "youtube",
            "video",
            "summarize",
            "read",
            "content",
        ],
    ),
    ToolDefinition(
        name="file_transform",
        description=(
            "Read one or more files, transform their content via a dedicated LLM call, "
            "and write the result to an output file. Use this for large file operations "
            "(merge, rewrite, consolidate, reformat) to avoid filling the conversation context. "
            "The file content never enters the main conversation — only a summary is returned."
        ),
        parameters={
            "type": "object",
            "properties": {
                "input_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File paths to read as input.",
                },
                "output_path": {
                    "type": "string",
                    "description": "File path to write the transformed output.",
                },
                "instructions": {
                    "type": "string",
                    "description": (
                        "Detailed instructions for the transformation. Be specific about "
                        "what to change, preserve, merge, or reformat."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": "Optional LLM model override for the transformation.",
                },
            },
            "required": ["input_paths", "output_path", "instructions"],
        },
        source="builtin",
        required_capability="builtin.file_transform",
        keywords=[
            "file",
            "transform",
            "merge",
            "combine",
            "consolidate",
            "rewrite",
            "reformat",
            "convert",
            "edit",
            "modify",
            "extract",
            "summarize",
        ],
    ),
    ToolDefinition(
        name="search_conversations",
        description=(
            "Search past conversations and chat history across all interfaces "
            "(Telegram, TUI, CLI). Use this when the user asks about something "
            "they said or discussed earlier, or to find messages from previous sessions. "
            "Returns matching messages with timestamps, roles, and context snippets."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query — keywords or phrases to find in past conversations.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default: 20, max: 50).",
                    "default": 20,
                },
                "days_back": {
                    "type": "integer",
                    "description": "Only search conversations from the last N days.",
                },
            },
            "required": ["query"],
        },
        source="builtin",
        required_capability="builtin.read",
        capability_tags=["conversation.search"],
        preferred_classifications=["knowledge_query"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "conversation",
            "chat",
            "said",
            "discussed",
            "talked",
            "earlier",
            "yesterday",
            "history",
            "message",
            "told you",
            "mentioned",
            "asked",
            "previous",
            "when did i",
            "last time",
            "we talked about",
            "did i say",
        ],
    ),
    ToolDefinition(
        name="search_knowledge",
        description=(
            "Search Memex's canonical retrieval surface for previously saved knowledge, semantic "
            "documents, reminders/tasks, commitments, articles, YouTube transcripts, bookmarks, "
            "notes, and conversations. Returns matching documents with titles, relevance "
            "scores, and content snippets. This is a READ-ONLY search. "
            "BEFORE searching, check: (1) If an item was just ingested in this session, prefer "
            "get_item with its ID — it is faster and guaranteed to find the right item. "
            "(2) If the conversation already contains the needed information, do NOT search. "
            "When you do search, use specific titles or phrases rather than generic keywords."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query — keywords, phrases, or topics to find in the knowledge store.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 10, max: 25).",
                    "default": 10,
                },
            },
            "required": ["query"],
        },
        source="builtin",
        required_capability="builtin.read",
        always_present=True,
        capability_tags=["memory.search"],
        preferred_classifications=["knowledge_query"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "search",
            "find",
            "recall",
            "lookup",
            "check",
            "query",
            "what do you know",
            "stored",
            "saved",
            "in memory",
            "do you remember",
            "knowledge",
            "retrieve",
            "what was",
            "notes about",
            "articles",
            "bookmarks",
        ],
    ),
    ToolDefinition(
        name="get_item",
        description=(
            "Retrieve a specific document by ID. Prefer IDs returned by search_knowledge "
            "or replay, such as world_model_knowledge:..., world_model_action:..., "
            "world_model_goal:..., world_model_action_plan:..., world_model_plan_step:..., world_model_task:..., world_model_commitment:..., world_model_dependency:..., world_model_claim_evaluation:..., or content_item:.... "
            "Raw live item IDs are only for direct ingest-style follow-up."
        ),
        parameters={
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "A document ID such as world_model_knowledge:..., world_model_action:..., world_model_goal:..., world_model_action_plan:..., world_model_plan_step:..., world_model_task:..., world_model_commitment:..., world_model_dependency:..., world_model_claim_evaluation:..., or content_item:....",
                },
            },
            "required": ["id"],
        },
        source="builtin",
        required_capability="builtin.read",
        keywords=[
            "get",
            "retrieve",
            "fetch",
            "item",
            "by id",
            "the article",
            "the video",
            "that item",
            "just ingested",
        ],
    ),
    ToolDefinition(
        name="list_goals",
        description=(
            "List the user's goals and intents. Shows active goals by default. "
            "Use include_all=true to see completed, abandoned, and paused goals too."
        ),
        parameters={
            "type": "object",
            "properties": {
                "include_all": {
                    "type": "boolean",
                    "description": "If true, include goals of all statuses (not just active). Default: false.",
                    "default": False,
                },
            },
        },
        source="builtin",
        required_capability="builtin.read",
        capability_tags=["goals.read"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "goals",
            "intents",
            "objectives",
            "priorities",
            "plans",
            "what am I working on",
            "active goals",
            "todo",
            "tracking",
            "progress",
            "status",
        ],
    ),
    ToolDefinition(
        name="list_reminders",
        description=(
            "List the user's scheduled reminders and tasks. "
            "Shows enabled reminders by default. Use include_disabled=true to see all."
        ),
        parameters={
            "type": "object",
            "properties": {
                "include_disabled": {
                    "type": "boolean",
                    "description": "If true, include disabled/completed reminders. Default: false.",
                    "default": False,
                },
            },
        },
        source="builtin",
        required_capability="builtin.read",
        capability_tags=["reminders.read"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "reminders",
            "scheduled",
            "tasks",
            "upcoming",
            "calendar",
            "what's coming up",
            "agenda",
            "appointments",
            "due",
            "deadline",
            "alert",
            "notification",
        ],
    ),
    ToolDefinition(
        name="self_state",
        description=(
            "Inspect Memex's own live runtime state. Returns a rich JSON snapshot including "
            "process info, goal counts, session info, interfaces, services, connectors, "
            "plugins, queues, activities, meeting runtime, sub-agents, and recent errors. "
            "Use this when the user asks about Memex's current status, capabilities, degraded mode, "
            "what is running, whether a connector or service is connected, or what Memex knows about itself."
        ),
        parameters={
            "type": "object",
            "properties": {},
        },
        source="builtin",
        required_capability="builtin.read",
        always_present=True,
        capability_tags=["system.inspect"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "self",
            "yourself",
            "state",
            "status",
            "runtime",
            "system",
            "what do you know about yourself",
            "self knowledge",
            "connectors",
            "services",
            "plugins",
            "queues",
            "degraded",
            "what is running",
            "your current state",
        ],
    ),
    ToolDefinition(
        name="remember",
        description=(
            "WRITE to long-term memory — save a new fact, context snapshot, or reminder. "
            "Use when the user says 'remember this', 'save this', 'remind me', "
            "or wants to store a fact, preference, or scheduled reminder. "
            "To SEARCH existing memory, use search_knowledge instead."
        ),
        parameters={
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": (
                        "What to remember. Can be a fact ('the API key is X'), "
                        "a context reference ('this conversation', 'what we discussed'), "
                        "or a reminder ('to call mom Tuesday at 3pm')."
                    ),
                },
            },
            "required": ["text"],
        },
        source="builtin",
        required_capability="builtin.write",
        always_present=True,
        capability_tags=["memory.write"],
        supported_intent_paths=["act"],
        keywords=[
            "remember",
            "save",
            "store",
            "note",
            "remind",
            "reminder",
            "don't forget",
            "keep in mind",
            "bookmark",
            "capture",
            "schedule",
            "calendar",
            "appointment",
            "todo",
            "keep",
            "log",
            "jot down",
            "make a note",
        ],
    ),
    ToolDefinition(
        name="cost_report",
        description=(
            "Report LLM usage cost over a time period. Shows total spend, "
            "per-turn average, and daily breakdown. Use when the user asks about "
            "spending, cost, budget, or how much they have used."
        ),
        parameters={
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Number of days to look back (default: 7, max: 365).",
                    "default": 7,
                },
            },
        },
        source="builtin",
        required_capability="builtin.read",
        keywords=[
            "cost",
            "spending",
            "spend",
            "budget",
            "usage",
            "tokens",
            "how much",
            "dollars",
            "price",
            "expensive",
            "bill",
        ],
    ),
    ToolDefinition(
        name="forget",
        description=(
            "DELETE items from the knowledge store. This is a DESTRUCTIVE operation. "
            "Do NOT use this to search or look up items — use search_knowledge for that. "
            "Workflow: first searches for matching items, then soft-deletes selected ones. "
            "Items are permanently removed after 1 hour. Use action='undo' to restore."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What to forget — search query to find items to DELETE.",
                },
                "action": {
                    "type": "string",
                    "enum": ["search", "select", "undo"],
                    "description": (
                        "Action to perform: "
                        "'search' finds items to delete (default), "
                        "'select' confirms deletion (pass ids), "
                        "'undo' restores soft-deleted items."
                    ),
                    "default": "search",
                },
                "ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Selection IDs to delete or restore (for select/undo actions). "
                        "For knowledge items, prefer canonical IDs such as "
                        "world_model_knowledge:knowledge/... or explicit live-item IDs "
                        "such as content_item:..."
                    ),
                },
            },
            "required": ["query"],
        },
        source="builtin",
        required_capability="builtin.write",
        keywords=[
            "forget",
            "delete",
            "remove",
            "purge",
            "erase",
            "redact",
            "sensitive",
            "undo forget",
            "restore",
        ],
    ),
    ToolDefinition(
        name="replay",
        description=(
            "Inspect and reprocess the incoming message backlog across all sources (Telegram, "
            "Gmail). Lists messages by receipt status — queued, failed, processed. Use "
            "`reprocess` to re-run failed messages through the full LLM or ingest pipeline. "
            "Use `dismiss` to clear entries. Use `prompt_control` to inspect replayable "
            "prompt-control artifacts and their canonical action / observation rows for a "
            "session. For searching message content, use "
            "`search_conversations` instead."
        ),
        parameters={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "reprocess", "dismiss", "prompt_control"],
                    "description": (
                        "list (default) returns the backlog. reprocess re-enqueues failed "
                        "messages. dismiss marks entries as cleared. prompt_control "
                        "shows route/debug replay for a session."
                    ),
                    "default": "list",
                },
                "session_id": {
                    "type": "string",
                    "description": (
                        "Session to inspect for prompt_control action. Defaults to the "
                        "currently loaded session when omitted."
                    ),
                },
                "source": {
                    "type": "string",
                    "description": "Filter by source: 'telegram', 'gmail', or omit for all sources.",
                },
                "hours": {
                    "type": "integer",
                    "description": "Hours back to search (default: 24)",
                    "default": 24,
                },
                "limit": {
                    "type": "integer",
                    "description": "Max messages to return (default: 20)",
                    "default": 20,
                },
                "intake_ids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "intake_ids to reprocess or dismiss (required for those actions).",
                },
                "statuses": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Filter by status: received, queued, failed, processed, dismissed. "
                        "Default for list: ['received', 'queued', 'failed']."
                    ),
                },
            },
        },
        source="builtin",
        required_capability="builtin.read",
        keywords=[
            "telegram",
            "gmail",
            "replay",
            "backlog",
            "missed",
            "pending",
            "unprocessed",
            "queued messages",
            "failed messages",
            "catch up",
            "process later",
            "recent messages",
            "incoming messages",
            "what messages came in",
            "reprocess",
            "retry failed",
            "intake",
            "received",
            "prompt control",
            "route replay",
            "debug session",
        ],
    ),
    ToolDefinition(
        name="search_logs",
        description=(
            "Search Memex's own log files for errors, warnings, and diagnostic events. "
            "Use when asked what failed, why something crashed, or to investigate unexpected behavior. "
            "Searches recent session log files by keyword, capturing multi-line tracebacks."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keyword or phrase to search for",
                },
                "level": {
                    "type": "string",
                    "enum": ["ERROR", "WARNING", "INFO", "DEBUG"],
                    "description": "Minimum log level to include (default: WARNING)",
                    "default": "WARNING",
                },
                "hours": {
                    "type": "integer",
                    "description": "How many hours back to search (default: 24)",
                    "default": 24,
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Number of log lines to include before each match (default: 2)",
                    "default": 2,
                },
            },
            "required": ["query"],
        },
        source="builtin",
        required_capability="builtin.read",
        capability_tags=["system.logs"],
        preferred_classifications=["knowledge_query", "clarification"],
        supported_intent_paths=["direct_answer", "act"],
        keywords=[
            "log",
            "error",
            "warning",
            "failed",
            "crash",
            "why",
            "debug",
            "happened",
            "exception",
            "traceback",
            "logs",
            "diagnostic",
        ],
    ),
    ToolDefinition(
        name="self_diagnostics",
        description=(
            "Run targeted system diagnostics. Returns pass/warn/fail per check. "
            "Checks: llm_proxy, scheduler, db, telegram_config, env_vars. "
            "READ-ONLY. Run before self_repair to confirm the problem."
        ),
        parameters={
            "type": "object",
            "properties": {
                "checks": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": [
                            "llm_proxy",
                            "scheduler",
                            "db",
                            "telegram_config",
                            "env_vars",
                        ],
                    },
                    "description": "Subset of checks to run. Omit to run all.",
                },
            },
        },
        source="builtin",
        required_capability="builtin.read",
        always_present=False,
        capability_tags=["system.diagnostics"],
        supported_intent_paths=["act", "direct_answer"],
        keywords=[
            "diagnostics",
            "health",
            "check",
            "system",
            "proxy",
            "llm down",
            "scheduler",
            "database",
            "telegram",
            "environment",
            "debug",
        ],
    ),
    ToolDefinition(
        name="self_repair",
        description=(
            "Execute a targeted self-repair action. WRITE — changes system state. "
            "Actions: reset_proxy (clears proxy-disabled flag, triggers re-probe on next LLM use); "
            "restart_queue (restarts work queue if stopped). "
            "Run self_diagnostics first to confirm the problem."
        ),
        parameters={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["reset_proxy", "restart_queue"],
                    "description": "Repair action to perform.",
                },
            },
            "required": ["action"],
        },
        source="builtin",
        required_capability="builtin.write",
        always_present=False,
        capability_tags=["system.repair"],
        supported_intent_paths=["act"],
        keywords=[
            "repair",
            "fix",
            "reset",
            "restart",
            "recover",
            "proxy down",
            "queue stopped",
            "llm unavailable",
        ],
    ),
    ToolDefinition(
        name="settings",
        description=(
            "Get or set persistent Memex configuration. Changes survive restarts.\n"
            "Known keys:\n"
            "  vad_threshold — speech detection sensitivity for meeting transcription (0.0–1.0, default 0.2). "
            "Lower = more sensitive (picks up quiet speech); higher = stricter (ignores background noise).\n"
            "  recording_device — audio input device name or index for meeting recording (default: system default). "
            "Use action='list_devices' to see available options.\n"
            "Resolution order: stored setting → MEMEX_<KEY> env var → hardcoded default."
        ),
        parameters={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["get", "set", "delete", "list", "list_devices"],
                    "description": "get/set/delete a key, list all stored settings, or list audio input devices",
                },
                "key": {
                    "type": "string",
                    "description": "Setting key (required for get/set/delete)",
                },
                "value": {
                    "type": "string",
                    "description": "New value to store (required for set)",
                },
            },
            "required": ["action"],
        },
        source="builtin",
        required_capability="builtin.write",
        always_present=False,
        keywords=[
            "settings",
            "configure",
            "configuration",
            "vad",
            "vad_threshold",
            "recording device",
            "microphone",
            "input device",
            "audio device",
            "speech threshold",
            "sensitivity",
            "set vad",
            "change vad",
            "list devices",
            "list microphones",
            "device",
        ],
    ),
]
