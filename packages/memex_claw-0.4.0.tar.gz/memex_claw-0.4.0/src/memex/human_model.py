"""Canonical human partner profile helpers for runtime use."""

from __future__ import annotations

from pathlib import Path

from memex.models import HumanPartnerProfile
from memex.store import MemexStore
from memex.utcnow import utcnow


def load_canonical_partner_profile(store: MemexStore) -> HumanPartnerProfile:
    """Load only the canonical partner profile."""
    profile = store.load_partner_profile()
    if profile is not None:
        return profile
    return HumanPartnerProfile()


def load_canonical_speaker_mappings(store: MemexStore) -> dict[str, str]:
    """Load runtime speaker mappings from the canonical partner profile only."""
    return dict(load_canonical_partner_profile(store).working_context.speaker_mappings)


def save_partner_profile(profile: HumanPartnerProfile, store: MemexStore) -> None:
    """Persist the canonical partner profile and sync speaker mappings."""
    profile.updated_at = utcnow()
    store.save_partner_profile(profile)
    _sync_speaker_mappings(profile, store)


def _sync_speaker_mappings(profile: HumanPartnerProfile, store: MemexStore) -> None:
    """Sync speaker_mappings from profile to world-model semantic mappings."""
    mappings = profile.working_context.speaker_mappings
    if not mappings:
        return
    try:
        from memex.models import WorldModelSemanticMapping

        now = utcnow()
        wm_mappings = [
            WorldModelSemanticMapping(
                mapping_id=f"speaker:{speaker_id}",
                mapping_kind="speaker_alias",
                source_value=speaker_id,
                target_value=name,
                scope_type="partner_profile",
                scope_key="speaker_mappings",
                source_surface="c05_semantic_mapping",
                created_at=now,
                updated_at=now,
            )
            for speaker_id, name in mappings.items()
        ]
        store.replace_world_model_semantic_mappings(
            scope_type="partner_profile",
            scope_key="speaker_mappings",
            mappings=wm_mappings,
        )
    except Exception:
        import logging

        logging.getLogger(__name__).debug(
            "Failed to sync speaker mappings", exc_info=True
        )


def format_for_prompt(model: HumanPartnerProfile) -> str:
    """Format canonical partner context for inclusion in the system prompt."""
    if (
        not model.name
        and not model.communication_style
        and not model.explanation_level
        and not model.working_context.timezone
        and not model.working_context.role
        and not model.working_context.team
        and not model.knowledge_profile.preferences
        and not model.knowledge_profile.notes
        and not model.knowledge_profile.expertise
        and not model.working_context.speaker_mappings
    ):
        return ""

    parts: list[str] = ["## About the Human"]
    if model.name:
        parts.append(f"Name: {model.name}")
    if model.communication_style:
        parts.append(f"Communication style: {model.communication_style}")
    if model.explanation_level:
        parts.append(f"Explanation level: {model.explanation_level}")
    if model.working_context.timezone:
        parts.append(f"Timezone: {model.working_context.timezone}")
    if model.working_context.role:
        parts.append(f"Role: {model.working_context.role}")
    if model.working_context.team:
        parts.append(f"Team: {model.working_context.team}")
    if model.knowledge_profile.expertise:
        parts.append("Expertise:")
        for topic in model.knowledge_profile.expertise:
            parts.append(f"  - {topic}")
    if model.knowledge_profile.preferences:
        parts.append("Preferences:")
        for key, value in model.knowledge_profile.preferences.items():
            parts.append(f"  - {key}: {value}")
    if model.knowledge_profile.notes:
        parts.append("Notes:")
        for note in model.knowledge_profile.notes:
            parts.append(f"  - {note}")
    if model.working_context.speaker_mappings:
        parts.append("Known speakers (for meeting transcripts):")
        for speaker_id, name in model.working_context.speaker_mappings.items():
            parts.append(f"  - {speaker_id}: {name}")
    return "\n".join(parts)


def load_user_md(project_root: Path | None = None) -> str:
    """Load USER.md static operator context. Returns empty string if absent."""
    from memex.governance import load_project_file

    return load_project_file("USER.md", project_root, default="") or ""


def format_combined_partner_prompt(
    model: HumanPartnerProfile,
    *,
    project_root: Path | None = None,
) -> str:
    """Combine USER.md (static) with database partner profile (dynamic).

    USER.md content appears first and gets priority within the token budget.
    The database-learned profile follows. If no content from either source,
    returns empty string.
    """
    user_md = load_user_md(project_root)
    db_prompt = format_for_prompt(model)

    parts: list[str] = []
    if user_md:
        parts.append(user_md)
    if db_prompt:
        parts.append(db_prompt)

    if not parts:
        return ""

    return "\n\n".join(parts)
