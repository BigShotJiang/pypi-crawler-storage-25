"""Memex CLI — argparse with always-exit-0 pattern."""

from __future__ import annotations

import argparse
import itertools
import os
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from memex.utcnow import utcnow


class _Spinner:
    """Animated spinner for terminal feedback during LLM calls."""

    _FRAMES = ["thinking", "thinking.", "thinking..", "thinking..."]

    def __init__(self) -> None:
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def __enter__(self) -> _Spinner:
        self._stop.clear()
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join()
        # Clear the spinner line
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()

    def _spin(self) -> None:
        for frame in itertools.cycle(self._FRAMES):
            if self._stop.is_set():
                break
            sys.stderr.write(f"\r\033[K{frame}")
            sys.stderr.flush()
            # Wait in small increments so we can stop quickly
            if self._stop.wait(0.4):
                break


def resolve_store_path() -> str:
    """Resolve the store path from env or default."""
    from memex.paths import resolve_store_path as _canonical

    return _canonical()


# Keep private alias for internal callers
_resolve_store_path = resolve_store_path


def _make_fathom_store(path: str | None = None):
    from memex.fathom_facade import make_fathom_store

    return make_fathom_store(path or _resolve_store_path())


def _cmd_chat(args: argparse.Namespace) -> None:
    """Interactive chat loop."""
    import uuid

    from memex.interfaces.api import MemexAPI
    from memex.interfaces.caller import CallerContext
    from memex.interfaces.formats import SessionMode
    from memex.scheduler import get_session_briefing

    api = MemexAPI.create(_resolve_store_path())
    try:
        session_id = str(uuid.uuid4())
        caller = CallerContext.owner("cli", session_id)

        # Resolve session mode
        mode = None
        if hasattr(args, "mode") and args.mode:
            mode = SessionMode(args.mode)

        # Print connector health
        for h in api.connector_health:
            icon = "+" if h.status == "connected" else "-"
            detail = f" ({h.tools_discovered} tools)" if h.tools_discovered > 0 else ""
            if h.error:
                detail = f" ({h.error})"
            print(f"  [{icon}] {h.name}: {h.status}{detail}")

        # Session briefing
        briefing = get_session_briefing(api.store)
        print(f"\n{briefing}\n")

        session = None
        while True:
            try:
                user_input = input("❯ ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye.")
                break

            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "bye"):
                print("Goodbye.")
                break

            with _Spinner():
                response, session = api.chat(
                    user_input,
                    caller,
                    session=session,
                    mode=mode,
                )
            print(f"\nmemex> {response}\n")

        # End session
        if session is not None:
            try:
                api.end_session(caller)
            except Exception:
                pass
    finally:
        api.close()


def _cmd_goal_list(args: argparse.Namespace) -> None:
    """List goals as a tree."""
    from memex.models import GoalStatus

    store = _make_fathom_store()
    try:
        if args.all:
            goals = store.list_goals()
        else:
            goals = store.list_goals(GoalStatus.ACTIVE)

        if not goals:
            print("No goals found.")
            return

        # Build tree structure
        roots = [g for g in goals if g.parent_id is None]
        children_map: dict[str, list] = {}
        for g in goals:
            if g.parent_id:
                children_map.setdefault(g.parent_id, []).append(g)

        def print_goal(goal, indent: int = 0) -> None:
            prefix = "  " * indent
            status = (
                f" [{goal.status.value}]" if goal.status != GoalStatus.ACTIVE else ""
            )
            priority = f" ({goal.priority.value})"
            print(f"{prefix}- {goal.title}{status}{priority}  [{goal.goal_id[:8]}]")
            for child in children_map.get(goal.goal_id, []):
                print_goal(child, indent + 1)

        for root in roots:
            print_goal(root)
    finally:
        store.close()


def _cmd_goal_show(args: argparse.Namespace) -> None:
    """Show goal details."""
    store = _make_fathom_store()
    try:
        # Support partial IDs
        goal = store.get_goal(args.id)
        if not goal:
            # Try prefix match
            all_goals = store.list_goals()
            matches = [g for g in all_goals if g.goal_id.startswith(args.id)]
            if len(matches) == 1:
                goal = matches[0]
            elif len(matches) > 1:
                print(f"Ambiguous ID '{args.id}', matches:")
                for g in matches:
                    print(f"  {g.goal_id[:8]} — {g.title}")
                return
            else:
                print(f"Goal not found: {args.id}")
                return

        print(f"Title:    {goal.title}")
        print(f"ID:       {goal.goal_id}")
        print(f"Status:   {goal.status.value}")
        print(f"Priority: {goal.priority.value}")
        if goal.parent_id:
            print(f"Parent:   {goal.parent_id[:8]}")
        if goal.description:
            print(f"Description: {goal.description}")
        if goal.blocked_reason:
            print(f"Blocked:  {goal.blocked_reason}")
        if goal.failure_reason:
            print(f"Failed:   {goal.failure_reason}")
        if goal.deadline:
            print(f"Deadline: {goal.deadline}")
        print(f"Created:  {goal.created_at}")
        print(f"Updated:  {goal.updated_at}")
        print(f"Touched:  {goal.last_touched_at}")

        # Show children
        children = store.get_children(goal.goal_id)
        if children:
            print(f"\nSub-goals ({len(children)}):")
            for c in children:
                status = f" [{c.status.value}]" if c.status.value != "active" else ""
                print(f"  - {c.title}{status}  [{c.goal_id[:8]}]")
    finally:
        store.close()


def _cmd_goal_create(args: argparse.Namespace) -> None:
    """Create a goal."""
    import uuid
    from memex.models import Goal, GoalPriority

    store = _make_fathom_store()
    try:
        now = utcnow()
        goal = Goal(
            goal_id=str(uuid.uuid4()),
            parent_id=args.parent,
            title=args.title,
            priority=GoalPriority(args.priority)
            if args.priority
            else GoalPriority.MEDIUM,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        store.create_goal(goal)

        try:
            from memex.event_bus import get_bus
            from memex.events import GoalCreated

            get_bus().publish(
                GoalCreated(
                    goal_id=goal.goal_id, title=goal.title, parent_id=goal.parent_id
                )
            )
        except Exception:
            pass

        print(f"Created: {goal.title}  [{goal.goal_id[:8]}]")
    finally:
        store.close()


def _cmd_session_end(args: argparse.Namespace) -> None:
    """End the current session."""
    from memex.loop import _build_middleware_chain
    from memex.session import end_session, load_session, save_session

    store = _make_fathom_store()
    try:
        session = load_session(store)
        if not session:
            print("No active session.")
            return

        chain = _build_middleware_chain()
        new_session = end_session(session, store, middleware_chain=chain)
        save_session(new_session, store)
        print(f"Ended session {session.session_id[:8]} ({session.turn_count} turns)")
        print(f"New session: {new_session.session_id[:8]}")
    finally:
        store.close()


def _cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest content into knowledge store."""
    from memex.models import ItemType
    from memex.memory.intake import ingest

    # Determine content and source_url from the source argument
    source_url: str | None = None
    if args.source == "-":
        content = sys.stdin.read()
    elif os.path.isfile(args.source):
        with open(args.source, encoding="utf-8") as f:
            content = f.read()
    else:
        source_url = args.source
        try:
            import httpx

            resp = httpx.get(args.source, follow_redirects=True, timeout=30)
            resp.raise_for_status()
            content = resp.text
        except Exception as exc:
            print(f"Failed to fetch {args.source}: {exc}", file=sys.stderr)
            return

    store = _make_fathom_store()
    try:
        item = ingest(
            content,
            type=ItemType(args.type),
            title=args.title,
            source_url=source_url,
            content_store=store.content,
            memex_store=store,
            generate_summary=False,
        )
        print(f"Ingested: {item.title}  [{item.item_id[:8]}]")
    finally:
        store.close()


def _cmd_status_quick(args: argparse.Namespace) -> None:
    """Show quick system status."""
    store = _make_fathom_store()
    try:
        all_goals = store.list_goals()
        active = [g for g in all_goals if g.status.value == "active"]
        session = store.load_session()

        print(f"Store:    {_resolve_store_path()}")
        print("Schema:   fathomdb")
        print(f"Goals:    {len(all_goals)} total, {len(active)} active")
        if session:
            print(f"Session:  {session.session_id[:8]} ({session.turn_count} turns)")
        else:
            print("Session:  none")

        # Connector health
        health_records = store.load_connector_health()
        if health_records:
            print("Connectors:")
            for h in health_records:
                icon = "+" if h.status == "connected" else "-"
                detail = (
                    f" ({h.tools_discovered} tools)" if h.tools_discovered > 0 else ""
                )
                if h.error:
                    detail = f" ({h.error})"
                print(f"  [{icon}] {h.name}: {h.status}{detail}")
    finally:
        store.close()


def _cmd_status(args: argparse.Namespace) -> None:
    """Show comprehensive system status."""
    from memex.interfaces.api import MemexAPI

    print("Memex Status\n")

    api = MemexAPI.create(_resolve_store_path())
    store = api.store

    # Core
    try:
        print(f"  Store:      {_resolve_store_path()} (fathomdb)")
    except Exception as exc:
        print(f"  Store:      {_resolve_store_path()} (error: {exc})")

    try:
        session = store.load_session()
        if session:
            print(
                f"  Session:    {session.session_id[:8]} ({session.turn_count} turns)"
            )
        else:
            print("  Session:    none")
    except Exception as exc:
        print(f"  Session:    error ({exc})")

    try:
        all_goals = store.list_goals()
        active = [g for g in all_goals if g.status.value == "active"]
        print(f"  Goals:      {len(all_goals)} total, {len(active)} active")
    except Exception as exc:
        print(f"  Goals:      error ({exc})")

    print()

    # Knowledge store
    try:
        backend = store.knowledge_backend
        content = store.content
        if hasattr(content, "list_items"):
            print(f"  Knowledge:  {backend}")
        else:
            print(f"  Knowledge:  {backend}")
    except Exception as exc:
        print(f"  Knowledge:  error ({exc})")

    print()

    # Connectors
    try:
        health_records = api.connector_health
        if health_records:
            print("  Connectors:")
            for h in health_records:
                icon = "+" if h.status == "connected" else "-"
                detail = (
                    f" ({h.tools_discovered} tools)" if h.tools_discovered > 0 else ""
                )
                if h.error:
                    detail = f" ({h.error})"
                print(f"    [{icon}] {h.name}: {h.status}{detail}")
            print()
    except Exception:
        pass

    # Skills
    try:
        mw_chain = api._middleware_chain
        if mw_chain and hasattr(mw_chain, "skill_middleware"):
            skill_mw = mw_chain.skill_middleware
            skills = skill_mw._skills.all_skills()
            if skills:
                names = ", ".join(s.name for s in skills[:10])
                extra = f", +{len(skills) - 10} more" if len(skills) > 10 else ""
                print(f"  Skills:     {len(skills)} loaded ({names}{extra})")
            else:
                print("  Skills:     none loaded")
        else:
            print("  Skills:     not initialized")
    except Exception:
        print("  Skills:     error")

    # Middleware
    try:
        if mw_chain and hasattr(mw_chain, "_middleware"):
            mw_list = mw_chain._middleware
            names = ", ".join(type(m).__name__ for m in mw_list)
            print(f"  Middleware:  {len(mw_list)} active ({names})")
    except Exception:
        pass

    # Services
    try:
        svc_mgr = api._service_manager
        if svc_mgr:
            running = list(svc_mgr.running) if hasattr(svc_mgr, "running") else []
            if running:
                names = ", ".join(s.name for s in running)
                print(f"  Services:   {len(running)} running ({names})")
            else:
                print("  Services:   none running")
    except Exception:
        pass

    # Providers
    try:
        from memex.providers_base import CredentialStore

        cred_store = CredentialStore()
        providers = cred_store.list_providers()
        if providers:
            print(f"  Providers:  {', '.join(providers)}")
        else:
            print("  Providers:  none configured")
    except Exception:
        pass

    print()

    # Scheduler
    try:
        sched_tasks = store.scheduler.list_tasks(enabled_only=True)
        print(f"  Scheduler:  {len(sched_tasks)} scheduled tasks")
    except Exception as exc:
        print(f"  Scheduler:  error ({exc})")

    # Auto-ingest sources
    try:
        from memex.auto_ingest.registry import get_default_registry

        registry = get_default_registry()
        sources = registry.list_sources()
        if sources:
            print(f"  Auto-ingest: {', '.join(sources)}")
    except Exception:
        pass

    # Embeddings
    try:
        if api._embedding_backend:
            name = type(api._embedding_backend).__name__
            print(f"  Embeddings: {name}")
        else:
            print("  Embeddings: not available")
    except Exception:
        pass

    print()

    # Cleanup
    try:
        api.close()
    except Exception:
        pass


def _cmd_telegram(args: argparse.Namespace) -> None:
    """Start the Telegram bot in polling mode (deprecated)."""
    print(
        "Deprecated: 'memex telegram' is removed.\n"
        "Telegram is now managed by the memex service daemon.\n"
        "\n"
        "  Start the daemon:   systemctl --user start memex\n"
        "  Check status:       systemctl --user status memex\n"
        "  View logs:          journalctl --user -u memex -f\n"
        "\n"
        "To run the standalone Telegram bot anyway, use --force.",
        file=sys.stderr,
    )
    if not getattr(args, "force", False):
        sys.exit(1)

    from memex.interfaces.api import MemexAPI
    from memex.interfaces.telegram import TelegramBot, config_from_env

    config = config_from_env()
    if config is None:
        print(
            "Telegram not configured. Set TELEGRAM_BOT_TOKEN and "
            "TELEGRAM_USER_ID environment variables.",
            file=sys.stderr,
        )
        return

    api = MemexAPI.create(_resolve_store_path())
    try:
        for h in api.connector_health:
            icon = "+" if h.status == "connected" else "-"
            detail = f" ({h.tools_discovered} tools)" if h.tools_discovered > 0 else ""
            if h.error:
                detail = f" ({h.error})"
            print(f"  [{icon}] {h.name}: {h.status}{detail}")

        print(
            f"\nStarting Telegram bot (polling, {len(config.allowed_user_ids)} allowed user(s))..."
        )

        bot = TelegramBot(config, api)
        bot.run()
    except KeyboardInterrupt:
        print("\nTelegram bot stopped.")
    finally:
        api.close()


def _cmd_tui(args: argparse.Namespace) -> None:
    """Launch the Textual TUI as a thin client against the memex service daemon."""
    from memex.interfaces.service_client import MemexServiceClient
    from memex.interfaces.tui.app import MemexApp

    mode = args.mode if hasattr(args, "mode") and args.mode else "normal"

    def _read_service_url_file() -> str | None:
        from memex.paths import resolve_service_url_file

        url_file = resolve_service_url_file()
        if url_file.exists():
            return url_file.read_text().strip() or None
        return None

    service_url = (
        getattr(args, "service", None)
        or os.environ.get("MEMEX_SERVICE_URL")
        or _read_service_url_file()
        or "http://127.0.0.1:8321"
    )

    _config_dir = Path.home() / ".config" / "memex"
    _session_file = _config_dir / "session_id"
    if _session_file.exists():
        _session_id = _session_file.read_text().strip()
    else:
        import uuid as _uuid

        _session_id = str(_uuid.uuid4())
        _config_dir.mkdir(parents=True, exist_ok=True)
        _session_file.write_text(_session_id)

    _token = getattr(args, "token", None) or os.environ.get("MEMEX_SERVICE_TOKEN")
    api = MemexServiceClient(
        base_url=service_url,
        token=_token,
        session_id=_session_id,
    )
    try:
        api.status(caller=None)
    except Exception as exc:
        print(
            f"Cannot connect to memex service at {service_url}: {exc}\n"
            "\n"
            "The memex service daemon must be running before starting the TUI.\n"
            "  Start:   systemctl --user start memex\n"
            "  Status:  systemctl --user status memex\n"
            "  Logs:    journalctl --user -u memex -f\n"
            "\n"
            "Or specify a custom URL:  memex tui --service http://host:port",
            file=sys.stderr,
        )
        api.close()
        sys.exit(1)
    try:
        app = MemexApp(api=api, mode=mode)
        app.run()
    finally:
        app.signal_shutdown_complete()
        api.close()


def _cmd_service(args: argparse.Namespace) -> None:
    """Run the memex-service daemon (Telegram + scheduler + HttpGateway)."""
    from memex import service as svc

    no_telegram = getattr(args, "no_telegram", False)
    svc.run(_resolve_store_path(), no_telegram=no_telegram)


def _cmd_install_service(args: argparse.Namespace) -> None:
    """Install memex as a systemd user service."""
    import shutil
    import subprocess

    project_root = Path(__file__).resolve().parent.parent.parent
    unit_src = project_root / "deploy" / "memex.service"
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dest = unit_dir / "memex.service"
    dry_run = getattr(args, "dry_run", False)
    service = "memex"

    def _run(cmd: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        if dry_run:
            print(f"  [dry-run] {' '.join(cmd)}")
            return subprocess.CompletedProcess(cmd, 0)
        return subprocess.run(cmd, check=True, text=True, **kwargs)  # noqa: S603

    # -- sanity checks --------------------------------------------------------
    if not unit_src.exists():
        print(f"ERROR: unit file not found: {unit_src}", file=sys.stderr)
        sys.exit(1)

    env_file = project_root / ".env"
    if not env_file.exists():
        print(
            f"ERROR: {env_file} not found — service needs it for credentials",
            file=sys.stderr,
        )
        print("       Run `memex init` first.", file=sys.stderr)
        sys.exit(1)

    if not shutil.which("systemctl"):
        print("ERROR: systemctl not found — systemd is required", file=sys.stderr)
        sys.exit(1)

    # -- stop if already running ----------------------------------------------
    active = subprocess.run(
        ["systemctl", "--user", "is-active", "--quiet", service],  # noqa: S603, S607
        capture_output=True,
    )
    if active.returncode == 0:
        print(f"  Stopping running {service}...")
        _run(["systemctl", "--user", "stop", service])

    # -- install unit file ----------------------------------------------------
    if not dry_run:
        unit_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(unit_src, unit_dest)
    print(f"  Installed unit file to {unit_dest}")

    # -- reload, enable, start ------------------------------------------------
    _run(["systemctl", "--user", "daemon-reload"])
    _run(["systemctl", "--user", "enable", service])
    _run(["systemctl", "--user", "start", service])

    if not dry_run:
        import time

        time.sleep(2)
        print()
        subprocess.run(  # noqa: S603, S607
            ["systemctl", "--user", "status", service, "--no-pager", "--lines=5"],
        )

    # -- linger check ---------------------------------------------------------
    try:
        result = subprocess.run(  # noqa: S603, S607
            ["loginctl", "show-user", os.environ.get("USER", ""), "--property=Linger"],
            capture_output=True,
            text=True,
        )
        if "Linger=yes" not in result.stdout:
            print()
            print(
                "  NOTE: Linger is disabled — service only runs while you are logged in."
            )
            print(
                f"        To start at boot: loginctl enable-linger {os.environ.get('USER', '')}"
            )
    except FileNotFoundError:
        pass

    print()
    print("  Done. Check status with: systemctl --user status memex")


def _cmd_serve(args: argparse.Namespace) -> None:
    """Start Memex as an MCP server."""
    from memex.interfaces.mcp_server import create_app

    scope = args.scope if hasattr(args, "scope") else "read_only"
    print(f"Starting Memex MCP server (scope: {scope})...")
    app = create_app(scope=scope, store_path=_resolve_store_path())
    app.run(transport="stdio")


def _cmd_approvals(args: argparse.Namespace) -> None:
    """Manage approval queue."""
    store = _make_fathom_store()
    try:
        ns = store.notifications
        cmd = args.approvals_command if hasattr(args, "approvals_command") else None

        if cmd == "list" or cmd is None:
            pending = ns.list_pending()
            approvals = [n for n in pending if n.action_type == "approve"]
            if not approvals:
                print("No pending approvals.")
                return
            for n in approvals:
                print(f"  [{n.notification_id[:8]}] {n.title}")
                if n.body:
                    print(f"    {n.body[:100]}")
    finally:
        store.close()


def _cmd_init(args: argparse.Namespace) -> None:
    """Initialize Memex in the current directory."""
    from memex.doctor import init

    print("Initializing Memex...\n")
    actions = init()
    for action in actions:
        print(f"  {action}")
    print("\nDone. Run `memex doctor` to verify setup.")


def _cmd_doctor(args: argparse.Namespace) -> None:
    """Run diagnostic self-test."""
    from memex.doctor import doctor

    print("Memex Doctor\n")
    report = doctor()
    report.print()


def _cmd_backfill_conversations(args: argparse.Namespace) -> None:
    """Backfill conversation search enrichment — no-op under fathomdb."""
    print(
        "Conversation indexing is handled automatically by fathomdb. No backfill needed."
    )


def _cmd_setup(args: argparse.Namespace) -> None:
    """Interactive provider setup wizard."""
    from memex.providers import ALL_PROVIDERS
    from memex.providers_base import CLIPrompter, CredentialStore

    prompter = CLIPrompter()
    cred_store = CredentialStore()

    # Show current state
    existing = cred_store.list_providers()
    if existing:
        prompter.info(f"Configured providers: {', '.join(existing)}\n")

    # List available providers
    providers = [cls() for cls in ALL_PROVIDERS]
    names = [p.name for p in providers]

    selected_name = prompter.select("Select a provider to set up:", names)
    provider = providers[names.index(selected_name)]

    result = provider.setup(prompter)
    if result.success:
        cred_store.save(provider.id, result.credentials)
        prompter.info(f"\n{result.message}")
    else:
        prompter.info(f"\nSetup cancelled: {result.message}")


def _cmd_schedule_list(args: argparse.Namespace) -> None:
    """List scheduled tasks."""
    from memex.scheduler.builtins import get_builtin_tasks
    from memex.scheduler.cron_utils import format_cron_human, next_fire_time

    store = _make_fathom_store()
    try:
        store.scheduler.seed_builtins(get_builtin_tasks())
        tasks = store.scheduler.list_tasks()
        if not tasks:
            print("No scheduled tasks.")
            return

        for t in tasks:
            status = "ON " if t.enabled else "OFF"
            schedule = format_cron_human(t.cron_expr)
            nxt = next_fire_time(t.cron_expr)
            from memex.scheduler.cron_utils import format_human_readable

            next_str = format_human_readable(nxt)
            last_run = store.scheduler.get_last_run(t.task_id)
            last_str = last_run.status if last_run else "never"
            builtin = " [builtin]" if t.builtin else ""
            print(f"  [{status}] {t.name}{builtin}")
            print(f"        Schedule: {schedule} | Next: {next_str} | Last: {last_str}")
    finally:
        store.close()


def _cmd_schedule_create(args: argparse.Namespace) -> None:
    """Create a new scheduled task."""
    import json
    import uuid
    from memex.models import ActionType, ScheduledTask

    store = _make_fathom_store()
    try:
        now = utcnow()
        action_data = {}
        raw_data = getattr(args, "action_data", None)
        if raw_data:
            try:
                action_data = json.loads(raw_data)
            except json.JSONDecodeError as exc:
                print(f"Invalid JSON in --action-data: {exc}")
                return

        task = ScheduledTask(
            task_id=str(uuid.uuid4()),
            name=args.name,
            description=getattr(args, "description", "") or "",
            cron_expr=args.cron,
            action_type=ActionType(args.action_type),
            action_data=action_data,
            created_at=now,
            updated_at=now,
        )
        store.scheduler.create_task(task)
        print(f"Created: {task.name} ({task.cron_expr})  [{task.task_id[:8]}]")
    finally:
        store.close()


def _cmd_schedule_toggle(args: argparse.Namespace, enable: bool) -> None:
    """Enable or disable a scheduled task."""
    store = _make_fathom_store()
    try:
        task = store.scheduler.get_task(args.id)
        if not task:
            # Try prefix match
            tasks = store.scheduler.list_tasks()
            matches = [t for t in tasks if t.task_id.startswith(args.id)]
            if len(matches) == 1:
                task = matches[0]
            else:
                print(f"Task not found: {args.id}")
                return

        store.scheduler.toggle_task(task.task_id, enable)
        state = "enabled" if enable else "disabled"
        print(f"{state.capitalize()}: {task.name}")
    finally:
        store.close()


def _cmd_schedule_history(args: argparse.Namespace) -> None:
    """Show run history for a scheduled task."""
    store = _make_fathom_store()
    try:
        runs = store.scheduler.get_runs(args.id, limit=getattr(args, "limit", 10) or 10)
        if not runs:
            print("No runs found.")
            return

        for r in runs:
            ts = r.started_at.strftime("%Y-%m-%d %H:%M") if r.started_at else ""
            dur = ""
            if r.completed_at and r.started_at:
                dur = f" ({(r.completed_at - r.started_at).total_seconds():.1f}s)"
            err = f" — {r.error}" if r.error else ""
            att = f" [attempt {r.attempt}]" if r.attempt else ""
            print(f"  {ts} {r.status}{dur}{att}{err}")
            if r.result:
                print(f"    {r.result[:120]}")
    finally:
        store.close()


def _cmd_schedule_run(args: argparse.Namespace) -> None:
    """Run a scheduled task immediately."""
    from memex.scheduler.engine import SchedulerEngine

    store = _make_fathom_store()
    try:
        ns = store.notifications
        engine = SchedulerEngine(
            store.scheduler,
            memex_store=store,
            notification_store=ns,
        )
        run_id = engine.run_task_now(args.id)
        if run_id is None:
            print(f"Task not found: {args.id}")
            return
        print(f"Enqueued task (run_id={run_id}). Starting work queue...")
        engine.work_queue.start()
        import time

        time.sleep(3)  # Give it a moment to process
        engine.stop(timeout=10)

        last = store.scheduler.get_last_run(args.id)
        if last:
            print(f"Result: {last.status}")
            if last.result:
                print(f"  {last.result[:200]}")
            if last.error:
                print(f"  Error: {last.error}")
    finally:
        store.close()


def _cmd_search(args: argparse.Namespace) -> None:
    """Search across all data types with optional temporal filtering."""
    from memex.temporal import temporal_search, TemporalRange

    store = _make_fathom_store()
    try:
        # TODO: temporal_search needs porting to fathomdb
        print("Search not yet ported to fathomdb backend.")
        return

        query = args.query
        now = utcnow()

        # Build temporal range from --since/--until or from query
        temporal_range = None
        if hasattr(args, "since") and args.since:
            start = _parse_date_arg(args.since, now)
            end = (
                _parse_date_arg(args.until, now)
                if hasattr(args, "until") and args.until
                else now
            )
            until_label = args.until if hasattr(args, "until") and args.until else "now"
            temporal_range = TemporalRange(
                start=start, end=end, expression=f"{args.since} to {until_label}"
            )
        else:
            from memex.temporal import extract_temporal_from_query

            query, temporal_range = extract_temporal_from_query(query, now)

        if temporal_range is None:
            # Default: last 30 days
            from datetime import timedelta

            temporal_range = TemporalRange(
                start=now - timedelta(days=30),
                end=now,
                expression="last 30 days",
            )

        results = temporal_search(
            query,
            temporal_range,
            conn=store.conn,
            limit=getattr(args, "limit", 20) or 20,
        )

        if not results:
            print(f"No results found for '{args.query}' ({temporal_range.expression}).")
            return

        # Filter by type if specified
        if hasattr(args, "type") and args.type:
            results = [r for r in results if r.source_type == args.type]

        print(f"Results for '{args.query}' ({temporal_range.expression}):\n")
        for r in results:
            ts = r.timestamp.strftime("%Y-%m-%d %H:%M")
            print(f"  [{r.source_type}] {ts} — {r.title}")
            if r.snippet:
                snippet = r.snippet[:120].replace("\n", " ")
                print(f"    {snippet}")
    finally:
        store.close()


def _parse_date_arg(value: str, now) -> datetime:
    """Parse a date argument — try temporal parser first, then ISO format."""
    from memex.temporal import parse_temporal

    result = parse_temporal(value, now)
    if result:
        return result.start
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        pass
    try:
        return datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        raise ValueError(f"Cannot parse date: {value!r}  (try YYYY-MM-DD)")


def _cmd_auto_ingest_list(args: argparse.Namespace) -> None:
    """List auto-ingest sources."""
    from memex.auto_ingest.registry import get_default_registry

    registry = get_default_registry()
    sources = registry.list_sources()
    if not sources:
        print("No auto-ingest sources available.")
        return

    print("Available auto-ingest sources:")
    for name in sources:
        print(f"  - {name}")


def _cmd_auto_ingest_run(args: argparse.Namespace) -> None:
    """Run an auto-ingest source."""
    from memex.auto_ingest.registry import get_default_registry

    store = _make_fathom_store()
    try:
        registry = get_default_registry()

        # Configure RSS feeds from auto_ingest_sources via operational store
        try:
            operational = getattr(store, "_fathom", None)
            if operational is not None:
                operational = operational.operational
            if operational is not None:
                import json

                rows = operational.list_auto_ingest_sources()
                rss_source = registry.get_source("rss")
                if rss_source and rows:
                    all_urls = []
                    for row in rows:
                        if row.get("type") == "rss" and row.get("enabled", True):
                            config = row if isinstance(row, dict) else json.loads(row)
                            all_urls.extend(config.get("feed_urls", []))
                    if all_urls:
                        rss_source.configure({"feed_urls": all_urls})
            else:
                print("Auto-ingest source configuration requires fathomdb backend.")
                return
        except Exception:
            pass

        count = registry.run_source(
            args.source,
            content_store=store.content,
            memex_store=store,
        )
        print(f"Ingested {count} items from {args.source}.")
    finally:
        store.close()


def _cmd_auto_ingest_add_feed(args: argparse.Namespace) -> None:
    """Add an RSS feed URL."""
    import uuid

    store = _make_fathom_store()
    try:
        source_id = str(uuid.uuid4())
        operational = getattr(store, "_fathom", None)
        if operational is not None:
            operational = operational.operational
        if operational is not None:
            operational.put_auto_ingest_source(
                source_id,
                {
                    "type": "rss",
                    "name": args.url,
                    "feed_urls": [args.url],
                    "enabled": True,
                },
            )
        else:
            print("Adding RSS feeds requires fathomdb backend.")
            return
        print(f"Added RSS feed: {args.url}")
    finally:
        store.close()


def _cmd_auth_list(args: argparse.Namespace) -> None:
    """List configured auth services."""
    from memex.auth.store import list_services, get_credentials, is_token_expired

    services = list_services()
    if not services:
        print("No services configured.")
        return

    print("Configured services:")
    for svc in services:
        creds = get_credentials(svc)
        status = "active"
        if creds and is_token_expired(creds):
            status = "expired"
        print(f"  - {svc} ({status})")


def _cmd_auth_setup(args: argparse.Namespace) -> None:
    """Set up auth for a service."""
    service = args.service.lower()

    if service == "outlook":
        from memex.integrations.outlook import OutlookClient

        client = OutlookClient()
        client.setup_auth()
        print("Outlook authentication successful.")
    elif service in ("gmail", "google"):
        from memex.integrations.gmail import GmailClient

        client = GmailClient()
        client.setup_auth()
        print("Gmail authentication successful.")
    elif service in ("google_keep", "keep"):
        print("Google Keep uses gkeepapi which requires manual authentication.")
        print("Store your master token with: memex auth store google_keep <token>")
    elif service == "icloud":
        from memex.integrations.icloud_cal import ICloudCalendarClient

        client = ICloudCalendarClient()
        client.setup_auth()
        print("iCloud authentication successful.")
    else:
        print(f"Unknown service: {service}")
        print("Available: outlook, gmail, google_keep, icloud")


def _cmd_auth_remove(args: argparse.Namespace) -> None:
    """Remove auth for a service."""
    from memex.auth.store import delete_credentials

    delete_credentials(args.service)
    print(f"Removed credentials for: {args.service}")


def _cmd_log_conversations(args: argparse.Namespace) -> None:
    """Show conversation log."""
    store = _make_fathom_store()
    try:
        session_id = getattr(args, "session", None)
        role = getattr(args, "role", None)
        n = getattr(args, "n", 50)

        since = None
        since_arg = getattr(args, "since", None)
        if since_arg:
            since = _parse_date_arg(since_arg, utcnow())

        rows = store.query_conversation_log(
            session_id=session_id,
            role=role,
            since=since,
            limit=n,
        )

        if not rows:
            print("No conversation log entries found.")
            return

        # Show oldest first for readability
        for row in reversed(rows):
            ts = row["timestamp"][:19]
            sid = row["session_id"][:8]
            role_str = row["role"]
            content = row["content"]
            # Truncate long content for display
            if len(content) > 200:
                content = content[:200] + "..."
            print(f"  [{ts}] ({sid}) {role_str}: {content}")
    finally:
        store.close()


def _cmd_log_audit(args: argparse.Namespace) -> None:
    """Show audit log (tool calls)."""
    store = _make_fathom_store()
    try:
        connector = getattr(args, "connector", None)
        n = getattr(args, "n", 50)

        since = None
        since_arg = getattr(args, "since", None)
        if since_arg:
            since = _parse_date_arg(since_arg, utcnow())

        entries = store.query_audit(
            connector=connector,
            since=since,
            limit=n,
        )

        if not entries:
            print("No audit log entries found.")
            return

        for e in entries:
            ts = e.timestamp.isoformat()[:19]
            granted = "+" if e.granted else "DENIED"
            dur = f" {e.duration_ms}ms" if e.duration_ms else ""
            summary = f" -> {e.result_summary[:80]}" if e.result_summary else ""
            print(f"  [{ts}] [{granted}] {e.connector}:{e.action}{dur}{summary}")
    finally:
        store.close()


def _cmd_log_runs(args: argparse.Namespace) -> None:
    """Show scheduled task run history."""
    store = _make_fathom_store()
    try:
        n = getattr(args, "n", 50)
        task_id = getattr(args, "task_id", None)

        scheduler = store.scheduler
        if task_id:
            runs = scheduler.get_runs(task_id, limit=n)
        else:
            # Get runs across all tasks
            runs = scheduler.get_all_runs(limit=n)

        if not runs:
            print("No task runs found.")
            return

        for r in runs:
            ts = (
                r.started_at.isoformat()[:19]
                if r.started_at
                else (r.queued_at.isoformat()[:19] if r.queued_at else "pending")
            )
            status = r.status
            tid = r.task_id[:20]
            result = ""
            if r.error:
                result = f" ERROR: {r.error[:80]}"
            elif r.result:
                result = f" -> {r.result[:80]}"
            dur = ""
            if r.completed_at and r.started_at:
                elapsed = (r.completed_at - r.started_at).total_seconds()
                dur = f" ({elapsed:.1f}s)"
            print(f"  [{ts}] {status:10s} {tid}{dur}{result}")
    finally:
        store.close()


def _cmd_notify(args: argparse.Namespace) -> None:
    """Show pending notifications."""
    store = _make_fathom_store()
    try:
        ns = store.notifications
        pending = ns.list_pending()

        if not pending:
            print("No pending notifications.")
            return

        for n in pending:
            icon = {"critical": "!!", "high": "!", "normal": "-", "low": "."}
            print(f"  [{icon.get(n.priority.value, '-')}] {n.title}")
            if n.body:
                print(f"      {n.body[:100]}")
    finally:
        store.close()


_FEATURE_COMMANDS: dict[str, object] = {}  # str → dispatch(args, parser) callable
_FEATURE_PARSERS: dict[str, argparse.ArgumentParser] = {}


def _register_features(subs) -> None:
    """Register feature module CLI commands."""
    from memex.meetings.cli import dispatch as meeting_dispatch
    from memex.meetings.cli import register_parser as meeting_register

    _FEATURE_PARSERS["meeting"] = meeting_register(subs)
    _FEATURE_COMMANDS["meeting"] = meeting_dispatch


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="memex",
        description="Memex — personal AI partner",
    )
    parser.add_argument("--version", action="version", version="memex 0.1.0")

    subs = parser.add_subparsers(dest="command")

    # chat
    chat_parser = subs.add_parser("chat", help="Interactive chat session")
    chat_parser.add_argument(
        "--mode",
        default=None,
        choices=["normal", "deep_work", "review", "quick_check"],
        help="Session mode",
    )

    # goal
    goal_parser = subs.add_parser("goal", help="Goal management")
    goal_subs = goal_parser.add_subparsers(dest="goal_command")

    # goal list
    gl = goal_subs.add_parser("list", help="List goals")
    gl.add_argument("--all", action="store_true", help="Include non-active goals")

    # goal show
    gs = goal_subs.add_parser("show", help="Show goal details")
    gs.add_argument("id", help="Goal ID (or prefix)")

    # goal create
    gc = goal_subs.add_parser("create", help="Create a goal")
    gc.add_argument("title", help="Goal title")
    gc.add_argument("--parent", default=None, help="Parent goal ID")
    gc.add_argument(
        "--priority", default=None, choices=["critical", "high", "medium", "low"]
    )

    # session
    session_parser = subs.add_parser("session", help="Session management")
    session_subs = session_parser.add_subparsers(dest="session_command")
    session_subs.add_parser("end", help="End current session")

    # ingest
    ingest_parser = subs.add_parser(
        "ingest", help="Ingest content into knowledge store"
    )
    ingest_parser.add_argument("source", help="URL, file path, or - for stdin")
    ingest_parser.add_argument(
        "--type", default="note", help="Item type (article, note, thought, etc.)"
    )
    ingest_parser.add_argument("--title", default=None, help="Item title")

    # status
    subs.add_parser("status", help="Comprehensive system status")
    subs.add_parser("status-quick", help="Quick system status")

    # telegram (deprecated — use memex service instead)
    telegram_parser = subs.add_parser(
        "telegram", help="[deprecated] Start Telegram bot (use 'memex service' instead)"
    )
    telegram_parser.add_argument(
        "--force", action="store_true", help="Run anyway despite deprecation"
    )

    # service
    service_parser = subs.add_parser(
        "service",
        help="Run the memex-service daemon (Telegram + scheduler + HttpGateway)",
    )
    service_parser.add_argument(
        "--no-telegram",
        action="store_true",
        default=False,
        help="Disable Telegram polling",
    )

    # tui (thin client — connects to memex service daemon)
    tui_parser = subs.add_parser(
        "tui", help="Launch the Textual TUI (connects to memex service)"
    )
    tui_parser.add_argument(
        "--mode",
        default=None,
        choices=["normal", "deep_work", "review", "quick_check"],
        help="Session mode",
    )
    tui_parser.add_argument(
        "--service",
        metavar="URL",
        default=None,
        help="Service daemon URL (default: $MEMEX_SERVICE_URL or http://127.0.0.1:8321)",
    )
    tui_parser.add_argument(
        "--token",
        metavar="TOKEN",
        default=None,
        help="Bearer token for service authentication (falls back to MEMEX_SERVICE_TOKEN env var)",
    )

    # serve (MCP server)
    serve_parser = subs.add_parser("serve", help="Start Memex as an MCP server")
    serve_parser.add_argument(
        "--scope",
        default="read_only",
        choices=["read_only", "collaborative", "full"],
        help="Tool scope for external callers",
    )

    # Feature module commands
    _register_features(subs)

    # schedule
    schedule_parser = subs.add_parser("schedule", help="Scheduled task management")
    schedule_subs = schedule_parser.add_subparsers(dest="schedule_command")
    schedule_subs.add_parser("list", help="List scheduled tasks")
    sc_create = schedule_subs.add_parser("create", help="Create a scheduled task")
    sc_create.add_argument("name", help="Task name")
    sc_create.add_argument(
        "--cron", required=True, help="Cron expression (e.g. '0 9 * * *')"
    )
    sc_create.add_argument(
        "--action-type",
        required=True,
        choices=["notification", "prompt", "callable", "auto_ingest"],
    )
    sc_create.add_argument("--action-data", default="{}", help="JSON action data")
    sc_create.add_argument("--description", default="", help="Task description")
    sc_enable = schedule_subs.add_parser("enable", help="Enable a task")
    sc_enable.add_argument("id", help="Task ID (or prefix)")
    sc_disable = schedule_subs.add_parser("disable", help="Disable a task")
    sc_disable.add_argument("id", help="Task ID (or prefix)")
    sc_history = schedule_subs.add_parser("history", help="Show run history")
    sc_history.add_argument("id", help="Task ID")
    sc_history.add_argument(
        "--limit", type=int, default=10, help="Number of runs to show"
    )
    sc_run = schedule_subs.add_parser("run", help="Run a task immediately")
    sc_run.add_argument("id", help="Task ID")

    # search
    search_parser = subs.add_parser("search", help="Search across all data types")
    search_parser.add_argument("query", help="Search query")
    search_parser.add_argument(
        "--since", default=None, help="Start date (e.g. 'last week', '2024-01-01')"
    )
    search_parser.add_argument("--until", default=None, help="End date")
    search_parser.add_argument(
        "--type",
        default=None,
        choices=["conversation", "goal", "item"],
        help="Filter by type",
    )
    search_parser.add_argument("--limit", type=int, default=20, help="Max results")

    # auto-ingest
    ai_parser = subs.add_parser("auto-ingest", help="Auto-ingest source management")
    ai_subs = ai_parser.add_subparsers(dest="ai_command")
    ai_subs.add_parser("list", help="List auto-ingest sources")
    ai_run = ai_subs.add_parser("run", help="Run an auto-ingest source")
    ai_run.add_argument("source", help="Source name (e.g. watch_folder, rss, gmail)")
    ai_feed = ai_subs.add_parser("add-feed", help="Add an RSS feed URL")
    ai_feed.add_argument("url", help="RSS feed URL")

    # auth
    auth_parser = subs.add_parser("auth", help="Authentication management")
    auth_subs = auth_parser.add_subparsers(dest="auth_command")
    auth_subs.add_parser("list", help="List configured services")
    auth_setup = auth_subs.add_parser("setup", help="Set up auth for a service")
    auth_setup.add_argument(
        "service", help="Service name (outlook, gmail, google_keep, icloud)"
    )
    auth_remove = auth_subs.add_parser("remove", help="Remove auth for a service")
    auth_remove.add_argument("service", help="Service name")

    # approvals
    approvals_parser = subs.add_parser("approvals", help="Approval queue management")
    approvals_subs = approvals_parser.add_subparsers(dest="approvals_command")
    approvals_subs.add_parser("list", help="List pending approvals")

    # log
    log_parser = subs.add_parser("log", help="View activity logs")
    log_subs = log_parser.add_subparsers(dest="log_command")

    log_conv = log_subs.add_parser("conversations", help="Show conversation log")
    log_conv.add_argument(
        "--session", default=None, help="Filter by session ID (prefix)"
    )
    log_conv.add_argument(
        "--role", default=None, choices=["human", "assistant", "system", "tool_result"]
    )
    log_conv.add_argument("--since", default=None, help="Since date (YYYY-MM-DD)")
    log_conv.add_argument(
        "-n", type=int, default=50, help="Number of entries (default 50)"
    )

    log_audit = log_subs.add_parser("audit", help="Show audit log (tool calls)")
    log_audit.add_argument("--connector", default=None, help="Filter by connector")
    log_audit.add_argument("--since", default=None, help="Since date (YYYY-MM-DD)")
    log_audit.add_argument(
        "-n", type=int, default=50, help="Number of entries (default 50)"
    )

    log_runs = log_subs.add_parser("runs", help="Show scheduled task runs")
    log_runs.add_argument("--task-id", default=None, help="Filter by task ID")
    log_runs.add_argument(
        "-n", type=int, default=50, help="Number of entries (default 50)"
    )

    # notify
    subs.add_parser("notify", help="Show pending notifications")

    # init
    subs.add_parser("init", help="Initialize Memex in the current directory")

    # doctor
    subs.add_parser("doctor", help="Run diagnostic self-test")

    # install-service
    install_svc_parser = subs.add_parser(
        "install-service",
        help="Install memex as a systemd user service",
    )
    install_svc_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print commands without executing",
    )

    # setup
    subs.add_parser("setup", help="Interactive provider setup wizard")

    # backfill-conversations
    bc_parser = subs.add_parser(
        "backfill-conversations",
        help="Backfill conversation search enrichment (search_text + optional embeddings)",
    )
    bc_parser.add_argument(
        "--embed",
        action="store_true",
        help="Also generate embeddings for turn pairs (slow, requires sentence-transformers)",
    )

    return parser


def main(argv: list[str] | None = None) -> None:
    """CLI entry point. Always exits 0."""
    from dotenv import load_dotenv

    load_dotenv()

    from memex.logging_config import setup_logging

    try:
        parser = _build_parser()
        args = parser.parse_args(argv if argv is not None else sys.argv[1:])

        # TUI, serve, and service own the terminal/journal — no console logging
        use_console = args.command not in ("tui", "serve", "service")
        setup_logging(console=use_console)

        if args.command == "chat":
            _cmd_chat(args)
        elif args.command == "goal":
            if not hasattr(args, "goal_command") or args.goal_command is None:
                parser.parse_args(["goal", "--help"])
            elif args.goal_command == "list":
                _cmd_goal_list(args)
            elif args.goal_command == "show":
                _cmd_goal_show(args)
            elif args.goal_command == "create":
                _cmd_goal_create(args)
        elif args.command == "session":
            if not hasattr(args, "session_command") or args.session_command is None:
                parser.parse_args(["session", "--help"])
            elif args.session_command == "end":
                _cmd_session_end(args)
        elif args.command == "ingest":
            _cmd_ingest(args)
        elif args.command == "status":
            _cmd_status(args)
        elif args.command == "status-quick":
            _cmd_status_quick(args)
        elif args.command == "telegram":
            _cmd_telegram(args)
        elif args.command == "service":
            _cmd_service(args)
        elif args.command == "tui":
            _cmd_tui(args)
        elif args.command == "serve":
            _cmd_serve(args)
        elif args.command in _FEATURE_COMMANDS:
            _FEATURE_COMMANDS[args.command](args, _FEATURE_PARSERS.get(args.command))
        elif args.command == "schedule":
            if not hasattr(args, "schedule_command") or args.schedule_command is None:
                parser.parse_args(["schedule", "--help"])
            elif args.schedule_command == "list":
                _cmd_schedule_list(args)
            elif args.schedule_command == "create":
                _cmd_schedule_create(args)
            elif args.schedule_command == "enable":
                _cmd_schedule_toggle(args, enable=True)
            elif args.schedule_command == "disable":
                _cmd_schedule_toggle(args, enable=False)
            elif args.schedule_command == "history":
                _cmd_schedule_history(args)
            elif args.schedule_command == "run":
                _cmd_schedule_run(args)
        elif args.command == "search":
            _cmd_search(args)
        elif args.command == "auto-ingest":
            if not hasattr(args, "ai_command") or args.ai_command is None:
                parser.parse_args(["auto-ingest", "--help"])
            elif args.ai_command == "list":
                _cmd_auto_ingest_list(args)
            elif args.ai_command == "run":
                _cmd_auto_ingest_run(args)
            elif args.ai_command == "add-feed":
                _cmd_auto_ingest_add_feed(args)
        elif args.command == "auth":
            if not hasattr(args, "auth_command") or args.auth_command is None:
                parser.parse_args(["auth", "--help"])
            elif args.auth_command == "list":
                _cmd_auth_list(args)
            elif args.auth_command == "setup":
                _cmd_auth_setup(args)
            elif args.auth_command == "remove":
                _cmd_auth_remove(args)
        elif args.command == "log":
            if not hasattr(args, "log_command") or args.log_command is None:
                parser.parse_args(["log", "--help"])
            elif args.log_command == "conversations":
                _cmd_log_conversations(args)
            elif args.log_command == "audit":
                _cmd_log_audit(args)
            elif args.log_command == "runs":
                _cmd_log_runs(args)
        elif args.command == "approvals":
            _cmd_approvals(args)
        elif args.command == "notify":
            _cmd_notify(args)
        elif args.command == "init":
            _cmd_init(args)
        elif args.command == "doctor":
            _cmd_doctor(args)
        elif args.command == "install-service":
            _cmd_install_service(args)
        elif args.command == "setup":
            _cmd_setup(args)
        elif args.command == "backfill-conversations":
            _cmd_backfill_conversations(args)
        else:
            parser.print_help()
    except SystemExit as e:
        if e.code and e.code != 0:
            sys.exit(e.code)
    except Exception as exc:
        print(f"memex: {exc}", file=sys.stderr)


if __name__ == "__main__":
    main()
