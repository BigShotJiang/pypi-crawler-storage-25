"""Migration runner for FathomDB document-level evolution.

Discovers numbered migration modules under ``src/memex/migrations/versions/``,
tracks which have been applied via a FathomDB operational collection, and
applies pending migrations in order.

Each migration module must expose:
    REVISION: str          — unique identifier, e.g. "001"
    DESCRIPTION: str       — human-readable summary
    def upgrade(engine):   — receives a fathomdb Engine; performs the migration

Migrations MUST be idempotent — safe to re-run if the tracking record was
lost or the database was restored from backup.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
import time
from dataclasses import dataclass
from typing import Any

from fathomdb import (
    Engine,
    OperationalAppend,
    OperationalCollectionKind,
    OperationalRegisterRequest,
    WriteRequest,
)

logger = logging.getLogger(__name__)

_COLLECTION_NAME = "schema_migrations"


@dataclass(frozen=True)
class MigrationRecord:
    revision: str
    description: str
    applied_at: str
    duration_ms: int


def _register_migration_collection(engine: Engine) -> None:
    """Ensure the schema_migrations operational collection exists (idempotent)."""
    existing = engine.admin.describe_operational_collection(_COLLECTION_NAME)
    if existing is not None:
        return
    reg = OperationalRegisterRequest(
        name=_COLLECTION_NAME,
        kind=OperationalCollectionKind.APPEND_ONLY_LOG,
        schema_json="{}",
        retention_json="{}",
        filter_fields_json='[{"name":"revision","type":"string","modes":["exact"]}]',
        validation_json='{"format_version":1,"mode":"disabled","fields":[]}',
        secondary_indexes_json="[]",
        format_version=1,
    )
    try:
        engine.admin.register_operational_collection(reg)
    except Exception:
        logger.debug("schema_migrations collection registration failed", exc_info=True)


def get_applied_revisions(engine: Engine) -> set[str]:
    """Return the set of revision strings already applied."""
    _register_migration_collection(engine)
    traced = engine.admin.trace_operational_collection(_COLLECTION_NAME)
    revisions: set[str] = set()
    for row in traced.mutations:
        if row.op_kind == "delete":
            continue
        payload = row.payload_json
        if isinstance(payload, dict) and "revision" in payload:
            revisions.add(payload["revision"])
    return revisions


def _record_migration(
    engine: Engine,
    revision: str,
    description: str,
    duration_ms: int,
) -> None:
    """Write a record that *revision* has been applied."""
    from memex.utcnow import utcnow

    engine.write(
        WriteRequest(
            label="migration-applied",
            operational_writes=[
                OperationalAppend(
                    collection=_COLLECTION_NAME,
                    record_key=f"migration-{revision}-{time.time_ns()}",
                    payload_json={
                        "revision": revision,
                        "description": description,
                        "applied_at": utcnow().isoformat(),
                        "duration_ms": duration_ms,
                    },
                    source_ref="memex:migrations",
                )
            ],
        )
    )


@dataclass(frozen=True)
class MigrationModule:
    revision: str
    description: str
    upgrade: Any  # callable(engine) -> None


def discover_migrations() -> list[MigrationModule]:
    """Import all migration modules from memex.migrations.versions, sorted by revision."""
    import memex.migrations.versions as versions_pkg

    modules: list[MigrationModule] = []
    for importer, modname, _ispkg in pkgutil.iter_modules(versions_pkg.__path__):
        mod = importlib.import_module(f"memex.migrations.versions.{modname}")
        revision = getattr(mod, "REVISION", None)
        description = getattr(mod, "DESCRIPTION", "")
        upgrade_fn = getattr(mod, "upgrade", None)
        if revision is None or upgrade_fn is None:
            logger.warning(
                "Skipping migration module %s: missing REVISION or upgrade()",
                modname,
            )
            continue
        modules.append(
            MigrationModule(
                revision=revision, description=description, upgrade=upgrade_fn
            )
        )

    modules.sort(key=lambda m: m.revision)
    return modules


def run_pending_migrations(engine: Engine) -> list[MigrationRecord]:
    """Discover and apply all pending migrations. Returns list of applied records."""
    _register_migration_collection(engine)
    applied = get_applied_revisions(engine)
    all_migrations = discover_migrations()
    results: list[MigrationRecord] = []

    for mig in all_migrations:
        if mig.revision in applied:
            continue
        logger.info("Applying migration %s: %s", mig.revision, mig.description)
        t0 = time.monotonic()
        try:
            mig.upgrade(engine)
        except Exception:
            logger.error("Migration %s failed", mig.revision, exc_info=True)
            raise
        duration_ms = int((time.monotonic() - t0) * 1000)
        _record_migration(engine, mig.revision, mig.description, duration_ms)
        record = MigrationRecord(
            revision=mig.revision,
            description=mig.description,
            applied_at="",  # logged in operational store
            duration_ms=duration_ms,
        )
        results.append(record)
        logger.info("Migration %s applied in %dms", mig.revision, duration_ms)

    if not results:
        logger.debug("No pending migrations")
    return results
