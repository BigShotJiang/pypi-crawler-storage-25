"""Backfill ``failure_reason`` on WorldModelTask nodes.

The WorldModelTask model defines ``failure_reason: str = ""`` but older
task nodes may lack this property.  This migration ensures the field
exists so downstream code can filter or display it without guarding
against None/missing.
"""

from __future__ import annotations

from fathomdb import ChunkPolicy, Engine, NodeInsert, WriteRequest, new_row_id

REVISION = "002"
DESCRIPTION = "Backfill failure_reason on WorldModelTask nodes"

_TASK_KIND = "WMTask"


def upgrade(engine: Engine) -> None:
    rows = engine.nodes(_TASK_KIND).limit(10_000).execute()
    for node in rows.nodes:
        props = dict(node.properties) if node.properties else {}
        if "failure_reason" in props:
            continue
        props["failure_reason"] = ""
        engine.write(
            WriteRequest(
                label="migration-002-task-failure-reason",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=node.logical_id,
                        kind=_TASK_KIND,
                        properties=props,
                        source_ref="memex:migration-002",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
