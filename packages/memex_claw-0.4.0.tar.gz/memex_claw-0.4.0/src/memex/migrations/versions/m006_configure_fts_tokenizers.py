"""Configure FTS tokenizer profiles on property-FTS node kinds."""

from __future__ import annotations

import logging

from fathomdb import Engine

REVISION = "006"
DESCRIPTION = "Configure recall-optimized-english tokenizer on prose property-FTS kinds"

logger = logging.getLogger(__name__)

_RECALL_KINDS = [
    "WMGoal",
    "WMTask",
    "WMCommitment",
    "WMAction",
    "WMExecutionRecord",
    "WMKnowledgeObject",
    "WMPlan",
    "WMPlanStep",
    "WMPlanStepTransition",
    "WMEvent",
    "WMObservation",
    "WMClaimEvaluation",
    "Goal",
]
_PRECISION_KINDS = [
    "WMSemanticMapping",
    "WMProvenanceLink",
]


def upgrade(engine: Engine) -> None:
    _configure_kind_group(engine, _RECALL_KINDS, "recall-optimized-english")
    _configure_kind_group(engine, _PRECISION_KINDS, "precision-optimized")


def _configure_kind_group(engine: Engine, kinds: list[str], tokenizer: str) -> None:
    for kind in kinds:
        if engine.admin.get_fts_profile(kind) is not None:
            continue
        schema = engine.admin.describe_fts_property_schema(kind)
        if schema is None:
            logger.warning("m006: no property-FTS schema for %s — skipping", kind)
            continue
        engine.admin.configure_fts(kind, tokenizer, agree_to_rebuild_impact=True)
        engine.admin.register_fts_property_schema_with_entries(
            kind, list(schema.entries)
        )
