"""Backfill ``metadata`` field on Goal nodes that lack it.

Older Goal nodes may have been created before the ``metadata`` field was
added to the Goal model.  This migration ensures every Goal node has an
explicit ``metadata`` property (empty dict) so that JSON-path filters on
``$.metadata`` work reliably.
"""

from __future__ import annotations

from fathomdb import ChunkPolicy, Engine, NodeInsert, WriteRequest, new_row_id

REVISION = "001"
DESCRIPTION = "Backfill metadata field on Goal nodes"

_GOAL_KIND = "Goal"


def upgrade(engine: Engine) -> None:
    rows = engine.nodes(_GOAL_KIND).limit(10_000).execute()
    for node in rows.nodes:
        props = dict(node.properties) if node.properties else {}
        if "metadata" in props:
            continue
        props["metadata"] = {}
        engine.write(
            WriteRequest(
                label="migration-001-goal-metadata",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id=node.logical_id,
                        kind=_GOAL_KIND,
                        properties=props,
                        source_ref="memex:migration-001",
                        upsert=True,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
