"""Register FTS property schemas v2: scalar + recursive $.payload + WMPlanStepTransition.

Supersedes m003 by upserting all schemas via register_fts_property_schema_with_entries
(idempotent per fathomdb docs/guides/property-fts.md). Adds:

* Recursive ``$.payload`` entries on WMAction, WMGoal, WMKnowledgeObject, and
  WMExecutionRecord so the 44s canonical_outcome_hits and 12s execution_record_docs
  hot paths collapse into sub-second property-FTS calls.
* WMPlanStepTransition registration, previously silently unindexed.

Rebuild cost: schema upsert with a new recursive path performs an eager
transactional rebuild per ``docs/guides/property-fts.md:185-196``. On a production
database with ~1M WMExecutionRecord rows this can take 5–10 minutes of blocking
rebuild on first application. Run during a maintenance window.

Requires fathomdb >= 0.3.1 which carries the fix for the recursive-walker
empty-leaf offset bug (the earlier 0.3.0 implementation violated
``UNIQUE(node_logical_id, kind, start_offset)`` whenever an empty scalar leaf was
emitted before a non-empty leaf at the same recursion depth, hitting production
payloads with common shapes like ``{'tags': ['', 'foo']}``).

Exclude paths are left empty. If check_semantics() flags drift or the rebuild is
too slow on first production run, tune by opening the payload constructors in
src/memex/models.py and identifying high-volume low-text subkeys.
"""

from __future__ import annotations

import logging

from fathomdb import (
    Engine,
    FtsPropertyPathMode,
    FtsPropertyPathSpec,
)

logger = logging.getLogger(__name__)

REVISION = "004"
DESCRIPTION = (
    "Register FTS property schemas v2 (recursive $.payload + WMPlanStepTransition)"
)

# Threshold above which the eager transactional rebuild becomes a noticeable
# blocking operation (~30–60s per 100k WMExecutionRecord rows).
_REBUILD_WARN_THRESHOLD = 100_000


def _scalar(path: str) -> FtsPropertyPathSpec:
    return FtsPropertyPathSpec(path=path, mode=FtsPropertyPathMode.SCALAR)


def _recursive(path: str) -> FtsPropertyPathSpec:
    return FtsPropertyPathSpec(path=path, mode=FtsPropertyPathMode.RECURSIVE)


_SCHEMAS: list[tuple[str, list[FtsPropertyPathSpec]]] = [
    (
        "WMAction",
        [
            _scalar("$.action_name"),
            _scalar("$.action_kind"),
            _scalar("$.status"),
            _recursive("$.payload"),
        ],
    ),
    (
        "WMExecutionRecord",
        [
            _scalar("$.execution_kind"),
            _scalar("$.status"),
            _scalar("$.title"),
            _scalar("$.summary"),
            _recursive("$.payload"),
        ],
    ),
    (
        "WMKnowledgeObject",
        [
            _scalar("$.title"),
            _scalar("$.knowledge_type"),
            _scalar("$.source_url"),
            _scalar("$.canonical_key"),
            _recursive("$.payload"),
        ],
    ),
    (
        "WMGoal",
        [
            _scalar("$.title"),
            _scalar("$.description"),
            _scalar("$.status"),
            _scalar("$.priority"),
            _scalar("$.blocked_reason"),
            _recursive("$.payload"),
        ],
    ),
    (
        "WMTask",
        [
            _scalar("$.title"),
            _scalar("$.description"),
            _scalar("$.task_kind"),
            _scalar("$.status"),
        ],
    ),
    (
        "WMPlan",
        [
            _scalar("$.title"),
            _scalar("$.summary"),
            _scalar("$.status"),
        ],
    ),
    (
        "WMPlanStep",
        [
            _scalar("$.title"),
            _scalar("$.description"),
            _scalar("$.status"),
            _scalar("$.step_kind"),
        ],
    ),
    (
        "WMPlanStepTransition",
        [
            _scalar("$.transition_kind"),
            _scalar("$.summary"),
            _scalar("$.from_status"),
            _scalar("$.to_status"),
            _scalar("$.blocked_reason"),
        ],
    ),
    (
        "WMEvent",
        [
            _scalar("$.title"),
            _scalar("$.summary"),
            _scalar("$.event_kind"),
        ],
    ),
    (
        "WMCommitment",
        [
            _scalar("$.title"),
            _scalar("$.description"),
            _scalar("$.assignee"),
            _scalar("$.agreed_by"),
        ],
    ),
    (
        "WMSemanticMapping",
        [
            _scalar("$.source_value"),
            _scalar("$.target_value"),
            _scalar("$.mapping_kind"),
        ],
    ),
    (
        "WMObservation",
        [
            _scalar("$.summary"),
            _scalar("$.observation_kind"),
        ],
    ),
    (
        "WMClaimEvaluation",
        [
            _scalar("$.title"),
            _scalar("$.summary"),
            _scalar("$.evaluation_kind"),
        ],
    ),
    (
        "Goal",
        [
            _scalar("$.title"),
            _scalar("$.description"),
            _scalar("$.blocked_reason"),
        ],
    ),
]


def _warn_if_large_rebuild(engine: Engine) -> None:
    """Surface an estimated rebuild window to operators before m004 blocks.

    WMExecutionRecord is the dominant cost because its schema adds a new
    recursive ``$.payload`` entry. We query slightly above the warn
    threshold so the "how many rows" answer is bounded even on huge DBs.
    """
    try:
        rows = (
            engine.nodes("WMExecutionRecord")
            .limit(_REBUILD_WARN_THRESHOLD + 1)
            .execute()
        )
    except Exception:
        logger.debug("m004: WMExecutionRecord row-count probe failed", exc_info=True)
        return
    count = len(rows.nodes)
    if count <= _REBUILD_WARN_THRESHOLD:
        return
    est_minutes = max(1, round((count * 45) / 60000))
    qualifier = "at least " if count == _REBUILD_WARN_THRESHOLD + 1 else ""
    logger.warning(
        "m004: rebuilding %s%d WMExecutionRecord FTS entries — expected ~%d "
        "minute(s) of blocking work. Consider running during a maintenance "
        "window.",
        qualifier,
        count,
        est_minutes,
    )


def upgrade(engine: Engine) -> None:
    # Per-kind upserts trigger eager transactional rebuilds for any kind whose
    # schema differs from what's stored (per fathomdb
    # docs/guides/property-fts.md:185-196). A terminal admin.rebuild(FTS) call
    # would fire a second full rebuild pass on top, doubling the blocking
    # maintenance-window cost, so it is intentionally omitted.
    _warn_if_large_rebuild(engine)
    for kind, entries in _SCHEMAS:
        engine.admin.register_fts_property_schema_with_entries(kind, entries=entries)
