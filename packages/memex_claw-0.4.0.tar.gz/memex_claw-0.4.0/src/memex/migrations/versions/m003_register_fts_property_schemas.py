"""Register FTS property schemas for world-model node kinds.

Enables FathomDB Property FTS on each world-model node kind so that
``text_search()`` queries hit FTS5 virtual tables instead of requiring
Python-side JSON serialisation and substring matching.
"""

from __future__ import annotations

from fathomdb import Engine, ProjectionTarget

REVISION = "003"
DESCRIPTION = "Register FTS property schemas for world-model node kinds"

_SCHEMAS: list[tuple[str, list[str]]] = [
    ("WMAction", ["$.action_name", "$.action_kind", "$.status"]),
    ("WMExecutionRecord", ["$.execution_kind", "$.status", "$.title", "$.summary"]),
    (
        "WMKnowledgeObject",
        ["$.title", "$.knowledge_type", "$.source_url", "$.canonical_key"],
    ),
    ("WMGoal", ["$.title", "$.description", "$.status", "$.priority"]),
    ("WMTask", ["$.title", "$.description", "$.task_kind", "$.status"]),
    ("WMPlan", ["$.title", "$.summary", "$.status"]),
    ("WMPlanStep", ["$.title", "$.description", "$.status", "$.step_kind"]),
    ("WMEvent", ["$.title", "$.summary", "$.event_kind"]),
    ("WMCommitment", ["$.title", "$.description", "$.assignee", "$.agreed_by"]),
    ("WMSemanticMapping", ["$.source_value", "$.target_value", "$.mapping_kind"]),
    ("WMObservation", ["$.summary", "$.observation_kind"]),
    ("WMClaimEvaluation", ["$.title", "$.summary", "$.evaluation_kind"]),
    # GoalsRepository uses kind "Goal" (separate from WMGoal)
    ("Goal", ["$.title", "$.description", "$.blocked_reason"]),
]


def upgrade(engine: Engine) -> None:
    for kind, paths in _SCHEMAS:
        engine.admin.register_fts_property_schema(kind, paths)
    engine.admin.rebuild(ProjectionTarget.FTS)
