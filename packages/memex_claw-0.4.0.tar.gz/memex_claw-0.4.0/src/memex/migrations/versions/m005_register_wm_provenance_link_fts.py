"""Register property FTS on WMProvenanceLink.

Completes the fathomdb 0.3.1 retrieval cutover by moving
``search_dependency_documents`` off its 5000-row Python scan and onto
property-FTS on the ``WMProvenanceLink`` node kind. The migration
declares scalar FTS paths for the link's relationship, endpoint types,
and denormalized source/target titles/statuses (the denormalized fields
are populated at write time by
``FathomMemexStore.upsert_world_model_provenance_link``).

See ``dev/notes/wm-provenance-link-denormalization.md`` for the full
design. Runs after m004 on fresh databases and as a one-shot upsert on
existing databases. Rebuild time on existing databases is seconds to
tens of seconds at current production scale (scalar-only entries; no
recursive walk).
"""

from __future__ import annotations

from fathomdb import (
    Engine,
    FtsPropertyPathMode,
    FtsPropertyPathSpec,
)

REVISION = "005"
DESCRIPTION = "Register property FTS on WMProvenanceLink for dependency search"


def _scalar(path: str) -> FtsPropertyPathSpec:
    return FtsPropertyPathSpec(path=path, mode=FtsPropertyPathMode.SCALAR)


_ENTRIES = [
    _scalar("$.relationship"),
    _scalar("$.source_type"),
    _scalar("$.target_type"),
    _scalar("$.source_title"),
    _scalar("$.source_status"),
    _scalar("$.target_title"),
    _scalar("$.target_status"),
]


def upgrade(engine: Engine) -> None:
    engine.admin.register_fts_property_schema_with_entries(
        "WMProvenanceLink", entries=_ENTRIES
    )
