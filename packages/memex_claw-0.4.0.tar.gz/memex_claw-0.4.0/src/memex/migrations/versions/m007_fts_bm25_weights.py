"""Re-register WM FTS schemas with BM25 per-column weights.

Supersedes m004's uniform-weight schemas. All 14 WM kinds are upserted with
FtsPropertyPathSpec.with_weight(f32). Schema upsert triggers per-kind
transactional FTS rebuild (same as m004).

Weight policy:
  2.0  primary semantic identifiers (title, action_name, source_value, target_value)
  1.0  narrative content (description, summary, blocked_reason)
  0.4  structured metadata (status, kind fields, assignee)
  0.2  catch-all / identifiers (payload recursive, canonical_key, source_url)
"""

from __future__ import annotations

import logging

from fathomdb import Engine, FtsPropertyPathMode, FtsPropertyPathSpec

logger = logging.getLogger(__name__)

REVISION = "007"
DESCRIPTION = "Re-register WM FTS schemas with BM25 per-column weights"

_REBUILD_WARN_THRESHOLD = 100_000


def _s(path: str, weight: float) -> FtsPropertyPathSpec:
    return FtsPropertyPathSpec(
        path=path, mode=FtsPropertyPathMode.SCALAR, weight=weight
    )


def _r(path: str, weight: float) -> FtsPropertyPathSpec:
    return FtsPropertyPathSpec(
        path=path, mode=FtsPropertyPathMode.RECURSIVE, weight=weight
    )


def _build_schemas() -> list[tuple[str, list[FtsPropertyPathSpec]]]:
    """Construct the per-kind FTS schema list with BM25 weights.

    Built lazily so the module is importable on fathomdb versions that predate
    FtsPropertyPathSpec.with_weight(); upgrade() is the only consumer and will
    surface the AttributeError at migration time if the runtime is too old.
    """
    return [
        (
            "WMAction",
            [
                _s("$.action_name", 2.0),
                _s("$.action_kind", 0.4),
                _s("$.status", 0.4),
                _r("$.payload", 0.2),
            ],
        ),
        (
            "WMExecutionRecord",
            [
                _s("$.title", 2.0),
                _s("$.summary", 1.0),
                _s("$.execution_kind", 0.4),
                _s("$.status", 0.4),
                _r("$.payload", 0.2),
            ],
        ),
        (
            "WMKnowledgeObject",
            [
                _s("$.title", 2.0),
                _s("$.knowledge_type", 0.4),
                _s("$.source_url", 0.2),
                _s("$.canonical_key", 0.2),
                _r("$.payload", 0.2),
            ],
        ),
        (
            "WMGoal",
            [
                _s("$.title", 2.0),
                _s("$.description", 1.0),
                _s("$.blocked_reason", 1.0),
                _s("$.status", 0.4),
                _s("$.priority", 0.4),
                _r("$.payload", 0.2),
            ],
        ),
        (
            "WMTask",
            [
                _s("$.title", 2.0),
                _s("$.description", 1.0),
                _s("$.task_kind", 0.4),
                _s("$.status", 0.4),
            ],
        ),
        (
            "WMPlan",
            [
                _s("$.title", 2.0),
                _s("$.summary", 1.0),
                _s("$.status", 0.4),
            ],
        ),
        (
            "WMPlanStep",
            [
                _s("$.title", 2.0),
                _s("$.description", 1.0),
                _s("$.status", 0.4),
                _s("$.step_kind", 0.4),
            ],
        ),
        (
            "WMPlanStepTransition",
            [
                _s("$.summary", 1.0),
                _s("$.blocked_reason", 1.0),
                _s("$.transition_kind", 0.4),
                _s("$.from_status", 0.4),
                _s("$.to_status", 0.4),
            ],
        ),
        (
            "WMEvent",
            [
                _s("$.title", 2.0),
                _s("$.summary", 1.0),
                _s("$.event_kind", 0.4),
            ],
        ),
        (
            "WMCommitment",
            [
                _s("$.title", 2.0),
                _s("$.description", 1.0),
                _s("$.assignee", 0.4),
                _s("$.agreed_by", 0.4),
            ],
        ),
        (
            "WMSemanticMapping",
            [
                _s("$.source_value", 2.0),
                _s("$.target_value", 2.0),
                _s("$.mapping_kind", 0.4),
            ],
        ),
        (
            "WMObservation",
            [
                _s("$.summary", 1.0),
                _s("$.observation_kind", 0.4),
            ],
        ),
        (
            "WMClaimEvaluation",
            [
                _s("$.title", 2.0),
                _s("$.summary", 1.0),
                _s("$.evaluation_kind", 0.4),
            ],
        ),
        (
            "Goal",
            [
                _s("$.title", 2.0),
                _s("$.description", 1.0),
                _s("$.blocked_reason", 1.0),
            ],
        ),
    ]


def _warn_if_large_rebuild(engine: Engine) -> None:
    try:
        rows = (
            engine.nodes("WMExecutionRecord")
            .limit(_REBUILD_WARN_THRESHOLD + 1)
            .execute()
        )
    except Exception:
        logger.debug("m007: WMExecutionRecord row-count probe failed", exc_info=True)
        return
    count = len(rows.nodes)
    if count <= _REBUILD_WARN_THRESHOLD:
        return
    est_minutes = max(1, round((count * 45) / 60000))
    qualifier = "at least " if count == _REBUILD_WARN_THRESHOLD + 1 else ""
    logger.warning(
        "m007: re-registering %s%d WMExecutionRecord FTS entries with BM25 weights"
        " — expected ~%d minute(s) of blocking work.",
        qualifier,
        count,
        est_minutes,
    )


def upgrade(engine: Engine) -> None:
    probe = FtsPropertyPathSpec(path="$.title", mode=FtsPropertyPathMode.SCALAR)
    if not hasattr(probe, "weight"):
        logger.warning(
            "m007: installed fathomdb lacks FtsPropertyPathSpec.weight; "
            "skipping BM25 weight re-registration. Upgrade to fathomdb 0.5.0+ "
            "to apply."
        )
        return
    _warn_if_large_rebuild(engine)
    for kind, entries in _build_schemas():
        engine.admin.register_fts_property_schema_with_entries(kind, entries=entries)
