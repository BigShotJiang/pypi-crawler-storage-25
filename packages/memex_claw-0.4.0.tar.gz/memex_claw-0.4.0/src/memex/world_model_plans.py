from __future__ import annotations

from memex.models import (
    WorldModelActionPlan,
    WorldModelExecutionRecord,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
    WorldModelProvenanceLink,
)


def build_world_model_action_plan_provenance_links(
    plan: WorldModelActionPlan,
) -> list[WorldModelProvenanceLink]:
    links: list[WorldModelProvenanceLink] = []
    if plan.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_action_plan:{plan.plan_id}"
                    f"->for_goal:world_model_goal:{plan.goal_id}"
                ),
                source_record_type="world_model_action_plan",
                source_record_id=plan.plan_id,
                target_record_type="world_model_goal",
                target_record_id=plan.goal_id,
                relationship="for_goal",
                created_at=plan.updated_at,
            )
        )
    if plan.selected_step_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_action_plan:{plan.plan_id}"
                    f"->selected_step:world_model_plan_step:{plan.selected_step_id}"
                ),
                source_record_type="world_model_action_plan",
                source_record_id=plan.plan_id,
                target_record_type="world_model_plan_step",
                target_record_id=plan.selected_step_id,
                relationship="selected_step",
                created_at=plan.updated_at,
            )
        )
    return links


def build_world_model_plan_step_provenance_links(
    step: WorldModelPlanStep,
) -> list[WorldModelProvenanceLink]:
    links = [
        WorldModelProvenanceLink(
            link_id=(
                f"world_model_plan_step:{step.step_id}"
                f"->part_of_plan:world_model_action_plan:{step.plan_id}"
            ),
            source_record_type="world_model_plan_step",
            source_record_id=step.step_id,
            target_record_type="world_model_action_plan",
            target_record_id=step.plan_id,
            relationship="part_of_plan",
            created_at=step.updated_at,
        )
    ]
    if step.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step:{step.step_id}"
                    f"->for_goal:world_model_goal:{step.goal_id}"
                ),
                source_record_type="world_model_plan_step",
                source_record_id=step.step_id,
                target_record_type="world_model_goal",
                target_record_id=step.goal_id,
                relationship="for_goal",
                created_at=step.updated_at,
            )
        )
    for depends_on_step_id in step.depends_on_step_ids:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step:{step.step_id}"
                    f"->depends_on_step:world_model_plan_step:{depends_on_step_id}"
                ),
                source_record_type="world_model_plan_step",
                source_record_id=step.step_id,
                target_record_type="world_model_plan_step",
                target_record_id=depends_on_step_id,
                relationship="depends_on_step",
                created_at=step.updated_at,
            )
        )
    for blocked_by_step_id in step.blocked_by_step_ids:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step:{step.step_id}"
                    f"->blocked_by_step:world_model_plan_step:{blocked_by_step_id}"
                ),
                source_record_type="world_model_plan_step",
                source_record_id=step.step_id,
                target_record_type="world_model_plan_step",
                target_record_id=blocked_by_step_id,
                relationship="blocked_by_step",
                created_at=step.updated_at,
            )
        )
    return links


def build_world_model_execution_record_provenance_links(
    record: WorldModelExecutionRecord,
) -> list[WorldModelProvenanceLink]:
    links: list[WorldModelProvenanceLink] = []
    if record.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_execution_record:{record.execution_id}"
                    f"->for_goal:world_model_goal:{record.goal_id}"
                ),
                source_record_type="world_model_execution_record",
                source_record_id=record.execution_id,
                target_record_type="world_model_goal",
                target_record_id=record.goal_id,
                relationship="for_goal",
                created_at=record.updated_at,
            )
        )
    if record.plan_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_execution_record:{record.execution_id}"
                    f"->for_plan:world_model_action_plan:{record.plan_id}"
                ),
                source_record_type="world_model_execution_record",
                source_record_id=record.execution_id,
                target_record_type="world_model_action_plan",
                target_record_id=record.plan_id,
                relationship="for_plan",
                created_at=record.updated_at,
            )
        )
    if record.step_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_execution_record:{record.execution_id}"
                    f"->executes_step:world_model_plan_step:{record.step_id}"
                ),
                source_record_type="world_model_execution_record",
                source_record_id=record.execution_id,
                target_record_type="world_model_plan_step",
                target_record_id=record.step_id,
                relationship="executes_step",
                created_at=record.updated_at,
            )
        )
    links.append(
        WorldModelProvenanceLink(
            link_id=(
                f"world_model_execution_record:{record.execution_id}"
                f"->records_source:{record.source_record_type}:{record.source_record_id}"
            ),
            source_record_type="world_model_execution_record",
            source_record_id=record.execution_id,
            target_record_type=record.source_record_type,
            target_record_id=record.source_record_id,
            relationship="records_source",
            created_at=record.updated_at,
        )
    )
    return links


def build_world_model_plan_step_transition_provenance_links(
    transition: WorldModelPlanStepTransition,
) -> list[WorldModelProvenanceLink]:
    links = [
        WorldModelProvenanceLink(
            link_id=(
                f"world_model_plan_step_transition:{transition.transition_id}"
                f"->part_of_plan:world_model_action_plan:{transition.plan_id}"
            ),
            source_record_type="world_model_plan_step_transition",
            source_record_id=transition.transition_id,
            target_record_type="world_model_action_plan",
            target_record_id=transition.plan_id,
            relationship="part_of_plan",
            created_at=transition.updated_at,
        ),
        WorldModelProvenanceLink(
            link_id=(
                f"world_model_plan_step_transition:{transition.transition_id}"
                f"->updates_step:world_model_plan_step:{transition.step_id}"
            ),
            source_record_type="world_model_plan_step_transition",
            source_record_id=transition.transition_id,
            target_record_type="world_model_plan_step",
            target_record_id=transition.step_id,
            relationship="updates_step",
            created_at=transition.updated_at,
        ),
    ]
    if transition.goal_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step_transition:{transition.transition_id}"
                    f"->for_goal:world_model_goal:{transition.goal_id}"
                ),
                source_record_type="world_model_plan_step_transition",
                source_record_id=transition.transition_id,
                target_record_type="world_model_goal",
                target_record_id=transition.goal_id,
                relationship="for_goal",
                created_at=transition.updated_at,
            )
        )
    if transition.execution_id:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step_transition:{transition.transition_id}"
                    "->emitted_by_execution:"
                    f"world_model_execution_record:{transition.execution_id}"
                ),
                source_record_type="world_model_plan_step_transition",
                source_record_id=transition.transition_id,
                target_record_type="world_model_execution_record",
                target_record_id=transition.execution_id,
                relationship="emitted_by_execution",
                created_at=transition.updated_at,
            )
        )
    for blocked_by_step_id in transition.blocked_by_step_ids or []:
        links.append(
            WorldModelProvenanceLink(
                link_id=(
                    f"world_model_plan_step_transition:{transition.transition_id}"
                    f"->blocked_by_step:world_model_plan_step:{blocked_by_step_id}"
                ),
                source_record_type="world_model_plan_step_transition",
                source_record_id=transition.transition_id,
                target_record_type="world_model_plan_step",
                target_record_id=blocked_by_step_id,
                relationship="blocked_by_step",
                created_at=transition.updated_at,
            )
        )
    return links
