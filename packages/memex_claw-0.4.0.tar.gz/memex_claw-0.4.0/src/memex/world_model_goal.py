from __future__ import annotations

from memex.models import Goal, WorldModelGoal


def build_world_model_goal(goal: Goal) -> WorldModelGoal:
    return WorldModelGoal(
        goal_id=goal.goal_id,
        parent_goal_id=goal.parent_id,
        title=goal.title,
        description=goal.description,
        status=goal.status.value,
        priority=goal.priority.value,
        blocked_by_goal_id=goal.blocked_by_goal_id,
        blocked_reason=goal.blocked_reason or "",
        failure_reason=goal.failure_reason or "",
        deadline_text=goal.deadline.isoformat() if goal.deadline else "",
        payload=dict(goal.metadata or {}),
        source_surface="c08_world_model_goal",
        created_at=goal.created_at,
        updated_at=goal.updated_at,
    )
