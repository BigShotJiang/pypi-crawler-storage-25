"""Audit logging and connector health persistence.

All live paths now go through FathomMemexStore methods directly.
This module is kept as a namespace stub for any future shared utilities.
"""
