"""Decay functions for knowledge items. Pure math, no I/O."""

from __future__ import annotations

import math
from datetime import datetime

from memex.models import Item, ItemType

DEFAULT_HALF_LIFE: dict[ItemType, float] = {
    ItemType.ARTICLE: 60.0,
    ItemType.NOTE: 30.0,
    ItemType.THOUGHT: 14.0,
    ItemType.LINK: 90.0,
    ItemType.CLIPPING: 30.0,
    ItemType.CONVERSATION: 180.0,
    ItemType.VOICE_MEMO: 14.0,
    ItemType.MEETING: 60.0,
}


def current_decay_weight(
    last_accessed: datetime,
    half_life_days: float,
    now: datetime,
    *,
    pinned: bool = False,
    is_milestone: bool = False,
    milestone_boost: float = 2.0,
) -> float:
    """Compute decay weight: 0.5 ** (days_since_access / effective_half_life).

    Pinned items always return 1.0.
    Milestones get their half_life multiplied by milestone_boost.
    """
    if pinned:
        return 1.0

    effective_half_life = half_life_days
    if is_milestone:
        effective_half_life *= milestone_boost

    if effective_half_life <= 0:
        return 0.0

    delta_days = (now - last_accessed).total_seconds() / 86400.0
    if delta_days <= 0:
        return 1.0

    return math.pow(0.5, delta_days / effective_half_life)


def item_decay_weight(item: Item, now: datetime) -> float:
    """Convenience wrapper extracting fields from Item."""
    return current_decay_weight(
        item.last_accessed,
        item.half_life_days,
        now,
        pinned=item.pinned,
        is_milestone=item.is_milestone,
    )


def is_expired(item: Item, now: datetime) -> bool:
    """Check if item.expires_at has passed."""
    if item.expires_at is None:
        return False
    return now > item.expires_at
