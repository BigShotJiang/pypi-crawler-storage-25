"""Read-side helpers for canonical world-model retrieval access."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any


from memex.models import (
    WorldModelActionPlan,
    WorldModelClaimEvaluation,
    WorldModelCommitment,
    WorldModelExecutionRecord,
    WorldModelEvent,
    WorldModelGoal,
    WorldModelKnowledgeObject,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
    WorldModelSemanticMapping,
    WorldModelTask,
)

logger = logging.getLogger(__name__)

# Retained as a type alias for callers that use it as a parameter annotation.
WorldModelReadStore = Any


@dataclass(frozen=True)
class CanonicalOutcomeHit:
    action_id: str
    meeting_id: str | None
    conversation_turn_id: int | None
    action_kind: str
    action_name: str
    status: str
    payload: dict[str, Any] = field(default_factory=dict)
    source_surface: str = ""
    score: float = 0.0
    observations: list[dict[str, Any]] = field(default_factory=list)
    provenance: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalKnowledgeHit:
    knowledge: WorldModelKnowledgeObject
    score: float
    relationships: list[dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalSemanticMappingHit:
    mapping: WorldModelSemanticMapping
    score: float


@dataclass(frozen=True)
class CanonicalEventHit:
    event: WorldModelEvent
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalTaskHit:
    task: WorldModelTask
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)
    incoming_links: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalGoalHit:
    goal: WorldModelGoal
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)
    incoming_links: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalActionPlanHit:
    plan: WorldModelActionPlan
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)
    incoming_links: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalPlanStepHit:
    step: WorldModelPlanStep
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)
    incoming_links: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalExecutionRecordHit:
    record: WorldModelExecutionRecord
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalPlanStepTransitionHit:
    transition: WorldModelPlanStepTransition
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalCommitmentHit:
    commitment: WorldModelCommitment
    score: float
    provenance: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class CanonicalClaimEvaluationHit:
    evaluation: WorldModelClaimEvaluation
    score: float


@dataclass(frozen=True)
class CanonicalDependencyHit:
    link_id: str
    relationship: str
    source_record_type: str
    source_record_id: str
    source_title: str
    source_status: str
    target_record_type: str
    target_record_id: str
    target_title: str
    target_status: str
    score: float

    @property
    def document_id(self) -> str:
        return f"world_model_dependency:{self.link_id}"


# ---------------------------------------------------------------------------
# Dependency relationship whitelist — the set of ``WMProvenanceLink.relationship``
# values that count as "dependencies" for retrieval purposes. Hoisted to
# module level so ``search_dependency_documents`` and any future
# dependency-related helpers share one canonical list; adding a new
# relationship kind that should participate in dependency search is a
# one-line change here.
# ---------------------------------------------------------------------------


_DEPENDENCY_RELATIONSHIPS: frozenset[str] = frozenset(
    {
        "blocked_by",
        "advances_goal",
        "updates_goal",
        "for_goal",
        "creates_task",
        "depends_on_step",
        "blocked_by_step",
        "promoted_action_item",
        "explicit",
        "child_of",
    }
)


# ---------------------------------------------------------------------------
# Shared helpers usable from both the read and write paths
# ---------------------------------------------------------------------------


def resolve_record_title_status(
    store: Any, record_type: str, record_id: str
) -> tuple[str, str]:
    """Resolve ``(title, status)`` for a world-model record by type + id.

    Used by both the read side (``FathomWorldModelReads`` for dependency
    search) and the write side (``FathomMemexStore.upsert_world_model_provenance_link``
    for denormalizing source/target titles onto WMProvenanceLink nodes).

    Returns ``(record_id, "")`` on any lookup failure so callers always
    get strings they can index or display without None checks.
    """
    loaders: dict[str, Any] = {
        "world_model_goal": store.load_world_model_goal,
        "world_model_task": store.load_world_model_task,
        "world_model_action_plan": store.load_world_model_action_plan,
        "world_model_plan_step": store.load_world_model_plan_step,
        "world_model_execution_record": store.load_world_model_execution_record,
        "world_model_commitment": store.load_world_model_commitment,
        "meeting": store.meetings.get_meeting,
    }
    loader = loaders.get(record_type)
    if loader is None:
        return record_id, ""
    try:
        rec = loader(record_id)
        if rec is None:
            return record_id, ""
        title = (
            getattr(rec, "title", None)
            or getattr(rec, "display_name", None)
            or record_id
        )
        status = getattr(rec, "status", "") or ""
        return title, status
    except Exception:
        return record_id, ""


# ---------------------------------------------------------------------------
# FathomDB-backed reads
# ---------------------------------------------------------------------------


class FathomWorldModelReads:
    """Canonical world-model read authority backed by FathomDB."""

    def __init__(self, store: Any) -> None:
        self._store = store

    def _load_provenance(
        self, source_type: str, source_id: str
    ) -> list[dict[str, str]]:
        links = self._store.list_world_model_provenance_links(
            source_record_type=source_type,
            source_record_id=source_id,
        )
        return [
            {
                "relationship": link.relationship,
                "target_record_type": link.target_record_type,
                "target_record_id": link.target_record_id,
            }
            for link in links
        ]

    def _load_incoming_links(
        self,
        target_type: str,
        target_id: str,
        *,
        relationships: tuple[str, ...],
    ) -> list[dict[str, str]]:
        """Load incoming provenance links that point at the given target."""
        all_links = self._store._fathom.world_model.list_provenance_links(
            target_type=target_type,
            target_id=target_id,
        )
        result: list[dict[str, str]] = []
        for d in all_links:
            rel = str(d.get("relationship") or "")
            if rel not in relationships:
                continue
            source_type = str(d.get("source_type") or "")
            source_id = str(d.get("source_id") or "")
            result.append(
                {
                    "relationship": rel,
                    "source_record_type": source_type,
                    "source_record_id": source_id,
                    "source_title": source_id,
                    "source_status": "",
                }
            )
        return result

    def load_knowledge_map(self, item_ids: list[str]) -> dict[str, Any]:
        if not item_ids:
            return {}
        result: dict[str, Any] = {}
        for item_id in item_ids:
            try:
                ko = self._store.load_world_model_knowledge_object_by_item_id(item_id)
                if ko is not None:
                    result[item_id] = ko
            except Exception:
                pass
        return result

    def canonical_document_id_for_item(self, item_id: str) -> str | None:
        try:
            ko = self._store.load_world_model_knowledge_object_by_item_id(item_id)
            if ko is not None:
                return f"world_model_knowledge:{ko.knowledge_id}"
        except Exception:
            pass
        return None

    def load_semantic_mapping_document(
        self,
        mapping_id: str,
    ) -> CanonicalSemanticMappingHit | None:
        try:
            mapping = self._store.load_world_model_semantic_mapping(mapping_id)
        except Exception:
            return None
        if mapping is None:
            return None
        return CanonicalSemanticMappingHit(mapping=mapping, score=1.0)

    def load_event_document(
        self,
        event_id: str,
    ) -> CanonicalEventHit | None:
        try:
            event = self._store.load_world_model_event(event_id)
        except Exception:
            event = None
        if event is None:
            return None
        provenance = self._load_provenance("world_model_event", event_id)
        return CanonicalEventHit(
            event=event,
            score=1.0,
            provenance=provenance,
        )

    def load_canonical_outcome(
        self,
        action_id: str,
    ) -> CanonicalOutcomeHit | None:
        try:
            action = self._store.load_world_model_action(action_id)
        except Exception:
            logger.debug(
                "load_world_model_action failed for action_id=%s",
                action_id,
                exc_info=True,
            )
            return None
        if action is None:
            logger.warning(
                "load_canonical_outcome miss: action_id=%s not found via "
                "direct logical_id lookup",
                action_id,
            )
            return None
        action_kind = getattr(action, "action_kind", "") or ""
        action_name = getattr(action, "action_name", "") or ""
        payload = action.payload if isinstance(action.payload, dict) else {}
        observations = self._store.list_world_model_observations(
            action_id=action_id, limit=10
        )
        obs_dicts = [
            {
                "observation_kind": getattr(o, "observation_kind", ""),
                "summary": o.summary,
                "payload": o.payload,
            }
            for o in observations
        ]
        provenance = self._load_provenance("world_model_action", action_id)
        return CanonicalOutcomeHit(
            action_id=action_id,
            meeting_id=getattr(action, "meeting_id", None),
            conversation_turn_id=getattr(action, "conversation_turn_id", None),
            action_kind=action_kind,
            action_name=action_name,
            status=getattr(action, "status", ""),
            payload=payload,
            source_surface=getattr(action, "source_surface", ""),
            score=1.0,
            observations=obs_dicts,
            provenance=provenance,
        )

    def load_claim_evaluation_document(
        self,
        evaluation_id: str,
    ) -> CanonicalClaimEvaluationHit | None:
        try:
            evaluation = self._store.load_world_model_claim_evaluation(evaluation_id)
        except Exception:
            return None
        if evaluation is None:
            return None
        return CanonicalClaimEvaluationHit(evaluation=evaluation, score=1.0)

    def load_knowledge_document_hit(
        self,
        knowledge_id: str,
    ) -> CanonicalKnowledgeHit | None:
        try:
            ko = self._store._fathom.world_model.load_knowledge_object(knowledge_id)
        except Exception:
            ko = None
        if ko is None:
            return None
        relationships = self._load_knowledge_relationships(knowledge_id)
        return CanonicalKnowledgeHit(
            knowledge=ko,
            score=1.0,
            relationships=relationships,
        )

    def _load_knowledge_relationships(self, knowledge_id: str) -> list[dict[str, Any]]:
        try:
            rels = self._store.list_world_model_knowledge_relationships(
                source_knowledge_id=knowledge_id,
                limit=10,
            )
            result: list[dict[str, Any]] = []
            for rel in rels:
                entry: dict[str, Any] = {
                    "relationship_kind": rel.relationship_kind,
                    "target_knowledge_id": rel.target_knowledge_id,
                }
                if hasattr(rel, "summary"):
                    entry["summary"] = rel.summary
                # Try to resolve target title
                try:
                    target_ko = self._store._fathom.world_model.load_knowledge_object(
                        rel.target_knowledge_id
                    )
                    if target_ko is not None:
                        entry["target_title"] = target_ko.title
                except Exception:
                    pass
                result.append(entry)
            return result
        except Exception:
            return []

    def load_task_document(
        self,
        task_id: str,
    ) -> CanonicalTaskHit | None:
        task = self._store.load_world_model_task(task_id)
        if task is None:
            return None
        return CanonicalTaskHit(
            task=task,
            score=1.0,
            provenance=self._load_provenance("world_model_task", task_id),
            incoming_links=self._load_incoming_links(
                "world_model_task",
                task_id,
                relationships=("creates_task",),
            ),
        )

    def load_commitment_document(
        self,
        commitment_id: str,
    ) -> CanonicalCommitmentHit | None:
        commitment = self._store.load_world_model_commitment(commitment_id)
        if commitment is None:
            return None
        return CanonicalCommitmentHit(
            commitment=commitment,
            score=1.0,
            provenance=self._load_provenance("world_model_commitment", commitment_id),
        )

    # -- Goal documents --------------------------------------------------------

    def _load_goal_incoming_links(self, goal_id: str) -> list[dict[str, str]]:
        """Load incoming links for a goal, including implicit task/commitment refs."""
        links = self._load_incoming_links(
            "world_model_goal",
            goal_id,
            relationships=("for_goal", "promoted_action_item", "explicit"),
        )
        # Resolve meeting titles for meeting-sourced links
        for link in links:
            if link.get("source_record_type") == "meeting":
                try:
                    meeting = self._store.meetings.get_meeting(link["source_record_id"])
                    if meeting is not None:
                        link["source_title"] = meeting.title
                except Exception:
                    pass
        # Add implicit links from tasks that reference this goal
        tasks = self._store.list_world_model_tasks(goal_id=goal_id, limit=100)
        for task in tasks:
            links.append(
                {
                    "relationship": "advances_goal",
                    "source_record_type": "world_model_task",
                    "source_record_id": task.task_id,
                    "source_title": task.title,
                    "source_status": task.status,
                }
            )
        # Add implicit links from commitments that reference this goal
        commitments = self._store.list_world_model_commitments(
            goal_id=goal_id, limit=100
        )
        for commitment in commitments:
            links.append(
                {
                    "relationship": "updates_goal",
                    "source_record_type": "world_model_commitment",
                    "source_record_id": commitment.commitment_id,
                    "source_title": commitment.title,
                    "source_status": commitment.status,
                }
            )
        return links

    def load_goal_document(
        self,
        goal_id: str,
    ) -> CanonicalGoalHit | None:
        goal = self._store.load_world_model_goal(goal_id)
        if goal is None:
            return None
        return CanonicalGoalHit(
            goal=goal,
            score=1.0,
            provenance=self._load_provenance("world_model_goal", goal_id),
            incoming_links=self._load_goal_incoming_links(goal_id),
        )

    # -- Plan documents --------------------------------------------------------

    def load_action_plan_document(
        self,
        plan_id: str,
    ) -> CanonicalActionPlanHit | None:
        plan = self._store.load_world_model_action_plan(plan_id)
        if plan is None:
            return None
        return CanonicalActionPlanHit(
            plan=plan,
            score=1.0,
            provenance=self._load_provenance("world_model_action_plan", plan_id),
            incoming_links=self._load_incoming_links(
                "world_model_action_plan",
                plan_id,
                relationships=("part_of_plan", "for_plan"),
            ),
        )

    def load_plan_step_document(
        self,
        step_id: str,
    ) -> CanonicalPlanStepHit | None:
        step = self._store.load_world_model_plan_step(step_id)
        if step is None:
            return None
        return CanonicalPlanStepHit(
            step=step,
            score=1.0,
            provenance=self._load_provenance("world_model_plan_step", step_id),
            incoming_links=self._load_incoming_links(
                "world_model_plan_step",
                step_id,
                relationships=(
                    "selected_step",
                    "executes_step",
                    "depends_on_step",
                    "blocked_by_step",
                    "updates_step",
                ),
            ),
        )

    # -- Execution documents ---------------------------------------------------

    def load_execution_record_document(
        self,
        execution_id: str,
    ) -> CanonicalExecutionRecordHit | None:
        record = self._store.load_world_model_execution_record(execution_id)
        if record is None:
            return None
        return CanonicalExecutionRecordHit(
            record=record,
            score=1.0,
            provenance=self._load_provenance(
                "world_model_execution_record", execution_id
            ),
        )

    def load_plan_step_transition_document(
        self,
        transition_id: str,
    ) -> CanonicalPlanStepTransitionHit | None:
        transition = self._store.load_world_model_plan_step_transition(transition_id)
        if transition is None:
            return None
        return CanonicalPlanStepTransitionHit(
            transition=transition,
            score=1.0,
            provenance=self._load_provenance(
                "world_model_plan_step_transition", transition_id
            ),
        )

    # -- Dependency documents --------------------------------------------------

    def _resolve_record_title_status(
        self, record_type: str, record_id: str
    ) -> tuple[str, str]:
        """Load a world-model record and return (title, status).

        Thin delegator — the real implementation is the module-level
        :func:`resolve_record_title_status` so the same code can be
        called from the write path (``FathomMemexStore.upsert_world_model_provenance_link``)
        to denormalize titles at link creation time.
        """
        return resolve_record_title_status(self._store, record_type, record_id)

    def search_dependency_documents(
        self,
        query: str,
        *,
        limit: int,
    ) -> list[CanonicalDependencyHit]:
        """Property-FTS search over WMProvenanceLink restricted to dependency kinds.

        Replaces the prior 5000-row ``list_world_model_provenance_links``
        Python scan. See ``dev/notes/wm-provenance-link-denormalization.md``
        for the design. fathomdb 0.5.1's ``filter_json_fused_text_in``
        pushes the relationship-set filter into the search CTE, so no
        over-fetch or Python-side whitelist check is needed; ``$.relationship``
        is registered in the WMProvenanceLink FTS schema (m005).

        Dependency queries are intentionally OR-based across tokens — a
        dependency that mentions ``review`` is relevant context for a
        query about ``final review``, even if the dependency's
        denormalized titles don't carry both words. Fathomdb's default
        search grammar uses implicit-AND across tokens, so this helper
        rewrites the query into an explicit uppercase-OR expression per
        the text query grammar (``ship OR docs OR review``).
        """
        terms = _query_terms(query)
        if not terms:
            return []
        or_query = " OR ".join(terms)
        try:
            engine = self._store._fathom.world_model._engine
            rows = (
                engine.nodes("WMProvenanceLink")
                .search(or_query, limit)
                .filter_json_fused_text_in(
                    "$.relationship", list(_DEPENDENCY_RELATIONSHIPS)
                )
                .execute()
            )
        except Exception:
            logger.debug("WMProvenanceLink property-FTS failed", exc_info=True)
            return []
        if not rows.hits:
            return []

        hits: list[CanonicalDependencyHit] = []
        for hit in rows.hits:
            props = hit.node.properties or {}
            relationship = props.get("relationship", "")
            src_type = props.get("source_type", "")
            src_id = props.get("source_id", "")
            tgt_type = props.get("target_type", "")
            tgt_id = props.get("target_id", "")
            link_id = f"{src_type}:{src_id}->{relationship}:{tgt_type}:{tgt_id}"
            hits.append(
                CanonicalDependencyHit(
                    link_id=link_id,
                    relationship=relationship,
                    source_record_type=src_type,
                    source_record_id=src_id,
                    source_title=props.get("source_title") or src_id,
                    source_status=props.get("source_status", ""),
                    target_record_type=tgt_type,
                    target_record_id=tgt_id,
                    target_title=props.get("target_title") or tgt_id,
                    target_status=props.get("target_status", ""),
                    score=hit.score,
                )
            )
        return hits

    def load_dependency_document(
        self,
        link_id: str,
    ) -> CanonicalDependencyHit | None:
        # Parse link_id: "source_type:source_id->relationship:target_type:target_id"
        try:
            source_part, rest = link_id.split("->", 1)
            src_type, src_id = source_part.split(":", 1)
            rel_and_target = rest.split(":", 1)
            relationship = rel_and_target[0]
            tgt_type, tgt_id = rel_and_target[1].split(":", 1)
        except (ValueError, IndexError):
            return None

        src_title, src_status = self._resolve_record_title_status(src_type, src_id)
        tgt_title, tgt_status = self._resolve_record_title_status(tgt_type, tgt_id)

        return CanonicalDependencyHit(
            link_id=link_id,
            relationship=relationship,
            source_record_type=src_type,
            source_record_id=src_id,
            source_title=src_title,
            source_status=src_status,
            target_record_type=tgt_type,
            target_record_id=tgt_id,
            target_title=tgt_title,
            target_status=tgt_status,
            score=1.0,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def resolve_world_model_reads(
    *,
    content_store: Any,
    world_model_store: Any | None = None,
) -> FathomWorldModelReads | None:
    """Resolve canonical world-model read authority for retrieval."""
    from memex.fathom_facade import FathomMemexStore

    if isinstance(world_model_store, FathomMemexStore):
        return FathomWorldModelReads(world_model_store)
    if isinstance(content_store, FathomMemexStore):
        return FathomWorldModelReads(content_store)
    return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _query_terms(query: str) -> list[str]:
    terms: list[str] = []
    seen: set[str] = set()
    for raw in query.lower().split():
        term = raw.strip(".,:;!?()[]{}<>\"'`")
        if len(term) < 2 or term in seen:
            continue
        seen.add(term)
        terms.append(term)
    return terms
