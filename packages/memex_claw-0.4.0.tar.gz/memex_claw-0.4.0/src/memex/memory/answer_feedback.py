from __future__ import annotations

import datetime
import re
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from memex.fathom_store import FathomStore

from fathomdb import (
    OperationalAppend,
    OperationalFilterClause,
    OperationalPut,
    OperationalReadRequest,
    WriteRequest,
)


@dataclass
class AnswerObservation:
    answer_id: str
    session_id: str
    turn_ordinal: int
    created_at: str
    response_excerpt: str
    classification: str
    selected_path: str
    tool_call_count: int
    tool_names: list[str] = field(default_factory=list)
    retrieved_document_ids: list[str] = field(default_factory=list)
    route_profile: str = ""
    resolved: bool = False
    resolved_at: str | None = None


@dataclass
class AnswerFeedbackSignal:
    signal_id: str
    answer_id: str
    session_id: str
    observed_turn_ordinal: int
    created_at: str
    signal_type: str
    weight: float
    confidence: float
    evidence_text: str


@dataclass
class AnswerOutcome:
    answer_id: str
    label: str
    confidence: float
    last_updated_at: str
    based_on_signal_ids: list[str] = field(default_factory=list)


# ── Persistence ───────────────────────────────────────────────────────────────


def save_answer_observation(store: FathomStore, obs: AnswerObservation) -> None:
    payload = {
        "answer_id": obs.answer_id,
        "session_id": obs.session_id,
        "turn_ordinal": obs.turn_ordinal,
        "created_at": obs.created_at,
        "response_excerpt": obs.response_excerpt,
        "classification": obs.classification,
        "selected_path": obs.selected_path,
        "tool_call_count": obs.tool_call_count,
        "tool_names": obs.tool_names,
        "retrieved_document_ids": obs.retrieved_document_ids,
        "route_profile": obs.route_profile,
        "resolved": str(obs.resolved).lower(),
        "resolved_at": obs.resolved_at,
    }
    store.operational._engine.write(
        WriteRequest(
            label="answer-observation-append",
            operational_writes=[
                OperationalAppend(
                    collection="answer_observation",
                    record_key=obs.answer_id,
                    payload_json=payload,
                    source_ref="memex:answer-feedback",
                )
            ],
        )
    )


def load_latest_unresolved_observation(
    store: FathomStore, session_id: str
) -> AnswerObservation | None:
    try:
        report = store.operational._engine.admin.read_operational_collection(
            OperationalReadRequest(
                collection_name="answer_observation",
                filters=[
                    OperationalFilterClause.exact("session_id", session_id),
                    OperationalFilterClause.exact("resolved", "false"),
                ],
                limit=100,
            )
        )
        rows = report.rows
    except Exception:
        return None

    if not rows:
        return None

    # Pick the row with the largest turn_ordinal
    best = None
    best_ordinal = -1
    for row in rows:
        p = row.payload_json
        ordinal = p.get("turn_ordinal", 0)
        if ordinal > best_ordinal:
            best_ordinal = ordinal
            best = p

    if best is None:
        return None

    return AnswerObservation(
        answer_id=best.get("answer_id", ""),
        session_id=best.get("session_id", ""),
        turn_ordinal=best.get("turn_ordinal", 0),
        created_at=best.get("created_at", ""),
        response_excerpt=best.get("response_excerpt", ""),
        classification=best.get("classification", ""),
        selected_path=best.get("selected_path", ""),
        tool_call_count=best.get("tool_call_count", 0),
        tool_names=best.get("tool_names", []),
        retrieved_document_ids=best.get("retrieved_document_ids", []),
        route_profile=best.get("route_profile", ""),
        resolved=best.get("resolved", "false") == "true",
        resolved_at=best.get("resolved_at"),
    )


def save_feedback_signal(store: FathomStore, signal: AnswerFeedbackSignal) -> None:
    payload = {
        "signal_id": signal.signal_id,
        "answer_id": signal.answer_id,
        "session_id": signal.session_id,
        "observed_turn_ordinal": signal.observed_turn_ordinal,
        "created_at": signal.created_at,
        "signal_type": signal.signal_type,
        "weight": signal.weight,
        "confidence": signal.confidence,
        "evidence_text": signal.evidence_text,
    }
    store.operational._engine.write(
        WriteRequest(
            label="answer-feedback-signal-append",
            operational_writes=[
                OperationalAppend(
                    collection="answer_feedback_signal",
                    record_key=signal.signal_id,
                    payload_json=payload,
                    source_ref="memex:answer-feedback",
                )
            ],
        )
    )


def save_answer_outcome(store: FathomStore, outcome: AnswerOutcome) -> None:
    payload = {
        "answer_id": outcome.answer_id,
        "label": outcome.label,
        "confidence": outcome.confidence,
        "last_updated_at": outcome.last_updated_at,
        "based_on_signal_ids": outcome.based_on_signal_ids,
    }
    store.operational._engine.write(
        WriteRequest(
            label="answer-outcome-put",
            operational_writes=[
                OperationalPut(
                    collection="answer_outcome",
                    record_key=outcome.answer_id,
                    payload_json=payload,
                    source_ref="memex:answer-feedback",
                )
            ],
        )
    )


def mark_observation_resolved(
    store: FathomStore, answer_id: str, resolved_at: str
) -> None:
    store.operational._engine.write(
        WriteRequest(
            label="answer-observation-resolve",
            operational_writes=[
                OperationalAppend(
                    collection="answer_observation",
                    record_key=f"{answer_id}:resolved",
                    payload_json={
                        "answer_id": answer_id,
                        "session_id": "__resolved__",
                        "turn_ordinal": 999999,
                        "created_at": resolved_at,
                        "response_excerpt": "",
                        "classification": "",
                        "selected_path": "",
                        "tool_call_count": 0,
                        "tool_names": [],
                        "retrieved_document_ids": [],
                        "route_profile": "",
                        "resolved": "true",
                        "resolved_at": resolved_at,
                    },
                    source_ref="memex:answer-feedback",
                )
            ],
        )
    )


# ── Heuristic classifier ──────────────────────────────────────────────────────

_CONFIRM_PATTERNS = re.compile(
    r"\b(yes|correct|exactly|that'?s? right|that works|perfect|confirmed|yep|yup|right|agreed)\b",
    re.IGNORECASE,
)

_CORRECTION_PATTERNS = re.compile(
    r"\b(no,|that'?s? wrong|actually|instead|not that|we decided|it'?s? actually|the answer is|you'?re? wrong|incorrect)\b",
    re.IGNORECASE,
)

_ACTED_ON_PATTERNS = re.compile(
    r"\b(use that|do that|draft it|schedule it|based on that|go ahead|proceed)\b",
    re.IGNORECASE,
)


def _token_overlap(text_a: str, text_b: str) -> float:
    if not text_a or not text_b:
        return 0.0
    tokens_a = set(re.findall(r"\w+", text_a.lower()))
    tokens_b = set(re.findall(r"\w+", text_b.lower()))
    if not tokens_a or not tokens_b:
        return 0.0
    intersection = tokens_a & tokens_b
    return len(intersection) / max(len(tokens_a), len(tokens_b))


def classify_follow_up(
    user_input: str,
    prior_obs: AnswerObservation,
    turn_ordinal: int,
    session_id: str,
) -> list[AnswerFeedbackSignal]:
    signals: list[AnswerFeedbackSignal] = []
    now = datetime.datetime.utcnow().isoformat()
    stripped = user_input.strip()
    is_short = len(stripped) <= 60

    # explicit_correction — check first so it can dominate
    if _CORRECTION_PATTERNS.search(stripped):
        match = _CORRECTION_PATTERNS.search(stripped)
        signals.append(
            AnswerFeedbackSignal(
                signal_id=str(uuid.uuid4()),
                answer_id=prior_obs.answer_id,
                session_id=session_id,
                observed_turn_ordinal=turn_ordinal,
                created_at=now,
                signal_type="explicit_correction",
                weight=1.0,
                confidence=0.95,
                evidence_text=match.group(0) if match else stripped[:100],
            )
        )

    # explicit_confirmation — short affirmation, no contradictory markers
    if (
        is_short
        and _CONFIRM_PATTERNS.search(stripped)
        and not _CORRECTION_PATTERNS.search(stripped)
    ):
        match = _CONFIRM_PATTERNS.search(stripped)
        signals.append(
            AnswerFeedbackSignal(
                signal_id=str(uuid.uuid4()),
                answer_id=prior_obs.answer_id,
                session_id=session_id,
                observed_turn_ordinal=turn_ordinal,
                created_at=now,
                signal_type="explicit_confirm",
                weight=0.9,
                confidence=0.85,
                evidence_text=match.group(0) if match else stripped[:100],
            )
        )

    # acted_on_answer — imperative deictic references
    if _ACTED_ON_PATTERNS.search(stripped):
        match = _ACTED_ON_PATTERNS.search(stripped)
        signals.append(
            AnswerFeedbackSignal(
                signal_id=str(uuid.uuid4()),
                answer_id=prior_obs.answer_id,
                session_id=session_id,
                observed_turn_ordinal=turn_ordinal,
                created_at=now,
                signal_type="acted_on_answer",
                weight=0.7,
                confidence=0.65,
                evidence_text=match.group(0) if match else stripped[:100],
            )
        )

    # topic_shift — low token overlap and non-short input
    if len(stripped) > 20 and not signals:
        overlap = _token_overlap(stripped, prior_obs.response_excerpt)
        if overlap < 0.1:
            signals.append(
                AnswerFeedbackSignal(
                    signal_id=str(uuid.uuid4()),
                    answer_id=prior_obs.answer_id,
                    session_id=session_id,
                    observed_turn_ordinal=turn_ordinal,
                    created_at=now,
                    signal_type="topic_shift",
                    weight=0.2,
                    confidence=0.3,
                    evidence_text=stripped[:100],
                )
            )

    return signals


# ── Outcome derivation ────────────────────────────────────────────────────────


def derive_outcome(
    signals: list[AnswerFeedbackSignal], answer_id: str
) -> AnswerOutcome:
    now = datetime.datetime.utcnow().isoformat()

    if not signals:
        return AnswerOutcome(
            answer_id=answer_id,
            label="unknown",
            confidence=0.0,
            last_updated_at=now,
            based_on_signal_ids=[],
        )

    corrections = [s for s in signals if s.signal_type == "explicit_correction"]
    confirms = [s for s in signals if s.signal_type == "explicit_confirm"]
    actions = [s for s in signals if s.signal_type == "acted_on_answer"]

    if corrections:
        return AnswerOutcome(
            answer_id=answer_id,
            label="corrected",
            confidence=0.95,
            last_updated_at=now,
            based_on_signal_ids=[s.signal_id for s in corrections],
        )
    elif confirms:
        return AnswerOutcome(
            answer_id=answer_id,
            label="confirmed",
            confidence=0.85,
            last_updated_at=now,
            based_on_signal_ids=[s.signal_id for s in confirms],
        )
    elif actions:
        return AnswerOutcome(
            answer_id=answer_id,
            label="confirmed",
            confidence=0.65,
            last_updated_at=now,
            based_on_signal_ids=[s.signal_id for s in actions],
        )
    else:
        return AnswerOutcome(
            answer_id=answer_id,
            label="unknown",
            confidence=0.0,
            last_updated_at=now,
            based_on_signal_ids=[s.signal_id for s in signals],
        )


# ── Phase node ────────────────────────────────────────────────────────────────


def _phase_evaluate_prior_answer_feedback(ctx: object) -> None:
    store = ctx.get("store")  # type: ignore[attr-defined]
    session = ctx.get("session")  # type: ignore[attr-defined]
    user_input = ctx.get("user_input", "")  # type: ignore[attr-defined]
    turn_ordinal = ctx.get("turn_ordinal", 0)  # type: ignore[attr-defined]

    if store is None or session is None or not user_input:
        return

    try:
        prior_obs = load_latest_unresolved_observation(store, session.session_id)
        if prior_obs is None:
            return

        signals = classify_follow_up(
            user_input, prior_obs, turn_ordinal, session.session_id
        )

        if not signals:
            return

        for signal in signals:
            try:
                save_feedback_signal(store, signal)
            except Exception:
                pass

        outcome = derive_outcome(signals, prior_obs.answer_id)

        try:
            save_answer_outcome(store, outcome)
        except Exception:
            pass

        if outcome.label in ("confirmed", "corrected"):
            try:
                mark_observation_resolved(
                    store,
                    prior_obs.answer_id,
                    datetime.datetime.utcnow().isoformat(),
                )
            except Exception:
                pass

        ctx["prior_answer_feedback_summary"] = {  # type: ignore[attr-defined]
            "answer_id": prior_obs.answer_id,
            "outcome_label": outcome.label,
            "signal_count": len(signals),
        }
    except Exception:
        pass
