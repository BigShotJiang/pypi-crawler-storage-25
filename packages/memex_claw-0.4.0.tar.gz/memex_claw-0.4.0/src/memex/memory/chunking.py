"""Content chunking for the knowledge layer."""

from __future__ import annotations

import re


def chunk_text(
    text: str,
    *,
    max_tokens: int = 500,
    overlap_tokens: int = 50,
    separator: str = "\n\n",
) -> list[dict]:
    """Split text into overlapping chunks.

    Returns list of {text, position, token_count}.
    Splits at paragraph boundaries when possible, falls back to
    sentence boundaries, then hard split.
    """
    if not text or not text.strip():
        return []

    # Rough token estimate: 1 token ≈ 4 chars
    max_chars = max_tokens * 4
    overlap_chars = overlap_tokens * 4

    total_tokens = len(text) // 4
    if total_tokens <= max_tokens:
        return [{"text": text, "position": 0, "token_count": total_tokens}]

    # Split into paragraphs first
    paragraphs = re.split(r"\n\n+", text)
    paragraphs = [p.strip() for p in paragraphs if p.strip()]

    if not paragraphs:
        return [{"text": text, "position": 0, "token_count": total_tokens}]

    chunks: list[dict] = []
    current_text = ""
    position = 0

    for para in paragraphs:
        candidate = (current_text + "\n\n" + para).strip() if current_text else para

        if len(candidate) > max_chars and current_text:
            # Flush current chunk
            tc = len(current_text) // 4
            chunks.append(
                {
                    "text": current_text,
                    "position": position,
                    "token_count": tc,
                }
            )
            position += 1

            # Overlap: take the last overlap_chars of the flushed chunk
            if overlap_chars > 0 and len(current_text) > overlap_chars:
                overlap_text = current_text[-overlap_chars:]
                current_text = (overlap_text + "\n\n" + para).strip()
            else:
                current_text = para
        elif len(candidate) > max_chars and not current_text:
            # Single paragraph exceeds max — split by sentences
            sub_chunks = _split_long_paragraph(para, max_chars, overlap_chars)
            for sc in sub_chunks:
                sc["position"] = position
                chunks.append(sc)
                position += 1
            current_text = ""
        else:
            current_text = candidate

    # Flush remaining
    if current_text.strip():
        tc = len(current_text) // 4
        chunks.append(
            {
                "text": current_text,
                "position": position,
                "token_count": tc,
            }
        )

    return chunks


def chunk_by_speaker_turns(text: str) -> list[dict]:
    """Split meeting transcript by speaker turns."""
    # Pattern: "Speaker Name:" or "[Speaker Name]" at start of line
    turns = re.split(r"\n(?=(?:\w[\w\s]*:\s|[\[【]\w))", text)
    turns = [t.strip() for t in turns if t.strip()]

    return [
        {"text": t, "position": i, "token_count": len(t) // 4}
        for i, t in enumerate(turns)
    ]


def _split_long_paragraph(text: str, max_chars: int, overlap_chars: int) -> list[dict]:
    """Split a long paragraph by sentence boundaries."""
    # Split on sentence endings
    sentences = re.split(r"(?<=[.!?])\s+", text)

    chunks = []
    current = ""
    for sent in sentences:
        candidate = (current + " " + sent).strip() if current else sent
        if len(candidate) > max_chars and current:
            chunks.append(
                {
                    "text": current,
                    "position": 0,
                    "token_count": len(current) // 4,
                }
            )
            if overlap_chars > 0 and len(current) > overlap_chars:
                current = current[-overlap_chars:] + " " + sent
            else:
                current = sent
        else:
            current = candidate

    if current.strip():
        chunks.append(
            {
                "text": current,
                "position": 0,
                "token_count": len(current) // 4,
            }
        )

    return chunks
