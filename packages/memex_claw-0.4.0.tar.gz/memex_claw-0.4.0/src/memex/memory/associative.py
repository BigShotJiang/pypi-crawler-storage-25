"""Associative index: trail management.

``auto_link_item`` was removed along with ``vector_store.py`` — it depended
on the vector-store protocol that was never concretely implemented in
production (``get_vector_store()`` returned ``None`` unconditionally).
Auto-link functionality is deferred until a real vector-store integration
lands (post fathomdb 0.4.0 write-time embedder parity). Human/agent-created
links continue to work via ``content_store.create_link``.
"""

from __future__ import annotations

import uuid

from memex.models import (
    Item,
    Link,
    LinkConfig,
    LinkCreator,
    Trail,
    TrailItem,
)
from memex.memory.store import ContentStore
from memex.utcnow import utcnow

_DEFAULT_CONFIG = LinkConfig()


def get_related(
    item_id: str,
    *,
    content_store: ContentStore,
    include_auto: bool = False,
    config: LinkConfig | None = None,
    limit: int = 10,
) -> list[Link]:
    """Get related items. Human/agent links always included.

    Auto links only if include_auto=True or strength >= display_threshold.
    """
    cfg = config or _DEFAULT_CONFIG

    all_links = content_store.get_links(item_id)

    result: list[Link] = []
    for link in all_links:
        if link.created_by in (LinkCreator.HUMAN, LinkCreator.AGENT):
            result.append(link)
        elif include_auto or link.strength >= cfg.display_threshold:
            result.append(link)

    result.sort(key=lambda lk: lk.strength, reverse=True)
    return result[:limit]


def create_trail(
    name: str,
    *,
    content_store: ContentStore,
    description: str = "",
    created_by: str = "human",
) -> Trail:
    """Create a new trail."""
    now = utcnow()
    trail = Trail(
        trail_id=str(uuid.uuid4()),
        name=name,
        description=description,
        created_by=created_by,
        created_at=now,
        updated_at=now,
    )
    content_store.create_trail(trail)
    return trail


def add_to_trail(
    trail_id: str,
    item_id: str,
    *,
    content_store: ContentStore,
    annotation: str = "",
    position: int | None = None,
) -> TrailItem:
    """Add an item to a trail."""
    if position is None:
        position = content_store.get_next_trail_position(trail_id)

    ti = TrailItem(
        trail_id=trail_id,
        item_id=item_id,
        position=position,
        annotation=annotation,
    )
    content_store.add_trail_item(ti)
    return ti


def get_trail_with_items(
    trail_id: str,
    *,
    content_store: ContentStore,
) -> tuple[Trail | None, list[tuple[TrailItem, Item | None]]]:
    """Get a trail with its items in order."""
    trail = content_store.get_trail(trail_id)
    if trail is None:
        return None, []

    trail_items = content_store.get_trail_items(trail_id)
    result: list[tuple[TrailItem, Item | None]] = []
    for ti in trail_items:
        item = content_store.get_item(ti.item_id)
        result.append((ti, item))

    return trail, result
