"""Ingest pipeline for knowledge items. Synchronous (d-005)."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from urllib.parse import urlparse

from typing import Any

from memex.models import Item, ItemType, Source, Summary
from memex.memory.decay import DEFAULT_HALF_LIFE
from memex.memory.store import ContentStore
from memex.memory.embeddings import EmbeddingBackend
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_SUMMARY_PROMPT = """\
Summarize the following content in 2-3 concise sentences. \
Focus on the key ideas and what makes this content notable or useful.

Content:
{content}
"""


def _extract_chunk_entities(
    content_store: ContentStore,
    chunks: list[dict],
    chunk_ids: list[str],
    item_type: str,
    full_content: str,
) -> None:
    """Run entity extraction on chunks and create Entity + MENTIONS edges."""
    try:
        from memex.memory.ner import (
            extract_entities,
            resolve_entity,
            should_deep_extract,
        )

        deep = should_deep_extract(item_type, len(full_content))
        for chunk, cid in zip(chunks, chunk_ids):
            entities = extract_entities(chunk["text"], deep=deep)
            for name, etype, context in entities:
                eid = resolve_entity(name, etype, content_store)
                content_store.create_mention(cid, eid, context)
    except ImportError:
        logger.debug("NER not available (spacy not installed)")
    except Exception:
        logger.debug("Entity extraction failed", exc_info=True)


def _extract_domain(url: str) -> str:
    try:
        parsed = urlparse(url)
        return parsed.netloc or ""
    except Exception:
        return ""


def _find_or_create_source(content_store: ContentStore, url: str) -> str | None:
    if not url:
        return None

    domain = _extract_domain(url)
    if not domain:
        return None

    existing = content_store.find_source_by_domain(domain)
    if existing:
        if isinstance(existing, dict):
            return existing.get("source_id", existing.get("id", ""))
        return existing.source_id

    source = Source(
        source_id=str(uuid.uuid4()),
        name=domain,
        domain=domain,
        reputation_score=0.5,
        confidence=0.0,
        created_at=utcnow(),
    )
    content_store.create_source(source)
    return source.source_id


def _generate_summary(
    content: str,
    *,
    session_id: str = "",
    usage_source: str = "ingest_summary",
) -> Summary:
    """Generate summary via chat() with cheap model. Returns empty Summary on failure."""
    try:
        from memex.llm import _get_cheap_model, chat_with_usage
        from memex.telemetry import record_usage

        prompt = _SUMMARY_PROMPT.format(content=content[:4000])
        messages = [{"role": "user", "content": prompt}]
        result, usage = chat_with_usage(
            messages, model=_get_cheap_model(), max_tokens=256
        )
        input_tokens = usage.prompt_tokens or (len(content) // 4)
        record_usage(
            cost_usd=usage.cost_usd,
            total_tokens=usage.total_tokens,
            session_id=session_id,
            source=usage_source,
        )

        return Summary(
            text=result.strip(),
            model=_get_cheap_model(),
            generated_at=utcnow(),
            input_tokens=input_tokens,
        )
    except Exception:
        logger.debug("Summary generation failed", exc_info=True)
        return Summary()


def _deterministic_summary_from_extracted(
    title: str,
    description: str,
    body: str,
) -> Summary:
    text = (description or "").strip()
    if not text:
        compact_body = " ".join((body or "").split())
        if title and compact_body.lower().startswith(title.strip().lower()):
            compact_body = compact_body[len(title.strip()) :].lstrip(" .:-\n")
        text = compact_body[:320].strip()
        if len(compact_body) > 320 and text:
            text = text.rstrip() + "..."
    return Summary(
        text=text,
        model="deterministic_extract" if text else "",
        generated_at=utcnow() if text else None,
        input_tokens=0,
    )


def _build_payload(item: Item, model: str = "") -> dict[str, Any]:
    """Build vector store payload from an Item."""
    return {
        "model": model,
        "item_id": item.item_id,
        "type": item.type.value,
        "tags": item.tags or [],
        "source_id": item.source_id,
        "captured_at": item.captured_at.isoformat(),
        "pinned": item.pinned or False,
        "expires_at": item.expires_at.isoformat() if item.expires_at else None,
    }


def _merge_item_metadata(
    existing: dict[str, Any] | None,
    new: dict[str, Any] | None,
) -> dict[str, Any]:
    merged = dict(existing or {})
    for key, value in (new or {}).items():
        merged[key] = value
    return merged


def ingest_from_url(
    url: str,
    *,
    tags: list[str] | None = None,
    item_type: ItemType = ItemType.ARTICLE,
    content_store: ContentStore,
    memex_store: Any | None = None,
    embedding_backend: EmbeddingBackend | None = None,
    generate_summary: bool = False,
    session_id: str = "",
) -> Item:
    """Fetch, extract, and ingest a URL in one call.

    Uses trafilatura for high-quality content + metadata extraction,
    then delegates to ingest() for storage, chunking, and embedding.

    Raises ValueError if extraction yields no meaningful content.
    """
    from memex.memory.web_extract import extract_from_url
    from memex.memory.youtube_extract import is_youtube_url, extract_from_youtube

    if is_youtube_url(url):
        extracted = extract_from_youtube(url)
    else:
        extracted = extract_from_url(url)
    if not extracted.is_substantial:
        raise ValueError(
            f"Could not extract meaningful content from {url} "
            f"({extracted.word_count} words, {extracted.raw_length} bytes HTML)"
        )

    return ingest_extracted_content(
        extracted,
        tags=tags,
        type=item_type,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=embedding_backend,
        generate_summary=generate_summary,
        session_id=session_id,
    )


def ingest_extracted_content(
    extracted: Any,
    *,
    tags: list[str] | None = None,
    type: ItemType = ItemType.ARTICLE,
    content_store: ContentStore,
    memex_store: Any | None = None,
    embedding_backend: EmbeddingBackend | None = None,
    generate_summary: bool = False,
    session_id: str = "",
) -> Item:
    combined_tags = list(
        set((tags or []) + list(getattr(extracted, "categories", []) or []))
    )
    summary_override = _deterministic_summary_from_extracted(
        getattr(extracted, "title", "") or "",
        getattr(extracted, "description", "") or "",
        getattr(extracted, "body", "") or "",
    )
    return ingest(
        getattr(extracted, "body", "") or "",
        type=type,
        title=getattr(extracted, "title", "") or None,
        source_url=getattr(extracted, "url", "") or None,
        author=getattr(extracted, "author", "") or None,
        tags=combined_tags,
        content_store=content_store,
        memex_store=memex_store,
        embedding_backend=embedding_backend,
        generate_summary=generate_summary,
        session_id=session_id,
        summary_override=summary_override if summary_override.text else None,
    )


def ingest(
    content: str,
    *,
    type: ItemType = ItemType.NOTE,
    title: str | None = None,
    source_url: str | None = None,
    author: str | None = None,
    tags: list[str] | None = None,
    content_store: ContentStore,
    memex_store: Any | None = None,
    embedding_backend: EmbeddingBackend | None = None,
    pinned: bool | None = None,
    is_milestone: bool | None = None,
    expires_at: datetime | None = None,
    metadata: dict[str, Any] | None = None,
    generate_summary: bool = True,
    session_id: str = "",
    summary_override: Summary | None = None,
) -> Item:
    """Ingest content into the knowledge store.

    Pipeline:
    1. Re-ingest detection: find_by_url -> create_version_snapshot -> update
    2. Extract/default metadata
    3. Find or create Source by domain
    4. Set half_life_days from DEFAULT_HALF_LIFE
    5. Create Item + persist
    6. Generate summary (C-2: store model/timestamp/tokens)
    7. Generate embedding (if backend available)
    8. Auto-link (if vector_store available)
    9. Return Item
    """
    now = utcnow()

    # 1. Re-ingest detection
    existing = content_store.find_by_url(source_url) if source_url else None

    # 2. Extract metadata
    if not title:
        first_line = content.split("\n", 1)[0].strip()
        title = first_line[:200] if first_line else "Untitled"

    # 3. Source
    source_id = _find_or_create_source(content_store, source_url or "")

    # 4. Half-life
    half_life = DEFAULT_HALF_LIFE.get(type, 30.0)

    if existing:
        # Re-ingest: snapshot old version, update
        content_store.create_version_snapshot(existing)

        existing.body = content
        existing.title = title
        existing.author = author or existing.author
        existing.tags = tags if tags is not None else existing.tags
        existing.version += 1
        existing.last_accessed = now
        if pinned is not None:
            existing.pinned = pinned
        if is_milestone is not None:
            existing.is_milestone = is_milestone
        if expires_at is not None:
            existing.expires_at = expires_at
        if metadata is not None:
            existing.metadata = _merge_item_metadata(existing.metadata, metadata)

        # 6. Summary (only replace if new summary has content)
        if summary_override is not None:
            existing.summary = summary_override
        if generate_summary:
            new_summary = _generate_summary(content, session_id=session_id)
            if new_summary.text:
                existing.summary = new_summary

        if metadata and metadata.get("typed_knowledge"):
            try:
                from memex.typed_knowledge import seed_typed_knowledge_metadata

                seed_typed_knowledge_metadata(existing, metadata.get("typed_knowledge"))
            except Exception:
                logger.debug(
                    "Typed-knowledge metadata seeding after update failed",
                    exc_info=True,
                )

        content_store.update_item(existing)
        try:
            from memex.typed_knowledge import sync_item_projection_if_needed

            sync_item_projection_if_needed(memex_store, content_store, existing)
        except Exception:
            logger.debug("Typed-knowledge sync after update failed", exc_info=True)

        # Re-chunk: delete old chunks and re-create
        if hasattr(content_store, "delete_chunks") and hasattr(
            content_store, "create_chunks"
        ):
            try:
                from memex.memory.chunking import chunk_text

                content_store.delete_chunks(existing.item_id)
                chunks = chunk_text(content)
                if chunks:
                    chunk_embeddings = None
                    if embedding_backend:
                        chunk_texts = [c["text"] for c in chunks]
                        chunk_embeddings = embedding_backend.embed_batch(chunk_texts)
                    chunk_ids = content_store.create_chunks(
                        existing.item_id, chunks, chunk_embeddings
                    )
                    if hasattr(content_store, "create_mention"):
                        _extract_chunk_entities(
                            content_store,
                            chunks,
                            chunk_ids,
                            existing.type.value,
                            content,
                        )
            except Exception:
                logger.debug("Re-chunking failed", exc_info=True)

        try:
            from memex.event_bus import get_bus
            from memex.events import ItemIngested

            get_bus().publish(
                ItemIngested(
                    item_id=existing.item_id,
                    title=existing.title,
                    item_type=existing.type.value,
                    is_update=True,
                )
            )
        except Exception:
            pass

        # Embedding / auto-link steps removed alongside vector_store.py
        # deletion. Auto-link was dead in production (vector_store always
        # None) and the item-level vector upsert had no consumer.
        return existing

    # 5. Create new item
    item = Item(
        item_id=str(uuid.uuid4()),
        type=type,
        title=title,
        body=content,
        source_url=source_url,
        author=author or "",
        captured_at=now,
        tags=tags or [],
        source_id=source_id,
        half_life_days=half_life,
        last_accessed=now,
        pinned=pinned if pinned is not None else False,
        is_milestone=is_milestone if is_milestone is not None else False,
        expires_at=expires_at,
        metadata=_merge_item_metadata({}, metadata),
    )

    # 6. Summary
    if summary_override is not None:
        item.summary = summary_override
    if generate_summary:
        item.summary = _generate_summary(content, session_id=session_id)

    if metadata and metadata.get("typed_knowledge"):
        try:
            from memex.typed_knowledge import seed_typed_knowledge_metadata

            seed_typed_knowledge_metadata(item, metadata.get("typed_knowledge"))
        except Exception:
            logger.debug(
                "Typed-knowledge metadata seeding after create failed", exc_info=True
            )

    content_store.create_item(item)
    try:
        from memex.typed_knowledge import sync_item_projection_if_needed

        sync_item_projection_if_needed(memex_store, content_store, item)
    except Exception:
        logger.debug("Typed-knowledge sync after create failed", exc_info=True)

    # 6.5 Emit domain event
    try:
        from memex.event_bus import get_bus
        from memex.events import ItemIngested

        get_bus().publish(
            ItemIngested(
                item_id=item.item_id,
                title=item.title,
                item_type=item.type.value,
                is_update=False,
            )
        )
    except Exception:
        pass

    # 6.6 Chunking + Entity extraction (if content store supports it)
    if hasattr(content_store, "create_chunks"):
        try:
            from memex.memory.chunking import chunk_text

            chunks = chunk_text(content)
            if chunks:
                chunk_embeddings = None
                if embedding_backend:
                    chunk_texts = [c["text"] for c in chunks]
                    chunk_embeddings = embedding_backend.embed_batch(chunk_texts)
                chunk_ids = content_store.create_chunks(
                    item.item_id, chunks, chunk_embeddings
                )
                # Entity extraction on chunks
                if hasattr(content_store, "create_mention"):
                    _extract_chunk_entities(
                        content_store, chunks, chunk_ids, item.type.value, content
                    )
        except Exception:
            logger.debug("Chunking failed", exc_info=True)

    # Embedding / auto-link steps removed alongside vector_store.py deletion.
    # See the matching update-path comment above.
    return item
