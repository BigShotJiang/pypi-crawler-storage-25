"""Ranking formula for knowledge retrieval. Pure functions."""

from __future__ import annotations

from memex.models import PromptControlRouteProfile, RankConfig

_DEFAULT_CONFIG = RankConfig()
_BASE_WORLD_MODEL_BOOSTS: dict[str, float] = {
    "claim": 0.10,
    "reference": 0.08,
    "context_snapshot": 0.07,
    "session_summary": 0.05,
    "meeting_record": 0.04,
    "note": 0.02,
    "procedure": 0.08,
}
_BASE_WORLD_MODEL_SEMANTIC_BOOSTS: dict[str, float] = {
    "decision": 0.04,
    "procedure": 0.08,
    "knowledge_gap": 0.06,
    "heuristic": 0.05,
}
_ROUTE_WORLD_MODEL_BOOSTS: dict[PromptControlRouteProfile, dict[str, float]] = {
    PromptControlRouteProfile.ANALYTIC_STRICT: {
        "claim": 0.06,
        "reference": 0.05,
        "session_summary": 0.03,
    },
    PromptControlRouteProfile.CREATIVE_OPEN: {
        "note": 0.03,
        "reference": 0.02,
    },
    PromptControlRouteProfile.OPERATIONAL_TOOL: {
        "claim": 0.14,
        "context_snapshot": 0.12,
        "session_summary": 0.06,
        "reference": 0.02,
        "procedure": 0.12,
    },
    PromptControlRouteProfile.RESEARCH_VERIFIED: {
        "reference": 0.14,
        "claim": 0.08,
        "meeting_record": 0.05,
    },
    PromptControlRouteProfile.SOCIAL_DRAFT: {
        "context_snapshot": 0.08,
        "claim": 0.04,
    },
    PromptControlRouteProfile.GUARDED_REVIEW: {
        "reference": 0.10,
        "claim": 0.06,
        "session_summary": 0.04,
    },
}
_ROUTE_WORLD_MODEL_SEMANTIC_BOOSTS: dict[
    PromptControlRouteProfile,
    dict[str, float],
] = {
    PromptControlRouteProfile.ANALYTIC_STRICT: {
        "decision": 0.04,
        "heuristic": 0.03,
        "knowledge_gap": 0.03,
    },
    PromptControlRouteProfile.OPERATIONAL_TOOL: {
        "procedure": 0.12,
        "decision": 0.04,
        "knowledge_gap": 0.02,
    },
    PromptControlRouteProfile.RESEARCH_VERIFIED: {
        "knowledge_gap": 0.05,
        "heuristic": 0.02,
    },
    PromptControlRouteProfile.GUARDED_REVIEW: {
        "knowledge_gap": 0.04,
    },
}


def rank_score(
    *,
    relevance: float,
    decay_weight: float,
    reputation: float,
    pinned: bool = False,
    config: RankConfig | None = None,
) -> float:
    """Compute composite rank score.

    Formula: (relevance ** r_exp) * (decay ** d_exp) * (reputation ** rep_exp) * pin_boost
    """
    cfg = config or _DEFAULT_CONFIG
    # Floor at 0.01 to prevent a single zero signal from zeroing the entire score
    score = (
        (max(relevance, 0.01) ** cfg.relevance_exp)
        * (max(decay_weight, 0.01) ** cfg.decay_exp)
        * (max(reputation, 0.01) ** cfg.reputation_exp)
    )
    if pinned:
        score *= cfg.pin_boost
    return score


def route_profile_world_model_boost(
    *,
    knowledge_type: str,
    semantic_kind: str = "",
    route_profile: PromptControlRouteProfile | str | None,
    has_source_url: bool = False,
) -> float:
    """Return a deterministic boost for typed knowledge under a route profile."""
    if not knowledge_type:
        return 0.0

    profile: PromptControlRouteProfile | None = None
    if isinstance(route_profile, PromptControlRouteProfile):
        profile = route_profile
    elif isinstance(route_profile, str) and route_profile:
        try:
            profile = PromptControlRouteProfile(route_profile)
        except ValueError:
            profile = None

    boost = _BASE_WORLD_MODEL_BOOSTS.get(knowledge_type, 0.0)
    if semantic_kind:
        boost += _BASE_WORLD_MODEL_SEMANTIC_BOOSTS.get(semantic_kind, 0.0)
    if profile is not None:
        boost += _ROUTE_WORLD_MODEL_BOOSTS.get(profile, {}).get(knowledge_type, 0.0)
        if semantic_kind:
            boost += _ROUTE_WORLD_MODEL_SEMANTIC_BOOSTS.get(profile, {}).get(
                semantic_kind,
                0.0,
            )
        if (
            has_source_url
            and knowledge_type == "reference"
            and profile
            in {
                PromptControlRouteProfile.RESEARCH_VERIFIED,
                PromptControlRouteProfile.GUARDED_REVIEW,
            }
        ):
            boost += 0.03

    return boost


def normalize_bm25(raw_bm25: float, *, max_bm25: float) -> float:
    """Normalize BM25 to [0, 1] using batch max."""
    if max_bm25 <= 0:
        return 0.0
    return min(1.0, max(0.0, raw_bm25 / max_bm25))


def normalize_cosine(cosine_sim: float) -> float:
    """Clamp cosine similarity to [0, 1]."""
    return min(1.0, max(0.0, cosine_sim))


def merge_dual_search(
    fts_results: list[tuple[str, float]],
    sem_results: list[tuple[str, float]],
    *,
    fts_weight: float = 0.5,
    sem_weight: float = 0.5,
) -> list[tuple[str, float]]:
    """Merge FTS and semantic results with normalized scores.

    BM25 normalized within-batch. Cosine clamped to [0,1].
    Items in both get weighted average. Items in only one get score * weight.
    """
    # Normalize BM25
    max_bm25 = max((s for _, s in fts_results), default=0.0)
    fts_scores: dict[str, float] = {
        item_id: normalize_bm25(score, max_bm25=max_bm25)
        for item_id, score in fts_results
    }

    # Normalize cosine
    sem_scores: dict[str, float] = {
        item_id: normalize_cosine(score) for item_id, score in sem_results
    }

    # Merge
    all_ids = set(fts_scores) | set(sem_scores)
    merged: list[tuple[str, float]] = []

    for item_id in all_ids:
        fts_s = fts_scores.get(item_id)
        sem_s = sem_scores.get(item_id)

        if fts_s is not None and sem_s is not None:
            score = fts_s * fts_weight + sem_s * sem_weight
        elif fts_s is not None:
            score = fts_s * fts_weight
        else:
            # sem_s is guaranteed not-None: item_id came from sem_scores
            score = (sem_s or 0.0) * sem_weight

        merged.append((item_id, score))

    merged.sort(key=lambda x: x[1], reverse=True)
    return merged
