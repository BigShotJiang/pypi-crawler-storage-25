"""YouTube video transcript and metadata extraction via yt-dlp."""

from __future__ import annotations

import json
import logging
import re
import urllib.parse
import urllib.request

import yt_dlp

from memex.memory.web_extract import ExtractedContent

logger = logging.getLogger(__name__)


# Matches youtube.com/watch, youtu.be, youtube.com/shorts, youtube.com/embed
_YT_PATTERNS = [
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/watch\?.*v=([a-zA-Z0-9_-]{11})"),
    re.compile(r"(?:https?://)?youtu\.be/([a-zA-Z0-9_-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/shorts/([a-zA-Z0-9_-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/embed/([a-zA-Z0-9_-]{11})"),
]


def strip_tracking_params(url: str) -> str:
    """Strip YouTube tracking parameters (si, pp, feature, etc.) from a URL.

    - watch URLs: keeps only the `v` param
    - youtu.be / /shorts/ / /embed/: strips the entire query string (video ID is in path)
    """
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower().lstrip("www.")

    if host == "youtube.com" and parsed.path == "/watch":
        params = urllib.parse.parse_qs(parsed.query)
        clean = urllib.parse.urlencode({"v": params["v"][0]}) if "v" in params else ""
        return urllib.parse.urlunparse(parsed._replace(query=clean))

    if host == "youtu.be" or "/shorts/" in parsed.path or "/embed/" in parsed.path:
        return urllib.parse.urlunparse(parsed._replace(query=""))

    return url


def extract_video_id(url: str) -> str | None:
    """Extract the 11-char video ID from a YouTube URL."""
    for pat in _YT_PATTERNS:
        m = pat.search(url)
        if m:
            return m.group(1)
    return None


def is_youtube_url(url: str) -> bool:
    """Return True if url is a recognized YouTube video URL."""
    return extract_video_id(url) is not None


def _fetch_info(video_id: str) -> dict:
    """Fetch video metadata + subtitle info via yt-dlp. Returns empty dict on failure."""
    from memex.connectors.cookies import get_cookie_provider

    opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "no_color": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["en"],
        "subtitlesformat": "json3",
        **get_cookie_provider().get_yt_dlp_opts(),
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(
                f"https://www.youtube.com/watch?v={video_id}",
                download=False,
            )
            return info or {}
    except Exception as e:
        logger.warning("yt-dlp extraction failed: %s", e)
        return {}


def _extract_transcript_from_info(info: dict) -> str:
    """Extract transcript text from yt-dlp info dict via subtitle URL.

    Uses requested_subtitles to find json3-format captions, downloads and
    parses them. Returns empty string on failure.
    """
    req_subs = info.get("requested_subtitles") or {}
    en_sub = req_subs.get("en")
    if not en_sub or not en_sub.get("url"):
        return ""

    try:
        data = urllib.request.urlopen(en_sub["url"], timeout=15).read()  # nosec B310 — YouTube subtitle URL from yt-dlp
        j = json.loads(data)
        texts: list[str] = []
        for event in j.get("events", []):
            for seg in event.get("segs", []):
                t = seg.get("utf8", "").strip()
                if t and t != "\n":
                    texts.append(t)
        return " ".join(texts)
    except Exception as e:
        logger.warning("Subtitle download failed: %s", e)
        return ""


def _format_body(transcript: str, metadata: dict) -> str:
    """Format transcript with a metadata header."""
    parts: list[str] = []

    if metadata.get("uploader"):
        parts.append(f"Channel: {metadata['uploader']}")
    if metadata.get("upload_date"):
        date = metadata["upload_date"]
        if len(date) == 8:
            date = f"{date[:4]}-{date[4:6]}-{date[6:]}"
        parts.append(f"Date: {date}")
    if metadata.get("duration"):
        mins, secs = divmod(int(metadata["duration"]), 60)
        parts.append(f"Duration: {mins}m{secs:02d}s")

    if parts:
        parts.append("")  # blank line separator

    parts.append(transcript)
    return "\n".join(parts)


def _build_tags(metadata: dict) -> list[str]:
    """Build tag list from metadata."""
    tags = ["youtube", "video"]
    yt_tags = metadata.get("tags") or []
    tags.extend(t.lower() for t in yt_tags[:10])
    return tags


def extract_from_youtube(url: str) -> ExtractedContent:
    """Extract transcript + metadata from a YouTube video."""
    url = strip_tracking_params(url)
    video_id = extract_video_id(url)
    if not video_id:
        return ExtractedContent(url=url)

    canonical_url = f"https://www.youtube.com/watch?v={video_id}"

    info = _fetch_info(video_id)
    transcript_text = _extract_transcript_from_info(info)

    if not transcript_text:
        # Fall back to description if no transcript available
        desc = info.get("description", "")
        if desc:
            body = _format_body(f"[No transcript available]\n\n{desc}", info)
            return ExtractedContent(
                url=canonical_url,
                title=info.get("title", ""),
                author=info.get("uploader", ""),
                date=info.get("upload_date", ""),
                body=body,
                description=desc[:500],
                sitename="YouTube",
                categories=_build_tags(info),
                word_count=len(body.split()),
                raw_length=len(body),
            )
        return ExtractedContent(url=canonical_url, title=info.get("title", ""))

    body = _format_body(transcript_text, info)

    return ExtractedContent(
        url=canonical_url,
        title=info.get("title", ""),
        author=info.get("uploader", ""),
        date=info.get("upload_date", ""),
        body=body,
        description=info.get("description", "")[:500],
        sitename="YouTube",
        categories=_build_tags(info),
        word_count=len(body.split()),
        raw_length=len(body),
    )
