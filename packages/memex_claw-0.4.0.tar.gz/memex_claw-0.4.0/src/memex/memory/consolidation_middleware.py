"""Fact consolidation middleware — session-end quick dedup.

Separate middleware class with explicit constructor dependencies
(soft constraint: not bolted onto SessionSummaryMiddleware).

Exception isolation per middleware contract: catch all, log debug.
"""

from __future__ import annotations

import logging
from typing import Any

from memex.middleware import TurnMiddleware
from memex.models import SessionContext
from memex.store import MemexStore

logger = logging.getLogger(__name__)


class FactConsolidationMiddleware(TurnMiddleware):
    """Runs quick_dedup on session end to catch obvious fact duplicates.

    Explicit dependencies (soft constraint):
    - content_store: for fact CRUD
    - embedding_backend: for similarity comparison
    """

    def __init__(
        self,
        content_store: Any,
        embedding_backend: Any,
    ) -> None:
        self._content_store = content_store
        self._embedding_backend = embedding_backend

    def after_session(
        self,
        session: SessionContext,
        store: MemexStore,
    ) -> None:
        """Run quick_dedup on session end. Never raises (middleware contract)."""
        try:
            from memex.memory.consolidation import quick_dedup

            merged = quick_dedup(self._content_store, self._embedding_backend)
            if merged:
                logger.info("Session-end quick dedup merged %d fact(s)", merged)
        except Exception:
            logger.debug(
                "FactConsolidationMiddleware.after_session failed", exc_info=True
            )
