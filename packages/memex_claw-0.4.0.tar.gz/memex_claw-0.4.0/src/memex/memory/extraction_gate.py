"""Deterministic extraction gate — decides whether to run LLM extraction+reflection.

spaCy NER + regex signal detection runs in <5ms with zero tokens.
~40-60% of turns are trivial (greetings, simple Q&A) that would produce
empty ReflectResults. The gate vetoes both extraction and reflection on
those turns to save cost.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from memex.models import InputClassification, InputClassificationType

# ---------------------------------------------------------------------------
# Compiled regex patterns (module-level singletons)
# ---------------------------------------------------------------------------

_FACTUAL_PATTERNS = re.compile(
    r"(?:"
    r"deadline\s+is|will\s+be|decided\s+to"
    r"|\d{4}-\d{2}-\d{2}"
    r"|(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}"
    r"|next\s+\w+day"
    r")",
    re.IGNORECASE,
)

_RELATIONSHIP_PATTERNS = re.compile(
    r"(?:"
    r"works\s+on|owns\s+(?:the\s+)?|manages\s+(?:the\s+)?"
    r"|depends\s+on|is\s+part\s+of|replaced\s+by"
    r")",
    re.IGNORECASE,
)

_URL_PATTERN = re.compile(r"https?://[^\s<>\"')]+")

_DECISION_PATTERNS = re.compile(
    r"(?:"
    r"we\s+decided|going\s+with|instead\s+of"
    r"|switching\s+to|chose\s+\S+\s+over"
    r"|using\s+\S+\s+instead"
    r")",
    re.IGNORECASE,
)

_NEGATION_PATTERNS = re.compile(
    r"(?:"
    r"actually[,.]|correction:|I\s+was\s+wrong"
    r"|turns\s+out|changed\s+to|no\s+longer"
    r")",
    re.IGNORECASE,
)

# Trivial-turn veto applies to these classification types
_TRIVIAL_VETO_TYPES = {
    InputClassificationType.CONVERSATIONAL,
    InputClassificationType.CLARIFICATION,
}

_TRIVIAL_WORD_THRESHOLD = 30


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------


@dataclass
class ExtractionSignals:
    """Result of the extraction gate check."""

    should_extract: bool = False
    signals: set[str] = field(default_factory=set)
    entities: list[tuple[str, str]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Signal detection helpers
# ---------------------------------------------------------------------------


def _detect_regex_signals(text: str) -> set[str]:
    """Detect signals from regex patterns. Returns set of signal names."""
    signals: set[str] = set()
    if _FACTUAL_PATTERNS.search(text):
        signals.add("factual_assertion")
    if _RELATIONSHIP_PATTERNS.search(text):
        signals.add("relationship_language")
    if _URL_PATTERN.search(text):
        signals.add("url_mentioned")
    if _DECISION_PATTERNS.search(text):
        signals.add("decision_language")
    if _NEGATION_PATTERNS.search(text):
        signals.add("negation_of_prior")
    return signals


def _extract_entities_safe(text: str) -> list[tuple[str, str]]:
    """Extract entities via spaCy, returning [] on any failure."""
    try:
        from memex.memory.ner import extract_entities_fast

        return extract_entities_fast(text)
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Main gate function
# ---------------------------------------------------------------------------


def check_extraction_gate(
    user_input: str,
    assistant_response: str,
    classification: InputClassification,
) -> ExtractionSignals:
    """Determine whether extraction + reflection should run for this turn.

    Cheap (<5ms, zero tokens): regex pattern matching + spaCy NER.

    Returns ExtractionSignals with should_extract=True when the turn
    contains entities, factual assertions, decisions, relationships,
    URLs, or corrections worth capturing.
    """
    combined_text = f"{user_input} {assistant_response}"

    # Detect regex signals on combined text
    signals = _detect_regex_signals(combined_text)

    # Extract entities via spaCy
    entities = _extract_entities_safe(combined_text)

    # Trivial-turn veto: CONVERSATIONAL/CLARIFICATION + short text
    word_count = len(combined_text.split())
    if (
        classification.classification in _TRIVIAL_VETO_TYPES
        and word_count < _TRIVIAL_WORD_THRESHOLD
        and not entities
        and not signals
    ):
        return ExtractionSignals(
            should_extract=False,
            signals={"trivial_turn"},
            entities=[],
        )

    # Determine should_extract: need at least one signal or entity
    has_signals = bool(signals) or bool(entities)

    return ExtractionSignals(
        should_extract=has_signals,
        signals=signals,
        entities=entities,
    )
