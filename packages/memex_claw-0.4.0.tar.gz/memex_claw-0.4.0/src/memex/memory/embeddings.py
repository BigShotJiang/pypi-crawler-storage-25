"""Embedding backend. Soft dependency on sentence-transformers."""

from __future__ import annotations

import logging
import platform
from typing import Protocol

logger = logging.getLogger(__name__)

_libgomp_preloaded = False


def preload_libgomp() -> None:
    """Preload libgomp on aarch64 to avoid TLS exhaustion.

    Both the system libgomp (needed by torchaudio) and scikit-learn's bundled
    copy must be preloaded before any imports that trigger them, otherwise
    dlopen fails with "cannot allocate memory in static TLS block".
    """
    global _libgomp_preloaded
    if _libgomp_preloaded or platform.machine() not in ("aarch64", "arm64"):
        return
    _libgomp_preloaded = True

    import ctypes
    from pathlib import Path

    # System libgomp — needed by torchaudio/pytorch
    try:
        ctypes.CDLL("/lib/aarch64-linux-gnu/libgomp.so.1")
        logger.debug("Preloaded system libgomp")
    except Exception:
        pass

    # scikit-learn's bundled libgomp
    try:
        import importlib.util

        spec = importlib.util.find_spec("sklearn")
        if spec and spec.origin:
            libs_dir = Path(spec.origin).parent.parent / "scikit_learn.libs"
            for lib in libs_dir.glob("libgomp*.so*"):
                ctypes.CDLL(str(lib))
                logger.debug("Preloaded libgomp from %s", lib)
                return
    except Exception:
        pass


class EmbeddingBackend(Protocol):
    def embed(self, text: str) -> list[float]: ...
    def embed_batch(self, texts: list[str]) -> list[list[float]]: ...

    @property
    def dimensions(self) -> int: ...

    @property
    def model_name(self) -> str: ...


class SentenceTransformerBackend:
    """Local embeddings via all-MiniLM-L6-v2. Lazy model loading."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self._model_name = model_name
        self._model = None

    def _load(self):
        if self._model is None:
            preload_libgomp()
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(self._model_name)
        return self._model

    def embed(self, text: str) -> list[float]:
        model = self._load()
        return model.encode(text).tolist()

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        model = self._load()
        return [e.tolist() for e in model.encode(texts)]

    @property
    def dimensions(self) -> int:
        model = self._load()
        return int(model.get_sentence_embedding_dimension())

    @property
    def model_name(self) -> str:
        return self._model_name


def get_embedding_backend() -> EmbeddingBackend | None:
    """Factory. Returns None if sentence-transformers not installed."""
    try:
        preload_libgomp()
        import sentence_transformers  # noqa: F401

        return SentenceTransformerBackend()
    except ImportError:
        logger.info("sentence-transformers not installed — semantic search disabled")
        return None
