"""Normalized retrieval-document resolution for canonical vs legacy reads."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from memex.models import PromptControlRouteProfile
from memex.memory.world_model_reads import (
    CanonicalActionPlanHit,
    CanonicalExecutionRecordHit,
    CanonicalClaimEvaluationHit,
    CanonicalCommitmentHit,
    CanonicalDependencyHit,
    CanonicalEventHit,
    CanonicalGoalHit,
    CanonicalOutcomeHit,
    CanonicalPlanStepHit,
    CanonicalPlanStepTransitionHit,
    CanonicalSemanticMappingHit,
    CanonicalTaskHit,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RetrievalDocument:
    document_id: str
    item_id: str | None
    title: str
    body_text: str
    source_url: str
    reputation_display: str
    relevance_pct: int
    world_model_context_lines: tuple[str, ...]

    @property
    def source_line(self) -> str:
        if self.source_url:
            return f"Source: {self.source_url} | Reputation: {self.reputation_display}"
        if self.reputation_display != "unrated":
            return f"Reputation: {self.reputation_display}"
        return ""


def resolve_retrieval_document(
    *,
    item_id: str,
    item,
    knowledge,
    knowledge_relationships: list[dict[str, str]] | None = None,
    relevance: float,
    route_profile: PromptControlRouteProfile | str | None,
    reputation_display: str,
) -> RetrievalDocument:
    """Resolve one retrieval document from a live item row and canonical knowledge.

    All canonical-vs-live precedence lives here so retrieval formatting does
    not drift across title/body/source policy fragments.
    """

    title = _candidate_title(item, knowledge, fallback_item_id=item_id)
    body_text = _body_text(item, knowledge)
    source_url = _source_url(item, knowledge)
    canonical_document = knowledge is not None
    is_auto_sync_shell = canonical_document and getattr(
        knowledge, "knowledge_id", ""
    ).startswith("ki-")
    document_id = (
        f"content_item:{item_id}"
        if not canonical_document or is_auto_sync_shell
        else f"world_model_knowledge:{knowledge.knowledge_id}"
    )
    context_lines = _format_world_model_context(
        knowledge,
        route_profile=route_profile,
        knowledge_relationships=knowledge_relationships or [],
    )
    # For research_verified/guarded_review profiles, show canonical URL
    # even without a knowledge object backing
    if not context_lines and knowledge is None and source_url:
        route_value = (
            route_profile.value
            if isinstance(route_profile, PromptControlRouteProfile)
            else (route_profile or "")
        )
        if route_value in {
            PromptControlRouteProfile.RESEARCH_VERIFIED.value,
            PromptControlRouteProfile.GUARDED_REVIEW.value,
        }:
            context_lines = [f"Canonical: {source_url}"]
    return RetrievalDocument(
        document_id=document_id,
        item_id=item_id if (not canonical_document or is_auto_sync_shell) else None,
        title=title,
        body_text=body_text,
        source_url=source_url,
        reputation_display=reputation_display,
        relevance_pct=int(min(relevance, 1.0) * 100),
        world_model_context_lines=tuple(context_lines),
    )


def resolve_canonical_outcome_document(
    hit: CanonicalOutcomeHit,
    *,
    route_profile: PromptControlRouteProfile | str | None,
) -> RetrievalDocument:
    del route_profile
    selected = (
        hit.payload.get("selected_action") if isinstance(hit.payload, dict) else {}
    )
    if not isinstance(selected, dict):
        selected = {}
    selected_name = str(selected.get("name") or hit.action_name or "outcome").strip()
    title = f"Selected action: {selected_name}"

    response_summary = ""
    for observation in hit.observations:
        if observation.get("observation_kind") == "user_visible_response":
            response_summary = str(observation.get("summary") or "").strip()
            if response_summary:
                break
    if not response_summary and hit.observations:
        response_summary = str(hit.observations[0].get("summary") or "").strip()

    body_lines = []
    if response_summary:
        body_lines.append(f"Response: {response_summary}")
    selected_rationale = str(selected.get("rationale") or "").strip()
    if selected_rationale:
        body_lines.append(f"Rationale: {selected_rationale}")
    for line in _format_canonical_outcome_context(hit):
        if line.startswith("Candidates:"):
            body_lines.append(line)
            break
    body_text = "\n".join(body_lines) if body_lines else "(no content)"

    return RetrievalDocument(
        document_id=f"world_model_action:{hit.action_id}",
        item_id=None,
        title=title,
        body_text=body_text,
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=tuple(_format_canonical_outcome_context(hit)),
    )


def resolve_world_model_action_document(
    hit: CanonicalOutcomeHit,
    *,
    route_profile: PromptControlRouteProfile | str | None,
) -> RetrievalDocument:
    if hit.action_kind == "meeting_semantic_promotion":
        return _resolve_meeting_promotion_document(hit)
    return resolve_canonical_outcome_document(hit, route_profile=route_profile)


def resolve_semantic_mapping_document(
    hit: CanonicalSemanticMappingHit,
) -> RetrievalDocument:
    mapping = hit.mapping
    title = f"Mapping: {mapping.source_value} -> {mapping.target_value}"
    body_lines = [
        f"Mapping kind: {mapping.mapping_kind}",
        f"Scope: {mapping.scope_type}:{mapping.scope_key}",
    ]
    if mapping.source_surface:
        body_lines.append(f"Source surface: {mapping.source_surface}")
    return RetrievalDocument(
        document_id=f"world_model_mapping:{mapping.mapping_id}",
        item_id=None,
        title=title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: semantic mapping via {mapping.source_surface or 'c05_semantic_mapping'}",
            f"Kind: {mapping.mapping_kind}",
        ),
    )


def resolve_world_model_event_document(
    hit: CanonicalEventHit,
) -> RetrievalDocument:
    event = hit.event
    body_lines = []
    if event.summary:
        body_lines.append(event.summary)
    route_profile = str(event.payload.get("route_profile") or "").strip()
    selected_path = str(event.payload.get("selected_path") or "").strip()
    if route_profile:
        body_lines.append(f"Route profile: {route_profile}")
    if selected_path:
        body_lines.append(f"Selected path: {selected_path}")
    tool_names = event.payload.get("tool_names")
    if isinstance(tool_names, list) and tool_names:
        body_lines.append(f"Tool names: {', '.join(str(name) for name in tool_names)}")
    body_text = "\n".join(body_lines) if body_lines else "(no content)"
    context_lines = [f"Typed: event via {event.source_surface or 'c08_event'}"]
    if event.conversation_turn_id is not None:
        context_lines.append(f"Turn: {event.conversation_turn_id}")
    context_lines.append(f"Kind: {event.event_kind}")
    return RetrievalDocument(
        document_id=f"world_model_event:{event.event_id}",
        item_id=None,
        title=event.title,
        body_text=body_text,
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=tuple(context_lines),
    )


def resolve_world_model_action_plan_document(
    hit: CanonicalActionPlanHit,
) -> RetrievalDocument:
    plan = hit.plan
    body_lines = []
    if plan.summary:
        body_lines.append(plan.summary)
    if plan.goal_id:
        body_lines.append(f"Goal: {plan.goal_id}")
    if plan.selected_step_id:
        body_lines.append(f"Selected step: {plan.selected_step_id}")
    body_lines.append(f"Status: {plan.status}")
    return RetrievalDocument(
        document_id=f"world_model_action_plan:{plan.plan_id}",
        item_id=None,
        title=plan.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: action plan via {plan.source_surface or 'c08_action_plan'}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:4]
            ),
            *(
                f"linked_from {link['relationship']} <- {link['source_record_type']}:{link['source_record_id']}"
                + (f" ({link['source_title']})" if link.get("source_title") else "")
                for link in hit.incoming_links[:4]
            ),
        ),
    )


def resolve_world_model_plan_step_document(
    hit: CanonicalPlanStepHit,
) -> RetrievalDocument:
    step = hit.step
    body_lines = []
    if step.description:
        body_lines.append(step.description)
    body_lines.append(f"Status: {step.status}")
    body_lines.append(f"Ordinal: {step.ordinal}")
    body_lines.append(f"Progress: {step.progress_pct}%")
    if step.goal_id:
        body_lines.append(f"Goal: {step.goal_id}")
    if step.blocked_reason:
        body_lines.append(f"Blocked reason: {step.blocked_reason}")
    return RetrievalDocument(
        document_id=f"world_model_plan_step:{step.step_id}",
        item_id=None,
        title=step.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: plan step via {step.source_surface or 'c08_plan_step'}",
            f"Kind: {step.step_kind}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:5]
            ),
            *(
                f"linked_from {link['relationship']} <- {link['source_record_type']}:{link['source_record_id']}"
                + (f" ({link['source_title']})" if link.get("source_title") else "")
                for link in hit.incoming_links[:5]
            ),
        ),
    )


def resolve_world_model_execution_record_document(
    hit: CanonicalExecutionRecordHit,
) -> RetrievalDocument:
    record = hit.record
    body_lines = []
    if record.summary:
        body_lines.append(record.summary)
    body_lines.append(f"Status: {record.status}")
    body_lines.append(f"Session: {record.session_id}")
    if record.goal_id:
        body_lines.append(f"Goal: {record.goal_id}")
    if record.plan_id:
        body_lines.append(f"Plan: {record.plan_id}")
    if record.step_id:
        body_lines.append(f"Step: {record.step_id}")
    return RetrievalDocument(
        document_id=f"world_model_execution_record:{record.execution_id}",
        item_id=None,
        title=record.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: execution record via {record.source_surface or 'c08_execution_record'}",
            f"Kind: {record.execution_kind}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:5]
            ),
        ),
    )


def resolve_world_model_plan_step_transition_document(
    hit: CanonicalPlanStepTransitionHit,
) -> RetrievalDocument:
    transition = hit.transition
    body_lines = []
    if transition.summary:
        body_lines.append(transition.summary)
    if transition.from_status:
        body_lines.append(f"From: {transition.from_status}")
    if transition.to_status:
        body_lines.append(f"To: {transition.to_status}")
    if transition.progress_pct is not None:
        body_lines.append(f"Progress: {transition.progress_pct}%")
    if transition.blocked_reason is not None and transition.blocked_reason != "":
        body_lines.append(f"Blocked reason: {transition.blocked_reason}")
    body_lines.append(f"Step: {transition.step_id}")
    return RetrievalDocument(
        document_id=f"world_model_plan_step_transition:{transition.transition_id}",
        item_id=None,
        title=transition.summary or transition.transition_kind,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: plan step transition via {transition.source_surface or 'c08_plan_step_transition'}",
            f"Kind: {transition.transition_kind}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:5]
            ),
        ),
    )


def resolve_world_model_task_document(
    hit: CanonicalTaskHit,
) -> RetrievalDocument:
    task = hit.task
    body_lines = []
    if task.description:
        body_lines.append(task.description)
    if task.due_at is not None:
        body_lines.append(f"Due: {task.due_at.strftime('%Y-%m-%d %H:%M')}")
    if task.goal_id:
        body_lines.append(f"Goal: {task.goal_id}")
    body_lines.append(f"Status: {task.status}")
    return RetrievalDocument(
        document_id=f"world_model_task:{task.task_id}",
        item_id=None,
        title=task.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: task via {task.source_surface or 'c08_world_model_task'}",
            f"Kind: {task.task_kind}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:3]
            ),
            *(
                f"linked_from {link['relationship']} <- {link['source_record_type']}:{link['source_record_id']}"
                + (f" ({link['source_title']})" if link.get("source_title") else "")
                for link in hit.incoming_links[:3]
            ),
        ),
    )


def resolve_world_model_goal_document(
    hit: CanonicalGoalHit,
) -> RetrievalDocument:
    goal = hit.goal
    body_lines = []
    if goal.description:
        body_lines.append(goal.description)
    body_lines.append(f"Status: {goal.status}")
    body_lines.append(f"Priority: {goal.priority}")
    if goal.deadline_text:
        body_lines.append(f"Deadline: {goal.deadline_text}")
    if goal.parent_goal_id:
        body_lines.append(f"Parent goal: {goal.parent_goal_id}")
    if goal.blocked_by_goal_id:
        body_lines.append(f"Blocked by: {goal.blocked_by_goal_id}")
    if goal.blocked_reason:
        body_lines.append(f"Blocked reason: {goal.blocked_reason}")
    if goal.failure_reason:
        body_lines.append(f"Failure reason: {goal.failure_reason}")
    return RetrievalDocument(
        document_id=f"world_model_goal:{goal.goal_id}",
        item_id=None,
        title=goal.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: goal via {goal.source_surface or 'c08_world_model_goal'}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:3]
            ),
            *(
                f"linked_from {link['relationship']} <- {link['source_record_type']}:{link['source_record_id']}"
                + (f" ({link['source_title']})" if link.get("source_title") else "")
                for link in hit.incoming_links[:3]
            ),
        ),
    )


def resolve_world_model_commitment_document(
    hit: CanonicalCommitmentHit,
) -> RetrievalDocument:
    commitment = hit.commitment
    body_lines = []
    if commitment.description:
        body_lines.append(commitment.description)
    if commitment.assignee:
        body_lines.append(f"Assignee: {commitment.assignee}")
    if commitment.deadline_text:
        body_lines.append(f"Deadline: {commitment.deadline_text}")
    if commitment.agreed_by:
        body_lines.append(f"Agreed by: {commitment.agreed_by}")
    if commitment.goal_id:
        body_lines.append(f"Goal: {commitment.goal_id}")
    body_lines.append(f"Status: {commitment.status}")
    return RetrievalDocument(
        document_id=f"world_model_commitment:{commitment.commitment_id}",
        item_id=None,
        title=commitment.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: commitment via {commitment.source_surface or 'c08_world_model_commitment'}",
            *(
                f"{link['relationship']} -> {link['target_record_type']}:{link['target_record_id']}"
                for link in hit.provenance[:3]
            ),
        ),
    )


def resolve_world_model_dependency_document(
    hit: CanonicalDependencyHit,
) -> RetrievalDocument:
    relationship_label = hit.relationship.replace("_", " ")
    title = f"{hit.source_title} {relationship_label} {hit.target_title}".strip()
    body_lines = [
        f"Relationship: {hit.relationship}",
        f"Source: {hit.source_record_type}:{hit.source_record_id}",
        f"Target: {hit.target_record_type}:{hit.target_record_id}",
    ]
    if hit.source_status:
        body_lines.append(f"Source status: {hit.source_status}")
    if hit.target_status:
        body_lines.append(f"Target status: {hit.target_status}")
    return RetrievalDocument(
        document_id=f"world_model_dependency:{hit.link_id}",
        item_id=None,
        title=title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            "Typed: dependency via c08_planning_dependency",
            f"Relationship: {hit.relationship}",
            f"Source title: {hit.source_title}",
            f"Target title: {hit.target_title}",
        ),
    )


def resolve_world_model_claim_evaluation_document(
    hit: CanonicalClaimEvaluationHit,
) -> RetrievalDocument:
    evaluation = hit.evaluation
    body_lines = []
    if evaluation.summary:
        body_lines.append(evaluation.summary)
    for key in ("original", "corrected", "context", "evidence", "verdict"):
        value = str(evaluation.payload.get(key) or "").strip()
        if value:
            body_lines.append(f"{key.replace('_', ' ').title()}: {value}")
    body_lines.append(f"Status: {evaluation.status}")
    return RetrievalDocument(
        document_id=f"world_model_claim_evaluation:{evaluation.evaluation_id}",
        item_id=None,
        title=evaluation.title,
        body_text="\n".join(body_lines),
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=(
            f"Typed: claim evaluation via {evaluation.source_surface or 'c05_claim_evaluation'}",
            f"Kind: {evaluation.evaluation_kind}",
            f"Knowledge: {evaluation.knowledge_id}",
        ),
    )


def knowledge_semantic_kind(knowledge) -> str:
    if knowledge is None:
        return ""
    payload = knowledge.payload or {}
    semantic_kind = str(payload.get("semantic_kind") or "").strip()
    if semantic_kind:
        return semantic_kind
    typed = payload.get("typed")
    if isinstance(typed, dict):
        return str(
            typed.get("semantic_kind") or typed.get("knowledge_type") or ""
        ).strip()
    return ""


def _candidate_title(item, knowledge, *, fallback_item_id: str) -> str:
    title = ""
    if knowledge is not None and getattr(knowledge, "title", ""):
        title = str(knowledge.title)
    elif item is not None and getattr(item, "title", ""):
        title = str(item.title)
    elif knowledge is not None and getattr(knowledge, "canonical_key", ""):
        title = str(knowledge.canonical_key)
    else:
        title = fallback_item_id

    if knowledge is not None:
        kt = getattr(knowledge, "knowledge_type", "") or ""
        if kt and kt not in {
            "note",
            "article",
            "reference",
            "session_summary",
            "claim",
        }:
            label = kt.replace("_", " ").title()
            if not title.lower().startswith(label.lower()):
                title = f"{label}: {title}"
    return title


def _source_url(item, knowledge) -> str:
    if knowledge is not None and getattr(knowledge, "source_url", ""):
        return str(knowledge.source_url)
    if item is not None and getattr(item, "source_url", ""):
        return str(item.source_url)
    return ""


def _body_text(item, knowledge) -> str:
    if knowledge is not None:
        payload = knowledge.payload or {}
        try:
            from memex.typed_knowledge import (
                meeting_semantic_summary_from_payload,
                typed_semantic_summary_from_payload,
            )

            semantic_summary = typed_semantic_summary_from_payload(payload)
            if semantic_summary:
                return semantic_summary
            semantic_summary = meeting_semantic_summary_from_payload(payload)
            if semantic_summary:
                return semantic_summary
        except Exception:
            logger.debug(
                "Typed-knowledge semantic summary extraction failed", exc_info=True
            )
        for key in ("summary_text", "body_excerpt"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value

    if item is not None and item.summary.text:
        return item.summary.text
    if item is not None and item.body:
        return item.body
    return "(no content)"


def _format_world_model_context(
    knowledge,
    *,
    route_profile: PromptControlRouteProfile | str | None = None,
    knowledge_relationships: list[dict[str, str]] | None = None,
) -> list[str]:
    if knowledge is None:
        return []

    route_value = (
        route_profile.value
        if isinstance(route_profile, PromptControlRouteProfile)
        else (route_profile or "")
    )
    if (
        knowledge.knowledge_type in {"reference", "note"}
        and knowledge.source_surface
        in {
            "",
            "memory_intake",
        }
        and not knowledge_relationships
        and route_value
        not in {
            PromptControlRouteProfile.RESEARCH_VERIFIED.value,
            PromptControlRouteProfile.GUARDED_REVIEW.value,
        }
    ):
        return []

    label = knowledge.knowledge_type.replace("_", " ")
    lines = [
        f"Typed: {label} via {knowledge.source_surface}"
        if knowledge.source_surface
        else f"Typed: {label}"
    ]
    semantic_kind = knowledge_semantic_kind(knowledge)
    if semantic_kind:
        lines.append(f"Semantic: {semantic_kind}")
    for relationship in (knowledge_relationships or [])[:3]:
        target_knowledge_id = str(relationship.get("target_knowledge_id") or "").strip()
        relationship_kind = str(relationship.get("relationship_kind") or "").strip()
        target_title = str(relationship.get("target_title") or "").strip()
        if relationship_kind and target_knowledge_id:
            line = f"{relationship_kind} -> world_model_knowledge:{target_knowledge_id}"
            if target_title:
                line += f" ({target_title})"
            lines.append(line)
        summary = str(relationship.get("summary") or "").strip()
        if summary:
            lines.append(f"Relation: {summary}")
    payload = knowledge.payload or {}
    corrections = payload.get("corrections")
    if isinstance(corrections, list):
        for correction in corrections[:3]:
            if isinstance(correction, dict):
                original = str(correction.get("original") or "").strip()
                corrected = str(correction.get("corrected") or "").strip()
                if original and corrected:
                    lines.append(f"Correction: {original} -> {corrected}")
    if route_value in {
        PromptControlRouteProfile.RESEARCH_VERIFIED.value,
        PromptControlRouteProfile.GUARDED_REVIEW.value,
    }:
        canonical = knowledge.source_url or knowledge.canonical_key
        if canonical:
            lines.append(f"Canonical: {canonical}")
    return lines


def _format_canonical_outcome_context(hit: CanonicalOutcomeHit) -> list[str]:
    lines = [
        f"Typed: selected action via {hit.source_surface or 'c08_selected_action'}",
        f"Status: {hit.status}",
    ]
    if hit.conversation_turn_id is not None:
        lines.append(f"Turn: {hit.conversation_turn_id}")
    payload = hit.payload if isinstance(hit.payload, dict) else {}
    route_profile = str(payload.get("route_profile") or "").strip()
    selected_path = str(payload.get("selected_path") or "").strip()
    if route_profile or selected_path:
        lines.append(
            " | ".join(
                part
                for part in (
                    f"Route: {route_profile}" if route_profile else "",
                    f"Path: {selected_path}" if selected_path else "",
                )
                if part
            )
        )
    candidates = payload.get("action_candidates")
    if isinstance(candidates, list) and candidates:
        rendered: list[str] = []
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            name = str(candidate.get("name") or "").strip()
            if not name:
                continue
            rendered.append(f"{name}[selected]" if candidate.get("selected") else name)
        if rendered:
            lines.append(f"Candidates: {', '.join(rendered)}")
    for link in sorted(
        hit.provenance,
        key=lambda row: (
            row["relationship"],
            row["target_record_type"],
            row["target_record_id"],
        ),
    ):
        lines.append(
            f"Provenance: {link['relationship']} {link['target_record_type']} | "
            f"{link['target_record_id']}"
        )
    return lines


def _resolve_meeting_promotion_document(hit: CanonicalOutcomeHit) -> RetrievalDocument:
    summary = ""
    promoted_item_id = ""
    for observation in hit.observations:
        if observation.get("observation_kind") == "promoted_semantic_item":
            summary = str(observation.get("summary") or "").strip()
            break
    payload = hit.payload if isinstance(hit.payload, dict) else {}
    promoted_item_id = str(payload.get("promoted_item_id") or "").strip()

    title = f"Meeting promotion: {summary or hit.action_name or 'promotion'}"
    body_lines = []
    if summary:
        body_lines.append(f"Promoted: {summary}")
    if promoted_item_id:
        body_lines.append(f"Item: {promoted_item_id}")
    body_text = "\n".join(body_lines) if body_lines else "(no content)"

    return RetrievalDocument(
        document_id=f"world_model_action:{hit.action_id}",
        item_id=None,
        title=title,
        body_text=body_text,
        source_url="",
        reputation_display="unrated",
        relevance_pct=int(min(hit.score, 1.0) * 100),
        world_model_context_lines=tuple(_format_meeting_promotion_context(hit)),
    )


def _format_meeting_promotion_context(hit: CanonicalOutcomeHit) -> list[str]:
    lines = [
        f"Typed: meeting semantic promotion via {hit.source_surface or 'c04_meeting_semantic_promotion'}",
        f"Status: {hit.status}",
    ]
    if hit.meeting_id:
        lines.append(f"Meeting: {hit.meeting_id}")
    lines.append(f"Artifact: {hit.action_name}")
    for link in sorted(
        hit.provenance,
        key=lambda row: (
            row["relationship"],
            row["target_record_type"],
            row["target_record_id"],
        ),
    ):
        lines.append(
            f"Provenance: {link['relationship']} {link['target_record_type']} | "
            f"{link['target_record_id']}"
        )
    return lines
