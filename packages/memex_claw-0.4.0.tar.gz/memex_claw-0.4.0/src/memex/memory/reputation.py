"""Source reputation utilities.

Pure functions for reputation scoring and display. The sqlite3-based
free functions (record_feedback, get_reputation_factor) have been removed;
the live path uses FathomMemexStore methods directly.
"""

from __future__ import annotations


def compute_reputation_score(accuracy_history: list[float]) -> float:
    """Exponentially weighted moving average of accuracy scores.

    Empty history returns 0.5 (neutral). Pure function.
    Recent entries have more weight (decay factor 0.9).
    """
    if not accuracy_history:
        return 0.5

    weight = 1.0
    decay = 0.9
    total_weight = 0.0
    total_score = 0.0

    for score in reversed(accuracy_history):
        total_score += score * weight
        total_weight += weight
        weight *= decay

    return total_score / total_weight


def reputation_display(score: float, confidence: float) -> str:
    """Human-readable reputation label."""
    if confidence < 0.1:
        return "unrated"
    if score >= 0.8:
        return "trusted"
    if score >= 0.6:
        return "good"
    if score >= 0.4:
        return "neutral"
    if score >= 0.2:
        return "questionable"
    return "untrusted"
