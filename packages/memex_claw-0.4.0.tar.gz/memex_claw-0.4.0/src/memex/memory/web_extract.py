"""Web content extraction using trafilatura.

Pure function layer — no database access, no LLM calls.
Takes HTML (or a URL) and returns structured content.
"""

from __future__ import annotations

import html as html_lib
import logging
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

_FETCH_TIMEOUT = 30
_MAX_REASONABLE_TITLE_LENGTH = 180
_TEXT_LIKE_CONTENT_TYPES = (
    "text/plain",
    "text/markdown",
    "text/x-markdown",
    "application/markdown",
)
_HTML_NOISE_BLOCK_PATTERNS = (
    r"<script\b[^>]*>.*?</script>",
    r"<style\b[^>]*>.*?</style>",
    r"<noscript\b[^>]*>.*?</noscript>",
    r"<svg\b[^>]*>.*?</svg>",
    r"<nav\b[^>]*>.*?</nav>",
    r"<footer\b[^>]*>.*?</footer>",
    r"<header\b[^>]*>.*?</header>",
    r"<form\b[^>]*>.*?</form>",
)


@dataclass(frozen=True)
class ExtractedContent:
    """Deterministic extraction result from a web page."""

    url: str
    title: str = ""
    author: str = ""
    date: str = ""
    body: str = ""
    description: str = ""
    sitename: str = ""
    language: str = ""
    categories: list[str] = field(default_factory=list)
    word_count: int = 0
    raw_length: int = 0

    @property
    def is_substantial(self) -> bool:
        """Whether the extraction yielded meaningful content."""
        return self.word_count > 50


def _clean_title_text(value: str) -> str:
    value = re.sub(r"<[^>]+>", " ", value)
    value = html_lib.unescape(value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _fallback_title_from_html(html: str) -> str:
    patterns = (
        r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)["\']',
        r'<meta[^>]+name=["\']twitter:title["\'][^>]+content=["\']([^"\']+)["\']',
        r"<title[^>]*>(.*?)</title>",
        r"<h1[^>]*>(.*?)</h1>",
    )
    for pattern in patterns:
        match = re.search(pattern, html, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue
        candidate = _clean_title_text(match.group(1))
        if candidate:
            return candidate
    return ""


def _clean_text_title(value: str) -> str:
    value = re.sub(r"^\s{0,3}#{1,6}\s*", "", value)
    value = re.sub(r"^\s*[-*+]\s+", "", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _extract_from_text(text: str, *, url: str = "") -> ExtractedContent:
    if not text or not text.strip():
        return ExtractedContent(url=url, raw_length=0)

    raw_length = len(text)
    body = text.strip()
    lines = [line.strip() for line in body.splitlines() if line.strip()]
    title = ""
    for line in lines:
        candidate = _clean_text_title(line)
        if candidate:
            title = candidate[:200]
            break

    word_count = len(body.split())
    return ExtractedContent(
        url=url,
        title=title,
        body=body,
        word_count=word_count,
        raw_length=raw_length,
    )


def _extract_description_from_html(html: str) -> str:
    patterns = (
        r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']',
        r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']+)["\']',
    )
    for pattern in patterns:
        match = re.search(pattern, html, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue
        candidate = _clean_title_text(match.group(1))
        if candidate:
            return candidate[:500]
    return ""


def _extract_text_fallback_from_html(html: str, *, url: str = "") -> ExtractedContent:
    raw_length = len(html)
    cleaned = html
    for pattern in _HTML_NOISE_BLOCK_PATTERNS:
        cleaned = re.sub(pattern, " ", cleaned, flags=re.IGNORECASE | re.DOTALL)
    cleaned = re.sub(
        r"</(p|div|section|article|main|li|ul|ol|h[1-6]|br|tr|table)>",
        "\n",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"<[^>]+>", " ", cleaned)
    cleaned = html_lib.unescape(cleaned)
    cleaned = re.sub(r"[ \t\r\f\v]+", " ", cleaned)
    cleaned = re.sub(r"\n\s*\n+", "\n\n", cleaned)
    body = cleaned.strip()
    title = _fallback_title_from_html(html)
    if not title and body:
        first_line = body.split("\n", 1)[0].strip()
        if first_line:
            title = first_line[:200]
    description = _extract_description_from_html(html)
    word_count = len(body.split()) if body else 0
    return ExtractedContent(
        url=url,
        title=title,
        body=body,
        description=description,
        word_count=word_count,
        raw_length=raw_length,
    )


def _html_to_markdown(html_fragment: str) -> str:
    """Convert a cleaned HTML fragment to markdown.

    Gracefully degrades to plain text if markdownify is not installed.
    """
    if not html_fragment or not html_fragment.strip():
        return ""

    try:
        from markdownify import markdownify

        md = markdownify(
            html_fragment,
            heading_style="ATX",
            bullets="-",
            strip=["img", "figure", "figcaption"],
        )
        # Collapse excessive blank lines from conversion artifacts
        md = re.sub(r"\n{3,}", "\n\n", md)
        return md.strip()
    except (ImportError, TypeError):
        logger.debug("markdownify not available, falling back to tag stripping")
        text = re.sub(r"<[^>]+>", " ", html_fragment)
        text = html_lib.unescape(text)
        text = re.sub(r"\s+", " ", text).strip()
        return text


def extract_from_html(html: str, *, url: str = "") -> ExtractedContent:
    """Extract clean content and metadata from raw HTML.

    Never raises — returns ExtractedContent with empty fields on failure.
    """
    import trafilatura

    if not html or not html.strip():
        return ExtractedContent(url=url, raw_length=0)

    raw_length = len(html)

    try:
        data = trafilatura.bare_extraction(
            html,
            url=url,
            include_comments=False,
            include_tables=True,
            include_links=True,
            favor_precision=False,
            favor_recall=True,
        )
    except Exception:
        logger.debug("trafilatura extraction failed", exc_info=True)
        return _extract_text_fallback_from_html(html, url=url)

    if data is None:
        return _extract_text_fallback_from_html(html, url=url)

    # trafilatura 2.0 returns a Document object with attributes
    plain_body = getattr(data, "text", "") or ""
    title = getattr(data, "title", "") or ""
    author = getattr(data, "author", "") or ""
    date = getattr(data, "date", "") or ""
    description = getattr(data, "description", "") or ""
    sitename = getattr(data, "sitename", "") or ""
    language = getattr(data, "language", "") or ""

    raw_categories = getattr(data, "categories", None) or ""
    if isinstance(raw_categories, str):
        categories = [c.strip() for c in raw_categories.split(",") if c.strip()]
    elif isinstance(raw_categories, list):
        categories = raw_categories
    else:
        categories = []

    raw_tags = getattr(data, "tags", None) or ""
    if isinstance(raw_tags, str):
        tags = [t.strip() for t in raw_tags.split(",") if t.strip()]
    elif isinstance(raw_tags, list):
        tags = raw_tags
    else:
        tags = []

    categories = list(set(categories + tags))

    # Convert body to markdown: use trafilatura's HTML output, then markdownify
    body = plain_body
    try:
        body_html = trafilatura.extract(
            html,
            url=url,
            include_comments=False,
            include_tables=True,
            include_links=True,
            favor_precision=False,
            favor_recall=True,
            output_format="html",
        )
        if body_html:
            md_body = _html_to_markdown(body_html)
            if md_body:
                body = md_body
    except Exception:
        logger.debug("markdown conversion failed, using plain text", exc_info=True)

    if not title or len(title) > _MAX_REASONABLE_TITLE_LENGTH:
        fallback_title = _fallback_title_from_html(html)
        if fallback_title:
            title = fallback_title

    # Final fallback: extract title from the first body line
    if not title and body:
        first_line = body.split("\n", 1)[0].strip()
        if first_line and len(first_line) < 200:
            title = first_line

    word_count = len(body.split()) if body else 0
    if word_count < 50:
        fallback = _extract_text_fallback_from_html(html, url=url)
        if fallback.word_count > word_count:
            if not title:
                title = fallback.title
            if not description:
                description = fallback.description
            body = fallback.body
            word_count = fallback.word_count

    return ExtractedContent(
        url=url,
        title=title,
        author=author,
        date=date,
        body=body,
        description=description,
        sitename=sitename,
        language=language,
        categories=categories,
        word_count=word_count,
        raw_length=raw_length,
    )


def extract_from_url(url: str, *, timeout: int = _FETCH_TIMEOUT) -> ExtractedContent:
    """Fetch a URL and extract clean content. Never raises.

    YouTube URLs are automatically routed to yt-dlp extraction instead of
    HTTP fetching, since curl_cffi/httpx cannot extract video transcripts.
    """
    from memex.memory.youtube_extract import is_youtube_url, extract_from_youtube

    if is_youtube_url(url):
        return extract_from_youtube(url)

    result = fetch_url_result(url, timeout=timeout)
    return extract_from_fetch_result(result)


def fetch_url_result(
    url: str,
    *,
    timeout: int = _FETCH_TIMEOUT,
    request_headers: dict[str, str] | None = None,
):
    """Fetch a URL and return the raw fetch result for callers that need headers."""
    from memex.connectors.web_fetcher import get_strategy

    try:
        result = get_strategy().fetch(url, timeout=timeout, headers=request_headers)
        if not result.ok:
            logger.debug("Failed to fetch %s: %s", url, result.error)
            return result
    except Exception:
        logger.debug("Failed to fetch %s", url, exc_info=True)
        from memex.connectors.web_fetcher import FetchResult

        return FetchResult(url=url, status_code=0, text="", ok=False)

    return result


def extract_from_fetch_result(result) -> ExtractedContent:
    """Extract clean content from a previously fetched result."""
    if result.status_code == 304:
        return ExtractedContent(url=result.url)
    if not result.ok:
        return ExtractedContent(url=result.url)
    content_type = str(getattr(result, "headers", {}).get("content-type") or "").lower()
    if any(content_type.startswith(prefix) for prefix in _TEXT_LIKE_CONTENT_TYPES):
        return _extract_from_text(result.text, url=result.url)
    return extract_from_html(result.text, url=result.url)
