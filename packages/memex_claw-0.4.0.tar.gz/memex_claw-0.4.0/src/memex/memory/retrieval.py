"""Retrieval bridge between memory store and agentic loop (d-007)."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from memex.models import PromptControlRouteProfile, RankConfig
from memex.memory.decay import is_expired, item_decay_weight
from memex.memory.retrieval_documents import (
    RetrievalDocument,
    knowledge_semantic_kind,
    resolve_world_model_action_plan_document,
    resolve_world_model_execution_record_document,
    resolve_world_model_claim_evaluation_document,
    resolve_world_model_dependency_document,
    resolve_world_model_goal_document,
    resolve_world_model_plan_step_document,
    resolve_world_model_plan_step_transition_document,
    resolve_retrieval_document,
    resolve_world_model_commitment_document,
    resolve_semantic_mapping_document,
    resolve_world_model_task_document,
    resolve_world_model_event_document,
    resolve_world_model_action_document,
)
from memex.memory.ranking import (
    normalize_bm25,
    rank_score,
    route_profile_world_model_boost,
)
from memex.memory.reputation import reputation_display
from memex.memory.store import ContentStore
from memex.memory.world_model_reads import (
    CanonicalKnowledgeHit,
    CanonicalOutcomeHit,
    WorldModelReadStore,
    resolve_world_model_reads,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_OUTCOME_LEAD_THRESHOLD = 0.6
_OUTCOME_LEAD_MARGIN = 0.05


def _apply_outcome_lead_sort(
    scored_items: list["RetrievalCandidate"],
) -> list["RetrievalCandidate"]:
    """Sort candidates with the outcome-lead tiebreak.

    Canonical outcome hits are allowed to lead the result list when both
    conditions hold:

    * The outcome's composite score is at least ``_OUTCOME_LEAD_THRESHOLD``
      (``0.6``) — strong enough on its own to be trustworthy.
    * The outcome is within ``_OUTCOME_LEAD_MARGIN`` (``0.05``) of the best
      non-outcome score — close enough that the tiebreak is legitimate
      rather than overriding a clearly-better knowledge hit.

    Secondary sort keys (composite score, canonical backing, relevance_pct,
    decay_weight, title) apply inside the outcome-lead and non-lead groups.
    Extracted from ``_retrieve_candidates`` so it can be unit-tested directly
    against constructed ``RetrievalCandidate`` rows without exercising the
    full search pipeline.
    """
    best_non_outcome_score = max(
        (
            candidate.score
            for candidate in scored_items
            if candidate.document_family != "canonical_outcome"
        ),
        default=0.0,
    )

    scored_items.sort(
        key=lambda candidate: (
            1
            if (
                candidate.document_family == "canonical_outcome"
                and candidate.score >= _OUTCOME_LEAD_THRESHOLD
                and candidate.score + _OUTCOME_LEAD_MARGIN >= best_non_outcome_score
            )
            else 0,
            candidate.score,
            1 if candidate.canonical_backed else 0,
            candidate.document.relevance_pct,
            candidate.decay_weight,
            candidate.document.title.lower(),
        ),
        reverse=True,
    )
    return scored_items


@dataclass(frozen=True)
class _WMSimpleSearchSpec:
    """Dispatch-table entry for a world-model kind that migrates to the
    ``engine.nodes(kind).search() + load_*_document(id)`` pattern.

    Each entry drives one iteration of the fan-out loop in
    ``_retrieve_candidates``:

    1. ``engine.nodes(fathom_kind).search(query, limit).execute()`` returns
       a ``SearchRows`` of fathomdb property-FTS hits.
    2. For each hit, ``id_field`` names the property on the node that
       carries the entity id (e.g. ``"mapping_id"`` for WMSemanticMapping).
    3. ``load_method`` names the method on ``FathomWorldModelReads`` that
       loads the fully-augmented typed hit by id (provenance, incoming
       links, etc.). Reusing the existing by-id loaders avoids duplicating
       augmentation logic.
    4. The loader returns a ``Canonical*Hit`` with ``score=1.0``; the
       dispatch loop overrides it with a position-based score
       (``1.0 - i/total``) so higher-ranked property-FTS hits still lead.
    5. ``resolver`` turns the typed hit into a ``RetrievalDocument`` for
       the final candidate.

    Three world-model surfaces are NOT in this table and keep custom
    handling in ``_retrieve_candidates``:
      * **WMKnowledgeObject** — the canonical-knowledge / legacy-item
        blended scoring loop (decay, reputation, query-term signal
        blending, typed boosts, pinned boost, ki- shell dedup).
      * **WMAction** (canonical_outcome + meeting_promotion) — primary
        search + observation-to-action fanout + action_kind split +
        per-hit observation and provenance augmentation.
      * **WMDependency** — there is no WMDependency fathomdb kind; the
        search is a Python-side scan over
        ``list_world_model_provenance_links`` with reconstructed titles.
        Left in place as a known exception until optimization is
        prioritized.
    """

    document_family: str
    fathom_kind: str
    id_field: str
    load_method: str
    resolver: Callable[[Any], Any]  # hit -> RetrievalDocument


_WM_SIMPLE_SPECS: tuple[_WMSimpleSearchSpec, ...] = (
    _WMSimpleSearchSpec(
        document_family="semantic_mapping",
        fathom_kind="WMSemanticMapping",
        id_field="mapping_id",
        load_method="load_semantic_mapping_document",
        resolver=resolve_semantic_mapping_document,
    ),
    _WMSimpleSearchSpec(
        document_family="action_plan",
        fathom_kind="WMPlan",
        id_field="plan_id",
        load_method="load_action_plan_document",
        resolver=resolve_world_model_action_plan_document,
    ),
    _WMSimpleSearchSpec(
        document_family="plan_step",
        fathom_kind="WMPlanStep",
        id_field="step_id",
        load_method="load_plan_step_document",
        resolver=resolve_world_model_plan_step_document,
    ),
    _WMSimpleSearchSpec(
        document_family="execution_record",
        fathom_kind="WMExecutionRecord",
        id_field="execution_id",
        load_method="load_execution_record_document",
        resolver=resolve_world_model_execution_record_document,
    ),
    _WMSimpleSearchSpec(
        document_family="plan_step_transition",
        fathom_kind="WMPlanStepTransition",
        id_field="transition_id",
        load_method="load_plan_step_transition_document",
        resolver=resolve_world_model_plan_step_transition_document,
    ),
    _WMSimpleSearchSpec(
        document_family="task",
        fathom_kind="WMTask",
        id_field="task_id",
        load_method="load_task_document",
        resolver=resolve_world_model_task_document,
    ),
    _WMSimpleSearchSpec(
        document_family="goal",
        fathom_kind="WMGoal",
        id_field="goal_id",
        load_method="load_goal_document",
        resolver=resolve_world_model_goal_document,
    ),
    _WMSimpleSearchSpec(
        document_family="commitment",
        fathom_kind="WMCommitment",
        id_field="commitment_id",
        load_method="load_commitment_document",
        resolver=resolve_world_model_commitment_document,
    ),
    _WMSimpleSearchSpec(
        document_family="claim_evaluation",
        fathom_kind="WMClaimEvaluation",
        id_field="evaluation_id",
        load_method="load_claim_evaluation_document",
        resolver=resolve_world_model_claim_evaluation_document,
    ),
    _WMSimpleSearchSpec(
        document_family="event",
        fathom_kind="WMEvent",
        id_field="event_id",
        load_method="load_event_document",
        resolver=resolve_world_model_event_document,
    ),
)


def _search_canonical_knowledge_hits(
    *,
    wmr: Any,  # FathomWorldModelReads
    engine: Any,
    query: str,
    limit: int,
) -> tuple[list[CanonicalKnowledgeHit], list[Any]]:
    """Property-FTS search on WMKnowledgeObject with canonical-over-shell
    dedup by ``item_id``.

    fathomdb 0.3.1's recursive ``$.payload`` property FTS (registered in
    m004) indexes nested payload tokens, so the previous Python-side
    ``list_world_model_knowledge_objects(limit=500)`` payload scan is
    redundant and is NOT reproduced here.

    Dedup rule: when the same ``item_id`` has both a canonical knowledge
    object (``knowledge_id`` does not start with ``ki-``) and an
    auto-synced shell (``ki-`` prefix), prefer the canonical. The
    canonical replacement inherits the first-seen FTS rank position so
    ranking stays stable.

    Per-hit augmentation (knowledge relationships) is delegated to
    ``FathomWorldModelReads.load_knowledge_document_hit`` (the single-id
    loader that already exists).
    """
    if not query.strip() or wmr is None or engine is None:
        return [], []

    from dataclasses import replace

    try:
        rows = engine.nodes("WMKnowledgeObject").search(query, limit).execute()
    except Exception:
        logger.debug("WMKnowledgeObject property-FTS failed", exc_info=True)
        return [], []
    search_rows_list: list[Any] = [rows]
    if not rows.hits:
        return [], search_rows_list

    # Dedup by item_id, preserving first-seen position and preferring canonical
    # over ki- shell knowledge objects.
    best_by_item: dict[str, tuple[int, str]] = {}
    for i, hit in enumerate(rows.hits):
        props = hit.node.properties or {}
        item_id = props.get("item_id") or ""
        kid = props.get("knowledge_id") or ""
        if not item_id or not kid:
            continue
        existing = best_by_item.get(item_id)
        if existing is None:
            best_by_item[item_id] = (i, kid)
        elif existing[1].startswith("ki-") and not kid.startswith("ki-"):
            # Replace shell with canonical, keep the first-seen rank position.
            best_by_item[item_id] = (existing[0], kid)

    ordered = sorted(best_by_item.values(), key=lambda entry: entry[0])
    deduped_kids = [kid for _, kid in ordered]

    hits: list[CanonicalKnowledgeHit] = []
    total = max(len(deduped_kids), 1)
    for i, kid in enumerate(deduped_kids):
        try:
            loaded = wmr.load_knowledge_document_hit(kid)
        except Exception:
            logger.debug(
                "load_knowledge_document_hit failed for knowledge_id=%s",
                kid,
                exc_info=True,
            )
            continue
        if loaded is None:
            continue
        hits.append(replace(loaded, score=1.0 - (i / total)))
    return hits, search_rows_list


def _search_canonical_action_hits(
    *,
    wmr: Any,  # FathomWorldModelReads
    engine: Any,
    query: str,
    limit: int,
) -> tuple[list[CanonicalOutcomeHit], list[Any]]:
    """Primary WMAction property-FTS + secondary WMObservation→WMAction
    expansion, returning deduped CanonicalOutcomeHit rows.

    Returns all action hits regardless of action_kind; callers split by kind
    (canonical outcome vs meeting_semantic_promotion) as needed. Reuses the
    existing ``FathomWorldModelReads.load_canonical_outcome`` by-id loader
    for per-hit augmentation (observations + provenance).

    The secondary WMObservation→WMAction step uses fathomdb 0.4.1+
    ``SearchBuilder.expand().execute_grouped()`` to collapse the N+1
    per-hit traversal into a single grouped call.
    """
    if not query.strip() or wmr is None or engine is None:
        return [], []

    from dataclasses import replace

    from fathomdb import TraverseDirection

    from memex.fathom_store import EDGE_HAS_OBSERVATION

    search_rows_list: list[Any] = []
    # Primary: property-FTS on WMAction. Over-fetch by 3x to leave budget
    # for per-kind filtering (outcome vs meeting_promotion) in the caller.
    primary_action_ids: list[str] = []
    try:
        primary_rows = engine.nodes("WMAction").search(query, limit * 3).execute()
        search_rows_list.append(primary_rows)
        for hit in primary_rows.hits:
            aid = (hit.node.properties or {}).get("action_id")
            if aid:
                primary_action_ids.append(aid)
    except Exception:
        logger.debug("WMAction property-FTS failed", exc_info=True)

    # Secondary: property-FTS on WMObservation → single grouped expand IN
    # HAS_OBSERVATION to parent WMAction, collapsing what was an N+1 per-hit
    # .traverse() round-trip into a single call.
    secondary_action_ids: list[str] = []
    try:
        grouped = (
            engine.nodes("WMObservation")
            .search(query, limit)
            .expand(
                slot="parent_action",
                direction=TraverseDirection.IN,
                label=EDGE_HAS_OBSERVATION,
                max_depth=1,
            )
            .execute_grouped()
        )
        for slot_rows in grouped.expansions:
            if slot_rows.slot != "parent_action":
                continue
            for root_rows in slot_rows.roots:
                for n in root_rows.nodes:
                    if n.kind == "WMAction":
                        aid = (n.properties or {}).get("action_id")
                        if aid:
                            secondary_action_ids.append(aid)
    except Exception:
        logger.debug("WMObservation→WMAction grouped expand failed", exc_info=True)

    # Dedup in order: primary first (preserves FTS rank), then secondary.
    seen: set[str] = set()
    ordered_ids: list[str] = []
    for aid in [*primary_action_ids, *secondary_action_ids]:
        if aid in seen:
            continue
        seen.add(aid)
        ordered_ids.append(aid)

    # Reuse the existing by-id loader for full per-hit augmentation
    # (observations, provenance). Override the loader's score=1.0 with
    # position-based ranking so the first hit leads.
    hits: list[CanonicalOutcomeHit] = []
    total = max(len(ordered_ids), 1)
    for i, aid in enumerate(ordered_ids):
        try:
            loaded = wmr.load_canonical_outcome(aid)
        except Exception:
            logger.debug(
                "load_canonical_outcome failed for action_id=%s", aid, exc_info=True
            )
            continue
        if loaded is None:
            continue
        hits.append(replace(loaded, score=1.0 - (i / total)))
    return hits, search_rows_list


def _search_and_load_typed_hits(
    *,
    wmr: Any,
    engine: Any,
    spec: _WMSimpleSearchSpec,
    query: str,
    limit: int,
) -> tuple[list[Any], list[Any]]:
    """Run property-FTS search for ``spec.fathom_kind``, then fan out to
    ``spec.load_method`` for per-hit augmentation.

    Replaces the fourteen ``search_*_documents`` shims that used to live on
    ``FathomWorldModelReads``. By going straight through ``engine.nodes``
    and reusing the existing by-id loaders, there is no duplicate
    augmentation logic anywhere. The seam between search and augmentation
    is honest: a SearchRows return from fathomdb, then a sequence of
    by-id load calls from Memex.

    Score is position-based within the SearchRows block — the loader's
    ``score=1.0`` is overridden so the first hit wins within a kind.
    """
    if not query.strip() or wmr is None:
        return [], []
    if engine is None:
        logger.debug(
            "world model engine unavailable; skipping %s dispatch",
            spec.fathom_kind,
        )
        return [], []
    try:
        rows = engine.nodes(spec.fathom_kind).search(query, limit).execute()
    except Exception:
        logger.debug(
            "property-FTS search failed for kind %s", spec.fathom_kind, exc_info=True
        )
        return [], []
    search_rows_list: list[Any] = [rows]
    if not rows.hits:
        return [], search_rows_list
    loader = getattr(wmr, spec.load_method, None)
    if loader is None:
        return [], search_rows_list
    from dataclasses import replace

    total = max(len(rows.hits), 1)
    typed_hits: list[Any] = []
    for i, search_hit in enumerate(rows.hits):
        props = search_hit.node.properties or {}
        entity_id = props.get(spec.id_field)
        if not entity_id:
            continue
        try:
            loaded = loader(entity_id)
        except Exception:
            logger.debug(
                "by-id load failed for %s id=%s",
                spec.fathom_kind,
                entity_id,
                exc_info=True,
            )
            continue
        if loaded is None:
            continue
        typed_hits.append(replace(loaded, score=1.0 - (i / total)))
    return typed_hits, search_rows_list


def _log_retrieval_timings(
    query: str,
    timings_ms: dict[str, int],
    result_counts: dict[str, int],
    *,
    quality_counts: dict[str, int] | None = None,
) -> None:
    if quality_counts is not None:
        quality_str = (
            f"strict={quality_counts.get('strict', 0)} "
            f"relaxed={quality_counts.get('relaxed', 0)} "
            f"vector={quality_counts.get('vector', 0)} "
            f"fallback={quality_counts.get('fallback', 0)} "
            f"degraded={quality_counts.get('degraded', 0)}"
        )
        logger.info(
            "retrieval timings query=%r timings_ms=%s result_counts=%s quality=%s",
            query[:120],
            timings_ms,
            result_counts,
            quality_str,
        )
    else:
        logger.info(
            "retrieval timings query=%r timings_ms=%s result_counts=%s",
            query[:120],
            timings_ms,
            result_counts,
        )


@dataclass
class RetrievalResult:
    """Result of retrieve_for_context with canonical document tracking."""

    text: str = ""
    document_ids: set[str] = field(default_factory=set)


@dataclass(frozen=True)
class RetrievalSearchResult:
    document_id: str
    title: str
    snippet: str
    document_family: str
    source_url: str
    relevance_pct: int


@dataclass
class RetrievalCandidate:
    document_id: str
    item_id: str | None
    item: Any | None
    knowledge: Any | None
    document: RetrievalDocument
    score: float
    relevance: float
    reputation: float
    decay_weight: float
    canonical_backed: bool
    document_family: str = "knowledge"


def _canonical_candidate(
    *,
    document: RetrievalDocument,
    relevance: float,
    document_family: str,
    rank_config: RankConfig | None,
) -> RetrievalCandidate:
    return RetrievalCandidate(
        document_id=document.document_id,
        item_id=None,
        item=None,
        knowledge=None,
        document=document,
        score=rank_score(
            relevance=relevance,
            decay_weight=1.0,
            reputation=0.5,
            pinned=False,
            config=rank_config,
        ),
        relevance=relevance,
        reputation=0.5,
        decay_weight=1.0,
        canonical_backed=True,
        document_family=document_family,
    )


def _query_terms(query: str) -> list[str]:
    terms: list[str] = []
    seen: set[str] = set()
    for raw in query.lower().split():
        term = raw.strip(".,:;!?()[]{}<>\"'`")
        if len(term) < 2 or term in seen:
            continue
        seen.add(term)
        terms.append(term)
    return terms


def _world_model_query_signal(knowledge, query: str) -> float:
    if knowledge is None:
        return 0.0

    terms = _query_terms(query)
    if not terms:
        return 0.0

    payload = knowledge.payload or {}
    structured_haystacks: tuple[str, ...] = ()
    try:
        from memex.typed_knowledge import structured_knowledge_search_texts

        structured_haystacks = tuple(
            text.lower() for text in structured_knowledge_search_texts(payload)
        )
    except Exception:
        logger.debug("Structured typed-knowledge text extraction failed", exc_info=True)
    haystacks = (
        (knowledge.title or "").lower(),
        (knowledge.canonical_key or "").lower(),
        (knowledge.source_url or "").lower(),
        str(payload.get("summary_text") or "").lower(),
        str(payload.get("body_excerpt") or "").lower(),
    )
    score = 0.0
    max_score = float(len(terms) * 4)
    for term in terms:
        if term in haystacks[0]:
            score += 4.0
        elif term in haystacks[1] or term in haystacks[2]:
            score += 3.0
        elif term in haystacks[3] or term in haystacks[4]:
            score += 2.0
        elif any(term in text for text in structured_haystacks):
            score += 2.5

    if max_score <= 0:
        return 0.0
    return min(score / max_score, 1.0)


def _document_query_signal(document: RetrievalDocument, query: str) -> float:
    terms = _query_terms(query)
    if not terms:
        return 0.0

    haystacks = (
        document.title.lower(),
        document.source_url.lower(),
        document.body_text.lower(),
        tuple(line.lower() for line in document.world_model_context_lines),
    )
    score = 0.0
    max_score = float(len(terms) * 4)
    for term in terms:
        if term in haystacks[0]:
            score += 4.0
        elif term in haystacks[1]:
            score += 3.0
        elif term in haystacks[2]:
            score += 2.5
        elif any(term in line for line in haystacks[3]):
            score += 2.0

    if max_score <= 0:
        return 0.0
    return min(score / max_score, 1.0)


def _search_items_by_metadata(
    content_store: ContentStore,
    query: str,
    *,
    limit: int,
) -> list[tuple[Any, float]]:
    """Search items by title, source_url, and metadata fields."""
    terms = _query_terms(query)
    if not terms:
        return []
    items = content_store.list_items(limit=500)
    results: list[tuple[Any, float]] = []
    for item in items:
        url = (getattr(item, "source_url", "") or "").lower()
        title = (getattr(item, "title", "") or "").lower()
        score = 0.0
        for t in terms:
            if t in title:
                score += 4.0
            elif t in url:
                score += 2.0
        if score > 0:
            results.append((item, score / (len(terms) * 4)))
    results.sort(key=lambda t: t[1], reverse=True)
    return results[:limit]


def _safe_get_items_batch(
    content_store: ContentStore, item_ids: list[str]
) -> dict[str, Any]:
    if not item_ids:
        return {}
    try:
        return content_store.get_items_batch(item_ids)
    except Exception:
        logger.debug("Item batch lookup failed during retrieval", exc_info=True)
        return {}


def _search_meeting_promotion_audit_items(
    content_store: ContentStore,
    query: str,
    *,
    limit: int,
) -> list[tuple[Any, list[str], float]]:
    """Search content items with meeting canonical_promotion_audit metadata."""
    terms = _query_terms(query)
    if not terms:
        return []
    try:
        from memex.models import ItemType

        items = content_store.list_items(type=ItemType.MEETING, limit=200)
    except Exception:
        return []
    results: list[tuple[Any, list[str], float]] = []
    max_score = float(len(terms) * 4)
    for item in items:
        metadata = getattr(item, "metadata", None) or {}
        meeting = metadata.get("meeting") or {}
        semantic = meeting.get("semantic") or {}
        audit_entries = semantic.get("canonical_promotion_audit") or []
        if not audit_entries:
            continue
        import json

        haystack = json.dumps(audit_entries, default=str).lower()
        title_haystack = (item.title or "").lower()
        score = 0.0
        for term in terms:
            if term in title_haystack:
                score += 4.0
            elif term in haystack:
                score += 3.0
        if score <= 0:
            continue
        context_lines: list[str] = []
        for entry in audit_entries:
            if not isinstance(entry, dict):
                continue
            artifact_type = str(entry.get("artifact_type") or "")
            for rel in entry.get("relationships") or []:
                if not isinstance(rel, dict):
                    continue
                target_type = str(rel.get("target_record_type") or "")
                target_id = str(rel.get("target_record_id") or "")
                context_lines.append(
                    f"Canonical audit: {artifact_type} -> {target_type} {target_id}"
                )
        results.append(
            (item, context_lines, min(score / max_score, 1.0) if max_score > 0 else 0.0)
        )
    results.sort(key=lambda t: t[2], reverse=True)
    return results[:limit]


def _resolve_meeting_audit_document(
    item: Any, audit_lines: list[str], score: float
) -> RetrievalDocument:
    return RetrievalDocument(
        document_id=f"content_item:{item.item_id}",
        item_id=item.item_id,
        title=item.title,
        body_text=item.body or "(no content)",
        source_url=getattr(item, "source_url", "") or "",
        reputation_display="unrated",
        relevance_pct=int(min(score, 1.0) * 100),
        world_model_context_lines=tuple(audit_lines),
    )


def retrieve_for_context(
    query: str,
    max_tokens: int,
    *,
    content_store: ContentStore,
    world_model_store: WorldModelReadStore | None = None,
    rank_config: RankConfig | None = None,
    route_profile: PromptControlRouteProfile | str | None = None,
    now: datetime | None = None,
    max_items: int = 10,
    include_document_ids: bool = False,
) -> RetrievalResult:
    """Retrieve and format knowledge items for the system prompt.

    Pipeline:
    1. Legacy content-store FTS (``content_store.fts_search``) for the
       ``KnowledgeItem`` surface that has not yet migrated to fathomdb
       property FTS.
    2. World-model property-FTS via the ``_WM_SIMPLE_SPECS`` dispatch table
       plus custom helpers (``_search_canonical_action_hits``,
       ``_search_canonical_knowledge_hits``).
    3. Fetch items, compute decay, get reputation.
    4. Rank via ``rank_score()`` with typed boosts and pinned multiplier.
    5. Token budgeting.
    6. Touch accessed items.
    7. Format output.

    Returns ``RetrievalResult`` with formatted text and the IDs of items
    included.
    """
    if now is None:
        now = utcnow()

    scored_items = _retrieve_candidates(
        query=query,
        content_store=content_store,
        world_model_store=world_model_store,
        rank_config=rank_config,
        route_profile=route_profile,
        now=now,
        max_items=max_items,
    )
    if not scored_items:
        return RetrievalResult()

    # 6. Token budgeting — greedily fill in rank order
    parts: list[str] = []
    tokens_used = 0
    included_document_ids: set[str] = set()

    if scored_items:
        parts.append("## Retrieved Knowledge\n")
        tokens_used += len(parts[-1]) // 4

    for i, candidate in enumerate(scored_items, 1):
        item = candidate.item
        document = candidate.document
        body_text = document.body_text
        header = f"### [{i}] {document.title} (relevance: {document.relevance_pct}%)"

        entry_parts = [header]
        if include_document_ids:
            entry_parts.append(f"ID: {document.document_id}")
        if document.source_line:
            entry_parts.append(document.source_line)
        entry_parts.extend(document.world_model_context_lines)

        entry_overhead = sum(len(p) for p in entry_parts) // 4 + 2
        remaining_tokens = max_tokens - tokens_used - entry_overhead
        if remaining_tokens <= 0:
            break

        max_body_chars = remaining_tokens * 4
        if len(body_text) > max_body_chars:
            body_text = body_text[:max_body_chars] + "..."

        entry_parts.append(body_text)
        entry = "\n".join(entry_parts)

        tokens_used += len(entry) // 4 + 1
        if tokens_used > max_tokens:
            break

        parts.append(entry)
        included_document_ids.add(candidate.document_id)
        if item is not None:
            try:
                content_store.touch_item(item.item_id)
            except Exception:
                pass

    if not parts:
        return RetrievalResult()

    return RetrievalResult(
        text="\n\n".join(parts),
        document_ids=included_document_ids,
    )


def search_documents(
    query: str,
    *,
    content_store: ContentStore,
    world_model_store: WorldModelReadStore | None = None,
    rank_config: RankConfig | None = None,
    route_profile: PromptControlRouteProfile | str | None = None,
    now: datetime | None = None,
    max_items: int = 10,
) -> list[RetrievalSearchResult]:
    if now is None:
        now = utcnow()
    candidates = _retrieve_candidates(
        query=query,
        content_store=content_store,
        world_model_store=world_model_store,
        rank_config=rank_config,
        route_profile=route_profile,
        now=now,
        max_items=max_items,
    )
    return [
        RetrievalSearchResult(
            document_id=candidate.document_id,
            title=candidate.document.title,
            snippet=candidate.document.body_text[:200],
            document_family=candidate.document_family,
            source_url=candidate.document.source_url,
            relevance_pct=candidate.document.relevance_pct,
        )
        for candidate in candidates
    ]


def _retrieve_candidates(
    *,
    query: str,
    content_store: ContentStore,
    world_model_store: WorldModelReadStore | None,
    rank_config: RankConfig | None,
    route_profile: PromptControlRouteProfile | str | None,
    now: datetime,
    max_items: int,
) -> list[RetrievalCandidate]:
    retrieval_start = time.monotonic()
    timings_ms: dict[str, int] = {}
    result_counts: dict[str, int] = {}
    quality_counts: dict[str, int] = {
        "strict": 0,
        "relaxed": 0,
        "vector": 0,
        "fallback": 0,
        "degraded": 0,
    }

    def _accumulate_quality(search_rows_list: list[Any]) -> None:
        for rows in search_rows_list:
            quality_counts["strict"] += int(getattr(rows, "strict_hit_count", 0) or 0)
            quality_counts["relaxed"] += int(getattr(rows, "relaxed_hit_count", 0) or 0)
            quality_counts["vector"] += int(getattr(rows, "vector_hit_count", 0) or 0)
            if getattr(rows, "fallback_used", False):
                quality_counts["fallback"] += 1
            if getattr(rows, "was_degraded", False):
                quality_counts["degraded"] += 1

    world_model_reads = resolve_world_model_reads(
        content_store=content_store,
        world_model_store=world_model_store,
    )

    fts_results: list[tuple[str, float]] = []
    fts_items_map: dict[str, Any] = {}
    fts_start = time.monotonic()
    try:
        if hasattr(content_store, "fts_search_chunks"):
            fts_results = content_store.fts_search_chunks(query, limit=max_items * 2)
        if not fts_results:
            fts_raw = content_store.fts_search(query, limit=max_items * 2)
            fts_items_map = {item.item_id: item for item, _score in fts_raw}
            fts_results = [(item.item_id, score) for item, score in fts_raw]
        # Also try individual terms for partial matches — these go into
        # fts_items_map for loading but get a very low score so they don't
        # outrank canonical knowledge hits.
        terms = _query_terms(query)
        if len(terms) > 1:
            for term in terms:
                try:
                    term_raw = content_store.fts_search(term, limit=max_items)
                    for item, _score in term_raw:
                        if item.item_id not in fts_items_map:
                            fts_items_map[item.item_id] = item
                            fts_results.append((item.item_id, 0.01))
                except Exception:
                    pass
    except Exception:
        logger.debug("FTS search failed", exc_info=True)
    timings_ms["fts"] = int((time.monotonic() - fts_start) * 1000)
    result_counts["fts"] = len(fts_results)

    # Metadata fallback: search items by title and source_url
    metadata_start = time.monotonic()
    try:
        meta_items = _search_items_by_metadata(
            content_store, query, limit=max_items * 2
        )
        for item, score in meta_items:
            if item.item_id not in fts_items_map:
                fts_items_map[item.item_id] = item
                fts_results.append((item.item_id, score))
    except Exception:
        logger.debug("Metadata item search failed", exc_info=True)
        meta_items = []
    timings_ms["metadata"] = int((time.monotonic() - metadata_start) * 1000)
    result_counts["metadata"] = len(meta_items)

    # Reach into the world_model repository's underlying fathomdb engine so the
    # dispatch loops below can run engine.nodes(kind).search() directly — the
    # canonical pattern after the ``search_*_documents`` shim deletion.
    engine: Any = None
    if world_model_reads is not None:
        try:
            engine = world_model_reads._store._fathom.world_model._engine
        except Exception:
            logger.warning(
                "Unable to resolve world model engine; WM property-FTS disabled",
                exc_info=True,
            )
            engine = None

    knowledge_start = time.monotonic()
    canonical_knowledge_hits, knowledge_search_rows = _search_canonical_knowledge_hits(
        wmr=world_model_reads,
        engine=engine,
        query=query,
        limit=max_items * 2,
    )
    _accumulate_quality(knowledge_search_rows)
    timings_ms["wm:canonical_knowledge_hits"] = int(
        (time.monotonic() - knowledge_start) * 1000
    )
    result_counts["wm:canonical_knowledge_hits"] = len(canonical_knowledge_hits)

    # Canonical action hits: single property-FTS call covers both regular
    # outcome hits and meeting_semantic_promotion hits. Split by action_kind
    # immediately below. Replaces the old ``search_canonical_outcome_hits`` and
    # ``search_meeting_promotion_hits`` calls, which independently duplicated
    # the primary+secondary scan.
    action_start = time.monotonic()
    all_action_hits, action_search_rows = _search_canonical_action_hits(
        wmr=world_model_reads,
        engine=engine,
        query=query,
        limit=max(3, min(max_items, 5)),
    )
    _accumulate_quality(action_search_rows)
    canonical_outcome_hits = [
        h for h in all_action_hits if h.action_kind != "meeting_semantic_promotion"
    ]
    meeting_promotion_hits = [
        h for h in all_action_hits if h.action_kind == "meeting_semantic_promotion"
    ]
    timings_ms["wm:canonical_action_hits"] = int(
        (time.monotonic() - action_start) * 1000
    )
    result_counts["wm:canonical_outcome_hits"] = len(canonical_outcome_hits)
    result_counts["wm:meeting_promotion_hits"] = len(meeting_promotion_hits)
    # Run the 10 "simple" world-model kinds through a single dispatch loop
    # over ``_WM_SIMPLE_SPECS``. Each entry drives one
    # ``engine.nodes(kind).search() + load_*_document(id)`` round trip; the
    # resulting typed hits become ``_canonical_candidate`` rows in the
    # materialize loop further down.
    simple_hits: dict[str, list[Any]] = {}
    for spec in _WM_SIMPLE_SPECS:
        spec_start = time.monotonic()
        typed_hits, typed_search_rows = _search_and_load_typed_hits(
            wmr=world_model_reads,
            engine=engine,
            spec=spec,
            query=query,
            limit=max_items * 2,
        )
        simple_hits[spec.document_family] = typed_hits
        _accumulate_quality(typed_search_rows)
        key = f"wm:{spec.document_family}"
        timings_ms[key] = int((time.monotonic() - spec_start) * 1000)
        result_counts[key] = len(simple_hits[spec.document_family])
    # Dependency search runs through property FTS on WMProvenanceLink
    # (m005 + write-path title denormalization). Custom call site because
    # the relationship whitelist is a Python-side post-filter — see
    # dev/notes/wm-provenance-link-denormalization.md.
    dependency_start = time.monotonic()
    if world_model_reads is not None:
        canonical_dependency_hits = world_model_reads.search_dependency_documents(
            query, limit=max_items * 2
        )
    else:
        canonical_dependency_hits = []
    timings_ms["wm:canonical_dependency_hits"] = int(
        (time.monotonic() - dependency_start) * 1000
    )
    result_counts["wm:canonical_dependency_hits"] = len(canonical_dependency_hits)
    meeting_audit_start = time.monotonic()
    meeting_audit_items = _search_meeting_promotion_audit_items(
        content_store, query, limit=max(3, min(max_items, 5))
    )
    timings_ms["meeting_audit_items"] = int(
        (time.monotonic() - meeting_audit_start) * 1000
    )
    result_counts["meeting_audit_items"] = len(meeting_audit_items)
    any_simple_hits = any(simple_hits.values())
    if (
        not fts_results
        and not canonical_knowledge_hits
        and not any_simple_hits
        and not canonical_outcome_hits
        and not meeting_promotion_hits
        and not canonical_dependency_hits
        and not meeting_audit_items
    ):
        timings_ms["total"] = int((time.monotonic() - retrieval_start) * 1000)
        _log_retrieval_timings(
            query, timings_ms, result_counts, quality_counts=quality_counts
        )
        return []

    timings_ms["total"] = int((time.monotonic() - retrieval_start) * 1000)
    _log_retrieval_timings(
        query, timings_ms, result_counts, quality_counts=quality_counts
    )

    # FTS-only scoring for the legacy content-store path. Semantic blend is
    # gone (see comment above); the "dual" merge degenerates to BM25
    # normalization.
    max_bm25 = max((score for _, score in fts_results), default=0.0)
    fts_score_map = {
        item_id: normalize_bm25(score, max_bm25=max_bm25)
        for item_id, score in fts_results
    }
    item_score_map = dict(fts_score_map)
    canonical_knowledge_map = {
        hit.knowledge.item_id: hit.knowledge for hit in canonical_knowledge_hits
    }
    wm_score_map = {
        hit.knowledge.item_id: hit.score for hit in canonical_knowledge_hits
    }
    wm_relationship_map = {
        hit.knowledge.item_id: hit.relationships for hit in canonical_knowledge_hits
    }

    canonical_candidate_ids: list[str] = []
    seen_candidate_ids: set[str] = set()
    for hit in canonical_knowledge_hits:
        item_id = hit.knowledge.item_id
        if item_id in seen_candidate_ids:
            continue
        seen_candidate_ids.add(item_id)
        canonical_candidate_ids.append(item_id)
    legacy_candidate_ids = [
        item_id for item_id, _score in fts_results if item_id not in seen_candidate_ids
    ]

    missing_knowledge_ids = [
        item_id
        for item_id in legacy_candidate_ids
        if item_id not in canonical_knowledge_map
    ]
    loaded_knowledge_map = (
        world_model_reads.load_knowledge_map(missing_knowledge_ids)
        if world_model_reads is not None and missing_knowledge_ids
        else {}
    )
    knowledge_map = {**loaded_knowledge_map, **canonical_knowledge_map}
    canonical_items_map = {
        **_safe_get_items_batch(content_store, canonical_candidate_ids),
        **{
            item_id: item
            for item_id, item in fts_items_map.items()
            if item_id in canonical_candidate_ids
        },
    }

    scored_items: list[RetrievalCandidate] = []
    for hit in canonical_knowledge_hits:
        item_id = hit.knowledge.item_id
        knowledge = hit.knowledge
        item = canonical_items_map.get(item_id)
        if item is not None and is_expired(item, now):
            continue
        decay = item_decay_weight(item, now) if item is not None else 1.0
        reputation = 0.5
        rep_confidence = 0.0
        if item is not None and item.source_id:
            reputation = content_store.get_reputation_factor(item.source_id)
            source = content_store.get_source(item.source_id)
            if source:
                rep_confidence = source.confidence
        rep_display = reputation_display(reputation, rep_confidence)
        item_signal = item_score_map.get(item_id, 0.0)
        knowledge_signal = hit.score
        document = resolve_retrieval_document(
            item_id=item_id,
            item=item,
            knowledge=knowledge,
            knowledge_relationships=hit.relationships,
            relevance=max(item_signal, knowledge_signal),
            route_profile=route_profile,
            reputation_display=rep_display,
        )
        typed_signal = _world_model_query_signal(knowledge, query)
        document_signal = _document_query_signal(document, query)
        typed_boost = route_profile_world_model_boost(
            knowledge_type=knowledge.knowledge_type if knowledge is not None else "",
            semantic_kind=knowledge_semantic_kind(knowledge),
            route_profile=route_profile,
            has_source_url=bool(knowledge.source_url)
            if knowledge is not None
            else False,
        )
        lexical_support = fts_score_map.get(item_id, 0.0)
        base_relevance = max(knowledge_signal, document_signal, typed_signal)
        if base_relevance <= 0:
            continue
        effective_relevance = min(
            1.5, base_relevance + (lexical_support * 0.15) + typed_boost
        )
        scored_items.append(
            RetrievalCandidate(
                document_id=document.document_id,
                item_id=document.item_id,
                item=item,
                knowledge=knowledge,
                document=document,
                score=rank_score(
                    relevance=effective_relevance,
                    decay_weight=decay,
                    reputation=reputation,
                    pinned=item.pinned if item is not None else False,
                    config=rank_config,
                ),
                relevance=effective_relevance,
                reputation=reputation,
                decay_weight=decay,
                canonical_backed=True,
                document_family="knowledge",
            )
        )

    legacy_items_map = {
        **_safe_get_items_batch(content_store, legacy_candidate_ids),
        **{
            item_id: item
            for item_id, item in fts_items_map.items()
            if item_id in legacy_candidate_ids
        },
    }
    for item_id in legacy_candidate_ids:
        item = legacy_items_map.get(item_id)
        knowledge = knowledge_map.get(item_id)
        if item is None and knowledge is None:
            continue
        if item is not None and is_expired(item, now):
            continue
        decay = item_decay_weight(item, now) if item is not None else 1.0
        reputation = 0.5
        rep_confidence = 0.0
        if item is not None and item.source_id:
            reputation = content_store.get_reputation_factor(item.source_id)
            source = content_store.get_source(item.source_id)
            if source:
                rep_confidence = source.confidence
        rep_display = reputation_display(reputation, rep_confidence)
        item_signal = item_score_map.get(item_id, 0.0)
        knowledge_signal = wm_score_map.get(item_id, 0.0)
        document = resolve_retrieval_document(
            item_id=item_id,
            item=item,
            knowledge=knowledge,
            knowledge_relationships=wm_relationship_map.get(item_id, []),
            relevance=max(item_signal, knowledge_signal),
            route_profile=route_profile,
            reputation_display=rep_display,
        )
        typed_signal = _world_model_query_signal(knowledge, query)
        document_signal = _document_query_signal(document, query)
        typed_boost = route_profile_world_model_boost(
            knowledge_type=knowledge.knowledge_type if knowledge is not None else "",
            semantic_kind=knowledge_semantic_kind(knowledge),
            route_profile=route_profile,
            has_source_url=bool(knowledge.source_url)
            if knowledge is not None
            else False,
        )
        if knowledge is not None:
            lexical_support = fts_score_map.get(item_id, 0.0)
            base_relevance = max(knowledge_signal, document_signal, typed_signal)
            if base_relevance <= 0:
                continue
            effective_relevance = min(
                1.5, base_relevance + (lexical_support * 0.15) + typed_boost
            )
        else:
            effective_relevance = max(item_signal, document_signal)
            if effective_relevance <= 0:
                continue
            # Discount items that only match a fraction of query terms
            terms = _query_terms(query)
            if len(terms) > 1 and item is not None:
                item_text = (
                    f"{item.title} {item.body}"
                    if hasattr(item, "body")
                    else str(item.title)
                ).lower()
                matched = sum(1 for t in terms if t in item_text)
                coverage = matched / len(terms)
                effective_relevance *= max(coverage, 0.1)
        scored_items.append(
            RetrievalCandidate(
                document_id=document.document_id,
                item_id=document.item_id,
                item=item,
                knowledge=knowledge,
                document=document,
                score=rank_score(
                    relevance=effective_relevance,
                    decay_weight=decay,
                    reputation=reputation,
                    pinned=item.pinned if item is not None else False,
                    config=rank_config,
                ),
                relevance=effective_relevance,
                reputation=reputation,
                decay_weight=decay,
                canonical_backed=knowledge is not None,
                document_family="knowledge",
            )
        )

    canonical_action_hits: list[CanonicalOutcomeHit] = []
    seen_action_ids: set[str] = set()
    for hit in [*canonical_outcome_hits, *meeting_promotion_hits]:
        if hit.action_id in seen_action_ids:
            continue
        seen_action_ids.add(hit.action_id)
        canonical_action_hits.append(hit)
    for hit in canonical_action_hits:
        document = resolve_world_model_action_document(hit, route_profile=route_profile)
        scored_items.append(
            _canonical_candidate(
                document=document,
                relevance=hit.score,
                document_family="canonical_outcome",
                rank_config=rank_config,
            )
        )

    # Dispatch-driven fan-out for the 10 "simple" world-model kinds. Each spec
    # in _WM_SIMPLE_SPECS maps (fathom_kind → id_field → load_method →
    # resolver); see _WMSimpleSearchSpec docstring for the boundary with the
    # custom-handled kinds (WMKnowledgeObject, WMAction, WMDependency).
    for spec in _WM_SIMPLE_SPECS:
        for hit in simple_hits.get(spec.document_family, ()):
            scored_items.append(
                _canonical_candidate(
                    document=spec.resolver(hit),
                    relevance=hit.score,
                    document_family=spec.document_family,
                    rank_config=rank_config,
                )
            )

    # WMDependency (special case): Python-side scan over provenance links.
    for hit in canonical_dependency_hits:
        scored_items.append(
            _canonical_candidate(
                document=resolve_world_model_dependency_document(hit),
                relevance=hit.score,
                document_family="dependency",
                rank_config=rank_config,
            )
        )

    for item, audit_lines, score in meeting_audit_items:
        document = _resolve_meeting_audit_document(item, audit_lines, score)
        scored_items.append(
            _canonical_candidate(
                document=document,
                relevance=score,
                document_family="meeting_audit",
                rank_config=rank_config,
            )
        )

    _apply_outcome_lead_sort(scored_items)
    return scored_items[:max_items]
