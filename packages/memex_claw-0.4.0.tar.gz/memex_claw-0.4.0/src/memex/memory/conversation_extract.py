"""Conversational knowledge extraction — combined extraction + reflection.

Single LLM call extracts domain facts, entities, relationships, decisions,
URLs, and corrections from conversation turns, while also performing the
existing reflection (goal updates, preferences, constraints).

Extraction context (entities, signals from the gate) improves reflection
quality by providing structured evidence.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pydantic import BaseModel, Field

from memex.models import (
    ItemType,
    GoalBlock,
    GoalFail,
    InputClassification,
    NewSubgoal,
    ObservedConstraint,
    ObservedPreference,
    ObservedRejection,
    ObservedRetrievalFeedback,
    ReflectResult,
    SessionContext,
)
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Extraction data models
# ---------------------------------------------------------------------------


class ExtractedFact(BaseModel):
    statement: str
    confidence: float = 0.5
    source: str = "both"  # "user", "assistant", "both"


class ExtractedEntity(BaseModel):
    name: str
    type: str = "concept"  # person, technology, organization, concept, place, event
    context: str = ""
    attributes: dict[str, str] = Field(default_factory=dict)


class ExtractedRelationship(BaseModel):
    subject: str
    predicate: str
    object: str
    context: str = ""


class ExtractedDecision(BaseModel):
    decision: str
    rationale: str = ""
    rejected: list[str] = Field(default_factory=list)


class ExtractedCorrection(BaseModel):
    original: str
    corrected: str
    context: str = ""


class ExtractionResult(BaseModel):
    facts: list[ExtractedFact] = Field(default_factory=list)
    entities: list[ExtractedEntity] = Field(default_factory=list)
    relationships: list[ExtractedRelationship] = Field(default_factory=list)
    decisions: list[ExtractedDecision] = Field(default_factory=list)
    urls: list[str] = Field(default_factory=list)
    corrections: list[ExtractedCorrection] = Field(default_factory=list)


class CombinedExtractReflectResult(BaseModel):
    """Flat model for single-schema chat_structured constraint.

    Contains both extraction fields and reflection fields.
    Methods convert to the individual result types.
    """

    # --- Extraction fields ---
    facts: list[ExtractedFact] = Field(default_factory=list)
    entities: list[ExtractedEntity] = Field(default_factory=list)
    relationships: list[ExtractedRelationship] = Field(default_factory=list)
    decisions: list[ExtractedDecision] = Field(default_factory=list)
    urls: list[str] = Field(default_factory=list)
    corrections: list[ExtractedCorrection] = Field(default_factory=list)

    # --- Reflection fields (mirrors ReflectResult) ---
    intent_advanced: list[str] = Field(default_factory=list)
    new_subgoals: list[NewSubgoal] = Field(default_factory=list)
    goals_to_complete: list[str] = Field(default_factory=list)
    goals_to_pause: list[str] = Field(default_factory=list)
    goals_to_block: list[GoalBlock] = Field(default_factory=list)
    goals_to_fail: list[GoalFail] = Field(default_factory=list)
    confidence: float = 0.0
    reflection_note: str = ""
    session_context_update: dict[str, Any] = Field(default_factory=dict)
    observed_preferences: list[ObservedPreference] = Field(default_factory=list)
    observed_constraints: list[ObservedConstraint] = Field(default_factory=list)
    rejected_approaches: list[ObservedRejection] = Field(default_factory=list)
    retrieval_feedback: list[ObservedRetrievalFeedback] = Field(default_factory=list)
    insight: str = ""
    topic_shift: str = ""

    def to_reflect_result(self) -> ReflectResult:
        return ReflectResult(
            intent_advanced=self.intent_advanced,
            new_subgoals=self.new_subgoals,
            goals_to_complete=self.goals_to_complete,
            goals_to_pause=self.goals_to_pause,
            goals_to_block=self.goals_to_block,
            goals_to_fail=self.goals_to_fail,
            confidence=self.confidence,
            reflection_note=self.reflection_note,
            session_context_update=self.session_context_update,
            observed_preferences=self.observed_preferences,
            observed_constraints=self.observed_constraints,
            rejected_approaches=self.rejected_approaches,
            retrieval_feedback=self.retrieval_feedback,
            insight=self.insight,
            topic_shift=self.topic_shift,
        )

    def to_extraction_result(self) -> ExtractionResult:
        return ExtractionResult(
            facts=self.facts,
            entities=self.entities,
            relationships=self.relationships,
            decisions=self.decisions,
            urls=self.urls,
            corrections=self.corrections,
        )


# ---------------------------------------------------------------------------
# Combined system prompt
# ---------------------------------------------------------------------------

_COMBINED_SYSTEM_PROMPT = """\
You are the reflection and extraction module for Memex, a personal AI assistant.
After each conversation turn, you perform two tasks:

## Task 1: Knowledge Extraction
Extract structured knowledge from the conversation:
- **facts**: Factual statements with confidence (0.0-1.0) and source ("user", "assistant", "both")
- **entities**: Named entities (people, technologies, organizations, concepts, places, events) with context
- **relationships**: Subject-predicate-object triples (e.g. "Sarah manages auth-service")
- **decisions**: Decisions made, with rationale and rejected alternatives
- **urls**: Any URLs mentioned in the conversation
- **corrections**: When something was corrected (original → corrected)

Only extract when clearly stated. Set confidence appropriately. Skip trivial greetings.

## Task 2: Reflection (Goal Tracking)
Analyze what happened and determine:
1. Which goals were advanced (list their IDs)
2. Whether new sub-goals should be created
3. Whether any goals should be marked completed, paused, blocked, or failed
4. Any updates to session working memory
5. User preferences, constraints, rejected approaches observed
6. Insights and topic shifts

Be precise. Only list goals that were actually discussed or advanced.
Keep reflection_note to one sentence.

Respond with JSON matching the schema.
"""


# ---------------------------------------------------------------------------
# extract_and_reflect
# ---------------------------------------------------------------------------


def extract_and_reflect(
    *,
    classification: InputClassification,
    assistant_response: str,
    relevant_goals: list,
    session: SessionContext,
    signals: set[str] | None = None,
    entities: list[tuple[str, str]] | None = None,
    model: str | None = None,
) -> CombinedExtractReflectResult:
    """Run combined extraction + reflection in a single LLM call.

    Falls back to no-op on failure (empty extraction + fallback reflection).
    """
    from memex.llm import _get_cheap_model, chat_structured

    messages: list[dict[str, str]] = [
        {"role": "system", "content": _COMBINED_SYSTEM_PROMPT},
    ]

    # Build context (mirrors reflect.py)
    context_parts: list[str] = []

    context_parts.append(f"Classification: {classification.classification.value}")
    if classification.goal_id:
        context_parts.append(f"Classified goal: {classification.goal_id}")

    if relevant_goals:
        goal_lines = [
            f"- [{g.goal_id[:8]}] {g.title} (status={g.status.value}, priority={g.priority.value})"
            for g in relevant_goals
        ]
        context_parts.append("Relevant goals:\n" + "\n".join(goal_lines))

    if session.active_task_context:
        context_parts.append(f"Active task: {session.active_task_context}")

    # Last human message + assistant response
    last_human = ""
    if session.conversation_history:
        for turn in reversed(session.conversation_history):
            if turn.role == "human":
                last_human = turn.content[:500]
                break

    context_parts.append(f"Human said: {last_human}")
    context_parts.append(f"Assistant responded: {assistant_response[:500]}")

    # Include gate signals for extraction context
    if signals:
        context_parts.append(f"Detected signals: {', '.join(sorted(signals))}")
    if entities:
        entity_strs = [f"{name} ({etype})" for name, etype in entities]
        context_parts.append(f"Detected entities: {', '.join(entity_strs)}")

    messages.append({"role": "user", "content": "\n\n".join(context_parts)})

    try:
        result = chat_structured(
            messages,
            CombinedExtractReflectResult,
            model=model or _get_cheap_model(),
        )
        logger.info(
            "extract_and_reflect: facts=%d, entities=%d, decisions=%d, advanced=%s — %s",
            len(result.facts),
            len(result.entities),
            len(result.decisions),
            result.intent_advanced,
            result.reflection_note,
        )
        return result
    except Exception:
        logger.warning(
            "Combined extraction+reflection failed, returning no-op", exc_info=True
        )
        return CombinedExtractReflectResult(
            reflection_note="extraction+reflection failed — no-op",
        )


# ---------------------------------------------------------------------------
# apply_extraction — persist extracted knowledge
# ---------------------------------------------------------------------------

_FIRST_PERSON_RE = re.compile(r"\b(I|I'm|I've|my|we|our)\b", re.IGNORECASE)


def apply_extraction(
    result: ExtractionResult,
    content_store,
    session: SessionContext,
    *,
    memex_store=None,
    fact_store=None,
) -> None:
    """Persist extracted knowledge to the content store.

    Storage mapping:
    - Facts (confidence >= 0.7) → FactStore.add_fact() if available, else ingest()
    - Entities → resolve_entity()
    - Relationships → graph MERGE
    - Decisions → ingest() as NOTE with decision tags
    - URLs → ingest_from_url() (background, failures logged)
    - Corrections → fts_search → create_version_snapshot → update_item
    """
    turn_num = session.turn_count
    session_id = session.session_id

    from memex.memory.intake import ingest, ingest_from_url
    from memex.memory.ner import resolve_entity

    # --- Facts ---
    for fact in result.facts:
        if fact.confidence < 0.7:
            continue
        try:
            if fact_store is not None:
                # Route through FactStore for write-time dedup
                provenance = {
                    "session_id": session_id,
                    "turn": turn_num,
                    "timestamp": utcnow().isoformat(),
                }
                fact_store.add_fact(
                    fact.statement,
                    provenance=provenance,
                    confidence=fact.confidence,
                )
            else:
                # Legacy path: direct ingest
                source_url = f"conversation://{session_id}/{turn_num}"
                existing = content_store.find_by_url(source_url)
                if existing:
                    continue
                ingest(
                    fact.statement,
                    type=ItemType.NOTE,
                    title=fact.statement[:100],
                    source_url=source_url,
                    tags=["conversational", "fact"],
                    content_store=content_store,
                    memex_store=memex_store,
                    generate_summary=False,
                )
        except Exception:
            logger.debug("Failed to store fact: %s", fact.statement[:50], exc_info=True)

    # --- Entities ---
    if hasattr(content_store, "find_entity"):
        for entity in result.entities:
            try:
                resolve_entity(entity.name, entity.type, content_store)
            except Exception:
                logger.debug("Failed to resolve entity: %s", entity.name, exc_info=True)

    # --- Relationships ---
    if hasattr(content_store, "_proxy"):
        for rel in result.relationships:
            try:
                content_store._proxy.execute_sync(
                    """MERGE (s:Entity {name: $subject})
                       MERGE (o:Entity {name: $object})
                       MERGE (s)-[r:RELATES {predicate: $predicate}]->(o)
                       SET r.context = $context""",
                    parameters={
                        "subject": rel.subject,
                        "object": rel.object,
                        "predicate": rel.predicate,
                        "context": rel.context,
                    },
                )
            except Exception:
                logger.debug(
                    "Failed to store relationship: %s %s %s",
                    rel.subject,
                    rel.predicate,
                    rel.object,
                    exc_info=True,
                )

    # --- Decisions ---
    for decision in result.decisions:
        source_url = f"conversation://{session_id}/{turn_num}/decision"
        try:
            existing = content_store.find_by_url(source_url)
            if existing:
                continue
            body = decision.decision
            if decision.rationale:
                body += f"\n\nRationale: {decision.rationale}"
            if decision.rejected:
                body += f"\n\nRejected: {', '.join(decision.rejected)}"
            ingest(
                body,
                type=ItemType.NOTE,
                title=decision.decision[:100],
                source_url=source_url,
                tags=["conversational", "decision"],
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "claim",
                        "statement": decision.decision,
                        "claim_kind": "decision",
                        "rationale": decision.rationale,
                        "rejected": list(decision.rejected),
                    }
                },
                content_store=content_store,
                memex_store=memex_store,
                generate_summary=False,
            )
        except Exception:
            logger.debug(
                "Failed to store decision: %s", decision.decision[:50], exc_info=True
            )

    # --- URLs ---
    for url in result.urls:
        try:
            ingest_from_url(
                url,
                tags=["conversational", "auto-ingested"],
                content_store=content_store,
                memex_store=memex_store,
            )
        except Exception:
            logger.debug("Failed to ingest URL: %s", url, exc_info=True)

    # --- Corrections ---
    for correction in result.corrections:
        try:
            matches = content_store.fts_search(correction.original, limit=3)
            for item, _score in matches:
                content_store.create_version_snapshot(item)
                item.body = item.body.replace(correction.original, correction.corrected)
                metadata = dict(getattr(item, "metadata", {}) or {})
                correction_entry = {
                    "original": correction.original,
                    "corrected": correction.corrected,
                    "context": correction.context,
                    "session_id": session_id,
                    "turn": turn_num,
                }
                corrections_meta = list(metadata.get("corrections") or [])
                corrections_meta.append(correction_entry)
                metadata["corrections"] = corrections_meta[-10:]
                typed_meta = metadata.get("typed_knowledge")
                if not isinstance(typed_meta, dict):
                    typed_meta = {}
                typed_corrections = list(typed_meta.get("corrections") or [])
                typed_corrections.append(correction_entry)
                typed_meta["corrections"] = typed_corrections[-10:]
                metadata["typed_knowledge"] = typed_meta
                item.metadata = metadata
                tags = list(getattr(item, "tags", []) or [])
                if "corrected" not in tags:
                    tags.append("corrected")
                item.tags = tags
                content_store.update_item(item)
                if memex_store is not None:
                    try:
                        from memex.typed_knowledge import sync_item_projection_if_needed

                        sync_item_projection_if_needed(memex_store, content_store, item)
                    except Exception:
                        logger.debug(
                            "Failed to resync typed knowledge after correction",
                            exc_info=True,
                        )
                break  # only update first match
        except Exception:
            logger.debug(
                "Failed to apply correction: %s",
                correction.original[:50],
                exc_info=True,
            )

    # --- Person model update ---
    try:
        update_partner_profile_from_extraction(result, memex_store)
    except Exception:
        logger.debug("Person model update failed", exc_info=True)


# ---------------------------------------------------------------------------
# Person model enrichment (Phase 4)
# ---------------------------------------------------------------------------

_ROLE_PATTERNS = re.compile(
    r"(?:I'm|I am|I work as)\s+(?:a\s+|the\s+)?(.+?)(?:\s+(?:on|for|at|in)\b|$)",
    re.IGNORECASE,
)

_TEAM_PATTERNS = re.compile(
    r"(?:our|my|the)\s+(\w[\w\s]*?)\s+team",
    re.IGNORECASE,
)

_EXPERTISE_PATTERNS = re.compile(
    r"(?:I(?:'ve| have) been (?:writing|using|working with)|I know|I'm experienced (?:in|with))\s+(\w[\w\s+#.]*?)(?:\s+for\b|\s+and\b|$)",
    re.IGNORECASE,
)


def update_partner_profile_from_extraction(
    extraction: ExtractionResult,
    store,
) -> None:
    """Update canonical partner-profile fields from extracted first-person facts.

    Only processes facts with source in ("user", "both") that contain
    first-person language. Third-party facts are skipped.
    """
    if store is None:
        return

    from memex.human_model import load_canonical_partner_profile, save_partner_profile

    profile = load_canonical_partner_profile(store)
    changed = False

    for fact in extraction.facts:
        if fact.source not in ("user", "both"):
            continue
        if not _FIRST_PERSON_RE.search(fact.statement):
            continue

        # Role detection
        role_match = _ROLE_PATTERNS.search(fact.statement)
        if role_match and not profile.working_context.role:
            profile.working_context.role = role_match.group(1).strip()
            changed = True

        # Team detection
        team_match = _TEAM_PATTERNS.search(fact.statement)
        if team_match and not profile.working_context.team:
            profile.working_context.team = team_match.group(1).strip()
            changed = True

        # Expertise detection
        exp_match = _EXPERTISE_PATTERNS.search(fact.statement)
        if exp_match:
            skill = exp_match.group(1).strip()
            if skill and skill.lower() not in {
                e.lower() for e in profile.knowledge_profile.expertise
            }:
                profile.knowledge_profile.expertise.append(skill)
                changed = True

    if changed:
        save_partner_profile(profile, store)
