"""Conversation search stubs.

These functions previously operated on raw sqlite3 connections.
They are no-ops until ported to FathomDB.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def sanitize_fts_query(query: str) -> str:
    return query


def search_conversations_hybrid(
    query: str,
    conn: Any,
    *,
    embedding_backend: Any = None,
    limit: int = 20,
    since: Any = None,
) -> list[dict[str, Any]]:
    logger.debug("search_conversations_hybrid: no-op (pending fathomdb port)")
    return []


def embed_conversation_turn(
    conn: Any,
    *,
    row_id: int,
    search_text: str,
    embedding_backend: Any = None,
) -> None:
    logger.debug("embed_conversation_turn: no-op (pending fathomdb port)")


def build_search_text(role: str, content: str, **kwargs: Any) -> str:
    return f"{role}: {content}"


def enrich_conversation_log_batch(
    conn: Any,
    *,
    embedding_backend: Any = None,
    limit: int = 100,
) -> dict[str, int]:
    logger.debug("enrich_conversation_log_batch: no-op (pending fathomdb port)")
    return {"enriched": 0, "embedded": 0}
