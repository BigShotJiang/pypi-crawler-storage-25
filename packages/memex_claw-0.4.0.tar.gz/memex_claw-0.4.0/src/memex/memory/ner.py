"""Hybrid NER: spaCy (fast, local) + LLM (accurate, selective)."""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

# spaCy label → Entity.type mapping
_SPACY_TYPE_MAP = {
    "PERSON": "person",
    "ORG": "organization",
    "PRODUCT": "technology",
    "WORK_OF_ART": "technology",
    "GPE": "place",
    "LOC": "place",
    "EVENT": "event",
}

_NER_PROMPT = """\
Extract entities from the following text. For each entity return:
- name: canonical name (e.g. "Python" not "python programming language")
- type: one of person, technology, organization, concept, place, event
- context: the sentence fragment where this entity appears

Return JSON array. Extract only meaningful entities, not common words.

Text:
{text}
"""

_nlp = None


def _get_nlp():
    """Lazy-load spaCy model."""
    global _nlp
    if _nlp is None:
        import os

        import spacy

        model_name = os.environ.get("MEMEX_NER_SPACY_MODEL", "en_core_web_sm")
        _nlp = spacy.load(model_name)
    return _nlp


def extract_entities_fast(text: str) -> list[tuple[str, str]]:
    """Tier 1: spaCy NER. Returns [(name, type), ...]."""
    try:
        nlp = _get_nlp()
    except Exception:
        logger.debug("spaCy not available for NER", exc_info=True)
        return []

    doc = nlp(text[:10000])  # Limit to avoid OOM
    seen: set[tuple[str, str]] = set()
    entities: list[tuple[str, str]] = []
    for ent in doc.ents:
        name = ent.text.strip()
        if not name or len(name) < 2:
            continue
        entity_type = _SPACY_TYPE_MAP.get(ent.label_, "concept")
        key = (name.lower(), entity_type)
        if key not in seen:
            seen.add(key)
            entities.append((name, entity_type))
    return entities


def extract_entities_deep(text: str) -> list[dict]:
    """Tier 2: LLM-based extraction. Returns [{name, type, context}, ...]."""
    try:
        from memex.llm import _get_cheap_model, chat

        prompt = _NER_PROMPT.format(text=text[:4000])
        messages = [{"role": "user", "content": prompt}]
        result = chat(messages, model=_get_cheap_model(), max_tokens=1024)

        # Parse JSON from response
        result = result.strip()
        if result.startswith("```"):
            result = result.split("\n", 1)[1].rsplit("```", 1)[0]
        entities = json.loads(result)
        if not isinstance(entities, list):
            return []
        return entities
    except Exception:
        logger.debug("LLM entity extraction failed", exc_info=True)
        return []


def extract_entities(text: str, *, deep: bool = False) -> list[tuple[str, str, str]]:
    """Extract entities using hybrid approach.

    Returns [(name, type, context), ...].
    Tier 2 results are authoritative when both tiers run.
    """
    # Tier 1: always run spaCy
    fast_entities = extract_entities_fast(text)

    if not deep:
        return [(name, etype, "") for name, etype in fast_entities]

    # Tier 2: LLM extraction
    deep_entities = extract_entities_deep(text)

    # Merge: LLM results take precedence
    seen: set[str] = set()
    merged: list[tuple[str, str, str]] = []

    for ent in deep_entities:
        name = ent.get("name", "").strip()
        etype = ent.get("type", "concept")
        context = ent.get("context", "")
        if not name:
            continue
        key = name.lower()
        if key not in seen:
            seen.add(key)
            merged.append((name, etype, context))

    # Add spaCy results that don't conflict
    for name, etype in fast_entities:
        key = name.lower()
        if key not in seen:
            seen.add(key)
            merged.append((name, etype, ""))

    return merged


def resolve_entity(name: str, entity_type: str, store: Any) -> str:
    """Find or create entity with dedup by normalized name + fuzzy match.

    Returns entity ID.
    """
    # Exact match first
    existing = store.find_entity(name, entity_type)
    if existing:
        return existing

    # Fuzzy match: check existing entities of same type
    # (Levenshtein ≤ 2 for short names, ≤ 3 for long)
    # Simplified: just create new for now, can enhance later
    return store.create_entity(name, entity_type)


def should_deep_extract(item_type: str, body_length: int) -> bool:
    """Determine if Tier 2 extraction should run."""
    if item_type in ("article", "meeting"):
        return True
    if item_type == "note" and body_length > 500:
        return True
    return False
