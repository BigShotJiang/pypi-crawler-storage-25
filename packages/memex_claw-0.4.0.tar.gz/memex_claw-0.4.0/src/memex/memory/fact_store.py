"""Fact store with write-time deduplication and memory block rendering.

Mem0-style discrete facts: extract, deduplicate at write time via cosine
similarity + negation detection, render compact memory block.

Hard constraints:
- FactStore must preserve provenance list in item metadata — never overwrite
- Write-time dedup: cosine > 0.85 THEN negation regex; prefer false negatives
"""

from __future__ import annotations

import logging
import re
import struct
import uuid
from typing import TYPE_CHECKING, Any
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.memory.protocols import ContentStoreProtocol, EmbeddingBackendProtocol

from memex.models import Item, ItemType, Summary

logger = logging.getLogger(__name__)

# Tags used to identify fact items in the content store
FACT_TAGS = ["fact", "memory-block"]

# Cosine similarity threshold for dedup (prefer false negatives over false positives)
DEDUP_THRESHOLD = 0.85

# Negation pattern — detects polarity reversal
_NEGATION_RE = re.compile(
    r"\b(not|no longer|stopped|quit|never|don't|doesn't|didn't|won't|isn't|aren't|wasn't|weren't|haven't|hasn't|hadn't)\b",
    re.IGNORECASE,
)


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _floats_to_bytes(floats: list[float]) -> bytes:
    return struct.pack(f"{len(floats)}f", *floats)


def _bytes_to_floats(data: bytes) -> list[float]:
    count = len(data) // 4
    return list(struct.unpack(f"{count}f", data))


class FactStore:
    """Manages discrete facts with write-time deduplication.

    Wraps a ContentStore + EmbeddingBackend to provide:
    - add_fact(): two-step dedup (cosine gate → negation check)
    - get_all_facts(): retrieve all fact items
    - render_memory_block(): compact text for system prompt injection
    """

    def __init__(
        self,
        content_store: ContentStoreProtocol,
        embedding_backend: EmbeddingBackendProtocol | None,
    ) -> None:
        self._content_store = content_store
        self._embedding_backend = embedding_backend

    def add_fact(
        self,
        text: str,
        provenance: dict[str, Any],
        confidence: float = 0.8,
    ) -> str | None:
        """Add a fact with write-time deduplication.

        Returns item_id if stored (new or supersede), None if merged with existing.

        Two-step dedup (hard constraint):
        1. Embed text, cosine search existing facts (threshold 0.85)
        2. If similar found, check negation:
           - Same polarity → merge (update provenance, keep higher confidence)
           - Negated → supersede (soft-delete old, store new)
        3. If no match → insert new fact
        """
        if not text.strip():
            return None

        # Embed the new fact
        try:
            new_embedding = self._embedding_backend.embed(text)
        except Exception:
            logger.warning(
                "Failed to embed fact (dedup skipped): %.80s", text, exc_info=True
            )
            # FTS fallback: check for exact-text match among existing facts
            try:
                fts_hits = self._content_store.fts_search(text, limit=5)
                for hit in fts_hits:
                    if (
                        set(FACT_TAGS).issubset(set(getattr(hit, "tags", [])))
                        and (hit.body or "").strip().lower() == text.strip().lower()
                    ):
                        self._merge_fact(hit, provenance, confidence)
                        return None
            except Exception:
                pass
            return self._store_new_fact(text, [provenance], confidence, embed_ok=False)

        # Load existing facts and their embeddings for comparison
        existing_facts = self.get_all_facts()
        best_match: tuple[Item, float] | None = None
        best_similarity = 0.0

        for fact in existing_facts:
            emb_data = self._content_store.get_embedding(fact.item_id)
            if emb_data is None:
                continue
            existing_vec = _bytes_to_floats(emb_data[0])
            sim = _cosine_similarity(new_embedding, existing_vec)
            if sim > best_similarity:
                best_similarity = sim
                best_match = (fact, sim)

        # Step 1: Cosine gate
        if best_match is not None and best_similarity > DEDUP_THRESHOLD:
            existing_item, sim = best_match

            # Step 2: Negation check
            new_negated = bool(_NEGATION_RE.search(text))
            old_negated = bool(_NEGATION_RE.search(existing_item.body or ""))

            if new_negated != old_negated:
                # Polarity changed → supersede
                return self._supersede_fact(
                    existing_item, text, [provenance], confidence, new_embedding
                )
            else:
                # Same polarity → merge (update provenance, keep higher confidence)
                self._merge_fact(existing_item, provenance, confidence)
                return None

        # No match → insert new
        return self._store_new_fact(text, [provenance], confidence, new_embedding)

    def get_all_facts(self) -> list[Item]:
        """Retrieve all fact items from the content store."""
        # Use list_items with a generous limit and filter by tags
        items = self._content_store.list_items(
            type=ItemType.NOTE,
            limit=10000,
        )
        return [item for item in items if set(FACT_TAGS).issubset(set(item.tags))]

    def render_memory_block(self) -> str:
        """Render all facts as a compact text block for system prompt.

        Format:
        ## Memory
        - fact 1
        - fact 2
        ...
        """
        facts = self.get_all_facts()
        if not facts:
            return ""

        lines = ["## Memory"]
        for fact in facts:
            body = (fact.body or "").strip()
            if body:
                lines.append(f"- {body}")

        return "\n".join(lines)

    def _store_new_fact(
        self,
        text: str,
        provenance_list: list[dict[str, Any]],
        confidence: float,
        embedding: list[float] | None = None,
        embed_ok: bool = True,
    ) -> str:
        """Store a new fact as an Item."""
        item_id = str(uuid.uuid4())
        now = utcnow()

        metadata: dict[str, Any] = {
            "provenance": provenance_list,
            "confidence": confidence,
            "fact_type": "discrete",
        }
        if not embed_ok:
            metadata["dedup_skipped"] = True

        item = Item(
            item_id=item_id,
            type=ItemType.NOTE,
            title=text[:100],
            body=text,
            source_url=f"fact://{item_id}",
            tags=list(FACT_TAGS),
            captured_at=now,
            last_accessed=now,
            half_life_days=365,
            summary=Summary(text=text[:200]),
            metadata=metadata,
        )
        self._content_store.create_item(item)

        # Store embedding
        if embedding is not None:
            try:
                vec_bytes = _floats_to_bytes(embedding)
                self._content_store.save_embedding(
                    item_id,
                    vec_bytes,
                    self._embedding_backend.model_name,
                    self._embedding_backend.dimensions,
                )
            except Exception:
                logger.warning("Failed to save fact embedding", exc_info=True)

        return item_id

    def _merge_fact(
        self,
        existing: Item,
        new_provenance: dict[str, Any],
        new_confidence: float,
    ) -> None:
        """Merge into existing fact — update provenance list (never overwrite)."""
        metadata = dict(existing.metadata)
        prov_list = list(metadata.get("provenance", []))
        prov_list.append(new_provenance)
        metadata["provenance"] = prov_list

        # Keep higher confidence
        old_confidence = metadata.get("confidence", 0.5)
        metadata["confidence"] = max(old_confidence, new_confidence)

        existing.metadata = metadata
        existing.last_accessed = utcnow()
        self._content_store.update_item(existing)

    def _supersede_fact(
        self,
        old_item: Item,
        new_text: str,
        provenance_list: list[dict[str, Any]],
        confidence: float,
        embedding: list[float] | None = None,
    ) -> str:
        """Supersede old fact — soft-delete old, store new with link."""
        # Soft-delete old fact
        self._content_store.soft_delete_item(old_item.item_id)

        # Store new fact with reference to superseded item
        item_id = str(uuid.uuid4())
        now = utcnow()

        # Carry forward provenance from old item (hard constraint: preserve history)
        old_provenance = old_item.metadata.get("provenance", [])
        combined_provenance = list(old_provenance) + provenance_list

        item = Item(
            item_id=item_id,
            type=ItemType.NOTE,
            title=new_text[:100],
            body=new_text,
            source_url=f"fact://{item_id}",
            tags=list(FACT_TAGS),
            captured_at=now,
            last_accessed=now,
            half_life_days=365,
            supersedes_id=old_item.item_id,
            summary=Summary(text=new_text[:200]),
            metadata={
                "provenance": combined_provenance,
                "confidence": confidence,
                "fact_type": "discrete",
                "supersedes": old_item.item_id,
            },
        )
        self._content_store.create_item(item)

        # Store embedding
        if embedding is not None:
            try:
                vec_bytes = _floats_to_bytes(embedding)
                self._content_store.save_embedding(
                    item_id,
                    vec_bytes,
                    self._embedding_backend.model_name,
                    self._embedding_backend.dimensions,
                )
            except Exception:
                logger.warning(
                    "Failed to save superseding fact embedding", exc_info=True
                )

        return item_id
