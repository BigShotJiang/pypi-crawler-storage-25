"""Knowledge and memory subsystem for Memex."""
