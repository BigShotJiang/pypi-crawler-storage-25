"""Sleep-time fact consolidation and session-end quick dedup.

Nightly consolidation merges similar fact clusters via LLM micro-call.
Session-end quick_dedup catches obvious duplicates using embedding-only
comparison (no LLM call).

Hard constraint: preserve full provenance list from all merged facts.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any
from memex.utcnow import utcnow

if TYPE_CHECKING:
    from memex.memory.protocols import ContentStoreProtocol, EmbeddingBackendProtocol

from memex.memory.fact_store import FactStore, _bytes_to_floats, _cosine_similarity

logger = logging.getLogger(__name__)

# Consolidation similarity threshold (slightly lower than write-time dedup)
CONSOLIDATION_THRESHOLD = 0.80

# Quick dedup threshold (higher — only obvious duplicates)
QUICK_DEDUP_THRESHOLD = 0.90


def consolidate_facts(
    content_store: ContentStoreProtocol,
    embedding_backend: EmbeddingBackendProtocol,
) -> int:
    """Nightly consolidation: cluster similar facts and merge via LLM.

    1. Load all facts
    2. Build pairwise cosine similarity matrix
    3. Cluster facts with similarity > 0.80
    4. For each cluster, LLM micro-call to merge into single canonical fact
    5. Preserve full provenance list from all merged facts (hard constraint)
    6. Soft-delete originals, insert merged fact
    7. Re-render memory block

    Returns number of facts merged.
    """
    fact_store = FactStore(content_store, embedding_backend)
    facts = fact_store.get_all_facts()

    if len(facts) < 2:
        return 0

    # Load embeddings
    fact_embeddings: list[tuple[Any, list[float]]] = []
    for fact in facts:
        emb_data = content_store.get_embedding(fact.item_id)
        if emb_data is None:
            continue
        vec = _bytes_to_floats(emb_data[0])
        fact_embeddings.append((fact, vec))

    if len(fact_embeddings) < 2:
        return 0

    # Build clusters via greedy single-linkage
    used: set[int] = set()
    clusters: list[list[int]] = []

    for i in range(len(fact_embeddings)):
        if i in used:
            continue
        cluster = [i]
        used.add(i)
        for j in range(i + 1, len(fact_embeddings)):
            if j in used:
                continue
            sim = _cosine_similarity(fact_embeddings[i][1], fact_embeddings[j][1])
            if sim > CONSOLIDATION_THRESHOLD:
                cluster.append(j)
                used.add(j)
        if len(cluster) > 1:
            clusters.append(cluster)

    if not clusters:
        return 0

    merged_count = 0

    for cluster_indices in clusters:
        cluster_facts = [fact_embeddings[i][0] for i in cluster_indices]
        cluster_texts = [f.body or "" for f in cluster_facts]

        # LLM micro-call to merge
        merged_text = _llm_merge_facts(cluster_texts)
        if not merged_text:
            continue

        # Collect all provenance from cluster (hard constraint: preserve all)
        all_provenance: list[dict[str, Any]] = []
        max_confidence = 0.0
        for fact in cluster_facts:
            prov = fact.metadata.get("provenance", [])
            all_provenance.extend(prov)
            max_confidence = max(max_confidence, fact.metadata.get("confidence", 0.5))

        # Soft-delete originals
        for fact in cluster_facts:
            try:
                content_store.soft_delete_item(fact.item_id)
            except Exception:
                logger.debug(
                    "Failed to soft-delete fact %s", fact.item_id, exc_info=True
                )

        # Store merged fact
        try:
            fact_store._store_new_fact(
                merged_text,
                all_provenance,
                max_confidence,
            )
            merged_count += len(cluster_facts)
        except Exception:
            logger.debug("Failed to store merged fact", exc_info=True)

    # Re-render memory block
    if merged_count > 0:
        try:
            block = fact_store.render_memory_block()
            memory_block_path = Path.home() / ".memex" / "memory_block.md"
            if block:
                memory_block_path.parent.mkdir(parents=True, exist_ok=True)
                memory_block_path.write_text(block)
        except Exception:
            logger.debug(
                "Memory block re-render after consolidation failed", exc_info=True
            )

    return merged_count


def _llm_merge_facts(texts: list[str]) -> str | None:
    """Merge a cluster of similar facts into one canonical statement.

    Uses a cheap model micro-call. Returns merged text or None on failure.
    """
    try:
        from memex.llm import chat_with_usage

        prompt = (
            "Merge these similar facts into a single, accurate statement. "
            "Preserve all important details. Return only the merged statement, nothing else.\n\n"
            + "\n".join(f"- {t}" for t in texts)
        )

        messages = [
            {
                "role": "system",
                "content": "You merge duplicate facts into a single canonical statement.",
            },
            {"role": "user", "content": prompt},
        ]

        # Use cheap model for consolidation
        from memex.llm import _get_cheap_model

        response, _ = chat_with_usage(messages, model=_get_cheap_model())
        return response.strip() if response else None
    except Exception:
        logger.debug("LLM fact merge failed, using first fact", exc_info=True)
        return texts[0] if texts else None


def quick_dedup(
    content_store: Any,
    embedding_backend: Any,
) -> int:
    """Session-end quick dedup: embedding-only, no LLM call.

    Merges facts with cosine similarity > 0.90. Pure embedding comparison.
    Returns number of facts merged.
    """
    fact_store = FactStore(content_store, embedding_backend)
    facts = fact_store.get_all_facts()

    if len(facts) < 2:
        return 0

    # Load embeddings
    fact_embeddings: list[tuple[Any, list[float]]] = []
    for fact in facts:
        emb_data = content_store.get_embedding(fact.item_id)
        if emb_data is None:
            continue
        vec = _bytes_to_floats(emb_data[0])
        fact_embeddings.append((fact, vec))

    if len(fact_embeddings) < 2:
        return 0

    merged_count = 0
    deleted_ids: set[str] = set()

    for i in range(len(fact_embeddings)):
        fact_i, vec_i = fact_embeddings[i]
        if fact_i.item_id in deleted_ids:
            continue

        for j in range(i + 1, len(fact_embeddings)):
            fact_j, vec_j = fact_embeddings[j]
            if fact_j.item_id in deleted_ids:
                continue

            sim = _cosine_similarity(vec_i, vec_j)
            if sim > QUICK_DEDUP_THRESHOLD:
                # Merge j into i (keep i, soft-delete j)
                prov_j = fact_j.metadata.get("provenance", [])
                conf_j = fact_j.metadata.get("confidence", 0.5)

                # Update i's provenance (hard constraint: accumulate)
                metadata = dict(fact_i.metadata)
                prov_list = list(metadata.get("provenance", []))
                prov_list.extend(prov_j)
                metadata["provenance"] = prov_list
                metadata["confidence"] = max(
                    metadata.get("confidence", 0.5),
                    conf_j,
                )
                fact_i.metadata = metadata
                fact_i.last_accessed = utcnow()
                content_store.update_item(fact_i)

                content_store.soft_delete_item(fact_j.item_id)
                deleted_ids.add(fact_j.item_id)
                merged_count += 1

    return merged_count
