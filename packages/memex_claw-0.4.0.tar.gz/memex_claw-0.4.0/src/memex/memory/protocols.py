"""Runtime Protocols for Memex store interfaces.

These Protocols are structural (not inherited). Any store class that
has matching methods/attributes satisfies the Protocol automatically
via Python's structural subtyping.

Usage with TYPE_CHECKING avoids circular imports:

    from __future__ import annotations
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from memex.memory.protocols import ContentStoreProtocol
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ContentStoreProtocol(Protocol):
    def create_item(self, item: Any) -> None: ...
    def get_item(self, item_id: str) -> Any | None: ...
    def update_item(self, item: Any) -> None: ...
    def soft_delete_item(self, item_id: str) -> bool: ...
    def fts_search(
        self, query: str, limit: int = 20, item_type: str | None = None
    ) -> list[Any]: ...
    def find_by_url(self, url: str) -> Any | None: ...


@runtime_checkable
class EmbeddingBackendProtocol(Protocol):
    def embed(self, text: str) -> list[float]: ...
    def embed_batch(self, texts: list[str]) -> list[list[float]]: ...
