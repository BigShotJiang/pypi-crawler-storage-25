"""Cold storage — filesystem archive for expired conversation summaries.

When conversation Items expire (decay weight below threshold after 6-month
half-life), they are archived to ~/.memex/archive/ as JSON before deletion.
This preserves the LLM summary, graph metadata, and URLs
indefinitely on disk.

Archive structure:
    ~/.memex/archive/conversations/
        2026/
            2026-03-session-abc12345.json

Each JSON file contains:
    - item_id, title, body (the LLM summary)
    - metadata (session_id, turn_count, interface, urls)
    - captured_at, source_url
    - graph_context: entity mentions, linked items (if available)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from memex.utcnow import utcnow

logger = logging.getLogger(__name__)

_DEFAULT_ARCHIVE_DIR = "~/.memex/archive/conversations"
_DECAY_THRESHOLD = 0.05  # Archive when decay weight drops below this


def get_archive_dir() -> Path:
    """Return the archive directory, creating it if needed."""
    import os

    path = Path(os.environ.get("MEMEX_ARCHIVE_DIR", _DEFAULT_ARCHIVE_DIR)).expanduser()
    path.mkdir(parents=True, exist_ok=True)
    return path


def archive_item(
    item: Any,
    *,
    graph_context: dict[str, Any] | None = None,
    archive_dir: Path | None = None,
) -> Path | None:
    """Write an expired conversation Item to cold storage as JSON.

    Returns the path written, or None on failure.
    """
    try:
        dest = archive_dir or get_archive_dir()

        # Organize by year
        captured = item.captured_at if hasattr(item, "captured_at") else utcnow()
        year_dir = dest / str(captured.year)
        year_dir.mkdir(exist_ok=True)

        # Filename: date-session-itemid.json
        session_id = ""
        metadata = item.metadata if hasattr(item, "metadata") else {}
        if isinstance(metadata, dict):
            session_id = metadata.get("session_id", "")

        date_str = captured.strftime("%Y-%m-%d")
        sid_short = session_id[:8] if session_id else "nosession"
        iid_short = item.item_id[:8] if hasattr(item, "item_id") else "unknown"
        filename = f"{date_str}-{sid_short}-{iid_short}.json"
        filepath = year_dir / filename

        # Build archive record
        record: dict[str, Any] = {
            "item_id": getattr(item, "item_id", ""),
            "type": getattr(item.type, "value", str(item.type))
            if hasattr(item, "type")
            else "",
            "title": getattr(item, "title", ""),
            "body": getattr(item, "body", ""),
            "source_url": getattr(item, "source_url", ""),
            "author": getattr(item, "author", ""),
            "captured_at": captured.isoformat(),
            "tags": getattr(item, "tags", []),
            "metadata": metadata,
            "archived_at": utcnow().isoformat(),
        }

        if graph_context:
            record["graph_context"] = graph_context

        filepath.write_text(
            json.dumps(record, indent=2, default=str),
            encoding="utf-8",
        )
        logger.info("Archived conversation %s to %s", iid_short, filepath)
        return filepath

    except Exception:
        logger.debug("Failed to archive item", exc_info=True)
        return None


def archive_expired_conversations(
    content_store: Any,
    *,
    threshold: float = _DECAY_THRESHOLD,
    archive_dir: Path | None = None,
) -> int:
    """Find conversation Items below decay threshold, archive, then delete.

    Returns count of items archived.
    """
    from memex.memory.decay import item_decay_weight
    from memex.models import ItemType

    now = utcnow()
    archived = 0

    try:
        # Get all conversation items including expired ones
        items = content_store.list_items(
            type=ItemType.CONVERSATION,
            include_expired=True,
            limit=500,
            now=now,
        )
    except Exception:
        logger.debug("Failed to list conversation items for archival", exc_info=True)
        return 0

    for item in items:
        if item.pinned:
            continue

        weight = item_decay_weight(item, now)
        if weight >= threshold:
            continue

        # Gather graph context if available (entity mentions, links)
        graph_context = _gather_graph_context(content_store, item.item_id)

        path = archive_item(
            item,
            graph_context=graph_context,
            archive_dir=archive_dir,
        )
        if path is not None:
            try:
                content_store.delete_item(item.item_id)
                archived += 1
            except Exception:
                logger.debug(
                    "Failed to delete archived item %s", item.item_id, exc_info=True
                )

    if archived:
        logger.info("Archived %d expired conversation(s) to cold storage", archived)
    return archived


def _gather_graph_context(content_store: Any, item_id: str) -> dict[str, Any]:
    """Extract graph metadata (links, entities) for an item before archival."""
    context: dict[str, Any] = {}

    try:
        links = content_store.get_links(item_id)
        if links:
            context["links"] = [
                {
                    "target_id": link.target_item_id,
                    "relationship": link.relationship,
                    "strength": link.strength,
                }
                for link in links[:20]
            ]
    except Exception:
        logger.debug("Failed to gather link context for %s", item_id, exc_info=True)

    # Try to get entity mentions
    try:
        if hasattr(content_store, "get_entity_mentions"):
            entities = content_store.get_entity_mentions(item_id, limit=20)
            if entities:
                context["entities"] = entities
    except Exception:
        logger.debug("Failed to gather entity context for %s", item_id, exc_info=True)

    return context
