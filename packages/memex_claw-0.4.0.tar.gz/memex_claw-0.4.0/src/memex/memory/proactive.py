"""Proactive context surfacing — inject related knowledge before the LLM responds.

Uses entity lookup + graph neighborhood to find items related to entities
mentioned in the user's input. Degrades gracefully when the knowledge
store is not available (returns empty string).
"""

from __future__ import annotations

import logging

from memex.memory.extraction_gate import ExtractionSignals

logger = logging.getLogger(__name__)

# Stop words to exclude from goal keyword overlap
_STOP_WORDS = frozenset(
    {
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "can",
        "shall",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "about",
        "up",
        "out",
        "if",
        "or",
        "and",
        "but",
        "not",
        "no",
        "so",
        "than",
        "too",
        "very",
        "just",
        "that",
        "this",
        "it",
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "she",
        "they",
        "them",
        "his",
        "her",
        "its",
        "what",
        "which",
        "who",
        "when",
        "where",
        "how",
        "all",
        "each",
        "some",
        "any",
    }
)

_MAX_PROACTIVE_ITEMS = 5


def _item_retrieval_ids(item) -> set[str]:
    item_id = getattr(item, "item_id", "")
    if not item_id:
        return set()
    return {
        f"content_item:{item_id}",
        f"world_model_knowledge:knowledge/{item_id}",
    }


def _meaningful_words(text: str) -> set[str]:
    """Extract non-stop-word tokens from text."""
    return {w for w in text.lower().split() if w not in _STOP_WORDS and len(w) > 1}


def surface_proactive_context(
    user_input: str,
    gate_signals: ExtractionSignals,
    active_goals: list,
    content_store,
    already_retrieved_ids: set[str],
) -> str:
    """Surface related knowledge items proactively.

    Uses entities from the gate to look up related items via
    find_by_entity and neighborhood graph queries.
    Deduplicates against already_retrieved_ids from the main retrieval.

    Returns formatted markdown string, or "" if nothing found.
    """
    if not gate_signals.entities:
        return ""

    # Graceful degradation: need find_by_entity
    if not hasattr(content_store, "find_by_entity"):
        return ""

    seen_ids = set(already_retrieved_ids)
    proactive_items = []

    # 1. Entity-based lookup
    for name, etype in gate_signals.entities:
        if len(proactive_items) >= _MAX_PROACTIVE_ITEMS:
            break
        try:
            items = content_store.find_by_entity(name, etype)
            for item in items:
                if _item_retrieval_ids(item).isdisjoint(seen_ids):
                    seen_ids.update(_item_retrieval_ids(item))
                    proactive_items.append(item)
                    if len(proactive_items) >= _MAX_PROACTIVE_ITEMS:
                        break
        except Exception:
            logger.debug("Entity lookup failed for %s", name, exc_info=True)

    # 2. Graph neighborhood expansion (1-hop from entity-matched items)
    if hasattr(content_store, "neighborhood") and proactive_items:
        seed_ids = [it.item_id for it in proactive_items[:2]]  # limit expansion
        for sid in seed_ids:
            if len(proactive_items) >= _MAX_PROACTIVE_ITEMS:
                break
            try:
                neighbors = content_store.neighborhood(sid, hops=1)
                for item in neighbors:
                    if _item_retrieval_ids(item).isdisjoint(seen_ids):
                        seen_ids.update(_item_retrieval_ids(item))
                        proactive_items.append(item)
                        if len(proactive_items) >= _MAX_PROACTIVE_ITEMS:
                            break
            except Exception:
                logger.debug("Neighborhood lookup failed for %s", sid, exc_info=True)

    # 3. Goal-relevance boost: check keyword overlap with active goals
    if active_goals:
        input_words = _meaningful_words(user_input)
        for goal in active_goals:
            goal_text = (
                getattr(goal, "title", "") + " " + getattr(goal, "description", "")
            )
            goal_words = _meaningful_words(goal_text)
            overlap = input_words & goal_words
            if len(overlap) >= 2:
                # Goal is relevant — already handled by entity lookup above
                break

    if not proactive_items:
        return ""

    # Format output
    parts = ["## Related Context"]
    for item in proactive_items[:_MAX_PROACTIVE_ITEMS]:
        title = item.title or "(untitled)"
        body = (
            item.summary.text
            if hasattr(item, "summary") and item.summary and item.summary.text
            else item.body
        )
        if body and len(body) > 200:
            body = body[:200] + "..."
        entry = f"- **{title}**"
        if body:
            entry += f": {body}"
        parts.append(entry)

    return "\n".join(parts)
