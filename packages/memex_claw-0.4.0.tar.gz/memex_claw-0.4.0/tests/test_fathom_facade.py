"""Tests for FathomMemexStore — the MemexStore facade over FathomStore."""

from __future__ import annotations

from datetime import datetime

import pytest

from memex.fathom_facade import FathomMemexStore, FathomSettingsAdapter
from memex.fathom_store import FathomStore
from memex.meetings.models import MeetingRecord, MeetingRecording, MeetingState
from memex.models import (
    AgentSelfModel,
    AuditEntry,
    CalendarEvent,
    ConnectorHealth,
    ConversationTurn,
    Goal,
    GoalEntityLink,
    GoalPriority,
    GoalStatus,
    HumanPartnerProfile,
    Item,
    ItemType,
    MeetingEntityLink,
    SessionContext,
    WorldModelActionPlan,
    WorldModelExecutionRecord,
    WorldModelKnowledgeEntityLink,
    WorldModelKnowledgeIngestRun,
    WorldModelKnowledgeObject,
    WorldModelKnowledgeRelationship,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
)
from memex.utcnow import utcnow


@pytest.fixture
def fstore(tmp_path):
    """Fresh FathomStore for each test."""
    db_path = str(tmp_path / "facade_test.db")
    store = FathomStore.open(db_path)
    yield store
    store.close()


@pytest.fixture
def facade(fstore):
    """FathomMemexStore wrapping the fresh FathomStore."""
    return FathomMemexStore(fstore)


# ── Properties ──────────────────────────────────────────────────────────


class TestFacadeProperties:
    """Basic facade wiring — properties and sub-stores."""

    def test_conn_returns_none(self, facade):
        assert facade.conn is None

    def test_knowledge_backend_is_fathomdb(self, facade):
        assert facade.knowledge_backend == "fathomdb"

    def test_knowledge_degraded_modes_empty(self, facade):
        assert facade.knowledge_degraded_modes == []

    def test_content_property_exists(self, facade):
        assert facade.content is not None

    def test_scheduler_property_exists(self, facade):
        assert facade.scheduler is not None

    def test_meetings_property_exists(self, facade):
        assert facade.meetings is not None

    def test_settings_property_exists(self, facade):
        assert facade.settings is not None
        assert isinstance(facade.settings, FathomSettingsAdapter)


# ── Settings adapter ───────────────────────────────────────────────────


class TestSettingsAdapter:
    """FathomSettingsAdapter mirrors SettingsStore behaviour."""

    def test_get_missing_returns_default(self, facade):
        assert facade.settings.get("absent") is None
        assert facade.settings.get("absent", "fallback") == "fallback"

    def test_set_and_get(self, facade):
        facade.settings.set("theme", "dark")
        assert facade.settings.get("theme") == "dark"

    def test_set_overwrites(self, facade):
        facade.settings.set("theme", "dark")
        facade.settings.set("theme", "light")
        assert facade.settings.get("theme") == "light"

    def test_delete_existing(self, facade):
        facade.settings.set("temp", "val")
        assert facade.settings.delete("temp") is True
        assert facade.settings.get("temp") is None

    def test_delete_missing(self, facade):
        assert facade.settings.delete("nope") is False

    def test_list_all(self, facade):
        facade.settings.set("a", "1")
        facade.settings.set("b", "2")
        rows = facade.settings.list_all()
        keys = {r["key"] for r in rows}
        assert keys >= {"a", "b"}

    def test_get_int(self, facade):
        facade.settings.set("count", "42")
        assert facade.settings.get_int("count") == 42
        assert facade.settings.get_int("missing", default=7) == 7

    def test_get_float(self, facade):
        facade.settings.set("ratio", "3.14")
        assert abs(facade.settings.get_float("ratio") - 3.14) < 0.001
        assert facade.settings.get_float("missing", default=1.5) == 1.5


# ── Goal CRUD ──────────────────────────────────────────────────────────


class TestGoalCRUD:
    """Goal create / get / update / list through the facade."""

    @staticmethod
    def _make_goal(goal_id: str = "g1", **kw) -> Goal:
        now = utcnow()
        defaults = dict(
            goal_id=goal_id,
            title="Test goal",
            description="A test",
            status=GoalStatus.ACTIVE,
            priority=GoalPriority.MEDIUM,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        defaults.update(kw)
        return Goal(**defaults)

    def test_create_and_get(self, facade):
        goal = self._make_goal()
        facade.create_goal(goal)
        got = facade.get_goal("g1")
        assert got is not None
        assert got.goal_id == "g1"
        assert got.title == "Test goal"
        assert got.status == GoalStatus.ACTIVE

    def test_update_goal(self, facade):
        goal = self._make_goal()
        facade.create_goal(goal)
        goal.title = "Updated"
        goal.status = GoalStatus.COMPLETED
        facade.update_goal(goal)
        got = facade.get_goal("g1")
        assert got is not None
        assert got.title == "Updated"
        assert got.status == GoalStatus.COMPLETED

    def test_list_goals_all(self, facade):
        facade.create_goal(self._make_goal("a"))
        facade.create_goal(self._make_goal("b"))
        goals = facade.list_goals()
        assert len(goals) >= 2

    def test_list_goals_by_status(self, facade):
        facade.create_goal(self._make_goal("act", status=GoalStatus.ACTIVE))
        facade.create_goal(self._make_goal("done", status=GoalStatus.COMPLETED))
        active = facade.list_goals(status=GoalStatus.ACTIVE)
        ids = {g.goal_id for g in active}
        assert "act" in ids
        assert "done" not in ids

    def test_get_children(self, facade):
        facade.create_goal(self._make_goal("parent"))
        facade.create_goal(self._make_goal("child", parent_id="parent"))
        children = facade.get_children("parent")
        assert len(children) >= 1
        assert children[0].goal_id == "child"

    def test_get_missing_goal_returns_none(self, facade):
        assert facade.get_goal("nonexistent") is None


# ── Partner / session / agent model ────────────────────────────────────


class TestProfileAndSession:
    """Partner profile, session context, and agent self-model round-trips."""

    def test_partner_profile_round_trip(self, facade):
        profile = HumanPartnerProfile(
            partner_id="default",
            name="Alice",
            communication_style="concise",
        )
        facade.save_partner_profile(profile)
        loaded = facade.load_partner_profile()
        assert loaded is not None
        assert loaded.name == "Alice"
        assert loaded.communication_style == "concise"

    def test_partner_profile_missing(self, facade):
        assert facade.load_partner_profile() is None

    def test_session_round_trip(self, facade):
        ctx = SessionContext(
            session_id="sess-1",
            started_at=utcnow(),
            turn_count=3,
        )
        facade.save_session(ctx)
        loaded = facade.load_session()
        assert loaded is not None
        assert loaded.session_id == "sess-1"
        assert loaded.turn_count == 3

    def test_agent_self_model_round_trip(self, facade):
        model = AgentSelfModel(agent_id="memex", display_name="Memex")
        facade.save_agent_self_model(model)
        loaded = facade.load_agent_self_model()
        assert loaded is not None
        assert loaded.agent_id == "memex"
        assert loaded.display_name == "Memex"


# ── Conversation log ───────────────────────────────────────────────────


class TestConversationLog:
    """Conversation turn logging and query through the facade."""

    def test_log_and_query(self, facade):
        now = utcnow()
        turn = ConversationTurn(role="human", content="Hello", timestamp=now)
        facade.log_turn("sess-1", turn)

        rows = facade.query_conversation_log(session_id="sess-1")
        assert len(rows) >= 1
        found = [r for r in rows if r.get("content") == "Hello"]
        assert len(found) == 1

    def test_fts_search(self, facade):
        now = utcnow()
        facade.log_turn(
            "s1",
            ConversationTurn(role="human", content="unicorn rainbow", timestamp=now),
        )
        facade.log_turn(
            "s1",
            ConversationTurn(role="assistant", content="something else", timestamp=now),
        )

        results = facade.fts_search_conversations("unicorn")
        assert len(results) >= 1
        assert any("unicorn" in r.get("content", "") for r in results)

    def test_cleanup(self, facade):
        old = datetime(2020, 1, 1)
        facade.log_turn(
            "s1", ConversationTurn(role="human", content="old msg", timestamp=old)
        )
        cutoff = datetime(2021, 1, 1)
        cleaned = facade.cleanup_conversation_log(cutoff)
        assert cleaned >= 1


# ── Audit & health ─────────────────────────────────────────────────────


class TestAuditAndHealth:
    """Audit logging and connector health through the facade."""

    def test_log_audit(self, facade):
        entry = AuditEntry(
            timestamp=utcnow(),
            connector="test",
            action="ping",
            granted=True,
        )
        facade.log_audit(entry)
        rows = facade.query_audit(connector="test")
        assert len(rows) >= 1
        assert rows[0].connector == "test"

    def test_connector_health_round_trip(self, facade):
        health = ConnectorHealth(
            name="mcp-fs",
            status="connected",
            last_check=utcnow(),
            tools_discovered=5,
        )
        facade.save_connector_health(health)
        loaded = facade.load_connector_health()
        assert len(loaded) >= 1
        names = {h.name for h in loaded}
        assert "mcp-fs" in names


# ── Calendar events through facade ────────────────────────────────────


class TestCalendarEventsFacade:
    """Calendar event upsert and list through the facade."""

    def test_upsert_and_list_upcoming(self, facade):
        now = utcnow()
        event = CalendarEvent(
            event_id="evt1",
            provider="google",
            title="Standup",
            starts_at=datetime(2026, 4, 1, 9, 0),
            ends_at=datetime(2026, 4, 1, 9, 30),
            attendees=["alice"],
            synced_at=now,
        )
        facade.upsert_calendar_event(event)

        horizon = datetime(2026, 5, 1)
        events = facade.list_upcoming_calendar_events(horizon)
        assert len(events) >= 1
        assert events[0].event_id == "evt1"
        assert events[0].title == "Standup"

    def test_list_upcoming_respects_horizon(self, facade):
        now = utcnow()
        facade.upsert_calendar_event(
            CalendarEvent(
                event_id="e1",
                provider="google",
                title="Soon",
                starts_at=datetime(2026, 3, 1),
                synced_at=now,
            )
        )
        facade.upsert_calendar_event(
            CalendarEvent(
                event_id="e2",
                provider="google",
                title="Far",
                starts_at=datetime(2027, 1, 1),
                synced_at=now,
            )
        )
        horizon = datetime(2026, 6, 1)
        events = facade.list_upcoming_calendar_events(horizon)
        assert all(e.starts_at < horizon for e in events)
        titles = {e.title for e in events}
        assert "Soon" in titles
        assert "Far" not in titles


# ── Meeting entity links through facade ──────────────────────────────


class TestMeetingEntityLinksFacade:
    """Meeting-entity link create and list through the facade."""

    def test_create_and_list(self, facade, fstore):
        fstore.meetings.create_meeting("m1", "Sprint Planning")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")

        link = MeetingEntityLink(
            meeting_id="m1",
            entity_id="e1",
            relationship="attendee",
            created_at=utcnow(),
        )
        facade.create_meeting_entity_link(link)
        links = facade.list_meeting_entity_links("m1")
        assert len(links) >= 1
        assert links[0].meeting_id == "m1"

    def test_list_empty(self, facade, fstore):
        fstore.meetings.create_meeting("m2", "Empty")
        links = facade.list_meeting_entity_links("m2")
        assert links == []


# ── Goals for entity through facade ──────────────────────────────────


class TestGoalsForEntityFacade:
    """list_goals_for_entity through the facade."""

    def test_goals_for_entity(self, facade, fstore):
        now = utcnow()
        facade.create_goal(
            Goal(
                goal_id="g1",
                title="Goal A",
                status=GoalStatus.ACTIVE,
                priority=GoalPriority.HIGH,
                created_at=now,
                updated_at=now,
                last_touched_at=now,
            )
        )
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        facade.create_goal_entity_link(
            GoalEntityLink(
                goal_id="g1",
                entity_id="e1",
                relationship="owner",
                created_at=now,
            )
        )
        results = facade.list_goals_for_entity("e1")
        assert len(results) >= 1
        assert results[0].goal_id == "g1"

    def test_goals_for_entity_empty(self, facade, fstore):
        fstore.world_model.upsert_entity("e2", "partner", "Bob")
        results = facade.list_goals_for_entity("e2")
        assert results == []


# ── Tool usage stats through facade ──────────────────────────────────


class TestToolUsageStatsFacade:
    """get_tool_usage_stats through the facade."""

    def test_get_all(self, facade):
        facade.record_tool_usage("search_knowledge", ["find", "lookup"])
        stats = facade.get_tool_usage_stats()
        assert len(stats) >= 2

    def test_get_filtered(self, facade):
        facade.record_tool_usage("search_knowledge", ["find"])
        facade.record_tool_usage("read_file", ["open"])
        stats = facade.get_tool_usage_stats(tool_name="search_knowledge")
        assert all(s["tool_name"] == "search_knowledge" for s in stats)

    def test_get_empty(self, facade):
        stats = facade.get_tool_usage_stats()
        assert stats == []


# ── Lifecycle ──────────────────────────────────────────────────────────


class TestLifecycle:
    """Store open/close semantics."""

    def test_close_is_safe(self, fstore):
        facade = FathomMemexStore(fstore)
        facade.close()
        # Second close should not raise
        facade.close()


# ── Action plan facade ──────────────────────────────────────────────


class TestActionPlanFacade:
    """Facade delegation for action plans."""

    def _make_plan(self, **overrides):
        now = utcnow()
        defaults = dict(
            plan_id="plan1",
            goal_id="g1",
            title="Deploy",
            summary="",
            status="active",
            selected_step_id=None,
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelActionPlan(**defaults)

    def test_upsert_and_load(self, facade):
        facade.upsert_world_model_action_plan(self._make_plan())
        loaded = facade.load_world_model_action_plan("plan1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelActionPlan)
        assert loaded.plan_id == "plan1"

    def test_load_missing(self, facade):
        assert facade.load_world_model_action_plan("nope") is None

    def test_list(self, facade):
        facade.upsert_world_model_action_plan(
            self._make_plan(plan_id="p1"),
        )
        facade.upsert_world_model_action_plan(
            self._make_plan(plan_id="p2"),
        )
        plans = facade.list_world_model_action_plans()
        assert len(plans) >= 2


# ── Plan step facade ────────────────────────────────────────────────


class TestPlanStepFacade:
    """Facade delegation for plan steps."""

    def _make_step(self, **overrides):
        now = utcnow()
        defaults = dict(
            step_id="s1",
            plan_id="p1",
            goal_id="g1",
            step_kind="task",
            title="Build",
            description="",
            status="active",
            ordinal=0,
            blocked_reason="",
            progress_pct=0,
            depends_on_step_ids=[],
            blocked_by_step_ids=[],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelPlanStep(**defaults)

    def test_upsert_and_load(self, facade):
        facade.upsert_world_model_plan_step(self._make_step())
        loaded = facade.load_world_model_plan_step("s1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelPlanStep)

    def test_load_missing(self, facade):
        assert facade.load_world_model_plan_step("nope") is None

    def test_list(self, facade):
        facade.upsert_world_model_plan_step(
            self._make_step(step_id="s1"),
        )
        facade.upsert_world_model_plan_step(
            self._make_step(step_id="s2"),
        )
        steps = facade.list_world_model_plan_steps(plan_id="p1")
        assert len(steps) >= 2


# ── Execution record facade ─────────────────────────────────────────


class TestExecutionRecordFacade:
    """Facade delegation for execution records."""

    def _make_record(self, **overrides):
        now = utcnow()
        defaults = dict(
            execution_id="e1",
            session_id="sess1",
            conversation_turn_id=None,
            goal_id="g1",
            plan_id="p1",
            step_id="s1",
            execution_kind="tool_call",
            title="Run",
            summary="",
            status="completed",
            source_record_type="WMAction",
            source_record_id="a1",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelExecutionRecord(**defaults)

    def test_upsert_and_load(self, facade):
        facade.upsert_world_model_execution_record(self._make_record())
        loaded = facade.load_world_model_execution_record("e1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelExecutionRecord)

    def test_load_missing(self, facade):
        assert facade.load_world_model_execution_record("nope") is None

    def test_list(self, facade):
        facade.upsert_world_model_execution_record(
            self._make_record(execution_id="e1"),
        )
        facade.upsert_world_model_execution_record(
            self._make_record(execution_id="e2"),
        )
        results = facade.list_world_model_execution_records(session_id="sess1")
        assert len(results) >= 2


# ── Ingest run facade ───────────────────────────────────────────────


class TestIngestRunFacade:
    """Facade delegation for knowledge ingest runs."""

    def _make_run(self, **overrides):
        now = utcnow()
        defaults = dict(
            ingest_run_id="ir1",
            ingest_kind="url",
            trigger_surface="telegram",
            session_id="sess1",
            source_ref="https://example.com",
            normalized_source_ref="example.com",
            requested_item_type="article",
            status="completed",
            phase="done",
            fallback_used=False,
            item_id="item1",
            knowledge_id="k1",
            summary_model="gpt-4o",
            error="",
            payload={},
            created_at=now,
            updated_at=now,
            finished_at=now,
        )
        defaults.update(overrides)
        return WorldModelKnowledgeIngestRun(**defaults)

    def test_upsert_and_load(self, facade):
        facade.upsert_world_model_knowledge_ingest_run(self._make_run())
        loaded = facade.load_world_model_knowledge_ingest_run("ir1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelKnowledgeIngestRun)

    def test_load_missing(self, facade):
        assert facade.load_world_model_knowledge_ingest_run("nope") is None

    def test_list(self, facade):
        facade.upsert_world_model_knowledge_ingest_run(
            self._make_run(ingest_run_id="ir1"),
        )
        facade.upsert_world_model_knowledge_ingest_run(
            self._make_run(ingest_run_id="ir2"),
        )
        results = facade.list_world_model_knowledge_ingest_runs()
        assert len(results) >= 2


# ── Transition facade ───────────────────────────────────────────────


class TestTransitionFacade:
    """Facade delegation for plan step transitions."""

    def _make_transition(self, **overrides):
        now = utcnow()
        defaults = dict(
            transition_id="t1",
            step_id="s1",
            plan_id="p1",
            goal_id="g1",
            execution_id="e1",
            transition_kind="status_change",
            from_status="active",
            to_status="completed",
            blocked_reason=None,
            blocked_by_step_ids=None,
            progress_pct=100,
            summary="Done",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelPlanStepTransition(**defaults)

    def test_append_and_load(self, facade):
        facade.append_world_model_plan_step_transition(
            self._make_transition(),
        )
        loaded = facade.load_world_model_plan_step_transition("t1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelPlanStepTransition)

    def test_load_missing(self, facade):
        assert facade.load_world_model_plan_step_transition("nope") is None

    def test_list(self, facade):
        facade.append_world_model_plan_step_transition(
            self._make_transition(transition_id="t1"),
        )
        facade.append_world_model_plan_step_transition(
            self._make_transition(transition_id="t2"),
        )
        results = facade.list_world_model_plan_step_transitions(step_id="s1")
        assert len(results) >= 2


# ── Knowledge sync facade ───────────────────────────────────────────


class TestKnowledgeSyncFacade:
    """Facade delegation for knowledge object operations."""

    def test_sync_and_load_by_item_id(self, facade):
        now = utcnow()
        item = Item(
            item_id="item1",
            type=ItemType.ARTICLE,
            title="Test Article",
            body="body",
            source_url="https://example.com",
            captured_at=now,
            last_accessed=now,
        )
        facade.sync_world_model_knowledge_from_item(item)
        loaded = facade.load_world_model_knowledge_object_by_item_id("item1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelKnowledgeObject)
        assert loaded.item_id == "item1"
        assert loaded.title == "Test Article"

    def test_load_by_item_id_missing(self, facade):
        assert facade.load_world_model_knowledge_object_by_item_id("nope") is None

    def test_list_entity_links_empty(self, facade):
        links = facade.list_world_model_knowledge_entity_links("k-none")
        assert links == []

    def test_list_entity_links(self, facade, fstore):
        fstore.world_model.upsert_knowledge_entity_link(
            "kel1",
            "k1",
            "ent1",
            relationship="mentions",
        )
        links = facade.list_world_model_knowledge_entity_links("k1")
        assert len(links) >= 1
        assert all(isinstance(lnk, WorldModelKnowledgeEntityLink) for lnk in links)

    def test_list_relationships_empty(self, facade):
        rels = facade.list_world_model_knowledge_relationships()
        assert rels == []

    def test_list_relationships(self, facade, fstore):
        fstore.world_model.upsert_knowledge_relationship(
            "kr1",
            "k1",
            "k2",
            "supports",
        )
        rels = facade.list_world_model_knowledge_relationships(
            source_knowledge_id="k1",
        )
        assert len(rels) >= 1
        assert all(isinstance(r, WorldModelKnowledgeRelationship) for r in rels)


# ── Meeting adapter: model-object API contract ────────────────────────


class TestMeetingAdapterContract:
    """FathomMeetingAdapter must accept model objects like SQLite MeetingStore."""

    @staticmethod
    def _make_record(**kw) -> MeetingRecord:
        now = utcnow()
        defaults = dict(
            meeting_id="m1",
            state=MeetingState.CREATED,
            title="Standup",
            created_at=now,
            updated_at=now,
        )
        defaults.update(kw)
        return MeetingRecord(**defaults)

    @staticmethod
    def _make_recording(meeting_id: str = "m1", **kw) -> MeetingRecording:
        defaults = dict(
            recording_id=f"{meeting_id}-r1",
            meeting_id=meeting_id,
            sequence_number=1,
            state=MeetingState.CREATED,
        )
        defaults.update(kw)
        return MeetingRecording(**defaults)

    def test_create_meeting_from_record(self, facade):
        """create_meeting(MeetingRecord) — the actual caller pattern."""
        record = self._make_record()
        facade.meetings.create_meeting(record)
        m = facade.meetings.get_meeting("m1")
        assert m is not None
        assert m.title == "Standup"

    def test_create_meeting_from_record_with_enum_state(self, facade):
        """State enum .value must be extracted."""
        record = self._make_record(state=MeetingState.RECORDING)
        facade.meetings.create_meeting(record)
        m = facade.meetings.get_meeting("m1")
        assert m is not None
        assert m.state in (MeetingState.RECORDING, "recording")

    def test_create_meeting_from_record_with_attendees(self, facade):
        record = self._make_record(attendees=["alice", "bob"])
        facade.meetings.create_meeting(record)
        m = facade.meetings.get_meeting("m1")
        assert m.attendees == ["alice", "bob"]

    def test_update_meeting_from_record(self, facade):
        """update_meeting(MeetingRecord) — callers pass the whole object."""
        record = self._make_record()
        facade.meetings.create_meeting(record)
        record.title = "Updated Standup"
        record.notes = "With notes"
        facade.meetings.update_meeting(record)
        m = facade.meetings.get_meeting("m1")
        assert m.title == "Updated Standup"
        assert m.notes == "With notes"

    def test_update_recording_from_object(self, facade, fstore):
        """update_recording(MeetingRecording) — callers pass the whole object."""
        fstore.meetings.create_meeting("m1", "Test")
        rec = self._make_recording()
        fstore.meetings.create_recording(
            rec.recording_id,
            rec.meeting_id,
            sequence_number=rec.sequence_number,
        )
        rec.state = MeetingState.RECORDING
        rec.audio_path = "/tmp/test.wav"
        facade.meetings.update_recording(rec)
        loaded = facade.meetings.get_recording(rec.recording_id)
        assert loaded is not None
        assert loaded.audio_path == "/tmp/test.wav"

    def test_delete_meeting(self, facade):
        record = self._make_record()
        facade.meetings.create_meeting(record)
        facade.meetings.delete_meeting("m1")
        assert facade.meetings.get_meeting("m1") is None


# ── Scheduler adapter: engine-compatible API contract ─────────────────


class TestSchedulerAdapterContract:
    """FathomSchedulerAdapter must accept the same API as SQLite SchedulerStore."""

    def test_create_task_from_model(self, facade, fstore):
        """create_task(ScheduledTask) — the actual caller pattern from cli.py."""
        from memex.models import ActionType, ScheduledTask

        now = utcnow()
        task = ScheduledTask(
            task_id="t1",
            name="Test Task",
            description="A test",
            cron_expr="0 8 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={"msg": "hi"},
            goal_id="g99",
            created_at=now,
            updated_at=now,
        )
        facade.scheduler.create_task(task)
        loaded = fstore.scheduler.get_task("t1")
        assert loaded is not None
        assert loaded.name == "Test Task"
        assert loaded.cron_expr == "0 8 * * *"

    def test_record_run_with_engine_kwargs(self, facade, fstore):
        """record_run(task_id, status=, queued_at=, action_type=, ...) — engine pattern."""
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        now = utcnow()
        run_id = facade.scheduler.record_run(
            "t1",
            status="queued",
            queued_at=now,
            action_type="notification",
            action_data={"key": "val"},
            priority=3,
        )
        assert run_id is not None
        runs = fstore.scheduler.get_runs("t1")
        assert len(runs) >= 1
        assert runs[0]["status"] == "queued"

    def test_record_run_minimal(self, facade, fstore):
        """record_run(task_id) with defaults only."""
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = facade.scheduler.record_run("t1")
        assert run_id is not None

    def test_get_last_run_returns_task_run(self, facade, fstore):
        """get_last_run returns a TaskRun model."""
        from memex.models import TaskRun

        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        last = facade.scheduler.get_last_run("t1")
        assert last is not None
        assert isinstance(last, TaskRun)
        assert hasattr(last, "started_at")

    def test_get_last_run_empty(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        assert facade.scheduler.get_last_run("t1") is None

    def test_get_runs_returns_task_run_models(self, facade, fstore):
        """get_runs returns TaskRun models with attribute access."""
        from memex.models import TaskRun

        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        runs = facade.scheduler.get_runs("t1")
        assert len(runs) >= 1
        assert isinstance(runs[0], TaskRun)
        assert hasattr(runs[0], "status")

    def test_list_tasks_returns_scheduled_task(self, facade, fstore):
        """list_tasks returns ScheduledTask objects with .task_id and .cron_expr."""
        from memex.models import ScheduledTask

        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        tasks = facade.scheduler.list_tasks(enabled_only=True)
        assert len(tasks) >= 1
        assert isinstance(tasks[0], ScheduledTask)
        assert hasattr(tasks[0], "task_id")
        assert hasattr(tasks[0], "cron_expr")

    def test_seed_builtins_with_model_objects(self, facade, fstore):
        """seed_builtins accepts ScheduledTask model objects."""
        from memex.scheduler.builtins import get_builtin_tasks

        tasks = get_builtin_tasks()
        facade.scheduler.seed_builtins(tasks)
        loaded = facade.scheduler.list_tasks()
        assert len(loaded) >= len(tasks)


# ── Goal adapter: model-object API contract ───────────────────────────


class TestGoalAdapterContract:
    """Facade must accept Goal model objects for create/update."""

    @staticmethod
    def _make_goal(**kw) -> Goal:
        now = utcnow()
        defaults = dict(
            goal_id="g1",
            title="Ship v1",
            description="",
            status=GoalStatus.ACTIVE,
            priority=GoalPriority.MEDIUM,
            parent_id=None,
            blocked_by_goal_id=None,
            blocked_reason=None,
            failure_reason=None,
            deadline=None,
            metadata={},
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        defaults.update(kw)
        return Goal(**defaults)

    def test_create_goal_from_model(self, facade):
        goal = self._make_goal()
        facade.create_goal(goal)
        loaded = facade.get_goal("g1")
        assert loaded is not None
        assert loaded.title == "Ship v1"

    def test_update_goal_from_model(self, facade):
        goal = self._make_goal()
        facade.create_goal(goal)
        goal.title = "Ship v2"
        goal.status = GoalStatus.COMPLETED
        facade.update_goal(goal)
        loaded = facade.get_goal("g1")
        assert loaded.title == "Ship v2"
        assert loaded.status == GoalStatus.COMPLETED

    def test_list_goals_with_status_filter(self, facade):
        facade.create_goal(self._make_goal(goal_id="g1", status=GoalStatus.ACTIVE))
        facade.create_goal(self._make_goal(goal_id="g2", status=GoalStatus.COMPLETED))
        active = facade.list_goals(status=GoalStatus.ACTIVE)
        assert all(g.status == GoalStatus.ACTIVE for g in active)
        assert any(g.goal_id == "g1" for g in active)
