"""Tests for memex init and doctor (POST)."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

from memex.doctor import Check, DoctorReport, doctor, init, startup_post


class TestCheck:
    def test_icon_ok(self):
        assert Check("test", "ok").icon == "\u2713"

    def test_icon_warn(self):
        assert Check("test", "warn").icon == "!"

    def test_icon_fail(self):
        assert Check("test", "fail").icon == "\u2717"


class TestDoctorReport:
    def test_ok_when_no_fails(self):
        r = DoctorReport()
        r.add("a", "ok")
        r.add("b", "warn")
        assert r.ok

    def test_not_ok_when_fail(self):
        r = DoctorReport()
        r.add("a", "ok")
        r.add("b", "fail")
        assert not r.ok


class TestInit:
    def test_creates_structure(self, tmp_path):
        """Init creates .memex/, log/, .env, SOUL.md, CONSTITUTION.md."""
        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            actions = init(tmp_path)

        assert (tmp_path / ".memex").is_dir()
        assert (tmp_path / ".memex" / "fathom.db").exists()
        assert (tmp_path / ".env").exists()
        assert (tmp_path / "SOUL.md").exists()
        assert (tmp_path / "CONSTITUTION.md").exists()
        assert (tmp_path / ".gitignore").exists()
        assert len(actions) > 0

    def test_idempotent(self, tmp_path):
        """Running init twice doesn't fail or overwrite existing files."""
        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)
            # Write custom content to SOUL.md
            soul = tmp_path / "SOUL.md"
            soul.write_text("Custom soul")
            actions2 = init(tmp_path)

        # SOUL.md should not be overwritten
        assert soul.read_text() == "Custom soul"
        assert "SOUL.md already exists" in actions2

    def test_env_template_content(self, tmp_path):
        """The .env template has key sections."""
        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        env_content = (tmp_path / ".env").read_text()
        assert "ANTHROPIC_API_KEY" in env_content
        assert "MEMEX_STORE" in env_content
        assert "TELEGRAM_BOT_TOKEN" in env_content

    def test_gitignore_entries(self, tmp_path):
        """The .gitignore has .env, log/, .memex/ entries."""
        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        gi = (tmp_path / ".gitignore").read_text()
        assert ".env" in gi
        assert "log/" in gi
        assert ".memex/" in gi

    def test_existing_gitignore_appended(self, tmp_path):
        """Existing .gitignore gets Memex entries appended."""
        (tmp_path / ".gitignore").write_text("*.pyc\n")
        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        gi = (tmp_path / ".gitignore").read_text()
        assert "*.pyc" in gi
        assert ".env" in gi


class TestDoctor:
    def test_healthy_setup(self, tmp_path):
        """Doctor reports all ok on a properly initialized project."""
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
                "MEMEX_LOG_DIR": str(tmp_path / "log"),
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            report = doctor(tmp_path)

        fails = [c for c in report.checks if c.status == "fail"]
        assert report.ok, f"Failed checks: {[(c.name, c.detail) for c in fails]}"
        names = [c.name for c in report.checks]
        assert "Data directory" in names
        assert "Knowledge store" in names
        assert "LLM API key" in names
        assert "Governance" in names

    def test_doctor_reports_fathomdb_knowledge_store(self, tmp_path):
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            report = doctor(tmp_path)

        knowledge_check = next(c for c in report.checks if c.name == "Knowledge store")
        assert knowledge_check.status == "ok"
        assert "fathomdb" in knowledge_check.detail.lower()

    def test_doctor_reports_fathomdb_ok_when_present(self, tmp_path):
        """Doctor reports ok when fathom.db exists and is readable."""
        memex_dir = tmp_path / ".memex"
        memex_dir.mkdir(parents=True)
        fathom_path = memex_dir / "fathom.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(memex_dir / "memex.db"),
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            # Create a real fathomdb
            from memex.fathom_store import FathomStore

            store = FathomStore.open(str(fathom_path))
            store.close()
            report = doctor(tmp_path)

        knowledge_check = next(c for c in report.checks if c.name == "Knowledge store")
        assert knowledge_check.status == "ok"
        assert "fathomdb" in knowledge_check.detail

    def test_missing_data_dir_fails(self, tmp_path):
        """Doctor reports fail if .memex/ doesn't exist."""
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
            },
            clear=False,
        ):
            report = doctor(tmp_path)

        data_check = next(c for c in report.checks if c.name == "Data directory")
        assert data_check.status == "fail"

    @patch.dict(os.environ, {}, clear=True)
    def test_no_api_key_fails(self, tmp_path):
        """Doctor reports fail if no LLM API key is set."""
        os.environ["MEMEX_STORE"] = str(tmp_path / ".memex" / "memex.db")
        report = doctor(tmp_path)

        llm_check = next(c for c in report.checks if c.name == "LLM API key")
        assert llm_check.status == "fail"

    def test_governance_warn_when_missing(self, tmp_path):
        """Doctor warns if governance files are missing."""
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
            },
            clear=False,
        ):
            report = doctor(tmp_path)

        gov_check = next(c for c in report.checks if c.name == "Governance")
        assert gov_check.status == "warn"

    def test_telegram_warn_when_unconfigured(self, tmp_path):
        """Doctor warns (not fails) when Telegram is not configured."""
        env = {
            "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
        }
        # Remove telegram vars if present
        env_clear = {
            k: v
            for k, v in os.environ.items()
            if k not in ("TELEGRAM_BOT_TOKEN", "TELEGRAM_USER_ID")
        }
        env_clear.update(env)
        with patch.dict(os.environ, env_clear, clear=True):
            report = doctor(tmp_path)

        tg_check = next(c for c in report.checks if c.name == "Telegram")
        assert tg_check.status == "warn"

    def test_doctor_persists_diagnostics_to_agent_self_model(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        store_path = tmp_path / ".memex" / "memex.db"
        fathom_path = tmp_path / ".memex" / "fathom.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(store_path),
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            report = doctor(tmp_path)
            _fs = FathomStore.open(str(fathom_path))
            store = FathomMemexStore(_fs)
            try:
                model = store.load_agent_self_model()
            finally:
                store.close()

        assert report.ok
        assert model is not None
        assert model.last_diagnostics["ok"] is True
        assert len(model.last_diagnostics["checks"]) > 0

    def test_llm_proxy_check_probes_and_reports_ok(self, tmp_path):
        store_path = tmp_path / ".memex" / "memex.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(store_path),
                "AIRLOCK_PROXY_URL": "http://proxy.internal",
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            with patch(
                "urllib.request.urlopen", return_value=MagicMock()
            ) as mock_probe:
                report = doctor(tmp_path)
        proxy_check = next(c for c in report.checks if c.name == "LLM proxy")
        assert proxy_check.status == "ok"
        assert "reachable" in proxy_check.detail
        mock_probe.assert_called_once()

    def test_llm_proxy_check_warns_when_unreachable(self, tmp_path):
        store_path = tmp_path / ".memex" / "memex.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(store_path),
                "AIRLOCK_PROXY_URL": "http://proxy.internal",
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            with patch(
                "urllib.request.urlopen", side_effect=OSError("connection refused")
            ):
                report = doctor(tmp_path)
        proxy_check = next(c for c in report.checks if c.name == "LLM proxy")
        assert proxy_check.status == "warn"
        assert "unreachable" in proxy_check.detail
        assert report.ok  # warn does not fail the overall report

    def test_llm_proxy_check_warns_on_401(self, tmp_path):
        import urllib.error

        store_path = tmp_path / ".memex" / "memex.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(store_path),
                "AIRLOCK_PROXY_URL": "http://proxy.internal",
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            err = urllib.error.HTTPError(
                "http://proxy.internal/health", 401, "Unauthorized", {}, None
            )
            with patch("urllib.request.urlopen", side_effect=err):
                report = doctor(tmp_path)
        proxy_check = next(c for c in report.checks if c.name == "LLM proxy")
        assert proxy_check.status == "warn"
        assert "auth rejected" in proxy_check.detail

    def test_llm_proxy_check_ok_no_proxy_configured(self, tmp_path):
        store_path = tmp_path / ".memex" / "memex.db"
        env = {
            k: v
            for k, v in os.environ.items()
            if k not in ("AIRLOCK_PROXY_URL", "AIRLOCK_HOST", "AIRLOCK_PORT")
        }
        env["MEMEX_STORE"] = str(store_path)
        env["ANTHROPIC_API_KEY"] = "sk-test"
        with patch.dict(os.environ, env, clear=True):
            init(tmp_path)
            with patch(
                "urllib.request.urlopen", side_effect=AssertionError("should not probe")
            ) as mock_probe:
                report = doctor(tmp_path)
        proxy_check = next(c for c in report.checks if c.name == "LLM proxy")
        assert proxy_check.status == "ok"
        assert "direct" in proxy_check.detail
        mock_probe.assert_not_called()


class TestStartupPost:
    def test_logs_and_returns_report(self, tmp_path):
        """startup_post() returns a report and logs results."""
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(tmp_path / ".memex" / "memex.db"),
                "MEMEX_LOG_DIR": str(tmp_path / "log"),
                "ANTHROPIC_API_KEY": "sk-test",
            },
            clear=False,
        ):
            init(tmp_path)
            report = startup_post(tmp_path)

        assert isinstance(report, DoctorReport)
        assert report.ok


class TestCheckFathomdbVecProfile:
    def test_detail_includes_vec_profile(self, tmp_path):
        import os
        from memex.doctor import _check_fathomdb, init

        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        store_path = str(tmp_path / ".memex" / "memex.db")
        check = _check_fathomdb(store_path)
        assert check.status == "ok"
        assert "VecProfile KnowledgeItem:" in check.detail
        # On fathomdb 0.5.x the per-kind vec profile is unregistered until
        # Wave 3 bootstrap populates it; either the model identity or the
        # "unregistered" sentinel is acceptable here.
        assert (
            "BAAI/bge-small-en-v1.5" in check.detail or "unregistered" in check.detail
        )

    def test_detail_vec_profile_check_failed(self, tmp_path):
        import os
        from unittest.mock import patch
        from memex.doctor import _check_fathomdb, init

        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        store_path = str(tmp_path / ".memex" / "memex.db")
        with patch(
            "fathomdb._admin.AdminClient.get_vec_profile",
            side_effect=RuntimeError("db error"),
        ):
            check = _check_fathomdb(store_path)
        assert check.status == "ok"
        assert "VecProfile" in check.detail and "check failed" in check.detail

    def test_detail_includes_per_kind_vec_profiles(self, tmp_path):
        """doctor detail must list VecProfile per kind (KnowledgeItem, ConversationTurn)."""
        import os
        from memex.doctor import _check_fathomdb, init

        with patch.dict(
            os.environ,
            {"MEMEX_STORE": str(tmp_path / ".memex" / "memex.db")},
            clear=False,
        ):
            init(tmp_path)

        store_path = str(tmp_path / ".memex" / "memex.db")
        check = _check_fathomdb(store_path)
        assert check.status == "ok"
        assert "VecProfile KnowledgeItem:" in check.detail
        assert "VecProfile ConversationTurn:" in check.detail
