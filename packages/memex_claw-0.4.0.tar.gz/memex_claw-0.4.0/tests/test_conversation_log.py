"""Tests for durable conversation logging."""

from datetime import datetime
from typing import Literal

import pytest

from memex.models import ConversationTurn, InputClassification, InputClassificationType
from memex.session import add_turn, create_session
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


@pytest.fixture()
def store(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    s = FathomMemexStore(_fs)
    return s


class TestLogTurn:
    """Test that log_turn persists to conversation_log."""

    def test_log_turn_inserts_row(self, store):
        turn = ConversationTurn(
            role="human",
            content="hello world",
            timestamp=utcnow(),
        )
        store.log_turn("sess-1", turn)

        rows = store.query_conversation_log(session_id="sess-1")
        assert len(rows) == 1
        assert rows[0]["role"] == "human"
        assert rows[0]["content"] == "hello world"
        assert rows[0]["session_id"] == "sess-1"

    def test_log_turn_with_classification(self, store):
        classification = InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.9,
        )
        turn = ConversationTurn(
            role="human",
            content="hi",
            timestamp=utcnow(),
            classification=classification,
        )
        store.log_turn("sess-2", turn)

        rows = store.query_conversation_log(session_id="sess-2")
        assert len(rows) == 1

    def test_log_turn_multiple(self, store):
        for i in range(5):
            turn = ConversationTurn(
                role="human" if i % 2 == 0 else "assistant",
                content=f"message {i}",
                timestamp=utcnow(),
            )
            store.log_turn("sess-3", turn)

        rows = store.query_conversation_log(session_id="sess-3")
        assert len(rows) == 5

    def test_log_turn_never_raises(self, store):
        """log_turn swallows errors."""
        # Close the connection to force an error
        store.close()
        turn = ConversationTurn(
            role="human",
            content="should not crash",
            timestamp=utcnow(),
        )
        # Should not raise
        store.log_turn("sess-x", turn)


class TestQueryConversationLog:
    """Test query_conversation_log filters."""

    def _insert_turns(self, store):
        data: list[
            tuple[str, Literal["human", "assistant", "tool_result", "system"], str, str]
        ] = [
            ("sess-a", "human", "q1", "2025-01-01T10:00:00"),
            ("sess-a", "assistant", "a1", "2025-01-01T10:00:01"),
            ("sess-a", "tool_result", "[search] ok", "2025-01-01T10:00:02"),
            ("sess-b", "human", "q2", "2025-01-15T12:00:00"),
            ("sess-b", "assistant", "a2", "2025-01-15T12:00:01"),
        ]
        for sid, role, content, ts in data:
            turn = ConversationTurn(
                role=role,
                content=content,
                timestamp=datetime.fromisoformat(ts),
            )
            store.log_turn(sid, turn)

    def test_filter_by_session(self, store):
        self._insert_turns(store)
        rows = store.query_conversation_log(session_id="sess-a")
        assert len(rows) == 3
        assert all(r["session_id"] == "sess-a" for r in rows)

    def test_filter_by_role(self, store):
        self._insert_turns(store)
        rows = store.query_conversation_log(role="human")
        assert len(rows) == 2
        assert all(r["role"] == "human" for r in rows)

    def test_filter_by_since(self, store):
        self._insert_turns(store)
        rows = store.query_conversation_log(
            since=datetime.fromisoformat("2025-01-10T00:00:00")
        )
        assert len(rows) == 2  # Only sess-b entries

    def test_limit(self, store):
        self._insert_turns(store)
        rows = store.query_conversation_log(limit=2)
        assert len(rows) == 2

    def test_no_results(self, store):
        rows = store.query_conversation_log(session_id="nonexistent")
        assert rows == []


class TestAddTurnWithStore:
    """Test that add_turn writes to conversation_log when store is provided."""

    def test_add_turn_logs_to_db(self, store):
        session = create_session()
        add_turn(session, "human", "test input", store=store)

        rows = store.query_conversation_log(session_id=session.session_id)
        assert len(rows) == 1
        assert rows[0]["role"] == "human"
        assert rows[0]["content"] == "test input"

    def test_add_turn_without_store_still_works(self):
        """add_turn without store should work as before (no logging)."""
        session = create_session()
        add_turn(session, "human", "test input")
        assert len(session.conversation_history) == 1

    def test_add_turn_logs_all_roles(self, store):
        session = create_session()
        add_turn(session, "human", "question", store=store)
        add_turn(session, "assistant", "answer", store=store)
        add_turn(session, "tool_result", "[tool] result", store=store)
        add_turn(session, "system", "proactive note", store=store)

        rows = store.query_conversation_log(session_id=session.session_id)
        assert len(rows) == 4
        roles = {r["role"] for r in rows}
        assert roles == {"human", "assistant", "tool_result", "system"}

    def test_add_turn_db_failure_does_not_crash(self, store):
        """If logging fails, add_turn still updates in-memory session."""
        session = create_session()
        store.close()  # Force DB error
        add_turn(session, "human", "still works", store=store)
        assert len(session.conversation_history) == 1
        assert session.conversation_history[0].content == "still works"
