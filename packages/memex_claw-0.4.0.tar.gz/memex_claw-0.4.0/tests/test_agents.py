"""Tests for SubAgentManager."""

import threading

from memex.agents import SubAgentManager
from memex.runtime_state import RuntimeStateRegistry


def test_spawn_creates_agent():
    mgr = SubAgentManager()
    agent = mgr.spawn("What is 2+2?", "sess-1")
    assert agent.agent_id == "qq-1"
    assert agent.status == "running"
    assert agent.label == "What is 2+2?"
    assert agent.session_id == "sess-1"


def test_spawn_increments_counter():
    mgr = SubAgentManager()
    a1 = mgr.spawn("q1", "s1")
    a2 = mgr.spawn("q2", "s2")
    assert a1.agent_id == "qq-1"
    assert a2.agent_id == "qq-2"


def test_spawn_truncates_long_label():
    mgr = SubAgentManager()
    long_q = "x" * 100
    agent = mgr.spawn(long_q, "s1")
    assert len(agent.label) == 63  # 60 + "..."
    assert agent.label.endswith("...")


def test_spawn_raises_when_full():
    mgr = SubAgentManager()
    mgr.spawn("q1", "s1")
    mgr.spawn("q2", "s2")
    mgr.spawn("q3", "s3")
    try:
        mgr.spawn("q4", "s4")
        assert False, "Should have raised RuntimeError"
    except RuntimeError as e:
        assert "Max 3" in str(e)


def test_complete_sets_response():
    mgr = SubAgentManager()
    agent = mgr.spawn("q1", "s1")
    mgr.complete("qq-1", "The answer is 4")
    assert agent.status == "done"
    assert agent.response == "The answer is 4"
    assert agent.finished_at is not None


def test_fail_sets_error():
    mgr = SubAgentManager()
    agent = mgr.spawn("q1", "s1")
    mgr.fail("qq-1", "LLM error")
    assert agent.status == "error"
    assert agent.error == "LLM error"


def test_cancel_sets_event():
    mgr = SubAgentManager()
    agent = mgr.spawn("q1", "s1")
    assert mgr.cancel("qq-1") is True
    assert agent.status == "cancelled"
    assert agent.cancel_event.is_set()


def test_cancel_nonexistent_returns_false():
    mgr = SubAgentManager()
    assert mgr.cancel("qq-99") is False


def test_cancel_already_done_returns_false():
    mgr = SubAgentManager()
    mgr.spawn("q1", "s1")
    mgr.complete("qq-1", "done")
    assert mgr.cancel("qq-1") is False


def test_list_agents():
    mgr = SubAgentManager()
    mgr.spawn("q1", "s1")
    mgr.spawn("q2", "s2")
    agents = mgr.list_agents()
    assert len(agents) == 2


def test_running_count():
    mgr = SubAgentManager()
    mgr.spawn("q1", "s1")
    mgr.spawn("q2", "s2")
    assert mgr.running_count == 2
    mgr.complete("qq-1", "done")
    assert mgr.running_count == 1


def test_spawn_after_complete_allows_new():
    """Completing an agent frees a slot."""
    mgr = SubAgentManager()
    mgr.spawn("q1", "s1")
    mgr.spawn("q2", "s2")
    mgr.spawn("q3", "s3")
    mgr.complete("qq-1", "done")
    # Should not raise — only 2 running now
    a4 = mgr.spawn("q4", "s4")
    assert a4.agent_id == "qq-4"


def test_elapsed_display():
    mgr = SubAgentManager()
    agent = mgr.spawn("q1", "s1")
    # elapsed should be very small
    display = agent.elapsed_display
    assert "ms" in display or "s" in display


def test_thread_safety():
    """Spawn from multiple threads without errors."""
    mgr = SubAgentManager()
    errors = []

    def worker(n):
        try:
            mgr.spawn(f"question-{n}", f"sess-{n}")
        except RuntimeError:
            pass  # expected when full
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    assert mgr.running_count <= SubAgentManager.MAX_AGENTS


def test_runtime_registry_sync():
    runtime_registry = RuntimeStateRegistry()
    mgr = SubAgentManager(runtime_registry=runtime_registry)
    mgr.spawn("q1", "s1")
    snapshot = runtime_registry.snapshot()
    assert snapshot["subagents"]["running_count"] == 1
    mgr.complete("qq-1", "done")
    snapshot = runtime_registry.snapshot()
    assert snapshot["subagents"]["running_count"] == 0
    assert snapshot["subagents"]["agents"][0]["status"] == "done"
