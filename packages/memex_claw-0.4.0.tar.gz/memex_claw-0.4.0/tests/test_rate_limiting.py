"""Tests for rate limiting, circuit breaker, and cost guard."""

import time

from memex.interfaces.rate_limiting import (
    CallerRateLimits,
    CircuitBreaker,
    CostGuard,
    ToolLimits,
)


class TestCallerRateLimits:
    def test_allows_within_limit(self):
        rl = CallerRateLimits(max_tokens=5, refill_rate=0.0)
        for _ in range(5):
            assert rl.allow() is True

    def test_blocks_after_exhaustion(self):
        rl = CallerRateLimits(max_tokens=2, refill_rate=0.0)
        assert rl.allow() is True
        assert rl.allow() is True
        assert rl.allow() is False

    def test_refills_over_time(self):
        rl = CallerRateLimits(max_tokens=2, refill_rate=1000.0)  # Very fast refill
        rl.allow()
        rl.allow()
        time.sleep(0.01)
        assert rl.allow() is True


class TestCircuitBreaker:
    def test_closed_by_default(self):
        cb = CircuitBreaker(failure_threshold=3)
        assert cb.is_open is False

    def test_opens_after_threshold(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure()
        cb.record_failure()
        cb.record_failure()
        assert cb.is_open is True

    def test_success_resets(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure()
        cb.record_failure()
        cb.record_success()
        cb.record_failure()
        assert cb.is_open is False

    def test_auto_resets_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=1, reset_timeout=0.01)
        cb.record_failure()
        assert cb.is_open is True
        time.sleep(0.02)
        assert cb.is_open is False


class TestCostGuard:
    def test_within_budget(self):
        cg = CostGuard(max_cost_per_hour_usd=10.0)
        assert cg.check(5.0) is True

    def test_exceeds_budget(self):
        cg = CostGuard(max_cost_per_hour_usd=1.0)
        cg.record(0.8)
        assert cg.check(0.5) is False

    def test_tracks_costs(self):
        cg = CostGuard(max_cost_per_hour_usd=10.0)
        cg.record(3.0)
        cg.record(4.0)
        assert cg.current_hour_cost == 7.0


class TestToolLimits:
    def test_default_weight(self):
        tl = ToolLimits()
        assert tl.get_weight("anything") == 1.0

    def test_custom_weight(self):
        tl = ToolLimits(cost_weights={"expensive_tool": 5.0})
        assert tl.get_weight("expensive_tool") == 5.0
        assert tl.get_weight("cheap_tool") == 1.0
