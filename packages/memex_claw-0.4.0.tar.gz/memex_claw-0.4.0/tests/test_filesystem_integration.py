"""Tests for filesystem MCP server integration — read/write capability separation."""

from __future__ import annotations

from unittest.mock import MagicMock

from memex.integrations.filesystem import FilesystemIntegration
from memex.models import ToolDefinition


def _make_tool(name: str) -> ToolDefinition:
    return ToolDefinition(
        name=name,
        description=f"Test {name}",
        source="mcp:filesystem",
        required_capability="filesystem.read",  # default from MCP discovery
    )


class TestToolDefinitions:
    def test_read_tools_get_read_capability(self):
        client = MagicMock()
        client.discovered_tools = [
            _make_tool("read_file"),
            _make_tool("list_directory"),
            _make_tool("directory_tree"),
            _make_tool("search_files"),
            _make_tool("get_file_info"),
            _make_tool("read_multiple_files"),
            _make_tool("list_allowed_directories"),
        ]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        for t in tools:
            assert t.required_capability == "filesystem.read", (
                f"{t.name} should have filesystem.read"
            )

    def test_write_tools_get_write_capability(self):
        client = MagicMock()
        client.discovered_tools = [
            _make_tool("write_file"),
            _make_tool("edit_file"),
            _make_tool("create_directory"),
            _make_tool("move_file"),
        ]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        for t in tools:
            assert t.required_capability == "filesystem.write", (
                f"{t.name} should have filesystem.write"
            )

    def test_write_false_excludes_write_tools(self):
        client = MagicMock()
        client.discovered_tools = [
            _make_tool("read_file"),
            _make_tool("write_file"),
            _make_tool("edit_file"),
            _make_tool("list_directory"),
            _make_tool("create_directory"),
            _make_tool("move_file"),
        ]
        integration = FilesystemIntegration(client, write=False)
        tools = integration.get_tool_definitions()

        tool_names = {t.name for t in tools}
        assert tool_names == {"read_file", "list_directory"}
        for t in tools:
            assert t.required_capability == "filesystem.read"

    def test_write_default_is_false(self):
        client = MagicMock()
        client.discovered_tools = [
            _make_tool("read_file"),
            _make_tool("write_file"),
        ]
        integration = FilesystemIntegration(client)
        tools = integration.get_tool_definitions()

        assert len(tools) == 1
        assert tools[0].name == "read_file"

    def test_all_tools_have_keywords(self):
        client = MagicMock()
        client.discovered_tools = [
            _make_tool("read_file"),
            _make_tool("write_file"),
            _make_tool("list_directory"),
            _make_tool("edit_file"),
            _make_tool("search_files"),
        ]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        for t in tools:
            assert len(t.keywords) > 0, f"{t.name} should have keywords"

    def test_source_preserved(self):
        """Source stays as mcp:filesystem from the discovered tools."""
        client = MagicMock()
        client.discovered_tools = [_make_tool("read_file")]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        assert tools[0].source == "mcp:filesystem"

    def test_empty_tools(self):
        client = MagicMock()
        client.discovered_tools = []
        integration = FilesystemIntegration(client, write=True)
        assert integration.get_tool_definitions() == []

    def test_unknown_tool_gets_read_capability(self):
        """Tools not in the write set default to filesystem.read."""
        client = MagicMock()
        client.discovered_tools = [_make_tool("some_future_tool")]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        assert tools[0].required_capability == "filesystem.read"

    def test_full_server_tool_set_write_true(self):
        """Simulate the complete set of 11 tools with write=True."""
        all_tool_names = [
            "read_file",
            "read_multiple_files",
            "write_file",
            "edit_file",
            "create_directory",
            "list_directory",
            "directory_tree",
            "move_file",
            "search_files",
            "get_file_info",
            "list_allowed_directories",
        ]
        client = MagicMock()
        client.discovered_tools = [_make_tool(n) for n in all_tool_names]
        integration = FilesystemIntegration(client, write=True)
        tools = integration.get_tool_definitions()

        assert len(tools) == 11

        read_tools = [t for t in tools if t.required_capability == "filesystem.read"]
        write_tools = [t for t in tools if t.required_capability == "filesystem.write"]

        assert len(write_tools) == 4
        assert {t.name for t in write_tools} == {
            "write_file",
            "edit_file",
            "create_directory",
            "move_file",
        }
        assert len(read_tools) == 7

    def test_full_server_tool_set_write_false(self):
        """Simulate the complete set of 11 tools with write=False — only 7 read tools."""
        all_tool_names = [
            "read_file",
            "read_multiple_files",
            "write_file",
            "edit_file",
            "create_directory",
            "list_directory",
            "directory_tree",
            "move_file",
            "search_files",
            "get_file_info",
            "list_allowed_directories",
        ]
        client = MagicMock()
        client.discovered_tools = [_make_tool(n) for n in all_tool_names]
        integration = FilesystemIntegration(client, write=False)
        tools = integration.get_tool_definitions()

        assert len(tools) == 7
        for t in tools:
            assert t.required_capability == "filesystem.read"
        assert {t.name for t in tools} == {
            "read_file",
            "read_multiple_files",
            "list_directory",
            "directory_tree",
            "search_files",
            "get_file_info",
            "list_allowed_directories",
        }
