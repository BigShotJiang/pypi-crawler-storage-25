"""Tests for self-improvement tiers 1-3."""

from __future__ import annotations

from pathlib import Path

from memex.self_improvement.observations import (
    ObservationStore,
    detect_patterns,
)
from memex.self_improvement.config_tuning import (
    AllowedParameter,
    ConfigProposal,
    load_allowed_proposals,
    validate_proposal,
)
from memex.self_improvement.capabilities import (
    generate_proposal,
    proposal_to_document,
)


# ---------------------------------------------------------------------------
# Tier 1: Observations
# ---------------------------------------------------------------------------


class TestObservationStore:
    def test_record_new(self):
        store = ObservationStore()
        obs = store.record("Test pattern", category="test")
        assert obs.pattern == "Test pattern"
        assert obs.frequency == 1

    def test_record_merges_duplicates(self):
        store = ObservationStore()
        store.record("Repeated pattern")
        obs = store.record("Repeated pattern")
        assert obs.frequency == 2

    def test_list_observations(self):
        store = ObservationStore()
        store.record("A")
        store.record("B")
        store.record("B")
        obs = store.list_observations()
        assert len(obs) == 2
        assert obs[0].pattern == "B"  # Higher frequency first

    def test_list_min_frequency(self):
        store = ObservationStore()
        store.record("Rare")
        store.record("Common")
        store.record("Common")
        store.record("Common")
        obs = store.list_observations(min_frequency=2)
        assert len(obs) == 1
        assert obs[0].pattern == "Common"

    def test_serialization_roundtrip(self):
        store = ObservationStore()
        store.record("Pattern A", evidence="s1", category="test")
        store.record("Pattern A", evidence="s2")
        data = store.to_dict()
        restored = ObservationStore.from_dict(data)
        assert len(restored.list_observations()) == 1
        assert restored.list_observations()[0].frequency == 2


class TestDetectPatterns:
    def test_detects_tool_failures(self):
        store = ObservationStore()
        detect_patterns(
            {"turn_count": 5, "last_tool_failures": ["err1"], "session_id": "s1"},
            store,
        )
        obs = store.list_observations()
        assert any("Tool failures" in o.pattern for o in obs)

    def test_detects_short_session(self):
        store = ObservationStore()
        detect_patterns({"turn_count": 2, "session_id": "s1"}, store)
        obs = store.list_observations()
        assert any("short session" in o.pattern.lower() for o in obs)

    def test_detects_long_session(self):
        store = ObservationStore()
        detect_patterns({"turn_count": 35, "session_id": "s1"}, store)
        obs = store.list_observations()
        assert any("long session" in o.pattern.lower() for o in obs)

    def test_no_patterns_for_normal_session(self):
        store = ObservationStore()
        result = detect_patterns({"turn_count": 10, "session_id": "s1"}, store)
        assert result == []


# ---------------------------------------------------------------------------
# Tier 2: Config Tuning
# ---------------------------------------------------------------------------


class TestConfigTuning:
    def test_validate_valid_proposal(self):
        allowed = [
            AllowedParameter(name="window_size", type="int", min_value=5, max_value=50)
        ]
        proposal = ConfigProposal(
            parameter="window_size",
            current_value=20,
            proposed_value=30,
            reason="Better context retention",
        )
        assert validate_proposal(proposal, allowed) is None

    def test_validate_out_of_range(self):
        allowed = [
            AllowedParameter(name="window_size", type="int", min_value=5, max_value=50)
        ]
        proposal = ConfigProposal(
            parameter="window_size",
            current_value=20,
            proposed_value=100,
            reason="Too high",
        )
        err = validate_proposal(proposal, allowed)
        assert err is not None
        assert "above maximum" in err

    def test_validate_not_in_allowlist(self):
        allowed = [AllowedParameter(name="window_size", type="int")]
        proposal = ConfigProposal(
            parameter="secret_key",
            current_value="old",
            proposed_value="new",
            reason="Nope",
        )
        err = validate_proposal(proposal, allowed)
        assert "not in the allowlist" in err

    def test_validate_allowed_values(self):
        allowed = [
            AllowedParameter(
                name="mode",
                type="str",
                allowed_values=["normal", "deep_work"],
            )
        ]
        proposal = ConfigProposal(
            parameter="mode",
            current_value="normal",
            proposed_value="evil_mode",
            reason="I want to be evil",
        )
        err = validate_proposal(proposal, allowed)
        assert "not in allowed values" in err

    def test_load_missing_file(self):
        result = load_allowed_proposals(Path("/nonexistent/file.yaml"))
        assert result == []


# ---------------------------------------------------------------------------
# Tier 3: Capabilities
# ---------------------------------------------------------------------------


class TestCapabilities:
    def test_generate_proposal(self):
        p = generate_proposal(
            "Email integration",
            "Add ability to send/receive emails",
            rationale="User frequently mentions email tasks",
            category="tool_integration",
            complexity="high",
        )
        assert p.title == "Email integration"
        assert p.estimated_complexity == "high"
        assert p.status == "proposed"

    def test_proposal_to_document(self):
        p = generate_proposal("Test", "Description", rationale="Reason")
        doc = proposal_to_document(p)
        assert "# Capability Proposal: Test" in doc
        assert "Description" in doc
        assert "Reason" in doc

    def test_proposal_document_without_rationale(self):
        p = generate_proposal("Minimal", "Just a desc")
        doc = proposal_to_document(p)
        assert "Rationale" not in doc
