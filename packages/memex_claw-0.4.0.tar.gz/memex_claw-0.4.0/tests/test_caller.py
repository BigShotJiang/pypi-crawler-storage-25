"""Tests for CallerContext."""

from memex.interfaces.caller import CallerContext


def test_owner_factory():
    ctx = CallerContext.owner("cli", "sess-1", user_id="alice")
    assert ctx.interface == "cli"
    assert ctx.session_id == "sess-1"
    assert ctx.user_id == "alice"
    assert ctx.created_at is not None


def test_frozen():
    ctx = CallerContext.owner("cli", "sess-1")
    try:
        ctx.interface = "tui"  # type: ignore[misc]
        assert False, "Should be frozen"
    except AttributeError:
        pass


def test_default_user_id():
    ctx = CallerContext.owner("telegram", "sess-2")
    assert ctx.user_id == ""
