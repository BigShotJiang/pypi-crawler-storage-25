"""Tests for transcribe_meeting() and orchestrate_transcription() with mocked whisper."""

from unittest.mock import MagicMock, patch

import pytest

pytest.importorskip("soundfile", reason="soundfile not installed (optional dep)")

from memex.meetings.models import (
    MeetingRecord,
    MeetingRecording,
    MeetingSegment,
    MeetingState,
)
from memex.meetings.transcribe import (
    TranscriptionResult,
    _format_body,
    _format_timestamp,
    _maybe_send_telegram_completion,
    orchestrate_transcription,
    transcribe_meeting,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fw_segment(
    start: float,
    end: float,
    text: str,
    avg_logprob: float = -0.3,
    no_speech_prob: float = 0.05,
):
    """Create a mock faster-whisper segment."""
    seg = MagicMock()
    seg.start = start
    seg.end = end
    seg.text = text
    seg.avg_logprob = avg_logprob
    seg.no_speech_prob = no_speech_prob
    return seg


def _make_fw_info(language: str = "en", duration: float = 120.0):
    """Create a mock faster-whisper info object."""
    info = MagicMock()
    info.language = language
    info.duration = duration
    return info


def _canned_result(quality: float = 0.8) -> TranscriptionResult:
    """Return a canned TranscriptionResult for orchestration tests."""
    return TranscriptionResult(
        segments=[
            MeetingSegment(speaker="Alice", start=0.0, end=5.0, text="Hello there."),
            MeetingSegment(speaker="Bob", start=5.0, end=10.0, text="Hi Alice."),
        ],
        speaker_count=2,
        language="en",
        model="large-v2",
        duration_seconds=120.0,
        quality=quality,
        tried_vad_thresholds=(0.1,),
    )


def _make_meeting_record(
    meeting_id: str = "mtg-1",
    audio_path: str = "/tmp/test.wav",
    title: str = "Test Meeting",
    state: MeetingState = MeetingState.RECORDED,
) -> MeetingRecord:
    now = utcnow()
    return MeetingRecord(
        meeting_id=meeting_id,
        state=state,
        title=title,
        audio_path=audio_path,
        started_at=now,
        stopped_at=now,
        created_at=now,
        updated_at=now,
    )


def _make_recording(
    recording_id: str,
    meeting_id: str = "mtg-1",
    sequence_number: int = 1,
    state: MeetingState = MeetingState.RECORDED,
    audio_path: str = "/tmp/test.wav",
    *,
    segments: list[MeetingSegment] | None = None,
    duration_seconds: float = 120.0,
    language: str = "en",
    whisper_model: str = "large-v2",
) -> MeetingRecording:
    now = utcnow()
    return MeetingRecording(
        recording_id=recording_id,
        meeting_id=meeting_id,
        sequence_number=sequence_number,
        state=state,
        audio_path=audio_path,
        duration_seconds=duration_seconds,
        started_at=now,
        stopped_at=now,
        transcribed_at=now
        if state in (MeetingState.TRANSCRIBED, MeetingState.INGESTED)
        else None,
        ingested_at=now if state == MeetingState.INGESTED else None,
        segments=segments or [],
        speaker_count=len({s.speaker for s in segments or []}),
        language=language,
        whisper_model=whisper_model,
        created_at=now,
        updated_at=now,
    )


# ---------------------------------------------------------------------------
# transcribe_meeting tests
# ---------------------------------------------------------------------------


def test_transcribe_meeting_basic(tmp_path):
    """Mock STT backend, verify TranscriptionResult with segments."""
    from memex.meetings.stt_backend import STTResult, STTSegment

    audio_file = tmp_path / "test.wav"
    audio_file.write_bytes(b"\x00" * 100)

    mock_backend = MagicMock()
    mock_backend.name = "mock"
    mock_backend.transcribe.return_value = STTResult(
        segments=[
            STTSegment(start=0.0, end=5.0, text="Hello there.", confidence=0.9),
            STTSegment(start=5.0, end=10.0, text="How are you?", confidence=0.85),
        ],
        language="en",
        duration_seconds=10.0,
        backend_name="mock",
        quality=0.875,
    )

    with patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend):
        result = transcribe_meeting(audio_file, diarize=False)

    assert isinstance(result, TranscriptionResult)
    assert len(result.segments) == 2
    assert result.segments[0].text == "Hello there."
    assert result.segments[1].text == "How are you?"
    assert result.language == "en"
    assert result.duration_seconds == 10.0
    assert result.speaker_count == 1  # all SPEAKER when diarize=False


def test_transcribe_meeting_no_diarize(tmp_path):
    """With diarize=False, all segments have speaker='SPEAKER'."""
    from memex.meetings.stt_backend import STTResult, STTSegment

    audio_file = tmp_path / "test.wav"
    audio_file.write_bytes(b"\x00" * 100)

    mock_backend = MagicMock()
    mock_backend.name = "mock"
    mock_backend.transcribe.return_value = STTResult(
        segments=[
            STTSegment(start=0.0, end=3.0, text="First segment.", confidence=0.9),
            STTSegment(start=3.0, end=6.0, text="Second segment.", confidence=0.85),
            STTSegment(start=6.0, end=9.0, text="Third segment.", confidence=0.8),
        ],
        language="fr",
        duration_seconds=9.0,
        backend_name="mock",
        quality=0.85,
    )

    with patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend):
        result = transcribe_meeting(audio_file, diarize=False)

    assert all(seg.speaker == "SPEAKER" for seg in result.segments)
    assert result.language == "fr"


def test_transcribe_meeting_empty(tmp_path):
    """Mock backend returns no segments, result has empty segments list."""
    from memex.meetings.stt_backend import STTResult

    audio_file = tmp_path / "test.wav"
    audio_file.write_bytes(b"\x00" * 100)

    mock_backend = MagicMock()
    mock_backend.name = "mock"
    mock_backend.transcribe.return_value = STTResult(
        segments=[],
        language="en",
        duration_seconds=0.0,
        backend_name="mock",
        quality=0.0,
    )

    with patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend):
        result = transcribe_meeting(audio_file, diarize=False)

    assert result.segments == []
    assert result.speaker_count == 0
    assert result.duration_seconds == 0.0


def test_transcribe_missing_file():
    """Non-existent file raises FileNotFoundError."""
    mock_backend = MagicMock()
    mock_backend.name = "mock"

    with patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend):
        with pytest.raises(FileNotFoundError, match="Audio file not found"):
            transcribe_meeting("/nonexistent/audio.wav", diarize=False)


def test_transcribe_no_backend(tmp_path):
    """No STT backend available raises RuntimeError."""
    audio_file = tmp_path / "test.wav"
    audio_file.write_bytes(b"\x00" * 100)
    with patch(
        "memex.meetings.stt_backend.get_backend",
        side_effect=RuntimeError("No STT backend available"),
    ):
        with pytest.raises(RuntimeError, match="No STT backend"):
            transcribe_meeting(audio_file, diarize=False)


# ---------------------------------------------------------------------------
# _format_body / _format_timestamp
# ---------------------------------------------------------------------------


def test_format_timestamp():
    """Test _format_timestamp with various inputs."""
    # Seconds only
    assert _format_timestamp(0.0) == "0:00"
    assert _format_timestamp(5.0) == "0:05"
    assert _format_timestamp(30.0) == "0:30"
    assert _format_timestamp(59.0) == "0:59"

    # Minutes
    assert _format_timestamp(60.0) == "1:00"
    assert _format_timestamp(90.0) == "1:30"
    assert _format_timestamp(125.0) == "2:05"

    # Hours
    assert _format_timestamp(3600.0) == "1:00:00"
    assert _format_timestamp(3661.0) == "1:01:01"
    assert _format_timestamp(7384.0) == "2:03:04"


def test_format_body():
    """Test _format_body with known segments."""
    segments = [
        MeetingSegment(speaker="Alice", start=0.0, end=5.5, text="Hello there."),
        MeetingSegment(speaker="Bob", start=65.0, end=70.0, text="Hi Alice."),
        MeetingSegment(speaker="Alice", start=3661.0, end=3700.0, text="Final point."),
    ]
    body = _format_body(segments)

    lines = body.split("\n")
    assert len(lines) == 3
    assert lines[0] == "[Alice] (0:00-0:05): Hello there."
    assert lines[1] == "[Bob] (1:05-1:10): Hi Alice."
    assert lines[2] == "[Alice] (1:01:01-1:01:40): Final point."


# ---------------------------------------------------------------------------
# orchestrate_transcription tests
# ---------------------------------------------------------------------------


def test_orchestrate_transcription_success(tmp_path):
    """Mock transcribe_meeting, verify state transitions to INGESTED and item is created."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="recorded")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/test.wav")

    canned = _canned_result()

    with patch("memex.meetings.transcribe.transcribe_meeting", return_value=canned):
        item = orchestrate_transcription(
            "mtg-1",
            meeting_store=ms,
            content_store=cs,
        )

    assert item is not None
    assert item.title == "Test Meeting"

    updated = ms.get_meeting("mtg-1")
    assert updated is not None
    assert updated.state == MeetingState.INGESTED
    assert updated.speaker_count == 2
    assert updated.language == "en"
    assert updated.duration_seconds == 120.0
    assert len(updated.segments) == 2
    assert updated.item_id == item.item_id
    assert updated.ingested_at is not None

    store.close()


def test_orchestrate_transcription_failure(tmp_path):
    """Mock transcribe_meeting to raise, verify state=FAILED and error stored."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="recorded")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/test.wav")

    with patch(
        "memex.meetings.transcribe.transcribe_meeting",
        side_effect=RuntimeError("whisper crashed"),
    ):
        with pytest.raises(RuntimeError, match="whisper crashed"):
            orchestrate_transcription(
                "mtg-1",
                meeting_store=ms,
                content_store=cs,
            )

    updated = ms.get_meeting("mtg-1")
    assert updated is not None
    assert updated.state == MeetingState.FAILED
    assert "whisper crashed" in updated.error

    store.close()


def test_orchestrate_transcription_publishes_transcribing_event(tmp_path):
    """Verify transcription start emits MeetingStateChanged(transcribing)."""
    from memex.event_bus import EventBus
    from memex.events import MeetingStateChanged

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="recorded")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/test.wav")

    canned = _canned_result()
    bus = EventBus()
    bus.start()
    received = []

    def handler(event):
        received.append(event)

    bus.subscribe(MeetingStateChanged, handler)

    with (
        patch("memex.event_bus.get_bus", return_value=bus),
        patch("memex.meetings.transcribe.transcribe_meeting", return_value=canned),
    ):
        orchestrate_transcription(
            "mtg-1",
            meeting_store=ms,
            content_store=cs,
        )

    bus.stop()
    assert received
    assert received[0].meeting_id == "mtg-1"
    assert received[0].title == "Test Meeting"
    assert received[0].state == "transcribing"

    store.close()


def test_orchestrate_notification_on_success(tmp_path):
    """Verify NotificationRouter.notify called on success."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="recorded")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/test.wav")

    canned = _canned_result()

    ns = store.notifications

    with patch("memex.meetings.transcribe.transcribe_meeting", return_value=canned):
        orchestrate_transcription(
            "mtg-1",
            meeting_store=ms,
            content_store=cs,
            notification_store=ns,
        )

    pending = ns.list_pending()
    assert len(pending) == 1
    assert "Test Meeting" in pending[0].title
    assert "transcribed" in pending[0].title.lower()
    assert pending[0].source == "meetings"

    store.close()


def test_orchestrate_notification_on_failure(tmp_path):
    """Verify notification on failure."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="recorded")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/test.wav")

    ns = store.notifications

    with patch(
        "memex.meetings.transcribe.transcribe_meeting",
        side_effect=RuntimeError("model not found"),
    ):
        with pytest.raises(RuntimeError):
            orchestrate_transcription(
                "mtg-1",
                meeting_store=ms,
                content_store=cs,
                notification_store=ns,
            )

    pending = ns.list_pending()
    assert len(pending) == 1
    assert "failed" in pending[0].title.lower()
    assert pending[0].source == "meetings"

    store.close()


def test_orchestrate_transcription_retry_selected_recording_only(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content
    canned = _canned_result()
    existing_segments = [
        MeetingSegment(speaker="Carol", start=0.0, end=4.0, text="Existing segment."),
    ]
    now = utcnow()
    record = MeetingRecord(
        meeting_id="mtg-1",
        state=MeetingState.FAILED,
        title="Test Meeting",
        recordings=[
            _make_recording(
                "rec-1",
                sequence_number=1,
                state=MeetingState.INGESTED,
                audio_path="/tmp/one.wav",
                segments=existing_segments,
                duration_seconds=4.0,
            ),
            _make_recording(
                "rec-2",
                sequence_number=2,
                state=MeetingState.FAILED,
                audio_path="/tmp/two.wav",
                segments=[],
                duration_seconds=6.0,
            ),
        ],
        created_at=now,
        updated_at=now,
    )
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="ingested")
    _fs.meetings.update_recording(
        "rec-1",
        audio_path="/tmp/one.wav",
        duration_seconds=4.0,
        segments=[
            {"speaker": "Carol", "start": 0.0, "end": 4.0, "text": "Existing segment."}
        ],
    )
    _fs.meetings.create_recording("rec-2", "mtg-1", state="failed", sequence_number=2)
    _fs.meetings.update_recording("rec-2", audio_path="/tmp/two.wav")

    with patch(
        "memex.meetings.transcribe.transcribe_meeting", return_value=canned
    ) as mock_transcribe:
        item = orchestrate_transcription(
            "mtg-1",
            meeting_store=ms,
            content_store=cs,
            recording_id="rec-2",
        )

    assert item is not None
    assert mock_transcribe.call_count == 1
    assert mock_transcribe.call_args.args[0] == "/tmp/two.wav"

    updated = ms.get_meeting("mtg-1")
    retried = ms.get_recording("rec-2")
    untouched = ms.get_recording("rec-1")
    assert updated is not None
    assert retried is not None
    assert untouched is not None
    assert updated.state == MeetingState.INGESTED
    assert retried.state == MeetingState.INGESTED
    assert untouched.state == MeetingState.INGESTED
    assert len(updated.segments) == 3
    store.close()


def test_retry_failure_does_not_hide_existing_ingested_meeting(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content
    existing_segments = [
        MeetingSegment(speaker="Carol", start=0.0, end=4.0, text="Existing segment."),
    ]
    now = utcnow()
    record = MeetingRecord(
        meeting_id="mtg-1",
        state=MeetingState.INGESTED,
        title="Test Meeting",
        item_id="item-1",
        recordings=[
            _make_recording(
                "rec-1",
                sequence_number=1,
                state=MeetingState.INGESTED,
                audio_path="/tmp/one.wav",
                segments=existing_segments,
                duration_seconds=4.0,
            ),
            _make_recording(
                "rec-2",
                sequence_number=2,
                state=MeetingState.FAILED,
                audio_path="/tmp/two.wav",
                segments=[],
                duration_seconds=6.0,
            ),
        ],
        created_at=now,
        updated_at=now,
    )
    ms.create_meeting(record)
    _fs.meetings.create_recording("rec-1", "mtg-1", state="ingested")
    _fs.meetings.update_recording("rec-1", audio_path="/tmp/one.wav")
    _fs.meetings.create_recording("rec-2", "mtg-1", state="failed", sequence_number=2)
    _fs.meetings.update_recording("rec-2", audio_path="/tmp/two.wav")

    with patch(
        "memex.meetings.transcribe.transcribe_meeting",
        side_effect=RuntimeError("retry blew up"),
    ):
        with pytest.raises(RuntimeError, match="retry blew up"):
            orchestrate_transcription(
                "mtg-1",
                meeting_store=ms,
                content_store=cs,
                recording_id="rec-2",
            )

    updated = ms.get_meeting("mtg-1")
    retried = ms.get_recording("rec-2")
    visible = ms.list_meetings()
    assert updated is not None
    assert retried is not None
    assert updated.state == MeetingState.INGESTED
    assert updated.item_id == "item-1"
    assert retried.state == MeetingState.FAILED
    assert "retry blew up" in retried.error
    assert any(m.meeting_id == "mtg-1" for m in visible)


# ---------------------------------------------------------------------------
# _maybe_send_telegram_completion (P2-9)
# ---------------------------------------------------------------------------


def _make_result(duration: float = 120.0, speaker_count: int = 2):
    return TranscriptionResult(
        segments=[],
        duration_seconds=duration,
        speaker_count=speaker_count,
        language="en",
        model="tiny",
    )


def test_notify_success_sends_telegram_when_chat_id_in_notes():
    """_maybe_send_telegram_completion parses chat_id and calls urlopen."""
    notes = "telegram://audio/file123|chat_id=99999"
    result = _make_result()
    with (
        patch("urllib.request.urlopen") as mock_urlopen,
        patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "fake-token"}),
    ):
        _maybe_send_telegram_completion(notes, "My Meeting", result)
    mock_urlopen.assert_called_once()
    call_args = mock_urlopen.call_args[0][0]
    assert b"99999" in call_args.data
    assert b"My Meeting" in call_args.data


def test_notify_success_no_telegram_when_no_chat_id():
    """notes without chat_id → urlopen not called."""
    notes = "telegram://audio/file123"
    result = _make_result()
    with (
        patch("urllib.request.urlopen") as mock_urlopen,
        patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "fake-token"}),
    ):
        _maybe_send_telegram_completion(notes, "My Meeting", result)
    mock_urlopen.assert_not_called()


def test_notify_success_no_telegram_when_empty_notes():
    """Empty notes → urlopen not called."""
    result = _make_result()
    with (
        patch("urllib.request.urlopen") as mock_urlopen,
        patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "fake-token"}),
    ):
        _maybe_send_telegram_completion("", "My Meeting", result)
    mock_urlopen.assert_not_called()


def test_notify_success_no_telegram_when_no_bot_token():
    """chat_id present but no TELEGRAM_BOT_TOKEN → urlopen not called."""
    notes = "telegram://audio/file123|chat_id=99999"
    result = _make_result()
    import os

    orig = os.environ.pop("TELEGRAM_BOT_TOKEN", None)
    try:
        with patch("urllib.request.urlopen") as mock_urlopen:
            _maybe_send_telegram_completion(notes, "My Meeting", result)
        mock_urlopen.assert_not_called()
    finally:
        if orig is not None:
            os.environ["TELEGRAM_BOT_TOKEN"] = orig
