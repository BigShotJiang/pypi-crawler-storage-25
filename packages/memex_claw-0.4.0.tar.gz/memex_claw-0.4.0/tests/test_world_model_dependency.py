from __future__ import annotations


from memex.meetings.models import MeetingRecord, MeetingState
from memex.memory.world_model_reads import resolve_world_model_reads
from memex.models import (
    Goal,
    MeetingGoalLink,
    GoalPriority,
    GoalStatus,
    WorldModelAction,
    WorldModelActionPlan,
    WorldModelCommitment,
    WorldModelEvent,
    WorldModelPlanStep,
    WorldModelTask,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.world_model_backbone import build_world_model_provenance_link
from memex.utcnow import utcnow


def test_search_dependency_documents_surfaces_planning_graph_links(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    blocker = Goal(
        goal_id="goal-review",
        title="Final review",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    goal = Goal(
        goal_id="goal-docs",
        title="Ship docs update",
        status=GoalStatus.BLOCKED,
        priority=GoalPriority.HIGH,
        blocked_by_goal_id="goal-review",
        blocked_reason="Waiting on final review",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(blocker)
    store.create_goal(goal)
    store.upsert_world_model_task(
        WorldModelTask(
            task_id="task-docs",
            scheduled_task_id=None,
            goal_id="goal-docs",
            task_kind="scheduled_reminder",
            title="Prepare docs rollout note",
            description="Prepare the docs rollout note",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_commitment(
        WorldModelCommitment(
            commitment_id="commitment-docs",
            source_record_type="meeting_artifact",
            source_record_id="artifact-docs",
            meeting_id="meeting-docs",
            semantic_item_id=None,
            goal_id="goal-docs",
            title="Ship docs update",
            description="Committed in meeting",
            assignee="Corey",
            agreed_by="Corey",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hits = reads.search_dependency_documents("ship docs update final review", limit=10)

    relationships = {hit.relationship for hit in hits}
    assert "blocked_by" in relationships
    assert "advances_goal" in relationships
    assert "updates_goal" in relationships
    assert all(hit.document_id.startswith("world_model_dependency:") for hit in hits)


def test_search_dependency_documents_surfaces_meeting_goal_links(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-docs",
        title="Ship docs update",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.meetings.create_meeting(
        MeetingRecord(
            meeting_id="meeting-arch-review",
            state=MeetingState.INGESTED,
            title="Architecture Review",
            created_at=now,
            updated_at=now,
        )
    )
    store.create_meeting_goal_link(
        MeetingGoalLink(
            meeting_id="meeting-arch-review",
            goal_id="goal-docs",
            relationship="explicit",
            created_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hits = reads.search_dependency_documents("architecture review ship docs", limit=10)

    assert any(
        hit.relationship == "explicit"
        and hit.source_record_type == "meeting"
        and hit.source_record_id == "meeting-arch-review"
        and hit.source_title == "Architecture Review"
        and hit.target_record_id == "goal-docs"
        for hit in hits
    )


def test_load_dependency_document_returns_titles_and_canonical_endpoints(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    blocker = Goal(
        goal_id="goal-review",
        title="Final review",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    goal = Goal(
        goal_id="goal-docs",
        title="Ship docs update",
        status=GoalStatus.BLOCKED,
        priority=GoalPriority.HIGH,
        blocked_by_goal_id="goal-review",
        blocked_reason="Waiting on final review",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(blocker)
    store.create_goal(goal)

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    link_id = "world_model_goal:goal-docs->blocked_by:world_model_goal:goal-review"
    hit = reads.load_dependency_document(link_id)

    assert hit is not None
    assert hit.relationship == "blocked_by"
    assert hit.source_record_type == "world_model_goal"
    assert hit.source_record_id == "goal-docs"
    assert hit.source_title == "Ship docs update"
    assert hit.target_record_type == "world_model_goal"
    assert hit.target_record_id == "goal-review"
    assert hit.target_title == "Final review"


def test_search_dependency_documents_surfaces_execution_link_records(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-docs",
        title="Ship docs update",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_task(
        WorldModelTask(
            task_id="task-docs-followup",
            scheduled_task_id=None,
            goal_id="goal-docs",
            task_kind="scheduled_reminder",
            title="Send docs follow-up",
            description="Send the architecture docs follow-up",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_action(
        WorldModelAction(
            action_id="session:s1:action:turn:1:selected",
            session_id="session:s1",
            intent_id="intent:s1:1",
            prompt_control_artifact_id=None,
            conversation_turn_id=1,
            action_kind="selected_action",
            action_name="answer_with_followup",
            status="succeeded",
            payload={"selected_action": {"name": "answer_with_followup"}},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_event(
        WorldModelEvent(
            event_id="session:s1:event:turn:1",
            session_id="session:s1",
            conversation_turn_id=1,
            event_kind="turn_outcome",
            title="Turn event: docs follow-up",
            summary="Prepared the docs follow-up turn",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            "session:s1:action:turn:1:selected",
            "world_model_goal",
            "goal-docs",
            "for_goal",
            created_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            "session:s1:action:turn:1:selected",
            "world_model_task",
            "task-docs-followup",
            "creates_task",
            created_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_event",
            "session:s1:event:turn:1",
            "world_model_goal",
            "goal-docs",
            "for_goal",
            created_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hits = reads.search_dependency_documents("docs follow-up ship update", limit=10)

    assert any(
        hit.relationship == "for_goal"
        and hit.source_record_type == "world_model_action"
        and hit.target_record_id == "goal-docs"
        for hit in hits
    )
    assert any(
        hit.relationship == "creates_task"
        and hit.source_record_type == "world_model_action"
        and hit.target_record_id == "task-docs-followup"
        for hit in hits
    )
    assert any(
        hit.relationship == "for_goal"
        and hit.source_record_type == "world_model_event"
        and hit.target_record_id == "goal-docs"
        for hit in hits
    )


def test_search_dependency_documents_surfaces_plan_step_dependencies_and_blockers(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-plan-deps",
        title="Ship docs rollout",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-deps",
            goal_id="goal-plan-deps",
            title="Docs rollout plan",
            summary="Explicit step dependencies for rollout.",
            status="active",
            selected_step_id="step-deps-execute",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-deps-approve",
            plan_id="plan-deps",
            goal_id="goal-plan-deps",
            step_kind="approval",
            title="Approve rollout package",
            description="Approve the rollout package.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-deps-execute",
            plan_id="plan-deps",
            goal_id="goal-plan-deps",
            step_kind="execution",
            title="Execute rollout",
            description="Execute the rollout after approval.",
            status="blocked",
            ordinal=2,
            blocked_reason="Blocked on approval.",
            depends_on_step_ids=["step-deps-approve"],
            blocked_by_step_ids=["step-deps-approve"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hits = reads.search_dependency_documents("rollout approval blocker", limit=10)

    assert any(
        hit.relationship == "depends_on_step"
        and hit.source_record_type == "world_model_plan_step"
        and hit.source_record_id == "step-deps-execute"
        and hit.target_record_type == "world_model_plan_step"
        and hit.target_record_id == "step-deps-approve"
        for hit in hits
    )
    assert any(
        hit.relationship == "blocked_by_step"
        and hit.source_record_type == "world_model_plan_step"
        and hit.source_record_id == "step-deps-execute"
        and hit.target_record_type == "world_model_plan_step"
        and hit.target_record_id == "step-deps-approve"
        for hit in hits
    )


class _FakeSearchResult:
    def __init__(self):
        self.hits = []


class _FakeBuilder:
    def __init__(self, recorder):
        self._recorder = recorder

    def search(self, query, limit):
        self._recorder["search"] = (query, limit)
        return self

    def filter_json_fused_text_in(self, path, values):
        self._recorder["filter_json_fused_text_in"] = (path, list(values))
        return self

    def execute(self):
        self._recorder["executed"] = True
        return _FakeSearchResult()


class _FakeEngine:
    def __init__(self, recorder):
        self._recorder = recorder

    def nodes(self, kind):
        self._recorder["nodes_kind"] = kind
        return _FakeBuilder(self._recorder)


class _FakeWorldModel:
    def __init__(self, recorder):
        self._engine = _FakeEngine(recorder)


class _FakeFathom:
    def __init__(self, recorder):
        self.world_model = _FakeWorldModel(recorder)


class _FakeStore:
    def __init__(self, recorder):
        self._fathom = _FakeFathom(recorder)


def test_search_dependency_documents_uses_fused_text_in_filter():
    from memex.memory.world_model_reads import (
        FathomWorldModelReads,
        _DEPENDENCY_RELATIONSHIPS,
    )

    recorder: dict = {}
    reads = FathomWorldModelReads(_FakeStore(recorder))

    result = reads.search_dependency_documents("ship docs", limit=7)

    assert result == []
    assert recorder["nodes_kind"] == "WMProvenanceLink"
    # limit passed straight through (no over-fetch).
    assert recorder["search"][1] == 7
    # Fused filter applied at the builder level.
    assert "filter_json_fused_text_in" in recorder
    path, values = recorder["filter_json_fused_text_in"]
    assert path == "$.relationship"
    assert set(values) == set(_DEPENDENCY_RELATIONSHIPS)
    assert recorder.get("executed") is True


def test_search_dependency_documents_returns_all_fused_hits_without_post_filter():
    """No Python-side relationship post-filter remains."""
    from types import SimpleNamespace

    from memex.memory.world_model_reads import FathomWorldModelReads

    recorder: dict = {}

    # Build hits whose relationship values would all pass the fused filter
    # (since the fused filter is the DB's responsibility). The function
    # must NOT re-filter them in Python.
    fake_hits = [
        SimpleNamespace(
            node=SimpleNamespace(
                properties={
                    "relationship": "blocked_by",
                    "source_type": "goal",
                    "source_id": "g1",
                    "target_type": "goal",
                    "target_id": "g2",
                    "source_title": "S1",
                    "source_status": "active",
                    "target_title": "T1",
                    "target_status": "active",
                }
            ),
            score=0.9,
        ),
        # A sentinel relationship value that is NOT in
        # _DEPENDENCY_RELATIONSHIPS. With the fused filter in place the DB
        # would never return this, but we inject it to prove the function
        # no longer performs a Python-side whitelist check.
        SimpleNamespace(
            node=SimpleNamespace(
                properties={
                    "relationship": "__not_a_dependency__",
                    "source_type": "goal",
                    "source_id": "g3",
                    "target_type": "goal",
                    "target_id": "g4",
                    "source_title": "S2",
                    "source_status": "active",
                    "target_title": "T2",
                    "target_status": "active",
                }
            ),
            score=0.5,
        ),
    ]

    class _Result:
        def __init__(self, hits):
            self.hits = hits

    class _Builder:
        def search(self, query, limit):
            recorder["search_limit"] = limit
            return self

        def filter_json_fused_text_in(self, path, values):
            recorder["filter_path"] = path
            return self

        def execute(self):
            return _Result(fake_hits)

    class _Engine:
        def nodes(self, kind):
            return _Builder()

    class _WM:
        _engine = _Engine()

    class _Fathom:
        world_model = _WM()

    class _Store:
        _fathom = _Fathom()

    reads = FathomWorldModelReads(_Store())
    hits = reads.search_dependency_documents("ship", limit=5)

    # Both rows returned — no Python-side relationship whitelist filter.
    assert len(hits) == 2
    relationships = {h.relationship for h in hits}
    assert "blocked_by" in relationships
    assert "__not_a_dependency__" in relationships
    # search() received the caller's limit, not limit * 10.
    assert recorder["search_limit"] == 5
    assert recorder["filter_path"] == "$.relationship"
