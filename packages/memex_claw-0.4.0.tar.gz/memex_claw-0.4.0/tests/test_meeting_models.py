"""Tests for meeting models, ItemType.MEETING, and ActionType.TRANSCRIPTION."""

from dataclasses import FrozenInstanceError
from datetime import datetime

import pytest

from memex.meetings.models import MeetingRecord, MeetingSegment, MeetingState
from memex.memory.decay import DEFAULT_HALF_LIFE
from memex.models import ActionType, ItemType
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# MeetingState enum
# ---------------------------------------------------------------------------


def test_meeting_state_values():
    assert MeetingState.CREATED.value == "created"
    assert MeetingState.RECORDING.value == "recording"
    assert MeetingState.RECORDED.value == "recorded"
    assert MeetingState.QUEUED.value == "queued"
    assert MeetingState.TRANSCRIBING.value == "transcribing"
    assert MeetingState.TRANSCRIBED.value == "transcribed"
    assert MeetingState.INGESTED.value == "ingested"
    assert MeetingState.FAILED.value == "failed"


def test_meeting_state_count():
    assert len(MeetingState) == 9


def test_meeting_state_is_str_enum():
    assert isinstance(MeetingState.RECORDING, str)
    assert MeetingState.FAILED == "failed"


# ---------------------------------------------------------------------------
# MeetingSegment
# ---------------------------------------------------------------------------


def test_meeting_segment_creation():
    seg = MeetingSegment(speaker="Alice", start=0.0, end=5.5, text="Hello everyone.")
    assert seg.speaker == "Alice"
    assert seg.start == 0.0
    assert seg.end == 5.5
    assert seg.text == "Hello everyone."


def test_meeting_segment_frozen():
    seg = MeetingSegment(speaker="Alice", start=0.0, end=5.5, text="Hello.")
    with pytest.raises(FrozenInstanceError):
        seg.speaker = "Bob"


# ---------------------------------------------------------------------------
# MeetingRecord — defaults
# ---------------------------------------------------------------------------


def test_meeting_record_defaults():
    rec = MeetingRecord(meeting_id="m1", state=MeetingState.RECORDING)
    assert rec.meeting_id == "m1"
    assert rec.state == MeetingState.RECORDING
    assert rec.title == ""
    assert rec.audio_path == ""
    assert rec.duration_seconds == 0.0
    assert rec.sample_rate == 16000
    assert rec.started_at is None
    assert rec.stopped_at is None
    assert rec.transcribed_at is None
    assert rec.ingested_at is None
    assert rec.item_id is None
    assert rec.segments == []
    assert rec.speaker_count == 0
    assert rec.language == ""
    assert rec.whisper_model == ""
    assert rec.error == ""
    assert rec.audio_deleted is False
    assert isinstance(rec.created_at, datetime)
    assert isinstance(rec.updated_at, datetime)


# ---------------------------------------------------------------------------
# MeetingRecord — all fields
# ---------------------------------------------------------------------------


def test_meeting_record_all_fields():
    now = utcnow()
    seg = MeetingSegment(speaker="Bob", start=0.0, end=3.0, text="Hi.")
    rec = MeetingRecord(
        meeting_id="m2",
        state=MeetingState.TRANSCRIBED,
        title="Standup",
        audio_path="/tmp/standup.wav",
        duration_seconds=120.5,
        sample_rate=44100,
        started_at=now,
        stopped_at=now,
        transcribed_at=now,
        ingested_at=now,
        item_id="item-42",
        segments=[seg],
        speaker_count=2,
        language="en",
        whisper_model="large-v3",
        error="",
        audio_deleted=True,
        created_at=now,
        updated_at=now,
    )
    assert rec.title == "Standup"
    assert rec.audio_path == "/tmp/standup.wav"
    assert rec.duration_seconds == 120.5
    assert rec.sample_rate == 44100
    assert rec.item_id == "item-42"
    assert len(rec.segments) == 1
    assert rec.segments[0].speaker == "Bob"
    assert rec.speaker_count == 2
    assert rec.language == "en"
    assert rec.whisper_model == "large-v3"
    assert rec.audio_deleted is True


# ---------------------------------------------------------------------------
# MeetingRecord — state mutations
# ---------------------------------------------------------------------------


def test_meeting_record_state_mutation():
    rec = MeetingRecord(meeting_id="m3", state=MeetingState.RECORDING)
    assert rec.state == MeetingState.RECORDING

    rec.state = MeetingState.RECORDED
    assert rec.state == MeetingState.RECORDED

    rec.state = MeetingState.QUEUED
    assert rec.state == MeetingState.QUEUED

    rec.state = MeetingState.TRANSCRIBING
    assert rec.state == MeetingState.TRANSCRIBING

    rec.state = MeetingState.TRANSCRIBED
    assert rec.state == MeetingState.TRANSCRIBED

    rec.state = MeetingState.INGESTED
    assert rec.state == MeetingState.INGESTED


def test_meeting_record_state_to_failed():
    rec = MeetingRecord(meeting_id="m4", state=MeetingState.TRANSCRIBING)
    rec.state = MeetingState.FAILED
    rec.error = "whisper crashed"
    assert rec.state == MeetingState.FAILED
    assert rec.error == "whisper crashed"


# ---------------------------------------------------------------------------
# ItemType.MEETING and ActionType.TRANSCRIPTION
# ---------------------------------------------------------------------------


def test_item_type_meeting():
    assert ItemType.MEETING.value == "meeting"
    assert isinstance(ItemType.MEETING, str)
    assert ItemType.MEETING == "meeting"


def test_action_type_transcription():
    assert ActionType.TRANSCRIPTION.value == "transcription"
    assert isinstance(ActionType.TRANSCRIPTION, str)
    assert ActionType.TRANSCRIPTION == "transcription"


# ---------------------------------------------------------------------------
# DEFAULT_HALF_LIFE includes MEETING
# ---------------------------------------------------------------------------


def test_default_half_life_meeting():
    assert ItemType.MEETING in DEFAULT_HALF_LIFE
    assert DEFAULT_HALF_LIFE[ItemType.MEETING] == 60.0
