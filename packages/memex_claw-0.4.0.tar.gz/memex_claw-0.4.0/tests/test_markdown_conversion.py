"""Tests for HTML-to-markdown conversion in the web extraction pipeline."""

from __future__ import annotations

import pytest

from memex.memory.web_extract import (
    _html_to_markdown,
    extract_from_html,
)

try:
    import markdownify as _markdownify_mod  # noqa: F401

    _HAS_MARKDOWNIFY = True
except ImportError:
    _HAS_MARKDOWNIFY = False

_needs_markdownify = pytest.mark.skipif(
    not _HAS_MARKDOWNIFY,
    reason="markdownify not installed in this Python environment",
)


# ---------------------------------------------------------------------------
# Unit tests for _html_to_markdown
# ---------------------------------------------------------------------------


class TestHtmlToMarkdown:
    """Direct tests for the converter function."""

    @_needs_markdownify
    def test_headings_become_atx(self):
        html = "<h1>Title</h1><h2>Subtitle</h2><p>Body text.</p>"
        md = _html_to_markdown(html)
        assert "# Title" in md
        assert "## Subtitle" in md
        assert "Body text." in md

    @_needs_markdownify
    def test_unordered_list_uses_dashes(self):
        html = "<ul><li>Alpha</li><li>Beta</li></ul>"
        md = _html_to_markdown(html)
        assert "- Alpha" in md
        assert "- Beta" in md

    @_needs_markdownify
    def test_ordered_list_preserved(self):
        html = "<ol><li>First</li><li>Second</li></ol>"
        md = _html_to_markdown(html)
        assert "1." in md
        assert "First" in md

    @_needs_markdownify
    def test_links_preserved(self):
        html = '<p>See <a href="https://example.com">this link</a> for details.</p>'
        md = _html_to_markdown(html)
        assert "[this link](https://example.com)" in md

    @_needs_markdownify
    def test_bold_and_italic(self):
        html = "<p><strong>bold</strong> and <em>italic</em></p>"
        md = _html_to_markdown(html)
        assert "**bold**" in md
        assert "*italic*" in md

    def test_table_content_preserved(self):
        html = """
        <table>
            <tr><th>Name</th><th>Type</th></tr>
            <tr><td>Neo4j</td><td>Graph</td></tr>
        </table>
        """
        md = _html_to_markdown(html)
        assert "Neo4j" in md
        assert "Graph" in md

    def test_images_stripped(self):
        html = '<p>Text before <img src="photo.jpg" alt="photo"> text after.</p>'
        md = _html_to_markdown(html)
        assert "src=" not in md
        assert "<img" not in md
        assert "text after" in md.lower()

    def test_no_excessive_blank_lines(self):
        html = "<p>A</p><p>B</p><p>C</p>"
        md = _html_to_markdown(html)
        assert "\n\n\n" not in md

    def test_empty_input(self):
        assert _html_to_markdown("") == ""

    def test_plain_text_passthrough(self):
        md = _html_to_markdown("just plain text")
        assert "just plain text" in md

    @_needs_markdownify
    def test_nested_structure(self):
        html = """
        <div>
            <h2>Section</h2>
            <p>Intro paragraph.</p>
            <ul>
                <li>Item one</li>
                <li>Item two</li>
            </ul>
        </div>
        """
        md = _html_to_markdown(html)
        assert "## Section" in md
        assert "- Item one" in md
        assert "Intro paragraph." in md


# ---------------------------------------------------------------------------
# Integration: extract_from_html now returns markdown body
# ---------------------------------------------------------------------------


_STRUCTURED_HTML = """\
<!DOCTYPE html>
<html>
<head>
    <title>Graph Database Guide</title>
    <meta name="author" content="Jane Smith">
    <meta name="description" content="A guide to graph databases">
</head>
<body>
    <nav>Home | About | Contact</nav>
    <article>
        <h1>Graph Database Guide</h1>
        <p>Graph databases represent data as nodes and edges, making them
        ideal for highly connected datasets. Unlike relational databases
        that use tables and joins, graph databases traverse relationships
        directly, enabling faster queries on connected data.</p>

        <h2>Query Languages</h2>
        <p>Cypher is the most popular graph query language, originally
        developed for Neo4j. It uses ASCII-art patterns to describe
        graph traversals.</p>

        <ul>
            <li>Cypher for Neo4j</li>
            <li>Gremlin for TinkerPop</li>
            <li>SPARQL for RDF</li>
        </ul>

        <h2>Comparison Table</h2>
        <table>
            <tr><th>Database</th><th>Model</th></tr>
            <tr><td>Neo4j</td><td>Property Graph</td></tr>
            <tr><td>LadybugDB</td><td>Property Graph</td></tr>
        </table>
    </article>
    <footer>Copyright 2025</footer>
</body>
</html>
"""


class TestExtractFromHtmlMarkdown:
    """extract_from_html should produce markdown-formatted body text."""

    @_needs_markdownify
    def test_body_contains_atx_headings(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        assert result.is_substantial
        # The body should contain markdown headings, not raw HTML or flat text
        assert (
            "## Query Languages" in result.body
            or "## query languages" in result.body.lower()
        )

    @_needs_markdownify
    def test_body_contains_list_markers(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        # Should have markdown list items, not bare text
        assert "- Cypher" in result.body or "- cypher" in result.body.lower()

    def test_table_data_preserved(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        assert "Neo4j" in result.body
        assert "LadybugDB" in result.body

    def test_navigation_stripped(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        assert "Home | About | Contact" not in result.body

    def test_metadata_still_extracted(self):
        """Markdown conversion must not break metadata extraction."""
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        assert result.title
        assert "graph" in result.title.lower() or "Graph" in result.title

    def test_no_html_tags_in_body(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        # Body should be markdown, not contain raw HTML tags
        assert "<h1>" not in result.body
        assert "<h2>" not in result.body
        assert "<p>" not in result.body
        assert "<li>" not in result.body


# ---------------------------------------------------------------------------
# Graceful degradation: markdownify not installed
# ---------------------------------------------------------------------------


class TestMarkdownifyMissing:
    """When markdownify is not installed, fall back to plain text."""

    def test_html_to_markdown_fallback(self):
        """Without markdownify, _html_to_markdown still returns usable text."""
        import unittest.mock

        with unittest.mock.patch.dict("sys.modules", {"markdownify": None}):
            # Force re-import failure
            result = _html_to_markdown("<h1>Title</h1><p>Body text here.</p>")

        # Should still contain the text content, just without markdown formatting
        assert "Title" in result
        assert "Body text here" in result
        assert "<h1>" not in result


# ---------------------------------------------------------------------------
# Chunking compatibility: markdown body chunks well
# ---------------------------------------------------------------------------


class TestMarkdownChunkingCompat:
    """Markdown output should chunk cleanly on paragraph boundaries."""

    @_needs_markdownify
    def test_markdown_body_splits_on_double_newline(self):
        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        # Markdown output should have paragraph separators that the chunker expects
        paragraphs = [p.strip() for p in result.body.split("\n\n") if p.strip()]
        assert len(paragraphs) >= 2, (
            f"Expected multiple paragraphs, got {len(paragraphs)}"
        )

    def test_chunks_from_markdown_body(self):
        from memex.memory.chunking import chunk_text

        result = extract_from_html(_STRUCTURED_HTML, url="https://example.com/guide")
        chunks = chunk_text(result.body, max_tokens=100)
        # With structured markdown, chunking should produce meaningful splits
        for chunk in chunks:
            assert chunk["text"].strip(), "Chunk should not be empty"
            assert chunk["token_count"] > 0
