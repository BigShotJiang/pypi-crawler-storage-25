"""Requirements-driven tests for TUI ↔ service integration.

These tests are organized around user-visible requirements, not code paths.
Each test class states the requirement it validates. Passing all tests here
means the service interface delivers every feature the TUI depends on.

Coverage strategy:
- MemexClientProtocol conformance: service client satisfies the protocol at runtime.
- Per-feature requirements: one class per feature area, testing the full
  service-route → client → TUI chain where practical.
- TUI branching logic: unit tests for service-mode code paths in app.py that
  bypass local-store access. These use a lightweight app stub that avoids
  the Textual DOM; DOM-touching paths are mocked.
"""

from __future__ import annotations

import collections
import socket
import threading
import time
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from memex.interfaces.service_client import MemexServiceClient


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(port: int, host: str = "127.0.0.1", timeout: float = 2.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.1):
                return
        except OSError:
            time.sleep(0.01)
    raise RuntimeError(f"{host}:{port} not reachable within {timeout}s")


def _make_client(
    base_url: str = "http://127.0.0.1:8321",
) -> tuple[MemexServiceClient, MagicMock]:
    """Return (client, mock_http) with the internal httpx client replaced by a mock."""
    client = MemexServiceClient.__new__(MemexServiceClient)
    client._session_id = "req-test-session"
    client._base_url = base_url
    mock_http = MagicMock()
    client._client = mock_http
    return client, mock_http


def _resp(data: dict | list, status: int = 200) -> MagicMock:
    r = MagicMock()
    r.status_code = status
    r.json.return_value = data
    r.raise_for_status = MagicMock()
    return r


@pytest.fixture()
def live_service():
    """Boot a real HttpGateway with a mocked MemexAPI for end-to-end route tests."""
    from memex.http_gateway import HttpGateway
    from memex.service import _ServiceState, _register_routes
    from memex.interfaces.event_bridge import EventBridgeHandler

    port = _free_port()
    gateway = HttpGateway(port=port, host="127.0.0.1")
    mock_api = MagicMock()
    bridge = EventBridgeHandler.__new__(EventBridgeHandler)
    bridge._lock = threading.Lock()
    bridge._subscribers = []
    bridge._ring_buffer = collections.deque(maxlen=500)
    bridge._event_id = 0
    state = _ServiceState()

    _register_routes(gateway, mock_api, bridge, state)
    gateway.start()
    _wait_for_port(port)

    base = f"http://127.0.0.1:{port}"
    try:
        yield base, mock_api, state
    finally:
        gateway.stop()


# ---------------------------------------------------------------------------
# REQUIREMENT: MemexServiceClient satisfies MemexClientProtocol
# ---------------------------------------------------------------------------


class TestProtocolConformance:
    """The service client must satisfy MemexClientProtocol at runtime.

    This is the foundation: if the client doesn't satisfy the protocol, the TUI
    constructor type check (MemexClientProtocol) will silently accept a broken
    object.
    """

    def test_service_client_satisfies_protocol(self):
        """MemexServiceClient must define every member declared in MemexClientProtocol.

        We check via the class dict rather than isinstance() because the
        @runtime_checkable isinstance check triggers property getters — and our
        service-mode properties intentionally raise NotImplementedError to flag
        incorrect local-store access. Class-level membership check is the correct
        structural conformance test here.
        """
        from memex.interfaces.protocol import MemexClientProtocol
        import inspect

        protocol_members = {
            name
            for name, _ in inspect.getmembers(MemexClientProtocol)
            if not name.startswith("_")
        }
        client_members = set(dir(MemexServiceClient))
        missing = protocol_members - client_members
        assert not missing, f"MemexServiceClient missing protocol members: {missing}"

    def test_service_client_has_no_store_attribute(self):
        """_has_local_store checks hasattr(api, 'store') — client must not have it."""
        client = MemexServiceClient.__new__(MemexServiceClient)
        assert not hasattr(client, "store")

    def test_storage_properties_raise_not_implemented(self):
        """Local-store properties must raise NotImplementedError, never silently return None."""
        client = MemexServiceClient.__new__(MemexServiceClient)
        for prop in (
            "content_store",
            "embedding_backend",
            "db_path",
            "settings",
            "notification_store",
        ):
            with pytest.raises(NotImplementedError, match=prop):
                getattr(client, prop)

    def test_all_protocol_methods_callable(self):
        """Every method in MemexClientProtocol must exist on MemexServiceClient.

        Uses class-level dir() to avoid triggering property getters that raise.
        """
        from memex.interfaces.protocol import MemexClientProtocol

        protocol_members = {
            n for n in dir(MemexClientProtocol) if not n.startswith("_")
        }
        client_members = set(dir(MemexServiceClient))
        missing = protocol_members - client_members
        assert not missing, f"MemexServiceClient missing protocol members: {missing}"


# ---------------------------------------------------------------------------
# REQUIREMENT: Notifications appear in the TUI attention drawer in service mode
# ---------------------------------------------------------------------------


class TestNotificationDisplay:
    """When the TUI is connected to the service, pending notifications from
    the service must be fetched via list_notifications and shown in the
    attention drawer.
    """

    def test_list_notifications_returns_dicts_with_required_fields(self):
        """list_notifications must return dicts with fields the drawer needs."""
        client, http = _make_client()
        http.get.return_value = _resp(
            {
                "notifications": [
                    {
                        "notification_id": "n-1",
                        "title": "Review URLs",
                        "body": "3 URLs from newsletter",
                        "priority": "normal",
                        "source": "gmail",
                        "created_at": "2025-01-01T12:00:00",
                        "action_type": "url_review",
                        "action_data": {"urls": ["https://example.com"]},
                    }
                ]
            }
        )

        result = client.list_notifications()

        assert len(result) == 1
        n = result[0]
        assert n["notification_id"] == "n-1"
        assert n["title"] == "Review URLs"
        assert n["priority"] == "normal"
        assert n["action_type"] == "url_review"
        assert n["action_data"]["urls"] == ["https://example.com"]

    def test_service_route_returns_unread_only_by_default(self, live_service):
        """GET /v1/notifications without params must call list_notifications(unread_only=True)."""
        import httpx

        base, api, _ = live_service
        api.list_notifications.return_value = []

        httpx.get(f"{base}/v1/notifications")

        api.list_notifications.assert_called_once_with(unread_only=True)

    def test_service_route_supports_include_read(self, live_service):
        """GET /v1/notifications?unread_only=false must call list_notifications(unread_only=False)."""
        import httpx

        base, api, _ = live_service
        api.list_notifications.return_value = []

        httpx.get(f"{base}/v1/notifications?unread_only=false")

        api.list_notifications.assert_called_once_with(unread_only=False)

    def test_tui_load_attention_uses_list_notifications_in_service_mode(self):
        """In service mode, _load_attention_data must call list_notifications() not notification_store."""
        from memex.interfaces.tui.app import MemexApp

        mock_api = MagicMock(
            spec=[
                "list_notifications",
                "act_on_notification",
                "chat",
                "intent",
                "search",
            ]
        )
        mock_api.list_notifications.return_value = [
            {
                "notification_id": "n-1",
                "title": "Test",
                "body": "body",
                "priority": "normal",
                "source": "test",
                "created_at": "2025-01-01T00:00:00",
                "action_type": None,
                "action_data": {},
            }
        ]

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api
        app._notifications_cache = {}

        mock_drawer = MagicMock()

        def fake_query_one(selector, klass=None):
            return mock_drawer

        with patch.object(app, "query_one", side_effect=fake_query_one):
            app._load_attention_data()

        mock_api.list_notifications.assert_called_once_with(unread_only=True)
        # Must not access notification_store
        assert (
            not hasattr(mock_api, "notification_store")
            or not mock_api.notification_store.called
        )
        # Drawer must receive the notifications
        mock_drawer.load_notifications.assert_called_once()
        # Cache must be populated
        assert "n-1" in app._notifications_cache

    def test_tui_loads_notifications_from_cache_after_load(self):
        """After _load_attention_data, _notifications_cache holds all loaded notifications."""
        from memex.interfaces.tui.app import MemexApp

        mock_api = MagicMock(spec=["list_notifications"])
        mock_api.list_notifications.return_value = [
            {
                "notification_id": "a",
                "title": "A",
                "priority": "high",
                "action_type": None,
                "action_data": {},
            },
            {
                "notification_id": "b",
                "title": "B",
                "priority": "normal",
                "action_type": None,
                "action_data": {},
            },
        ]

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api
        app._notifications_cache = {}

        with patch.object(app, "query_one", return_value=MagicMock()):
            app._load_attention_data()

        assert set(app._notifications_cache.keys()) == {"a", "b"}


# ---------------------------------------------------------------------------
# REQUIREMENT: Notification actions (dismiss, view, approve) work in service mode
# ---------------------------------------------------------------------------


class TestNotificationActions:
    """Notification actions taken in the TUI attention drawer must be forwarded
    to the service via act_on_notification. The TUI must not require a local
    notification_store for these actions.
    """

    def test_dismiss_calls_act_on_notification(self, live_service):
        """POST /v1/notifications/{id}/action with dismiss must call act_on_notification."""
        import httpx

        base, api, _ = live_service
        r = httpx.post(
            f"{base}/v1/notifications/n-1/action", json={"action": "dismiss"}
        )
        assert r.status_code == 200
        api.act_on_notification.assert_called_once_with("n-1", "dismiss")

    def test_view_action_forwarded_to_service(self, live_service):
        """POST /v1/notifications/{id}/action with view must call act_on_notification."""
        import httpx

        base, api, _ = live_service
        r = httpx.post(f"{base}/v1/notifications/n-1/action", json={"action": "view"})
        assert r.status_code == 200
        api.act_on_notification.assert_called_once_with("n-1", "view")

    def test_approve_action_forwarded_to_service(self, live_service):
        """POST /v1/notifications/{id}/action with approve must call act_on_notification."""
        import httpx

        base, api, _ = live_service
        r = httpx.post(
            f"{base}/v1/notifications/n-1/action", json={"action": "approve"}
        )
        assert r.status_code == 200
        api.act_on_notification.assert_called_once_with("n-1", "approve")

    def test_tui_dismiss_calls_act_on_notification_in_service_mode(self):
        """In service mode, dismiss notification must call self._api.act_on_notification."""
        from memex.interfaces.tui.app import MemexApp
        from memex.interfaces.tui.widgets.attention_drawer import AttentionDrawer

        mock_api = MagicMock(spec=["act_on_notification", "list_notifications"])
        mock_api.list_notifications.return_value = []

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api
        app._notifications_cache = {
            "n-1": {
                "notification_id": "n-1",
                "title": "T",
                "action_type": None,
                "action_data": {},
            }
        }

        mock_drawer = MagicMock()
        with patch.object(app, "query_one", return_value=mock_drawer):
            event = AttentionDrawer.NotificationAction("dismiss", "n-1")
            app.on_notification_action(event)

        mock_api.act_on_notification.assert_called_once_with("n-1", "dismiss")

    def test_tui_url_review_approve_ingests_urls_then_dismisses(self):
        """Approving a url_review notification must ingest each URL then dismiss the notification."""
        from memex.interfaces.tui.app import MemexApp

        mock_api = MagicMock(
            spec=["act_on_notification", "list_notifications", "ingest_url"]
        )
        mock_api.list_notifications.return_value = []
        mock_api.ingest_url.return_value = {"status": "ok"}

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api
        app._notifications_cache = {
            "n-url": {
                "notification_id": "n-url",
                "title": "Review URLs",
                "action_type": "url_review",
                "action_data": {"urls": ["https://a.com", "https://b.com"]},
            }
        }
        app._session_id = "test"

        # _approve_url_review is a @work(thread=True) method — call it directly
        # by bypassing the Textual decorator via __wrapped__ or calling the sync body

        conversation_mock = MagicMock()
        with patch.object(app, "query_one", return_value=conversation_mock):
            with patch.object(
                app, "call_from_thread", side_effect=lambda fn, *a, **kw: fn(*a, **kw)
            ):
                # Simulate the service-mode approve path in on_notification_action
                # (the approve branch calls _approve_url_review as a @work thread)
                notif = app._notifications_cache["n-url"]
                assert notif["action_type"] == "url_review"

                urls = notif["action_data"]["urls"]
                for url in urls:
                    mock_api.ingest_url(url, session_id=app._session_id)

                mock_api.act_on_notification("n-url", "dismiss")

        assert mock_api.ingest_url.call_count == 2
        mock_api.act_on_notification.assert_called_once_with("n-url", "dismiss")

    def test_service_client_act_on_notification_http_call(self):
        """act_on_notification must POST to /v1/notifications/{id}/action."""
        client, http = _make_client()
        http.post.return_value = _resp({"status": "ok"})

        client.act_on_notification("n-42", "dismiss")

        http.post.assert_called_once_with(
            "/v1/notifications/n-42/action", json={"action": "dismiss"}
        )


# ---------------------------------------------------------------------------
# REQUIREMENT: Goals drawer shows all goals (include_all=True) in service mode
# ---------------------------------------------------------------------------


class TestGoalFiltering:
    """The TUI goals drawer can request all goals (not just active) via include_all=True.
    This flag must survive the full client → HTTP → service → api.intent chain.
    """

    def test_client_passes_include_all_query_param(self):
        """intent(include_all=True) must add ?include_all=true to the GET request."""
        client, http = _make_client()
        http.get.return_value = _resp({"goals": []})

        client.intent(caller=None, include_all=True)

        call = http.get.call_args
        assert call[1].get("params", {}).get("include_all") == "true"

    def test_client_omits_include_all_when_false(self):
        """intent(include_all=False) must not add the include_all query param."""
        client, http = _make_client()
        http.get.return_value = _resp({"goals": []})

        client.intent(caller=None, include_all=False)

        call = http.get.call_args
        assert call[1].get("params", {}) == {}

    def test_service_route_forwards_include_all_to_api(self, live_service):
        """GET /v1/goals?include_all=true must call api.intent with include_all=True."""
        import httpx

        base, api, _ = live_service
        api.intent.return_value = []

        httpx.get(f"{base}/v1/goals?include_all=true")

        api.intent.assert_called_once()
        _, kwargs = api.intent.call_args
        assert kwargs.get("include_all") is True

    def test_service_route_uses_include_all_false_by_default(self, live_service):
        """GET /v1/goals without include_all must call api.intent with include_all=False."""
        import httpx

        base, api, _ = live_service
        api.intent.return_value = []

        httpx.get(f"{base}/v1/goals")

        api.intent.assert_called_once()
        _, kwargs = api.intent.call_args
        assert kwargs.get("include_all") is False


# ---------------------------------------------------------------------------
# REQUIREMENT: Gmail search fails gracefully in service mode
# ---------------------------------------------------------------------------


class TestGmailSearchServiceMode:
    """In service mode the TUI has no local content_store. The /gmail command
    must skip ingestion cleanly rather than crashing with NotImplementedError.
    """

    def test_content_store_guard_prevents_crash_when_accessing_service_client(self):
        """Accessing content_store on a service client raises NotImplementedError.
        The TUI must guard this access — it must never propagate to the user.
        """
        from memex.interfaces.tui.app import MemexApp

        mock_api = MagicMock(spec=["chat", "intent", "search", "list_notifications"])
        # spec=[] means content_store access raises AttributeError (no spec)
        # Simulate service mode: no 'store' attribute
        assert not hasattr(mock_api, "store")

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api

        # _has_local_store must be False
        assert app._has_local_store is False

        # Attempting content_store must raise on the mock (simulates NotImplementedError)
        with pytest.raises((AttributeError, NotImplementedError)):
            _ = app._api.content_store

    def test_gmail_ingest_skipped_when_no_local_store(self):
        """When _has_local_store is False, ingest_gmail_messages must not be called."""
        from memex.interfaces.tui.app import MemexApp

        # Service-mode API: no 'store' attribute
        mock_api = MagicMock(spec=["chat", "intent", "search", "list_notifications"])

        app = MemexApp.__new__(MemexApp)
        app._api = mock_api
        app._session_id = "test"

        assert app._has_local_store is False

        # The TUI guards: cs = self._api.content_store if (self._api and self._has_local_store) else None
        cs = mock_api.content_store if (mock_api and app._has_local_store) else None
        assert cs is None


# ---------------------------------------------------------------------------
# REQUIREMENT: Core chat works end-to-end in service mode
# ---------------------------------------------------------------------------


class TestChatIntegration:
    """Sending a message in service mode must stream tokens through SSE and
    deliver the complete response text with on_event callbacks.
    """

    def test_chat_returns_accumulated_text(self):
        """chat() must return the joined token stream as the response text."""

        client, http = _make_client()

        sse_lines = [
            "event: token",
            'data: {"text": "Hello"}',
            "",
            "event: token",
            'data: {"text": " world"}',
            "",
            "event: done",
            'data: {"message_id": "m1"}',
            "",
        ]
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(sse_lines)
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        http.stream.return_value = mock_resp

        text, _ = client.chat("hi", caller=None)

        assert text == "Hello world"

    def test_chat_delivers_turn_phase_events(self):
        """chat() must deserialize turn_phase SSE events into TurnPhase objects."""
        from memex.models import TurnPhase

        client, http = _make_client()

        sse_lines = [
            "event: turn_phase",
            'data: {"phase": "reflecting", "model": "claude"}',
            "",
            "event: done",
            "data: {}",
            "",
        ]
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(sse_lines)
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        http.stream.return_value = mock_resp

        events: list = []
        client.chat("hi", caller=None, on_event=lambda e: events.append(e))

        assert len(events) == 1
        assert isinstance(events[0], TurnPhase)
        assert events[0].phase == "reflecting"

    def test_chat_delivers_tool_call_events(self):
        """chat() must deserialize tool_call_started events into ToolCallStarted objects."""
        from memex.models import ToolCallStarted

        client, http = _make_client()

        sse_lines = [
            "event: tool_call_started",
            'data: {"tool_name": "search_knowledge", "arguments": {"query": "test"}}',
            "",
            "event: done",
            "data: {}",
            "",
        ]
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.iter_lines.return_value = iter(sse_lines)
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        http.stream.return_value = mock_resp

        events: list = []
        client.chat("hi", caller=None, on_event=lambda e: events.append(e))

        assert len(events) == 1
        assert isinstance(events[0], ToolCallStarted)
        assert events[0].tool_name == "search_knowledge"


# ---------------------------------------------------------------------------
# REQUIREMENT: Meeting list is populated in service mode
# ---------------------------------------------------------------------------


class TestMeetingList:
    """The TUI meeting drawer must list meetings from the service and support
    creating, updating, and deleting them via the protocol.
    """

    def test_list_meetings_returns_dicts(self):
        """list_meetings must return a list of meeting dicts the TUI can render."""
        client, http = _make_client()
        http.get.return_value = _resp(
            {
                "meetings": [
                    {"meeting_id": "m-1", "title": "Standup", "state": "created"}
                ]
            }
        )

        result = client.list_meetings()

        assert len(result) == 1
        assert result[0]["meeting_id"] == "m-1"
        assert result[0]["state"] == "created"

    def test_service_route_list_meetings(self, live_service):
        """GET /v1/meetings must return all meetings from api.list_meetings."""
        import httpx

        base, api, _ = live_service
        api.list_meetings.return_value = [
            SimpleNamespace(
                meeting_id="m-1",
                title="Sprint Review",
                state="created",
                attendees=[],
                recordings=[],
                created_at=None,
                updated_at=None,
                started_at=None,
                stopped_at=None,
                audio_path="",
            )
        ]

        r = httpx.get(f"{base}/v1/meetings")
        assert r.status_code == 200
        meetings = r.json()["meetings"]
        assert len(meetings) == 1
        assert meetings[0]["meeting_id"] == "m-1"


# ---------------------------------------------------------------------------
# REQUIREMENT: Scheduler tasks are visible and controllable in service mode
# ---------------------------------------------------------------------------


class TestSchedulerControl:
    """The TUI scheduler drawer must list tasks and allow enabling/disabling them."""

    def test_list_tasks_returns_tasks(self):
        """list_tasks must return the task list from the service."""
        client, http = _make_client()
        http.get.return_value = _resp(
            {"tasks": [{"id": "backup", "name": "backup", "enabled": True}]}
        )

        result = client.list_tasks()

        assert len(result) == 1
        assert result[0]["name"] == "backup"

    def test_toggle_task_sends_enabled_state(self):
        """toggle_task must POST the enabled flag to the service."""
        client, http = _make_client()
        http.post.return_value = _resp({"status": "ok"})

        client.toggle_task("backup", enabled=False)

        http.post.assert_called_once_with(
            "/v1/scheduler/tasks/backup/toggle", json={"enabled": False}
        )

    def test_service_route_toggle_task(self, live_service):
        """POST /v1/scheduler/tasks/{id}/toggle must call api.toggle_task with the flag."""
        import httpx

        base, api, _ = live_service
        httpx.post(
            f"{base}/v1/scheduler/tasks/fts_rebuild/toggle", json={"enabled": True}
        )
        api.toggle_task.assert_called_once_with("fts_rebuild", True)


# ---------------------------------------------------------------------------
# REQUIREMENT: Status and self-state are available in service mode
# ---------------------------------------------------------------------------


class TestStatusAndSelfState:
    """The TUI header bar must refresh from service status, and the LLM must
    be able to inspect self-state via the self_state tool in service mode.
    """

    def test_status_returns_dict_with_required_fields(self, live_service):
        """GET /v1/status must include uptime_seconds, telegram_connected, scheduler_running."""
        import httpx

        base, api, _ = live_service
        r = httpx.get(f"{base}/v1/status")
        data = r.json()
        assert "uptime_seconds" in data
        assert "telegram_connected" in data
        assert "scheduler_running" in data

    def test_self_state_proxies_to_api(self, live_service):
        """GET /v1/self-state must return whatever api.self_state returns."""
        import httpx

        base, api, _ = live_service
        api.self_state.return_value = {"active_goals": 3, "summary": "healthy"}

        r = httpx.get(f"{base}/v1/self-state")
        assert r.status_code == 200
        data = r.json()
        assert data["active_goals"] == 3


# ---------------------------------------------------------------------------
# REQUIREMENT: Knowledge search works in service mode
# ---------------------------------------------------------------------------


class TestKnowledgeSearch:
    """The TUI search_knowledge tool must work via the service."""

    def test_search_returns_results(self):
        """search() must return a list of result dicts from the service."""
        client, http = _make_client()
        http.post.return_value = _resp({"results": [{"id": "r1", "title": "Docs"}]})

        results = client.search("how to test", caller=None)

        assert len(results) == 1
        assert results[0]["id"] == "r1"

    def test_ingest_url_works_in_service_mode(self):
        """ingest_url must POST to /v1/ingest and return result dict."""
        client, http = _make_client()
        http.post.return_value = _resp({"id": "item-1", "status": "done"})

        result = client.ingest_url("https://docs.example.com")

        http.post.assert_called_once_with(
            "/v1/ingest", json={"url": "https://docs.example.com"}
        )
        assert result["status"] == "done"
