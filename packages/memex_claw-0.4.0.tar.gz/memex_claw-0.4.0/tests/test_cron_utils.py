"""Tests for cron expression utilities."""

from datetime import datetime, timezone

from memex.scheduler.cron_utils import (
    format_cron_human,
    format_human_readable,
    is_due,
    next_fire_time,
)


def test_next_fire_time():
    # After 2026-03-08 08:00, "0 9 * * *" should fire at 2026-03-08 09:00
    after = datetime(2026, 3, 8, 8, 0, tzinfo=timezone.utc)
    nxt = next_fire_time("0 9 * * *", after)
    assert nxt == datetime(2026, 3, 8, 9, 0, tzinfo=timezone.utc)


def test_is_due_never_run():
    # Never run should always be due (valid cron)
    assert is_due("0 9 * * *", None) is True


def test_is_due_invalid_cron():
    # Invalid cron expressions should return False, not raise
    assert is_due("invalid cron", None) is False
    assert (
        is_due("invalid cron", datetime(2026, 3, 8, 9, 0, tzinfo=timezone.utc)) is False
    )


def test_is_due_recently_run():
    now = datetime(2026, 3, 8, 9, 30, tzinfo=timezone.utc)
    # Last run was at 9:00, next fire is tomorrow 9:00 — not due
    last_run = datetime(2026, 3, 8, 9, 0, tzinfo=timezone.utc)
    assert is_due("0 9 * * *", last_run, now) is False


def test_is_due_past_due():
    now = datetime(2026, 3, 9, 10, 0, tzinfo=timezone.utc)
    # Last run was 2026-03-08 09:00, next fire is 2026-03-09 09:00 which is <= now
    last_run = datetime(2026, 3, 8, 9, 0, tzinfo=timezone.utc)
    assert is_due("0 9 * * *", last_run, now) is True


def test_format_human_readable():
    # Verify ordinal suffixes
    cases = {
        1: "st",
        2: "nd",
        3: "rd",
        4: "th",
        11: "th",
        12: "th",
        13: "th",
        21: "st",
    }
    for day, expected_suffix in cases.items():
        dt = datetime(2026, 3, day, 9, 0, tzinfo=timezone.utc)
        result = format_human_readable(dt)
        assert f"{day}{expected_suffix}" in result, (
            f"Expected {day}{expected_suffix} in {result}"
        )


def test_format_cron_human_daily():
    assert format_cron_human("0 9 * * *") == "Daily at 9:00 AM"


def test_format_cron_human_weekly():
    assert format_cron_human("0 18 * * 0") == "Every Sunday at 6:00 PM"
