from __future__ import annotations


from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    WorldModelActionPlan,
    WorldModelPlanStep,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.tools_builtin import _STORES, configure_stores, execute_builtin
from memex.utcnow import utcnow


def test_get_item_renders_world_model_action_plan_and_plan_step_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-tools-plan",
        title="Ship docs rollout",
        description="Ship the docs rollout safely.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-tools-rollout",
            goal_id="goal-tools-plan",
            title="Docs rollout plan",
            summary="Drive the rollout with explicit steps.",
            status="active",
            selected_step_id="step-tools-execute",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-tools-prepare",
            plan_id="plan-tools-rollout",
            goal_id="goal-tools-plan",
            step_kind="prep",
            title="Prepare approval package",
            description="Prepare the approval package.",
            status="done",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-tools-execute",
            plan_id="plan-tools-rollout",
            goal_id="goal-tools-plan",
            step_kind="execution",
            title="Execute rollout",
            description="Execute the rollout after approval.",
            status="blocked",
            ordinal=2,
            blocked_reason="Waiting on approval package.",
            depends_on_step_ids=["step-tools-prepare"],
            blocked_by_step_ids=["step-tools-prepare"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    configure_stores(content_store=store.content, memex_store=store)

    try:
        plan_detail = execute_builtin(
            "get_item", {"id": "world_model_action_plan:plan-tools-rollout"}
        )
        step_detail = execute_builtin(
            "get_item", {"id": "world_model_plan_step:step-tools-execute"}
        )

        assert plan_detail.success
        assert (
            "Type: action_plan | ID: world_model_action_plan:plan-tools-rollout"
            in plan_detail.content
        )
        assert "for_goal -> world_model_goal:goal-tools-plan" in plan_detail.content
        assert (
            "selected_step -> world_model_plan_step:step-tools-execute"
            in plan_detail.content
        )
        assert step_detail.success
        assert (
            "Type: execution | ID: world_model_plan_step:step-tools-execute"
            in step_detail.content
        )
        assert (
            "part_of_plan -> world_model_action_plan:plan-tools-rollout"
            in step_detail.content
        )
        assert "for_goal -> world_model_goal:goal-tools-plan" in step_detail.content
        assert (
            "depends_on_step -> world_model_plan_step:step-tools-prepare"
            in step_detail.content
        )
        assert (
            "blocked_by_step -> world_model_plan_step:step-tools-prepare"
            in step_detail.content
        )
    finally:
        _STORES.clear()
