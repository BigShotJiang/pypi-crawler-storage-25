"""Tests for Claude Code integration — mocked ClaudeCodeClient."""

from __future__ import annotations

from unittest.mock import MagicMock

from memex.integrations.claude_code import ClaudeCodeIntegration
from memex.models import ToolResult


def _make_result(content: str = "ok", success: bool = True) -> ToolResult:
    return ToolResult(
        tool_name="claude_code",
        success=success,
        content=content,
        error=None if success else content,
        source="claude_code",
        duration_ms=100,
    )


class TestToolDefinitions:
    def test_returns_five_tools(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        assert len(tools) == 5

    def test_tool_names(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        names = {t.name for t in tools}
        assert names == {
            "claude_code_explain",
            "claude_code_review",
            "claude_code_write",
            "claude_code_refactor",
            "claude_code_debug",
        }

    def test_read_tools_have_read_capability(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        for t in tools:
            if t.name in ("claude_code_explain", "claude_code_review"):
                assert t.required_capability == "claude_code.read"

    def test_write_tools_have_execute_capability(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        for t in tools:
            if t.name in (
                "claude_code_write",
                "claude_code_refactor",
                "claude_code_debug",
            ):
                assert t.required_capability == "claude_code.execute"

    def test_tools_have_keywords(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        for t in tools:
            assert len(t.keywords) > 0

    def test_source_prefix(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        tools = integration.get_tool_definitions()
        for t in tools:
            assert t.source.startswith("claude_code:")


class TestExecuteTool:
    def test_explain_dispatches_with_plan_mode(self):
        client = MagicMock()
        client.execute.return_value = _make_result("explanation here")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool(
            "claude_code_explain", {"prompt": "explain loop.py"}
        )
        assert result.success
        assert result.content == "explanation here"

        call_kwargs = client.execute.call_args[1]
        assert call_kwargs["permission_mode"] == "plan"
        assert call_kwargs["allowed_tools"] == ["Read", "Glob", "Grep"]
        assert call_kwargs["max_turns"] == 3

    def test_review_dispatches_with_plan_mode(self):
        client = MagicMock()
        client.execute.return_value = _make_result("review notes")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool(
            "claude_code_review", {"prompt": "review store.py"}
        )
        assert result.success
        call_kwargs = client.execute.call_args[1]
        assert call_kwargs["permission_mode"] == "plan"

    def test_write_dispatches_with_default_mode(self):
        client = MagicMock()
        client.execute.return_value = _make_result("wrote file")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool(
            "claude_code_write", {"prompt": "write hello.py"}
        )
        assert result.success
        call_kwargs = client.execute.call_args[1]
        assert call_kwargs["permission_mode"] == "default"
        assert "Write" in call_kwargs["allowed_tools"]
        assert "Edit" in call_kwargs["allowed_tools"]
        assert call_kwargs["max_turns"] == 10

    def test_refactor_dispatches_with_default_mode(self):
        client = MagicMock()
        client.execute.return_value = _make_result("refactored")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool(
            "claude_code_refactor", {"prompt": "rename class"}
        )
        assert result.success
        call_kwargs = client.execute.call_args[1]
        assert call_kwargs["permission_mode"] == "default"

    def test_debug_has_bash_access(self):
        client = MagicMock()
        client.execute.return_value = _make_result("found bug")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool("claude_code_debug", {"prompt": "fix crash"})
        assert result.success
        call_kwargs = client.execute.call_args[1]
        assert "Bash" in call_kwargs["allowed_tools"]

    def test_unknown_tool(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        result = integration.execute_tool("claude_code_unknown", {"prompt": "hi"})
        assert not result.success
        assert "Unknown" in result.error

    def test_missing_prompt(self):
        client = MagicMock()
        integration = ClaudeCodeIntegration(client)
        result = integration.execute_tool("claude_code_explain", {})
        assert not result.success
        assert "prompt" in result.error.lower()

    def test_error_propagated(self):
        client = MagicMock()
        client.execute.return_value = _make_result("timeout", success=False)
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool("claude_code_explain", {"prompt": "explain"})
        assert not result.success

    def test_prompt_with_braces_does_not_crash(self):
        """Prompts containing {curly_braces} must not cause format errors."""
        client = MagicMock()
        client.execute.return_value = _make_result("ok")
        integration = ClaudeCodeIntegration(client)

        result = integration.execute_tool(
            "claude_code_explain",
            {"prompt": "explain {__class__} and dict[str, {T}]"},
        )
        assert result.success
        # Verify the full prompt was passed through safely
        call_args = client.execute.call_args[0][0]
        assert "{__class__}" in call_args
        assert "{T}" in call_args

    def test_session_tracking_for_write_tools(self):
        """Write tools track session_id for follow-up resume."""
        client = MagicMock()
        client.execute.return_value = _make_result("wrote it")
        client.last_session_id = "sess-write-1"
        integration = ClaudeCodeIntegration(client)

        # First call — uses execute
        integration.execute_tool("claude_code_write", {"prompt": "write hello.py"})
        client.execute.assert_called_once()

        # Second call — should use resume
        client.resume.return_value = _make_result("continued")
        client.last_session_id = "sess-write-1"
        integration.execute_tool("claude_code_write", {"prompt": "add tests"})
        client.resume.assert_called_once()
        assert client.resume.call_args[0][0] == "sess-write-1"

    def test_failed_resume_clears_stale_session(self):
        """If resume fails, the stale session is cleared so next call starts fresh."""
        client = MagicMock()
        client.execute.return_value = _make_result("wrote it")
        client.last_session_id = "sess-1"
        integration = ClaudeCodeIntegration(client)

        # First call succeeds, stores session
        integration.execute_tool("claude_code_write", {"prompt": "write file"})

        # Second call resumes but fails (e.g., session expired)
        client.resume.return_value = _make_result("session expired", success=False)
        integration.execute_tool("claude_code_write", {"prompt": "continue"})
        client.resume.assert_called_once()

        # Third call should use execute (fresh), not resume
        client.execute.return_value = _make_result("wrote again")
        client.last_session_id = "sess-2"
        integration.execute_tool("claude_code_write", {"prompt": "try again"})
        assert client.execute.call_count == 2  # initial + retry after cleared session

    def test_session_not_tracked_for_read_tools(self):
        """Read tools don't track sessions — each call is independent."""
        client = MagicMock()
        client.execute.return_value = _make_result("explained")
        client.last_session_id = "sess-read-1"
        integration = ClaudeCodeIntegration(client)

        # First call
        integration.execute_tool("claude_code_explain", {"prompt": "explain A"})
        # Second call — should still use execute, not resume
        integration.execute_tool("claude_code_explain", {"prompt": "explain B"})
        assert client.execute.call_count == 2
        client.resume.assert_not_called()
