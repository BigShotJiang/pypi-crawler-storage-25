"""Integration tests — verify domain events are published at all mutation sites."""

import threading
from unittest.mock import patch

import pytest

from memex.event_bus import EventBus, reset_bus
from memex.events import (
    GoalCreated,
    GoalStatusChanged,
    GoalUpdated,
    ItemIngested,
    NotificationCreated,
    NotificationDismissed,
    TaskRunCompleted,
)


@pytest.fixture(autouse=True)
def _clean_bus():
    reset_bus()
    yield
    reset_bus()


def _make_bus_and_collector(event_type):
    """Create a bus, subscribe to event_type, return (bus, received_list, done_event)."""
    bus = EventBus()
    bus.start()
    received = []
    done = threading.Event()

    def handler(event):
        received.append(event)
        done.set()

    bus.subscribe(event_type, handler)
    return bus, received, done


class TestReflectPublishesGoalEvents:
    """reflect.apply_reflect_result publishes goal mutation events."""

    def test_touch_advanced_goal(self, tmp_path):
        from memex.models import ReflectResult
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        bus, received, done = _make_bus_and_collector(GoalUpdated)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Test goal")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="advanced",
            intent_advanced=[goal.goal_id],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].goal_id == goal.goal_id
        store.close()

    def test_complete_goal(self, tmp_path):
        from memex.models import ReflectResult
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        bus, received, done = _make_bus_and_collector(GoalStatusChanged)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Completable")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="done",
            goals_to_complete=[goal.goal_id],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].new_status == "completed"
        assert received[0].old_status == "active"
        store.close()

    def test_create_subgoal(self, tmp_path):
        from memex.models import ReflectResult, NewSubgoal, GoalPriority
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        bus, received, done = _make_bus_and_collector(GoalCreated)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)

        result = ReflectResult(
            reflection_note="new subgoal",
            new_subgoals=[
                NewSubgoal(
                    parent_id="",
                    title="Sub task",
                    description="Do the thing",
                    priority=GoalPriority.MEDIUM,
                ),
            ],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].title == "Sub task"
        store.close()


class TestNotificationPublishesEvents:
    """NotificationRouter.notify and NotificationStore.dismiss publish events."""

    def test_notify_publishes_created(self, tmp_path):
        from memex.notifications import NotificationRouter
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        bus, received, done = _make_bus_and_collector(NotificationCreated)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        ns = store.notifications
        router = NotificationRouter(ns)

        with patch("memex.event_bus.get_bus", return_value=bus):
            notification = router.notify("Test notification", source="test")

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].title == "Test notification"
        assert received[0].notification_id == notification.notification_id
        store.close()

    def test_dismiss_publishes_dismissed(self, tmp_path):
        from memex.notifications import NotificationRouter
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        bus, received, done = _make_bus_and_collector(NotificationDismissed)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        ns = store.notifications
        router = NotificationRouter(ns)

        # Create a notification first (without event bus)
        notification = router.notify("To dismiss", source="test")

        with patch("memex.event_bus.get_bus", return_value=bus):
            ns.dismiss(notification.notification_id)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].notification_id == notification.notification_id
        store.close()


class TestIngestPublishesItemIngested:
    """ingest() publishes ItemIngested for new and re-ingested items."""

    def test_new_item(self, tmp_path):
        from memex.memory.intake import ingest
        from memex.models import ItemType
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        bus, received, done = _make_bus_and_collector(ItemIngested)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        cs = store.content

        with patch("memex.event_bus.get_bus", return_value=bus):
            item = ingest(
                content="Some content",
                title="New item",
                type=ItemType.NOTE,
                content_store=cs,
                generate_summary=False,
            )

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].item_id == item.item_id
        assert received[0].is_update is False
        store.close()

    def test_re_ingest_is_update(self, tmp_path):
        from memex.memory.intake import ingest
        from memex.models import ItemType
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        bus, received, done = _make_bus_and_collector(ItemIngested)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        cs = store.content

        # First ingest (without bus)
        item = ingest(
            content="Original",
            title="Versioned",
            type=ItemType.NOTE,
            source_url="https://example.com/doc",
            content_store=cs,
            generate_summary=False,
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            ingest(
                content="Updated content",
                title="Versioned",
                type=ItemType.NOTE,
                source_url="https://example.com/doc",
                content_store=cs,
                generate_summary=False,
            )

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].item_id == item.item_id
        assert received[0].is_update is True
        store.close()


class TestWorkQueuePublishesTaskRunCompleted:
    """WorkQueue publishes TaskRunCompleted on success and final failure."""

    def test_success(self):
        from memex.scheduler.work_queue import WorkQueue, WorkItem

        bus, received, done = _make_bus_and_collector(TaskRunCompleted)
        consumer = WorkQueue()
        consumer.register_dispatcher("test", lambda data, run_id: "ok")
        consumer.start()

        item = WorkItem(
            priority=1,
            task_id="t1",
            run_id=1,
            action_type="test",
            action_data={},
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            consumer.enqueue(item)
            done.wait(timeout=3)

        consumer.stop()
        bus.stop()
        assert len(received) == 1
        assert received[0].task_id == "t1"
        assert received[0].status == "completed"

    def test_failure_after_retries(self):
        from memex.scheduler.work_queue import WorkQueue, WorkItem

        bus, received, done = _make_bus_and_collector(TaskRunCompleted)

        def fail_dispatcher(data, run_id):
            raise RuntimeError("boom")

        consumer = WorkQueue()
        consumer.register_dispatcher("test", fail_dispatcher)
        consumer.start()

        item = WorkItem(
            priority=1,
            task_id="t2",
            run_id=2,
            action_type="test",
            action_data={},
            max_retries=0,  # fail immediately, no retries
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            consumer.enqueue(item)
            done.wait(timeout=3)

        consumer.stop()
        bus.stop()
        assert len(received) == 1
        assert received[0].task_id == "t2"
        assert received[0].status == "failed"


class TestReflectStatusTransitions:
    """Pause, block, and fail goal transitions emit GoalStatusChanged."""

    def test_pause_goal(self, tmp_path):
        from memex.models import ReflectResult
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        bus, received, done = _make_bus_and_collector(GoalStatusChanged)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Pausable")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="pause",
            goals_to_pause=[goal.goal_id],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].new_status == "paused"
        assert received[0].old_status == "active"
        store.close()

    def test_block_goal(self, tmp_path):
        from memex.models import ReflectResult, GoalBlock
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        bus, received, done = _make_bus_and_collector(GoalStatusChanged)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Blockable")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="blocked",
            goals_to_block=[GoalBlock(goal_id=goal.goal_id, reason="waiting on X")],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].new_status == "blocked"
        store.close()

    def test_fail_goal(self, tmp_path):
        from memex.models import ReflectResult, GoalFail
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        bus, received, done = _make_bus_and_collector(GoalStatusChanged)
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Failable")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="failed",
            goals_to_fail=[GoalFail(goal_id=goal.goal_id, reason="impossible")],
        )

        with patch("memex.event_bus.get_bus", return_value=bus):
            apply_reflect_result(result, store)

        done.wait(timeout=2)
        bus.stop()
        assert len(received) == 1
        assert received[0].new_status == "failed"
        store.close()


class TestPublisherFailureIsolation:
    """Event publishing failures must never crash the mutation path."""

    def test_ingest_succeeds_when_bus_unavailable(self, tmp_path):
        """ingest() completes even when get_bus() raises."""
        from memex.memory.intake import ingest
        from memex.models import ItemType
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        cs = store.content

        with patch("memex.event_bus.get_bus", side_effect=RuntimeError("bus broken")):
            item = ingest(
                content="Should still work",
                title="Bus broken item",
                type=ItemType.NOTE,
                content_store=cs,
                generate_summary=False,
            )

        assert item is not None
        assert item.title == "Bus broken item"
        # Item was persisted despite bus failure
        fetched = cs.get_item(item.item_id)
        assert fetched is not None
        store.close()

    def test_reflect_applies_when_bus_unavailable(self, tmp_path):
        """apply_reflect_result() completes even when get_bus() raises."""
        from memex.models import ReflectResult
        from memex.reflect import apply_reflect_result
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from conftest import make_goal

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        goal = make_goal(title="Survivable")
        store.create_goal(goal)

        result = ReflectResult(
            reflection_note="advance",
            goals_to_complete=[goal.goal_id],
        )

        with patch("memex.event_bus.get_bus", side_effect=RuntimeError("bus broken")):
            apply_reflect_result(result, store)

        # Goal was still completed despite bus failure
        updated = store.get_goal(goal.goal_id)
        assert updated.status.value == "completed"
        store.close()
