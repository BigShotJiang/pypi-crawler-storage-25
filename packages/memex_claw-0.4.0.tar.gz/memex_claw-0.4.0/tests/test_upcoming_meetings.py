"""Tests for upcoming meeting syncing and briefing helpers."""

from __future__ import annotations

from datetime import timedelta
from unittest.mock import MagicMock

from memex.meetings.models import MeetingRecord, MeetingState
from memex.meetings.upcoming import prepare_meeting_briefings
from memex.models import (
    CalendarEvent,
    Goal,
    GoalStatus,
    MeetingGoalLink,
    NotificationPriority,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


def test_prepare_meeting_briefings_from_calendar_event_links_goal_entities(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()

    mock_content = MagicMock()
    mock_content.find_entity.side_effect = lambda name, entity_type: {
        ("Alice Example", "person"): "entity-alice",
        ("Project Atlas", "concept"): "entity-atlas",
    }.get((name, entity_type))
    mock_content.create_entity.side_effect = lambda name, entity_type: {
        ("Alice Example", "person"): "entity-alice",
        ("Project Atlas", "concept"): "entity-atlas",
    }.get((name, entity_type), f"{entity_type}:{name}")
    store._content_store = mock_content

    goal = Goal(
        goal_id="goal-1",
        title="Prepare Project Atlas plan with Alice Example",
        status=GoalStatus.ACTIVE,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
    )
    store.create_goal(goal)

    store.upsert_calendar_event(
        CalendarEvent(
            event_id="evt-1",
            provider="google",
            title="1:1 with Alice",
            starts_at=now + timedelta(hours=2),
            attendees=["Alice Example"],
            synced_at=now,
        )
    )

    ns = store.notifications
    created = prepare_meeting_briefings(store, ns, now=now)
    assert created == 1

    pending = ns.list_pending(limit=10)
    assert len(pending) == 1
    assert pending[0].title == "Prep: 1:1 with Alice"
    assert pending[0].priority == NotificationPriority.NORMAL
    assert pending[0].goal_id == "goal-1"
    assert pending[0].action_data["event_id"] == "evt-1"
    assert "Project Atlas" in pending[0].body
    store.close()


def test_prepare_meeting_briefings_from_memex_meeting_explicit_goal_link(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    store._content_store = MagicMock()
    store._content_store.find_entity.return_value = None
    store._content_store.create_entity.return_value = "entity-bob"

    goal = Goal(
        goal_id="goal-2",
        title="Review launch checklist",
        status=GoalStatus.ACTIVE,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        deadline=now + timedelta(hours=8),
    )
    store.create_goal(goal)

    meeting = MeetingRecord(
        meeting_id="mtg-1",
        state=MeetingState.CREATED,
        title="Launch review",
        scheduled_for=now + timedelta(hours=3),
        attendees=["Bob Reviewer"],
        calendar_source="memex",
        created_at=now,
        updated_at=now,
    )
    store.meetings.create_meeting(meeting)
    store.create_meeting_goal_link(
        MeetingGoalLink(
            meeting_id="mtg-1",
            goal_id="goal-2",
            relationship="explicit",
            created_at=now,
        )
    )

    ns = store.notifications
    created = prepare_meeting_briefings(store, ns, now=now)
    assert created == 1

    pending = ns.list_pending(limit=10)
    assert len(pending) == 1
    assert pending[0].action_data["meeting_id"] == "mtg-1"
    assert "deadline" in pending[0].body.lower()
    store.close()
