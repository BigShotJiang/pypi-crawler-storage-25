"""Tests for cleanup_audio()."""

from datetime import datetime, timedelta

from memex.meetings.cleanup import cleanup_audio
from memex.meetings.models import MeetingRecord, MeetingState
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_meeting(
    meeting_id: str = "mtg-1",
    state: MeetingState = MeetingState.INGESTED,
    audio_path: str = "/tmp/audio.wav",
    stopped_at: datetime | None = None,
    audio_deleted: bool = False,
) -> MeetingRecord:
    now = utcnow()
    return MeetingRecord(
        meeting_id=meeting_id,
        state=state,
        title="Test Meeting",
        audio_path=audio_path,
        started_at=now,
        stopped_at=stopped_at or now,
        created_at=now,
        updated_at=now,
        audio_deleted=audio_deleted,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_cleanup_deletes_old_audio(tmp_path):
    """Create a temp WAV file, set meeting state=ingested with old stopped_at, verify file deleted."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    audio_file = tmp_path / "old_meeting.wav"
    audio_file.write_bytes(b"\x00" * 100)
    assert audio_file.exists()

    old_time = utcnow() - timedelta(days=5)
    record = _make_meeting(
        meeting_id="mtg-old",
        state=MeetingState.INGESTED,
        audio_path=str(audio_file),
        stopped_at=old_time,
        audio_deleted=False,
    )
    ms.create_meeting(record)

    count = cleanup_audio(ms, retention_days=3)

    assert count == 1
    assert not audio_file.exists()

    updated = ms.get_meeting("mtg-old")
    assert updated is not None
    assert updated.audio_deleted is True

    store.close()


def test_cleanup_skips_recent_audio(tmp_path):
    """Meeting stopped recently (within retention), file not deleted."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    audio_file = tmp_path / "recent_meeting.wav"
    audio_file.write_bytes(b"\x00" * 100)

    recent_time = utcnow() - timedelta(hours=6)
    record = _make_meeting(
        meeting_id="mtg-recent",
        state=MeetingState.INGESTED,
        audio_path=str(audio_file),
        stopped_at=recent_time,
        audio_deleted=False,
    )
    ms.create_meeting(record)

    count = cleanup_audio(ms, retention_days=3)

    assert count == 0
    assert audio_file.exists()

    updated = ms.get_meeting("mtg-recent")
    assert updated is not None
    assert updated.audio_deleted is False

    store.close()


def test_cleanup_skips_already_deleted(tmp_path):
    """audio_deleted=True, no attempt to delete."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    old_time = utcnow() - timedelta(days=5)
    record = _make_meeting(
        meeting_id="mtg-already",
        state=MeetingState.INGESTED,
        audio_path="/tmp/gone.wav",
        stopped_at=old_time,
        audio_deleted=True,
    )
    ms.create_meeting(record)

    count = cleanup_audio(ms, retention_days=3)

    # audio_deleted=True means get_meetings_for_cleanup won't return it
    assert count == 0

    store.close()


def test_cleanup_skips_non_ingested(tmp_path):
    """state=transcribed, not cleaned up."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    old_time = utcnow() - timedelta(days=5)
    record = _make_meeting(
        meeting_id="mtg-transcribed",
        state=MeetingState.TRANSCRIBED,
        audio_path="/tmp/transcribed.wav",
        stopped_at=old_time,
        audio_deleted=False,
    )
    ms.create_meeting(record)

    count = cleanup_audio(ms, retention_days=3)

    assert count == 0

    store.close()


def test_cleanup_handles_missing_file(tmp_path):
    """Audio file doesn't exist on disk, still marks audio_deleted=True."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    old_time = utcnow() - timedelta(days=5)
    record = _make_meeting(
        meeting_id="mtg-missing",
        state=MeetingState.INGESTED,
        audio_path="/tmp/nonexistent_audio_file_12345.wav",
        stopped_at=old_time,
        audio_deleted=False,
    )
    ms.create_meeting(record)

    count = cleanup_audio(ms, retention_days=3)

    assert count == 1

    updated = ms.get_meeting("mtg-missing")
    assert updated is not None
    assert updated.audio_deleted is True

    store.close()


def test_cleanup_returns_count(tmp_path):
    """Verify return value matches number deleted."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings

    old_time = utcnow() - timedelta(days=10)

    for i in range(4):
        audio_file = tmp_path / f"meeting_{i}.wav"
        audio_file.write_bytes(b"\x00" * 50)
        record = _make_meeting(
            meeting_id=f"mtg-{i}",
            state=MeetingState.INGESTED,
            audio_path=str(audio_file),
            stopped_at=old_time,
            audio_deleted=False,
        )
        ms.create_meeting(record)

    # Add one that should NOT be cleaned up (recent)
    recent_file = tmp_path / "meeting_recent.wav"
    recent_file.write_bytes(b"\x00" * 50)
    recent_record = _make_meeting(
        meeting_id="mtg-recent",
        state=MeetingState.INGESTED,
        audio_path=str(recent_file),
        stopped_at=utcnow(),
        audio_deleted=False,
    )
    ms.create_meeting(recent_record)

    count = cleanup_audio(ms, retention_days=3)

    assert count == 4

    # Verify all old files deleted
    for i in range(4):
        assert not (tmp_path / f"meeting_{i}.wav").exists()

    # Verify recent file still exists
    assert recent_file.exists()

    store.close()
