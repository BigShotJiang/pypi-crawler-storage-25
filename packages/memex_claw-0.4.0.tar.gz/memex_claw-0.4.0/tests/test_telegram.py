"""Tests for Telegram bot interface — auth, message handling, response splitting."""

from __future__ import annotations

import asyncio
import os
from datetime import date
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from memex.utcnow import utcnow

from memex.interfaces.telegram import (
    TelegramBot,
    TelegramConfig,
    _URL_PATTERN,
    config_from_env,
    split_at_paragraphs,
)
from memex.models import SessionContext


# ---------------------------------------------------------------------------
# config_from_env
# ---------------------------------------------------------------------------


class TestConfigFromEnv:
    @patch.dict(
        os.environ,
        {
            "TELEGRAM_BOT_TOKEN": "123:ABC",
            "TELEGRAM_USER_ID": "42",
        },
    )
    def test_basic_config(self):
        config = config_from_env()
        assert config is not None
        assert config.bot_token == "123:ABC"
        assert config.allowed_user_ids == {42}

    @patch.dict(
        os.environ,
        {
            "TELEGRAM_BOT_TOKEN": "123:ABC",
            "TELEGRAM_USER_ID": "42,99",
        },
    )
    def test_multiple_user_ids(self):
        config = config_from_env()
        assert config is not None
        assert config.allowed_user_ids == {42, 99}

    @patch.dict(os.environ, {}, clear=True)
    def test_missing_token_returns_none(self):
        assert config_from_env() is None

    @patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "123:ABC"}, clear=True)
    def test_missing_user_id_returns_none(self):
        assert config_from_env() is None

    @patch.dict(
        os.environ,
        {
            "TELEGRAM_BOT_TOKEN": "123:ABC",
            "TELEGRAM_USER_ID": "not-a-number",
        },
    )
    def test_invalid_user_id_returns_none(self):
        assert config_from_env() is None

    @patch.dict(
        os.environ,
        {
            "TELEGRAM_BOT_TOKEN": "123:ABC",
            "TELEGRAM_USER_ID": "42",
            "MEMEX_TELEGRAM_POLL_INTERVAL": "5",
            "MEMEX_TELEGRAM_BATCH_WINDOW": "60",
        },
    )
    def test_custom_settings(self):
        config = config_from_env()
        assert config is not None
        assert config.poll_interval == 5.0
        assert config.batch_window_seconds == 60

    @patch.dict(
        os.environ,
        {
            "TELEGRAM_BOT_TOKEN": "123:ABC",
            "TELEGRAM_USER_ID": "",
        },
    )
    def test_empty_user_id_returns_none(self):
        assert config_from_env() is None


# ---------------------------------------------------------------------------
# split_at_paragraphs
# ---------------------------------------------------------------------------


class TestSplitAtParagraphs:
    def test_short_text_no_split(self):
        assert split_at_paragraphs("hello world") == ["hello world"]

    def test_exact_limit_no_split(self):
        text = "a" * 4000
        assert split_at_paragraphs(text, max_length=4000) == [text]

    def test_splits_at_paragraph_boundary(self):
        para1 = "A" * 2000
        para2 = "B" * 2000
        text = f"{para1}\n\n{para2}"
        chunks = split_at_paragraphs(text, max_length=2500)
        assert len(chunks) == 2
        assert chunks[0] == para1
        assert chunks[1] == para2

    def test_preserves_paragraph_grouping(self):
        text = "short1\n\nshort2\n\nshort3"
        chunks = split_at_paragraphs(text, max_length=100)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_hard_split_for_long_paragraph(self):
        long_para = "X" * 5000
        chunks = split_at_paragraphs(long_para, max_length=2000)
        assert len(chunks) == 3
        assert len(chunks[0]) == 2000
        assert len(chunks[1]) == 2000
        assert len(chunks[2]) == 1000

    def test_empty_text(self):
        assert split_at_paragraphs("") == [""]

    def test_mixed_short_and_long(self):
        short = "Hello"
        long_para = "X" * 5000
        text = f"{short}\n\n{long_para}"
        chunks = split_at_paragraphs(text, max_length=3000)
        assert len(chunks) >= 2
        assert chunks[0] == short


# ---------------------------------------------------------------------------
# TelegramBot — auth
# ---------------------------------------------------------------------------


def _make_config(**overrides) -> TelegramConfig:
    defaults = {
        "bot_token": "fake:token",
        "allowed_user_ids": {42},
    }
    defaults.update(overrides)
    return TelegramConfig(**defaults)


def _make_update(user_id: int = 42, text: str = "hello") -> MagicMock:
    update = MagicMock()
    update.effective_user = MagicMock()
    update.effective_user.id = user_id
    update.message = MagicMock()
    update.message.text = text
    update.message.chat_id = 100
    update.message.reply_text = AsyncMock()
    return update


def _make_context() -> MagicMock:
    ctx = MagicMock()
    ctx.bot = MagicMock()
    ctx.bot.send_chat_action = AsyncMock()
    ctx.args = []
    return ctx


class TestAuthCheck:
    @pytest.mark.asyncio
    async def test_authorized_user(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        assert await bot._auth_check(update) is True

    @pytest.mark.asyncio
    async def test_unauthorized_user(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=999)
        assert await bot._auth_check(update) is False

    @pytest.mark.asyncio
    async def test_no_user(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = MagicMock()
        update.effective_user = None
        assert await bot._auth_check(update) is False


# ---------------------------------------------------------------------------
# TelegramBot — message handling
# ---------------------------------------------------------------------------


class TestHandleMessage:
    @pytest.fixture(autouse=True)
    def llm_available(self):
        """Default: LLM is available. Tests that need LLM-down behavior override this."""
        with patch(
            "memex.interfaces.telegram.TelegramBot._check_llm_available",
            return_value=True,
        ):
            yield

    @pytest.mark.asyncio
    async def test_authorized_message_calls_run_turn(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42, text="what are my goals?")
        context = _make_context()

        with patch.object(bot, "_run_turn", return_value="You have 3 goals."):
            await bot.handle_message(update, context)

        update.message.reply_text.assert_called_once()
        response = update.message.reply_text.call_args[0][0]
        assert "3 goals" in response

    @pytest.mark.asyncio
    async def test_unauthorized_message_no_response(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=999, text="hack!")
        context = _make_context()

        await bot.handle_message(update, context)

        update.message.reply_text.assert_not_called()

    @pytest.mark.asyncio
    async def test_typing_indicator_sent(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        context = _make_context()

        with patch.object(bot, "_run_turn", return_value="response"):
            await bot.handle_message(update, context)

        context.bot.send_chat_action.assert_called_once_with(
            chat_id=100, action="typing"
        )

    @pytest.mark.asyncio
    async def test_chat_id_auto_captured(self):
        config = _make_config()
        assert config.owner_chat_id is None

        bot = TelegramBot(config, MagicMock())
        update = _make_update(user_id=42)
        update.message.chat_id = 12345
        context = _make_context()

        with patch.object(bot, "_run_turn", return_value="hi"):
            await bot.handle_message(update, context)

        assert config.owner_chat_id == 12345

    @pytest.mark.asyncio
    async def test_error_returns_error_message(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        context = _make_context()

        with patch.object(bot, "_run_turn", side_effect=RuntimeError("boom")):
            await bot.handle_message(update, context)

        update.message.reply_text.assert_called_once()
        assert "error" in update.message.reply_text.call_args[0][0].lower()

    @pytest.mark.asyncio
    async def test_empty_message_ignored(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        update.message.text = None
        context = _make_context()

        await bot.handle_message(update, context)

        update.message.reply_text.assert_not_called()

    @pytest.mark.asyncio
    async def test_url_in_message_triggers_auto_ingest(self):
        bot = TelegramBot(_make_config(), MagicMock())
        url = "https://example.com/article"
        update = _make_update(user_id=42, text=f"Check this out {url}")
        context = _make_context()

        with (
            patch.object(bot, "_run_turn", return_value="Interesting!"),
            patch.object(bot, "_schedule_background_url_ingest") as mock_schedule,
        ):
            await bot.handle_message(update, context)

        mock_schedule.assert_called_once_with(update.message, [url])
        assert update.message.reply_text.call_count == 1
        assert update.message.reply_text.call_args_list[0][0][0] == "Interesting!"

    @pytest.mark.asyncio
    async def test_bare_url_message_uses_deterministic_ingest_path(self):
        api = MagicMock()
        bot = TelegramBot(_make_config(), api)
        url = "https://example.com/article"
        update = _make_update(user_id=42, text=url)
        context = _make_context()

        with (
            patch.object(
                bot,
                "_auto_ingest_urls_detailed",
                return_value=(
                    [
                        {
                            "item_id": "abc",
                            "title": "Example Article",
                            "summary": "Short article summary.",
                            "ingest_run_id": "run-1",
                            "operation_stats": {
                                "phase_timings_ms": {
                                    "extract": 11,
                                    "project": 7,
                                    "summary": 0,
                                    "total": 18,
                                },
                                "total_ms": 18,
                            },
                        }
                    ],
                    [],
                ),
            ) as mock_ingest,
            patch.object(
                bot,
                "_run_turn",
                side_effect=AssertionError("run_turn should not be used"),
            ),
        ):
            await bot.handle_message(update, context)

        mock_ingest.assert_called_once_with([url])
        replies = [call.args[0] for call in update.message.reply_text.call_args_list]
        assert len(replies) == 3
        assert "Saving that URL now." in replies[0]
        assert 'Saved "Example Article".' in replies[1]
        assert "Short article summary." in replies[1]
        assert "Auto-saved" in replies[2]
        assert bot._last_operation_stats["path"] == "telegram_url_capture"
        assert bot._last_operation_stats["used_llm"] is False
        assert bot._last_operation_stats["url_ingest"]["mode"] == "inline"
        assert (
            bot._last_operation_stats["url_ingest"]["per_url"][0]["operation_stats"][
                "phase_timings_ms"
            ]["extract"]
            == 11
        )

    @pytest.mark.asyncio
    async def test_save_wrapper_url_message_skips_run_turn_even_if_llm_down(self):
        api = MagicMock()
        bot = TelegramBot(_make_config(), api)
        url = "https://example.com/article"
        update = _make_update(user_id=42, text=f"Please save this article {url}")
        context = _make_context()

        with (
            patch.object(bot, "_check_llm_available", return_value=False),
            patch.object(
                bot,
                "_auto_ingest_urls_detailed",
                return_value=(
                    [{"item_id": "abc", "title": "Example Article", "summary": ""}],
                    [],
                ),
            ) as mock_ingest,
            patch.object(
                bot,
                "_run_turn",
                side_effect=AssertionError("run_turn should not be used"),
            ),
        ):
            await bot.handle_message(update, context)

        mock_ingest.assert_called_once_with([url])
        api.enqueue_work.assert_not_called()
        replies = [call.args[0] for call in update.message.reply_text.call_args_list]
        assert len(replies) == 3
        assert "Saving that URL now." in replies[0]
        assert 'Saved "Example Article"' in replies[1]
        assert "Auto-saved" in replies[2]

    @pytest.mark.asyncio
    async def test_conversational_url_message_uses_chat_path_and_schedules_background_ingest(
        self,
    ):
        bot = TelegramBot(_make_config(), MagicMock())
        url = "https://example.com/article"
        update = _make_update(user_id=42, text=f"Check this out {url}")
        context = _make_context()
        bot._session = SessionContext(
            session_id="telegram_2026-03-22",
            started_at=utcnow(),
        )
        bot._session.working_memory["_turn_runtime_stats"] = {
            "phase_timings_ms": {"total": 12, "llm": 8},
            "turn_ordinal": 1,
        }

        with (
            patch.object(
                bot, "_run_turn", return_value="Interesting!"
            ) as mock_run_turn,
            patch.object(
                bot,
                "_auto_ingest_urls_detailed",
                side_effect=AssertionError(
                    "URL ingest should be scheduled, not run inline"
                ),
            ),
            patch.object(bot, "_schedule_background_url_ingest") as mock_schedule,
        ):
            await bot.handle_message(update, context)

        mock_run_turn.assert_called_once_with(f"Check this out {url}")
        mock_schedule.assert_called_once_with(update.message, [url])
        assert bot._last_operation_stats["path"] == "telegram_mixed_url_message"
        assert bot._last_operation_stats["url_ingest"]["status"] == "scheduled"

    @pytest.mark.asyncio
    async def test_background_url_ingest_merges_operation_stats(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(
            user_id=42, text="Check this out https://example.com/article"
        )
        bot._last_operation_stats = {
            "path": "telegram_mixed_url_message",
            "used_llm": True,
            "turn_runtime_stats": {"phase_timings_ms": {"total": 14}},
            "url_ingest": {"mode": "background", "status": "scheduled", "url_count": 1},
        }

        with patch.object(
            bot,
            "_auto_ingest_urls_detailed",
            return_value=(
                [
                    {
                        "item_id": "abc",
                        "title": "Example Article",
                        "source_url": "https://example.com/article",
                        "ingest_run_id": "run-123",
                        "operation_stats": {
                            "phase_timings_ms": {
                                "extract": 21,
                                "project": 9,
                                "summary": 0,
                                "total": 30,
                            },
                            "total_ms": 30,
                        },
                    }
                ],
                [],
            ),
        ):
            await bot._finish_background_url_ingest(
                update.message, ["https://example.com/article"]
            )

        reply = update.message.reply_text.call_args[0][0]
        assert "Auto-saved" in reply
        assert bot._last_operation_stats["url_ingest"]["status"] == "completed"
        assert (
            bot._last_operation_stats["url_ingest"]["per_url"][0]["operation_stats"][
                "phase_timings_ms"
            ]["project"]
            == 9
        )

    @pytest.mark.asyncio
    async def test_no_url_skips_auto_ingest(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42, text="Hello, how are you?")
        context = _make_context()

        with patch.object(bot, "_run_turn", return_value="I'm good!"):
            with patch.object(bot, "_auto_ingest_urls") as mock_ingest:
                await bot.handle_message(update, context)

        mock_ingest.assert_not_called()

    @pytest.mark.asyncio
    async def test_auto_ingest_failure_still_sends_response(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42, text="See https://example.com/broken")
        context = _make_context()

        with (
            patch.object(bot, "_run_turn", return_value="Noted."),
            patch.object(bot, "_schedule_background_url_ingest") as mock_schedule,
        ):
            await bot.handle_message(update, context)

        assert update.message.reply_text.call_count == 1
        update.message.reply_text.assert_any_call("Noted.")
        mock_schedule.assert_called_once_with(
            update.message,
            ["https://example.com/broken"],
        )

    @pytest.mark.asyncio
    async def test_handle_message_queues_when_llm_down(self, llm_available):
        """When LLM is down at pre-flight check, message is queued and user notified."""
        api = MagicMock()
        api.enqueue_work.return_value = 42
        bot = TelegramBot(_make_config(), api)
        update = _make_update(user_id=42, text="hello")
        context = _make_context()

        with patch.object(bot, "_check_llm_available", return_value=False):
            await bot.handle_message(update, context)

        # run_turn should NOT be called
        # Message should say "queued"
        update.message.reply_text.assert_called_once()
        reply = update.message.reply_text.call_args[0][0]
        assert "queued" in reply.lower()
        api.enqueue_work.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_message_queues_when_llm_down_no_engine(self, llm_available):
        """When LLM is down but no engine is available, user gets fallback message."""
        api = MagicMock()
        api.enqueue_work.return_value = None  # engine not set
        bot = TelegramBot(_make_config(), api)
        update = _make_update(user_id=42, text="hello")
        context = _make_context()

        with patch.object(bot, "_check_llm_available", return_value=False):
            await bot.handle_message(update, context)

        update.message.reply_text.assert_called_once()
        reply = update.message.reply_text.call_args[0][0]
        assert "unavailable" in reply.lower()

    @pytest.mark.asyncio
    async def test_handle_message_queues_on_post_failure_llm_down(self, llm_available):
        """When run_turn fails and LLM is detected as down, message is queued."""
        api = MagicMock()
        api.enqueue_work.return_value = 99
        bot = TelegramBot(_make_config(), api)
        update = _make_update(user_id=42, text="hello")
        context = _make_context()

        check_results = [True, False]  # up before, down after failure

        def _side_effect():
            return check_results.pop(0)

        with patch.object(bot, "_check_llm_available", side_effect=_side_effect):
            with patch.object(bot, "_run_turn", side_effect=RuntimeError("proxy down")):
                await bot.handle_message(update, context)

        update.message.reply_text.assert_called_once()
        reply = update.message.reply_text.call_args[0][0]
        assert "queued" in reply.lower()
        api.enqueue_work.assert_called_once()


# ---------------------------------------------------------------------------
# TelegramBot — response splitting
# ---------------------------------------------------------------------------


class TestSendResponse:
    @pytest.mark.asyncio
    async def test_short_response_single_message(self):
        bot = TelegramBot(_make_config(), MagicMock())
        message = MagicMock()
        message.reply_text = AsyncMock()

        await bot._send_response(message, "short response")

        message.reply_text.assert_called_once_with("short response")

    @pytest.mark.asyncio
    async def test_long_response_split_into_chunks(self):
        bot = TelegramBot(_make_config(), MagicMock())
        message = MagicMock()
        message.reply_text = AsyncMock()

        para1 = "A" * 2500
        para2 = "B" * 2500
        response = f"{para1}\n\n{para2}"

        await bot._send_response(message, response)

        assert message.reply_text.call_count == 2
        # Check pagination suffixes
        first_call = message.reply_text.call_args_list[0][0][0]
        assert "(1/2)" in first_call
        second_call = message.reply_text.call_args_list[1][0][0]
        assert "(2/2)" in second_call


# ---------------------------------------------------------------------------
# TelegramBot — forwarded messages
# ---------------------------------------------------------------------------


class TestHandleForwarded:
    @pytest.mark.asyncio
    async def test_forwarded_ingested(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42, text="forwarded article content")
        context = _make_context()

        with patch.object(bot, "_run_turn", return_value="Ingested article."):
            await bot.handle_forwarded(update, context)

        update.message.reply_text.assert_called_once()
        response = update.message.reply_text.call_args[0][0]
        assert "Captured" in response

    @pytest.mark.asyncio
    async def test_forwarded_no_content(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        update.message.text = None
        update.message.caption = None
        context = _make_context()

        await bot.handle_forwarded(update, context)

        update.message.reply_text.assert_called_once()
        assert "No text" in update.message.reply_text.call_args[0][0]

    @pytest.mark.asyncio
    async def test_forwarded_unauthorized(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=999)
        context = _make_context()

        await bot.handle_forwarded(update, context)

        update.message.reply_text.assert_not_called()


# ---------------------------------------------------------------------------
# TelegramBot — /status command
# ---------------------------------------------------------------------------


class TestHandleStatus:
    @pytest.mark.asyncio
    async def test_status_shows_goals(self):
        api = MagicMock()
        api.status.return_value = {
            "goals_total": 5,
            "goals_active": 1,
            "connectors": [],
        }

        bot = TelegramBot(_make_config(), api)
        update = _make_update(user_id=42)
        context = _make_context()

        await bot.handle_command_status(update, context)

        update.message.reply_text.assert_called_once()
        response = update.message.reply_text.call_args[0][0]
        assert "1 active goals" in response

    @pytest.mark.asyncio
    async def test_status_unauthorized(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=999)
        context = _make_context()

        await bot.handle_command_status(update, context)

        update.message.reply_text.assert_not_called()


# ---------------------------------------------------------------------------
# TelegramBot — /search command
# ---------------------------------------------------------------------------


class TestHandleSearch:
    @pytest.mark.asyncio
    async def test_search_with_query(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        context = _make_context()
        context.args = ["python", "decorators"]

        with patch.object(bot, "_run_turn", return_value="Found 3 results."):
            await bot.handle_command_search(update, context)

        update.message.reply_text.assert_called_once()
        assert "3 results" in update.message.reply_text.call_args[0][0]

    @pytest.mark.asyncio
    async def test_search_no_query(self):
        bot = TelegramBot(_make_config(), MagicMock())
        update = _make_update(user_id=42)
        context = _make_context()
        context.args = []

        await bot.handle_command_search(update, context)

        update.message.reply_text.assert_called_once()
        assert "Usage" in update.message.reply_text.call_args[0][0]


# ---------------------------------------------------------------------------
# TelegramBot — session management
# ---------------------------------------------------------------------------


class TestSession:
    def test_caller_per_day(self):
        bot = TelegramBot(_make_config(), MagicMock())
        caller = bot._get_caller()
        today = date.today().isoformat()
        assert caller.session_id == f"telegram_{today}"
        assert caller.interface == "telegram"

    def test_caller_reused_same_day(self):
        bot = TelegramBot(_make_config(), MagicMock())
        c1 = bot._get_caller()
        c2 = bot._get_caller()
        assert c1.session_id == c2.session_id


# ---------------------------------------------------------------------------
# TelegramBot — build_application
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# URL extraction
# ---------------------------------------------------------------------------


class TestUrlExtraction:
    def test_extracts_http_url(self):
        urls = _URL_PATTERN.findall("Check http://example.com out")
        assert urls == ["http://example.com"]

    def test_extracts_https_url(self):
        urls = _URL_PATTERN.findall("See https://example.com/path?q=1")
        assert urls == ["https://example.com/path?q=1"]

    def test_extracts_multiple_urls(self):
        text = "See https://a.com and https://b.com/page"
        urls = _URL_PATTERN.findall(text)
        assert len(urls) == 2

    def test_no_urls(self):
        assert _URL_PATTERN.findall("No links here") == []

    def test_complex_url(self):
        url = "https://theconversation.com/its-tempting-to-offload-your-thinking-to-ai-276766"
        urls = _URL_PATTERN.findall(f"Read this {url}")
        assert urls == [url]


# ---------------------------------------------------------------------------
# TelegramBot — auto-ingest
# ---------------------------------------------------------------------------


class TestAutoIngestUrls:
    def test_ingests_url_returns_details(self):
        api = MagicMock()
        api.ingest_url.return_value = {
            "item_id": "abc",
            "title": "Test Article",
            "summary": "Useful summary.",
        }

        bot = TelegramBot(_make_config(), api)
        ingested, failed = bot._auto_ingest_urls_detailed(["https://example.com"])

        assert ingested == [api.ingest_url.return_value]
        assert failed == []

    def test_ingests_url_returns_title(self):
        api = MagicMock()
        api.ingest_url.return_value = {"item_id": "abc", "title": "Test Article"}

        bot = TelegramBot(_make_config(), api)
        ingested, failed = bot._auto_ingest_urls(["https://example.com"])

        assert ingested == ["Test Article"]
        assert failed == []
        call_kwargs = api.ingest_url.call_args
        assert call_kwargs.args[0] == "https://example.com"
        assert "session_id" in call_kwargs.kwargs

    def test_ingest_returns_none_skipped(self):
        api = MagicMock()
        api.ingest_url.return_value = None

        bot = TelegramBot(_make_config(), api)
        ingested, failed = bot._auto_ingest_urls(["https://example.com/broken"])

        assert ingested == []
        assert failed == ["https://example.com/broken"]

    def test_multiple_urls_partial_success(self):
        api = MagicMock()
        api.ingest_url.side_effect = [
            {"item_id": "a", "title": "Article A"},
            None,
            {"item_id": "c", "title": "Article C"},
        ]

        bot = TelegramBot(_make_config(), api)
        ingested, failed = bot._auto_ingest_urls(
            [
                "https://a.com",
                "https://b.com",
                "https://c.com",
            ]
        )

        assert ingested == ["Article A", "Article C"]
        assert failed == ["https://b.com"]


# ---------------------------------------------------------------------------
# TelegramBot — build_application
# ---------------------------------------------------------------------------


class TestBuildApplication:
    def test_builds_application_with_handlers(self):
        bot = TelegramBot(_make_config(), MagicMock())
        app = bot.build_application()

        # Should have handlers registered
        assert len(app.handlers) > 0
        # Check that handlers exist in at least one group
        total_handlers = sum(len(h) for h in app.handlers.values())
        assert total_handlers >= 4  # status, search, forwarded, message


# ---------------------------------------------------------------------------
# TelegramBot — handle_audio
# ---------------------------------------------------------------------------


class TestHandleAudio:
    def setup_method(self):
        self.api = MagicMock()
        self.api._store_path = "/tmp/test_memex/.memex/memex.db"
        self.api._store = MagicMock()
        self.api._scheduler_engine = MagicMock()
        self.bot = TelegramBot(_make_config(), self.api)

        self.update = MagicMock()
        self.update.effective_user = MagicMock()
        self.update.effective_user.id = 42
        self.update.message = MagicMock()
        self.update.message.chat_id = 12345
        self.update.message.voice = MagicMock(file_id="file123", file_name=None)
        self.update.message.audio = None
        self.update.message.reply_text = AsyncMock()

        self.context = MagicMock()
        mock_file = AsyncMock()
        mock_file.download_to_drive = AsyncMock()
        self.context.bot.get_file = AsyncMock(return_value=mock_file)
        self.context.bot.send_chat_action = AsyncMock()

    @pytest.fixture(autouse=True)
    def _auth_ok(self):
        with patch.object(self.bot, "_auth_check", return_value=True):
            yield

    @pytest.mark.asyncio
    async def test_speech_audio_creates_meeting_and_enqueues(self):
        from memex.auto_ingest.audio_classify import AudioClassification
        from pathlib import Path as _Path

        classified = AudioClassification(
            path=_Path("/tmp/x.ogg"),
            is_speech=True,
            speech_ratio=0.85,
            vad_available=True,
        )
        mock_create = self.api._store.meetings.create_meeting
        with (
            patch(
                "memex.auto_ingest.audio_classify.classify_audio",
                return_value=classified,
            ),
            patch(
                "memex.meetings.submit_transcription", return_value=42
            ) as mock_submit,
            patch("shutil.move"),
            patch("pathlib.Path.mkdir"),
        ):
            await self.bot.handle_audio(self.update, self.context)

        mock_create.assert_called_once()
        record = mock_create.call_args[0][0]
        assert record.state.value == "recorded"
        assert record.audio_path != ""
        mock_submit.assert_called_once()
        reply = self.update.message.reply_text.call_args[0][0]
        assert "transcribing" in reply.lower()

    @pytest.mark.asyncio
    async def test_speech_audio_degraded_no_engine(self):
        from memex.auto_ingest.audio_classify import AudioClassification
        from pathlib import Path as _Path

        self.api._scheduler_engine = None
        classified = AudioClassification(
            path=_Path("/tmp/x.ogg"),
            is_speech=True,
            speech_ratio=0.85,
            vad_available=True,
        )
        mock_create = self.api._store.meetings.create_meeting
        with (
            patch(
                "memex.auto_ingest.audio_classify.classify_audio",
                return_value=classified,
            ),
            patch("memex.meetings.submit_transcription") as mock_submit,
            patch("shutil.move"),
            patch("pathlib.Path.mkdir"),
        ):
            await self.bot.handle_audio(self.update, self.context)

        mock_create.assert_called_once()
        mock_submit.assert_not_called()
        reply = self.update.message.reply_text.call_args[0][0]
        assert "scheduler" in reply.lower()


class TestBackgroundTaskFailureNotification:
    """Background task failures should create a notification via NotificationRouter."""

    def setup_method(self):
        self.api = MagicMock()
        self.api._store_path = "/tmp/test_memex/.memex/memex.db"
        self.bot = TelegramBot(_make_config(), self.api)

    def test_background_task_failure_creates_notification(self):
        """When a background async task raises, a HIGH-priority notification is created."""
        mock_ns = MagicMock()
        self.api.notification_store = mock_ns

        mock_router = MagicMock()

        async def failing_task():
            raise RuntimeError("network timeout")

        loop = asyncio.new_event_loop()
        try:
            with (
                patch(
                    "memex.notifications.NotificationRouter", return_value=mock_router
                ),
                patch(
                    "memex.interfaces.telegram.NotificationRouter",
                    return_value=mock_router,
                    create=True,
                ),
            ):
                task = loop.create_task(failing_task())
                self.bot._track_background_task(task)
                loop.run_until_complete(asyncio.gather(task, return_exceptions=True))
                # Give done callback a moment to run
                loop.run_until_complete(asyncio.sleep(0))
        finally:
            loop.close()

        # Either the notification_store was accessed or the router was called
        # (depending on import path); the key is that warning was logged
        # and the cleanup didn't re-raise
        assert task.done()

    def test_background_task_failure_does_not_raise(self):
        """Cleanup callback must not propagate the exception."""

        async def failing_task():
            raise ValueError("boom")

        loop = asyncio.new_event_loop()
        try:
            task = loop.create_task(failing_task())
            self.bot._track_background_task(task)
            # Should not raise
            loop.run_until_complete(asyncio.gather(task, return_exceptions=True))
            loop.run_until_complete(asyncio.sleep(0))
        finally:
            loop.close()

        assert task.done()
