"""Tests for session management."""

from memex.models import InputClassification, InputClassificationType
from memex.session import WINDOW_SIZE, add_turn, create_session, window_history


def test_create_session():
    s = create_session()
    assert s.session_id
    assert s.turn_count == 0
    assert s.conversation_history == []


def test_add_turn_increments_count():
    s = create_session()
    add_turn(s, "human", "hello")
    assert s.turn_count == 1
    add_turn(s, "assistant", "hi there")
    assert s.turn_count == 1  # only human turns increment


def test_add_turn_stores_classification():
    s = create_session()
    c = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.9,
        reasoning="greeting",
    )
    add_turn(s, "human", "hello", classification=c)
    assert s.last_classification == c
    assert s.conversation_history[-1].classification == c


def test_window_history_no_op_under_limit():
    s = create_session()
    for i in range(10):
        add_turn(s, "human", f"msg {i}")
    window_history(s, use_llm=False)
    assert len(s.conversation_history) == 10


def test_window_history_trims():
    s = create_session()
    for i in range(WINDOW_SIZE + 5):
        add_turn(s, "human", f"msg {i}")
        add_turn(s, "assistant", f"reply {i}")
    window_history(s, use_llm=False)
    assert len(s.conversation_history) == WINDOW_SIZE
    assert s.conversation_summary != ""
