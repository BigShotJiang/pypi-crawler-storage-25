"""Version floor guard for the fathomdb dependency.

Memex's m004 property-FTS migration registers recursive ``$.payload``
entries on WMAction, WMExecutionRecord, WMGoal, and WMKnowledgeObject.
The recursive walker in fathomdb 0.3.0 has a bug that violates
``UNIQUE(node_logical_id, kind, start_offset)`` on
``fts_node_property_positions`` whenever an empty scalar leaf is emitted
before a non-empty leaf at the same recursion depth (see the empty-leaf
offset fix shipped in fathomdb 0.3.1).

This test asserts that the installed fathomdb is at least 0.3.1 on every
platform the test suite runs on. Without it, a CI runner resolving to
PyPI 0.3.0 (because the aarch64-only ``[tool.uv.sources]`` override in
``pyproject.toml`` does not match its platform) would silently hit the
recursive-walker bug the moment any test wrote a WMAction payload with
a list containing an empty string — a very common production shape
(empty tags, blank recipients, etc.).

The guard is loud by design: any CI job that falls back to 0.3.0 fails
here with a clear error message pointing at the root cause, rather than
leaving the failure to surface as a cryptic UNIQUE constraint violation
during an unrelated e2e test.

When fathomdb 0.3.1 propagates to PyPI the ``[tool.uv.sources]``
override can be dropped and this guard becomes a permanent floor on the
dependency version — keep it as the one test that enforces the minimum
required fix.
"""

from __future__ import annotations

import fathomdb


_MIN_VERSION: tuple[int, int, int] = (0, 3, 1)


def _parse_version(raw: str) -> tuple[int, int, int]:
    parts = raw.split(".")[:3]
    return tuple(int(p.split("-")[0].split("+")[0]) for p in parts)  # type: ignore[return-value]


def test_fathomdb_version_floor() -> None:
    """fathomdb must be >= 0.3.1 so m004 recursive FTS registration is safe."""
    raw = getattr(fathomdb, "__version__", "0.0.0")
    parsed = _parse_version(raw)
    assert parsed >= _MIN_VERSION, (
        f"fathomdb {raw} is installed, but m004's recursive property-FTS "
        f"registration requires >= {'.'.join(map(str, _MIN_VERSION))}. "
        "The 0.3.0 recursive walker has a UNIQUE-constraint bug on "
        "empty-leaf payloads (list with leading empty string, sibling "
        "dict with empty-valued earlier key) that will fail m004 or any "
        "live write carrying those payload shapes. Upgrade fathomdb or "
        "check that [tool.uv.sources] in pyproject.toml resolves to the "
        "0.3.1+ local wheel on this platform."
    )
