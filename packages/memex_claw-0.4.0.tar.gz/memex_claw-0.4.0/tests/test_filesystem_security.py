"""Tests for filesystem capability gating in security module."""

from __future__ import annotations

from unittest.mock import patch

from memex.models import ConnectorHealth, ToolDefinition
from memex.mcp_servers import MCPServerEntry, MCPServersConfig
from memex.security import (
    check_capability,
    filter_permitted_tools,
    get_granted_capabilities,
)
from memex.utcnow import utcnow


def _health(name: str, status: str, capability_prefix: str = "") -> ConnectorHealth:
    return ConnectorHealth(
        name=name,
        status=status,
        last_check=utcnow(),
        capability_prefix=capability_prefix,
    )


def _tool(name: str, capability: str) -> ToolDefinition:
    return ToolDefinition(
        name=name,
        description=f"Test {name}",
        source="mcp:filesystem",
        required_capability=capability,
    )


def _writable_config() -> MCPServersConfig:
    """Config with one writable filesystem server."""
    return MCPServersConfig(
        servers=[
            MCPServerEntry(
                name="fs-rw",
                command="npx",
                args=["@modelcontextprotocol/server-filesystem", "/workspace"],
                integration="filesystem",
                write=True,
            ),
        ]
    )


def _readonly_config() -> MCPServersConfig:
    """Config with only read-only filesystem servers."""
    return MCPServersConfig(
        servers=[
            MCPServerEntry(
                name="fs-ro",
                command="npx",
                args=["@modelcontextprotocol/server-filesystem", "/code"],
                integration="filesystem",
                write=False,
            ),
        ]
    )


class TestFilesystemCapabilities:
    @patch("memex.mcp_servers.servers_config_from_env", return_value=_writable_config())
    def test_connected_filesystem_grants_read_and_write(self, _mock):
        """When filesystem is connected and writable server exists, both capabilities granted."""
        caps = get_granted_capabilities([_health("filesystem", "connected")])
        assert "filesystem.read" in caps
        assert "filesystem.write" in caps
        assert "builtin.file_transform" in caps

    @patch("memex.mcp_servers.servers_config_from_env", return_value=_readonly_config())
    def test_readonly_config_grants_read_not_write(self, _mock):
        """When connected but only read-only servers, write capability is NOT granted."""
        caps = get_granted_capabilities([_health("filesystem", "connected")])
        assert "filesystem.read" in caps
        assert "filesystem.write" not in caps
        assert "builtin.file_transform" not in caps

    def test_unavailable_filesystem_no_capabilities(self):
        caps = get_granted_capabilities([_health("filesystem", "unavailable")])
        assert "filesystem.read" not in caps
        assert "filesystem.write" not in caps
        assert "builtin.file_transform" not in caps

    @patch("memex.mcp_servers.servers_config_from_env", return_value=_writable_config())
    def test_named_server_with_prefix_grants_capabilities(self, _mock):
        """Servers named 'fs-code' etc. match via capability_prefix='filesystem'."""
        caps = get_granted_capabilities(
            [
                _health("fs-code", "connected", capability_prefix="filesystem"),
            ]
        )
        assert "filesystem.read" in caps
        assert "filesystem.write" in caps
        assert "builtin.file_transform" in caps

    def test_no_filesystem_connector(self):
        caps = get_granted_capabilities([])
        assert "filesystem.read" not in caps
        assert "filesystem.write" not in caps


class TestFilesystemToolFiltering:
    @patch("memex.mcp_servers.servers_config_from_env", return_value=_writable_config())
    def test_all_tools_visible_when_writable_server_exists(self, _mock):
        tools = [
            _tool("read_file", "filesystem.read"),
            _tool("write_file", "filesystem.write"),
        ]
        granted = get_granted_capabilities([_health("filesystem", "connected")])
        filtered = filter_permitted_tools(tools, granted)
        assert len(filtered) == 2

    @patch("memex.mcp_servers.servers_config_from_env", return_value=_readonly_config())
    def test_only_read_tools_visible_when_readonly(self, _mock):
        tools = [
            _tool("read_file", "filesystem.read"),
            _tool("write_file", "filesystem.write"),
        ]
        granted = get_granted_capabilities([_health("filesystem", "connected")])
        filtered = filter_permitted_tools(tools, granted)
        assert len(filtered) == 1
        assert filtered[0].name == "read_file"

    def test_no_filesystem_tools_without_connection(self):
        tools = [
            _tool("read_file", "filesystem.read"),
            _tool("write_file", "filesystem.write"),
        ]
        granted = get_granted_capabilities([_health("filesystem", "unavailable")])
        filtered = filter_permitted_tools(tools, granted)
        assert len(filtered) == 0


class TestCapabilityGate:
    def test_read_allowed(self):
        assert check_capability(
            "filesystem.read",
            {"builtin.read", "filesystem.read"},
        )

    def test_write_denied_without_grant(self):
        assert not check_capability(
            "filesystem.write",
            {"builtin.read"},
        )

    def test_write_allowed_with_grant(self):
        assert check_capability(
            "filesystem.write",
            {"builtin.read", "filesystem.read", "filesystem.write"},
        )
