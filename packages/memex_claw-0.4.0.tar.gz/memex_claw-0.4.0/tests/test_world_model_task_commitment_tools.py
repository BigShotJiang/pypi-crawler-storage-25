from __future__ import annotations

from unittest.mock import patch

from memex.meetings.models import MeetingRecord, MeetingState
from memex.meetings.semantic_projection import sync_meeting_item_projection
from memex.models import Item, ItemType, Provenance, WorldModelAction
from memex.remember import RememberClassification, RememberIntent
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.tools_builtin import _STORES, configure_stores, execute_builtin
from memex.world_model_backbone import build_world_model_provenance_link
from memex.utcnow import utcnow


def test_builtin_remember_returns_canonical_task_id(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    configure_stores(
        content_store=store.content,
        memex_store=store,
        scheduler_store=store.scheduler,
    )
    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )

    try:
        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_builtin(
                "remember", {"text": "remind me to call mom Tuesday at 3pm"}
            )

        assert result.success
        assert "ID: world_model_task:reminder-" in result.content
    finally:
        _STORES.clear()


def test_get_item_renders_world_model_task_and_commitment_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()

    configure_stores(
        content_store=store.content,
        memex_store=store,
        scheduler_store=store.scheduler,
    )
    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )

    try:
        with patch("memex.llm.chat_structured", return_value=mock_result):
            remember_result = execute_builtin(
                "remember", {"text": "remind me to call mom Tuesday at 3pm"}
            )
        task_id = (
            remember_result.content.split("ID: world_model_task:", 1)[1]
            .splitlines()[0]
            .strip()
        )
        store.upsert_world_model_action(
            WorldModelAction(
                action_id="session:tools:action:turn:1:selected",
                session_id="session:tools",
                intent_id="intent:tools:1",
                prompt_control_artifact_id=None,
                conversation_turn_id=1,
                action_kind="selected_action",
                action_name="schedule_followup",
                status="succeeded",
                payload={"selected_action": {"name": "schedule_followup"}},
                source_surface="test",
                created_at=now,
                updated_at=now,
            )
        )
        store.upsert_world_model_provenance_link(
            build_world_model_provenance_link(
                "world_model_action",
                "session:tools:action:turn:1:selected",
                "world_model_task",
                task_id,
                "creates_task",
                created_at=now,
            )
        )

        meeting = MeetingRecord(
            meeting_id="mtg-tools-commitment",
            state=MeetingState.INGESTED,
            title="Architecture Review",
            item_id="meeting-item-tools-commitment",
            started_at=now,
            action_items=[
                {
                    "text": "Ship docs update",
                    "assignee": "Corey",
                    "deadline": "Friday",
                    "commitment_confirmed": True,
                    "agreed_by": "Corey",
                    "promoted_goal_id": "goal-123",
                }
            ],
            created_at=now,
            updated_at=now,
        )
        store.meetings.create_meeting(meeting)
        store.content.create_item(
            Item(
                item_id="meeting-item-tools-commitment",
                type=ItemType.MEETING,
                title="Architecture Review",
                body="Transcript body",
                source_url="memex://meeting/mtg-tools-commitment",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="meeting_transcription", captured_at=now, confidence=1.0
                ),
                metadata={"meeting": {"meeting_id": "mtg-tools-commitment"}},
            )
        )
        record = store.meetings.get_meeting("mtg-tools-commitment")
        assert record is not None
        sync_meeting_item_projection(
            record,
            meeting_store=store.meetings,
            content_store=store.content,
            memex_store=store,
            bump_version=False,
        )
        commitment = store.list_world_model_commitments(
            meeting_id="mtg-tools-commitment"
        )[0]

        task_detail = execute_builtin("get_item", {"id": f"world_model_task:{task_id}"})
        commitment_detail = execute_builtin(
            "get_item",
            {"id": f"world_model_commitment:{commitment.commitment_id}"},
        )

        assert task_detail.success
        assert "Reminder: Call mom" in task_detail.content
        assert "Kind: scheduled_reminder" in task_detail.content
        assert "advances_goal -> world_model_goal:" in task_detail.content
        assert (
            "linked_from creates_task <- world_model_action:session:tools:action:turn:1:selected"
            in task_detail.content
        )
        assert commitment_detail.success
        assert "Ship docs update" in commitment_detail.content
        assert "Assignee: Corey" in commitment_detail.content
        assert "updates_goal -> world_model_goal:goal-123" in commitment_detail.content
    finally:
        _STORES.clear()
