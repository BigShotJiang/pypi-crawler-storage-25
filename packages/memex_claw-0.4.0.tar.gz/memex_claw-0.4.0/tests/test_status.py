"""Tests for status command."""

from __future__ import annotations

import os
from unittest.mock import patch


from memex.cli import main
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore


class TestStatusQuick:
    """Tests for the status-quick command (old behavior)."""

    def test_status_quick_runs(self, tmp_path, capsys):
        store_path = str(tmp_path / "test.db")
        with patch.dict(os.environ, {"MEMEX_STORE": store_path}):
            main(["status-quick"])
        captured = capsys.readouterr()
        assert "Store:" in captured.out
        assert "Goals:" in captured.out
        assert "Schema:" in captured.out


class TestStoreContentBackend:
    """After fathomdb cutover, content returns FathomContentAdapter."""

    def test_content_returns_fathom_adapter(self, tmp_path):
        from memex.fathom_facade import FathomContentAdapter

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        try:
            assert isinstance(store.content, FathomContentAdapter)
        finally:
            store.close()


class TestComprehensiveStatus:
    """Tests for the full status command."""

    def test_status_shows_sections(self, tmp_path, capsys, monkeypatch):
        monkeypatch.setenv("MEMEX_STORE", str(tmp_path / "test.db"))
        monkeypatch.setenv("MEMEX_KNOWLEDGE_BACKEND", "sqlite")
        main(["status"])
        captured = capsys.readouterr()
        assert "Memex Status" in captured.out
        assert "Store:" in captured.out
        assert "Goals:" in captured.out
        assert "Knowledge:" in captured.out
