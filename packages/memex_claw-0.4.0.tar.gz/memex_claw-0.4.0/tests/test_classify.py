"""Tests for input classification with mocked LLM."""

from unittest.mock import patch

from memex.classify import classify_input
from memex.models import InputClassification, InputClassificationType
from conftest import make_goal


def _mock_classify(classification_type, goal_id=None):
    """Create a mock that returns a specific classification."""
    result = InputClassification(
        classification=classification_type,
        goal_id=goal_id,
        confidence=0.9,
        reasoning="test mock",
    )

    def mock_chat_structured(messages, schema, **kwargs):
        return result

    return mock_chat_structured


def test_classify_advances_goal():
    goal = make_goal(title="Learn Rust")
    mock = _mock_classify(InputClassificationType.ADVANCES_GOAL, goal.goal_id)

    with patch("memex.classify.chat_structured", mock):
        result = classify_input("I finished chapter 3", active_goals=[goal])

    assert result.classification == InputClassificationType.ADVANCES_GOAL
    assert result.goal_id == goal.goal_id


def test_classify_new_goal():
    mock = _mock_classify(InputClassificationType.NEW_GOAL)

    with patch("memex.classify.chat_structured", mock):
        result = classify_input("I want to learn Spanish", active_goals=[])

    assert result.classification == InputClassificationType.NEW_GOAL


def test_classify_conversational():
    mock = _mock_classify(InputClassificationType.CONVERSATIONAL)

    with patch("memex.classify.chat_structured", mock):
        result = classify_input("Hey, how are you?", active_goals=[])

    assert result.classification == InputClassificationType.CONVERSATIONAL


def test_classify_clarification():
    mock = _mock_classify(InputClassificationType.CLARIFICATION)

    with patch("memex.classify.chat_structured", mock):
        result = classify_input("What did you mean by that?", active_goals=[])

    assert result.classification == InputClassificationType.CLARIFICATION


def test_classify_fallback_on_error():
    def raise_error(*args, **kwargs):
        raise RuntimeError("LLM unavailable")

    with patch("memex.classify.chat_structured", raise_error):
        result = classify_input("anything", active_goals=[])

    assert result.classification == InputClassificationType.CONVERSATIONAL
    assert result.confidence == 0.0
