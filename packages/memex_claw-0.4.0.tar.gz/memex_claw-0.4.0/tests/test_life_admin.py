"""Tests for life-admin integrations with mocked HTTP and auth."""

from unittest.mock import patch

import pytest


def _has_google_auth() -> bool:
    try:
        import google.auth  # noqa: F401

        return True
    except ImportError:
        return False


def test_outlook_no_client_id(monkeypatch):
    monkeypatch.delenv("MEMEX_OUTLOOK_CLIENT_ID", raising=False)
    from memex.integrations.outlook import OutlookClient

    client = OutlookClient()
    with pytest.raises(RuntimeError, match="MEMEX_OUTLOOK_CLIENT_ID"):
        client.setup_auth()


def test_outlook_not_authenticated(monkeypatch):
    monkeypatch.delenv("MEMEX_OUTLOOK_CLIENT_ID", raising=False)
    from memex.integrations.outlook import OutlookClient

    client = OutlookClient()
    with patch("memex.auth.store.get_credentials", return_value=None):
        with pytest.raises(RuntimeError, match="not authenticated"):
            client.authenticate()


@pytest.mark.skipif(
    not _has_google_auth(), reason="google-auth not installed (optional dep)"
)
def test_gmail_no_credentials(monkeypatch):
    monkeypatch.delenv("MEMEX_GOOGLE_CLIENT_ID", raising=False)
    monkeypatch.delenv("MEMEX_GOOGLE_CLIENT_SECRET", raising=False)
    from memex.integrations.gmail import GmailClient

    client = GmailClient()
    with patch("memex.auth.store.get_credentials", return_value=None):
        with pytest.raises(RuntimeError, match="not authenticated"):
            client.authenticate()


def test_google_keep_no_gkeepapi():
    """GoogleKeepClient.authenticate() raises ImportError when gkeepapi is missing."""
    with patch.dict("sys.modules", {"gkeepapi": None}):
        import importlib
        import memex.integrations.google_keep as gk_mod

        importlib.reload(gk_mod)
        client = gk_mod.GoogleKeepClient()
        with pytest.raises((ImportError, ModuleNotFoundError)):
            client.authenticate()


def test_icloud_no_credentials(monkeypatch):
    monkeypatch.delenv("MEMEX_ICLOUD_USERNAME", raising=False)
    monkeypatch.delenv("MEMEX_ICLOUD_APP_PASSWORD", raising=False)
    from memex.integrations.icloud_cal import ICloudCalendarClient

    client = ICloudCalendarClient()
    with pytest.raises(RuntimeError, match="MEMEX_ICLOUD_USERNAME"):
        client.setup_auth()
