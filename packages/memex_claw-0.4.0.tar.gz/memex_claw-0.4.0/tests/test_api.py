"""Tests for the unified MemexAPI."""

import os
from unittest.mock import MagicMock, patch

from memex.utcnow import utcnow
from memex.interfaces.api import MemexAPI
from memex.interfaces.caller import CallerContext
from memex.interfaces.formats import ResponseFormat, SessionMode
from memex.memory.web_extract import ExtractedContent
from memex.models import (
    AgentCapability,
    AgentSelfModel,
    GoalStatus,
    HumanPartnerProfile,
    SessionContext,
)
from memex.memory.retrieval import RetrievalSearchResult
from memex.tools_builtin import _STORES


def _make_api(store=None):
    """Create a MemexAPI with a mock store."""
    if store is None:
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
    return MemexAPI(store)


def _make_caller(interface="cli"):
    return CallerContext.owner(interface, "test-session")


class TestChat:
    @patch("memex.loop.run_turn")
    def test_chat_calls_run_turn(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("Hello!", session)

        api = _make_api()
        caller = _make_caller()
        response, sess = api.chat("Hi", caller)

        assert response == "Hello!"
        assert sess.session_id == "s1"
        mock_run_turn.assert_called_once()

    @patch("memex.loop.run_turn")
    def test_chat_passes_format(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("ok", session)

        api = _make_api()
        caller = _make_caller()
        fmt = ResponseFormat(verbosity="terse")
        api.chat("Hi", caller, response_format=fmt)

        call_kwargs = mock_run_turn.call_args
        assert call_kwargs.kwargs["response_format"] is fmt

    @patch("memex.loop.run_turn")
    def test_chat_passes_mode(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("ok", session)

        api = _make_api()
        caller = _make_caller()
        api.chat("Hi", caller, mode=SessionMode.DEEP_WORK)

        call_kwargs = mock_run_turn.call_args
        assert call_kwargs.kwargs["session_mode"] == SessionMode.DEEP_WORK

    @patch("memex.loop.run_turn")
    def test_chat_passes_caller(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("ok", session)

        api = _make_api()
        caller = _make_caller("telegram")
        api.chat("Hi", caller)

        call_kwargs = mock_run_turn.call_args
        assert call_kwargs.kwargs["caller"].interface == "telegram"

    @patch("memex.loop.run_turn")
    def test_chat_persists_runtime_self_model_after_turn(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
            turn_count=3,
        )
        mock_run_turn.return_value = ("ok", session)

        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = None
        store.save_agent_self_model = MagicMock()
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None

        api = MemexAPI(store)
        caller = _make_caller("telegram")
        api.chat("Hi", caller)

        saved_model = store.save_agent_self_model.call_args.args[0]
        assert store.save_agent_self_model.call_count == 1
        assert saved_model.operational_state["session"]["session_id"] == "s1"
        assert saved_model.operational_state["session"]["turn_count"] == 3
        assert (
            saved_model.operational_state["session"]["active_interface"] == "telegram"
        )

    @patch("memex.loop.run_turn")
    def test_chat_caches_session(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("ok", session)

        api = _make_api()
        caller = _make_caller()
        api.chat("Hi", caller)
        api.chat("Again", caller)

        # Second call should receive the cached session
        second_call = mock_run_turn.call_args_list[1]
        assert second_call.args[2] is session

    @patch("memex.loop.run_turn")
    def test_chat_uses_interface_format_by_default(self, mock_run_turn):
        session = SessionContext(
            session_id="s1",
            started_at=utcnow(),
        )
        mock_run_turn.return_value = ("ok", session)

        api = _make_api()
        caller = _make_caller("telegram")
        api.chat("Hi", caller)

        call_kwargs = mock_run_turn.call_args
        fmt = call_kwargs.kwargs["response_format"]
        assert fmt.verbosity == "normal"

    def test_ingest_url_returns_operation_stats(self, memory_store):
        api = MemexAPI(
            memory_store,
            content_store=memory_store.content,
            store_path=":memory:",
        )
        extracted = ExtractedContent(
            url="https://example.com/rust-guide",
            title="Rust Guide",
            body=(
                "Rust ownership and borrowing keep memory safe without a garbage collector. "
                "Each value has one owner, and ownership can move in predictable ways. "
                "Borrowing allows references without transferring ownership. "
                "The borrow checker prevents data races and dangling references before code runs. "
                "Lifetimes help the compiler enforce valid reference usage across scopes."
            ),
            categories=["rust"],
            word_count=52,
            raw_length=1200,
        )
        fetch_result = type(
            "FetchResultStub",
            (),
            {
                "url": "https://example.com/rust-guide",
                "status_code": 200,
                "text": "<html><body>Rust guide body</body></html>",
                "ok": True,
                "error": "",
                "headers": {
                    "etag": '"rust-guide-v1"',
                    "cache-control": "public, max-age=600",
                },
            },
        )()

        try:
            with (
                patch(
                    "memex.memory.web_extract.fetch_url_result",
                    return_value=fetch_result,
                ),
                patch(
                    "memex.memory.web_extract.extract_from_fetch_result",
                    return_value=extracted,
                ),
            ):
                result = api.ingest_url(
                    "https://example.com/rust-guide",
                    session_id="api-op-stats",
                )
        finally:
            api.close()

        assert result is not None
        assert result["ingest_run_id"]
        assert result["operation_stats"]["phase_timings_ms"]["extract"] >= 0
        assert result["operation_stats"]["phase_timings_ms"]["project"] >= 0
        assert result["operation_stats"]["phase_timings_ms"]["summary"] == 0

    def test_close_releases_builtin_store_bindings(self):
        previous_stores = dict(_STORES)
        store = MagicMock()
        store.conn = MagicMock()
        store.close = MagicMock()
        store.scheduler = MagicMock()
        store.settings = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = None
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
        content_store = MagicMock()
        embedding_backend = MagicMock()

        try:
            api = MemexAPI(
                store,
                content_store=content_store,
                embedding_backend=embedding_backend,
            )
            assert _STORES["content"] is content_store
            assert _STORES["embedding"] is embedding_backend
            assert _STORES["goal"] is store

            api.close()

            assert _STORES.get("content") is not content_store
            assert _STORES.get("embedding") is not embedding_backend
            assert _STORES.get("goal") is not store
        finally:
            _STORES.clear()
            _STORES.update(previous_stores)


class TestStatus:
    def test_status_returns_dict(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None

        api = MemexAPI(store)
        caller = _make_caller()
        status = api.status(caller)

        assert status["goals_total"] == 0
        assert status["goals_active"] == 0
        assert status["session_id"] is None

    def test_status_projects_from_self_state(self):
        api = _make_api()
        caller = _make_caller()
        api.self_state = MagicMock(
            return_value={
                "goals": {"total": 4, "active": 2},
                "session": {"session_id": "abcdef123456", "turn_count": 9},
                "connectors": [
                    {
                        "name": "openclaw-bridge",
                        "status": "connected",
                        "tools_discovered": 3,
                        "error": "",
                    }
                ],
            }
        )

        status = api.status(caller)

        assert status == {
            "goals_total": 4,
            "goals_active": 2,
            "session_id": "abcdef12",
            "session_turns": 9,
            "connectors": [
                {
                    "name": "openclaw-bridge",
                    "status": "connected",
                    "tools": 3,
                    "error": "",
                }
            ],
        }

    def test_status_prefers_durable_store_records(self):
        from memex.models import ConnectorHealth, Goal, GoalPriority

        store = MagicMock()
        store.list_goals.return_value = [
            Goal(
                goal_id="g-active",
                title="Active goal",
                status=GoalStatus.ACTIVE,
                priority=GoalPriority.MEDIUM,
                created_at=utcnow(),
                updated_at=utcnow(),
                last_touched_at=utcnow(),
            ),
            Goal(
                goal_id="g-done",
                title="Done goal",
                status=GoalStatus.COMPLETED,
                priority=GoalPriority.MEDIUM,
                created_at=utcnow(),
                updated_at=utcnow(),
                last_touched_at=utcnow(),
            ),
        ]
        store.load_session.return_value = SessionContext(
            session_id="abcdef123456",
            started_at=utcnow(),
            turn_count=9,
        )
        store.load_connector_health.return_value = [
            ConnectorHealth(
                name="openclaw-bridge",
                status="connected",
                last_check=utcnow(),
                error=None,
                tools_discovered=3,
            )
        ]
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None

        api = MemexAPI(store)
        api.self_state = MagicMock(
            side_effect=AssertionError("status should not use self_state")
        )

        status = api.status(_make_caller())

        assert status == {
            "goals_total": 2,
            "goals_active": 1,
            "session_id": "abcdef12",
            "session_turns": 9,
            "connectors": [
                {
                    "name": "openclaw-bridge",
                    "status": "connected",
                    "tools": 3,
                    "error": "",
                }
            ],
        }
        api.self_state.assert_not_called()

    def test_self_state_includes_meeting_runtime(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = HumanPartnerProfile(
            name="Corey",
            communication_style="concise",
            working_context={"role": "engineer"},
        )
        store.save_agent_self_model = MagicMock()
        store.content = None
        store.knowledge_backend = "fathomdb"
        active_recording = MagicMock(
            meeting_id="meeting-1",
            recording_id="recording-1",
            started_at=utcnow(),
            vad_threshold=0.33,
        )
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = active_recording

        api = MemexAPI(store, store_path="/tmp/memex.db")
        caller = _make_caller()
        state = api.self_state(caller)

        assert state["process"]["store_path"] == "/tmp/memex.db"
        assert state["session"]["active_interface"] == caller.interface
        assert state["meetings"]["active_recording"]["meeting_id"] == "meeting-1"
        assert state["meetings"]["active_recording"]["recording_id"] == "recording-1"
        assert state["meetings"]["active_recording"]["vad_threshold"] == 0.33
        assert state["human_partner"]["name"] == "Corey"
        assert state["human_partner"]["working_context"]["role"] == "engineer"
        assert any(
            item["capability_id"] == "surface/status"
            for item in state["agent_self"]["capabilities"]
        )
        assert any(item["name"] == "meeting_capture" for item in state["interfaces"])
        assert any(
            item["name"] == "transcription_engine" for item in state["interfaces"]
        )
        store.save_agent_self_model.assert_not_called()

    def test_self_state_preserves_stored_agent_self_capabilities(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = None
        store.load_agent_self_model.return_value = AgentSelfModel(
            capabilities=[
                AgentCapability(
                    capability_id="planner/canonical",
                    title="Canonical planner",
                    status="available",
                    detail="Stored semantic authority.",
                    source="canonical",
                )
            ],
            last_diagnostics={
                "ok": False,
                "checks": [{"name": "db", "status": "warn", "detail": "slow"}],
            },
            last_repair={
                "ok": True,
                "action": "reset_proxy",
                "detail": "cleared",
            },
        )
        store.save_agent_self_model = MagicMock()
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None

        api = MemexAPI(store)
        state = api.self_state(_make_caller())

        capability_ids = {
            item["capability_id"] for item in state["agent_self"]["capabilities"]
        }
        assert "planner/canonical" in capability_ids
        assert "surface/status" in capability_ids
        assert state["agent_self"]["last_diagnostics"]["checks"][0]["name"] == "db"
        assert state["agent_self"]["last_repair"]["action"] == "reset_proxy"
        store.save_agent_self_model.assert_not_called()

    def test_run_diagnostics_persists_agent_self_model(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_partner_profile.return_value = None
        store.save_agent_self_model = MagicMock()
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
        store.conn.execute.return_value = None

        api = MemexAPI(store)
        result = api.run_diagnostics(checks=["db"])

        assert result["ok"] is True
        assert result["checks"][0]["name"] == "db"
        store.save_agent_self_model.assert_called()

    def test_run_diagnostics_matches_doctor_for_deterministic_checks(self, tmp_path):
        from memex.doctor import doctor
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore

        store_path = tmp_path / ".memex" / "memex.db"
        with patch.dict(
            os.environ,
            {
                "MEMEX_STORE": str(store_path),
                "AIRLOCK_PROXY_URL": "http://proxy.internal",
                "ANTHROPIC_API_KEY": "sk-test",
                "TELEGRAM_BOT_TOKEN": "token",
                "TELEGRAM_USER_ID": "123",
            },
            clear=False,
        ):
            from memex.doctor import init

            init(tmp_path)
            _fs = FathomStore.open(str(store_path))
            store = FathomMemexStore(_fs)
            try:
                api = MemexAPI(store, store_path=str(store_path))
                result = api.run_diagnostics(
                    ["db", "env_vars", "telegram_config", "llm_proxy"]
                )
                report = doctor(tmp_path)
            finally:
                store.close()

        api_checks = {
            check["name"]: (check["status"], check["detail"])
            for check in result["checks"]
        }
        doctor_checks = {
            check.name: (check.status, check.detail) for check in report.checks
        }
        assert api_checks["db"] == doctor_checks["Knowledge store"]
        assert api_checks["env_vars"] == doctor_checks["LLM API key"]
        assert api_checks["telegram_config"] == doctor_checks["Telegram"]
        assert api_checks["llm_proxy"] == doctor_checks["LLM proxy"]

    def test_repair_uses_persisted_diagnostic_context(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_connector_health.return_value = []
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
        store.load_agent_self_model.return_value = AgentSelfModel(
            last_diagnostics={
                "ok": False,
                "checks": [
                    {
                        "name": "scheduler",
                        "status": "warn",
                        "detail": "engine not registered",
                    }
                ],
            }
        )
        store.save_agent_self_model = MagicMock()

        engine = MagicMock()
        engine.work_queue = MagicMock()

        api = MemexAPI(store)
        api.set_scheduler_engine(engine)
        result = api.repair("restart_queue")

        assert result["ok"] is True
        assert "engine not registered" in result["detail"]
        assert "last diagnostics" in result["detail"].lower()
        store.save_agent_self_model.assert_called()

    def test_self_state_reads_diagnostics_and_repair_from_stored_agent_self_model(self):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
        store.conn.execute.return_value = None

        persisted: dict[str, AgentSelfModel] = {}
        store.load_agent_self_model.side_effect = lambda: persisted.get("model")
        store.save_agent_self_model.side_effect = lambda model: persisted.__setitem__(
            "model", model
        )

        api_a = MemexAPI(store)
        api_a.run_diagnostics(checks=["db"])
        api_a.repair("reset_proxy")

        api_b = MemexAPI(store)
        state = api_b.self_state(_make_caller())

        assert state["agent_self"]["last_diagnostics"]["checks"][0]["name"] == "db"
        assert state["agent_self"]["last_repair"]["action"] == "reset_proxy"

    @patch("memex.plugins.get_plugin_registry")
    def test_self_state_projects_plugins_from_registry(self, mock_get_plugin_registry):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None

        plugin_registry = MagicMock()
        plugin_registry.scan.return_value = []
        plugin_registry.all_plugins.return_value = [
            MagicMock(
                manifest=MagicMock(
                    id="demo",
                    name="Demo",
                    version="1.0.0",
                    kind="tool",
                ),
                status="loaded",
                error=None,
            ),
        ]
        mock_get_plugin_registry.return_value = plugin_registry

        api = MemexAPI(store)
        state = api.self_state(_make_caller())

        assert state["plugins"]["installed_count"] == 1
        assert state["plugins"]["loaded_count"] == 1
        assert state["plugins"]["items"][0]["plugin_id"] == "demo"

    @patch("memex.plugins.get_plugin_registry", side_effect=RuntimeError("boom"))
    def test_self_state_does_not_fall_back_to_runtime_registry_plugins(
        self, _mock_get_plugin_registry
    ):
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_partner_profile.return_value = None
        store.content = None
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None

        api = MemexAPI(store)
        api.runtime_registry.sync_plugins(
            [
                MagicMock(
                    manifest=MagicMock(
                        id="stale", name="Stale", version="1.0.0", kind="tool"
                    ),
                    status="loaded",
                    error=None,
                ),
            ]
        )

        state = api.self_state(_make_caller())

        assert state["plugins"]["installed_count"] == 0
        assert state["plugins"]["items"] == []


class TestSearch:
    @patch("memex.memory.retrieval.search_documents")
    def test_search_uses_canonical_retrieval_documents(self, mock_search_documents):
        mock_search_documents.return_value = [
            RetrievalSearchResult(
                document_id="world_model_mapping:partner/default:speaker:alice",
                title="Mapping: SPEAKER_00 -> Alice",
                snippet="Mapping kind: speaker_alias",
                document_family="semantic_mapping",
                source_url="",
                relevance_pct=91,
            )
        ]
        store = MagicMock()
        store.list_goals.return_value = []
        store.load_session.return_value = None
        store.load_partner_profile.return_value = None
        store.content = MagicMock()
        store.knowledge_backend = "fathomdb"
        store.meetings = MagicMock()
        store.meetings.get_active_recording.return_value = None
        api = MemexAPI(store, content_store=store.content)

        results = api.search("speaker alias", _make_caller())

        mock_search_documents.assert_called_once()
        assert results == [
            {
                "document_id": "world_model_mapping:partner/default:speaker:alice",
                "title": "Mapping: SPEAKER_00 -> Alice",
                "type": "semantic_mapping",
                "snippet": "Mapping kind: speaker_alias",
            }
        ]

    def test_api_instances_keep_isolated_runtime_state(self):
        store_a = MagicMock()
        store_a.list_goals.return_value = []
        store_a.load_session.return_value = None
        store_a.content = None
        store_a.knowledge_backend = "fathom"
        store_a.meetings = MagicMock()
        store_a.meetings.get_active_recording.return_value = None
        store_b = MagicMock()
        store_b.list_goals.return_value = []
        store_b.load_session.return_value = None
        store_b.content = None
        store_b.knowledge_backend = "fathom"
        store_b.meetings = MagicMock()
        store_b.meetings.get_active_recording.return_value = None

        api_a = MemexAPI(store_a)
        api_b = MemexAPI(store_b)
        api_a.runtime_registry.start_activity("a1", label="A", source="test")
        api_b.runtime_registry.start_activity("b1", label="B", source="test")

        state_a = api_a.self_state(_make_caller("cli"))
        state_b = api_b.self_state(_make_caller("telegram"))

        assert [item["activity_id"] for item in state_a["activities"]] == ["a1"]
        assert [item["activity_id"] for item in state_b["activities"]] == ["b1"]


class TestCreate:
    """Tests for MemexAPI.create() startup enforcement."""

    def test_create_succeeds_on_fresh_db(self, tmp_path, monkeypatch):
        """create() migrates a fresh DB and starts successfully."""
        db_path = tmp_path / "memex.db"
        monkeypatch.setenv("MEMEX_STORE", str(db_path))

        with (
            patch("memex.doctor.startup_post", return_value=None),
            patch("memex.loop.startup_health_check", return_value=(None, [], {})),
            patch("memex.memory.embeddings.get_embedding_backend", return_value=None),
        ):
            api = MemexAPI.create(str(db_path))

        assert api is not None
        api.close()

    def test_create_persists_runtime_self_model_during_startup(
        self, tmp_path, monkeypatch
    ):
        """create() materializes the durable self-model during startup, before first chat."""

        from memex.models import ConnectorHealth

        db_path = tmp_path / "memex.db"
        monkeypatch.setenv("MEMEX_STORE", str(db_path))

        connector_health = [
            ConnectorHealth(
                name="openclaw-bridge",
                status="connected",
                last_check=utcnow(),
                error=None,
                tools_discovered=2,
            )
        ]

        with (
            patch("memex.doctor.startup_post", return_value=None),
            patch(
                "memex.loop.startup_health_check",
                return_value=(None, connector_health, {}),
            ),
            patch("memex.memory.embeddings.get_embedding_backend", return_value=None),
        ):
            api = MemexAPI.create(str(db_path))

        try:
            model = api.store.load_agent_self_model()
            assert model is not None
            assert model.operational_state["process"]["store_path"] == str(db_path)
            assert model.operational_state["session"]["turn_count"] == 0
            capability_ids = {item.capability_id for item in model.capabilities}
            assert "surface/status" in capability_ids
            assert "connector/openclaw-bridge" in capability_ids
        finally:
            api.close()


class TestIntent:
    def test_intent_returns_list(self):
        store = MagicMock()
        store.list_goals.return_value = []

        api = MemexAPI(store)
        caller = _make_caller()
        intents = api.intent(caller)

        assert intents == []
