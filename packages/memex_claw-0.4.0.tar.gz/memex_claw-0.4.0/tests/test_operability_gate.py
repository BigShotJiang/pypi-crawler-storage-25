from pathlib import Path
from unittest.mock import Mock, patch

from memex import operability_gate


def test_operability_tests_are_the_preserved_surface_slice():
    assert operability_gate.OPERABILITY_TESTS == (
        "tests/test_doctor.py",
        "tests/test_status.py",
        "tests/test_api.py",
        "tests/test_operational_smoke.py",
        "tests/test_ingest_url.py",
        "tests/test_cookies.py",
        "tests/test_web_fetcher.py",
        "tests/e2e/test_preservation_guardrails.py",
        "tests/e2e/test_meeting_pipeline.py",
        "tests/test_tools.py",
        "tests/test_scheduler_engine.py",
        "tests/test_telegram.py",
        "tests/test_meeting_transcribe.py",
        "tests/test_cli.py",
        "tests/test_loop.py",
        "tests/test_openclaw_bridge.py",
    )


def test_build_command_uses_uv_run_pytest():
    command = operability_gate.build_command()
    assert command[:9] == [
        "uv",
        "run",
        "--with",
        "pytest",
        "--with",
        "pytest-asyncio",
        "python",
        "-m",
        "pytest",
    ]
    assert command[9:] == list(operability_gate.OPERABILITY_TESTS)


def test_build_command_appends_extra_args():
    command = operability_gate.build_command(["-q", "--maxfail=1"])
    assert command[-2:] == ["-q", "--maxfail=1"]


def test_repo_root_is_checkout_root():
    assert operability_gate.repo_root() == Path(__file__).resolve().parents[1]


def test_main_runs_gate_from_repo_root():
    completed = Mock(returncode=0)
    with patch("memex.operability_gate.subprocess.run", return_value=completed) as run:
        code = operability_gate.main(["-q"])

    assert code == 0
    run.assert_called_once_with(
        operability_gate.build_command(["-q"]),
        cwd=operability_gate.repo_root(),
        check=False,
    )
