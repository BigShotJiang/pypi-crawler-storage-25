"""Tests for SchedulerEngine."""

import logging
import threading
from unittest.mock import MagicMock, patch

import pytest

from memex.models import ActionType, ScheduledTask
from memex.scheduler.engine import SchedulerEngine
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.human_model import save_partner_profile
from memex.models import HumanPartnerProfile

from memex.utcnow import utcnow


def _make_task(
    task_id: str = "test-1",
    name: str = "Test",
    cron_expr: str = "0 9 * * *",
    action_type: ActionType = ActionType.NOTIFICATION,
    action_data: dict | None = None,
    enabled: bool = True,
) -> ScheduledTask:
    now = utcnow()
    return ScheduledTask(
        task_id=task_id,
        name=name,
        cron_expr=cron_expr,
        action_type=action_type,
        action_data=action_data or {"generator": "test"},
        enabled=enabled,
        created_at=now,
        updated_at=now,
    )


def test_engine_seeds_builtins(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    SchedulerEngine(ss, memex_store=store, notification_store=ns, tick_seconds=1)

    # After engine creation, builtins should be seeded
    tasks = ss.list_tasks()
    assert (
        len(tasks) >= 4
    )  # morning_briefing, weekly_review, deadline_watch, stale_goals
    names = {t.name for t in tasks}
    assert "Morning Briefing" in names
    assert "Weekly Review" in names
    assert "Deadline Watch" in names
    assert "Stale Goals" in names
    store.close()


def test_tick_enqueues_due_task(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    # Create a custom task
    task = _make_task(task_id="custom-1", name="Custom", enabled=True)
    ss.create_task(task)

    with patch("memex.scheduler.engine.is_due", return_value=True):
        engine._tick()

    # A run should have been recorded
    runs = ss.get_runs("custom-1")
    assert len(runs) >= 1
    assert runs[0].status in ("queued", "running", "completed")
    store.close()


def test_tick_skips_not_due(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    task = _make_task(task_id="custom-1", name="Custom", enabled=True)
    ss.create_task(task)

    with patch("memex.scheduler.engine.is_due", return_value=False):
        engine._tick()

    runs = ss.get_runs("custom-1")
    assert len(runs) == 0
    store.close()


def test_dispatch_notification(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    # Dispatch a notification with a generic generator
    result = engine._dispatch_notification({"generator": "some_test"}, run_id=1)
    assert "notification:some_test" in result


def test_dispatch_callable_deadlines(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    result = engine._dispatch_callable({"callable": "check_deadlines"}, run_id=1)
    assert "checked deadlines" in result


def test_dispatch_callable_stale(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    result = engine._dispatch_callable({"callable": "check_stale_goals"}, run_id=1)
    assert "checked stale goals" in result


def test_dispatch_callable_nightly_vec_regeneration(tmp_path):
    """Dispatching nightly_vec_regeneration must call
    engine.admin.regenerate_vector_embeddings once per vec-enabled kind
    (KnowledgeItem, ConversationTurn) with a VectorRegenerationConfig."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    with patch(
        "fathomdb._admin.AdminClient.regenerate_vector_embeddings"
    ) as mock_regen:
        result = engine._dispatch_callable(
            {"callable": "nightly_vec_regeneration"}, run_id=1
        )

    # One call per vec-enabled kind
    kinds_called = set()
    for call in mock_regen.call_args_list:
        args, kwargs = call
        cfg = args[0] if args else kwargs.get("config")
        kinds_called.add(cfg.kind)
    assert kinds_called == {"KnowledgeItem", "ConversationTurn"}
    assert "vec regeneration" in result
    store.close()


def test_dispatch_callable_fts_rebuild_rebuilds_projection(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    with patch.object(
        store,
        "rebuild_knowledge_projection",
        return_value={"items": 2, "chunks": 0},
        create=True,
    ) as mock_rebuild:
        result = engine._dispatch_callable({"callable": "fts_rebuild"}, run_id=1)

    mock_rebuild.assert_called_once_with()
    assert "knowledge projection rebuilt" in result
    assert "2 items" in result
    store.close()


def test_dispatch_transcription_uses_canonical_partner_speaker_mappings(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    save_partner_profile(
        HumanPartnerProfile(
            name="Corey",
            working_context={"speaker_mappings": {"SPEAKER_00": "Corey"}},
        ),
        store,
    )
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    with patch(
        "memex.meetings.transcribe.orchestrate_transcription", return_value=None
    ) as mock_orchestrate:
        result = engine._dispatch_transcription({"meeting_id": "mtg-123"}, run_id=1)

    assert "transcribed meeting" in result
    assert mock_orchestrate.call_args.kwargs["speaker_mappings"] == {
        "SPEAKER_00": "Corey"
    }
    store.close()


def test_error_handling(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    task = _make_task(
        task_id="err-task",
        name="ErrorTask",
        action_type=ActionType.AUTO_INGEST,
        action_data={"source": "nonexistent"},
        enabled=True,
    )
    ss.create_task(task)

    # Record a run, then dispatch which should raise
    run_id = ss.record_run("err-task", status="running")
    try:
        engine._dispatch_auto_ingest({"source": "nonexistent"}, run_id=run_id)
        raised = False
    except RuntimeError:
        raised = True
        # Mark the run as failed (simulating what WorkQueue would do)
        ss.complete_run(run_id, status="failed", error="auto-ingest failed")

    assert raised is True
    run = ss.get_last_run("err-task")
    assert run is not None
    assert run.status == "failed"
    store.close()


def test_start_logs_clean_state_when_no_stale_runs(caplog, tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )
    engine._queue.start = MagicMock()

    fake_thread = MagicMock()
    with (
        caplog.at_level(logging.DEBUG, logger="memex.scheduler.engine"),
        patch("memex.scheduler.engine.threading.Thread", return_value=fake_thread),
    ):
        engine.start()

    assert "Startup: state sweep found no stale task run(s)" in caplog.text
    fake_thread.start.assert_called_once()
    store.close()


def test_enqueue_adhoc(tmp_path):
    """enqueue_adhoc creates a task_runs row and enqueues a WorkItem."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    engine = SchedulerEngine(ss, tick_seconds=60)

    run_id = engine.enqueue_adhoc(
        ActionType.TELEGRAM_MESSAGE.value,
        {"text": "hello", "chat_id": 99},
        priority=2,
    )
    assert run_id is not None

    # The run should be in the DB as queued
    runs = ss.get_queued_runs()
    matching = [r for r in runs if r.get("logical_id") == run_id]
    assert len(matching) == 1
    row = matching[0]
    assert row["task_id"] is None
    assert row["action_type"] == ActionType.TELEGRAM_MESSAGE.value
    assert row["status"] == "queued"
    assert row["priority"] == 2

    # The item should be in the queue
    assert engine._queue.pending_count >= 1
    store.close()


def test_rehydrate_queued_runs(tmp_path):
    """_rehydrate_queued_runs re-enqueues orphaned queued rows on startup."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    engine = SchedulerEngine(ss, tick_seconds=60)

    # Simulate orphaned rows from a previous crash
    ss.record_adhoc_run(
        ActionType.TELEGRAM_MESSAGE.value,
        {"text": "orphaned"},
        priority=2,
    )
    ss.record_adhoc_run(
        ActionType.TELEGRAM_MESSAGE.value,
        {"text": "orphaned2"},
        priority=3,
    )

    before = engine._queue.pending_count
    count = engine._rehydrate_queued_runs()
    after = engine._queue.pending_count

    assert count == 2
    assert after == before + 2
    store.close()


def test_dispatch_prompt_raises_on_llm_down(tmp_path):
    """_dispatch_prompt raises LLMUnavailableError when LLM is not reachable."""
    from memex.scheduler.work_queue import LLMUnavailableError

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    api = MagicMock()
    engine = SchedulerEngine(ss, api=api, tick_seconds=60)

    with patch("memex.llm.is_llm_available", return_value=False):
        try:
            engine._dispatch_prompt({"prompt": "weekly_review"}, run_id=1)
            raised = False
        except LLMUnavailableError:
            raised = True

    assert raised, "Expected LLMUnavailableError when LLM is down"
    store.close()


def test_dispatch_transcription_timeout_marks_failed(monkeypatch, tmp_path):
    """_dispatch_transcription raises RuntimeError and marks recording FAILED on timeout."""
    from memex.meetings.models import MeetingRecord, MeetingRecording, MeetingState

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ns = store.notifications
    ss = store.scheduler
    engine = SchedulerEngine(
        ss, memex_store=store, notification_store=ns, tick_seconds=1
    )

    meeting_store = store.meetings
    rec = MeetingRecord(
        meeting_id="test-mtg-timeout",
        state=MeetingState.TRANSCRIBING,
        recordings=[
            MeetingRecording(
                recording_id="test-rec-1",
                meeting_id="test-mtg-timeout",
                sequence_number=1,
                state=MeetingState.TRANSCRIBING,
            )
        ],
    )
    meeting_store.create_meeting(rec)

    released = threading.Event()

    def _blocking(*args, **kwargs):
        released.wait(timeout=10)
        return None

    monkeypatch.setattr("memex.scheduler.engine._TRANSCRIPTION_TIMEOUT", 1)
    with patch(
        "memex.meetings.transcribe.orchestrate_transcription", side_effect=_blocking
    ):
        with pytest.raises(RuntimeError, match="timed out"):
            engine._dispatch_transcription({"meeting_id": "test-mtg-timeout"}, run_id=1)
    released.set()

    record = meeting_store.get_meeting("test-mtg-timeout")
    assert record is not None and record.recordings
    assert record.recordings[-1].state == MeetingState.FAILED
    assert "timed out" in record.recordings[-1].error
    store.close()
