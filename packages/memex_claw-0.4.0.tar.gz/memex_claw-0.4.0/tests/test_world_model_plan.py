from __future__ import annotations


from memex.memory.retrieval import retrieve_for_context
from memex.memory.world_model_reads import resolve_world_model_reads
from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    WorldModelActionPlan,
    WorldModelPlanStep,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


def test_world_model_action_plan_and_steps_roundtrip_with_provenance(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-plan-rollout",
        title="Ship the 0.8 rollout",
        description="Land the rollout safely.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    plan = WorldModelActionPlan(
        plan_id="plan-rollout",
        goal_id="goal-plan-rollout",
        title="0.8 rollout plan",
        summary="Drive the rollout through explicit execution steps.",
        status="active",
        selected_step_id="step-migrate",
        payload={"planning_mode": "canonical"},
        source_surface="test",
        created_at=now,
        updated_at=now,
    )
    draft = WorldModelPlanStep(
        step_id="step-draft",
        plan_id="plan-rollout",
        goal_id="goal-plan-rollout",
        step_kind="design",
        title="Draft the release sequence",
        description="Define the release sequence and responsibilities.",
        status="done",
        ordinal=1,
        blocked_reason="",
        payload={},
        source_surface="test",
        created_at=now,
        updated_at=now,
    )
    migrate = WorldModelPlanStep(
        step_id="step-migrate",
        plan_id="plan-rollout",
        goal_id="goal-plan-rollout",
        step_kind="execution",
        title="Run the 0.8 migration",
        description="Apply migrations and verify the rollout gate.",
        status="blocked",
        ordinal=2,
        blocked_reason="Waiting on the release sequence to lock.",
        payload={},
        source_surface="test",
        created_at=now,
        updated_at=now,
    )

    store.upsert_world_model_action_plan(plan)
    store.upsert_world_model_plan_step(draft)
    store.upsert_world_model_plan_step(migrate)

    loaded_plan = store.load_world_model_action_plan("plan-rollout")
    loaded_steps = store.list_world_model_plan_steps(plan_id="plan-rollout")
    plan_links = store.list_world_model_provenance_links(
        source_record_type="world_model_action_plan",
        source_record_id="plan-rollout",
    )
    step_links = store.list_world_model_provenance_links(
        source_record_type="world_model_plan_step",
        source_record_id="step-migrate",
    )

    assert loaded_plan is not None
    assert loaded_plan.selected_step_id == "step-migrate"
    assert [step.step_id for step in loaded_steps] == ["step-draft", "step-migrate"]
    assert {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in plan_links
    } == {
        ("for_goal", "world_model_goal", "goal-plan-rollout"),
        ("selected_step", "world_model_plan_step", "step-migrate"),
    }
    assert {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in step_links
    } == {
        ("part_of_plan", "world_model_action_plan", "plan-rollout"),
        ("for_goal", "world_model_goal", "goal-plan-rollout"),
    }


def test_plan_step_reads_and_retrieval_surface_canonical_plan_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-plan-search",
        title="Ship docs rollout",
        description="Ship the docs rollout safely.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-docs-rollout",
            goal_id="goal-plan-search",
            title="Docs rollout plan",
            summary="Coordinate the rollout with explicit execution ownership.",
            status="active",
            selected_step_id="step-rollout-execute",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-rollout-prepare",
            plan_id="plan-docs-rollout",
            goal_id="goal-plan-search",
            step_kind="prep",
            title="Prepare rollout checklist",
            description="Prepare the checklist that unblocks execution.",
            status="done",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-rollout-execute",
            plan_id="plan-docs-rollout",
            goal_id="goal-plan-search",
            step_kind="execution",
            title="Execute docs rollout",
            description="Execute the rollout after checklist approval.",
            status="blocked",
            ordinal=2,
            blocked_reason="Blocked on checklist approval.",
            depends_on_step_ids=["step-rollout-prepare"],
            blocked_by_step_ids=["step-rollout-prepare"],
            payload={"blocker": "approval"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    plan_hit = reads.load_action_plan_document("plan-docs-rollout")
    step_hit = reads.load_plan_step_document("step-rollout-execute")
    result = retrieve_for_context(
        "docs rollout checklist approval",
        2000,
        content_store=store.content,
        world_model_store=store,
    )

    assert plan_hit is not None
    assert any(
        link["relationship"] == "selected_step"
        and link["target_record_type"] == "world_model_plan_step"
        and link["target_record_id"] == "step-rollout-execute"
        for link in plan_hit.provenance
    )
    assert step_hit is not None
    assert any(
        link["relationship"] == "depends_on_step"
        and link["target_record_id"] == "step-rollout-prepare"
        for link in step_hit.provenance
    )
    assert any(
        link["relationship"] == "blocked_by_step"
        and link["target_record_id"] == "step-rollout-prepare"
        for link in step_hit.provenance
    )
    assert "Docs rollout plan" in result.text
    assert "Execute docs rollout" in result.text
    assert "world_model_action_plan:plan-docs-rollout" in result.document_ids
    assert "world_model_plan_step:step-rollout-execute" in result.document_ids
