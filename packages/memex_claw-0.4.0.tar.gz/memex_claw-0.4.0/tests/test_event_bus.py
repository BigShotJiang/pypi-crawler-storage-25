"""Tests for the event bus — no memex dependencies beyond event_bus.py and events.py."""

import threading
import time

import pytest

from memex.event_bus import EventBus, get_bus, reset_bus
from memex.events import (
    DomainEvent,
    GoalChanged,
    GoalCreated,
    GoalStatusChanged,
    GoalUpdated,
    ItemIngested,
    MeetingStateChanged,
    NotificationCreated,
    NotificationDismissed,
    TaskRunCompleted,
    TurnFinished,
    MeetingTranscribed,
)


@pytest.fixture(autouse=True)
def _clean_singleton():
    """Reset the global singleton before and after each test."""
    reset_bus()
    yield
    reset_bus()


class TestEventBusCore:
    """Core pub/sub mechanics."""

    def test_publish_subscribe_basic(self):
        bus = EventBus()
        bus.start()
        received = []
        done = threading.Event()

        def handler(event):
            received.append(event)
            done.set()

        bus.subscribe(GoalCreated, handler)
        event = GoalCreated(goal_id="g1", title="Test")
        bus.publish(event)
        done.wait(timeout=2)
        bus.stop()

        assert len(received) == 1
        assert received[0].goal_id == "g1"
        assert received[0].title == "Test"

    def test_subscriber_isolation(self):
        """One subscriber raising doesn't block others."""
        bus = EventBus()
        bus.start()
        received = []
        done = threading.Event()

        def bad_handler(event):
            raise RuntimeError("boom")

        def good_handler(event):
            received.append(event)
            done.set()

        bus.subscribe(GoalCreated, bad_handler)
        bus.subscribe(GoalCreated, good_handler)
        bus.publish(GoalCreated(goal_id="g1"))
        done.wait(timeout=2)
        bus.stop()

        assert len(received) == 1

    def test_subclass_dispatch(self):
        """Subscribing to base class receives subclass events."""
        bus = EventBus()
        bus.start()
        received = []
        done = threading.Event()

        def handler(event):
            received.append(event)
            if len(received) == 3:
                done.set()

        bus.subscribe(GoalChanged, handler)
        bus.publish(GoalCreated(goal_id="g1"))
        bus.publish(GoalStatusChanged(goal_id="g2", new_status="completed"))
        bus.publish(GoalUpdated(goal_id="g3"))
        done.wait(timeout=2)
        bus.stop()

        assert len(received) == 3
        assert isinstance(received[0], GoalCreated)
        assert isinstance(received[1], GoalStatusChanged)
        assert isinstance(received[2], GoalUpdated)

    def test_domain_event_base_catches_all(self):
        """Subscribing to DomainEvent receives everything."""
        bus = EventBus()
        bus.start()
        received = []
        done = threading.Event()

        def handler(event):
            received.append(event)
            if len(received) == 3:
                done.set()

        bus.subscribe(DomainEvent, handler)
        bus.publish(GoalCreated(goal_id="g1"))
        bus.publish(NotificationCreated(notification_id="n1"))
        bus.publish(ItemIngested(item_id="i1"))
        done.wait(timeout=2)
        bus.stop()

        assert len(received) == 3

    def test_unsubscribe(self):
        bus = EventBus()
        bus.start()
        received = []

        def handler(event):
            received.append(event)

        bus.subscribe(GoalCreated, handler)
        bus.unsubscribe(GoalCreated, handler)
        bus.publish(GoalCreated(goal_id="g1"))
        time.sleep(0.5)
        bus.stop()

        assert received == []

    def test_unsubscribe_nonexistent_is_noop(self):
        bus = EventBus()

        def handler(event):
            pass

        # Should not raise
        bus.unsubscribe(GoalCreated, handler)

    def test_publish_no_subscribers(self):
        bus = EventBus()
        bus.start()
        # Should not raise
        bus.publish(GoalCreated(goal_id="g1"))
        time.sleep(0.2)
        bus.stop()

    def test_stop_drains_queue(self):
        bus = EventBus()
        bus.start()
        count = 0
        lock = threading.Lock()

        def handler(event):
            nonlocal count
            with lock:
                count += 1

        bus.subscribe(GoalCreated, handler)
        for i in range(50):
            bus.publish(GoalCreated(goal_id=f"g{i}"))
        bus.stop(timeout=5)

        assert count == 50

    def test_reentrant_publish(self):
        """Subscriber publishing a new event doesn't deadlock."""
        bus = EventBus()
        bus.start()
        received = []
        done = threading.Event()

        def first_handler(event):
            if isinstance(event, GoalCreated):
                bus.publish(
                    NotificationCreated(notification_id="n1", title="re-entrant")
                )

        def second_handler(event):
            received.append(event)
            done.set()

        bus.subscribe(GoalCreated, first_handler)
        bus.subscribe(NotificationCreated, second_handler)
        bus.publish(GoalCreated(goal_id="g1"))
        done.wait(timeout=2)
        bus.stop()

        assert len(received) == 1
        assert received[0].notification_id == "n1"

    def test_multiple_subscribers_same_type(self):
        bus = EventBus()
        bus.start()
        r1, r2 = [], []
        done = threading.Event()

        def h1(event):
            r1.append(event)

        def h2(event):
            r2.append(event)
            done.set()

        bus.subscribe(GoalCreated, h1)
        bus.subscribe(GoalCreated, h2)
        bus.publish(GoalCreated(goal_id="g1"))
        done.wait(timeout=2)
        bus.stop()

        assert len(r1) == 1
        assert len(r2) == 1

    def test_start_idempotent(self):
        bus = EventBus()
        bus.start()
        bus.start()  # Should not create a second thread
        bus.stop()


class TestSingleton:
    """Test get_bus / reset_bus singleton lifecycle."""

    def test_get_bus_returns_same_instance(self):
        bus1 = get_bus()
        bus2 = get_bus()
        assert bus1 is bus2

    def test_reset_creates_new_instance(self):
        bus1 = get_bus()
        reset_bus()
        bus2 = get_bus()
        assert bus1 is not bus2

    def test_get_bus_from_multiple_threads(self):
        results = []

        def get_it():
            results.append(get_bus())

        threads = [threading.Thread(target=get_it) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 10
        assert all(b is results[0] for b in results)


class TestEventTypes:
    """Test event dataclasses."""

    def test_events_are_frozen(self):
        event = GoalCreated(goal_id="g1", title="Test")
        with pytest.raises(AttributeError):
            event.goal_id = "g2"  # type: ignore[misc]

    def test_event_inheritance(self):
        event = GoalCreated(goal_id="g1")
        assert isinstance(event, GoalCreated)
        assert isinstance(event, GoalChanged)
        assert isinstance(event, DomainEvent)

    def test_timestamp_default(self):
        event = GoalCreated(goal_id="g1")
        assert event.timestamp is not None

    def test_all_event_types_constructible(self):
        """Every event type can be created with defaults."""
        for cls in [
            GoalCreated,
            GoalStatusChanged,
            GoalUpdated,
            NotificationCreated,
            NotificationDismissed,
            ItemIngested,
            TaskRunCompleted,
            MeetingStateChanged,
            MeetingTranscribed,
            TurnFinished,
        ]:
            event = cls()
            assert isinstance(event, DomainEvent)
