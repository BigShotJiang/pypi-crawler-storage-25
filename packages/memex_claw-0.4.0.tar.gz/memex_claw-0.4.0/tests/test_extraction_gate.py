"""Tests for extraction gate (Phase 1)."""

from __future__ import annotations

from concurrent.futures import Future
from unittest.mock import MagicMock, patch

import pytest
from memex.utcnow import utcnow

from memex.memory.extraction_gate import (
    ExtractionSignals,
    _detect_regex_signals,
    check_extraction_gate,
)
from memex.models import InputClassification, InputClassificationType


def _has_spacy() -> bool:
    try:
        import spacy  # noqa: F401

        return True
    except ImportError:
        return False


def _synchronous_submit(fn, *args, **kwargs):
    """Run the callable inline instead of on a thread pool, then return a resolved Future."""
    fut = Future()
    try:
        result = fn(*args, **kwargs)
        fut.set_result(result)
    except Exception as exc:
        fut.set_exception(exc)
    return fut


# ---------------------------------------------------------------------------
# TestExtractionSignals
# ---------------------------------------------------------------------------


_MINIMAL_MESSAGES = [
    {"role": "system", "content": "sys"},
    {"role": "user", "content": "hi"},
]


class TestExtractionSignals:
    def test_defaults(self):
        sig = ExtractionSignals()
        assert sig.should_extract is False
        assert sig.signals == set()
        assert sig.entities == []


# ---------------------------------------------------------------------------
# TestSignalDetection — parametrized regex signal detection
# ---------------------------------------------------------------------------


class TestSignalDetection:
    @pytest.mark.parametrize(
        "text, expected_signal",
        [
            ("The deadline is March 20th", "factual_assertion"),
            ("Meeting on 2026-03-15", "factual_assertion"),
            ("We decided to use Postgres", "decision_language"),
            ("Sarah owns the auth service", "relationship_language"),
            ("He manages the platform team", "relationship_language"),
            ("Check https://example.com/api", "url_mentioned"),
            ("Using Postgres instead of Redis", "decision_language"),
            ("Actually, the deadline moved", "negation_of_prior"),
            ("Correction: it's March 25th", "negation_of_prior"),
        ],
    )
    def test_signal_detected(self, text, expected_signal):
        signals = _detect_regex_signals(text)
        assert expected_signal in signals

    def test_no_signals_for_greeting(self):
        signals = _detect_regex_signals("Hello, how are you?")
        assert signals == set()


# ---------------------------------------------------------------------------
# TestCheckExtractionGate
# ---------------------------------------------------------------------------


def _make_classification(
    ctype: InputClassificationType = InputClassificationType.CONVERSATIONAL,
) -> InputClassification:
    return InputClassification(classification=ctype, confidence=0.9)


class TestCheckExtractionGate:
    def test_trivial_greeting_vetoed(self):
        """Short CONVERSATIONAL greeting → should_extract=False, trivial_turn signal."""
        result = check_extraction_gate(
            "Hello, how are you?",
            "I'm doing well!",
            _make_classification(InputClassificationType.CONVERSATIONAL),
        )
        assert result.should_extract is False
        assert "trivial_turn" in result.signals

    def test_trivial_clarification_vetoed(self):
        """Short CLARIFICATION → vetoed."""
        result = check_extraction_gate(
            "What do you mean?",
            "I meant that thing you said.",
            _make_classification(InputClassificationType.CLARIFICATION),
        )
        assert result.should_extract is False
        assert "trivial_turn" in result.signals

    def test_conversational_with_entity_and_long_text(self):
        """CONVERSATIONAL with entity + >30 words → passes (veto doesn't apply)."""
        long_text = (
            "Sarah from the platform team told me that the new authentication "
            "service will be deployed next week and we need to prepare the "
            "migration scripts for the database changes that are coming"
        )
        result = check_extraction_gate(
            long_text,
            "Got it, I'll help with the migration.",
            _make_classification(InputClassificationType.CONVERSATIONAL),
        )
        # Should pass because entities are present (spaCy finds "Sarah")
        # or because word count > 30
        assert result.should_extract is True

    @pytest.mark.skipif(not _has_spacy(), reason="spaCy not installed (optional dep)")
    def test_named_entity_detected(self):
        """Named entity → should_extract=True, entities populated."""
        result = check_extraction_gate(
            "Sarah from the platform team is the tech lead",
            "Noted.",
            _make_classification(InputClassificationType.ADVANCES_GOAL),
        )
        assert result.should_extract is True
        # At minimum, spaCy should find "Sarah"
        entity_names = [name.lower() for name, _ in result.entities]
        assert any("sarah" in n for n in entity_names)

    def test_multiple_signals_combine(self):
        """URL + decision language → multiple signals."""
        result = check_extraction_gate(
            "We decided to use the API at https://example.com/api",
            "Good choice.",
            _make_classification(InputClassificationType.ADVANCES_GOAL),
        )
        assert result.should_extract is True
        assert "url_mentioned" in result.signals
        assert "decision_language" in result.signals

    def test_no_entities_no_signals(self):
        """No entities, no regex signals, non-trivial classification → False."""
        result = check_extraction_gate(
            "Please help me with this task that requires some work " * 3,
            "Sure, I can help with that.",
            _make_classification(InputClassificationType.ADVANCES_GOAL),
        )
        # No specific signals or entities → should_extract=False
        # (not vetoed as trivial, just no signals detected)
        assert result.should_extract is False

    def test_spacy_unavailable_still_works(self):
        """When spaCy is unavailable, regex signals still work."""
        with patch(
            "memex.memory.extraction_gate._extract_entities_safe",
            return_value=[],
        ):
            result = check_extraction_gate(
                "We decided to use Postgres for the database",
                "Good choice.",
                _make_classification(InputClassificationType.ADVANCES_GOAL),
            )
            assert result.should_extract is True
            assert "decision_language" in result.signals


# ---------------------------------------------------------------------------
# TestGateIntegration — verify gate controls reflect in loop.py
# ---------------------------------------------------------------------------


class TestGateIntegration:
    @patch("memex.memory.extraction_gate.check_extraction_gate")
    def test_gate_false_skips_extraction(self, mock_gate):
        """When gate returns False, extract_and_reflect should NOT be called."""
        from memex.loop import run_turn
        from memex.models import SessionContext

        mock_gate.return_value = ExtractionSignals(
            should_extract=False,
            signals={"trivial_turn"},
        )

        session = SessionContext(
            session_id="test-session",
            started_at=utcnow(),
        )

        pool_mock = MagicMock()
        pool_mock.submit.side_effect = _synchronous_submit

        with (
            patch("memex.classify.classify_input") as mock_classify,
            patch(
                "memex.llm.chat_with_usage",
                return_value=(
                    "response",
                    MagicMock(
                        prompt_tokens=10,
                        completion_tokens=10,
                        total_tokens=20,
                        cost_usd=0.0,
                    ),
                ),
            ),
            patch("memex.governance.load_governance", return_value=""),
            patch(
                "memex.human_model.load_canonical_partner_profile",
                return_value=MagicMock(),
            ),
            patch(
                "memex.agent_self_model.load_agent_self_model", return_value=MagicMock()
            ),
            patch("memex.agent_self_model.format_for_prompt", return_value=""),
            patch("memex.loop._build_system_prompt", return_value="sys"),
            patch("memex.loop._build_messages", return_value=_MINIMAL_MESSAGES),
            patch("memex.loop._use_message_builder", return_value=False),
            patch("memex.session.window_history"),
            patch("memex.session.add_turn"),
            patch("memex.scheduler.check_proactive", return_value=""),
            patch("memex.reflect.apply_reflect_result"),
            patch("memex.loop._POST_RESPONSE_POOL", pool_mock),
            patch(
                "memex.memory.conversation_extract.extract_and_reflect"
            ) as mock_extract,
        ):
            mock_classify.return_value = _make_classification()
            store = MagicMock()
            store.list_goals.return_value = []

            run_turn("hi", store, session)

            mock_extract.assert_not_called()
            assert session.working_memory.get("_last_reflect_skipped") is True

    @patch("memex.reflect.apply_reflect_result")
    @patch("memex.memory.extraction_gate.check_extraction_gate")
    def test_gate_true_calls_extract_and_reflect(self, mock_gate, mock_apply):
        """When gate returns True, extract_and_reflect should be called."""
        from memex.loop import run_turn
        from memex.memory.conversation_extract import CombinedExtractReflectResult
        from memex.models import SessionContext

        mock_gate.return_value = ExtractionSignals(
            should_extract=True,
            signals={"factual_assertion"},
        )

        session = SessionContext(
            session_id="test-session",
            started_at=utcnow(),
        )

        pool_mock = MagicMock()
        pool_mock.submit.side_effect = _synchronous_submit

        with (
            patch("memex.classify.classify_input") as mock_classify,
            patch(
                "memex.llm.chat_with_usage",
                return_value=(
                    "response",
                    MagicMock(
                        prompt_tokens=10,
                        completion_tokens=10,
                        total_tokens=20,
                        cost_usd=0.0,
                    ),
                ),
            ),
            patch("memex.governance.load_governance", return_value=""),
            patch(
                "memex.human_model.load_canonical_partner_profile",
                return_value=MagicMock(),
            ),
            patch(
                "memex.agent_self_model.load_agent_self_model", return_value=MagicMock()
            ),
            patch("memex.agent_self_model.format_for_prompt", return_value=""),
            patch("memex.loop._build_system_prompt", return_value="sys"),
            patch("memex.loop._build_messages", return_value=_MINIMAL_MESSAGES),
            patch("memex.loop._use_message_builder", return_value=False),
            patch("memex.session.window_history"),
            patch("memex.session.add_turn"),
            patch("memex.scheduler.check_proactive", return_value=""),
            patch("memex.loop._POST_RESPONSE_POOL", pool_mock),
            patch(
                "memex.memory.conversation_extract.extract_and_reflect"
            ) as mock_extract,
        ):
            mock_extract.return_value = CombinedExtractReflectResult(
                reflection_note="test",
            )
            mock_classify.return_value = _make_classification()
            store = MagicMock()
            store.list_goals.return_value = []

            run_turn("hi", store, session)

            mock_extract.assert_called_once()

    @patch("memex.memory.extraction_gate.check_extraction_gate")
    def test_telegram_url_capture_turn_skips_extract_and_reflect(self, mock_gate):
        """Telegram URL-only capture should not pay synchronous extract/reflect cost."""
        from memex.loop import run_turn
        from memex.interfaces.caller import CallerContext
        from memex.models import SessionContext

        mock_gate.return_value = ExtractionSignals(
            should_extract=True,
            signals={"url_mentioned"},
        )

        session = SessionContext(
            session_id="telegram-session",
            started_at=utcnow(),
        )

        pool_mock = MagicMock()
        pool_mock.submit.side_effect = _synchronous_submit

        with (
            patch("memex.classify.classify_input") as mock_classify,
            patch(
                "memex.llm.chat_with_usage",
                return_value=(
                    "Saved and indexed.",
                    MagicMock(
                        prompt_tokens=10,
                        completion_tokens=10,
                        total_tokens=20,
                        cost_usd=0.0,
                    ),
                ),
            ),
            patch("memex.governance.load_governance", return_value=""),
            patch(
                "memex.human_model.load_canonical_partner_profile",
                return_value=MagicMock(),
            ),
            patch(
                "memex.agent_self_model.load_agent_self_model", return_value=MagicMock()
            ),
            patch("memex.agent_self_model.format_for_prompt", return_value=""),
            patch("memex.loop._build_system_prompt", return_value="sys"),
            patch("memex.loop._build_messages", return_value=_MINIMAL_MESSAGES),
            patch("memex.loop._use_message_builder", return_value=False),
            patch("memex.session.window_history"),
            patch("memex.session.add_turn"),
            patch("memex.scheduler.check_proactive", return_value=""),
            patch("memex.reflect.apply_reflect_result"),
            patch("memex.loop._POST_RESPONSE_POOL", pool_mock),
            patch(
                "memex.memory.conversation_extract.extract_and_reflect"
            ) as mock_extract,
        ):
            mock_classify.return_value = _make_classification()
            store = MagicMock()
            store.list_goals.return_value = []

            run_turn(
                "Please save this article https://example.com/article",
                store,
                session,
                caller=CallerContext.owner("telegram", "telegram-session"),
            )

            mock_extract.assert_not_called()
            assert session.working_memory.get("_last_reflect_skipped") is True
            assert (
                session.working_memory.get("_last_reflect_skipped_reason")
                == "fast_url_capture"
            )
