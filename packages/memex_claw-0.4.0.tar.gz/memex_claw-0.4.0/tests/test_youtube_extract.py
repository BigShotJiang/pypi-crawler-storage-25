"""Tests for YouTube video transcript and metadata extraction."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from memex.memory.youtube_extract import (
    _build_tags,
    _extract_transcript_from_info,
    _fetch_info,
    _format_body,
    extract_from_youtube,
    extract_video_id,
    is_youtube_url,
)


# ---------------------------------------------------------------------------
# URL detection — pure functions, no mocks
# ---------------------------------------------------------------------------


class TestExtractVideoId:
    """Extract 11-char video ID from all YouTube URL formats."""

    @pytest.mark.parametrize(
        "url,expected",
        [
            ("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("http://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=123", "dQw4w9WgXcQ"),
            ("https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=PLfoo", "dQw4w9WgXcQ"),
            ("https://youtu.be/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("http://youtu.be/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://www.youtube.com/shorts/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://youtube.com/shorts/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://www.youtube.com/embed/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            ("https://youtube.com/embed/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
            # IDs with hyphens and underscores
            ("https://www.youtube.com/watch?v=abc-_12DE3f", "abc-_12DE3f"),
        ],
    )
    def test_valid_urls(self, url, expected):
        assert extract_video_id(url) == expected

    @pytest.mark.parametrize(
        "url",
        [
            "https://example.com/page",
            "https://www.youtube.com/playlist?list=PLfoo",
            "https://www.youtube.com/channel/UCfoo",
            "https://www.youtube.com/",
            "not-a-url",
            "",
        ],
    )
    def test_non_youtube_returns_none(self, url):
        assert extract_video_id(url) is None


class TestIsYoutubeUrl:
    """Boolean wrapper around extract_video_id."""

    def test_youtube_url(self):
        assert is_youtube_url("https://www.youtube.com/watch?v=dQw4w9WgXcQ") is True

    def test_short_url(self):
        assert is_youtube_url("https://youtu.be/dQw4w9WgXcQ") is True

    def test_non_youtube(self):
        assert is_youtube_url("https://example.com") is False

    def test_empty(self):
        assert is_youtube_url("") is False


# ---------------------------------------------------------------------------
# Body formatting — pure functions, no mocks
# ---------------------------------------------------------------------------


class TestFormatBody:
    """_format_body(transcript, metadata) → formatted string."""

    def test_full_metadata(self):
        metadata = {
            "uploader": "Test Channel",
            "upload_date": "20240315",
            "duration": 615,
        }
        result = _format_body("Hello world transcript", metadata)
        assert "Channel: Test Channel" in result
        assert "Date: 2024-03-15" in result
        assert "Duration: 10m15s" in result
        assert "Hello world transcript" in result

    def test_empty_metadata(self):
        result = _format_body("Just a transcript", {})
        assert result == "Just a transcript"

    def test_date_formatting(self):
        result = _format_body("text", {"upload_date": "20240315"})
        assert "Date: 2024-03-15" in result

    def test_duration_formatting(self):
        result = _format_body("text", {"duration": 615})
        assert "Duration: 10m15s" in result

    def test_duration_under_minute(self):
        result = _format_body("text", {"duration": 45})
        assert "Duration: 0m45s" in result

    def test_blank_line_separator(self):
        """Header and transcript separated by blank line."""
        result = _format_body("transcript", {"uploader": "Ch"})
        lines = result.split("\n")
        # Should be: "Channel: Ch", "", "transcript"
        assert lines[-2] == ""
        assert lines[-1] == "transcript"


class TestBuildTags:
    """_build_tags(metadata) → tag list."""

    def test_always_includes_base_tags(self):
        tags = _build_tags({})
        assert tags == ["youtube", "video"]

    def test_appends_youtube_tags_lowercased(self):
        tags = _build_tags({"tags": ["Python", "Tutorial", "CODING"]})
        assert tags == ["youtube", "video", "python", "tutorial", "coding"]

    def test_limits_to_10_tags(self):
        yt_tags = [f"tag{i}" for i in range(20)]
        tags = _build_tags({"tags": yt_tags})
        # 2 base + 10 from YouTube
        assert len(tags) == 12

    def test_none_tags(self):
        tags = _build_tags({"tags": None})
        assert tags == ["youtube", "video"]


# ---------------------------------------------------------------------------
# _fetch_info — mocked yt_dlp
# ---------------------------------------------------------------------------


class TestFetchInfo:
    """_fetch_info with mocked yt_dlp."""

    @patch("memex.memory.youtube_extract.yt_dlp")
    def test_success(self, mock_ytdlp):
        mock_ydl = MagicMock()
        mock_ydl.extract_info.return_value = {"title": "Test Video", "uploader": "Ch"}
        mock_ytdlp.YoutubeDL.return_value.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ytdlp.YoutubeDL.return_value.__exit__ = MagicMock(return_value=False)

        result = _fetch_info("fake_id")
        assert result["title"] == "Test Video"

    @patch("memex.memory.youtube_extract.yt_dlp")
    def test_extraction_exception(self, mock_ytdlp):
        mock_ydl = MagicMock()
        mock_ydl.extract_info.side_effect = Exception("Video unavailable")
        mock_ytdlp.YoutubeDL.return_value.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ytdlp.YoutubeDL.return_value.__exit__ = MagicMock(return_value=False)

        result = _fetch_info("fake_id")
        assert result == {}


# ---------------------------------------------------------------------------
# _extract_transcript_from_info — mocked urllib
# ---------------------------------------------------------------------------


class TestExtractTranscriptFromInfo:
    """_extract_transcript_from_info parses json3 subtitles from info dict."""

    def test_no_requested_subtitles(self):
        assert _extract_transcript_from_info({}) == ""

    def test_no_en_subtitles(self):
        assert _extract_transcript_from_info({"requested_subtitles": {"fr": {}}}) == ""

    def test_no_url(self):
        assert (
            _extract_transcript_from_info(
                {"requested_subtitles": {"en": {"ext": "json3"}}}
            )
            == ""
        )

    @patch("memex.memory.youtube_extract.urllib.request.urlopen")
    def test_success(self, mock_urlopen):
        json3_data = json.dumps(
            {
                "events": [
                    {"segs": [{"utf8": "Hello"}]},
                    {"segs": [{"utf8": " "}, {"utf8": "world"}]},
                ]
            }
        ).encode()
        mock_urlopen.return_value.read.return_value = json3_data

        info = {"requested_subtitles": {"en": {"url": "https://example.com/subs"}}}
        result = _extract_transcript_from_info(info)
        assert result == "Hello world"

    @patch("memex.memory.youtube_extract.urllib.request.urlopen")
    def test_filters_empty_and_newlines(self, mock_urlopen):
        json3_data = json.dumps(
            {
                "events": [
                    {"segs": [{"utf8": "Hello"}]},
                    {"segs": [{"utf8": "\n"}]},
                    {"segs": [{"utf8": ""}]},
                    {"segs": [{"utf8": "world"}]},
                ]
            }
        ).encode()
        mock_urlopen.return_value.read.return_value = json3_data

        info = {"requested_subtitles": {"en": {"url": "https://example.com/subs"}}}
        result = _extract_transcript_from_info(info)
        assert result == "Hello world"

    @patch("memex.memory.youtube_extract.urllib.request.urlopen")
    def test_download_failure(self, mock_urlopen):
        mock_urlopen.side_effect = Exception("Network error")

        info = {"requested_subtitles": {"en": {"url": "https://example.com/subs"}}}
        result = _extract_transcript_from_info(info)
        assert result == ""


# ---------------------------------------------------------------------------
# extract_from_youtube — integration of fetch + format
# ---------------------------------------------------------------------------


class TestExtractFromYoutube:
    """extract_from_youtube with mocked fetch functions."""

    @patch("memex.memory.youtube_extract._extract_transcript_from_info")
    @patch("memex.memory.youtube_extract._fetch_info")
    def test_full_extraction(self, mock_info, mock_transcript):
        mock_info.return_value = {
            "title": "Great Video",
            "uploader": "Test Channel",
            "upload_date": "20240101",
            "duration": 300,
            "description": "A great video about things",
            "tags": ["python", "coding"],
        }
        mock_transcript.return_value = "This is the transcript text with enough words"

        result = extract_from_youtube("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

        assert result.title == "Great Video"
        assert result.author == "Test Channel"
        assert result.date == "20240101"
        assert result.sitename == "YouTube"
        assert "transcript text" in result.body
        assert "Channel: Test Channel" in result.body
        assert result.word_count > 0
        assert result.raw_length > 0
        assert "youtube" in result.categories
        assert "video" in result.categories
        assert "python" in result.categories
        # Canonical URL
        assert result.url == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

    @patch("memex.memory.youtube_extract._extract_transcript_from_info")
    @patch("memex.memory.youtube_extract._fetch_info")
    def test_no_transcript_with_description_fallback(self, mock_info, mock_transcript):
        mock_info.return_value = {
            "title": "No Captions Video",
            "description": "Video description here",
        }
        mock_transcript.return_value = ""

        result = extract_from_youtube("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

        assert result.title == "No Captions Video"
        assert "[No transcript available]" in result.body
        assert "Video description here" in result.body

    @patch("memex.memory.youtube_extract._extract_transcript_from_info")
    @patch("memex.memory.youtube_extract._fetch_info")
    def test_no_transcript_no_description(self, mock_info, mock_transcript):
        mock_info.return_value = {"title": "No Captions Video"}
        mock_transcript.return_value = ""

        result = extract_from_youtube("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

        assert result.title == "No Captions Video"
        assert not result.body

    def test_invalid_url(self):
        result = extract_from_youtube("https://example.com/not-youtube")

        assert result.url == "https://example.com/not-youtube"
        assert result.body == ""
        assert result.title == ""

    @patch("memex.memory.youtube_extract._extract_transcript_from_info")
    @patch("memex.memory.youtube_extract._fetch_info")
    def test_description_truncated(self, mock_info, mock_transcript):
        mock_info.return_value = {
            "title": "Video",
            "description": "x" * 1000,
        }
        mock_transcript.return_value = "transcript"

        result = extract_from_youtube("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assert len(result.description) == 500

    @patch("memex.memory.youtube_extract._extract_transcript_from_info")
    @patch("memex.memory.youtube_extract._fetch_info")
    def test_canonical_url_from_shortlink(self, mock_info, mock_transcript):
        mock_info.return_value = {"title": "Video"}
        mock_transcript.return_value = "transcript"

        result = extract_from_youtube("https://youtu.be/dQw4w9WgXcQ")
        assert result.url == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
