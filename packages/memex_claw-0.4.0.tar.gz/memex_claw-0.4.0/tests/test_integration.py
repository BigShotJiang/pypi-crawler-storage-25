"""Integration test: full loop iteration with mocked LLM."""

from unittest.mock import patch

from memex.llm import TokenUsage
from memex.memory.conversation_extract import CombinedExtractReflectResult
from memex.memory.extraction_gate import ExtractionSignals
from memex.models import (
    GoalStatus,
    InputClassification,
    InputClassificationType,
    NewSubgoal,
)
from memex.loop import run_turn
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore


def _mock_combined(**reflect_kwargs):
    """Create a CombinedExtractReflectResult from ReflectResult-style kwargs."""
    return CombinedExtractReflectResult(**reflect_kwargs)


def test_full_flow_create_and_advance(tmp_path):
    """Simulate: user creates a goal, then advances it in the next turn."""
    _fs = FathomStore.open(str(tmp_path / "integration.db"))
    store = FathomMemexStore(_fs)

    # Turn 1: new goal
    def mock_classify_new(*args, **kwargs):
        return InputClassification(
            classification=InputClassificationType.NEW_GOAL,
            confidence=0.9,
            reasoning="new intent",
        )

    def mock_chat_1(messages, **kwargs):
        return "Great! I'll track your goal to learn Rust.", TokenUsage()

    def mock_extract_1(**kwargs):
        return _mock_combined(
            reflection_note="New Rust learning goal created",
            confidence=0.9,
        )

    _gate_true = ExtractionSignals(should_extract=True, signals={"factual_assertion"})

    with (
        patch("memex.classify.classify_input", mock_classify_new),
        patch("memex.llm.chat_with_usage", mock_chat_1),
        patch("memex.memory.conversation_extract.extract_and_reflect", mock_extract_1),
        patch(
            "memex.memory.extraction_gate.check_extraction_gate",
            return_value=_gate_true,
        ),
    ):
        response1, session = run_turn(
            "I want to learn Rust",
            store,
            project_root=tmp_path,
        )

    goals = store.list_goals(GoalStatus.ACTIVE)
    assert len(goals) == 1
    rust_goal = goals[0]
    assert "Rust" in rust_goal.title

    # Turn 2: advance with sub-goal creation via reflect
    def mock_classify_advance(*args, **kwargs):
        return InputClassification(
            classification=InputClassificationType.ADVANCES_GOAL,
            goal_id=rust_goal.goal_id,
            confidence=0.9,
            reasoning="working on Rust",
        )

    def mock_chat_2(messages, **kwargs):
        return "The ownership chapter is a great starting point.", TokenUsage()

    def mock_extract_2(**kwargs):
        return _mock_combined(
            intent_advanced=[rust_goal.goal_id],
            new_subgoals=[
                NewSubgoal(
                    parent_id=rust_goal.goal_id,
                    title="Read ownership chapter",
                    description="Chapter 4 of the Rust book",
                )
            ],
            reflection_note="Sub-goal created for ownership chapter",
            confidence=0.85,
        )

    with (
        patch("memex.classify.classify_input", mock_classify_advance),
        patch("memex.llm.chat_with_usage", mock_chat_2),
        patch("memex.memory.conversation_extract.extract_and_reflect", mock_extract_2),
        patch(
            "memex.memory.extraction_gate.check_extraction_gate",
            return_value=_gate_true,
        ),
    ):
        response2, session = run_turn(
            "Let's start with the ownership chapter",
            store,
            session,
            project_root=tmp_path,
        )

    # Verify sub-goal was created
    children = store.get_children(rust_goal.goal_id)
    assert len(children) == 1
    assert "ownership" in children[0].title.lower()

    # Verify session state
    assert session.turn_count == 2
    loaded_session = store.load_session()
    assert loaded_session is not None
    assert loaded_session.turn_count == 2

    # Verify tree structure
    tree = store.get_tree(rust_goal.goal_id)
    assert len(tree) == 2  # parent + child

    store.close()


def test_goal_persistence_across_sessions(tmp_path):
    """Goals survive store close/reopen (simulates restart)."""
    _fs = FathomStore.open(str(tmp_path / "persist.db"))
    store1 = FathomMemexStore(_fs)

    def mock_classify(*args, **kwargs):
        return InputClassification(
            classification=InputClassificationType.NEW_GOAL,
            confidence=0.9,
            reasoning="new",
        )

    def mock_chat(messages, **kwargs):
        return "Got it.", TokenUsage()

    def mock_extract(**kwargs):
        return _mock_combined(reflection_note="ok")

    _gate_true = ExtractionSignals(should_extract=True, signals={"factual_assertion"})

    with (
        patch("memex.classify.classify_input", mock_classify),
        patch("memex.llm.chat_with_usage", mock_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", mock_extract),
        patch(
            "memex.memory.extraction_gate.check_extraction_gate",
            return_value=_gate_true,
        ),
    ):
        run_turn("Learn Rust", store1, project_root=tmp_path)

    store1.close()

    # Reopen
    _fs = FathomStore.open(str(tmp_path / "persist.db"))
    store2 = FathomMemexStore(_fs)
    goals = store2.list_goals()
    assert len(goals) == 1
    assert "Rust" in goals[0].title
    store2.close()
