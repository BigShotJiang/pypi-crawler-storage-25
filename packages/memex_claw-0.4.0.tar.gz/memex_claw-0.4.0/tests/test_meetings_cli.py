"""Tests for meeting CLI canonical runtime reads."""

from __future__ import annotations

import argparse
from unittest.mock import patch

from memex.human_model import save_partner_profile
from memex.models import HumanPartnerProfile
from memex.meetings.cli import _cmd_meeting_transcribe
from memex.meetings.models import MeetingRecord, MeetingState
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


def test_cmd_meeting_transcribe_uses_canonical_partner_speaker_mappings(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        now = utcnow()
        record = MeetingRecord(
            meeting_id="mtg-cli-1",
            state=MeetingState.RECORDED,
            title="CLI Meeting",
            started_at=now,
            created_at=now,
            updated_at=now,
        )
        store.meetings.create_meeting(record)
        save_partner_profile(
            HumanPartnerProfile(
                name="Corey",
                working_context={"speaker_mappings": {"SPEAKER_00": "Corey"}},
            ),
            store,
        )
        args = argparse.Namespace(
            id="mtg-cli-1",
            model="large-v3",
            extract_actions=False,
        )

        with (
            patch("memex.meetings.cli._make_fathom_store", return_value=store),
            patch(
                "memex.meetings.transcribe.orchestrate_transcription", return_value=None
            ) as mock_orchestrate,
        ):
            _cmd_meeting_transcribe(args)

        assert mock_orchestrate.call_args.kwargs["speaker_mappings"] == {
            "SPEAKER_00": "Corey",
        }
    finally:
        store.close()
