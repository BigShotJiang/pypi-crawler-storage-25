"""Tests for Memex TUI widgets and app behavior."""

from __future__ import annotations

import logging
import pytest
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import MagicMock, PropertyMock, patch

from textual.widgets import TextArea

from textual.actions import SkipAction
from memex.interfaces.tui.app import (
    ConfirmDialog,
    MemexApp,
    MeetingDetailScreen,
    NewMeetingDialog,
)
from memex.interfaces.tui.widgets.conversation import ConversationPanel
from memex.interfaces.tui.widgets.header_bar import HeaderBar
from memex.interfaces.tui.widgets.footer_bar import FooterBar
from memex.interfaces.tui.widgets.base_drawer import BaseDrawer
from memex.interfaces.tui.widgets.intent_drawer import IntentDrawer, STATUS_ICONS
from memex.interfaces.tui.widgets.attention_drawer import AttentionDrawer
from memex.interfaces.tui.widgets.input_bar import InputBar, _PROMPT
from memex.interfaces.tui.widgets.command_hints import CommandHintPanel
from memex.interfaces.tui.commands import SlashCommand, SlashCommandRegistry
from memex.interfaces.tui.prompt_history import PromptHistory
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# ConversationPanel — message buffer and recent pairs
# ---------------------------------------------------------------------------


class TestConversationBuffer:
    def test_get_recent_pairs_empty(self):
        panel = ConversationPanel()
        assert panel.get_recent_pairs() == []

    def test_get_recent_pairs_single(self):
        panel = ConversationPanel()
        panel._message_buffer.append(("human", "hello"))
        panel._message_buffer.append(("assistant", "hi there"))
        pairs = panel.get_recent_pairs()
        assert len(pairs) == 1
        assert pairs[0] == ("hello", "hi there")

    def test_get_recent_pairs_multiple(self):
        panel = ConversationPanel()
        panel._message_buffer.extend(
            [
                ("human", "q1"),
                ("assistant", "a1"),
                ("human", "q2"),
                ("assistant", "a2"),
                ("human", "q3"),
                ("assistant", "a3"),
            ]
        )
        pairs = panel.get_recent_pairs(2)
        assert len(pairs) == 2
        assert pairs[0] == ("q2", "a2")
        assert pairs[1] == ("q3", "a3")

    def test_get_recent_pairs_skips_system(self):
        panel = ConversationPanel()
        panel._message_buffer.extend(
            [
                ("human", "hi"),
                ("system", "mode set"),
                ("assistant", "hello"),
            ]
        )
        pairs = panel.get_recent_pairs()
        assert len(pairs) == 1
        assert pairs[0] == ("hi", "hello")

    def test_get_recent_pairs_caps_at_n(self):
        panel = ConversationPanel()
        for i in range(10):
            panel._message_buffer.append(("human", f"q{i}"))
            panel._message_buffer.append(("assistant", f"a{i}"))
        pairs = panel.get_recent_pairs(3)
        assert len(pairs) == 3
        assert pairs[0] == ("q7", "a7")
        assert pairs[2] == ("q9", "a9")


# ---------------------------------------------------------------------------
# ConversationPanel — streaming content tracking
# ---------------------------------------------------------------------------


class TestConversationStreaming:
    """Tests for streaming state management in ConversationPanel.

    These tests manipulate internal state directly (no Textual mount needed)
    to verify _streaming_content tracking without relying on Static.renderable.
    """

    def _panel_with_streaming(self, text: str) -> ConversationPanel:
        """Return a panel with an active streaming static and given content."""
        panel = ConversationPanel()
        panel._streaming_static = MagicMock()
        panel._streaming_content = text
        return panel

    def test_get_streaming_content_none_when_no_static(self):
        panel = ConversationPanel()
        assert panel._streaming_static is None
        assert panel.get_streaming_content() is None

    def test_get_streaming_content_returns_text_when_streaming(self):
        panel = self._panel_with_streaming("Hello world")
        assert panel.get_streaming_content() == "Hello world"

    def test_get_streaming_content_none_for_empty_string(self):
        panel = self._panel_with_streaming("")
        assert panel.get_streaming_content() is None

    def test_get_streaming_content_none_for_whitespace(self):
        panel = self._panel_with_streaming("   \n  ")
        assert panel.get_streaming_content() is None

    def test_append_streaming_updates_content(self):
        panel = ConversationPanel()
        panel._streaming_static = MagicMock()
        panel._streaming_content = ""
        panel.append_streaming("partial response")
        assert panel._streaming_content == "partial response"
        panel._streaming_static.update.assert_called_once_with("partial response")

    def test_append_streaming_accumulates(self):
        panel = ConversationPanel()
        panel._streaming_static = MagicMock()
        panel.append_streaming("first")
        panel.append_streaming("first second")
        assert panel._streaming_content == "first second"

    def test_append_streaming_noop_when_no_static(self):
        panel = ConversationPanel()
        panel.append_streaming("should be ignored")
        assert panel._streaming_content == ""

    def test_finish_streaming_clears_content(self):
        panel = self._panel_with_streaming("some text")
        with patch.object(
            type(panel), "_log", new_callable=PropertyMock, return_value=MagicMock()
        ):
            panel.finish_streaming()
        assert panel._streaming_static is None
        assert panel._streaming_content == ""

    def test_discard_interrupted_clears_content(self):
        panel = self._panel_with_streaming("partial")
        with patch.object(
            type(panel), "_log", new_callable=PropertyMock, return_value=MagicMock()
        ):
            panel.discard_interrupted()
        assert panel._streaming_static is None
        assert panel._streaming_content == ""

    def test_finalize_interrupted_returns_content_and_clears(self):
        panel = self._panel_with_streaming("interrupted text")
        panel.add_message = MagicMock()
        with patch.object(
            type(panel), "_log", new_callable=PropertyMock, return_value=MagicMock()
        ):
            content = panel.finalize_interrupted()
        assert content == "interrupted text"
        assert panel._streaming_static is None
        assert panel._streaming_content == ""

    def test_finalize_interrupted_returns_none_when_empty(self):
        panel = self._panel_with_streaming("")
        panel.add_message = MagicMock()
        with patch.object(
            type(panel), "_log", new_callable=PropertyMock, return_value=MagicMock()
        ):
            content = panel.finalize_interrupted()
        assert content is None
        panel.add_message.assert_not_called()

    def test_start_streaming_resets_content(self):
        panel = ConversationPanel()
        panel._streaming_content = "leftover"
        panel.mount = MagicMock()
        panel.start_streaming()
        assert panel._streaming_content == ""
        assert panel._streaming_static is not None


# ---------------------------------------------------------------------------
# BaseDrawer
# ---------------------------------------------------------------------------


class TestBaseDrawer:
    def test_toggle_updates_open_state_and_display(self):
        class DummyDrawer(BaseDrawer):
            DRAWER_NAME = "dummy"

        drawer = DummyDrawer()
        assert not drawer.is_open

        drawer.toggle()
        assert drawer.is_open
        assert drawer.display is True

        drawer.toggle()
        assert not drawer.is_open
        assert drawer.display is False

    def test_drawer_close_message_uses_subclass_name(self):
        class DummyDrawer(BaseDrawer):
            DRAWER_NAME = "dummy"

        close_msg = DummyDrawer.DrawerClose(DummyDrawer.DRAWER_NAME)
        assert close_msg.drawer == "dummy"


class TestMeetingDetailScreen:
    def test_escape_closes_modal_from_list_focus(self):
        meeting = SimpleNamespace(
            action_items=[],
            notes="",
            recordings=[],
        )
        screen = MeetingDetailScreen(meeting, store=MagicMock())
        screen.dismiss = MagicMock()
        notes = MagicMock()
        notes.text = ""
        screen.query_one = MagicMock(return_value=notes)

        event = SimpleNamespace(
            key="escape", prevent_default=MagicMock(), stop=MagicMock()
        )
        with patch.object(
            MeetingDetailScreen,
            "focused",
            new_callable=PropertyMock,
            return_value=object(),
        ):
            screen.on_key(event)

        event.prevent_default.assert_called_once()
        event.stop.assert_called_once()
        screen.dismiss.assert_called_once_with({"notes": "", "action_items": []})

    def test_escape_closes_modal_from_textarea_focus(self):
        meeting = SimpleNamespace(
            action_items=[],
            notes="draft notes",
            recordings=[],
        )
        screen = MeetingDetailScreen(meeting, store=MagicMock())
        screen.dismiss = MagicMock()
        notes = MagicMock()
        notes.text = "draft notes"
        screen.query_one = MagicMock(return_value=notes)

        event = SimpleNamespace(
            key="escape", prevent_default=MagicMock(), stop=MagicMock()
        )
        with patch.object(
            MeetingDetailScreen,
            "focused",
            new_callable=PropertyMock,
            return_value=TextArea(),
        ):
            screen.on_key(event)

        event.prevent_default.assert_called_once()
        event.stop.assert_called_once()
        screen.dismiss.assert_called_once_with(
            {"notes": "draft notes", "action_items": []}
        )

    def test_retry_selected_recording_dismisses_with_recording_id(self):
        meeting = SimpleNamespace(
            action_items=[],
            notes="draft notes",
            recordings=[
                SimpleNamespace(
                    recording_id="rec-1",
                    audio_path="/tmp/audio.wav",
                    state=SimpleNamespace(value="failed"),
                )
            ],
        )
        screen = MeetingDetailScreen(meeting, store=MagicMock())
        screen.dismiss = MagicMock()
        notes = MagicMock()
        notes.text = "draft notes"
        recording_list = MagicMock()
        recording_list.index = 0

        def _query_one(selector, _type=None):
            if selector == "#detail-notes":
                return notes
            if selector == "#detail-recording-list":
                return recording_list
            raise AssertionError(selector)

        screen.query_one = MagicMock(side_effect=_query_one)
        event = SimpleNamespace(key="t", prevent_default=MagicMock(), stop=MagicMock())

        with patch.object(
            MeetingDetailScreen,
            "focused",
            new_callable=PropertyMock,
            return_value=object(),
        ):
            screen.on_key(event)

        event.prevent_default.assert_called_once()
        screen.dismiss.assert_called_once_with(
            {
                "notes": "draft notes",
                "action_items": [],
                "retry_recording_id": "rec-1",
            }
        )


class TestNewMeetingDialog:
    def test_default_scheduled_for_floors_to_previous_quarter_hour(self):
        dt = NewMeetingDialog._default_scheduled_for(datetime(2026, 3, 16, 10, 22, 41))
        assert dt == datetime(2026, 3, 16, 10, 15)

    def test_up_arrow_advances_schedule_by_fifteen_minutes(self):
        dialog = NewMeetingDialog()
        scheduled = SimpleNamespace(id="nm-scheduled", value="2026-03-16 10:15")
        event = SimpleNamespace(key="up", prevent_default=MagicMock())

        with patch.object(
            NewMeetingDialog,
            "focused",
            new_callable=PropertyMock,
            return_value=scheduled,
        ):
            dialog.on_key(event)

        event.prevent_default.assert_called_once()
        assert scheduled.value == "2026-03-16 10:30"

    def test_down_arrow_decrements_schedule_by_fifteen_minutes(self):
        dialog = NewMeetingDialog()
        scheduled = SimpleNamespace(id="nm-scheduled", value="2026-03-16 10:15")
        event = SimpleNamespace(key="down", prevent_default=MagicMock())

        with patch.object(
            NewMeetingDialog,
            "focused",
            new_callable=PropertyMock,
            return_value=scheduled,
        ):
            dialog.on_key(event)

        event.prevent_default.assert_called_once()
        assert scheduled.value == "2026-03-16 10:00"


# ---------------------------------------------------------------------------
# HeaderBar
# ---------------------------------------------------------------------------


class TestHeaderBar:
    def test_initial_state(self):
        hb = HeaderBar()
        assert hb.focal_goal == ""
        assert hb.mode == "normal"
        assert hb.attn_count == 0
        assert hb.attn_urgency == "ok"

    def test_update_goal(self):
        hb = HeaderBar()
        hb.update_goal("Build memex")
        assert hb.focal_goal == "Build memex"

    def test_update_mode(self):
        hb = HeaderBar()
        hb.update_mode("deep_work")
        assert hb.mode == "deep_work"

    def test_update_model(self):
        hb = HeaderBar()
        hb.update_model("sonnet-4")
        assert hb.model == "sonnet-4"

    def test_update_cost(self):
        hb = HeaderBar()
        hb.update_cost("$0.42")
        assert hb.cost == "$0.42"

    def test_update_attention(self):
        hb = HeaderBar()
        hb.update_attention(3, "warning")
        assert hb.attn_count == 3
        assert hb.attn_urgency == "warning"

    def test_render_minimal(self):
        hb = HeaderBar()
        rendered = hb.render()
        assert "MEMEX" in rendered
        assert "normal" in rendered

    def test_render_with_goal(self):
        hb = HeaderBar()
        hb.update_goal("Ship v1")
        rendered = hb.render()
        assert "◈ Ship v1" in rendered

    def test_render_attn_shown_when_zero(self):
        hb = HeaderBar()
        rendered = hb.render()
        assert "ATTN:0" in rendered

    def test_render_attn_shown_when_nonzero(self):
        hb = HeaderBar()
        hb.update_attention(5, "error")
        rendered = hb.render()
        assert "ATTN:5" in rendered

    def test_render_activity_shown_when_nonzero(self):
        hb = HeaderBar()
        hb.update_activity(2, "Gmail ingest")
        rendered = hb.render()
        assert "ACT:2" in rendered
        assert "[Gmail ingest]" in rendered

    # --- VU meter and recording indicator ---

    def test_recording_indicator_absent_when_not_recording(self):
        hb = HeaderBar()
        rendered = hb.render()
        assert "REC" not in rendered
        assert "●" not in rendered

    def test_recording_indicator_present_when_recording(self):
        hb = HeaderBar()
        hb.update_recording(True)
        rendered = hb.render()
        assert "● REC" in rendered

    def test_vu_bar_shown_in_header_when_recording(self):
        hb = HeaderBar()
        hb.update_recording(True)
        hb.update_level(0.5)
        rendered = hb.render()
        assert "█" in rendered
        assert "░" in rendered

    def test_vu_bar_all_empty_at_zero_level(self):
        hb = HeaderBar()
        hb.update_recording(True)
        hb.update_level(0.0)
        rendered = hb.render()
        # No filled blocks at zero
        assert "░░░░░░░░░░" in rendered

    def test_vu_bar_all_full_at_max_level(self):
        hb = HeaderBar()
        hb.update_recording(True)
        hb.update_level(1.0)
        rendered = hb.render()
        assert "██████████" in rendered

    def test_update_recording_false_clears_level(self):
        hb = HeaderBar()
        hb.update_recording(True)
        hb.update_level(0.8)
        assert hb.recording_level == pytest.approx(0.8)
        hb.update_recording(False)
        assert hb.recording_level == pytest.approx(0.0)

    def test_vu_bar_hidden_when_not_recording(self):
        hb = HeaderBar()
        hb.update_level(0.9)  # level set, but not recording
        rendered = hb.render()
        assert "REC" not in rendered


# ---------------------------------------------------------------------------
# FooterBar
# ---------------------------------------------------------------------------


class TestFooterBar:
    def test_default_context(self):
        fb = FooterBar()
        assert fb.context == "default"

    def test_set_context_intents(self):
        fb = FooterBar()
        fb.set_context("intents")
        assert fb.context == "intents"

    def test_set_context_attention(self):
        fb = FooterBar()
        fb.set_context("attention")
        assert fb.context == "attention"

    def test_render_default(self):
        fb = FooterBar()
        rendered = fb.render()
        assert "Ctrl+N" in rendered
        assert "Ctrl+A" in rendered

    def test_render_intents(self):
        fb = FooterBar()
        fb.set_context("intents")
        rendered = fb.render()
        assert "navigate" in rendered
        assert "Esc" in rendered

    def test_render_attention(self):
        fb = FooterBar()
        fb.set_context("attention")
        rendered = fb.render()
        assert "a)pprove" in rendered

    def test_render_meetings_recording(self):
        fb = FooterBar()
        fb.set_context("meetings_recording")
        rendered = fb.render()
        assert "Ctrl+R" in rendered
        assert "s/" in rendered
        assert "stop recording" in rendered


def test_app_plain_s_stops_recording_when_not_typing():
    app = MemexApp.__new__(MemexApp)
    app._audio_capture = object()
    app._stop_recording = MagicMock()

    event = MagicMock()
    event.key = "s"

    with (
        patch.object(MemexApp, "focused", new_callable=PropertyMock, return_value=None),
        patch.object(
            MemexApp, "screen", new_callable=PropertyMock, return_value=object()
        ),
    ):
        MemexApp.on_key(app, event)

    app._stop_recording.assert_called_once()
    event.prevent_default.assert_called_once()
    event.stop.assert_called_once()


def test_app_plain_r_stops_recording_when_not_typing():
    app = MemexApp.__new__(MemexApp)
    app._audio_capture = object()
    app._stop_recording = MagicMock()

    event = MagicMock()
    event.key = "r"

    with (
        patch.object(MemexApp, "focused", new_callable=PropertyMock, return_value=None),
        patch.object(
            MemexApp, "screen", new_callable=PropertyMock, return_value=object()
        ),
    ):
        MemexApp.on_key(app, event)

    app._stop_recording.assert_called_once()
    event.prevent_default.assert_called_once()
    event.stop.assert_called_once()


def test_confirm_dialog_escape_dismisses_false_and_stops_event():
    dialog = ConfirmDialog("Start another recording?")
    dialog.dismiss = MagicMock()
    event = SimpleNamespace(key="escape", prevent_default=MagicMock(), stop=MagicMock())

    dialog.on_key(event)

    event.prevent_default.assert_called_once()
    event.stop.assert_called_once()
    dialog.dismiss.assert_called_once_with(False)


def test_app_escape_skips_action_for_modal_screen():
    """action_cancel_turn raises SkipAction when any modal is active so the
    modal's own on_key handler can process Escape via _forward_event."""
    import pytest

    app = MemexApp.__new__(MemexApp)
    screen = MagicMock(spec=MeetingDetailScreen)

    with patch.object(
        MemexApp, "screen", new_callable=PropertyMock, return_value=screen
    ):
        with pytest.raises(SkipAction):
            MemexApp.action_cancel_turn(app)


def test_load_initial_data_logs_clean_state_when_no_stale_recordings(caplog):
    app = MemexApp.__new__(MemexApp)
    app._api = MagicMock()
    app._api.cleanup_stale_recordings.return_value = 0
    app._load_attention_data = MagicMock()
    app._mode = "normal"
    app._make_caller = MagicMock(return_value=object())

    intent_drawer = MagicMock()
    header_bar = MagicMock()

    def query_one(selector, _widget_type):
        if selector == "#intent-drawer":
            return intent_drawer
        if selector == "#header-bar":
            return header_bar
        raise AssertionError(f"unexpected selector: {selector}")

    app.query_one = MagicMock(side_effect=query_one)
    app._api.intent.return_value = []
    app._api.status.return_value = {"goals_active": 0}

    with caplog.at_level(logging.DEBUG, logger="memex.interfaces.tui.app"):
        MemexApp._load_initial_data(app)

    assert "Startup: state sweep found no stale recording(s)" in caplog.text


# ---------------------------------------------------------------------------
# IntentDrawer
# ---------------------------------------------------------------------------


class TestIntentDrawer:
    def test_initially_hidden(self):
        drawer = IntentDrawer()
        assert not drawer.is_open

    def test_toggle(self):
        drawer = IntentDrawer()
        drawer.toggle()
        assert drawer.is_open
        drawer.toggle()
        assert not drawer.is_open

    def test_status_icons_unicode(self):
        assert STATUS_ICONS["active"] == "●"
        assert STATUS_ICONS["completed"] == "✓"
        assert STATUS_ICONS["paused"] == "⊘"
        assert STATUS_ICONS["blocked"] == "○"
        assert STATUS_ICONS["failed"] == "✗"
        assert STATUS_ICONS["abandoned"] == "◌"

    def test_intent_drawer_docks_right(self):
        """IntentDrawer DEFAULT_CSS uses dock:right, not dock:bottom."""
        assert "dock: right" in IntentDrawer.DEFAULT_CSS
        assert "dock: bottom" not in IntentDrawer.DEFAULT_CSS

    def test_intent_drawer_css_has_border_left(self):
        """IntentDrawer DEFAULT_CSS uses border-left, not border-top."""
        assert "border-left" in IntentDrawer.DEFAULT_CSS
        assert "border-top" not in IntentDrawer.DEFAULT_CSS


class TestCloseAllDrawersExceptPreservesIntent:
    """_close_all_drawers_except must never force-close the intent drawer."""

    def _make_open_drawer(self):
        d = MagicMock()
        d.is_open = True
        return d

    def _make_closed_drawer(self):
        d = MagicMock()
        d.is_open = False
        return d

    def test_opening_attention_does_not_close_open_intent(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")

        intent = self._make_open_drawer()
        attention = self._make_closed_drawer()
        scheduler = self._make_closed_drawer()
        meetings = self._make_closed_drawer()
        subagents = self._make_closed_drawer()

        def query_one(selector, _type=None):
            return {
                "#intent-drawer": intent,
                "#attention-drawer": attention,
                "#scheduler-drawer": scheduler,
                "#meeting-drawer": meetings,
                "#subagent-drawer": subagents,
            }[selector]

        app.query_one = MagicMock(side_effect=query_one)
        app._close_all_drawers_except("attention")

        # intent drawer must NOT be toggled (it's always preserved)
        intent.toggle.assert_not_called()

    def test_opening_meetings_does_not_close_open_intent(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")

        intent = self._make_open_drawer()
        attention = self._make_closed_drawer()
        scheduler = self._make_open_drawer()
        meetings = self._make_closed_drawer()
        subagents = self._make_closed_drawer()

        def query_one(selector, _type=None):
            return {
                "#intent-drawer": intent,
                "#attention-drawer": attention,
                "#scheduler-drawer": scheduler,
                "#meeting-drawer": meetings,
                "#subagent-drawer": subagents,
            }[selector]

        app.query_one = MagicMock(side_effect=query_one)
        app._close_all_drawers_except("meetings")

        # intent must stay open; scheduler (another open drawer) must be closed
        intent.toggle.assert_not_called()
        scheduler.toggle.assert_called_once()


# ---------------------------------------------------------------------------
# AttentionDrawer
# ---------------------------------------------------------------------------


class TestAttentionDrawer:
    def test_initially_hidden(self):
        drawer = AttentionDrawer()
        assert not drawer.is_open

    def test_toggle(self):
        drawer = AttentionDrawer()
        drawer.toggle()
        assert drawer.is_open
        drawer.toggle()
        assert not drawer.is_open

    def test_urgency_critical(self):
        drawer = AttentionDrawer()
        count, urgency = drawer.get_count_and_urgency(
            [
                {"title": "A", "priority": "critical"},
                {"title": "B", "priority": "normal"},
            ]
        )
        assert count == 2
        assert urgency == "error"

    def test_urgency_high(self):
        drawer = AttentionDrawer()
        count, urgency = drawer.get_count_and_urgency(
            [
                {"title": "A", "priority": "high"},
                {"title": "B", "priority": "normal"},
            ]
        )
        assert count == 2
        assert urgency == "warning"

    def test_urgency_normal(self):
        drawer = AttentionDrawer()
        count, urgency = drawer.get_count_and_urgency(
            [
                {"title": "A", "priority": "normal"},
            ]
        )
        assert count == 1
        assert urgency == "ok"

    def test_urgency_empty(self):
        drawer = AttentionDrawer()
        count, urgency = drawer.get_count_and_urgency([])
        assert count == 0
        assert urgency == "ok"


# ---------------------------------------------------------------------------
# Layout / app
# ---------------------------------------------------------------------------


class TestLayout:
    def test_mode_selector_modes(self):
        from memex.interfaces.tui.app import ModeSelector

        ms = ModeSelector()
        assert ms is not None

    def test_app_creation(self):
        """MemexApp can be instantiated without API (demo mode)."""
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        assert app._mode == "normal"

    def test_app_with_api(self):
        from memex.interfaces.tui.app import MemexApp

        api = MagicMock()
        app = MemexApp(api=api, mode="review")
        assert app._mode == "review"
        assert app._api is api

    def test_app_has_drawer_bindings(self):
        """Verify Ctrl+N, Ctrl+A, and Ctrl+Y bindings exist."""
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        binding_keys = [b.key for b in app.BINDINGS]
        assert "ctrl+n" in binding_keys
        assert "ctrl+a" in binding_keys
        assert "ctrl+y" in binding_keys

    def test_app_focal_goal_init(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        assert app._focal_goal_id is None
        assert app._focal_goal_title == ""

    def test_app_has_escape_binding(self):
        """Verify Escape binding exists for cancel_turn."""
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        binding_keys = [b.key for b in app.BINDINGS]
        assert "escape" in binding_keys

    def test_cancel_event_init(self):
        """App initializes with cancel event cleared and turn not active."""
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        assert not app._cancel_event.is_set()
        assert not app._turn_active

    def test_cancel_turn_noop_when_idle(self):
        """action_cancel_turn raises SkipAction when idle so drawer bindings can handle Esc."""
        import pytest
        from textual.actions import SkipAction
        from textual.screen import Screen
        from unittest.mock import MagicMock, PropertyMock, patch
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=None, mode="normal")
        mock_screen = MagicMock(spec=Screen)
        mock_screen.__class__ = Screen  # not a ModalScreen
        with patch.object(
            type(app), "screen", new_callable=PropertyMock, return_value=mock_screen
        ):
            with pytest.raises(SkipAction):
                app.action_cancel_turn()
        assert not app._cancel_event.is_set()

    def test_cancel_turn_sets_event_when_active(self):
        """action_cancel_turn sets the cancel event when a turn is active."""
        from memex.interfaces.tui.app import MemexApp
        from memex.models import TurnCancelled

        app = MemexApp(api=None, mode="normal")
        app._turn_active = True
        # Can't call action_cancel_turn without mounted widgets,
        # but we can verify the exception class exists and the event works
        app._cancel_event.set()
        assert app._cancel_event.is_set()
        # Verify TurnCancelled is raisable
        try:
            raise TurnCancelled()
        except TurnCancelled:
            pass

    def test_drawer_mutual_exclusion_attributes(self):
        """Both drawers start closed — mutual exclusion is enforced by toggle actions."""
        intent = IntentDrawer()
        attn = AttentionDrawer()
        assert not intent.is_open
        assert not attn.is_open

    def test_toggle_intents_refreshes_goals_on_open(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=MagicMock(), mode="normal")
        app._refresh_intent_drawer = MagicMock()

        class FakeDrawer:
            def __init__(self) -> None:
                self.is_open = False
                self.focus = MagicMock()

            def toggle(self) -> None:
                self.is_open = not self.is_open

        intent = FakeDrawer()
        attention = FakeDrawer()
        scheduler = FakeDrawer()
        meetings = FakeDrawer()
        subagents = FakeDrawer()
        footer = MagicMock()
        input_bar = MagicMock()

        def query_one(selector, _widget_type=None):
            lookup = {
                "#intent-drawer": intent,
                "#attention-drawer": attention,
                "#scheduler-drawer": scheduler,
                "#meeting-drawer": meetings,
                "#subagent-drawer": subagents,
                "#footer-bar": footer,
                "#input-bar": input_bar,
            }
            return lookup[selector]

        app.query_one = MagicMock(side_effect=query_one)

        app.action_toggle_intents()

        app._refresh_intent_drawer.assert_called_once_with()
        footer.set_context.assert_called_once_with("intents")
        intent.focus.assert_called_once_with()

    def test_toggle_intents_does_not_refresh_on_close(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=MagicMock(), mode="normal")
        app._refresh_intent_drawer = MagicMock()

        class FakeDrawer:
            def __init__(self, is_open: bool = False) -> None:
                self.is_open = is_open
                self.focus = MagicMock()

            def toggle(self) -> None:
                self.is_open = not self.is_open

        intent = FakeDrawer(is_open=True)
        attention = FakeDrawer()
        scheduler = FakeDrawer()
        meetings = FakeDrawer()
        subagents = FakeDrawer()
        footer = MagicMock()
        input_bar = MagicMock()

        def query_one(selector, _widget_type=None):
            lookup = {
                "#intent-drawer": intent,
                "#attention-drawer": attention,
                "#scheduler-drawer": scheduler,
                "#meeting-drawer": meetings,
                "#subagent-drawer": subagents,
                "#footer-bar": footer,
                "#input-bar": input_bar,
            }
            return lookup[selector]

        app.query_one = MagicMock(side_effect=query_one)

        app.action_toggle_intents()

        app._refresh_intent_drawer.assert_not_called()
        footer.set_context.assert_called_once_with("default")
        input_bar.focus.assert_called_once_with()

    def test_toggle_meetings_focuses_table_on_open(self):
        from memex.interfaces.tui.app import MemexApp

        app = MemexApp(api=MagicMock(), mode="normal")
        app._load_meeting_data = MagicMock()

        class FakeDrawer:
            def __init__(self, is_open: bool = False) -> None:
                self.is_open = is_open
                self.is_recording = False
                self.is_paused = False
                self.focus = MagicMock()
                self.focus_table = MagicMock()

            def toggle(self) -> None:
                self.is_open = not self.is_open

        intent = FakeDrawer()
        attention = FakeDrawer()
        scheduler = FakeDrawer()
        meetings = FakeDrawer()
        subagents = FakeDrawer()
        footer = MagicMock()
        input_bar = MagicMock()

        def query_one(selector, _widget_type=None):
            lookup = {
                "#intent-drawer": intent,
                "#attention-drawer": attention,
                "#scheduler-drawer": scheduler,
                "#meeting-drawer": meetings,
                "#subagent-drawer": subagents,
                "#footer-bar": footer,
                "#input-bar": input_bar,
            }
            return lookup[selector]

        app.query_one = MagicMock(side_effect=query_one)

        app.action_toggle_meetings()

        app._load_meeting_data.assert_called_once_with()
        footer.set_context.assert_called_once_with("meetings")
        meetings.focus_table.assert_called_once_with()
        meetings.focus.assert_not_called()


# ---------------------------------------------------------------------------
# InputBar — prompt history navigation
# ---------------------------------------------------------------------------


def _make_input_bar(tmp_path, entries=None):
    """Create an InputBar with a test history file, bypassing on_mount."""
    bar = InputBar()
    bar._history = PromptHistory(path=tmp_path / "history.json")
    bar._history.load()
    if entries:
        for e in entries:
            bar._history.add(e)
    bar._history_index = len(bar._history.entries)
    # Simulate mounted state: insert prompt
    bar.insert(_PROMPT)
    return bar


class TestInputBarHistory:
    def test_submit_adds_to_history(self, tmp_path):
        """Submit text -> appears in history."""
        bar = _make_input_bar(tmp_path)
        bar.clear()
        bar.insert(_PROMPT + "hello world")
        bar._submit()
        assert "hello world" in bar._history.entries

    def test_history_up_replaces_buffer(self, tmp_path):
        """Up arrow shows previous prompt."""
        bar = _make_input_bar(tmp_path, ["first", "second"])
        bar._history_up()
        assert bar._get_user_text() == "second"
        bar._history_up()
        assert bar._get_user_text() == "first"

    def test_history_down_restores_draft(self, tmp_path):
        """Type draft, up, down -> draft restored."""
        bar = _make_input_bar(tmp_path, ["old"])
        # Simulate user typing a draft
        bar.clear()
        bar.insert(_PROMPT + "my draft")
        bar._history_up()
        assert bar._get_user_text() == "old"
        bar._history_down()
        assert bar._get_user_text() == "my draft"

    def test_history_up_clamps_at_zero(self, tmp_path):
        """Pressing up at start of history stays at first entry."""
        bar = _make_input_bar(tmp_path, ["only"])
        bar._history_up()
        assert bar._get_user_text() == "only"
        bar._history_up()  # should not crash, stays at 0
        assert bar._get_user_text() == "only"
        assert bar._history_index == 0

    def test_history_up_empty_noop(self, tmp_path):
        """Up with no history is a no-op."""
        bar = _make_input_bar(tmp_path)
        bar.clear()
        bar.insert(_PROMPT + "draft")
        bar._history_up()
        # Buffer unchanged — no history to navigate
        assert bar._get_user_text() == "draft"

    def test_submit_resets_navigation(self, tmp_path):
        """Submit while browsing resets index to end."""
        bar = _make_input_bar(tmp_path, ["first", "second"])
        bar._history_up()  # index -> 1
        # Now submit something new
        bar.clear()
        bar.insert(_PROMPT + "third")
        bar._submit()
        assert bar._history_index == len(bar._history.entries)
        assert bar._draft is None
        assert bar._history.entries[-1] == "third"


def test_meeting_detail_close_resyncs_ingested_item_semantics_after_goal_promotion(
    tmp_path,
):
    from memex.memory.intake import ingest
    from memex.meetings.models import MeetingRecord, MeetingState
    from memex.models import ItemType
    from memex.fathom_facade import FathomMemexStore
    from memex.fathom_store import FathomStore

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-tui-sync",
        state=MeetingState.INGESTED,
        title="Sprint Planning",
        ingested_at=now,
        created_at=now,
        updated_at=now,
    )
    store.meetings.create_meeting(meeting)

    item = ingest(
        "Initial meeting transcript body.",
        type=ItemType.MEETING,
        title="Sprint Planning",
        source_url="memex://meeting/mtg-tui-sync",
        content_store=store.content,
        memex_store=store,
        generate_summary=False,
    )
    item.metadata = {"meeting": {"meeting_id": "mtg-tui-sync"}}
    store.content.update_item(item)

    meeting = store.meetings.get_meeting("mtg-tui-sync")
    assert meeting is not None
    meeting.item_id = item.item_id
    store.meetings.update_meeting(meeting)

    app = MemexApp.__new__(MemexApp)
    app._api = SimpleNamespace(
        store=store,
        content_store=store.content,
        create_goal=store.create_goal,
        update_goal=store.update_goal,
        get_goal=store.get_goal,
        create_meeting_goal_link=store.create_meeting_goal_link,
        get_meeting=store.meetings.get_meeting,
        update_meeting=store.meetings.update_meeting,
    )
    app._load_meeting_data = MagicMock()
    app.query_one = MagicMock(return_value=MagicMock())

    with (
        patch("memex.interfaces.tui.app.uuid.uuid4", return_value="goal-promoted-1"),
        patch("memex.event_bus.get_bus", return_value=MagicMock()),
    ):
        MemexApp._on_meeting_detail_closed(
            app,
            {
                "notes": (
                    "Decision: Ship docs by Friday.\n"
                    "Outcome: Roll out the docs update after review.\n"
                    "Commitment: Corey will send the rollout summary."
                ),
                "action_items": [
                    {
                        "text": "Ship docs",
                        "assignee": "Corey",
                        "deadline": "Friday",
                        "commitment_confirmed": True,
                        "agreed_by": "Corey",
                        "promoted_goal_id": "__pending__",
                        "promote_parent_goal_id": None,
                    }
                ],
            },
            "mtg-tui-sync",
        )

    refreshed = store.meetings.get_meeting("mtg-tui-sync")
    assert refreshed is not None
    stored_item = store.content.get_item(item.item_id)
    assert stored_item is not None

    links = {
        (link.goal_id, link.relationship)
        for link in store.list_meeting_goal_links("mtg-tui-sync")
    }
    semantic = stored_item.metadata["meeting"]["semantic"]
    knowledge = store.load_world_model_knowledge_object_by_item_id(item.item_id)

    assert ("goal-promoted-1", "explicit") in links
    assert ("goal-promoted-1", "promoted_action_item") in links
    assert semantic["decisions"][0]["content"] == "Ship docs by Friday."
    assert (
        semantic["outcomes"][0]["content"] == "Roll out the docs update after review."
    )
    assert any(
        commitment["content"] == "Ship docs" for commitment in semantic["commitments"]
    )
    assert any(
        link["goal_id"] == "goal-promoted-1"
        and link["relationship"] == "promoted_action_item"
        for link in semantic["goal_links"]
    )
    assert knowledge is not None
    assert (
        knowledge.payload["metadata"]["meeting"]["semantic"]["goal_links"]
        == semantic["goal_links"]
    )
    store.close()


# ---------------------------------------------------------------------------
# CommandHintPanel
# ---------------------------------------------------------------------------


def _noop(app, args):
    pass


def _make_commands():
    return [
        SlashCommand("/help", _noop, aliases=(), usage="— show commands"),
        SlashCommand("/search", _noop, aliases=("/s",), usage="<query>"),
        SlashCommand("/schedule", _noop, aliases=(), usage=""),
        SlashCommand("/quit", _noop, aliases=("/q", "/exit"), usage=""),
    ]


class TestCommandHintPanel:
    def test_update_suggestions(self):
        panel = CommandHintPanel()
        cmds = _make_commands()
        panel.update_suggestions(cmds)
        assert panel._items == cmds
        assert panel._highlight == -1

    def test_move_highlight_wraps(self):
        panel = CommandHintPanel()
        panel.update_suggestions(_make_commands())
        # From -1, move up wraps to last item (index 3)
        panel.move_highlight(-1)
        assert panel._highlight == 3
        # From last, move down wraps to first (index 0)
        panel.move_highlight(1)
        assert panel._highlight == 0

    def test_highlighted_command(self):
        panel = CommandHintPanel()
        cmds = _make_commands()
        panel.update_suggestions(cmds)
        assert panel.highlighted_command is None
        panel.move_highlight(1)  # -1 + 1 = 0
        assert panel.highlighted_command == cmds[0]

    def test_render_list_format(self):
        panel = CommandHintPanel()
        cmds = _make_commands()[:2]
        panel.update_suggestions(cmds)
        panel.move_highlight(1)  # highlight index 0
        # Verify marker is present — renderable is set via update()
        assert panel._highlight == 0
        assert panel._items[0].name == "/help"


class TestSlashCommandMatch:
    def _make_registry(self):
        registry = SlashCommandRegistry()
        for cmd in _make_commands():
            registry.register(cmd)
        return registry

    def test_match_prefix(self):
        r = self._make_registry()
        matches = r.match("/se")
        names = [m.name for m in matches]
        assert "/search" in names
        # /schedule starts with /sc, not /se
        assert "/schedule" not in names

    def test_match_prefix_broad(self):
        r = self._make_registry()
        matches = r.match("/s")
        names = [m.name for m in matches]
        assert "/search" in names
        assert "/schedule" in names

    def test_match_alias(self):
        r = self._make_registry()
        matches = r.match("/q")
        names = [m.name for m in matches]
        assert "/quit" in names

    def test_match_case_insensitive(self):
        r = self._make_registry()
        matches = r.match("/HELP")
        names = [m.name for m in matches]
        assert "/help" in names

    def test_match_no_results(self):
        r = self._make_registry()
        matches = r.match("/xyz")
        assert matches == []


# ---------------------------------------------------------------------------
# Service mode: notification_store guard tests (CRITICAL-1)
# ---------------------------------------------------------------------------


class TestServiceModeNotificationGuards:
    """In service mode, notification operations must use the protocol (list_notifications,
    act_on_notification) rather than the local notification_store."""

    def _make_service_app(self):
        """App with a mock api that raises NotImplementedError for notification_store."""
        app = MemexApp.__new__(MemexApp)
        app._api = MagicMock()
        app._notifications_cache = {}
        ns_mock = PropertyMock(side_effect=NotImplementedError("service mode"))
        type(app._api).notification_store = ns_mock
        return app, ns_mock

    def test_load_attention_data_calls_list_notifications_in_service_mode(self):
        """In service mode, _load_attention_data must call list_notifications(), not notification_store."""
        app, ns_mock = self._make_service_app()
        app._api.list_notifications.return_value = []
        with patch.object(
            MemexApp, "_has_local_store", new_callable=PropertyMock, return_value=False
        ):
            with patch.object(app, "query_one", return_value=MagicMock()):
                MemexApp._load_attention_data(app)
        ns_mock.assert_not_called()
        app._api.list_notifications.assert_called_once_with(unread_only=True)

    def test_on_notification_action_calls_act_on_notification_in_service_mode(self):
        """In service mode, dismiss must call act_on_notification, not notification_store."""
        app, ns_mock = self._make_service_app()
        app._api.act_on_notification.return_value = None
        app._api.list_notifications.return_value = []
        app._notifications_cache = {
            "n-1": {
                "notification_id": "n-1",
                "title": "T",
                "action_type": None,
                "action_data": {},
            }
        }
        event = MagicMock()
        event.notification_id = "n-1"
        event.action = "dismiss"
        with patch.object(
            MemexApp, "_has_local_store", new_callable=PropertyMock, return_value=False
        ):
            with patch.object(app, "query_one", return_value=MagicMock()):
                MemexApp.on_notification_action(app, event)
        ns_mock.assert_not_called()
        app._api.act_on_notification.assert_called_once_with("n-1", "dismiss")

    def test_approve_url_review_calls_act_on_notification_dismiss_in_service_mode(self):
        """In service mode, _approve_url_review must call act_on_notification('dismiss'), not notification_store."""
        app, ns_mock = self._make_service_app()
        app._session_id = "test-session"
        app.call_from_thread = MagicMock()
        app.query_one = MagicMock(return_value=MagicMock())
        app._api.ingest_url.return_value = {"status": "ok"}
        # @work(thread=True) wraps the function; use __wrapped__ to call the body directly
        unwrapped = MemexApp._approve_url_review.__wrapped__
        with patch.object(
            MemexApp, "_has_local_store", new_callable=PropertyMock, return_value=False
        ):
            unwrapped(app, "notif-id", {"urls": ["http://example.com"]})
        ns_mock.assert_not_called()
        app._api.act_on_notification.assert_called_once_with("notif-id", "dismiss")
