"""Tests for OpenClaw alias table and parameter shims."""

import logging

from memex.models import ToolDefinition
from memex.skills.aliases import (
    INCOMPATIBLE_TOOLS,
    apply_openclaw_aliases,
)
from memex.skills.param_shims import PARAM_TRANSLATORS, translate_exec_params
from memex.tools import ToolRegistry


def _tool(name: str) -> ToolDefinition:
    return ToolDefinition(
        name=name,
        description=f"Test {name}",
        source="test",
        required_capability="builtin.read",
    )


def test_apply_aliases_registers():
    reg = ToolRegistry()
    reg.register(_tool("bash"))
    reg.register(_tool("read_file"))
    apply_openclaw_aliases(reg)
    assert reg.get_tool("exec") is not None
    assert reg.get_tool("exec").name == "bash"
    assert reg.get_tool("read") is not None
    assert reg.get_tool("read").name == "read_file"


def test_apply_aliases_skips_missing():
    reg = ToolRegistry()
    # Only register bash, not read_file
    reg.register(_tool("bash"))
    apply_openclaw_aliases(reg)
    assert reg.get_tool("exec") is not None
    assert reg.get_tool("read") is None  # read_file not registered


def test_apply_aliases_idempotent():
    reg = ToolRegistry()
    reg.register(_tool("bash"))
    apply_openclaw_aliases(reg)
    apply_openclaw_aliases(reg)
    assert reg.get_tool("exec").name == "bash"


def test_incompatible_tools_set():
    expected = {"browser", "canvas", "nodes", "image"}
    assert expected.issubset(INCOMPATIBLE_TOOLS)


def test_translate_exec_basic():
    result = translate_exec_params({"command": "ls -la"})
    assert result["command"] == "ls -la"


def test_translate_exec_workdir():
    result = translate_exec_params({"command": "ls", "workdir": "/tmp"})
    assert result["command"] == "cd /tmp && ls"


def test_translate_exec_workdir_with_spaces():
    result = translate_exec_params({"command": "ls", "workdir": "/tmp/my dir"})
    assert result["command"] == "cd '/tmp/my dir' && ls"


def test_translate_exec_unsupported_warns(caplog):
    with caplog.at_level(logging.WARNING):
        result = translate_exec_params(
            {"command": "ls", "pty": True, "background": True}
        )
    assert result["command"] == "ls"
    assert "pty" in caplog.text
    assert "background" in caplog.text


def test_param_translators_registered():
    assert "exec" in PARAM_TRANSLATORS
    assert "bash" in PARAM_TRANSLATORS
