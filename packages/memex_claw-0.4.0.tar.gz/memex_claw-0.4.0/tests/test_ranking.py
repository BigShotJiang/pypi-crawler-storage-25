"""Tests for ranking functions (Phase 3 Step 6)."""

import pytest

from memex.memory.ranking import (
    merge_dual_search,
    normalize_bm25,
    normalize_cosine,
    rank_score,
    route_profile_world_model_boost,
)
from memex.models import PromptControlRouteProfile, RankConfig


def test_rank_score_basic():
    score = rank_score(relevance=1.0, decay_weight=1.0, reputation=1.0)
    assert score == pytest.approx(1.0)


def test_rank_score_pin_boost():
    normal = rank_score(relevance=0.5, decay_weight=0.5, reputation=0.5)
    pinned = rank_score(relevance=0.5, decay_weight=0.5, reputation=0.5, pinned=True)
    assert pinned == pytest.approx(normal * 2.0)


def test_rank_score_custom_config():
    cfg = RankConfig(
        relevance_exp=2.0, decay_exp=1.0, reputation_exp=1.0, pin_boost=3.0
    )
    score = rank_score(relevance=0.5, decay_weight=0.5, reputation=0.5, config=cfg)
    expected = (0.5**2.0) * (0.5**1.0) * (0.5**1.0)
    assert score == pytest.approx(expected)


def test_normalize_bm25():
    assert normalize_bm25(5.0, max_bm25=10.0) == pytest.approx(0.5)
    assert normalize_bm25(10.0, max_bm25=10.0) == pytest.approx(1.0)
    assert normalize_bm25(0.0, max_bm25=10.0) == pytest.approx(0.0)
    assert normalize_bm25(5.0, max_bm25=0.0) == pytest.approx(0.0)


def test_normalize_cosine():
    assert normalize_cosine(0.5) == pytest.approx(0.5)
    assert normalize_cosine(1.5) == pytest.approx(1.0)
    assert normalize_cosine(-0.5) == pytest.approx(0.0)


def test_merge_dual_search_fts_only():
    fts = [("a", 10.0), ("b", 5.0)]
    result = merge_dual_search(fts, [], fts_weight=0.5, sem_weight=0.5)
    assert result[0][0] == "a"
    assert result[0][1] == pytest.approx(0.5)  # 1.0 * 0.5


def test_merge_dual_search_sem_only():
    sem = [("a", 0.9), ("b", 0.3)]
    result = merge_dual_search([], sem, fts_weight=0.5, sem_weight=0.5)
    assert result[0][0] == "a"
    assert result[0][1] == pytest.approx(0.45)  # 0.9 * 0.5


def test_merge_dual_search_overlap():
    fts = [("a", 10.0), ("b", 5.0)]
    sem = [("a", 0.8), ("c", 0.6)]
    result = merge_dual_search(fts, sem)

    result_dict = dict(result)
    # "a" in both: (1.0 * 0.5) + (0.8 * 0.5) = 0.9
    assert result_dict["a"] == pytest.approx(0.9)
    # "b" only in fts: (0.5 * 0.5) = 0.25
    assert result_dict["b"] == pytest.approx(0.25)
    # "c" only in sem: (0.6 * 0.5) = 0.3
    assert result_dict["c"] == pytest.approx(0.3)

    # Sorted by score
    assert result[0][0] == "a"


def test_merge_dual_search_empty():
    result = merge_dual_search([], [])
    assert result == []


def test_route_profile_world_model_boost_prefers_reference_for_research_verified():
    reference_boost = route_profile_world_model_boost(
        knowledge_type="reference",
        route_profile=PromptControlRouteProfile.RESEARCH_VERIFIED,
        has_source_url=True,
    )
    note_boost = route_profile_world_model_boost(
        knowledge_type="note",
        route_profile=PromptControlRouteProfile.RESEARCH_VERIFIED,
        has_source_url=False,
    )

    assert reference_boost > note_boost


def test_route_profile_world_model_boost_prefers_claim_for_operational_tool():
    claim_boost = route_profile_world_model_boost(
        knowledge_type="claim",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=False,
    )
    reference_boost = route_profile_world_model_boost(
        knowledge_type="reference",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=True,
    )

    assert claim_boost > reference_boost


def test_route_profile_world_model_boost_prefers_procedure_for_operational_tool():
    procedure_boost = route_profile_world_model_boost(
        knowledge_type="procedure",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=False,
    )
    note_boost = route_profile_world_model_boost(
        knowledge_type="note",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=False,
    )

    assert procedure_boost > note_boost


def test_route_profile_world_model_boost_prefers_semantic_procedure_for_operational_tool():
    procedure_boost = route_profile_world_model_boost(
        knowledge_type="note",
        semantic_kind="procedure",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=False,
    )
    note_boost = route_profile_world_model_boost(
        knowledge_type="note",
        semantic_kind="",
        route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
        has_source_url=False,
    )

    assert procedure_boost > note_boost
