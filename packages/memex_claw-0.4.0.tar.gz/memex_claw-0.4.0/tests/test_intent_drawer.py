"""Tests for IntentDrawer urgency signals."""

from __future__ import annotations

from datetime import timedelta

from memex.interfaces.tui.widgets.intent_drawer import _urgency_suffix
from memex.utcnow import utcnow


def test_urgency_suffix_overdue():
    g = {"deadline": "2020-01-01T00:00:00", "status": "active"}
    assert "OVERDUE" in _urgency_suffix(g)


def test_urgency_suffix_due_today():
    g = {"deadline": (utcnow() + timedelta(hours=2)).isoformat(), "status": "active"}
    assert "DUE TODAY" in _urgency_suffix(g)


def test_urgency_suffix_due_in_2_days():
    g = {
        "deadline": (utcnow() + timedelta(days=2, hours=1)).isoformat(),
        "status": "active",
    }
    suffix = _urgency_suffix(g)
    assert "2d" in suffix


def test_urgency_suffix_blocked_ignores_deadline():
    g = {"deadline": "2020-01-01T00:00:00", "status": "blocked"}
    suffix = _urgency_suffix(g)
    assert "(blocked)" in suffix
    assert "OVERDUE" not in suffix


def test_urgency_suffix_failed():
    g = {"status": "failed", "deadline": "2020-01-01T00:00:00"}
    assert "(failed)" in _urgency_suffix(g)


def test_urgency_suffix_no_deadline():
    assert _urgency_suffix({"status": "active"}) == ""


def test_urgency_suffix_invalid_deadline():
    g = {"deadline": "not-a-date", "status": "active"}
    assert _urgency_suffix(g) == ""
