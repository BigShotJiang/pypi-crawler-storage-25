"""Tests for the chunking module."""

from __future__ import annotations

from memex.memory.chunking import chunk_text, chunk_by_speaker_turns


def test_short_text_single_chunk():
    text = "This is a short note."
    chunks = chunk_text(text)
    assert len(chunks) == 1
    assert chunks[0]["text"] == text
    assert chunks[0]["position"] == 0


def test_empty_text():
    assert chunk_text("") == []
    assert chunk_text("   ") == []


def test_paragraph_split():
    paragraphs = [
        "Paragraph one. " * 50,
        "Paragraph two. " * 50,
        "Paragraph three. " * 50,
    ]
    text = "\n\n".join(paragraphs)
    chunks = chunk_text(text, max_tokens=200)
    assert len(chunks) > 1
    for i, chunk in enumerate(chunks):
        assert chunk["position"] == i


def test_chunk_positions_sequential():
    text = "\n\n".join([f"Paragraph {i}. " * 30 for i in range(10)])
    chunks = chunk_text(text, max_tokens=100)
    positions = [c["position"] for c in chunks]
    assert positions == sorted(positions)
    assert positions == list(range(len(positions)))


def test_token_count_present():
    text = "Hello world. " * 100
    chunks = chunk_text(text, max_tokens=50)
    for chunk in chunks:
        assert "token_count" in chunk
        assert chunk["token_count"] > 0


def test_speaker_turn_split():
    text = """Host: Welcome to the show.
Speaker A: Thanks for having me.
Host: Let's talk about Python.
Speaker A: Python is great for data science."""
    chunks = chunk_by_speaker_turns(text)
    assert len(chunks) >= 2
    assert chunks[0]["position"] == 0
