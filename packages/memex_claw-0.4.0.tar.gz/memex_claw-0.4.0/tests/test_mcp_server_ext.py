"""Tests for the external MCP server (Memex as server)."""

from __future__ import annotations


from memex.interfaces.rate_limiting import CallerRateLimits, CircuitBreaker


class TestScopeGating:
    """Test that scope controls which tools are available."""

    def test_read_only_scope(self):
        from memex.interfaces.mcp_server import _READ_ONLY_TOOLS

        assert "memex_status" in _READ_ONLY_TOOLS
        assert "memex_self_state" in _READ_ONLY_TOOLS
        assert "memex_goal_list" in _READ_ONLY_TOOLS
        assert "memex_chat" not in _READ_ONLY_TOOLS
        assert "memex_goal_update" not in _READ_ONLY_TOOLS

    def test_collaborative_scope(self):
        from memex.interfaces.mcp_server import _COLLABORATIVE_TOOLS

        assert "memex_chat" in _COLLABORATIVE_TOOLS
        assert "memex_goal_create" in _COLLABORATIVE_TOOLS
        assert "memex_goal_update" not in _COLLABORATIVE_TOOLS

    def test_full_scope(self):
        from memex.interfaces.mcp_server import _FULL_TOOLS

        assert "memex_goal_update" in _FULL_TOOLS
        assert "memex_ingest" in _FULL_TOOLS


class TestCircuitBreakerIntegration:
    def test_blocks_when_open(self):
        cb = CircuitBreaker(failure_threshold=1)
        cb.record_failure()
        assert cb.is_open is True

    def test_allows_after_success(self):
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure()
        cb.record_success()
        assert cb.is_open is False


class TestRateLimiterIntegration:
    def test_blocks_after_exhaustion(self):
        rl = CallerRateLimits(max_tokens=1, refill_rate=0.0)
        assert rl.allow() is True
        assert rl.allow() is False
