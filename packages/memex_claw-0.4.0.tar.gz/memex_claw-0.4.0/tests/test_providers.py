"""Tests for provider system and credential storage."""

from __future__ import annotations


from memex.providers_base import (
    CredentialStore,
    ProviderCredential,
    SetupPrompter,
)
from memex.providers.anthropic import AnthropicProvider
from memex.providers.openai import OpenAIProvider
from memex.providers.ollama import OllamaProvider


class MockPrompter(SetupPrompter):
    """Deterministic prompter for testing."""

    def __init__(
        self, responses: list[str] | None = None, confirms: list[bool] | None = None
    ):
        self._responses = list(responses or [])
        self._confirms = list(confirms or [])
        self._response_idx = 0
        self._confirm_idx = 0
        self.messages: list[str] = []

    def text(self, message: str, *, default: str = "", secret: bool = False) -> str:
        self.messages.append(message)
        if self._response_idx < len(self._responses):
            val = self._responses[self._response_idx]
            self._response_idx += 1
            return val
        return default

    def select(self, message: str, choices: list[str]) -> str:
        self.messages.append(message)
        if self._response_idx < len(self._responses):
            val = self._responses[self._response_idx]
            self._response_idx += 1
            return val
        return choices[0]

    def confirm(self, message: str, *, default: bool = True) -> bool:
        self.messages.append(message)
        if self._confirm_idx < len(self._confirms):
            val = self._confirms[self._confirm_idx]
            self._confirm_idx += 1
            return val
        return default

    def info(self, message: str) -> None:
        self.messages.append(message)


class TestCredentialStore:
    def test_save_and_load(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        creds = [
            ProviderCredential(key="api_key", value="sk-test", env_var="API_KEY"),
        ]
        store.save("test-provider", creds)

        loaded = store.load("test-provider")
        assert len(loaded) == 1
        assert loaded[0].key == "api_key"
        assert loaded[0].value == "sk-test"
        assert loaded[0].env_var == "API_KEY"

    def test_load_nonexistent(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        assert store.load("missing") == []

    def test_list_providers(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        store.save("a", [ProviderCredential("k", "v", "A_KEY")])
        store.save("b", [ProviderCredential("k", "v", "B_KEY")])
        assert sorted(store.list_providers()) == ["a", "b"]

    def test_delete(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        store.save("target", [ProviderCredential("k", "v", "KEY")])
        assert store.delete("target") is True
        assert store.load("target") == []
        assert store.delete("missing") is False

    def test_to_env_vars(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        store.save("p1", [ProviderCredential("k", "val1", "ENV_A")])
        store.save("p2", [ProviderCredential("k", "val2", "ENV_B")])
        env = store.to_env_vars()
        assert env == {"ENV_A": "val1", "ENV_B": "val2"}

    def test_overwrite_existing(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        store.save("p", [ProviderCredential("k", "old", "KEY")])
        store.save("p", [ProviderCredential("k", "new", "KEY")])
        loaded = store.load("p")
        assert loaded[0].value == "new"

    def test_file_permissions(self, tmp_path):
        store = CredentialStore(tmp_path / "creds.json")
        store.save("p", [ProviderCredential("k", "v", "KEY")])
        mode = store.path.stat().st_mode & 0o777
        assert mode == 0o600


class TestAnthropicProvider:
    def test_setup_success(self):
        prompter = MockPrompter(responses=["sk-ant-test-key"])
        provider = AnthropicProvider()
        result = provider.setup(prompter)

        assert result.success
        assert len(result.credentials) == 1
        assert result.credentials[0].env_var == "ANTHROPIC_API_KEY"
        assert result.credentials[0].value == "sk-ant-test-key"

    def test_setup_empty_key(self):
        prompter = MockPrompter(responses=[""])
        provider = AnthropicProvider()
        result = provider.setup(prompter)
        assert not result.success

    def test_validate(self):
        provider = AnthropicProvider()
        good = [ProviderCredential("api_key", "sk-ant-abc123", "ANTHROPIC_API_KEY")]
        bad = [ProviderCredential("api_key", "bad-key", "ANTHROPIC_API_KEY")]
        assert provider.validate(good) is True
        assert provider.validate(bad) is False

    def test_properties(self):
        p = AnthropicProvider()
        assert p.id == "anthropic"
        assert p.name == "Anthropic (Claude)"
        assert p.env_vars == ["ANTHROPIC_API_KEY"]


class TestOpenAIProvider:
    def test_setup_success(self):
        prompter = MockPrompter(responses=["sk-test-key"])
        provider = OpenAIProvider()
        result = provider.setup(prompter)

        assert result.success
        assert result.credentials[0].env_var == "OPENAI_API_KEY"

    def test_properties(self):
        p = OpenAIProvider()
        assert p.id == "openai"
        assert p.env_vars == ["OPENAI_API_KEY"]


class TestOllamaProvider:
    def test_properties(self):
        p = OllamaProvider()
        assert p.id == "ollama"
        assert p.env_vars == ["OLLAMA_BASE_URL"]

    def test_setup_with_default_url(self):
        # Use default URL, connection will fail, user cancels
        prompter = MockPrompter(responses=[""], confirms=[False])
        provider = OllamaProvider()
        result = provider.setup(prompter)
        assert not result.success

    def test_setup_save_anyway(self):
        # Connection fails but user says save anyway
        prompter = MockPrompter(responses=["http://custom:1234"], confirms=[True])
        provider = OllamaProvider()
        result = provider.setup(prompter)
        assert result.success
        assert result.credentials[0].value == "http://custom:1234"


class TestProviderDiscovery:
    def test_all_providers_importable(self):
        from memex.providers import ALL_PROVIDERS

        assert len(ALL_PROVIDERS) == 3
        ids = {cls().id for cls in ALL_PROVIDERS}
        assert ids == {"anthropic", "openai", "ollama"}
