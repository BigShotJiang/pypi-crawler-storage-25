"""Tests for MemexServiceClient.

Uses unittest.mock to patch httpx.Client so no running service is required.
Verifies that each protocol method makes the right HTTP call and correctly
maps the response to its return value.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from memex.interfaces.service_client import MemexServiceClient


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_client() -> tuple[MemexServiceClient, MagicMock]:
    """Create a MemexServiceClient with a fully mocked internal httpx client."""
    client = MemexServiceClient.__new__(MemexServiceClient)
    client._session_id = "test-session-id"
    mock_http = MagicMock()
    client._client = mock_http
    client._base_url = "http://127.0.0.1:8321"
    return client, mock_http


def _mock_response(data: dict | list, status_code: int = 200) -> MagicMock:
    """Build a mock httpx Response that returns *data* as JSON."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.raise_for_status = MagicMock()
    return resp


# ---------------------------------------------------------------------------
# Basic REST methods
# ---------------------------------------------------------------------------


def test_status():
    client, http = _make_client()
    payload = {"version": "1.0", "uptime_seconds": 42, "telegram_connected": False}
    http.get.return_value = _mock_response(payload)

    result = client.status(caller=None)

    http.get.assert_called_once_with("/v1/status")
    assert result["uptime_seconds"] == 42


def test_self_state():
    client, http = _make_client()
    payload = {"summary": "all good", "active_goals": []}
    http.get.return_value = _mock_response(payload)

    result = client.self_state(caller=None)

    http.get.assert_called_once_with("/v1/self-state")
    assert result["summary"] == "all good"


def test_intent():
    client, http = _make_client()
    goals = [{"goal_id": "g1", "title": "Write tests"}]
    http.get.return_value = _mock_response({"goals": goals})

    result = client.intent(caller=None)

    http.get.assert_called_once_with("/v1/goals", params={})
    assert len(result) == 1
    assert result[0]["goal_id"] == "g1"


def test_search():
    client, http = _make_client()
    results = [{"id": "r1", "title": "Result"}]
    http.post.return_value = _mock_response({"results": results})

    result = client.search("test query", caller=None)

    http.post.assert_called_once_with("/v1/search", json={"query": "test query"})
    assert len(result) == 1


def test_ingest_url():
    client, http = _make_client()
    http.post.return_value = _mock_response({"id": "item-1", "status": "done"})

    result = client.ingest_url("https://example.com")

    http.post.assert_called_once_with("/v1/ingest", json={"url": "https://example.com"})
    assert result["id"] == "item-1"


def test_ingest_content():
    client, http = _make_client()
    http.post.return_value = _mock_response({"id": "item-2", "status": "done"})

    result = client.ingest_content("some raw text", title="My Note")

    http.post.assert_called_once_with(
        "/v1/ingest", json={"text": "some raw text", "title": "My Note"}
    )
    assert result["status"] == "done"


# ---------------------------------------------------------------------------
# Meetings
# ---------------------------------------------------------------------------


def test_list_meetings():
    client, http = _make_client()
    meetings = [{"meeting_id": "m1", "title": "Stand-up"}]
    http.get.return_value = _mock_response({"meetings": meetings})

    result = client.list_meetings()

    http.get.assert_called_once_with("/v1/meetings")
    assert result[0]["meeting_id"] == "m1"


def test_get_meeting_found():
    client, http = _make_client()
    meeting = {"meeting_id": "m1", "title": "Stand-up"}
    http.get.return_value = _mock_response(meeting)

    result = client.get_meeting("m1")

    http.get.assert_called_once_with("/v1/meetings/m1")
    assert result["title"] == "Stand-up"


def test_get_meeting_not_found():
    client, http = _make_client()
    resp = _mock_response({}, status_code=404)
    http.get.return_value = resp

    result = client.get_meeting("nonexistent")

    assert result is None


def test_create_meeting():
    client, http = _make_client()
    created = {"meeting_id": "m2", "title": "Sprint"}
    http.post.return_value = _mock_response(created, status_code=201)

    # Simulate passing a dict-like object
    record = {"meeting_id": "m2", "title": "Sprint", "state": "created"}
    client.create_meeting(record)

    http.post.assert_called_once()
    call_kwargs = http.post.call_args
    assert call_kwargs[0][0] == "/v1/meetings"


def test_delete_meeting():
    client, http = _make_client()
    resp = _mock_response({}, status_code=204)
    http.delete.return_value = resp

    client.delete_meeting("m1")

    http.delete.assert_called_once_with("/v1/meetings/m1")


def test_cleanup_stale_recordings():
    client, http = _make_client()
    http.post.return_value = _mock_response({"cleaned": 3})

    result = client.cleanup_stale_recordings()

    http.post.assert_called_once_with("/v1/meetings/cleanup")
    assert result == 3


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


def test_list_tasks():
    client, http = _make_client()
    tasks = [{"id": "t1", "name": "backup"}]
    http.get.return_value = _mock_response({"tasks": tasks})

    result = client.list_tasks()

    http.get.assert_called_once_with("/v1/scheduler/tasks")
    assert result[0]["name"] == "backup"


def test_get_task():
    client, http = _make_client()
    task = {"id": "t1", "name": "backup"}
    http.get.return_value = _mock_response(task)

    result = client.get_task("t1")

    http.get.assert_called_once_with("/v1/scheduler/tasks/t1")
    assert result["name"] == "backup"


def test_toggle_task():
    client, http = _make_client()
    http.post.return_value = _mock_response({"status": "ok"})

    client.toggle_task("t1", enabled=False)

    http.post.assert_called_once_with(
        "/v1/scheduler/tasks/t1/toggle", json={"enabled": False}
    )


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------


def test_list_notifications():
    client, http = _make_client()
    notifs = [{"id": "n1", "title": "Reminder"}]
    http.get.return_value = _mock_response({"notifications": notifs})

    result = client.list_notifications()

    http.get.assert_called_once_with("/v1/notifications", params={})
    assert result[0]["id"] == "n1"


def test_list_notifications_include_read():
    client, http = _make_client()
    http.get.return_value = _mock_response({"notifications": []})

    client.list_notifications(unread_only=False)

    call_kwargs = http.get.call_args
    assert call_kwargs[1]["params"] == {"unread_only": "false"}


def test_act_on_notification():
    client, http = _make_client()
    http.post.return_value = _mock_response({"status": "ok"})

    client.act_on_notification("n1", "dismiss")

    http.post.assert_called_once_with(
        "/v1/notifications/n1/action", json={"action": "dismiss"}
    )


# ---------------------------------------------------------------------------
# Chat SSE parsing
# ---------------------------------------------------------------------------


def test_chat_sse_parsing():
    """Verify that chat() correctly parses SSE lines and calls callbacks."""
    client, http = _make_client()

    # Build a fake SSE stream
    sse_lines = [
        "event: token",
        'data: {"text": "Hello"}',
        "",
        "event: token",
        'data: {"text": " world"}',
        "",
        "event: done",
        'data: {"message_id": "msg-1", "session_id": "test-session-id"}',
        "",
    ]

    # Mock the streaming context manager
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.iter_lines.return_value = iter(sse_lines)
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_response

    tokens: list[str] = []
    events: list[tuple] = []

    response_text, _ = client.chat(
        "hi",
        caller=None,
        on_token=lambda t: tokens.append(t),
        on_event=lambda event: events.append(event),
    )

    assert tokens == ["Hello", " world"]
    assert response_text == "Hello world"
    assert not events  # "done" is consumed internally, not forwarded


def test_chat_sse_non_token_event():
    """SSE turn_phase events are deserialized into TurnPhase objects for on_event."""
    from memex.models import TurnPhase

    client, http = _make_client()

    sse_lines = [
        "event: turn_phase",
        'data: {"phase": "reflecting", "model": ""}',
        "",
        "event: done",
        'data: {"message_id": "x"}',
        "",
    ]

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.iter_lines.return_value = iter(sse_lines)
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_response

    events: list = []
    client.chat("hi", caller=None, on_event=lambda event: events.append(event))

    assert len(events) == 1
    assert isinstance(events[0], TurnPhase)
    assert events[0].phase == "reflecting"


# ---------------------------------------------------------------------------
# Storage properties raise NotImplementedError
# ---------------------------------------------------------------------------


def test_storage_properties_raise():
    client, _ = _make_client()

    with pytest.raises(NotImplementedError):
        _ = client.content_store

    with pytest.raises(NotImplementedError):
        _ = client.embedding_backend

    with pytest.raises(NotImplementedError):
        _ = client.db_path

    with pytest.raises(NotImplementedError):
        _ = client.settings

    with pytest.raises(NotImplementedError):
        _ = client.notification_store


# ---------------------------------------------------------------------------
# Runtime helpers
# ---------------------------------------------------------------------------


def test_runtime_registry_is_none():
    client, _ = _make_client()
    assert client.runtime_registry is None


def test_set_scheduler_engine_is_noop():
    client, _ = _make_client()
    client.set_scheduler_engine(object())  # should not raise


def test_end_session_returns_none():
    client, http = _make_client()
    http.delete.return_value = _mock_response({}, status_code=204)
    result = client.end_session(caller=None)
    assert result is None


def test_close():
    client, http = _make_client()
    client.close()
    http.close.assert_called_once()


# ---------------------------------------------------------------------------
# Goals
# ---------------------------------------------------------------------------


def test_create_goal():
    client, http = _make_client()
    http.post.return_value = _mock_response({}, status_code=201)

    goal = {"goal_id": "g1", "title": "My goal"}
    client.create_goal(goal)

    http.post.assert_called_once()
    assert http.post.call_args[0][0] == "/v1/goals"


def test_get_goal():
    client, http = _make_client()
    http.get.return_value = _mock_response({"goal_id": "g1", "title": "g"})

    result = client.get_goal("g1")

    http.get.assert_called_once_with("/v1/goals/g1")
    assert result["goal_id"] == "g1"


def test_get_goal_not_found():
    client, http = _make_client()
    http.get.return_value = _mock_response({}, status_code=404)

    result = client.get_goal("missing")

    assert result is None


def test_update_goal():
    client, http = _make_client()
    http.put.return_value = _mock_response({"goal_id": "g1", "title": "Updated"})

    goal = {"goal_id": "g1", "title": "Updated"}
    client.update_goal(goal)

    http.put.assert_called_once()
    assert http.put.call_args[0][0] == "/v1/goals/g1"


def test_intent_include_all_passes_query_param():
    client, http = _make_client()
    http.get.return_value = _mock_response({"goals": []})

    client.intent(caller=None, include_all=True)

    call_args = http.get.call_args
    assert call_args[1].get("params") == {"include_all": "true"}


def test_intent_default_omits_include_all_param():
    client, http = _make_client()
    http.get.return_value = _mock_response({"goals": []})

    client.intent(caller=None)

    call_args = http.get.call_args
    assert call_args[1].get("params") == {}


def test_get_last_task_run():
    client, http = _make_client()
    http.get.return_value = _mock_response(
        {"status": "completed", "finished_at": "2025-01-01T12:00:00"}
    )

    result = client.get_last_task_run("t1")

    http.get.assert_called_once_with("/v1/scheduler/tasks/t1/last-run")
    assert result["status"] == "completed"


def test_update_meeting():
    client, http = _make_client()
    http.put.return_value = _mock_response({"meeting_id": "m1"})

    meeting = {"meeting_id": "m1", "title": "Updated"}
    client.update_meeting(meeting)

    http.put.assert_called_once()
    assert http.put.call_args[0][0] == "/v1/meetings/m1"


def test_update_recording():
    client, http = _make_client()
    http.put.return_value = _mock_response({"recording_id": "r1"})

    recording = {"recording_id": "r1", "state": "recorded"}
    client.update_recording(recording)

    http.put.assert_called_once()
    assert http.put.call_args[0][0] == "/v1/recordings/r1"


def test_get_recording_found():
    client, http = _make_client()
    http.get.return_value = _mock_response({"recording_id": "r1", "state": "recorded"})

    result = client.get_recording("r1")

    http.get.assert_called_once_with("/v1/recordings/r1")
    assert result["recording_id"] == "r1"


def test_get_recording_not_found():
    client, http = _make_client()
    http.get.return_value = _mock_response({}, status_code=404)

    result = client.get_recording("missing")

    assert result is None


# ---------------------------------------------------------------------------
# create_meeting_goal_link
# ---------------------------------------------------------------------------


def test_create_meeting_goal_link():
    client, http = _make_client()
    http.post.return_value = _mock_response({}, status_code=201)
    link = {"meeting_id": "m1", "goal_id": "g1", "relationship": "explicit"}
    client.create_meeting_goal_link(link)
    http.post.assert_called_once()
    assert http.post.call_args[0][0] == "/v1/meeting-goal-links"


# ---------------------------------------------------------------------------
# stream_events
# ---------------------------------------------------------------------------


def test_stream_events_yields_typed_events():
    client, http = _make_client()
    sse_lines = [
        "event: GoalCreated",
        'data: {"goal_id": "g1"}',
        "",
        "event: MeetingUpdated",
        'data: {"meeting_id": "m1"}',
        "",
    ]
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_resp.iter_lines.return_value = iter(sse_lines)
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_resp

    results = list(client.stream_events())

    assert results == [
        ("GoalCreated", {"goal_id": "g1"}),
        ("MeetingUpdated", {"meeting_id": "m1"}),
    ]
    assert http.stream.call_args[0] == ("GET", "/v1/events")


def test_stream_events_with_last_event_id():
    client, http = _make_client()
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_resp.iter_lines.return_value = iter([])
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_resp

    list(client.stream_events(last_event_id=42))

    assert http.stream.call_args[1]["headers"]["Last-Event-ID"] == "42"


def test_stream_events_no_last_event_id_omits_header():
    client, http = _make_client()
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_resp.iter_lines.return_value = iter([])
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_resp

    list(client.stream_events())

    headers = http.stream.call_args[1].get("headers", {})
    assert "Last-Event-ID" not in headers


def test_stream_events_resets_event_type_on_blank_line():
    client, http = _make_client()
    sse_lines = [
        "event: Named",
        'data: {"a": 1}',
        "",
        'data: {"b": 2}',
        "",
    ]
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_resp.iter_lines.return_value = iter(sse_lines)
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)
    http.stream.return_value = mock_resp

    results = list(client.stream_events())

    assert results[0] == ("Named", {"a": 1})
    assert results[1] == ("heartbeat", {"b": 2})


# ---------------------------------------------------------------------------
# Subagents
# ---------------------------------------------------------------------------


def test_list_subagents():
    client, http = _make_client()
    payload = {
        "subagents": [{"agent_id": "qq-1", "label": "test", "status": "running"}]
    }
    http.get.return_value = _mock_response(payload)

    result = client.list_subagents()

    http.get.assert_called_once_with("/v1/subagents")
    assert len(result) == 1
    assert result[0]["agent_id"] == "qq-1"


def test_list_subagents_empty():
    client, http = _make_client()
    http.get.return_value = _mock_response({"subagents": []})

    result = client.list_subagents()

    assert result == []


# ---------------------------------------------------------------------------
# Chat cancellation
# ---------------------------------------------------------------------------


def test_cancel_chat():
    client, http = _make_client()
    http.delete.return_value = _mock_response({}, status_code=204)

    client.cancel_chat("sess-123")

    http.delete.assert_called_once_with("/v1/chat/sess-123")


# ---------------------------------------------------------------------------
# Session cleanup
# ---------------------------------------------------------------------------


def test_end_session():
    client, http = _make_client()
    http.delete.return_value = _mock_response({}, status_code=204)

    caller = MagicMock()
    caller.session_id = "test-session-id"
    result = client.end_session(caller)

    http.delete.assert_called_once_with("/v1/sessions/test-session-id")
    assert result is None


def test_end_session_uses_client_session_id_as_fallback():
    client, http = _make_client()
    http.delete.return_value = _mock_response({}, status_code=204)

    # caller without session_id attribute
    result = client.end_session(caller=None)

    http.delete.assert_called_once_with("/v1/sessions/test-session-id")
    assert result is None
