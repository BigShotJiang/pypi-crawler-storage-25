"""Tests for fact consolidation and quick dedup."""

from __future__ import annotations

import struct
from unittest.mock import MagicMock, patch


from memex.memory.consolidation import (
    consolidate_facts,
    quick_dedup,
)
from memex.memory.consolidation_middleware import FactConsolidationMiddleware
from memex.memory.fact_store import FACT_TAGS
from memex.models import Item, ItemType, SessionContext, Summary
from memex.utcnow import utcnow


def _floats_to_bytes(floats: list[float]) -> bytes:
    return struct.pack(f"{len(floats)}f", *floats)


def _make_fact(
    item_id: str,
    body: str,
    embedding: list[float],
    provenance: list[dict] | None = None,
    confidence: float = 0.8,
) -> tuple[Item, bytes]:
    """Create a fact item and its embedding bytes."""
    item = Item(
        item_id=item_id,
        type=ItemType.NOTE,
        title=body[:100],
        body=body,
        source_url=f"fact://{item_id}",
        tags=list(FACT_TAGS),
        captured_at=utcnow(),
        last_accessed=utcnow(),
        summary=Summary(text=body[:200]),
        metadata={
            "provenance": provenance or [{"session_id": "s1", "turn": 1}],
            "confidence": confidence,
        },
    )
    emb_bytes = _floats_to_bytes(embedding)
    return item, emb_bytes


class MockContentStore:
    """Minimal content store mock for consolidation tests."""

    def __init__(self):
        self._items: dict[str, Item] = {}
        self._embeddings: dict[str, tuple[bytes, str]] = {}

    def create_item(self, item: Item) -> None:
        self._items[item.item_id] = item

    def update_item(self, item: Item) -> None:
        self._items[item.item_id] = item

    def list_items(
        self, *, type=None, pinned=None, include_expired=False, limit=50, now=None
    ) -> list[Item]:
        items = [i for i in self._items.values() if i.deleted_at is None]
        if type is not None:
            items = [i for i in items if i.type == type]
        return items[:limit]

    def save_embedding(self, item_id, vector, model, dimensions) -> None:
        self._embeddings[item_id] = (vector, model)

    def get_embedding(self, item_id) -> tuple[bytes, str] | None:
        return self._embeddings.get(item_id)

    def soft_delete_item(self, item_id: str) -> bool:
        if item_id in self._items:
            self._items[item_id].deleted_at = utcnow()
            return True
        return False

    def find_by_url(self, url: str) -> Item | None:
        for item in self._items.values():
            if item.source_url == url and item.deleted_at is None:
                return item
        return None


class MockEmbedding:
    def embed(self, text: str) -> list[float]:
        return [1.0, 0.0, 0.0]

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]

    @property
    def dimensions(self) -> int:
        return 3

    @property
    def model_name(self) -> str:
        return "test-model"


class TestQuickDedup:
    def test_merges_near_duplicates(self):
        """Facts with > 0.90 cosine similarity are merged."""
        store = MockContentStore()
        emb = MockEmbedding()

        # Two facts with identical embeddings
        fact1, emb1 = _make_fact(
            "f1",
            "I work at Acme",
            [1.0, 0.0, 0.0],
            provenance=[{"session_id": "s1", "turn": 1}],
        )
        fact2, emb2 = _make_fact(
            "f2",
            "I work at Acme Corp",
            [1.0, 0.0, 0.0],
            provenance=[{"session_id": "s2", "turn": 3}],
        )

        store.create_item(fact1)
        store.create_item(fact2)
        store.save_embedding("f1", emb1, "test", 3)
        store.save_embedding("f2", emb2, "test", 3)

        merged = quick_dedup(store, emb)

        assert merged == 1
        # f1 kept, f2 soft-deleted
        active = [i for i in store._items.values() if i.deleted_at is None]
        assert len(active) == 1
        assert active[0].item_id == "f1"
        # f1 has combined provenance
        assert len(active[0].metadata["provenance"]) == 2

    def test_does_not_merge_dissimilar(self):
        """Facts with low similarity are not merged."""
        store = MockContentStore()
        emb = MockEmbedding()

        fact1, emb1 = _make_fact("f1", "I work at Acme", [1.0, 0.0, 0.0])
        fact2, emb2 = _make_fact("f2", "My cat is named Felix", [0.0, 1.0, 0.0])

        store.create_item(fact1)
        store.create_item(fact2)
        store.save_embedding("f1", emb1, "test", 3)
        store.save_embedding("f2", emb2, "test", 3)

        merged = quick_dedup(store, emb)

        assert merged == 0
        active = [i for i in store._items.values() if i.deleted_at is None]
        assert len(active) == 2

    def test_empty_store(self):
        """Quick dedup on empty store returns 0."""
        store = MockContentStore()
        emb = MockEmbedding()
        assert quick_dedup(store, emb) == 0

    def test_single_fact(self):
        """Quick dedup with single fact returns 0."""
        store = MockContentStore()
        emb = MockEmbedding()

        fact1, emb1 = _make_fact("f1", "single fact", [1.0, 0.0, 0.0])
        store.create_item(fact1)
        store.save_embedding("f1", emb1, "test", 3)

        assert quick_dedup(store, emb) == 0

    def test_provenance_preserved_across_merge(self):
        """Provenance from merged fact is added to survivor (hard constraint)."""
        store = MockContentStore()
        emb = MockEmbedding()

        prov1 = [{"session_id": "s1", "turn": 1}]
        prov2 = [{"session_id": "s2", "turn": 2}, {"session_id": "s3", "turn": 3}]

        fact1, emb1 = _make_fact("f1", "fact A", [1.0, 0.0, 0.0], provenance=prov1)
        fact2, emb2 = _make_fact(
            "f2", "fact A again", [1.0, 0.0, 0.0], provenance=prov2
        )

        store.create_item(fact1)
        store.create_item(fact2)
        store.save_embedding("f1", emb1, "test", 3)
        store.save_embedding("f2", emb2, "test", 3)

        quick_dedup(store, emb)

        active = [i for i in store._items.values() if i.deleted_at is None]
        assert len(active) == 1
        # All 3 provenance entries preserved
        assert len(active[0].metadata["provenance"]) == 3


class TestConsolidateFacts:
    @patch("memex.memory.consolidation._llm_merge_facts")
    def test_merges_cluster(self, mock_merge):
        """Consolidation merges a cluster of similar facts."""
        mock_merge.return_value = "I work at Acme Corporation"

        store = MockContentStore()
        emb = MockEmbedding()

        # Three similar facts
        for i, body in enumerate(
            ["I work at Acme", "I work at Acme Corp", "Working at Acme"]
        ):
            fact, emb_bytes = _make_fact(
                f"f{i}",
                body,
                [1.0, 0.0, 0.0],
                provenance=[{"session_id": f"s{i}", "turn": i}],
            )
            store.create_item(fact)
            store.save_embedding(f"f{i}", emb_bytes, "test", 3)

        merged = consolidate_facts(store, emb)

        assert merged == 3
        mock_merge.assert_called_once()
        # Originals soft-deleted, one merged fact created
        active = [i for i in store._items.values() if i.deleted_at is None]
        assert len(active) == 1
        assert active[0].body == "I work at Acme Corporation"
        # All 3 provenance entries preserved
        assert len(active[0].metadata["provenance"]) == 3

    @patch("memex.memory.consolidation._llm_merge_facts")
    def test_llm_failure_falls_back_to_first_fact(self, mock_merge):
        """When LLM merge fails, first fact text is used as fallback."""
        mock_merge.return_value = None  # Simulate failure return

        store = MockContentStore()
        emb = MockEmbedding()

        for i, body in enumerate(["I work at Acme", "I work at Acme Corp"]):
            fact, emb_bytes = _make_fact(
                f"f{i}",
                body,
                [1.0, 0.0, 0.0],
                provenance=[{"session_id": f"s{i}", "turn": i}],
            )
            store.create_item(fact)
            store.save_embedding(f"f{i}", emb_bytes, "test", 3)

        merged = consolidate_facts(store, emb)

        # LLM returned None → cluster skipped, no merge
        assert merged == 0

    @patch("memex.memory.consolidation._llm_merge_facts")
    def test_consolidation_skips_facts_without_embeddings(self, mock_merge):
        """Facts without embeddings are excluded from consolidation."""
        mock_merge.return_value = "merged fact"

        store = MockContentStore()
        emb = MockEmbedding()

        # Two similar facts WITH embeddings
        fact1, emb1 = _make_fact("f1", "I work at Acme", [1.0, 0.0, 0.0])
        fact2, emb2 = _make_fact("f2", "I work at Acme Corp", [1.0, 0.0, 0.0])
        # One fact WITHOUT embedding
        fact3, _ = _make_fact("f3", "My favorite color is blue", [0.0, 1.0, 0.0])

        store.create_item(fact1)
        store.create_item(fact2)
        store.create_item(fact3)
        store.save_embedding("f1", emb1, "test", 3)
        store.save_embedding("f2", emb2, "test", 3)
        # Deliberately don't save embedding for fact3

        merged = consolidate_facts(store, emb)

        # f1 and f2 merged, f3 untouched
        active = [i for i in store._items.values() if i.deleted_at is None]
        active_ids = {i.item_id for i in active}
        assert "f3" in active_ids
        assert merged == 2

    @patch("memex.memory.consolidation._llm_merge_facts")
    def test_multiple_clusters_consolidated_separately(self, mock_merge):
        """Multiple clusters are each merged independently."""
        mock_merge.side_effect = [
            "I work at Acme Corporation",
            "My favorite color is blue",
        ]

        store = MockContentStore()
        emb = MockEmbedding()

        # Cluster 1: Acme facts (identical embeddings)
        for i, body in enumerate(["I work at Acme", "I work at Acme Corp"]):
            fact, emb_bytes = _make_fact(f"a{i}", body, [1.0, 0.0, 0.0])
            store.create_item(fact)
            store.save_embedding(f"a{i}", emb_bytes, "test", 3)

        # Cluster 2: Color facts (identical embeddings, orthogonal to cluster 1)
        for i, body in enumerate(["My favorite color is blue", "I like blue"]):
            fact, emb_bytes = _make_fact(f"c{i}", body, [0.0, 1.0, 0.0])
            store.create_item(fact)
            store.save_embedding(f"c{i}", emb_bytes, "test", 3)

        merged = consolidate_facts(store, emb)

        assert merged == 4  # All 4 facts merged into 2 clusters
        active = [i for i in store._items.values() if i.deleted_at is None]
        assert len(active) == 2
        assert mock_merge.call_count == 2

    def test_no_merge_for_dissimilar(self):
        """Dissimilar facts are not merged."""
        store = MockContentStore()
        emb = MockEmbedding()

        fact1, emb1 = _make_fact("f1", "I work at Acme", [1.0, 0.0, 0.0])
        fact2, emb2 = _make_fact("f2", "My cat is Felix", [0.0, 1.0, 0.0])

        store.create_item(fact1)
        store.create_item(fact2)
        store.save_embedding("f1", emb1, "test", 3)
        store.save_embedding("f2", emb2, "test", 3)

        merged = consolidate_facts(store, emb)
        assert merged == 0


class TestFactConsolidationMiddleware:
    def test_after_session_calls_quick_dedup(self):
        """Middleware after_session hook calls quick_dedup."""
        content_store = MockContentStore()
        emb = MockEmbedding()
        mw = FactConsolidationMiddleware(content_store, emb)

        session = SessionContext(session_id="test", started_at=utcnow())
        store = MagicMock()

        with patch(
            "memex.memory.consolidation.quick_dedup", return_value=0
        ) as mock_dedup:
            mw.after_session(session, store)
            mock_dedup.assert_called_once_with(content_store, emb)

    def test_after_session_exception_isolation(self):
        """Middleware never raises (middleware contract)."""
        content_store = MockContentStore()
        emb = MockEmbedding()
        mw = FactConsolidationMiddleware(content_store, emb)

        session = SessionContext(session_id="test", started_at=utcnow())
        store = MagicMock()

        with patch(
            "memex.memory.consolidation.quick_dedup", side_effect=RuntimeError("boom")
        ):
            # Should not raise
            mw.after_session(session, store)


class TestSchedulerBuiltins:
    def test_memory_consolidation_task_registered(self):
        """Memory consolidation task is in the builtin tasks list."""
        from memex.scheduler.builtins import get_builtin_tasks

        tasks = get_builtin_tasks()
        names = [t.name for t in tasks]
        assert "Memory Consolidation" in names

        task = next(t for t in tasks if t.name == "Memory Consolidation")
        assert task.cron_expr == "30 3 * * *"
        assert task.action_data["callable"] == "memory_consolidation"
        assert task.enabled is True
