"""Tests for new meeting features: speaker mapping, action items, and human model integration."""

import uuid
from unittest.mock import patch


from memex.human_model import format_for_prompt
from memex.meetings.models import MeetingRecord, MeetingSegment, MeetingState
from memex.meetings.transcribe import (
    TranscriptionResult,
    _extract_action_items,
    _format_body,
    orchestrate_transcription,
)
from memex.models import HumanPartnerProfile
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_segments() -> list[MeetingSegment]:
    return [
        MeetingSegment(speaker="SPEAKER_00", start=0.0, end=5.0, text="Hello there."),
        MeetingSegment(
            speaker="SPEAKER_01", start=5.0, end=10.0, text="Hi, how are you?"
        ),
        MeetingSegment(speaker="SPEAKER_00", start=10.0, end=15.0, text="Doing well."),
    ]


def _canned_result(segments: list[MeetingSegment] | None = None) -> TranscriptionResult:
    segs = segments or _make_segments()
    speakers = {s.speaker for s in segs}
    return TranscriptionResult(
        segments=segs,
        speaker_count=len(speakers),
        language="en",
        model="large-v3",
        duration_seconds=120.0,
    )


def _make_meeting_record(
    meeting_id: str = "mtg-feat-1",
    audio_path: str = "/tmp/test.wav",
    title: str = "Feature Test Meeting",
    state: MeetingState = MeetingState.RECORDED,
) -> MeetingRecord:
    now = utcnow()
    return MeetingRecord(
        meeting_id=meeting_id,
        state=state,
        title=title,
        audio_path=audio_path,
        started_at=now,
        stopped_at=now,
        created_at=now,
        updated_at=now,
    )


# ---------------------------------------------------------------------------
# _format_body with speaker mappings
# ---------------------------------------------------------------------------


def test_format_body_with_speaker_mappings():
    """Speaker mappings replace speaker IDs with human-readable names."""
    segments = _make_segments()
    mappings = {"SPEAKER_00": "Alice", "SPEAKER_01": "Bob"}
    body = _format_body(segments, speaker_mappings=mappings)

    lines = body.split("\n")
    assert len(lines) == 3
    assert lines[0].startswith("[Alice]")
    assert lines[1].startswith("[Bob]")
    assert lines[2].startswith("[Alice]")
    # Ensure raw IDs are gone
    assert "SPEAKER_00" not in body
    assert "SPEAKER_01" not in body


def test_format_body_partial_mappings():
    """Only mapped speakers get replaced; unmapped ones keep their IDs."""
    segments = _make_segments()
    mappings = {"SPEAKER_00": "Alice"}
    body = _format_body(segments, speaker_mappings=mappings)

    lines = body.split("\n")
    assert lines[0].startswith("[Alice]")
    assert lines[1].startswith("[SPEAKER_01]")
    assert lines[2].startswith("[Alice]")


def test_format_body_no_mappings():
    """Without mappings, speaker IDs remain unchanged."""
    segments = _make_segments()
    body = _format_body(segments)

    lines = body.split("\n")
    assert lines[0].startswith("[SPEAKER_00]")
    assert lines[1].startswith("[SPEAKER_01]")
    assert lines[2].startswith("[SPEAKER_00]")


# ---------------------------------------------------------------------------
# HumanPartnerProfile speaker mappings
# ---------------------------------------------------------------------------


def test_partner_profile_speaker_mappings_field():
    """speaker_mappings round-trips through canonical partner profile serialization."""
    mappings = {"SPEAKER_00": "Alice", "SPEAKER_01": "Bob"}
    model = HumanPartnerProfile(
        name="Test User",
        working_context={"speaker_mappings": mappings},
    )

    assert model.working_context.speaker_mappings == mappings

    dumped = model.model_dump()
    assert dumped["working_context"]["speaker_mappings"] == mappings

    restored = HumanPartnerProfile.model_validate(dumped)
    assert restored.working_context.speaker_mappings == mappings


# ---------------------------------------------------------------------------
# format_for_prompt with speaker_mappings
# ---------------------------------------------------------------------------


def test_format_for_prompt_includes_speakers():
    """When speaker_mappings is set, output includes 'Known speakers' section."""
    model = HumanPartnerProfile(
        name="Test",
        working_context={
            "speaker_mappings": {"SPEAKER_00": "Alice", "SPEAKER_01": "Bob"}
        },
    )
    prompt = format_for_prompt(model)

    assert "Known speakers" in prompt
    assert "SPEAKER_00: Alice" in prompt
    assert "SPEAKER_01: Bob" in prompt


def test_format_for_prompt_no_speakers():
    """When speaker_mappings is empty, output does NOT contain 'Known speakers'."""
    model = HumanPartnerProfile(name="Test", working_context={"speaker_mappings": {}})
    prompt = format_for_prompt(model)

    assert "Known speakers" not in prompt


# ---------------------------------------------------------------------------
# _extract_action_items
# ---------------------------------------------------------------------------


def test_extract_action_items_parses_json():
    """LLM returns a clean JSON array — parsed correctly."""
    fake_response = (
        '[{"assignee": "Alice", "action": "Send report", "deadline": "Friday"}]'
    )

    with patch("memex.llm.chat", return_value=fake_response):
        items = _extract_action_items("some transcript body")

    assert len(items) == 1
    assert items[0]["assignee"] == "Alice"
    assert items[0]["action"] == "Send report"
    assert items[0]["deadline"] == "Friday"


def test_extract_action_items_empty():
    """LLM returns '[]' — returns empty list."""
    with patch("memex.llm.chat", return_value="[]"):
        items = _extract_action_items("some transcript body")

    assert items == []


def test_extract_action_items_malformed():
    """LLM returns garbage — gracefully returns empty list."""
    with patch("memex.llm.chat", return_value="I don't know, sorry!"):
        items = _extract_action_items("some transcript body")

    assert items == []


def test_extract_action_items_embedded_json():
    """LLM returns text with embedded JSON array — still extracts it."""
    fake_response = (
        "Here are the action items:\n"
        '[{"assignee": "Bob", "action": "Fix the bug", "deadline": "none"}]\n'
        "Let me know if you need anything else."
    )

    with patch("memex.llm.chat", return_value=fake_response):
        items = _extract_action_items("some transcript body")

    assert len(items) == 1
    assert items[0]["assignee"] == "Bob"
    assert items[0]["action"] == "Fix the bug"


# ---------------------------------------------------------------------------
# orchestrate_transcription with new parameters
# ---------------------------------------------------------------------------


def test_orchestrate_with_speaker_mappings(tmp_path):
    """Speaker mappings are applied to the ingested item body."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    rec_id = str(uuid.uuid4())
    ms.create_recording(rec_id, record.meeting_id, state="recorded")
    ms._repo.update_recording(rec_id, audio_path=record.audio_path)

    canned = _canned_result()
    mappings = {"SPEAKER_00": "Alice", "SPEAKER_01": "Bob"}

    with patch("memex.meetings.transcribe.transcribe_meeting", return_value=canned):
        item = orchestrate_transcription(
            "mtg-feat-1",
            meeting_store=ms,
            content_store=cs,
            speaker_mappings=mappings,
        )

    assert item is not None
    # The body should contain mapped names, not raw speaker IDs
    assert "Alice" in item.body
    assert "Bob" in item.body
    assert "SPEAKER_00" not in item.body
    assert "SPEAKER_01" not in item.body

    # speaker_mappings should be stored in metadata
    assert item.metadata["meeting"]["speaker_mappings"] == mappings

    store.close()


def test_orchestrate_with_action_items(tmp_path):
    """extract_action_items=True populates metadata.meeting.action_items."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    cs = store.content

    record = _make_meeting_record()
    ms.create_meeting(record)
    rec_id = str(uuid.uuid4())
    ms.create_recording(rec_id, record.meeting_id, state="recorded")
    ms._repo.update_recording(rec_id, audio_path=record.audio_path)

    canned = _canned_result()
    fake_actions = [
        {"assignee": "Alice", "action": "Write docs", "deadline": "Monday"},
    ]

    with patch("memex.meetings.transcribe.transcribe_meeting", return_value=canned):
        with patch(
            "memex.meetings.transcribe._extract_action_items",
            return_value=fake_actions,
        ):
            item = orchestrate_transcription(
                "mtg-feat-1",
                meeting_store=ms,
                content_store=cs,
                extract_action_items=True,
            )

    assert item is not None
    assert "action_items" in item.metadata["meeting"]
    assert item.metadata["meeting"]["action_items"] == fake_actions

    store.close()
