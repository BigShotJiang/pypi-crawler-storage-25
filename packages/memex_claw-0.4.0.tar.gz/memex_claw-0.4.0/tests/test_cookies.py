"""Tests for CookieProvider cookie loading and export."""

from __future__ import annotations

import textwrap
import time
from http.cookiejar import MozillaCookieJar
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from memex.connectors.cookies import CookieProvider, get_cookie_provider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

NETSCAPE_COOKIES = textwrap.dedent("""\
    # Netscape HTTP Cookie File
    .example.com\tTRUE\t/\tFALSE\t0\tsession_id\tabc123
    .example.com\tTRUE\t/\tFALSE\t0\tauth_token\txyz789
""")


@pytest.fixture()
def cookies_txt(tmp_path: Path) -> Path:
    """Write a valid Netscape cookies.txt and return its path."""
    p = tmp_path / "cookies.txt"
    p.write_text(NETSCAPE_COOKIES)
    return p


@pytest.fixture()
def provider(cookies_txt: Path) -> CookieProvider:
    """CookieProvider pointed at the fixture cookies.txt."""
    return CookieProvider(cookies_path=cookies_txt, ttl=60)


# ---------------------------------------------------------------------------
# _load_from_file
# ---------------------------------------------------------------------------


class TestLoadFromFile:
    def test_loads_valid_cookies(self, provider: CookieProvider):
        jar = provider._load_from_file()
        assert jar is not None
        assert isinstance(jar, MozillaCookieJar)
        names = {c.name for c in jar}
        assert "session_id" in names
        assert "auth_token" in names

    def test_returns_none_for_missing_file(self, tmp_path: Path):
        p = CookieProvider(cookies_path=tmp_path / "nope.txt")
        assert p._load_from_file() is None

    def test_returns_none_for_malformed_file(self, tmp_path: Path):
        bad = tmp_path / "bad.txt"
        bad.write_text("not a cookie file at all\x00\x01\x02")
        p = CookieProvider(cookies_path=bad)
        assert p._load_from_file() is None


# ---------------------------------------------------------------------------
# get_jar — caching
# ---------------------------------------------------------------------------


class TestGetJar:
    def test_returns_jar_from_file(self, provider: CookieProvider):
        jar = provider.get_jar()
        assert jar is not None
        assert len(jar) == 2

    def test_caches_within_ttl(self, provider: CookieProvider):
        jar1 = provider.get_jar()
        jar2 = provider.get_jar()
        assert jar1 is jar2

    def test_returns_none_when_no_source(self, tmp_path: Path):
        p = CookieProvider(cookies_path=tmp_path / "nope.txt")
        assert p.get_jar() is None

    def test_none_result_cached_within_ttl(self, tmp_path: Path):
        """When no cookies available, don't retry browser export on every call."""
        p = CookieProvider(cookies_path=tmp_path / "nope.txt", ttl=60)
        with patch.object(p, "_export_from_browser") as mock_export:
            mock_export.return_value = False
            p.get_jar()
            p.get_jar()
            p.get_jar()
            assert mock_export.call_count == 1

    def test_stale_file_triggers_browser_export(
        self, cookies_txt: Path, tmp_path: Path
    ):
        """When cookies.txt exists but is older than TTL, re-export from browser."""
        import os

        # Make the file look old (mtime 2 hours ago)
        old_time = time.time() - 7200
        os.utime(cookies_txt, (old_time, old_time))
        p = CookieProvider(cookies_path=cookies_txt, ttl=60)
        with patch.object(p, "_export_from_browser") as mock_export:
            mock_export.return_value = False
            p.get_jar()
            assert mock_export.call_count == 1

    def test_fresh_file_skips_browser_export(self, provider: CookieProvider):
        """When cookies.txt is fresh, don't try browser export."""
        with patch.object(provider, "_export_from_browser") as mock_export:
            provider.get_jar()
            assert mock_export.call_count == 0

    def test_refresh_clears_cache(self, provider: CookieProvider):
        jar1 = provider.get_jar()
        assert jar1 is not None
        provider.refresh()
        jar2 = provider.get_jar()
        # New jar instance after refresh
        assert jar2 is not jar1


# ---------------------------------------------------------------------------
# _export_from_browser
# ---------------------------------------------------------------------------


class TestExportFromBrowser:
    def test_export_skips_when_browser_db_missing(self, tmp_path: Path):
        provider = CookieProvider(
            cookies_path=tmp_path / "exported.txt", browser="chromium"
        )

        with patch.object(provider, "_browser_db_exists", return_value=False):
            assert provider._export_from_browser() is False

    def test_export_saves_cookies(self, tmp_path: Path):
        cookies_path = tmp_path / "exported.txt"
        provider = CookieProvider(cookies_path=cookies_path, browser="chromium")

        # Create a real MozillaCookieJar for the mock
        mock_jar = MozillaCookieJar(str(cookies_path))
        mock_ydl = MagicMock()
        mock_ydl.cookiejar = mock_jar

        mock_ytdlp = MagicMock()
        mock_ytdlp.YoutubeDL.return_value.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ytdlp.YoutubeDL.return_value.__exit__ = MagicMock(return_value=False)

        with (
            patch.object(provider, "_browser_db_exists", return_value=True),
            patch.dict("sys.modules", {"yt_dlp": mock_ytdlp}),
        ):
            result = provider._export_from_browser()
        assert result is True
        assert cookies_path.exists()
        assert (cookies_path.stat().st_mode & 0o777) == 0o600

    def test_export_handles_exception(self, tmp_path: Path):
        mock_ytdlp = MagicMock()
        mock_ytdlp.YoutubeDL.side_effect = Exception("Chromium locked")

        with patch.dict("sys.modules", {"yt_dlp": mock_ytdlp}):
            provider = CookieProvider(cookies_path=tmp_path / "out.txt")
            assert provider._export_from_browser() is False


# ---------------------------------------------------------------------------
# get_yt_dlp_opts
# ---------------------------------------------------------------------------


class TestGetYtDlpOpts:
    def test_returns_cookiesfrombrowser_when_db_exists(self, cookies_txt: Path):
        p = CookieProvider(cookies_path=cookies_txt, browser="chromium", ttl=60)
        with patch.object(p, "_browser_db_exists", return_value=True):
            opts = p.get_yt_dlp_opts()
        assert opts == {"cookiesfrombrowser": ("chromium",)}

    def test_returns_cookiefile_when_file_exists(
        self, provider: CookieProvider, cookies_txt: Path
    ):
        with patch.object(provider, "_browser_db_exists", return_value=False):
            opts = provider.get_yt_dlp_opts()
        assert opts == {"cookiefile": str(cookies_txt)}

    def test_returns_empty_when_no_source(self, tmp_path: Path):
        p = CookieProvider(cookies_path=tmp_path / "nope.txt")
        with patch.object(p, "_browser_db_exists", return_value=False):
            opts = p.get_yt_dlp_opts()
        assert opts == {}


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------


class TestSingleton:
    def test_get_cookie_provider_returns_same_instance(self, monkeypatch):
        import memex.connectors.cookies as mod

        monkeypatch.setattr(mod, "_provider", None)
        p1 = get_cookie_provider()
        p2 = get_cookie_provider()
        assert p1 is p2
        monkeypatch.setattr(mod, "_provider", None)
