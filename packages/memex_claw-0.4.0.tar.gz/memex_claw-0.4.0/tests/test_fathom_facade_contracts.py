"""End-to-end contract tests for FathomMemexStore adapter boundaries.

Each test creates a model object the way real callers do, passes it through
the facade adapter, then reads it back. This catches signature mismatches,
type mismatches, and missing adapter overrides between the Python caller
layer and the fathomdb Rust engine.

Tests in test_fathom_facade.py already cover world-model upsert/load methods
with correct model construction. This file focuses on:
  1. Adapter boundaries (content, notification, settings, scheduler, meeting)
  2. Dict-vs-model return type contracts
  3. Model-object API contracts that callers actually use
  4. Scheduler builtin seeding and engine lifecycle
"""

from __future__ import annotations


import pytest

from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.meetings.models import MeetingRecord, MeetingRecording, MeetingState
from memex.models import (
    ActionType,
    AuditEntry,
    ConnectorHealth,
    ConversationTurn,
    Goal,
    GoalEntityLink,
    GoalPriority,
    GoalStatus,
    Item,
    ItemType,
    MeetingEntityLink,
    MeetingGoalLink,
    Notification,
    NotificationPriority,
    ScheduledTask,
)
from memex.utcnow import utcnow


@pytest.fixture
def fstore(tmp_path):
    db_path = str(tmp_path / "contract_test.db")
    store = FathomStore.open(db_path)
    yield store
    store.close()


@pytest.fixture
def facade(fstore):
    return FathomMemexStore(fstore)


NOW = utcnow()


# ── Content adapter ───────────────────────────────────────────────────


class TestContentAdapter:
    """FathomContentAdapter: ingest, get, search, list_items."""

    @staticmethod
    def _make_item(item_id="item1", **kw):
        defaults = dict(
            item_id=item_id,
            title="Test Article",
            body="Some body text",
            type=ItemType.NOTE,
            source_url="https://example.com",
            author="alice",
            tags=["test"],
            metadata={},
            captured_at=NOW,
            last_accessed=NOW,
        )
        defaults.update(kw)
        return Item(**defaults)

    def test_ingest_and_get(self, facade):
        facade.content.ingest(self._make_item())
        loaded = facade.content.get("item1")
        assert loaded is not None
        assert loaded.title == "Test Article"

    def test_search(self, facade):
        facade.content.ingest(
            self._make_item("item2", title="Searchable", body="xyzzy")
        )
        results = facade.content.search("xyzzy")
        assert any(r.item_id == "item2" for r in results)

    def test_list_items(self, facade):
        for i in range(3):
            facade.content.ingest(self._make_item(f"li{i}", title=f"Item {i}"))
        items = facade.content.list_items(limit=10)
        assert len(items) >= 3


# ── Notification adapter ──────────────────────────────────────────────


class TestNotificationAdapter:
    """FathomNotificationAdapter: create, list_pending, mark_read, dismiss, get."""

    @staticmethod
    def _make_notif(nid="n1", **kw):
        defaults = dict(
            notification_id=nid,
            title="Heads up",
            body="Something happened",
            priority=NotificationPriority.NORMAL,
            source="test",
            created_at=NOW,
        )
        defaults.update(kw)
        return Notification(**defaults)

    def test_create_and_list(self, facade):
        facade.notifications.create(self._make_notif())
        pending = facade.notifications.list_pending()
        assert any(p.notification_id == "n1" for p in pending)

    def test_mark_read(self, facade):
        facade.notifications.create(self._make_notif("n2"))
        facade.notifications.mark_read("n2")
        pending = facade.notifications.list_pending()
        assert not any(p.notification_id == "n2" for p in pending)

    def test_dismiss(self, facade):
        facade.notifications.create(self._make_notif("n3"))
        facade.notifications.dismiss("n3")
        pending = facade.notifications.list_pending()
        assert not any(p.notification_id == "n3" for p in pending)

    def test_get(self, facade):
        facade.notifications.create(
            self._make_notif("n4", title="Get me", priority=NotificationPriority.HIGH)
        )
        loaded = facade.notifications.get("n4")
        assert loaded is not None
        assert loaded.title == "Get me"


# ── Settings adapter ─────────────────────────────────────────────────


class TestSettingsAdapter:
    """FathomSettingsAdapter: set, get_str, get_int, get_float."""

    def test_set_and_get_str(self, facade):
        facade.settings.set("test_key", "hello")
        assert facade.settings.get_str("test_key") == "hello"

    def test_set_and_get_int(self, facade):
        facade.settings.set("count", "42")
        assert facade.settings.get_int("count") == 42

    def test_set_and_get_float(self, facade):
        facade.settings.set("threshold", "0.85")
        assert facade.settings.get_float("threshold") == pytest.approx(0.85)


# ── Conversation log ──────────────────────────────────────────────────


class TestConversationLog:
    """log_turn(ConversationTurn) and query_conversation_log round-trip."""

    def test_log_and_query(self, facade):
        turn = ConversationTurn(role="human", content="hello", timestamp=NOW)
        facade.log_turn("sess-1", turn)
        rows = facade.query_conversation_log(session_id="sess-1")
        assert len(rows) >= 1
        # Returns dicts, not model objects
        assert isinstance(rows[0], dict)
        assert rows[0].get("content") == "hello"

    def test_query_with_role_filter(self, facade):
        facade.log_turn(
            "sess-2", ConversationTurn(role="human", content="hi", timestamp=NOW)
        )
        facade.log_turn(
            "sess-2", ConversationTurn(role="assistant", content="hey", timestamp=NOW)
        )
        human_only = facade.query_conversation_log(session_id="sess-2", role="human")
        assert all(r.get("role") == "human" for r in human_only)


# ── Audit log ─────────────────────────────────────────────────────────


class TestAuditLog:
    def test_log_and_query(self, facade):
        entry = AuditEntry(
            timestamp=NOW,
            connector="gmail",
            action="search",
            granted=True,
            session_id="sess-1",
            result_summary="found 3",
            duration_ms=150,
        )
        facade.log_audit(entry)
        entries = facade.query_audit(connector="gmail")
        assert len(entries) >= 1
        assert isinstance(entries[0], AuditEntry)
        assert entries[0].action == "search"


# ── Connector health ──────────────────────────────────────────────────


class TestConnectorHealth:
    def test_save_and_load(self, facade):
        health = ConnectorHealth(
            name="gmail",
            status="connected",
            last_check=NOW,
            tools_discovered=5,
        )
        facade.save_connector_health(health)
        loaded = facade.load_connector_health()
        assert isinstance(loaded, list)
        assert any(h.name == "gmail" for h in loaded)
        assert isinstance(loaded[0], ConnectorHealth)


# ── Tool usage ────────────────────────────────────────────────────────


class TestToolUsage:
    def test_record_and_get(self, facade):
        facade.record_tool_usage("search_knowledge", ["weather"])
        stats = facade.get_tool_usage_stats("search_knowledge")
        assert len(stats) >= 1


# ── Meeting adapter: model-object API ─────────────────────────────────


class TestMeetingAdapterContract:
    """FathomMeetingAdapter must accept model objects like SQLite MeetingStore."""

    @staticmethod
    def _make_record(**kw):
        now = utcnow()
        defaults = dict(
            meeting_id="m1",
            state=MeetingState.CREATED,
            title="Standup",
            created_at=now,
            updated_at=now,
        )
        defaults.update(kw)
        return MeetingRecord(**defaults)

    @staticmethod
    def _make_recording(meeting_id="m1", **kw):
        defaults = dict(
            recording_id=f"{meeting_id}-r1",
            meeting_id=meeting_id,
            sequence_number=1,
            state=MeetingState.CREATED,
        )
        defaults.update(kw)
        return MeetingRecording(**defaults)

    def test_create_meeting_from_record(self, facade):
        facade.meetings.create_meeting(self._make_record())
        m = facade.meetings.get_meeting("m1")
        assert m is not None
        assert m.title == "Standup"

    def test_create_meeting_enum_state(self, facade):
        facade.meetings.create_meeting(self._make_record(state=MeetingState.RECORDING))
        m = facade.meetings.get_meeting("m1")
        assert m is not None

    def test_create_meeting_attendees(self, facade):
        facade.meetings.create_meeting(self._make_record(attendees=["alice", "bob"]))
        m = facade.meetings.get_meeting("m1")
        assert m.attendees == ["alice", "bob"]

    def test_update_meeting_from_record(self, facade):
        record = self._make_record()
        facade.meetings.create_meeting(record)
        record.title = "Updated"
        record.notes = "Notes here"
        facade.meetings.update_meeting(record)
        m = facade.meetings.get_meeting("m1")
        assert m.title == "Updated"
        assert m.notes == "Notes here"

    def test_update_recording_from_object(self, facade, fstore):
        fstore.meetings.create_meeting("m1", "Test")
        rec = self._make_recording()
        fstore.meetings.create_recording(
            rec.recording_id, rec.meeting_id, sequence_number=1
        )
        rec.state = MeetingState.RECORDING
        rec.audio_path = "/tmp/test.wav"
        facade.meetings.update_recording(rec)
        loaded = facade.meetings.get_recording(rec.recording_id)
        assert loaded is not None
        assert loaded.audio_path == "/tmp/test.wav"

    def test_delete_meeting(self, facade):
        facade.meetings.create_meeting(self._make_record())
        facade.meetings.delete_meeting("m1")
        assert facade.meetings.get_meeting("m1") is None

    def test_list_meetings(self, facade):
        facade.meetings.create_meeting(self._make_record(meeting_id="m1"))
        facade.meetings.create_meeting(
            self._make_record(meeting_id="m2", title="Other")
        )
        meetings = facade.meetings.list_meetings()
        assert len(meetings) >= 2


# ── Scheduler adapter: engine-compatible API ──────────────────────────


class TestSchedulerAdapterContract:
    """FathomSchedulerAdapter must accept the same API as SQLite SchedulerStore."""

    def test_create_task_from_model(self, facade, fstore):
        now = utcnow()
        task = ScheduledTask(
            task_id="t1",
            name="Test Task",
            description="A test",
            cron_expr="0 8 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={"msg": "hi"},
            goal_id="g99",
            created_at=now,
            updated_at=now,
        )
        facade.scheduler.create_task(task)
        loaded = fstore.scheduler.get_task("t1")
        assert loaded is not None
        assert loaded.name == "Test Task"

    def test_record_run_with_engine_kwargs(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        now = utcnow()
        run_id = facade.scheduler.record_run(
            "t1",
            status="queued",
            queued_at=now,
            action_type="notification",
            action_data={"key": "val"},
            priority=3,
        )
        assert run_id is not None

    def test_record_run_minimal(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = facade.scheduler.record_run("t1")
        assert run_id is not None

    def test_get_last_run_returns_task_run(self, facade, fstore):
        from memex.models import TaskRun

        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        last = facade.scheduler.get_last_run("t1")
        assert last is not None
        assert isinstance(last, TaskRun)
        assert last.status == "queued"

    def test_get_runs_returns_task_runs(self, facade, fstore):
        from memex.models import TaskRun

        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        runs = facade.scheduler.get_runs("t1")
        assert len(runs) >= 1
        assert isinstance(runs[0], TaskRun)
        assert hasattr(runs[0], "started_at")

    def test_list_tasks_returns_models(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        tasks = facade.scheduler.list_tasks(enabled_only=True)
        assert len(tasks) >= 1
        assert hasattr(tasks[0], "task_id")
        assert hasattr(tasks[0], "cron_expr")

    def test_toggle_task(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        facade.scheduler.toggle_task("t1", False)
        task = facade.scheduler.get_task("t1")
        assert task.enabled is False

    def test_get_task(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        task = facade.scheduler.get_task("t1")
        assert task is not None
        assert task.task_id == "t1"

    def test_seed_all_builtins(self, facade):
        from memex.scheduler.builtins import get_builtin_tasks

        tasks = get_builtin_tasks()
        assert len(tasks) >= 13
        facade.scheduler.seed_builtins(tasks)
        loaded = facade.scheduler.list_tasks()
        seeded_ids = {t.task_id for t in loaded}
        for task in tasks:
            assert task.task_id in seeded_ids

    def test_seed_idempotent(self, facade):
        from memex.scheduler.builtins import get_builtin_tasks

        tasks = get_builtin_tasks()
        facade.scheduler.seed_builtins(tasks)
        facade.scheduler.seed_builtins(tasks)

    def test_cleanup_stale_runs(self, facade, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        count = facade.scheduler.cleanup_stale_runs()
        assert count == 0  # no stale runs

    def test_enqueue_complete_round_trip(self, facade, fstore):
        """Full lifecycle: create task → record run → complete run → get_last_run."""
        fstore.scheduler.create_task("t1", "Test", "* * * * *", "notification")
        run_id = facade.scheduler.record_run(
            "t1",
            status="queued",
            queued_at=utcnow(),
            action_type="notification",
            action_data={},
            priority=5,
        )
        fstore.scheduler.complete_run(run_id, status="completed", result="ok")
        last = facade.scheduler.get_last_run("t1")
        assert last is not None
        assert last.status == "completed"


# ── Goal adapter: model-object API ────────────────────────────────────


class TestGoalAdapterContract:
    """Facade must accept Goal model objects for create/update."""

    @staticmethod
    def _make_goal(**kw):
        now = utcnow()
        defaults = dict(
            goal_id="g1",
            title="Ship v1",
            description="",
            status=GoalStatus.ACTIVE,
            priority=GoalPriority.MEDIUM,
            parent_id=None,
            blocked_by_goal_id=None,
            blocked_reason=None,
            failure_reason=None,
            deadline=None,
            metadata={},
            created_at=now,
            updated_at=now,
            last_touched_at=now,
        )
        defaults.update(kw)
        return Goal(**defaults)

    def test_create_goal_from_model(self, facade):
        facade.create_goal(self._make_goal())
        loaded = facade.get_goal("g1")
        assert loaded is not None
        assert loaded.title == "Ship v1"

    def test_update_goal_from_model(self, facade):
        goal = self._make_goal()
        facade.create_goal(goal)
        goal.title = "Ship v2"
        goal.status = GoalStatus.COMPLETED
        facade.update_goal(goal)
        loaded = facade.get_goal("g1")
        assert loaded.title == "Ship v2"

    def test_list_goals_with_status(self, facade):
        facade.create_goal(self._make_goal(goal_id="g1"))
        facade.create_goal(self._make_goal(goal_id="g2", status=GoalStatus.COMPLETED))
        active = facade.list_goals(status=GoalStatus.ACTIVE)
        assert all(g.status == GoalStatus.ACTIVE for g in active)


# ── Goal/meeting/entity links ─────────────────────────────────────────


class TestLinkContracts:
    """GoalEntityLink, MeetingGoalLink, MeetingEntityLink model-object round-trips."""

    def test_goal_entity_link(self, facade, fstore):
        fstore.goals.create("g1", "Goal", "", "active", "medium")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        link = GoalEntityLink(
            goal_id="g1", entity_id="e1", relationship="owner", created_at=NOW
        )
        facade.create_goal_entity_link(link)
        links = facade.list_goal_entity_links("g1")
        assert len(links) >= 1

    def test_meeting_goal_link(self, facade, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.goals.create("g1", "Ship v1", "", "active", "medium")
        link = MeetingGoalLink(
            meeting_id="m1", goal_id="g1", relationship="explicit", created_at=NOW
        )
        facade.create_meeting_goal_link(link)
        links = facade.list_meeting_goal_links("m1")
        assert len(links) >= 1

    def test_meeting_entity_link(self, facade, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        link = MeetingEntityLink(
            meeting_id="m1", entity_id="e1", relationship="attendee", created_at=NOW
        )
        facade.create_meeting_entity_link(link)
        links = facade.list_meeting_entity_links("m1")
        assert len(links) >= 1
