from __future__ import annotations

from unittest.mock import patch

from memex.meetings.models import MeetingRecord, MeetingState
from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    MeetingGoalLink,
    WorldModelCommitment,
    WorldModelTask,
)
from memex.remember import RememberClassification, RememberIntent
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.tools_builtin import _STORES, configure_stores, execute_builtin
from memex.utcnow import utcnow


def test_builtin_remember_returns_canonical_goal_id_for_reminder_goal(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    configure_stores(
        content_store=store.content,
        memex_store=store,
        scheduler_store=store.scheduler,
    )
    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )

    try:
        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_builtin(
                "remember", {"text": "remind me to call mom Tuesday at 3pm"}
            )

        assert result.success
        assert "Goal ID: world_model_goal:" in result.content
    finally:
        _STORES.clear()


def test_get_item_renders_world_model_goal_document(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    blocker = Goal(
        goal_id="goal-tools-parent",
        title="Final review",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(blocker)
    goal = Goal(
        goal_id="goal-tools-1",
        parent_id="goal-tools-parent",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.BLOCKED,
        priority=GoalPriority.HIGH,
        blocked_by_goal_id="goal-tools-parent",
        blocked_reason="Waiting on final review",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={"origin": "manual"},
    )
    store.create_goal(goal)
    store.upsert_world_model_task(
        WorldModelTask(
            task_id="task-tools-1",
            scheduled_task_id=None,
            goal_id="goal-tools-1",
            task_kind="scheduled_reminder",
            title="Prepare release summary",
            description="Prepare release summary",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_commitment(
        WorldModelCommitment(
            commitment_id="commitment-tools-1",
            source_record_type="meeting_artifact",
            source_record_id="artifact-tools-1",
            meeting_id="meeting-tools-1",
            semantic_item_id=None,
            goal_id="goal-tools-1",
            title="Ship docs update",
            description="Committed in meeting",
            assignee="Corey",
            agreed_by="Corey",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    configure_stores(content_store=store.content, memex_store=store)

    try:
        result = execute_builtin("get_item", {"id": "world_model_goal:goal-tools-1"})

        assert result.success
        assert "Ship docs update" in result.content
        assert "Type: goal | ID: world_model_goal:goal-tools-1" in result.content
        assert "Status: blocked" in result.content
        assert "Priority: high" in result.content
        assert "Blocked reason: Waiting on final review" in result.content
        assert "child_of -> world_model_goal:goal-tools-parent" in result.content
        assert "blocked_by -> world_model_goal:goal-tools-parent" in result.content
        assert (
            "linked_from advances_goal <- world_model_task:task-tools-1"
            in result.content
        )
        assert (
            "linked_from updates_goal <- world_model_commitment:commitment-tools-1"
            in result.content
        )
    finally:
        _STORES.clear()


def test_get_item_renders_meeting_goal_links_in_goal_document(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-tools-meeting",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.meetings.create_meeting(
        MeetingRecord(
            meeting_id="meeting-tools-goal",
            state=MeetingState.INGESTED,
            title="Architecture Review",
            created_at=now,
            updated_at=now,
        )
    )
    store.create_meeting_goal_link(
        link=MeetingGoalLink(
            meeting_id="meeting-tools-goal",
            goal_id="goal-tools-meeting",
            relationship="explicit",
            created_at=now,
        )
    )
    configure_stores(content_store=store.content, memex_store=store)

    try:
        result = execute_builtin(
            "get_item", {"id": "world_model_goal:goal-tools-meeting"}
        )

        assert result.success
        assert "linked_from explicit <- meeting:meeting-tools-goal" in result.content
        assert "(Architecture Review)" in result.content
    finally:
        _STORES.clear()
