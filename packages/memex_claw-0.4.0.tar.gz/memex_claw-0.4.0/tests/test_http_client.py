"""Tests for HTTP client wrapper."""

from unittest.mock import MagicMock, patch

from memex.connectors.http_client import HttpClient


def test_get_success():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = '{"ok": true}'

    mock_client = MagicMock()
    mock_client.request.return_value = mock_resp

    client = HttpClient()
    client._client = mock_client

    result = client.get("https://example.com/api")
    assert result.success
    assert result.content == '{"ok": true}'
    assert result.duration_ms >= 0


def test_post_success():
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = "created"

    mock_client = MagicMock()
    mock_client.request.return_value = mock_resp

    client = HttpClient()
    client._client = mock_client

    result = client.post("https://example.com/api", json_body={"key": "val"})
    assert result.success


def test_http_error_status():
    mock_resp = MagicMock()
    mock_resp.status_code = 404
    mock_resp.text = "Not Found"

    mock_client = MagicMock()
    mock_client.request.return_value = mock_resp

    client = HttpClient()
    client._client = mock_client

    result = client.get("https://example.com/missing")
    assert not result.success
    assert result.error == "HTTP 404"


def test_connection_error():
    mock_client = MagicMock()
    mock_client.request.side_effect = ConnectionError("refused")

    client = HttpClient()
    client._client = mock_client

    result = client.get("https://unreachable.example.com")
    assert not result.success
    assert "refused" in result.error


def test_close():
    mock_client = MagicMock()
    client = HttpClient()
    client._client = mock_client

    client.close()
    mock_client.close.assert_called_once()
    assert client._client is None


def test_lazy_client_creation():
    """Client is not created until first request."""
    client = HttpClient()
    assert client._client is None

    import httpx

    with patch.object(httpx, "Client") as mock_cls:
        mock_httpx_client = MagicMock()
        mock_cls.return_value = mock_httpx_client
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = "ok"
        mock_httpx_client.request.return_value = mock_resp

        result = client.get("https://example.com")
        assert result.success
        mock_cls.assert_called_once()
