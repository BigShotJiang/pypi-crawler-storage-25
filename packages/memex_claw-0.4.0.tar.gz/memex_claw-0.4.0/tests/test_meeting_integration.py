"""End-to-end tests for the meeting pipeline: record -> transcribe -> ingest."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from memex.meetings.models import MeetingRecord, MeetingSegment, MeetingState
from memex.meetings.transcribe import TranscriptionResult, orchestrate_transcription
from memex.models import ActionType, ItemType
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore


# ---------------------------------------------------------------------------
# Canned data
# ---------------------------------------------------------------------------

SEGMENTS = [
    MeetingSegment(
        speaker="SPEAKER_00",
        start=0.0,
        end=5.2,
        text="We need to finalize the zylophane migration by Friday.",
    ),
    MeetingSegment(
        speaker="SPEAKER_01",
        start=5.5,
        end=11.0,
        text="Agreed. The quorbitex tests are blocking us right now.",
    ),
    MeetingSegment(
        speaker="SPEAKER_00",
        start=11.3,
        end=16.8,
        text="Let me check the fluorptide configuration and get back to you.",
    ),
]

CANNED_RESULT = TranscriptionResult(
    segments=SEGMENTS,
    speaker_count=2,
    language="en",
    model="large-v3",
    duration_seconds=16.8,
)


def _make_recorded_meeting(meeting_store: Any) -> MeetingRecord:
    """Create a MeetingRecord in RECORDED state and persist it, with a recording."""
    record = MeetingRecord(
        meeting_id=str(uuid.uuid4()),
        state=MeetingState.RECORDED,
        title="Sprint Planning 2026-03-08",
        audio_path="/tmp/fake_audio.wav",
        started_at=datetime(2026, 3, 8, 10, 0),
        stopped_at=datetime(2026, 3, 8, 10, 17),
    )
    meeting_store.create_meeting(record)
    rec_id = str(uuid.uuid4())
    meeting_store.create_recording(rec_id, record.meeting_id, state="recorded")
    meeting_store._repo.update_recording(rec_id, audio_path=record.audio_path)
    return record


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def stores(tmp_path):
    """Return (memex_store, content_store, meeting_store) backed by in-memory SQLite."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    yield store, store.content, store.meetings
    store.close()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
def test_full_pipeline_record_to_ingest(mock_transcribe, stores):
    """Full pipeline: RECORDED -> transcribe -> ingest. Verify final state."""
    memex_store, content_store, meeting_store = stores

    record = _make_recorded_meeting(meeting_store)

    item = orchestrate_transcription(
        record.meeting_id,
        meeting_store=meeting_store,
        content_store=content_store,
    )

    # Re-fetch meeting from store to verify persisted state
    updated = meeting_store.get_meeting(record.meeting_id)

    assert updated.state == MeetingState.INGESTED
    assert updated.item_id is not None

    # Item must exist in content store
    assert item is not None
    stored_item = content_store.get_item(updated.item_id)
    assert stored_item is not None
    assert stored_item.type == ItemType.MEETING

    # Body must contain speaker labels
    assert "[SPEAKER_00]" in stored_item.body
    assert "[SPEAKER_01]" in stored_item.body

    # Title should be set
    assert stored_item.title == "Sprint Planning 2026-03-08"


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
def test_fts_finds_transcript_content(mock_transcribe, stores):
    """After pipeline, FTS should find content by a word in the transcript."""
    memex_store, content_store, meeting_store = stores

    record = _make_recorded_meeting(meeting_store)
    orchestrate_transcription(
        record.meeting_id,
        meeting_store=meeting_store,
        content_store=content_store,
    )

    # "zylophane" is a unique keyword in the first segment
    results = content_store.fts_search("zylophane")
    assert len(results) >= 1
    found_item, relevance = results[0]
    assert "zylophane" in found_item.body
    assert relevance > 0


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
def test_meeting_item_half_life(mock_transcribe, stores):
    """Meeting items should get DEFAULT_HALF_LIFE for MEETING type (60.0 days)."""
    memex_store, content_store, meeting_store = stores

    record = _make_recorded_meeting(meeting_store)
    item = orchestrate_transcription(
        record.meeting_id,
        meeting_store=meeting_store,
        content_store=content_store,
    )

    assert item is not None
    assert item.half_life_days == 60.0


def test_submit_transcription_enqueues():
    """submit_transcription() should enqueue a WorkItem with correct fields."""
    from memex.meetings import submit_transcription

    mock_queue = MagicMock()
    mock_scheduler_store = MagicMock()
    mock_scheduler_store.record_run.return_value = 42

    meeting_id = str(uuid.uuid4())
    run_id = submit_transcription(meeting_id, mock_queue, mock_scheduler_store)

    assert run_id == 42
    mock_scheduler_store.record_run.assert_called_once()
    mock_queue.enqueue.assert_called_once()

    work_item = mock_queue.enqueue.call_args[0][0]
    assert work_item.action_type == ActionType.TRANSCRIPTION.value
    assert work_item.action_data["meeting_id"] == meeting_id


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
def test_pipeline_with_metadata(mock_transcribe, stores):
    """After pipeline, item.metadata should contain meeting details."""
    memex_store, content_store, meeting_store = stores

    record = _make_recorded_meeting(meeting_store)
    item = orchestrate_transcription(
        record.meeting_id,
        meeting_store=meeting_store,
        content_store=content_store,
    )

    assert item is not None

    # Re-fetch from store to verify persisted metadata
    stored_item = content_store.get_item(item.item_id)
    assert "meeting" in stored_item.metadata

    meeting_meta = stored_item.metadata["meeting"]
    assert meeting_meta["speaker_count"] == 2
    assert meeting_meta["language"] == "en"
    assert len(meeting_meta["segments"]) == 3
