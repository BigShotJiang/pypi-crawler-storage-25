"""Tests for AudioCapture with mocked sounddevice/soundfile."""

from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_stream():
    """Create a mock InputStream with start/stop/close."""
    stream = MagicMock()
    stream.start = MagicMock()
    stream.stop = MagicMock()
    stream.close = MagicMock()
    return stream


def _make_mock_soundfile(frames: int = 16000):
    """Create a mock SoundFile that tracks writes and returns frame count."""
    sf = MagicMock()
    sf.tell.return_value = frames
    sf.write = MagicMock()
    sf.close = MagicMock()
    return sf


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_start_creates_wav_file(tmp_path):
    """start() returns a path and sets is_recording=True."""
    mock_stream = _make_mock_stream()
    mock_sf_instance = _make_mock_soundfile()

    mock_sd = MagicMock()
    mock_sd.InputStream.return_value = mock_stream

    mock_sf = MagicMock()
    mock_sf.SoundFile.return_value = mock_sf_instance

    with patch.dict("sys.modules", {"sounddevice": mock_sd, "soundfile": mock_sf}):
        from memex.meetings.capture import AudioCapture

        cap = AudioCapture(audio_dir=tmp_path, sample_rate=16000)
        assert not cap.is_recording

        path = cap.start("test-meeting-id-1234")

        assert cap.is_recording
        assert path is not None
        assert str(path).endswith(".wav")
        assert "test-mee" in str(path)  # first 8 chars of meeting_id
        mock_sf.SoundFile.assert_called_once()
        mock_sd.InputStream.assert_called_once()


def test_stop_returns_path_and_duration(tmp_path):
    """start then stop returns (path, duration)."""
    mock_stream = _make_mock_stream()
    mock_sf = _make_mock_soundfile(frames=32000)  # 2 seconds at 16kHz

    with patch.dict(
        "sys.modules", {"sounddevice": MagicMock(), "soundfile": MagicMock()}
    ):
        from memex.meetings.capture import AudioCapture

        cap = AudioCapture(audio_dir=tmp_path, sample_rate=16000)

        # Manually wire internals to simulate a started state
        cap._recording = True
        cap._stream = mock_stream
        cap._file = mock_sf
        cap._audio_path = tmp_path / "test.wav"

        path, duration = cap.stop()

        assert not cap.is_recording
        assert path == tmp_path / "test.wav"
        assert duration == pytest.approx(2.0)
        mock_stream.stop.assert_called_once()
        mock_stream.close.assert_called_once()
        mock_sf.close.assert_called_once()


def test_start_while_recording_raises(tmp_path):
    """Calling start() twice raises RuntimeError."""
    with patch.dict(
        "sys.modules", {"sounddevice": MagicMock(), "soundfile": MagicMock()}
    ):
        from memex.meetings.capture import AudioCapture

        cap = AudioCapture(audio_dir=tmp_path, sample_rate=16000)
        cap._recording = True  # simulate already recording

        with pytest.raises(RuntimeError, match="Already recording"):
            cap.start("mtg-1")


def test_stop_without_start_raises(tmp_path):
    """Calling stop() without start raises RuntimeError."""
    from memex.meetings.capture import AudioCapture

    cap = AudioCapture(audio_dir=tmp_path, sample_rate=16000)
    assert not cap.is_recording

    with pytest.raises(RuntimeError, match="Not recording"):
        cap.stop()


def test_require_audio_deps_missing():
    """Missing sounddevice raises RuntimeError with install message."""
    import sys

    # Temporarily remove sounddevice from sys.modules if present
    saved = sys.modules.get("sounddevice")
    sys.modules["sounddevice"] = None  # type: ignore[assignment]

    try:
        # Re-import to get a fresh _require_audio_deps
        from memex.meetings.capture import _require_audio_deps

        with patch.dict("sys.modules", {"sounddevice": None}):
            with pytest.raises(RuntimeError, match="pip install memex"):
                _require_audio_deps()
    finally:
        if saved is not None:
            sys.modules["sounddevice"] = saved
        else:
            sys.modules.pop("sounddevice", None)
