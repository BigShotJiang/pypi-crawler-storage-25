"""Tests for Claude Code dispatch in the agentic loop."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

from memex.loop import _execute_tool_call, startup_health_check
from memex.models import ToolDefinition, ToolResult
from memex.tools import ToolRegistry


def _make_registry_with_claude_tool() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(
        ToolDefinition(
            name="claude_code_explain",
            description="Explain code",
            parameters={"type": "object", "properties": {}},
            source="claude_code:claude_code_explain",
            required_capability="claude_code.read",
            keywords=["explain"],
        )
    )
    return registry


class TestExecuteToolCallDispatch:
    def test_claude_code_dispatches_to_integration(self):
        registry = _make_registry_with_claude_tool()
        granted = {"claude_code.read"}
        store = MagicMock()

        mock_integration = MagicMock()
        mock_integration.execute_tool.return_value = ToolResult(
            tool_name="claude_code_explain",
            success=True,
            content="code explanation",
            source="claude_code",
            duration_ms=100,
        )

        result = _execute_tool_call(
            "claude_code_explain",
            {"prompt": "explain loop.py"},
            registry,
            granted,
            store,
            {"claude_code_integration": mock_integration},
        )

        assert result.success
        mock_integration.execute_tool.assert_called_once_with(
            "claude_code_explain", {"prompt": "explain loop.py"}
        )

    def test_claude_code_no_integration_returns_error(self):
        registry = _make_registry_with_claude_tool()
        granted = {"claude_code.read"}
        store = MagicMock()

        result = _execute_tool_call(
            "claude_code_explain",
            {"prompt": "explain"},
            registry,
            granted,
            store,
            {},  # no integration
        )

        assert not result.success
        assert "No Claude Code client" in result.error

    def test_capability_denied(self):
        registry = _make_registry_with_claude_tool()
        granted = set()  # no capabilities
        store = MagicMock()

        result = _execute_tool_call(
            "claude_code_explain",
            {"prompt": "explain"},
            registry,
            granted,
            store,
            {},
        )

        assert not result.success
        assert "denied" in result.error.lower()


class TestStartupClaudeCode:
    @patch.dict(os.environ, {"MEMEX_CLAUDE_CODE_ENABLED": "1"})
    def test_startup_connects_when_enabled(self):
        with patch("memex.loop._connect_claude_code") as mock_connect:
            store = MagicMock()
            startup_health_check(store)
            mock_connect.assert_called_once()

    @patch.dict(os.environ, {}, clear=True)
    def test_startup_skips_when_disabled(self):
        store = MagicMock()
        # Remove env var if present
        os.environ.pop("MEMEX_CLAUDE_CODE_ENABLED", None)
        registry, health_list, clients = startup_health_check(store)
        assert "claude_code_integration" not in clients

    @patch.dict(os.environ, {"MEMEX_CLAUDE_CODE_ENABLED": "1"})
    def test_startup_handles_failure_gracefully(self):
        store = MagicMock()
        with patch("memex.loop._connect_claude_code", side_effect=RuntimeError("boom")):
            registry, health_list, clients = startup_health_check(store)
            # Should not crash, should record unavailable health
            claude_health = [h for h in health_list if h.name == "claude_code"]
            assert len(claude_health) == 1
            assert claude_health[0].status == "unavailable"
