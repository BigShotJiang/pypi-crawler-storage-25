"""Tests for the FactStore write-time deduplication and memory block rendering."""

from __future__ import annotations

import struct
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from memex.memory.fact_store import (
    FACT_TAGS,
    FactStore,
    _cosine_similarity,
)
from memex.models import Item, ItemType, Summary
from memex.utcnow import utcnow


def _make_item(
    item_id: str = "item-1",
    body: str = "test fact",
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Item:
    return Item(
        item_id=item_id,
        type=ItemType.NOTE,
        title=body[:100],
        body=body,
        source_url=f"fact://{item_id}",
        tags=tags or list(FACT_TAGS),
        captured_at=utcnow(),
        last_accessed=utcnow(),
        summary=Summary(text=body[:200]),
        metadata=metadata or {"provenance": [], "confidence": 0.8},
    )


def _floats_to_bytes(floats: list[float]) -> bytes:
    return struct.pack(f"{len(floats)}f", *floats)


class MockEmbedding:
    """Mock embedding backend that returns deterministic vectors."""

    def __init__(self, vectors: dict[str, list[float]] | None = None):
        self._vectors = vectors or {}
        self._default = [1.0, 0.0, 0.0]

    def embed(self, text: str) -> list[float]:
        return self._vectors.get(text, self._default)

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]

    @property
    def dimensions(self) -> int:
        return 3

    @property
    def model_name(self) -> str:
        return "test-model"


class MockContentStore:
    """Minimal content store mock for fact store tests."""

    def __init__(self):
        self._items: dict[str, Item] = {}
        self._embeddings: dict[str, tuple[bytes, str]] = {}

    def create_item(self, item: Item) -> None:
        self._items[item.item_id] = item

    def update_item(self, item: Item) -> None:
        self._items[item.item_id] = item

    def list_items(
        self, *, type=None, pinned=None, include_expired=False, limit=50, now=None
    ) -> list[Item]:
        items = list(self._items.values())
        if type is not None:
            items = [i for i in items if i.type == type]
        return items[:limit]

    def save_embedding(self, item_id, vector, model, dimensions) -> None:
        self._embeddings[item_id] = (vector, model)

    def get_embedding(self, item_id) -> tuple[bytes, str] | None:
        return self._embeddings.get(item_id)

    def soft_delete_item(self, item_id: str) -> bool:
        if item_id in self._items:
            del self._items[item_id]
            return True
        return False

    def find_by_url(self, url: str) -> Item | None:
        for item in self._items.values():
            if item.source_url == url:
                return item
        return None

    def fts_search(
        self, query: str, limit: int = 20, item_type: str | None = None
    ) -> list[Item]:
        """Simple substring match for testing."""
        results = []
        q = query.strip().lower()
        for item in self._items.values():
            if q in (item.body or "").lower() or q in (item.title or "").lower():
                results.append(item)
        return results[:limit]


class TestCosine:
    def test_identical_vectors(self):
        assert _cosine_similarity([1, 0, 0], [1, 0, 0]) == pytest.approx(1.0)

    def test_orthogonal_vectors(self):
        assert _cosine_similarity([1, 0, 0], [0, 1, 0]) == pytest.approx(0.0)

    def test_opposite_vectors(self):
        assert _cosine_similarity([1, 0], [-1, 0]) == pytest.approx(-1.0)

    def test_zero_vector(self):
        assert _cosine_similarity([0, 0], [1, 0]) == pytest.approx(0.0)


class TestFactStoreAddFact:
    def test_new_fact_stored(self):
        """A new fact with no similar existing facts is stored."""
        store = MockContentStore()
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        provenance = {"session_id": "s1", "turn": 1, "timestamp": "2026-01-01"}
        result = fs.add_fact("I work at Acme Corp", provenance)

        assert result is not None
        assert len(store._items) == 1
        item = list(store._items.values())[0]
        assert item.body == "I work at Acme Corp"
        assert set(FACT_TAGS).issubset(set(item.tags))
        assert item.metadata["provenance"] == [provenance]

    def test_duplicate_fact_merged(self):
        """Same fact added twice results in merge (provenance accumulated)."""
        store = MockContentStore()
        # Both texts get the same embedding vector → high similarity
        emb = MockEmbedding(
            vectors={
                "I work at Acme": [1.0, 0.0, 0.0],
                "I work at Acme Corp": [1.0, 0.0, 0.0],
            }
        )
        fs = FactStore(store, emb)

        prov1 = {"session_id": "s1", "turn": 1, "timestamp": "2026-01-01"}
        prov2 = {"session_id": "s2", "turn": 3, "timestamp": "2026-01-02"}

        fs.add_fact("I work at Acme", prov1)
        result = fs.add_fact("I work at Acme Corp", prov2)

        # Second should merge, not create new
        assert result is None
        assert len(store._items) == 1
        item = list(store._items.values())[0]
        # Provenance list should have both entries (never overwritten)
        assert len(item.metadata["provenance"]) == 2

    def test_negated_fact_supersedes(self):
        """Contradictory fact supersedes the original."""
        store = MockContentStore()
        # Similar embeddings but different polarity
        emb = MockEmbedding(
            vectors={
                "I use Python": [1.0, 0.0, 0.0],
                "I no longer use Python": [0.99, 0.1, 0.0],
            }
        )
        fs = FactStore(store, emb)

        prov1 = {"session_id": "s1", "turn": 1, "timestamp": "2026-01-01"}
        prov2 = {"session_id": "s2", "turn": 5, "timestamp": "2026-01-03"}

        fs.add_fact("I use Python", prov1)
        assert len(store._items) == 1

        result = fs.add_fact("I no longer use Python", prov2)

        # Should supersede: old deleted, new created
        assert result is not None
        assert len(store._items) == 1  # old soft-deleted, new created
        item = list(store._items.values())[0]
        assert item.body == "I no longer use Python"
        assert item.supersedes_id is not None
        # Provenance should include history from both
        assert len(item.metadata["provenance"]) == 2

    def test_unrelated_fact_stored_separately(self):
        """Unrelated fact creates a new item."""
        store = MockContentStore()
        emb = MockEmbedding(
            vectors={
                "I work at Acme": [1.0, 0.0, 0.0],
                "My favorite color is blue": [0.0, 1.0, 0.0],
            }
        )
        fs = FactStore(store, emb)

        fs.add_fact("I work at Acme", {"session_id": "s1", "turn": 1})
        fs.add_fact("My favorite color is blue", {"session_id": "s1", "turn": 2})

        assert len(store._items) == 2

    def test_empty_fact_rejected(self):
        """Empty or whitespace-only facts are rejected."""
        store = MockContentStore()
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        assert fs.add_fact("", {"session_id": "s1"}) is None
        assert fs.add_fact("   ", {"session_id": "s1"}) is None
        assert len(store._items) == 0

    def test_provenance_never_overwritten(self):
        """Provenance accumulates across merges, never replaced (hard constraint)."""
        store = MockContentStore()
        vec = [1.0, 0.0, 0.0]
        emb = MockEmbedding(
            vectors={
                "fact A": vec,
                "fact A v2": vec,
                "fact A v3": vec,
            }
        )
        fs = FactStore(store, emb)

        for i in range(3):
            fs.add_fact(
                f"fact A{'v' + str(i + 1) if i else ' '}",
                {
                    "session_id": f"s{i}",
                    "turn": i,
                },
            )

        assert len(store._items) == 1
        item = list(store._items.values())[0]
        assert len(item.metadata["provenance"]) == 3

    def test_embedding_failure_stores_without_dedup(self):
        """When embedding fails, fact is stored anyway without dedup."""
        store = MockContentStore()
        emb = MockEmbedding()
        emb.embed = MagicMock(side_effect=RuntimeError("embedding service down"))
        fs = FactStore(store, emb)

        result = fs.add_fact("I work at Acme", {"session_id": "s1"})

        assert result is not None
        assert len(store._items) == 1
        # Embedding was not saved (embed failed before we could store it)
        assert store.get_embedding(result) is None

    def test_create_item_failure_propagates(self):
        """When content_store.create_item fails, exception propagates."""
        store = MockContentStore()
        store.create_item = MagicMock(side_effect=RuntimeError("database locked"))
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        with pytest.raises(RuntimeError, match="database locked"):
            fs.add_fact("I work at Acme", {"session_id": "s1"})

    def test_supersede_preserves_complex_provenance_chain(self):
        """Superseding a fact with multiple provenance entries preserves all."""
        store = MockContentStore()
        emb = MockEmbedding(
            vectors={
                "I use Python": [1.0, 0.0, 0.0],
                "I stopped using Python": [0.99, 0.1, 0.0],
            }
        )
        fs = FactStore(store, emb)

        # First fact
        prov1 = {"session_id": "s1", "turn": 1}
        item1_id = fs.add_fact("I use Python", prov1)

        # Manually add more provenance to simulate historical buildup
        item1 = store._items[item1_id]
        item1.metadata["provenance"].extend(
            [
                {"session_id": "s1", "turn": 5},
                {"session_id": "s2", "turn": 2},
            ]
        )
        store.update_item(item1)

        # Now supersede with negation
        new_prov = {"session_id": "s3", "turn": 1}
        result = fs.add_fact("I stopped using Python", new_prov)

        # New fact should have all 4 provenance entries (3 old + 1 new)
        new_item = store._items[result]
        assert len(new_item.metadata["provenance"]) == 4

    def test_higher_confidence_kept_on_merge(self):
        """Merge keeps the higher confidence value."""
        store = MockContentStore()
        vec = [1.0, 0.0, 0.0]
        emb = MockEmbedding(vectors={"fact": vec, "fact again": vec})
        fs = FactStore(store, emb)

        fs.add_fact("fact", {"session_id": "s1"}, confidence=0.6)
        fs.add_fact("fact again", {"session_id": "s2"}, confidence=0.9)

        item = list(store._items.values())[0]
        assert item.metadata["confidence"] == 0.9


class TestFactStoreRender:
    def test_render_empty(self):
        """No facts → empty string."""
        store = MockContentStore()
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        assert fs.render_memory_block() == ""

    def test_render_facts(self):
        """Facts render as bullet list under ## Memory header."""
        store = MockContentStore()
        emb = MockEmbedding(
            vectors={
                "I work at Acme": [1.0, 0.0, 0.0],
                "My favorite language is Python": [0.0, 1.0, 0.0],
            }
        )
        fs = FactStore(store, emb)

        fs.add_fact("I work at Acme", {"session_id": "s1"})
        fs.add_fact("My favorite language is Python", {"session_id": "s1"})

        block = fs.render_memory_block()
        assert block.startswith("## Memory")
        assert "- I work at Acme" in block
        assert "- My favorite language is Python" in block

    def test_get_all_facts_filters_by_tags(self):
        """get_all_facts returns only items with both fact tags."""
        store = MockContentStore()
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        # Add a fact via FactStore
        fs.add_fact("real fact", {"session_id": "s1"})

        # Add a non-fact item directly
        non_fact = _make_item(item_id="non-fact", body="not a fact", tags=["other"])
        store.create_item(non_fact)

        facts = fs.get_all_facts()
        assert len(facts) == 1
        assert facts[0].body == "real fact"


class TestApplyExtractionWithFactStore:
    def test_facts_routed_through_fact_store(self):
        """When fact_store is provided, facts go through add_fact."""
        from memex.memory.conversation_extract import (
            apply_extraction,
            ExtractionResult,
            ExtractedFact,
        )
        from memex.models import SessionContext

        fact_store = MagicMock()
        content_store = MockContentStore()
        session = SessionContext(session_id="test", started_at=utcnow())

        result = ExtractionResult(
            facts=[ExtractedFact(statement="test fact", confidence=0.8)],
        )

        apply_extraction(
            result,
            content_store,
            session,
            fact_store=fact_store,
        )

        fact_store.add_fact.assert_called_once()
        call_args = fact_store.add_fact.call_args
        assert call_args.args[0] == "test fact"
        assert call_args.kwargs["confidence"] == 0.8

    def test_facts_fallback_without_fact_store(self):
        """Without fact_store, facts use legacy ingest path."""
        from memex.memory.conversation_extract import (
            apply_extraction,
            ExtractionResult,
            ExtractedFact,
        )
        from memex.models import SessionContext
        from unittest.mock import patch

        content_store = MockContentStore()
        session = SessionContext(session_id="test", started_at=utcnow())

        result = ExtractionResult(
            facts=[ExtractedFact(statement="test fact", confidence=0.8)],
        )

        with patch("memex.memory.intake.ingest") as mock_ingest:
            apply_extraction(result, content_store, session)
            mock_ingest.assert_called_once()


class TestEmbedFailureWarning:
    def test_embed_failure_logs_warning(self):
        """Embed failure should log at WARNING (not DEBUG) with text preview."""
        store = MockContentStore()
        emb = MockEmbedding()

        with patch("memex.memory.fact_store.logger") as mock_logger:
            emb.embed = MagicMock(side_effect=RuntimeError("embedding service down"))
            fs = FactStore(store, emb)
            fs.add_fact("I work at Acme", {"session_id": "s1"})

        mock_logger.warning.assert_called()
        call_args = mock_logger.warning.call_args
        assert "dedup" in str(call_args).lower()

    def test_embed_failure_sets_dedup_skipped_metadata(self):
        """When embedding fails, stored fact has dedup_skipped=True in metadata."""
        store = MockContentStore()
        emb = MockEmbedding()
        emb.embed = MagicMock(side_effect=RuntimeError("embedding service down"))
        fs = FactStore(store, emb)

        result = fs.add_fact("I work at Acme", {"session_id": "s1"})

        assert result is not None
        stored = store._items[result]
        assert stored.metadata.get("dedup_skipped") is True

    def test_fts_fallback_dedup_on_embed_failure(self):
        """When embedding fails and FTS finds exact same text, merges instead of duplicating."""
        store = MockContentStore()
        emb = MockEmbedding()
        fs = FactStore(store, emb)

        # First store a fact normally
        first_id = fs.add_fact("I work at Acme", {"session_id": "s1"})
        assert first_id is not None

        # Now simulate embed failure for second identical fact
        emb.embed = MagicMock(side_effect=RuntimeError("embedding service down"))

        result = fs.add_fact("I work at Acme", {"session_id": "s2"})

        # Should merge (return None) not store a duplicate
        assert result is None
        assert len(store._items) == 1  # No new item created
        # Provenance should have both entries
        merged = store._items[first_id]
        assert len(merged.metadata.get("provenance", [])) == 2
