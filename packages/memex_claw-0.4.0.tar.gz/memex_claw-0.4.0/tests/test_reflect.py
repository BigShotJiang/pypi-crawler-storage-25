"""Tests for structured reflection with mocked LLM."""

from unittest.mock import patch

from memex.models import (
    GoalStatus,
    InputClassification,
    InputClassificationType,
    NewSubgoal,
    ReflectResult,
    SessionContext,
)
from memex.reflect import apply_reflect_result, reflect
from memex.session import create_session
from conftest import make_goal


def _make_session() -> SessionContext:
    return create_session()


def _mock_reflect(result: ReflectResult):
    def mock_chat_structured(messages, schema, **kwargs):
        return result

    return mock_chat_structured


def test_reflect_returns_structured():
    result = ReflectResult(
        intent_advanced=["abc"],
        reflection_note="User advanced Rust learning",
        confidence=0.8,
    )
    mock = _mock_reflect(result)
    classification = InputClassification(
        classification=InputClassificationType.ADVANCES_GOAL,
        goal_id="abc",
        confidence=0.9,
        reasoning="test",
    )

    with patch("memex.reflect.chat_structured", mock):
        got = reflect(
            classification=classification,
            assistant_response="Great progress!",
            relevant_goals=[],
            session=_make_session(),
        )

    assert got.intent_advanced == ["abc"]
    assert got.reflection_note == "User advanced Rust learning"


def test_reflect_fallback_on_error():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
    )

    def raise_error(*args, **kwargs):
        raise RuntimeError("LLM down")

    with patch("memex.reflect.chat_structured", raise_error):
        got = reflect(
            classification=classification,
            assistant_response="Hi!",
            relevant_goals=[],
            session=_make_session(),
        )

    assert got.reflection_note == "reflection failed — no-op"
    assert got.intent_advanced == []


def test_apply_reflect_creates_subgoal(memory_store):
    parent = make_goal(title="Learn Rust")
    memory_store.create_goal(parent)

    result = ReflectResult(
        new_subgoals=[
            NewSubgoal(
                parent_id=parent.goal_id,
                title="Read ownership chapter",
                description="Chapter 4 of the Rust book",
            )
        ],
    )
    apply_reflect_result(result, memory_store)

    children = memory_store.get_children(parent.goal_id)
    assert len(children) == 1
    assert children[0].title == "Read ownership chapter"


def test_apply_reflect_completes_goal(memory_store):
    g = make_goal(title="Done task")
    memory_store.create_goal(g)

    result = ReflectResult(goals_to_complete=[g.goal_id])
    apply_reflect_result(result, memory_store)

    updated = memory_store.get_goal(g.goal_id)
    assert updated.status == GoalStatus.COMPLETED


def test_apply_reflect_blocks_goal(memory_store):
    g = make_goal(title="Blocked task")
    memory_store.create_goal(g)

    from memex.models import GoalBlock

    result = ReflectResult(
        goals_to_block=[GoalBlock(goal_id=g.goal_id, reason="need API key")]
    )
    apply_reflect_result(result, memory_store)

    updated = memory_store.get_goal(g.goal_id)
    assert updated.status == GoalStatus.BLOCKED
    assert updated.blocked_reason == "need API key"


def test_apply_reflect_fails_goal(memory_store):
    g = make_goal(title="Failed task")
    memory_store.create_goal(g)

    from memex.models import GoalFail

    result = ReflectResult(
        goals_to_fail=[GoalFail(goal_id=g.goal_id, reason="deprecated")]
    )
    apply_reflect_result(result, memory_store)

    updated = memory_store.get_goal(g.goal_id)
    assert updated.status == GoalStatus.FAILED
    assert updated.failure_reason == "deprecated"


def test_apply_reflect_pauses_goal(memory_store):
    g = make_goal(title="Paused task")
    memory_store.create_goal(g)

    result = ReflectResult(goals_to_pause=[g.goal_id])
    apply_reflect_result(result, memory_store)

    updated = memory_store.get_goal(g.goal_id)
    assert updated.status == GoalStatus.PAUSED


def test_apply_reflect_touches_advanced(memory_store):
    g = make_goal(title="Advancing", days_ago=5)
    memory_store.create_goal(g)
    old_touched = g.last_touched_at

    result = ReflectResult(intent_advanced=[g.goal_id])
    apply_reflect_result(result, memory_store)

    updated = memory_store.get_goal(g.goal_id)
    assert updated.last_touched_at > old_touched
