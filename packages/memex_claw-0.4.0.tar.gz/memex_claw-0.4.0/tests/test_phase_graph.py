"""Tests for the PhaseGraph foundation (Pack 1)."""

from __future__ import annotations

from dataclasses import FrozenInstanceError

import pytest

from memex.phase_graph.context import INITIAL_CONTEXT_KEYS, _set_retrieval_defaults
from memex.phase_graph.graph import (
    JoinBarrier,
    PhaseEdge,
    PhaseGraph,
    PhaseNode,
)
from memex.phase_graph.retry import RetryPolicy
from memex.phase_graph.trace import PhaseTraceEntry, compute_phase_timings
from memex.phase_graph.graph import GraphDefinitionError

from unittest.mock import patch

from memex.llm import TokenUsage
from memex.loop import run_turn
from memex.memory.conversation_extract import CombinedExtractReflectResult
from memex.models import (
    InputClassification,
    InputClassificationType,
    IntentFrame,
    IntentFramePath,
)
from memex.utcnow import utcnow as _utcnow


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _noop(ctx):
    pass


def _make_simple_graph():
    nodes = [
        PhaseNode("A", execute=_noop, inputs=frozenset(), outputs=frozenset({"a_out"})),
        PhaseNode(
            "B",
            execute=_noop,
            inputs=frozenset({"a_out"}),
            outputs=frozenset({"b_out"}),
        ),
        PhaseNode("C", execute=_noop, inputs=frozenset({"b_out"}), outputs=frozenset()),
    ]
    edges = [
        PhaseEdge(source="A", target="B"),
        PhaseEdge(source="B", target="C"),
    ]
    return PhaseGraph(nodes=nodes, edges=edges, fallback_edges=(), join_barriers=())


# ---------------------------------------------------------------------------
# Validation tests
# ---------------------------------------------------------------------------


class TestValidGraph:
    def test_valid_graph_passes_validation(self):
        graph = _make_simple_graph()
        assert len(graph.nodes) == 3
        assert graph.get_node("A").name == "A"

    def test_entry_node(self):
        graph = _make_simple_graph()
        assert graph.entry_node == "A"

    def test_get_outgoing_edges(self):
        graph = _make_simple_graph()
        edges = graph.get_outgoing_edges("A")
        assert len(edges) == 1
        assert edges[0].target == "B"


class TestUnreachableNode:
    def test_unreachable_node_raises(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"a_out"})
            ),
            PhaseNode(
                "B", execute=_noop, inputs=frozenset({"a_out"}), outputs=frozenset()
            ),
            PhaseNode("Y", execute=_noop, inputs=frozenset(), outputs=frozenset()),
            PhaseNode("Z", execute=_noop, inputs=frozenset(), outputs=frozenset()),
        ]
        # Y and Z form a disconnected pair: Y->Z makes Z not an entry node,
        # but Y itself is an entry node reachable from the start. We need both
        # to be non-entry. Use Y->Z and Z->Y edges to form a cycle that makes
        # neither an entry node, but they are unreachable from A.
        edges = [
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="Y", target="Z"),
            PhaseEdge(source="Z", target="Y"),
        ]
        with pytest.raises(GraphDefinitionError, match="[Uu]nreachable|[Cc]ycle"):
            PhaseGraph(nodes=nodes, edges=edges, fallback_edges=(), join_barriers=())


class TestUnsatisfiedInput:
    def test_unsatisfied_input_raises(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"a_out"})
            ),
            PhaseNode(
                "B",
                execute=_noop,
                inputs=frozenset({"missing_key"}),
                outputs=frozenset(),
            ),
        ]
        edges = [PhaseEdge(source="A", target="B")]
        with pytest.raises(GraphDefinitionError, match="unsatisfied"):
            PhaseGraph(nodes=nodes, edges=edges, fallback_edges=(), join_barriers=())


class TestOutputConflict:
    def test_output_conflict_raises(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"shared"})
            ),
            PhaseNode(
                "B", execute=_noop, inputs=frozenset(), outputs=frozenset({"shared"})
            ),
            PhaseNode(
                "C",
                execute=_noop,
                inputs=frozenset({"shared"}),
                outputs=frozenset(),
            ),
        ]
        # A and B are both entry nodes (no incoming edges), both write "shared"
        edges = [
            PhaseEdge(source="A", target="C"),
            PhaseEdge(source="B", target="C"),
        ]
        with pytest.raises(GraphDefinitionError, match="[Oo]utput conflict"):
            PhaseGraph(nodes=nodes, edges=edges, fallback_edges=(), join_barriers=())

    def test_output_conflict_exempt_with_exclusive_pairs(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"shared"})
            ),
            PhaseNode(
                "B", execute=_noop, inputs=frozenset(), outputs=frozenset({"shared"})
            ),
            PhaseNode(
                "C",
                execute=_noop,
                inputs=frozenset({"shared"}),
                outputs=frozenset(),
            ),
        ]
        edges = [
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="B", target="C"),
            PhaseEdge(source="A", target="C"),
        ]
        # Should NOT raise because the pair is exempted
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            fallback_edges=(),
            join_barriers=(),
            exclusive_output_pairs={frozenset({"A", "B"})},
        )
        assert len(graph.nodes) == 3


class TestJoinCompleteness:
    def test_join_incomplete_raises(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"a_out"})
            ),
            PhaseNode(
                "B", execute=_noop, inputs=frozenset(), outputs=frozenset({"b_out"})
            ),
            PhaseNode("JOIN", execute=_noop, inputs=frozenset(), outputs=frozenset()),
        ]
        edges = [
            PhaseEdge(source="A", target="JOIN"),
            # B has no edge to JOIN, but barrier expects it
        ]
        barrier = JoinBarrier(name="JOIN", incoming=frozenset({"A", "B"}))
        with pytest.raises(GraphDefinitionError, match="[Jj]oin[Bb]arrier"):
            PhaseGraph(
                nodes=nodes, edges=edges, fallback_edges=(), join_barriers=(barrier,)
            )


class TestCycleDetection:
    def test_cycle_raises(self):
        nodes = [
            PhaseNode(
                "A", execute=_noop, inputs=frozenset(), outputs=frozenset({"a_out"})
            ),
            PhaseNode(
                "B",
                execute=_noop,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
            ),
            PhaseNode(
                "C",
                execute=_noop,
                inputs=frozenset({"b_out"}),
                outputs=frozenset({"c_out"}),
            ),
        ]
        # A->B->C->B creates a cycle between B and C, but A is still an entry node
        edges = [
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="B", target="C"),
            PhaseEdge(source="C", target="B"),
        ]
        with pytest.raises(GraphDefinitionError, match="[Cc]ycle"):
            PhaseGraph(nodes=nodes, edges=edges, fallback_edges=(), join_barriers=())


class TestFallbackCoverageValidation:
    def test_retryable_node_without_fallback_still_valid(self):
        retry = RetryPolicy(max_attempts=3)
        nodes = [
            PhaseNode(
                "A",
                execute=_noop,
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                retry=retry,
            ),
            PhaseNode(
                "B", execute=_noop, inputs=frozenset({"a_out"}), outputs=frozenset()
            ),
        ]
        edges = [PhaseEdge(source="A", target="B")]
        graph = PhaseGraph(
            nodes=nodes, edges=edges, fallback_edges=(), join_barriers=()
        )
        assert len(graph.nodes) == 2


# ---------------------------------------------------------------------------
# Data structure tests
# ---------------------------------------------------------------------------


class TestDataStructures:
    def test_phase_node_frozen(self):
        node = PhaseNode("X", execute=_noop, inputs=frozenset(), outputs=frozenset())
        with pytest.raises(FrozenInstanceError):
            node.name = "Y"

    def test_retry_policy_defaults(self):
        policy = RetryPolicy()
        assert policy.max_attempts == 1
        assert policy.backoff_base == 2.0
        assert policy.retryable(Exception("test")) is False

    def test_compute_phase_timings(self):
        trace = [
            PhaseTraceEntry("CLASSIFY", 0.0, 0.5, "completed"),
            PhaseTraceEntry("SELECT_TOOLS", 0.5, 1.0, "completed"),
            PhaseTraceEntry("RETRIEVE", 0.5, 1.0, "completed"),
            PhaseTraceEntry("LLM_RESPOND", 1.0, 2.0, "completed"),
        ]
        timings = compute_phase_timings(trace)
        assert timings["classify"] == 500
        assert timings["tool_selection"] == 500
        assert timings["retrieval"] == 500
        assert timings["llm"] == 1000
        assert timings["total"] == 2000


# ---------------------------------------------------------------------------
# Context tests
# ---------------------------------------------------------------------------


class TestContext:
    def test_set_retrieval_defaults(self):
        ctx = {}
        _set_retrieval_defaults(ctx)
        assert ctx["retrieved_knowledge"] == ""
        assert ctx["retrieved_document_ids"] == set()
        assert ctx["proactive_context"] == ""

    def test_initial_context_keys_contains_required(self):
        required = {"user_input", "store", "session", "tool_registry", "now"}
        assert required.issubset(INITIAL_CONTEXT_KEYS)


# ---------------------------------------------------------------------------
# Structural property tests (whitepaper design rules)
# ---------------------------------------------------------------------------


class TestWhitepaperStructuralProperties:
    """Tests that the Memex phase graph satisfies the structural properties
    defined in the phase graph whitepaper (dev/notes/whitepaper-phase-graphs-for-llm-agents.md).

    These are design-rule conformance tests, not functional tests. They verify
    that the graph topology guarantees termination, deadlock-freedom, input
    completeness, deterministic degradation, and other properties that prevent
    entire classes of runtime failures.
    """

    @pytest.fixture(autouse=True)
    def _build_graph(self):
        from memex.phase_graph.definition import build_memex_turn_graph

        self.graph = build_memex_turn_graph()
        self.node_map = {n.name: n for n in self.graph.nodes}
        self.edge_set = {(e.source, e.target) for e in self.graph.edges}

    # -- 2.1 Termination: graph is a DAG (no cycles) --------------------------

    def test_graph_is_acyclic(self):
        """Whitepaper 2.1: acyclic graph guarantees termination.

        Cycles (e.g., tool loops) must use bounded iteration inside a node,
        not graph-level cycles.
        """
        from collections import defaultdict

        adj: dict[str, set[str]] = defaultdict(set)
        for e in self.graph.edges:
            adj[e.source].add(e.target)

        WHITE, GRAY, BLACK = 0, 1, 2
        all_names = self.graph.node_names | self.graph.barrier_names
        color = {n: WHITE for n in all_names}

        def has_cycle(node: str) -> bool:
            color[node] = GRAY
            for nb in adj.get(node, set()):
                if nb in color:
                    if color[nb] == GRAY:
                        return True
                    if color[nb] == WHITE and has_cycle(nb):
                        return True
            color[node] = BLACK
            return False

        for name in all_names:
            if color[name] == WHITE:
                assert not has_cycle(name), f"Cycle detected involving {name}"

    def test_tool_loop_bounded(self):
        """Whitepaper 2.1: tool loop must have a bounded iteration limit."""
        from memex.phase_graph.nodes.tool_loop import MAX_TOOL_ITERATIONS

        assert MAX_TOOL_ITERATIONS > 0
        assert MAX_TOOL_ITERATIONS <= 20  # reasonable upper bound

    # -- 2.2 Deadlock-freedom at join barriers --------------------------------

    def test_join_barriers_have_skip_paths(self):
        """Whitepaper 2.2: every conditional branch that skips nodes feeding
        a join barrier must provide an alternative path.

        For _GATHER_JOIN: SKIP_RETRIEVE supplies defaults when RETRIEVE is skipped.
        For _POST_JOIN: vacuous completion handles absent APPLY_EXTRACTION.
        """
        gather = self.graph.get_join_barrier("_GATHER_JOIN")
        assert gather is not None

        # SKIP_RETRIEVE must feed the gather barrier (alternative to RETRIEVE)
        assert ("SKIP_RETRIEVE", "_GATHER_JOIN") in self.edge_set

        # RETRIEVE_FALLBACK must also feed the barrier
        assert ("RETRIEVE_FALLBACK", "_GATHER_JOIN") in self.edge_set

    def test_conditional_edges_are_exhaustive(self):
        """Whitepaper 2.2: conditional branches from the same source must
        cover all cases (complementary predicates).

        When a node has ONLY conditional outgoing edges (no unconditional
        fallthrough), at least two conditional edges must exist to cover
        all cases. Nodes that mix conditional + unconditional edges (like
        EXTRACT_REFLECT) are fine — the unconditional edge always fires.
        """
        from collections import defaultdict

        outgoing: dict[str, list] = defaultdict(list)
        for e in self.graph.edges:
            outgoing[e.source].append(e)

        for source, edges in outgoing.items():
            conditional = [e for e in edges if e.condition is not None]
            unconditional = [e for e in edges if e.condition is None]
            if conditional and not unconditional:
                # All edges are conditional — must have complementary pair
                assert len(conditional) >= 2, (
                    f"Node {source} has only conditional edges but fewer than 2 "
                    f"— not exhaustive"
                )

    # -- 2.3 Input completeness -----------------------------------------------

    def test_every_node_input_satisfiable(self):
        """Whitepaper 2.3: every declared input must be producible by some
        transitive predecessor or be an initial context key.

        This test re-checks the property that validation.py checks at
        construction time, serving as a regression guard.
        """
        from collections import defaultdict

        adj: dict[str, set[str]] = defaultdict(set)
        for e in self.graph.edges:
            adj[e.source].add(e.target)
        for fb in self.graph.fallback_edges:
            adj[fb.source].add(fb.target)

        rev_adj: dict[str, set[str]] = defaultdict(set)
        for src, targets in adj.items():
            for tgt in targets:
                rev_adj[tgt].add(src)

        for node in self.graph.nodes:
            if not node.inputs:
                continue
            predecessor_outputs: set[str] = set()
            visited: set[str] = set()
            stack = list(rev_adj.get(node.name, set()))
            while stack:
                pred = stack.pop()
                if pred in visited:
                    continue
                visited.add(pred)
                if pred in self.node_map:
                    predecessor_outputs.update(self.node_map[pred].outputs)
                stack.extend(rev_adj.get(pred, set()) - visited)

            unsatisfied = node.inputs - INITIAL_CONTEXT_KEYS - predecessor_outputs
            assert not unsatisfied, (
                f"Node '{node.name}' has unsatisfied inputs: {sorted(unsatisfied)}"
            )

    # -- 2.4 Fallback coverage (deterministic degradation) --------------------

    def test_every_retryable_node_has_fallback(self):
        """Whitepaper 2.4 / 4.3: every node with a retry policy must have
        a fallback edge for deterministic degradation.
        """
        retryable_nodes = [n for n in self.graph.nodes if n.retry.max_attempts > 1]
        fallback_sources = {fb.source for fb in self.graph.fallback_edges}

        for node in retryable_nodes:
            assert node.name in fallback_sources, (
                f"Node '{node.name}' has retry (max_attempts={node.retry.max_attempts}) "
                f"but no fallback edge"
            )

    def test_every_fallback_reaches_terminal(self):
        """Whitepaper 2.4: every fallback path must reach a terminal node.

        'Terminal' means a node with no outgoing edges, or SAVE_SESSION /
        LOG_SAVE_FAILURE which are the graph's sink nodes.
        """
        from collections import defaultdict

        adj: dict[str, set[str]] = defaultdict(set)
        for e in self.graph.edges:
            adj[e.source].add(e.target)
        for fb in self.graph.fallback_edges:
            adj[fb.source].add(fb.target)

        terminal_nodes = {"SAVE_SESSION", "LOG_SAVE_FAILURE"}

        for fb in self.graph.fallback_edges:
            # BFS from fallback target to find a terminal
            visited: set[str] = set()
            stack = [fb.target]
            reached_terminal = False
            while stack:
                current = stack.pop()
                if current in visited:
                    continue
                visited.add(current)
                if current in terminal_nodes:
                    reached_terminal = True
                    break
                stack.extend(adj.get(current, set()))

            assert reached_terminal, (
                f"Fallback {fb.source} -> {fb.target} cannot reach a terminal node"
            )

    # -- 2.5 Separation of control flow from execution logic ------------------

    def test_edge_conditions_are_deterministic(self):
        """Whitepaper 4.5: edge predicates should be deterministic functions
        of the context, not LLM calls.

        Verify all condition functions are plain Python callables (not
        coroutines or LLM wrappers).
        """
        import asyncio

        for edge in self.graph.edges:
            if edge.condition is not None:
                assert not asyncio.iscoroutinefunction(edge.condition), (
                    f"Edge {edge.source} -> {edge.target} has async condition "
                    f"(suggests LLM call); edge predicates must be deterministic"
                )

    # -- 2.8 Executor size ----------------------------------------------------

    def test_executor_is_small(self):
        """Whitepaper 2.8: the executor should not exceed ~500 lines."""
        import inspect
        from memex.phase_graph.executor import GraphExecutor

        source = inspect.getsource(GraphExecutor)
        line_count = len(source.splitlines())
        assert line_count < 500, (
            f"GraphExecutor is {line_count} lines; whitepaper recommends < 500"
        )

    # -- 2.9 Boundary for responsiveness --------------------------------------

    def test_boundary_node_exists(self):
        """Whitepaper 2.9: a boundary node must exist so the executor can
        return results before background work completes.

        RETURN_RESPONSE is the boundary in the Memex graph.
        """
        assert self.graph.get_node("RETURN_RESPONSE") is not None

        # Verify edges exist from RETURN_RESPONSE to background work
        post_boundary_edges = [
            e for e in self.graph.edges if e.source == "RETURN_RESPONSE"
        ]
        assert len(post_boundary_edges) > 0, (
            "RETURN_RESPONSE must have outgoing edges to background work"
        )

    # -- 2.10 Static validation at construction time --------------------------

    def test_validation_runs_at_construction(self):
        """Whitepaper 2.10: all critical properties must be checked at graph
        construction time, not at runtime.
        """
        # Verify that constructing a bad graph raises immediately
        with pytest.raises(GraphDefinitionError):
            PhaseGraph(
                nodes=(
                    PhaseNode(
                        "A", execute=_noop, inputs=frozenset(), outputs=frozenset()
                    ),
                    PhaseNode(
                        "B",
                        execute=_noop,
                        inputs=frozenset({"missing_key"}),
                        outputs=frozenset(),
                    ),
                ),
                edges=(PhaseEdge(source="A", target="B"),),
            )

    # -- 4.1 Phase graph warranted for Memex ----------------------------------

    def test_graph_has_genuine_parallelism(self):
        """Whitepaper 4.1: phase graph warranted when genuine parallelism exists.

        The gather phase fans out to 4+ parallel branches from FILTER_GOALS.
        """
        gather_targets = [
            e.target for e in self.graph.edges if e.source == "FILTER_GOALS"
        ]
        assert len(gather_targets) >= 3, (
            f"Gather phase should fan out to 3+ branches, got {len(gather_targets)}"
        )
        gather_edges = [e for e in self.graph.edges if e.source == "FILTER_GOALS"]
        assert all(e.parallel for e in gather_edges), (
            "All FILTER_GOALS outgoing edges must be parallel=True for concurrent gather"
        )

    def test_graph_has_background_processing(self):
        """Whitepaper 4.1: phase graph warranted when background processing exists.

        Post-boundary nodes (EXTRACT_REFLECT, APPLY_REFLECT, SAVE_SESSION)
        run after the response is returned to the user.
        """
        # RETURN_RESPONSE -> EXTRACT_REFLECT is the boundary crossing
        assert ("RETURN_RESPONSE", "EXTRACT_REFLECT") in self.edge_set

    # -- Exclusive output pairs consistency -----------------------------------

    def test_nodes_sharing_outputs_have_exclusive_pair(self):
        """Every pair of nodes that produce the same output key must be
        declared in exclusive_output_pairs (or the validator would reject it).

        This is the inverse check: if two nodes share an output key and are
        NOT in exclusive_output_pairs, the graph would fail validation.
        """
        from collections import defaultdict

        output_producers: dict[str, list[str]] = defaultdict(list)
        for node in self.graph.nodes:
            for key in node.outputs:
                output_producers[key].append(node.name)

        for key, producers in output_producers.items():
            if len(producers) < 2:
                continue
            from itertools import combinations

            for a, b in combinations(producers, 2):
                pair = frozenset({a, b})
                assert pair in self.graph.exclusive_output_pairs, (
                    f"Nodes {sorted(pair)} both produce '{key}' but are not "
                    f"in exclusive_output_pairs"
                )

    def test_early_exit_routes_through_return_response(self):
        """Early exit path must include RETURN_RESPONSE for middleware and TurnCompleted."""
        # WINDOW_HISTORY -> RETURN_RESPONSE must be unconditional (no condition)
        wh_edges = [e for e in self.graph.edges if e.source == "WINDOW_HISTORY"]
        rr_edges = [e for e in wh_edges if e.target == "RETURN_RESPONSE"]
        assert len(rr_edges) == 1, (
            "WINDOW_HISTORY must have exactly one edge to RETURN_RESPONSE"
        )
        assert rr_edges[0].condition is None, (
            "WINDOW_HISTORY -> RETURN_RESPONSE must be unconditional"
        )

        # RETURN_RESPONSE -> SAVE_SESSION must exist (for early save)
        rr_out = [e for e in self.graph.edges if e.source == "RETURN_RESPONSE"]
        rr_save = [e for e in rr_out if e.target == "SAVE_SESSION"]
        assert len(rr_save) == 1, "RETURN_RESPONSE must have an edge to SAVE_SESSION"
        assert rr_save[0].condition is not None, (
            "RETURN_RESPONSE -> SAVE_SESSION must be conditional"
        )

        # WINDOW_HISTORY must NOT have a direct edge to SAVE_SESSION
        wh_save = [e for e in wh_edges if e.target == "SAVE_SESSION"]
        assert len(wh_save) == 0, (
            "WINDOW_HISTORY must not have a direct edge to SAVE_SESSION"
        )


# ---------------------------------------------------------------------------
# Integration tests: graph definition + run_turn through PhaseGraph
# ---------------------------------------------------------------------------


_MOCK_USAGE = TokenUsage(
    prompt_tokens=100, completion_tokens=50, total_tokens=150, cost_usd=0.001
)


def _mock_classify_conversational(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )


def _mock_chat_with_usage(messages, **kwargs):
    return "Hello from PhaseGraph!", _MOCK_USAGE


def _mock_extract(**kwargs):
    return CombinedExtractReflectResult(
        reflection_note="Conversational turn",
        confidence=0.5,
    )


class TestGraphDefinition:
    def test_graph_builds_and_validates(self):
        from memex.phase_graph.definition import build_memex_turn_graph

        graph = build_memex_turn_graph()
        assert len(graph.nodes) >= 25
        assert graph.entry_node == "LOAD_CONTEXT"

    def test_graph_passes_smp_validation(self):
        from memex.phase_graph.definition import build_memex_turn_graph
        from memex.phase_graph.smp_validator import validate_memex_turn_graph

        graph = build_memex_turn_graph()
        # validate_memex_turn_graph raises SMPValidationError on critical
        # violations, returns list of warnings otherwise.
        warnings = validate_memex_turn_graph(graph)
        assert isinstance(warnings, list)

    def test_build_prompt_declares_gather_inputs(self):
        from memex.phase_graph.definition import build_memex_turn_graph

        graph = build_memex_turn_graph()
        bp = graph.get_node("BUILD_PROMPT")
        expected = {
            "relevant_goals",
            "retrieved_knowledge",
            "memory_block_text",
            "documentation_text",
            "proactive_context",
            "available_tools",
            "governance",
            "partner_prompt",
            "agent_self_prompt",
        }
        assert bp.inputs >= expected

    def test_tool_loop_has_fallback(self):
        from memex.phase_graph.definition import build_memex_turn_graph

        graph = build_memex_turn_graph()
        fb = [e for e in graph.fallback_edges if e.source == "TOOL_LOOP"]
        assert len(fb) == 1, "TOOL_LOOP should have exactly one fallback edge"
        fb_target = fb[0].target
        cont = [
            e
            for e in graph.edges
            if e.source == fb_target and e.target == "WINDOW_HISTORY"
        ]
        assert len(cont) == 1


class TestRunTurnViaPhaseGraph:
    def test_run_turn_conversational(self, memory_store, tmp_path):
        with (
            patch("memex.classify.classify_input", _mock_classify_conversational),
            patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
            patch(
                "memex.memory.conversation_extract.extract_and_reflect", _mock_extract
            ),
        ):
            response, session = run_turn(
                "hello",
                memory_store,
                project_root=tmp_path,
            )

        assert response
        assert "Hello from PhaseGraph!" in response
        assert session is not None
        assert session.turn_count >= 1

    def test_run_turn_early_exit(self, memory_store, tmp_path):
        with (
            patch("memex.classify.classify_input", _mock_classify_conversational),
            patch(
                "memex.intent_frame.build_intent_frame",
                return_value=IntentFrame(
                    raw_input="Do that",
                    classification=InputClassificationType.CONVERSATIONAL,
                    summary="Clarify unresolved request",
                    selected_path=IntentFramePath.CLARIFY,
                    confidence=0.9,
                    rationale="need clarification",
                    unresolved_references=["that"],
                    missing_information=["what 'that' refers to"],
                    created_at=_utcnow(),
                ),
            ),
            patch("memex.llm.chat_with_usage") as mock_chat,
        ):
            response, session = run_turn(
                "Do that",
                memory_store,
                project_root=tmp_path,
            )

        assert response
        assert session is not None
        # Early exit should not call the main LLM
        mock_chat.assert_not_called()
