"""Tests for SkillMiddleware."""

from pathlib import Path
from unittest.mock import MagicMock

from memex.skills.loader import SkillDefinition
from memex.skills.middleware import SkillMiddleware
from memex.skills.registry import SkillRegistry
from memex.tools import ToolRegistry


def _skill(name: str, **kwargs) -> SkillDefinition:
    defaults = dict(
        description=f"Test {name}",
        version="1.0.0",
        body=f"Instructions for {name}",
        base_dir=Path("/tmp"),
    )
    defaults.update(kwargs)
    return SkillDefinition(name=name, **defaults)


def _make_middleware(skills=None, tools=None, **kwargs):
    sr = SkillRegistry()
    for s in skills or []:
        sr.register(s)
    tr = tools or ToolRegistry()
    return SkillMiddleware(sr, tr, **kwargs)


def test_get_skill_block_empty():
    mw = _make_middleware()
    assert mw.get_skill_block() == ""


def test_get_skill_block_single():
    mw = _make_middleware([_skill("my-skill")])
    block = mw.get_skill_block()
    assert "# Active Skills" in block
    assert "## Skill: my-skill" in block
    assert "Instructions for my-skill" in block


def test_get_skill_block_excludes_disabled():
    mw = _make_middleware(
        [
            _skill("visible"),
            _skill("hidden", disable_model_invocation=True),
        ]
    )
    block = mw.get_skill_block()
    assert "visible" in block
    assert "hidden" not in block


def test_get_skill_block_token_budget():
    big_body = "x" * 20000  # ~5000 tokens, exceeds default 4000
    mw = _make_middleware(
        [_skill("big", body=big_body)],
        max_tokens=4000,
    )
    block = mw.get_skill_block()
    assert block == ""


def test_get_skill_block_count_budget():
    skills = [_skill(f"s{i}") for i in range(15)]
    mw = _make_middleware(skills, max_count=3)
    block = mw.get_skill_block()
    # Should have at most 3 skills
    assert block.count("## Skill:") <= 3


def test_get_skill_block_relevance():
    skills = [
        _skill("deploy-release", description="deploy and release code"),
        _skill("weather-forecast", description="check weather forecast"),
    ]
    mw = _make_middleware(skills)
    block = mw.get_skill_block(user_input="deploy the release")
    # deploy-release should appear before weather
    deploy_pos = block.find("deploy-release")
    weather_pos = block.find("weather-forecast")
    if weather_pos != -1:
        assert deploy_pos < weather_pos


def test_before_tool_call_no_active_skill():
    mw = _make_middleware()
    session = MagicMock()
    session._active_skill = None
    args, blocked = mw.before_tool_call(session, "bash", {"command": "ls"})
    assert blocked is False


def test_before_tool_call_blocks_unlisted():
    skill = _skill("restricted", allowed_tools=["bash", "read_file"])
    mw = _make_middleware([skill])
    session = MagicMock()
    session._active_skill = skill
    args, blocked = mw.before_tool_call(session, "write_file", {"path": "/tmp/x"})
    assert blocked is True


def test_before_tool_call_allows_listed():
    skill = _skill("restricted", allowed_tools=["bash", "read_file"])
    mw = _make_middleware([skill])
    session = MagicMock()
    session._active_skill = skill
    args, blocked = mw.before_tool_call(session, "bash", {"command": "ls"})
    assert blocked is False


def test_before_tool_call_resolves_alias():
    skill = _skill("restricted", allowed_tools=["bash"])
    tr = ToolRegistry()
    tr.register_alias("exec", "bash")
    mw = _make_middleware([skill], tools=tr)
    session = MagicMock()
    session._active_skill = skill
    args, blocked = mw.before_tool_call(session, "exec", {"command": "ls"})
    assert blocked is False
