"""Contract tests for FathomStore — the fathomdb-backed storage layer.

TDD: these tests define the expected interface before implementation.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from memex.fathom_store import FathomStore
from memex.meetings.models import (
    MeetingExtractionRun,
    MeetingIntelligenceArtifact,
    MeetingRecord,
    MeetingRecording,
    MeetingState,
)
from memex.models import (
    Goal,
    GoalStatus,
    GoalPriority,
    ScheduledTask,
    ActionType,
    Notification,
    NotificationPriority,
    Item,
    ItemType,
    PromptControlArtifact,
    WorldModelAction,
    WorldModelActionPlan,
    WorldModelClaimEvaluation,
    WorldModelCommitment,
    WorldModelEntity,
    WorldModelEvent,
    WorldModelExecutionRecord,
    WorldModelGoal,
    WorldModelIntent,
    WorldModelKnowledgeEntityLink,
    WorldModelKnowledgeIngestRun,
    WorldModelKnowledgeObject,
    WorldModelKnowledgeRelationship,
    WorldModelObservation,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
    WorldModelSemanticMapping,
    WorldModelTask,
)
from memex.utcnow import utcnow


@pytest.fixture
def fstore(tmp_path):
    """Fresh FathomStore for each test."""
    db_path = str(tmp_path / "fathom.db")
    store = FathomStore.open(db_path)
    yield store
    store.close()


# ── 1a. Skeleton ──────────────────────────────────────────────────────


class TestFathomStoreLifecycle:
    """FathomStore can be opened, checked, and closed."""

    def test_open_creates_database(self, fstore, tmp_path):
        db = tmp_path / "fathom.db"
        assert db.exists()

    def test_check_integrity_clean(self, fstore):
        report = fstore.admin.check()
        assert report.physical_ok is True
        assert report.foreign_keys_ok is True

    def test_check_semantics_clean(self, fstore):
        report = fstore.admin.check_semantics()
        assert report.dangling_edges == 0
        assert report.orphaned_chunks == 0

    def test_close_is_idempotent(self, tmp_path):
        db_path = str(tmp_path / "close_test.db")
        store = FathomStore.open(db_path)
        store.close()
        store.close()  # should not raise

    def test_rebuild_projections_on_empty(self, fstore):
        report = fstore.admin.rebuild_projections()
        assert report is not None

    def test_path_property(self, fstore, tmp_path):
        assert fstore.path == str(tmp_path / "fathom.db")

    def test_builtin_embedder_not_degraded(self, fstore):
        """Trip-wire: confirm the wheel was built with --features default-embedder.

        Without that feature, ``embedder="builtin"`` silently degrades and every
        SearchRows returns ``was_degraded=True``. This test guards against a
        silent recall regression on wheel rebuilds — if a future wheel loses
        the feature, this fails loudly.

        Asserts on ``was_degraded == False`` rather than ``vector_hit_count >
        0`` because fathomdb 0.3.x only wires the builtin embedder into the
        read path; write-time vectors are written separately or not at all.
        The read-path embedder loading silently is the regression we care
        about here.
        """
        rows = (
            fstore.world_model._engine.nodes("WMGoal").search("anything", 5).execute()
        )
        assert rows.was_degraded is False


# ── 1b. Operational collections ──────────────────────────────────────


class TestSettingsCollection:
    """user_settings → latest_state collection."""

    def test_put_and_get(self, fstore):
        fstore.operational.put_setting("theme", "dark")
        assert fstore.operational.get_setting("theme") == "dark"

    def test_get_missing_returns_none(self, fstore):
        assert fstore.operational.get_setting("nonexistent") is None

    def test_put_overwrites(self, fstore):
        fstore.operational.put_setting("theme", "dark")
        fstore.operational.put_setting("theme", "light")
        assert fstore.operational.get_setting("theme") == "light"

    def test_list_settings(self, fstore):
        fstore.operational.put_setting("a", "1")
        fstore.operational.put_setting("b", "2")
        settings = fstore.operational.list_settings()
        assert len(settings) >= 2
        keys = {s["key"] for s in settings}
        assert keys >= {"a", "b"}

    def test_delete_setting(self, fstore):
        fstore.operational.put_setting("temp", "val")
        fstore.operational.delete_setting("temp")
        assert fstore.operational.get_setting("temp") is None


class TestConnectorHealthCollection:
    """connector_health → latest_state collection."""

    def test_put_and_get(self, fstore):
        fstore.operational.put_connector_health(
            "gmail", status="healthy", error=None, tools_discovered=3
        )
        row = fstore.operational.get_connector_health("gmail")
        assert row is not None
        assert row["status"] == "healthy"
        assert row["tools_discovered"] == 3

    def test_get_missing_returns_none(self, fstore):
        assert fstore.operational.get_connector_health("nope") is None

    def test_list_all(self, fstore):
        fstore.operational.put_connector_health("a", status="healthy")
        fstore.operational.put_connector_health("b", status="degraded")
        rows = fstore.operational.list_connector_health()
        names = {r["name"] for r in rows}
        assert names >= {"a", "b"}


class TestAuditLogCollection:
    """audit_log → append_only_log collection."""

    def test_append_and_list(self, fstore):
        fstore.operational.append_audit(
            connector="gmail",
            action="fetch_messages",
            granted=True,
            session_id="s1",
        )
        rows = fstore.operational.list_audit(limit=10)
        assert len(rows) >= 1
        assert rows[0]["connector"] == "gmail"

    def test_list_filtered_by_connector(self, fstore):
        fstore.operational.append_audit(connector="gmail", action="a1")
        fstore.operational.append_audit(connector="telegram", action="a2")
        rows = fstore.operational.list_audit(connector="gmail", limit=10)
        assert all(r["connector"] == "gmail" for r in rows)

    def test_list_empty(self, fstore):
        assert fstore.operational.list_audit(limit=10) == []


class TestHumanModelCollection:
    """human_model → latest_state collection (singleton)."""

    def test_put_and_get(self, fstore):
        profile = {"name": "Corey", "expertise": ["python"]}
        fstore.operational.put_human_model(profile)
        result = fstore.operational.get_human_model()
        assert result["name"] == "Corey"

    def test_get_empty_returns_none(self, fstore):
        assert fstore.operational.get_human_model() is None

    def test_overwrite(self, fstore):
        fstore.operational.put_human_model({"name": "A"})
        fstore.operational.put_human_model({"name": "B"})
        assert fstore.operational.get_human_model()["name"] == "B"


class TestSessionContextCollection:
    """session_context → latest_state collection (singleton)."""

    def test_put_and_get(self, fstore):
        ctx = {"session_id": "s1", "turns": 5}
        fstore.operational.put_session_context(ctx)
        result = fstore.operational.get_session_context()
        assert result["session_id"] == "s1"

    def test_get_empty_returns_none(self, fstore):
        assert fstore.operational.get_session_context() is None


class TestAutoIngestSourcesCollection:
    """auto_ingest_sources → latest_state collection."""

    def test_put_and_get(self, fstore):
        fstore.operational.put_auto_ingest_source(
            "gmail-main", {"type": "gmail", "enabled": True}
        )
        row = fstore.operational.get_auto_ingest_source("gmail-main")
        assert row is not None
        assert row["type"] == "gmail"

    def test_list(self, fstore):
        fstore.operational.put_auto_ingest_source("s1", {"type": "gmail"})
        fstore.operational.put_auto_ingest_source("s2", {"type": "rss"})
        rows = fstore.operational.list_auto_ingest_sources()
        assert len(rows) >= 2


class TestIntakeLogCollection:
    """intake_log → latest_state collection."""

    def test_put_and_get(self, fstore):
        fstore.operational.put_intake_log(
            "msg-123",
            source="telegram",
            status="received",
            action_type="message",
        )
        row = fstore.operational.get_intake_log("msg-123")
        assert row is not None
        assert row["source"] == "telegram"
        assert row["status"] == "received"

    def test_update_status(self, fstore):
        fstore.operational.put_intake_log("msg-1", source="telegram", status="received")
        fstore.operational.put_intake_log(
            "msg-1", source="telegram", status="processed"
        )
        row = fstore.operational.get_intake_log("msg-1")
        assert row["status"] == "processed"


class TestToolUsageStatsCollection:
    """tool_usage_stats → latest_state collection."""

    def test_record_and_get(self, fstore):
        fstore.operational.record_tool_usage("search_knowledge", "find")
        row = fstore.operational.get_tool_usage("search_knowledge", "find")
        assert row is not None
        assert row["call_count"] >= 1

    def test_increment(self, fstore):
        fstore.operational.record_tool_usage("search_knowledge", "find")
        fstore.operational.record_tool_usage("search_knowledge", "find")
        row = fstore.operational.get_tool_usage("search_knowledge", "find")
        assert row["call_count"] >= 2


class TestAgentSelfModelCollection:
    """agent_self_model → latest_state singleton collection."""

    def test_put_and_get_agent_self_model(self, fstore):
        model = {"agent_id": "memex", "capabilities": ["chat", "search"]}
        fstore.operational.put_agent_self_model(model)
        result = fstore.operational.get_agent_self_model()
        assert result["agent_id"] == "memex"

    def test_get_missing_returns_none(self, fstore):
        assert fstore.operational.get_agent_self_model() is None

    def test_put_overwrites(self, fstore):
        fstore.operational.put_agent_self_model({"version": 1})
        fstore.operational.put_agent_self_model({"version": 2})
        result = fstore.operational.get_agent_self_model()
        assert result["version"] == 2


# ── 1c. Conversation store ───────────────────────────────────────────


class TestConversationLog:
    """conversation_log → append_only_log collection."""

    def test_log_and_query(self, fstore):
        now = utcnow()
        fstore.conversation.log_turn(
            session_id="s1",
            role="human",
            content="Hello",
            timestamp=now,
        )
        turns = fstore.conversation.query(session_id="s1")
        assert len(turns) >= 1
        assert turns[0]["role"] == "human"
        assert turns[0]["content"] == "Hello"
        assert turns[0]["session_id"] == "s1"

    def test_query_by_session(self, fstore):
        now = utcnow()
        fstore.conversation.log_turn("s1", "human", "A", now)
        fstore.conversation.log_turn("s2", "human", "B", now)
        turns = fstore.conversation.query(session_id="s1")
        assert all(t["session_id"] == "s1" for t in turns)

    def test_query_limit(self, fstore):
        now = utcnow()
        for i in range(5):
            fstore.conversation.log_turn("s1", "human", f"msg-{i}", now)
        turns = fstore.conversation.query(session_id="s1", limit=3)
        assert len(turns) == 3

    def test_query_empty(self, fstore):
        assert fstore.conversation.query(session_id="none") == []

    def test_text_search(self, fstore):
        now = utcnow()
        fstore.conversation.log_turn("s1", "human", "budget review meeting", now)
        fstore.conversation.log_turn("s1", "assistant", "summary of the budget", now)
        fstore.conversation.log_turn("s1", "human", "what about lunch", now)
        results = fstore.conversation.search("budget", limit=10)
        assert len(results) >= 1
        assert any("budget" in r["content"].lower() for r in results)

    def test_search_empty(self, fstore):
        assert fstore.conversation.search("nonexistent", limit=10) == []

    def test_cleanup(self, fstore):
        now = utcnow()
        fstore.conversation.log_turn("s1", "human", "old message", now)
        # Cleanup everything before far future
        from datetime import timedelta

        future = now + timedelta(days=365)
        deleted = fstore.conversation.cleanup(before=future)
        assert deleted >= 1
        assert fstore.conversation.query(session_id="s1") == []

    def test_query_with_since(self, fstore):
        t1 = datetime(2026, 1, 1)
        t2 = datetime(2026, 6, 1)
        fstore.conversation.log_turn("s1", "human", "old", t1)
        fstore.conversation.log_turn("s1", "human", "new", t2)
        results = fstore.conversation.query(session_id="s1", since=datetime(2026, 3, 1))
        assert len(results) == 1
        assert results[0]["content"] == "new"

    def test_get_conversation_context(self, fstore):
        now = utcnow()
        lids = []
        for i in range(10):
            lid = fstore.conversation.log_turn("s1", "human", f"msg-{i}", now)
            lids.append(lid)
        ctx = fstore.conversation.get_conversation_context(lids[5], window=2)
        assert len(ctx) == 5  # 2 before + target + 2 after

    def test_get_conversation_context_missing(self, fstore):
        ctx = fstore.conversation.get_conversation_context("turn:nonexistent", window=2)
        assert ctx == []


# ── 2a. Goals repository ────────────────────────────────────────────


class TestGoalsRepository:
    """Goal graph nodes with parent-child and blocker edges."""

    def test_create_and_get(self, fstore):
        lid = fstore.goals.create("g1", "Ship v1", "Launch the MVP", "active", "high")
        assert lid == "goal:g1"
        goal = fstore.goals.get("g1")
        assert goal is not None
        assert isinstance(goal, Goal)
        assert goal.title == "Ship v1"
        assert goal.description == "Launch the MVP"
        assert goal.status == GoalStatus.ACTIVE
        assert goal.priority == GoalPriority.HIGH

    def test_get_missing_returns_none(self, fstore):
        assert fstore.goals.get("nonexistent") is None

    def test_list_all(self, fstore):
        fstore.goals.create("g1", "A", "", "active", "high")
        fstore.goals.create("g2", "B", "", "active", "low")
        goals = fstore.goals.list()
        assert len(goals) >= 2
        assert isinstance(goals[0], Goal)

    def test_list_filter_by_status(self, fstore):
        fstore.goals.create("g1", "A", "", "active", "high")
        fstore.goals.create("g2", "B", "", "completed", "low")
        active = fstore.goals.list(status="active")
        assert all(g.status == GoalStatus.ACTIVE for g in active)
        assert any(g.title == "A" for g in active)

    def test_list_limit(self, fstore):
        for i in range(5):
            fstore.goals.create(f"g{i}", f"Goal {i}", "", "active", "medium")
        goals = fstore.goals.list(limit=3)
        assert len(goals) == 3

    def test_update(self, fstore):
        fstore.goals.create("g1", "Draft", "desc", "active", "low")
        fstore.goals.update("g1", title="Final", priority="high")
        goal = fstore.goals.get("g1")
        assert goal.title == "Final"
        assert goal.priority == GoalPriority.HIGH
        # unchanged fields preserved
        assert goal.status == GoalStatus.ACTIVE
        assert goal.description == "desc"

    def test_parent_child_edge(self, fstore):
        fstore.goals.create("parent", "Parent Goal", "", "active", "high")
        fstore.goals.create(
            "child", "Child Goal", "", "active", "medium", parent_id="parent"
        )
        children = fstore.goals.get_children("parent")
        assert len(children) >= 1
        assert isinstance(children[0], Goal)
        assert any(c.title == "Child Goal" for c in children)

    def test_get_children_empty(self, fstore):
        fstore.goals.create("solo", "Solo", "", "active", "low")
        assert fstore.goals.get_children("solo") == []

    def test_create_with_metadata(self, fstore):
        fstore.goals.create(
            "g1",
            "Meta",
            "",
            "active",
            "low",
            metadata={"tags": ["work"], "source": "telegram"},
        )
        goal = fstore.goals.get("g1")
        assert goal.metadata == {"tags": ["work"], "source": "telegram"}

    def test_create_with_deadline(self, fstore):
        fstore.goals.create(
            "g1", "Deadline", "", "active", "high", deadline="2026-04-01"
        )
        goal = fstore.goals.get("g1")
        assert goal.deadline is not None
        assert goal.deadline.year == 2026
        assert goal.deadline.month == 4
        assert goal.deadline.day == 1

    def test_create_with_blocked_by(self, fstore):
        fstore.goals.create("blocker", "Blocker", "", "active", "high")
        fstore.goals.create(
            "blocked",
            "Blocked",
            "",
            "blocked",
            "medium",
            blocked_by_goal_id="blocker",
        )
        blocked = fstore.goals.get("blocked")
        assert blocked is not None
        assert blocked.status == GoalStatus.BLOCKED

    # ── Phase 2a: get_tree ──────────────────────────────────────────

    def test_get_tree_all_goals(self, fstore):
        fstore.goals.create("g1", "Root", "", "active", "high")
        fstore.goals.create("g2", "Child", "", "active", "medium", parent_id="g1")
        tree = fstore.goals.get_tree()
        assert len(tree) >= 2

    def test_get_tree_with_root(self, fstore):
        fstore.goals.create("root", "Root", "", "active", "high")
        fstore.goals.create(
            "child1", "Child 1", "", "active", "medium", parent_id="root"
        )
        fstore.goals.create("child2", "Child 2", "", "active", "low", parent_id="root")
        fstore.goals.create(
            "grandchild", "Grandchild", "", "active", "low", parent_id="child1"
        )
        fstore.goals.create("unrelated", "Unrelated", "", "active", "low")
        tree = fstore.goals.get_tree("root")
        ids = {g.goal_id for g in tree}
        assert "root" in ids
        assert "child1" in ids
        assert "child2" in ids
        assert "grandchild" in ids
        assert "unrelated" not in ids

    def test_get_tree_single_node(self, fstore):
        fstore.goals.create("solo", "Solo", "", "active", "low")
        tree = fstore.goals.get_tree("solo")
        assert len(tree) == 1
        assert tree[0].goal_id == "solo"

    def test_get_tree_missing_root(self, fstore):
        tree = fstore.goals.get_tree("nonexistent")
        assert tree == []

    # ── Phase 2a: get_stale_goals ───────────────────────────────────

    def test_get_stale_goals(self, fstore):
        fstore.goals.create("g1", "Old", "", "active", "high")
        fstore.goals.create("g2", "New", "", "active", "low")
        from datetime import timedelta

        future = utcnow() + timedelta(hours=1)
        stale = fstore.goals.get_stale_goals(future)
        assert len(stale) >= 2

    def test_get_stale_goals_excludes_completed(self, fstore):
        fstore.goals.create("g1", "Active", "", "active", "high")
        fstore.goals.create("g2", "Done", "", "completed", "low")
        from datetime import timedelta

        future = utcnow() + timedelta(hours=1)
        stale = fstore.goals.get_stale_goals(future)
        ids = {g.goal_id for g in stale}
        assert "g1" in ids
        assert "g2" not in ids

    def test_get_stale_goals_none_stale(self, fstore):
        fstore.goals.create("g1", "Fresh", "", "active", "high")
        from datetime import timedelta

        past = utcnow() - timedelta(hours=1)
        stale = fstore.goals.get_stale_goals(past)
        assert stale == []

    # ── Phase 2a: get_approaching_deadlines ─────────────────────────

    def test_get_approaching_deadlines(self, fstore):
        fstore.goals.create(
            "g1", "Urgent", "", "active", "high", deadline="2026-04-01T00:00:00+00:00"
        )
        fstore.goals.create(
            "g2", "Later", "", "active", "low", deadline="2027-01-01T00:00:00+00:00"
        )
        fstore.goals.create("g3", "No deadline", "", "active", "medium")
        horizon = datetime(2026, 6, 1)
        approaching = fstore.goals.get_approaching_deadlines(horizon)
        ids = {g.goal_id for g in approaching}
        assert "g1" in ids
        assert "g2" not in ids
        assert "g3" not in ids

    def test_get_approaching_deadlines_excludes_completed(self, fstore):
        fstore.goals.create(
            "g1", "Done", "", "completed", "high", deadline="2026-04-01T00:00:00+00:00"
        )
        horizon = datetime(2026, 6, 1)
        approaching = fstore.goals.get_approaching_deadlines(horizon)
        assert all(g.goal_id != "g1" for g in approaching)

    def test_get_approaching_deadlines_empty(self, fstore):
        fstore.goals.create(
            "g1", "Far away", "", "active", "low", deadline="2030-01-01T00:00:00+00:00"
        )
        horizon = datetime(2026, 6, 1)
        approaching = fstore.goals.get_approaching_deadlines(horizon)
        assert approaching == []

    # ── Phase 2a: goal-entity links ─────────────────────────────────

    def test_create_and_list_goal_entity_links(self, fstore):
        fstore.goals.create("g1", "Goal", "", "active", "high")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        edge_id = fstore.goals.create_goal_entity_link("g1", "e1", "owner")
        assert edge_id.startswith("edge:goal_entity_link:")
        links = fstore.goals.list_goal_entity_links("g1")
        assert len(links) >= 1
        assert any(
            d.get("entity_id") == "e1" or d.get("display_name") == "Alice"
            for d in links
        )

    def test_list_goal_entity_links_empty(self, fstore):
        fstore.goals.create("g1", "Solo Goal", "", "active", "low")
        links = fstore.goals.list_goal_entity_links("g1")
        assert links == []

    def test_create_goal_entity_link_default_relationship(self, fstore):
        fstore.goals.create("g1", "Goal", "", "active", "high")
        fstore.world_model.upsert_entity("e1", "partner", "Bob")
        edge_id = fstore.goals.create_goal_entity_link("g1", "e1")
        assert "goal_entity_link" in edge_id

    # ── Phase 2a: meeting-goal links ────────────────────────────────

    def test_create_and_list_meeting_goal_links(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.goals.create("g1", "Ship v1", "", "active", "high")
        edge_id = fstore.goals.create_meeting_goal_link("m1", "g1", "discussed")
        assert edge_id.startswith("edge:meeting_goal_link:")
        links = fstore.goals.list_meeting_goal_links("m1")
        assert len(links) >= 1
        assert any(
            d.get("goal_id") == "g1" or d.get("title") == "Ship v1" for d in links
        )

    def test_list_meeting_goal_links_empty(self, fstore):
        fstore.meetings.create_meeting("m1", "Solo Meeting")
        links = fstore.goals.list_meeting_goal_links("m1")
        assert links == []

    def test_create_meeting_goal_link_default_relationship(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.goals.create("g1", "Goal", "", "active", "high")
        edge_id = fstore.goals.create_meeting_goal_link("m1", "g1")
        assert "meeting_goal_link" in edge_id

    # ── Phase 5: list_goals_for_entity (reverse lookup) ───────────

    def test_list_goals_for_entity(self, fstore):
        fstore.goals.create("g1", "Goal A", "", "active", "high")
        fstore.goals.create("g2", "Goal B", "", "active", "low")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.goals.create_goal_entity_link("g1", "e1", "owner")
        fstore.goals.create_goal_entity_link("g2", "e1", "contributor")
        goals = fstore.goals.list_goals_for_entity("e1")
        assert len(goals) >= 2
        titles = {d.get("title") for d in goals}
        assert "Goal A" in titles
        assert "Goal B" in titles

    def test_list_goals_for_entity_empty(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Nobody")
        goals = fstore.goals.list_goals_for_entity("e1")
        assert goals == []

    # ── Phase 5: meeting-entity links ──────────────────────────────

    def test_create_and_list_meeting_entity_links(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        edge_id = fstore.goals.create_meeting_entity_link("m1", "e1", "attendee")
        assert edge_id.startswith("edge:meeting_entity_link:")
        links = fstore.goals.list_meeting_entity_links("m1")
        assert len(links) >= 1
        assert any(
            d.get("entity_id") == "e1" or d.get("display_name") == "Alice"
            for d in links
        )

    def test_list_meeting_entity_links_empty(self, fstore):
        fstore.meetings.create_meeting("m1", "Solo Meeting")
        links = fstore.goals.list_meeting_entity_links("m1")
        assert links == []

    def test_create_meeting_entity_link_default_relationship(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.world_model.upsert_entity("e1", "partner", "Bob")
        edge_id = fstore.goals.create_meeting_entity_link("m1", "e1")
        assert "meeting_entity_link" in edge_id

    # ── Phase 5: calendar events ───────────────────────────────────

    def test_upsert_and_list_calendar_events(self, fstore):
        fstore.goals.upsert_calendar_event(
            "evt1",
            "google",
            "Team Standup",
            "2026-04-01T09:00:00+00:00",
            ends_at="2026-04-01T09:30:00+00:00",
            attendees=["alice", "bob"],
        )
        fstore.goals.upsert_calendar_event(
            "evt2",
            "google",
            "Later Meeting",
            "2026-06-01T10:00:00+00:00",
        )
        events = fstore.goals.list_upcoming_calendar_events("2026-05-01T00:00:00+00:00")
        assert len(events) == 1
        assert events[0]["title"] == "Team Standup"
        assert events[0]["event_id"] == "evt1"

    def test_upsert_calendar_event_idempotent(self, fstore):
        fstore.goals.upsert_calendar_event(
            "evt1",
            "google",
            "Original Title",
            "2026-04-01T09:00:00+00:00",
        )
        fstore.goals.upsert_calendar_event(
            "evt1",
            "google",
            "Updated Title",
            "2026-04-01T09:00:00+00:00",
        )
        events = fstore.goals.list_upcoming_calendar_events("2026-05-01T00:00:00+00:00")
        assert len(events) == 1
        assert events[0]["title"] == "Updated Title"

    def test_list_upcoming_calendar_events_empty(self, fstore):
        events = fstore.goals.list_upcoming_calendar_events("2026-01-01T00:00:00+00:00")
        assert events == []

    def test_calendar_event_with_metadata(self, fstore):
        fstore.goals.upsert_calendar_event(
            "evt1",
            "google",
            "Planning",
            "2026-04-01T09:00:00+00:00",
            metadata={"location": "Room 3"},
        )
        events = fstore.goals.list_upcoming_calendar_events("2026-05-01T00:00:00+00:00")
        assert events[0].get("metadata", {}).get("location") == "Room 3"


class TestToolUsageStatsExtended:
    """Extended tool usage stats tests for get_tool_usage_stats."""

    def test_get_all_tool_usage_stats(self, fstore):
        fstore.operational.record_tool_usage("search_knowledge", "find")
        fstore.operational.record_tool_usage("read_file", "open")
        stats = fstore.operational.get_tool_usage_stats()
        assert len(stats) >= 2
        tool_names = {s["tool_name"] for s in stats}
        assert "search_knowledge" in tool_names
        assert "read_file" in tool_names

    def test_get_tool_usage_stats_filtered(self, fstore):
        fstore.operational.record_tool_usage("search_knowledge", "find")
        fstore.operational.record_tool_usage("search_knowledge", "lookup")
        fstore.operational.record_tool_usage("read_file", "open")
        stats = fstore.operational.get_tool_usage_stats(tool_name="search_knowledge")
        assert all(s["tool_name"] == "search_knowledge" for s in stats)
        assert len(stats) >= 2

    def test_get_tool_usage_stats_empty(self, fstore):
        stats = fstore.operational.get_tool_usage_stats()
        assert stats == []

    def test_get_tool_usage_stats_no_match(self, fstore):
        fstore.operational.record_tool_usage("search_knowledge", "find")
        stats = fstore.operational.get_tool_usage_stats(tool_name="nonexistent")
        assert stats == []


# ── 2b. Scheduler repository ────────────────────────────────────────


class TestSchedulerRepository:
    """Scheduler tasks and runs as graph nodes."""

    def test_create_task_and_get(self, fstore):
        lid = fstore.scheduler.create_task(
            "daily-digest", "Daily Digest", "0 8 * * *", "notification"
        )
        assert lid == "task:daily-digest"
        task = fstore.scheduler.get_task("daily-digest")
        assert task is not None
        assert isinstance(task, ScheduledTask)
        assert task.name == "Daily Digest"
        assert task.cron_expr == "0 8 * * *"
        assert task.action_type == ActionType.NOTIFICATION
        assert task.enabled is True

    def test_get_task_missing(self, fstore):
        assert fstore.scheduler.get_task("nope") is None

    def test_list_tasks(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.create_task("t2", "T2", "* * * * *", "prompt", enabled=False)
        tasks = fstore.scheduler.list_tasks()
        assert len(tasks) >= 2
        assert isinstance(tasks[0], ScheduledTask)

    def test_list_tasks_enabled_only(self, fstore):
        fstore.scheduler.create_task(
            "t1", "T1", "* * * * *", "notification", enabled=True
        )
        fstore.scheduler.create_task("t2", "T2", "* * * * *", "prompt", enabled=False)
        enabled = fstore.scheduler.list_tasks(enabled_only=True)
        assert all(t.enabled is True for t in enabled)
        assert any(t.name == "T1" for t in enabled)

    def test_toggle_task(self, fstore):
        fstore.scheduler.create_task(
            "t1", "T1", "* * * * *", "notification", enabled=True
        )
        fstore.scheduler.toggle_task("t1", False)
        task = fstore.scheduler.get_task("t1")
        assert task.enabled is False
        fstore.scheduler.toggle_task("t1", True)
        task = fstore.scheduler.get_task("t1")
        assert task.enabled is True

    def test_create_task_with_action_data(self, fstore):
        fstore.scheduler.create_task(
            "t1",
            "T1",
            "* * * * *",
            "callable",
            action_data={"url": "https://example.com"},
        )
        task = fstore.scheduler.get_task("t1")
        assert task.action_data == {"url": "https://example.com"}

    def test_create_builtin_task(self, fstore):
        fstore.scheduler.create_task(
            "t1", "Builtin", "* * * * *", "notification", builtin=True
        )
        task = fstore.scheduler.get_task("t1")
        assert task.builtin is True

    def test_record_and_get_run(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = fstore.scheduler.record_run("t1")
        assert run_id.startswith("run:")
        runs = fstore.scheduler.get_runs("t1")
        assert len(runs) >= 1
        assert runs[0]["status"] == "queued"
        assert runs[0]["task_id"] == "t1"

    def test_complete_run(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = fstore.scheduler.record_run("t1")
        fstore.scheduler.complete_run(run_id, status="completed", result="ok")
        runs = fstore.scheduler.get_runs("t1")
        completed = [r for r in runs if r["status"] == "completed"]
        assert len(completed) >= 1
        assert completed[0]["result"] == "ok"

    def test_complete_run_with_error(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = fstore.scheduler.record_run("t1")
        fstore.scheduler.complete_run(run_id, status="failed", error="timeout")
        runs = fstore.scheduler.get_runs("t1")
        failed = [r for r in runs if r["status"] == "failed"]
        assert len(failed) >= 1
        assert failed[0]["error"] == "timeout"

    def test_get_runs_limit(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        for _ in range(5):
            fstore.scheduler.record_run("t1")
        runs = fstore.scheduler.get_runs("t1", limit=3)
        assert len(runs) == 3

    def test_get_runs_empty(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        assert fstore.scheduler.get_runs("t1") == []

    # ── Phase 2b: update_task ───────────────────────────────────────

    def test_update_task(self, fstore):
        fstore.scheduler.create_task("t1", "Draft", "0 8 * * *", "notification")
        updated = fstore.scheduler.update_task(
            "t1", name="Final", cron_expr="0 9 * * *"
        )
        assert isinstance(updated, ScheduledTask)
        assert updated.name == "Final"
        assert updated.cron_expr == "0 9 * * *"
        # unchanged fields preserved
        assert updated.action_type == ActionType.NOTIFICATION

    def test_update_task_missing_raises(self, fstore):
        with pytest.raises(KeyError):
            fstore.scheduler.update_task("nonexistent", name="X")

    # ── Phase 2b: record_adhoc_run ──────────────────────────────────

    def test_record_adhoc_run(self, fstore):
        run_id = fstore.scheduler.record_adhoc_run(
            "notification", {"message": "hello"}, priority=3, max_retries=5
        )
        assert run_id.startswith("run:")
        # Verify it's in queued runs
        queued = fstore.scheduler.get_queued_runs()
        assert len(queued) >= 1
        match = [r for r in queued if r["logical_id"] == run_id]
        assert len(match) == 1
        assert match[0]["action_type"] == "notification"
        assert match[0]["priority"] == 3
        assert match[0]["max_retries"] == 5
        assert match[0]["task_id"] is None

    # ── Phase 2b: get_queued_runs ───────────────────────────────────

    def test_get_queued_runs_excludes_no_action_type(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")  # has no action_type
        fstore.scheduler.record_adhoc_run("prompt", {"q": "test"})
        queued = fstore.scheduler.get_queued_runs()
        # Only the adhoc run should appear (it has action_type)
        assert all(r.get("action_type") is not None for r in queued)

    def test_get_queued_runs_empty(self, fstore):
        assert fstore.scheduler.get_queued_runs() == []

    # ── Phase 2b: cleanup_stale_runs ────────────────────────────────

    def test_cleanup_stale_runs(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = fstore.scheduler.record_run("t1")
        # Manually set status to "running"
        fstore.scheduler.complete_run(run_id, status="running")
        count = fstore.scheduler.cleanup_stale_runs()
        assert count >= 1
        # Verify the run is now "failed"
        all_runs = fstore.scheduler.get_all_runs()
        running_runs = [r for r in all_runs if r.get("status") == "running"]
        assert len(running_runs) == 0

    def test_cleanup_stale_runs_none(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        count = fstore.scheduler.cleanup_stale_runs()
        assert count == 0

    # ── Phase 2b: seed_builtins ─────────────────────────────────────

    def test_seed_builtins_creates(self, fstore):
        tasks = [
            {
                "task_id": "digest",
                "name": "Daily Digest",
                "cron_expr": "0 8 * * *",
                "action_type": "notification",
            },
            {
                "task_id": "cleanup",
                "name": "Cleanup",
                "cron_expr": "0 0 * * *",
                "action_type": "callable",
            },
        ]
        created = fstore.scheduler.seed_builtins(tasks)
        assert created == 2
        assert fstore.scheduler.get_task("digest") is not None
        assert fstore.scheduler.get_task("cleanup") is not None

    def test_seed_builtins_skips_existing(self, fstore):
        fstore.scheduler.create_task(
            "digest", "Old Digest", "0 7 * * *", "notification"
        )
        tasks = [
            {
                "task_id": "digest",
                "name": "New Digest",
                "cron_expr": "0 8 * * *",
                "action_type": "notification",
            },
            {
                "task_id": "cleanup",
                "name": "Cleanup",
                "cron_expr": "0 0 * * *",
                "action_type": "callable",
            },
        ]
        created = fstore.scheduler.seed_builtins(tasks)
        assert created == 1  # only cleanup created
        # Original task preserved
        task = fstore.scheduler.get_task("digest")
        assert task.name == "Old Digest"

    # ── Phase 2b: get_last_run ──────────────────────────────────────

    def test_get_last_run(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.record_run("t1")
        last = fstore.scheduler.get_last_run("t1")
        assert last is not None
        assert last["task_id"] == "t1"

    def test_get_last_run_empty(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        assert fstore.scheduler.get_last_run("t1") is None

    # ── Phase 2b: get_all_runs ──────────────────────────────────────

    def test_get_all_runs(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.create_task("t2", "T2", "* * * * *", "prompt")
        fstore.scheduler.record_run("t1")
        fstore.scheduler.record_run("t2")
        all_runs = fstore.scheduler.get_all_runs()
        assert len(all_runs) >= 2

    def test_get_all_runs_empty(self, fstore):
        assert fstore.scheduler.get_all_runs() == []

    def test_get_all_runs_limit(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        for _ in range(5):
            fstore.scheduler.record_run("t1")
        runs = fstore.scheduler.get_all_runs(limit=3)
        assert len(runs) == 3

    # ── Phase 2b: get_runs_by_action_type ───────────────────────────

    def test_get_runs_by_action_type(self, fstore):
        fstore.scheduler.record_adhoc_run("notification", {"msg": "a"})
        fstore.scheduler.record_adhoc_run("prompt", {"q": "b"})
        fstore.scheduler.record_adhoc_run("notification", {"msg": "c"})
        notif_runs = fstore.scheduler.get_runs_by_action_type("notification")
        assert len(notif_runs) >= 2
        assert all(r["action_type"] == "notification" for r in notif_runs)

    def test_get_runs_by_action_type_empty(self, fstore):
        assert fstore.scheduler.get_runs_by_action_type("nonexistent") == []

    # ── Phase 2b: update_run_status ─────────────────────────────────

    def test_update_run_status(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        run_id = fstore.scheduler.record_run("t1")
        fstore.scheduler.update_run_status(run_id, "running", attempt=1)
        all_runs = fstore.scheduler.get_all_runs()
        match = [r for r in all_runs if r["logical_id"] == run_id]
        assert len(match) == 1
        assert match[0]["status"] == "running"
        assert match[0]["attempt"] == 1

    def test_update_run_status_missing_raises(self, fstore):
        with pytest.raises(KeyError):
            fstore.scheduler.update_run_status("run:nonexistent", "failed")

    # ── Phase 2b: list_tasks_for_goal ───────────────────────────────

    def test_list_tasks_for_goal(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        fstore.scheduler.update_task("t1", goal_id="g1")
        fstore.scheduler.create_task("t2", "T2", "* * * * *", "prompt")
        fstore.scheduler.update_task("t2", goal_id="g1")
        fstore.scheduler.create_task("t3", "T3", "* * * * *", "callable")
        fstore.scheduler.update_task("t3", goal_id="g2")
        tasks = fstore.scheduler.list_tasks_for_goal("g1")
        assert len(tasks) >= 2
        assert all(isinstance(t, ScheduledTask) for t in tasks)
        ids = {t.task_id for t in tasks}
        assert "t1" in ids
        assert "t2" in ids
        assert "t3" not in ids

    def test_list_tasks_for_goal_empty(self, fstore):
        fstore.scheduler.create_task("t1", "T1", "* * * * *", "notification")
        tasks = fstore.scheduler.list_tasks_for_goal("nonexistent")
        assert tasks == []


# ── 2c. Notifications repository ────────────────────────────────────


class TestNotificationsRepository:
    """Notification graph nodes."""

    def test_create_and_get(self, fstore):
        lid = fstore.notifications.create(
            "n1",
            "New message",
            body="Hello world",
            priority="high",
        )
        assert lid == "notification:n1"
        notif = fstore.notifications.get("n1")
        assert notif is not None
        assert isinstance(notif, Notification)
        assert notif.title == "New message"
        assert notif.body == "Hello world"
        assert notif.priority == NotificationPriority.HIGH
        assert notif.read_at is None
        assert notif.dismissed_at is None

    def test_get_missing(self, fstore):
        assert fstore.notifications.get("nope") is None

    def test_list_pending(self, fstore):
        fstore.notifications.create("n1", "A")
        fstore.notifications.create("n2", "B")
        pending = fstore.notifications.list_pending()
        assert len(pending) >= 2
        assert isinstance(pending[0], Notification)

    def test_list_pending_excludes_read(self, fstore):
        fstore.notifications.create("n1", "Read One")
        fstore.notifications.create("n2", "Unread One")
        fstore.notifications.mark_read("n1")
        pending = fstore.notifications.list_pending()
        ids = [n.notification_id for n in pending]
        assert "n1" not in ids
        assert "n2" in ids

    def test_list_pending_excludes_dismissed(self, fstore):
        fstore.notifications.create("n1", "Dismissed")
        fstore.notifications.create("n2", "Active")
        fstore.notifications.dismiss("n1")
        pending = fstore.notifications.list_pending()
        ids = [n.notification_id for n in pending]
        assert "n1" not in ids
        assert "n2" in ids

    def test_list_pending_limit(self, fstore):
        for i in range(5):
            fstore.notifications.create(f"n{i}", f"Notif {i}")
        pending = fstore.notifications.list_pending(limit=3)
        assert len(pending) == 3

    def test_mark_read(self, fstore):
        fstore.notifications.create("n1", "Test")
        fstore.notifications.mark_read("n1")
        notif = fstore.notifications.get("n1")
        assert notif.read_at is not None

    def test_dismiss(self, fstore):
        fstore.notifications.create("n1", "Test")
        fstore.notifications.dismiss("n1")
        notif = fstore.notifications.get("n1")
        assert notif.dismissed_at is not None

    def test_create_with_source(self, fstore):
        fstore.notifications.create("n1", "Test", source="telegram")
        notif = fstore.notifications.get("n1")
        assert notif.source == "telegram"

    def test_create_with_goal_id(self, fstore):
        fstore.notifications.create("n1", "Goal alert", goal_id="g1")
        notif = fstore.notifications.get("n1")
        assert notif.goal_id == "g1"

    def test_create_with_action(self, fstore):
        fstore.notifications.create(
            "n1",
            "Action",
            action_type="open_url",
            action_data={"url": "https://example.com"},
        )
        notif = fstore.notifications.get("n1")
        assert notif.action_type == "open_url"
        assert notif.action_data == {"url": "https://example.com"}


# ── 3a. Meetings repository ────────────────────────────────────────


class TestMeetingsRepository:
    """Meeting graph nodes with recordings, artifacts, and extraction runs."""

    def test_create_and_get_meeting(self, fstore):
        lid = fstore.meetings.create_meeting("m1", "Standup")
        assert lid == "meeting:m1"
        m = fstore.meetings.get_meeting("m1")
        assert m is not None
        assert isinstance(m, MeetingRecord)
        assert m.title == "Standup"
        assert m.state == MeetingState.CREATED

    def test_get_meeting_missing(self, fstore):
        assert fstore.meetings.get_meeting("nope") is None

    def test_create_meeting_with_all_fields(self, fstore):
        fstore.meetings.create_meeting(
            "m1",
            "Sprint Review",
            state="scheduled",
            attendees=["alice", "bob"],
            notes="Quarterly review",
            scheduled_for="2026-04-01T10:00:00Z",
        )
        m = fstore.meetings.get_meeting("m1")
        assert isinstance(m, MeetingRecord)
        # "scheduled" is not a MeetingState member — kept as raw string
        assert m.attendees == ["alice", "bob"]
        assert m.notes == "Quarterly review"
        assert m.scheduled_for == datetime.fromisoformat("2026-04-01T10:00:00+00:00")

    def test_update_meeting(self, fstore):
        fstore.meetings.create_meeting("m1", "Draft")
        fstore.meetings.update_meeting("m1", title="Final", state="active")
        m = fstore.meetings.get_meeting("m1")
        assert isinstance(m, MeetingRecord)
        assert m.title == "Final"
        assert m.state == "active"

    def test_list_meetings(self, fstore):
        fstore.meetings.create_meeting("m1", "A")
        fstore.meetings.create_meeting("m2", "B")
        meetings = fstore.meetings.list_meetings()
        assert len(meetings) >= 2

    def test_list_meetings_filter_by_state(self, fstore):
        fstore.meetings.create_meeting("m1", "A", state="active")
        fstore.meetings.create_meeting("m2", "B", state="completed")
        active = fstore.meetings.list_meetings(state="active")
        assert all(m.state == "active" for m in active)
        assert any(m.title == "A" for m in active)

    def test_list_meetings_limit(self, fstore):
        for i in range(5):
            fstore.meetings.create_meeting(f"m{i}", f"Meeting {i}")
        meetings = fstore.meetings.list_meetings(limit=3)
        assert len(meetings) == 3

    def test_create_and_get_recording(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        lid = fstore.meetings.create_recording("r1", "m1")
        assert lid == "recording:r1"
        rec = fstore.meetings.get_recording("r1")
        assert rec is not None
        assert isinstance(rec, MeetingRecording)
        assert rec.state == MeetingState.RECORDING
        assert rec.sample_rate == 16000
        assert rec.sequence_number == 1

    def test_update_recording(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1")
        fstore.meetings.update_recording("r1", state="completed", duration_seconds=120)
        rec = fstore.meetings.get_recording("r1")
        assert isinstance(rec, MeetingRecording)
        assert rec.state == "completed"
        assert rec.duration_seconds == 120

    def test_list_recordings(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1")
        fstore.meetings.create_recording("r2", "m1", sequence_number=2)
        recs = fstore.meetings.list_recordings("m1")
        assert len(recs) >= 2

    def test_create_and_list_artifacts(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_artifact(
            "a1", "m1", "transcript", title="Full transcript", content="Hello world"
        )
        fstore.meetings.create_artifact(
            "a2", "m1", "summary", title="Meeting summary", content="We discussed X"
        )
        arts = fstore.meetings.list_artifacts("m1")
        assert len(arts) >= 2
        assert all(isinstance(a, MeetingIntelligenceArtifact) for a in arts)
        types = {a.artifact_type for a in arts}
        assert "transcript" in types
        assert "summary" in types

    def test_list_artifacts_filter_by_type(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_artifact("a1", "m1", "transcript")
        fstore.meetings.create_artifact("a2", "m1", "summary")
        transcripts = fstore.meetings.list_artifacts("m1", artifact_type="transcript")
        assert all(a.artifact_type == "transcript" for a in transcripts)

    def test_create_extraction_run_and_complete(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        lid = fstore.meetings.create_extraction_run(
            "er1", "m1", "transcribe", model="whisper-1"
        )
        assert lid == "extraction_run:er1"
        fstore.meetings.complete_extraction_run(
            "er1", status="completed", artifact_count=3
        )
        # Verify via direct node query — extraction runs are linked via HAS_EXTRACTION
        runs = (
            fstore.engine.nodes("MeetingExtractionRun")
            .filter_logical_id_eq("extraction_run:er1")
            .limit(1)
            .execute()
        )
        assert len(runs.nodes) == 1
        props = runs.nodes[0].properties
        assert props["status"] == "completed"
        assert props["artifact_count"] == 3

    def test_delete_meeting(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1")
        fstore.meetings.create_artifact("a1", "m1", "transcript")
        fstore.meetings.create_extraction_run("er1", "m1", "transcribe")
        fstore.meetings.delete_meeting("m1")
        assert fstore.meetings.get_meeting("m1") is None

    def test_create_artifact_with_recording_and_speaker(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1")
        fstore.meetings.create_artifact(
            "a1",
            "m1",
            "transcript",
            recording_id="r1",
            speaker="alice",
            payload={"confidence": 0.95},
        )
        arts = fstore.meetings.list_artifacts("m1")
        assert len(arts) >= 1
        art = [a for a in arts if a.artifact_id == "a1"][0]
        assert isinstance(art, MeetingIntelligenceArtifact)
        assert art.recording_id == "r1"
        assert art.speaker == "alice"
        assert art.payload == {"confidence": 0.95}

    # ── Phase 2c: additional MeetingsRepository methods ─────────────

    def test_get_active_recording(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1", state="recording")
        fstore.meetings.create_recording(
            "r2", "m1", state="completed", sequence_number=2
        )
        active = fstore.meetings.get_active_recording("m1")
        assert active is not None
        assert isinstance(active, MeetingRecording)
        assert active.recording_id == "r1"
        assert active.state == MeetingState.RECORDING

    def test_get_active_recording_none(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1", state="completed")
        assert fstore.meetings.get_active_recording("m1") is None

    def test_get_active_recording_no_recordings(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        assert fstore.meetings.get_active_recording("m1") is None

    def test_list_upcoming_meetings(self, fstore):
        fstore.meetings.create_meeting(
            "m1",
            "Past",
            state="completed",
            scheduled_for="2026-01-01T10:00:00Z",
        )
        fstore.meetings.create_meeting(
            "m2",
            "Upcoming",
            state="created",
            scheduled_for="2026-04-01T10:00:00Z",
        )
        fstore.meetings.create_meeting(
            "m3",
            "Far Future",
            state="created",
            scheduled_for="2027-01-01T10:00:00Z",
        )
        upcoming = fstore.meetings.list_upcoming_meetings("2026-06-01T00:00:00Z")
        titles = [m.title for m in upcoming]
        assert "Upcoming" in titles
        assert "Past" not in titles  # state is "completed"
        assert "Far Future" not in titles  # beyond horizon

    def test_list_upcoming_meetings_empty(self, fstore):
        fstore.meetings.create_meeting("m1", "Active", state="active")
        upcoming = fstore.meetings.list_upcoming_meetings("2026-12-31T00:00:00Z")
        assert upcoming == []

    def test_list_extraction_runs(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_extraction_run("er1", "m1", "transcribe")
        fstore.meetings.create_extraction_run("er2", "m1", "summarize")
        runs = fstore.meetings.list_extraction_runs("m1")
        assert len(runs) >= 2
        assert all(isinstance(r, MeetingExtractionRun) for r in runs)
        run_types = {r.run_type for r in runs}
        assert "transcribe" in run_types
        assert "summarize" in run_types

    def test_list_extraction_runs_empty(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        assert fstore.meetings.list_extraction_runs("m1") == []

    def test_get_latest_recording(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        fstore.meetings.create_recording("r1", "m1", sequence_number=1)
        fstore.meetings.create_recording("r2", "m1", sequence_number=3)
        fstore.meetings.create_recording("r3", "m1", sequence_number=2)
        latest = fstore.meetings.get_latest_recording("m1")
        assert latest is not None
        assert isinstance(latest, MeetingRecording)
        assert latest.sequence_number == 3
        assert latest.recording_id == "r2"

    def test_get_latest_recording_none(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        assert fstore.meetings.get_latest_recording("m1") is None

    def test_next_recording_sequence(self, fstore):
        fstore.meetings.create_meeting("m1", "Standup")
        assert fstore.meetings.next_recording_sequence("m1") == 1
        fstore.meetings.create_recording("r1", "m1", sequence_number=1)
        assert fstore.meetings.next_recording_sequence("m1") == 2
        fstore.meetings.create_recording("r2", "m1", sequence_number=2)
        assert fstore.meetings.next_recording_sequence("m1") == 3

    def test_cleanup_stale_recordings(self, fstore):
        fstore.meetings.create_meeting("m1", "A")
        fstore.meetings.create_meeting("m2", "B")
        fstore.meetings.create_recording("r1", "m1", state="recording")
        fstore.meetings.create_recording(
            "r2", "m1", state="completed", sequence_number=2
        )
        fstore.meetings.create_recording("r3", "m2", state="recording")
        count = fstore.meetings.cleanup_stale_recordings()
        assert count == 2
        # Both should now be "failed"
        r1 = fstore.meetings.get_recording("r1")
        assert r1.state == MeetingState.FAILED
        r3 = fstore.meetings.get_recording("r3")
        assert r3.state == MeetingState.FAILED
        # r2 should still be "completed"
        r2 = fstore.meetings.get_recording("r2")
        assert r2.state == "completed"

    def test_cleanup_stale_recordings_none(self, fstore):
        fstore.meetings.create_meeting("m1", "A")
        fstore.meetings.create_recording("r1", "m1", state="completed")
        assert fstore.meetings.cleanup_stale_recordings() == 0


# ── 4a. Knowledge repository ──────────────────────────────────────


class TestKnowledgeRepository:
    """Knowledge graph: items, sources, links, trails, and forget/restore/purge lifecycle."""

    def test_ingest_and_get(self, fstore):
        lid = fstore.knowledge.ingest(
            "k1",
            "Python Tips",
            "Use list comprehensions for speed",
            "article",
            source_url="https://example.com/py",
            author="alice",
            tags=["python", "performance"],
        )
        assert lid == "item:k1"
        item = fstore.knowledge.get("k1")
        assert item is not None
        assert isinstance(item, Item)
        assert item.title == "Python Tips"
        assert item.body == "Use list comprehensions for speed"
        assert item.type == ItemType.ARTICLE
        assert item.source_url == "https://example.com/py"
        assert item.author == "alice"
        assert item.tags == ["python", "performance"]

    def test_get_missing_returns_none(self, fstore):
        assert fstore.knowledge.get("nonexistent") is None

    def test_ingest_with_defaults(self, fstore):
        fstore.knowledge.ingest("k1", "Simple", "Body text", "note")
        item = fstore.knowledge.get("k1")
        assert item is not None
        assert item.pinned is False

    def test_ingest_pinned(self, fstore):
        fstore.knowledge.ingest("k1", "Pinned", "Body", "note", pinned=True)
        item = fstore.knowledge.get("k1")
        assert item.pinned is True

    def test_update_body_replaces_chunk(self, fstore):
        fstore.knowledge.ingest("k1", "Title", "old body", "article")
        fstore.knowledge.update("k1", body="new body content")
        item = fstore.knowledge.get("k1")
        assert item.body == "new body content"
        # FTS should find the new body
        results = fstore.knowledge.search("new body content")
        assert any(r.item_id == "k1" for r in results)

    def test_update_title_only(self, fstore):
        fstore.knowledge.ingest("k1", "Old Title", "body text", "article")
        fstore.knowledge.update("k1", title="New Title")
        item = fstore.knowledge.get("k1")
        assert item.title == "New Title"
        assert item.body == "body text"

    def test_list_all(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body a", "article")
        fstore.knowledge.ingest("k2", "B", "body b", "note")
        items = fstore.knowledge.list()
        assert len(items) >= 2
        assert isinstance(items[0], Item)

    def test_list_filter_by_type(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body", "article")
        fstore.knowledge.ingest("k2", "B", "body", "note")
        fstore.knowledge.ingest("k3", "C", "body", "article")
        articles = fstore.knowledge.list(item_type="article")
        assert all(i.type == ItemType.ARTICLE for i in articles)
        assert len(articles) >= 2

    def test_list_filter_by_pinned(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body", "note", pinned=True)
        fstore.knowledge.ingest("k2", "B", "body", "note", pinned=False)
        pinned = fstore.knowledge.list(pinned=True)
        assert all(i.pinned is True for i in pinned)
        assert any(i.item_id == "k1" for i in pinned)

    def test_list_limit(self, fstore):
        for i in range(5):
            fstore.knowledge.ingest(f"k{i}", f"Item {i}", "body", "note")
        items = fstore.knowledge.list(limit=3)
        assert len(items) == 3

    def test_search_fts(self, fstore):
        fstore.knowledge.ingest(
            "k1", "Cooking", "How to make sourdough bread", "article"
        )
        fstore.knowledge.ingest("k2", "Coding", "Python async programming", "article")
        fstore.knowledge.ingest("k3", "Baking", "Sourdough starter recipe", "note")
        results = fstore.knowledge.search("sourdough")
        assert len(results) >= 1
        assert any("sourdough" in r.body.lower() for r in results)

    def test_search_empty(self, fstore):
        assert fstore.knowledge.search("nonexistent_xyzzy") == []

    def test_find_by_url(self, fstore):
        fstore.knowledge.ingest(
            "k1",
            "Page",
            "body",
            "link",
            source_url="https://example.com/page",
        )
        found = fstore.knowledge.find_by_url("https://example.com/page")
        assert found is not None
        assert isinstance(found, Item)
        assert found.item_id == "k1"

    def test_find_by_url_missing(self, fstore):
        assert fstore.knowledge.find_by_url("https://nope.com") is None

    def test_create_source_and_get(self, fstore):
        lid = fstore.knowledge.create_source(
            "src1",
            "Wikipedia",
            "wikipedia.org",
            "encyclopedia",
            reputation=0.9,
        )
        assert lid == "source:src1"
        src = fstore.knowledge.get_source("src1")
        assert src is not None
        assert src["name"] == "Wikipedia"
        assert src["domain"] == "wikipedia.org"
        assert src["source_type"] == "encyclopedia"
        assert src["reputation"] == 0.9

    def test_get_source_missing(self, fstore):
        assert fstore.knowledge.get_source("nope") is None

    def test_create_link_and_get_links(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body a", "article")
        fstore.knowledge.ingest("k2", "B", "body b", "article")
        lid = fstore.knowledge.create_link("k1", "k2", "references", strength=0.8)
        assert lid.startswith("edge:knowledge-link:")
        links = fstore.knowledge.get_links("k1")
        assert len(links) >= 1
        assert any(lk["target_item_id"] == "k2" for lk in links)
        assert any(lk["relationship"] == "references" for lk in links)

    def test_create_trail_and_add_items(self, fstore):
        lid = fstore.knowledge.create_trail(
            "t1", "Python Trail", description="A learning path"
        )
        assert lid == "trail:t1"
        fstore.knowledge.ingest("k1", "Intro", "body1", "article")
        fstore.knowledge.ingest("k2", "Advanced", "body2", "article")
        fstore.knowledge.add_trail_item("t1", "k1", 1, annotation="Start here")
        fstore.knowledge.add_trail_item("t1", "k2", 2, annotation="Then this")
        items = fstore.knowledge.get_trail_items("t1")
        assert len(items) >= 2

    def test_soft_delete_hides_item(self, fstore):
        fstore.knowledge.ingest("k1", "Forgotten", "body", "note")
        fstore.knowledge.soft_delete("k1")
        assert fstore.knowledge.get("k1") is None

    def test_restore_after_soft_delete(self, fstore):
        fstore.knowledge.ingest("k1", "Restored", "body", "note")
        fstore.knowledge.soft_delete("k1")
        assert fstore.knowledge.get("k1") is None
        fstore.knowledge.restore("k1")
        item = fstore.knowledge.get("k1")
        assert item is not None
        assert item.title == "Restored"

    def test_purge_permanently_removes(self, fstore):
        fstore.knowledge.ingest("k1", "Purged", "body", "note")
        fstore.knowledge.soft_delete("k1")
        fstore.knowledge.purge("k1")
        # After purge, the node is permanently gone
        assert fstore.knowledge.get("k1") is None

    def test_touch_updates_last_accessed(self, fstore):
        fstore.knowledge.ingest("k1", "Touch Me", "body", "note")
        fstore.knowledge.touch("k1")
        item_after = fstore.knowledge.get("k1")
        assert item_after is not None
        assert item_after.last_accessed is not None

    # ── Phase 2d: additional KnowledgeRepository methods ────────────

    def test_get_items_batch(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body a", "article")
        fstore.knowledge.ingest("k2", "B", "body b", "note")
        fstore.knowledge.ingest("k3", "C", "body c", "article")
        items = fstore.knowledge.get_items_batch(["k1", "k3"])
        assert len(items) == 2
        assert all(isinstance(i, Item) for i in items)
        ids = {i.item_id for i in items}
        assert ids == {"k1", "k3"}

    def test_get_items_batch_skips_missing(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body a", "article")
        items = fstore.knowledge.get_items_batch(["k1", "missing", "also_missing"])
        assert len(items) == 1
        assert items[0].item_id == "k1"

    def test_get_items_batch_empty(self, fstore):
        assert fstore.knowledge.get_items_batch([]) == []

    def test_upsert_item_creates(self, fstore):
        lid = fstore.knowledge.upsert_item("k1", "Title", "Body text", "article")
        assert lid == "item:k1"
        item = fstore.knowledge.get("k1")
        assert item is not None
        assert item.title == "Title"
        assert item.body == "Body text"
        assert item.type == ItemType.ARTICLE

    def test_upsert_item_updates(self, fstore):
        fstore.knowledge.upsert_item("k1", "V1", "body v1", "note")
        fstore.knowledge.upsert_item("k1", "V2", "body v2", "note")
        item = fstore.knowledge.get("k1")
        assert item.title == "V2"
        assert item.body == "body v2"

    def test_upsert_item_with_kwargs(self, fstore):
        fstore.knowledge.upsert_item(
            "k1",
            "Title",
            "Body",
            "article",
            source_url="https://example.com",
            author="alice",
            tags=["test"],
            pinned=True,
        )
        item = fstore.knowledge.get("k1")
        assert item.source_url == "https://example.com"
        assert item.author == "alice"
        assert item.tags == ["test"]
        assert item.pinned is True

    def test_find_source_by_domain(self, fstore):
        fstore.knowledge.create_source(
            "src1", "Wikipedia", "wikipedia.org", "encyclopedia"
        )
        fstore.knowledge.create_source("src2", "ArXiv", "arxiv.org", "research")
        found = fstore.knowledge.find_source_by_domain("arxiv.org")
        assert found is not None
        assert found["name"] == "ArXiv"
        assert found["domain"] == "arxiv.org"

    def test_find_source_by_domain_missing(self, fstore):
        assert fstore.knowledge.find_source_by_domain("nope.com") is None

    def test_update_source(self, fstore):
        fstore.knowledge.create_source("src1", "Wiki", "wiki.org", "encyclopedia")
        fstore.knowledge.update_source("src1", reputation=0.95, name="Wikipedia")
        src = fstore.knowledge.get_source("src1")
        assert src["reputation"] == 0.95
        assert src["name"] == "Wikipedia"
        # unchanged fields preserved
        assert src["domain"] == "wiki.org"

    def test_update_source_missing_raises(self, fstore):
        with pytest.raises(KeyError):
            fstore.knowledge.update_source("nope", reputation=0.5)

    def test_list_trails(self, fstore):
        fstore.knowledge.create_trail("t1", "Trail A", description="first")
        fstore.knowledge.create_trail("t2", "Trail B", description="second")
        trails = fstore.knowledge.list_trails()
        assert len(trails) >= 2
        names = {t["name"] for t in trails}
        assert names >= {"Trail A", "Trail B"}

    def test_list_trails_empty(self, fstore):
        assert fstore.knowledge.list_trails() == []

    def test_get_trail(self, fstore):
        fstore.knowledge.create_trail("t1", "My Trail", description="desc")
        trail = fstore.knowledge.get_trail("t1")
        assert trail is not None
        assert trail["name"] == "My Trail"
        assert trail["description"] == "desc"

    def test_get_trail_missing(self, fstore):
        assert fstore.knowledge.get_trail("nope") is None

    def test_delete_item(self, fstore):
        fstore.knowledge.ingest("k1", "ToDelete", "body", "note")
        fstore.knowledge.delete_item("k1")
        assert fstore.knowledge.get("k1") is None
        # Also cannot be restored (it was purged)
        # Just verify it stays None
        assert fstore.knowledge.get("k1") is None

    def test_count_auto_links(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body", "article")
        fstore.knowledge.ingest("k2", "B", "body", "article")
        fstore.knowledge.ingest("k3", "C", "body", "article")
        fstore.knowledge.create_link("k1", "k2", "references", created_by="auto")
        fstore.knowledge.create_link("k1", "k3", "related", created_by="human")
        count = fstore.knowledge.count_auto_links("k1")
        assert count == 1

    def test_count_auto_links_none(self, fstore):
        fstore.knowledge.ingest("k1", "A", "body", "article")
        assert fstore.knowledge.count_auto_links("k1") == 0


# ── 5a. World Model repository ──────────────────────────────────────


class TestWorldModelRepository:
    """World-model graph: entities, intents, actions, observations, plans, provenance."""

    # ── Entities ─────────────────────────────────────────────────────

    def test_upsert_entity_and_get(self, fstore):
        lid = fstore.world_model.upsert_entity(
            "e1",
            "partner",
            "Alice",
            canonical_key="alice@example.com",
            status="active",
            confidence=0.95,
        )
        assert lid == "wm_entity:e1"
        entity = fstore.world_model.get_entity("e1")
        assert entity is not None
        assert isinstance(entity, WorldModelEntity)
        assert entity.entity_type == "partner"
        assert entity.display_name == "Alice"
        assert entity.canonical_key == "alice@example.com"
        assert entity.status == "active"
        assert entity.confidence == 0.95

    def test_get_entity_missing(self, fstore):
        assert fstore.world_model.get_entity("nope") is None

    def test_upsert_entity_updates_existing(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.world_model.upsert_entity("e1", "partner", "Alice B.", status="inactive")
        entity = fstore.world_model.get_entity("e1")
        assert entity.display_name == "Alice B."
        assert entity.status == "inactive"

    def test_set_and_get_entity_attributes(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.world_model.set_entity_attribute(
            "e1", "contact", "email", "alice@example.com"
        )
        fstore.world_model.set_entity_attribute(
            "e1", "contact", "phone", "555-1234", confidence=0.8
        )
        attrs = fstore.world_model.get_entity_attributes("e1")
        assert len(attrs) >= 2
        email_attr = [a for a in attrs if a["key"] == "email"]
        assert len(email_attr) == 1
        assert email_attr[0]["value"] == "alice@example.com"
        assert email_attr[0]["group"] == "contact"
        phone_attr = [a for a in attrs if a["key"] == "phone"]
        assert phone_attr[0]["confidence"] == 0.8

    def test_set_entity_attribute_overwrites(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.world_model.set_entity_attribute(
            "e1", "contact", "email", "old@example.com"
        )
        fstore.world_model.set_entity_attribute(
            "e1", "contact", "email", "new@example.com"
        )
        attrs = fstore.world_model.get_entity_attributes("e1")
        email_attrs = [a for a in attrs if a["key"] == "email"]
        assert len(email_attrs) == 1
        assert email_attrs[0]["value"] == "new@example.com"

    def test_get_entity_attributes_empty(self, fstore):
        fstore.world_model.upsert_entity("e1", "self", "Me")
        attrs = fstore.world_model.get_entity_attributes("e1")
        assert attrs == []

    # ── Intents ──────────────────────────────────────────────────────

    def test_record_intent_and_get(self, fstore):
        lid = fstore.world_model.record_intent(
            "i1",
            "s1",
            "What's the weather?",
            "query",
            "knowledge_lookup",
            turn_id="5",
            confidence=0.9,
        )
        assert lid == "wm_intent:i1"
        intent = fstore.world_model.get_intent("i1")
        assert intent is not None
        assert isinstance(intent, WorldModelIntent)
        assert intent.session_id == "s1"
        assert intent.raw_input == "What's the weather?"
        assert intent.classification == "query"
        assert intent.selected_path == "knowledge_lookup"
        assert intent.conversation_turn_id == 5
        assert intent.confidence == 0.9

    def test_get_intent_missing(self, fstore):
        assert fstore.world_model.get_intent("nope") is None

    # ── Actions ──────────────────────────────────────────────────────

    def test_record_action(self, fstore):
        lid = fstore.world_model.record_action(
            "a1",
            "s1",
            "tool_call",
            "search_knowledge",
            intent_id="i1",
            status="active",
            payload={"query": "weather"},
        )
        assert lid == "wm_action:a1"

    def test_record_action_duplicate_id_upserts(self, fstore):
        # First call creates the action node.
        lid1 = fstore.world_model.record_action(
            "a1", "s1", "tool_call", "search", status="active"
        )
        # Second call with same action_id (idempotent replay) — must not raise
        # and must return the same logical_id.
        lid2 = fstore.world_model.record_action(
            "a1", "s1", "tool_call", "search", status="completed"
        )
        assert lid1 == lid2 == "wm_action:a1"
        # Only one node should exist for this action_id.
        actions = fstore.world_model.list_actions(session_id="s1")
        assert sum(1 for a in actions if a.action_id == "a1") == 1

    # ── Observations ─────────────────────────────────────────────────

    def test_record_observation_with_edge(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search_knowledge")
        lid = fstore.world_model.record_observation(
            "o1",
            "a1",
            "tool_result",
            "Found 3 results",
            status="observed",
            payload={"count": 3},
        )
        assert lid == "wm_observation:o1"

    # ── Plans ────────────────────────────────────────────────────────

    def test_create_plan_and_get(self, fstore):
        fstore.goals.create("g1", "Ship v1", "Launch MVP", "active", "high")
        lid = fstore.world_model.create_plan(
            "p1", "g1", "Launch checklist", status="active"
        )
        assert lid == "wm_plan:p1"
        plan = fstore.world_model.get_plan("p1")
        assert plan is not None
        assert plan["title"] == "Launch checklist"
        assert plan["goal_id"] == "g1"
        assert plan["status"] == "active"

    def test_get_plan_missing(self, fstore):
        assert fstore.world_model.get_plan("nope") is None

    def test_add_plan_steps_and_list(self, fstore):
        fstore.goals.create("g1", "Ship v1", "", "active", "high")
        fstore.world_model.create_plan("p1", "g1", "Launch checklist")
        fstore.world_model.add_plan_step("s1", "p1", "Write tests", ordinal=1)
        fstore.world_model.add_plan_step(
            "s2", "p1", "Deploy", step_kind="deploy", ordinal=2, status="pending"
        )
        steps = fstore.world_model.list_plan_steps("p1")
        assert len(steps) >= 2
        titles = {s["title"] for s in steps}
        assert "Write tests" in titles
        assert "Deploy" in titles

    def test_list_plan_steps_empty(self, fstore):
        fstore.goals.create("g1", "Ship v1", "", "active", "high")
        fstore.world_model.create_plan("p1", "g1", "Empty plan")
        steps = fstore.world_model.list_plan_steps("p1")
        assert steps == []

    # ── Provenance links ─────────────────────────────────────────────

    def test_create_provenance_link(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.world_model.record_intent("i1", "s1", "hello", "greeting", "respond")
        lid = fstore.world_model.create_provenance_link(
            "WMEntity",
            "e1",
            "WMIntent",
            "i1",
            "MENTIONED_IN",
        )
        assert lid.startswith("edge:provenance:")

    def test_create_provenance_link_different_types(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search")
        fstore.world_model.record_action("a2", "s1", "tool_call", "write")
        lid = fstore.world_model.create_provenance_link(
            "WMAction",
            "a1",
            "WMAction",
            "a2",
            "TRIGGERED",
        )
        assert lid.startswith("edge:provenance:")

    # ── Events (Group 1) ────────────────────────────────────────────

    def test_record_event_and_list(self, fstore):
        lid = fstore.world_model.record_event(
            "ev1",
            "s1",
            "meeting_start",
            "Standup began",
            summary="Daily standup started",
            meeting_id="m1",
            turn_id="t5",
            payload={"attendees": 3},
        )
        assert lid == "wm_event:ev1"
        events = fstore.world_model.list_events(session_id="s1")
        assert len(events) >= 1
        ev = events[0]
        assert ev.event_kind == "meeting_start"
        assert ev.title == "Standup began"
        assert ev.summary == "Daily standup started"
        assert ev.meeting_id == "m1"
        assert ev.payload["attendees"] == 3

    def test_list_events_filter_by_kind(self, fstore):
        fstore.world_model.record_event("ev1", "s1", "start", "Start")
        fstore.world_model.record_event("ev2", "s1", "end", "End")
        fstore.world_model.record_event("ev3", "s2", "start", "Start 2")
        events = fstore.world_model.list_events(event_kind="start")
        assert len(events) == 2
        assert all(e.event_kind == "start" for e in events)

    def test_list_events_empty(self, fstore):
        assert fstore.world_model.list_events() == []

    # ── Execution records (Group 2) ─────────────────────────────────

    def test_record_execution_and_list(self, fstore):
        lid = fstore.world_model.record_execution(
            "ex1",
            "s1",
            "tool_run",
            "Search knowledge",
            goal_id="g1",
            plan_id="p1",
            step_id="st1",
            source_record_type="WMAction",
            source_record_id="a1",
            payload={"query": "weather"},
        )
        assert lid == "wm_execution:ex1"
        execs = fstore.world_model.list_executions(session_id="s1")
        assert len(execs) >= 1
        ex = execs[0]
        assert ex["execution_kind"] == "tool_run"
        assert ex["title"] == "Search knowledge"
        assert ex["goal_id"] == "g1"
        assert ex["source_record_type"] == "WMAction"

    def test_list_executions_filter_by_plan(self, fstore):
        fstore.world_model.record_execution("ex1", "s1", "run", "A", plan_id="p1")
        fstore.world_model.record_execution("ex2", "s1", "run", "B", plan_id="p2")
        execs = fstore.world_model.list_executions(plan_id="p1")
        assert len(execs) == 1
        assert execs[0]["plan_id"] == "p1"

    def test_list_executions_empty(self, fstore):
        assert fstore.world_model.list_executions() == []

    # ── WM Goals (Group 3a) ─────────────────────────────────────────

    def test_upsert_wm_goal_and_load(self, fstore):
        lid = fstore.world_model.upsert_wm_goal(
            "wg1",
            "Ship v2",
            status="active",
            priority="high",
            parent_goal_id="wg0",
            description="Release version 2",
        )
        assert lid == "wm_goal:wg1"
        goal = fstore.world_model.load_wm_goal("wg1")
        assert goal is not None
        assert isinstance(goal, WorldModelGoal)
        assert goal.title == "Ship v2"
        assert goal.status == "active"
        assert goal.priority == "high"
        assert goal.parent_goal_id == "wg0"
        assert goal.description == "Release version 2"

    def test_load_wm_goal_missing(self, fstore):
        assert fstore.world_model.load_wm_goal("nope") is None

    def test_list_wm_goals_filter_by_status(self, fstore):
        fstore.world_model.upsert_wm_goal("wg1", "A", status="active")
        fstore.world_model.upsert_wm_goal("wg2", "B", status="completed")
        fstore.world_model.upsert_wm_goal("wg3", "C", status="active")
        goals = fstore.world_model.list_wm_goals(status="active")
        assert len(goals) == 2
        assert all(isinstance(g, WorldModelGoal) for g in goals)
        assert all(g.status == "active" for g in goals)

    def test_list_wm_goals_all(self, fstore):
        fstore.world_model.upsert_wm_goal("wg1", "A")
        fstore.world_model.upsert_wm_goal("wg2", "B")
        goals = fstore.world_model.list_wm_goals()
        assert len(goals) == 2

    # ── WM Tasks (Group 3b) ─────────────────────────────────────────

    def test_upsert_wm_task_and_load(self, fstore):
        lid = fstore.world_model.upsert_wm_task(
            "wt1",
            "followup",
            "Send email",
            goal_id="wg1",
            status="active",
            description="Follow up with Alice",
        )
        assert lid == "wm_task:wt1"
        task = fstore.world_model.load_wm_task("wt1")
        assert task is not None
        assert isinstance(task, WorldModelTask)
        assert task.task_kind == "followup"
        assert task.title == "Send email"
        assert task.goal_id == "wg1"
        assert task.description == "Follow up with Alice"

    def test_load_wm_task_missing(self, fstore):
        assert fstore.world_model.load_wm_task("nope") is None

    def test_list_wm_tasks_all(self, fstore):
        fstore.world_model.upsert_wm_task("wt1", "followup", "A", goal_id="g1")
        fstore.world_model.upsert_wm_task("wt2", "review", "B", goal_id="g2")
        tasks = fstore.world_model.list_wm_tasks()
        assert len(tasks) == 2
        assert all(isinstance(t, WorldModelTask) for t in tasks)

    def test_list_wm_tasks_filter_by_goal(self, fstore):
        fstore.world_model.upsert_wm_task("wt1", "followup", "A", goal_id="g1")
        fstore.world_model.upsert_wm_task("wt2", "review", "B", goal_id="g2")
        tasks = fstore.world_model.list_wm_tasks(goal_id="g1")
        assert len(tasks) == 1
        assert tasks[0].goal_id == "g1"

    def test_list_wm_tasks_filter_by_status(self, fstore):
        fstore.world_model.upsert_wm_task("wt1", "followup", "A", status="active")
        fstore.world_model.upsert_wm_task("wt2", "review", "B", status="completed")
        tasks = fstore.world_model.list_wm_tasks(status="active")
        assert len(tasks) == 1
        assert tasks[0].status == "active"

    def test_delete_wm_task(self, fstore):
        fstore.world_model.upsert_wm_task("wt1", "followup", "A")
        assert fstore.world_model.load_wm_task("wt1") is not None
        fstore.world_model.delete_wm_task("wt1")
        assert fstore.world_model.load_wm_task("wt1") is None

    # ── WM Commitments (Group 3c) ───────────────────────────────────

    def test_upsert_wm_commitment_and_load(self, fstore):
        lid = fstore.world_model.upsert_wm_commitment(
            "wc1",
            "Review PR by Friday",
            meeting_id="m1",
            goal_id="wg1",
            status="active",
            assignee="Corey",
        )
        assert lid == "wm_commitment:wc1"
        comm = fstore.world_model.load_wm_commitment("wc1")
        assert comm is not None
        assert isinstance(comm, WorldModelCommitment)
        assert comm.title == "Review PR by Friday"
        assert comm.meeting_id == "m1"
        assert comm.goal_id == "wg1"
        assert comm.assignee == "Corey"

    def test_load_wm_commitment_missing(self, fstore):
        assert fstore.world_model.load_wm_commitment("nope") is None

    def test_list_wm_commitments_all(self, fstore):
        fstore.world_model.upsert_wm_commitment("wc1", "A", meeting_id="m1")
        fstore.world_model.upsert_wm_commitment("wc2", "B", meeting_id="m2")
        comms = fstore.world_model.list_wm_commitments()
        assert len(comms) == 2
        assert all(isinstance(c, WorldModelCommitment) for c in comms)

    def test_list_wm_commitments_filter_by_meeting(self, fstore):
        fstore.world_model.upsert_wm_commitment("wc1", "A", meeting_id="m1")
        fstore.world_model.upsert_wm_commitment("wc2", "B", meeting_id="m2")
        comms = fstore.world_model.list_wm_commitments(meeting_id="m1")
        assert len(comms) == 1
        assert comms[0].meeting_id == "m1"

    def test_list_wm_commitments_filter_by_goal(self, fstore):
        fstore.world_model.upsert_wm_commitment("wc1", "A", goal_id="g1")
        fstore.world_model.upsert_wm_commitment("wc2", "B", goal_id="g2")
        comms = fstore.world_model.list_wm_commitments(goal_id="g1")
        assert len(comms) == 1
        assert comms[0].goal_id == "g1"

    def test_delete_wm_commitment(self, fstore):
        fstore.world_model.upsert_wm_commitment("wc1", "A")
        assert fstore.world_model.load_wm_commitment("wc1") is not None
        fstore.world_model.delete_wm_commitment("wc1")
        assert fstore.world_model.load_wm_commitment("wc1") is None

    # ── Semantic mappings (Group 4) ─────────────────────────────────

    def test_replace_semantic_mappings(self, fstore):
        mappings = [
            {
                "mapping_kind": "speaker",
                "source_value": "Speaker 1",
                "target_value": "Alice",
            },
            {
                "mapping_kind": "speaker",
                "source_value": "Speaker 2",
                "target_value": "Bob",
            },
        ]
        count = fstore.world_model.replace_semantic_mappings("meeting", "m1", mappings)
        assert count == 2
        result = fstore.world_model.list_semantic_mappings(
            scope_type="meeting", scope_key="m1"
        )
        assert len(result) == 2
        assert all(isinstance(m, WorldModelSemanticMapping) for m in result)
        names = {m.target_value for m in result}
        assert names == {"Alice", "Bob"}

    def test_replace_semantic_mappings_retires_old(self, fstore):
        fstore.world_model.replace_semantic_mappings(
            "meeting",
            "m1",
            [
                {
                    "mapping_kind": "speaker",
                    "source_value": "S1",
                    "target_value": "Alice",
                },
            ],
        )
        # Replace with new mappings
        fstore.world_model.replace_semantic_mappings(
            "meeting",
            "m1",
            [
                {
                    "mapping_kind": "speaker",
                    "source_value": "S1",
                    "target_value": "Carol",
                },
            ],
        )
        result = fstore.world_model.list_semantic_mappings(
            scope_type="meeting", scope_key="m1"
        )
        assert len(result) == 1
        assert result[0].target_value == "Carol"

    def test_list_semantic_mappings_filter_scope_type(self, fstore):
        fstore.world_model.replace_semantic_mappings(
            "meeting",
            "m1",
            [
                {
                    "mapping_kind": "speaker",
                    "source_value": "S1",
                    "target_value": "Alice",
                },
            ],
        )
        fstore.world_model.replace_semantic_mappings(
            "session",
            "s1",
            [
                {
                    "mapping_kind": "topic",
                    "source_value": "T1",
                    "target_value": "Weather",
                },
            ],
        )
        result = fstore.world_model.list_semantic_mappings(scope_type="meeting")
        assert len(result) == 1
        assert result[0].scope_type == "meeting"

    def test_load_semantic_mapping(self, fstore):
        fstore.world_model.replace_semantic_mappings(
            "meeting",
            "m1",
            [
                {
                    "mapping_kind": "speaker",
                    "source_value": "S1",
                    "target_value": "Alice",
                },
            ],
        )
        result = fstore.world_model.list_semantic_mappings(
            scope_type="meeting", scope_key="m1"
        )
        assert len(result) == 1
        mapping = fstore.world_model.load_semantic_mapping(result[0].mapping_id)
        assert mapping is not None
        assert isinstance(mapping, WorldModelSemanticMapping)
        assert mapping.target_value == "Alice"

    def test_load_semantic_mapping_missing(self, fstore):
        assert fstore.world_model.load_semantic_mapping("nope") is None

    # ── Knowledge objects (Group 5) ─────────────────────────────────

    def test_upsert_knowledge_object_and_load(self, fstore):
        lid = fstore.world_model.upsert_knowledge_object(
            "ko1",
            "item1",
            "article",
            "arxiv:2301.00001",
            title="Attention Is All You Need",
            source_url="https://arxiv.org/abs/2301.00001",
        )
        assert lid == "wm_knowledge_object:ko1"
        ko = fstore.world_model.load_knowledge_object("ko1")
        assert ko is not None
        assert isinstance(ko, WorldModelKnowledgeObject)
        assert ko.knowledge_type == "article"
        assert ko.canonical_key == "arxiv:2301.00001"
        assert ko.title == "Attention Is All You Need"
        assert ko.source_url == "https://arxiv.org/abs/2301.00001"

    def test_load_knowledge_object_missing(self, fstore):
        assert fstore.world_model.load_knowledge_object("nope") is None

    # ── Prompt control (Group 6) ────────────────────────────────────

    def test_upsert_prompt_control_and_load_latest(self, fstore):
        lid = fstore.world_model.upsert_prompt_control_artifact(
            "pc1",
            "s1",
            "What is the weather?",
            "query",
            "direct_answer",
            "analytic_strict",
            tool_policy="allow_all",
            validation_policy="strict",
            memory_policy="default",
            response_contract="standard",
        )
        assert lid == "wm_prompt_control:pc1"
        latest = fstore.world_model.load_latest_prompt_control("s1")
        assert latest is not None
        assert isinstance(latest, PromptControlArtifact)
        assert latest.raw_input == "What is the weather?"
        assert latest.classification == "query"
        assert latest.route_profile.value == "analytic_strict"
        assert latest.tool_policy == "allow_all"

    def test_load_latest_prompt_control_returns_most_recent(self, fstore):
        fstore.world_model.upsert_prompt_control_artifact(
            "pc1",
            "s1",
            "first",
            "query",
            "direct_answer",
            "analytic_strict",
            tool_policy="allow_all",
            validation_policy="strict",
            memory_policy="default",
            response_contract="standard",
        )
        fstore.world_model.upsert_prompt_control_artifact(
            "pc2",
            "s1",
            "second",
            "action",
            "act",
            "operational_tool",
            tool_policy="allow_all",
            validation_policy="strict",
            memory_policy="default",
            response_contract="standard",
        )
        latest = fstore.world_model.load_latest_prompt_control("s1")
        assert latest is not None
        assert isinstance(latest, PromptControlArtifact)
        assert latest.raw_input == "second"

    def test_load_latest_prompt_control_empty(self, fstore):
        assert fstore.world_model.load_latest_prompt_control("s99") is None

    def test_list_prompt_control_artifacts(self, fstore):
        fstore.world_model.upsert_prompt_control_artifact(
            "pc1",
            "s1",
            "first",
            "query",
            "direct_answer",
            "analytic_strict",
            tool_policy="allow_all",
            validation_policy="strict",
            memory_policy="default",
            response_contract="standard",
        )
        fstore.world_model.upsert_prompt_control_artifact(
            "pc2",
            "s1",
            "second",
            "action",
            "act",
            "operational_tool",
            tool_policy="allow_all",
            validation_policy="strict",
            memory_policy="default",
            response_contract="standard",
        )
        arts = fstore.world_model.list_prompt_control_artifacts("s1")
        assert len(arts) == 2
        assert all(isinstance(a, PromptControlArtifact) for a in arts)
        # newest first
        assert arts[0].raw_input == "second"

    def test_list_prompt_control_artifacts_empty(self, fstore):
        assert fstore.world_model.list_prompt_control_artifacts("s99") == []

    # ── Claim evaluations (Group 6b) ──────────────────────────────

    def test_upsert_claim_evaluation_and_load(self, fstore):
        lid = fstore.world_model.upsert_claim_evaluation(
            "ce1",
            "ko1",
            "item1",
            "factual",
            "Earth is round",
            summary="Verified claim",
            status="verified",
        )
        assert lid == "wm_claim_evaluation:ce1"
        ce = fstore.world_model.load_claim_evaluation("ce1")
        assert ce is not None
        assert isinstance(ce, WorldModelClaimEvaluation)
        assert ce.knowledge_id == "ko1"
        assert ce.item_id == "item1"
        assert ce.evaluation_kind == "factual"
        assert ce.title == "Earth is round"
        assert ce.status == "verified"

    def test_load_claim_evaluation_missing(self, fstore):
        assert fstore.world_model.load_claim_evaluation("nope") is None

    def test_list_claim_evaluations(self, fstore):
        fstore.world_model.upsert_claim_evaluation(
            "ce1",
            "ko1",
            "item1",
            "factual",
            "Claim A",
        )
        fstore.world_model.upsert_claim_evaluation(
            "ce2",
            "ko1",
            "item2",
            "opinion",
            "Claim B",
        )
        fstore.world_model.upsert_claim_evaluation(
            "ce3",
            "ko2",
            "item3",
            "factual",
            "Claim C",
        )
        evals = fstore.world_model.list_claim_evaluations(knowledge_id="ko1")
        assert len(evals) == 2
        assert all(isinstance(e, WorldModelClaimEvaluation) for e in evals)
        assert all(e.knowledge_id == "ko1" for e in evals)

    def test_list_claim_evaluations_all(self, fstore):
        fstore.world_model.upsert_claim_evaluation(
            "ce1",
            "ko1",
            "item1",
            "factual",
            "A",
        )
        fstore.world_model.upsert_claim_evaluation(
            "ce2",
            "ko2",
            "item2",
            "opinion",
            "B",
        )
        evals = fstore.world_model.list_claim_evaluations()
        assert len(evals) == 2

    # ── Provenance queries (Group 7) ────────────────────────────────

    def test_list_provenance_links_by_source(self, fstore):
        fstore.world_model.upsert_entity("e1", "partner", "Alice")
        fstore.world_model.record_intent("i1", "s1", "hello", "greeting", "respond")
        fstore.world_model.create_provenance_link(
            "WMEntity",
            "e1",
            "WMIntent",
            "i1",
            "MENTIONED_IN",
        )
        links = fstore.world_model.list_provenance_links(
            source_type="WMEntity",
            source_id="e1",
        )
        assert len(links) >= 1
        assert links[0]["target_type"] == "WMIntent"
        assert links[0]["target_id"] == "i1"
        assert links[0]["relationship"] == "MENTIONED_IN"

    def test_list_provenance_links_by_target(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search")
        fstore.world_model.record_action("a2", "s1", "tool_call", "write")
        fstore.world_model.create_provenance_link(
            "WMAction",
            "a1",
            "WMAction",
            "a2",
            "TRIGGERED",
        )
        links = fstore.world_model.list_provenance_links(
            target_type="WMAction",
            target_id="a2",
        )
        assert len(links) >= 1
        assert links[0]["source_type"] == "WMAction"
        assert links[0]["source_id"] == "a1"

    def test_list_provenance_links_empty(self, fstore):
        assert fstore.world_model.list_provenance_links() == []

    # ── list_actions ────────────────────────────────────────────────

    def test_list_actions_returns_typed_models(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search")
        fstore.world_model.record_action("a2", "s1", "reflection", "reflect")
        actions = fstore.world_model.list_actions(session_id="s1")
        assert len(actions) >= 2
        assert all(isinstance(a, WorldModelAction) for a in actions)
        kinds = {a.action_kind for a in actions}
        assert "tool_call" in kinds
        assert "reflection" in kinds

    def test_list_actions_filter_by_kind(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search")
        fstore.world_model.record_action("a2", "s1", "reflection", "reflect")
        actions = fstore.world_model.list_actions(action_kind="tool_call")
        assert len(actions) == 1
        assert actions[0].action_kind == "tool_call"

    def test_list_actions_empty(self, fstore):
        assert fstore.world_model.list_actions() == []

    # ── list_observations ───────────────────────────────────────────

    def test_list_observations_returns_typed_models(self, fstore):
        fstore.world_model.record_action("a1", "s1", "tool_call", "search")
        fstore.world_model.record_observation("o1", "a1", "tool_result", "Found 3")
        fstore.world_model.record_observation("o2", "a1", "tool_result", "Found 5")
        observations = fstore.world_model.list_observations(action_id="a1")
        assert len(observations) >= 2
        assert all(isinstance(o, WorldModelObservation) for o in observations)

    def test_list_observations_empty(self, fstore):
        assert fstore.world_model.list_observations() == []

    # ── load_event ──────────────────────────────────────────────────

    def test_load_event_returns_typed_model(self, fstore):
        fstore.world_model.record_event(
            "ev1",
            "s1",
            "meeting_start",
            "Standup began",
            summary="Daily standup started",
            payload={"attendees": 3},
        )
        event = fstore.world_model.load_event("ev1")
        assert event is not None
        assert isinstance(event, WorldModelEvent)
        assert event.event_kind == "meeting_start"
        assert event.title == "Standup began"
        assert event.summary == "Daily standup started"
        assert event.payload["attendees"] == 3

    def test_load_event_missing(self, fstore):
        assert fstore.world_model.load_event("nope") is None

    # ── load_latest_intent ──────────────────────────────────────────

    def test_load_latest_intent_returns_most_recent(self, fstore):
        fstore.world_model.record_intent(
            "i1",
            "s1",
            "first question",
            "query",
            "direct_answer",
        )
        fstore.world_model.record_intent(
            "i2",
            "s1",
            "second question",
            "action",
            "act",
        )
        latest = fstore.world_model.load_latest_intent("s1")
        assert latest is not None
        assert isinstance(latest, WorldModelIntent)
        assert latest.raw_input == "second question"

    def test_load_latest_intent_empty(self, fstore):
        assert fstore.world_model.load_latest_intent("s99") is None


# ── Plans (typed) ───────────────────────────────────────────────────


class TestWorldModelPlansTyped:
    """WorldModelRepository typed plan CRUD."""

    def _make_plan(self, **overrides):
        now = utcnow()
        defaults = dict(
            plan_id="plan1",
            goal_id="g1",
            title="Deploy",
            summary="Deploy app",
            status="active",
            selected_step_id=None,
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelActionPlan(**defaults)

    def test_upsert_and_load(self, fstore):
        plan = self._make_plan()
        fstore.world_model.upsert_plan(plan)
        loaded = fstore.world_model.get_plan_typed("plan1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelActionPlan)
        assert loaded.plan_id == "plan1"
        assert loaded.title == "Deploy"

    def test_upsert_updates(self, fstore):
        plan = self._make_plan()
        fstore.world_model.upsert_plan(plan)
        plan2 = self._make_plan(title="Deploy v2", status="completed")
        fstore.world_model.upsert_plan(plan2)
        loaded = fstore.world_model.get_plan_typed("plan1")
        assert loaded is not None
        assert loaded.title == "Deploy v2"
        assert loaded.status == "completed"

    def test_load_missing(self, fstore):
        assert fstore.world_model.get_plan_typed("nope") is None

    def test_list_plans(self, fstore):
        fstore.world_model.upsert_plan(self._make_plan(plan_id="p1"))
        fstore.world_model.upsert_plan(self._make_plan(plan_id="p2"))
        plans = fstore.world_model.list_plans()
        assert len(plans) >= 2
        assert all(isinstance(p, WorldModelActionPlan) for p in plans)

    def test_list_plans_filter_goal(self, fstore):
        fstore.world_model.upsert_plan(
            self._make_plan(plan_id="p1", goal_id="g1"),
        )
        fstore.world_model.upsert_plan(
            self._make_plan(plan_id="p2", goal_id="g2"),
        )
        plans = fstore.world_model.list_plans(goal_id="g1")
        assert all(p.goal_id == "g1" for p in plans)

    def test_list_plans_filter_status(self, fstore):
        fstore.world_model.upsert_plan(
            self._make_plan(plan_id="p1", status="active"),
        )
        fstore.world_model.upsert_plan(
            self._make_plan(plan_id="p2", status="completed"),
        )
        plans = fstore.world_model.list_plans(status="completed")
        assert all(p.status == "completed" for p in plans)

    def test_list_plans_empty(self, fstore):
        assert fstore.world_model.list_plans() == []


# ── Plan steps (typed) ──────────────────────────────────────────────


class TestWorldModelPlanStepsTyped:
    """WorldModelRepository typed plan step CRUD."""

    def _make_step(self, **overrides):
        now = utcnow()
        defaults = dict(
            step_id="s1",
            plan_id="plan1",
            goal_id="g1",
            step_kind="task",
            title="Build",
            description="Build it",
            status="active",
            ordinal=1,
            blocked_reason="",
            progress_pct=0,
            depends_on_step_ids=[],
            blocked_by_step_ids=[],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelPlanStep(**defaults)

    def test_upsert_and_load(self, fstore):
        step = self._make_step()
        fstore.world_model.upsert_plan_step(step)
        loaded = fstore.world_model.load_plan_step("s1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelPlanStep)
        assert loaded.step_id == "s1"
        assert loaded.title == "Build"

    def test_upsert_updates(self, fstore):
        fstore.world_model.upsert_plan_step(self._make_step())
        fstore.world_model.upsert_plan_step(
            self._make_step(title="Build v2", status="done"),
        )
        loaded = fstore.world_model.load_plan_step("s1")
        assert loaded is not None
        assert loaded.title == "Build v2"
        assert loaded.status == "done"

    def test_load_missing(self, fstore):
        assert fstore.world_model.load_plan_step("nope") is None

    def test_list_plan_steps_typed(self, fstore):
        fstore.world_model.upsert_plan_step(
            self._make_step(step_id="s1", plan_id="p1"),
        )
        fstore.world_model.upsert_plan_step(
            self._make_step(step_id="s2", plan_id="p1"),
        )
        fstore.world_model.upsert_plan_step(
            self._make_step(step_id="s3", plan_id="p2"),
        )
        steps = fstore.world_model.list_plan_steps_typed(plan_id="p1")
        assert len(steps) >= 2
        assert all(isinstance(s, WorldModelPlanStep) for s in steps)
        assert all(s.plan_id == "p1" for s in steps)

    def test_list_plan_steps_typed_empty(self, fstore):
        assert fstore.world_model.list_plan_steps_typed() == []


# ── Execution records (typed) ───────────────────────────────────────


class TestWorldModelExecutionRecordsTyped:
    """WorldModelRepository typed execution record CRUD."""

    def _make_record(self, **overrides):
        now = utcnow()
        defaults = dict(
            execution_id="e1",
            session_id="sess1",
            conversation_turn_id=None,
            goal_id="g1",
            plan_id="p1",
            step_id="s1",
            execution_kind="tool_call",
            title="Run search",
            summary="Searched",
            status="completed",
            source_record_type="WMAction",
            source_record_id="a1",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelExecutionRecord(**defaults)

    def test_upsert_and_load(self, fstore):
        rec = self._make_record()
        fstore.world_model.upsert_execution(rec)
        loaded = fstore.world_model.load_execution("e1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelExecutionRecord)
        assert loaded.execution_id == "e1"
        assert loaded.title == "Run search"

    def test_upsert_updates(self, fstore):
        fstore.world_model.upsert_execution(self._make_record())
        fstore.world_model.upsert_execution(
            self._make_record(title="Run v2", status="failed"),
        )
        loaded = fstore.world_model.load_execution("e1")
        assert loaded is not None
        assert loaded.title == "Run v2"
        assert loaded.status == "failed"

    def test_load_missing(self, fstore):
        assert fstore.world_model.load_execution("nope") is None

    def test_list_executions_typed(self, fstore):
        fstore.world_model.upsert_execution(
            self._make_record(execution_id="e1", session_id="s1"),
        )
        fstore.world_model.upsert_execution(
            self._make_record(execution_id="e2", session_id="s1"),
        )
        fstore.world_model.upsert_execution(
            self._make_record(execution_id="e3", session_id="s2"),
        )
        results = fstore.world_model.list_executions_typed(session_id="s1")
        assert len(results) >= 2
        assert all(isinstance(r, WorldModelExecutionRecord) for r in results)

    def test_list_executions_typed_empty(self, fstore):
        assert fstore.world_model.list_executions_typed() == []


# ── Knowledge ingest runs ───────────────────────────────────────────


class TestWorldModelIngestRuns:
    """WorldModelRepository ingest run CRUD."""

    def _make_run(self, **overrides):
        now = utcnow()
        defaults = dict(
            ingest_run_id="ir1",
            ingest_kind="url",
            trigger_surface="telegram",
            session_id="sess1",
            source_ref="https://example.com",
            normalized_source_ref="example.com",
            requested_item_type="article",
            status="completed",
            phase="done",
            fallback_used=False,
            item_id="item1",
            knowledge_id="k1",
            summary_model="gpt-4o",
            error="",
            payload={},
            created_at=now,
            updated_at=now,
            finished_at=now,
        )
        defaults.update(overrides)
        return WorldModelKnowledgeIngestRun(**defaults)

    def test_upsert_and_load(self, fstore):
        run = self._make_run()
        fstore.world_model.upsert_ingest_run(run)
        loaded = fstore.world_model.load_ingest_run("ir1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelKnowledgeIngestRun)
        assert loaded.ingest_run_id == "ir1"
        assert loaded.ingest_kind == "url"

    def test_upsert_updates(self, fstore):
        fstore.world_model.upsert_ingest_run(self._make_run())
        fstore.world_model.upsert_ingest_run(
            self._make_run(status="failed", error="timeout"),
        )
        loaded = fstore.world_model.load_ingest_run("ir1")
        assert loaded is not None
        assert loaded.status == "failed"
        assert loaded.error == "timeout"

    def test_load_missing(self, fstore):
        assert fstore.world_model.load_ingest_run("nope") is None

    def test_list_ingest_runs(self, fstore):
        fstore.world_model.upsert_ingest_run(
            self._make_run(ingest_run_id="ir1", status="completed"),
        )
        fstore.world_model.upsert_ingest_run(
            self._make_run(ingest_run_id="ir2", status="failed"),
        )
        results = fstore.world_model.list_ingest_runs(status="completed")
        assert len(results) >= 1
        assert all(r.status == "completed" for r in results)

    def test_list_ingest_runs_empty(self, fstore):
        assert fstore.world_model.list_ingest_runs() == []


# ── Plan step transitions ──────────────────────────────────────────


class TestWorldModelTransitions:
    """WorldModelRepository transition CRUD."""

    def _make_transition(self, **overrides):
        now = utcnow()
        defaults = dict(
            transition_id="t1",
            step_id="s1",
            plan_id="p1",
            goal_id="g1",
            execution_id="e1",
            transition_kind="status_change",
            from_status="active",
            to_status="completed",
            blocked_reason=None,
            blocked_by_step_ids=None,
            progress_pct=100,
            summary="Step done",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
        defaults.update(overrides)
        return WorldModelPlanStepTransition(**defaults)

    def test_append_and_load(self, fstore):
        t = self._make_transition()
        fstore.world_model.append_transition(t)
        loaded = fstore.world_model.load_transition("t1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelPlanStepTransition)
        assert loaded.transition_id == "t1"
        assert loaded.transition_kind == "status_change"

    def test_load_missing(self, fstore):
        assert fstore.world_model.load_transition("nope") is None

    def test_list_transitions(self, fstore):
        fstore.world_model.append_transition(
            self._make_transition(transition_id="t1", step_id="s1"),
        )
        fstore.world_model.append_transition(
            self._make_transition(transition_id="t2", step_id="s1"),
        )
        fstore.world_model.append_transition(
            self._make_transition(transition_id="t3", step_id="s2"),
        )
        results = fstore.world_model.list_transitions(step_id="s1")
        assert len(results) >= 2
        assert all(isinstance(t, WorldModelPlanStepTransition) for t in results)

    def test_list_transitions_empty(self, fstore):
        assert fstore.world_model.list_transitions() == []


# ── Knowledge object by item_id ─────────────────────────────────────


class TestWorldModelKnowledgeObjectByItemId:
    """WorldModelRepository knowledge object lookup by item_id."""

    def test_load_by_item_id(self, fstore):
        fstore.world_model.upsert_knowledge_object(
            "k1",
            "item1",
            "article",
            "example.com",
            title="Example",
        )
        loaded = fstore.world_model.load_knowledge_object_by_item_id("item1")
        assert loaded is not None
        assert isinstance(loaded, WorldModelKnowledgeObject)
        assert loaded.knowledge_id == "k1"

    def test_load_by_item_id_missing(self, fstore):
        assert fstore.world_model.load_knowledge_object_by_item_id("nope") is None


# ── Knowledge entity links ──────────────────────────────────────────


class TestWorldModelKnowledgeEntityLinks:
    """WorldModelRepository knowledge entity link CRUD."""

    def test_upsert_and_list(self, fstore):
        fstore.world_model.upsert_knowledge_entity_link(
            "kel1",
            "k1",
            "ent1",
            relationship="mentions",
        )
        fstore.world_model.upsert_knowledge_entity_link(
            "kel2",
            "k1",
            "ent2",
            relationship="authored_by",
        )
        links = fstore.world_model.list_knowledge_entity_links("k1")
        assert len(links) >= 2
        assert all(isinstance(lnk, WorldModelKnowledgeEntityLink) for lnk in links)

    def test_list_empty(self, fstore):
        assert fstore.world_model.list_knowledge_entity_links("nope") == []


# ── Knowledge relationships ──────────────────────────────────────────


class TestWorldModelKnowledgeRelationships:
    """WorldModelRepository knowledge relationship CRUD."""

    def test_upsert_and_list(self, fstore):
        fstore.world_model.upsert_knowledge_relationship(
            "kr1",
            "k1",
            "k2",
            "supports",
        )
        fstore.world_model.upsert_knowledge_relationship(
            "kr2",
            "k1",
            "k3",
            "contradicts",
        )
        rels = fstore.world_model.list_knowledge_relationships(
            source_knowledge_id="k1",
        )
        assert len(rels) >= 2
        assert all(isinstance(r, WorldModelKnowledgeRelationship) for r in rels)

    def test_list_filter_kind(self, fstore):
        fstore.world_model.upsert_knowledge_relationship(
            "kr1",
            "k1",
            "k2",
            "supports",
        )
        fstore.world_model.upsert_knowledge_relationship(
            "kr2",
            "k1",
            "k3",
            "contradicts",
        )
        rels = fstore.world_model.list_knowledge_relationships(
            relationship_kind="supports",
        )
        assert all(r.relationship_kind == "supports" for r in rels)

    def test_list_empty(self, fstore):
        assert fstore.world_model.list_knowledge_relationships() == []


class TestFathomStoreVecProfile:
    def test_open_registers_vec_profile(self, fstore):
        # fathomdb 0.5.x requires per-kind VecProfile lookups; the per-kind
        # bootstrap lands in a later wave, so this test only asserts open()
        # completed without raising and the call with kind succeeds.
        profile = fstore.engine.admin.get_vec_profile("KnowledgeItem")
        # profile may be None until Wave 3 bootstrap; the important
        # contract here is that the call with kind does not raise.
        assert profile is None or profile.dimensions == 384

    def test_open_vec_profile_idempotent(self, tmp_path):
        db_path = str(tmp_path / "fathom.db")
        s1 = FathomStore.open(db_path)
        s1.close()
        s2 = FathomStore.open(db_path)  # second open — should not error
        profile = s2.engine.admin.get_vec_profile("KnowledgeItem")
        s2.close()
        assert profile is None or profile.dimensions == 384

    def test_open_logs_vec_profile(self, tmp_path, caplog):
        import logging

        db_path = str(tmp_path / "fathom.db")
        with caplog.at_level(logging.INFO, logger="memex.fathom_store"):
            store = FathomStore.open(db_path)
            store.close()
        assert any("VecProfile" in r.message for r in caplog.records)

    def test_open_warns_when_configure_vec_fails(self, tmp_path, caplog):
        import logging
        from unittest.mock import patch

        db_path = str(tmp_path / "fathom.db")
        with caplog.at_level(logging.WARNING, logger="memex.fathom_store"):
            with patch(
                "fathomdb.embedders.BuiltinEmbedder",
                side_effect=RuntimeError("embedder unavailable"),
            ):
                store = FathomStore.open(db_path)
                store.close()
        assert any(
            "VecProfile registration failed" in r.message for r in caplog.records
        )

    def test_open_calls_get_vec_profile_with_kind(self, tmp_path):
        """FathomStore.open() must call get_vec_profile('KnowledgeItem').

        fathomdb 0.5.0 made kind mandatory on get_vec_profile(); calling
        with zero args raises TypeError at runtime.
        """
        from unittest.mock import patch

        db_path = str(tmp_path / "fathom.db")
        with patch(
            "fathomdb._admin.AdminClient.get_vec_profile",
            wraps=lambda *a, **kw: None,
        ) as mock_gvp:
            store = FathomStore.open(db_path)
            store.close()
        # Every call must pass "KnowledgeItem" as the first positional arg
        # (or as kind= keyword).
        assert mock_gvp.call_count >= 1
        for call in mock_gvp.call_args_list:
            args, kwargs = call
            kind = args[0] if args else kwargs.get("kind")
            assert kind == "KnowledgeItem", (
                f"Expected get_vec_profile('KnowledgeItem'), got args={args!r} kwargs={kwargs!r}"
            )

    def test_open_logs_regeneration_warning(self, tmp_path, caplog):
        """open() warns operators to run nightly_vec_regeneration for existing DBs."""
        import logging

        db_path = str(tmp_path / "fathom.db")
        with caplog.at_level(logging.WARNING, logger="memex.fathom_store"):
            store = FathomStore.open(db_path)
            store.close()
        assert any("nightly_vec_regeneration" in r.message for r in caplog.records)

    def test_open_bootstraps_vec_on_fresh_db(self, tmp_path):
        """Fresh DB bootstrap: open() calls regenerate_vector_embeddings per-kind
        when the kind has a vec profile and the probe query returns no nodes.
        """
        from unittest.mock import MagicMock, patch

        from fathomdb import VectorRegenerationConfig

        db_path = str(tmp_path / "fathom.db")

        with patch(
            "fathomdb._admin.AdminClient.regenerate_vector_embeddings"
        ) as mock_regen:
            store = FathomStore.open(db_path)
            store.close()

        # Every call must pass a VectorRegenerationConfig with profile="default"
        calls_by_kind: dict[str, VectorRegenerationConfig] = {}
        for call in mock_regen.call_args_list:
            args, kwargs = call
            cfg = args[0] if args else kwargs.get("config")
            assert isinstance(cfg, VectorRegenerationConfig)
            calls_by_kind[cfg.kind] = cfg

        assert "KnowledgeItem" in calls_by_kind
        assert "ConversationTurn" in calls_by_kind
        for cfg in calls_by_kind.values():
            assert cfg.profile == "default"
            assert cfg.chunking_policy == "default"
            assert cfg.preprocessing_policy == "default"
        # Silence unused-var warning
        del MagicMock

    def test_open_skips_bootstrap_when_probe_has_nodes(self, tmp_path):
        """Non-empty probe: open() must NOT call regenerate_vector_embeddings
        for kinds that already have data.
        """
        from unittest.mock import MagicMock, patch

        db_path = str(tmp_path / "fathom.db")

        # Open once to create the DB
        store = FathomStore.open(db_path)
        store.close()

        # Simulate a non-empty probe by patching Query.execute to return rows
        # with a non-empty `.nodes` list, so the bootstrap short-circuits.
        fake_probe = MagicMock()
        fake_probe.nodes = [MagicMock()]

        with patch(
            "fathomdb._query.Query.execute",
            return_value=fake_probe,
        ):
            with patch(
                "fathomdb._admin.AdminClient.regenerate_vector_embeddings"
            ) as mock_regen:
                store = FathomStore.open(db_path)
                store.close()

        assert mock_regen.call_count == 0
