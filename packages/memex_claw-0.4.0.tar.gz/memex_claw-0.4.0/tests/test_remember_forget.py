"""Tests for /remember and /forget commands."""

from __future__ import annotations

from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest

from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.models import (
    ActionType,
    GoalStatus,
    Item,
    ItemType,
    Provenance,
    ScheduledTask,
)
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def fathom(tmp_path):
    """FathomDB-backed MemexStore for testing."""
    fs = FathomStore.open(str(tmp_path / "test-remember.db"))
    store = FathomMemexStore(fs)
    yield store
    store.close()


@pytest.fixture()
def content_store(fathom):
    return fathom.content


@pytest.fixture()
def scheduler_store(fathom):
    return fathom.scheduler


@pytest.fixture()
def memex_store(fathom):
    """MemexStore for tests that need goal/world-model operations."""
    return fathom


@pytest.fixture()
def _sample_item(content_store):
    """Create a sample item in the store."""
    now = utcnow()
    item = Item(
        item_id="test-item-001",
        type=ItemType.NOTE,
        title="WiFi password for office",
        body="The office WiFi password is hunter2",
        captured_at=now,
        last_accessed=now,
        tags=["credentials", "office"],
        provenance=Provenance(source="manual"),
    )
    content_store.create_item(item)
    return item


# ---------------------------------------------------------------------------
# Remember classification tests
# ---------------------------------------------------------------------------


class TestRememberClassification:
    def test_classify_fact(self):
        """Mock LLM returns FACT intent."""
        from memex.remember import RememberClassification, RememberIntent, _classify

        mock_result = RememberClassification(
            intent=RememberIntent.FACT,
            title="WiFi password",
            body="The WiFi password is hunter2",
            tags=["credentials"],
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = _classify("the WiFi password is hunter2")

        assert result.intent == RememberIntent.FACT
        assert result.title == "WiFi password"

    def test_classify_context(self):
        """Mock LLM returns CONTEXT intent."""
        from memex.remember import RememberClassification, RememberIntent, _classify

        mock_result = RememberClassification(
            intent=RememberIntent.CONTEXT,
            title="Debugging OAuth flow",
            body="Discussion about OAuth token refresh issues",
            tags=["debugging"],
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = _classify("remember this conversation")

        assert result.intent == RememberIntent.CONTEXT

    def test_classify_reminder(self):
        """Mock LLM returns REMINDER intent."""
        from memex.remember import RememberClassification, RememberIntent, _classify

        mock_result = RememberClassification(
            intent=RememberIntent.REMINDER,
            title="Call mom",
            body="Call mom to check in",
            tags=["personal"],
            reminder_time="2026-03-12T15:00:00",
            is_actionable=True,
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = _classify("remember to call mom Tuesday at 3pm")

        assert result.intent == RememberIntent.REMINDER
        assert result.is_actionable is True


# ---------------------------------------------------------------------------
# Remember FACT tests
# ---------------------------------------------------------------------------


class TestRememberFact:
    def test_fact_creates_note_item(self, content_store):
        """FACT intent creates a NOTE item in content store."""
        from memex.remember import (
            RememberClassification,
            RememberIntent,
            execute_remember,
        )

        mock_result = RememberClassification(
            intent=RememberIntent.FACT,
            title="API key for Stripe",
            body="The Stripe API key is sk_test_abc123",
            tags=["credentials", "stripe"],
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_remember(
                "the Stripe API key is sk_test_abc123",
                content_store=content_store,
            )

        assert result["intent"] == "fact"
        assert "item_id" in result

        # Verify item in store
        item = content_store.get_item(result["item_id"])
        assert item is not None
        assert item.type == ItemType.NOTE
        assert item.title == "API key for Stripe"
        assert "remembered" in item.tags
        assert item.provenance.source == "remember"
        assert item.provenance.confidence == 1.0


# ---------------------------------------------------------------------------
# Remember CONTEXT tests
# ---------------------------------------------------------------------------


class TestRememberContext:
    def test_context_creates_conversation_item(self, content_store, memex_store):
        """CONTEXT intent creates a CONVERSATION item."""
        from memex.remember import (
            RememberClassification,
            RememberIntent,
            execute_remember,
        )

        mock_result = RememberClassification(
            intent=RememberIntent.CONTEXT,
            title="OAuth debugging session",
            body="We were debugging OAuth token refresh",
            tags=["debugging", "oauth"],
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_remember(
                "remember this",
                content_store=content_store,
                memex_store=memex_store,
            )

        assert result["intent"] == "context"
        item = content_store.get_item(result["item_id"])
        assert item is not None
        assert item.type == ItemType.CONVERSATION
        assert "session-capture" in item.tags


# ---------------------------------------------------------------------------
# Remember REMINDER tests
# ---------------------------------------------------------------------------


class TestRememberReminder:
    def test_reminder_creates_scheduled_task(
        self, content_store, scheduler_store, memex_store
    ):
        """REMINDER intent creates a ScheduledTask."""
        from memex.remember import (
            RememberClassification,
            RememberIntent,
            execute_remember,
        )

        mock_result = RememberClassification(
            intent=RememberIntent.REMINDER,
            title="Call mom",
            body="Call mom to check in",
            tags=["personal"],
            reminder_time="2026-03-12T15:00:00",
            is_actionable=True,
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_remember(
                "remind me to call mom Tuesday at 3pm",
                content_store=content_store,
                memex_store=memex_store,
                scheduler_store=scheduler_store,
            )

        assert result["intent"] == "reminder"
        assert result["task_id"].startswith("reminder-")
        assert result["remind_at"] is not None

        # Verify task in scheduler
        task = scheduler_store.get_task(result["task_id"])
        assert task is not None
        assert task.action_type == ActionType.NOTIFICATION
        assert task.goal_id == result["goal_id"]
        assert task.action_data["one_shot"] is True
        assert task.action_data["task_id"] == result["task_id"]
        assert task.action_data["goal_id"] == result["goal_id"]

    def test_reminder_creates_goal_when_actionable(
        self, content_store, scheduler_store, memex_store
    ):
        """Actionable reminders create a Goal."""
        from memex.remember import (
            RememberClassification,
            RememberIntent,
            execute_remember,
        )

        mock_result = RememberClassification(
            intent=RememberIntent.REMINDER,
            title="File taxes",
            body="File 2025 taxes before deadline",
            tags=["finance"],
            reminder_time="2026-04-15T09:00:00",
            is_actionable=True,
        )

        with patch("memex.llm.chat_structured", return_value=mock_result):
            result = execute_remember(
                "remind me to file taxes by April 15",
                content_store=content_store,
                memex_store=memex_store,
                scheduler_store=scheduler_store,
            )

        assert result.get("goal_id") is not None
        goal = memex_store.get_goal(result["goal_id"])
        assert goal is not None
        assert goal.status == GoalStatus.ACTIVE
        assert goal.metadata["source"] == "remember"


# ---------------------------------------------------------------------------
# Time parsing tests
# ---------------------------------------------------------------------------


class TestTimeParsing:
    def test_iso_string(self):
        from memex.remember import _parse_reminder_time

        result = _parse_reminder_time("2026-03-12T15:00:00")
        assert result is not None
        assert result.hour == 15
        assert result.day == 12

    def test_none_input(self):
        from memex.remember import _parse_reminder_time

        assert _parse_reminder_time(None) is None
        assert _parse_reminder_time("") is None

    def test_one_shot_cron(self):
        from memex.remember import to_one_shot_cron

        dt = datetime(2026, 3, 12, 15, 30)
        cron = to_one_shot_cron(dt)
        assert cron == "30 15 12 3 *"


# ---------------------------------------------------------------------------
# Forget search tests
# ---------------------------------------------------------------------------


class TestForgetSearch:
    def test_search_finds_items(self, content_store, memex_store, _sample_item):
        from memex.forget import search_candidates

        memex_store.sync_world_model_knowledge_from_item(_sample_item)
        candidates = search_candidates("WiFi", content_store, memex_store)
        assert len(candidates) >= 1
        assert any(
            c.id == "world_model_knowledge:knowledge/test-item-001" for c in candidates
        )

    def test_search_finds_live_items_with_explicit_content_item_ids(
        self, content_store, _sample_item
    ):
        """FathomDB: search candidates finds items via content store."""
        from memex.forget import search_candidates

        # With FathomDB, knowledge objects and content items share the same
        # backing store, so we just verify the search finds the item.
        candidates = search_candidates("WiFi", content_store)
        assert len(candidates) >= 1

    def test_search_no_results(self, content_store):
        from memex.forget import search_candidates

        candidates = search_candidates("nonexistent_query_xyz", content_store)
        assert len(candidates) == 0

    def test_forget_accepts_canonical_knowledge_id_for_select_and_undo(
        self, content_store, memex_store, _sample_item
    ):
        from memex.forget import forget_items, restore_items

        memex_store.sync_world_model_knowledge_from_item(_sample_item)
        selection_id = "world_model_knowledge:knowledge/test-item-001"

        messages = forget_items([selection_id], content_store)
        assert any("Soft-deleted item" in message for message in messages)
        assert content_store.get_item("test-item-001") is None

        restore_messages = restore_items([selection_id], content_store)
        assert any("Restored item" in message for message in restore_messages)
        assert content_store.get_item("test-item-001") is not None

    def test_forget_accepts_content_item_id_for_select_and_undo(
        self, content_store, _sample_item
    ):
        from memex.forget import forget_items, restore_items

        selection_id = "content_item:test-item-001"

        messages = forget_items([selection_id], content_store)
        assert any("Soft-deleted item" in message for message in messages)
        assert content_store.get_item("test-item-001") is None

        restore_messages = restore_items([selection_id], content_store)
        assert any("Restored item" in message for message in restore_messages)
        assert content_store.get_item("test-item-001") is not None

    def test_forget_content_item_missing_does_not_fall_through_to_goal(
        self, content_store, memex_store
    ):
        from conftest import make_goal
        from memex.forget import forget_items

        goal = make_goal(title="Preserve me")
        goal.goal_id = "shared-id"
        memex_store.create_goal(goal)

        messages = forget_items(
            ["content_item:shared-id"],
            content_store,
            memex_store,
        )

        assert messages == ["Not found: [content_item:shared-id]"]
        stored_goal = memex_store.get_goal("shared-id")
        assert stored_goal is not None
        assert stored_goal.status == GoalStatus.ACTIVE

    def test_restore_content_item_missing_does_not_fall_through_to_goal(
        self, content_store, memex_store
    ):
        from conftest import make_goal
        from memex.forget import restore_items

        goal = make_goal(title="Preserve me")
        goal.goal_id = "shared-id"
        goal.metadata["forgotten"] = True
        goal.status = GoalStatus.ABANDONED
        memex_store.create_goal(goal)

        messages = restore_items(
            ["content_item:shared-id"],
            content_store,
            memex_store,
        )

        assert messages == ["Not found: [content_item:shared-id]"]
        stored_goal = memex_store.get_goal("shared-id")
        assert stored_goal is not None
        assert stored_goal.status == GoalStatus.ABANDONED


# ---------------------------------------------------------------------------
# Soft-delete tests
# ---------------------------------------------------------------------------


class TestSoftDelete:
    def test_soft_delete_hides_item(self, content_store, _sample_item):
        """Soft-deleted items are excluded from normal queries."""
        # Item visible before delete
        assert content_store.get_item("test-item-001") is not None

        # Soft-delete
        result = content_store.soft_delete_item("test-item-001")
        assert result is True

        # Item invisible from normal queries
        assert content_store.get_item("test-item-001") is None
        assert "test-item-001" not in content_store.get_items_batch(["test-item-001"])
        assert content_store.find_by_url(None) is None

        # Item visible in soft-deleted list
        soft_deleted = content_store.list_soft_deleted()
        assert len(soft_deleted) == 1
        assert soft_deleted[0].item_id == "test-item-001"
        assert soft_deleted[0].deleted_at is not None

    def test_soft_delete_excluded_from_list_items(self, content_store, _sample_item):
        content_store.soft_delete_item("test-item-001")
        items = content_store.list_items()
        assert all(i.item_id != "test-item-001" for i in items)

    def test_soft_delete_excluded_from_fts(self, content_store, _sample_item):
        content_store.soft_delete_item("test-item-001")
        results = content_store.fts_search("WiFi")
        assert all(item.item_id != "test-item-001" for item, _ in results)


# ---------------------------------------------------------------------------
# Restore tests
# ---------------------------------------------------------------------------


class TestRestore:
    def test_restore_makes_item_visible(self, content_store, _sample_item):
        """Restoring a soft-deleted item makes it queryable again."""
        content_store.soft_delete_item("test-item-001")
        assert content_store.get_item("test-item-001") is None

        result = content_store.restore_item("test-item-001")
        assert result is True

        item = content_store.get_item("test-item-001")
        assert item is not None
        assert item.deleted_at is None


# ---------------------------------------------------------------------------
# Purge tests
# ---------------------------------------------------------------------------


class TestPurge:
    def test_purge_deletes_old_items(self, content_store, _sample_item):
        """Items past grace period are hard-deleted by purge."""
        content_store.soft_delete_item("test-item-001")

        # Use a future cutoff so the recently-deleted item qualifies for purge
        cutoff = utcnow() + timedelta(hours=1)
        purged = content_store.purge_deleted(cutoff)
        assert purged == 1

        # Item is gone from everything (including soft-deleted list)
        assert content_store.list_soft_deleted() == []

    def test_purge_preserves_recent_deletes(self, content_store, _sample_item):
        """Items within grace period are preserved."""
        content_store.soft_delete_item("test-item-001")

        cutoff = utcnow() - timedelta(hours=1)
        purged = content_store.purge_deleted(cutoff)
        assert purged == 0

        assert len(content_store.list_soft_deleted()) == 1


# ---------------------------------------------------------------------------
# One-shot auto-disable test
# ---------------------------------------------------------------------------


class TestOneShotAutoDisable:
    def test_one_shot_disables_after_fire(self, scheduler_store):
        """One-shot reminder tasks are auto-disabled after notification fires."""
        now = utcnow()
        task = ScheduledTask(
            task_id="reminder-test123",
            name="Test Reminder",
            description="test",
            cron_expr="0 12 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={
                "generator": "reminder",
                "title": "Test",
                "body": "Test body",
                "one_shot": True,
                "task_id": "reminder-test123",
            },
            enabled=True,
            builtin=False,
            created_at=now,
            updated_at=now,
        )
        scheduler_store.create_task(task)

        from memex.scheduler.engine import SchedulerEngine

        engine = SchedulerEngine(
            scheduler_store,
            notification_store=MagicMock(),
        )

        # Dispatch the notification
        action_data = task.action_data
        engine._dispatch_notification(action_data, run_id=1)

        # Task should be disabled
        updated = scheduler_store.get_task("reminder-test123")
        assert updated is not None
        assert updated.enabled is False


# ---------------------------------------------------------------------------
# Tool handler integration tests
# ---------------------------------------------------------------------------


class TestToolHandlers:
    def test_remember_handler_missing_text(self):
        from memex.tools_builtin import execute_builtin

        result = execute_builtin("remember", {})
        assert result.success is False
        assert "text" in result.error

    def test_forget_handler_search_missing_query(self):
        from memex.tools_builtin import _STORES, execute_builtin

        _STORES["content"] = MagicMock()
        try:
            result = execute_builtin("forget", {"action": "search"})
            assert result.success is False
            assert "query" in result.error
        finally:
            _STORES.pop("content", None)

    def test_forget_handler_select_missing_ids(self):
        from memex.tools_builtin import _STORES, execute_builtin

        _STORES["content"] = MagicMock()
        try:
            result = execute_builtin("forget", {"action": "select", "query": "test"})
            assert result.success is False
            assert "ids" in result.error
        finally:
            _STORES.pop("content", None)

    @patch(
        "memex.tools_builtin._followup_document_id_for_item",
        return_value="world_model_knowledge:knowledge/remembered-item",
    )
    @patch("memex.remember.execute_remember")
    def test_remember_handler_returns_canonical_followup_document_id(
        self, mock_execute_remember, _mock_document_id
    ):
        from memex.tools_builtin import _STORES, execute_builtin

        mock_execute_remember.return_value = {
            "intent": "fact",
            "title": "Rust ownership",
            "item_id": "remembered-item",
            "tags": ["language", "systems"],
        }
        _STORES["content"] = MagicMock()
        _STORES["goal"] = MagicMock()
        _STORES["goal"].load_session.return_value = None
        try:
            result = execute_builtin("remember", {"text": "Remember Rust ownership"})
            assert result.success is True
            assert (
                "ID: world_model_knowledge:knowledge/remembered-item" in result.content
            )
        finally:
            _STORES.pop("content", None)
            _STORES.pop("goal", None)
