"""Tests for MCP servers config loading and env-var shorthand."""

from __future__ import annotations

import textwrap
from pathlib import Path

from memex.mcp_servers import (
    MCPServerEntry,
    MCPServersConfig,
    load_servers_config,
    servers_config_from_env,
)


class TestMCPServerEntry:
    def test_defaults(self):
        entry = MCPServerEntry(name="test", command="test-cmd")
        assert entry.transport == "stdio"
        assert entry.args == []
        assert entry.env is None
        assert entry.timeout_seconds == 30.0
        assert entry.integration is None
        assert entry.write is False
        assert entry.enabled is True

    def test_only_stdio_transport(self):
        import pytest

        with pytest.raises(ValueError, match="stdio"):
            MCPServerEntry(name="test", command="test", transport="sse")

    def test_custom_fields(self):
        entry = MCPServerEntry(
            name="filesystem",
            command="npx",
            args=["@modelcontextprotocol/server-filesystem", "/home/user"],
            capability_prefix="filesystem",
            integration="filesystem",
            timeout_seconds=60.0,
        )
        assert entry.name == "filesystem"
        assert entry.capability_prefix == "filesystem"
        assert entry.integration == "filesystem"
        assert entry.write is False

    def test_write_field(self):
        ro = MCPServerEntry(name="fs-ro", command="npx", integration="filesystem")
        rw = MCPServerEntry(
            name="fs-rw", command="npx", integration="filesystem", write=True
        )
        assert ro.write is False
        assert rw.write is True


class TestMCPServersConfig:
    def test_empty_config(self):
        config = MCPServersConfig()
        assert config.servers == []

    def test_with_servers(self):
        config = MCPServersConfig(
            servers=[
                MCPServerEntry(name="a", command="cmd-a"),
                MCPServerEntry(name="b", command="cmd-b"),
            ]
        )
        assert len(config.servers) == 2


class TestLoadServersConfig:
    def test_none_path_returns_empty(self):
        config = load_servers_config(None)
        assert config.servers == []

    def test_missing_file_returns_empty(self):
        config = load_servers_config("/nonexistent/path.yaml")
        assert config.servers == []

    def test_valid_yaml(self, tmp_path: Path):
        yaml_file = tmp_path / "servers.yaml"
        yaml_file.write_text(
            textwrap.dedent("""\
            servers:
              - name: filesystem
                command: npx
                args:
                  - "@modelcontextprotocol/server-filesystem"
                  - "/home/user/projects"
                capability_prefix: filesystem
                integration: filesystem
              - name: git
                command: npx
                args:
                  - "@modelcontextprotocol/server-git"
                capability_prefix: git
        """)
        )
        config = load_servers_config(yaml_file)
        assert len(config.servers) == 2
        assert config.servers[0].name == "filesystem"
        assert config.servers[0].integration == "filesystem"
        assert config.servers[1].name == "git"

    def test_valid_yaml_with_write(self, tmp_path: Path):
        yaml_file = tmp_path / "servers.yaml"
        yaml_file.write_text(
            textwrap.dedent("""\
            servers:
              - name: fs-ro
                command: npx
                args: ["@modelcontextprotocol/server-filesystem", "/code"]
                integration: filesystem
                write: false
              - name: fs-rw
                command: npx
                args: ["@modelcontextprotocol/server-filesystem", "/workspace"]
                integration: filesystem
                write: true
        """)
        )
        config = load_servers_config(yaml_file)
        assert len(config.servers) == 2
        assert config.servers[0].write is False
        assert config.servers[1].write is True

    def test_invalid_yaml_returns_empty(self, tmp_path: Path):
        yaml_file = tmp_path / "bad.yaml"
        yaml_file.write_text("{{{{not yaml")
        config = load_servers_config(yaml_file)
        assert config.servers == []

    def test_non_dict_yaml_returns_empty(self, tmp_path: Path):
        yaml_file = tmp_path / "list.yaml"
        yaml_file.write_text("- item1\n- item2\n")
        config = load_servers_config(yaml_file)
        assert config.servers == []

    def test_disabled_server(self, tmp_path: Path):
        yaml_file = tmp_path / "servers.yaml"
        yaml_file.write_text(
            textwrap.dedent("""\
            servers:
              - name: disabled_server
                command: some-cmd
                enabled: false
        """)
        )
        config = load_servers_config(yaml_file)
        assert len(config.servers) == 1
        assert config.servers[0].enabled is False


class TestServersConfigFromEnv:
    def test_no_env_vars_returns_empty(self):
        config = servers_config_from_env(env={})
        assert config.servers == []

    def test_yaml_config_loaded(self, tmp_path: Path):
        yaml_file = tmp_path / "servers.yaml"
        yaml_file.write_text(
            textwrap.dedent("""\
            servers:
              - name: fs-code
                command: npx
                args: ["@modelcontextprotocol/server-filesystem", "/code"]
                integration: filesystem
                write: false
              - name: fs-workspace
                command: npx
                args: ["@modelcontextprotocol/server-filesystem", "/workspace"]
                integration: filesystem
                write: true
        """)
        )
        env = {"MEMEX_MCP_SERVERS_CONFIG": str(yaml_file)}
        config = servers_config_from_env(env=env)

        assert len(config.servers) == 2
        assert config.servers[0].name == "fs-code"
        assert config.servers[0].write is False
        assert config.servers[1].name == "fs-workspace"
        assert config.servers[1].write is True
