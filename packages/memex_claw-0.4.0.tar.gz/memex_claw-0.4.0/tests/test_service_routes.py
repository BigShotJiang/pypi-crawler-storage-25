"""Integration tests for memex service route handlers.

Boots a real HttpGateway on an ephemeral port with a mocked MemexAPI,
then sends real HTTP requests to exercise every endpoint in service.py.
"""

from __future__ import annotations

import collections
import socket
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest

from memex.http_gateway import HttpGateway
from memex.service import _ServiceState, _register_routes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(port: int, host: str = "127.0.0.1", timeout: float = 2.0) -> None:
    """Poll until *host:port* accepts connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.1):
                return
        except OSError:
            time.sleep(0.01)
    raise RuntimeError(f"{host}:{port} not reachable within {timeout}s")


def _collect_sse(
    base: str,
    path: str,
    *,
    json: dict | None = None,
    method: str = "POST",
    headers: dict | None = None,
    stop_after: str | None = None,
    timeout: float = 3.0,
) -> list[str]:
    """Stream an SSE endpoint and collect lines until *stop_after* event or timeout."""
    lines: list[str] = []
    try:
        with httpx.Client(timeout=httpx.Timeout(timeout, connect=5)) as client:
            with client.stream(
                method, f"{base}{path}", json=json, headers=headers
            ) as resp:
                for line in resp.iter_lines():
                    lines.append(line)
                    if stop_after and stop_after in line:
                        break
    except httpx.ReadTimeout:
        pass  # expected for long-lived SSE
    return lines


def _make_goal(**overrides: Any) -> SimpleNamespace:
    defaults = dict(
        goal_id="g-1",
        parent_id=None,
        title="Ship docs",
        description="Write the docs",
        status="active",
        priority="medium",
        blocked_by_goal_id=None,
        blocked_reason=None,
        failure_reason=None,
        created_at=datetime(2025, 1, 1),
        updated_at=datetime(2025, 1, 1),
        last_touched_at=datetime(2025, 1, 1),
        deadline=None,
        metadata={},
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_meeting(**overrides: Any) -> SimpleNamespace:
    defaults = dict(
        meeting_id="m-1",
        state="created",
        title="Standup",
        attendees=["Alice"],
        recordings=[],
        created_at=datetime(2025, 1, 1),
        updated_at=datetime(2025, 1, 1),
        started_at=None,
        stopped_at=None,
        audio_path="",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_recording(**overrides: Any) -> SimpleNamespace:
    defaults = dict(
        recording_id="r-1",
        meeting_id="m-1",
        sequence_number=1,
        state="recorded",
        audio_path="/tmp/audio.wav",
        duration_seconds=60.0,
        sample_rate=16000,
        started_at=datetime(2025, 1, 1),
        stopped_at=datetime(2025, 1, 1),
        created_at=datetime(2025, 1, 1),
        updated_at=datetime(2025, 1, 1),
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_bridge():
    """Create an EventBridgeHandler without subscribing to the global EventBus."""
    from memex.interfaces.event_bridge import EventBridgeHandler

    bridge = EventBridgeHandler.__new__(EventBridgeHandler)
    bridge._lock = threading.Lock()
    bridge._subscribers = []
    bridge._ring_buffer = collections.deque(maxlen=500)
    bridge._event_id = 0
    return bridge


@pytest.fixture()
def service_app():
    """Boot a real HttpGateway with mocked API on an ephemeral port.

    Yields (base_url, mock_api, state) for each test.
    """
    port = _free_port()
    gateway = HttpGateway(port=port, host="127.0.0.1")
    mock_api = MagicMock()
    bridge = MagicMock()
    state = _ServiceState()

    _register_routes(gateway, mock_api, bridge, state)
    gateway.start()
    _wait_for_port(port)

    base = f"http://127.0.0.1:{port}"
    try:
        yield base, mock_api, state
    finally:
        gateway.stop()


@pytest.fixture()
def service_app_with_auth():
    """Like service_app but with Bearer token auth enabled."""
    port = _free_port()
    gateway = HttpGateway(port=port, host="127.0.0.1", auth_token="test-secret")

    mock_api = MagicMock()
    bridge = MagicMock()
    state = _ServiceState()

    # All routes need auth="gateway" for token checking to apply.
    # However, the service registers routes with auth="none" by default.
    # The gateway checks auth at the gateway level only when route.auth == "gateway".
    # So we register routes, then patch their auth field.
    _register_routes(gateway, mock_api, bridge, state)
    for route in gateway.routes:
        route.auth = "gateway"

    gateway.start()
    _wait_for_port(port)

    base = f"http://127.0.0.1:{port}"
    try:
        yield base, mock_api, state
    finally:
        gateway.stop()


class TestServiceState:
    def test_get_or_create_session_returns_valid_session(self):
        """get_or_create_session must create a SessionContext with required fields."""
        from memex.session import SessionContext

        state = _ServiceState()
        session = state.get_or_create_session("test-session-id")
        assert session is not None
        assert isinstance(session, SessionContext)
        assert session.session_id  # non-empty
        assert session.started_at is not None

    def test_get_or_create_session_reuses_existing(self):
        """Second call with same ID returns the same session object."""
        state = _ServiceState()
        s1 = state.get_or_create_session("abc")
        s2 = state.get_or_create_session("abc")
        assert s1 is s2


class TestHealth:
    def test_health_returns_ok(self, service_app):
        base, *_ = service_app
        r = httpx.get(f"{base}/v1/health")
        assert r.status_code == 200
        assert r.json() == {"status": "ok"}

    def test_status_returns_runtime_info(self, service_app):
        base, _, state = service_app
        state.telegram_running.set()
        state.scheduler_started.set()

        r = httpx.get(f"{base}/v1/status")
        assert r.status_code == 200
        data = r.json()
        assert "version" in data
        assert isinstance(data["uptime_seconds"], int)
        assert data["telegram_connected"] is True
        assert data["scheduler_running"] is True
        assert data["active_sessions"] == 0


class TestGoals:
    def test_list_goals(self, service_app):
        base, api, _ = service_app
        api.intent.return_value = [_make_goal()]

        r = httpx.get(f"{base}/v1/goals")
        assert r.status_code == 200
        assert "goals" in r.json()
        api.intent.assert_called_once()

    def test_list_goals_include_all_passes_flag_to_api(self, service_app):
        """GET /v1/goals?include_all=true must forward include_all=True to api.intent."""
        base, api, _ = service_app
        api.intent.return_value = [_make_goal()]

        r = httpx.get(f"{base}/v1/goals?include_all=true")
        assert r.status_code == 200
        call_kwargs = api.intent.call_args
        assert call_kwargs[1].get("include_all") is True

    def test_list_goals_default_does_not_set_include_all(self, service_app):
        """GET /v1/goals without include_all must call api.intent with include_all=False."""
        base, api, _ = service_app
        api.intent.return_value = []

        r = httpx.get(f"{base}/v1/goals")
        assert r.status_code == 200
        call_kwargs = api.intent.call_args
        assert call_kwargs[1].get("include_all") is False

    def test_create_goal(self, service_app):
        base, api, _ = service_app
        r = httpx.post(
            f"{base}/v1/goals", json={"title": "New goal", "description": "desc"}
        )
        assert r.status_code == 201
        data = r.json()
        assert data["title"] == "New goal"
        assert "goal_id" in data
        api.create_goal.assert_called_once()

    def test_create_goal_invalid_status(self, service_app):
        base, *_ = service_app
        r = httpx.post(f"{base}/v1/goals", json={"title": "X", "status": "bogus"})
        assert r.status_code == 400
        assert "error" in r.json()

    def test_create_goal_empty_body(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/goals", json={})
        assert r.status_code == 201
        api.create_goal.assert_called_once()

    def test_get_goal(self, service_app):
        base, api, _ = service_app
        api.get_goal.return_value = _make_goal()
        r = httpx.get(f"{base}/v1/goals/g-1")
        assert r.status_code == 200
        assert r.json()["goal_id"] == "g-1"

    def test_get_goal_not_found(self, service_app):
        base, api, _ = service_app
        api.get_goal.return_value = None
        r = httpx.get(f"{base}/v1/goals/nonexistent")
        assert r.status_code == 404

    def test_update_goal(self, service_app):
        base, api, _ = service_app
        goal = _make_goal()
        api.get_goal.return_value = goal

        r = httpx.put(f"{base}/v1/goals/g-1", json={"title": "Updated"})
        assert r.status_code == 200
        assert goal.title == "Updated"
        api.update_goal.assert_called_once()

    def test_update_goal_readonly_fields_rejected(self, service_app):
        """Readonly/unknown fields are now rejected with 400 (strict validation)."""
        base, api, _ = service_app
        goal = _make_goal()
        api.get_goal.return_value = goal

        r = httpx.put(
            f"{base}/v1/goals/g-1",
            json={
                "goal_id": "hacked",
                "created_at": "2000-01-01",
                "title": "OK",
            },
        )
        assert r.status_code == 400
        assert "goal_id" in r.text or "created_at" in r.text

    def test_update_goal_valid_fields_only(self, service_app):
        """Sending only allowed fields returns 200 and applies changes."""
        base, api, _ = service_app
        goal = _make_goal()
        api.get_goal.return_value = goal

        r = httpx.put(f"{base}/v1/goals/g-1", json={"title": "OK", "priority": "high"})
        assert r.status_code == 200
        assert goal.title == "OK"

    def test_update_goal_rejects_wrong_type(self, service_app):
        """A field with wrong type (e.g. int for str field) returns 400."""
        base, api, _ = service_app
        goal = _make_goal()
        api.get_goal.return_value = goal

        r = httpx.put(f"{base}/v1/goals/g-1", json={"title": 42})
        assert r.status_code == 400

    def test_update_goal_rejects_unknown_field(self, service_app):
        """An invented field name returns 400."""
        base, api, _ = service_app
        goal = _make_goal()
        api.get_goal.return_value = goal

        r = httpx.put(f"{base}/v1/goals/g-1", json={"invented_field": "x"})
        assert r.status_code == 400


class TestMeetings:
    def test_list_meetings(self, service_app):
        base, api, _ = service_app
        api.list_meetings.return_value = [_make_meeting()]
        r = httpx.get(f"{base}/v1/meetings")
        assert r.status_code == 200
        assert "meetings" in r.json()

    def test_create_meeting(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/meetings", json={"title": "Standup"})
        assert r.status_code == 201
        data = r.json()
        assert data["title"] == "Standup"
        assert "meeting_id" in data
        api.create_meeting.assert_called_once()

    def test_create_meeting_accepts_attendees_key(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/meetings", json={"title": "X", "attendees": ["Bob"]})
        assert r.status_code == 201
        created = api.create_meeting.call_args[0][0]
        assert created.attendees == ["Bob"]

    def test_get_meeting(self, service_app):
        base, api, _ = service_app
        api.get_meeting.return_value = _make_meeting()
        r = httpx.get(f"{base}/v1/meetings/m-1")
        assert r.status_code == 200

    def test_get_meeting_not_found(self, service_app):
        base, api, _ = service_app
        api.get_meeting.return_value = None
        r = httpx.get(f"{base}/v1/meetings/nonexistent")
        assert r.status_code == 404

    def test_update_meeting(self, service_app):
        base, api, _ = service_app
        meeting = _make_meeting()
        api.get_meeting.return_value = meeting
        r = httpx.put(f"{base}/v1/meetings/m-1", json={"title": "Retro"})
        assert r.status_code == 200
        assert meeting.title == "Retro"
        api.update_meeting.assert_called_once()

    def test_update_meeting_readonly_fields_rejected(self, service_app):
        """Readonly/unknown fields are now rejected with 400 (strict validation)."""
        base, api, _ = service_app
        meeting = _make_meeting()
        api.get_meeting.return_value = meeting
        r = httpx.put(
            f"{base}/v1/meetings/m-1",
            json={
                "meeting_id": "hacked",
                "recordings": [{"fake": True}],
                "title": "OK",
            },
        )
        assert r.status_code == 400
        assert "meeting_id" in r.text or "recordings" in r.text

    def test_update_meeting_valid_fields_only(self, service_app):
        """Sending only allowed meeting fields returns 200."""
        base, api, _ = service_app
        meeting = _make_meeting()
        api.get_meeting.return_value = meeting
        r = httpx.put(
            f"{base}/v1/meetings/m-1", json={"title": "OK", "notes": "some notes"}
        )
        assert r.status_code == 200
        assert meeting.title == "OK"

    def test_delete_meeting(self, service_app):
        base, api, _ = service_app
        r = httpx.delete(f"{base}/v1/meetings/m-1")
        assert r.status_code == 204
        api.delete_meeting.assert_called_once_with("m-1")

    def test_cleanup_stale_meetings(self, service_app):
        base, api, _ = service_app
        api.cleanup_stale_recordings.return_value = 3
        r = httpx.post(f"{base}/v1/meetings/cleanup")
        assert r.status_code == 200
        assert r.json() == {"cleaned": 3}


class TestRecordings:
    def test_get_recording(self, service_app):
        base, api, _ = service_app
        api.get_recording.return_value = _make_recording()
        r = httpx.get(f"{base}/v1/recordings/r-1")
        assert r.status_code == 200
        assert r.json()["recording_id"] == "r-1"

    def test_get_recording_not_found(self, service_app):
        base, api, _ = service_app
        api.get_recording.return_value = None
        r = httpx.get(f"{base}/v1/recordings/none")
        assert r.status_code == 404

    def test_update_recording(self, service_app):
        base, api, _ = service_app
        rec = _make_recording()
        api.get_recording.return_value = rec
        r = httpx.put(
            f"{base}/v1/recordings/r-1", json={"state": "failed", "error": "timeout"}
        )
        assert r.status_code == 200
        assert rec.state == "failed"
        api.update_recording.assert_called_once()

    def test_update_recording_readonly_fields_rejected(self, service_app):
        """Readonly/unknown fields are now rejected with 400 (strict validation)."""
        base, api, _ = service_app
        rec = _make_recording()
        api.get_recording.return_value = rec
        r = httpx.put(
            f"{base}/v1/recordings/r-1",
            json={
                "recording_id": "hacked",
                "meeting_id": "hacked",
                "state": "failed",
            },
        )
        assert r.status_code == 400
        assert "recording_id" in r.text or "meeting_id" in r.text

    def test_update_recording_valid_fields_only(self, service_app):
        """Sending only allowed recording fields returns 200."""
        base, api, _ = service_app
        rec = _make_recording()
        api.get_recording.return_value = rec
        r = httpx.put(f"{base}/v1/recordings/r-1", json={"vad_threshold": 0.3})
        assert r.status_code == 200
        assert rec.vad_threshold == 0.3


class TestKnowledgeSearch:
    def test_self_state(self, service_app):
        base, api, _ = service_app
        api.self_state.return_value = {"knowledge": "graph"}
        r = httpx.get(f"{base}/v1/self-state")
        assert r.status_code == 200
        assert r.json() == {"knowledge": "graph"}

    def test_search(self, service_app):
        base, api, _ = service_app
        api.search.return_value = [{"title": "Result"}]
        r = httpx.post(f"{base}/v1/search", json={"query": "hello"})
        assert r.status_code == 200
        assert r.json()["results"] == [{"title": "Result"}]

    def test_search_missing_query(self, service_app):
        base, *_ = service_app
        r = httpx.post(f"{base}/v1/search", json={})
        assert r.status_code == 400
        assert "query required" in r.json()["error"]


class TestIngest:
    def test_ingest_url(self, service_app):
        base, api, _ = service_app
        api.ingest_url.return_value = {"status": "ok"}
        r = httpx.post(f"{base}/v1/ingest", json={"url": "https://example.com"})
        assert r.status_code == 200
        api.ingest_url.assert_called_once_with("https://example.com")

    def test_ingest_text(self, service_app):
        base, api, _ = service_app
        api.ingest_content.return_value = {"status": "ok"}
        r = httpx.post(
            f"{base}/v1/ingest", json={"text": "some content", "title": "Doc"}
        )
        assert r.status_code == 200
        api.ingest_content.assert_called_once_with("some content", title="Doc")

    def test_ingest_missing_both(self, service_app):
        base, *_ = service_app
        r = httpx.post(f"{base}/v1/ingest", json={})
        assert r.status_code == 400
        assert "url or text required" in r.json()["error"]


class TestScheduler:
    def test_list_tasks(self, service_app):
        base, api, _ = service_app
        api.list_tasks.return_value = []
        r = httpx.get(f"{base}/v1/scheduler/tasks")
        assert r.status_code == 200
        assert r.json() == {"tasks": []}

    def test_get_task(self, service_app):
        base, api, _ = service_app
        task = SimpleNamespace(task_id="t-1", name="daily", enabled=True)
        api.get_task.return_value = task
        r = httpx.get(f"{base}/v1/scheduler/tasks/t-1")
        assert r.status_code == 200
        assert r.json()["task_id"] == "t-1"

    def test_get_task_not_found(self, service_app):
        base, api, _ = service_app
        api.get_task.return_value = None
        r = httpx.get(f"{base}/v1/scheduler/tasks/missing")
        assert r.status_code == 404

    def test_toggle_task(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/scheduler/tasks/t-1/toggle", json={"enabled": False})
        assert r.status_code == 200
        api.toggle_task.assert_called_once_with("t-1", False)

    def test_run_task(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/scheduler/tasks/t-1/run")
        assert r.status_code == 200
        assert r.json()["status"] == "triggered"
        api.enqueue_work.assert_called_once_with("scheduled_task", {"task_id": "t-1"})

    def test_get_last_run(self, service_app):
        base, api, _ = service_app
        api.get_last_task_run.return_value = {"ran_at": "2025-01-01"}
        r = httpx.get(f"{base}/v1/scheduler/tasks/t-1/last-run")
        assert r.status_code == 200


class TestNotifications:
    def test_list_notifications_unread(self, service_app):
        base, api, _ = service_app
        api.list_notifications.return_value = []
        r = httpx.get(f"{base}/v1/notifications")
        assert r.status_code == 200
        api.list_notifications.assert_called_once_with(unread_only=True)

    def test_list_notifications_all(self, service_app):
        base, api, _ = service_app
        api.list_notifications.return_value = []
        r = httpx.get(f"{base}/v1/notifications?unread_only=false")
        assert r.status_code == 200
        api.list_notifications.assert_called_once_with(unread_only=False)

    def test_dismiss_notification(self, service_app):
        base, api, _ = service_app
        r = httpx.post(f"{base}/v1/notifications/n-1", json={"action": "dismiss"})
        assert r.status_code == 200
        api.act_on_notification.assert_called_once_with("n-1", "dismiss")


class TestSessions:
    def test_delete_session(self, service_app):
        base, api, state = service_app
        state.sessions["s-1"] = MagicMock()
        r = httpx.delete(f"{base}/v1/sessions/s-1")
        assert r.status_code == 204
        api.end_session.assert_called_once()
        assert "s-1" not in state.sessions

    def test_delete_session_nonexistent(self, service_app):
        base, api, _ = service_app
        r = httpx.delete(f"{base}/v1/sessions/nope")
        assert r.status_code == 204  # idempotent


class TestMeetingGoalLinks:
    def test_create_link(self, service_app):
        base, api, _ = service_app
        r = httpx.post(
            f"{base}/v1/meeting-goal-links",
            json={
                "meeting_id": "m-1",
                "goal_id": "g-1",
            },
        )
        assert r.status_code == 201
        api.create_meeting_goal_link.assert_called_once()


class TestSubagents:
    def test_list_subagents(self, service_app):
        base, api, _ = service_app
        api.list_subagents.return_value = [{"id": "a-1"}]
        r = httpx.get(f"{base}/v1/subagents")
        assert r.status_code == 200
        assert r.json() == {"subagents": [{"id": "a-1"}]}


class TestAudioRecording:
    def test_start_recording_meeting_not_found(self, service_app):
        base, api, _ = service_app
        api.get_meeting.return_value = None
        r = httpx.post(f"{base}/v1/meetings/m-1/record/start")
        assert r.status_code == 404

    def test_stop_recording_no_active(self, service_app):
        base, *_ = service_app
        r = httpx.post(f"{base}/v1/meetings/m-1/record/stop")
        assert r.status_code == 404
        assert "No active recording" in r.json()["error"]

    def test_start_recording_already_active(self, service_app):
        base, _, state = service_app
        state.audio_captures["m-1"] = (MagicMock(), "r-existing")
        r = httpx.post(f"{base}/v1/meetings/m-1/record/start")
        assert r.status_code == 200
        assert r.json()["status"] == "recording"

    def test_stop_recording_success(self, service_app):
        base, api, state = service_app
        mock_capture = MagicMock()
        mock_capture.stop.return_value = ("/audio/out.wav", 42.5)
        state.audio_captures["m-1"] = (mock_capture, "r-1")

        mock_store = MagicMock()
        mock_store.get_recording.return_value = _make_recording()
        api.store.meetings = mock_store
        api.get_meeting.return_value = _make_meeting()

        r = httpx.post(f"{base}/v1/meetings/m-1/record/stop")
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "stopped"
        assert data["duration_seconds"] == 42.5
        mock_capture.stop.assert_called_once()


class TestTranscription:
    def test_transcribe_meeting_not_found(self, service_app):
        base, api, _ = service_app
        api.get_meeting.return_value = None
        r = httpx.post(f"{base}/v1/meetings/m-1/transcribe")
        assert r.status_code == 404

    def test_transcribe_no_recorded_audio(self, service_app):
        base, api, _ = service_app
        api.get_meeting.return_value = _make_meeting(recordings=[])
        r = httpx.post(f"{base}/v1/meetings/m-1/transcribe")
        assert r.status_code == 404
        assert "No recorded audio" in r.json()["error"]

    def test_transcribe_success(self, service_app):
        base, api, _ = service_app
        from memex.meetings.models import MeetingState

        rec = _make_recording(state=MeetingState.RECORDED)
        api.get_meeting.return_value = _make_meeting(recordings=[rec])
        r = httpx.post(f"{base}/v1/meetings/m-1/transcribe")
        assert r.status_code == 200
        assert r.json()["status"] == "queued"
        api.enqueue_work.assert_called_once()


class TestAuth:
    def test_no_token_configured_allows_all(self, service_app):
        base, *_ = service_app
        r = httpx.get(f"{base}/v1/health")
        assert r.status_code == 200

    def test_valid_bearer_token(self, service_app_with_auth):
        base, *_ = service_app_with_auth
        r = httpx.get(
            f"{base}/v1/health",
            headers={"Authorization": "Bearer test-secret"},
        )
        assert r.status_code == 200

    def test_invalid_bearer_token(self, service_app_with_auth):
        base, *_ = service_app_with_auth
        r = httpx.get(
            f"{base}/v1/health",
            headers={"Authorization": "Bearer wrong"},
        )
        assert r.status_code == 401

    def test_missing_bearer_token(self, service_app_with_auth):
        base, *_ = service_app_with_auth
        r = httpx.get(f"{base}/v1/health")
        assert r.status_code == 401


class TestErrorHandling:
    def test_malformed_json_body(self, service_app):
        base, api, _ = service_app
        # Send invalid JSON — handler should get {} from _req_json and proceed
        r = httpx.post(
            f"{base}/v1/goals",
            content=b"not-json",
            headers={"Content-Type": "application/json"},
        )
        # Empty body means default title="" and status="active" — should succeed
        assert r.status_code == 201
        api.create_goal.assert_called_once()

    def test_unknown_route(self, service_app):
        base, *_ = service_app
        r = httpx.get(f"{base}/v1/nonexistent")
        assert r.status_code == 404

    def test_handler_exception_returns_500(self, service_app):
        base, api, _ = service_app
        api.self_state.side_effect = RuntimeError("boom")
        r = httpx.get(f"{base}/v1/self-state")
        assert r.status_code == 500

    def test_empty_body_on_search(self, service_app):
        """POST /v1/search with no Content-Length should not crash."""
        base, *_ = service_app
        r = httpx.post(f"{base}/v1/search")
        assert r.status_code == 400

    def test_get_on_post_only_route(self, service_app):
        """GET /v1/search should 404 since it only accepts POST."""
        base, *_ = service_app
        r = httpx.get(f"{base}/v1/search")
        assert r.status_code == 404


class TestChatSSE:
    def test_chat_streams_tokens(self, service_app):
        base, api, state = service_app

        # Mock session creation to return a non-None session
        state.get_or_create_session = MagicMock(return_value=MagicMock())

        def fake_chat(message, caller, session=None, on_token=None, on_event=None):
            on_token("Hello ")
            on_token("world")

        api.chat.side_effect = fake_chat

        lines = _collect_sse(
            base, "/v1/chat", json={"message": "hi", "session_id": "s-1"}
        )
        body = "\n".join(lines)
        assert "event: token" in body
        assert '"Hello "' in body
        assert "event: done" in body

    def test_chat_missing_message(self, service_app):
        base, *_ = service_app
        lines = _collect_sse(base, "/v1/chat", json={}, stop_after="missing_message")
        body = "\n".join(lines)
        assert "event: error" in body
        assert "missing_message" in body

    def test_chat_emits_done_with_session_id(self, service_app):
        base, api, state = service_app
        state.get_or_create_session = MagicMock(return_value=MagicMock())
        api.chat.side_effect = lambda *a, **kw: None  # no tokens

        lines = _collect_sse(
            base,
            "/v1/chat",
            json={"message": "test", "session_id": "my-session"},
            stop_after="my-session",
        )
        body = "\n".join(lines)
        assert "event: done" in body
        assert "my-session" in body

    def test_chat_cancel(self, service_app):
        base, api, state = service_app
        state.get_or_create_session = MagicMock(return_value=MagicMock())

        started = threading.Event()

        def slow_chat(message, caller, session=None, on_token=None, on_event=None):
            started.set()
            for _ in range(50):
                time.sleep(0.05)
                on_token(".")

        api.chat.side_effect = slow_chat

        collected: list[str] = []

        def do_stream():
            try:
                with httpx.Client(timeout=httpx.Timeout(5, connect=5)) as client:
                    with client.stream(
                        "POST",
                        f"{base}/v1/chat",
                        json={"message": "slow", "session_id": "cancel-me"},
                    ) as resp:
                        for line in resp.iter_lines():
                            collected.append(line)
                            if "interrupted" in line:
                                break
            except httpx.ReadTimeout:
                pass

        t = threading.Thread(target=do_stream)
        t.start()
        started.wait(timeout=3)
        time.sleep(0.1)

        # Send cancel
        r = httpx.delete(f"{base}/v1/chat/cancel-me")
        assert r.status_code == 204

        t.join(timeout=5)
        body = "\n".join(collected)
        assert "event: interrupted" in body

    def test_chat_auto_generates_session_id(self, service_app):
        base, api, state = service_app
        state.get_or_create_session = MagicMock(return_value=MagicMock())
        api.chat.side_effect = lambda *a, **kw: None

        lines = _collect_sse(
            base,
            "/v1/chat",
            json={"message": "test"},  # no session_id
            stop_after="session_id",
        )
        body = "\n".join(lines)
        assert "event: done" in body
        # session_id should be a UUID (36 chars)
        import re

        match = re.search(r'"session_id":\s*"([^"]+)"', body)
        assert match is not None
        assert len(match.group(1)) == 36


class TestEventsSSE:
    def test_events_stream_forwards_domain_events(self, service_app):
        base, _, state = service_app

        bridge = _make_bridge()
        port = _free_port()
        gateway = HttpGateway(port=port, host="127.0.0.1")
        _register_routes(gateway, MagicMock(), bridge, state)
        gateway.start()
        _wait_for_port(port)

        received = []

        def do_stream():
            try:
                with httpx.Client(timeout=3) as client:
                    with client.stream(
                        "GET", f"http://127.0.0.1:{port}/v1/events"
                    ) as resp:
                        for line in resp.iter_lines():
                            received.append(line)
                            if "test_event" in line:
                                break
            except httpx.ReadTimeout:
                pass

        t = threading.Thread(target=do_stream)
        t.start()
        time.sleep(0.3)  # Wait for subscriber to register

        # Simulate a domain event via the bridge
        @dataclass
        class TestEvent:
            msg: str = "hello"

        bridge.on_event(TestEvent())
        t.join(timeout=5)
        gateway.stop()

        full = "\n".join(received)
        assert "test_event" in full

    def test_events_stream_last_event_id_replay(self, service_app):
        """Bridge replays missed events when Last-Event-ID is sent."""
        bridge = _make_bridge()

        port = _free_port()
        gateway = HttpGateway(port=port, host="127.0.0.1")
        state = _ServiceState()
        _register_routes(gateway, MagicMock(), bridge, state)
        gateway.start()
        _wait_for_port(port)

        # Pre-populate the ring buffer with events
        @dataclass
        class Ev:
            n: int

        for i in range(3):
            bridge.on_event(Ev(n=i))

        # Now connect with Last-Event-ID=1 — should replay events 2 and 3
        received = []

        def do_stream():
            try:
                with httpx.Client(timeout=2) as client:
                    with client.stream(
                        "GET",
                        f"http://127.0.0.1:{port}/v1/events",
                        headers={"Last-Event-ID": "1"},
                    ) as resp:
                        for line in resp.iter_lines():
                            received.append(line)
            except httpx.ReadTimeout:
                pass

        t = threading.Thread(target=do_stream)
        t.start()
        t.join(timeout=5)
        gateway.stop()

        full = "\n".join(received)
        # Should contain events with id 2 and 3 (but not 1)
        assert "id: 2" in full
        assert "id: 3" in full


class TestConcurrency:
    def test_concurrent_goal_reads(self, service_app):
        """Multiple simultaneous requests don't interfere."""
        base, api, _ = service_app
        api.intent.return_value = []

        errors = []

        def fetch():
            try:
                r = httpx.get(f"{base}/v1/goals")
                if r.status_code != 200:
                    errors.append(r.status_code)
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=fetch) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        assert errors == []

    def test_session_isolation(self, service_app):
        base, api, state = service_app

        # Create two sessions
        r1 = httpx.delete(f"{base}/v1/sessions/s-1")
        r2 = httpx.delete(f"{base}/v1/sessions/s-2")
        assert r1.status_code == 204
        assert r2.status_code == 204

        # end_session called for each
        assert api.end_session.call_count == 2
        calls = [c.args[0].session_id for c in api.end_session.call_args_list]
        assert "s-1" in calls
        assert "s-2" in calls

    def test_audio_lock_prevents_double_start(self, service_app):
        """If a recording is already active, second start returns idempotent response."""
        base, _, state = service_app
        state.audio_captures["m-1"] = (MagicMock(), "r-1")

        results = []

        def start():
            r = httpx.post(f"{base}/v1/meetings/m-1/record/start")
            results.append(r.json())

        threads = [threading.Thread(target=start) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        # All should return "recording" status (idempotent)
        assert all(r["status"] == "recording" for r in results)


class TestStartupShutdown:
    def test_sd_notify_ready(self):
        """_sd_notify sends to NOTIFY_SOCKET when set."""
        import socket as sock

        from memex.service import _sd_notify

        server = sock.socket(sock.AF_UNIX, sock.SOCK_DGRAM)
        import tempfile
        import os

        path = tempfile.mktemp(suffix=".sock")
        server.bind(path)

        try:
            with patch.dict(os.environ, {"NOTIFY_SOCKET": path}):
                _sd_notify("READY=1")
            data = server.recv(1024)
            assert data == b"READY=1"
        finally:
            server.close()
            os.unlink(path)

    def test_sd_notify_skipped_without_socket(self):
        """No error when NOTIFY_SOCKET is unset."""
        from memex.service import _sd_notify

        with patch.dict(__import__("os").environ, {}, clear=True):
            _sd_notify("READY=1")  # should not raise

    def test_watchdog_loop_exits_on_shutdown(self):
        from memex.service import _watchdog_loop

        shutdown = threading.Event()
        shutdown.set()
        _watchdog_loop(shutdown)  # should return immediately

    def test_run_blocks_second_instance(self, tmp_path):
        """run() exits with code 1 if another process holds the lock."""
        import fcntl

        lock_file = tmp_path / ".memex" / "service.lock"
        lock_file.parent.mkdir(parents=True)
        lock_file.write_text("")

        fd = lock_file.open("w")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

        try:
            with patch("memex.paths.resolve_service_lock_file", return_value=lock_file):
                with pytest.raises(SystemExit) as exc_info:
                    from memex.service import run

                    run(str(tmp_path / ".memex" / "memex.db"))
                assert exc_info.value.code == 1
        finally:
            fd.close()

    def test_run_writes_and_removes_url_file(self, tmp_path):
        """run() writes service.url during operation and removes it on shutdown."""
        from memex.service import run

        lock_file = tmp_path / ".memex" / "service.lock"
        url_file = tmp_path / ".memex" / "service.url"

        url_file_existed_during_run = threading.Event()

        def fake_watchdog(shutdown_event):
            if url_file.exists():
                url_file_existed_during_run.set()
            shutdown_event.set()

        mock_api = MagicMock()
        mock_gateway = MagicMock()

        with (
            patch("memex.paths.resolve_service_lock_file", return_value=lock_file),
            patch("memex.paths.resolve_service_url_file", return_value=url_file),
            patch("memex.interfaces.api.MemexAPI") as mock_api_cls,
            patch("memex.http_gateway.HttpGateway", return_value=mock_gateway),
            patch("memex.interfaces.event_bridge.EventBridgeHandler"),
            patch("memex.service._register_routes"),
            patch("memex.service._start_scheduler"),
            patch("memex.service._sd_notify"),
            patch("memex.service._watchdog_loop", side_effect=fake_watchdog),
        ):
            mock_api_cls.create.return_value = mock_api
            run(str(tmp_path / ".memex" / "memex.db"), no_telegram=True)

        assert url_file_existed_during_run.is_set(), (
            "service.url not written during run"
        )
        assert not url_file.exists(), "service.url not removed after shutdown"

    def test_run_port_error_exits_cleanly(self, tmp_path):
        """run() exits with code 1 and closes the API when port bind fails."""
        from memex.service import run

        lock_file = tmp_path / ".memex" / "service.lock"
        url_file = tmp_path / ".memex" / "service.url"

        mock_api = MagicMock()
        mock_gateway = MagicMock()
        mock_gateway.start.side_effect = OSError("Address already in use")

        with (
            patch("memex.paths.resolve_service_lock_file", return_value=lock_file),
            patch("memex.paths.resolve_service_url_file", return_value=url_file),
            patch("memex.interfaces.api.MemexAPI") as mock_api_cls,
            patch("memex.http_gateway.HttpGateway", return_value=mock_gateway),
            patch("memex.interfaces.event_bridge.EventBridgeHandler"),
            patch("memex.service._register_routes"),
            patch("memex.service._sd_notify"),
        ):
            mock_api_cls.create.return_value = mock_api
            with pytest.raises(SystemExit) as exc_info:
                run(str(tmp_path / ".memex" / "memex.db"), no_telegram=True)
            assert exc_info.value.code == 1

        mock_api.close.assert_called_once()
        assert not url_file.exists()

    def test_telegram_watchdog_notifies_on_unexpected_exit(self):
        """When telegram bot thread crashes, a HIGH-priority notification is created."""
        import threading
        from memex.service import _start_telegram

        running = threading.Event()
        mock_api = MagicMock()
        mock_ns = MagicMock()
        mock_api.notification_store = mock_ns
        mock_router = MagicMock()

        config = MagicMock()
        config.allowed_user_ids = [42]

        with (
            patch("memex.interfaces.telegram.config_from_env", return_value=config),
            patch("memex.interfaces.telegram.TelegramBot") as mock_bot_cls,
            patch("memex.notifications.NotificationRouter", return_value=mock_router),
        ):
            mock_bot_cls.return_value.run.side_effect = RuntimeError("connection lost")
            _start_telegram(mock_api, running)
            # Join the thread so it completes before we check
            import time

            time.sleep(0.2)

        # The error handler should have attempted to notify
        assert mock_api.notification_store is mock_ns
