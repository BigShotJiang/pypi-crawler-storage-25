"""Tests for the agentic loop with mocked LLM."""

from unittest.mock import patch

from conftest import make_item
from memex.agent_self_model import save_agent_self_model
from memex.human_model import save_partner_profile
from memex.llm import TokenUsage
from memex.loop import _signals_continuation
import pytest

from memex.memory.conversation_extract import CombinedExtractReflectResult
from memex.memory.retrieval import RetrievalResult
from memex.models import (
    AgentCapability,
    AgentLimitation,
    AgentSelfModel,
    Goal,
    GoalPriority,
    GoalStatus,
    HumanKnowledgeProfile,
    HumanPartnerProfile,
    HumanWorkingContext,
    InputClassification,
    InputClassificationType,
    IntentActionCandidate,
    IntentFrame,
    IntentFramePath,
    SessionContext,
    ToolDefinition,
    ToolResult,
    TurnCancelled,
    TurnCompleted,
    TurnEvent,
    TurnPhase,
    WorldModelActionPlan,
    WorldModelPlanStep,
)
from memex.loop import (
    _build_selected_action_payload,
    _persist_world_model_decision_outcome,
    _persist_world_model_tool_execution,
    _persist_world_model_turn_event,
    _resolve_execution_authority,
    run_turn,
)
from memex.prompt_budget import PromptBudgetConfig
from memex.tools import ToolRegistry
from memex.utcnow import utcnow

_MOCK_USAGE = TokenUsage(
    prompt_tokens=100, completion_tokens=50, total_tokens=150, cost_usd=0.001
)


def _mock_classify_new_goal(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.NEW_GOAL,
        confidence=0.9,
        reasoning="new intent detected",
    )


def _mock_classify_conversational(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )


def _mock_classify_fallback(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.0,
        reasoning="classification failed - fallback",
    )


def _mock_chat_with_usage(messages, **kwargs):
    return "That sounds like a great goal! Let's get started.", _MOCK_USAGE


def _mock_extract(**kwargs):
    return CombinedExtractReflectResult(
        reflection_note="New goal identified",
        confidence=0.8,
    )


def _prompt_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "\n".join(parts)
    return str(content)


def test_run_turn_new_goal(memory_store, tmp_path):
    """Full loop: new goal input creates a goal and returns response."""
    with (
        patch("memex.classify.classify_input", _mock_classify_new_goal),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "I want to learn Rust",
            memory_store,
            project_root=tmp_path,
        )

    assert "great goal" in response.lower()
    goals = memory_store.list_goals(GoalStatus.ACTIVE)
    assert len(goals) == 1
    assert "Rust" in goals[0].title


def test_run_turn_new_goal_links_selected_action_and_turn_event_to_goal(
    memory_store, tmp_path
):
    with (
        patch("memex.classify.classify_input", _mock_classify_new_goal),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _response, session = run_turn(
            "I want to learn Rust",
            memory_store,
            project_root=tmp_path,
        )

    goals = memory_store.list_goals(GoalStatus.ACTIVE)
    assert len(goals) == 1
    goal_id = goals[0].goal_id

    action = memory_store.list_world_model_actions(
        session_id=session.session_id,
        action_kind="selected_action",
        limit=1,
    )[0]
    event = memory_store.list_world_model_events(
        session_id=session.session_id,
        event_kind="turn_outcome",
        limit=1,
    )[0]

    action_links = memory_store.list_world_model_provenance_links(
        source_record_type="world_model_action",
        source_record_id=action.action_id,
    )
    event_links = memory_store.list_world_model_provenance_links(
        source_record_type="world_model_event",
        source_record_id=event.event_id,
    )

    assert any(
        link.relationship == "for_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == goal_id
        for link in action_links
    )
    assert any(
        link.relationship == "for_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == goal_id
        for link in event_links
    )


def test_run_turn_conversational(memory_store, tmp_path):
    """Conversational input doesn't create goals."""
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Hey, how's it going?",
            memory_store,
            project_root=tmp_path,
        )

    assert response != ""
    goals = memory_store.list_goals()
    assert len(goals) == 0


def test_tool_execution_persists_structured_planning_refs(memory_store):
    result = ToolResult(
        tool_name="remember",
        success=True,
        content="Reminder set",
        source="builtin",
        duration_ms=0,
        metadata={
            "world_model_refs": [
                {
                    "relationship": "creates_task",
                    "record_type": "world_model_task",
                    "record_id": "task-123",
                },
                {
                    "relationship": "creates_goal",
                    "record_type": "world_model_goal",
                    "record_id": "goal-created-123",
                },
            ]
        },
    )

    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-tool-planning",
        turn_ordinal=1,
        intent_id="intent-tool-planning",
        prompt_control_artifact_id=None,
        tool_call_id="remember-1",
        tool_name="remember",
        arguments={"text": "remind me to ship docs"},
        result=result,
        goal_id="goal-context-123",
    )

    action = memory_store.list_world_model_actions(
        session_id="session-tool-planning",
        action_kind="tool_call",
        limit=1,
    )[0]
    links = memory_store.list_world_model_provenance_links(
        source_record_type="world_model_action",
        source_record_id=action.action_id,
    )

    assert any(
        link.relationship == "for_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == "goal-context-123"
        for link in links
    )
    assert any(
        link.relationship == "creates_task"
        and link.target_record_type == "world_model_task"
        and link.target_record_id == "task-123"
        for link in links
    )
    assert any(
        link.relationship == "creates_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == "goal-created-123"
        for link in links
    )


def test_tool_execution_links_to_selected_canonical_plan_step_for_goal(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-context-123",
            goal_id="goal-context-123",
            title="Contextual rollout plan",
            summary="Drive execution through an explicit current step.",
            status="active",
            selected_step_id="step-context-123",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-context-123",
            plan_id="plan-context-123",
            goal_id="goal-context-123",
            step_kind="execution",
            title="Execute migration",
            description="Run the migration.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    result = ToolResult(
        tool_name="remember",
        success=True,
        content="Reminder set",
        source="builtin",
        duration_ms=0,
        metadata={"world_model_refs": []},
    )

    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-tool-selected-step",
        turn_ordinal=1,
        intent_id="intent-tool-selected-step",
        prompt_control_artifact_id=None,
        tool_call_id="remember-selected-step",
        tool_name="remember",
        arguments={"text": "remind me to ship docs"},
        result=result,
        goal_id="goal-context-123",
    )

    action = memory_store.list_world_model_actions(
        session_id="session-tool-selected-step",
        action_kind="tool_call",
        limit=1,
    )[0]
    links = memory_store.list_world_model_provenance_links(
        source_record_type="world_model_action",
        source_record_id=action.action_id,
    )

    assert any(
        link.relationship == "for_plan"
        and link.target_record_type == "world_model_action_plan"
        and link.target_record_id == "plan-context-123"
        for link in links
    )
    assert any(
        link.relationship == "executes_step"
        and link.target_record_type == "world_model_plan_step"
        and link.target_record_id == "step-context-123"
        for link in links
    )


def test_resolve_execution_authority_uses_active_plan_selected_step_for_goal(
    memory_store,
):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-authority-goal",
            goal_id="goal-authority-goal",
            title="Goal authority plan",
            summary="Use selected step from active plan.",
            status="active",
            selected_step_id="step-authority-goal",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        memory_store,
        goal_id="goal-authority-goal",
        transition_spec=None,
    )

    assert resolved_goal_id == "goal-authority-goal"
    assert resolved_plan_id == "plan-authority-goal"
    assert resolved_step_id == "step-authority-goal"


def test_resolve_execution_authority_honors_explicit_plan_override(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-explicit-authority",
            goal_id="goal-explicit-authority",
            title="Explicit authority plan",
            summary="Use explicit plan authority.",
            status="active",
            selected_step_id="step-explicit-authority",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        memory_store,
        goal_id=None,
        transition_spec={"plan_id": "plan-explicit-authority"},
    )

    assert resolved_goal_id == "goal-explicit-authority"
    assert resolved_plan_id == "plan-explicit-authority"
    assert resolved_step_id == "step-explicit-authority"


def test_resolve_execution_authority_honors_explicit_step_override(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-step-authority",
            goal_id="goal-step-authority",
            title="Step authority plan",
            summary="Use explicit step authority.",
            status="active",
            selected_step_id="step-step-authority",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-step-authority",
            plan_id="plan-step-authority",
            goal_id="goal-step-authority",
            step_kind="execution",
            title="Explicit step",
            description="Use this step directly.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        memory_store,
        goal_id="goal-other",
        transition_spec={"step_id": "step-step-authority"},
    )

    assert resolved_goal_id == "goal-step-authority"
    assert resolved_plan_id == "plan-step-authority"
    assert resolved_step_id == "step-step-authority"


def test_resolve_execution_authority_handles_goal_without_active_plan(memory_store):
    resolved_goal_id, resolved_plan_id, resolved_step_id = _resolve_execution_authority(
        memory_store,
        goal_id="goal-without-plan",
        transition_spec=None,
    )

    assert resolved_goal_id == "goal-without-plan"
    assert resolved_plan_id is None
    assert resolved_step_id is None


def test_tool_execution_persists_canonical_execution_record_and_applies_step_transition(
    memory_store,
):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-transition-123",
            goal_id="goal-transition-123",
            title="Transition rollout plan",
            summary="Drive execution from canonical step state.",
            status="active",
            selected_step_id="step-transition-123",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-transition-123",
            plan_id="plan-transition-123",
            goal_id="goal-transition-123",
            step_kind="execution",
            title="Execute rollout",
            description="Run the rollout and update progress.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    result = ToolResult(
        tool_name="remember",
        success=True,
        content="Reminder set",
        source="builtin",
        duration_ms=0,
        metadata={
            "world_model_refs": [],
            "plan_step_transition": {
                "transition_kind": "progress_update",
                "to_status": "in_progress",
                "progress_pct": 55,
                "summary": "Rollout step moved into active execution.",
            },
        },
    )

    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-tool-transition",
        turn_ordinal=2,
        intent_id="intent-tool-transition",
        prompt_control_artifact_id=None,
        tool_call_id="remember-transition",
        tool_name="remember",
        arguments={"text": "continue the rollout"},
        result=result,
        goal_id="goal-transition-123",
    )

    executions = memory_store.list_world_model_execution_records(
        session_id="session-tool-transition"
    )
    transitions = memory_store.list_world_model_plan_step_transitions(
        step_id="step-transition-123"
    )
    step = memory_store.load_world_model_plan_step("step-transition-123")

    assert len(executions) == 1
    assert executions[0].execution_kind == "tool_call"
    assert executions[0].plan_id == "plan-transition-123"
    assert executions[0].step_id == "step-transition-123"
    assert executions[0].source_record_type == "world_model_action"
    assert len(transitions) == 1
    assert transitions[0].execution_id == executions[0].execution_id
    assert transitions[0].to_status == "in_progress"
    assert step is not None
    assert step.status == "in_progress"
    assert step.progress_pct == 55


def test_decision_and_turn_event_persist_canonical_execution_records(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-execution-records",
            goal_id="goal-execution-records",
            title="Execution record plan",
            summary="Record every execution surface canonically.",
            status="active",
            selected_step_id="step-execution-records",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-execution-records",
            plan_id="plan-execution-records",
            goal_id="goal-execution-records",
            step_kind="execution",
            title="Capture execution surfaces",
            description="Capture decision and event execution records.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    _persist_world_model_decision_outcome(
        memory_store,
        session_id="session-execution-records",
        turn_ordinal=1,
        intent_id="intent-execution-records",
        goal_id="goal-execution-records",
        prompt_control_artifact_id=None,
        decision_name="direct_answer",
        status="completed",
        response="Execution is underway.",
        payload={"selected_action": {"name": "Continue execution"}},
    )
    _persist_world_model_turn_event(
        memory_store,
        session_id="session-execution-records",
        turn_ordinal=1,
        intent_id="intent-execution-records",
        goal_id="goal-execution-records",
        prompt_control_artifact_id=None,
        title="Execution outcome",
        summary="Execution produced a canonical event record.",
        payload={"outcome": "recorded"},
    )

    executions = memory_store.list_world_model_execution_records(
        session_id="session-execution-records"
    )

    assert {record.execution_kind for record in executions} == {
        "decision_outcome",
        "turn_event",
    }
    assert all(record.plan_id == "plan-execution-records" for record in executions)
    assert all(record.step_id == "step-execution-records" for record in executions)


def test_tool_execution_uses_dependency_promoted_selected_step(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-promoted-step",
            goal_id="goal-promoted-step",
            title="Promoted step plan",
            summary="Use canonical selected-step refresh after execution.",
            status="active",
            selected_step_id="step-promoted-execute",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-promoted-execute",
            plan_id="plan-promoted-step",
            goal_id="goal-promoted-step",
            step_kind="execution",
            title="Execute rollout",
            description="Run the rollout.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-promoted-verify",
            plan_id="plan-promoted-step",
            goal_id="goal-promoted-step",
            step_kind="verification",
            title="Verify rollout",
            description="Verify after execution.",
            status="blocked",
            ordinal=2,
            blocked_reason="Waiting on execution.",
            depends_on_step_ids=["step-promoted-execute"],
            blocked_by_step_ids=["step-promoted-execute"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-promoted-step",
        turn_ordinal=1,
        intent_id="intent-promoted-step",
        prompt_control_artifact_id=None,
        tool_call_id="remember-promoted-step-1",
        tool_name="remember",
        arguments={"text": "finish execution"},
        result=ToolResult(
            tool_name="remember",
            success=True,
            content="Execution finished",
            source="builtin",
            duration_ms=0,
            metadata={
                "plan_step_transition": {
                    "transition_kind": "done",
                    "to_status": "done",
                    "progress_pct": 100,
                    "summary": "Execution finished.",
                }
            },
        ),
        goal_id="goal-promoted-step",
    )
    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-promoted-step",
        turn_ordinal=2,
        intent_id="intent-promoted-step",
        prompt_control_artifact_id=None,
        tool_call_id="remember-promoted-step-2",
        tool_name="remember",
        arguments={"text": "run verification"},
        result=ToolResult(
            tool_name="remember",
            success=True,
            content="Verification running",
            source="builtin",
            duration_ms=0,
            metadata={},
        ),
        goal_id="goal-promoted-step",
    )

    executions = memory_store.list_world_model_execution_records(
        session_id="session-promoted-step"
    )

    assert len(executions) == 2
    assert executions[0].step_id == "step-promoted-verify"
    assert executions[1].step_id == "step-promoted-execute"


def test_tool_execution_done_transition_completes_single_step_plan(memory_store):
    now = utcnow()
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-single-step-complete",
            goal_id="goal-single-step-complete",
            title="Single-step completion plan",
            summary="A single step should complete the whole plan.",
            status="active",
            selected_step_id="step-single-step-complete",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-single-step-complete",
            plan_id="plan-single-step-complete",
            goal_id="goal-single-step-complete",
            step_kind="execution",
            title="Complete the single step",
            description="Finishing this step should complete the plan.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    _persist_world_model_tool_execution(
        memory_store,
        session_id="session-single-step-complete",
        turn_ordinal=1,
        intent_id="intent-single-step-complete",
        prompt_control_artifact_id=None,
        tool_call_id="remember-single-step-complete",
        tool_name="remember",
        arguments={"text": "finish the final step"},
        result=ToolResult(
            tool_name="remember",
            success=True,
            content="Single step completed",
            source="builtin",
            duration_ms=0,
            metadata={
                "plan_step_transition": {
                    "transition_kind": "done",
                    "to_status": "done",
                    "progress_pct": 100,
                    "summary": "The only step completed.",
                }
            },
        ),
        goal_id="goal-single-step-complete",
    )

    plan = memory_store.load_world_model_action_plan("plan-single-step-complete")
    step = memory_store.load_world_model_plan_step("step-single-step-complete")
    executions = memory_store.list_world_model_execution_records(
        session_id="session-single-step-complete"
    )

    assert step is not None
    assert step.status == "done"
    assert step.progress_pct == 100
    assert plan is not None
    assert plan.status == "done"
    assert plan.selected_step_id is None
    assert len(executions) == 1
    assert executions[0].plan_id == "plan-single-step-complete"
    assert executions[0].step_id == "step-single-step-complete"


def test_run_turn_clarifies_for_ambiguous_reference(memory_store, tmp_path):
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage") as mock_chat,
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Can you do that?",
            memory_store,
            project_root=tmp_path,
        )

    assert "clarify" in response.lower()
    assert session.last_intent_frame is not None
    assert session.last_intent_frame.selected_path == IntentFramePath.CLARIFY
    assert [slot.name for slot in session.last_intent_frame.slot_states] == [
        "reference_that"
    ]
    assert session.last_prompt_control is not None
    mock_chat.assert_not_called()


def test_run_turn_does_not_clarify_for_relative_clause_that(memory_store, tmp_path):
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch(
            "memex.llm.chat_with_usage", return_value=("database status", _MOCK_USAGE)
        ) as mock_chat,
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Has the data in your knowledge store also been saved with vector embeddings?",
            memory_store,
            project_root=tmp_path,
        )

    assert response == "database status"
    assert session.last_intent_frame is not None
    assert session.last_intent_frame.selected_path != IntentFramePath.CLARIFY
    assert session.last_intent_frame.unresolved_references == []
    mock_chat.assert_called_once()


def test_run_turn_uses_selected_action_candidate_for_clarify(memory_store, tmp_path):
    intent_frame = IntentFrame(
        raw_input="Can you do that?",
        classification=InputClassificationType.CONVERSATIONAL,
        summary="Clarify target",
        selected_path=IntentFramePath.DIRECT_ANSWER,
        selected_action_candidate=IntentActionCandidate(
            name=IntentFramePath.CLARIFY.value,
            selected=True,
            rationale="need target object",
            required_slots=["target_item"],
            unresolved_required_slots=["target_item"],
        ),
        missing_information=["which target item to act on"],
        slot_states=[
            {
                "name": "target_item",
                "status": "missing",
                "description": "which target item to act on",
                "source": "missing_information",
                "required": True,
            }
        ],
        confidence=0.8,
        rationale="general chat",
        created_at=utcnow(),
    )

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.intent_frame.build_intent_frame", return_value=intent_frame),
        patch("memex.llm.chat_with_usage") as mock_chat,
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Can you do that?",
            memory_store,
            project_root=tmp_path,
        )

    assert response == "Please clarify: which target item to act on"
    assert session.working_memory["last_intent_path"] == IntentFramePath.CLARIFY.value
    mock_chat.assert_not_called()


def test_build_selected_action_payload_serializes_unresolved_required_slots():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    intent_frame = IntentFrame(
        raw_input="Can you do that?",
        classification=InputClassificationType.CONVERSATIONAL,
        summary="Need clarification to resolve ambiguous references",
        selected_path=IntentFramePath.CLARIFY,
        unresolved_references=["that"],
        missing_information=["what 'that' refers to"],
        slot_states=[
            {
                "name": "reference_that",
                "status": "unresolved",
                "description": "Resolve what 'that' refers to.",
                "source": "reference_resolution",
                "required": True,
            }
        ],
        confidence=0.8,
        rationale="general chat",
        created_at=utcnow(),
    )

    payload = _build_selected_action_payload(
        decision_name=IntentFramePath.CLARIFY.value,
        status="selected",
        classification=classification.classification.value,
        intent_frame=intent_frame,
        prompt_control_artifact=None,
    )

    assert payload["slot_states"] == [
        {
            "name": "reference_that",
            "status": "unresolved",
            "description": "Resolve what 'that' refers to.",
            "value": None,
            "source": "reference_resolution",
            "required": True,
        }
    ]
    assert payload["selected_action"]["required_slots"] == ["reference_that"]
    assert payload["selected_action"]["unresolved_required_slots"] == ["reference_that"]
    assert payload["selected_action"]["name"] == "clarify"
    clarify_candidate = next(
        candidate
        for candidate in payload["action_candidates"]
        if candidate["name"] == "clarify"
    )
    assert clarify_candidate["required_slots"] == ["reference_that"]
    assert clarify_candidate["unresolved_required_slots"] == ["reference_that"]


def test_run_turn_abstains_on_low_confidence_fallback(memory_store, tmp_path):
    with (
        patch("memex.classify.classify_input", _mock_classify_fallback),
        patch("memex.llm.chat_with_usage") as mock_chat,
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Do it",
            memory_store,
            project_root=tmp_path,
        )

    assert "rephrase" in response.lower()
    assert session.last_intent_frame is not None
    assert session.last_intent_frame.selected_path == IntentFramePath.ABSTAIN
    mock_chat.assert_not_called()


def test_run_turn_passes_intent_path_to_tool_router(memory_store, tmp_path):
    reg = ToolRegistry()
    reg.register(
        ToolDefinition(
            name="remember",
            description="Remember something",
            source="builtin",
            required_capability="builtin.write",
            capability_tags=["memory.write"],
            supported_intent_paths=["act"],
        )
    )

    with (
        patch(
            "memex.classify.classify_input",
            return_value=InputClassification(
                classification=InputClassificationType.KNOWLEDGE_QUERY,
                confidence=0.9,
                reasoning="knowledge lookup",
            ),
        ),
        patch(
            "memex.llm.chat_with_usage",
            return_value=("Here is what I know.", _MOCK_USAGE),
        ) as mock_chat,
        patch("memex.llm.chat_with_tools_streaming") as mock_tool_chat,
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "what do you remember about rust",
            memory_store,
            project_root=tmp_path,
            tool_registry=reg,
        )

    assert "what i know" in response.lower()
    assert session.last_intent_frame is not None
    assert session.last_intent_frame.selected_path == IntentFramePath.DIRECT_ANSWER
    mock_chat.assert_called_once()
    mock_tool_chat.assert_not_called()


def test_run_turn_blocks_tools_from_unavailable_self_model_capabilities(
    memory_store, tmp_path
):
    save_agent_self_model(
        AgentSelfModel(
            capabilities=[
                AgentCapability(
                    capability_id="connector/gmail",
                    title="Connector: Gmail",
                    status="unavailable",
                    detail="Auth missing.",
                    source="connector",
                ),
            ]
        ),
        memory_store,
    )
    reg = ToolRegistry()
    reg.register(
        ToolDefinition(
            name="gmail_search",
            description="Search Gmail",
            source="builtin",
            required_capability="builtin.read",
            capability_tags=["comm.gmail"],
            supported_intent_paths=["act", "direct_answer"],
        )
    )

    with (
        patch(
            "memex.classify.classify_input",
            return_value=InputClassification(
                classification=InputClassificationType.KNOWLEDGE_QUERY,
                confidence=0.9,
                reasoning="gmail lookup",
            ),
        ),
        patch(
            "memex.llm.chat_with_usage",
            return_value=("No gmail tool was offered.", _MOCK_USAGE),
        ),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _response, session = run_turn(
            "search my gmail for the invoice",
            memory_store,
            project_root=tmp_path,
            tool_registry=reg,
        )

    assert session.last_prompt_control is not None
    assert "gmail_search" not in session.last_prompt_control.tool_candidate_names


def test_run_turn_includes_prompt_control_block_and_typed_knowledge_in_system_prompt(
    memory_store,
    tmp_path,
):
    content_store = memory_store.content
    content_store.create_item(
        make_item(
            title="Python tutorial",
            body="Official tutorial entry for Python.",
            source_url="https://docs.python.org/3/tutorial/",
        )
    )
    captured: dict[str, object] = {}

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return "Here is the tutorial reference.", _MOCK_USAGE

    with (
        patch(
            "memex.classify.classify_input",
            return_value=InputClassification(
                classification=InputClassificationType.KNOWLEDGE_QUERY,
                confidence=0.93,
                reasoning="knowledge lookup",
            ),
        ),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, session = run_turn(
            "Verify docs.python.org tutorial with sources.",
            memory_store,
            project_root=tmp_path,
            content_store=content_store,
        )

    assert response == "Here is the tutorial reference."
    assert session.last_prompt_control is not None
    assert session.last_prompt_control.route_profile.value == "research_verified"

    messages = captured["messages"]
    system_prompt = messages[0]["content"]
    assert "## Prompt Control" in system_prompt
    assert "Route profile: research_verified" in system_prompt
    assert "Canonical: https://docs.python.org/3/tutorial/" in system_prompt


def test_run_turn_legacy_prompt_includes_recent_canonical_outcomes(
    memory_store, tmp_path
):
    now = utcnow()
    session = SessionContext(session_id="session-canonical-legacy", started_at=now)
    captured: dict[str, object] = {}
    responses = iter(
        [
            "Rust is a systems programming language.",
            "You asked about Rust earlier.",
        ]
    )

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return next(responses), _MOCK_USAGE

    with (
        patch(
            "memex.classify.classify_input",
            return_value=InputClassification(
                classification=InputClassificationType.KNOWLEDGE_QUERY,
                confidence=0.9,
                reasoning="knowledge lookup",
            ),
        ),
        patch(
            "memex.intent_frame.build_intent_frame",
            side_effect=[
                IntentFrame(
                    raw_input="What is Rust?",
                    classification=InputClassificationType.KNOWLEDGE_QUERY,
                    summary="Answer what Rust is",
                    selected_path=IntentFramePath.DIRECT_ANSWER,
                    confidence=0.9,
                    rationale="answer directly",
                    created_at=now,
                ),
                IntentFrame(
                    raw_input="What did I ask before?",
                    classification=InputClassificationType.KNOWLEDGE_QUERY,
                    summary="Answer from recent context",
                    selected_path=IntentFramePath.DIRECT_ANSWER,
                    confidence=0.86,
                    rationale="answer directly",
                    created_at=now,
                ),
            ],
        ),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _, session = run_turn(
            "What is Rust?",
            memory_store,
            session,
            project_root=tmp_path,
        )
        _, session = run_turn(
            "What did I ask before?",
            memory_store,
            session,
            project_root=tmp_path,
        )

    system_prompt = _prompt_text(captured["messages"][0]["content"])
    assert "## Recent Canonical Outcomes" in system_prompt
    assert "selected_action direct_answer | succeeded" in system_prompt
    assert "provenance governed_by prompt_control_artifact" in system_prompt
    assert "provenance selected_for_intent world_model_intent" in system_prompt
    assert (
        "observed user_visible_response | succeeded | Rust is a systems programming language."
        in system_prompt
    )


def test_run_turn_cached_prompt_includes_recent_canonical_outcomes(
    memory_store, tmp_path
):
    now = utcnow()
    session = SessionContext(session_id="session-canonical-cached", started_at=now)
    captured: dict[str, object] = {}
    responses = iter(
        [
            "Rust is memory-safe.",
            "You asked about Rust earlier.",
        ]
    )

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return next(responses), _MOCK_USAGE

    with (
        patch(
            "memex.classify.classify_input",
            return_value=InputClassification(
                classification=InputClassificationType.KNOWLEDGE_QUERY,
                confidence=0.9,
                reasoning="knowledge lookup",
            ),
        ),
        patch(
            "memex.intent_frame.build_intent_frame",
            side_effect=[
                IntentFrame(
                    raw_input="What is Rust?",
                    classification=InputClassificationType.KNOWLEDGE_QUERY,
                    summary="Answer what Rust is",
                    selected_path=IntentFramePath.DIRECT_ANSWER,
                    confidence=0.9,
                    rationale="answer directly",
                    created_at=now,
                ),
                IntentFrame(
                    raw_input="What did I ask before?",
                    classification=InputClassificationType.KNOWLEDGE_QUERY,
                    summary="Answer from recent context",
                    selected_path=IntentFramePath.DIRECT_ANSWER,
                    confidence=0.86,
                    rationale="answer directly",
                    created_at=now,
                ),
            ],
        ),
        patch("memex.loop._use_message_builder", return_value=True),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _, session = run_turn(
            "What is Rust?",
            memory_store,
            session,
            project_root=tmp_path,
        )
        _, session = run_turn(
            "What did I ask before?",
            memory_store,
            session,
            project_root=tmp_path,
        )

    system_prompt = _prompt_text(captured["messages"][0]["content"])
    assert "## Recent Canonical Outcomes" in system_prompt
    assert "selected_action direct_answer | succeeded" in system_prompt
    assert "provenance governed_by prompt_control_artifact" in system_prompt
    assert (
        "observed user_visible_response | succeeded | Rust is memory-safe."
        in system_prompt
    )


def test_run_turn_prompt_uses_canonical_partner_and_agent_self_models(
    memory_store, tmp_path
):
    save_partner_profile(
        HumanPartnerProfile(
            name="Corey",
            communication_style="concise",
            explanation_level="deep",
            working_context=HumanWorkingContext(
                timezone="America/Chicago",
                role="engineer",
                team="Memex",
                speaker_mappings={"SPEAKER_1": "Corey"},
            ),
            knowledge_profile=HumanKnowledgeProfile(
                preferences={"verbosity": "low"},
                notes=["Prefers direct explanations."],
                expertise=["systems", "python"],
            ),
        ),
        memory_store,
    )
    save_agent_self_model(
        AgentSelfModel(
            capabilities=[
                AgentCapability(
                    capability_id="surface/tui",
                    title="Interface: Tui",
                    status="available",
                    detail="TUI shell is available.",
                    source="runtime",
                ),
            ],
            limitations=[],
            degraded_modes=[],
        ),
        memory_store,
    )
    captured: dict[str, object] = {}

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return "Grounded response.", _MOCK_USAGE

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, _ = run_turn(
            "How should we proceed?",
            memory_store,
            project_root=tmp_path,
        )

    assert response == "Grounded response."
    system_prompt = _prompt_text(captured["messages"][0]["content"])
    assert "## About the Human" in system_prompt
    assert "Explanation level: deep" in system_prompt
    assert "## About Memex" in system_prompt
    assert "## About Memex" in system_prompt


def test_run_turn_prompt_includes_canonical_plan_and_selected_step(
    memory_store, tmp_path
):
    now = utcnow()
    memory_store.create_goal(
        Goal(
            goal_id="goal-prompt-plan",
            title="Ship the rollout",
            description="Land the rollout through the canonical plan.",
            status=GoalStatus.ACTIVE,
            priority=GoalPriority.HIGH,
            created_at=now,
            updated_at=now,
            last_touched_at=now,
            metadata={},
        )
    )
    memory_store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-prompt-rollout",
            goal_id="goal-prompt-plan",
            title="Rollout plan",
            summary="Drive the rollout through explicit steps.",
            status="active",
            selected_step_id="step-prompt-verify",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    memory_store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-prompt-verify",
            plan_id="plan-prompt-rollout",
            goal_id="goal-prompt-plan",
            step_kind="verification",
            title="Verify rollout",
            description="Verify and close the rollout.",
            status="blocked",
            ordinal=2,
            blocked_reason="Waiting on approval signoff.",
            progress_pct=60,
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    captured: dict[str, object] = {}

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return "Grounded response.", _MOCK_USAGE

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, _ = run_turn(
            "What should we do next?",
            memory_store,
            project_root=tmp_path,
        )

    assert response == "Grounded response."
    system_prompt = _prompt_text(captured["messages"][0]["content"])
    assert "## Prompt Control" in system_prompt
    assert "## Current Goals" in system_prompt
    assert "Plan: Rollout plan [active]" in system_prompt
    assert "Current step: Verify rollout [blocked, 60%]" in system_prompt
    assert "Step blocker: Waiting on approval signoff." in system_prompt
    assert "Canonical plan:" not in system_prompt


def test_run_turn_persists_session(memory_store, tmp_path):
    """Session is persisted after each turn."""
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _, session = run_turn("hello", memory_store, project_root=tmp_path)

    loaded = memory_store.load_session()
    assert loaded is not None
    assert loaded.turn_count == 1


def test_run_turn_applies_prompt_budget_to_large_context_sections(
    memory_store, tmp_path
):
    from memex.agent_self_model import save_agent_self_model
    from memex.human_model import save_partner_profile

    save_partner_profile(
        HumanPartnerProfile(
            name="Corey",
            knowledge_profile=HumanKnowledgeProfile(
                notes=["very long note " * 120],
            ),
        ),
        memory_store,
    )
    save_agent_self_model(
        AgentSelfModel(
            capabilities=[
                AgentCapability(
                    capability_id="surface/tui",
                    title="Interface: TUI",
                    status="available",
                    detail="very detailed capability description " * 120,
                    source="runtime",
                )
            ],
            limitations=[
                AgentLimitation(
                    limitation_id="degraded/example",
                    title="example degraded mode",
                    detail="very detailed limitation description " * 120,
                    severity="warn",
                    recoverable=True,
                    source="runtime",
                )
            ],
            degraded_modes=["example_degraded"],
        ),
        memory_store,
    )
    content_store = memory_store.content
    session = SessionContext(
        session_id="session-budget",
        started_at=utcnow(),
        conversation_summary="summary " * 800,
    )
    captured: dict[str, object] = {}

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return "Budgeted response.", _MOCK_USAGE

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.loop._use_message_builder", return_value=False),
        patch(
            "memex.loop.DEFAULT_PROMPT_BUDGET",
            PromptBudgetConfig(
                stable_prefix_tokens=220,
                dynamic_turn_tokens=100,
                retrieval_tokens=80,
                operator_tokens=40,
            ),
        ),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.loop._should_auto_retrieve_for_turn", return_value=True),
        patch(
            "memex.memory.retrieval.retrieve_for_context",
            return_value=RetrievalResult(
                text="## Retrieved Knowledge\n" + ("knowledge " * 1000),
                document_ids={"world_model_knowledge:test"},
            ),
        ),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, _ = run_turn(
            "What should we do next?",
            memory_store,
            session=session,
            project_root=tmp_path,
            content_store=content_store,
        )

    assert response == "Budgeted response."
    system_prompt = _prompt_text(captured["messages"][0]["content"])
    assert "## Prompt Control" in system_prompt
    assert "## About Memex" in system_prompt
    assert "... [prompt budget truncated]" in system_prompt
    assert len(system_prompt) < 2400


def test_run_turn_multiple_turns(memory_store, tmp_path):
    """Multiple turns accumulate in session history."""
    session = None
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        for i in range(3):
            _, session = run_turn(
                f"message {i}",
                memory_store,
                session,
                project_root=tmp_path,
            )

    assert session.turn_count == 3
    # 3 human + 3 assistant = 6
    assert len(session.conversation_history) == 6


def test_run_turn_emits_events(memory_store, tmp_path):
    """on_event callback receives TurnPhase and TurnCompleted events."""
    events: list[TurnEvent] = []

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        run_turn(
            "hello",
            memory_store,
            project_root=tmp_path,
            on_event=events.append,
        )

    # Should have: classifying, thinking, and optionally reflecting, plus turn_completed
    phases = [e for e in events if isinstance(e, TurnPhase)]
    assert len(phases) >= 2  # at least classifying + thinking
    assert phases[0].phase == "classifying"
    assert phases[1].phase == "thinking"

    completed = [e for e in events if isinstance(e, TurnCompleted)]
    assert len(completed) == 1
    assert completed[0].duration_ms >= 0
    assert completed[0].prompt_tokens == 100
    assert completed[0].completion_tokens == 50
    assert completed[0].cost_usd == 0.001
    assert completed[0].tool_call_count == 0
    assert completed[0].route_profile != ""
    assert completed[0].prompt_mode == "full"


def test_run_turn_events_callback_errors_ignored(memory_store, tmp_path):
    """Errors in on_event callback are silently ignored."""

    def bad_callback(event):
        raise RuntimeError("boom")

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        response, _ = run_turn(
            "hello",
            memory_store,
            project_root=tmp_path,
            on_event=bad_callback,
        )

    # Turn should complete normally despite callback errors
    assert response != ""


def test_run_turn_records_runtime_stats_for_operability(memory_store, tmp_path):
    captured: dict[str, object] = {}

    def _capture_chat(messages, **kwargs):
        captured["messages"] = messages
        return "Operational response.", _MOCK_USAGE

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.llm.chat_with_usage", side_effect=_capture_chat),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        _response, session = run_turn(
            "hello",
            memory_store,
            project_root=tmp_path,
        )

    runtime_stats = session.working_memory["_turn_runtime_stats"]
    assert runtime_stats["turn_ordinal"] == 1
    assert runtime_stats["used_cache"] is False
    assert runtime_stats["tool_call_count"] == 0
    assert runtime_stats["phase_timings_ms"]["classify"] >= 0
    assert runtime_stats["phase_timings_ms"]["prompt_build"] >= 0
    assert runtime_stats["phase_timings_ms"]["llm"] >= 0
    assert runtime_stats["phase_timings_ms"]["total"] >= 0
    assert runtime_stats["prompt_metrics"]["system_prompt_chars"] > 0
    assert (
        runtime_stats["prompt_metrics"]["total_prompt_chars"]
        >= runtime_stats["prompt_metrics"]["system_prompt_chars"]
    )
    assert runtime_stats["prompt_metrics"]["history_prompt_chars"] == 0
    assert session.working_memory["_recent_turn_runtime_stats"][-1] == runtime_stats


def test_run_turn_records_runtime_stats_for_clarify_short_circuit(
    memory_store, tmp_path
):
    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch(
            "memex.intent_frame.build_intent_frame",
            return_value=IntentFrame(
                raw_input="Do that",
                classification=InputClassificationType.CONVERSATIONAL,
                summary="Clarify unresolved request",
                selected_path=IntentFramePath.CLARIFY,
                confidence=0.9,
                rationale="need clarification",
                unresolved_references=["that"],
                created_at=utcnow(),
            ),
        ),
    ):
        response, session = run_turn(
            "Do that",
            memory_store,
            project_root=tmp_path,
        )

    assert response
    runtime_stats = session.working_memory["_turn_runtime_stats"]
    assert runtime_stats["turn_ordinal"] == 1
    assert runtime_stats["tool_call_count"] == 0
    assert runtime_stats["prompt_metrics"]["system_prompt_chars"] == 0
    assert runtime_stats["phase_timings_ms"].get("total", 0) >= 0


def test_run_turn_cancellation_propagates(memory_store, tmp_path):
    """TurnCancelled in on_event callback is NOT swallowed — it propagates up."""

    def cancel_callback(event):
        raise TurnCancelled()

    with (
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.llm.chat_with_usage", _mock_chat_with_usage),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        with pytest.raises(TurnCancelled):
            run_turn(
                "hello",
                memory_store,
                project_root=tmp_path,
                on_event=cancel_callback,
            )


class TestSignalsContinuation:
    """Tests for _signals_continuation helper."""

    def test_let_me_try(self):
        assert _signals_continuation("Let me try a more specific search")
