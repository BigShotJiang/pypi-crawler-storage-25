"""Tests for built-in tools (web_fetch, file_transform, etc.)."""

from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

from memex.llm import TokenUsage
from memex.tools_builtin import BUILTIN_TOOLS, execute_builtin
from memex.utcnow import utcnow


class TestWebFetchTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "web_fetch" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "web_fetch")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.read"
        assert "url" in tool.parameters["properties"]
        assert "url" in tool.parameters["required"]

    def test_missing_url(self):
        result = execute_builtin("web_fetch", {})
        assert not result.success
        assert "url" in result.error.lower()

    @patch("memex.memory.web_extract.extract_from_url")
    def test_successful_fetch(self, mock_extract):
        from memex.memory.web_extract import ExtractedContent

        mock_extract.return_value = ExtractedContent(
            url="https://example.com",
            title="Hello World",
            body="Hello World content here.",
            word_count=4,
        )

        result = execute_builtin("web_fetch", {"url": "https://example.com"})
        assert result.success
        assert "Hello World" in result.content
        mock_extract.assert_called_once()

    @patch("memex.memory.web_extract.extract_from_url")
    def test_truncates_large_response(self, mock_extract):
        from memex.memory.web_extract import ExtractedContent

        mock_extract.return_value = ExtractedContent(
            url="https://example.com",
            title="Big page",
            body="x " * 60_000,
            word_count=60_000,
        )

        result = execute_builtin("web_fetch", {"url": "https://example.com"})
        assert result.success
        assert "Truncated" in result.content
        assert len(result.content) < 60_000 + 1000  # body + header

    @patch("memex.memory.web_extract.extract_from_url")
    def test_extraction_failure(self, mock_extract):
        from memex.memory.web_extract import ExtractedContent

        mock_extract.return_value = ExtractedContent(url="https://example.com", body="")

        result = execute_builtin("web_fetch", {"url": "https://example.com"})
        assert not result.success

    @patch("memex.memory.web_extract.extract_from_url")
    def test_http_error(self, mock_extract):
        mock_extract.side_effect = Exception("Connection refused")

        result = execute_builtin("web_fetch", {"url": "https://bad.example.com"})
        assert not result.success
        assert "Connection refused" in result.error


class TestBuiltinDispatch:
    def test_unknown_tool(self):
        result = execute_builtin("nonexistent_tool", {})
        assert not result.success
        assert "Unknown" in result.error

    def test_web_fetch_registered(self):
        """web_fetch is in the handler registry."""
        from memex.tools_builtin import _HANDLERS

        assert "web_fetch" in _HANDLERS

    def test_get_item_renders_meeting_canonical_promotion_audit(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="meeting-audit-item",
                type=ItemType.MEETING,
                title="Architecture Review",
                body="Transcript body",
                source_url="memex://meeting/mtg-audit-view",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="meeting_transcription",
                    captured_at=now,
                    confidence=1.0,
                ),
                metadata={
                    "meeting": {
                        "meeting_id": "mtg-audit-view",
                        "semantic": {
                            "canonical_promotion_audit": [
                                {
                                    "artifact_id": "mtg-audit-view:commitment:0",
                                    "artifact_type": "commitment",
                                    "status": "succeeded",
                                    "relationships": [
                                        {
                                            "relationship": "updates_goal",
                                            "target_record_type": "goal",
                                            "target_record_id": "goal-123",
                                        }
                                    ],
                                    "observations": [
                                        {
                                            "observation_kind": "promoted_semantic_item",
                                            "status": "succeeded",
                                            "summary": "Ship docs update",
                                        }
                                    ],
                                }
                            ]
                        },
                    }
                },
            )
            content_store.create_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item", {"id": "content_item:meeting-audit-item"}
            )

            assert result.success
            assert "Meeting Promotion Audit" in result.content
            assert "commitment | succeeded" in result.content
            assert "updates_goal -> goal:goal-123" in result.content
            assert (
                "promoted_semantic_item | succeeded | Ship docs update"
                in result.content
            )
        finally:
            store.close()

    def test_get_item_renders_meeting_canonical_activity_audit(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="meeting-activity-item",
                type=ItemType.MEETING,
                title="Sprint Planning",
                body="Transcript body",
                source_url="memex://meeting/mtg-activity-view",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="meeting_transcription",
                    captured_at=now,
                    confidence=1.0,
                ),
                metadata={
                    "meeting": {
                        "meeting_id": "mtg-activity-view",
                        "semantic": {
                            "canonical_activity_audit": [
                                {
                                    "action_id": "meeting:mtg-activity-view:semantic_sync:123",
                                    "action_kind": "meeting_semantic_sync",
                                    "action_name": "item_projection_refresh",
                                    "status": "succeeded",
                                    "relationships": [
                                        {
                                            "relationship": "updates",
                                            "target_record_type": "item",
                                            "target_record_id": "meeting-activity-item",
                                        }
                                    ],
                                    "observations": [
                                        {
                                            "observation_kind": "meeting_semantic_state",
                                            "status": "succeeded",
                                            "summary": "1 decisions, 0 commitments",
                                        }
                                    ],
                                }
                            ]
                        },
                    }
                },
            )
            content_store.create_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item", {"id": "content_item:meeting-activity-item"}
            )

            assert result.success
            assert "Meeting Activity Audit" in result.content
            assert (
                "meeting_semantic_sync:item_projection_refresh | succeeded"
                in result.content
            )
            assert "updates -> item:meeting-activity-item" in result.content
            assert (
                "meeting_semantic_state | succeeded | 1 decisions, 0 commitments"
                in result.content
            )
        finally:
            store.close()

    def test_get_item_resolves_canonical_knowledge_document_id(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="canonical-knowledge-item",
                type=ItemType.NOTE,
                title="OAuth Rotation",
                body="Rotate the OAuth token and retry.",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="memory_intake", captured_at=now, confidence=1.0
                ),
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "procedure",
                        "steps": ["Rotate the OAuth token", "Retry"],
                    }
                },
            )
            content_store.create_item(item)
            store.sync_world_model_knowledge_from_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": "world_model_knowledge:knowledge/canonical-knowledge-item"},
            )

            assert result.success
            assert "# OAuth Rotation" in result.content
            assert "Type: procedure" in result.content
            assert (
                "ID: world_model_knowledge:knowledge/canonical-knowledge-item"
                in result.content
            )
            assert "Rotate the OAuth token" in result.content
        finally:
            store.close()

    def test_get_item_resolves_world_model_mapping_document_id(self, tmp_path):
        from memex.human_model import save_partner_profile
        from memex.models import HumanPartnerProfile
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            save_partner_profile(
                HumanPartnerProfile(
                    name="Corey",
                    working_context={"speaker_mappings": {"SPEAKER_00": "Corey"}},
                ),
                store,
            )
            mapping = store.list_world_model_semantic_mappings()[0]
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_mapping:{mapping.mapping_id}"},
            )

            assert result.success
            assert "# Mapping: SPEAKER_00 -> Corey" in result.content
            assert "Type: semantic_mapping" in result.content
            assert f"ID: world_model_mapping:{mapping.mapping_id}" in result.content
            assert "Mapping kind: speaker_alias" in result.content
        finally:
            store.close()

    def test_get_item_resolves_world_model_event_document_id(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.world_model_backbone import build_world_model_turn_event

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            event = build_world_model_turn_event(
                "session-turns",
                conversation_turn_id=1,
                title="Turn event: direct_answer",
                summary="Rust is a systems programming language.",
                payload={
                    "selected_path": "direct_answer",
                    "route_profile": "analytic_strict",
                    "tool_call_count": 0,
                },
            )
            store.upsert_world_model_event(event)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_event:{event.event_id}"},
            )

            assert result.success
            assert "# Turn event: direct_answer" in result.content
            assert "Type: turn_outcome" in result.content
            assert f"ID: world_model_event:{event.event_id}" in result.content
            assert "Route profile: analytic_strict" in result.content
        finally:
            store.close()

    def test_get_item_resolves_world_model_claim_evaluation_document_id(self, tmp_path):
        from memex.memory.intake import ingest
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            item = ingest(
                "The deadline is March 25 for the release.",
                title="Release deadline",
                content_store=content_store,
                generate_summary=False,
                memex_store=store,
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "claim",
                        "statement": "The deadline is March 25 for the release.",
                        "claim_evaluations": [
                            {
                                "evaluation_kind": "verification",
                                "title": "Deadline verified",
                                "summary": "Confirmed against the release board.",
                            }
                        ],
                    }
                },
            )
            knowledge = store.load_world_model_knowledge_object_by_item_id(item.item_id)
            assert knowledge is not None
            evaluation = store.list_world_model_claim_evaluations(
                knowledge_id=knowledge.knowledge_id
            )[0]
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_claim_evaluation:{evaluation.evaluation_id}"},
            )

            assert result.success
            assert "# Deadline verified" in result.content
            assert "Type: verification" in result.content
            assert (
                f"ID: world_model_claim_evaluation:{evaluation.evaluation_id}"
                in result.content
            )
            assert "Confirmed against the release board." in result.content
        finally:
            store.close()

    def test_get_item_resolves_world_model_knowledge_with_relationship_context(
        self, tmp_path
    ):
        from memex.memory.intake import ingest
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            target = ingest(
                "The release deadline is Friday.",
                title="Release deadline",
                content_store=content_store,
                generate_summary=False,
                memex_store=store,
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "claim",
                        "statement": "The release deadline is Friday.",
                    }
                },
            )
            source = ingest(
                "See the deployment board screenshot.",
                title="Deployment board evidence",
                content_store=content_store,
                generate_summary=False,
                memex_store=store,
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "reference",
                        "relationships": [
                            {
                                "relationship_kind": "supports",
                                "target_item_id": target.item_id,
                                "summary": "Evidence from the deployment board.",
                            }
                        ],
                    }
                },
            )
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_knowledge:knowledge/{source.item_id}"},
            )

            assert result.success
            assert "# Deployment board evidence" in result.content
            assert "supports -> world_model_knowledge:knowledge/" in result.content
            assert "Release deadline" in result.content
            assert "Evidence from the deployment board." in result.content
        finally:
            store.close()

    def test_get_item_resolves_explicit_content_item_document_id(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="content-item-doc",
                type=ItemType.NOTE,
                title="Local scratchpad",
                body="Temporary working note.",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="memory_intake", captured_at=now, confidence=1.0
                ),
                metadata={},
            )
            content_store.create_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": "content_item:content-item-doc"},
            )

            assert result.success
            assert "# Local scratchpad" in result.content
            assert "ID: content_item:content-item-doc" in result.content
            assert "Temporary working note." in result.content
        finally:
            store.close()

    def test_get_item_content_item_does_not_require_world_model_reads(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import _STORES, configure_stores
        from memex.models import Item, ItemType, Provenance

        class NoConnContentStore:
            conn = None

            def __init__(self, backing_store):
                self._backing_store = backing_store

            def __getattr__(self, name):
                return getattr(self._backing_store, name)

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="content-item-no-reads",
                type=ItemType.NOTE,
                title="No reads required",
                body="Content item drill-in should not depend on world model reads.",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="memory_intake", captured_at=now, confidence=1.0
                ),
                metadata={},
            )
            content_store.create_item(item)
            configure_stores(content_store=NoConnContentStore(content_store))
            _STORES.pop("goal", None)

            result = execute_builtin(
                "get_item",
                {"id": "content_item:content-item-no-reads"},
            )

            assert result.success
            assert "# No reads required" in result.content
            assert "ID: content_item:content-item-no-reads" in result.content
        finally:
            _STORES.pop("content", None)
            _STORES.pop("goal", None)
            store.close()

    def test_get_item_resolves_canonical_selected_action_document_id(self, tmp_path):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.world_model_backbone import (
            build_world_model_decision_outcome_action,
            build_world_model_provenance_link,
            build_world_model_response_observation,
        )

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            action = build_world_model_decision_outcome_action(
                session_id="sess-get-item",
                conversation_turn_id=3,
                intent_id="intent/sess-get-item/3",
                prompt_control_artifact_id="pc/sess-get-item/3",
                decision_name="clarify",
                status="succeeded",
                payload={
                    "selected_action": {
                        "name": "clarify",
                        "rationale": "ambiguous reference",
                    },
                    "action_candidates": [{"name": "clarify", "selected": True}],
                },
            )
            observation = build_world_model_response_observation(
                action,
                "What does 'that' refer to?",
                payload={"reason": "ambiguous reference"},
            )
            provenance = build_world_model_provenance_link(
                source_record_type="world_model_action",
                source_record_id=action.action_id,
                target_record_type="intent",
                target_record_id="intent/sess-get-item/3",
                relationship="selected_from",
            )
            store.upsert_world_model_action(action)
            store.upsert_world_model_observation(observation)
            store.upsert_world_model_provenance_link(provenance)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_action:{action.action_id}"},
            )

            assert result.success
            assert "# Selected action: clarify" in result.content
            assert "Type: selected_action" in result.content
            assert "Candidates: clarify[selected]" in result.content
            assert "selected_from -> intent:intent/sess-get-item/3" in result.content
            assert "What does 'that' refer to?" in result.content
        finally:
            store.close()

    def test_builtin_remember_returns_structured_planning_refs_for_reminders(
        self, tmp_path
    ):
        from unittest.mock import patch

        from memex.remember import RememberClassification, RememberIntent
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        try:
            configure_stores(
                content_store=store.content,
                memex_store=store,
                scheduler_store=store.scheduler,
            )
            mock_result = RememberClassification(
                intent=RememberIntent.REMINDER,
                title="Ship docs update",
                body="Ship docs update tomorrow",
                tags=["docs"],
                reminder_time="2026-03-12T15:00:00",
                is_actionable=True,
            )

            with patch("memex.llm.chat_structured", return_value=mock_result):
                result = execute_builtin(
                    "remember", {"text": "remind me to ship docs update tomorrow"}
                )

            assert result.success
            refs = result.metadata.get("world_model_refs")
            assert isinstance(refs, list)
            assert any(
                ref.get("relationship") == "creates_task"
                and ref.get("record_type") == "world_model_task"
                for ref in refs
            )
            assert any(
                ref.get("relationship") == "creates_goal"
                and ref.get("record_type") == "world_model_goal"
                for ref in refs
            )
        finally:
            store.close()

    def test_get_item_resolves_meeting_promotion_world_model_action_document_id(
        self, tmp_path
    ):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.world_model_backbone import (
            build_world_model_meeting_promotion_action,
            build_world_model_meeting_promotion_observation,
            build_world_model_provenance_link,
        )

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            action = build_world_model_meeting_promotion_action(
                "mtg-get-item",
                artifact_id="mtg-get-item:decision:0",
                artifact_type="decision",
                promoted_item_id="meeting-semantic:mtg-get-item:decision:0",
                payload={"promoted_goal_id": "goal-456"},
                created_at=now,
            )
            observation = build_world_model_meeting_promotion_observation(
                action,
                promoted_item_id="meeting-semantic:mtg-get-item:decision:0",
                summary="Ship docs update",
                payload={
                    "artifact_id": "mtg-get-item:decision:0",
                    "artifact_type": "decision",
                },
                created_at=now,
            )
            provenance = build_world_model_provenance_link(
                source_record_type="world_model_action",
                source_record_id=action.action_id,
                target_record_type="goal",
                target_record_id="goal-456",
                relationship="updates_goal",
                created_at=now,
            )
            store.upsert_world_model_action(action)
            store.upsert_world_model_observation(observation)
            store.upsert_world_model_provenance_link(provenance)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_action:{action.action_id}"},
            )

            assert result.success
            assert "# Meeting promotion: Ship docs update" in result.content
            assert "Type: meeting_semantic_promotion" in result.content
            assert "Meeting: mtg-get-item" in result.content
            assert "updates_goal -> goal:goal-456" in result.content
        finally:
            store.close()

    def test_get_item_resolves_meeting_extraction_world_model_action_document_id(
        self, tmp_path
    ):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.world_model_backbone import (
            build_world_model_meeting_extraction_action,
            build_world_model_meeting_extraction_observation,
            build_world_model_provenance_link,
        )

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            action = build_world_model_meeting_extraction_action(
                "mtg-extract-get-item",
                run_id="run-123",
                run_type="transcription_projection",
                recording_id="rec-123",
                status="success",
                payload={"artifact_count": 4, "metadata": {"recording_count": 1}},
                created_at=now,
            )
            observation = build_world_model_meeting_extraction_observation(
                action,
                summary="transcription_projection success | artifacts=4",
                status="success",
                payload={"artifact_count": 4},
                created_at=now,
            )
            provenance = build_world_model_provenance_link(
                source_record_type="world_model_action",
                source_record_id=action.action_id,
                target_record_type="meeting_extraction_run",
                target_record_id="run-123",
                relationship="updates",
                created_at=now,
            )
            store.upsert_world_model_action(action)
            store.upsert_world_model_observation(observation)
            store.upsert_world_model_provenance_link(provenance)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "get_item",
                {"id": f"world_model_action:{action.action_id}"},
            )

            assert result.success
            assert "Type: meeting_extraction" in result.content
            assert "Meeting: mtg-extract-get-item" in result.content
            assert "Run: run-123" in result.content
            assert "Recording: rec-123" in result.content
            assert "updates -> meeting_extraction_run:run-123" in result.content
            assert "artifacts=4" in result.content
        finally:
            store.close()


class TestFileTransformTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "file_transform" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "file_transform")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.file_transform"
        assert "input_paths" in tool.parameters["properties"]
        assert "output_path" in tool.parameters["properties"]
        assert "instructions" in tool.parameters["properties"]
        assert set(tool.parameters["required"]) == {
            "input_paths",
            "output_path",
            "instructions",
        }

    def test_missing_input_paths(self):
        result = execute_builtin(
            "file_transform",
            {
                "output_path": "/tmp/out.md",
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "input_paths" in result.error

    def test_missing_output_path(self):
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/tmp/a.md"],
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "output_path" in result.error

    def test_missing_instructions(self):
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/tmp/a.md"],
                "output_path": "/tmp/out.md",
            },
        )
        assert not result.success
        assert "instructions" in result.error

    @patch("memex.mcp_servers.servers_config_from_env")
    def test_no_roots_configured(self, mock_config):
        from memex.mcp_servers import MCPServersConfig

        mock_config.return_value = MCPServersConfig(servers=[])
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/tmp/a.md"],
                "output_path": "/tmp/out.md",
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "No filesystem servers configured" in result.error

    @patch("memex.mcp_servers.servers_config_from_env")
    def test_no_writable_roots_configured(self, mock_config):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="fs-ro",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/allowed"],
                    integration="filesystem",
                    write=False,
                ),
            ]
        )
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/allowed/a.md"],
                "output_path": "/allowed/out.md",
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "No writable filesystem servers" in result.error

    @patch("memex.mcp_servers.servers_config_from_env")
    def test_path_outside_allowed_roots(self, mock_config):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="fs-rw",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/allowed"],
                    integration="filesystem",
                    write=True,
                ),
            ]
        )
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/not_allowed/a.md"],
                "output_path": "/allowed/out.md",
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "outside allowed" in result.error

    @patch("memex.mcp_servers.servers_config_from_env")
    def test_input_file_not_found(self, mock_config):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="fs-rw",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/tmp"],
                    integration="filesystem",
                    write=True,
                ),
            ]
        )
        result = execute_builtin(
            "file_transform",
            {
                "input_paths": ["/tmp/nonexistent_file_xyz.md"],
                "output_path": "/tmp/out.md",
                "instructions": "merge",
            },
        )
        assert not result.success
        assert "not found" in result.error

    @patch("memex.llm.chat_with_usage")
    def test_successful_transform(self, mock_chat, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        # Create input files
        f1 = tmp_path / "a.md"
        f1.write_text("# File A\nContent A")
        f2 = tmp_path / "b.md"
        f2.write_text("# File B\nContent B")
        out = tmp_path / "merged.md"

        mock_chat.return_value = (
            "# Merged\nContent A\nContent B",
            TokenUsage(prompt_tokens=100, completion_tokens=50, cost_usd=0.001),
        )

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1), str(f2)],
                    "output_path": str(out),
                    "instructions": "Merge these files into one",
                },
            )

        assert result.success
        assert "2 file(s)" in result.content
        assert str(out) in result.content
        # Output file was written
        assert out.exists()
        assert "Merged" in out.read_text()
        # Full content is NOT in the result (only summary)
        assert "Content A\nContent B" not in result.content
        # LLM was called with correct params
        mock_chat.assert_called_once()
        call_kwargs = mock_chat.call_args
        assert call_kwargs.kwargs["max_tokens"] == 16384
        assert call_kwargs.kwargs["temperature"] == 0.2

    @patch("memex.llm.chat_with_usage")
    def test_llm_failure(self, mock_chat, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "a.md"
        f1.write_text("content")
        mock_chat.side_effect = RuntimeError("LLM unavailable")

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(tmp_path / "out.md"),
                    "instructions": "reformat",
                },
            )

        assert not result.success
        assert "LLM call failed" in result.error

    @patch("memex.llm.chat_with_usage")
    def test_empty_llm_response(self, mock_chat, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "a.md"
        f1.write_text("content")
        mock_chat.return_value = ("", TokenUsage())

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(tmp_path / "out.md"),
                    "instructions": "reformat",
                },
            )

        assert not result.success
        assert "empty" in result.error.lower()

    @patch("memex.llm.chat_with_usage")
    def test_strips_outer_code_fence(self, mock_chat, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "a.md"
        f1.write_text("content")
        out = tmp_path / "out.md"
        mock_chat.return_value = (
            "```markdown\n# Result\nDone\n```",
            TokenUsage(prompt_tokens=50, completion_tokens=20),
        )

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(out),
                    "instructions": "reformat",
                },
            )

        assert result.success
        written = out.read_text()
        assert not written.startswith("```")
        assert not written.endswith("```")
        assert "# Result" in written

    @patch("memex.llm.chat_with_usage")
    def test_preserves_inner_code_fences(self, mock_chat, tmp_path):
        """Inner code blocks in content are not stripped."""
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "a.md"
        f1.write_text("content")
        out = tmp_path / "out.md"
        # LLM returns content with inner code blocks but no outer fence
        inner_content = "# Doc\n\nExample:\n```python\nprint('hi')\n```\n\nDone."
        mock_chat.return_value = (
            inner_content,
            TokenUsage(prompt_tokens=50, completion_tokens=20),
        )

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(out),
                    "instructions": "reformat",
                },
            )

        assert result.success
        written = out.read_text()
        assert "```python" in written
        assert "print('hi')" in written

    def test_binary_file_rejected(self, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "binary.dat"
        f1.write_bytes(b"hello\x00world")

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(tmp_path / "out.md"),
                    "instructions": "convert",
                },
            )

        assert not result.success
        assert "Binary" in result.error

    def test_oversized_file_rejected(self, tmp_path):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        f1 = tmp_path / "big.md"
        f1.write_text("x" * (600 * 1024))  # 600KB > 512KB limit

        with patch(
            "memex.mcp_servers.servers_config_from_env",
            return_value=MCPServersConfig(
                servers=[
                    MCPServerEntry(
                        name="fs-rw",
                        command="npx",
                        args=["@modelcontextprotocol/server-filesystem", str(tmp_path)],
                        integration="filesystem",
                        write=True,
                    ),
                ]
            ),
        ):
            result = execute_builtin(
                "file_transform",
                {
                    "input_paths": [str(f1)],
                    "output_path": str(tmp_path / "out.md"),
                    "instructions": "summarize",
                },
            )

        assert not result.success
        assert "too large" in result.error.lower()

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "file_transform" in _HANDLERS


class TestFileTransformCapability:
    def test_not_granted_without_filesystem_connector(self):
        from memex.security import get_granted_capabilities

        granted = get_granted_capabilities([])
        assert "builtin.file_transform" not in granted

    def test_granted_when_writable_filesystem_connected(self):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig
        from memex.models import ConnectorHealth
        from memex.security import get_granted_capabilities

        health = ConnectorHealth(
            name="filesystem",
            status="connected",
            last_check=utcnow(),
        )
        writable_config = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="fs-rw",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/workspace"],
                    integration="filesystem",
                    write=True,
                ),
            ]
        )
        with patch(
            "memex.mcp_servers.servers_config_from_env", return_value=writable_config
        ):
            granted = get_granted_capabilities([health])
        assert "builtin.file_transform" in granted

    def test_not_granted_when_only_readonly_filesystem(self):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig
        from memex.models import ConnectorHealth
        from memex.security import get_granted_capabilities

        health = ConnectorHealth(
            name="filesystem",
            status="connected",
            last_check=utcnow(),
        )
        readonly_config = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="fs-ro",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/code"],
                    integration="filesystem",
                    write=False,
                ),
            ]
        )
        with patch(
            "memex.mcp_servers.servers_config_from_env", return_value=readonly_config
        ):
            granted = get_granted_capabilities([health])
        assert "builtin.file_transform" not in granted


class TestSearchKnowledgeTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "search_knowledge" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "search_knowledge")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.read"
        assert tool.always_present is True
        assert "query" in tool.parameters["properties"]
        assert "query" in tool.parameters["required"]

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "search_knowledge" in _HANDLERS

    def test_missing_query(self):
        result = execute_builtin("search_knowledge", {})
        assert not result.success
        assert "query" in result.error.lower()

    def test_no_store_configured(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("content", None)
        try:
            result = execute_builtin("search_knowledge", {"query": "test"})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["content"] = original

    @patch("memex.memory.retrieval.retrieve_for_context")
    def test_successful_search(self, mock_retrieve):
        from memex.memory.retrieval import RetrievalResult
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        configure_stores(content_store=mock_store)
        mock_retrieve.return_value = RetrievalResult(
            text="## Retrieved Knowledge\n\n### [1] Test Article (relevance: 85%)\nSome content",
            document_ids={"content_item:item-1"},
        )

        try:
            result = execute_builtin("search_knowledge", {"query": "test article"})
            assert result.success
            assert "Test Article" in result.content
            mock_retrieve.assert_called_once()
            call_kwargs = mock_retrieve.call_args
            assert call_kwargs.args[0] == "test article"
        finally:
            _STORES.pop("content", None)

    def test_search_knowledge_surfaces_canonical_document_id_for_get_item_handoff(
        self, tmp_path
    ):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="handoff-knowledge-item",
                type=ItemType.NOTE,
                title="OAuth Rotation",
                body="Rotate the OAuth token and retry.",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="memory_intake", captured_at=now, confidence=1.0
                ),
                metadata={
                    "typed_knowledge": {
                        "knowledge_type": "procedure",
                        "steps": ["Rotate the OAuth token", "Retry"],
                    }
                },
            )
            content_store.create_item(item)
            store.sync_world_model_knowledge_from_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin("search_knowledge", {"query": "OAuth token"})

            assert result.success
            assert (
                "ID: world_model_knowledge:knowledge/handoff-knowledge-item"
                in result.content
            )
        finally:
            store.close()

    def test_search_knowledge_surfaces_content_item_document_id_for_live_item_handoff(
        self,
        tmp_path,
    ):
        from memex.fathom_facade import FathomMemexStore
        from memex.fathom_store import FathomStore
        from memex.tools_builtin import configure_stores
        from memex.models import Item, ItemType, Provenance

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        content_store = store.content
        try:
            now = utcnow()
            item = Item(
                item_id="handoff-content-item",
                type=ItemType.NOTE,
                title="Ephemeral scratchpad",
                body="This item is not projected into canonical knowledge.",
                captured_at=now,
                last_accessed=now,
                provenance=Provenance(
                    source="memory_intake", captured_at=now, confidence=1.0
                ),
                metadata={},
            )
            content_store.create_item(item)
            configure_stores(content_store=content_store, memex_store=store)

            result = execute_builtin(
                "search_knowledge", {"query": "Ephemeral scratchpad"}
            )

            assert result.success
            assert "ID: content_item:handoff-content-item" in result.content
        finally:
            store.close()

    @patch("memex.memory.retrieval.retrieve_for_context")
    def test_no_results(self, mock_retrieve):
        from memex.memory.retrieval import RetrievalResult
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        configure_stores(content_store=mock_store)
        mock_retrieve.return_value = RetrievalResult(text="", document_ids=set())

        try:
            result = execute_builtin("search_knowledge", {"query": "nonexistent"})
            assert result.success
            assert "No items found" in result.content
        finally:
            _STORES.pop("content", None)

    @patch("memex.memory.retrieval.retrieve_for_context")
    def test_limit_clamped(self, mock_retrieve):
        from memex.memory.retrieval import RetrievalResult
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        configure_stores(content_store=mock_store)
        mock_retrieve.return_value = RetrievalResult(text="", document_ids=set())

        try:
            execute_builtin("search_knowledge", {"query": "test", "limit": 100})
            call_kwargs = mock_retrieve.call_args
            assert call_kwargs.kwargs["max_items"] == 25  # clamped to max
        finally:
            _STORES.pop("content", None)


class TestSelfStateTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "self_state" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "self_state")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.read"
        assert tool.always_present is True
        assert tool.parameters["properties"] == {}

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "self_state" in _HANDLERS

    def test_requires_provider(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("self_state_provider", None)
        try:
            result = execute_builtin("self_state", {})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["self_state_provider"] = original

    def test_returns_json_snapshot(self):
        from memex.interfaces.caller import CallerContext
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock(
            return_value={
                "process": {"store_path": "/tmp/memex.db"},
                "session": {"active_interface": "tui"},
            }
        )
        caller = CallerContext.owner("tui", "test-session")
        original = _STORES.get("self_state_provider")
        try:
            configure_stores(self_state_provider=provider)
            result = execute_builtin("self_state", {}, caller=caller)

            assert result.success
            assert json.loads(result.content) == {
                "process": {"store_path": "/tmp/memex.db"},
                "session": {"active_interface": "tui"},
            }
            provider.assert_called_once_with(caller)
        finally:
            if original is None:
                _STORES.pop("self_state_provider", None)
            else:
                _STORES["self_state_provider"] = original


class TestListGoalsTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "list_goals" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "list_goals")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.read"

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "list_goals" in _HANDLERS

    def test_no_store_configured(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("goal", None)
        try:
            result = execute_builtin("list_goals", {})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["goal"] = original

    def test_list_active_goals(self):
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        mock_goal = MagicMock()
        mock_goal.goal_id = "abc12345-6789"
        mock_goal.title = "Learn Rust"
        mock_goal.status = MagicMock(value="active")
        mock_goal.priority = MagicMock(value="high")
        mock_goal.description = "Systems programming language"
        mock_goal.deadline = None
        mock_store.list_goals.return_value = [mock_goal]
        configure_stores(memex_store=mock_store)

        try:
            result = execute_builtin("list_goals", {})
            assert result.success
            assert "Learn Rust" in result.content
            assert (
                "1)" in result.content
                or "1 " in result.content
                or "(1)" in result.content
            )
        finally:
            _STORES.pop("goal", None)

    def test_no_goals_found(self):
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        mock_store.list_goals.return_value = []
        configure_stores(memex_store=mock_store)

        try:
            result = execute_builtin("list_goals", {})
            assert result.success
            assert "No active goals" in result.content
        finally:
            _STORES.pop("goal", None)


class TestListRemindersTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "list_reminders" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "list_reminders")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.read"

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "list_reminders" in _HANDLERS

    def test_no_store_configured(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("scheduler", None)
        try:
            result = execute_builtin("list_reminders", {})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["scheduler"] = original

    def test_list_reminders(self):
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        mock_task = MagicMock()
        mock_task.task_id = "reminder-abc123"
        mock_task.name = "Reminder: Call Mom"
        mock_task.description = "Weekly call"
        mock_task.cron_expr = "0 18 * * 0"
        mock_task.enabled = True
        mock_task.builtin = False
        mock_task.last_run_at = None
        mock_store.list_tasks.return_value = [mock_task]
        configure_stores(scheduler_store=mock_store)

        try:
            result = execute_builtin("list_reminders", {})
            assert result.success
            assert "Call Mom" in result.content
        finally:
            _STORES.pop("scheduler", None)

    def test_filters_out_builtins(self):
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        builtin_task = MagicMock()
        builtin_task.builtin = True
        builtin_task.task_id = "builtin-cleanup"
        mock_store.list_tasks.return_value = [builtin_task]
        configure_stores(scheduler_store=mock_store)

        try:
            result = execute_builtin("list_reminders", {})
            assert result.success
            assert "No reminders" in result.content
        finally:
            _STORES.pop("scheduler", None)

    def test_no_reminders_found(self):
        from memex.tools_builtin import _STORES, configure_stores

        mock_store = MagicMock()
        mock_store.list_tasks.return_value = []
        configure_stores(scheduler_store=mock_store)

        try:
            result = execute_builtin("list_reminders", {})
            assert result.success
            assert "No reminders" in result.content
        finally:
            _STORES.pop("scheduler", None)


class TestToolDescriptionClarity:
    """Ensure tool descriptions guide the LLM to use the right tool."""

    def test_forget_warns_about_deletion(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "forget")
        desc = tool.description.lower()
        assert "delete" in desc
        assert "destructive" in desc or "delete" in desc

    def test_forget_directs_to_search_knowledge(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "forget")
        assert "search_knowledge" in tool.description

    def test_remember_directs_to_search_knowledge(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "remember")
        assert "search_knowledge" in tool.description

    def test_search_knowledge_is_read_only(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "search_knowledge")
        assert (
            "READ-ONLY" in tool.description or "read-only" in tool.description.lower()
        )


class TestGmailSearchTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "gmail_search" in names

    def test_definition_schema(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "gmail_search")
        assert tool.source == "builtin"
        assert tool.required_capability == "builtin.write"
        props = tool.parameters["properties"]
        assert "from_address" in props
        assert "after" in props
        assert "newer_than" in props
        assert "query" in props
        assert "gmail" in tool.keywords

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "gmail_search" in _HANDLERS

    def test_missing_all_params(self):
        result = execute_builtin("gmail_search", {})
        assert not result.success
        assert "required" in result.error.lower()

    def test_no_content_store(self):
        from memex.tools_builtin import _STORES

        old = _STORES.pop("content", None)
        try:
            result = execute_builtin("gmail_search", {"query": "test"})
            assert not result.success
            assert "Knowledge store" in result.error
        finally:
            if old is not None:
                _STORES["content"] = old

    @patch("memex.integrations.gmail.GmailClient")
    def test_no_messages_found(self, MockClient):
        from memex.tools_builtin import _STORES

        mock_cs = MagicMock()
        _STORES["content"] = mock_cs
        try:
            client = MockClient.return_value
            client.search_messages.return_value = []

            result = execute_builtin("gmail_search", {"query": "nonexistent"})
            assert result.success
            assert "No messages found" in result.content
            client.authenticate.assert_called_once()
        finally:
            _STORES.pop("content", None)

    @patch("memex.memory.intake.ingest")
    @patch("memex.integrations.gmail.GmailClient")
    def test_ingests_messages(self, MockClient, mock_ingest):
        from memex.tools_builtin import _STORES

        mock_cs = MagicMock()
        _STORES["content"] = mock_cs
        try:
            client = MockClient.return_value
            client.search_messages.return_value = [
                {
                    "id": "m1",
                    "body": "hello",
                    "subject": "Test",
                    "from": "a@b.com",
                    "date": "Mar 14",
                },
                {
                    "id": "m2",
                    "body": "world",
                    "subject": "Test 2",
                    "from": "c@d.com",
                    "date": "Mar 13",
                },
            ]

            result = execute_builtin("gmail_search", {"query": "newer_than:7d"})
            assert result.success
            assert "Found 2 messages" in result.content
            assert "ingested 2" in result.content
            assert mock_ingest.call_count == 2
        finally:
            _STORES.pop("content", None)

    @patch.dict(os.environ, {"MEMEX_GMAIL_LABEL": ""})
    @patch("memex.memory.intake.ingest")
    @patch("memex.integrations.gmail.GmailClient")
    def test_limit_capped_at_50(self, MockClient, mock_ingest):
        from memex.tools_builtin import _STORES

        mock_cs = MagicMock()
        _STORES["content"] = mock_cs
        try:
            client = MockClient.return_value
            client.search_messages.return_value = []

            execute_builtin("gmail_search", {"query": "test", "limit": 100})
            client.search_messages.assert_called_once_with("test", limit=50)
        finally:
            _STORES.pop("content", None)

    @patch.dict(os.environ, {"MEMEX_GMAIL_LABEL": "interesting"})
    @patch("memex.integrations.gmail.GmailClient")
    def test_label_prepended_from_env(self, MockClient):
        from memex.tools_builtin import _STORES

        mock_cs = MagicMock()
        _STORES["content"] = mock_cs
        try:
            client = MockClient.return_value
            client.search_messages.return_value = []

            execute_builtin("gmail_search", {"query": "newer_than:7d"})
            client.search_messages.assert_called_once_with(
                "label:interesting newer_than:7d",
                limit=10,
            )
        finally:
            _STORES.pop("content", None)

    @patch.dict(os.environ, {}, clear=False)
    @patch("memex.integrations.gmail.GmailClient")
    def test_no_label_when_env_unset(self, MockClient):
        from memex.tools_builtin import _STORES

        os.environ.pop("MEMEX_GMAIL_LABEL", None)
        mock_cs = MagicMock()
        _STORES["content"] = mock_cs
        try:
            client = MockClient.return_value
            client.search_messages.return_value = []

            execute_builtin("gmail_search", {"query": "newer_than:7d"})
            client.search_messages.assert_called_once_with(
                "newer_than:7d",
                limit=10,
            )
        finally:
            _STORES.pop("content", None)


class TestBuiltinRegistration:
    def test_startup_registers_builtins(self, memory_store):
        """startup_health_check registers builtin tools."""
        from memex.loop import startup_health_check

        registry, _, _ = startup_health_check(memory_store)
        tool = registry.get_tool("web_fetch")
        assert tool is not None
        assert tool.source == "builtin"

    def test_startup_registers_new_tools(self, memory_store):
        """All new tools are registered during startup."""
        from memex.loop import startup_health_check

        registry, _, _ = startup_health_check(memory_store)
        for name in ("search_knowledge", "list_goals", "list_reminders"):
            tool = registry.get_tool(name)
            assert tool is not None, f"{name} not registered"
            assert tool.source == "builtin"


class TestSelfDiagnosticsTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "self_diagnostics" in names

    def test_required_capability(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "self_diagnostics")
        assert tool.required_capability == "builtin.read"
        assert tool.always_present is False

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "self_diagnostics" in _HANDLERS

    def test_no_provider_fails(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("diagnostics_provider", None)
        try:
            result = execute_builtin("self_diagnostics", {})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["diagnostics_provider"] = original

    def test_returns_formatted_output(self):
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock(
            return_value={
                "ok": False,
                "checks": [
                    {"name": "llm_proxy", "status": "ok", "detail": "reachable"},
                    {
                        "name": "scheduler",
                        "status": "warn",
                        "detail": "engine not registered",
                    },
                ],
            }
        )
        original = _STORES.get("diagnostics_provider")
        try:
            configure_stores(diagnostics_provider=provider)
            result = execute_builtin("self_diagnostics", {})
            assert result.success
            assert "[+]" in result.content
            assert "[!]" in result.content
            assert "llm_proxy" in result.content
            assert "scheduler" in result.content
        finally:
            if original is None:
                _STORES.pop("diagnostics_provider", None)
            else:
                _STORES["diagnostics_provider"] = original

    def test_passes_checks_filter(self):
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock(
            return_value={
                "ok": True,
                "checks": [
                    {"name": "llm_proxy", "status": "ok", "detail": "reachable"}
                ],
            }
        )
        original = _STORES.get("diagnostics_provider")
        try:
            configure_stores(diagnostics_provider=provider)
            execute_builtin("self_diagnostics", {"checks": ["llm_proxy"]})
            provider.assert_called_once_with(["llm_proxy"])
        finally:
            if original is None:
                _STORES.pop("diagnostics_provider", None)
            else:
                _STORES["diagnostics_provider"] = original


class TestSelfRepairTool:
    def test_definition_exists(self):
        names = [t.name for t in BUILTIN_TOOLS]
        assert "self_repair" in names

    def test_required_capability(self):
        tool = next(t for t in BUILTIN_TOOLS if t.name == "self_repair")
        assert tool.required_capability == "builtin.write"
        assert tool.always_present is False

    def test_handler_registered(self):
        from memex.tools_builtin import _HANDLERS

        assert "self_repair" in _HANDLERS

    def test_no_provider_fails(self):
        from memex.tools_builtin import _STORES

        original = _STORES.pop("repair_provider", None)
        try:
            result = execute_builtin("self_repair", {"action": "reset_proxy"})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            if original is not None:
                _STORES["repair_provider"] = original

    def test_missing_action(self):
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock()
        original = _STORES.get("repair_provider")
        try:
            configure_stores(repair_provider=provider)
            result = execute_builtin("self_repair", {})
            assert not result.success
            assert "action" in result.error.lower()
        finally:
            if original is None:
                _STORES.pop("repair_provider", None)
            else:
                _STORES["repair_provider"] = original

    def test_reset_proxy_success(self):
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock(
            return_value={
                "ok": True,
                "action": "reset_proxy",
                "detail": "Proxy-disabled flag cleared.",
            }
        )
        original = _STORES.get("repair_provider")
        try:
            configure_stores(repair_provider=provider)
            result = execute_builtin("self_repair", {"action": "reset_proxy"})
            assert result.success
            assert "[+]" in result.content
            assert "reset_proxy" in result.content
        finally:
            if original is None:
                _STORES.pop("repair_provider", None)
            else:
                _STORES["repair_provider"] = original

    def test_restart_queue_fail(self):
        from memex.tools_builtin import _STORES, configure_stores

        provider = MagicMock(
            return_value={
                "ok": False,
                "action": "restart_queue",
                "detail": "Scheduler engine not registered.",
            }
        )
        original = _STORES.get("repair_provider")
        try:
            configure_stores(repair_provider=provider)
            result = execute_builtin("self_repair", {"action": "restart_queue"})
            assert not result.success
            assert "[X]" in result.content
            assert "restart_queue" in result.content
        finally:
            if original is None:
                _STORES.pop("repair_provider", None)
            else:
                _STORES["repair_provider"] = original
