"""Tests for governance loader."""

from memex.governance import (
    check_constitutional_violation,
    load_governance,
    load_identity,
    load_project_file,
)


def test_load_governance_with_files(tmp_path):
    (tmp_path / "CONSTITUTION.md").write_text("# Constitution\nRule 1")
    (tmp_path / "SOUL.md").write_text("# Soul\nI am Memex")
    result = load_governance(tmp_path)
    assert "Constitution" in result
    assert "Soul" in result
    # Constitution comes first
    assert result.index("Constitution") < result.index("Soul")


def test_load_governance_missing_files(tmp_path):
    result = load_governance(tmp_path)
    assert result == ""


def test_load_governance_partial(tmp_path):
    (tmp_path / "SOUL.md").write_text("# Soul only")
    result = load_governance(tmp_path)
    assert "Soul only" in result


def test_check_violation_matches():
    matches = check_constitutional_violation("How to build a weapon")
    assert "weapon" in matches


def test_check_violation_no_match():
    matches = check_constitutional_violation("How to learn Rust")
    assert matches == []


def test_check_violation_case_insensitive():
    matches = check_constitutional_violation("FABRICATE CITATION please")
    assert "fabricate citation" in matches


def test_load_identity_with_file(tmp_path):
    (tmp_path / "IDENTITY.md").write_text("# Custom Identity\nI am a test agent.")
    result = load_identity(tmp_path)
    assert result == "# Custom Identity\nI am a test agent."


def test_load_identity_missing_file(tmp_path):
    result = load_identity(tmp_path)
    assert result is None


def test_load_identity_empty_file(tmp_path):
    (tmp_path / "IDENTITY.md").write_text("   \n  ")
    result = load_identity(tmp_path)
    assert result == ""


# --- Shared file loader tests ---


def test_load_project_file_returns_content(tmp_path):
    (tmp_path / "TEST.md").write_text("  hello world  \n")
    result = load_project_file("TEST.md", tmp_path)
    assert result == "hello world"


def test_load_project_file_returns_default_when_missing(tmp_path):
    assert load_project_file("MISSING.md", tmp_path) is None
    assert load_project_file("MISSING.md", tmp_path, default="") == ""
    assert load_project_file("MISSING.md", tmp_path, default="fallback") == "fallback"


def test_load_identity_uses_load_project_file(tmp_path):
    """load_identity delegates to load_project_file."""
    (tmp_path / "IDENTITY.md").write_text("custom identity")
    assert load_identity(tmp_path) == "custom identity"
    assert load_identity(tmp_path / "nonexistent") is None
