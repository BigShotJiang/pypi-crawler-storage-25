"""Tests for auto-ingest framework."""

from unittest.mock import MagicMock, patch

from memex.auto_ingest.base import IngestItem
from memex.auto_ingest.gmail import GmailAutoIngestSource
from memex.auto_ingest.registry import SourceRegistry
from memex.auto_ingest.rss import RSSFeedSource
from memex.auto_ingest.watch_folder import WatchFolderSource
from memex.models import ItemType


def test_watch_folder_source(tmp_path):
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    (inbox / "test_note.txt").write_text("hello world")
    (inbox / "my_doc.md").write_text("# My Doc\nSome content")

    source = WatchFolderSource(inbox_path=inbox)
    items = source.fetch()

    assert len(items) == 2
    # Items are sorted by filename
    titles = {item.title for item in items}
    assert "test note" in titles
    assert "my doc" in titles

    # Files should be moved to .processed
    assert (inbox / ".processed" / "test_note.txt").exists()
    assert (inbox / ".processed" / "my_doc.md").exists()
    assert not (inbox / "test_note.txt").exists()
    assert not (inbox / "my_doc.md").exists()


def test_watch_folder_empty(tmp_path):
    inbox = tmp_path / "inbox"
    inbox.mkdir()

    source = WatchFolderSource(inbox_path=inbox)
    items = source.fetch()
    assert items == []


def test_watch_folder_unsupported(tmp_path):
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    (inbox / "binary.exe").write_bytes(b"\x00\x01\x02")

    source = WatchFolderSource(inbox_path=inbox)
    items = source.fetch()
    assert items == []


def test_watch_folder_skips_symlinks(tmp_path):
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    # Create a real file and a symlink
    real_file = tmp_path / "real.txt"
    real_file.write_text("real content")
    (inbox / "link.txt").symlink_to(real_file)
    (inbox / "normal.txt").write_text("normal content")

    source = WatchFolderSource(inbox_path=inbox)
    items = source.fetch()
    # Should only get the normal file, not the symlink
    assert len(items) == 1
    assert items[0].title == "normal"


def test_rss_feed_source_mocked():
    source = RSSFeedSource(feed_urls=["https://example.com/feed.xml"])

    mock_entry = MagicMock()
    mock_entry.title = "Test Article"
    mock_entry.link = "https://example.com/article"
    mock_entry.summary = "This is a test article summary"
    mock_entry.author = "Test Author"

    mock_feed = MagicMock()
    mock_feed.entries = [mock_entry]

    mock_feedparser = MagicMock()
    mock_feedparser.parse.return_value = mock_feed
    with patch.dict("sys.modules", {"feedparser": mock_feedparser}):
        items = source.fetch()

    assert len(items) == 1
    assert items[0].title == "Test Article"
    assert items[0].source_url == "https://example.com/article"
    assert items[0].item_type == ItemType.ARTICLE
    assert items[0].author == "Test Author"
    assert "rss" in items[0].tags


def test_rss_no_feeds():
    source = RSSFeedSource(feed_urls=[])
    mock_feedparser = MagicMock()
    with patch.dict("sys.modules", {"feedparser": mock_feedparser}):
        items = source.fetch()
    assert items == []


def test_gmail_skeleton_no_auth():
    source = GmailAutoIngestSource()
    # Gmail fetch should raise when auth fails
    import pytest

    mock_client = MagicMock()
    mock_client.authenticate.side_effect = RuntimeError("No credentials")
    with patch("memex.integrations.gmail.GmailClient", return_value=mock_client):
        with pytest.raises(RuntimeError):
            source.fetch()


def test_registry_register_and_list(tmp_path):
    registry = SourceRegistry()
    inbox = tmp_path / "inbox"
    inbox.mkdir()

    wf = WatchFolderSource(inbox_path=inbox)
    registry.register(wf)

    sources = registry.list_sources()
    assert "watch_folder" in sources

    assert registry.get_source("watch_folder") is wf
    assert registry.get_source("nonexistent") is None


def test_registry_fetch_error():
    """Source.fetch() errors should propagate with logging, not crash silently."""
    import pytest

    registry = SourceRegistry()
    mock_source = MagicMock()
    mock_source.name = "broken"
    mock_source.source_type = "mock"
    mock_source.fetch.side_effect = ConnectionError("network down")

    registry.register(mock_source)

    with pytest.raises(ConnectionError):
        registry.run_source("broken", content_store=MagicMock())


def test_registry_run_source_mocked(tmp_path):
    registry = SourceRegistry()

    mock_source = MagicMock()
    mock_source.name = "mock_source"
    mock_source.source_type = "mock"
    mock_source.fetch.return_value = [
        IngestItem(content="test content", title="Test", item_type=ItemType.NOTE),
    ]

    registry.register(mock_source)

    # run_source requires a content_store; mock the ingest call
    with patch("memex.memory.intake.ingest") as mock_ingest:
        count = registry.run_source("mock_source", content_store=MagicMock())

    assert count == 1
    mock_ingest.assert_called_once()
