"""Direct tests for the canonical human partner profile helpers."""

from unittest.mock import MagicMock

from memex.human_model import (
    format_combined_partner_prompt,
    format_for_prompt,
    load_canonical_partner_profile,
    load_canonical_speaker_mappings,
    load_user_md,
    save_partner_profile,
)
from memex.models import HumanPartnerProfile
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore


def test_load_canonical_partner_profile_returns_empty_profile_without_fallback():
    store = MagicMock()
    store.load_partner_profile.return_value = None

    profile = load_canonical_partner_profile(store)

    assert profile.name == ""
    assert profile.communication_style == ""
    assert profile.working_context.role == ""
    assert profile.knowledge_profile.preferences == {}


def test_load_canonical_speaker_mappings_reads_only_partner_profile():
    store = MagicMock()
    store.load_partner_profile.return_value = HumanPartnerProfile(
        name="Corey",
        working_context={"speaker_mappings": {"SPEAKER_00": "Corey"}},
    )

    mappings = load_canonical_speaker_mappings(store)

    assert mappings == {"SPEAKER_00": "Corey"}


def test_save_partner_profile_persists_only_canonical_profile():
    store = MagicMock()
    profile = HumanPartnerProfile(
        name="Corey",
        communication_style="concise",
        working_context={
            "timezone": "America/Chicago",
            "role": "engineer",
            "speaker_mappings": {"SPEAKER_00": "Corey"},
        },
        knowledge_profile={"preferences": {"editor": "neovim"}},
    )

    save_partner_profile(profile, store)

    store.save_partner_profile.assert_called_once()
    store.replace_world_model_semantic_mappings.assert_called_once()
    assert store.method_calls[0][0] == "save_partner_profile"


def test_format_for_prompt_accepts_partner_profile():
    prompt = format_for_prompt(
        HumanPartnerProfile(
            name="Corey",
            communication_style="concise",
            working_context={
                "timezone": "America/Chicago",
                "role": "engineer",
                "team": "platform",
            },
            knowledge_profile={
                "preferences": {"editor": "neovim"},
                "expertise": ["Python"],
            },
        )
    )

    assert "Name: Corey" in prompt
    assert "Communication style: concise" in prompt
    assert "Timezone: America/Chicago" in prompt
    assert "Role: engineer" in prompt
    assert "Team: platform" in prompt
    assert "editor: neovim" in prompt
    assert "Python" in prompt


def test_format_for_prompt_includes_partner_only_fields():
    prompt = format_for_prompt(
        HumanPartnerProfile(
            name="Corey",
            communication_style="concise",
            explanation_level="deep",
        )
    )

    assert "Explanation level: deep" in prompt


def test_save_partner_profile_syncs_canonical_speaker_mappings(tmp_path):
    fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(fs)
    try:
        save_partner_profile(
            HumanPartnerProfile(
                name="Corey",
                working_context={
                    "speaker_mappings": {"SPEAKER_00": "Corey", "SPEAKER_01": "Taylor"}
                },
            ),
            store,
        )

        mappings = store.list_world_model_semantic_mappings()

        assert len(mappings) == 2
        assert {mapping.mapping_kind for mapping in mappings} == {"speaker_alias"}
        assert {mapping.source_value for mapping in mappings} == {
            "SPEAKER_00",
            "SPEAKER_01",
        }
        assert {mapping.target_value for mapping in mappings} == {"Corey", "Taylor"}
    finally:
        store.close()


# --- USER.md tests ---


def test_load_user_md_with_file(tmp_path):
    (tmp_path / "USER.md").write_text("# About the Human\nName: Corey")
    result = load_user_md(tmp_path)
    assert "Name: Corey" in result


def test_load_user_md_missing(tmp_path):
    """Missing USER.md returns empty string, not None."""
    result = load_user_md(tmp_path)
    assert result == ""
    assert result is not None


def test_format_combined_user_md_only(tmp_path):
    (tmp_path / "USER.md").write_text("# About the Human\nName: Corey")
    result = format_combined_partner_prompt(
        HumanPartnerProfile(), project_root=tmp_path
    )
    assert "Name: Corey" in result


def test_format_combined_db_only(tmp_path):
    profile = HumanPartnerProfile(name="Corey", communication_style="direct")
    result = format_combined_partner_prompt(profile, project_root=tmp_path)
    assert "Name: Corey" in result
    assert "Communication style: direct" in result


def test_format_combined_both_sources(tmp_path):
    (tmp_path / "USER.md").write_text("# Static Context\nTimezone: America/Chicago")
    profile = HumanPartnerProfile(name="Corey")
    result = format_combined_partner_prompt(profile, project_root=tmp_path)
    # USER.md content comes first
    assert result.index("Timezone") < result.index("Corey")


def test_format_combined_neither_source(tmp_path):
    result = format_combined_partner_prompt(
        HumanPartnerProfile(), project_root=tmp_path
    )
    assert result == ""
