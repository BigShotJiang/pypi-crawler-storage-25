"""Tests for deterministic prompt-control artifacts."""

from memex.models import (
    AgentSelfModel,
    InputClassification,
    InputClassificationType,
    IntentFrame,
    IntentFramePath,
    PromptControlPlanSnapshot,
    PromptControlPlanStepSnapshot,
    PromptControlRouteProfile,
)
from memex.prompt_control import (
    _DEFAULT_CUES,
    _collect_signals,
    build_prompt_control_artifact,
    load_signal_cues,
    render_prompt_control_section,
)
from memex.utcnow import utcnow


def _intent_frame(
    *,
    raw_input: str,
    classification: InputClassificationType,
    selected_path: IntentFramePath,
    confidence: float = 0.9,
) -> IntentFrame:
    return IntentFrame(
        raw_input=raw_input,
        classification=classification,
        summary=raw_input[:120],
        selected_path=selected_path,
        confidence=confidence,
        rationale="test rationale",
        created_at=utcnow(),
    )


def test_build_prompt_control_artifact_for_operational_route():
    classification = InputClassification(
        classification=InputClassificationType.NEW_GOAL,
        confidence=0.92,
        reasoning="new intent detected",
        suggested_title="Learn Rust",
    )
    intent = _intent_frame(
        raw_input="I want to learn Rust",
        classification=InputClassificationType.NEW_GOAL,
        selected_path=IntentFramePath.ACT,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-1",
        user_input="I want to learn Rust",
        classification=classification,
        intent_frame=intent,
        tool_candidate_names=["remember"],
    )

    assert artifact.route_profile == PromptControlRouteProfile.OPERATIONAL_TOOL
    assert artifact.tool_policy == "enabled_per_permission"
    assert artifact.validation_policy == "action_result_check"
    assert artifact.memory_policy == "task_state"
    assert artifact.response_contract == "action_summary"
    assert artifact.tool_candidate_names == ["remember"]
    assert artifact.parser_version == "pc.v1"
    assert artifact.routing_version == "pc.v1"


def test_build_prompt_control_artifact_for_research_verified_route():
    classification = InputClassification(
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        confidence=0.88,
        reasoning="knowledge lookup",
    )
    intent = _intent_frame(
        raw_input="What are the latest Rust release notes? Verify with sources.",
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.88,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-2",
        user_input="What are the latest Rust release notes? Verify with sources.",
        classification=classification,
        intent_frame=intent,
        tool_candidate_names=["search_knowledge", "web_fetch"],
    )

    assert artifact.route_profile == PromptControlRouteProfile.RESEARCH_VERIFIED
    assert artifact.tool_policy == "retrieval_and_verification"
    assert artifact.validation_policy == "citation_cross_check"
    assert artifact.memory_policy == "sources_and_conclusions"
    assert artifact.response_contract == "cited_answer"


def test_build_prompt_control_artifact_emits_drift_warning_for_stylized_high_stakes_request():
    classification = InputClassification(
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        confidence=0.7,
        reasoning="knowledge lookup",
    )
    intent = _intent_frame(
        raw_input="Pretend you are a poet and explain this medical diagnosis.",
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.7,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-3",
        user_input="Pretend you are a poet and explain this medical diagnosis.",
        classification=classification,
        intent_frame=intent,
    )

    assert artifact.route_profile == PromptControlRouteProfile.GUARDED_REVIEW
    assert artifact.high_stakes is True
    assert artifact.stylization_drift > 0.0
    assert any(
        warning.warning_type == "stylization_drift"
        for warning in artifact.lint_warnings
    )


def test_build_prompt_control_artifact_routes_guarded_for_degraded_self_model():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.82,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="What should we do next?",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.82,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-guarded",
        user_input="What should we do next?",
        classification=classification,
        intent_frame=intent,
        agent_self_model=AgentSelfModel(
            degraded_modes=["projection_stale"],
        ),
    )

    assert artifact.route_profile == PromptControlRouteProfile.GUARDED_REVIEW
    assert artifact.tool_policy == "minimal_tools_guarded"
    assert "self_model_guarded" in artifact.detected_signals
    assert "self-model signal detected" in artifact.route_rationale


def test_render_prompt_control_section_includes_policy_bundle_and_warnings():
    classification = InputClassification(
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        confidence=0.88,
        reasoning="knowledge lookup",
    )
    intent = _intent_frame(
        raw_input="What are the latest Rust release notes? Verify with sources.",
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.88,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-4",
        user_input="What are the latest Rust release notes? Verify with sources.",
        classification=classification,
        intent_frame=intent,
        tool_candidate_names=["search_knowledge", "web_fetch"],
    )
    section = render_prompt_control_section(artifact)

    assert "## Prompt Control" in section
    assert "Route profile: research_verified" in section
    assert "Tool policy: retrieval_and_verification" in section
    assert "Validation policy: citation_cross_check" in section
    assert "Response contract: cited_answer" in section
    assert "search_knowledge, web_fetch" in section


def test_build_prompt_control_artifact_uses_turn_scoped_id_when_turn_is_provided():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="Summarize our plan.",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.8,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-5",
        user_input="Summarize our plan.",
        classification=classification,
        intent_frame=intent,
        conversation_turn_id=3,
    )

    assert artifact.artifact_id == "session:session-5:prompt_control:turn:3"
    assert artifact.conversation_turn_id == 3


def test_build_prompt_control_artifact_carries_compact_plan_snapshot_and_blocker_policy():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.84,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="What should we do next on the rollout?",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.84,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-6",
        user_input="What should we do next on the rollout?",
        classification=classification,
        intent_frame=intent,
        plan_snapshot=PromptControlPlanSnapshot(
            goal_id="goal-1",
            plan_id="plan-1",
            title="Rollout plan",
            status="active",
            selected_step=PromptControlPlanStepSnapshot(
                step_id="step-1",
                step_kind="verification",
                title="Verify rollout",
                status="blocked",
                progress_pct=60,
                blocked_reason="Waiting on approval signoff.",
            ),
        ),
    )

    assert artifact.plan_snapshot is not None
    assert artifact.plan_snapshot.plan_id == "plan-1"
    assert "plan_present" in artifact.detected_signals
    assert "plan_step_blocked" in artifact.detected_signals
    assert "plan=Rollout plan [active]" in artifact.route_rationale
    assert "step=Verify rollout [blocked]" in artifact.route_rationale
    assert any(
        warning.warning_type == "plan_step_blocked"
        for warning in artifact.lint_warnings
    )


def test_render_prompt_control_section_includes_compact_plan_snapshot():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.84,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="What should we do next on the rollout?",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
        confidence=0.84,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-7",
        user_input="What should we do next on the rollout?",
        classification=classification,
        intent_frame=intent,
        plan_snapshot=PromptControlPlanSnapshot(
            goal_id="goal-1",
            plan_id="plan-1",
            title="Rollout plan",
            status="active",
            selected_step=PromptControlPlanStepSnapshot(
                step_id="step-1",
                step_kind="verification",
                title="Verify rollout",
                status="blocked",
                progress_pct=60,
                blocked_reason="Waiting on approval signoff.",
            ),
        ),
    )

    section = render_prompt_control_section(artifact)

    assert "## Prompt Control" in section
    assert "Plan: Rollout plan [active]" in section
    assert "Current step: Verify rollout [blocked, 60%]" in section
    assert "Step blocker: Waiting on approval signoff." in section


# --- prompt_mode persistence tests ---


def test_build_prompt_control_artifact_carries_prompt_mode():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="hello",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-mode",
        user_input="hello",
        classification=classification,
        intent_frame=intent,
        prompt_mode="minimal",
    )

    assert artifact.prompt_mode == "minimal"


def test_prompt_mode_persists_through_store_round_trip(tmp_path):
    from memex.fathom_facade import FathomMemexStore
    from memex.fathom_store import FathomStore

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        classification = InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.8,
            reasoning="general chat",
        )
        intent = _intent_frame(
            raw_input="hello",
            classification=InputClassificationType.CONVERSATIONAL,
            selected_path=IntentFramePath.DIRECT_ANSWER,
        )
        artifact = build_prompt_control_artifact(
            session_id="session-store",
            user_input="hello",
            classification=classification,
            intent_frame=intent,
            prompt_mode="minimal",
        )
        store.upsert_prompt_control_artifact(artifact)
        loaded = store.load_latest_prompt_control_artifact("session-store")
        assert loaded is not None
        assert loaded.prompt_mode == "minimal"
    finally:
        store.close()


def test_build_prompt_control_artifact_defaults_prompt_mode_to_full():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    intent = _intent_frame(
        raw_input="hello",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=IntentFramePath.DIRECT_ANSWER,
    )

    artifact = build_prompt_control_artifact(
        session_id="session-mode-default",
        user_input="hello",
        classification=classification,
        intent_frame=intent,
    )

    assert artifact.prompt_mode == "full"


# --- Signal cue loading tests ---


def test_load_signal_cues_defaults_when_no_file(tmp_path):
    cues = load_signal_cues(tmp_path)
    assert cues == _DEFAULT_CUES


def test_load_signal_cues_from_toml(tmp_path):
    (tmp_path / "SIGNALS.toml").write_text('[creative]\ncues = ["haiku", "limerick"]\n')
    cues = load_signal_cues(tmp_path)
    assert cues["creative"] == ("haiku", "limerick")
    # Other sections fall back to defaults
    assert cues["jailbreak"] == _DEFAULT_CUES["jailbreak"]


def test_load_signal_cues_partial_toml(tmp_path):
    (tmp_path / "SIGNALS.toml").write_text('[social]\ncues = ["text", "dm"]\n')
    cues = load_signal_cues(tmp_path)
    assert cues["social"] == ("text", "dm")
    assert cues["creative"] == _DEFAULT_CUES["creative"]


def test_load_signal_cues_invalid_toml(tmp_path):
    (tmp_path / "SIGNALS.toml").write_text("not valid toml {{{")
    cues = load_signal_cues(tmp_path)
    assert cues == _DEFAULT_CUES


def test_collect_signals_with_custom_cues():
    custom = dict(_DEFAULT_CUES)
    custom["creative"] = ("painting", "sculpture")
    signals, _, drift, _ = _collect_signals("i want to try painting", custom)
    assert "creative_mode" in signals
    assert drift > 0


def test_collect_signals_custom_cues_no_false_positive():
    custom = dict(_DEFAULT_CUES)
    custom["creative"] = ("painting",)
    signals, _, drift, _ = _collect_signals("tell me a story", custom)
    # "story" is in defaults but not in custom
    assert "creative_mode" not in signals
    assert drift == 0.0
