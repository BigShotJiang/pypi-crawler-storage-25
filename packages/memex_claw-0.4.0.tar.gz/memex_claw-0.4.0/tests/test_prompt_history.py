"""Tests for TUI prompt history persistence."""

from __future__ import annotations

import json
import os
import stat
from datetime import timedelta

import pytest

from memex.interfaces.tui.prompt_history import (
    PromptHistory,
    _MAX_ENTRIES,
    _MAX_AGE_HOURS,
)
from memex.utcnow import utcnow


@pytest.fixture
def history_path(tmp_path):
    return tmp_path / "history.json"


class TestPromptHistory:
    def test_empty_history(self, history_path):
        """No file -> empty entries."""
        h = PromptHistory(path=history_path)
        h.load()
        assert h.entries == []

    def test_add_and_retrieve(self, history_path):
        """Add entries, verify oldest-first order."""
        h = PromptHistory(path=history_path)
        h.load()
        h.add("first")
        h.add("second")
        h.add("third")
        assert h.entries == ["first", "second", "third"]

    def test_max_entries_enforced(self, history_path):
        """Add 25, only last 20 retained."""
        h = PromptHistory(path=history_path)
        h.load()
        for i in range(25):
            h.add(f"entry-{i}")
        assert len(h.entries) == _MAX_ENTRIES
        assert h.entries[0] == "entry-5"
        assert h.entries[-1] == "entry-24"

    def test_dedup_consecutive(self, history_path):
        """Same text twice in a row -> stored once."""
        h = PromptHistory(path=history_path)
        h.load()
        h.add("hello")
        h.add("hello")
        assert h.entries == ["hello"]

    def test_dedup_nonconsecutive_allowed(self, history_path):
        """Non-consecutive duplicates are allowed."""
        h = PromptHistory(path=history_path)
        h.load()
        h.add("hello")
        h.add("world")
        h.add("hello")
        assert h.entries == ["hello", "world", "hello"]

    def test_prune_old_entries(self, history_path):
        """Entries >48h removed on load."""
        old_ts = (utcnow() - timedelta(hours=_MAX_AGE_HOURS + 1)).isoformat()
        fresh_ts = utcnow().isoformat()
        data = [
            {"text": "old", "ts": old_ts},
            {"text": "fresh", "ts": fresh_ts},
        ]
        history_path.write_text(json.dumps(data))

        h = PromptHistory(path=history_path)
        h.load()
        assert h.entries == ["fresh"]

    def test_persistence_round_trip(self, history_path):
        """Write with one instance, read with another."""
        h1 = PromptHistory(path=history_path)
        h1.load()
        h1.add("persisted")

        h2 = PromptHistory(path=history_path)
        h2.load()
        assert h2.entries == ["persisted"]

    def test_corrupt_file_loads_empty(self, history_path):
        """Malformed JSON -> empty, no crash."""
        history_path.write_text("{not valid json!!")
        h = PromptHistory(path=history_path)
        h.load()
        assert h.entries == []

    def test_file_permissions(self, history_path):
        """Saved file has 0o600."""
        h = PromptHistory(path=history_path)
        h.load()
        h.add("secret")
        mode = stat.S_IMODE(os.stat(history_path).st_mode)
        assert mode == 0o600

    def test_empty_and_whitespace_skipped(self, history_path):
        """Empty strings and whitespace-only are not added."""
        h = PromptHistory(path=history_path)
        h.load()
        h.add("")
        h.add("   ")
        h.add("\n")
        assert h.entries == []
