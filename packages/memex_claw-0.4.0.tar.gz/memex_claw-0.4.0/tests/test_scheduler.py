"""Tests for proactive surfacing / scheduler."""

from datetime import timedelta

from memex.models import GoalStatus, SessionContext
from memex.scheduler import PROACTIVE_INTERVAL, check_proactive, get_session_briefing
from conftest import make_goal
from memex.utcnow import utcnow


def test_check_proactive_throttle(memory_store):
    """Should only fire on turns divisible by PROACTIVE_INTERVAL."""
    session = SessionContext(
        session_id="test",
        started_at=utcnow(),
        turn_count=3,  # not divisible by 5
    )
    assert check_proactive(session, memory_store) is None


def test_check_proactive_deadline(memory_store):
    now = utcnow()
    g = make_goal(title="Urgent", deadline=now + timedelta(hours=6))
    memory_store.create_goal(g)

    session = SessionContext(
        session_id="test",
        started_at=now,
        turn_count=PROACTIVE_INTERVAL,
    )
    msg = check_proactive(session, memory_store, now)
    assert msg is not None
    assert "Urgent" in msg


def test_check_proactive_stale(memory_store):
    now = utcnow()
    g = make_goal(title="Forgotten", days_ago=30)
    memory_store.create_goal(g)

    session = SessionContext(
        session_id="test",
        started_at=now,
        turn_count=PROACTIVE_INTERVAL,
    )
    msg = check_proactive(session, memory_store, now)
    assert msg is not None
    assert "Forgotten" in msg


def test_check_proactive_blocked(memory_store):
    now = utcnow()
    g = make_goal(
        title="Stuck", status=GoalStatus.BLOCKED, blocked_reason="need API key"
    )
    memory_store.create_goal(g)

    session = SessionContext(
        session_id="test",
        started_at=now,
        turn_count=PROACTIVE_INTERVAL,
    )
    msg = check_proactive(session, memory_store, now)
    assert msg is not None
    assert "Stuck" in msg


def test_check_proactive_turn_zero(memory_store):
    session = SessionContext(
        session_id="test",
        started_at=utcnow(),
        turn_count=0,
    )
    assert check_proactive(session, memory_store) is None


def test_session_briefing_empty(memory_store):
    briefing = get_session_briefing(memory_store)
    assert "No active goals" in briefing


def test_session_briefing_with_goals(memory_store):
    memory_store.create_goal(make_goal(title="Learn Rust"))
    memory_store.create_goal(make_goal(title="Build Memex"))
    briefing = get_session_briefing(memory_store)
    assert "Learn Rust" in briefing
    assert "Build Memex" in briefing
