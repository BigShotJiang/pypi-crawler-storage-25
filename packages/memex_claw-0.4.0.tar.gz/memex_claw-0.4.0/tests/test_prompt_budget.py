from unittest.mock import MagicMock

from memex.prompt_budget import (
    PromptBudgetConfig,
    PromptBudgetSection,
    PromptBudgetUsage,
    PromptMode,
    budget_prompt_context,
    filter_sections_for_mode,
    load_prompt_budget_config,
    truncate_prompt_text,
)


def test_truncate_prompt_text_marks_truncation():
    text = "## Section\n" + ("line\n" * 200)

    truncated = truncate_prompt_text(text, max_tokens=20)

    assert truncated.startswith("## Section")
    assert truncated.endswith("... [prompt budget truncated]")


def test_budget_prompt_context_enforces_bucket_caps_and_order():
    budgeted = budget_prompt_context(
        stable_sections=[
            PromptBudgetSection("stable_a", "A" * 120, 40),
            PromptBudgetSection("stable_b", "B" * 120, 40),
        ],
        dynamic_sections=[
            PromptBudgetSection("dynamic_a", "D" * 80, 30),
            PromptBudgetSection("dynamic_b", "E" * 80, 30),
        ],
        operator_sections=[
            PromptBudgetSection("operator_a", "O" * 80, 30),
        ],
        retrieval_text="R" * 400,
        config=PromptBudgetConfig(
            stable_prefix_tokens=40,
            dynamic_turn_tokens=30,
            retrieval_tokens=25,
            operator_tokens=15,
        ),
    )

    assert budgeted.stable_parts
    assert budgeted.stable_parts[0].startswith("A")
    assert len("\n\n".join(budgeted.stable_parts)) <= 160
    assert len("\n\n".join(budgeted.dynamic_parts)) <= 120
    assert len("\n\n".join(budgeted.operator_parts)) <= 60
    assert len(budgeted.retrieval_text) <= 100


# --- PromptMode filtering tests ---

_ALL_SECTIONS = [
    PromptBudgetSection("governance", "gov", 100),
    PromptBudgetSection("identity", "id", 100),
    PromptBudgetSection("agent_self", "self", 100),
    PromptBudgetSection("partner", "partner", 100),
    PromptBudgetSection("interface", "iface", 100),
    PromptBudgetSection("mode", "mode", 100),
    PromptBudgetSection("memory_block", "mem", 100),
    PromptBudgetSection("prompt_control", "pc", 100),
    PromptBudgetSection("goals", "goals", 100),
    PromptBudgetSection("session_summary", "ss", 100),
    PromptBudgetSection("skill_block", "skills", 100),
    PromptBudgetSection("session_items", "items", 100),
    PromptBudgetSection("proactive_context", "proactive", 100),
    PromptBudgetSection("world_model", "wm", 100),
]


def test_filter_full_mode_keeps_all():
    result = filter_sections_for_mode(_ALL_SECTIONS, mode=PromptMode.FULL)
    assert len(result) == len(_ALL_SECTIONS)


def test_filter_minimal_drops_expected_sections():
    result = filter_sections_for_mode(_ALL_SECTIONS, mode=PromptMode.MINIMAL)
    names = {s.name for s in result}
    # These should be dropped
    assert "skill_block" not in names
    assert "session_items" not in names
    assert "proactive_context" not in names
    assert "world_model" not in names
    assert "session_summary" not in names
    # These should remain
    assert "governance" in names
    assert "identity" in names
    assert "partner" in names
    assert "prompt_control" in names
    assert "goals" in names


def test_filter_bare_keeps_only_governance_and_identity():
    result = filter_sections_for_mode(_ALL_SECTIONS, mode=PromptMode.BARE)
    names = {s.name for s in result}
    assert names == {"governance", "identity"}


# --- Budget config loading tests ---


def test_load_prompt_budget_config_returns_defaults_when_none():
    config = load_prompt_budget_config(None)
    assert config.stable_prefix_tokens == 1600
    assert config.dynamic_turn_tokens == 900


def test_load_prompt_budget_config_reads_from_settings():
    settings = MagicMock()
    settings.get_int.side_effect = lambda key, default: {
        "prompt_budget_stable": 2000,
        "prompt_budget_dynamic": 1200,
        "prompt_budget_retrieval": 800,
        "prompt_budget_operator": 300,
    }.get(key, default)
    config = load_prompt_budget_config(settings)
    assert config.stable_prefix_tokens == 2000
    assert config.dynamic_turn_tokens == 1200
    assert config.retrieval_tokens == 800
    assert config.operator_tokens == 300


# --- Budget usage tracking tests ---


def test_budget_prompt_context_tracks_usage():
    budgeted = budget_prompt_context(
        stable_sections=[
            PromptBudgetSection("governance", "A" * 100, 40),
            PromptBudgetSection("identity", "B" * 100, 40),
        ],
        dynamic_sections=[
            PromptBudgetSection("goals", "C" * 20, 30),
        ],
        operator_sections=[],
        retrieval_text="R" * 50,
        config=PromptBudgetConfig(
            stable_prefix_tokens=200,
            dynamic_turn_tokens=100,
            retrieval_tokens=50,
            operator_tokens=50,
        ),
    )
    assert len(budgeted.usage) > 0
    names = [u.section_name for u in budgeted.usage]
    assert "governance" in names
    assert "identity" in names
    assert "goals" in names
    assert "retrieval" in names


def test_abbreviate_route_profile():
    from memex.prompt_budget import abbreviate_route

    assert abbreviate_route("analytic_strict") == "analytic"
    assert abbreviate_route("creative_open") == "creative"
    assert abbreviate_route("operational_tool") == "operational"
    assert abbreviate_route("research_verified") == "research"
    assert abbreviate_route("social_draft") == "social"
    assert abbreviate_route("guarded_review") == "guarded"
    assert abbreviate_route("analytic_strict", "minimal") == "analytic/minimal"
    assert abbreviate_route("guarded_review", "full") == "guarded"
    assert abbreviate_route("", "full") == ""


def test_prompt_budget_usage_to_dict():
    usage = PromptBudgetUsage("governance", 600, 150, False)
    d = usage.to_dict()
    assert d == {
        "name": "governance",
        "max_tokens": 600,
        "actual_tokens": 150,
        "truncated": False,
    }
