"""Tests for the URL ingestion pipeline (web_extract → intake → knowledge store)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from conftest import make_item
from memex.memory.web_extract import ExtractedContent
from memex.models import ItemType


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_SAMPLE_HTML = """\
<!DOCTYPE html>
<html>
<head>
    <title>Rust Ownership Model Explained</title>
    <meta name="author" content="Alice Chen">
    <meta name="description" content="How Rust manages memory without a garbage collector">
</head>
<body>
<article>
    <h1>Rust Ownership Model Explained</h1>
    <p>Rust's ownership system is a set of rules that the compiler checks at
    compile time. It ensures memory safety without needing a garbage collector,
    which is one of Rust's most distinctive features.</p>

    <p>Every value in Rust has a variable that is called its owner. There can
    only be one owner at a time. When the owner goes out of scope, the value
    is dropped. This simple set of rules prevents data races and dangling
    pointers at compile time.</p>

    <p>Borrowing allows references to a value without taking ownership.
    Immutable references allow multiple readers, while mutable references
    are exclusive. The borrow checker enforces these rules at compile time,
    catching bugs that would be runtime errors in other languages.</p>

    <p>Lifetimes are Rust's way of tracking how long references are valid.
    Most of the time, lifetimes are inferred by the compiler. When they
    can't be inferred, explicit lifetime annotations guide the compiler.
    This ensures that references never outlive the data they point to.</p>

    <p>Smart pointers like Box, Rc, and Arc provide additional ownership
    patterns. Box allocates on the heap with single ownership. Rc enables
    reference counting for multiple owners within a thread. Arc is the
    atomic version for cross-thread sharing.</p>
</article>
</body>
</html>
"""

_EXTRACTED = ExtractedContent(
    url="https://example.com/rust-ownership",
    title="Rust Ownership Model Explained",
    author="Alice Chen",
    date="",
    body=(
        "Rust's ownership system is a set of rules that the compiler checks at "
        "compile time. It ensures memory safety without needing a garbage collector. "
        "Every value in Rust has a variable that is called its owner. There can "
        "only be one owner at a time. Borrowing allows references to a value "
        "without taking ownership. Lifetimes track how long references are valid. "
        "Smart pointers like Box, Rc, and Arc provide additional ownership patterns."
    ),
    description="How Rust manages memory without a garbage collector",
    sitename="example.com",
    language="en",
    categories=["programming", "rust"],
    word_count=75,
    raw_length=1500,
)


# ---------------------------------------------------------------------------
# ingest_from_url unit tests
# ---------------------------------------------------------------------------


class TestIngestFromUrl:
    """Tests for intake.ingest_from_url()."""

    @patch("memex.memory.intake.ingest")
    @patch("memex.memory.web_extract.extract_from_url", return_value=_EXTRACTED)
    def test_basic(self, mock_extract, mock_ingest, memory_store):
        """URL is fetched, extracted, and ingested."""
        from memex.memory.intake import ingest_from_url

        mock_ingest.return_value = make_item(title="Rust Ownership Model Explained")

        ingest_from_url(
            "https://example.com/rust-ownership",
            content_store=memory_store.content,
        )

        mock_extract.assert_called_once_with("https://example.com/rust-ownership")
        mock_ingest.assert_called_once()
        call_kwargs = mock_ingest.call_args[1]
        assert call_kwargs["title"] == "Rust Ownership Model Explained"
        assert call_kwargs["source_url"] == "https://example.com/rust-ownership"
        assert call_kwargs["author"] == "Alice Chen"
        assert "rust" in call_kwargs["tags"]

    @patch("memex.memory.web_extract.extract_from_url")
    def test_extraction_failure_raises(self, mock_extract, memory_store):
        """ValueError raised when extraction yields no content."""
        from memex.memory.intake import ingest_from_url

        mock_extract.return_value = ExtractedContent(
            url="https://example.com/empty",
            word_count=5,
            raw_length=100,
        )

        with pytest.raises(ValueError, match="Could not extract"):
            ingest_from_url(
                "https://example.com/empty",
                content_store=memory_store.content,
            )

    @patch("memex.memory.intake.ingest")
    @patch("memex.memory.web_extract.extract_from_url", return_value=_EXTRACTED)
    def test_tags_merged(self, mock_extract, mock_ingest, memory_store):
        """User tags and extracted categories are merged."""
        from memex.memory.intake import ingest_from_url

        mock_ingest.return_value = make_item()

        ingest_from_url(
            "https://example.com/rust-ownership",
            tags=["memory-safety", "rust"],
            content_store=memory_store.content,
        )

        call_kwargs = mock_ingest.call_args[1]
        tags = call_kwargs["tags"]
        assert "memory-safety" in tags
        assert "rust" in tags
        assert "programming" in tags
        # No duplicates
        assert len(tags) == len(set(tags))

    @patch("memex.memory.web_extract.extract_from_url", return_value=_EXTRACTED)
    @patch(
        "memex.memory.intake._generate_summary",
        side_effect=AssertionError("LLM summary should be skipped"),
    )
    def test_ingest_from_url_uses_deterministic_extracted_summary_by_default(
        self,
        _mock_generate_summary,
        _mock_extract,
        memory_store,
    ):
        """URL ingest should avoid the slow LLM summary path and seed a deterministic summary."""
        from memex.memory.intake import ingest_from_url

        item = ingest_from_url(
            "https://example.com/rust-ownership",
            content_store=memory_store.content,
            memex_store=memory_store,
        )

        assert item.summary.text
        assert (
            "memory safety" in item.summary.text.lower()
            or "garbage collector" in item.summary.text.lower()
        )
        assert item.summary.model == "deterministic_extract"
        assert item.summary.input_tokens == 0


# ---------------------------------------------------------------------------
# ingest_url tool tests
# ---------------------------------------------------------------------------


class TestIngestUrlTool:
    """Tests for the ingest_url builtin tool."""

    def test_tool_definition_exists(self):
        """ingest_url is registered in BUILTIN_TOOLS."""
        from memex.tools_builtin import BUILTIN_TOOLS

        names = [t.name for t in BUILTIN_TOOLS]
        assert "ingest_url" in names

    def test_tool_requires_write_capability(self):
        """ingest_url requires builtin.write capability."""
        from memex.tools_builtin import BUILTIN_TOOLS

        tool = next(t for t in BUILTIN_TOOLS if t.name == "ingest_url")
        assert tool.required_capability == "builtin.write"

    def test_missing_url(self):
        """Error when url parameter is missing."""
        from memex.tools_builtin import execute_builtin

        result = execute_builtin("ingest_url", {})
        assert not result.success
        assert "url" in result.error.lower()

    def test_no_store_configured(self):
        """Error when stores haven't been configured."""
        from memex.tools_builtin import _STORES, execute_builtin

        # Temporarily clear stores
        saved = dict(_STORES)
        _STORES.clear()
        try:
            result = execute_builtin("ingest_url", {"url": "https://example.com"})
            assert not result.success
            assert "not configured" in result.error.lower()
        finally:
            _STORES.update(saved)

    @patch("memex.memory.intake.ingest_from_url")
    def test_successful_ingest(self, mock_ingest, memory_store):
        """Successful URL ingestion returns item info."""
        from memex.tools_builtin import _STORES, execute_builtin

        mock_ingest.return_value = make_item(
            title="Test Article",
            body="Some article content with enough words",
        )

        _STORES["content"] = memory_store.content
        _STORES["goal"] = memory_store
        try:
            result = execute_builtin(
                "ingest_url",
                {"url": "https://example.com/article"},
            )
            assert result.success
            assert "Test Article" in result.content
            assert "ID: content_item:" in result.content
        finally:
            _STORES.pop("content", None)
            _STORES.pop("goal", None)


# ---------------------------------------------------------------------------
# web_fetch tool tests (upgraded to use trafilatura)
# ---------------------------------------------------------------------------


class TestWebFetchUpgraded:
    """Tests for the upgraded web_fetch tool."""

    @patch("memex.memory.web_extract.extract_from_url")
    def test_returns_clean_text(self, mock_extract):
        """web_fetch now returns extracted text, not raw HTML."""
        from memex.tools_builtin import execute_builtin

        mock_extract.return_value = _EXTRACTED

        result = execute_builtin("web_fetch", {"url": "https://example.com/article"})

        assert result.success
        assert "Title: Rust Ownership Model Explained" in result.content
        assert "Author: Alice Chen" in result.content
        assert "ownership" in result.content
        # Should NOT contain raw HTML
        assert "<html>" not in result.content
        assert "<article>" not in result.content

    @patch("memex.memory.web_extract.extract_from_url")
    def test_extraction_failure(self, mock_extract):
        """web_fetch reports error when extraction fails."""
        from memex.tools_builtin import execute_builtin

        mock_extract.return_value = ExtractedContent(url="https://example.com", body="")

        result = execute_builtin("web_fetch", {"url": "https://example.com"})

        assert not result.success

    def test_missing_url(self):
        """web_fetch errors on missing url."""
        from memex.tools_builtin import execute_builtin

        result = execute_builtin("web_fetch", {})
        assert not result.success


# ---------------------------------------------------------------------------
# E2E: HTML → extract → ingest → store → retrieve
# ---------------------------------------------------------------------------


class TestE2EUrlIngestion:
    """End-to-end test: real HTML → trafilatura → ingest → content store."""

    def test_html_to_knowledge_store(self, memory_store):
        """Full pipeline: extract from real HTML, ingest, verify in store."""
        from memex.memory.intake import ingest
        from memex.memory.web_extract import extract_from_html

        # Step 1: Extract from real HTML
        extracted = extract_from_html(
            _SAMPLE_HTML, url="https://example.com/rust-ownership"
        )
        assert extracted.is_substantial
        assert "ownership" in extracted.body.lower()

        # Step 2: Ingest into knowledge store
        cs = memory_store.content
        item = ingest(
            extracted.body,
            type=ItemType.ARTICLE,
            title=extracted.title or "Untitled",
            source_url="https://example.com/rust-ownership",
            author=extracted.author or "",
            tags=extracted.categories,
            content_store=cs,
            generate_summary=False,
        )

        # Step 3: Verify item in store
        got = cs.get_item(item.item_id)
        assert got is not None
        assert "Rust" in got.title
        assert got.source_url == "https://example.com/rust-ownership"
        assert got.type == ItemType.ARTICLE
        assert "ownership" in got.body.lower()

        # Step 4: Verify findable by URL (re-ingest detection)
        found = cs.find_by_url("https://example.com/rust-ownership")
        assert found is not None
        assert found.item_id == item.item_id

        # Step 5: Verify source was created
        if got.source_id:
            source = cs.get_source(got.source_id)
            assert source is not None
            assert "example.com" in source.domain

    def test_ingest_from_url_e2e(self, memory_store):
        """ingest_from_url with mocked HTTP, real extraction and storage."""

        from memex.memory.intake import ingest_from_url

        # Mock only the HTTP fetch — extraction and storage are real
        from memex.connectors.web_fetcher import FetchResult

        mock_result = FetchResult(
            url="https://example.com/rust-ownership",
            status_code=200,
            text=_SAMPLE_HTML,
            ok=True,
        )
        mock_strategy = MagicMock()
        mock_strategy.fetch.return_value = mock_result

        with patch(
            "memex.connectors.web_fetcher.get_strategy", return_value=mock_strategy
        ):
            item = ingest_from_url(
                "https://example.com/rust-ownership",
                tags=["systems-programming"],
                content_store=memory_store.content,
                generate_summary=False,
            )

        assert item is not None
        assert "Rust" in item.title
        assert "ownership" in item.body.lower()

        # Verify it's in the store
        got = memory_store.content.get_item(item.item_id)
        assert got is not None
        assert got.source_url == "https://example.com/rust-ownership"

    def test_reingest_url_bumps_version(self, memory_store):
        """Ingesting the same URL twice creates a version snapshot."""
        import uuid

        from memex.memory.intake import ingest
        from memex.memory.web_extract import extract_from_html

        cs = memory_store.content
        # Use a unique URL to avoid collisions with other tests
        unique_url = f"https://example.com/reingest-{uuid.uuid4().hex[:8]}"
        extracted = extract_from_html(_SAMPLE_HTML, url=unique_url)

        # First ingest
        item1 = ingest(
            extracted.body,
            title=extracted.title,
            source_url=unique_url,
            content_store=cs,
            generate_summary=False,
        )
        assert item1.version == 1

        # Second ingest (same URL, updated content)
        item2 = ingest(
            extracted.body + "\n\nUpdated with new section.",
            title=extracted.title,
            source_url=unique_url,
            content_store=cs,
            generate_summary=False,
        )
        assert item2.item_id == item1.item_id
        assert item2.version == 2

        # Version snapshot exists
        versions = cs.get_versions(item1.item_id)
        assert len(versions) >= 1


# ---------------------------------------------------------------------------
# MCP tool test
# ---------------------------------------------------------------------------


class TestMcpIngestUrl:
    """Tests for the memex_ingest_url MCP tool."""

    def test_tool_registered(self):
        """memex_ingest_url is in the full tool set."""
        from memex.interfaces.mcp_server import _FULL_TOOLS

        assert "memex_ingest_url" in _FULL_TOOLS


# ---------------------------------------------------------------------------
# YouTube URL routing
# ---------------------------------------------------------------------------


class TestYouTubeUrlRouting:
    """Tests for YouTube URL detection and routing in ingest_from_url."""

    @patch("memex.memory.intake.ingest")
    @patch("memex.memory.youtube_extract.extract_from_youtube")
    def test_youtube_url_routes_to_youtube_extractor(
        self, mock_yt_extract, mock_ingest, memory_store
    ):
        """YouTube URLs call extract_from_youtube, not extract_from_url."""
        from memex.memory.intake import ingest_from_url

        mock_yt_extract.return_value = ExtractedContent(
            url="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            title="Test Video",
            body="This is a transcript with more than fifty words " * 5,
            word_count=100,
            raw_length=500,
            sitename="YouTube",
            categories=["youtube", "video"],
        )
        mock_ingest.return_value = make_item(title="Test Video")

        ingest_from_url(
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            content_store=memory_store.content,
        )

        mock_yt_extract.assert_called_once_with(
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        )

    @patch("memex.memory.intake.ingest")
    @patch("memex.memory.web_extract.extract_from_url", return_value=_EXTRACTED)
    def test_non_youtube_url_uses_existing_path(
        self, mock_extract, mock_ingest, memory_store
    ):
        """Non-YouTube URLs still go through extract_from_url."""
        from memex.memory.intake import ingest_from_url

        mock_ingest.return_value = make_item()

        ingest_from_url(
            "https://example.com/article",
            content_store=memory_store.content,
        )

        mock_extract.assert_called_once_with("https://example.com/article")

    @patch("memex.memory.youtube_extract.extract_from_youtube")
    def test_youtube_insufficient_content_raises(self, mock_yt_extract, memory_store):
        """ValueError raised when YouTube extraction yields no content."""
        from memex.memory.intake import ingest_from_url

        mock_yt_extract.return_value = ExtractedContent(
            url="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            word_count=5,
            raw_length=20,
        )

        with pytest.raises(ValueError, match="Could not extract"):
            ingest_from_url(
                "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                content_store=memory_store.content,
            )
