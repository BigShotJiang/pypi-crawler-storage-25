"""Tests for relevance scoring — pure math, no LLM."""

from datetime import timedelta

from memex.models import GoalPriority
from memex.relevance import (
    filter_goals,
    priority_score,
    recency_score,
    relation_score,
    score_goal,
)
from conftest import make_goal
from memex.utcnow import utcnow


def test_recency_score_now():
    now = utcnow()
    assert recency_score(now, now) == 1.0


def test_recency_score_decays():
    now = utcnow()
    week_ago = now - timedelta(days=7)
    score = recency_score(week_ago, now)
    assert 0.49 < score < 0.51  # half-life = 7 days


def test_recency_score_old():
    now = utcnow()
    month_ago = now - timedelta(days=28)
    score = recency_score(month_ago, now)
    assert score < 0.1


def test_priority_scores():
    assert priority_score(GoalPriority.CRITICAL) == 1.0
    assert priority_score(GoalPriority.HIGH) == 0.75
    assert priority_score(GoalPriority.MEDIUM) == 0.5
    assert priority_score(GoalPriority.LOW) == 0.25


def test_relation_score_direct():
    g = make_goal(title="Test")
    assert relation_score(g, referenced_goal_id=g.goal_id) == 1.0


def test_relation_score_child():
    parent = make_goal(title="Parent")
    child = make_goal(title="Child", parent_id=parent.goal_id)
    assert relation_score(child, referenced_goal_id=parent.goal_id) == 0.5


def test_relation_score_parent():
    parent = make_goal(title="Parent")
    child = make_goal(title="Child", parent_id=parent.goal_id)
    assert (
        relation_score(
            parent,
            referenced_goal_id=child.goal_id,
            referenced_parent_id=parent.goal_id,
        )
        == 0.5
    )


def test_relation_score_sibling():
    parent = make_goal(title="Parent")
    child1 = make_goal(title="Child1", parent_id=parent.goal_id)
    child2 = make_goal(title="Child2", parent_id=parent.goal_id)
    assert (
        relation_score(
            child2,
            referenced_goal_id=child1.goal_id,
            sibling_ids={child2.goal_id},
        )
        == 0.2
    )


def test_relation_score_unrelated():
    g = make_goal(title="Unrelated")
    assert relation_score(g) == 0.0


def test_filter_goals_caps():
    now = utcnow()
    goals = [make_goal(title=f"Goal {i}") for i in range(20)]
    result = filter_goals(goals, now, max_goals=10)
    assert len(result) <= 10


def test_filter_goals_includes_referenced():
    now = utcnow()
    goals = [make_goal(title=f"Goal {i}", days_ago=i * 5) for i in range(15)]
    # Reference the oldest (least relevant by recency)
    ref_id = goals[-1].goal_id
    result = filter_goals(goals, now, referenced_goal_id=ref_id, max_goals=5)
    result_ids = {g.goal_id for g in result}
    assert ref_id in result_ids


def test_filter_goals_empty():
    assert filter_goals([], utcnow()) == []


def test_score_goal_composite():
    now = utcnow()
    g = make_goal(title="Test", priority=GoalPriority.CRITICAL, days_ago=0)
    score = score_goal(g, now, referenced_goal_id=g.goal_id)
    # recency=1.0*0.4 + priority=1.0*0.3 + relation=1.0*0.3 = 1.0
    assert 0.99 < score <= 1.0
