"""Tests for proactive context surfacing (Phase 2)."""

from __future__ import annotations

from unittest.mock import MagicMock


from conftest import make_item
from memex.memory.extraction_gate import ExtractionSignals
from memex.memory.proactive import surface_proactive_context


def _make_signals(entities=None, signals=None):
    return ExtractionSignals(
        should_extract=True,
        signals=signals or set(),
        entities=entities or [],
    )


class TestSurfaceProactiveContext:
    def test_no_entities_returns_empty(self):
        """No entities → returns empty string."""
        store = MagicMock()
        result = surface_proactive_context(
            "hello", _make_signals(entities=[]), [], store, set()
        )
        assert result == ""

    def test_entity_found_via_find_by_entity(self):
        """Entity found → items appear in output."""
        item = make_item(title="Auth Service Docs", body="Documentation for auth")
        store = MagicMock()
        store.find_by_entity.return_value = [item]

        result = surface_proactive_context(
            "Sarah owns the auth service",
            _make_signals(entities=[("Sarah", "person")]),
            [],
            store,
            set(),
        )
        assert "## Related Context" in result
        assert "Auth Service Docs" in result

    def test_dedup_against_already_retrieved_content_item_document_id(self):
        """Explicit content-item document IDs are excluded."""
        item = make_item(title="Already Retrieved")
        store = MagicMock()
        store.find_by_entity.return_value = [item]

        result = surface_proactive_context(
            "Sarah owns the auth service",
            _make_signals(entities=[("Sarah", "person")]),
            [],
            store,
            {f"content_item:{item.item_id}"},
        )
        assert result == ""

    def test_dedup_against_already_retrieved_canonical_document_id(self):
        """Canonical retrieval document IDs should also dedup proactive items."""
        item = make_item(title="Already Retrieved")
        store = MagicMock()
        store.find_by_entity.return_value = [item]

        result = surface_proactive_context(
            "Sarah owns the auth service",
            _make_signals(entities=[("Sarah", "person")]),
            [],
            store,
            {f"world_model_knowledge:knowledge/{item.item_id}"},
        )
        assert result == ""

    def test_caps_at_5_items(self):
        """Should not return more than 5 items."""
        items = [make_item(title=f"Item {i}") for i in range(10)]
        store = MagicMock()
        store.find_by_entity.return_value = items

        result = surface_proactive_context(
            "test input",
            _make_signals(entities=[("Test", "concept")]),
            [],
            store,
            set(),
        )
        # Count bullet points
        assert result.count("- **") <= 5

    def test_store_lacks_find_by_entity(self):
        """Store without find_by_entity → returns empty string gracefully."""
        store = MagicMock(spec=[])  # no find_by_entity attribute

        result = surface_proactive_context(
            "Sarah owns the auth service",
            _make_signals(entities=[("Sarah", "person")]),
            [],
            store,
            set(),
        )
        assert result == ""

    def test_output_starts_with_related_context(self):
        """Output format starts with '## Related Context'."""
        item = make_item(title="Test Item", body="Some content")
        store = MagicMock()
        store.find_by_entity.return_value = [item]

        result = surface_proactive_context(
            "test",
            _make_signals(entities=[("Test", "concept")]),
            [],
            store,
            set(),
        )
        assert result.startswith("## Related Context")

    def test_neighborhood_expansion(self):
        """Items from graph neighborhood are included."""
        entity_item = make_item(title="Entity Match")
        neighbor_item = make_item(title="Neighbor Item")
        store = MagicMock()
        store.find_by_entity.return_value = [entity_item]
        store.neighborhood.return_value = [neighbor_item]

        result = surface_proactive_context(
            "test",
            _make_signals(entities=[("Test", "concept")]),
            [],
            store,
            set(),
        )
        assert "Entity Match" in result
        assert "Neighbor Item" in result
