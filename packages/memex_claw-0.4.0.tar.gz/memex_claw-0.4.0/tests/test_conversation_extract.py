"""Tests for conversational knowledge extraction (Phase 3 + Phase 4)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch


from memex.memory.conversation_extract import (
    CombinedExtractReflectResult,
    ExtractionResult,
    ExtractedCorrection,
    ExtractedDecision,
    ExtractedEntity,
    ExtractedFact,
    apply_extraction,
    extract_and_reflect,
    update_partner_profile_from_extraction,
)
from memex.memory.intake import ingest
from memex.models import (
    HumanPartnerProfile,
    InputClassification,
    InputClassificationType,
    ItemType,
    ReflectResult,
    SessionContext,
)
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_classification(
    ctype=InputClassificationType.CONVERSATIONAL,
) -> InputClassification:
    return InputClassification(classification=ctype, confidence=0.9)


def _make_session() -> SessionContext:
    return SessionContext(
        session_id="test-session-123",
        started_at=utcnow(),
        turn_count=5,
    )


# ---------------------------------------------------------------------------
# TestExtractionModels
# ---------------------------------------------------------------------------


class TestExtractionModels:
    def test_extraction_result_defaults(self):
        r = ExtractionResult()
        assert r.facts == []
        assert r.entities == []
        assert r.relationships == []
        assert r.decisions == []
        assert r.urls == []
        assert r.corrections == []

    def test_combined_result_has_both_fields(self):
        r = CombinedExtractReflectResult()
        # Extraction fields
        assert r.facts == []
        assert r.entities == []
        # Reflection fields
        assert r.intent_advanced == []
        assert r.confidence == 0.0

    def test_to_reflect_result(self):
        r = CombinedExtractReflectResult(
            intent_advanced=["goal-1"],
            reflection_note="test note",
            confidence=0.8,
        )
        reflect = r.to_reflect_result()
        assert isinstance(reflect, ReflectResult)
        assert reflect.intent_advanced == ["goal-1"]
        assert reflect.reflection_note == "test note"
        assert reflect.confidence == 0.8

    def test_to_extraction_result(self):
        r = CombinedExtractReflectResult(
            facts=[ExtractedFact(statement="test", confidence=0.9)],
            urls=["https://example.com"],
        )
        extraction = r.to_extraction_result()
        assert isinstance(extraction, ExtractionResult)
        assert len(extraction.facts) == 1
        assert extraction.urls == ["https://example.com"]


# ---------------------------------------------------------------------------
# TestExtractAndReflect
# ---------------------------------------------------------------------------


class TestExtractAndReflect:
    @patch("memex.llm.chat_structured")
    def test_returns_combined_result(self, mock_chat):
        """chat_structured returns CombinedExtractReflectResult with both parts."""
        mock_chat.return_value = CombinedExtractReflectResult(
            facts=[ExtractedFact(statement="deadline is March 20", confidence=0.9)],
            intent_advanced=["goal-1"],
            reflection_note="noted deadline",
        )

        result = extract_and_reflect(
            classification=_make_classification(),
            assistant_response="OK, noted.",
            relevant_goals=[],
            session=_make_session(),
            signals={"factual_assertion"},
            entities=[("March", "date")],
        )

        assert len(result.facts) == 1
        assert result.intent_advanced == ["goal-1"]
        assert result.to_reflect_result().intent_advanced == ["goal-1"]
        assert (
            result.to_extraction_result().facts[0].statement == "deadline is March 20"
        )

    @patch("memex.llm.chat_structured")
    def test_failure_returns_noop(self, mock_chat):
        """chat_structured raises → returns no-op."""
        mock_chat.side_effect = RuntimeError("LLM failed")

        result = extract_and_reflect(
            classification=_make_classification(),
            assistant_response="response",
            relevant_goals=[],
            session=_make_session(),
        )

        assert result.facts == []
        assert result.reflection_note == "extraction+reflection failed — no-op"

    @patch("memex.llm.chat_structured")
    def test_signals_included_in_context(self, mock_chat):
        """Gate signals are included in the user message."""
        mock_chat.return_value = CombinedExtractReflectResult()

        extract_and_reflect(
            classification=_make_classification(),
            assistant_response="response",
            relevant_goals=[],
            session=_make_session(),
            signals={"factual_assertion", "url_mentioned"},
            entities=[("Sarah", "person")],
        )

        call_args = mock_chat.call_args
        messages = call_args[0][0]
        user_msg = messages[1]["content"]
        assert "factual_assertion" in user_msg
        assert "Sarah (person)" in user_msg


# ---------------------------------------------------------------------------
# TestApplyExtraction
# ---------------------------------------------------------------------------


class TestApplyExtraction:
    def test_fact_high_confidence_ingested(self):
        """Fact with confidence >= 0.7 → ingest() called."""
        result = ExtractionResult(
            facts=[ExtractedFact(statement="The API uses OAuth2", confidence=0.9)],
        )
        store = MagicMock()
        store.find_by_url.return_value = None

        with patch("memex.memory.intake.ingest") as mock_ingest:
            apply_extraction(result, store, _make_session())
            mock_ingest.assert_called_once()
            call_kwargs = mock_ingest.call_args.kwargs
            assert call_kwargs["tags"] == ["conversational", "fact"]
            assert "conversation://" in call_kwargs["source_url"]

    def test_fact_low_confidence_skipped(self):
        """Fact with confidence < 0.7 → skipped."""
        result = ExtractionResult(
            facts=[ExtractedFact(statement="Maybe it uses REST", confidence=0.3)],
        )
        store = MagicMock()

        with patch("memex.memory.intake.ingest") as mock_ingest:
            apply_extraction(result, store, _make_session())
            mock_ingest.assert_not_called()

    def test_fact_dedup_by_url(self):
        """Fact dedup: find_by_url returns existing → no duplicate."""
        result = ExtractionResult(
            facts=[ExtractedFact(statement="test fact", confidence=0.9)],
        )
        store = MagicMock()
        store.find_by_url.return_value = MagicMock()  # existing item

        with patch("memex.memory.intake.ingest") as mock_ingest:
            apply_extraction(result, store, _make_session())
            mock_ingest.assert_not_called()

    def test_entity_resolved(self):
        """Entity → resolve_entity() called (when store has find_entity)."""
        result = ExtractionResult(
            entities=[ExtractedEntity(name="Python", type="technology")],
        )
        store = MagicMock()
        store.find_entity = MagicMock(return_value="entity-1")

        with patch("memex.memory.ner.resolve_entity") as mock_resolve:
            mock_resolve.return_value = "entity-1"
            apply_extraction(result, store, _make_session())
            mock_resolve.assert_called_once_with("Python", "technology", store)

    def test_entity_skipped_without_find_entity(self):
        """Entity skipped when store lacks find_entity."""
        result = ExtractionResult(
            entities=[ExtractedEntity(name="Python", type="technology")],
        )
        store = MagicMock(spec=[])  # no find_entity

        with patch("memex.memory.ner.resolve_entity") as mock_resolve:
            apply_extraction(result, store, _make_session())
            mock_resolve.assert_not_called()

    def test_decision_ingested(self):
        """Decision → ingest() with decision tags."""
        result = ExtractionResult(
            decisions=[
                ExtractedDecision(
                    decision="Use Postgres for the database",
                    rationale="Better for complex queries",
                    rejected=["MySQL", "MongoDB"],
                )
            ],
        )
        store = MagicMock()
        store.find_by_url.return_value = None

        with patch("memex.memory.intake.ingest") as mock_ingest:
            apply_extraction(result, store, _make_session())
            mock_ingest.assert_called_once()
            call_kwargs = mock_ingest.call_args.kwargs
            assert "decision" in call_kwargs["tags"]
            typed = call_kwargs["metadata"]["typed_knowledge"]
            assert typed["knowledge_type"] == "claim"
            assert typed["claim_kind"] == "decision"
            assert typed["statement"] == "Use Postgres for the database"
            assert typed["rationale"] == "Better for complex queries"
            assert typed["rejected"] == ["MySQL", "MongoDB"]

    def test_url_ingested(self):
        """URL → ingest_from_url() called."""
        result = ExtractionResult(urls=["https://example.com/docs"])
        store = MagicMock()

        with patch("memex.memory.intake.ingest_from_url") as mock_ingest:
            apply_extraction(result, store, _make_session())
            mock_ingest.assert_called_once()
            assert mock_ingest.call_args.args[0] == "https://example.com/docs"

    def test_correction_applied(self):
        """Correction → fts_search finds match → version snapshot + update."""
        result = ExtractionResult(
            corrections=[
                ExtractedCorrection(
                    original="deadline is March 15",
                    corrected="deadline is March 25",
                )
            ],
        )
        mock_item = MagicMock()
        mock_item.body = "The deadline is March 15 for the project"
        store = MagicMock()
        store.fts_search.return_value = [(mock_item, 1.0)]

        apply_extraction(result, store, _make_session())

        store.create_version_snapshot.assert_called_once_with(mock_item)
        store.update_item.assert_called_once_with(mock_item)
        assert "March 25" in mock_item.body

    def test_correction_applied_records_correction_metadata(self):
        """Correction updates item metadata so the typed sidecar can surface it."""
        result = ExtractionResult(
            corrections=[
                ExtractedCorrection(
                    original="deadline is March 15",
                    corrected="deadline is March 25",
                    context="Planning review",
                )
            ],
        )
        mock_item = MagicMock()
        mock_item.body = "The deadline is March 15 for the project"
        mock_item.metadata = {}
        mock_item.tags = []
        store = MagicMock()
        store.fts_search.return_value = [(mock_item, 1.0)]

        apply_extraction(result, store, _make_session())

        correction = mock_item.metadata["corrections"][0]
        assert correction["original"] == "deadline is March 15"
        assert correction["corrected"] == "deadline is March 25"
        assert correction["context"] == "Planning review"
        assert correction["session_id"] == "test-session-123"
        assert correction["turn"] == 5
        assert "corrected" in mock_item.tags

    def test_correction_no_match_skipped(self):
        """Correction with no FTS match → silently skipped."""
        result = ExtractionResult(
            corrections=[
                ExtractedCorrection(
                    original="nonexistent text",
                    corrected="new text",
                )
            ],
        )
        store = MagicMock()
        store.fts_search.return_value = []

        apply_extraction(result, store, _make_session())
        store.create_version_snapshot.assert_not_called()

    def test_correction_tracks_typed_history_and_resyncs_projection(self, memory_store):
        """Corrections should leave typed correction history on the updated item."""
        content_store = memory_store.content
        item = ingest(
            "The deadline is March 15 for the project.",
            type=ItemType.NOTE,
            title="Deadline note",
            content_store=content_store,
            generate_summary=False,
            memex_store=memory_store,
        )
        result = ExtractionResult(
            corrections=[
                ExtractedCorrection(
                    original="March 15",
                    corrected="March 25",
                    context="deadline correction",
                )
            ],
        )

        apply_extraction(
            result,
            content_store,
            _make_session(),
            memex_store=memory_store,
        )

        updated = content_store.get_item(item.item_id)
        assert updated is not None
        typed = updated.metadata.get("typed_knowledge") or {}
        corrections = typed.get("corrections") or []
        assert corrections
        assert corrections[0]["original"] == "March 15"
        assert corrections[0]["corrected"] == "March 25"

        knowledge = memory_store.load_world_model_knowledge_object_by_item_id(
            item.item_id
        )
        assert knowledge is not None
        assert knowledge.payload["typed"]["corrections"][0]["corrected"] == "March 25"


# ---------------------------------------------------------------------------
# TestPersonModelUpdate (Phase 4)
# ---------------------------------------------------------------------------


class TestPersonModelUpdate:
    @patch("memex.human_model.save_partner_profile")
    @patch("memex.human_model.load_canonical_partner_profile")
    def test_role_extracted(self, mock_load, mock_save):
        """First-person role statement → canonical partner role updated."""
        mock_load.return_value = HumanPartnerProfile()
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="I'm the tech lead on this project",
                    confidence=0.9,
                    source="user",
                )
            ],
        )
        store = MagicMock()
        update_partner_profile_from_extraction(extraction, store)

        mock_save.assert_called_once()
        saved_profile = mock_save.call_args.args[0]
        assert "tech lead" in saved_profile.working_context.role

    @patch("memex.human_model.save_partner_profile")
    @patch("memex.human_model.load_canonical_partner_profile")
    def test_team_extracted(self, mock_load, mock_save):
        """Team reference → canonical partner team updated."""
        mock_load.return_value = HumanPartnerProfile()
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="Our platform team handles all authentication",
                    confidence=0.9,
                    source="user",
                )
            ],
        )
        store = MagicMock()
        update_partner_profile_from_extraction(extraction, store)

        mock_save.assert_called_once()
        saved_profile = mock_save.call_args.args[0]
        assert "platform" in saved_profile.working_context.team

    @patch("memex.human_model.save_partner_profile")
    @patch("memex.human_model.load_canonical_partner_profile")
    def test_expertise_extracted(self, mock_load, mock_save):
        """Expertise statement → canonical partner expertise updated."""
        mock_load.return_value = HumanPartnerProfile()
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="I've been writing Go for 10 years",
                    confidence=0.9,
                    source="user",
                )
            ],
        )
        store = MagicMock()
        update_partner_profile_from_extraction(extraction, store)

        mock_save.assert_called_once()
        saved_profile = mock_save.call_args.args[0]
        assert any("Go" in e for e in saved_profile.knowledge_profile.expertise)

    @patch("memex.human_model.save_partner_profile")
    @patch("memex.human_model.load_canonical_partner_profile")
    def test_third_party_fact_skipped(self, mock_load, mock_save):
        """Fact about someone else → no canonical partner update."""
        mock_load.return_value = HumanPartnerProfile()
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="Sarah manages the auth service",
                    confidence=0.9,
                    source="assistant",
                )
            ],
        )
        store = MagicMock()
        update_partner_profile_from_extraction(extraction, store)

        mock_save.assert_not_called()

    @patch("memex.human_model.save_partner_profile")
    @patch("memex.human_model.load_canonical_partner_profile")
    def test_existing_expertise_not_duplicated(self, mock_load, mock_save):
        """Existing expertise not duplicated."""
        mock_load.return_value = HumanPartnerProfile(
            knowledge_profile={"expertise": ["Go"]},
        )
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="I've been writing Go for many years",
                    confidence=0.9,
                    source="user",
                )
            ],
        )
        store = MagicMock()
        update_partner_profile_from_extraction(extraction, store)

        # No save because Go already in expertise
        mock_save.assert_not_called()

    def test_none_store_returns_silently(self):
        """None store → returns without error."""
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="I'm an engineer", confidence=0.9, source="user"
                )
            ],
        )
        update_partner_profile_from_extraction(extraction, None)

    def test_store_backed_update_writes_canonical_partner_profile(self, memory_store):
        extraction = ExtractionResult(
            facts=[
                ExtractedFact(
                    statement="I'm the tech lead on this project",
                    confidence=0.9,
                    source="user",
                ),
                ExtractedFact(
                    statement="Our platform team handles all authentication",
                    confidence=0.9,
                    source="user",
                ),
                ExtractedFact(
                    statement="I've been writing Go for 10 years",
                    confidence=0.9,
                    source="user",
                ),
            ],
        )

        update_partner_profile_from_extraction(extraction, memory_store)

        profile = memory_store.load_partner_profile()
        assert profile is not None
        assert "tech lead" in profile.working_context.role
        assert "platform" in profile.working_context.team
        assert any("Go" in entry for entry in profile.knowledge_profile.expertise)


def test_partner_profile_defaults():
    profile = HumanPartnerProfile()
    assert profile.working_context.role == ""
    assert profile.working_context.team == ""
    assert profile.knowledge_profile.expertise == []


def test_partner_profile_round_trip():
    profile = HumanPartnerProfile(
        name="Alice",
        communication_style="concise",
        working_context={"role": "engineer", "team": "platform"},
        knowledge_profile={"expertise": ["Python", "Go"]},
    )
    restored = HumanPartnerProfile.model_validate(profile.model_dump())
    assert restored.name == "Alice"
    assert restored.working_context.role == "engineer"
    assert restored.working_context.team == "platform"
    assert restored.knowledge_profile.expertise == ["Python", "Go"]
