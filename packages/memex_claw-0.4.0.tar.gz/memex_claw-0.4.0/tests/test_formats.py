"""Tests for ResponseFormat, SessionMode, and interface presets."""

from memex.interfaces.formats import (
    INTERFACE_FORMATS,
    ResponseFormat,
    SessionMode,
    get_mode_description,
    get_mode_prompt,
)


def test_response_format_no_constraints():
    fmt = ResponseFormat()
    assert fmt.as_prompt_section() == ""


def test_response_format_terse():
    fmt = ResponseFormat(verbosity="terse", max_length=500)
    section = fmt.as_prompt_section()
    assert "500 characters" in section
    assert "concise" in section.lower()


def test_response_format_verbose():
    fmt = ResponseFormat(verbosity="verbose")
    section = fmt.as_prompt_section()
    assert "thorough" in section.lower()


def test_response_format_no_markdown():
    fmt = ResponseFormat(markdown=False)
    section = fmt.as_prompt_section()
    assert "plain text" in section.lower()


def test_response_format_paragraph_hint():
    fmt = ResponseFormat(paragraph_hint="Keep it short.")
    section = fmt.as_prompt_section()
    assert "Keep it short." in section


def test_interface_formats_keys():
    assert "cli" in INTERFACE_FORMATS
    assert "telegram" in INTERFACE_FORMATS
    assert "tui" in INTERFACE_FORMATS
    assert "mcp" in INTERFACE_FORMATS


def test_telegram_format_no_truncation():
    fmt = INTERFACE_FORMATS["telegram"]
    assert fmt.verbosity == "normal"
    assert (
        fmt.max_length == 0
    )  # no LLM-side length limit; splitting handles Telegram API limit
    assert fmt.markdown is False


def test_session_modes():
    assert SessionMode.NORMAL == "normal"
    assert SessionMode.DEEP_WORK == "deep_work"
    assert SessionMode.REVIEW == "review"
    assert SessionMode.QUICK_CHECK == "quick_check"


def test_get_mode_description():
    desc = get_mode_description(SessionMode.DEEP_WORK)
    assert "focus" in desc.lower()


def test_get_mode_prompt():
    prompt = get_mode_prompt(SessionMode.REVIEW)
    assert "Review" in prompt
    assert "approvals" in prompt.lower()


def test_get_mode_prompt_normal_has_content():
    prompt = get_mode_prompt(SessionMode.NORMAL)
    assert "normal" in prompt.lower() or "Standard" in prompt
