"""Tests for the Memex-specific PhaseGraph topology validator."""

from __future__ import annotations

import pytest

from memex.phase_graph.graph import (
    FallbackEdge,
    JoinBarrier,
    PhaseEdge,
    PhaseGraph,
    PhaseNode,
)
from memex.phase_graph.retry import RetryPolicy
from memex.phase_graph.smp_validator import (
    REQUIRED_EDGES,
    REQUIRED_FALLBACKS,
    REQUIRED_NODES,
    SMPValidationError,
    validate_memex_turn_graph,
)


def _noop(ctx):
    pass


def _build_spec_nodes(
    *, exclude: set[str] | None = None, overrides: dict[str, PhaseNode] | None = None
) -> tuple[PhaseNode, ...]:
    """Build all required nodes with correct retry policies."""
    exclude = exclude or set()
    overrides = overrides or {}

    llm_retry = RetryPolicy(
        max_attempts=3,
        backoff_base=2.0,
        retryable=lambda e: isinstance(e, ConnectionError),
    )
    classify_retry = RetryPolicy(
        max_attempts=2,
        retryable=lambda e: isinstance(e, Exception),
    )
    save_retry = RetryPolicy(
        max_attempts=3,
        backoff_base=1.0,
        retryable=lambda e: isinstance(e, OSError),
    )

    nodes = []
    for name in sorted(REQUIRED_NODES):
        if name in exclude:
            continue
        if name in overrides:
            nodes.append(overrides[name])
            continue
        retry = RetryPolicy()
        if name == "LLM_RESPOND":
            retry = llm_retry
        elif name == "CLASSIFY":
            retry = classify_retry
        elif name == "SAVE_SESSION":
            retry = save_retry
        nodes.append(
            PhaseNode(
                name=name,
                execute=_noop,
                inputs=frozenset(),
                outputs=frozenset(),
                retry=retry,
                emit_event=False,
            )
        )
    return tuple(nodes)


def _build_spec_edges(
    *, exclude: set[tuple[str, str]] | None = None
) -> tuple[PhaseEdge, ...]:
    """Build all required edges."""
    exclude = exclude or set()
    return tuple(
        PhaseEdge(source=s, target=t)
        for s, t in REQUIRED_EDGES
        if (s, t) not in exclude
    )


def _build_spec_fallbacks(
    *, exclude: set[tuple[str, str]] | None = None
) -> tuple[FallbackEdge, ...]:
    """Build all required fallback edges."""
    exclude = exclude or set()
    return tuple(
        FallbackEdge(source=s, target=t)
        for s, t in REQUIRED_FALLBACKS
        if (s, t) not in exclude
    )


def _build_spec_barriers(
    *, overrides: dict[str, JoinBarrier] | None = None
) -> tuple[JoinBarrier, ...]:
    overrides = overrides or {}
    default = (
        JoinBarrier(
            name="_GATHER_JOIN",
            incoming=frozenset(
                {"SELECT_TOOLS", "PROACTIVE_CONTEXT", "SKIP_RETRIEVE", "FACT_STORE"}
            ),
        ),
        JoinBarrier(
            name="_POST_JOIN",
            incoming=frozenset({"APPLY_EXTRACTION", "APPLY_REFLECT"}),
        ),
    )
    return tuple(overrides.get(jb.name, jb) for jb in default)


def _build_spec_graph(**kwargs) -> PhaseGraph:
    """Build a PhaseGraph that conforms to the Memex spec.

    Bypasses PhaseGraph validation since nodes have no real I/O declarations.
    """
    nodes = kwargs.get("nodes", _build_spec_nodes())
    edges = kwargs.get("edges", _build_spec_edges())
    fallbacks = kwargs.get("fallback_edges", _build_spec_fallbacks())
    barriers = kwargs.get("join_barriers", _build_spec_barriers())

    # Build without validation (our test nodes have empty inputs/outputs)
    graph = object.__new__(PhaseGraph)
    object.__setattr__(graph, "nodes", nodes)
    object.__setattr__(graph, "edges", edges)
    object.__setattr__(graph, "fallback_edges", fallbacks)
    object.__setattr__(graph, "join_barriers", barriers)
    object.__setattr__(graph, "entry_node", "LOAD_CONTEXT")
    object.__setattr__(graph, "exclusive_output_pairs", frozenset())
    return graph


class TestSpecCompliantGraph:
    def test_valid_graph_passes(self):
        g = _build_spec_graph()
        warnings = validate_memex_turn_graph(g)
        assert isinstance(warnings, list)

    def test_extra_node_produces_warning(self):
        extra = PhaseNode(
            name="MY_CUSTOM_NODE",
            execute=_noop,
            inputs=frozenset(),
            outputs=frozenset(),
            emit_event=False,
        )
        nodes = _build_spec_nodes() + (extra,)
        g = _build_spec_graph(nodes=nodes)
        warnings = validate_memex_turn_graph(g)
        assert any("MY_CUSTOM_NODE" in w for w in warnings)


class TestMissingNode:
    def test_missing_required_node_raises(self):
        nodes = _build_spec_nodes(exclude={"CLASSIFY"})
        g = _build_spec_graph(nodes=nodes)
        with pytest.raises(SMPValidationError, match="missing required node: CLASSIFY"):
            validate_memex_turn_graph(g)

    def test_missing_fallback_node_raises(self):
        nodes = _build_spec_nodes(exclude={"REFLECT_FALLBACK"})
        g = _build_spec_graph(nodes=nodes)
        with pytest.raises(
            SMPValidationError, match="missing required node: REFLECT_FALLBACK"
        ):
            validate_memex_turn_graph(g)


class TestMissingEdge:
    def test_missing_required_edge_raises(self):
        edges = _build_spec_edges(
            exclude={("LOAD_CONTEXT", "EVALUATE_PRIOR_ANSWER_FEEDBACK")}
        )
        g = _build_spec_graph(edges=edges)
        with pytest.raises(
            SMPValidationError,
            match="missing required edge: LOAD_CONTEXT -> EVALUATE_PRIOR_ANSWER_FEEDBACK",
        ):
            validate_memex_turn_graph(g)

    def test_missing_fallback_continuation_edge_raises(self):
        edges = _build_spec_edges(exclude={("CLASSIFY_DEFAULT", "MIDDLEWARE_CLASSIFY")})
        g = _build_spec_graph(edges=edges)
        with pytest.raises(
            SMPValidationError,
            match="missing required edge: CLASSIFY_DEFAULT -> MIDDLEWARE_CLASSIFY",
        ):
            validate_memex_turn_graph(g)


class TestMissingFallback:
    def test_missing_fallback_raises(self):
        fallbacks = _build_spec_fallbacks(exclude={("CLASSIFY", "CLASSIFY_DEFAULT")})
        g = _build_spec_graph(fallback_edges=fallbacks)
        with pytest.raises(
            SMPValidationError,
            match="missing required fallback: CLASSIFY -> CLASSIFY_DEFAULT",
        ):
            validate_memex_turn_graph(g)

    def test_missing_tool_loop_fallback_raises(self):
        fallbacks = _build_spec_fallbacks(exclude={("TOOL_LOOP", "TOOL_LOOP_FALLBACK")})
        g = _build_spec_graph(fallback_edges=fallbacks)
        with pytest.raises(
            SMPValidationError,
            match=r"TOOL_LOOP.*TOOL_LOOP_FALLBACK",
        ):
            validate_memex_turn_graph(g)


class TestJoinBarriers:
    def test_missing_join_barrier_raises(self):
        # Only include _POST_JOIN, omit _GATHER_JOIN
        barriers = (
            JoinBarrier(
                name="_POST_JOIN",
                incoming=frozenset({"APPLY_EXTRACTION", "APPLY_REFLECT"}),
            ),
        )
        g = _build_spec_graph(join_barriers=barriers)
        with pytest.raises(
            SMPValidationError, match="missing join barrier: _GATHER_JOIN"
        ):
            validate_memex_turn_graph(g)

    def test_wrong_incoming_set_raises(self):
        barriers = _build_spec_barriers(
            overrides={
                "_GATHER_JOIN": JoinBarrier(
                    name="_GATHER_JOIN",
                    incoming=frozenset({"SELECT_TOOLS", "FACT_STORE"}),
                )
            }
        )
        g = _build_spec_graph(join_barriers=barriers)
        with pytest.raises(SMPValidationError, match="incoming mismatch"):
            validate_memex_turn_graph(g)


class TestRetryPolicies:
    def test_llm_respond_no_retry_raises(self):
        overrides = {
            "LLM_RESPOND": PhaseNode(
                name="LLM_RESPOND",
                execute=_noop,
                inputs=frozenset(),
                outputs=frozenset(),
                retry=RetryPolicy(max_attempts=1),
                emit_event=False,
            )
        }
        nodes = _build_spec_nodes(overrides=overrides)
        g = _build_spec_graph(nodes=nodes)
        with pytest.raises(
            SMPValidationError, match="LLM_RESPOND must have retry max_attempts >= 2"
        ):
            validate_memex_turn_graph(g)

    def test_classify_no_retry_warns(self):
        overrides = {
            "CLASSIFY": PhaseNode(
                name="CLASSIFY",
                execute=_noop,
                inputs=frozenset(),
                outputs=frozenset(),
                retry=RetryPolicy(max_attempts=1),
                emit_event=False,
            )
        }
        nodes = _build_spec_nodes(overrides=overrides)
        g = _build_spec_graph(nodes=nodes)
        warnings = validate_memex_turn_graph(g)
        assert any("CLASSIFY" in w and "retry" in w for w in warnings)


class TestCriticalPath:
    def test_broken_critical_path_raises(self):
        edges = _build_spec_edges(exclude={("BUILD_PROMPT", "RECORD_HUMAN_TURN")})
        g = _build_spec_graph(edges=edges)
        with pytest.raises(
            SMPValidationError,
            match="critical path broken.*BUILD_PROMPT -> RECORD_HUMAN_TURN",
        ):
            validate_memex_turn_graph(g)
