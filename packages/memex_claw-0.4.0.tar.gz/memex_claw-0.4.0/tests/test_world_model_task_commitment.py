from __future__ import annotations

from unittest.mock import patch

from memex.meetings.models import MeetingRecord, MeetingState
from memex.meetings.semantic_projection import sync_meeting_item_projection
from memex.memory.retrieval import retrieve_for_context
from memex.memory.world_model_reads import resolve_world_model_reads
from memex.models import (
    ActionType,
    Item,
    ItemType,
    Provenance,
    ScheduledTask,
    WorldModelAction,
    WorldModelCommitment,
    WorldModelEvent,
)
from memex.remember import RememberClassification, RememberIntent, execute_remember
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.world_model_backbone import build_world_model_provenance_link
from memex.utcnow import utcnow


def test_reminder_creates_canonical_world_model_task(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    content_store = store.content
    scheduler_store = store.scheduler

    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )

    with patch("memex.llm.chat_structured", return_value=mock_result):
        result = execute_remember(
            "remind me to call mom Tuesday at 3pm",
            content_store=content_store,
            memex_store=store,
            scheduler_store=scheduler_store,
        )

    task = store.load_world_model_task(result["task_id"])

    assert task is not None
    assert task.task_id == result["task_id"]
    assert task.title == "Reminder: Call mom"
    assert task.goal_id == result["goal_id"]
    assert task.task_kind == "scheduled_reminder"
    assert task.status == "active"
    assert task.source_surface == "c08_world_model_task"
    assert task.payload["scheduled_task_id"] == result["task_id"]
    assert task.payload["action_type"] == "notification"
    assert task.payload["generator"] == "reminder"
    provenance = store.list_world_model_provenance_links(
        source_record_type="world_model_task",
        source_record_id=task.task_id,
    )
    assert any(
        link.relationship == "advances_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == result["goal_id"]
        for link in provenance
    )


def test_task_document_incoming_links_include_execution_context(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    task = ScheduledTask(
        task_id="sched-task-execution-links",
        name="Reminder: send docs note",
        description="Send the docs release note",
        cron_expr="0 9 * * *",
        action_type=ActionType.NOTIFICATION,
        action_data={"generator": "reminder", "one_shot": True},
        goal_id="goal-docs",
        enabled=True,
        builtin=False,
        created_at=now,
        updated_at=now,
    )
    store.scheduler.create_task(task)
    store.upsert_world_model_action(
        WorldModelAction(
            action_id="session:s3:action:turn:1:selected",
            session_id="session:s3",
            intent_id="intent:s3:1",
            prompt_control_artifact_id=None,
            conversation_turn_id=1,
            action_kind="selected_action",
            action_name="schedule_followup",
            status="succeeded",
            payload={"selected_action": {"name": "schedule_followup"}},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_event(
        WorldModelEvent(
            event_id="session:s3:event:turn:1",
            session_id="session:s3",
            conversation_turn_id=1,
            event_kind="turn_outcome",
            title="Turn event: scheduled reminder",
            summary="Scheduled the docs reminder",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            "session:s3:action:turn:1:selected",
            "world_model_task",
            "sched-task-execution-links",
            "creates_task",
            created_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_event",
            "session:s3:event:turn:1",
            "world_model_task",
            "sched-task-execution-links",
            "creates_task",
            created_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hit = reads.load_task_document("sched-task-execution-links")

    assert hit is not None
    assert any(
        link["relationship"] == "creates_task"
        and link["source_record_type"] == "world_model_action"
        and link["source_record_id"] == "session:s3:action:turn:1:selected"
        for link in hit.incoming_links
    )
    assert any(
        link["relationship"] == "creates_task"
        and link["source_record_type"] == "world_model_event"
        and link["source_record_id"] == "session:s3:event:turn:1"
        for link in hit.incoming_links
    )


def test_task_provenance_replaces_stale_goal_links_on_update(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    scheduler_store = store.scheduler
    now = utcnow()
    task = ScheduledTask(
        task_id="sched-task-1",
        name="Reminder: check rollout",
        description="Check rollout status",
        cron_expr="0 9 * * *",
        action_type=ActionType.NOTIFICATION,
        action_data={"generator": "reminder", "one_shot": True},
        goal_id="goal-1",
        enabled=True,
        builtin=False,
        created_at=now,
        updated_at=now,
    )
    scheduler_store.create_task(task)

    task.goal_id = "goal-2"
    task.updated_at = utcnow()
    scheduler_store.update_task(task)

    provenance = store.list_world_model_provenance_links(
        source_record_type="world_model_task",
        source_record_id=task.task_id,
    )
    assert len(provenance) == 1
    assert provenance[0].relationship == "advances_goal"
    assert provenance[0].target_record_type == "world_model_goal"
    assert provenance[0].target_record_id == "goal-2"

    task.goal_id = None
    task.updated_at = utcnow()
    scheduler_store.update_task(task)
    provenance = store.list_world_model_provenance_links(
        source_record_type="world_model_task",
        source_record_id=task.task_id,
    )
    assert provenance == []


def test_explicit_meeting_commitment_creates_canonical_world_model_commitment(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-canonical-commitment",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        item_id="meeting-item-canonical-commitment",
        started_at=now,
        notes="Decision: keep SQLite canonical.",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-123",
            }
        ],
        created_at=now,
        updated_at=now,
    )
    ms.create_meeting(meeting)

    store.content.create_item(
        Item(
            item_id="meeting-item-canonical-commitment",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-canonical-commitment",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-canonical-commitment"}},
        )
    )
    record = ms.get_meeting("mtg-canonical-commitment")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    commitments = store.list_world_model_commitments(
        meeting_id="mtg-canonical-commitment"
    )

    assert len(commitments) == 1
    commitment = commitments[0]
    assert commitment.meeting_id == "mtg-canonical-commitment"
    assert commitment.title == "Ship docs update"
    assert commitment.goal_id == "goal-123"
    assert commitment.assignee == "Corey"
    assert commitment.agreed_by == "Corey"
    assert commitment.status == "active"
    assert commitment.source_surface == "c08_world_model_commitment"
    assert commitment.payload["artifact_type"] == "commitment"
    provenance = store.list_world_model_provenance_links(
        source_record_type="world_model_commitment",
        source_record_id=commitment.commitment_id,
    )
    assert any(
        link.relationship == "commits_from"
        and link.target_record_type == "meeting_artifact"
        for link in provenance
    )
    assert any(
        link.relationship == "updates_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == "goal-123"
        for link in provenance
    )


def test_commitment_provenance_is_store_owned_and_replaces_stale_links(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    commitment = WorldModelCommitment(
        commitment_id="commitment-1",
        source_record_type="meeting_artifact",
        source_record_id="artifact-1",
        meeting_id="meeting-1",
        semantic_item_id="item-1",
        goal_id="goal-1",
        title="Ship docs update",
        description="Commitment from meeting",
        assignee="Corey",
        agreed_by="Corey",
        status="active",
        payload={"artifact_type": "commitment"},
        source_surface="c08_world_model_commitment",
        created_at=now,
        updated_at=now,
    )
    store.upsert_world_model_commitment(commitment)

    commitment = commitment.model_copy(
        update={
            "goal_id": "goal-2",
            "semantic_item_id": None,
            "updated_at": utcnow(),
        }
    )
    store.upsert_world_model_commitment(commitment)

    provenance = store.list_world_model_provenance_links(
        source_record_type="world_model_commitment",
        source_record_id="commitment-1",
    )
    assert any(
        link.relationship == "commits_from"
        and link.target_record_type == "meeting_artifact"
        and link.target_record_id == "artifact-1"
        for link in provenance
    )
    assert any(
        link.relationship == "updates_goal"
        and link.target_record_type == "world_model_goal"
        and link.target_record_id == "goal-2"
        for link in provenance
    )
    assert not any(
        link.relationship == "updates_goal" and link.target_record_id == "goal-1"
        for link in provenance
    )
    assert not any(
        link.relationship == "updates" and link.target_record_type == "item"
        for link in provenance
    )


def test_retrieve_can_surface_world_model_task_and_commitment_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    content_store = store.content
    scheduler_store = store.scheduler
    now = utcnow()

    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )
    with patch("memex.llm.chat_structured", return_value=mock_result):
        reminder = execute_remember(
            "remind me to call mom Tuesday at 3pm",
            content_store=content_store,
            memex_store=store,
            scheduler_store=scheduler_store,
        )

    ms = store.meetings
    meeting = MeetingRecord(
        meeting_id="mtg-retrieval-commitment",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        item_id="meeting-item-retrieval-commitment",
        started_at=now,
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-123",
            }
        ],
        created_at=now,
        updated_at=now,
    )
    ms.create_meeting(meeting)
    store.content.create_item(
        Item(
            item_id="meeting-item-retrieval-commitment",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-retrieval-commitment",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-retrieval-commitment"}},
        )
    )
    record = ms.get_meeting("mtg-retrieval-commitment")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    reminder_result = retrieve_for_context(
        "Call mom",
        2000,
        content_store=content_store,
        world_model_store=store,
    )
    commitment_result = retrieve_for_context(
        "Ship docs update Corey Friday",
        2000,
        content_store=content_store,
        world_model_store=store,
    )

    assert f"world_model_task:{reminder['task_id']}" in reminder_result.document_ids
    assert "Reminder: Call mom" in reminder_result.text
    assert any(
        doc_id.startswith("world_model_commitment:")
        for doc_id in commitment_result.document_ids
    )
    assert "Ship docs update" in commitment_result.text
