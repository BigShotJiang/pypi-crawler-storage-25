"""Tests for GraphExecutor (sequential dispatch, retry, fallback, join barriers)."""

from __future__ import annotations

from memex.phase_graph.context import TurnContext
from memex.phase_graph.executor import GraphExecutor
from memex.phase_graph.graph import (
    FallbackEdge,
    JoinBarrier,
    PhaseEdge,
    PhaseGraph,
    PhaseNode,
)
from memex.phase_graph.retry import RetryPolicy


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _noop(ctx):
    pass


def _write_key(key, value):
    def _fn(ctx):
        ctx[key] = value

    return _fn


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestSimpleLinearGraph:
    def test_simple_linear_graph(self):
        """3 nodes A->B->C, verify execution order and context keys."""
        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", 2),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", 3),
                inputs=frozenset({"b_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="B", target="C"),
        )
        graph = PhaseGraph(nodes=nodes, edges=edges)
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["a_out"] == 1
        assert result["b_out"] == 2
        assert result["c_out"] == 3

        trace = result["execution_trace"]
        assert len(trace) == 3
        assert [e.node_name for e in trace] == ["A", "B", "C"]
        assert all(e.status == "completed" for e in trace)


class TestRetryThenSucceed:
    def test_retry_then_succeed(self):
        """Node fails twice then succeeds with max_attempts=3."""
        call_count = {"n": 0}

        def flaky(ctx):
            call_count["n"] += 1
            if call_count["n"] < 3:
                raise ConnectionError("transient")
            ctx["result"] = "ok"

        retry = RetryPolicy(
            max_attempts=3,
            backoff_base=0.001,
            retryable=lambda exc: isinstance(exc, ConnectionError),
        )
        nodes = (
            PhaseNode(
                "A",
                execute=flaky,
                inputs=frozenset(),
                outputs=frozenset({"result"}),
                retry=retry,
                emit_event=False,
            ),
        )
        graph = PhaseGraph(nodes=nodes, edges=())
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["result"] == "ok"
        trace = result["execution_trace"]
        assert len(trace) == 1
        assert trace[0].status == "completed"
        assert trace[0].retry_count == 2  # 0-indexed: final successful attempt index


class TestFallbackOnFailure:
    def test_fallback_on_failure(self):
        """Node always fails, fallback node runs, continuation fires."""

        def always_fail(ctx):
            raise RuntimeError("boom")

        nodes = (
            PhaseNode(
                "A",
                execute=always_fail,
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "A_FALLBACK",
                execute=_write_key("a_out", "fallback_val"),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "done"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="A_FALLBACK", target="B"),
        )
        fallbacks = (FallbackEdge(source="A", target="A_FALLBACK"),)
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            fallback_edges=fallbacks,
            exclusive_output_pairs=frozenset({frozenset({"A", "A_FALLBACK"})}),
        )
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["a_out"] == "fallback_val"
        assert result["b_out"] == "done"

        trace = result["execution_trace"]
        statuses = {e.node_name: e.status for e in trace if e.status != "cancelled"}
        assert statuses["A"] == "failed"
        assert statuses["A_FALLBACK"] == "completed"
        assert statuses["B"] == "completed"

    def test_fallback_preserves_existing_response(self):
        """Fallback keeps pre-existing response if non-empty."""

        def write_response(ctx):
            ctx["response"] = "original"

        def always_fail(ctx):
            raise RuntimeError("tool loop broke")

        def fallback_fn(ctx):
            if not ctx.get("response", ""):
                ctx["response"] = "error fallback"
            ctx["tool_calls"] = []

        def read_response(ctx):
            ctx["final"] = ctx["response"]

        nodes = (
            PhaseNode(
                "MAIN",
                execute=write_response,
                inputs=frozenset(),
                outputs=frozenset({"response"}),
                emit_event=False,
            ),
            PhaseNode(
                "TOOL",
                execute=always_fail,
                inputs=frozenset({"response"}),
                outputs=frozenset({"tool_calls"}),
                emit_event=False,
            ),
            PhaseNode(
                "TOOL_FB",
                execute=fallback_fn,
                inputs=frozenset(),
                outputs=frozenset({"response", "tool_calls"}),
                emit_event=False,
            ),
            PhaseNode(
                "NEXT",
                execute=read_response,
                inputs=frozenset({"response", "tool_calls"}),
                outputs=frozenset({"final"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="MAIN", target="TOOL"),
            PhaseEdge(source="TOOL_FB", target="NEXT"),
        )
        fallbacks = (FallbackEdge(source="TOOL", target="TOOL_FB"),)
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            fallback_edges=fallbacks,
            exclusive_output_pairs=frozenset(
                {frozenset({"TOOL", "TOOL_FB"}), frozenset({"MAIN", "TOOL_FB"})}
            ),
        )
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["response"] == "original"
        assert result["tool_calls"] == []

    def test_fallback_uses_default_when_no_response(self):
        """Fallback writes default error message when no prior response exists."""

        def always_fail(ctx):
            raise RuntimeError("tool loop broke")

        def fallback_fn(ctx):
            if not ctx.get("response", ""):
                ctx["response"] = "error fallback"
            ctx["tool_calls"] = []

        def read_response(ctx):
            ctx["final"] = ctx["response"]

        nodes = (
            PhaseNode(
                "TOOL",
                execute=always_fail,
                inputs=frozenset(),
                outputs=frozenset({"tool_calls"}),
                emit_event=False,
            ),
            PhaseNode(
                "TOOL_FB",
                execute=fallback_fn,
                inputs=frozenset(),
                outputs=frozenset({"response", "tool_calls"}),
                emit_event=False,
            ),
            PhaseNode(
                "NEXT",
                execute=read_response,
                inputs=frozenset({"response", "tool_calls"}),
                outputs=frozenset({"final"}),
                emit_event=False,
            ),
        )
        edges = (PhaseEdge(source="TOOL_FB", target="NEXT"),)
        fallbacks = (FallbackEdge(source="TOOL", target="TOOL_FB"),)
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            fallback_edges=fallbacks,
            exclusive_output_pairs=frozenset({frozenset({"TOOL", "TOOL_FB"})}),
        )
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["response"] == "error fallback"
        assert result["tool_calls"] == []
        assert result["final"] == "error fallback"


class TestJoinBarrier:
    def test_join_barrier(self):
        """Two branches converge at a join, then D runs."""
        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", 2),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", 3),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "D",
                execute=_write_key("d_out", 4),
                inputs=frozenset({"b_out", "c_out"}),
                outputs=frozenset({"d_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="A", target="C"),
            PhaseEdge(source="B", target="join_bc"),
            PhaseEdge(source="C", target="join_bc"),
            PhaseEdge(source="join_bc", target="D"),
        )
        barriers = (JoinBarrier(name="join_bc", incoming=frozenset({"B", "C"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result["d_out"] == 4
        trace = result["execution_trace"]
        names = [e.node_name for e in trace]
        assert "D" in names
        # D must come after both B and C
        assert names.index("D") > names.index("B")
        assert names.index("D") > names.index("C")


class TestRunToBoundary:
    def test_run_to_boundary(self):
        """Linear A->B->C->D. run_to_boundary('B') executes A,B only."""
        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", 2),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", 3),
                inputs=frozenset({"b_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "D",
                execute=_write_key("d_out", 4),
                inputs=frozenset({"c_out"}),
                outputs=frozenset({"d_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="B"),
            PhaseEdge(source="B", target="C"),
            PhaseEdge(source="C", target="D"),
        )
        graph = PhaseGraph(nodes=nodes, edges=edges)
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run_to_boundary("B")

        assert result.get("a_out") == 1
        assert result.get("b_out") == 2
        assert "c_out" not in result
        assert "d_out" not in result

        remaining = executor.remaining_nodes()
        assert "C" in remaining
        assert "D" in remaining

        # Now run remaining
        result = executor.run_remaining()
        assert result["c_out"] == 3
        assert result["d_out"] == 4


class TestConditionalEdge:
    def test_conditional_edge_positive(self):
        """A with two conditional edges: A->B (x>0), A->C (x<=0). x=5 -> B runs."""
        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out", "x"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "took_b"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", "took_c"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
        )

        def _set_x(ctx):
            ctx["a_out"] = 1
            ctx["x"] = 5

        nodes = (
            PhaseNode(
                "A",
                execute=_set_x,
                inputs=frozenset(),
                outputs=frozenset({"a_out", "x"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "took_b"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", "took_c"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(
                source="A", target="B", condition=lambda ctx: ctx.get("x", 0) > 0
            ),
            PhaseEdge(
                source="A", target="C", condition=lambda ctx: ctx.get("x", 0) <= 0
            ),
        )
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            exclusive_output_pairs=frozenset({frozenset({"B", "C"})}),
        )
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert result.get("b_out") == "took_b"
        assert "c_out" not in result

    def test_conditional_edge_negative(self):
        """A with two conditional edges: x=-1 -> C runs."""

        def _set_x_neg(ctx):
            ctx["a_out"] = 1
            ctx["x"] = -1

        nodes = (
            PhaseNode(
                "A",
                execute=_set_x_neg,
                inputs=frozenset(),
                outputs=frozenset({"a_out", "x"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "took_b"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=_write_key("c_out", "took_c"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(
                source="A", target="B", condition=lambda ctx: ctx.get("x", 0) > 0
            ),
            PhaseEdge(
                source="A", target="C", condition=lambda ctx: ctx.get("x", 0) <= 0
            ),
        )
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            exclusive_output_pairs=frozenset({frozenset({"B", "C"})}),
        )
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        assert "b_out" not in result
        assert result.get("c_out") == "took_c"


class TestVacuousJoin:
    def test_vacuous_join(self):
        """Join barrier with incoming={X, Y}. Only X is scheduled. Barrier resolves."""
        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "X",
                execute=_write_key("x_out", 10),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"x_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "Y",
                execute=_write_key("y_out", 20),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"y_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "D",
                execute=_write_key("d_out", 99),
                inputs=frozenset({"x_out"}),
                outputs=frozenset({"d_out"}),
                emit_event=False,
            ),
        )
        edges = (
            # A -> X always, A -> Y only if condition (never true)
            PhaseEdge(source="A", target="X"),
            PhaseEdge(source="A", target="Y", condition=lambda ctx: False),
            PhaseEdge(source="X", target="join_xy"),
            PhaseEdge(source="Y", target="join_xy"),
            PhaseEdge(source="join_xy", target="D"),
        )
        barriers = (JoinBarrier(name="join_xy", incoming=frozenset({"X", "Y"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore[typeddict-item]

        executor = GraphExecutor(graph, ctx)
        result = executor.run()

        # Y was never scheduled so vacuously complete, barrier should resolve
        assert result["d_out"] == 99
        trace = result["execution_trace"]
        names = [e.node_name for e in trace if e.status == "completed"]
        assert "D" in names
        assert "Y" not in names


class TestParallelEdges:
    def test_parallel_edges_execute_concurrently(self):
        """Nodes with parallel=True edges run concurrently — detect via threading.Barrier."""
        import threading

        barrier = threading.Barrier(2, timeout=5.0)

        def node_b(ctx):
            barrier.wait()
            ctx["b_out"] = "b"

        def node_c(ctx):
            barrier.wait()
            ctx["c_out"] = "c"

        def noop(ctx):
            pass

        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=node_b,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "C",
                execute=node_c,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"c_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "JOIN",
                execute=noop,
                inputs=frozenset(),
                outputs=frozenset(),
                emit_event=False,
            ),
            PhaseNode(
                "D",
                execute=_write_key("d_out", 99),
                inputs=frozenset({"b_out", "c_out"}),
                outputs=frozenset({"d_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="B", parallel=True),
            PhaseEdge(source="A", target="C", parallel=True),
            PhaseEdge(source="B", target="JOIN"),
            PhaseEdge(source="C", target="JOIN"),
            PhaseEdge(source="JOIN", target="D"),
        )
        barriers = (JoinBarrier(name="JOIN", incoming=frozenset({"B", "C"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore

        executor = GraphExecutor(graph, ctx)
        result = executor.run()
        assert result["b_out"] == "b"
        assert result["c_out"] == "c"
        assert result["d_out"] == 99

    def test_parallel_group_writes_disjoint_keys(self):
        """Parallel nodes write distinct context keys — no collision."""

        def write_x(ctx):
            ctx["x_out"] = "x"

        def write_y(ctx):
            ctx["y_out"] = "y"

        def noop(ctx):
            pass

        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "X",
                execute=write_x,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"x_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "Y",
                execute=write_y,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"y_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "JOIN",
                execute=noop,
                inputs=frozenset(),
                outputs=frozenset(),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "done"),
                inputs=frozenset({"x_out", "y_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="X", parallel=True),
            PhaseEdge(source="A", target="Y", parallel=True),
            PhaseEdge(source="X", target="JOIN"),
            PhaseEdge(source="Y", target="JOIN"),
            PhaseEdge(source="JOIN", target="B"),
        )
        barriers = (JoinBarrier(name="JOIN", incoming=frozenset({"X", "Y"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore

        executor = GraphExecutor(graph, ctx)
        result = executor.run()
        assert result["x_out"] == "x"
        assert result["y_out"] == "y"
        assert result["b_out"] == "done"

    def test_parallel_node_failure_routes_to_fallback(self):
        """One parallel node fails, its fallback runs, other parallel nodes complete."""

        def always_fail(ctx):
            raise RuntimeError("boom")

        def fallback_fn(ctx):
            ctx["x_out"] = "fallback"

        def noop(ctx):
            pass

        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "X",
                execute=always_fail,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"x_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "X_FB",
                execute=fallback_fn,
                inputs=frozenset(),
                outputs=frozenset({"x_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "Y",
                execute=_write_key("y_out", "y"),
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"y_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "JOIN",
                execute=noop,
                inputs=frozenset(),
                outputs=frozenset(),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "done"),
                inputs=frozenset({"x_out", "y_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="X", parallel=True),
            PhaseEdge(source="A", target="Y", parallel=True),
            PhaseEdge(source="X", target="JOIN"),
            PhaseEdge(source="X_FB", target="JOIN"),
            PhaseEdge(source="Y", target="JOIN"),
            PhaseEdge(source="JOIN", target="B"),
        )
        fallbacks = (FallbackEdge(source="X", target="X_FB"),)
        barriers = (JoinBarrier(name="JOIN", incoming=frozenset({"X", "Y"})),)
        graph = PhaseGraph(
            nodes=nodes,
            edges=edges,
            fallback_edges=fallbacks,
            join_barriers=barriers,
            exclusive_output_pairs=frozenset({frozenset({"X", "X_FB"})}),
        )
        ctx: TurnContext = {}  # type: ignore

        executor = GraphExecutor(graph, ctx)
        result = executor.run()
        assert result["x_out"] == "fallback"
        assert result["y_out"] == "y"
        assert result["b_out"] == "done"

    def test_parallel_barrier_waits_for_all_before_continuing(self):
        """Barrier after parallel nodes: not crossed until all parallel chains complete."""
        import threading

        completed_order = []
        lock = threading.Lock()

        def node_slow(ctx):
            import time

            time.sleep(0.02)
            with lock:
                completed_order.append("SLOW")
            ctx["slow_out"] = "s"

        def node_fast(ctx):
            with lock:
                completed_order.append("FAST")
            ctx["fast_out"] = "f"

        def noop(ctx):
            pass

        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "SLOW",
                execute=node_slow,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"slow_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "FAST",
                execute=node_fast,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"fast_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "JOIN",
                execute=noop,
                inputs=frozenset(),
                outputs=frozenset(),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "after_join"),
                inputs=frozenset({"slow_out", "fast_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="SLOW", parallel=True),
            PhaseEdge(source="A", target="FAST", parallel=True),
            PhaseEdge(source="SLOW", target="JOIN"),
            PhaseEdge(source="FAST", target="JOIN"),
            PhaseEdge(source="JOIN", target="B"),
        )
        barriers = (JoinBarrier(name="JOIN", incoming=frozenset({"SLOW", "FAST"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore

        executor = GraphExecutor(graph, ctx)
        result = executor.run()
        assert "SLOW" in completed_order
        assert "FAST" in completed_order
        assert result["b_out"] == "after_join"

    def test_sequential_chain_within_parallel_thread(self):
        """Parallel node with sequential descendant: descendant runs within same thread."""
        import threading

        thread_ids = {}

        def node_p(ctx):
            thread_ids["P"] = threading.current_thread().ident
            ctx["p_out"] = "p"

        def node_q(ctx):
            thread_ids["Q"] = threading.current_thread().ident
            ctx["q_out"] = "q"

        def noop(ctx):
            pass

        nodes = (
            PhaseNode(
                "A",
                execute=_write_key("a_out", 1),
                inputs=frozenset(),
                outputs=frozenset({"a_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "P",
                execute=node_p,
                inputs=frozenset({"a_out"}),
                outputs=frozenset({"p_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "Q",
                execute=node_q,
                inputs=frozenset({"p_out"}),
                outputs=frozenset({"q_out"}),
                emit_event=False,
            ),
            PhaseNode(
                "JOIN",
                execute=noop,
                inputs=frozenset(),
                outputs=frozenset(),
                emit_event=False,
            ),
            PhaseNode(
                "B",
                execute=_write_key("b_out", "done"),
                inputs=frozenset({"q_out"}),
                outputs=frozenset({"b_out"}),
                emit_event=False,
            ),
        )
        edges = (
            PhaseEdge(source="A", target="P", parallel=True),
            PhaseEdge(source="P", target="Q"),
            PhaseEdge(source="Q", target="JOIN"),
            PhaseEdge(source="JOIN", target="B"),
        )
        barriers = (JoinBarrier(name="JOIN", incoming=frozenset({"Q"})),)
        graph = PhaseGraph(nodes=nodes, edges=edges, join_barriers=barriers)
        ctx: TurnContext = {}  # type: ignore

        executor = GraphExecutor(graph, ctx)
        result = executor.run()
        assert result["q_out"] == "q"
        assert result["b_out"] == "done"
        main_thread_id = threading.main_thread().ident
        assert thread_ids["P"] != main_thread_id
        assert thread_ids["P"] == thread_ids["Q"]
