"""Tests for run_async — verifying it correctly dispatches to the MCP event loop.

The key invariant: coroutines that reference MCP sessions must run on the
same event loop where the session was created. run_async must dispatch to
that loop, not create a new one.
"""

import asyncio
import threading
from unittest.mock import MagicMock

import pytest

from memex.connectors.mcp_client import MCPClient, MCPClientConfig, run_async


@pytest.fixture
def mcp_loop():
    """Start a persistent MCP event loop thread, register it, and tear down after test."""
    from memex.connectors.mcp_client import set_mcp_loop

    loop = asyncio.new_event_loop()
    thread = threading.Thread(target=loop.run_forever, daemon=True)
    thread.start()
    set_mcp_loop(loop)
    yield loop
    set_mcp_loop(None)
    loop.call_soon_threadsafe(loop.stop)
    thread.join(timeout=5)
    loop.close()


# ---------------------------------------------------------------------------
# Test: run_async works from a thread with no running loop
# ---------------------------------------------------------------------------


def test_run_async_from_sync_thread():
    """run_async should work when called from a plain sync context."""

    async def add(a, b):
        return a + b

    assert run_async(add(2, 3)) == 5


# ---------------------------------------------------------------------------
# Test: run_async works from a thread that has a running event loop
# ---------------------------------------------------------------------------


def test_run_async_from_thread_with_running_loop():
    """run_async should work even when called from a thread that has a
    running event loop (e.g. HTTP handler thread in a service with asyncio).
    """
    result = None

    async def inner():
        return 42

    def worker():
        nonlocal result
        result = run_async(inner())

    loop = asyncio.new_event_loop()

    def run_in_loop():
        asyncio.set_event_loop(loop)
        loop.run_until_complete(asyncio.sleep(0))
        t = threading.Thread(target=worker)
        t.start()
        t.join(timeout=10)

    t = threading.Thread(target=run_in_loop)
    t.start()
    t.join(timeout=15)
    assert result == 42


# ---------------------------------------------------------------------------
# Test: run_async dispatches to the MCP loop when one is set
# ---------------------------------------------------------------------------


def test_run_async_dispatches_to_mcp_loop(mcp_loop):
    """When an MCP loop is registered, run_async should dispatch coroutines
    to that loop via run_coroutine_threadsafe, not create a new one.
    """
    coro_loop_id = None

    async def check_loop():
        nonlocal coro_loop_id
        coro_loop_id = id(asyncio.get_running_loop())
        return "ok"

    result = run_async(check_loop())
    assert result == "ok"
    assert coro_loop_id == id(mcp_loop), (
        "Coroutine should have run on the MCP loop, not a new one"
    )


# ---------------------------------------------------------------------------
# Test: run_async respects timeout on MCP loop dispatch
# ---------------------------------------------------------------------------


def test_run_async_mcp_loop_timeout(mcp_loop):
    """When dispatched to the MCP loop, run_async should time out rather
    than hang forever if the coroutine never completes.
    """

    async def hang_forever():
        await asyncio.sleep(3600)

    with pytest.raises(TimeoutError):
        run_async(hang_forever(), timeout=0.5)


# ---------------------------------------------------------------------------
# Test: MCP tool call via run_async uses the MCP loop
# ---------------------------------------------------------------------------


def test_tool_call_dispatches_to_mcp_loop(mcp_loop):
    """MCPClient.call_tool called via run_async should execute on the
    MCP loop where the session lives, not a throwaway loop.
    """
    config = MCPClientConfig(
        name="test",
        command="echo",
        args=[],
        timeout_seconds=5.0,
    )
    client = MCPClient(config)
    client._available = True
    client._session = MagicMock()

    call_loop_id = None

    async def mock_do_call(name, args):
        nonlocal call_loop_id
        call_loop_id = id(asyncio.get_running_loop())
        from memex.models import ToolResult

        return ToolResult(
            tool_name=name,
            success=True,
            content="ok",
            source="mcp:test",
            duration_ms=1,
        )

    client._do_call = mock_do_call

    result = run_async(client.call_tool("read_file", {"path": "/tmp/test"}))
    assert result.success
    assert call_loop_id == id(mcp_loop)
