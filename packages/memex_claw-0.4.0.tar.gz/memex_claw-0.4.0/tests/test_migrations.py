"""Tests for the FathomDB document migration framework."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from fathomdb import ChunkPolicy, NodeInsert, WriteRequest, new_row_id
from memex.fathom_store import FathomStore
from memex.migrations.runner import (
    MigrationModule,
    _register_migration_collection,
    discover_migrations,
    get_applied_revisions,
    run_pending_migrations,
)


@pytest.fixture
def engine(tmp_path):
    """Bare FathomDB engine (no FathomStore wrapper) for migration tests."""
    from fathomdb import Engine, ProvenanceMode

    eng = Engine.open(
        str(tmp_path / "mig-test.db"),
        provenance_mode=ProvenanceMode.WARN,
        vector_dimension=384,
    )
    yield eng
    eng.close()


@pytest.fixture
def fstore(tmp_path):
    """Full FathomStore — migrations run during open()."""
    store = FathomStore.open(str(tmp_path / "fathom.db"))
    yield store
    store.close()


class TestMigrationCollectionSetup:
    def test_register_is_idempotent(self, engine):
        _register_migration_collection(engine)
        _register_migration_collection(engine)  # no error

    def test_applied_revisions_empty_initially(self, engine):
        assert get_applied_revisions(engine) == set()


class TestRunPendingMigrations:
    def test_discovers_and_applies_builtin_migrations(self, engine):
        results = run_pending_migrations(engine)
        revisions = {r.revision for r in results}
        assert "001" in revisions
        assert "002" in revisions

    def test_idempotent_rerun(self, engine):
        run_pending_migrations(engine)
        second = run_pending_migrations(engine)
        assert second == [], "No migrations should apply on second run"

    def test_applied_revisions_tracked(self, engine):
        run_pending_migrations(engine)
        applied = get_applied_revisions(engine)
        assert "001" in applied
        assert "002" in applied

    def test_custom_migration_via_patch(self, engine):
        called = []

        def fake_upgrade(eng):
            called.append(True)

        fake_mig = MigrationModule(
            revision="999",
            description="test migration",
            upgrade=fake_upgrade,
        )
        with patch(
            "memex.migrations.runner.discover_migrations",
            return_value=[fake_mig],
        ):
            results = run_pending_migrations(engine)
        assert len(results) == 1
        assert results[0].revision == "999"
        assert called == [True]

    def test_failing_migration_raises(self, engine):
        def bad_upgrade(eng):
            raise RuntimeError("boom")

        fake_mig = MigrationModule(
            revision="999",
            description="broken",
            upgrade=bad_upgrade,
        )
        with patch(
            "memex.migrations.runner.discover_migrations",
            return_value=[fake_mig],
        ):
            with pytest.raises(RuntimeError, match="boom"):
                run_pending_migrations(engine)

    def test_skips_already_applied(self, engine):
        called = []

        def tracked_upgrade(eng):
            called.append(True)

        fake_mig = MigrationModule(
            revision="999",
            description="test",
            upgrade=tracked_upgrade,
        )
        with patch(
            "memex.migrations.runner.discover_migrations",
            return_value=[fake_mig],
        ):
            run_pending_migrations(engine)
            run_pending_migrations(engine)
        assert len(called) == 1, "Should only run once"


class TestMigration001GoalMetadata:
    def test_backfills_missing_metadata(self, engine):
        _register_migration_collection(engine)
        # Create a goal node WITHOUT metadata
        engine.write(
            WriteRequest(
                label="test-setup",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id="goal:test-1",
                        kind="Goal",
                        properties={
                            "goal_id": "test-1",
                            "title": "Old goal",
                            "status": "active",
                            "priority": "medium",
                        },
                        source_ref="test",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        from memex.migrations.versions.m001_backfill_goal_metadata import upgrade

        upgrade(engine)

        rows = (
            engine.nodes("Goal").filter_logical_id_eq("goal:test-1").limit(1).execute()
        )
        props = rows.nodes[0].properties
        assert props.get("metadata") == {}

    def test_leaves_existing_metadata_intact(self, engine):
        _register_migration_collection(engine)
        engine.write(
            WriteRequest(
                label="test-setup",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id="goal:test-2",
                        kind="Goal",
                        properties={
                            "goal_id": "test-2",
                            "title": "New goal",
                            "status": "active",
                            "priority": "high",
                            "metadata": {"key": "value"},
                        },
                        source_ref="test",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        from memex.migrations.versions.m001_backfill_goal_metadata import upgrade

        upgrade(engine)

        rows = (
            engine.nodes("Goal").filter_logical_id_eq("goal:test-2").limit(1).execute()
        )
        props = rows.nodes[0].properties
        assert props["metadata"] == {"key": "value"}


class TestMigration002TaskFailureReason:
    def test_backfills_missing_failure_reason(self, engine):
        _register_migration_collection(engine)
        engine.write(
            WriteRequest(
                label="test-setup",
                nodes=[
                    NodeInsert(
                        row_id=new_row_id(),
                        logical_id="wm_task:t1",
                        kind="WMTask",
                        properties={
                            "task_id": "t1",
                            "title": "Old task",
                            "status": "pending",
                        },
                        source_ref="test",
                        upsert=False,
                        chunk_policy=ChunkPolicy.PRESERVE,
                    )
                ],
            )
        )
        from memex.migrations.versions.m002_backfill_task_failure_reason import upgrade

        upgrade(engine)

        rows = (
            engine.nodes("WMTask").filter_logical_id_eq("wm_task:t1").limit(1).execute()
        )
        props = rows.nodes[0].properties
        assert props.get("failure_reason") == ""


class TestMigration004FtsPropertySchemasV2:
    def _seed_execution_records(self, engine, count):
        nodes = [
            NodeInsert(
                row_id=new_row_id(),
                logical_id=f"wm_execution_record:er-{i}",
                kind="WMExecutionRecord",
                properties={
                    "execution_id": f"er-{i}",
                    "execution_kind": "test",
                    "status": "succeeded",
                    "title": f"record {i}",
                    "summary": "",
                },
                source_ref="test",
                upsert=False,
                chunk_policy=ChunkPolicy.PRESERVE,
            )
            for i in range(count)
        ]
        engine.write(WriteRequest(label="test-seed-exec-records", nodes=nodes))

    def test_warns_when_execution_record_count_exceeds_threshold(
        self, engine, caplog, monkeypatch
    ):
        import logging

        from memex.migrations.versions import (
            m004_register_fts_property_schemas_v2 as m004,
        )

        monkeypatch.setattr(m004, "_REBUILD_WARN_THRESHOLD", 5)
        self._seed_execution_records(engine, 7)
        with caplog.at_level(logging.WARNING, logger=m004.logger.name):
            m004._warn_if_large_rebuild(engine)
        assert any(
            "rebuilding" in rec.message and "WMExecutionRecord" in rec.message
            for rec in caplog.records
        )

    def test_silent_when_execution_record_count_below_threshold(
        self, engine, caplog, monkeypatch
    ):
        import logging

        from memex.migrations.versions import (
            m004_register_fts_property_schemas_v2 as m004,
        )

        monkeypatch.setattr(m004, "_REBUILD_WARN_THRESHOLD", 100)
        self._seed_execution_records(engine, 3)
        with caplog.at_level(logging.WARNING, logger=m004.logger.name):
            m004._warn_if_large_rebuild(engine)
        assert not any("rebuilding" in rec.message for rec in caplog.records)


class TestMigration006FtsTokenizers:
    def test_recall_kinds_get_recall_tokenizer(self, engine):
        from fathomdb import FtsPropertyPathMode, FtsPropertyPathSpec

        from memex.migrations.runner import _register_migration_collection
        from memex.migrations.versions import m006_configure_fts_tokenizers as m006

        _register_migration_collection(engine)
        spec = FtsPropertyPathSpec(path="$.title", mode=FtsPropertyPathMode.SCALAR)
        engine.admin.register_fts_property_schema_with_entries("WMGoal", [spec])
        engine.admin.register_fts_property_schema_with_entries("WMTask", [spec])
        m006.upgrade(engine)
        assert (
            engine.admin.get_fts_profile("WMGoal").tokenizer
            == "porter unicode61 remove_diacritics 2"
        )
        assert (
            engine.admin.get_fts_profile("WMTask").tokenizer
            == "porter unicode61 remove_diacritics 2"
        )

    def test_precision_kinds_get_precision_tokenizer(self, engine):
        from fathomdb import FtsPropertyPathMode, FtsPropertyPathSpec

        from memex.migrations.runner import _register_migration_collection
        from memex.migrations.versions import m006_configure_fts_tokenizers as m006

        _register_migration_collection(engine)
        spec = FtsPropertyPathSpec(
            path="$.relationship", mode=FtsPropertyPathMode.SCALAR
        )
        engine.admin.register_fts_property_schema_with_entries(
            "WMProvenanceLink", [spec]
        )
        engine.admin.register_fts_property_schema_with_entries(
            "WMSemanticMapping", [spec]
        )
        m006.upgrade(engine)
        for kind in ("WMProvenanceLink", "WMSemanticMapping"):
            profile = engine.admin.get_fts_profile(kind)
            assert profile is not None, f"{kind} profile not set"
            assert profile.tokenizer == "unicode61 remove_diacritics 2"

    def test_upgrade_idempotent(self, engine):
        from fathomdb import FtsPropertyPathMode, FtsPropertyPathSpec

        from memex.migrations.runner import _register_migration_collection
        from memex.migrations.versions import m006_configure_fts_tokenizers as m006

        _register_migration_collection(engine)
        spec = FtsPropertyPathSpec(path="$.title", mode=FtsPropertyPathMode.SCALAR)
        engine.admin.register_fts_property_schema_with_entries("WMGoal", [spec])
        m006.upgrade(engine)
        m006.upgrade(engine)
        m006.upgrade(engine)

    def test_skips_kind_with_no_fts_schema(self, engine, caplog):
        import logging

        from memex.migrations.runner import _register_migration_collection
        from memex.migrations.versions import m006_configure_fts_tokenizers as m006

        _register_migration_collection(engine)
        with caplog.at_level(
            logging.WARNING,
            logger="memex.migrations.versions.m006_configure_fts_tokenizers",
        ):
            m006.upgrade(engine)
        assert any("skipping" in record.message for record in caplog.records)


class TestMigration007FtsBm25Weights:
    """m007 re-registers WM FTS schemas with BM25 per-column weights.

    Requires fathomdb 0.5.0+ for FtsPropertyPathSpec.with_weight(). Tests that
    touch the module contents are gated so CI passes cleanly on 0.4.x where
    with_weight is not available; the module import may still succeed in that
    case because the helpers reference with_weight only at call time.
    """

    def _import_m007(self):
        from fathomdb import FtsPropertyPathMode, FtsPropertyPathSpec

        probe = FtsPropertyPathSpec(path="$.title", mode=FtsPropertyPathMode.SCALAR)
        if not hasattr(probe, "weight"):
            pytest.skip("fathomdb installed lacks FtsPropertyPathSpec.weight")
        from memex.migrations.versions import m007_fts_bm25_weights as m007

        return m007

    def test_revision_and_description(self):
        m007 = self._import_m007()
        assert m007.REVISION == "007"
        assert isinstance(m007.DESCRIPTION, str)
        assert m007.DESCRIPTION.strip() != ""

    def test_upgrade_is_callable(self):
        m007 = self._import_m007()
        assert callable(m007.upgrade)

    def test_schemas_contain_all_14_expected_kinds(self):
        m007 = self._import_m007()
        kinds = [kind for kind, _entries in m007._build_schemas()]
        expected = {
            "WMAction",
            "WMExecutionRecord",
            "WMKnowledgeObject",
            "WMGoal",
            "WMTask",
            "WMPlan",
            "WMPlanStep",
            "WMPlanStepTransition",
            "WMEvent",
            "WMCommitment",
            "WMSemanticMapping",
            "WMObservation",
            "WMClaimEvaluation",
            "Goal",
        }
        assert set(kinds) == expected
        assert len(kinds) == 14

    def test_wm_goal_weight_policy_spot_check(self):
        m007 = self._import_m007()
        wm_goal_entries = dict(m007._build_schemas())["WMGoal"]
        by_path = {e.path: e for e in wm_goal_entries}
        assert by_path["$.title"].weight == pytest.approx(2.0)
        assert by_path["$.status"].weight == pytest.approx(0.4)


class TestFathomStoreRunsMigrationsOnOpen:
    def test_migrations_applied_during_open(self, fstore):
        applied = get_applied_revisions(fstore.engine)
        assert "001" in applied
        assert "002" in applied

    def test_006_applied_during_open(self, fstore):
        applied = get_applied_revisions(fstore.engine)
        assert "006" in applied


class TestDiscoverMigrations:
    def test_returns_sorted_modules(self):
        migs = discover_migrations()
        revisions = [m.revision for m in migs]
        assert revisions == sorted(revisions)
        assert len(migs) >= 2
