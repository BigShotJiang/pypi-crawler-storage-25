"""Tests for SkillRegistry."""

from pathlib import Path

from memex.skills.loader import SkillDefinition
from memex.skills.registry import SkillRegistry


def _skill(name: str, **kwargs) -> SkillDefinition:
    defaults = dict(
        description=f"Test {name}",
        version="1.0.0",
        body=f"Body of {name}",
        base_dir=Path("/tmp"),
    )
    defaults.update(kwargs)
    return SkillDefinition(name=name, **defaults)


def test_register_and_get():
    reg = SkillRegistry()
    s = _skill("a")
    reg.register(s)
    assert reg.get_skill("a") is s
    assert reg.get_skill("missing") is None


def test_all_skills():
    reg = SkillRegistry()
    reg.register(_skill("a"))
    reg.register(_skill("b"))
    assert len(reg.all_skills()) == 2


def test_get_prompt_candidates_excludes_disabled():
    reg = SkillRegistry()
    reg.register(_skill("visible"))
    reg.register(_skill("hidden", disable_model_invocation=True))
    candidates = reg.get_prompt_candidates()
    names = [s.name for s in candidates]
    assert "visible" in names
    assert "hidden" not in names


def test_get_slash_commands():
    reg = SkillRegistry()
    reg.register(_skill("invocable", user_invocable=True))
    reg.register(_skill("not-invocable", user_invocable=False))
    cmds = reg.get_slash_commands()
    assert "invocable" in cmds
    assert "not-invocable" not in cmds
