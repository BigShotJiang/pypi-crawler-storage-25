"""Tests for filesystem server connection in the startup loop."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from memex.models import ConnectorHealth, ToolDefinition
from memex.utcnow import utcnow


class TestConnectConfiguredServers:
    @patch("memex.loop._connect_mcp_server_entry")
    @patch("memex.mcp_servers.servers_config_from_env")
    def test_connects_enabled_servers(self, mock_config_fn, mock_connect):
        """Enabled servers from config are connected."""
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config_fn.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="filesystem",
                    command="npx",
                    args=["@modelcontextprotocol/server-filesystem", "/tmp"],
                    capability_prefix="filesystem",
                    integration="filesystem",
                ),
            ]
        )

        from memex.loop import _connect_configured_servers

        store = MagicMock()
        registry = MagicMock()
        clients: dict = {}
        health: list = []

        _connect_configured_servers(store, registry, clients, health)

        mock_connect.assert_called_once()
        entry = mock_connect.call_args[0][0]
        assert entry.name == "filesystem"

    @patch("memex.loop._connect_mcp_server_entry")
    @patch("memex.mcp_servers.servers_config_from_env")
    def test_skips_disabled_servers(self, mock_config_fn, mock_connect):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config_fn.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="filesystem",
                    command="npx",
                    enabled=False,
                ),
            ]
        )

        from memex.loop import _connect_configured_servers

        store = MagicMock()
        _connect_configured_servers(store, MagicMock(), {}, [])

        mock_connect.assert_not_called()

    @patch("memex.loop._connect_mcp_server_entry")
    @patch("memex.mcp_servers.servers_config_from_env")
    def test_skips_already_connected(self, mock_config_fn, mock_connect):
        """Servers already in connector_clients are skipped."""
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config_fn.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(name="wake", command="wake-mcp"),
            ]
        )

        from memex.loop import _connect_configured_servers

        store = MagicMock()
        clients = {"wake": MagicMock()}  # already connected
        _connect_configured_servers(store, MagicMock(), clients, [])

        mock_connect.assert_not_called()

    @patch("memex.loop._connect_mcp_server_entry")
    @patch("memex.mcp_servers.servers_config_from_env")
    def test_failure_adds_unavailable_health(self, mock_config_fn, mock_connect):
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config_fn.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(name="filesystem", command="bad-cmd"),
            ]
        )
        mock_connect.side_effect = OSError("spawn failed")

        from memex.loop import _connect_configured_servers

        store = MagicMock()
        health: list = []
        _connect_configured_servers(store, MagicMock(), {}, health)

        assert len(health) == 1
        assert health[0].status == "unavailable"
        assert health[0].name == "filesystem"
        assert "spawn failed" in health[0].error

    @patch("memex.loop._connect_mcp_server_entry")
    @patch("memex.mcp_servers.servers_config_from_env")
    def test_multiple_servers(self, mock_config_fn, mock_connect):
        """Multiple configured servers are all attempted."""
        from memex.mcp_servers import MCPServerEntry, MCPServersConfig

        mock_config_fn.return_value = MCPServersConfig(
            servers=[
                MCPServerEntry(
                    name="filesystem", command="fs-cmd", integration="filesystem"
                ),
                MCPServerEntry(name="git", command="git-cmd"),
            ]
        )

        from memex.loop import _connect_configured_servers

        _connect_configured_servers(MagicMock(), MagicMock(), {}, [])

        assert mock_connect.call_count == 2


class TestConnectMCPServerEntry:
    @patch("memex.connectors.mcp_client.MCPClient")
    def test_filesystem_uses_integration(self, mock_client_cls):
        """Filesystem entries use FilesystemIntegration for tool registration."""
        from memex.mcp_servers import MCPServerEntry

        entry = MCPServerEntry(
            name="filesystem",
            command="npx",
            args=["@modelcontextprotocol/server-filesystem", "/tmp"],
            capability_prefix="filesystem",
            integration="filesystem",
            write=True,
        )

        mock_client = MagicMock()
        mock_client.available = True
        mock_client.discovered_tools = [
            ToolDefinition(
                name="read_file",
                description="Read",
                source="mcp:filesystem",
                required_capability="filesystem.read",
            ),
            ToolDefinition(
                name="write_file",
                description="Write",
                source="mcp:filesystem",
                required_capability="filesystem.read",
            ),
        ]
        mock_client_cls.return_value = mock_client

        mock_health = ConnectorHealth(
            name="filesystem",
            status="connected",
            last_check=utcnow(),
            tools_discovered=2,
        )

        with patch("memex.connectors.mcp_client.run_async", return_value=mock_health):
            from memex.loop import _connect_mcp_server_entry

            store = MagicMock()
            registry = MagicMock()
            clients: dict = {}
            health: list = []

            _connect_mcp_server_entry(entry, store, registry, clients, health)

        assert "filesystem" in clients
        # FilesystemIntegration with write=True should have assigned different capabilities
        registered_tools = [call.args[0] for call in registry.register.call_args_list]
        write_tools = [
            t for t in registered_tools if t.required_capability == "filesystem.write"
        ]
        read_tools = [
            t for t in registered_tools if t.required_capability == "filesystem.read"
        ]
        assert len(write_tools) == 1  # write_file
        assert len(read_tools) == 1  # read_file

    @patch("memex.connectors.mcp_client.MCPClient")
    def test_generic_server_registers_directly(self, mock_client_cls):
        """Non-filesystem entries register discovered tools directly."""
        from memex.mcp_servers import MCPServerEntry

        entry = MCPServerEntry(
            name="git",
            command="npx",
            args=["@modelcontextprotocol/server-git"],
            capability_prefix="git",
        )

        mock_tool = ToolDefinition(
            name="git_log",
            description="Git log",
            source="mcp:git",
            required_capability="git.read",
        )
        mock_client = MagicMock()
        mock_client.available = True
        mock_client.discovered_tools = [mock_tool]
        mock_client_cls.return_value = mock_client

        mock_health = ConnectorHealth(
            name="git",
            status="connected",
            last_check=utcnow(),
            tools_discovered=1,
        )

        with patch("memex.connectors.mcp_client.run_async", return_value=mock_health):
            from memex.loop import _connect_mcp_server_entry

            store = MagicMock()
            registry = MagicMock()
            clients: dict = {}
            health: list = []

            _connect_mcp_server_entry(entry, store, registry, clients, health)

        registry.register.assert_called_once_with(mock_tool)
        assert "git" in clients

    @patch("memex.connectors.mcp_client.MCPClient")
    def test_unavailable_server_not_registered(self, mock_client_cls):
        """If server fails to connect, no tools are registered."""
        from memex.mcp_servers import MCPServerEntry

        entry = MCPServerEntry(name="broken", command="bad")

        mock_client = MagicMock()
        mock_client.available = False
        mock_client_cls.return_value = mock_client

        mock_health = ConnectorHealth(
            name="broken",
            status="unavailable",
            last_check=utcnow(),
            error="connection refused",
        )

        with patch("memex.connectors.mcp_client.run_async", return_value=mock_health):
            from memex.loop import _connect_mcp_server_entry

            store = MagicMock()
            registry = MagicMock()
            clients: dict = {}
            health: list = []

            _connect_mcp_server_entry(entry, store, registry, clients, health)

        registry.register.assert_not_called()
        assert "broken" not in clients
        assert len(health) == 1
        assert health[0].status == "unavailable"


class TestStartupIncludesConfiguredServers:
    @patch("memex.loop._connect_configured_servers")
    @patch("memex.loop._connect_claude_code")
    @patch("memex.loop._connect_mcp")
    def test_startup_calls_configured_servers(
        self, _mock_mcp, _mock_cc, mock_configured
    ):
        """startup_health_check calls _connect_configured_servers."""
        from memex.loop import startup_health_check

        store = MagicMock()
        store.list_goals.return_value = []

        startup_health_check(store)

        mock_configured.assert_called_once()
