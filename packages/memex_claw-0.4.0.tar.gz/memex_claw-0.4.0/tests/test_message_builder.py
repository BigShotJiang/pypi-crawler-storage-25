"""Tests for the MessageBuilder cache-aware message construction system."""

from __future__ import annotations

import os
from unittest.mock import patch


from memex.cache_annotator import (
    AnthropicAnnotator,
    NoOpAnnotator,
    annotator_for_model,
)
from memex.message_builder import MessageBuilder
from memex.utcnow import utcnow


# ---------------------------------------------------------------------------
# annotator_for_model factory
# ---------------------------------------------------------------------------


class TestAnnotatorFactory:
    def test_anthropic_model(self):
        ann = annotator_for_model("anthropic/claude-sonnet-4-20250514")
        assert isinstance(ann, AnthropicAnnotator)

    def test_claude_model(self):
        ann = annotator_for_model("claude-3-opus")
        assert isinstance(ann, AnthropicAnnotator)

    def test_openai_model(self):
        ann = annotator_for_model("openai/gpt-4o")
        assert isinstance(ann, NoOpAnnotator)

    def test_unknown_model(self):
        ann = annotator_for_model("some-other-model")
        assert isinstance(ann, NoOpAnnotator)

    def test_case_insensitive(self):
        ann = annotator_for_model("ANTHROPIC/Claude-Sonnet")
        assert isinstance(ann, AnthropicAnnotator)


# ---------------------------------------------------------------------------
# AnthropicAnnotator
# ---------------------------------------------------------------------------


class TestAnthropicAnnotator:
    def setup_method(self):
        self.annotator = AnthropicAnnotator()

    def test_annotate_system_marks_prefix_block(self):
        """With content blocks, cache_control goes on the last prefix block."""
        msg = {
            "role": "system",
            "content": [
                {"type": "text", "text": "stable prefix"},
                {"type": "text", "text": "dynamic suffix"},
            ],
        }
        result = self.annotator.annotate_system(msg, prefix_block_count=1)

        assert result["role"] == "system"
        content = result["content"]
        assert isinstance(content, list)
        assert len(content) == 2

        # First block: cached prefix
        assert content[0]["type"] == "text"
        assert content[0]["text"] == "stable prefix"
        assert content[0]["cache_control"] == {"type": "ephemeral"}

        # Second block: uncached
        assert content[1]["type"] == "text"
        assert content[1]["text"] == "dynamic suffix"
        assert "cache_control" not in content[1]

    def test_annotate_system_all_blocks_cached(self):
        """When all blocks are prefix, cache_control on last block."""
        msg = {
            "role": "system",
            "content": [
                {"type": "text", "text": "part one"},
                {"type": "text", "text": "part two"},
            ],
        }
        result = self.annotator.annotate_system(msg, prefix_block_count=2)

        content = result["content"]
        assert isinstance(content, list)
        assert len(content) == 2
        # cache_control on last prefix block (index 1)
        assert "cache_control" not in content[0]
        assert content[1]["cache_control"] == {"type": "ephemeral"}

    def test_annotate_system_string_fallback(self):
        """String content is wrapped in a single cached block."""
        msg = {"role": "system", "content": "all cached"}
        result = self.annotator.annotate_system(msg, prefix_block_count=1)

        content = result["content"]
        assert isinstance(content, list)
        assert len(content) == 1
        assert content[0]["cache_control"] == {"type": "ephemeral"}
        assert content[0]["text"] == "all cached"

    def test_annotate_system_zero_prefix_blocks(self):
        """With zero prefix blocks, no cache_control is added."""
        msg = {
            "role": "system",
            "content": [
                {"type": "text", "text": "dynamic only"},
            ],
        }
        result = self.annotator.annotate_system(msg, prefix_block_count=0)
        assert "cache_control" not in result["content"][0]

    def test_annotate_history_adds_cache_control(self):
        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
            {"role": "user", "content": "next question"},
        ]
        result = self.annotator.annotate_history(messages, 1)

        # Message at index 1 should have cache_control
        assert isinstance(result[1]["content"], list)
        assert result[1]["content"][0]["cache_control"] == {"type": "ephemeral"}

        # Other messages unchanged in structure
        assert isinstance(result[0]["content"], str)
        assert isinstance(result[2]["content"], str)

    def test_annotate_history_empty(self):
        result = self.annotator.annotate_history([], 0)
        assert result == []

    def test_annotate_history_out_of_bounds(self):
        messages = [{"role": "user", "content": "hello"}]
        result = self.annotator.annotate_history(messages, 5)
        # Should return unchanged
        assert result == messages

    def test_annotate_history_negative_index(self):
        messages = [{"role": "user", "content": "hello"}]
        result = self.annotator.annotate_history(messages, -1)
        assert result == messages


# ---------------------------------------------------------------------------
# NoOpAnnotator
# ---------------------------------------------------------------------------


class TestNoOpAnnotator:
    def setup_method(self):
        self.annotator = NoOpAnnotator()

    def test_annotate_system_string_unchanged(self):
        """String content passes through unchanged."""
        msg = {"role": "system", "content": "hello world"}
        result = self.annotator.annotate_system(msg, 1)
        assert result["content"] == "hello world"

    def test_annotate_system_flattens_blocks(self):
        """Content blocks are flattened back to a plain string."""
        msg = {
            "role": "system",
            "content": [
                {"type": "text", "text": "part one"},
                {"type": "text", "text": "part two"},
            ],
        }
        result = self.annotator.annotate_system(msg, 1)
        assert isinstance(result["content"], str)
        assert result["content"] == "part one\n\npart two"

    def test_annotate_history_unchanged(self):
        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ]
        result = self.annotator.annotate_history(messages, 0)
        assert result == messages
        assert result is messages  # Same object


# ---------------------------------------------------------------------------
# MessageBuilder — message ordering
# ---------------------------------------------------------------------------


class TestMessageBuilderOrdering:
    def test_basic_build_structure(self):
        """Build produces system, then history, then user input."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("identity", "governance")
        builder.set_system_dynamic("goals", "summary")

        messages = builder.build("Hello")

        assert len(messages) == 2  # system + user
        assert messages[0]["role"] == "system"
        assert messages[-1]["role"] == "user"
        assert messages[-1]["content"] == "Hello"

    def test_system_content_ordering(self):
        """Stable prefix comes before dynamic in system content."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("STABLE")
        builder.set_system_dynamic("DYNAMIC")

        messages = builder.build("Hello")
        system_content = messages[0]["content"]

        stable_pos = system_content.index("STABLE")
        dynamic_pos = system_content.index("DYNAMIC")
        assert stable_pos < dynamic_pos

    def test_history_appears_between_system_and_user(self):
        """History messages are between system and new user input."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("system")
        builder.append_turn("user1", "assistant1")

        messages = builder.build("user2")

        assert len(messages) == 4  # system + user1 + assistant1 + user2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "user1"
        assert messages[2]["role"] == "assistant"
        assert messages[2]["content"] == "assistant1"
        assert messages[3]["role"] == "user"
        assert messages[3]["content"] == "user2"

    def test_empty_parts_filtered(self):
        """Empty strings are filtered from prefix and dynamic parts."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("a", "", "b")
        builder.set_system_dynamic("", "c", "")

        messages = builder.build("Hello")
        system_content = messages[0]["content"]
        assert "a" in system_content
        assert "b" in system_content
        assert "c" in system_content

    def test_build_returns_list_of_dicts(self):
        """build() returns standard OpenAI message format."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("test")
        messages = builder.build("Hello")

        assert isinstance(messages, list)
        for msg in messages:
            assert isinstance(msg, dict)
            assert "role" in msg
            assert "content" in msg

    def test_build_with_no_system_parts(self):
        """build() with no system parts produces valid system message."""
        builder = MessageBuilder("openai/gpt-4o")
        # No set_system_prefix or set_system_dynamic

        messages = builder.build("Hello")

        assert len(messages) == 2  # system + user
        assert messages[0]["role"] == "system"
        # NoOp flattens to string; should be empty, not a list
        assert isinstance(messages[0]["content"], str)

    def test_build_with_no_system_parts_anthropic(self):
        """Anthropic build() with no system parts produces valid content blocks."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")

        messages = builder.build("Hello")

        system_content = messages[0]["content"]
        assert isinstance(system_content, list)
        assert len(system_content) >= 1  # At least the sentinel block


# ---------------------------------------------------------------------------
# MessageBuilder — cache breakpoint advancement
# ---------------------------------------------------------------------------


class TestCacheBreakpoint:
    def test_anthropic_advance_interval(self):
        """Anthropic models advance every 3 turns."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        assert builder._advance_interval == 3

    def test_openai_advance_interval(self):
        """OpenAI models advance every turn."""
        builder = MessageBuilder("openai/gpt-4o")
        assert builder._advance_interval == 1

    def test_third_turn_rule_anthropic(self):
        """Anthropic: breakpoint advances after 3rd turn."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")

        assert builder._cache_breakpoint == 0

        builder.append_turn("u1", "a1")
        assert builder._cache_breakpoint == 0
        assert builder._turns_since_write == 1

        builder.append_turn("u2", "a2")
        assert builder._cache_breakpoint == 0
        assert builder._turns_since_write == 2

        builder.append_turn("u3", "a3")
        # After 3rd turn, breakpoint advances to end of history (6 messages)
        assert builder._cache_breakpoint == 6
        assert builder._turns_since_write == 0

    def test_every_turn_rule_openai(self):
        """OpenAI: breakpoint advances every turn."""
        builder = MessageBuilder("openai/gpt-4o")

        builder.append_turn("u1", "a1")
        assert builder._cache_breakpoint == 2
        assert builder._turns_since_write == 0

        builder.append_turn("u2", "a2")
        assert builder._cache_breakpoint == 4

    def test_breakpoint_continues_advancing(self):
        """Breakpoint keeps advancing as more turns are added."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")

        for i in range(6):
            builder.append_turn(f"u{i}", f"a{i}")

        # After 3 turns: bp=6, after 6 turns: bp=12
        assert builder._cache_breakpoint == 12

    def test_cache_stats(self):
        """cache_stats returns correct diagnostic information."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        builder.set_system_prefix("test")
        builder.append_turn("u1", "a1")

        stats = builder.cache_stats()
        assert stats["cache_breakpoint"] == 0
        assert stats["turns_since_write"] == 1
        assert stats["advance_interval"] == 3
        assert stats["history_length"] == 2
        assert stats["turn_count"] == 1
        assert stats["model"] == "anthropic/claude-sonnet-4-20250514"


# ---------------------------------------------------------------------------
# MessageBuilder — Anthropic annotation in build()
# ---------------------------------------------------------------------------


class TestAnthropicBuildAnnotation:
    def test_system_message_has_content_blocks(self):
        """Anthropic build() produces content blocks with cache_control."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        builder.set_system_prefix("stable")
        builder.set_system_dynamic("dynamic")

        messages = builder.build("Hello")
        system_content = messages[0]["content"]

        # Should be in content-block format
        assert isinstance(system_content, list)
        assert len(system_content) == 2
        # First block (prefix) should have cache_control
        assert system_content[0]["cache_control"] == {"type": "ephemeral"}
        assert system_content[0]["text"] == "stable"
        # Second block (dynamic) should NOT have cache_control
        assert "cache_control" not in system_content[1]
        assert system_content[1]["text"] == "dynamic"

    def test_system_prefix_only_all_cached(self):
        """With prefix only, the single block gets cache_control."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        builder.set_system_prefix("stable only")

        messages = builder.build("Hello")
        system_content = messages[0]["content"]

        assert isinstance(system_content, list)
        assert len(system_content) == 1
        assert system_content[0]["cache_control"] == {"type": "ephemeral"}

    def test_multiple_prefix_parts_single_block(self):
        """Multiple prefix parts are joined into one block."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        builder.set_system_prefix("identity", "governance")
        builder.set_system_dynamic("goals")

        messages = builder.build("Hello")
        system_content = messages[0]["content"]

        assert len(system_content) == 2
        assert "identity" in system_content[0]["text"]
        assert "governance" in system_content[0]["text"]
        assert system_content[0]["cache_control"] == {"type": "ephemeral"}
        assert system_content[1]["text"] == "goals"

    def test_history_annotated_at_breakpoint(self):
        """History messages at breakpoint index get cache_control."""
        builder = MessageBuilder("anthropic/claude-sonnet-4-20250514")
        builder.set_system_prefix("test")

        # Add 3 turns to trigger breakpoint advancement
        for i in range(3):
            builder.append_turn(f"u{i}", f"a{i}")

        messages = builder.build("next")
        # Breakpoint is at 6 (all 6 history messages cached)
        # bp_idx = min(6 - 1, len(history) - 1) = 5
        # In final messages: system(0) + history(1..6) + user(7)
        history_at_bp = messages[6]  # Last message before user input
        if isinstance(history_at_bp["content"], list):
            assert history_at_bp["content"][0]["cache_control"] == {"type": "ephemeral"}


# ---------------------------------------------------------------------------
# MessageBuilder — knowledge dedup
# ---------------------------------------------------------------------------


class TestKnowledgeDedup:
    def test_first_knowledge_not_cached(self):
        """First time setting knowledge, it's not cached."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_knowledge("some knowledge")

        assert not builder._knowledge_is_cached
        assert builder._knowledge_hash is not None

    def test_same_knowledge_is_cached(self):
        """Same knowledge text on second call is detected as cached."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_knowledge("some knowledge")
        builder.set_knowledge("some knowledge")

        assert builder._knowledge_is_cached

    def test_different_knowledge_not_cached(self):
        """Different knowledge text is not cached."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_knowledge("knowledge A")
        builder.set_knowledge("knowledge B")

        assert not builder._knowledge_is_cached

    def test_empty_knowledge_clears_state(self):
        """Setting empty knowledge clears hash and cached flag."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_knowledge("some knowledge")
        builder.set_knowledge("")

        assert builder._knowledge_hash is None
        assert not builder._knowledge_is_cached
        assert builder._knowledge_text == ""

    def test_cached_knowledge_in_prefix(self):
        """When knowledge is cached, it appears in the prefix region."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("STABLE")
        builder.set_system_dynamic("DYNAMIC")

        # Set same knowledge twice to make it cached
        builder.set_knowledge("KNOWLEDGE")
        builder.set_knowledge("KNOWLEDGE")
        assert builder._knowledge_is_cached

        messages = builder.build("Hello")
        system = messages[0]["content"]
        # Knowledge should be between STABLE and DYNAMIC
        stable_pos = system.index("STABLE")
        knowledge_pos = system.index("KNOWLEDGE")
        dynamic_pos = system.index("DYNAMIC")
        assert stable_pos < knowledge_pos < dynamic_pos

    def test_uncached_knowledge_in_dynamic(self):
        """When knowledge is not cached, it appears in the dynamic section."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("STABLE")
        builder.set_system_dynamic("DYNAMIC")
        builder.set_knowledge("KNOWLEDGE")  # First time = uncached

        messages = builder.build("Hello")
        system = messages[0]["content"]
        stable_pos = system.index("STABLE")
        knowledge_pos = system.index("KNOWLEDGE")
        dynamic_pos = system.index("DYNAMIC")
        # Knowledge should be in dynamic region (after prefix)
        assert stable_pos < knowledge_pos
        assert knowledge_pos < dynamic_pos


# ---------------------------------------------------------------------------
# MessageBuilder — fork
# ---------------------------------------------------------------------------


class TestFork:
    def test_fork_shares_prefix(self):
        """Forked builder has same system prefix."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("identity", "governance")
        builder.set_system_dynamic("goals")

        forked = builder.fork()

        assert forked._system_prefix_parts == ["identity", "governance"]
        # Dynamic should be cleared for sub-task
        assert forked._system_dynamic_parts == []

    def test_fork_shares_cached_history(self):
        """Forked builder has history up to cache breakpoint."""
        builder = MessageBuilder("openai/gpt-4o")  # interval=1
        builder.append_turn("u1", "a1")
        builder.append_turn("u2", "a2")
        # OpenAI: breakpoint at 4 (2 turns * 2 messages)

        forked = builder.fork()
        assert len(forked._history) == 4
        assert forked._cache_breakpoint == 4

    def test_fork_independent_appends(self):
        """Forked builder can append independently without affecting parent."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("test")
        builder.append_turn("u1", "a1")

        forked = builder.fork()
        forked.append_turn("fork_u", "fork_a")

        # Parent unchanged
        assert len(builder._history) == 2
        # Fork has additional turn
        assert len(forked._history) == 4

    def test_fork_builds_valid_messages(self):
        """Forked builder produces valid message array."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("system prompt")
        builder.append_turn("u1", "a1")

        forked = builder.fork()
        forked.set_system_dynamic("reflect on this")

        messages = forked.build("What happened last turn?")
        assert messages[0]["role"] == "system"
        assert messages[-1]["role"] == "user"
        assert messages[-1]["content"] == "What happened last turn?"


# ---------------------------------------------------------------------------
# MessageBuilder — tool exchange
# ---------------------------------------------------------------------------


class TestToolExchange:
    def test_append_tool_exchange(self):
        """Tool exchanges are added to history."""
        builder = MessageBuilder("openai/gpt-4o")

        tool_calls = [
            {
                "id": "tc1",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{}"},
            }
        ]
        tool_results = [
            {"role": "tool", "tool_call_id": "tc1", "content": "file contents"}
        ]

        builder.append_tool_exchange(tool_calls, tool_results)

        assert len(builder._history) == 2  # assistant + tool result
        assert builder._history[0]["role"] == "assistant"
        assert builder._history[0]["tool_calls"] == tool_calls
        assert builder._history[0]["content"] is None  # default no response text
        assert builder._history[1]["role"] == "tool"

    def test_append_tool_exchange_with_response_text(self):
        """Tool exchange preserves response_text on assistant message."""
        builder = MessageBuilder("openai/gpt-4o")

        tool_calls = [
            {
                "id": "tc1",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{}"},
            }
        ]
        tool_results = [
            {"role": "tool", "tool_call_id": "tc1", "content": "file contents"}
        ]

        builder.append_tool_exchange(
            tool_calls, tool_results, response_text="Let me check that file."
        )

        assert builder._history[0]["content"] == "Let me check that file."

    def test_tool_exchange_does_not_affect_cache_breakpoint(self):
        """Tool exchanges don't advance the cache breakpoint."""
        builder = MessageBuilder("openai/gpt-4o")

        tool_calls = [
            {
                "id": "tc1",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{}"},
            }
        ]
        tool_results = [
            {"role": "tool", "tool_call_id": "tc1", "content": "file contents"}
        ]

        builder.append_tool_exchange(tool_calls, tool_results)
        assert builder._cache_breakpoint == 0
        assert builder._turns_since_write == 0

    def test_build_after_tool_exchange_includes_tool_messages(self):
        """build() includes tool exchange messages in history."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("system")

        tool_calls = [
            {
                "id": "tc1",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{}"},
            }
        ]
        tool_results = [
            {"role": "tool", "tool_call_id": "tc1", "content": "file contents"}
        ]

        builder.append_tool_exchange(
            tool_calls, tool_results, response_text="Checking..."
        )

        messages = builder.build("continue")
        # system + assistant(tool_calls) + tool_result + user
        assert len(messages) == 4
        assert messages[1]["role"] == "assistant"
        assert messages[1]["tool_calls"] == tool_calls
        assert messages[2]["role"] == "tool"
        assert messages[3]["role"] == "user"


# ---------------------------------------------------------------------------
# Feature flag
# ---------------------------------------------------------------------------


class TestFeatureFlag:
    def test_flag_disabled_by_default(self):
        """Without MEMEX_CACHE_ENABLED, the flag is off."""
        from memex.loop import _use_message_builder

        with patch.dict(os.environ, {}, clear=True):
            # Remove MEMEX_CACHE_ENABLED if set
            os.environ.pop("MEMEX_CACHE_ENABLED", None)
            assert not _use_message_builder()

    def test_flag_enabled(self):
        """With MEMEX_CACHE_ENABLED=1, the flag is on."""
        from memex.loop import _use_message_builder

        with patch.dict(os.environ, {"MEMEX_CACHE_ENABLED": "1"}):
            assert _use_message_builder()

    def test_flag_disabled_explicit(self):
        """With MEMEX_CACHE_ENABLED=0, the flag is off."""
        from memex.loop import _use_message_builder

        with patch.dict(os.environ, {"MEMEX_CACHE_ENABLED": "0"}):
            assert not _use_message_builder()


# ---------------------------------------------------------------------------
# SessionContext cache fields
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# MessageBuilder — observation masking
# ---------------------------------------------------------------------------


class TestObservationMasking:
    """Tests for Phase 2: Observation Masking."""

    def _make_tool_calls(self, name: str = "read_file", tc_id: str = "tc1"):
        return [
            {
                "id": tc_id,
                "type": "function",
                "function": {"name": name, "arguments": "{}"},
            }
        ]

    def _make_tool_results(self, content: str = "file contents", tc_id: str = "tc1"):
        return [{"role": "tool", "tool_call_id": tc_id, "content": content}]

    def test_previous_turn_tool_results_masked(self):
        """Tool result from turn 0 is masked after turn 1 begins."""
        builder = MessageBuilder("openai/gpt-4o")

        # Turn 0: tool exchange then complete the turn
        builder.append_tool_exchange(
            self._make_tool_calls("read_file"),
            self._make_tool_results("x" * 100),
        )
        builder.append_turn("u1", "a1")

        # Now in turn 1 — build should mask the turn-0 tool result
        messages = builder.build("u2")

        # Find the tool result message
        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["content"] == "[read_file: 100 chars of output]"

    def test_current_turn_tool_results_preserved(self):
        """Tool result within the current turn is NOT masked."""
        builder = MessageBuilder("openai/gpt-4o")

        # Tool exchange in current turn (no append_turn yet)
        builder.append_tool_exchange(
            self._make_tool_calls("search"),
            self._make_tool_results("search results here"),
        )

        messages = builder.build("continue")

        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["content"] == "search results here"

    def test_masking_format(self):
        """Verify the masked content format [tool_name: N chars of output]."""
        result = MessageBuilder._make_masked_content("execute_code", 42)
        assert result == "[execute_code: 42 chars of output]"

        result2 = MessageBuilder._make_masked_content("read_file", 0)
        assert result2 == "[read_file: 0 chars of output]"

    def test_fork_preserves_metadata(self):
        """Forked builder preserves tool metadata on history entries."""
        builder = MessageBuilder("openai/gpt-4o")

        builder.append_tool_exchange(
            self._make_tool_calls("read_file"),
            self._make_tool_results("some content"),
        )
        builder.append_turn("u1", "a1")
        # OpenAI advances breakpoint every turn, so bp includes tool exchange + turn

        forked = builder.fork()

        # Find tool result in forked history
        tool_msgs = [m for m in forked._history if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["_tool_name"] == "read_file"
        assert tool_msgs[0]["_turn_index"] == 0
        assert tool_msgs[0]["_char_count"] == len("some content")

    def test_compact_history_trims(self):
        """compact_history reduces history when over limit."""
        builder = MessageBuilder("openai/gpt-4o")

        # Add many turns to exceed limit
        for i in range(50):
            builder.append_turn(f"u{i}", f"a{i}")

        assert len(builder._history) == 100  # 50 turns * 2 messages

        builder.compact_history(max_entries=20)

        assert len(builder._history) <= 20

    def test_compact_history_no_op_under_limit(self):
        """compact_history does nothing when under limit."""
        builder = MessageBuilder("openai/gpt-4o")

        builder.append_turn("u1", "a1")
        builder.append_turn("u2", "a2")

        original_len = len(builder._history)
        builder.compact_history(max_entries=80)

        assert len(builder._history) == original_len

    def test_cache_stats_masked_count(self):
        """masked_tool_results count appears in cache_stats."""
        builder = MessageBuilder("openai/gpt-4o")

        # Turn 0: tool exchange
        builder.append_tool_exchange(
            self._make_tool_calls("read_file", "tc1"),
            self._make_tool_results("content1", "tc1"),
        )
        builder.append_turn("u1", "a1")

        # Turn 0 is now complete (_turn_count=1). Its tool result is maskable.
        stats = builder.cache_stats()
        assert "masked_tool_results" in stats
        assert stats["masked_tool_results"] == 1

        # Turn 1: another tool exchange
        builder.append_tool_exchange(
            self._make_tool_calls("search", "tc2"),
            self._make_tool_results("content2", "tc2"),
        )
        builder.append_turn("u2", "a2")

        # Now _turn_count=2. Both turn 0 and turn 1 tool results are maskable.
        stats = builder.cache_stats()
        assert stats["masked_tool_results"] == 2

    def test_metadata_stripped_from_build_output(self):
        """build() output should not contain internal metadata keys."""
        builder = MessageBuilder("openai/gpt-4o")

        builder.append_tool_exchange(
            self._make_tool_calls("read_file"),
            self._make_tool_results("content"),
        )

        messages = builder.build("hello")
        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        for msg in tool_msgs:
            assert "_tool_name" not in msg
            assert "_turn_index" not in msg
            assert "_char_count" not in msg

    def test_multiple_tool_results_in_same_turn(self):
        """Multiple tool calls/results in one turn are all annotated and masked correctly."""
        builder = MessageBuilder("openai/gpt-4o")

        tool_calls = [
            {
                "id": "tc1",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{}"},
            },
            {
                "id": "tc2",
                "type": "function",
                "function": {"name": "search", "arguments": "{}"},
            },
        ]
        tool_results = [
            {"role": "tool", "tool_call_id": "tc1", "content": "file contents here"},
            {"role": "tool", "tool_call_id": "tc2", "content": "search results"},
        ]

        builder.append_tool_exchange(tool_calls, tool_results)

        # Verify both results have correct metadata
        tool_msgs = [m for m in builder._history if m.get("role") == "tool"]
        assert len(tool_msgs) == 2
        assert tool_msgs[0]["_tool_name"] == "read_file"
        assert tool_msgs[0]["_char_count"] == len("file contents here")
        assert tool_msgs[1]["_tool_name"] == "search"
        assert tool_msgs[1]["_char_count"] == len("search results")

        # Complete turn, then verify masking
        builder.append_turn("u1", "a1")
        messages = builder.build("next")

        tool_in_output = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_in_output) == 2
        assert (
            tool_in_output[0]["content"]
            == f"[read_file: {len('file contents here')} chars of output]"
        )
        assert (
            tool_in_output[1]["content"]
            == f"[search: {len('search results')} chars of output]"
        )

    def test_tool_result_missing_metadata_not_masked(self):
        """Tool results without metadata are left unchanged (defensive)."""
        builder = MessageBuilder("openai/gpt-4o")

        # Manually add a tool result without metadata
        builder._history.append(
            {
                "role": "tool",
                "tool_call_id": "tc1",
                "content": "original content",
            }
        )
        builder._turn_count = 1  # Simulate completed turn

        messages = builder.build("next")

        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["content"] == "original content"

    def test_build_called_multiple_times_consistent(self):
        """Calling build() multiple times produces consistent structure."""
        builder = MessageBuilder("openai/gpt-4o")
        builder.set_system_prefix("system")
        builder.append_turn("u1", "a1")

        messages1 = builder.build("query1")
        messages2 = builder.build("query2")

        # Structure should be identical except user input
        assert len(messages1) == len(messages2)
        assert messages1[0] == messages2[0]  # system
        assert messages1[1:-1] == messages2[1:-1]  # history
        assert messages1[-1]["content"] == "query1"
        assert messages2[-1]["content"] == "query2"

    def test_metadata_preserved_in_internal_history(self):
        """Internal _history still has metadata after build()."""
        builder = MessageBuilder("openai/gpt-4o")

        builder.append_tool_exchange(
            self._make_tool_calls("read_file"),
            self._make_tool_results("content"),
        )

        builder.build("hello")

        # Internal history should still have metadata
        tool_msgs = [m for m in builder._history if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        assert tool_msgs[0]["_tool_name"] == "read_file"
        assert tool_msgs[0]["_turn_index"] == 0
        assert tool_msgs[0]["_char_count"] == len("content")


class TestSessionContextCacheFields:
    def test_default_cache_fields(self):
        """SessionContext has default cache fields."""
        from memex.models import SessionContext

        session = SessionContext(session_id="test", started_at=utcnow())
        assert session.cache_breakpoint == 0
        assert session.turns_since_cache_write == 0
        assert session.last_knowledge_hash is None
