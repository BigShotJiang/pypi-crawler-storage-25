"""Tests for auth credential store."""

import os
import platform
import stat
from datetime import timedelta

import pytest

from memex.auth.store import (
    delete_credentials,
    get_credentials,
    is_token_expired,
    list_services,
    save_credentials,
)
from memex.utcnow import utcnow


def test_save_and_get_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    save_credentials("test", {"access_token": "abc123"})
    creds = get_credentials("test")
    assert creds is not None
    assert creds["access_token"] == "abc123"
    assert creds["service"] == "test"
    assert "saved_at" in creds


def test_get_nonexistent(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    creds = get_credentials("nonexistent")
    assert creds is None


def test_delete_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    save_credentials("deleteme", {"token": "xyz"})
    assert get_credentials("deleteme") is not None

    delete_credentials("deleteme")
    assert get_credentials("deleteme") is None


def test_list_services(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    save_credentials("service_a", {"token": "a"})
    save_credentials("service_b", {"token": "b"})
    save_credentials("service_c", {"token": "c"})

    services = list_services()
    assert "service_a" in services
    assert "service_b" in services
    assert "service_c" in services
    assert len(services) == 3


def test_token_expired():
    # Token expired 1 hour ago
    past = utcnow() - timedelta(hours=1)
    token_data = {"expires_at": past.isoformat()}
    assert is_token_expired(token_data) is True

    # Token as unix timestamp in the past
    token_data_ts = {"expires_at": past.timestamp()}
    assert is_token_expired(token_data_ts) is True


def test_token_not_expired():
    # Token expires 1 hour from now
    future = utcnow() + timedelta(hours=1)
    token_data = {"expires_at": future.isoformat()}
    assert is_token_expired(token_data) is False

    # No expires_at field means not expired
    assert is_token_expired({}) is False

    # Token as unix timestamp in the future
    token_data_ts = {"expires_at": future.timestamp()}
    assert is_token_expired(token_data_ts) is False


@pytest.mark.skipif(
    platform.system() == "Windows", reason="File permissions not reliable on Windows"
)
def test_file_permissions(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    save_credentials("secure_test", {"secret": "value"})

    cred_file = tmp_path / ".memex" / "auth" / "secure_test.json"
    assert cred_file.exists()

    file_stat = os.stat(cred_file)
    mode = stat.S_IMODE(file_stat.st_mode)
    # Should be 0600 (owner read/write only)
    assert mode == 0o600
