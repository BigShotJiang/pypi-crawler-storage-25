"""Tests for SkillConfigRegistry."""

from memex.skills.config_registry import SkillConfigRegistry


def test_register_and_satisfy():
    reg = SkillConfigRegistry()
    reg.register("my.key", lambda: True)
    assert reg.is_satisfied("my.key") is True


def test_unsatisfied_check():
    reg = SkillConfigRegistry()
    reg.register("my.key", lambda: False)
    assert reg.is_satisfied("my.key") is False


def test_unknown_key_returns_false():
    reg = SkillConfigRegistry()
    assert reg.is_satisfied("unknown.key") is False


def test_unregister():
    reg = SkillConfigRegistry()
    reg.register("my.key", lambda: True)
    reg.unregister("my.key")
    assert reg.is_satisfied("my.key") is False


def test_unregister_unknown_is_noop():
    reg = SkillConfigRegistry()
    reg.unregister("nonexistent")  # should not raise
