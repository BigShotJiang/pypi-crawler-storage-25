"""Tests for MCP client — uses mocks, no real subprocess."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from memex.connectors.mcp_client import MCPClient, MCPClientConfig, run_async
from memex.utcnow import utcnow


@pytest.fixture
def config():
    return MCPClientConfig(
        name="test",
        command="echo",
        args=["hello"],
        timeout_seconds=5.0,
        capability_prefix="test",
    )


def test_config_defaults():
    cfg = MCPClientConfig(name="x", command="y")
    assert cfg.timeout_seconds == 30.0
    assert cfg.args == []
    assert cfg.capability_prefix == ""


def test_client_initial_state(config):
    client = MCPClient(config)
    assert not client.available
    assert client.discovered_tools == []


def test_call_tool_when_not_connected(config):
    client = MCPClient(config)
    result = run_async(client.call_tool("test_tool", {"q": "hi"}))
    assert not result.success
    assert result.error == "Client not connected"


def test_run_async_basic():
    async def add(a, b):
        return a + b

    assert run_async(add(1, 2)) == 3


@pytest.mark.asyncio
async def test_connect_timeout(config):
    """Connection that exceeds timeout returns unavailable."""
    config.timeout_seconds = 0.01

    async def slow_connect():
        await asyncio.sleep(10)

    client = MCPClient(config)
    with patch.object(client, "_do_connect", side_effect=slow_connect):
        health = await client.connect()
    assert health.status == "unavailable"
    assert not client.available


@pytest.mark.asyncio
async def test_connect_error(config):
    """Connection error returns unavailable."""
    client = MCPClient(config)
    with patch.object(client, "_do_connect", side_effect=RuntimeError("boom")):
        health = await client.connect()
    assert health.status == "unavailable"
    assert "boom" in health.error


@pytest.mark.asyncio
async def test_connect_success(config):
    """Successful connection returns connected health."""
    client = MCPClient(config)

    async def mock_connect():
        client._available = True
        client._discovered_tools = []
        from memex.models import ConnectorHealth

        return ConnectorHealth(
            name="test", status="connected", last_check=utcnow(), tools_discovered=3
        )

    with patch.object(client, "_do_connect", side_effect=mock_connect):
        health = await client.connect()
    assert health.status == "connected"
    assert health.tools_discovered == 3
    assert client.available


@pytest.mark.asyncio
async def test_call_tool_timeout(config):
    """Tool call that times out returns failure."""
    config.timeout_seconds = 0.01
    client = MCPClient(config)
    client._available = True
    client._session = MagicMock()

    async def slow_call(name, args):
        await asyncio.sleep(10)

    with patch.object(client, "_do_call", side_effect=slow_call):
        result = await client.call_tool("test", {"q": "hi"})
    assert not result.success
    assert "Timeout" in result.error


@pytest.mark.asyncio
async def test_disconnect(config):
    client = MCPClient(config)
    client._available = True
    client._session = MagicMock()
    client._session_cm = AsyncMock()
    client._cm = AsyncMock()

    await client.disconnect()
    assert not client.available
    assert client._session is None
    assert client.discovered_tools == []
