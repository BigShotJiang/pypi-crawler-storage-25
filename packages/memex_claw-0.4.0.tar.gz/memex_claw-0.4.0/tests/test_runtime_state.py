from memex.runtime_state import RuntimeStateRegistry


def test_activity_lifecycle():
    registry = RuntimeStateRegistry()

    registry.start_activity("a1", label="Fetching", source="ingest")
    snapshot = registry.snapshot()
    assert snapshot["activities"][0]["label"] == "Fetching"

    registry.update_activity("a1", label="Ingesting")
    snapshot = registry.snapshot()
    assert snapshot["activities"][0]["label"] == "Ingesting"

    registry.finish_activity("a1", success=True)
    snapshot = registry.snapshot()
    assert snapshot["activities"] == []


def test_queue_and_recording_state():
    registry = RuntimeStateRegistry()

    registry.set_queue_state(
        "work_queue", pending_count=2, is_paused=False, running_count=1
    )
    registry.set_active_recording(
        {
            "meeting_id": "m1",
            "recording_id": "r1",
            "paused": False,
        }
    )

    snapshot = registry.snapshot()
    assert snapshot["queues"]["work_queue_pending"] == 2
    assert snapshot["queues"]["work_queue_running"] == 1
    assert snapshot["meetings"]["active_recording"]["meeting_id"] == "m1"


def test_session_and_interface_defaults():
    registry = RuntimeStateRegistry()
    registry.set_session(
        session_id="sess-1",
        turn_count=4,
        active_interface="tui",
        session_cost_usd=1.25,
    )

    snapshot = registry.snapshot()
    assert snapshot["session"]["active_interface"] == "tui"
    assert snapshot["session"]["session_cost_usd"] == 1.25
    interface_names = {item["name"] for item in snapshot["interfaces"]}
    assert "meeting_capture" in interface_names
    assert "transcription_engine" in interface_names
