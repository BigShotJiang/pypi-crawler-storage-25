from __future__ import annotations


from memex.models import Goal, GoalPriority, GoalStatus
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.tools_builtin import _STORES, configure_stores, execute_builtin
from memex.utcnow import utcnow


def test_search_knowledge_and_get_item_surface_world_model_dependency_documents(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    blocker = Goal(
        goal_id="goal-review",
        title="Final review",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    goal = Goal(
        goal_id="goal-docs",
        title="Ship docs update",
        status=GoalStatus.BLOCKED,
        priority=GoalPriority.HIGH,
        blocked_by_goal_id="goal-review",
        blocked_reason="Waiting on final review",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(blocker)
    store.create_goal(goal)
    configure_stores(
        content_store=store.content, memex_store=store, scheduler_store=store.scheduler
    )

    try:
        search = execute_builtin(
            "search_knowledge", {"query": "ship docs update final review"}
        )

        assert search.success
        assert "world_model_dependency:" in search.content
        dependency_id = (
            search.content.split("ID: world_model_dependency:", 1)[1]
            .splitlines()[0]
            .strip()
        )

        detail = execute_builtin(
            "get_item", {"id": f"world_model_dependency:{dependency_id}"}
        )

        assert detail.success
        assert "Type: dependency | ID: world_model_dependency:" in detail.content
        assert "Relationship: blocked_by" in detail.content
        assert "Source: world_model_goal:goal-docs" in detail.content
        assert "Target: world_model_goal:goal-review" in detail.content
    finally:
        _STORES.clear()
