"""Tests for scheduler built-in tasks registry."""

from __future__ import annotations

from memex.models import ActionType
from memex.scheduler.builtins import _BUILTIN_IDS, get_builtin_tasks


def test_nightly_vec_regeneration_has_stable_builtin_id():
    """The nightly_vec_regeneration builtin must have a stable deterministic id
    so reseeding does not create duplicate rows."""
    assert "nightly_vec_regeneration" in _BUILTIN_IDS
    assert _BUILTIN_IDS["nightly_vec_regeneration"].startswith("builtin-")


def test_nightly_vec_regeneration_task_registered():
    """get_builtin_tasks() must include a CALLABLE entry for nightly_vec_regeneration
    so the scheduler seeds and enqueues it on schedule."""
    tasks = get_builtin_tasks()
    matching = [
        t
        for t in tasks
        if t.action_type == ActionType.CALLABLE
        and t.action_data.get("callable") == "nightly_vec_regeneration"
    ]
    assert len(matching) == 1
    task = matching[0]
    assert task.builtin is True
    assert task.enabled is True
    assert task.cron_expr == "0 3 * * *"
    assert task.task_id == _BUILTIN_IDS["nightly_vec_regeneration"]
