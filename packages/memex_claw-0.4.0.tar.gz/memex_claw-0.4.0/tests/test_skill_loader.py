"""Tests for SkillLoader and SKILL.md parsing."""

from pathlib import Path


from memex.skills.config_registry import SkillConfigRegistry
from memex.skills.loader import SkillLoader

FIXTURES = Path(__file__).parent / "fixtures" / "skills"


def test_parse_basic_skill():
    loader = SkillLoader([FIXTURES])
    skills = loader.load_all()
    names = {s.name for s in skills}
    assert "test-skill" in names


def test_parse_frontmatter_fields():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    skill = skills["test-skill"]
    assert skill.description == "A test skill for unit tests"
    assert skill.version == "1.0.0"
    assert skill.user_invocable is True
    assert skill.emoji == "🧪"


def test_basedir_substitution():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    skill = skills["basedir-skill"]
    basedir_str = str(FIXTURES / "basedir-skill")
    assert basedir_str in skill.body
    assert "{baseDir}" not in skill.body


def test_env_requirement_missing(monkeypatch):
    monkeypatch.delenv("TEST_SKILL_API_KEY", raising=False)
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "env-skill" not in skills


def test_env_requirement_met(monkeypatch):
    monkeypatch.setenv("TEST_SKILL_API_KEY", "abc123")
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "env-skill" in skills


def test_bin_requirement_missing():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "bin-skill" not in skills


def test_anybin_requirement_met():
    """python3 or python should be available in test env."""
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "anybin-skill" in skills


def test_config_requirement_missing():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    # No config registry → config requirements fail
    assert "config-skill" not in skills


def test_config_requirement_satisfied():
    config_reg = SkillConfigRegistry()
    config_reg.register("channels.discord.token", lambda: True)
    loader = SkillLoader([FIXTURES], config_registry=config_reg)
    skills = {s.name: s for s in loader.load_all()}
    assert "config-skill" in skills


def test_malformed_skill_skipped():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "malformed-skill" not in skills


def test_incompatibility_detection():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    skill = skills["incompatible-skill"]
    assert "browser" in skill.incompatible_tools
    assert "canvas" in skill.incompatible_tools


def test_disabled_skill_loaded():
    loader = SkillLoader([FIXTURES])
    skills = {s.name: s for s in loader.load_all()}
    assert "disabled-skill" in skills
    assert skills["disabled-skill"].disable_model_invocation is True


def test_precedence_ordering(tmp_path):
    """Higher-precedence dir (later in list) overrides lower."""
    low = tmp_path / "low"
    high = tmp_path / "high"
    skill_dir_low = low / "my-skill"
    skill_dir_high = high / "my-skill"
    skill_dir_low.mkdir(parents=True)
    skill_dir_high.mkdir(parents=True)

    (skill_dir_low / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: low\nversion: 1.0.0\n---\n\nLow body"
    )
    (skill_dir_high / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: high\nversion: 2.0.0\n---\n\nHigh body"
    )

    loader = SkillLoader([low, high])
    skills = {s.name: s for s in loader.load_all()}
    assert skills["my-skill"].description == "high"
    assert skills["my-skill"].version == "2.0.0"


def test_fallback_yaml_multiline_list(tmp_path):
    """Fallback YAML parser handles multi-line lists."""
    skill_dir = tmp_path / "multi-list"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        "---\n"
        "name: multi-list\n"
        "description: test\n"
        "version: 1.0.0\n"
        "metadata:\n"
        "  openclaw:\n"
        "    requires:\n"
        "      bins:\n"
        "        - python3\n"
        "        - bash\n"
        "---\n\n"
        "Body here"
    )
    loader = SkillLoader([tmp_path])
    skills = {s.name: s for s in loader.load_all()}
    skill = skills["multi-list"]
    assert skill.requires_bins == ["python3", "bash"]


def test_nonexistent_dir():
    loader = SkillLoader([Path("/nonexistent/dir")])
    skills = loader.load_all()
    assert skills == []


def test_empty_dir(tmp_path):
    loader = SkillLoader([tmp_path])
    skills = loader.load_all()
    assert skills == []
