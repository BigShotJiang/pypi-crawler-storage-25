"""Tests for route-driven runtime retrieval policy."""

from __future__ import annotations


from memex.loop import _should_auto_retrieve_for_turn
from memex.models import (
    InputClassification,
    InputClassificationType,
    IntentFrame,
    IntentFramePath,
    PromptControlArtifact,
    PromptControlRouteProfile,
)
from memex.utcnow import utcnow


def _artifact(
    *,
    route_profile: PromptControlRouteProfile,
    memory_policy: str,
    selected_path: str = "direct_answer",
) -> PromptControlArtifact:
    now = utcnow()
    return PromptControlArtifact(
        artifact_id="pc:test",
        session_id="session-test",
        raw_input="test",
        classification="conversational",
        selected_path=selected_path,
        route_profile=route_profile,
        tool_policy="test",
        validation_policy="test",
        memory_policy=memory_policy,
        response_contract="test",
        created_at=now,
        updated_at=now,
    )


def _intent(path: IntentFramePath = IntentFramePath.DIRECT_ANSWER) -> IntentFrame:
    return IntentFrame(
        raw_input="test",
        classification=InputClassificationType.CONVERSATIONAL,
        selected_path=path,
        created_at=utcnow(),
    )


def test_knowledge_query_always_retrieves():
    assert _should_auto_retrieve_for_turn(
        InputClassification(classification=InputClassificationType.KNOWLEDGE_QUERY),
        prompt_control_artifact=None,
        intent_frame=_intent(),
    )


def test_analytic_route_retrieves_for_conversational_turns():
    assert _should_auto_retrieve_for_turn(
        InputClassification(classification=InputClassificationType.CONVERSATIONAL),
        prompt_control_artifact=_artifact(
            route_profile=PromptControlRouteProfile.ANALYTIC_STRICT,
            memory_policy="preferences_only",
        ),
        intent_frame=_intent(),
    )


def test_operational_tool_route_retrieves_for_act_turns():
    assert _should_auto_retrieve_for_turn(
        InputClassification(classification=InputClassificationType.ADVANCES_GOAL),
        prompt_control_artifact=_artifact(
            route_profile=PromptControlRouteProfile.OPERATIONAL_TOOL,
            memory_policy="task_state",
            selected_path="act",
        ),
        intent_frame=_intent(IntentFramePath.ACT),
    )


def test_creative_open_route_skips_auto_retrieval():
    assert not _should_auto_retrieve_for_turn(
        InputClassification(classification=InputClassificationType.CONVERSATIONAL),
        prompt_control_artifact=_artifact(
            route_profile=PromptControlRouteProfile.CREATIVE_OPEN,
            memory_policy="no_memory_by_default",
        ),
        intent_frame=_intent(),
    )


def test_social_draft_route_skips_auto_retrieval():
    assert not _should_auto_retrieve_for_turn(
        InputClassification(classification=InputClassificationType.CONVERSATIONAL),
        prompt_control_artifact=_artifact(
            route_profile=PromptControlRouteProfile.SOCIAL_DRAFT,
            memory_policy="user_requested_only",
        ),
        intent_frame=_intent(),
    )
