from __future__ import annotations

from unittest.mock import patch

from memex.meetings.models import MeetingRecord, MeetingState
from memex.memory.retrieval import retrieve_for_context
from memex.memory.world_model_reads import resolve_world_model_reads
from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    WorldModelAction,
    WorldModelCommitment,
    WorldModelEvent,
    WorldModelTask,
)
from memex.remember import RememberClassification, RememberIntent, execute_remember
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.world_model_backbone import build_world_model_provenance_link
from memex.utcnow import utcnow


def test_goal_create_and_update_syncs_canonical_world_model_goal(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    blocker = Goal(
        goal_id="goal-blocker",
        title="Final review",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(blocker)
    goal = Goal(
        goal_id="goal-canonical-1",
        parent_id="goal-blocker",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={"origin": "manual"},
    )

    store.create_goal(goal)
    canonical = store.load_world_model_goal(goal.goal_id)

    assert canonical is not None
    assert canonical.goal_id == goal.goal_id
    assert canonical.title == "Ship docs update"
    assert canonical.status == "active"
    assert canonical.priority == "high"
    assert canonical.payload["origin"] == "manual"
    assert canonical.source_surface == "c08_world_model_goal"

    goal.status = GoalStatus.BLOCKED
    goal.blocked_by_goal_id = "goal-blocker"
    goal.blocked_reason = "Waiting on review"
    goal.updated_at = utcnow()
    store.update_goal(goal)

    updated = store.load_world_model_goal(goal.goal_id)
    assert updated is not None
    assert updated.status == "blocked"
    assert updated.blocked_reason == "Waiting on review"
    links = store.list_world_model_provenance_links(
        source_record_type="world_model_goal",
        source_record_id=goal.goal_id,
    )
    assert any(
        link.relationship == "child_of" and link.target_record_id == "goal-blocker"
        for link in links
    )
    assert any(
        link.relationship == "blocked_by" and link.target_record_id == "goal-blocker"
        for link in links
    )


def test_reminder_goal_is_available_as_canonical_goal_document(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    content_store = store.content
    scheduler_store = store.scheduler

    mock_result = RememberClassification(
        intent=RememberIntent.REMINDER,
        title="Call mom",
        body="Call mom to check in",
        tags=["personal"],
        reminder_time="2026-03-12T15:00:00",
        is_actionable=True,
    )

    with patch("memex.llm.chat_structured", return_value=mock_result):
        result = execute_remember(
            "remind me to call mom Tuesday at 3pm",
            content_store=content_store,
            memex_store=store,
            scheduler_store=scheduler_store,
        )

    goal = store.load_world_model_goal(result["goal_id"])

    assert goal is not None
    assert goal.title == "Call mom"
    assert goal.status == "active"
    assert goal.priority == "medium"


def test_retrieve_can_surface_world_model_goal_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    content_store = store.content
    now = utcnow()
    goal = Goal(
        goal_id="goal-retrieve-1",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.BLOCKED,
        priority=GoalPriority.HIGH,
        blocked_reason="Waiting on final review",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_task(
        WorldModelTask(
            task_id="task-goal-retrieve-1",
            scheduled_task_id=None,
            goal_id=goal.goal_id,
            task_kind="scheduled_reminder",
            title="Prepare release summary",
            description="Prepare release summary",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_commitment(
        WorldModelCommitment(
            commitment_id="commitment-goal-retrieve-1",
            source_record_type="meeting_artifact",
            source_record_id="artifact-goal-retrieve-1",
            meeting_id="meeting-goal-retrieve-1",
            semantic_item_id=None,
            goal_id=goal.goal_id,
            title="Ship docs update",
            description="Committed in meeting",
            assignee="Corey",
            agreed_by="Corey",
            status="active",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    result = retrieve_for_context(
        "ship docs waiting final review",
        2000,
        content_store=content_store,
        world_model_store=store,
    )

    assert "Ship docs update" in result.text
    assert "Status: blocked" in result.text
    assert (
        "linked_from advances_goal <- world_model_task:task-goal-retrieve-1"
        in result.text
    )
    assert (
        "linked_from updates_goal <- world_model_commitment:commitment-goal-retrieve-1"
        in result.text
    )
    assert any(doc_id.startswith("world_model_goal:") for doc_id in result.document_ids)


def test_goal_document_incoming_links_include_execution_context(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-execution-neighborhood",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action(
        WorldModelAction(
            action_id="session:s2:action:turn:3:selected",
            session_id="session:s2",
            intent_id="intent:s2:3",
            prompt_control_artifact_id=None,
            conversation_turn_id=3,
            action_kind="selected_action",
            action_name="answer_with_followup",
            status="succeeded",
            payload={"selected_action": {"name": "answer_with_followup"}},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_event(
        WorldModelEvent(
            event_id="session:s2:event:turn:3",
            session_id="session:s2",
            conversation_turn_id=3,
            event_kind="turn_outcome",
            title="Turn event: docs follow-up",
            summary="Prepared the docs follow-up turn",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_action",
            "session:s2:action:turn:3:selected",
            "world_model_goal",
            "goal-execution-neighborhood",
            "for_goal",
            created_at=now,
        )
    )
    store.upsert_world_model_provenance_link(
        build_world_model_provenance_link(
            "world_model_event",
            "session:s2:event:turn:3",
            "world_model_goal",
            "goal-execution-neighborhood",
            "for_goal",
            created_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hit = reads.load_goal_document("goal-execution-neighborhood")

    assert hit is not None
    assert any(
        link["relationship"] == "for_goal"
        and link["source_record_type"] == "world_model_action"
        and link["source_record_id"] == "session:s2:action:turn:3:selected"
        for link in hit.incoming_links
    )
    assert any(
        link["relationship"] == "for_goal"
        and link["source_record_type"] == "world_model_event"
        and link["source_record_id"] == "session:s2:event:turn:3"
        for link in hit.incoming_links
    )


def test_goal_document_incoming_links_include_promoted_meeting_goal_links(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-meeting-promotion",
        title="Ship docs update",
        description="Publish the updated architecture docs.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    meeting = MeetingRecord(
        meeting_id="mtg-goal-neighborhood",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        action_items=[
            {"text": "Ship docs update", "promoted_goal_id": "goal-meeting-promotion"}
        ],
        created_at=now,
        updated_at=now,
    )
    store.meetings.create_meeting(meeting)

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    hit = reads.load_goal_document("goal-meeting-promotion")

    assert hit is not None
    assert any(
        link["relationship"] == "promoted_action_item"
        and link["source_record_type"] == "meeting"
        and link["source_record_id"] == "mtg-goal-neighborhood"
        and link["source_title"] == "Architecture Review"
        for link in hit.incoming_links
    )
