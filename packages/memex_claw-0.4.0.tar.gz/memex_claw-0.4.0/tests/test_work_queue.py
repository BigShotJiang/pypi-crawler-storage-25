"""Tests for WorkQueue."""

import time

from memex.models import ActionType
from memex.runtime_state import RuntimeStateRegistry
from memex.scheduler.work_queue import LLMUnavailableError, WorkItem, WorkQueue
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


def _make_item(
    task_id: str = "t1",
    run_id: int = 1,
    priority: int = 0,
    action_type: str = "notification",
    action_data: dict | None = None,
    max_retries: int = 3,
) -> WorkItem:
    return WorkItem(
        priority=priority,
        task_id=task_id,
        run_id=run_id,
        action_type=action_type,
        action_data=action_data or {},
        max_retries=max_retries,
    )


def test_enqueue_dequeue_order(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    q = WorkQueue(max_workers=1, scheduler_store=ss)

    # Enqueue with different priorities (lower = higher priority)
    q.enqueue(_make_item(task_id="low", run_id=1, priority=5))
    q.enqueue(_make_item(task_id="high", run_id=2, priority=0))
    q.enqueue(_make_item(task_id="mid", run_id=3, priority=2))

    # Dequeue should come out in priority order
    items = []
    while q.pending_count > 0:
        item = q._queue.get(timeout=1)
        items.append(item)

    assert items[0].task_id == "high"
    assert items[1].task_id == "mid"
    assert items[2].task_id == "low"
    store.close()


def test_dispatch_success(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler

    # Create a task in the store so the run can reference it
    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="t1",
            name="Test",
            cron_expr="0 9 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("t1", status="queued")

    q = WorkQueue(max_workers=1, scheduler_store=ss)
    q.register_dispatcher("notification", lambda data, rid: "ok")
    q.start()

    q.enqueue(_make_item(task_id="t1", run_id=run_id, action_type="notification"))

    # Wait for processing
    time.sleep(1.0)
    q.stop(timeout=5)

    run = ss.get_last_run("t1")
    assert run is not None
    assert run.status == "completed"
    store.close()


def test_dispatch_failure_retry(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler

    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="t1",
            name="Test",
            cron_expr="0 9 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("t1", status="queued")

    call_count = {"n": 0}

    def failing_dispatcher(data, rid):
        call_count["n"] += 1
        if call_count["n"] <= 1:
            raise RuntimeError("transient error")
        return "recovered"

    q = WorkQueue(max_workers=1, scheduler_store=ss)
    q.register_dispatcher("notification", failing_dispatcher)
    q.start()

    q.enqueue(
        _make_item(
            task_id="t1", run_id=run_id, action_type="notification", max_retries=3
        )
    )

    # Wait for processing + retry backoff
    time.sleep(4.0)
    q.stop(timeout=5)

    # Should have been called at least twice (initial + retry)
    assert call_count["n"] >= 2
    store.close()


def test_max_retries_exhausted(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler

    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="t1",
            name="Test",
            cron_expr="0 9 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("t1", status="queued")

    def always_fail(data, rid):
        raise RuntimeError("permanent error")

    q = WorkQueue(max_workers=1, scheduler_store=ss)
    q.register_dispatcher("notification", always_fail)
    q.start()

    # max_retries=0 means no retries, fails immediately
    q.enqueue(
        _make_item(
            task_id="t1", run_id=run_id, action_type="notification", max_retries=0
        )
    )

    time.sleep(2.0)
    q.stop(timeout=5)

    run = ss.get_last_run("t1")
    assert run is not None
    assert run.status == "failed"
    assert run.error is not None
    store.close()


def test_graceful_shutdown(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    q = WorkQueue(max_workers=1, scheduler_store=ss)
    q.register_dispatcher("notification", lambda data, rid: "ok")
    q.start()

    q.enqueue(_make_item(task_id="t1", run_id=1))
    q.enqueue(_make_item(task_id="t2", run_id=2))

    # Should not raise
    q.stop(timeout=5)
    store.close()


def test_pending_count(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    q = WorkQueue(max_workers=1, scheduler_store=ss)

    assert q.pending_count == 0
    q.enqueue(_make_item(task_id="t1", run_id=1))
    q.enqueue(_make_item(task_id="t2", run_id=2))
    assert q.pending_count == 2
    store.close()


def test_unknown_action_type(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler

    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="t1",
            name="Test",
            cron_expr="0 9 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("t1", status="queued")

    q = WorkQueue(max_workers=1, scheduler_store=ss)
    # Do NOT register any dispatcher
    q.start()

    q.enqueue(_make_item(task_id="t1", run_id=run_id, action_type="unknown_type"))

    time.sleep(1.0)
    q.stop(timeout=5)

    run = ss.get_last_run("t1")
    assert run is not None
    assert run.status == "failed"
    assert "No dispatcher" in (run.error or "")
    store.close()


def test_transcription_runtime_lifecycle(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler
    runtime_registry = RuntimeStateRegistry()

    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="transcribe-m1",
            name="Transcribe",
            cron_expr="0 9 * * *",
            action_type=ActionType.TRANSCRIPTION,
            action_data={"meeting_id": "m1"},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("transcribe-m1", status="queued")

    gate = {"release": False}

    def dispatcher(data, rid):
        while not gate["release"]:
            time.sleep(0.01)
        return "ok"

    q = WorkQueue(max_workers=1, scheduler_store=ss, runtime_registry=runtime_registry)
    q.register_dispatcher(ActionType.TRANSCRIPTION.value, dispatcher)
    q.start()
    q.enqueue(
        _make_item(
            task_id="transcribe-m1",
            run_id=run_id,
            action_type=ActionType.TRANSCRIPTION.value,
            action_data={"meeting_id": "m1"},
        )
    )

    deadline = time.time() + 2
    while time.time() < deadline:
        meetings = runtime_registry.snapshot()["meetings"]
        if meetings["running_transcriptions"] == 1:
            break
        time.sleep(0.01)

    meetings = runtime_registry.snapshot()["meetings"]
    assert meetings["queued_transcriptions"] == 0
    assert meetings["running_transcriptions"] == 1

    gate["release"] = True
    time.sleep(0.2)
    q.stop(timeout=5)

    meetings = runtime_registry.snapshot()["meetings"]
    assert meetings["queued_transcriptions"] == 0
    assert meetings["running_transcriptions"] == 0
    store.close()


def test_llm_unavailable_error_does_not_burn_retry(tmp_path):
    """LLMUnavailableError re-enqueues with the same attempt count (no retry burn)."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ss = store.scheduler

    from memex.models import ScheduledTask

    now = utcnow()
    ss.create_task(
        ScheduledTask(
            task_id="t1",
            name="Test",
            cron_expr="0 9 * * *",
            action_type=ActionType.NOTIFICATION,
            action_data={},
            created_at=now,
            updated_at=now,
        )
    )
    run_id = ss.record_run("t1", status="queued")

    call_count = {"n": 0}

    def flaky_dispatcher(data, rid):
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise LLMUnavailableError("down")
        return "ok"

    q = WorkQueue(max_workers=1, scheduler_store=ss)
    q.register_dispatcher("notification", flaky_dispatcher)
    q.start()

    # Monkey-patch the 60s hold to 0.1s for test speed
    original_wait = q._shutdown.wait
    q._shutdown.wait = lambda t: original_wait(min(t, 0.1))

    q.enqueue(_make_item(task_id="t1", run_id=run_id, action_type="notification"))

    # Wait for both dispatch attempts
    deadline = time.time() + 5
    while time.time() < deadline and call_count["n"] < 2:
        time.sleep(0.05)

    q.stop(timeout=5)

    # Should have been called twice (first: LLMUnavailable, second: success)
    assert call_count["n"] == 2

    run = ss.get_last_run("t1")
    assert run is not None
    assert run.status == "completed"
    store.close()
