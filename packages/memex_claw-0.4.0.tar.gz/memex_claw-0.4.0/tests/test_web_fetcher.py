"""Tests for web fetcher strategy chain and bot detection."""

from __future__ import annotations

from memex.connectors.web_fetcher import (
    FetchResult,
    FetchStrategy,
    _has_content,
    get_fetcher,
    get_strategy,
)


# ---------------------------------------------------------------------------
# Mock backend
# ---------------------------------------------------------------------------


class MockFetcher:
    def __init__(self, result: FetchResult) -> None:
        self._result = result
        self.closed = False
        self.calls: list[tuple[str, int, dict[str, str] | None]] = []

    def fetch(
        self,
        url: str,
        *,
        timeout: int = 30,
        headers: dict[str, str] | None = None,
    ) -> FetchResult:
        self.calls.append((url, timeout, headers))
        return self._result

    def close(self) -> None:
        self.closed = True


GOOD_HTML = "<html><body>" + "x " * 300 + "</body></html>"
SHORT_HTML = "<p>hi</p>"
CLOUDFLARE_HTML = (
    "<html><head><title>Just a moment...</title></head><body>"
    "Checking your browser before accessing the site. "
    "cf-browser-verification cf_chl_opt challenges.cloudflare.com"
    + " padding" * 100
    + "</body></html>"
)
DATADOME_HTML = (
    "<html><body>dd.datadome blocked datadome.co/captcha"
    + " pad" * 200
    + "</body></html>"
)


def _ok(text: str = GOOD_HTML, status: int = 200) -> FetchResult:
    return FetchResult(
        url="https://example.com", status_code=status, text=text, ok=True
    )


def _fail(error: str = "conn refused") -> FetchResult:
    return FetchResult(
        url="https://example.com", status_code=0, text="", ok=False, error=error
    )


# ---------------------------------------------------------------------------
# _has_content tests
# ---------------------------------------------------------------------------


def test_has_content_passes_real_content():
    assert _has_content(_ok()) is True


def test_has_content_rejects_short_responses():
    assert _has_content(_ok(text=SHORT_HTML)) is False


def test_has_content_rejects_failed_result():
    assert _has_content(_fail()) is False


def test_has_content_detects_cloudflare():
    assert _has_content(_ok(text=CLOUDFLARE_HTML)) is False


def test_has_content_detects_datadome():
    assert _has_content(_ok(text=DATADOME_HTML)) is False


# ---------------------------------------------------------------------------
# FetchStrategy tests
# ---------------------------------------------------------------------------


def test_strategy_returns_first_successful():
    first_content = GOOD_HTML + " FIRST"
    second_content = GOOD_HTML + " SECOND"
    s = FetchStrategy(
        [MockFetcher(_ok(first_content)), MockFetcher(_ok(second_content))]
    )
    result = s.fetch("https://example.com")
    assert "FIRST" in result.text


def test_strategy_falls_through_on_failure():
    s = FetchStrategy([MockFetcher(_fail()), MockFetcher(_ok())])
    result = s.fetch("https://example.com")
    assert result.ok is True
    assert result.text == GOOD_HTML


def test_strategy_falls_through_on_bot_challenge():
    s = FetchStrategy([MockFetcher(_ok(CLOUDFLARE_HTML)), MockFetcher(_ok())])
    result = s.fetch("https://example.com")
    assert result.ok is True
    assert "cf-browser-verification" not in result.text


def test_strategy_returns_last_failure_when_all_fail():
    s = FetchStrategy([MockFetcher(_fail("err1")), MockFetcher(_fail("err2"))])
    result = s.fetch("https://example.com")
    assert result.ok is False
    assert result.error == "err2"


def test_strategy_passes_request_headers_to_backends():
    backend = MockFetcher(_ok())
    s = FetchStrategy([backend])
    result = s.fetch("https://example.com", headers={"If-None-Match": '"etag-123"'})
    assert result.ok is True
    assert backend.calls == [
        ("https://example.com", 30, {"If-None-Match": '"etag-123"'})
    ]


def test_strategy_close_closes_all_backends():
    a, b = MockFetcher(_ok()), MockFetcher(_ok())
    s = FetchStrategy([a, b])
    s.close()
    assert a.closed is True
    assert b.closed is True


# ---------------------------------------------------------------------------
# Factory / singleton tests
# ---------------------------------------------------------------------------


def test_get_strategy_singleton(monkeypatch):
    import memex.connectors.web_fetcher as mod

    monkeypatch.setattr(mod, "_strategy", None)
    monkeypatch.setenv("MEMEX_FETCH_STRATEGY", "httpx")
    s1 = get_strategy()
    s2 = get_strategy()
    assert s1 is s2
    # cleanup
    s1.close()
    monkeypatch.setattr(mod, "_strategy", None)


def test_get_strategy_single_backend(monkeypatch):
    import memex.connectors.web_fetcher as mod

    monkeypatch.setattr(mod, "_strategy", None)
    s = get_strategy("httpx")
    # Should have exactly one backend (HttpxFetcher)
    assert len(s._backends) == 1
    assert type(s._backends[0]).__name__ == "HttpxFetcher"
    s.close()


def test_get_fetcher_compat(monkeypatch):
    import memex.connectors.web_fetcher as mod

    monkeypatch.setattr(mod, "_strategy", None)
    monkeypatch.setenv("MEMEX_FETCH_STRATEGY", "httpx")
    result = get_fetcher()
    assert isinstance(result, FetchStrategy)
    result.close()
    monkeypatch.setattr(mod, "_strategy", None)
