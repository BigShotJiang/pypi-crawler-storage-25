"""Tests for MeetingDrawer widget — data model, toggle state, and message classes."""

from memex.interfaces.tui.widgets.meeting_drawer import MeetingDrawer


# ---------------------------------------------------------------------------
# Toggle state
# ---------------------------------------------------------------------------


def test_meeting_drawer_toggle():
    """is_open starts False, toggle flips it, toggle again restores."""
    drawer = MeetingDrawer()

    assert drawer.is_open is False

    drawer._open = True
    assert drawer.is_open is True

    drawer._open = False
    assert drawer.is_open is False


# ---------------------------------------------------------------------------
# Data storage
# ---------------------------------------------------------------------------


def test_meeting_drawer_load_meetings():
    """_meetings stores data passed to the drawer."""
    drawer = MeetingDrawer()

    assert drawer._meetings == []

    test_data = [
        {
            "meeting_id": "mtg-1",
            "state": "transcribed",
            "title": "Standup",
            "duration_human": "15m",
            "speaker_count": 3,
            "language": "en",
            "started_human": "2026-03-08 09:00",
        },
        {
            "meeting_id": "mtg-2",
            "state": "recorded",
            "title": "Planning",
            "duration_human": "45m",
            "speaker_count": 5,
            "language": "en",
            "started_human": "2026-03-08 10:00",
        },
    ]

    drawer._meetings = test_data
    assert len(drawer._meetings) == 2
    assert drawer._meetings[0]["meeting_id"] == "mtg-1"
    assert drawer._meetings[1]["title"] == "Planning"


# ---------------------------------------------------------------------------
# Message classes
# ---------------------------------------------------------------------------


def test_meeting_drawer_messages():
    """DrawerClose and MeetingAction message classes exist with expected fields."""
    # DrawerClose drawer value comes from DRAWER_NAME (set via action_close_drawer)
    assert MeetingDrawer.DRAWER_NAME == "meetings"
    close_msg = MeetingDrawer.DrawerClose(MeetingDrawer.DRAWER_NAME)
    assert close_msg.drawer == "meetings"

    # MeetingAction has action and meeting_id fields
    action_msg = MeetingDrawer.MeetingAction(action="transcribe", meeting_id="mtg-42")
    assert action_msg.action == "transcribe"
    assert action_msg.meeting_id == "mtg-42"

    # Different action
    view_msg = MeetingDrawer.MeetingAction(action="view", meeting_id="mtg-99")
    assert view_msg.action == "view"
    assert view_msg.meeting_id == "mtg-99"


def test_meeting_drawer_has_stop_binding():
    binding_keys = [b.key for b in MeetingDrawer.BINDINGS]
    assert "s" in binding_keys


def test_meeting_drawer_has_enter_binding_for_view():
    binding_keys = [b.key for b in MeetingDrawer.BINDINGS]
    assert "enter" in binding_keys


def test_meeting_drawer_has_delete_binding():
    binding_keys = [b.key for b in MeetingDrawer.BINDINGS]
    assert "d" in binding_keys
    assert "delete" in binding_keys


# ---------------------------------------------------------------------------
# Action item count display (P2-14)
# ---------------------------------------------------------------------------


def _build_title(meeting: dict) -> str:
    """Replicate the title-building logic from load_meetings()."""
    title = meeting.get("title", "Untitled") or "Untitled"
    recording_count = int(meeting.get("recording_count", 0) or 0)
    if recording_count:
        title = f"{title} [{recording_count} rec]"
    action_count = int(meeting.get("action_item_count", 0) or 0)
    if action_count:
        title = f"{title} \u26a1{action_count}"
    return title


def test_action_item_count_shown_in_title():
    title = _build_title(
        {"title": "Standup", "action_item_count": 3, "recording_count": 0}
    )
    assert "⚡3" in title


def test_no_action_item_count_when_zero():
    title = _build_title(
        {"title": "Standup", "action_item_count": 0, "recording_count": 0}
    )
    assert "⚡" not in title


def test_action_item_and_recording_count_combined():
    title = _build_title(
        {"title": "Standup", "action_item_count": 2, "recording_count": 1}
    )
    assert "[1 rec]" in title
    assert "⚡2" in title


def test_action_item_count_none_treated_as_zero():
    title = _build_title(
        {"title": "Standup", "action_item_count": None, "recording_count": 0}
    )
    assert "⚡" not in title


def test_meeting_drawer_r_stops_when_recording():
    drawer = MeetingDrawer()
    drawer._is_recording = True
    drawer.post_message = lambda msg: setattr(drawer, "_last_msg", msg)

    drawer.action_record()

    assert drawer._last_msg.action == "stop_recording"


def test_meeting_drawer_delete_posts_delete_action():
    drawer = MeetingDrawer()
    drawer._meetings = [{"meeting_id": "mtg-1", "title": "Planning"}]

    class _Table:
        cursor_row = 0

    drawer.query_one = lambda *_args, **_kwargs: _Table()
    drawer.post_message = lambda msg: setattr(drawer, "_last_msg", msg)

    drawer.action_delete_meeting()

    assert drawer._last_msg.action == "delete"
    assert drawer._last_msg.meeting_id == "mtg-1"
