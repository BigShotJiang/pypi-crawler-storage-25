"""TDD tests for audio_prep — written before implementation.

Tests cover:
  - AudioAnalysis detection (too quiet, clipping, sample rate, duration)
  - RMS normalization of quiet recordings
  - Peak limiting for clipping audio
  - High-pass filter removes low-frequency rumble
  - Silence trimming at start and end
  - Resampling from 44100 Hz to 16000 Hz
  - Silero VAD pre-analysis threshold suggestion
  - Real recorded audio files from ~/.memex/audio/
  - Integration: transcribe_meeting uses prepared audio path
"""

from __future__ import annotations

import shutil
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

sf = pytest.importorskip("soundfile", reason="soundfile not installed (optional dep)")

_SILERO_AVAILABLE = True
try:
    from memex.meetings.vad import get_silero_vad

    get_silero_vad()
except Exception:
    _SILERO_AVAILABLE = False

_SILERO_SKIP = pytest.mark.skipif(
    not _SILERO_AVAILABLE, reason="Silero VAD not available"
)

# ---------------------------------------------------------------------------
# Paths to real recordings captured by Memex
# ---------------------------------------------------------------------------
_AUDIO_DIR = Path.home() / ".memex" / "audio"
_TEST_WAV = Path(__file__).parent.parent / "test_usb.wav"

# Quiet recordings (rms < 0.02 based on pre-measurement)
_QUIET_FILES = sorted(_AUDIO_DIR.glob("*.wav"))[:3]  # 20260313, 20260318, 20260320
# Normal recordings (rms ~0.22)
_NORMAL_FILES = sorted(_AUDIO_DIR.glob("*.wav"))[3:]  # 20260322, 20260323

_HAS_REAL_AUDIO = _AUDIO_DIR.exists() and any(_AUDIO_DIR.glob("*.wav"))
_HAS_NORMAL_AUDIO = bool(
    _AUDIO_DIR.exists()
    and any(
        "20260322" in f.name or "20260323" in f.name for f in _AUDIO_DIR.glob("*.wav")
    )
)


# ---------------------------------------------------------------------------
# Synthetic helpers
# ---------------------------------------------------------------------------


def _write_wav(path: Path, data: np.ndarray, sr: int = 16000) -> None:
    sf.write(str(path), data.astype(np.float32), sr)


def _make_speech_like(
    duration_s: float = 3.0, sr: int = 16000, rms: float = 0.1
) -> np.ndarray:
    """White noise burst — stands in for speech in unit tests."""
    rng = np.random.default_rng(42)
    n = int(duration_s * sr)
    data = rng.standard_normal(n).astype(np.float32)
    data *= rms / (np.sqrt(np.mean(data**2)) + 1e-9)
    return data


def _make_quiet_audio(duration_s: float = 3.0, sr: int = 16000) -> np.ndarray:
    """Return audio with RMS well below the quiet threshold (< 0.005)."""
    return _make_speech_like(duration_s, sr, rms=0.005)


def _make_loud_audio(duration_s: float = 3.0, sr: int = 16000) -> np.ndarray:
    """Return audio that clips (peak > 1.0)."""
    data = _make_speech_like(duration_s, sr, rms=0.5)
    data *= 3.0  # push peak well above 1.0
    return data


def _make_low_freq_audio(duration_s: float = 2.0, sr: int = 16000) -> np.ndarray:
    """Pure 50 Hz tone (below high-pass cutoff) + weak 1kHz speech tone."""
    t = np.linspace(0, duration_s, int(duration_s * sr), endpoint=False)
    rumble = 0.3 * np.sin(2 * np.pi * 50 * t)
    speech = 0.05 * np.sin(2 * np.pi * 1000 * t)
    return (rumble + speech).astype(np.float32)


def _make_padded_silence(
    duration_s: float = 2.0, silence_s: float = 1.0, sr: int = 16000
) -> np.ndarray:
    """Speech-like burst surrounded by silence."""
    speech_n = int(duration_s * sr)
    silence_n = int(silence_s * sr)
    rng = np.random.default_rng(7)
    speech = (rng.standard_normal(speech_n) * 0.1).astype(np.float32)
    silence = np.zeros(silence_n, dtype=np.float32)
    return np.concatenate([silence, speech, silence])


# ---------------------------------------------------------------------------
# AudioAnalysis tests
# ---------------------------------------------------------------------------


class TestAnalyzeAudio:
    def test_detects_too_quiet(self, tmp_path):
        from memex.meetings.audio_prep import analyze_audio, QUIET_RMS_THRESHOLD

        p = tmp_path / "quiet.wav"
        _write_wav(p, _make_quiet_audio())
        a = analyze_audio(p)
        assert a.is_too_quiet, f"Expected is_too_quiet=True for rms={a.rms_level:.4f}"
        assert a.rms_level < QUIET_RMS_THRESHOLD

    def test_detects_normal_level(self, tmp_path):
        from memex.meetings.audio_prep import analyze_audio, QUIET_RMS_THRESHOLD

        p = tmp_path / "normal.wav"
        _write_wav(p, _make_speech_like(rms=0.1))
        a = analyze_audio(p)
        assert not a.is_too_quiet
        assert a.rms_level >= QUIET_RMS_THRESHOLD

    def test_detects_clipping(self, tmp_path):
        from memex.meetings.audio_prep import analyze_audio, LOUD_PEAK_THRESHOLD

        p = tmp_path / "loud.wav"
        data = _make_loud_audio()
        # Clamp to WAV float range before writing; test that we flag high peak
        data_clamped = np.clip(data, -1.0, 1.0)
        # Manually scale to just above threshold
        data_clamped = (
            data_clamped / np.max(np.abs(data_clamped)) * (LOUD_PEAK_THRESHOLD + 0.02)
        )
        _write_wav(p, data_clamped)
        a = analyze_audio(p)
        assert a.is_clipping, f"Expected is_clipping=True for peak={a.peak_level:.4f}"

    def test_sample_rate_and_duration(self, tmp_path):
        from memex.meetings.audio_prep import analyze_audio

        sr, dur = 16000, 3.5
        p = tmp_path / "test.wav"
        _write_wav(p, _make_speech_like(dur, sr), sr)
        a = analyze_audio(p)
        assert a.sample_rate == sr
        assert abs(a.duration_seconds - dur) < 0.05
        assert a.channels == 1

    def test_stereo_detected(self, tmp_path):
        from memex.meetings.audio_prep import analyze_audio

        p = tmp_path / "stereo.wav"
        data = np.stack([_make_speech_like(2.0), _make_speech_like(2.0)], axis=1)
        sf.write(str(p), data, 16000)
        a = analyze_audio(p)
        assert a.channels == 2

    @pytest.mark.skipif(not _HAS_REAL_AUDIO, reason="No real recordings found")
    def test_real_quiet_recordings_detected(self):
        from memex.meetings.audio_prep import analyze_audio, QUIET_RMS_THRESHOLD

        quiet = [
            f
            for f in sorted(_AUDIO_DIR.glob("*.wav"))
            if "20260313" in f.name or "20260318" in f.name
        ]
        assert quiet, "Expected quiet real recordings not found"
        for f in quiet:
            a = analyze_audio(f)
            assert a.is_too_quiet, (
                f"{f.name}: expected is_too_quiet=True, got rms={a.rms_level:.4f} "
                f"(threshold={QUIET_RMS_THRESHOLD})"
            )

    @pytest.mark.skipif(
        not _HAS_NORMAL_AUDIO, reason="No normal recordings (20260322/20260323) found"
    )
    def test_real_normal_recordings_detected(self):
        from memex.meetings.audio_prep import analyze_audio

        normal = [
            f
            for f in sorted(_AUDIO_DIR.glob("*.wav"))
            if "20260322" in f.name or "20260323" in f.name
        ]
        assert normal, "Expected normal real recordings not found"
        for f in normal:
            a = analyze_audio(f)
            assert not a.is_too_quiet, (
                f"{f.name}: expected is_too_quiet=False, got rms={a.rms_level:.4f}"
            )


# ---------------------------------------------------------------------------
# RMS normalization tests
# ---------------------------------------------------------------------------


class TestNormalization:
    def test_quiet_audio_raised_to_target(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio, TARGET_RMS

        src = tmp_path / "quiet.wav"
        _write_wav(src, _make_quiet_audio())
        result = prepare_audio(src, tmp_dir=tmp_path)
        # Either loudnorm (ffmpeg) or normalize (fallback) must have run
        assert (
            "normalize" in result.applied_steps or "loudnorm" in result.applied_steps
        ), f"Expected normalization step, got {result.applied_steps}"
        # For RMS normalization, verify the level was raised. Skip for loudnorm
        # since EBU R128 normalises K-weighted loudness, not raw RMS; white-noise
        # fixtures have most energy at high frequencies which K-weighting discounts.
        if "normalize" in result.applied_steps:
            data, _ = sf.read(str(result.path), dtype="float32")
            rms_out = np.sqrt(np.mean(data**2))
            assert rms_out >= TARGET_RMS * 0.7, (
                f"Expected rms≥{TARGET_RMS * 0.7:.3f} after normalization, got {rms_out:.4f}"
            )

    def test_normalization_never_clips(self, tmp_path):
        """Quiet audio with rare loud spike: normalizing by RMS must not cause clipping."""
        from memex.meetings.audio_prep import prepare_audio, LOUD_PEAK_THRESHOLD

        src = tmp_path / "spiky.wav"
        # Low RMS but high peak — matches real recordings 20260318 and 20260320
        data = _make_speech_like(3.0, rms=0.005)
        # Add a single loud spike
        data[len(data) // 2] = 0.95
        _write_wav(src, data)
        result = prepare_audio(src, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        assert np.max(np.abs(out)) <= LOUD_PEAK_THRESHOLD + 1e-4, (
            f"Peak after normalization exceeded threshold: {np.max(np.abs(out)):.4f}"
        )

    def test_loud_audio_peak_limited(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio, LOUD_PEAK_THRESHOLD

        src = tmp_path / "loud.wav"
        # Build audio that is already at normal RMS but has peaks above threshold
        data = _make_speech_like(3.0, rms=0.3)
        data = data / np.max(np.abs(data)) * (LOUD_PEAK_THRESHOLD + 0.1)
        _write_wav(src, data)
        result = prepare_audio(src, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        assert (
            np.max(np.abs(out)) <= LOUD_PEAK_THRESHOLD + 0.02
        )  # small headroom for loudnorm TP
        # Either peak_limit (fallback) or loudnorm (ffmpeg) must have run
        assert (
            "peak_limit" in result.applied_steps or "loudnorm" in result.applied_steps
        )

    def test_normal_audio_unchanged_by_normalization(self, tmp_path):
        """Audio already at target RMS should not have 'normalize' applied."""
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "normal.wav"
        _write_wav(src, _make_speech_like(3.0, rms=0.1))
        result = prepare_audio(src, tmp_dir=tmp_path)
        assert "normalize" not in result.applied_steps

    @pytest.mark.skipif(not _HAS_REAL_AUDIO, reason="No real recordings found")
    def test_real_quiet_recording_normalized(self, tmp_path):
        """Real quiet recording should be raised toward target RMS."""
        from memex.meetings.audio_prep import prepare_audio, TARGET_RMS

        quiet = next(
            (f for f in sorted(_AUDIO_DIR.glob("*.wav")) if "20260313" in f.name), None
        )
        if quiet is None:
            pytest.skip("Quiet recording not found")
        result = prepare_audio(quiet, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        rms_out = np.sqrt(np.mean(out**2))
        assert rms_out >= TARGET_RMS * 0.5, (
            f"rms after prep={rms_out:.4f}, expected ≥{TARGET_RMS * 0.5:.3f}"
        )


# ---------------------------------------------------------------------------
# High-pass filter tests
# ---------------------------------------------------------------------------


class TestHighPassFilter:
    def test_removes_low_frequency_rumble(self, tmp_path):
        """50 Hz rumble (dominant) should be attenuated; 1kHz speech component preserved."""
        from memex.meetings.audio_prep import prepare_audio, HIGHPASS_CUTOFF_HZ

        src = tmp_path / "rumble.wav"
        data = _make_low_freq_audio()
        _write_wav(src, data)

        result = prepare_audio(src, tmp_dir=tmp_path)
        out, sr = sf.read(str(result.path), dtype="float32")

        # Compute power in low-frequency band (< cutoff) before and after
        from numpy.fft import rfft, rfftfreq

        freqs = rfftfreq(len(data), 1 / sr)
        # Input: low-freq power is dominated by 50 Hz rumble
        in_fft = np.abs(rfft(data))
        out_fft = np.abs(rfft(out))

        low_mask = freqs < HIGHPASS_CUTOFF_HZ
        in_low_power = np.sum(in_fft[low_mask] ** 2)
        out_low_power = np.sum(out_fft[low_mask] ** 2)

        assert out_low_power < in_low_power * 0.1, (
            f"High-pass did not attenuate low-freq: in={in_low_power:.1f} out={out_low_power:.1f}"
        )
        assert "highpass" in result.applied_steps

    def test_highpass_preserves_speech_frequencies(self, tmp_path):
        """Frequencies well above the cutoff should survive the filter."""
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "speech.wav"
        data = _make_low_freq_audio()
        _write_wav(src, data)

        result = prepare_audio(src, tmp_dir=tmp_path)
        out, sr = sf.read(str(result.path), dtype="float32")

        from numpy.fft import rfft, rfftfreq

        freqs = rfftfreq(len(data), 1 / sr)
        in_fft = np.abs(rfft(data))
        out_fft = np.abs(rfft(out))

        speech_mask = (freqs >= 800) & (freqs <= 1200)
        in_speech = np.sum(in_fft[speech_mask] ** 2)
        out_speech = np.sum(out_fft[speech_mask] ** 2)

        # Speech band should be largely preserved (at least 50% power remains)
        assert out_speech >= in_speech * 0.5, (
            f"High-pass attenuated too much speech power: {out_speech / in_speech:.2f}"
        )


# ---------------------------------------------------------------------------
# Silence trimming tests
# ---------------------------------------------------------------------------


class TestSilenceTrimming:
    def test_leading_silence_removed(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "padded.wav"
        data = _make_padded_silence(duration_s=2.0, silence_s=1.0)
        _write_wav(src, data)

        result = prepare_audio(src, tmp_dir=tmp_path)
        out, sr = sf.read(str(result.path), dtype="float32")

        # Original: 2s silence + 2s speech + 1s silence = 4s
        # After trim: should be noticeably shorter
        original_dur = len(data) / 16000
        trimmed_dur = len(out) / sr
        assert trimmed_dur < original_dur * 0.85, (
            f"Expected trim to shorten audio: {original_dur:.1f}s → {trimmed_dur:.1f}s"
        )
        assert "trim_silence" in result.applied_steps

    def test_no_speech_content_survives(self, tmp_path):
        """If audio has speech content, trimming must not remove all of it."""
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "padded.wav"
        data = _make_padded_silence(duration_s=2.0, silence_s=0.5)
        _write_wav(src, data)

        result = prepare_audio(src, tmp_dir=tmp_path)
        out, sr = sf.read(str(result.path), dtype="float32")

        # At least 1 second of content should remain
        assert len(out) / sr >= 1.0


# ---------------------------------------------------------------------------
# Sample rate conversion
# ---------------------------------------------------------------------------


class TestResampling:
    @pytest.mark.skipif(not _TEST_WAV.exists(), reason=f"{_TEST_WAV} not present")
    def test_44100hz_converted_to_16khz(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio

        # test_usb.wav is 44100 Hz mono
        result = prepare_audio(_TEST_WAV, tmp_dir=tmp_path)
        _, sr_out = sf.read(str(result.path), dtype="float32")
        assert sr_out == 16000
        assert "resample" in result.applied_steps

    def test_16khz_mono_not_resampled(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "native.wav"
        _write_wav(src, _make_speech_like(rms=0.1), sr=16000)
        result = prepare_audio(src, tmp_dir=tmp_path)
        assert "resample" not in result.applied_steps

    def test_stereo_converted_to_mono(self, tmp_path):
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "stereo.wav"
        data = np.stack([_make_speech_like(2.0), _make_speech_like(2.0)], axis=1)
        sf.write(str(src), data, 16000)
        result = prepare_audio(src, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        assert out.ndim == 1, "Expected mono output"
        assert "to_mono" in result.applied_steps


# ---------------------------------------------------------------------------
# VAD pre-analysis / threshold suggestion
# ---------------------------------------------------------------------------


@_SILERO_SKIP
class TestSuggestVadThreshold:
    def test_returns_float_for_speech_audio(self, tmp_path):
        """Speech-like audio should yield a non-None threshold."""
        from memex.meetings.audio_prep import suggest_vad_threshold

        src = tmp_path / "speech.wav"
        _write_wav(src, _make_speech_like(rms=0.15))
        threshold = suggest_vad_threshold(src)
        # May return None if Silero not available, else float in valid range
        if threshold is not None:
            assert 0.0 < threshold <= 1.0

    def test_returns_none_or_low_for_silent_audio(self, tmp_path):
        """Completely silent audio: no threshold should confidently fire."""
        from memex.meetings.audio_prep import suggest_vad_threshold

        src = tmp_path / "silence.wav"
        _write_wav(src, np.zeros(32000, dtype=np.float32))
        threshold = suggest_vad_threshold(src)
        # Either None (no speech detected) or very low threshold
        if threshold is not None:
            assert threshold <= 0.15

    @pytest.mark.skipif(not _HAS_REAL_AUDIO, reason="No real recordings found")
    def test_real_recordings_get_threshold(self):
        """Each real recording should get a usable threshold or None."""
        from memex.meetings.audio_prep import suggest_vad_threshold

        for f in sorted(_AUDIO_DIR.glob("*.wav")):
            t = suggest_vad_threshold(f)
            if t is not None:
                assert 0.0 < t <= 1.0, f"{f.name}: invalid threshold {t}"


# ---------------------------------------------------------------------------
# PreparedAudio: was_modified flag
# ---------------------------------------------------------------------------


class TestFfmpegLoudnorm:
    def test_loudnorm_applied_when_ffmpeg_available(self, tmp_path):
        """When ffmpeg is present and audio is quiet, 'loudnorm' should appear in applied_steps."""
        import shutil as _shutil

        if not _shutil.which("ffmpeg"):
            pytest.skip("ffmpeg not installed")
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "quiet.wav"
        _write_wav(src, _make_quiet_audio(duration_s=2.0))
        result = prepare_audio(src, tmp_dir=tmp_path)
        assert "loudnorm" in result.applied_steps, (
            f"Expected 'loudnorm' in steps, got {result.applied_steps}"
        )

    def test_loudnorm_output_not_clipping(self, tmp_path):
        """loudnorm output must not exceed LOUD_PEAK_THRESHOLD."""
        import shutil as _shutil

        if not _shutil.which("ffmpeg"):
            pytest.skip("ffmpeg not installed")
        from memex.meetings.audio_prep import prepare_audio, LOUD_PEAK_THRESHOLD

        src = tmp_path / "quiet.wav"
        _write_wav(src, _make_quiet_audio(duration_s=2.0))
        result = prepare_audio(src, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        assert np.max(np.abs(out)) <= LOUD_PEAK_THRESHOLD + 0.02

    def test_loudnorm_raises_rms_on_real_audio(self, tmp_path):
        """loudnorm output should raise RMS on a real quiet speech recording.

        White-noise fixtures get K-weighted differently (EBU R128 discounts high
        frequencies), so we use a real recording for the RMS-raise assertion.
        """
        import shutil as _shutil

        if not _shutil.which("ffmpeg"):
            pytest.skip("ffmpeg not installed")
        if not _HAS_REAL_AUDIO:
            pytest.skip("No real recordings available")
        from memex.meetings.audio_prep import prepare_audio

        quiet = next(
            (f for f in sorted(_AUDIO_DIR.glob("*.wav")) if "20260313" in f.name), None
        )
        if quiet is None:
            pytest.skip("Quiet real recording not found")
        orig_data, _ = sf.read(str(quiet), dtype="float32")
        original_rms = np.sqrt(np.mean(orig_data**2))
        result = prepare_audio(quiet, tmp_dir=tmp_path)
        out, _ = sf.read(str(result.path), dtype="float32")
        out_rms = np.sqrt(np.mean(out**2))
        assert out_rms > original_rms * 2, (
            f"loudnorm should raise RMS on speech: {original_rms:.4f} → {out_rms:.4f}"
        )

    @pytest.mark.skipif(not _HAS_REAL_AUDIO, reason="No real recordings found")
    def test_loudnorm_on_real_quiet_recording(self, tmp_path):
        """Real quiet recording should be normalized with loudnorm."""
        import shutil as _shutil

        if not _shutil.which("ffmpeg"):
            pytest.skip("ffmpeg not installed")
        from memex.meetings.audio_prep import prepare_audio

        quiet = next(
            (f for f in sorted(_AUDIO_DIR.glob("*.wav")) if "20260313" in f.name), None
        )
        if quiet is None:
            pytest.skip("Quiet recording not found")
        result = prepare_audio(quiet, tmp_dir=tmp_path)
        assert "loudnorm" in result.applied_steps


class TestWasModified:
    def test_clean_16khz_mono_not_modified(self, tmp_path):
        """Already-ideal audio: was_modified should be False."""
        from memex.meetings.audio_prep import prepare_audio, TARGET_RMS

        src = tmp_path / "ideal.wav"
        _write_wav(src, _make_speech_like(rms=TARGET_RMS), sr=16000)
        result = prepare_audio(src, tmp_dir=tmp_path)
        # Path should be the original (no copy) or was_modified=False
        assert not result.was_modified or result.path == src

    def test_modified_audio_written_to_tmp(self, tmp_path):
        """Modified audio must be written to tmp_dir, not overwrite original."""
        from memex.meetings.audio_prep import prepare_audio

        src = tmp_path / "quiet.wav"
        _write_wav(src, _make_quiet_audio())
        out_dir = tmp_path / "prepared"
        out_dir.mkdir()
        result = prepare_audio(src, tmp_dir=out_dir)
        assert result.was_modified
        assert result.path != src
        assert result.path.parent == out_dir


# ---------------------------------------------------------------------------
# Integration: transcribe_meeting uses audio prep
# ---------------------------------------------------------------------------


def _make_mock_backend(segments=None, language="en", duration=2.0, quality=0.85):
    """Build a mock STT backend returning the given segments."""
    from memex.meetings.stt_backend import STTResult, STTSegment

    if segments is None:
        segments = [
            STTSegment(start=0.0, end=2.0, text="test", confidence=0.85),
        ]

    mock_backend = MagicMock()
    mock_backend.name = "mock"
    mock_backend.transcribe.return_value = STTResult(
        segments=segments,
        language=language,
        duration_seconds=duration,
        backend_name="mock",
        quality=quality,
    )
    return mock_backend


def _make_prep_patch(prepared_path: Path, *, is_too_quiet: bool = False):
    """Return a mock PreparedAudio result."""
    mock = MagicMock()
    mock.path = prepared_path
    mock.analysis = MagicMock()
    mock.analysis.is_too_quiet = is_too_quiet
    mock.was_modified = True
    mock.applied_steps = []
    return mock


class TestTranscribeMeetingUsesAudioPrep:
    def test_prepare_audio_called_before_backend(self, tmp_path):
        """transcribe_meeting must call prepare_audio and pass the prepared path to backend."""
        from memex.meetings.transcribe import transcribe_meeting

        src = tmp_path / "test.wav"
        _write_wav(src, _make_speech_like(rms=0.1))
        prepared_path = tmp_path / "prepared.wav"
        shutil.copy(src, prepared_path)

        mock_backend = _make_mock_backend()
        mock_prep = _make_prep_patch(prepared_path)

        with (
            patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend),
            patch(
                "memex.meetings.audio_prep.prepare_audio", return_value=mock_prep
            ) as mock_prepare,
        ):
            transcribe_meeting(src, diarize=False)

        mock_prepare.assert_called_once()
        passed_path = mock_backend.transcribe.call_args.kwargs.get(
            "audio_path", mock_backend.transcribe.call_args.args[0]
        )
        assert str(passed_path) == str(prepared_path), (
            f"Expected prepared path {prepared_path}, got {passed_path}"
        )

    def test_language_passed_when_provided(self, tmp_path):
        """Explicit language is forwarded to backend."""
        from memex.meetings.transcribe import transcribe_meeting

        src = tmp_path / "test.wav"
        _write_wav(src, _make_speech_like(rms=0.1))
        prepared_path = tmp_path / "prepared.wav"
        shutil.copy(src, prepared_path)

        mock_backend = _make_mock_backend()
        mock_prep = _make_prep_patch(prepared_path)

        with (
            patch("memex.meetings.stt_backend.get_backend", return_value=mock_backend),
            patch("memex.meetings.audio_prep.prepare_audio", return_value=mock_prep),
        ):
            transcribe_meeting(src, diarize=False, language="fr")

        assert mock_backend.transcribe.call_args.kwargs.get("language") == "fr"


# ---------------------------------------------------------------------------
# Single temp-dir creation (MEDIUM-3)
# ---------------------------------------------------------------------------


class TestSingleTmpDir:
    def test_stereo_audio_creates_at_most_one_tmpdir(self, tmp_path, monkeypatch):
        """prepare_audio must call mkdtemp at most once even for stereo input."""
        import tempfile as _tempfile
        from memex.meetings.audio_prep import prepare_audio

        calls: list[dict] = []
        original_mkdtemp = _tempfile.mkdtemp

        def counting_mkdtemp(**kwargs):
            calls.append(kwargs)
            return original_mkdtemp(**kwargs)

        monkeypatch.setattr(_tempfile, "mkdtemp", counting_mkdtemp)

        # Stereo audio at a good level: needs to_mono but not normalization.
        # Without the fix a second mkdtemp would fire at the "write final" step.
        sr = 16000
        stereo = np.stack(
            [
                np.zeros(sr * 2, dtype=np.float32) + 0.07,
                np.zeros(sr * 2, dtype=np.float32) + 0.07,
            ],
            axis=1,
        )
        src = tmp_path / "stereo.wav"
        sf.write(str(src), stereo, sr)

        prepare_audio(src)  # no tmp_dir provided

        assert len(calls) <= 1, f"mkdtemp called {len(calls)} times, expected ≤1"


# ---------------------------------------------------------------------------
# Robust ffmpeg JSON parsing (LOW-3)
# ---------------------------------------------------------------------------


class TestFfmpegJsonParsing:
    def test_loudnorm_json_extracted_from_multiblock_stderr(self, tmp_path):
        """_ffmpeg_loudnorm must extract the loudnorm JSON even when stderr contains
        spurious {} fragments from other ffmpeg output lines."""
        import shutil as _shutil
        from unittest.mock import patch, MagicMock
        from memex.meetings.audio_prep import _ffmpeg_loudnorm

        if not _shutil.which("ffmpeg"):
            pytest.skip("ffmpeg not installed")

        fake_stderr = (
            "frame=100 fps=50.0 {proginfo}\n"
            "another line {foo: bar}\n"
            "[Parsed_loudnorm_0 @ 0x...] {\n"
            '        "input_i" : "-34.67",\n'
            '        "input_tp" : "-5.20",\n'
            '        "input_lra" : "3.40",\n'
            '        "input_thresh" : "-44.68",\n'
            '        "target_offset" : "0.67"\n'
            "}\n"
        )
        mock_pass1 = MagicMock()
        mock_pass1.stderr = fake_stderr
        mock_pass1.returncode = 0

        src = tmp_path / "test.wav"
        sf.write(str(src), np.zeros(16000, dtype="float32"), 16000)

        with patch("subprocess.run") as mock_run:
            # First call is pass1 (returns our fake stderr)
            # Second call is pass2 (we return success)
            mock_pass2 = MagicMock()
            mock_pass2.returncode = 0
            mock_run.side_effect = [mock_pass1, mock_pass2]
            result = _ffmpeg_loudnorm(src, tmp_path, "test")

        # Should not return None — JSON was found despite the spurious {} blocks
        assert result is not None, "Expected loudnorm to succeed with multiblock stderr"
