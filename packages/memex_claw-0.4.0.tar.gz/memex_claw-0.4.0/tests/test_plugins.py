"""Tests for plugin registry."""

from __future__ import annotations

import json

import pytest

from memex.plugins import (
    PluginInfo,
    PluginManifest,
    PluginRegistry,
    parse_manifest,
    get_plugin_registry,
    reset_plugin_registry,
)


@pytest.fixture
def plugin_dir(tmp_path):
    """Create a temp plugin dir with one valid plugin."""
    p = tmp_path / "plugins"
    p.mkdir()

    # Valid plugin
    valid = p / "my-tool"
    valid.mkdir()
    (valid / "openclaw.plugin.json").write_text(
        json.dumps(
            {
                "id": "my-tool",
                "name": "My Tool Plugin",
                "description": "A test tool plugin",
                "version": "1.2.0",
                "kind": "tool",
            }
        )
    )

    # Another plugin
    other = p / "other-plugin"
    other.mkdir()
    (other / "openclaw.plugin.json").write_text(
        json.dumps(
            {
                "id": "other-plugin",
                "name": "Other",
                "description": "Another plugin",
                "version": "0.1.0",
            }
        )
    )

    return p


@pytest.fixture
def empty_dir(tmp_path):
    p = tmp_path / "empty"
    p.mkdir()
    return p


class TestParseManifest:
    def test_parse_valid(self, plugin_dir):
        manifest = parse_manifest(plugin_dir / "my-tool" / "openclaw.plugin.json")
        assert manifest.id == "my-tool"
        assert manifest.name == "My Tool Plugin"
        assert manifest.description == "A test tool plugin"
        assert manifest.version == "1.2.0"
        assert manifest.kind == "tool"
        assert manifest.path == plugin_dir / "my-tool"

    def test_parse_minimal(self, tmp_path):
        d = tmp_path / "minimal"
        d.mkdir()
        (d / "openclaw.plugin.json").write_text(json.dumps({"id": "min"}))
        manifest = parse_manifest(d / "openclaw.plugin.json")
        assert manifest.id == "min"
        assert manifest.name == "min"
        assert manifest.version == "0.0.0"


class TestPluginRegistry:
    def test_scan_finds_plugins(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        plugins = reg.scan()
        assert len(plugins) == 2
        ids = {p.manifest.id for p in plugins}
        assert ids == {"my-tool", "other-plugin"}

    def test_scan_empty_dir(self, empty_dir):
        reg = PluginRegistry(empty_dir)
        assert reg.scan() == []

    def test_scan_nonexistent_dir(self, tmp_path):
        reg = PluginRegistry(tmp_path / "nope")
        assert reg.scan() == []

    def test_get(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        info = reg.get("my-tool")
        assert info is not None
        assert info.manifest.name == "My Tool Plugin"
        assert info.status == "installed"

    def test_get_missing(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        assert reg.get("nope") is None

    def test_mark_loaded(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        reg.mark_loaded("my-tool")
        assert reg.get("my-tool").status == "loaded"

    def test_mark_error(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        reg.mark_error("my-tool", "boom")
        info = reg.get("my-tool")
        assert info.status == "error"
        assert info.error == "boom"

    def test_installed_paths(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        paths = reg.installed_paths()
        assert len(paths) == 2
        assert str(plugin_dir / "my-tool") in paths

    def test_register_direct(self, tmp_path):
        reg = PluginRegistry(tmp_path)
        manifest = PluginManifest(
            id="direct",
            name="Direct",
            description="",
            version="1.0.0",
            path=tmp_path,
        )
        reg.register(PluginInfo(manifest=manifest))
        assert reg.get("direct") is not None

    def test_registry_has_no_runtime_state_dependency(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        reg.scan()
        reg.mark_loaded("my-tool")
        info = reg.get("my-tool")
        assert info is not None
        assert info.status == "loaded"

    def test_scan_skips_malformed(self, tmp_path):
        d = tmp_path / "plugins"
        d.mkdir()
        bad = d / "bad-plugin"
        bad.mkdir()
        (bad / "openclaw.plugin.json").write_text("not json")
        reg = PluginRegistry(d)
        assert reg.scan() == []

    def test_scan_skips_dirs_without_manifest(self, tmp_path):
        d = tmp_path / "plugins"
        d.mkdir()
        (d / "no-manifest").mkdir()
        reg = PluginRegistry(d)
        assert reg.scan() == []

    def test_scan_prunes_removed_plugins(self, plugin_dir):
        reg = PluginRegistry(plugin_dir)
        plugins = reg.scan()
        assert len(plugins) == 2

        manifest = plugin_dir / "other-plugin" / "openclaw.plugin.json"
        manifest.unlink()

        plugins = reg.scan()
        ids = {p.manifest.id for p in plugins}
        assert ids == {"my-tool"}


class TestSingleton:
    def test_get_plugin_registry_returns_same(self, tmp_path):
        reset_plugin_registry()
        try:
            r1 = get_plugin_registry(tmp_path)
            r2 = get_plugin_registry()
            assert r1 is r2
        finally:
            reset_plugin_registry()
