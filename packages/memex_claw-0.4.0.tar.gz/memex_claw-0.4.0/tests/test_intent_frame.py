"""Tests for the intent-frame bridge introduced in the 0.8 rethink migration."""

from memex.models import (
    ConversationTurn,
    InputClassification,
    InputClassificationType,
    IntentActionCandidate,
    IntentFrame,
    IntentFramePath,
)
from memex.intent_frame import build_intent_frame, render_intent_response
from memex.utcnow import utcnow


def test_build_intent_frame_marks_new_goal_as_act():
    classification = InputClassification(
        classification=InputClassificationType.NEW_GOAL,
        confidence=0.9,
        reasoning="new intent detected",
        suggested_title="Learn Rust",
    )

    frame = build_intent_frame(
        "I want to learn Rust",
        classification=classification,
        recent_turns=[],
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.ACT
    assert frame.summary == "Learn Rust"
    assert frame.unresolved_references == []


def test_build_intent_frame_requests_clarification_for_ambiguous_reference_without_context():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )

    frame = build_intent_frame(
        "Can you do that?",
        classification=classification,
        recent_turns=[],
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.CLARIFY
    assert "that" in frame.unresolved_references
    assert "clarify" in frame.rationale.lower()
    assert len(frame.slot_states) == 1
    assert frame.slot_states[0].name == "reference_that"
    assert frame.slot_states[0].status == "unresolved"
    assert frame.slot_states[0].required is True
    assert frame.selected_action_candidate is not None
    assert frame.selected_action_candidate.name == IntentFramePath.CLARIFY.value
    assert frame.selected_action_candidate.unresolved_required_slots == [
        "reference_that"
    ]


def test_build_intent_frame_does_not_clarify_when_recent_context_mentions_actionable_object():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    recent_turns = [
        ConversationTurn(
            role="assistant",
            content="I can retry the transcription job.",
            timestamp=utcnow(),
        ),
    ]

    frame = build_intent_frame(
        "Can you do that?",
        classification=classification,
        recent_turns=recent_turns,
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.DIRECT_ANSWER


def test_build_intent_frame_still_clarifies_when_recent_context_is_unrelated():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )
    recent_turns = [
        ConversationTurn(role="human", content="Hi there.", timestamp=utcnow()),
    ]

    frame = build_intent_frame(
        "Can you do that?",
        classification=classification,
        recent_turns=recent_turns,
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.CLARIFY
    assert "that" in frame.unresolved_references


def test_build_intent_frame_does_not_clarify_when_this_is_a_determiner():
    classification = InputClassification(
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        confidence=0.9,
        reasoning="user wants to save a page",
    )

    frame = build_intent_frame(
        "Save this article about Rust: https://example.com/rust-guide",
        classification=classification,
        recent_turns=[],
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.DIRECT_ANSWER
    assert frame.unresolved_references == []


def test_build_intent_frame_does_not_clarify_when_that_introduces_a_clause():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.85,
        reasoning="user wants to remember a fact",
    )

    frame = build_intent_frame(
        "Remember that I prefer Python over JavaScript",
        classification=classification,
        recent_turns=[],
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.DIRECT_ANSWER
    assert frame.unresolved_references == []


def test_build_intent_frame_does_not_clarify_when_that_starts_relative_clause():
    classification = InputClassification(
        classification=InputClassificationType.KNOWLEDGE_QUERY,
        confidence=0.9,
        reasoning="user is asking about database state",
    )

    frame = build_intent_frame(
        "Has the data in your knowledge store also been saved with vector embeddings?",
        classification=classification,
        recent_turns=[],
        active_goals=[],
    )

    assert frame.selected_path == IntentFramePath.DIRECT_ANSWER
    assert frame.unresolved_references == []


def test_build_intent_frame_abstains_on_low_confidence_fallback():
    classification = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.0,
        reasoning="classification failed - fallback",
    )

    frame = build_intent_frame(
        "Do it", classification=classification, recent_turns=[], active_goals=[]
    )

    assert frame.selected_path == IntentFramePath.ABSTAIN
    assert "fallback" in frame.rationale.lower()
    assert len(frame.slot_states) == 1
    assert frame.slot_states[0].name == "context_1"
    assert frame.slot_states[0].status == "missing"
    assert frame.slot_states[0].source == "missing_information"


def test_render_intent_response_for_clarify_and_abstain():
    clarify = build_intent_frame(
        "Do that",
        classification=InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.9,
            reasoning="general chat",
        ),
        recent_turns=[],
        active_goals=[],
    )
    abstain = build_intent_frame(
        "Do it",
        classification=InputClassification(
            classification=InputClassificationType.CONVERSATIONAL,
            confidence=0.0,
            reasoning="classification failed - fallback",
        ),
        recent_turns=[],
        active_goals=[],
    )

    assert "clarify" in render_intent_response(clarify).lower()
    assert "rephrase" in render_intent_response(abstain).lower()


def test_render_intent_response_names_only_unresolved_required_slots():
    frame = IntentFrame(
        raw_input="Do it",
        classification=InputClassificationType.CONVERSATIONAL,
        summary="Clarify target item",
        selected_path=IntentFramePath.DIRECT_ANSWER,
        selected_action_candidate=IntentActionCandidate(
            name=IntentFramePath.CLARIFY.value,
            selected=True,
            rationale="need target object",
            required_slots=["target_item"],
            unresolved_required_slots=["target_item"],
        ),
        slot_states=[
            {
                "name": "target_item",
                "status": "missing",
                "description": "which target item to act on",
                "source": "missing_information",
                "required": True,
            },
            {
                "name": "optional_context",
                "status": "missing",
                "description": "extra background",
                "source": "missing_information",
                "required": False,
            },
        ],
        confidence=0.8,
        rationale="need target object",
        created_at=utcnow(),
    )

    assert (
        render_intent_response(frame) == "Please clarify: which target item to act on"
    )
