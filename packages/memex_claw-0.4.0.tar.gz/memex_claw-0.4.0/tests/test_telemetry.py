from memex.events import UsageRecorded
from memex.telemetry import record_usage


def test_record_usage_publishes_event(monkeypatch):
    published = []

    monkeypatch.setattr("memex.telemetry.safe_publish", published.append)

    record_usage(
        cost_usd=0.25,
        total_tokens=120,
        session_id="sess-1",
        source="ingest_summary",
    )

    assert len(published) == 1
    assert isinstance(published[0], UsageRecorded)
    assert published[0].cost_usd == 0.25
    assert published[0].total_tokens == 120
