"""Tests for memex log CLI commands and SchedulerStore.get_all_runs."""

from datetime import datetime

import pytest

from memex.models import ConversationTurn
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore


@pytest.fixture()
def store(tmp_path):
    fs = FathomStore.open(str(tmp_path / "test.db"))
    s = FathomMemexStore(fs)
    yield s
    s.close()


class TestGetAllRuns:
    """Test SchedulerStore.get_all_runs."""

    def test_get_all_runs_empty(self, store):
        scheduler = store.scheduler
        assert scheduler.get_all_runs() == []

    def test_get_all_runs_returns_runs_across_tasks(self, store):
        scheduler = store.scheduler
        scheduler.record_run("task-a", status="completed")
        scheduler.record_run("task-b", status="completed")
        scheduler.record_run("task-a", status="failed")

        runs = scheduler.get_all_runs()
        assert len(runs) == 3
        task_ids = {r.task_id for r in runs}
        assert task_ids == {"task-a", "task-b"}

    def test_get_all_runs_respects_limit(self, store):
        scheduler = store.scheduler
        for i in range(10):
            scheduler.record_run(f"task-{i}", status="completed")

        runs = scheduler.get_all_runs(limit=3)
        assert len(runs) == 3

    def test_get_all_runs_ordered_by_started_at_desc(self, store):
        scheduler = store.scheduler
        r1 = scheduler.record_run("task-a", status="completed")
        r2 = scheduler.record_run("task-b", status="completed")
        r3 = scheduler.record_run("task-c", status="completed")

        runs = scheduler.get_all_runs()
        run_ids = [r.run_id for r in runs]
        # Most recent first
        assert run_ids == [r3, r2, r1]


class TestLogCLI:
    """Test CLI log commands produce output."""

    def test_log_conversations_no_data(self, store, capsys):
        from memex.cli import _cmd_log_conversations

        class Args:
            session = None
            role = None
            since = None
            n = 50

        import unittest.mock

        with unittest.mock.patch("memex.cli._make_fathom_store", return_value=store):
            _cmd_log_conversations(Args())

        captured = capsys.readouterr()
        assert "No conversation log entries" in captured.out

    def test_log_conversations_with_data(self, store, capsys):
        from memex.cli import _cmd_log_conversations

        turn = ConversationTurn(
            role="human",
            content="hello world",
            timestamp=datetime(2025, 1, 1, 10, 0, 0),
        )
        store.log_turn("sess-test", turn)

        class Args:
            session = None
            role = None
            since = None
            n = 50

        import unittest.mock

        with unittest.mock.patch("memex.cli._make_fathom_store", return_value=store):
            _cmd_log_conversations(Args())

        captured = capsys.readouterr()
        assert "hello world" in captured.out
        assert "human" in captured.out

    def test_log_audit_no_data(self, store, capsys):
        from memex.cli import _cmd_log_audit

        class Args:
            connector = None
            since = None
            n = 50

        import unittest.mock

        with unittest.mock.patch("memex.cli._make_fathom_store", return_value=store):
            _cmd_log_audit(Args())

        captured = capsys.readouterr()
        assert "No audit log entries" in captured.out

    def test_log_runs_no_data(self, store, capsys):
        from memex.cli import _cmd_log_runs

        class Args:
            task_id = None
            n = 50

        import unittest.mock

        with unittest.mock.patch("memex.cli._make_fathom_store", return_value=store):
            _cmd_log_runs(Args())

        captured = capsys.readouterr()
        assert "No task runs found" in captured.out

    def test_log_runs_with_data(self, store, capsys):
        from memex.cli import _cmd_log_runs

        scheduler = store.scheduler
        run_id = scheduler.record_run("test-task", status="queued")
        scheduler.complete_run(run_id, status="completed", result="done ok")

        class Args:
            task_id = None
            n = 50

        import unittest.mock

        with unittest.mock.patch("memex.cli._make_fathom_store", return_value=store):
            _cmd_log_runs(Args())

        captured = capsys.readouterr()
        assert "completed" in captured.out
        assert "done ok" in captured.out
