"""Operational smoke test for startup plus first public API turn."""

from __future__ import annotations

import asyncio
import os
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from memex.cli import main
from memex.interfaces.api import MemexAPI
from memex.interfaces.caller import CallerContext
from memex.interfaces.tui.app import MemexApp
from memex.interfaces.tui.widgets.header_bar import HeaderBar
from memex.interfaces.tui.widgets.intent_drawer import IntentDrawer
from memex.llm import TokenUsage
from memex.memory.conversation_extract import CombinedExtractReflectResult
from memex.models import InputClassification, InputClassificationType

_MOCK_USAGE = TokenUsage(
    prompt_tokens=100,
    completion_tokens=50,
    total_tokens=150,
    cost_usd=0.001,
)


def _mock_classify_conversational(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )


def _mock_extract(**kwargs):
    return CombinedExtractReflectResult(
        reflection_note="operational smoke",
        confidence=0.8,
    )


@contextmanager
def _operational_startup_patches():
    with (
        patch("memex.doctor.startup_post", return_value=None),
        patch("memex.loop.startup_health_check", return_value=(None, [], {})),
        patch("memex.loop._build_middleware_chain", return_value=None),
        patch("memex.memory.embeddings.get_embedding_backend", return_value=None),
    ):
        yield


def test_memex_operational_smoke_startup_and_first_turn(tmp_path):
    db_path = tmp_path / "memex.db"

    with _operational_startup_patches():
        api = MemexAPI.create(str(db_path))

    try:
        caller = CallerContext.owner("cli", "operational-smoke")

        startup_status = api.status(caller)
        assert startup_status["goals_total"] == 0
        assert startup_status["goals_active"] == 0
        assert startup_status["session_turns"] == 0

        startup_state = api.self_state(caller)
        assert startup_state["process"]["store_path"] == str(db_path)
        assert startup_state["session"]["turn_count"] == 0
        assert startup_state["session"]["active_interface"] == "cli"
        assert any(
            item["capability_id"] == "surface/status"
            for item in startup_state["agent_self"]["capabilities"]
        )

        with (
            patch("memex.classify.classify_input", _mock_classify_conversational),
            patch("memex.loop._use_message_builder", return_value=False),
            patch("memex.loop._should_auto_retrieve_for_turn", return_value=False),
            patch(
                "memex.llm.chat_with_usage",
                return_value=("Operational smoke response.", _MOCK_USAGE),
            ),
            patch(
                "memex.memory.conversation_extract.extract_and_reflect", _mock_extract
            ),
        ):
            response, session = api.chat("hello", caller)

        assert response == "Operational smoke response."
        assert session.turn_count == 1
        assert session.session_id

        runtime_stats = session.working_memory["_turn_runtime_stats"]
        assert runtime_stats["turn_ordinal"] == 1
        assert runtime_stats["tool_call_count"] == 0
        assert runtime_stats["phase_timings_ms"]["total"] >= 0
        assert runtime_stats["prompt_metrics"]["system_prompt_chars"] > 0

        status_after = api.status(caller)
        assert status_after["session_id"] == session.session_id[:8]
        assert status_after["session_turns"] == 1

        state_after = api.self_state(caller)
        assert state_after["session"]["session_id"] == session.session_id
        assert state_after["session"]["turn_count"] == 1
        assert state_after["session"]["active_interface"] == "cli"
    finally:
        api.close()


def test_cli_tui_operational_smoke_starts_app_and_closes_api(tmp_path):
    """TUI now connects to the service daemon. We mock MemexServiceClient."""
    observed: dict[str, object] = {}

    fake_client = MagicMock()
    fake_client.status.return_value = {"status": "ok", "goals_active": 1}
    fake_client.intent.return_value = [
        {
            "goal_id": "g1",
            "title": "Ship the docs",
            "status": "active",
            "priority": "high",
        }
    ]
    fake_client.list_meetings.return_value = []
    fake_client.list_notifications.return_value = []
    fake_client.list_tasks.return_value = []
    fake_client.list_subagents.return_value = []
    fake_client.self_state.return_value = {
        "process": {},
        "session": {},
        "agent_self": {},
    }
    fake_client.close.return_value = None
    # Make _has_local_store return False (no 'store' attr on mock)
    del fake_client.store

    def _run_once(self, *args, **kwargs):
        async def _exercise() -> None:
            async with self.run_test() as pilot:
                await pilot.pause()
                header = self.query_one("#header-bar", HeaderBar)
                drawer = self.query_one("#intent-drawer", IntentDrawer)
                tree = drawer.query_one("#intent-tree-inner")
                observed["header_mode"] = header.mode
                observed["header_goal"] = header.focal_goal
                observed["goal_labels"] = [
                    node.label.plain
                    if hasattr(node.label, "plain")
                    else str(node.label)
                    for node in tree.root.children
                ]

        asyncio.run(_exercise())

    with (
        patch(
            "memex.interfaces.service_client.MemexServiceClient",
            return_value=fake_client,
        ),
        patch.object(MemexApp, "run", _run_once),
    ):
        main(["tui", "--mode", "review", "--service", "http://127.0.0.1:9999"])

    assert observed["header_mode"] == "review"
    assert observed["header_goal"] == "1 active goals"
    assert any("Ship the docs" in label for label in observed["goal_labels"])


def test_cli_telegram_operational_smoke_starts_bot_and_closes_api(tmp_path, capsys):
    store_path = str(tmp_path / "memex.db")
    fake_api = MagicMock()
    fake_api.connector_health = [
        SimpleNamespace(
            name="openclaw",
            status="connected",
            tools_discovered=2,
            error=None,
        )
    ]
    bot_instance = MagicMock()

    with (
        patch.dict(
            os.environ,
            {
                "MEMEX_STORE": store_path,
                "TELEGRAM_BOT_TOKEN": "123:ABC",
                "TELEGRAM_USER_ID": "42",
            },
            clear=False,
        ),
        patch(
            "memex.interfaces.api.MemexAPI.create", return_value=fake_api
        ) as create_api,
        patch(
            "memex.interfaces.telegram.TelegramBot", return_value=bot_instance
        ) as bot_cls,
    ):
        main(["telegram", "--force"])

    create_api.assert_called_once_with(store_path)
    bot_cls.assert_called_once()
    config, api = bot_cls.call_args.args
    assert config.bot_token == "123:ABC"
    assert config.allowed_user_ids == {42}
    assert api is fake_api
    bot_instance.run.assert_called_once_with()
    fake_api.close.assert_called_once_with()

    captured = capsys.readouterr()
    assert "[+] openclaw: connected (2 tools)" in captured.out
    assert "Starting Telegram bot" in captured.out
