"""Tests for CLI — always-exit-0, subcommands."""

from __future__ import annotations

import os
import runpy
import sys
from contextlib import contextmanager
from unittest.mock import MagicMock, patch

from memex.cli import main
from memex.llm import TokenUsage
from memex.memory.conversation_extract import CombinedExtractReflectResult
from memex.models import InputClassification, InputClassificationType

_MOCK_USAGE = TokenUsage(
    prompt_tokens=100,
    completion_tokens=50,
    total_tokens=150,
    cost_usd=0.001,
)


def _mock_classify_conversational(*args, **kwargs):
    return InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
        confidence=0.8,
        reasoning="general chat",
    )


def _mock_extract(**kwargs):
    return CombinedExtractReflectResult(
        reflection_note="cli smoke",
        confidence=0.8,
    )


class _NoSpinner:
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return None


@contextmanager
def _operational_startup_patches():
    with (
        patch("memex.doctor.startup_post", return_value=None),
        patch("memex.loop.startup_health_check", return_value=(None, [], {})),
        patch("memex.loop._build_middleware_chain", return_value=None),
        patch("memex.memory.embeddings.get_embedding_backend", return_value=None),
    ):
        yield


def test_cli_no_args(capsys):
    """No args shows help, exits 0."""
    main([])
    captured = capsys.readouterr()
    assert "memex" in captured.out.lower() or captured.out == ""


def test_cli_version(capsys):
    main(["--version"])
    captured = capsys.readouterr()
    assert "0.1.0" in captured.out


def test_cli_goal_list_empty(tmp_path, capsys):
    store_path = str(tmp_path / "test.db")
    with patch.dict(os.environ, {"MEMEX_STORE": store_path}):
        main(["goal", "list"])
    captured = capsys.readouterr()
    assert "No goals found" in captured.out


def test_cli_goal_create_and_list(tmp_path, capsys):
    store_path = str(tmp_path / "test.db")
    with patch.dict(os.environ, {"MEMEX_STORE": store_path}):
        main(["goal", "create", "Learn Rust"])
        captured = capsys.readouterr()
        assert "Created" in captured.out
        assert "Learn Rust" in captured.out

        main(["goal", "list"])
        captured = capsys.readouterr()
        assert "Learn Rust" in captured.out


def test_cli_status(tmp_path, capsys):
    store_path = str(tmp_path / "test.db")
    with patch.dict(
        os.environ,
        {"MEMEX_STORE": store_path, "MEMEX_KNOWLEDGE_BACKEND": "sqlite"},
    ):
        main(["status"])
    captured = capsys.readouterr()
    assert "Memex Status" in captured.out
    assert "Store:" in captured.out
    assert "Goals:" in captured.out


def test_cli_status_quick(tmp_path, capsys):
    store_path = str(tmp_path / "test.db")
    with patch.dict(os.environ, {"MEMEX_STORE": store_path}):
        main(["status-quick"])
    captured = capsys.readouterr()
    assert "Schema" in captured.out
    assert "Goals" in captured.out


def test_cli_goal_show_not_found(tmp_path, capsys):
    store_path = str(tmp_path / "test.db")
    with patch.dict(os.environ, {"MEMEX_STORE": store_path}):
        main(["goal", "show", "nonexistent"])
    captured = capsys.readouterr()
    assert "not found" in captured.out.lower()


def test_cli_invalid_command_exits_nonzero():
    """Invalid commands should exit with non-zero status."""
    import pytest

    with pytest.raises(SystemExit):
        main(["nonexistent-command"])
    with pytest.raises(SystemExit):
        main(["goal", "list", "--invalid-flag"])


def test_cli_missing_subcommand_shows_help():
    """Missing subcommand should show help, not crash."""
    main(["goal"])


def test_cli_chat_operational_smoke_runs_first_turn_and_persists_session(
    tmp_path, capsys
):
    store_path = str(tmp_path / "chat-smoke.db")

    with (
        patch.dict(os.environ, {"MEMEX_STORE": store_path}, clear=False),
        _operational_startup_patches(),
        patch("builtins.input", side_effect=["hello", "exit"]),
        patch("memex.cli._Spinner", _NoSpinner),
        patch(
            "memex.scheduler.get_session_briefing", return_value="Operational briefing."
        ),
        patch("memex.classify.classify_input", _mock_classify_conversational),
        patch("memex.loop._use_message_builder", return_value=False),
        patch("memex.loop._should_auto_retrieve_for_turn", return_value=False),
        patch(
            "memex.llm.chat_with_usage",
            return_value=("Operational smoke response.", _MOCK_USAGE),
        ),
        patch("memex.memory.conversation_extract.extract_and_reflect", _mock_extract),
    ):
        main(["chat", "--mode", "review"])

    captured = capsys.readouterr()
    assert "Operational briefing." in captured.out
    assert "memex> Operational smoke response." in captured.out
    assert "Goodbye." in captured.out

    # Verify persistence via fathomdb (MemexAPI.create now writes to fathom.db)
    from pathlib import Path
    from memex.fathom_store import FathomStore
    from memex.fathom_facade import FathomMemexStore

    fathom_path = str(Path(store_path).parent / "fathom.db")
    fathom = FathomStore.open(fathom_path)
    fstore = FathomMemexStore(fathom)
    try:
        session = fstore.load_session()
        assert session is not None
        assert session.session_id

        turns = fstore.query_conversation_log(limit=10)
        assert len(turns) >= 2
        roles = [t["role"] for t in turns[:2]]
        assert "human" in roles
        assert "assistant" in roles
    finally:
        fathom.close()


def test_cmd_tui_reads_service_url_from_file(tmp_path):
    """_cmd_tui auto-discovers service URL from .memex/service.url when no flag or env var is set."""
    import argparse
    from memex.cli import _cmd_tui

    url_file = tmp_path / ".memex" / "service.url"
    url_file.parent.mkdir(parents=True)
    url_file.write_text("http://127.0.0.1:9999\n")

    captured_url = {}

    def fake_service_client(base_url, **kwargs):
        captured_url["url"] = base_url
        client = MagicMock()
        client.status.return_value = {"status": "ok"}
        return client

    with (
        patch.dict(os.environ, {"MEMEX_SERVICE_URL": ""}, clear=False),
        patch("memex.paths.resolve_service_url_file", return_value=url_file),
        patch(
            "memex.interfaces.service_client.MemexServiceClient",
            side_effect=fake_service_client,
        ),
        patch("memex.interfaces.tui.app.MemexApp") as mock_app_cls,
    ):
        mock_app_cls.return_value.run = MagicMock()
        args = argparse.Namespace(service=None, mode="normal")
        try:
            _cmd_tui(args)
        except Exception:
            pass  # app.run() may fail in test environment; we only care about URL discovery

    assert captured_url.get("url") == "http://127.0.0.1:9999"


def test_cmd_tui_flag_overrides_url_file(tmp_path):
    """--service flag takes precedence over .memex/service.url."""
    import argparse
    from memex.cli import _cmd_tui

    url_file = tmp_path / ".memex" / "service.url"
    url_file.parent.mkdir(parents=True)
    url_file.write_text("http://127.0.0.1:9999\n")

    captured_url = {}

    def fake_service_client(base_url, **kwargs):
        captured_url["url"] = base_url
        client = MagicMock()
        client.status.return_value = {"status": "ok"}
        return client

    with (
        patch.dict(os.environ, {"MEMEX_SERVICE_URL": ""}, clear=False),
        patch("memex.paths.resolve_service_url_file", return_value=url_file),
        patch(
            "memex.interfaces.service_client.MemexServiceClient",
            side_effect=fake_service_client,
        ),
        patch("memex.interfaces.tui.app.MemexApp") as mock_app_cls,
    ):
        mock_app_cls.return_value.run = MagicMock()
        args = argparse.Namespace(service="http://192.168.1.100:8321", mode="normal")
        try:
            _cmd_tui(args)
        except Exception:
            pass

    assert captured_url.get("url") == "http://192.168.1.100:8321"


def test_cli_module_invocation_runs_main(capsys):
    with patch.object(sys, "argv", ["memex", "--version"]):
        runpy.run_module("memex.cli", run_name="__main__")

    captured = capsys.readouterr()
    assert "0.1.0" in captured.out
