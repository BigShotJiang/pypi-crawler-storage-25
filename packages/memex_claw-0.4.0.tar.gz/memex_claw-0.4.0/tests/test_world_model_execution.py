from __future__ import annotations

from datetime import datetime

from memex.memory.retrieval import retrieve_for_context
from memex.memory.world_model_reads import resolve_world_model_reads
from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    WorldModelActionPlan,
    WorldModelExecutionRecord,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


def _seed_plan(store) -> datetime:
    now = utcnow()
    goal = Goal(
        goal_id="goal-execution-rollout",
        title="Ship the canonical execution slice",
        description="Land the execution slice safely.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            title="Execution rollout plan",
            summary="Drive execution through canonical execution records.",
            status="active",
            selected_step_id="step-execute-rollout",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-approve-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="approval",
            title="Approve rollout",
            description="Approve the rollout before execution continues.",
            status="done",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="execution",
            title="Execute rollout",
            description="Execute the rollout and report progress.",
            status="active",
            ordinal=2,
            blocked_reason="",
            depends_on_step_ids=["step-approve-rollout"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    return now


def test_execution_record_and_transition_roundtrip_updates_plan_step_state(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)

    store.upsert_world_model_execution_record(
        WorldModelExecutionRecord(
            execution_id="execution-rollout-1",
            session_id="session-rollout",
            conversation_turn_id=4,
            goal_id="goal-execution-rollout",
            plan_id="plan-execution-rollout",
            step_id="step-execute-rollout",
            execution_kind="tool_call",
            title="Run rollout verifier",
            summary="Verifier found an approval blocker.",
            status="blocked",
            source_record_type="world_model_action",
            source_record_id="action-rollout-1",
            payload={"tool_name": "verify_rollout"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-1",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-1",
            transition_kind="blocked",
            from_status="active",
            to_status="blocked",
            blocked_reason="Waiting on final approval signoff.",
            blocked_by_step_ids=["step-approve-rollout"],
            progress_pct=35,
            summary="Verifier surfaced an approval blocker.",
            payload={"source": "tool"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    loaded_step = store.load_world_model_plan_step("step-execute-rollout")
    loaded_execution = store.load_world_model_execution_record("execution-rollout-1")
    plan = store.load_world_model_action_plan("plan-execution-rollout")
    transitions = store.list_world_model_plan_step_transitions(
        step_id="step-execute-rollout"
    )
    execution_links = store.list_world_model_provenance_links(
        source_record_type="world_model_execution_record",
        source_record_id="execution-rollout-1",
    )
    transition_links = store.list_world_model_provenance_links(
        source_record_type="world_model_plan_step_transition",
        source_record_id="transition-rollout-1",
    )

    assert loaded_step is not None
    assert loaded_step.status == "blocked"
    assert loaded_step.blocked_reason == "Waiting on final approval signoff."
    assert loaded_step.blocked_by_step_ids == ["step-approve-rollout"]
    assert loaded_step.progress_pct == 35
    assert loaded_execution is not None
    assert loaded_execution.step_id == "step-execute-rollout"
    assert loaded_execution.plan_id == "plan-execution-rollout"
    assert loaded_execution.source_record_type == "world_model_action"
    assert plan is not None
    assert plan.status == "blocked"
    assert plan.selected_step_id == "step-execute-rollout"
    assert transitions[0].execution_id == "execution-rollout-1"
    assert transitions[0].to_status == "blocked"
    assert {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in execution_links
    } == {
        ("for_goal", "world_model_goal", "goal-execution-rollout"),
        ("for_plan", "world_model_action_plan", "plan-execution-rollout"),
        ("executes_step", "world_model_plan_step", "step-execute-rollout"),
        ("records_source", "world_model_action", "action-rollout-1"),
    }
    assert {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in transition_links
    } == {
        ("part_of_plan", "world_model_action_plan", "plan-execution-rollout"),
        ("for_goal", "world_model_goal", "goal-execution-rollout"),
        ("updates_step", "world_model_plan_step", "step-execute-rollout"),
        ("emitted_by_execution", "world_model_execution_record", "execution-rollout-1"),
        ("blocked_by_step", "world_model_plan_step", "step-approve-rollout"),
    }


def test_execution_and_transition_reads_surface_canonical_documents(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)
    store.upsert_world_model_execution_record(
        WorldModelExecutionRecord(
            execution_id="execution-rollout-2",
            session_id="session-rollout",
            conversation_turn_id=5,
            goal_id="goal-execution-rollout",
            plan_id="plan-execution-rollout",
            step_id="step-execute-rollout",
            execution_kind="decision_outcome",
            title="Commit to rollout execution",
            summary="Decision committed to the rollout step.",
            status="in_progress",
            source_record_type="world_model_action",
            source_record_id="action-rollout-2",
            payload={"decision_name": "direct_answer"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-2",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-2",
            transition_kind="progress_update",
            from_status="active",
            to_status="in_progress",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=60,
            summary="Execution moved into active progress.",
            payload={"source": "decision"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    reads = resolve_world_model_reads(
        content_store=store.content, world_model_store=store
    )
    assert reads is not None

    step_hit = reads.load_plan_step_document("step-execute-rollout")
    execution_hit = reads.load_execution_record_document("execution-rollout-2")
    transition_hit = reads.load_plan_step_transition_document("transition-rollout-2")
    result = retrieve_for_context(
        "rollout execution active progress",
        2000,
        content_store=store.content,
        world_model_store=store,
    )

    assert step_hit is not None
    assert any(
        link["relationship"] == "executes_step"
        and link["source_record_type"] == "world_model_execution_record"
        and link["source_record_id"] == "execution-rollout-2"
        for link in step_hit.incoming_links
    )
    assert any(
        link["relationship"] == "updates_step"
        and link["source_record_type"] == "world_model_plan_step_transition"
        and link["source_record_id"] == "transition-rollout-2"
        for link in step_hit.incoming_links
    )
    assert execution_hit is not None
    assert execution_hit.record.execution_kind == "decision_outcome"
    assert execution_hit.record.step_id == "step-execute-rollout"
    assert transition_hit is not None
    assert transition_hit.transition.progress_pct == 60
    assert transition_hit.transition.to_status == "in_progress"
    assert (
        "world_model_plan_step_transition:transition-rollout-2" in result.document_ids
    )


def test_step_transition_advances_plan_selection_and_status(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-finalize-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="verification",
            title="Finalize rollout",
            description="Finalize after execution completes.",
            status="active",
            ordinal=3,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-advance",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-advance",
            transition_kind="done",
            from_status="active",
            to_status="done",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=100,
            summary="Execution step completed.",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    plan = store.load_world_model_action_plan("plan-execution-rollout")
    step = store.load_world_model_plan_step("step-execute-rollout")

    assert step is not None
    assert step.status == "done"
    assert step.progress_pct == 100
    assert plan is not None
    assert plan.status == "active"
    assert plan.selected_step_id == "step-finalize-rollout"


def test_step_transition_completes_plan_when_last_step_finishes(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-final-step",
            goal_id="goal-final-step",
            title="Finish the final step",
            summary="Single-step plan.",
            status="active",
            selected_step_id="step-final-step",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-final-step",
            plan_id="plan-final-step",
            goal_id="goal-final-step",
            step_kind="execution",
            title="Finish the work",
            description="Complete the last step.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-final-step",
            step_id="step-final-step",
            plan_id="plan-final-step",
            goal_id="goal-final-step",
            execution_id="execution-final-step",
            transition_kind="done",
            from_status="active",
            to_status="done",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=100,
            summary="Final step completed.",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    plan = store.load_world_model_action_plan("plan-final-step")

    assert plan is not None
    assert plan.status == "done"
    assert plan.selected_step_id is None


def test_step_transition_progress_update_keeps_plan_selected_step_on_transition_target(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)

    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-progress-authority",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-progress-authority",
            transition_kind="progress_update",
            from_status="active",
            to_status="in_progress",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=80,
            summary="Execution progress came from canonical transition application.",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    step = store.load_world_model_plan_step("step-execute-rollout")
    plan = store.load_world_model_action_plan("plan-execution-rollout")

    assert step is not None
    assert step.status == "in_progress"
    assert step.progress_pct == 80
    assert plan is not None
    assert plan.status == "active"
    assert plan.selected_step_id == "step-execute-rollout"


def test_step_transition_unblocks_next_step_when_dependencies_complete(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-verify-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="verification",
            title="Verify rollout",
            description="Verify after execution completes.",
            status="blocked",
            ordinal=3,
            blocked_reason="Waiting on execution step.",
            depends_on_step_ids=["step-execute-rollout"],
            blocked_by_step_ids=["step-execute-rollout"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-unblock",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-unblock",
            transition_kind="done",
            from_status="active",
            to_status="done",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=100,
            summary="Execution step completed and should unblock verification.",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    next_step = store.load_world_model_plan_step("step-verify-rollout")
    plan = store.load_world_model_action_plan("plan-execution-rollout")

    assert next_step is not None
    assert next_step.status == "active"
    assert next_step.blocked_reason == ""
    assert next_step.blocked_by_step_ids == []
    assert plan is not None
    assert plan.selected_step_id == "step-verify-rollout"


def test_step_transition_keeps_future_step_blocked_when_dependencies_still_open(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = _seed_plan(store)
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-verify-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="verification",
            title="Verify rollout",
            description="Verify after approval and execution complete.",
            status="blocked",
            ordinal=3,
            blocked_reason="Waiting on earlier steps.",
            depends_on_step_ids=["step-approve-rollout", "step-execute-rollout"],
            blocked_by_step_ids=["step-approve-rollout", "step-execute-rollout"],
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-approve-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            step_kind="approval",
            title="Approve rollout",
            description="Approval still outstanding.",
            status="active",
            ordinal=1,
            blocked_reason="",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-rollout-partial-unblock",
            step_id="step-execute-rollout",
            plan_id="plan-execution-rollout",
            goal_id="goal-execution-rollout",
            execution_id="execution-rollout-partial-unblock",
            transition_kind="done",
            from_status="active",
            to_status="done",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=100,
            summary="Execution step completed but approval is still open.",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )

    future_step = store.load_world_model_plan_step("step-verify-rollout")
    plan = store.load_world_model_action_plan("plan-execution-rollout")

    assert future_step is not None
    assert future_step.status == "blocked"
    assert future_step.blocked_reason == "Waiting on earlier steps."
    assert future_step.blocked_by_step_ids == [
        "step-approve-rollout",
        "step-execute-rollout",
    ]
    assert plan is not None
    assert plan.selected_step_id == "step-approve-rollout"
