"""Tests for src/memex/interfaces/json_util.py."""

from __future__ import annotations

import dataclasses
from datetime import date, datetime, time, timezone

import pytest

from memex.interfaces.json_util import coerce_json, model_to_dict


# ---------------------------------------------------------------------------
# coerce_json
# ---------------------------------------------------------------------------


def test_coerce_dict_recursive():
    now = datetime(2025, 1, 15, 12, 0, 0)
    result = coerce_json({"ts": now, "count": 3})
    assert result == {"ts": "2025-01-15T12:00:00", "count": 3}


def test_coerce_nested_dict():
    result = coerce_json({"outer": {"inner": datetime(2025, 1, 1)}})
    assert result == {"outer": {"inner": "2025-01-01T00:00:00"}}


def test_coerce_list():
    result = coerce_json([1, "a", datetime(2025, 6, 1)])
    assert result == [1, "a", "2025-06-01T00:00:00"]


def test_coerce_tuple_becomes_list():
    result = coerce_json((1, 2, 3))
    assert result == [1, 2, 3]


def test_coerce_datetime():
    dt = datetime(2025, 3, 25, 10, 30, 0, tzinfo=timezone.utc)
    assert coerce_json(dt) == "2025-03-25T10:30:00+00:00"


def test_coerce_date():
    """date objects must be handled via hasattr(isoformat), not isinstance(datetime)."""
    d = date(2025, 3, 25)
    assert coerce_json(d) == "2025-03-25"


def test_coerce_time():
    t = time(14, 30, 0)
    assert coerce_json(t) == "14:30:00"


def test_coerce_primitives_passthrough():
    assert coerce_json("hello") == "hello"
    assert coerce_json(42) == 42
    assert coerce_json(3.14) == pytest.approx(3.14)
    assert coerce_json(True) is True
    assert coerce_json(False) is False
    assert coerce_json(None) is None


def test_coerce_fallback_str_conversion():
    class Weird:
        def __str__(self):
            return "weird_repr"

    assert coerce_json(Weird()) == "weird_repr"


def test_coerce_fallback_returns_none_when_str_raises():
    class Unstrifiable:
        def __str__(self):
            raise RuntimeError("no str")

    assert coerce_json(Unstrifiable()) is None


def test_coerce_enum_via_str():
    import enum

    class Color(enum.Enum):
        RED = "red"

    # Enums have no isoformat; fallback to str gives "Color.RED"
    result = coerce_json(Color.RED)
    assert isinstance(result, str)


# ---------------------------------------------------------------------------
# model_to_dict
# ---------------------------------------------------------------------------


def test_model_to_dict_none_returns_none():
    assert model_to_dict(None) is None


def test_model_to_dict_list_recursive():
    @dataclasses.dataclass
    class Item:
        name: str
        value: int

    result = model_to_dict([Item("a", 1), Item("b", 2)])
    assert result == [{"name": "a", "value": 1}, {"name": "b", "value": 2}]


def test_model_to_dict_dataclass():
    @dataclasses.dataclass
    class Point:
        x: float
        y: float
        created: datetime = dataclasses.field(
            default_factory=lambda: datetime(2025, 1, 1)
        )

    result = model_to_dict(Point(1.0, 2.0))
    assert result == {"x": 1.0, "y": 2.0, "created": "2025-01-01T00:00:00"}


def test_model_to_dict_plain_dict():
    d = {"key": "value", "ts": datetime(2025, 1, 1)}
    result = model_to_dict(d)
    assert result == {"key": "value", "ts": "2025-01-01T00:00:00"}


def test_model_to_dict_model_dump():
    class FakePydantic:
        def model_dump(self):
            return {"field": "data", "at": datetime(2025, 6, 1)}

    result = model_to_dict(FakePydantic())
    assert result == {"field": "data", "at": "2025-06-01T00:00:00"}


def test_model_to_dict_pydantic_v1_dict():
    class FakePydanticV1:
        def dict(self):
            return {"legacy": True}

    result = model_to_dict(FakePydanticV1())
    assert result == {"legacy": True}


def test_model_to_dict_generic_object_via_vars():
    class Obj:
        def __init__(self):
            self.x = 10
            self.ts = datetime(2025, 2, 14)

    result = model_to_dict(Obj())
    assert result == {"x": 10, "ts": "2025-02-14T00:00:00"}


def test_model_to_dict_primitive_returned_unchanged():
    assert model_to_dict(42) == 42
    assert model_to_dict("hello") == "hello"


def test_model_to_dict_nested_dataclass():
    @dataclasses.dataclass
    class Inner:
        val: int

    @dataclasses.dataclass
    class Outer:
        inner: Inner
        name: str

    result = model_to_dict(Outer(inner=Inner(99), name="test"))
    assert result == {"inner": {"val": 99}, "name": "test"}
