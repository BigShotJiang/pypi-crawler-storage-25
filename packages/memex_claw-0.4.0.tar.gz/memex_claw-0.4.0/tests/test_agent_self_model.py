"""Direct tests for the 0.8 agent self-model helpers."""

from unittest.mock import MagicMock

from memex.agent_self_model import (
    apply_diagnostics_observation,
    apply_repair_observation,
    apply_runtime_observation,
    blocked_tool_capability_tags,
    guarded_route_reason,
    has_guarded_route_signal,
    load_agent_self_model,
    save_agent_self_model,
)
from memex.models import AgentCapability, AgentLimitation, AgentSelfModel


def test_runtime_observation_projects_runtime_state():
    runtime_state = {
        "process": {"degraded_modes": ["store_locked"]},
        "goals": {"active": 2},
        "session": {"session_id": "s1"},
        "queues": {"work_queue_pending": 1},
        "meetings": {"active_recording": None},
        "subagents": {"running_count": 0},
        "interfaces": [
            {
                "name": "telegram",
                "status": "running",
                "owner": "connector",
                "last_error": "",
            },
        ],
        "connectors": [
            {
                "name": "openclaw-bridge",
                "status": "degraded",
                "error": "bridge disconnected",
                "tools_discovered": 0,
            },
        ],
        "services": [
            {
                "id": "scheduler",
                "name": "Scheduler",
                "status": "running",
                "last_error": "",
            },
        ],
        "plugins": {
            "items": [
                {
                    "plugin_id": "demo",
                    "name": "Demo",
                    "loaded": True,
                    "status": "loaded",
                    "error": "",
                },
            ],
        },
        "errors": [],
    }

    model = apply_runtime_observation(AgentSelfModel(), runtime_state)

    capability_ids = {cap.capability_id for cap in model.capabilities}
    limitation_ids = {lim.limitation_id for lim in model.limitations}
    assert "surface/status" in capability_ids
    assert "interface/telegram" in capability_ids
    assert "connector/openclaw-bridge" in capability_ids
    assert "service/scheduler" in capability_ids
    assert "plugin/demo" in capability_ids
    assert "degraded/store_locked" in limitation_ids
    assert model.operational_state["goals"]["active"] == 2


def test_diagnostics_and_repair_observations_capture_failures():
    runtime_state = {
        "process": {"degraded_modes": []},
        "goals": {},
        "session": {},
        "queues": {},
        "meetings": {},
        "subagents": {},
        "interfaces": [],
        "connectors": [],
        "services": [],
        "plugins": {"items": []},
        "errors": [
            {"subsystem": "scheduler", "message": "stalled", "recoverable": False}
        ],
    }
    diagnostics = {
        "checks": [
            {"name": "db", "status": "warn", "detail": "slow"},
            {"name": "telegram_config", "status": "ok", "detail": "configured"},
        ]
    }
    last_repair = {
        "ok": False,
        "action": "restart_queue",
        "detail": "engine not registered",
    }

    model = apply_runtime_observation(AgentSelfModel(), runtime_state)
    model = apply_diagnostics_observation(model, diagnostics)
    model = apply_repair_observation(model, last_repair)

    limitation_ids = {lim.limitation_id for lim in model.limitations}
    assert "diagnostic/db" in limitation_ids
    assert "repair/restart_queue" in limitation_ids
    assert any(lim.severity == "error" for lim in model.limitations)
    assert model.last_diagnostics == diagnostics
    assert model.last_repair == last_repair


def test_load_and_save_agent_self_model_helpers():
    store = MagicMock()

    empty = load_agent_self_model(store)
    assert empty.agent_id == "memex"

    save_agent_self_model(empty, store)
    store.save_agent_self_model.assert_called_once()


def test_apply_runtime_observation_preserves_existing_canonical_capabilities():
    model = AgentSelfModel(
        capabilities=[
            AgentCapability(
                capability_id="planner/canonical",
                title="Canonical planner",
                status="available",
                detail="Stored semantic capability.",
                source="canonical",
            )
        ]
    )

    updated = apply_runtime_observation(
        model,
        {
            "process": {"degraded_modes": []},
            "goals": {"active": 1},
            "session": {"session_id": "s1"},
            "queues": {},
            "meetings": {},
            "subagents": {},
            "interfaces": [],
            "connectors": [
                {
                    "name": "gmail",
                    "status": "unavailable",
                    "error": "auth missing",
                    "tools_discovered": 0,
                }
            ],
            "services": [],
            "plugins": {"items": []},
            "errors": [],
        },
    )

    capability_ids = {cap.capability_id for cap in updated.capabilities}
    assert "planner/canonical" in capability_ids
    assert "connector/gmail" in capability_ids
    assert updated.operational_state["goals"]["active"] == 1


def test_apply_diagnostics_and_repair_observations_replace_managed_limitations():
    model = AgentSelfModel()

    diagnosed = apply_diagnostics_observation(
        model,
        {"checks": [{"name": "db", "status": "warn", "detail": "slow"}]},
    )
    repaired = apply_repair_observation(
        diagnosed,
        {"ok": False, "action": "restart_queue", "detail": "engine not registered"},
    )
    healthy = apply_diagnostics_observation(
        repaired,
        {"checks": [{"name": "db", "status": "ok", "detail": "healthy"}]},
    )

    limitation_ids = {lim.limitation_id for lim in healthy.limitations}
    assert "repair/restart_queue" in limitation_ids
    assert "diagnostic/db" not in limitation_ids
    assert healthy.last_diagnostics["checks"][0]["status"] == "ok"


def test_blocked_tool_capability_tags_follow_unavailable_self_capabilities():
    model = AgentSelfModel(
        capabilities=[
            AgentCapability(
                capability_id="connector/gmail",
                title="Connector: Gmail",
                status="unavailable",
                detail="Auth missing",
                source="connector",
            )
        ]
    )

    assert blocked_tool_capability_tags(model) == {"comm.gmail"}


def test_guarded_route_reason_follows_durable_degradation_signals():
    degraded = AgentSelfModel(degraded_modes=["projection_stale"])
    limited = AgentSelfModel(
        limitations=[
            AgentLimitation(
                limitation_id="degraded/vector-store",
                title="vector store degraded",
                detail="projection stale",
                severity="warn",
                recoverable=True,
                source="runtime",
            )
        ]
    )

    assert has_guarded_route_signal(degraded) is True
    assert "degraded modes active" in guarded_route_reason(degraded)
    assert has_guarded_route_signal(limited) is True
    assert "degradation signal" in guarded_route_reason(limited)
