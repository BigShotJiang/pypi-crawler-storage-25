"""Tests for decay functions (Phase 3 Step 4)."""

from datetime import timedelta

from conftest import make_item
from memex.memory.decay import (
    DEFAULT_HALF_LIFE,
    current_decay_weight,
    is_expired,
    item_decay_weight,
)
from memex.models import ItemType
from memex.utcnow import utcnow


def test_no_decay_at_zero():
    now = utcnow()
    w = current_decay_weight(now, 30.0, now)
    assert w == 1.0


def test_half_decay_at_half_life():
    now = utcnow()
    accessed = now - timedelta(days=30)
    w = current_decay_weight(accessed, 30.0, now)
    assert abs(w - 0.5) < 0.01


def test_quarter_at_two_half_lives():
    now = utcnow()
    accessed = now - timedelta(days=60)
    w = current_decay_weight(accessed, 30.0, now)
    assert abs(w - 0.25) < 0.01


def test_pinned_always_one():
    now = utcnow()
    accessed = now - timedelta(days=365)
    w = current_decay_weight(accessed, 30.0, now, pinned=True)
    assert w == 1.0


def test_milestone_slower_decay():
    now = utcnow()
    accessed = now - timedelta(days=30)
    w_normal = current_decay_weight(accessed, 30.0, now)
    w_milestone = current_decay_weight(accessed, 30.0, now, is_milestone=True)
    assert w_milestone > w_normal


def test_item_decay_weight_wrapper():
    now = utcnow()
    item = make_item()
    w = item_decay_weight(item, now)
    assert 0.0 < w <= 1.0


def test_is_expired_true():
    now = utcnow()
    item = make_item(expires_at=now - timedelta(hours=1))
    assert is_expired(item, now) is True


def test_is_expired_false():
    now = utcnow()
    item = make_item(expires_at=now + timedelta(hours=1))
    assert is_expired(item, now) is False


def test_is_expired_none():
    now = utcnow()
    item = make_item()
    assert is_expired(item, now) is False


def test_default_half_life_types():
    assert DEFAULT_HALF_LIFE[ItemType.ARTICLE] == 60.0
    assert DEFAULT_HALF_LIFE[ItemType.CONVERSATION] == 180.0
    assert DEFAULT_HALF_LIFE[ItemType.THOUGHT] == 14.0


def test_zero_half_life_returns_zero():
    now = utcnow()
    accessed = now - timedelta(days=1)
    w = current_decay_weight(accessed, 0.0, now)
    assert w == 0.0


def test_negative_half_life_returns_zero():
    now = utcnow()
    accessed = now - timedelta(days=1)
    w = current_decay_weight(accessed, -5.0, now)
    assert w == 0.0
