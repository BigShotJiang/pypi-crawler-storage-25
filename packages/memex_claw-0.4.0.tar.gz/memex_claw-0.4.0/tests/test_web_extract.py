"""Tests for web content extraction."""

from __future__ import annotations

from memex.connectors.web_fetcher import FetchResult
from memex.memory.web_extract import (
    ExtractedContent,
    extract_from_fetch_result,
    extract_from_html,
)


_ARTICLE_HTML = """\
<!DOCTYPE html>
<html>
<head>
    <title>Understanding Graph Databases</title>
    <meta name="author" content="Jane Smith">
    <meta name="description" content="A deep dive into graph database technology">
    <meta property="article:published_time" content="2025-12-15">
</head>
<body>
    <nav>Home | About | Contact</nav>
    <article>
        <h1>Understanding Graph Databases</h1>
        <p>Graph databases represent data as nodes and edges, making them
        ideal for highly connected datasets. Unlike relational databases
        that use tables and joins, graph databases traverse relationships
        directly, enabling faster queries on connected data.</p>

        <p>The property graph model is the most common approach. Each node
        and edge can have key-value properties attached. This flexibility
        makes it easy to model real-world domains like social networks,
        knowledge graphs, and recommendation engines.</p>

        <h2>Query Languages</h2>
        <p>Cypher is the most popular graph query language, originally
        developed for Neo4j. It uses ASCII-art patterns to describe
        graph traversals. For example, MATCH (a)-[:KNOWS]->(b) finds
        all pairs of people where a knows b.</p>

        <p>Other query languages include Gremlin (Apache TinkerPop),
        SPARQL (for RDF graphs), and GQL (the upcoming ISO standard).
        Each has different strengths depending on the use case.</p>

        <h2>Use Cases</h2>
        <p>Graph databases excel at fraud detection, where suspicious
        patterns emerge from relationship analysis. They power
        recommendation systems by finding items connected through
        shared attributes. Knowledge management platforms use them
        to model concepts and their relationships.</p>

        <table>
            <tr><th>Database</th><th>Model</th></tr>
            <tr><td>Neo4j</td><td>Property Graph</td></tr>
            <tr><td>LadybugDB</td><td>Property Graph</td></tr>
        </table>
    </article>
    <footer>Copyright 2025</footer>
</body>
</html>
"""

_MINIMAL_HTML = "<html><body><p>Short.</p></body></html>"

_EMPTY_HTML = "<html><body></body></html>"

_LONG_BODY_FALLBACK_HTML = """\
<!DOCTYPE html>
<html>
<head>
    <title>ClawTeam Multi-Agent Orchestration Tutorial</title>
    <meta property="og:title" content="ClawTeam Multi-Agent Orchestration Tutorial">
</head>
<body>
    <article>
        <p>In this comprehensive tutorial, we present the core architecture of ClawTeam, an open-source agent swarm framework with OpenAI function calling integration and task orchestration primitives for complex workflows.</p>
        <p>The system coordinates leader agents, worker agents, and task dependencies.</p>
        <p>The full tutorial walks through implementation details and monitoring dashboards.</p>
        <p>Each component is explained in a deterministic step-by-step format.</p>
        <p>This makes the approach reproducible for engineering teams.</p>
        <p>It also shows how to scale multi-agent workflows safely.</p>
    </article>
</body>
</html>
"""


def test_extract_article():
    """Full article extraction with metadata."""
    result = extract_from_html(_ARTICLE_HTML, url="https://example.com/graphs")

    assert result.is_substantial
    assert result.word_count > 100
    assert result.url == "https://example.com/graphs"
    assert "graph" in result.body.lower()
    assert "Cypher" in result.body
    assert result.raw_length == len(_ARTICLE_HTML)


def test_extract_metadata():
    """Title is extracted (from content or HTML head)."""
    result = extract_from_html(_ARTICLE_HTML, url="https://example.com/graphs")

    # Title should be found — either from meta or body first line fallback
    assert result.title
    assert "Graph" in result.title or "graph" in result.title
    assert isinstance(result.author, str)
    assert isinstance(result.description, str)


def test_extract_prefers_html_title_over_long_body_first_line():
    """HTML title should win over a long body-first-line fallback title."""
    result = extract_from_html(
        _LONG_BODY_FALLBACK_HTML,
        url="https://example.com/clawteam",
    )

    assert result.title == "ClawTeam Multi-Agent Orchestration Tutorial"


def test_extract_strips_navigation():
    """Nav and footer boilerplate should be removed."""
    result = extract_from_html(_ARTICLE_HTML, url="https://example.com/graphs")

    # Navigation links should not appear in extracted body
    assert "Home | About | Contact" not in result.body


def test_extract_preserves_tables():
    """Table content should be captured."""
    result = extract_from_html(_ARTICLE_HTML, url="https://example.com/graphs")

    # At least some table content should survive
    assert "Neo4j" in result.body or "LadybugDB" in result.body


def test_extract_minimal_html():
    """Very short content is not substantial."""
    result = extract_from_html(_MINIMAL_HTML, url="https://example.com/short")

    assert not result.is_substantial
    assert result.word_count < 50


def test_extract_empty_html():
    """Empty HTML returns empty ExtractedContent."""
    result = extract_from_html(_EMPTY_HTML, url="https://example.com/empty")

    assert not result.is_substantial
    assert result.body == "" or result.word_count == 0


def test_extract_empty_string():
    """Empty input returns empty ExtractedContent."""
    result = extract_from_html("", url="https://example.com")

    assert not result.is_substantial
    assert result.raw_length == 0


def test_extract_garbage():
    """Random binary-like content doesn't crash."""
    result = extract_from_html("\\x00\\xff\\xfe not html at all", url="")

    assert isinstance(result, ExtractedContent)
    assert isinstance(result.body, str)


def test_extract_from_html_falls_back_when_trafilatura_returns_none():
    """Useful article text should still be recovered when the primary extractor fails."""
    fallback_html = """\
    <html>
    <head>
        <title>Release Notes</title>
        <meta name="description" content="Deployment and status details">
    </head>
    <body>
        <nav>Home Pricing Docs</nav>
        <main>
            <h1>Release Notes</h1>
            <p>The deployment completed successfully across all regions and the scheduler backlog is now empty.</p>
            <p>Background ingestion workers are healthy, API startup checks are green, and no recovery action is needed.</p>
            <p>Operators can continue normal activity while monitoring the next routine sync window.</p>
        </main>
        <footer>copyright</footer>
    </body>
    </html>
    """

    with __import__("unittest.mock").mock.patch(
        "trafilatura.bare_extraction", return_value=None
    ):
        result = extract_from_html(fallback_html, url="https://example.com/release")

    assert result.title == "Release Notes"
    assert "deployment completed successfully" in result.body.lower()
    assert "Home Pricing Docs" not in result.body
    assert result.description == "Deployment and status details"
    assert result.word_count >= 20


def test_extract_from_fetch_result_supports_text_plain_fast_path():
    """Text/plain responses should bypass HTML extraction and keep their text."""
    result = extract_from_fetch_result(
        FetchResult(
            url="https://example.com/status.txt",
            status_code=200,
            text=(
                "Operational Status\n\n"
                "All systems are healthy and background jobs are current. "
                "No maintenance window is active."
            ),
            ok=True,
            headers={"content-type": "text/plain; charset=utf-8"},
        )
    )

    assert result.title == "Operational Status"
    assert "background jobs are current" in result.body
    assert result.word_count >= 10
    assert result.raw_length > 0


def test_extracted_content_frozen():
    """ExtractedContent is immutable."""
    result = ExtractedContent(url="https://example.com", body="test", word_count=1)
    try:
        result.body = "modified"  # type: ignore[misc]
        assert False, "Should have raised FrozenInstanceError"
    except AttributeError:
        pass
