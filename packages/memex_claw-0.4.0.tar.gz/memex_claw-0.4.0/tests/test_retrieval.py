"""Tests for retrieval module.

After the fathomdb 0.3.1 cutover, the mock-heavy ``_retrieve_candidates``
test was replaced with a direct unit test on ``_apply_outcome_lead_sort``.
The outcome-lead tiebreak is a sort-function feature — the test covers the
sort directly rather than mocking every seam in the retrieval pipeline.
End-to-end coverage of the full pipeline lives in the e2e tests under
``tests/e2e/`` and in ``test_world_model_*`` modules that exercise
``retrieve_for_context`` against a real ephemeral FathomStore.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from memex.memory.retrieval import (
    RetrievalCandidate,
    _apply_outcome_lead_sort,
    _OUTCOME_LEAD_MARGIN,
    _OUTCOME_LEAD_THRESHOLD,
    _search_canonical_action_hits,
)
from memex.memory.retrieval_documents import RetrievalDocument
from memex.memory.world_model_reads import CanonicalOutcomeHit


def _make_document(
    *, document_id: str, title: str, relevance_pct: int = 100
) -> RetrievalDocument:
    return RetrievalDocument(
        document_id=document_id,
        item_id=None,
        title=title,
        body_text="",
        source_url="",
        reputation_display="unrated",
        relevance_pct=relevance_pct,
        world_model_context_lines=(),
    )


def _make_candidate(
    *,
    document_id: str,
    title: str,
    score: float,
    document_family: str,
    canonical_backed: bool = True,
    relevance_pct: int = 100,
) -> RetrievalCandidate:
    return RetrievalCandidate(
        document_id=document_id,
        item_id=None,
        item=None,
        knowledge=None,
        document=_make_document(
            document_id=document_id, title=title, relevance_pct=relevance_pct
        ),
        score=score,
        relevance=score,
        reputation=0.5,
        decay_weight=1.0,
        canonical_backed=canonical_backed,
        document_family=document_family,
    )


def test_outcome_lead_sort_allows_margin_outcome_to_lead_slightly_stronger_knowledge():
    """An outcome at 0.62 leads a knowledge at 0.64 because both:

    * 0.62 ≥ _OUTCOME_LEAD_THRESHOLD (0.6), and
    * 0.62 + _OUTCOME_LEAD_MARGIN (0.05) = 0.67 ≥ 0.64.
    """
    knowledge = _make_candidate(
        document_id="content_item:k-1",
        title="General note",
        score=0.64,
        document_family="knowledge",
    )
    outcome = _make_candidate(
        document_id="world_model_action:action-1",
        title="Selected action: direct_answer",
        score=0.62,
        document_family="canonical_outcome",
    )
    sorted_candidates = _apply_outcome_lead_sort([knowledge, outcome])
    assert sorted_candidates[0].document_family == "canonical_outcome"
    assert sorted_candidates[0].document.title == "Selected action: direct_answer"


def test_outcome_lead_sort_does_not_lead_when_below_threshold():
    """An outcome at 0.55 loses to a knowledge at 0.56 because the outcome
    is below _OUTCOME_LEAD_THRESHOLD (0.6) and cannot claim the lead."""
    knowledge = _make_candidate(
        document_id="content_item:k-1",
        title="Strong note",
        score=0.56,
        document_family="knowledge",
    )
    outcome = _make_candidate(
        document_id="world_model_action:action-1",
        title="Weak outcome",
        score=0.55,
        document_family="canonical_outcome",
    )
    sorted_candidates = _apply_outcome_lead_sort([knowledge, outcome])
    assert sorted_candidates[0].document_family == "knowledge"


def test_outcome_lead_sort_does_not_lead_when_knowledge_exceeds_margin():
    """An outcome at 0.60 loses to a knowledge at 0.80 because the gap
    exceeds _OUTCOME_LEAD_MARGIN (0.05)."""
    knowledge = _make_candidate(
        document_id="content_item:k-1",
        title="Dominant note",
        score=0.80,
        document_family="knowledge",
    )
    outcome = _make_candidate(
        document_id="world_model_action:action-1",
        title="Trailing outcome",
        score=0.60,
        document_family="canonical_outcome",
    )
    sorted_candidates = _apply_outcome_lead_sort([knowledge, outcome])
    assert sorted_candidates[0].document_family == "knowledge"


def test_outcome_lead_sort_preserves_within_group_order_by_score():
    """Inside the outcome-lead group and inside the non-lead group, higher
    composite score sorts first."""
    strong_outcome = _make_candidate(
        document_id="world_model_action:strong",
        title="Strong outcome",
        score=0.75,
        document_family="canonical_outcome",
    )
    weak_outcome = _make_candidate(
        document_id="world_model_action:weak",
        title="Weak outcome",
        score=0.65,
        document_family="canonical_outcome",
    )
    knowledge = _make_candidate(
        document_id="content_item:k-1",
        title="Note",
        score=0.70,
        document_family="knowledge",
    )
    sorted_candidates = _apply_outcome_lead_sort(
        [knowledge, weak_outcome, strong_outcome]
    )
    # Both outcomes qualify for the lead (≥0.6 threshold and within 0.05 of
    # the knowledge hit at 0.70); inside the lead group they sort by score.
    assert sorted_candidates[0].document.title == "Strong outcome"
    assert sorted_candidates[1].document.title == "Weak outcome"
    assert sorted_candidates[2].document.title == "Note"


def test_outcome_lead_sort_tiebreak_on_canonical_backed():
    """With identical scores, canonical-backed candidates outrank non-canonical."""
    canonical = _make_candidate(
        document_id="content_item:canonical",
        title="Canonical",
        score=0.5,
        document_family="knowledge",
        canonical_backed=True,
    )
    non_canonical = _make_candidate(
        document_id="content_item:legacy",
        title="Legacy",
        score=0.5,
        document_family="knowledge",
        canonical_backed=False,
    )
    sorted_candidates = _apply_outcome_lead_sort([non_canonical, canonical])
    assert sorted_candidates[0].document.title == "Canonical"


def test_outcome_lead_sort_constants_visible_for_callers():
    """Guard against accidental constant drift — the threshold and margin
    are load-bearing for the outcome-lead feature."""
    assert _OUTCOME_LEAD_THRESHOLD == 0.6
    assert _OUTCOME_LEAD_MARGIN == 0.05


def test_search_canonical_action_hits_uses_grouped_expand_for_secondary():
    """_search_canonical_action_hits must drive the WMObservation → WMAction
    secondary pass through SearchBuilder.expand().execute_grouped() (fathomdb
    0.4.1+ API), NOT the legacy per-hit .traverse() round-trip.
    """
    # Primary WMAction search returns no hits (empty properties).
    primary_rows = MagicMock()
    primary_rows.hits = []

    # Secondary search builder: search() -> builder; .expand(...) -> builder;
    # .execute_grouped() -> GroupedQueryRows-like with a parent_action slot.
    action_node = MagicMock()
    action_node.kind = "WMAction"
    action_node.properties = {"action_id": "act-42"}

    root_rows = MagicMock()
    root_rows.nodes = [action_node]

    slot_rows = MagicMock()
    slot_rows.slot = "parent_action"
    slot_rows.roots = [root_rows]

    grouped = MagicMock()
    grouped.expansions = [slot_rows]
    grouped.roots = []
    grouped.was_degraded = False

    search_builder = MagicMock()
    search_builder.execute.return_value = primary_rows
    search_builder.expand.return_value = search_builder
    search_builder.execute_grouped.return_value = grouped

    nodes_builder = MagicMock()
    nodes_builder.search.return_value = search_builder

    engine = MagicMock()
    engine.nodes.return_value = nodes_builder

    loaded_hit = CanonicalOutcomeHit(
        action_id="act-42",
        meeting_id=None,
        conversation_turn_id=None,
        action_kind="direct_answer",
        action_name="n",
        status="committed",
    )
    wmr = MagicMock()
    wmr.load_canonical_outcome.return_value = loaded_hit

    hits, _rows = _search_canonical_action_hits(
        wmr=wmr,
        engine=engine,
        query="some query",
        limit=10,
    )

    # The grouped expand must have been invoked (no N+1 traverse loop).
    search_builder.expand.assert_called()
    search_builder.execute_grouped.assert_called_once()

    # Legacy filter_logical_id_eq.traverse() path must NOT be used.
    # nodes_builder.filter_logical_id_eq should not have been touched.
    assert not any(
        name == "filter_logical_id_eq"
        for name, _args, _kwargs in nodes_builder.method_calls
    )

    # The action_id from the grouped expansion is returned as a canonical
    # outcome hit.
    wmr.load_canonical_outcome.assert_any_call("act-42")
    assert len(hits) == 1
