from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from unittest.mock import Mock

from memex.memory.retrieval import _log_retrieval_timings, _retrieve_candidates


def _make_content_store() -> Mock:
    store = Mock()
    store.fts_search_chunks.return_value = []
    store.fts_search.return_value = []
    store.list_items.return_value = []
    return store


def test_retrieve_candidates_logs_timings_with_fts_and_total_keys(monkeypatch):
    calls = []

    def capture(query, timings_ms, result_counts, *, quality_counts=None):
        calls.append((query, timings_ms, result_counts))

    monkeypatch.setattr("memex.memory.retrieval._log_retrieval_timings", capture)

    now = datetime.now(timezone.utc)
    _retrieve_candidates(
        query="test query",
        content_store=_make_content_store(),
        world_model_store=None,
        rank_config=None,
        route_profile=None,
        now=now,
        max_items=10,
    )

    assert len(calls) == 1
    timings_ms = calls[0][1]
    assert "fts" in timings_ms
    assert "total" in timings_ms
    assert timings_ms["total"] >= 0


def test_retrieve_candidates_total_timing_covers_entire_call(monkeypatch):
    captured = {}

    def capture(query, timings_ms, result_counts, *, quality_counts=None):
        captured["timings_ms"] = timings_ms

    monkeypatch.setattr("memex.memory.retrieval._log_retrieval_timings", capture)

    now = datetime.now(timezone.utc)
    t0 = time.monotonic()
    _retrieve_candidates(
        query="test query",
        content_store=_make_content_store(),
        world_model_store=None,
        rank_config=None,
        route_profile=None,
        now=now,
        max_items=10,
    )
    elapsed_ms = (time.monotonic() - t0) * 1000

    timings_ms = captured["timings_ms"]
    assert timings_ms["total"] >= 0
    assert timings_ms["total"] <= elapsed_ms + 100


def test_log_retrieval_timings_includes_quality_counts(caplog):
    quality_counts = {
        "strict": 7,
        "relaxed": 3,
        "vector": 2,
        "fallback": 1,
        "degraded": 0,
    }
    with caplog.at_level(logging.INFO, logger="memex.memory.retrieval"):
        _log_retrieval_timings(
            "some query",
            {"fts": 1, "total": 2},
            {"fts": 4},
            quality_counts=quality_counts,
        )
    joined = " ".join(r.getMessage() for r in caplog.records)
    assert "strict=7" in joined
    assert "relaxed=3" in joined
    assert "vector=2" in joined
    assert "fallback=1" in joined
    assert "degraded=0" in joined


class _FakeSearchRows:
    def __init__(
        self,
        *,
        hits=None,
        strict_hit_count=0,
        relaxed_hit_count=0,
        vector_hit_count=0,
        fallback_used=False,
        was_degraded=False,
    ):
        self.hits = hits or []
        self.strict_hit_count = strict_hit_count
        self.relaxed_hit_count = relaxed_hit_count
        self.vector_hit_count = vector_hit_count
        self.fallback_used = fallback_used
        self.was_degraded = was_degraded


class _FakeSearchBuilder:
    def __init__(self, rows: _FakeSearchRows) -> None:
        self._rows = rows

    def search(self, query, limit):
        return self

    def execute(self):
        return self._rows


class _FakeEngine:
    def __init__(self, rows_by_kind: dict[str, _FakeSearchRows]) -> None:
        self._rows_by_kind = rows_by_kind

    def nodes(self, kind: str):
        rows = self._rows_by_kind.get(kind, _FakeSearchRows())
        return _FakeSearchBuilder(rows)


def test_retrieve_candidates_aggregates_search_rows_quality_counts(monkeypatch):
    captured: dict = {}

    def capture(query, timings_ms, result_counts, *, quality_counts=None):
        captured["quality_counts"] = quality_counts

    monkeypatch.setattr("memex.memory.retrieval._log_retrieval_timings", capture)

    # Two distinct kinds each report strict_hit_count so we can assert the
    # accumulator sums across SearchRows returned from WM helper calls.
    rows_by_kind = {
        "WMKnowledgeObject": _FakeSearchRows(
            strict_hit_count=4,
            relaxed_hit_count=1,
            vector_hit_count=2,
            fallback_used=True,
            was_degraded=False,
        ),
        "WMAction": _FakeSearchRows(
            strict_hit_count=3,
            relaxed_hit_count=2,
            vector_hit_count=0,
            fallback_used=False,
            was_degraded=True,
        ),
        "WMObservation": _FakeSearchRows(
            strict_hit_count=2,
            relaxed_hit_count=0,
            vector_hit_count=1,
            fallback_used=False,
            was_degraded=False,
        ),
    }
    fake_engine = _FakeEngine(rows_by_kind)

    class _FakeStore:
        class _Inner:
            class _Fathom:
                class _WM:
                    pass

                world_model = _WM()

            _fathom = _Fathom()

        _store = _Inner()

    fake_wmr = _FakeStore()
    fake_wmr._store._fathom.world_model._engine = fake_engine  # type: ignore[attr-defined]
    fake_wmr.search_dependency_documents = lambda q, limit=0: []  # type: ignore[attr-defined]

    monkeypatch.setattr(
        "memex.memory.retrieval.resolve_world_model_reads",
        lambda content_store, world_model_store: fake_wmr,
    )

    now = datetime.now(timezone.utc)
    _retrieve_candidates(
        query="anything",
        content_store=_make_content_store(),
        world_model_store=Mock(),
        rank_config=None,
        route_profile=None,
        now=now,
        max_items=10,
    )

    qc = captured["quality_counts"]
    assert qc is not None
    # strict accumulates across WMKnowledgeObject (4) + WMAction (3)
    # + 10 WM_SIMPLE_SPECS (each 0) = 7. The WMObservation→WMAction
    # secondary pass now runs via SearchBuilder.expand().execute_grouped()
    # (fathomdb 0.4.1+) which returns GroupedQueryRows, not SearchRows,
    # so its strict counts are not aggregated into the SearchRows totals.
    assert qc["strict"] >= 7
    assert qc["relaxed"] >= 3
    assert qc["vector"] >= 2
    # fallback flag was set by at least one SearchRows
    assert qc["fallback"] >= 1
    # degraded flag was set by at least one SearchRows
    assert qc["degraded"] >= 1
