"""Tests for temporal query parsing and search."""

from datetime import datetime, timedelta

from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.temporal import (
    TemporalRange,
    TemporalResult,
    extract_temporal_from_query,
    format_temporal_results,
    parse_temporal,
    temporal_search,
)


def test_parse_today():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("today", now)
    assert result is not None
    assert result.start == datetime(2026, 3, 8, 0, 0, 0)
    assert result.end.date() == now.date()


def test_parse_yesterday():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("yesterday", now)
    assert result is not None
    assert result.start == datetime(2026, 3, 7, 0, 0, 0)
    assert result.end.date() == datetime(2026, 3, 7).date()


def test_parse_day_before_yesterday():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("day before yesterday", now)
    assert result is not None
    assert result.start == datetime(2026, 3, 6, 0, 0, 0)
    assert result.end.date() == datetime(2026, 3, 6).date()
    assert result.expression == "day before yesterday"


def test_parse_n_days_ago():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("3 days ago", now)
    assert result is not None
    expected_day = datetime(2026, 3, 5)
    assert result.start.date() == expected_day.date()
    assert result.end.date() == expected_day.date()


def test_parse_last_week():
    now = datetime(2026, 3, 8, 14, 30)  # Sunday
    result = parse_temporal("last week", now)
    assert result is not None
    # Last week should start on Monday (March 2) to Sunday (March 8 not included)
    # now.weekday() for Sunday (2026-03-08) is 6
    expected_start = now - timedelta(days=now.weekday() + 7)
    expected_start = expected_start.replace(hour=0, minute=0, second=0, microsecond=0)
    assert result.start == expected_start
    # End should be 7 days later minus 1 microsecond
    assert result.end < expected_start + timedelta(days=7)


def test_parse_this_month():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("this month", now)
    assert result is not None
    assert result.start == datetime(2026, 3, 1, 0, 0, 0)
    assert result.end.month == 3
    assert result.end.day == 31


def test_parse_last_tuesday():
    # 2026-03-08 is a Sunday, so last Tuesday is 2026-03-03
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("last Tuesday", now)
    assert result is not None
    assert result.start.date() == datetime(2026, 3, 3).date()


def test_parse_march_5th():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("March 5th", now)
    assert result is not None
    assert result.start == datetime(2026, 3, 5, 0, 0, 0)
    assert result.end.date() == datetime(2026, 3, 5).date()


def test_parse_january_2024():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("January 2024", now)
    assert result is not None
    assert result.start == datetime(2024, 1, 1, 0, 0, 0)
    assert result.end.month == 1
    assert result.end.day == 31
    assert result.end.year == 2024


def test_parse_between():
    now = datetime(2026, 3, 8, 14, 30)
    result = parse_temporal("between yesterday and today", now)
    assert result is not None
    assert result.start.date() == datetime(2026, 3, 7).date()
    assert result.end.date() == datetime(2026, 3, 8).date()


def test_parse_none():
    result = parse_temporal("hello world")
    assert result is None


def test_extract_temporal_from_query():
    now = datetime(2026, 3, 8, 14, 30)
    cleaned, temporal_range = extract_temporal_from_query(
        "what was I working on yesterday?", now
    )
    assert temporal_range is not None
    assert temporal_range.start.date() == datetime(2026, 3, 7).date()
    # The temporal expression should be removed from the query
    assert "yesterday" not in cleaned


def test_temporal_search_conversations(tmp_path):
    """Temporal search finds conversation log entries via FathomDB."""
    from memex.models import ConversationTurn

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)

    store.log_turn(
        "s1",
        ConversationTurn(
            role="human",
            content="working on tests",
            timestamp=datetime(2026, 3, 5, 10, 0),
        ),
    )
    store.log_turn(
        "s1",
        ConversationTurn(
            role="assistant",
            content="sure, let me help with tests",
            timestamp=datetime(2026, 3, 5, 10, 1),
        ),
    )

    tr = TemporalRange(
        start=datetime(2026, 3, 5, 0, 0),
        end=datetime(2026, 3, 5, 23, 59, 59),
        expression="march 5th",
    )
    results = temporal_search("tests", tr, conn=store.conn, content_store=store.content)
    assert len(results) >= 1
    assert any("tests" in r.snippet.lower() for r in results)
    store.close()


def test_temporal_search_goals(tmp_path):
    """Temporal search finds goals via FathomDB."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)

    from conftest import make_goal

    goal = make_goal(title="Learn Rust")
    # Override timestamps for deterministic search
    goal.created_at = datetime(2026, 3, 5, 9, 0)
    goal.updated_at = datetime(2026, 3, 5, 9, 0)
    goal.last_touched_at = datetime(2026, 3, 5, 9, 0)
    store.create_goal(goal)

    tr = TemporalRange(
        start=datetime(2026, 3, 5, 0, 0),
        end=datetime(2026, 3, 5, 23, 59, 59),
        expression="march 5th",
    )
    results = temporal_search("Rust", tr, conn=store.conn, content_store=store.content)
    assert len(results) >= 1
    assert any("Rust" in r.title for r in results)
    store.close()


def test_format_temporal_results():
    tr = TemporalRange(
        start=datetime(2026, 3, 5, 0, 0),
        end=datetime(2026, 3, 5, 23, 59, 59),
        expression="march 5th",
    )
    results = [
        TemporalResult(
            source_type="conversation",
            title="[human] working on tests",
            snippet="working on tests today",
            timestamp=datetime(2026, 3, 5, 10, 0),
            source_id="conv:1",
        ),
    ]
    formatted = format_temporal_results(results, tr)
    assert "march 5th" in formatted
    assert "working on tests" in formatted
    assert "conversation" in formatted

    # Empty results return empty string
    assert format_temporal_results([], tr) == ""
