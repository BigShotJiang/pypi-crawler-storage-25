"""Tests for Pydantic models."""

from memex.models import (
    ConversationTurn,
    Goal,
    GoalBlock,
    GoalFail,
    GoalPriority,
    GoalStatus,
    HumanPartnerProfile,
    InputClassification,
    InputClassificationType,
    Item,
    ItemType,
    LinkConfig,
    LinkCreator,
    NewSubgoal,
    PRIORITY_WEIGHTS,
    Provenance,
    ProvenanceLink,
    RankConfig,
    ReflectResult,
    SessionContext,
    Source,
    Summary,
    TrailItem,
)
from memex.utcnow import utcnow


def test_goal_defaults():
    now = utcnow()
    g = Goal(
        goal_id="abc",
        title="Learn Rust",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
    )
    assert g.status == GoalStatus.ACTIVE
    assert g.priority == GoalPriority.MEDIUM
    assert g.parent_id is None
    assert g.metadata == {}


def test_goal_serialization():
    now = utcnow()
    g = Goal(
        goal_id="abc",
        title="Learn Rust",
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={"source": "chat"},
    )
    data = g.model_dump_json()
    g2 = Goal.model_validate_json(data)
    assert g2.goal_id == "abc"
    assert g2.metadata["source"] == "chat"


def test_goal_status_values():
    assert GoalStatus.ACTIVE.value == "active"
    assert GoalStatus.FAILED.value == "failed"
    assert GoalStatus.BLOCKED.value == "blocked"


def test_priority_weights():
    assert PRIORITY_WEIGHTS[GoalPriority.CRITICAL] == 1.0
    assert PRIORITY_WEIGHTS[GoalPriority.LOW] == 0.25


def test_input_classification_defaults():
    ic = InputClassification(
        classification=InputClassificationType.CONVERSATIONAL,
    )
    assert ic.goal_id is None
    assert ic.confidence == 0.0


def test_reflect_result_defaults():
    rr = ReflectResult()
    assert rr.intent_advanced == []
    assert rr.new_subgoals == []
    assert rr.confidence == 0.0


def test_new_subgoal():
    sg = NewSubgoal(parent_id="abc", title="Sub task")
    assert sg.priority == GoalPriority.MEDIUM


def test_goal_block():
    gb = GoalBlock(goal_id="abc", reason="waiting on API key")
    assert gb.reason == "waiting on API key"


def test_goal_fail():
    gf = GoalFail(goal_id="abc", reason="deprecated")
    assert gf.reason == "deprecated"


def test_conversation_turn():
    ct = ConversationTurn(
        role="human",
        content="hello",
        timestamp=utcnow(),
    )
    assert ct.classification is None


def test_session_context_defaults():
    sc = SessionContext(
        session_id="test",
        started_at=utcnow(),
    )
    assert sc.turn_count == 0
    assert sc.working_memory == {}
    assert sc.conversation_history == []


def test_human_partner_profile_defaults():
    profile = HumanPartnerProfile()
    assert profile.name == ""
    assert profile.knowledge_profile.preferences == {}
    assert profile.knowledge_profile.notes == []


# ---------------------------------------------------------------------------
# Phase 3: Knowledge & Memory models
# ---------------------------------------------------------------------------


def test_item_type_values():
    assert ItemType.ARTICLE.value == "article"
    assert ItemType.NOTE.value == "note"
    assert ItemType.VOICE_MEMO.value == "voice_memo"


def test_link_creator_values():
    assert LinkCreator.AUTO.value == "auto"
    assert LinkCreator.HUMAN.value == "human"
    assert LinkCreator.AGENT.value == "agent"


def test_knowledge_query_classification():
    assert InputClassificationType.KNOWLEDGE_QUERY.value == "knowledge_query"


def test_item_serialization_roundtrip():
    now = utcnow()
    item = Item(
        item_id="test-item",
        type=ItemType.ARTICLE,
        title="Test Article",
        body="Article body",
        source_url="https://example.com",
        captured_at=now,
        last_accessed=now,
        tags=["python", "testing"],
        summary=Summary(
            text="A summary", model="test", generated_at=now, input_tokens=100
        ),
        provenance=Provenance(
            source="web",
            author="Author",
            chain=[
                ProvenanceLink(url="https://example.com", source_description="original")
            ],
        ),
        metadata={"key": "value"},
    )
    data = item.model_dump_json()
    restored = Item.model_validate_json(data)
    assert restored.item_id == "test-item"
    assert restored.tags == ["python", "testing"]
    assert restored.summary.text == "A summary"
    assert restored.provenance.chain[0].url == "https://example.com"
    assert restored.metadata == {"key": "value"}


def test_source_defaults():
    now = utcnow()
    s = Source(source_id="s1", name="Test", created_at=now)
    assert s.reputation_score == 0.5
    assert s.confidence == 0.0
    assert s.accuracy_history == []


def test_link_config_defaults():
    cfg = LinkConfig()
    assert cfg.min_strength == 0.3
    assert cfg.max_auto_links_per_item == 10
    assert cfg.display_threshold == 0.5


def test_rank_config_defaults():
    cfg = RankConfig()
    assert cfg.relevance_exp == 1.0
    assert cfg.decay_exp == 0.5
    assert cfg.pin_boost == 2.0


def test_trail_item_annotation():
    ti = TrailItem(
        trail_id="t1", item_id="i1", position=0, annotation="Why this matters"
    )
    assert ti.annotation == "Why this matters"
