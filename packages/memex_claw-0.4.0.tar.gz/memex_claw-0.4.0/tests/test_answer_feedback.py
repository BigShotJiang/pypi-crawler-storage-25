from __future__ import annotations

import datetime
from unittest.mock import MagicMock, patch

from memex.memory.answer_feedback import (
    AnswerFeedbackSignal,
    AnswerObservation,
    AnswerOutcome,
    _phase_evaluate_prior_answer_feedback,
    classify_follow_up,
    derive_outcome,
)


def _make_prior_obs(
    answer_id: str = "ans-001",
    session_id: str = "sess-001",
    turn_ordinal: int = 1,
    response_excerpt: str = "The project was started in 2023 and runs on Python.",
) -> AnswerObservation:
    return AnswerObservation(
        answer_id=answer_id,
        session_id=session_id,
        turn_ordinal=turn_ordinal,
        created_at=datetime.datetime.utcnow().isoformat(),
        response_excerpt=response_excerpt,
        classification="INFORMATIONAL",
        selected_path="DIRECT_ANSWER",
        tool_call_count=0,
        tool_names=[],
        retrieved_document_ids=["doc-1"],
        route_profile="standard",
        resolved=False,
        resolved_at=None,
    )


# ── Classifier tests ──────────────────────────────────────────────────────────


def test_classify_explicit_confirm():
    prior = _make_prior_obs()
    signals = classify_follow_up("yes exactly", prior, 2, "sess-001")
    assert any(s.signal_type == "explicit_confirm" for s in signals), (
        f"Expected explicit_confirm signal, got: {[s.signal_type for s in signals]}"
    )


def test_classify_explicit_correction():
    prior = _make_prior_obs()
    signals = classify_follow_up(
        "no that's wrong, actually it was 2024", prior, 2, "sess-001"
    )
    assert any(s.signal_type == "explicit_correction" for s in signals), (
        f"Expected explicit_correction signal, got: {[s.signal_type for s in signals]}"
    )


def test_classify_acted_on_answer():
    prior = _make_prior_obs()
    signals = classify_follow_up("use that, draft it now", prior, 2, "sess-001")
    assert any(s.signal_type == "acted_on_answer" for s in signals), (
        f"Expected acted_on_answer signal, got: {[s.signal_type for s in signals]}"
    )


def test_classify_no_signals():
    prior = _make_prior_obs(response_excerpt="The project runs on Python with poetry.")
    # Unrelated topic with enough length to not be short, no matching patterns
    signals = classify_follow_up(
        "what is the capital of France and how is the weather there",
        prior,
        2,
        "sess-001",
    )
    # This might produce topic_shift; the test verifies no strong signals (confirm/correction/acted)
    strong = [
        s
        for s in signals
        if s.signal_type
        in ("explicit_confirm", "explicit_correction", "acted_on_answer")
    ]
    assert strong == [], (
        f"Expected no strong signals, got: {[s.signal_type for s in strong]}"
    )


# ── Outcome derivation tests ──────────────────────────────────────────────────


def _make_signal(signal_type: str, signal_id: str = "sig-001") -> AnswerFeedbackSignal:
    return AnswerFeedbackSignal(
        signal_id=signal_id,
        answer_id="ans-001",
        session_id="sess-001",
        observed_turn_ordinal=2,
        created_at=datetime.datetime.utcnow().isoformat(),
        signal_type=signal_type,
        weight=1.0,
        confidence=0.9,
        evidence_text="test evidence",
    )


def test_derive_outcome_corrected_dominates():
    correction = _make_signal("explicit_correction", "sig-001")
    confirm = _make_signal("explicit_confirm", "sig-002")
    outcome = derive_outcome([correction, confirm], "ans-001")
    assert outcome.label == "corrected"


def test_derive_outcome_confirmed():
    confirm = _make_signal("explicit_confirm", "sig-001")
    outcome = derive_outcome([confirm], "ans-001")
    assert outcome.label == "confirmed"
    assert outcome.confidence == 0.85


def test_derive_outcome_unknown():
    outcome = derive_outcome([], "ans-001")
    assert outcome.label == "unknown"
    assert outcome.confidence == 0.0
    assert isinstance(outcome, AnswerOutcome)


# ── Phase node tests ──────────────────────────────────────────────────────────


class _FakeCtx(dict):
    """dict subclass that supports ctx.get() and ctx[key] = val (for phase node)."""

    pass


def test_phase_node_no_prior_obs():
    """Node with store returning None for unresolved obs → no summary, no raise."""
    ctx = _FakeCtx(
        store=MagicMock(),
        session=MagicMock(session_id="sess-001"),
        user_input="hello there",
        turn_ordinal=2,
    )

    with patch(
        "memex.memory.answer_feedback.load_latest_unresolved_observation",
        return_value=None,
    ):
        _phase_evaluate_prior_answer_feedback(ctx)

    assert "prior_answer_feedback_summary" not in ctx


def test_phase_node_with_correction():
    """Node with mocked prior obs and correction input → summary with outcome_label corrected."""
    prior = _make_prior_obs(
        answer_id="ans-xyz",
        session_id="sess-001",
        turn_ordinal=1,
        response_excerpt="The answer is 2023, confirmed by team.",
    )

    ctx = _FakeCtx(
        store=MagicMock(),
        session=MagicMock(session_id="sess-001"),
        user_input="actually that's wrong, it was 2024 not 2023",
        turn_ordinal=2,
    )

    with (
        patch(
            "memex.memory.answer_feedback.load_latest_unresolved_observation",
            return_value=prior,
        ),
        patch("memex.memory.answer_feedback.save_feedback_signal"),
        patch("memex.memory.answer_feedback.save_answer_outcome"),
        patch("memex.memory.answer_feedback.mark_observation_resolved"),
    ):
        _phase_evaluate_prior_answer_feedback(ctx)

    assert "prior_answer_feedback_summary" in ctx
    summary = ctx["prior_answer_feedback_summary"]
    assert summary["outcome_label"] == "corrected"
    assert summary["answer_id"] == "ans-xyz"
