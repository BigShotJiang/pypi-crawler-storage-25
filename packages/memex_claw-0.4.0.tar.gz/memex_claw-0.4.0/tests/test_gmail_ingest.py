"""Tests for Gmail auto-ingest: conversion helper, configurable fetch, URL extraction, and scheduler wiring."""

from __future__ import annotations

from unittest.mock import MagicMock, patch
from pathlib import Path

from memex.auto_ingest.gmail import (
    _process_gmail_audio_attachments,
    ingest_gmail_item,
    GmailAutoIngestSource,
    _message_to_ingest_item,
    extract_urls_from_body,
    post_process_urls,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.models import ItemType


# ---------------------------------------------------------------------------
# _message_to_ingest_item
# ---------------------------------------------------------------------------


class TestMessageToIngestItem:
    def test_basic_field_mapping(self):
        msg = {
            "id": "abc123",
            "body": "Hello world",
            "subject": "Test Subject",
            "from": "alice@example.com",
        }
        item = _message_to_ingest_item(msg)

        assert item.content == "Hello world"
        assert item.title == "Test Subject"
        assert item.source_url == "gmail://abc123"
        assert item.item_type == ItemType.CONVERSATION
        assert item.author == "alice@example.com"
        assert item.tags == ["gmail", "auto-ingest"]

    def test_missing_fields_use_defaults(self):
        item = _message_to_ingest_item({})

        assert item.content == ""
        assert item.title == "(no subject)"
        assert item.source_url == "gmail://"
        assert item.author == ""

    def test_author_falls_back_to_to(self):
        msg = {"to": "bob@example.com"}
        item = _message_to_ingest_item(msg)
        assert item.author == "bob@example.com"

    def test_custom_tags(self):
        msg = {"id": "x"}
        item = _message_to_ingest_item(msg, tags=["custom", "tags"])
        assert item.tags == ["custom", "tags"]


# ---------------------------------------------------------------------------
# extract_urls_from_body
# ---------------------------------------------------------------------------


class TestExtractUrls:
    def test_extract_urls_empty(self):
        assert extract_urls_from_body("") == []
        assert extract_urls_from_body("no urls here") == []

    def test_extract_urls_http_and_https(self):
        body = "Visit http://example.com and https://secure.example.com/path"
        urls = extract_urls_from_body(body)
        assert "http://example.com" in urls
        assert "https://secure.example.com/path" in urls

    def test_extract_urls_deduplicates(self):
        body = "See https://example.com and also https://example.com again"
        urls = extract_urls_from_body(body)
        assert urls == ["https://example.com"]

    def test_extract_urls_preserves_order(self):
        body = "First https://aaa.com then https://bbb.com then https://ccc.com"
        urls = extract_urls_from_body(body)
        assert urls == ["https://aaa.com", "https://bbb.com", "https://ccc.com"]

    def test_extract_urls_strips_trailing_punctuation(self):
        """URLs followed by quotes/parens should not include those chars."""
        body = 'Check https://example.com"trailing and (https://other.com)'
        urls = extract_urls_from_body(body)
        assert "https://example.com" in urls
        assert "https://other.com" in urls


# ---------------------------------------------------------------------------
# URL post-processing (post_process_urls)
# ---------------------------------------------------------------------------


class TestGmailUrlPostProcessing:
    def test_few_urls_auto_ingested(self):
        """<=3 URLs should trigger ingest_from_url for each."""
        from memex.auto_ingest.gmail import _URL_REVIEW_THRESHOLD

        body = "Check https://example.com and https://other.com"
        msg = {"id": "m1", "body": body, "subject": "Links", "from": "a@b.com"}
        item = _message_to_ingest_item(msg)

        urls = extract_urls_from_body(item.content)
        assert len(urls) <= _URL_REVIEW_THRESHOLD
        assert len(urls) == 2

        with patch("memex.memory.intake.ingest_from_url") as mock_ingest:
            post_process_urls(
                item,
                content_store=MagicMock(),
            )

            assert mock_ingest.call_count == 2

    def test_many_urls_creates_notification(self):
        """More than 3 URLs should create a url_review notification."""
        body = "Links: https://a.com https://b.com https://c.com https://d.com"
        msg = {"id": "m2", "body": body, "subject": "Many links", "from": "a@b.com"}
        item = _message_to_ingest_item(msg)

        urls = extract_urls_from_body(item.content)
        assert len(urls) == 4

        mock_router = MagicMock()
        with patch("memex.memory.intake.ingest_from_url") as mock_ingest:
            post_process_urls(
                item,
                content_store=MagicMock(),
                notification_router=mock_router,
            )

            mock_ingest.assert_not_called()
            mock_router.notify.assert_called_once()
            call_kwargs = mock_router.notify.call_args
            assert call_kwargs.kwargs["action_type"] == "url_review"
            assert call_kwargs.kwargs["action_data"]["urls"] == urls

    def test_url_ingest_failure_logged_not_raised(self):
        """Failures ingesting individual URLs should not propagate."""
        body = "Check https://failing.com"
        msg = {"id": "m3", "body": body, "subject": "Fail", "from": "a@b.com"}
        item = _message_to_ingest_item(msg)

        with patch(
            "memex.memory.intake.ingest_from_url",
            side_effect=ValueError("thin content"),
        ):
            # Should not raise
            post_process_urls(
                item,
                content_store=MagicMock(),
            )

    def test_url_ingest_exception_logged_not_raised(self):
        """Generic exceptions should also be caught."""
        body = "Check https://broken.com"
        msg = {"id": "m4", "body": body, "subject": "Error", "from": "a@b.com"}
        item = _message_to_ingest_item(msg)

        with patch(
            "memex.memory.intake.ingest_from_url",
            side_effect=RuntimeError("network error"),
        ):
            post_process_urls(
                item,
                content_store=MagicMock(),
            )

    @patch("memex.memory.web_extract.extract_from_url")
    def test_post_process_urls_writes_ingest_run_for_embedded_url(
        self, mock_extract, tmp_path
    ):
        from memex.memory.web_extract import ExtractedContent

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        try:
            content_store = store.content
            body = "Check https://example.com/spec"
            msg = {"id": "m5", "body": body, "subject": "Spec", "from": "a@b.com"}
            item = _message_to_ingest_item(msg)
            mock_extract.return_value = ExtractedContent(
                url="https://example.com/spec",
                title="Spec",
                body=(
                    "Specification content with enough detail to stay substantial. "
                    "It explains the rollout contract, testing expectations, and the operational envelope."
                ),
                description="Specification content for the rollout contract.",
                word_count=22,
                raw_length=700,
            )

            post_process_urls(
                item,
                content_store=content_store,
                memex_store=store,
                session_id="gmail-session-1",
                trigger_surface="tool",
            )

            runs = store.list_world_model_knowledge_ingest_runs(
                session_id="gmail-session-1"
            )
            assert len(runs) == 1
            assert runs[0].ingest_kind == "url"
            assert runs[0].trigger_surface == "tool"
            assert runs[0].source_ref == "https://example.com/spec"
        finally:
            store.close()


class TestGmailLifecycle:
    def test_ingest_gmail_item_writes_gmail_ingest_run(self, tmp_path):
        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        try:
            content_store = store.content
            item = _message_to_ingest_item(
                {
                    "id": "gmail-123",
                    "body": "Launch notes for the rollout.",
                    "subject": "Launch notes",
                    "from": "corey@example.com",
                }
            )

            ingested = ingest_gmail_item(
                item,
                content_store=content_store,
                memex_store=store,
                session_id="gmail-run-session",
                trigger_surface="tool",
            )

            runs = store.list_world_model_knowledge_ingest_runs(
                session_id="gmail-run-session"
            )
            assert ingested is not None
            assert len(runs) == 1
            assert runs[0].ingest_kind == "gmail"
            assert runs[0].trigger_surface == "tool"
            assert runs[0].item_id == ingested.item_id
            assert runs[0].status == "completed"
        finally:
            store.close()


# ---------------------------------------------------------------------------
# GmailAutoIngestSource.configure
# ---------------------------------------------------------------------------


class TestGmailConfigure:
    def test_configure_with_query(self):
        source = GmailAutoIngestSource()
        source.configure({"query": "label:important"})
        assert source._query == "label:important"

    def test_configure_without_query(self):
        source = GmailAutoIngestSource()
        source.configure({"last_check": "2025-01-01T00:00:00"})
        assert source._query is None

    def test_configure_with_both(self):
        source = GmailAutoIngestSource()
        source.configure({"query": "from:alice", "last_check": "2025-06-01T12:00:00"})
        assert source._query == "from:alice"
        assert source._last_check is not None

    def test_configure_resets_query_when_absent(self):
        source = GmailAutoIngestSource()
        source.configure({"query": "from:alice"})
        assert source._query == "from:alice"
        source.configure({"source": "gmail"})
        assert source._query is None


# ---------------------------------------------------------------------------
# GmailAutoIngestSource.fetch — query vs sent branching
# ---------------------------------------------------------------------------


class TestGmailFetch:
    @patch("memex.integrations.gmail.GmailClient")
    def test_fetch_with_query_uses_search(self, MockClient):
        client = MockClient.return_value
        client.search_messages.return_value = [
            {"id": "m1", "body": "hi", "subject": "Re: test", "from": "a@b.com"},
        ]

        source = GmailAutoIngestSource()
        source.configure({"query": "from:a@b.com"})
        items = source.fetch()

        client.authenticate.assert_called_once()
        client.search_messages.assert_called_once_with("from:a@b.com")
        client.get_sent_messages.assert_not_called()

        assert len(items) == 1
        assert items[0].tags == ["gmail", "search", "auto-ingest"]
        assert items[0].source_url == "gmail://m1"

    @patch("memex.integrations.gmail.GmailClient")
    def test_fetch_without_query_uses_sent(self, MockClient):
        client = MockClient.return_value
        client.get_sent_messages.return_value = [
            {"id": "s1", "body": "sent msg", "subject": "Fwd", "to": "x@y.com"},
        ]

        source = GmailAutoIngestSource()
        items = source.fetch()

        client.authenticate.assert_called_once()
        client.get_sent_messages.assert_called_once()
        client.search_messages.assert_not_called()

        assert len(items) == 1
        assert items[0].tags == ["gmail", "sent", "auto-ingest"]
        assert items[0].title == "Sent: Fwd"
        assert items[0].source_url == "gmail://sent/s1"

    @patch("memex.integrations.gmail.GmailClient")
    def test_fetch_empty_results(self, MockClient):
        client = MockClient.return_value
        client.search_messages.return_value = []

        source = GmailAutoIngestSource()
        source.configure({"query": "nonexistent"})
        items = source.fetch()

        assert items == []


# ---------------------------------------------------------------------------
# Scheduler wiring — _dispatch_auto_ingest calls configure
# ---------------------------------------------------------------------------


class TestDispatchAutoIngest:
    @patch("memex.scheduler.engine.get_default_registry", create=True)
    def test_dispatch_calls_configure(self, mock_get_registry):
        """Verify _dispatch_auto_ingest calls source.configure(action_data)."""
        mock_source = MagicMock()
        mock_registry = MagicMock()
        mock_registry.get_source.return_value = mock_source
        mock_registry.run_source.return_value = 3

        with patch(
            "memex.auto_ingest.registry.get_default_registry",
            return_value=mock_registry,
        ):
            from memex.scheduler.engine import SchedulerEngine

            store = MagicMock()
            store.seed_builtins = MagicMock()
            store.conn = MagicMock()

            engine = SchedulerEngine(store)
            action_data = {"source": "gmail", "query": "label:important"}
            result = engine._dispatch_auto_ingest(action_data, run_id=1)

        mock_registry.get_source.assert_called_once_with("gmail")
        mock_source.configure.assert_called_once_with(action_data)
        mock_registry.run_source.assert_called_once()
        assert "ingested 3 items" in result


# ---------------------------------------------------------------------------
# TUI /gmail command — help text
# ---------------------------------------------------------------------------


class TestGmailTUICommand:
    def test_gmail_no_args_shows_help(self):
        """Verify /gmail with no args produces usage text."""
        from memex.interfaces.tui.app import MemexApp

        # Verify /gmail is registered in the command registry and handler exists.
        import inspect

        app = MemexApp.__new__(MemexApp)
        app._command_registry = __import__(
            "memex.interfaces.tui.commands", fromlist=["SlashCommandRegistry"]
        ).SlashCommandRegistry()
        app._sub_agent_manager = None
        app._pending_skill_install = None
        app._register_commands()
        assert "/gmail" in app._command_registry._lookup
        source_method = inspect.getsource(MemexApp._do_gmail_search)
        assert "search_messages" in source_method


# ---------------------------------------------------------------------------
# Attention drawer notification_id key
# ---------------------------------------------------------------------------


class TestAttentionDrawerNotificationId:
    def test_notification_id_key_used(self):
        """Verify attention drawer reads notification_id, not id."""
        import inspect
        from memex.interfaces.tui.widgets.attention_drawer import AttentionDrawer

        source = inspect.getsource(AttentionDrawer.on_key)
        assert 'notification.get("notification_id"' in source
        assert 'notification.get("id"' not in source


# ---------------------------------------------------------------------------
# _process_gmail_audio_attachments — speech transcription wiring
# ---------------------------------------------------------------------------


class TestGmailAudioAttachments:
    def test_speech_audio_creates_meeting_and_enqueues(self, tmp_path):
        from memex.auto_ingest.audio_classify import AudioClassification
        from memex.fathom_facade import FathomMeetingAdapter, FathomMemexStore
        from memex.fathom_store import FathomStore

        _fs = FathomStore.open(str(tmp_path / "test.db"))
        store = FathomMemexStore(_fs)
        work_queue = MagicMock()
        scheduler_store = MagicMock()

        classified = AudioClassification(
            path=Path("/tmp/x.ogg"),
            is_speech=True,
            speech_ratio=0.9,
            vad_available=True,
        )
        att = [{"filename": "voice.ogg", "attachment_id": "att123"}]

        with (
            patch("memex.integrations.gmail.GmailClient.authenticate"),
            patch(
                "memex.integrations.gmail.GmailClient.download_attachment",
                return_value=b"fake_audio",
            ),
            patch(
                "memex.auto_ingest.audio_classify.classify_audio",
                return_value=classified,
            ),
            patch.object(FathomMeetingAdapter, "create_meeting") as mock_create,
            patch("memex.meetings.submit_transcription", return_value=7) as mock_submit,
            patch("shutil.move"),
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.write_bytes"),
            patch(
                "memex.paths.resolve_store_path",
                return_value="/tmp/test_store/.memex/memex.db",
            ),
        ):
            _process_gmail_audio_attachments(
                "msg123",
                att,
                content_store=MagicMock(),
                memex_store=store,
                work_queue=work_queue,
                scheduler_store=scheduler_store,
            )

        mock_create.assert_called_once()
        mock_submit.assert_called_once()
        store.close()

    def test_speech_audio_skips_when_no_scheduler(self):
        from memex.auto_ingest.audio_classify import AudioClassification

        classified = AudioClassification(
            path=Path("/tmp/x.ogg"),
            is_speech=True,
            speech_ratio=0.9,
            vad_available=True,
        )
        att = [{"filename": "voice.ogg", "attachment_id": "att123"}]

        memex_store = MagicMock()
        mock_meetings = MagicMock()
        memex_store.meetings = mock_meetings

        with (
            patch("memex.integrations.gmail.GmailClient.authenticate"),
            patch(
                "memex.integrations.gmail.GmailClient.download_attachment",
                return_value=b"fake_audio",
            ),
            patch(
                "memex.auto_ingest.audio_classify.classify_audio",
                return_value=classified,
            ),
            patch("pathlib.Path.write_bytes"),
        ):
            _process_gmail_audio_attachments(
                "msg123",
                att,
                content_store=MagicMock(),
                memex_store=memex_store,
                work_queue=None,
                scheduler_store=None,
            )

        mock_meetings.create_meeting.assert_not_called()
