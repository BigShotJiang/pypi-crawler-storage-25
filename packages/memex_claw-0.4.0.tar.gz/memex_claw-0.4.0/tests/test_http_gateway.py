"""Tests for HTTP Gateway."""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error

import pytest

from memex.http_gateway import HttpGateway, HttpRequest, HttpResponse, HttpRoute


def _get(url: str, headers: dict | None = None) -> tuple[int, str]:
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def _post(url: str, data: dict, headers: dict | None = None) -> tuple[int, str]:
    body = json.dumps(data).encode()
    hdrs = {"Content-Type": "application/json"}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


@pytest.fixture
def gateway():
    """Create a gateway on an ephemeral port, start it, and stop after test."""
    gw = HttpGateway(port=0, host="127.0.0.1")

    # Register a health route
    gw.register_route(
        HttpRoute(
            path="/health",
            handler=lambda req: HttpResponse.json({"status": "ok"}),
            methods={"GET"},
        )
    )

    # Register an echo route
    gw.register_route(
        HttpRoute(
            path="/echo",
            handler=lambda req: HttpResponse.json({"echo": req.json}),
            methods={"POST"},
        )
    )

    gw.start()
    # Get the actual port from the bound server
    actual_port = gw._server.server_address[1]
    gw._actual_port = actual_port
    time.sleep(0.1)  # brief wait for server to be ready
    yield gw
    gw.stop()


@pytest.fixture
def base_url(gateway):
    return f"http://127.0.0.1:{gateway._actual_port}"


class TestHttpGateway:
    def test_health_route(self, base_url):
        status, body = _get(f"{base_url}/health")
        assert status == 200
        data = json.loads(body)
        assert data == {"status": "ok"}

    def test_echo_route(self, base_url):
        status, body = _post(f"{base_url}/echo", {"message": "hello"})
        assert status == 200
        data = json.loads(body)
        assert data == {"echo": {"message": "hello"}}

    def test_not_found(self, base_url):
        status, body = _get(f"{base_url}/nonexistent")
        assert status == 404

    def test_method_not_allowed(self, base_url):
        # /health only allows GET
        status, body = _post(f"{base_url}/health", {})
        assert status == 404  # No matching route for POST /health

    def test_prefix_matching(self, gateway, base_url):
        gateway.register_route(
            HttpRoute(
                path="/api/",
                handler=lambda req: HttpResponse.json({"path": req.path}),
                match="prefix",
            )
        )

        status, body = _get(f"{base_url}/api/users")
        assert status == 200
        data = json.loads(body)
        assert data == {"path": "/api/users"}

    def test_handler_exception_returns_500(self, gateway, base_url):
        def bad_handler(req):
            raise RuntimeError("handler error")

        gateway.register_route(
            HttpRoute(
                path="/boom",
                handler=bad_handler,
            )
        )

        status, body = _get(f"{base_url}/boom")
        assert status == 500

    def test_start_idempotent(self, gateway):
        # Calling start again should be a no-op
        gateway.start()
        assert gateway._server is not None


class TestHttpGatewayAuth:
    def test_gateway_auth_required(self):
        gw = HttpGateway(port=0, host="127.0.0.1", auth_token="secret123")
        gw.register_route(
            HttpRoute(
                path="/secure",
                handler=lambda req: HttpResponse.json({"ok": True}),
                auth="gateway",
            )
        )
        gw.start()
        port = gw._server.server_address[1]
        time.sleep(0.1)

        try:
            # No auth → 401
            status, _ = _get(f"http://127.0.0.1:{port}/secure")
            assert status == 401

            # Wrong token → 401
            status, _ = _get(
                f"http://127.0.0.1:{port}/secure",
                headers={"Authorization": "Bearer wrong"},
            )
            assert status == 401

            # Correct token → 200
            status, body = _get(
                f"http://127.0.0.1:{port}/secure",
                headers={"Authorization": "Bearer secret123"},
            )
            assert status == 200
            assert json.loads(body) == {"ok": True}
        finally:
            gw.stop()

    def test_no_token_configured_allows_all(self):
        gw = HttpGateway(port=0, host="127.0.0.1")  # no auth_token
        gw.register_route(
            HttpRoute(
                path="/open",
                handler=lambda req: HttpResponse.json({"ok": True}),
                auth="gateway",
            )
        )
        gw.start()
        port = gw._server.server_address[1]
        time.sleep(0.1)

        try:
            status, _ = _get(f"http://127.0.0.1:{port}/open")
            assert status == 200
        finally:
            gw.stop()


class TestHttpRequestResponse:
    def test_request_json_parsing(self):
        req = HttpRequest(
            method="POST",
            path="/test",
            headers={},
            body=b'{"key": "value"}',
        )
        assert req.json == {"key": "value"}

    def test_request_empty_body(self):
        req = HttpRequest(method="GET", path="/test", headers={}, body=b"")
        assert req.json is None

    def test_response_helpers(self):
        r1 = HttpResponse.json({"a": 1})
        assert r1.status == 200
        assert r1.content_type == "application/json"
        assert json.loads(r1.body) == {"a": 1}

        r2 = HttpResponse.text("hello")
        assert r2.content_type == "text/plain"
        assert r2.body == "hello"

        r3 = HttpResponse.error("bad", 400)
        assert r3.status == 400
        assert json.loads(r3.body) == {"error": "bad"}
