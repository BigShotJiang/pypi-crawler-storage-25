"""Tests for OpenClaw bridge middleware and service."""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import MagicMock

import pytest

from memex.integrations.openclaw import OpenClawBridgeMiddleware, OpenClawBridgeService
from memex.middleware import MiddlewareChain
from memex.models import SessionContext
from memex.plugins import get_plugin_registry, reset_plugin_registry
from memex.runtime_state import RuntimeStateRegistry
from memex.services import ServiceContext


@pytest.fixture
def session():
    return SessionContext(
        session_id="test-bridge",
        started_at=datetime(2026, 3, 10, 10, 0),
    )


@pytest.fixture
def mock_client():
    return MagicMock()


class TestOpenClawBridgeMiddleware:
    def test_no_client_returns_defaults(self, session):
        mw = OpenClawBridgeMiddleware(mcp_client=None)
        assert mw.on_message_received(session, "hello") == "hello"
        assert mw.on_message_sending(session, "bye") == "bye"
        assert mw.before_prompt_build(session, MagicMock()) == ""
        args, blocked = mw.before_tool_call(session, "tool", {"k": "v"})
        assert args == {"k": "v"}
        assert blocked is False

    def test_on_message_received_transforms(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps({"user_input": "HELLO"})
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        result = mw.on_message_received(session, "hello")
        assert result == "HELLO"
        mock_client.call_tool.assert_called_once()

    def test_on_message_sending_transforms(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps({"response": "BYE"})
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        result = mw.on_message_sending(session, "bye")
        assert result == "BYE"

    def test_before_prompt_build(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps({"content": "extra context"})
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        result = mw.before_prompt_build(session, MagicMock())
        assert result == "extra context"

    def test_before_tool_call_block(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps(
            {
                "arguments": {"k": "v"},
                "blocked": True,
            }
        )
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        args, blocked = mw.before_tool_call(session, "tool", {"k": "v"})
        assert blocked is True

    def test_before_tool_call_modify(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps(
            {
                "arguments": {"k": "modified"},
                "blocked": False,
            }
        )
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        args, blocked = mw.before_tool_call(session, "tool", {"k": "v"})
        assert args == {"k": "modified"}
        assert blocked is False

    def test_observe_hooks_fire_and_forget(self, session, mock_client):
        mock_client.call_tool.return_value = None
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        # These should not raise
        mw.on_llm_input(session, [{"role": "user", "content": "hi"}])
        mw.on_llm_output(session, "response", [])
        mw.after_tool_call(session, "tool", {}, "result")

        assert mock_client.call_tool.call_count == 3

    def test_client_error_returns_defaults(self, session, mock_client):
        mock_client.call_tool.side_effect = RuntimeError("connection lost")
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)

        assert mw.on_message_received(session, "hello") == "hello"
        assert mw.on_message_sending(session, "bye") == "bye"
        assert mw.before_prompt_build(session, MagicMock()) == ""

    def test_integrates_with_chain(self, session, mock_client):
        mock_client.call_tool.return_value = json.dumps({"user_input": "TRANSFORMED"})
        mw = OpenClawBridgeMiddleware(mcp_client=mock_client)
        chain = MiddlewareChain([mw])

        result = chain.on_message_received(session, "original")
        assert result == "TRANSFORMED"


class TestOpenClawBridgeService:
    def test_properties(self):
        svc = OpenClawBridgeService()
        assert svc.id == "openclaw-bridge"
        assert svc.name == "OpenClaw MCP Bridge"

    def test_start_without_config(self, tmp_path):
        svc = OpenClawBridgeService()
        ctx = ServiceContext(
            config={},
            store=MagicMock(),
            event_bus=MagicMock(),
            scheduler=None,
            logger=MagicMock(),
            data_dir=tmp_path,
        )
        svc.start(ctx)  # Should not raise

    def test_start_with_bridge_dir(self, tmp_path):
        svc = OpenClawBridgeService()
        ctx = ServiceContext(
            config={"bridge_dir": "/path/to/bridge"},
            store=MagicMock(),
            event_bus=MagicMock(),
            scheduler=None,
            logger=MagicMock(),
            data_dir=tmp_path,
        )
        svc.start(ctx)
        ctx.logger.info.assert_called()


def test_connect_plugin_bridge_reports_unavailable_connector_and_interface(
    tmp_path, monkeypatch
):
    from memex.loop import _connect_plugin_bridge

    plugin_root = tmp_path / "plugins"
    plugin_root.mkdir()
    plugin_dir = plugin_root / "demo-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "openclaw.plugin.json").write_text(
        json.dumps(
            {
                "id": "demo-plugin",
                "name": "Demo Plugin",
                "version": "0.1.0",
            }
        )
    )

    runtime_registry = RuntimeStateRegistry()
    reset_plugin_registry()
    try:
        get_plugin_registry(plugin_root)
        monkeypatch.setenv(
            "MEMEX_OPENCLAW_BRIDGE_DIR", str(tmp_path / "missing-bridge")
        )
        _connect_plugin_bridge(
            store=MagicMock(),
            registry=MagicMock(),
            connector_clients={},
            health_list=[],
            runtime_registry=runtime_registry,
        )
        snapshot = runtime_registry.snapshot()
        connectors = {item["name"]: item for item in snapshot["connectors"]}
        interfaces = {item["name"]: item for item in snapshot["interfaces"]}
        assert connectors["openclaw-bridge"]["status"] == "unavailable"
        assert interfaces["openclaw_bridge"]["status"] == "unavailable"
    finally:
        reset_plugin_registry()


def test_connect_plugin_bridge_preserves_connected_connector_state(
    tmp_path, monkeypatch
):
    from memex.loop import _connect_plugin_bridge

    plugin_root = tmp_path / "plugins"
    plugin_root.mkdir()
    plugin_dir = plugin_root / "demo-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "openclaw.plugin.json").write_text(
        json.dumps(
            {
                "id": "demo-plugin",
                "name": "Demo Plugin",
                "version": "0.1.0",
            }
        )
    )

    bridge_dir = tmp_path / "bridge"
    (bridge_dir / "dist").mkdir(parents=True)
    (bridge_dir / "dist" / "index.js").write_text("// bridge")

    runtime_registry = RuntimeStateRegistry()
    reset_plugin_registry()
    try:
        get_plugin_registry(plugin_root)
        monkeypatch.setenv("MEMEX_OPENCLAW_BRIDGE_DIR", str(bridge_dir))

        def _fake_connect(
            entry,
            store,
            registry,
            connector_clients,
            health_list,
            runtime_registry=None,
        ):
            connector_clients["openclaw-bridge"] = MagicMock(
                discovered_tools=["a", "b"]
            )
            if runtime_registry is not None:
                runtime_registry.set_connector_state(
                    "openclaw-bridge",
                    status="connected",
                    tools_discovered=2,
                    error="",
                    degraded=False,
                )

        monkeypatch.setattr("memex.loop._connect_mcp_server_entry", _fake_connect)
        _connect_plugin_bridge(
            store=MagicMock(),
            registry=MagicMock(),
            connector_clients={},
            health_list=[],
            runtime_registry=runtime_registry,
        )
        snapshot = runtime_registry.snapshot()
        connectors = {item["name"]: item for item in snapshot["connectors"]}
        interfaces = {item["name"]: item for item in snapshot["interfaces"]}
        assert connectors["openclaw-bridge"]["status"] == "connected"
        assert connectors["openclaw-bridge"]["tools_discovered"] == 2
        assert interfaces["openclaw_bridge"]["status"] == "connected"
    finally:
        reset_plugin_registry()
