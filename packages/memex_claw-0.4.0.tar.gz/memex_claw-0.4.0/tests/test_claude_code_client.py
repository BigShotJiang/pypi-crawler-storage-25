"""Tests for Claude Code CLI connector — all subprocess calls mocked."""

from __future__ import annotations

import json
import subprocess
from unittest.mock import patch

from memex.connectors.claude_code import ClaudeCodeClient, ClaudeCodeConfig


def _make_proc(stdout: str = "", stderr: str = "", returncode: int = 0):
    """Create a mock CompletedProcess."""
    return subprocess.CompletedProcess(
        args=[],
        returncode=returncode,
        stdout=stdout,
        stderr=stderr,
    )


def _json_output(
    result: str = "done",
    session_id: str = "sess-123",
    cost_usd: float = 0.01,
    num_turns: int = 1,
    is_error: bool = False,
    duration_ms: int = 500,
) -> str:
    return json.dumps(
        {
            "result": result,
            "session_id": session_id,
            "cost_usd": cost_usd,
            "num_turns": num_turns,
            "is_error": is_error,
            "duration_ms": duration_ms,
        }
    )


class TestBuildCommand:
    def test_basic_command(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello")
        assert cmd[:3] == ["claude", "-p", "hello"]
        assert "--output-format" in cmd
        assert "json" in cmd

    def test_max_turns(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello", max_turns=7)
        idx = cmd.index("--max-turns")
        assert cmd[idx + 1] == "7"

    def test_permission_mode(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello", permission_mode="default")
        idx = cmd.index("--permission-mode")
        assert cmd[idx + 1] == "default"

    def test_allowed_tools(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello", allowed_tools=["Read", "Glob"])
        idx = cmd.index("--allowedTools")
        assert cmd[idx + 1] == "Read"
        assert cmd[idx + 2] == "Glob"

    def test_working_directory(self):
        client = ClaudeCodeClient()
        # Working directory is no longer a CLI arg — it's passed as cwd to subprocess.run
        assert client._resolve_working_directory("/tmp/test") == "/tmp/test"
        assert client._resolve_working_directory(None) is None

    def test_system_prompt(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello", system_prompt="be helpful")
        idx = cmd.index("--system-prompt")
        assert cmd[idx + 1] == "be helpful"

    def test_system_prompt_append(self):
        config = ClaudeCodeConfig(system_prompt_append="always be concise")
        client = ClaudeCodeClient(config)
        cmd = client._build_command("hello", system_prompt="be helpful")
        idx = cmd.index("--system-prompt")
        assert "be helpful" in cmd[idx + 1]
        assert "always be concise" in cmd[idx + 1]

    def test_session_id_adds_resume(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello", session_id="sess-abc")
        idx = cmd.index("--resume")
        assert cmd[idx + 1] == "sess-abc"

    def test_default_config(self):
        config = ClaudeCodeConfig(
            default_max_turns=3,
            default_permission_mode="default",
            default_allowed_tools=["Read"],
            default_working_directory="/home/test",
        )
        client = ClaudeCodeClient(config)
        cmd = client._build_command("hello")
        idx = cmd.index("--max-turns")
        assert cmd[idx + 1] == "3"
        idx = cmd.index("--permission-mode")
        assert cmd[idx + 1] == "default"
        assert "--allowedTools" in cmd
        # Working directory is resolved separately, not in CLI args
        assert "--cwd" not in cmd
        assert client._resolve_working_directory(None) == "/home/test"

    def test_no_allowed_tools_when_empty(self):
        client = ClaudeCodeClient()
        cmd = client._build_command("hello")
        assert "--allowedTools" not in cmd

    def test_custom_binary(self):
        config = ClaudeCodeConfig(claude_binary="/usr/local/bin/claude")
        client = ClaudeCodeClient(config)
        cmd = client._build_command("hello")
        assert cmd[0] == "/usr/local/bin/claude"


class TestExecute:
    @patch("subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = _make_proc(stdout=_json_output())
        client = ClaudeCodeClient()
        result = client.execute("explain this code")
        assert result.success
        assert result.content == "done"
        assert result.source == "claude_code"

    @patch("subprocess.run")
    def test_error_result(self, mock_run):
        mock_run.return_value = _make_proc(
            stdout=_json_output(result="something failed", is_error=True)
        )
        client = ClaudeCodeClient()
        result = client.execute("do something")
        assert not result.success
        assert result.error == "something failed"

    @patch("subprocess.run")
    def test_timeout(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=[], timeout=5)
        client = ClaudeCodeClient()
        result = client.execute("slow task", timeout=5.0)
        assert not result.success
        assert "Timeout" in result.error

    @patch("subprocess.run")
    def test_invalid_json(self, mock_run):
        mock_run.return_value = _make_proc(stdout="not json", stderr="parse error")
        client = ClaudeCodeClient()
        result = client.execute("hello")
        assert not result.success
        assert "Invalid JSON" in result.error

    @patch("subprocess.run")
    def test_subprocess_exception(self, mock_run):
        mock_run.side_effect = OSError("spawn failed")
        client = ClaudeCodeClient()
        result = client.execute("hello")
        assert not result.success
        assert "spawn failed" in result.error

    @patch("subprocess.run")
    def test_duration_tracked(self, mock_run):
        mock_run.return_value = _make_proc(stdout=_json_output())
        client = ClaudeCodeClient()
        result = client.execute("hello")
        assert result.duration_ms >= 0


class TestResume:
    @patch("subprocess.run")
    def test_resume_includes_flag(self, mock_run):
        mock_run.return_value = _make_proc(stdout=_json_output())
        client = ClaudeCodeClient()
        result = client.resume("sess-abc", "continue")
        assert result.success
        call_args = mock_run.call_args[0][0]
        assert "--resume" in call_args
        idx = call_args.index("--resume")
        assert call_args[idx + 1] == "sess-abc"


class TestCostLimits:
    @patch("subprocess.run")
    def test_per_call_cost_warning(self, mock_run):
        """Per-call cost exceeding limit logs warning but still succeeds."""
        mock_run.return_value = _make_proc(stdout=_json_output(cost_usd=5.0))
        config = ClaudeCodeConfig(max_cost_per_call_usd=1.0)
        client = ClaudeCodeClient(config)
        result = client.execute("expensive")
        # Per-call is a warning, not a hard block
        assert result.success

    @patch("subprocess.run")
    def test_session_cost_limit(self, mock_run):
        """Session cost exceeding limit blocks further calls."""
        config = ClaudeCodeConfig(max_cost_per_session_usd=0.05)
        client = ClaudeCodeClient(config)

        # First call at $0.03 — under limit
        mock_run.return_value = _make_proc(
            stdout=_json_output(cost_usd=0.03, session_id="s1")
        )
        r1 = client.execute("first")
        assert r1.success

        # Second call at $0.03 — total $0.06 exceeds $0.05 limit
        mock_run.return_value = _make_proc(
            stdout=_json_output(cost_usd=0.03, session_id="s1")
        )
        r2 = client.execute("second")
        assert not r2.success
        assert "cost limit" in r2.error.lower()

    @patch("subprocess.run")
    def test_separate_sessions_tracked_independently(self, mock_run):
        config = ClaudeCodeConfig(max_cost_per_session_usd=0.05)
        client = ClaudeCodeClient(config)

        mock_run.return_value = _make_proc(
            stdout=_json_output(cost_usd=0.04, session_id="s1")
        )
        assert client.execute("a").success

        mock_run.return_value = _make_proc(
            stdout=_json_output(cost_usd=0.04, session_id="s2")
        )
        assert client.execute("b").success

    @patch("subprocess.run")
    def test_resume_precheck_blocks_over_budget_session(self, mock_run):
        """Resume refuses to spawn subprocess if session is already over budget."""
        config = ClaudeCodeConfig(max_cost_per_session_usd=0.05)
        client = ClaudeCodeClient(config)

        # First call pushes session over budget
        mock_run.return_value = _make_proc(
            stdout=_json_output(cost_usd=0.06, session_id="s1")
        )
        r1 = client.execute("first")
        assert not r1.success  # Post-check catches it

        # Resume should be blocked without spawning subprocess
        mock_run.reset_mock()
        r2 = client.resume("s1", "continue")
        assert not r2.success
        assert "cost limit" in r2.error.lower()
        mock_run.assert_not_called()  # No subprocess spawned

    @patch("subprocess.run")
    def test_last_session_id_tracked(self, mock_run):
        mock_run.return_value = _make_proc(stdout=_json_output(session_id="sess-xyz"))
        client = ClaudeCodeClient()
        client.execute("hello")
        assert client.last_session_id == "sess-xyz"


class TestNonDictJson:
    @patch("subprocess.run")
    def test_json_array_returns_error(self, mock_run):
        mock_run.return_value = _make_proc(stdout="[1, 2, 3]")
        client = ClaudeCodeClient()
        result = client.execute("hello")
        assert not result.success
        assert "expected object" in result.error.lower()

    @patch("subprocess.run")
    def test_json_string_returns_error(self, mock_run):
        mock_run.return_value = _make_proc(stdout='"just a string"')
        client = ClaudeCodeClient()
        result = client.execute("hello")
        assert not result.success
        assert "expected object" in result.error.lower()


class TestHealthCheck:
    @patch("subprocess.run")
    def test_healthy(self, mock_run):
        mock_run.return_value = _make_proc(stdout="claude 1.0.0")
        client = ClaudeCodeClient()
        health = client.health_check()
        assert health.status == "connected"
        assert health.name == "claude_code"

    @patch("subprocess.run")
    def test_binary_not_found(self, mock_run):
        mock_run.side_effect = FileNotFoundError()
        client = ClaudeCodeClient()
        health = client.health_check()
        assert health.status == "unavailable"
        assert "not found" in health.error.lower()

    @patch("subprocess.run")
    def test_nonzero_exit(self, mock_run):
        mock_run.return_value = _make_proc(returncode=1, stderr="bad config")
        client = ClaudeCodeClient()
        health = client.health_check()
        assert health.status == "unavailable"
        assert "bad config" in health.error
