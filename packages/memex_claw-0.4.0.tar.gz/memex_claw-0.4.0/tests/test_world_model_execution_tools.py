from __future__ import annotations


from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    WorldModelActionPlan,
    WorldModelExecutionRecord,
    WorldModelPlanStep,
    WorldModelPlanStepTransition,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.tools_builtin import _STORES, configure_stores, execute_builtin
from memex.utcnow import utcnow


def test_get_item_renders_world_model_execution_record_and_transition_documents(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    now = utcnow()
    goal = Goal(
        goal_id="goal-tools-execution",
        title="Ship execution records",
        description="Ship canonical execution records safely.",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.HIGH,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={},
    )
    store.create_goal(goal)
    store.upsert_world_model_action_plan(
        WorldModelActionPlan(
            plan_id="plan-tools-execution",
            goal_id="goal-tools-execution",
            title="Execution record rollout",
            summary="Drive rollout through canonical execution state.",
            status="active",
            selected_step_id="step-tools-execution",
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_plan_step(
        WorldModelPlanStep(
            step_id="step-tools-execution",
            plan_id="plan-tools-execution",
            goal_id="goal-tools-execution",
            step_kind="execution",
            title="Execute canonical rollout",
            description="Drive the rollout.",
            status="in_progress",
            ordinal=1,
            blocked_reason="",
            progress_pct=50,
            payload={},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.upsert_world_model_execution_record(
        WorldModelExecutionRecord(
            execution_id="execution-tools-1",
            session_id="session-tools-execution",
            conversation_turn_id=3,
            goal_id="goal-tools-execution",
            plan_id="plan-tools-execution",
            step_id="step-tools-execution",
            execution_kind="tool_call",
            title="Run rollout checker",
            summary="Checker advanced rollout progress.",
            status="succeeded",
            source_record_type="world_model_action",
            source_record_id="action-tools-1",
            payload={"tool_name": "check_rollout"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    store.append_world_model_plan_step_transition(
        WorldModelPlanStepTransition(
            transition_id="transition-tools-1",
            step_id="step-tools-execution",
            plan_id="plan-tools-execution",
            goal_id="goal-tools-execution",
            execution_id="execution-tools-1",
            transition_kind="progress_update",
            from_status="active",
            to_status="in_progress",
            blocked_reason="",
            blocked_by_step_ids=[],
            progress_pct=50,
            summary="Checker confirmed half the rollout is complete.",
            payload={"source": "tool"},
            source_surface="test",
            created_at=now,
            updated_at=now,
        )
    )
    configure_stores(content_store=store.content, memex_store=store)

    try:
        execution_detail = execute_builtin(
            "get_item",
            {"id": "world_model_execution_record:execution-tools-1"},
        )
        transition_detail = execute_builtin(
            "get_item",
            {"id": "world_model_plan_step_transition:transition-tools-1"},
        )

        assert execution_detail.success
        assert (
            "Type: execution_record | ID: "
            "world_model_execution_record:execution-tools-1"
        ) in execution_detail.content
        assert (
            "for_plan -> world_model_action_plan:plan-tools-execution"
            in execution_detail.content
        )
        assert (
            "executes_step -> world_model_plan_step:step-tools-execution"
            in execution_detail.content
        )
        assert (
            "records_source -> world_model_action:action-tools-1"
            in execution_detail.content
        )
        assert transition_detail.success
        assert (
            "Type: plan_step_transition | ID: "
            "world_model_plan_step_transition:transition-tools-1"
        ) in transition_detail.content
        assert (
            "updates_step -> world_model_plan_step:step-tools-execution"
            in transition_detail.content
        )
        assert (
            "emitted_by_execution -> world_model_execution_record:execution-tools-1"
        ) in transition_detail.content
        assert "Progress: 50%" in transition_detail.content
    finally:
        _STORES.clear()
