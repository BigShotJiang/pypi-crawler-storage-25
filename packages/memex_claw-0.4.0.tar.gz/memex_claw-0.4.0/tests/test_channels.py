"""Tests for Channel abstraction and ChannelManager."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from memex.channels import (
    Channel,
    ChannelManager,
    InboundMessage,
    MessageHandler,
    OutboundMessage,
)


class DummyChannel(Channel):
    """Test channel that records lifecycle calls."""

    def __init__(self, channel_id: str = "test", max_len: int = 4096) -> None:
        self._id = channel_id
        self._max_len = max_len
        self.started = False
        self.stopped = False
        self.handler: MessageHandler | None = None
        self.sent: list[OutboundMessage] = []

    @property
    def id(self) -> str:
        return self._id

    @property
    def max_message_length(self) -> int:
        return self._max_len

    async def start(self, on_message: MessageHandler) -> None:
        self.started = True
        self.handler = on_message

    async def stop(self) -> None:
        self.stopped = True

    async def send(self, message: OutboundMessage) -> None:
        self.sent.append(message)


class BrokenChannel(Channel):
    @property
    def id(self) -> str:
        return "broken"

    async def start(self, on_message: MessageHandler) -> None:
        raise RuntimeError("start failed")

    async def stop(self) -> None:
        raise RuntimeError("stop failed")

    async def send(self, message: OutboundMessage) -> None:
        pass


@pytest.fixture
def mock_api():
    api = MagicMock()
    api.chat.return_value = ("Hello back!", MagicMock())
    return api


class TestChannel:
    def test_split_message_short(self):
        ch = DummyChannel()
        assert ch.split_message("hello") == ["hello"]

    def test_split_message_at_paragraphs(self):
        ch = DummyChannel(max_len=20)
        text = "short\n\nslightly longer"
        chunks = ch.split_message(text)
        assert len(chunks) == 2
        assert chunks[0] == "short"
        assert chunks[1] == "slightly longer"

    def test_split_message_hard_split(self):
        ch = DummyChannel(max_len=10)
        text = "a" * 25
        chunks = ch.split_message(text)
        assert len(chunks) == 3
        assert chunks[0] == "a" * 10
        assert chunks[1] == "a" * 10
        assert chunks[2] == "a" * 5

    def test_default_capabilities(self):
        ch = DummyChannel()
        assert ch.capabilities == set()

    def test_default_max_message_length(self):
        class Bare(Channel):
            @property
            def id(self):
                return "bare"

            async def start(self, on_message):
                pass

            async def stop(self):
                pass

            async def send(self, message):
                pass

        ch = Bare()
        assert ch.max_message_length == 4096


class TestChannelManager:
    @pytest.mark.asyncio
    async def test_register_and_start(self, mock_api):
        ch = DummyChannel()
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch)
        await mgr.start_all()

        assert ch.started
        assert ch in mgr.running

    @pytest.mark.asyncio
    async def test_stop_all(self, mock_api):
        ch = DummyChannel()
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch)
        await mgr.start_all()
        await mgr.stop_all()

        assert ch.stopped
        assert mgr.running == []

    @pytest.mark.asyncio
    async def test_broken_start_does_not_abort(self, mock_api):
        broken = BrokenChannel()
        good = DummyChannel("good")
        mgr = ChannelManager(api=mock_api)
        mgr.register(broken)
        mgr.register(good)
        await mgr.start_all()

        assert good.started
        assert broken not in mgr.running
        assert good in mgr.running

    @pytest.mark.asyncio
    async def test_handler_calls_api_chat(self, mock_api):
        ch = DummyChannel()
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch)
        await mgr.start_all()

        msg = InboundMessage(
            text="hi",
            sender_id="user1",
            channel_id="ch1",
            platform="test",
        )
        response = await ch.handler(msg)

        assert response == "Hello back!"
        mock_api.chat.assert_called_once()

    @pytest.mark.asyncio
    async def test_handler_session_naming(self, mock_api):
        ch = DummyChannel("telegram")
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch)
        await mgr.start_all()

        msg = InboundMessage(
            text="hi",
            sender_id="user1",
            channel_id="ch1",
            platform="telegram",
        )
        await ch.handler(msg)

        call_args = mock_api.chat.call_args
        caller = call_args[0][1]
        assert caller.interface == "telegram"
        assert "telegram_" in caller.session_id

    @pytest.mark.asyncio
    async def test_auth_rejects_unauthorized(self, mock_api):
        ch = DummyChannel("secure")
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch, allowed_users={"allowed_user"})
        await mgr.start_all()

        msg = InboundMessage(
            text="hi",
            sender_id="hacker",
            channel_id="ch1",
            platform="secure",
        )
        response = await ch.handler(msg)

        assert response == ""
        mock_api.chat.assert_not_called()

    @pytest.mark.asyncio
    async def test_auth_allows_authorized(self, mock_api):
        ch = DummyChannel("secure")
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch, allowed_users={"allowed_user"})
        await mgr.start_all()

        msg = InboundMessage(
            text="hi",
            sender_id="allowed_user",
            channel_id="ch1",
            platform="secure",
        )
        response = await ch.handler(msg)

        assert response == "Hello back!"

    @pytest.mark.asyncio
    async def test_no_allowlist_allows_all(self, mock_api):
        ch = DummyChannel()
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch)  # no allowed_users
        await mgr.start_all()

        msg = InboundMessage(
            text="hi",
            sender_id="anyone",
            channel_id="ch1",
            platform="test",
        )
        response = await ch.handler(msg)

        assert response == "Hello back!"

    def test_registered_property(self, mock_api):
        ch1 = DummyChannel("a")
        ch2 = DummyChannel("b")
        mgr = ChannelManager(api=mock_api)
        mgr.register(ch1)
        mgr.register(ch2)
        assert mgr.registered == [ch1, ch2]
