"""Tests for the additive C04 meeting-intelligence sidecar."""

from __future__ import annotations

import uuid
from datetime import datetime
from unittest.mock import patch

import pytest

from memex.meetings.models import (
    MeetingExtractionRun,
    MeetingIntelligenceArtifact,
    MeetingIntelligenceArtifactType,
    MeetingRecord,
    MeetingRecording,
    MeetingSegment,
    MeetingState,
)
from memex.meetings.semantic_projection import sync_meeting_item_projection
from memex.meetings.transcribe import TranscriptionResult, orchestrate_transcription
from memex.models import (
    Goal,
    GoalPriority,
    GoalStatus,
    Item,
    ItemType,
    MeetingGoalLink,
    Provenance,
)
from memex.fathom_facade import FathomMemexStore
from memex.fathom_store import FathomStore
from memex.utcnow import utcnow


SEGMENTS = [
    MeetingSegment(
        speaker="SPEAKER_00",
        start=0.0,
        end=5.2,
        text="We need to finalize the zylophane migration by Friday.",
    ),
    MeetingSegment(
        speaker="SPEAKER_01",
        start=5.5,
        end=11.0,
        text="Agreed. The quorbitex tests are blocking us right now.",
    ),
]

CANNED_RESULT = TranscriptionResult(
    segments=SEGMENTS,
    speaker_count=2,
    language="en",
    model="large-v3",
    duration_seconds=11.0,
)


def _make_recorded_meeting(meeting_store) -> MeetingRecord:
    record = MeetingRecord(
        meeting_id=str(uuid.uuid4()),
        state=MeetingState.RECORDED,
        title="Sprint Planning",
        audio_path="/tmp/fake_audio.wav",
        started_at=datetime(2026, 3, 8, 10, 0),
        stopped_at=datetime(2026, 3, 8, 10, 17),
    )
    meeting_store.create_meeting(record)
    rec_id = str(uuid.uuid4())
    meeting_store.create_recording(rec_id, record.meeting_id, state="recorded")
    meeting_store._repo.update_recording(rec_id, audio_path=record.audio_path)
    return record


def test_meeting_intelligence_models_create():
    now = utcnow()
    artifact = MeetingIntelligenceArtifact(
        artifact_id="mtg-1:action_item:0",
        meeting_id="mtg-1",
        recording_id=None,
        artifact_type=MeetingIntelligenceArtifactType.ACTION_ITEM,
        ordinal=0,
        content="Ship docs",
        payload={"assignee": "Corey", "deadline": "Friday"},
        source_surface="meeting_store",
        created_at=now,
        updated_at=now,
    )
    run = MeetingExtractionRun(
        run_id="run-1",
        meeting_id="mtg-1",
        recording_id=None,
        run_type="transcription_projection",
        status="success",
        model="large-v3",
        artifact_count=3,
        metadata={"extract_action_items": True},
        created_at=now,
        updated_at=now,
    )

    assert artifact.artifact_type == MeetingIntelligenceArtifactType.ACTION_ITEM
    assert artifact.payload["assignee"] == "Corey"
    assert run.run_type == "transcription_projection"
    assert run.artifact_count == 3


def test_meeting_store_dual_writes_notes_and_action_items(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-notes",
        state=MeetingState.TRANSCRIBED,
        title="Retro",
        notes="Discussed launch risks and next steps.",
        action_items=[{"text": "Ship docs", "assignee": "Corey", "deadline": "Friday"}],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)

    artifacts = ms.list_meeting_artifacts("mtg-notes")
    note = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.NOTE
    )
    action = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.ACTION_ITEM
    )

    assert note.content == "Discussed launch risks and next steps."
    assert action.payload["text"] == "Ship docs"
    assert action.payload["assignee"] == "Corey"
    store.close()


def test_meeting_store_dual_writes_decisions_outcomes_and_commitments(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-semantic-notes",
        state=MeetingState.TRANSCRIBED,
        title="Architecture Review",
        notes=(
            "Decision: SQLite remains the canonical store.\n"
            "Outcome: Ship the docs update by Friday."
        ),
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-123",
            }
        ],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)

    artifacts = ms.list_meeting_artifacts("mtg-semantic-notes")
    decision = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.DECISION
    )
    outcome = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.OUTCOME
    )
    commitment = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.COMMITMENT
    )

    assert decision.content == "SQLite remains the canonical store."
    assert outcome.content == "Ship the docs update by Friday."
    assert commitment.content == "Ship docs update"
    assert commitment.payload["promoted_goal_id"] == "goal-123"
    assert commitment.payload["assignee"] == "Corey"
    store.close()


def test_meeting_store_refreshes_outcomes_on_note_update(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-outcome-refresh",
        state=MeetingState.TRANSCRIBED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-outcome-refresh")
    assert record is not None

    record.notes = (
        "Decision: SQLite remains the canonical store.\n"
        "Outcome: Ship the docs update by Friday."
    )
    ms.update_meeting(record)

    artifacts = ms.list_meeting_artifacts("mtg-outcome-refresh")
    outcome = next(
        artifact
        for artifact in artifacts
        if artifact.artifact_type == MeetingIntelligenceArtifactType.OUTCOME
    )

    assert outcome.content == "Ship the docs update by Friday."
    store.close()


def test_sync_meeting_item_projection_promotes_decisions_and_commitments_to_typed_knowledge(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-promoted-knowledge",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-123",
            }
        ],
        item_id="meeting-item-promoted-knowledge",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-promoted-knowledge",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-promoted-knowledge",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-promoted-knowledge"}},
        )
    )
    ms.create_meeting(meeting)

    record = ms.get_meeting("mtg-promoted-knowledge")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    decision_item = store.content.find_by_url(
        "memex://meeting/mtg-promoted-knowledge/artifact/mtg-promoted-knowledge:decision:0"
    )
    commitment_item = store.content.find_by_url(
        "memex://meeting/mtg-promoted-knowledge/artifact/mtg-promoted-knowledge:commitment:0"
    )
    assert decision_item is not None
    assert commitment_item is not None
    assert decision_item.metadata["typed_knowledge"]["claim_kind"] == "decision"
    assert commitment_item.metadata["typed_knowledge"]["claim_kind"] == "commitment"
    assert commitment_item.metadata["typed_knowledge"]["agreed_by"] == "Corey"
    assert commitment_item.metadata["typed_knowledge"]["promoted_goal_id"] == "goal-123"

    decision_knowledge = store.load_world_model_knowledge_object_by_item_id(
        decision_item.item_id
    )
    commitment_knowledge = store.load_world_model_knowledge_object_by_item_id(
        commitment_item.item_id
    )
    assert decision_knowledge is not None
    assert commitment_knowledge is not None
    assert decision_knowledge.knowledge_type == "claim"
    assert decision_knowledge.payload["semantic_kind"] == "decision"
    assert decision_knowledge.payload["metadata"]["meeting_artifact"][
        "artifact_id"
    ] == ("mtg-promoted-knowledge:decision:0")
    assert commitment_knowledge.knowledge_type == "claim"
    assert commitment_knowledge.payload["semantic_kind"] == "commitment"
    assert commitment_knowledge.payload["typed"]["agreed_by"] == "Corey"
    store.close()


def test_sync_meeting_item_projection_persists_world_model_action_observation_and_provenance(
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-world-model-promotion",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        item_id="meeting-item-world-model-promotion",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-world-model-promotion",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-world-model-promotion",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription",
                captured_at=now,
                confidence=1.0,
            ),
            metadata={"meeting": {"meeting_id": "mtg-world-model-promotion"}},
        )
    )
    ms.create_meeting(meeting)

    record = ms.get_meeting("mtg-world-model-promotion")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    actions = store.list_world_model_actions(meeting_id=record.meeting_id)
    assert {action.action_kind for action in actions} == {
        "meeting_semantic_promotion",
        "meeting_semantic_sync",
    }
    action = next(
        row for row in actions if row.action_kind == "meeting_semantic_promotion"
    )
    assert action.action_kind == "meeting_semantic_promotion"
    assert action.action_name == "decision"
    assert action.status == "succeeded"
    assert action.payload["artifact_id"] == "mtg-world-model-promotion:decision:0"

    observations = store.list_world_model_observations(action_id=action.action_id)
    assert len(observations) == 1
    observation = observations[0]
    assert observation.observation_kind == "promoted_semantic_item"
    assert observation.status == "succeeded"
    assert (
        observation.payload["item_id"]
        == "meeting-semantic:mtg-world-model-promotion:decision:0"
    )

    links = store.list_world_model_provenance_links(source_record_id=action.action_id)
    relationships = {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in links
    }
    assert (
        "promotes",
        "meeting_artifact",
        "mtg-world-model-promotion:decision:0",
    ) in relationships
    assert (
        "updates",
        "item",
        "meeting-semantic:mtg-world-model-promotion:decision:0",
    ) in relationships

    observation_links = store.list_world_model_provenance_links(
        source_record_id=observation.observation_id
    )
    assert {
        (link.relationship, link.target_record_type, link.target_record_id)
        for link in observation_links
    } == {("observed_from", "world_model_action", action.action_id)}
    semantic_sync_action = next(
        row for row in actions if row.action_kind == "meeting_semantic_sync"
    )
    assert semantic_sync_action.action_name == "item_projection_refresh"
    assert semantic_sync_action.status == "succeeded"
    assert (
        semantic_sync_action.payload["item_id"] == "meeting-item-world-model-promotion"
    )
    semantic_sync_observations = store.list_world_model_observations(
        action_id=semantic_sync_action.action_id
    )
    assert len(semantic_sync_observations) == 1
    assert semantic_sync_observations[0].observation_kind == "meeting_semantic_state"
    assert semantic_sync_observations[0].status == "succeeded"
    stored_item = store.content.get_item("meeting-item-world-model-promotion")
    assert stored_item is not None
    audit = stored_item.metadata["meeting"]["semantic"]["canonical_promotion_audit"]
    assert len(audit) == 1
    assert audit[0]["action_id"] == action.action_id
    assert audit[0]["artifact_id"] == "mtg-world-model-promotion:decision:0"
    assert audit[0]["relationships"][0]["relationship"] in {"promotes", "updates"}
    assert audit[0]["observations"][0]["observation_id"] == observation.observation_id
    activity_audit = stored_item.metadata["meeting"]["semantic"][
        "canonical_activity_audit"
    ]
    assert len(activity_audit) == 1
    assert activity_audit[0]["action_id"] == semantic_sync_action.action_id
    assert activity_audit[0]["action_kind"] == "meeting_semantic_sync"
    assert activity_audit[0]["observations"][0]["observation_id"] == (
        semantic_sync_observations[0].observation_id
    )
    store.close()


def test_sync_meeting_item_projection_forces_typed_refresh_for_nonshared_content_store(
    tmp_path,
):
    class NonSharedContentStore:
        """Wrapper that simulates a content store with a different connection.

        With FathomDB, there's no shared SQLite connection concept, so this
        wrapper delegates all operations to the backing store while keeping
        ``conn`` as a distinct object to trigger the non-shared path.
        """

        def __init__(self, backing_store, conn):
            self._backing_store = backing_store
            self.conn = object()  # Deliberately different from store.conn

        def get_item(self, item_id: str):
            return self._backing_store.get_item(item_id)

        def find_by_url(self, url: str):
            return self._backing_store.find_by_url(url)

        def create_version_snapshot(self, item):
            return self._backing_store.create_version_snapshot(item)

        def create_item(self, item):
            return self._backing_store.create_item(item)

        def update_item(self, item):
            return self._backing_store.update_item(item)

        def delete_item(self, item_id: str):
            return self._backing_store.delete_item(item_id)

    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    sqlite_content = store.content
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-nonshared-refresh",
        state=MeetingState.INGESTED,
        title="Sprint Planning",
        notes="Decision: Keep SQLite canonical.",
        action_items=[
            {
                "text": "Finalize the zylophane migration",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
            }
        ],
        item_id="meeting-item-nonshared-refresh",
        created_at=now,
        updated_at=now,
    )
    initial_item = Item(
        item_id="meeting-item-nonshared-refresh",
        type=ItemType.MEETING,
        title="Sprint Planning",
        body="Transcript body",
        source_url="memex://meeting/mtg-nonshared-refresh",
        captured_at=now,
        last_accessed=now,
        provenance=Provenance(
            source="meeting_transcription",
            captured_at=now,
            confidence=1.0,
        ),
        metadata={"meeting": {"meeting_id": "mtg-nonshared-refresh"}},
    )
    sqlite_content.create_item(initial_item)
    store.sync_world_model_knowledge_from_item(initial_item)
    ms.create_meeting(meeting)

    knowledge = store.load_world_model_knowledge_object_by_item_id(
        "meeting-item-nonshared-refresh"
    )
    assert knowledge is not None
    assert (
        knowledge.payload["metadata"]["meeting"]["meeting_id"]
        == "mtg-nonshared-refresh"
    )
    assert "semantic" not in knowledge.payload["metadata"]["meeting"]

    record = ms.get_meeting("mtg-nonshared-refresh")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=NonSharedContentStore(sqlite_content, None),
        memex_store=store,
        bump_version=False,
    )

    refreshed = store.load_world_model_knowledge_object_by_item_id(
        "meeting-item-nonshared-refresh"
    )
    assert refreshed is not None
    assert refreshed.payload["metadata"]["meeting"]["semantic"]["commitments"][0][
        "content"
    ] == ("Finalize the zylophane migration")
    promoted = sqlite_content.find_by_url(
        "memex://meeting/mtg-nonshared-refresh/artifact/mtg-nonshared-refresh:commitment:0"
    )
    assert promoted is not None
    promoted_knowledge = store.load_world_model_knowledge_object_by_item_id(
        promoted.item_id
    )
    assert promoted_knowledge is not None
    assert promoted_knowledge.payload["semantic_kind"] == "commitment"
    store.close()


def test_sync_meeting_item_projection_deletes_stale_promoted_semantic_items(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-promoted-prune",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
            }
        ],
        item_id="meeting-item-promoted-prune",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-promoted-prune",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-promoted-prune",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-promoted-prune"}},
        )
    )
    ms.create_meeting(meeting)

    record = ms.get_meeting("mtg-promoted-prune")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    record.notes = ""
    record.action_items = []
    ms.update_meeting(record)
    record = ms.get_meeting("mtg-promoted-prune")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    assert (
        store.content.find_by_url(
            "memex://meeting/mtg-promoted-prune/artifact/mtg-promoted-prune:decision:0"
        )
        is None
    )
    assert (
        store.content.find_by_url(
            "memex://meeting/mtg-promoted-prune/artifact/mtg-promoted-prune:commitment:0"
        )
        is None
    )
    remaining_actions = store.list_world_model_actions(meeting_id="mtg-promoted-prune")
    assert {action.action_kind for action in remaining_actions} == {
        "meeting_semantic_sync"
    }
    remaining_observations = store.list_world_model_observations(
        meeting_id="mtg-promoted-prune"
    )
    assert {observation.observation_kind for observation in remaining_observations} == {
        "meeting_semantic_state"
    }
    store.close()


def test_sync_meeting_item_projection_is_idempotent(tmp_path):
    """Bug 1: Repeated syncs must not accumulate unbounded action rows."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-idempotent",
        state=MeetingState.INGESTED,
        title="Idempotency Check",
        notes="Decision: Use deterministic IDs.",
        item_id="meeting-item-idempotent",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-idempotent",
            type=ItemType.MEETING,
            title="Idempotency Check",
            body="Transcript body",
            source_url="memex://meeting/mtg-idempotent",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-idempotent"}},
        )
    )
    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-idempotent")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )
    actions_after_first = store.list_world_model_actions(meeting_id="mtg-idempotent")
    count_first = len(actions_after_first)

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )
    actions_after_second = store.list_world_model_actions(meeting_id="mtg-idempotent")
    count_second = len(actions_after_second)

    assert count_second == count_first, (
        f"Expected idempotent sync but actions grew from {count_first} to {count_second}"
    )
    store.close()


def test_sync_meeting_item_projection_no_collision_between_note_and_action_commitments(
    tmp_path,
):
    """Bug 2: note-sourced and action-item-sourced commitments must get distinct IDs."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-collision",
        state=MeetingState.INGESTED,
        title="Collision Check",
        notes="Commitment: Review the design doc.",
        action_items=[
            {
                "text": "Ship the widget",
                "assignee": "Corey",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
            }
        ],
        item_id="meeting-item-collision",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-collision",
            type=ItemType.MEETING,
            title="Collision Check",
            body="Transcript body",
            source_url="memex://meeting/mtg-collision",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-collision"}},
        )
    )
    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-collision")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    # The note-sourced commitment has artifact_id like "mtg-collision:commitment:note:0"
    # The action-item-sourced commitment has artifact_id like "mtg-collision:commitment:0"
    note_commitment = store.content.find_by_url(
        "memex://meeting/mtg-collision/artifact/mtg-collision:commitment:note:0"
    )
    action_commitment = store.content.find_by_url(
        "memex://meeting/mtg-collision/artifact/mtg-collision:commitment:0"
    )
    assert note_commitment is not None, "Note-sourced commitment not found"
    assert action_commitment is not None, "Action-item-sourced commitment not found"
    assert note_commitment.item_id != action_commitment.item_id, (
        "Note and action commitments should have distinct item IDs"
    )
    store.close()


def test_sync_meeting_item_projection_prunes_note_sourced_commitments(tmp_path):
    """Bug 3: Note-sourced commitment items must be cleaned up when removed."""
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-note-prune",
        state=MeetingState.INGESTED,
        title="Note Pruning Check",
        notes="Commitment: Review the design doc.",
        item_id="meeting-item-note-prune",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-note-prune",
            type=ItemType.MEETING,
            title="Note Pruning Check",
            body="Transcript body",
            source_url="memex://meeting/mtg-note-prune",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-note-prune"}},
        )
    )
    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-note-prune")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    # Verify the note-sourced commitment was promoted
    promoted = store.content.find_by_url(
        "memex://meeting/mtg-note-prune/artifact/mtg-note-prune:commitment:note:0"
    )
    assert promoted is not None, "Note-sourced commitment should be promoted"

    # Remove the commitment from notes
    record.notes = ""
    ms.update_meeting(record)
    record = ms.get_meeting("mtg-note-prune")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    # Verify the promoted item was cleaned up
    pruned = store.content.find_by_url(
        "memex://meeting/mtg-note-prune/artifact/mtg-note-prune:commitment:note:0"
    )
    assert pruned is None, "Note-sourced commitment should be pruned after removal"
    store.close()


def test_sync_meeting_item_projection_updates_promoted_goal_metadata(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    goal = Goal(
        goal_id="goal-meeting-link",
        title="Ship docs update",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={"source": "meeting_action_item"},
    )
    store.create_goal(goal)
    meeting = MeetingRecord(
        meeting_id="mtg-goal-metadata",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-meeting-link",
            }
        ],
        item_id="meeting-item-goal-metadata",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-goal-metadata",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-goal-metadata",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-goal-metadata"}},
        )
    )
    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-goal-metadata")
    assert record is not None

    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    updated_goal = store.get_goal("goal-meeting-link")
    assert updated_goal is not None
    promotion = updated_goal.metadata["meeting_promotion"]
    assert promotion["meeting_id"] == "mtg-goal-metadata"
    assert promotion["relationship"] == "commitment"
    assert promotion["action_text"] == "Ship docs update"
    assert promotion["assignee"] == "Corey"
    assert promotion["deadline"] == "Friday"
    assert promotion["commitment_artifact_id"] == "mtg-goal-metadata:commitment:0"
    assert (
        promotion["semantic_item_id"]
        == "meeting-semantic:mtg-goal-metadata:commitment:0"
    )
    store.close()


def test_sync_meeting_item_projection_clears_stale_goal_promotion_metadata(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    goal = Goal(
        goal_id="goal-stale-link",
        title="Ship docs update",
        status=GoalStatus.ACTIVE,
        priority=GoalPriority.MEDIUM,
        created_at=now,
        updated_at=now,
        last_touched_at=now,
        metadata={"source": "meeting_action_item"},
    )
    store.create_goal(goal)
    meeting = MeetingRecord(
        meeting_id="mtg-stale-goal-metadata",
        state=MeetingState.INGESTED,
        title="Architecture Review",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
                "promoted_goal_id": "goal-stale-link",
            }
        ],
        item_id="meeting-item-stale-goal-metadata",
        created_at=now,
        updated_at=now,
    )
    store.content.create_item(
        Item(
            item_id="meeting-item-stale-goal-metadata",
            type=ItemType.MEETING,
            title="Architecture Review",
            body="Transcript body",
            source_url="memex://meeting/mtg-stale-goal-metadata",
            captured_at=now,
            last_accessed=now,
            provenance=Provenance(
                source="meeting_transcription", captured_at=now, confidence=1.0
            ),
            metadata={"meeting": {"meeting_id": "mtg-stale-goal-metadata"}},
        )
    )
    ms.create_meeting(meeting)
    record = ms.get_meeting("mtg-stale-goal-metadata")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    # Confirm the first sync actually wrote meeting_promotion metadata on
    # the goal; otherwise the stale-clearing assertion below would pass
    # vacuously.
    promoted_goal = store.get_goal("goal-stale-link")
    assert promoted_goal is not None
    assert "meeting_promotion" in promoted_goal.metadata

    record.action_items = []
    ms.update_meeting(record)
    record = ms.get_meeting("mtg-stale-goal-metadata")
    assert record is not None
    sync_meeting_item_projection(
        record,
        meeting_store=ms,
        content_store=store.content,
        memex_store=store,
        bump_version=False,
    )

    updated_goal = store.get_goal("goal-stale-link")
    assert updated_goal is not None
    assert "meeting_promotion" not in updated_goal.metadata
    store.close()


def test_meeting_store_does_not_infer_commitment_from_plain_action_item(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-no-commitment",
        state=MeetingState.TRANSCRIBED,
        title="Planning",
        action_items=[{"text": "Ship docs", "assignee": "Corey", "deadline": "Friday"}],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)

    commitments = ms.list_meeting_artifacts(
        "mtg-no-commitment",
        artifact_type=MeetingIntelligenceArtifactType.COMMITMENT,
    )

    assert commitments == []
    store.close()


def test_meeting_store_syncs_promoted_goal_links_and_preserves_explicit_links(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    # Create goal nodes so edges can target them
    for gid in ("goal-a", "goal-b", "goal-explicit"):
        store.create_goal(
            Goal(
                goal_id=gid,
                title=gid,
                status=GoalStatus.ACTIVE,
                priority=GoalPriority.MEDIUM,
                created_at=now,
                updated_at=now,
                last_touched_at=now,
            )
        )
    meeting = MeetingRecord(
        meeting_id="mtg-goal-links",
        state=MeetingState.TRANSCRIBED,
        title="Planning",
        action_items=[
            {"text": "Ship docs", "promoted_goal_id": "goal-a"},
            {"text": "Prep launch", "promoted_goal_id": None},
        ],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)
    store.create_meeting_goal_link(
        MeetingGoalLink(
            meeting_id="mtg-goal-links",
            goal_id="goal-explicit",
            relationship="explicit",
            created_at=now,
        )
    )

    meeting = ms.get_meeting("mtg-goal-links")
    assert meeting is not None
    meeting.action_items = [
        {"text": "Ship docs v2", "promoted_goal_id": "goal-b"},
        {"text": "Prep launch", "promoted_goal_id": None},
    ]

    ms.update_meeting(meeting)

    links = {
        (link.goal_id, link.relationship)
        for link in store.list_meeting_goal_links("mtg-goal-links")
    }

    assert links == {
        ("goal-explicit", "explicit"),
        ("goal-b", "promoted_action_item"),
    }
    store.close()


def test_meeting_store_preserves_artifact_created_at_on_unrelated_update(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-created-at",
        state=MeetingState.TRANSCRIBED,
        title="Architecture Review",
        notes="Decision: SQLite remains the canonical store.",
        action_items=[
            {
                "text": "Ship docs update",
                "assignee": "Corey",
                "commitment_confirmed": True,
                "agreed_by": "Corey",
            }
        ],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)
    before = {
        artifact.artifact_id: artifact.created_at
        for artifact in ms.list_meeting_artifacts("mtg-created-at")
        if artifact.artifact_type
        in {
            MeetingIntelligenceArtifactType.DECISION,
            MeetingIntelligenceArtifactType.ACTION_ITEM,
            MeetingIntelligenceArtifactType.COMMITMENT,
        }
    }

    meeting = ms.get_meeting("mtg-created-at")
    assert meeting is not None
    meeting.title = "Architecture Review v2"
    ms.update_meeting(meeting)

    after = {
        artifact.artifact_id: artifact.created_at
        for artifact in ms.list_meeting_artifacts("mtg-created-at")
        if artifact.artifact_id in before
    }

    assert after == before
    store.close()


def test_meeting_store_dual_writes_transcript_segments_from_recordings(tmp_path):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    ms = store.meetings
    now = utcnow()
    meeting = MeetingRecord(
        meeting_id="mtg-segments",
        state=MeetingState.TRANSCRIBED,
        title="Segment Test",
        recordings=[
            MeetingRecording(
                recording_id="mtg-segments-r1",
                meeting_id="mtg-segments",
                sequence_number=1,
                state=MeetingState.TRANSCRIBED,
                audio_path="/tmp/test.wav",
                segments=SEGMENTS,
                speaker_count=2,
                started_at=now,
                stopped_at=now,
                created_at=now,
                updated_at=now,
            )
        ],
        created_at=now,
        updated_at=now,
    )

    ms.create_meeting(meeting)

    artifacts = ms.list_meeting_artifacts(
        "mtg-segments",
        artifact_type=MeetingIntelligenceArtifactType.TRANSCRIPT_SEGMENT,
    )

    assert len(artifacts) == 2
    assert artifacts[0].recording_id == "mtg-segments-r1"
    assert artifacts[0].speaker == "SPEAKER_00"
    assert artifacts[0].start_seconds == 0.0
    assert artifacts[1].content.startswith("Agreed.")
    store.close()


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
@patch(
    "memex.meetings.transcribe._extract_action_items",
    return_value=[
        {
            "assignee": "SPEAKER_00",
            "action": "Finalize the zylophane migration",
            "deadline": "Friday",
            "commitment_confirmed": True,
            "agreed_by": "SPEAKER_00",
        }
    ],
)
def test_orchestrate_transcription_records_meeting_intelligence_run(
    mock_extract_actions,
    mock_transcribe,
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        record = _make_recorded_meeting(store.meetings)

        item = orchestrate_transcription(
            record.meeting_id,
            meeting_store=store.meetings,
            content_store=store.content,
            memex_store=store,
            extract_action_items=True,
        )

        artifacts = store.meetings.list_meeting_artifacts(record.meeting_id)
        action_items = [
            artifact
            for artifact in artifacts
            if artifact.artifact_type == MeetingIntelligenceArtifactType.ACTION_ITEM
        ]
        commitments = [
            artifact
            for artifact in artifacts
            if artifact.artifact_type == MeetingIntelligenceArtifactType.COMMITMENT
        ]
        segments = [
            artifact
            for artifact in artifacts
            if artifact.artifact_type
            == MeetingIntelligenceArtifactType.TRANSCRIPT_SEGMENT
        ]
        runs = store.meetings.list_extraction_runs(record.meeting_id)
        refreshed = store.meetings.get_meeting(record.meeting_id)
        actions = store.list_world_model_actions(meeting_id=record.meeting_id)

        assert item is not None
        assert len(segments) == 2
        assert len(action_items) == 1
        assert len(commitments) == 1
        assert action_items[0].payload["action"] == "Finalize the zylophane migration"
        assert commitments[0].payload["action"] == "Finalize the zylophane migration"
        assert len(runs) == 1
        assert runs[0].run_type == "transcription_projection"
        assert runs[0].status == "success"
        assert runs[0].artifact_count == 4
        assert refreshed is not None
        assert refreshed.action_items[0]["action"] == "Finalize the zylophane migration"
        extraction_action = next(
            row for row in actions if row.action_kind == "meeting_extraction"
        )
        assert extraction_action.action_name == "transcription_projection"
        assert extraction_action.status == "success"
        assert extraction_action.payload["run_id"] == runs[0].run_id
        extraction_observations = store.list_world_model_observations(
            action_id=extraction_action.action_id
        )
        assert len(extraction_observations) == 1
        assert (
            extraction_observations[0].observation_kind == "meeting_extraction_result"
        )
        assert extraction_observations[0].status == "success"
    finally:
        store.close()


@patch(
    "memex.meetings.transcribe.transcribe_meeting",
    side_effect=RuntimeError("whisper exploded"),
)
def test_orchestrate_transcription_records_failed_meeting_intelligence_run(
    mock_transcribe,
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        record = _make_recorded_meeting(store.meetings)

        with pytest.raises(RuntimeError, match="whisper exploded"):
            orchestrate_transcription(
                record.meeting_id,
                meeting_store=store.meetings,
                content_store=store.content,
            )

        runs = store.meetings.list_extraction_runs(record.meeting_id)
        refreshed = store.meetings.get_meeting(record.meeting_id)

        assert len(runs) == 1
        assert runs[0].run_type == "transcription_projection"
        assert runs[0].status == "failed"
        assert runs[0].metadata["error"] == "whisper exploded"
        assert refreshed is not None
        assert refreshed.state == MeetingState.FAILED
    finally:
        store.close()


@patch("memex.meetings.transcribe.transcribe_meeting", return_value=CANNED_RESULT)
def test_orchestrate_transcription_records_single_failed_run_when_item_sync_fails(
    mock_transcribe,
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        record = _make_recorded_meeting(store.meetings)

        with patch(
            "memex.meetings.transcribe._upsert_meeting_item",
            side_effect=RuntimeError("sync exploded"),
        ):
            with pytest.raises(RuntimeError, match="sync exploded"):
                orchestrate_transcription(
                    record.meeting_id,
                    meeting_store=store.meetings,
                    content_store=store.content,
                )

        runs = store.meetings.list_extraction_runs(record.meeting_id)

        assert len(runs) == 1
        assert runs[0].status == "failed"
        assert runs[0].metadata["error"] == "sync exploded"
    finally:
        store.close()


@patch(
    "memex.meetings.transcribe.transcribe_meeting",
    side_effect=[CANNED_RESULT, CANNED_RESULT],
)
@patch(
    "memex.meetings.transcribe._extract_action_items",
    side_effect=[
        [
            {
                "assignee": "SPEAKER_00",
                "action": "Finalize the zylophane migration",
                "deadline": "Friday",
                "commitment_confirmed": True,
                "agreed_by": "SPEAKER_00",
            }
        ],
        [],
    ],
)
def test_orchestrate_transcription_clears_action_items_when_rerun_extracts_none(
    mock_extract_actions,
    mock_transcribe,
    tmp_path,
):
    _fs = FathomStore.open(str(tmp_path / "test.db"))
    store = FathomMemexStore(_fs)
    try:
        record = _make_recorded_meeting(store.meetings)

        orchestrate_transcription(
            record.meeting_id,
            meeting_store=store.meetings,
            content_store=store.content,
            extract_action_items=True,
        )
        orchestrate_transcription(
            record.meeting_id,
            meeting_store=store.meetings,
            content_store=store.content,
            extract_action_items=True,
        )

        refreshed = store.meetings.get_meeting(record.meeting_id)
        assert refreshed is not None
        assert refreshed.action_items == []

        action_items = store.meetings.list_meeting_artifacts(
            record.meeting_id,
            artifact_type=MeetingIntelligenceArtifactType.ACTION_ITEM,
        )
        commitments = store.meetings.list_meeting_artifacts(
            record.meeting_id,
            artifact_type=MeetingIntelligenceArtifactType.COMMITMENT,
        )
        assert action_items == []
        assert commitments == []
    finally:
        store.close()
