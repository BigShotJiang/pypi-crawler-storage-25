"""Tests for TurnMiddleware base class and MiddlewareChain.

Tests verify that:
1. TurnMiddleware defaults are no-ops (original + extended)
2. MiddlewareChain runs middleware in order
3. before_session aggregates strings with newline separator
4. Void methods swallow exceptions per-middleware
5. Exception in one middleware doesn't prevent others from running
6. Extended hooks: transform, concatenate, observe, and block semantics
"""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock

import pytest

from memex.middleware import MiddlewareChain, TurnMiddleware
from memex.models import (
    InputClassification,
    InputClassificationType,
    ReflectResult,
    SessionContext,
)


@pytest.fixture
def session():
    return SessionContext(
        session_id="test-session",
        started_at=datetime(2026, 3, 7, 10, 0),
    )


@pytest.fixture
def mock_store():
    return MagicMock()


@pytest.fixture
def classification():
    return InputClassification(
        classification=InputClassificationType.ADVANCES_GOAL,
        goal_id="goal-abc",
        confidence=0.9,
    )


@pytest.fixture
def reflect_result():
    return ReflectResult(
        intent_advanced=["goal-abc"],
        reflection_note="Made progress",
    )


class TestTurnMiddleware:
    """Base class methods are no-ops."""

    def test_before_session_returns_empty(self, session, mock_store):
        mw = TurnMiddleware()
        assert mw.before_session(session, mock_store) == ""

    def test_after_classify_is_noop(self, session, classification):
        mw = TurnMiddleware()
        mw.after_classify(session, classification)  # Should not raise

    def test_after_reflect_is_noop(self, session, reflect_result, classification):
        mw = TurnMiddleware()
        mw.after_reflect(session, reflect_result, classification)

    def test_after_turn_is_noop(self, session):
        mw = TurnMiddleware()
        mw.after_turn(session, "response text")

    def test_after_session_is_noop(self, session, mock_store):
        mw = TurnMiddleware()
        mw.after_session(session, mock_store)

    # Extended hook defaults

    def test_on_message_received_returns_input(self, session):
        mw = TurnMiddleware()
        assert mw.on_message_received(session, "hello") == "hello"

    def test_on_message_sending_returns_response(self, session):
        mw = TurnMiddleware()
        assert mw.on_message_sending(session, "bye") == "bye"

    def test_before_prompt_build_returns_empty(self, session, mock_store):
        mw = TurnMiddleware()
        assert mw.before_prompt_build(session, mock_store) == ""

    def test_on_llm_input_is_noop(self, session):
        mw = TurnMiddleware()
        mw.on_llm_input(session, [{"role": "user", "content": "hi"}])

    def test_on_llm_output_is_noop(self, session):
        mw = TurnMiddleware()
        mw.on_llm_output(session, "response", [])

    def test_before_tool_call_passes_through(self, session):
        mw = TurnMiddleware()
        args, blocked = mw.before_tool_call(session, "my_tool", {"key": "val"})
        assert args == {"key": "val"}
        assert blocked is False

    def test_after_tool_call_is_noop(self, session):
        mw = TurnMiddleware()
        mw.after_tool_call(session, "my_tool", {"key": "val"}, "result")


class TestMiddlewareChain:
    """Chain runs middleware in order, handles exceptions."""

    def test_empty_chain(self, session, mock_store):
        chain = MiddlewareChain([])
        assert chain.before_session(session, mock_store) == ""

    def test_before_session_aggregates_strings(self, session, mock_store):
        class MW1(TurnMiddleware):
            def before_session(self, session, store):
                return "brief-1"

        class MW2(TurnMiddleware):
            def before_session(self, session, store):
                return "brief-2"

        chain = MiddlewareChain([MW1(), MW2()])
        result = chain.before_session(session, mock_store)
        assert result == "brief-1\n\nbrief-2"

    def test_before_session_skips_empty(self, session, mock_store):
        class MW1(TurnMiddleware):
            def before_session(self, session, store):
                return "only-this"

        chain = MiddlewareChain([TurnMiddleware(), MW1()])
        result = chain.before_session(session, mock_store)
        assert result == "only-this"

    def test_after_classify_runs_all(self, session, classification):
        calls = []

        class MW1(TurnMiddleware):
            def after_classify(self, session, classification):
                calls.append("mw1")

        class MW2(TurnMiddleware):
            def after_classify(self, session, classification):
                calls.append("mw2")

        chain = MiddlewareChain([MW1(), MW2()])
        chain.after_classify(session, classification)
        assert calls == ["mw1", "mw2"]

    def test_after_reflect_runs_all(self, session, reflect_result, classification):
        calls = []

        class MW1(TurnMiddleware):
            def after_reflect(self, session, reflect_result, classification):
                calls.append("mw1")

        chain = MiddlewareChain([MW1()])
        chain.after_reflect(session, reflect_result, classification)
        assert calls == ["mw1"]

    def test_after_turn_runs_all(self, session):
        calls = []

        class MW1(TurnMiddleware):
            def after_turn(self, session, response):
                calls.append(response)

        chain = MiddlewareChain([MW1()])
        chain.after_turn(session, "hello")
        assert calls == ["hello"]

    def test_after_session_runs_all(self, session, mock_store):
        calls = []

        class MW1(TurnMiddleware):
            def after_session(self, session, store):
                calls.append("ended")

        chain = MiddlewareChain([MW1()])
        chain.after_session(session, mock_store)
        assert calls == ["ended"]

    def test_exception_in_before_session_does_not_abort(self, session, mock_store):
        class Broken(TurnMiddleware):
            def before_session(self, session, store):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def before_session(self, session, store):
                return "survived"

        chain = MiddlewareChain([Broken(), Good()])
        result = chain.before_session(session, mock_store)
        assert result == "survived"

    def test_exception_in_void_method_does_not_abort(self, session, classification):
        calls = []

        class Broken(TurnMiddleware):
            def after_classify(self, session, classification):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def after_classify(self, session, classification):
                calls.append("survived")

        chain = MiddlewareChain([Broken(), Good()])
        chain.after_classify(session, classification)
        assert calls == ["survived"]

    def test_add_middleware(self, session, mock_store):
        chain = MiddlewareChain()

        class MW1(TurnMiddleware):
            def before_session(self, session, store):
                return "added"

        chain.add(MW1())
        assert chain.before_session(session, mock_store) == "added"


class TestOnMessageReceived:
    """Sequential transform: each middleware transforms the result of the previous."""

    def test_single_transform(self, session):
        class Upper(TurnMiddleware):
            def on_message_received(self, session, user_input):
                return user_input.upper()

        chain = MiddlewareChain([Upper()])
        assert chain.on_message_received(session, "hello") == "HELLO"

    def test_chained_transforms(self, session):
        class Prefix(TurnMiddleware):
            def on_message_received(self, session, user_input):
                return f"[prefix] {user_input}"

        class Upper(TurnMiddleware):
            def on_message_received(self, session, user_input):
                return user_input.upper()

        chain = MiddlewareChain([Prefix(), Upper()])
        assert chain.on_message_received(session, "hello") == "[PREFIX] HELLO"

    def test_exception_skips_middleware(self, session):
        class Broken(TurnMiddleware):
            def on_message_received(self, session, user_input):
                raise RuntimeError("boom")

        class Upper(TurnMiddleware):
            def on_message_received(self, session, user_input):
                return user_input.upper()

        chain = MiddlewareChain([Broken(), Upper()])
        # Broken raises, chain skips it but continues with current value
        assert chain.on_message_received(session, "hello") == "HELLO"

    def test_empty_chain_passthrough(self, session):
        chain = MiddlewareChain([])
        assert chain.on_message_received(session, "hello") == "hello"


class TestOnMessageSending:
    """Sequential transform on response."""

    def test_chained_transforms(self, session):
        class Suffix(TurnMiddleware):
            def on_message_sending(self, session, response):
                return response + " [end]"

        class Upper(TurnMiddleware):
            def on_message_sending(self, session, response):
                return response.upper()

        chain = MiddlewareChain([Suffix(), Upper()])
        assert chain.on_message_sending(session, "hello") == "HELLO [END]"

    def test_exception_skips_middleware(self, session):
        class Broken(TurnMiddleware):
            def on_message_sending(self, session, response):
                raise RuntimeError("boom")

        chain = MiddlewareChain([Broken()])
        assert chain.on_message_sending(session, "hello") == "hello"


class TestBeforePromptBuild:
    """Concatenate non-empty returns with double newline."""

    def test_aggregates_strings(self, session, mock_store):
        class MW1(TurnMiddleware):
            def before_prompt_build(self, session, store):
                return "context-1"

        class MW2(TurnMiddleware):
            def before_prompt_build(self, session, store):
                return "context-2"

        chain = MiddlewareChain([MW1(), MW2()])
        assert (
            chain.before_prompt_build(session, mock_store) == "context-1\n\ncontext-2"
        )

    def test_skips_empty(self, session, mock_store):
        class MW1(TurnMiddleware):
            def before_prompt_build(self, session, store):
                return ""

        class MW2(TurnMiddleware):
            def before_prompt_build(self, session, store):
                return "only-this"

        chain = MiddlewareChain([MW1(), MW2()])
        assert chain.before_prompt_build(session, mock_store) == "only-this"

    def test_exception_does_not_abort(self, session, mock_store):
        class Broken(TurnMiddleware):
            def before_prompt_build(self, session, store):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def before_prompt_build(self, session, store):
                return "survived"

        chain = MiddlewareChain([Broken(), Good()])
        assert chain.before_prompt_build(session, mock_store) == "survived"

    def test_empty_chain(self, session, mock_store):
        chain = MiddlewareChain([])
        assert chain.before_prompt_build(session, mock_store) == ""


class TestOnLlmInput:
    """Fire-and-forget: observe messages."""

    def test_all_called(self, session):
        calls = []

        class MW1(TurnMiddleware):
            def on_llm_input(self, session, messages):
                calls.append(("mw1", len(messages)))

        class MW2(TurnMiddleware):
            def on_llm_input(self, session, messages):
                calls.append(("mw2", len(messages)))

        chain = MiddlewareChain([MW1(), MW2()])
        msgs = [{"role": "user", "content": "hi"}]
        chain.on_llm_input(session, msgs)
        assert calls == [("mw1", 1), ("mw2", 1)]

    def test_exception_does_not_abort(self, session):
        calls = []

        class Broken(TurnMiddleware):
            def on_llm_input(self, session, messages):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def on_llm_input(self, session, messages):
                calls.append("survived")

        chain = MiddlewareChain([Broken(), Good()])
        chain.on_llm_input(session, [])
        assert calls == ["survived"]


class TestOnLlmOutput:
    """Fire-and-forget: observe LLM response."""

    def test_all_called(self, session):
        calls = []

        class MW1(TurnMiddleware):
            def on_llm_output(self, session, response, tool_calls):
                calls.append(("mw1", response, len(tool_calls)))

        chain = MiddlewareChain([MW1()])
        chain.on_llm_output(session, "hello", [{"name": "tool1"}])
        assert calls == [("mw1", "hello", 1)]

    def test_exception_does_not_abort(self, session):
        calls = []

        class Broken(TurnMiddleware):
            def on_llm_output(self, session, response, tool_calls):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def on_llm_output(self, session, response, tool_calls):
                calls.append("survived")

        chain = MiddlewareChain([Broken(), Good()])
        chain.on_llm_output(session, "hi", [])
        assert calls == ["survived"]


class TestBeforeToolCall:
    """Sequential: first blocked=True wins."""

    def test_passthrough(self, session):
        chain = MiddlewareChain([TurnMiddleware()])
        args, blocked = chain.before_tool_call(session, "tool", {"k": "v"})
        assert args == {"k": "v"}
        assert blocked is False

    def test_modify_arguments(self, session):
        class Modifier(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                return {**arguments, "extra": True}, False

        chain = MiddlewareChain([Modifier()])
        args, blocked = chain.before_tool_call(session, "tool", {"k": "v"})
        assert args == {"k": "v", "extra": True}
        assert blocked is False

    def test_first_block_wins(self, session):
        calls = []

        class Blocker(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                return arguments, True

        class NeverReached(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                calls.append("should not run")
                return arguments, False

        chain = MiddlewareChain([Blocker(), NeverReached()])
        args, blocked = chain.before_tool_call(session, "tool", {"k": "v"})
        assert blocked is True
        assert calls == []  # second middleware never ran

    def test_chained_modifications(self, session):
        class Add1(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                return {**arguments, "a": 1}, False

        class Add2(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                return {**arguments, "b": 2}, False

        chain = MiddlewareChain([Add1(), Add2()])
        args, blocked = chain.before_tool_call(session, "tool", {})
        assert args == {"a": 1, "b": 2}
        assert blocked is False

    def test_exception_does_not_abort(self, session):
        class Broken(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                raise RuntimeError("boom")

        class Modifier(TurnMiddleware):
            def before_tool_call(self, session, tool_name, arguments):
                return {**arguments, "ok": True}, False

        chain = MiddlewareChain([Broken(), Modifier()])
        args, blocked = chain.before_tool_call(session, "tool", {})
        assert args == {"ok": True}
        assert blocked is False

    def test_empty_chain(self, session):
        chain = MiddlewareChain([])
        args, blocked = chain.before_tool_call(session, "tool", {"k": "v"})
        assert args == {"k": "v"}
        assert blocked is False


class TestAfterToolCall:
    """Fire-and-forget: observe tool results."""

    def test_all_called(self, session):
        calls = []

        class MW1(TurnMiddleware):
            def after_tool_call(self, session, tool_name, arguments, result):
                calls.append(("mw1", tool_name, result))

        class MW2(TurnMiddleware):
            def after_tool_call(self, session, tool_name, arguments, result):
                calls.append(("mw2", tool_name, result))

        chain = MiddlewareChain([MW1(), MW2()])
        chain.after_tool_call(session, "my_tool", {"k": "v"}, "success")
        assert calls == [("mw1", "my_tool", "success"), ("mw2", "my_tool", "success")]

    def test_exception_does_not_abort(self, session):
        calls = []

        class Broken(TurnMiddleware):
            def after_tool_call(self, session, tool_name, arguments, result):
                raise RuntimeError("boom")

        class Good(TurnMiddleware):
            def after_tool_call(self, session, tool_name, arguments, result):
                calls.append("survived")

        chain = MiddlewareChain([Broken(), Good()])
        chain.after_tool_call(session, "tool", {}, "result")
        assert calls == ["survived"]
