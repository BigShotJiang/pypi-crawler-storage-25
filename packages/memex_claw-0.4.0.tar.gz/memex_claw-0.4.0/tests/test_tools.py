"""Tests for tool registry and relevance filtering."""

from unittest.mock import MagicMock, patch

from memex.models import ToolDefinition
from memex.tools import ToolRegistry, to_openai_tools


def _tool(
    name: str,
    capability: str = "builtin.read",
    always_present: bool = False,
    keywords: list[str] | None = None,
    source: str = "test",
    aliases: list[str] | None = None,
    capability_tags: list[str] | None = None,
    preferred_classifications: list[str] | None = None,
    supported_intent_paths: list[str] | None = None,
) -> ToolDefinition:
    return ToolDefinition(
        name=name,
        description=f"Test {name}",
        source=source,
        required_capability=capability,
        always_present=always_present,
        keywords=keywords or [],
        aliases=aliases or [],
        capability_tags=capability_tags or [],
        preferred_classifications=preferred_classifications or [],
        supported_intent_paths=supported_intent_paths or [],
    )


def test_register_and_get():
    reg = ToolRegistry()
    t = _tool("a")
    reg.register(t)
    assert reg.get_tool("a") == t
    assert reg.get_tool("missing") is None


def test_unregister_source():
    reg = ToolRegistry()
    reg.register(_tool("a", source="wake"))
    reg.register(_tool("b", source="armada"))
    reg.unregister_source("wake")
    assert reg.get_tool("a") is None
    assert reg.get_tool("b") is not None


def test_all_tools():
    reg = ToolRegistry()
    reg.register(_tool("a"))
    reg.register(_tool("b"))
    assert len(reg.all_tools()) == 2


def test_get_tools_for_context_capability_filter():
    reg = ToolRegistry()
    reg.register(_tool("a", capability="builtin.read"))
    reg.register(_tool("b", capability="wake.read"))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("hello", [], granted)
    assert len(result) == 1
    assert result[0].name == "a"


def test_get_tools_for_context_always_present():
    reg = ToolRegistry()
    reg.register(_tool("always", always_present=True))
    reg.register(_tool("optional"))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("hello", [], granted)
    assert any(t.name == "always" for t in result)


def test_get_tools_for_context_keyword_scoring():
    reg = ToolRegistry()
    reg.register(_tool("weather", keywords=["weather", "forecast"]))
    reg.register(_tool("code", keywords=["code", "review", "search"]))
    reg.register(_tool("other", keywords=["unrelated", "stuff"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("what is the weather forecast", [], granted)
    # weather tool should be ranked first
    assert result[0].name == "weather"


def test_get_tools_for_context_max_tools():
    reg = ToolRegistry()
    # Use matching keywords so tools aren't excluded by threshold
    for i in range(20):
        reg.register(_tool(f"t{i}", keywords=["hello"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("hello", [], granted, max_tools=5)
    assert len(result) == 5


def test_get_tools_for_context_empty_when_no_capabilities():
    reg = ToolRegistry()
    reg.register(_tool("a", capability="wake.read"))
    result = reg.get_tools_for_context("hello", [], set())
    assert result == []


def test_get_tools_for_context_goal_titles_contribute():
    reg = ToolRegistry()
    reg.register(_tool("deploy", keywords=["deploy", "release"]))
    reg.register(_tool("other", keywords=["unrelated"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context(
        "status update", ["deploy to production"], granted
    )
    assert result[0].name == "deploy"


def test_to_openai_tools():
    tools = [
        ToolDefinition(
            name="test_tool",
            description="A test",
            parameters={"type": "object", "properties": {"q": {"type": "string"}}},
            source="test",
            required_capability="builtin.read",
        ),
    ]
    result = to_openai_tools(tools)
    assert len(result) == 1
    assert result[0]["type"] == "function"
    assert result[0]["function"]["name"] == "test_tool"
    assert "q" in result[0]["function"]["parameters"]["properties"]


def test_to_openai_tools_empty_params():
    tools = [_tool("simple")]
    result = to_openai_tools(tools)
    assert result[0]["function"]["parameters"] == {"type": "object", "properties": {}}


# --- Alias tests ---


def test_alias_resolution():
    reg = ToolRegistry()
    t = _tool("bash", aliases=["exec", "shell"])
    reg.register(t)
    assert reg.get_tool("exec") == t
    assert reg.get_tool("shell") == t
    assert reg.get_tool("bash") == t


def test_alias_cleanup_on_unregister():
    reg = ToolRegistry()
    reg.register(_tool("bash", source="cc", aliases=["exec"]))
    assert reg.get_tool("exec") is not None
    reg.unregister_source("cc")
    assert reg.get_tool("exec") is None
    assert reg.get_tool("bash") is None


def test_register_alias_method():
    reg = ToolRegistry()
    reg.register(_tool("bash"))
    reg.register_alias("exec", "bash")
    assert reg.get_tool("exec").name == "bash"


def test_resolve_alias():
    reg = ToolRegistry()
    reg.register_alias("exec", "bash")
    assert reg.resolve_alias("exec") == "bash"
    assert reg.resolve_alias("unknown") == "unknown"


def test_tool_registered_event():
    """Event publishing during register() should not crash even without bus."""
    reg = ToolRegistry()
    mock_bus = MagicMock()
    with patch("memex.event_bus.get_bus", return_value=mock_bus):
        reg.register(_tool("a"))
        mock_bus.publish.assert_called_once()


def test_tool_unregistered_event():
    """Event publishing during unregister_source() should not crash."""
    reg = ToolRegistry()
    mock_bus = MagicMock()
    reg.register(_tool("a", source="wake"))
    with patch("memex.event_bus.get_bus", return_value=mock_bus):
        reg.unregister_source("wake")
        mock_bus.publish.assert_called_once()


# --- New tests for scoring, threshold, classification, usage boost ---


def test_zero_score_tools_excluded():
    """Tools with no keyword match should not be returned."""
    reg = ToolRegistry()
    reg.register(_tool("always", always_present=True, keywords=["core"]))
    reg.register(_tool("match", keywords=["weather"]))
    reg.register(_tool("nomatch", keywords=["unrelated", "stuff"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("what is the weather", [], granted)
    names = [t.name for t in result]
    assert "always" in names
    assert "match" in names
    assert "nomatch" not in names


def test_classification_reduces_budget():
    """Conversational classification caps tools at 5."""
    reg = ToolRegistry()
    for i in range(10):
        reg.register(_tool(f"t{i}", keywords=["hello"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context(
        "hello there", [], granted, classification="conversational"
    )
    assert len(result) <= 5


def test_more_keywords_helps_not_hurts():
    """Tool with more matching keywords should rank higher than one with fewer."""
    reg = ToolRegistry()
    # Tool A: 2 keywords, 1 match
    reg.register(_tool("a", keywords=["weather", "cloud"]))
    # Tool B: 5 keywords, 2 matches
    reg.register(_tool("b", keywords=["weather", "forecast", "rain", "sun", "temp"]))
    granted = {"builtin.read"}
    result = reg.get_tools_for_context("what is the weather forecast", [], granted)
    # B has 2 matches, A has 1 match — B should rank higher
    assert result[0].name == "b"


def test_get_matched_keywords():
    """get_matched_keywords returns correct keyword list."""
    reg = ToolRegistry()
    reg.register(_tool("weather", keywords=["weather", "forecast", "rain"]))
    matched = reg.get_matched_keywords("weather", "what is the weather forecast")
    assert "weather" in matched
    assert "forecast" in matched
    assert "rain" not in matched


def test_get_matched_keywords_missing_tool():
    """get_matched_keywords returns empty for unknown tool."""
    reg = ToolRegistry()
    assert reg.get_matched_keywords("nonexistent", "hello") == []


def test_usage_boost_affects_scoring():
    """Tool with 0 keyword overlap but high usage_boosts still included."""
    reg = ToolRegistry()
    reg.register(_tool("popular", keywords=["unrelated"]))
    reg.register(_tool("unpopular", keywords=["also_unrelated"]))
    granted = {"builtin.read"}
    # Without boost, neither matches "hello world"
    result = reg.get_tools_for_context("hello world", [], granted)
    assert len(result) == 0

    # With boost, popular tool gets score > 0
    result = reg.get_tools_for_context(
        "hello world",
        [],
        granted,
        usage_boosts={"popular": 20},  # +2.0 boost
    )
    names = [t.name for t in result]
    assert "popular" in names
    assert "unpopular" not in names


def test_usage_boost_capped():
    """Usage boost is capped at 2.0 regardless of call count."""
    reg = ToolRegistry()
    reg.register(_tool("tool_a", keywords=["match"]))
    reg.register(_tool("tool_b", keywords=["different"]))
    granted = {"builtin.read"}
    # tool_a has 1 keyword match (score=1.0), tool_b has huge usage but no match
    result = reg.get_tools_for_context(
        "match this",
        [],
        granted,
        usage_boosts={"tool_b": 1000},  # capped at +2.0
    )
    # Both should be included, but tool_b (2.0) > tool_a (1.0)
    names = [t.name for t in result]
    assert "tool_a" in names
    assert "tool_b" in names


def test_capability_tags_boost_relevant_tool():
    reg = ToolRegistry()
    reg.register(_tool("status", keywords=["status"]))
    reg.register(_tool("diagnostics", capability_tags=["system.diagnostics"]))
    granted = {"builtin.read"}

    result = reg.get_tools_for_context("run a health check", [], granted)

    assert result[0].name == "diagnostics"


def test_preferred_classification_breaks_tie():
    reg = ToolRegistry()
    reg.register(
        _tool(
            "search_knowledge",
            keywords=["remember"],
            capability_tags=["memory.search"],
            preferred_classifications=["knowledge_query"],
        )
    )
    reg.register(
        _tool(
            "remember",
            capability="builtin.write",
            keywords=["remember"],
            capability_tags=["memory.write"],
            preferred_classifications=["conversational"],
        )
    )
    granted = {"builtin.read", "builtin.write"}

    result = reg.get_tools_for_context(
        "remember rust notes",
        [],
        granted,
        classification="knowledge_query",
    )

    assert result[0].name == "search_knowledge"


def test_supported_intent_paths_filter_action_tools_from_direct_answer():
    reg = ToolRegistry()
    reg.register(
        _tool(
            "remember",
            capability="builtin.write",
            capability_tags=["memory.write"],
            supported_intent_paths=["act"],
        )
    )
    reg.register(
        _tool(
            "search_knowledge",
            capability_tags=["memory.search"],
            supported_intent_paths=["direct_answer", "act"],
        )
    )
    granted = {"builtin.read", "builtin.write"}

    result = reg.get_tools_for_context(
        "what do you remember about rust",
        [],
        granted,
        classification="knowledge_query",
        intent_path="direct_answer",
    )

    names = [t.name for t in result]
    assert "search_knowledge" in names
    assert "remember" not in names
