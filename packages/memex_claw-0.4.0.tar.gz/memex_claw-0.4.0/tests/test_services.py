"""Tests for ServiceManager lifecycle."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from memex.runtime_state import RuntimeStateRegistry
from memex.event_bus import EventBus
from memex.services import Service, ServiceContext, ServiceManager


class DummyService(Service):
    """Test service that records lifecycle calls."""

    def __init__(self, svc_id: str = "dummy", name: str = "Dummy") -> None:
        self._id = svc_id
        self._name = name
        self.started = False
        self.stopped = False
        self.start_ctx: ServiceContext | None = None
        self.stop_ctx: ServiceContext | None = None

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return self._name

    def start(self, ctx: ServiceContext) -> None:
        self.started = True
        self.start_ctx = ctx

    def stop(self, ctx: ServiceContext) -> None:
        self.stopped = True
        self.stop_ctx = ctx


class BrokenService(Service):
    """Service that raises on start/stop."""

    @property
    def id(self) -> str:
        return "broken"

    @property
    def name(self) -> str:
        return "Broken"

    def start(self, ctx: ServiceContext) -> None:
        raise RuntimeError("start failed")

    def stop(self, ctx: ServiceContext) -> None:
        raise RuntimeError("stop failed")


@pytest.fixture
def mock_store():
    return MagicMock()


@pytest.fixture
def event_bus():
    return EventBus()


@pytest.fixture
def mgr(mock_store, event_bus, tmp_path):
    runtime_registry = RuntimeStateRegistry()
    return ServiceManager(
        store=mock_store,
        event_bus=event_bus,
        data_dir=tmp_path / "services",
        runtime_registry=runtime_registry,
    )


class TestServiceManager:
    def test_register_and_start(self, mgr):
        svc = DummyService()
        mgr.register(svc, config={"key": "value"})
        mgr.start_all()

        assert svc.started
        assert svc.start_ctx is not None
        assert svc.start_ctx.config == {"key": "value"}
        assert svc in mgr.running

    def test_stop_all_reverse_order(self, mgr):
        order = []

        class OrderedService(DummyService):
            def stop(self, ctx):
                order.append(self.id)

        svc1 = OrderedService("first", "First")
        svc2 = OrderedService("second", "Second")
        mgr.register(svc1)
        mgr.register(svc2)
        mgr.start_all()
        mgr.stop_all()

        assert order == ["second", "first"]

    def test_stop_clears_running(self, mgr):
        svc = DummyService()
        mgr.register(svc)
        mgr.start_all()
        assert len(mgr.running) == 1
        mgr.stop_all()
        assert len(mgr.running) == 0

    def test_broken_start_does_not_abort_others(self, mgr):
        broken = BrokenService()
        good = DummyService("good", "Good")
        mgr.register(broken)
        mgr.register(good)
        mgr.start_all()

        assert good.started
        assert broken not in mgr.running
        assert good in mgr.running

    def test_broken_stop_does_not_abort_others(self, mgr):
        # Register a good service and a "broken on stop" service
        class BrokenOnStop(DummyService):
            def stop(self, ctx):
                raise RuntimeError("stop boom")

        broken = BrokenOnStop("broken-stop", "BrokenStop")
        good = DummyService("good", "Good")
        mgr.register(good)
        mgr.register(broken)
        mgr.start_all()
        mgr.stop_all()  # should not raise

        assert good.stopped

    def test_context_has_data_dir(self, mgr, tmp_path):
        svc = DummyService("myservice", "My Service")
        mgr.register(svc)
        mgr.start_all()

        assert svc.start_ctx is not None
        assert svc.start_ctx.data_dir == tmp_path / "services" / "myservice"
        assert svc.start_ctx.data_dir.exists()

    def test_context_has_event_bus(self, mgr, event_bus):
        svc = DummyService()
        mgr.register(svc)
        mgr.start_all()
        assert svc.start_ctx.event_bus is event_bus

    def test_context_has_logger(self, mgr):
        svc = DummyService("test-svc", "Test")
        mgr.register(svc)
        mgr.start_all()
        assert svc.start_ctx.logger.name == "memex.services.test-svc"

    def test_registered_property(self, mgr):
        svc1 = DummyService("a", "A")
        svc2 = DummyService("b", "B")
        mgr.register(svc1)
        mgr.register(svc2)
        assert mgr.registered == [svc1, svc2]

    def test_empty_manager(self, mgr):
        mgr.start_all()  # no-op
        mgr.stop_all()  # no-op
        assert mgr.running == []
        assert mgr.registered == []

    def test_default_config(self, mgr):
        svc = DummyService()
        mgr.register(svc)  # no config
        mgr.start_all()
        assert svc.start_ctx.config == {}

    def test_runtime_registry_tracks_service_state(
        self, mock_store, event_bus, tmp_path
    ):
        runtime_registry = RuntimeStateRegistry()
        mgr = ServiceManager(
            store=mock_store,
            event_bus=event_bus,
            data_dir=tmp_path / "services",
            runtime_registry=runtime_registry,
        )
        svc = DummyService("svc-a", "Service A")

        mgr.register(svc)
        mgr.start_all()
        snapshot = runtime_registry.snapshot()
        assert snapshot["services"][0]["id"] == "svc-a"
        assert snapshot["services"][0]["status"] == "running"

        mgr.stop_all()
        snapshot = runtime_registry.snapshot()
        assert snapshot["services"][0]["status"] == "stopped"
