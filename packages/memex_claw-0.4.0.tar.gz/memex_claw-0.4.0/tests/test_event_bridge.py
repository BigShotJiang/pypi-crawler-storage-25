"""Tests for EventBridgeHandler: subscribe/unsubscribe, replay, resync."""

from __future__ import annotations

import collections
import dataclasses
import json
import queue
import threading

from memex.interfaces.event_bridge import EventBridgeHandler


def _make_bridge(maxlen: int = 500) -> EventBridgeHandler:
    bridge = EventBridgeHandler.__new__(EventBridgeHandler)
    bridge._lock = threading.Lock()
    bridge._subscribers = []
    bridge._ring_buffer = collections.deque(maxlen=maxlen)
    bridge._event_id = 0
    return bridge


def _drain(q: queue.SimpleQueue) -> list[tuple]:
    items = []
    while True:
        try:
            items.append(q.get_nowait())
        except queue.Empty:
            break
    return items


@dataclasses.dataclass
class EvtPayload:
    n: int = 0


# -- subscribe / unsubscribe --


def test_subscribe_receives_events():
    bridge = _make_bridge()
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q)
    bridge.on_event(EvtPayload(n=1))
    items = _drain(q)
    assert len(items) == 1
    event_type, data_json, eid = items[0]
    assert event_type == "evt_payload"
    assert json.loads(data_json)["n"] == 1
    assert eid == 1


def test_unsubscribe_stops_delivery():
    bridge = _make_bridge()
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q)
    bridge.remove_subscriber(q)
    bridge.on_event(EvtPayload(n=1))
    assert _drain(q) == []


def test_remove_nonexistent_subscriber_is_noop():
    bridge = _make_bridge()
    bridge.remove_subscriber(queue.SimpleQueue())  # must not raise


# -- ring buffer replay --


def test_replay_sends_missed_events():
    bridge = _make_bridge()
    bridge.on_event(EvtPayload(n=1))  # id=1
    bridge.on_event(EvtPayload(n=2))  # id=2
    bridge.on_event(EvtPayload(n=3))  # id=3
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q, last_event_id=1)
    eids = [item[2] for item in _drain(q)]
    assert eids == [2, 3]


def test_replay_nothing_when_caught_up():
    bridge = _make_bridge()
    bridge.on_event(EvtPayload(n=1))
    bridge.on_event(EvtPayload(n=2))
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q, last_event_id=2)
    assert _drain(q) == []


# -- buffer overflow → resync --


def test_buffer_overflow_sends_resync_then_replay():
    bridge = _make_bridge(maxlen=3)
    for i in range(1, 6):  # ids 1–5, buffer holds only 3–5
        bridge.on_event(EvtPayload(n=i))
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q, last_event_id=1)  # id=2 evicted → overflow
    items = _drain(q)
    assert items[0][0] == "resync"
    assert json.loads(items[0][1])["reason"] == "buffer_overflow"
    assert [item[2] for item in items[1:]] == [3, 4, 5]


def test_no_resync_when_buffer_covers_gap():
    bridge = _make_bridge()
    bridge.on_event(EvtPayload(n=1))  # id=1
    bridge.on_event(EvtPayload(n=2))  # id=2
    bridge.on_event(EvtPayload(n=3))  # id=3
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q, last_event_id=1)
    items = _drain(q)
    assert all(item[0] != "resync" for item in items)
    assert [item[2] for item in items] == [2, 3]


def test_stale_subscriber_evicted_when_queue_depth_exceeded():
    """A subscriber whose queue depth exceeds _STALE_QUEUE_DEPTH is removed."""
    import sys
    import pytest
    from memex.interfaces.event_bridge import _STALE_QUEUE_DEPTH

    if sys.version_info < (3, 11):
        pytest.skip("SimpleQueue.qsize() requires Python 3.11+")

    bridge = _make_bridge()
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q)

    # Pre-fill queue beyond threshold so q.qsize() > _STALE_QUEUE_DEPTH
    for i in range(_STALE_QUEUE_DEPTH + 5):
        q.put(("dummy", "{}", i))

    # Sending the next event should detect the overflow and evict the subscriber
    bridge.on_event(EvtPayload(n=99))

    assert q not in bridge._subscribers, "stale subscriber should have been removed"


def test_healthy_subscriber_not_evicted():
    """A subscriber below the depth threshold must stay registered."""
    import sys
    import pytest

    if sys.version_info < (3, 11):
        pytest.skip("SimpleQueue.qsize() requires Python 3.11+")

    bridge = _make_bridge()
    q: queue.SimpleQueue = queue.SimpleQueue()
    bridge.add_subscriber(q)

    bridge.on_event(EvtPayload(n=1))
    bridge.on_event(EvtPayload(n=2))

    assert q in bridge._subscribers, "healthy subscriber should remain registered"
