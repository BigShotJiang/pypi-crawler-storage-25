# Memex

[![CI](https://github.com/coreyt/memex/actions/workflows/ci.yml/badge.svg)](https://github.com/coreyt/memex/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Personal AI partner with persistent intent tracking, knowledge management, and multi-interface operation. Memex is a thinking partner, not a chatbot -- it tracks your goals across conversations, remembers what matters, connects ideas, and proactively surfaces relevant context.

## Quick Start

```bash
# Clone and install (all dependencies are in the main package)
git clone https://github.com/coreyt/memex.git
cd memex
uv pip install -e .

# Initialize and configure
memex init
memex setup                            # Interactive provider setup wizard

# Set your LLM API key in .env
#   ANTHROPIC_API_KEY=sk-ant-...
#   or OPENAI_API_KEY / GOOGLE_AISTUDIO_API_KEY

# Option A: Full setup (recommended)
memex service                          # Start daemon (scheduler, Telegram, HTTP gateway on :8321)
memex tui                              # Open TUI (connects to daemon)

# Option B: Quick standalone chat
memex chat
```

> **Note:** `.env` is gitignored. Do not commit it — it's for your local credentials only.

Run `memex doctor` at any time to check system health.

## Runtime-loaded governance files

Four files at the repo root -- `CONSTITUTION.md`, `SOUL.md`, `IDENTITY.md`, and `DOCUMENTATION.md` -- are loaded at runtime by `src/memex/governance.py` and injected into Memex's system prompt on every turn. They govern agent behavior, personality, identity, and internal documentation routing respectively. They are runtime infrastructure, not human-facing documentation; if you are just trying to use or understand Memex, you can skip them. Contributors who want to see how they are wired should start with the loader in `src/memex/governance.py`.

## What Memex Does

- **Thinking-partner conversations** -- each turn runs a classify, retrieve, respond, reflect loop that advances goals and updates persistent state
- **Goal and intent tracking** -- hierarchical goals, tasks, commitments, execution state, and plan snapshots that persist across sessions
- **Knowledge capture** -- ingest from files, URLs, stdin, Gmail, RSS feeds, watch folders, YouTube transcripts, and conversations
- **Hybrid search and retrieval** -- full-text + semantic search with temporal decay, source reputation scoring, and token-budgeted context injection
- **Meeting intelligence** -- recording, audio preparation, Whisper transcription with quality scoring and retry, speaker diarization, and action extraction
- **Proactive scheduling** -- 13 built-in scheduled tasks covering briefings, reviews, backups, cleanup, calendar sync, and memory consolidation
- **18 built-in tools** -- search, ingest, remember, forget, diagnostics, self-repair, cost reporting, and more
- **Self-improvement** -- behavioral observations, config tuning proposals, and capability proposals (all human-gated)
- **Episodic memory** -- cross-session event ledger with session briefs, fact extraction, memory consolidation, and cold storage archival

See [dev/FEATURES.md](dev/FEATURES.md) for the complete capability inventory.

## Architecture at a Glance

Every conversation turn executes a three-phase LLM pipeline:

```
Classify (cheap model) --> Respond (full model with tools) --> Reflect (cheap model)
```

Classification determines intent and retrieval budget. The response phase retrieves relevant knowledge, selects tools, and generates a reply. Reflection updates goals, extracts facts, and detects behavioral patterns.

**Two-process model**: `memex service` runs the daemon (Telegram polling, cron scheduler, HTTP/SSE gateway on port 8321). `memex tui` is a thin client that connects over HTTP/SSE. `memex chat` works standalone without the daemon.

**Storage**: SQLite is the primary store (WAL mode). FathomDB provides a derived retrieval layer with graph, vector, and full-text search (including FTS with Porter stemmer and vector profiles). Embeddings use sentence-transformers locally; Qdrant is an optional server-side backend.

**Unified API**: All interfaces (CLI, TUI, Telegram, MCP) route through `MemexAPI` for consistent caller identity, format injection, and session handling.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the full design.

## Interfaces

| Interface | Description |
|-----------|-------------|
| **CLI** | `memex chat`, `memex goal`, `memex search`, `memex ingest`, and 20+ other commands |
| **TUI** | Three-panel Textual interface (goals, chat, notifications) connecting to the service daemon |
| **Telegram** | Bot with user-ID auth, message batching, URL ingestion; managed by `memex service` |
| **MCP Server** | `memex serve` exposes scoped tool sets (`read_only`, `collaborative`, `full`) for external agents |
| **HTTP Gateway** | REST + SSE on port 8321, provided by `memex service` for TUI and automation |

See [docs/user/](docs/user/) for interface-specific guides: [TUI Guide](docs/user/tui-guide.md), [CLI Reference](docs/user/cli-reference.md), [Integrations](docs/user/integrations.md).

## Documentation

| Document | Contents |
|----------|----------|
| [docs/user/getting-started.md](docs/user/getting-started.md) | Installation, first run, initial configuration |
| [docs/user/cli-reference.md](docs/user/cli-reference.md) | All CLI commands and flags |
| [docs/user/tui-guide.md](docs/user/tui-guide.md) | TUI layout, keybindings, service connection |
| [docs/user/meetings.md](docs/user/meetings.md) | Recording, transcription, diarization, action extraction |
| [docs/user/knowledge.md](docs/user/knowledge.md) | Ingestion, search, retrieval, decay, reputation |
| [docs/user/scheduling.md](docs/user/scheduling.md) | Scheduler, built-in tasks, work queue |
| [docs/user/integrations.md](docs/user/integrations.md) | Gmail, Google Calendar, iCloud, Outlook, Claude Code, MCP |
| [docs/user/configuration.md](docs/user/configuration.md) | Environment variables, LLM providers, vector backends |
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design, component map, trade-offs |
| [dev/FEATURES.md](dev/FEATURES.md) | Complete feature inventory |

## Configuration

Key environment variables (set in `.env`):

| Variable | Default | Description |
|----------|---------|-------------|
| `ANTHROPIC_API_KEY` | -- | Anthropic API key (or `OPENAI_API_KEY`, `GOOGLE_AISTUDIO_API_KEY`) |
| `MEMEX_RESPONSE_MODEL` | `anthropic/claude-sonnet-4-20250514` | LLM for main responses |
| `MEMEX_CHEAP_MODEL` | `anthropic/claude-haiku-4-5-20251001` | LLM for classify/reflect |
| `MEMEX_STORE` | `.memex/memex.db` | SQLite database path |
| `TELEGRAM_BOT_TOKEN` | -- | Telegram bot token (enables Telegram in `memex service`) |
| `TELEGRAM_USER_ID` | -- | Comma-separated allowed Telegram user IDs |

See [docs/user/configuration.md](docs/user/configuration.md) for the full variable reference including LLM proxy, connectors, vector search, meetings, and integration credentials.

## Development

```bash
# Install dev dependencies
uv sync

# Run tests
uv run pytest tests/ -q

# Run the operability gate (startup, doctor, API, scheduler, Telegram, CLI regression)
source .env && uv run memex-operability

# Lint
uv run ruff check src/ tests/
```

### Optional Extras

All core features are included in the base install. Optional extras:

```bash
uv pip install -e ".[diarization]"     # Speaker diarization (pyannote.audio; requires HF token)
uv pip install -e ".[dev]"             # Testing and development tools
```

## License

MIT
