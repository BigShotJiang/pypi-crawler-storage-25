import ast
import asyncio
import fnmatch
import importlib.util
import inspect
import json
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, get_args, get_origin, get_type_hints

import yaml

from .core import (
    Agent,
    AgentConfig,
    AgentType,
    ApprovalConfig,
    CollectionPermissions,
    CustomGuardrail,
    DatabaseAccessConfig,
    GuardrailRule,
    GuardrailsConfig,
    KnowledgeAccessConfig,
    McpServerConfig,
    Middleware,
    NamespacePermissions,
    RetryOptions,
    Tool,
    ToolHook,
)

# List of predefined tool names - SDK knows names only, not implementations
# Actual implementations are in the runner (backend/app/templates/predefined_tools/)
PREDEFINED_TOOL_NAMES = {
    "trigger_agent",
    "trigger_agent_at",
    "query_knowledge",              # Query the knowledge base using semantic search
    "store_knowledge",              # Store new knowledge in the knowledge base
    "delete_knowledge",             # Delete knowledge from the knowledge base
    "kb_list_namespaces",           # List knowledge base namespaces and hierarchy
    "web_search",           # Search the web for real-time information (costs 2x runs)
    "web_read_page",        # Fetch a web page and return its content as markdown (costs 2x runs)
    # Database tools
    "db_find",              # Query documents with JSON filters
    "db_insert",            # Insert documents into a collection (auto-creates collection)
    "db_update",            # Update documents matching a filter
    "db_upsert",            # Update first matching document, or insert if none matches
    "db_delete",            # Delete documents matching a filter
    "db_count",             # Count documents matching a filter
    "db_list_collections",  # List all collections in the environment
}


class ProjectLoader:
    """
    Loads a Connic project from disk, discovering agents, tools, and middlewares.
    """
    
    def __init__(self, project_root: str = ".", api_spec_tools: Optional[Dict[str, Dict[str, Any]]] = None, validation_only: bool = False):
        self.project_root = Path(project_root).resolve()
        self.agents_dir = self.project_root / "agents"
        self.tools_dir = self.project_root / "tools"
        self.middleware_dir = self.project_root / "middleware"
        self.schemas_dir = self.project_root / "schemas"
        self.guardrails_dir = self.project_root / "guardrails"
        self.hooks_dir = self.project_root / "hooks"

        # When True, use AST parsing instead of importing tool modules.
        # This avoids executing code and needing external dependencies at validation time.
        self._validation_only = validation_only

        # Cache for loaded modules to avoid reloading
        self._loaded_modules: Dict[str, Any] = {}
        # Cache for loaded middlewares
        self._loaded_middlewares: Dict[str, Optional[Middleware]] = {}
        # Cache for loaded schemas
        self._loaded_schemas: Dict[str, Dict[str, Any]] = {}
        # Cache for loaded custom guardrails
        self._loaded_guardrails: Dict[str, Optional[CustomGuardrail]] = {}
        # Cache for loaded tool hooks
        self._loaded_tool_hooks: Dict[str, Optional[ToolHook]] = {}
        # Errors accumulated during loading (checked by linter)
        self._load_errors: List[str] = []
        # Warnings for api: refs that can't be validated locally (no registry)
        self._api_spec_warnings: List[str] = []

        self._api_spec_tools: Dict[str, Dict[str, Any]] = api_spec_tools or {}

        # Ensure project root is in sys.path for imports
        if str(self.project_root) not in sys.path:
            sys.path.insert(0, str(self.project_root))

    def _discover_agent_files(self) -> List[Path]:
        """Discover agent YAML files recursively under agents/."""
        agent_files: List[Path] = []
        seen_paths = set()

        for pattern in ("*.yaml", "*.yml"):
            for agent_file in self.agents_dir.rglob(pattern):
                relative_parts = agent_file.relative_to(self.agents_dir).parts
                if any(part.startswith(".") for part in relative_parts):
                    continue

                resolved_path = agent_file.resolve()
                if resolved_path in seen_paths:
                    continue

                seen_paths.add(resolved_path)
                agent_files.append(agent_file)

        return sorted(agent_files, key=lambda path: path.relative_to(self.agents_dir).as_posix())

    def load_agents(self) -> List[Agent]:
        """
        Scans the agents directory and loads all defined agents.
        
        Returns:
            List of loaded Agent objects
        
        Raises:
            FileNotFoundError: If agents directory doesn't exist
        """
        if not self.agents_dir.exists():
            raise FileNotFoundError(f"Agents directory not found at {self.agents_dir}")

        agents = []
        errors = []
        
        loaded_names: Dict[str, Path] = {}

        for agent_file in self._discover_agent_files():
            try:
                agent = self._load_single_agent(agent_file)
                existing_file = loaded_names.get(agent.config.name)
                if existing_file:
                    existing_rel = existing_file.relative_to(self.project_root).as_posix()
                    current_rel = agent_file.relative_to(self.project_root).as_posix()
                    errors.append(
                        f"{current_rel}: duplicate agent name '{agent.config.name}' already defined in {existing_rel}"
                    )
                    continue

                loaded_names[agent.config.name] = agent_file
                agents.append(agent)
            except Exception as e:
                errors.append(f"{agent_file.relative_to(self.project_root).as_posix()}: {e}")
        
        if errors:
            for error in errors:
                self._load_errors.append(f"Failed to load agent: {error}")

        # Detect A/B test variant agents by naming convention: {base-agent}-test-{name}
        base_agent_names = set(loaded_names.keys())
        for agent in agents:
            name = agent.config.name
            if "-test-" not in name:
                continue

            # Try all possible split points to find the longest matching base agent
            idx = 0
            matched_base = None
            while True:
                pos = name.find("-test-", idx)
                if pos == -1:
                    break
                candidate_base = name[:pos]
                candidate_test = name[pos + len("-test-"):]
                if candidate_base in base_agent_names and candidate_test:
                    matched_base = candidate_base
                    matched_test = candidate_test
                    # Keep looking for a longer base match
                idx = pos + 1

            if matched_base:
                agent.config.is_test_variant = True
                agent.config.base_agent_name = matched_base
                agent.config.test_name = matched_test
            else:
                # Name contains -test- but no base agent matches — load error
                self._load_errors.append(
                    f"Agent '{name}' looks like a test variant (contains '-test-') "
                    f"but no matching base agent was found. "
                    f"Expected a base agent named '{name.split('-test-')[0]}' to exist."
                )

        return agents

    def load_agent(self, name: str) -> Agent:
        """
        Load a specific agent by name.
        
        Args:
            name: The agent name (filename without .yaml extension)
            
        Returns:
            The loaded Agent object
        """
        for agent in self.load_agents():
            if agent.config.name == name:
                return agent

        raise FileNotFoundError(f"Agent '{name}' not found under {self.agents_dir}")

    def _parse_tool_entry(self, tool_entry: Any, label: str) -> tuple[str, Optional[str]]:
        if isinstance(tool_entry, str):
            return tool_entry, None
        if isinstance(tool_entry, dict):
            if len(tool_entry) != 1:
                raise ValueError(f"Conditional {label} entry must have exactly one key, got: {tool_entry}")
            return list(tool_entry.keys())[0], str(list(tool_entry.values())[0])

        field_name = "discoverable_tools" if label == "discoverable tool" else "tool"
        raise ValueError(f"Invalid {field_name} entry: {tool_entry}")

    def _resolve_agent_tool_entries(self, config: AgentConfig, entries: List[Any], label: str) -> List[Tool]:
        resolved_tools = []
        for tool_entry in entries:
            tool_ref, condition = self._parse_tool_entry(tool_entry, label)

            if condition:
                self._validate_condition(condition, tool_ref)

            try:
                resolved = self._resolve_tools(tool_ref)
            except Exception as e:
                self._load_errors.append(f"Agent '{config.name}': cannot resolve {label} '{tool_ref}': {e}")
                continue

            for tool in resolved:
                if condition:
                    tool.condition = condition
                resolved_tools.append(tool)

        return resolved_tools

    def _load_single_agent(self, agent_file: Path) -> Agent:
        """Load a single agent from a YAML file."""
        with open(agent_file, "r") as f:
            config_data = yaml.safe_load(f)
        
        if not config_data:
            raise ValueError(f"Empty configuration in {agent_file.name}")
        
        # Handle retry_options as nested object
        if "retry_options" in config_data and config_data["retry_options"]:
            config_data["retry_options"] = RetryOptions(**config_data["retry_options"])
        
        # Handle mcp_servers as list of nested objects
        if "mcp_servers" in config_data and config_data["mcp_servers"]:
            config_data["mcp_servers"] = [
                McpServerConfig(**server) if isinstance(server, dict) else server
                for server in config_data["mcp_servers"]
            ]
        
        # Handle database access config
        if "database" in config_data and config_data["database"]:
            db_raw = dict(config_data["database"])
            if "collections" in db_raw and isinstance(db_raw["collections"], list):
                # Simple format: flat list -> dict with empty per-collection permissions
                db_raw["collections"] = {name: CollectionPermissions() for name in db_raw["collections"]}
            elif "collections" in db_raw and isinstance(db_raw["collections"], dict):
                # Advanced format: dict with optional per-collection overrides
                db_raw["collections"] = {
                    name: CollectionPermissions(**(perms or {}))
                    for name, perms in db_raw["collections"].items()
                }
            config_data["database"] = DatabaseAccessConfig(**db_raw)

        # Handle knowledge access config
        if "knowledge" in config_data and config_data["knowledge"]:
            kn_raw = dict(config_data["knowledge"])
            if "namespaces" in kn_raw and isinstance(kn_raw["namespaces"], list):
                # Simple format: flat list -> dict with empty per-namespace permissions
                kn_raw["namespaces"] = {name: NamespacePermissions() for name in kn_raw["namespaces"]}
            elif "namespaces" in kn_raw and isinstance(kn_raw["namespaces"], dict):
                # Advanced format: dict with optional per-namespace overrides
                kn_raw["namespaces"] = {
                    name: NamespacePermissions(**(perms or {}))
                    for name, perms in kn_raw["namespaces"].items()
                }
            config_data["knowledge"] = KnowledgeAccessConfig(**kn_raw)

        # Handle guardrails config
        if "guardrails" in config_data and config_data["guardrails"]:
            gr_raw = config_data["guardrails"]
            parsed = {}
            for direction in ("input", "output"):
                if direction in gr_raw and gr_raw[direction]:
                    parsed[direction] = [
                        GuardrailRule(**rule) if isinstance(rule, dict) else rule
                        for rule in gr_raw[direction]
                    ]
            config_data["guardrails"] = GuardrailsConfig(**parsed)

        # Handle approval config
        if "approval" in config_data and config_data["approval"]:
            approval_raw = config_data["approval"]
            # Validate conditions on approval tools (same pattern as conditional tool parsing)
            for entry in approval_raw.get("tools", []):
                if isinstance(entry, dict):
                    if len(entry) != 1:
                        raise ValueError(
                            f"Conditional approval entry must have exactly one key, got: {entry}"
                        )
                    tool_ref = list(entry.keys())[0]
                    condition = str(list(entry.values())[0])
                    self._validate_condition(condition, tool_ref)
            config_data["approval"] = ApprovalConfig(**approval_raw)

        # Convert type string to enum if present
        if "type" in config_data and isinstance(config_data["type"], str):
            config_data["type"] = AgentType(config_data["type"])
        
        # Parse config
        config = AgentConfig(**config_data)
        config.source_path = agent_file.relative_to(self.project_root).as_posix()
        
        # Load output schema if specified (LLM agents only)
        if config.output_schema:
            if config.type == AgentType.LLM:
                try:
                    schema_dict = self._load_schema(config.output_schema)
                    config.output_schema_dict = schema_dict
                except Exception as e:
                    print(f"Warning: Could not load output schema '{config.output_schema}' for agent '{config.name}': {e}")
            else:
                print(f"Warning: output_schema is only supported for LLM agents. Ignoring for '{config.name}' (type: {config.type.value})")
        
        tools = []
        discoverable_tools = []

        if config.type == AgentType.LLM:
            tools = self._resolve_agent_tool_entries(config, config.tools, "tool")
            discoverable_tools = self._resolve_agent_tool_entries(
                config,
                config.discoverable_tools,
                "discoverable tool",
            )

        elif config.type == AgentType.TOOL:
            # Tool agents: resolve the single tool_name
            if config.tool_name:
                try:
                    resolved = self._resolve_tools(config.tool_name)
                    tools.extend(resolved)
                except Exception as e:
                    self._load_errors.append(f"Tool agent '{config.name}': cannot resolve tool '{config.tool_name}': {e}")

        tool_names = {t.name for t in tools}
        discoverable_names = {t.name for t in discoverable_tools}
        overlap = tool_names & discoverable_names
        if overlap:
            raise ValueError(
                f"Tools cannot appear in both 'tools' and 'discoverable_tools': {', '.join(sorted(overlap))}"
            )

        all_tools_for_dedup = tools + discoverable_tools
        duplicate_tool_names: Dict[str, List[str]] = {}
        for tool in all_tools_for_dedup:
            duplicate_tool_names.setdefault(tool.name, []).append(tool.ref or tool.name)

        collisions = {
            tool_name: refs
            for tool_name, refs in duplicate_tool_names.items()
            if len(refs) > 1
        }
        if collisions:
            messages = [
                f"'{tool_name}' via {', '.join(sorted(refs))}"
                for tool_name, refs in sorted(collisions.items())
            ]
            raise ValueError(
                "Agent exposes duplicate tool names. Tool function names must be unique within an agent: "
                + "; ".join(messages)
            )

        has_discoverable_mcp = any(mcp.discoverable for mcp in config.mcp_servers)

        if discoverable_tools or has_discoverable_mcp:
            existing_names = {t.name for t in tools}
            if "search_tools" not in existing_names:
                tools.append(self._create_predefined_tool_marker("search_tools"))
            if "use_tool" not in existing_names:
                tools.append(self._create_predefined_tool_marker("use_tool"))

        # Sequential agents don't need tools - they orchestrate other agents

        return Agent(config=config, tools=tools, discoverable_tools=discoverable_tools)

    def _resolve_tools(self, tool_ref: str) -> List[Tool]:
        """Resolve a tool reference to one or more Tool instances (file tools, api: spec, wildcards, predefined)."""
        if tool_ref in PREDEFINED_TOOL_NAMES:
            return [self._create_predefined_tool_marker(tool_ref)]

        if tool_ref.startswith("api:"):
            return self._resolve_api_spec_tools(tool_ref[4:])

        if "*" in tool_ref:
            return self._resolve_wildcard(tool_ref)

        parts = tool_ref.split(".")

        if len(parts) < 2:
            raise ValueError(
                f"Invalid tool reference '{tool_ref}'. "
                "Use 'module.function' or 'directory.module.function' format "
                "(e.g., 'calculator.add' or 'billing.calculator.add'), "
                "'api:spec_name.tool_name' for API spec tools, "
                f"or a predefined tool name ({', '.join(PREDEFINED_TOOL_NAMES)})."
            )

        module_name = ".".join(parts[:-1])
        function_name = parts[-1]

        resolved_module_name = self._resolve_tool_module_name(module_name)
        module = self._load_tool_module(resolved_module_name)

        func = getattr(module, function_name, None)
        if func is None:
            raise ValueError(f"Function '{function_name}' not found in module '{resolved_module_name}'")

        if not callable(func):
            raise ValueError(f"'{function_name}' in module '{resolved_module_name}' is not callable")

        if getattr(func, "__module__", None) != f"tools.{resolved_module_name}":
            raise ValueError(
                f"Function '{function_name}' is not defined in module '{resolved_module_name}'"
            )

        is_async = asyncio.iscoroutinefunction(func)
        description = inspect.getdoc(func) or "No description provided."
        schema = self._generate_schema(func)

        return [Tool(
            name=function_name,
            description=description,
            func=func,
            is_async=is_async,
            parameters=schema,
            ref=f"{resolved_module_name}.{function_name}",
        )]

    def _resolve_wildcard(self, tool_ref: str) -> List[Tool]:
        """Match file-based tools under a module prefix against a fnmatch pattern."""
        parts = tool_ref.split(".", 1)
        if len(parts) != 2:
            raise ValueError(
                f"Invalid wildcard pattern '{tool_ref}'. Use 'module.pattern' format (e.g., 'billing.*')"
            )

        module_part, pattern = parts

        matched_tools: List[Tool] = []

        tool_modules = self._discover_tool_modules()
        if module_part in tool_modules:
            try:
                module = self._load_tool_module(module_part)
                for func_name, func in inspect.getmembers(module, inspect.isfunction):
                    if func_name.startswith("_"):
                        continue
                    if getattr(func, "__module__", None) != f"tools.{module_part}":
                        continue
                    if not fnmatch.fnmatch(func_name, pattern):
                        continue

                    is_async = asyncio.iscoroutinefunction(func)
                    description = inspect.getdoc(func) or "No description provided."
                    schema = self._generate_schema(func)

                    matched_tools.append(Tool(
                        name=func_name,
                        description=description,
                        func=func,
                        is_async=is_async,
                        parameters=schema,
                        ref=f"{module_part}.{func_name}",
                    ))
            except Exception as e:
                self._load_errors.append(f"Wildcard '{tool_ref}': failed to load module '{module_part}': {e}")

        if not matched_tools:
            raise ValueError(f"Wildcard '{tool_ref}' matched no tools")

        return matched_tools

    def _resolve_api_spec_tools(self, stripped_ref: str) -> List[Tool]:
        """Resolve an api: prefixed tool reference (exact or wildcard) against the API spec registry."""
        if not self._api_spec_tools:
            self._api_spec_warnings.append(f"api:{stripped_ref}")
            return []

        if "*" in stripped_ref:
            parts = stripped_ref.split(".", 1)
            if len(parts) != 2:
                raise ValueError(
                    f"Invalid API spec wildcard 'api:{stripped_ref}'. "
                    "Use 'api:spec_name.pattern' format (e.g., 'api:my_api.*')"
                )
            spec_name, pattern = parts
            if spec_name not in self._api_spec_tools:
                raise ValueError(f"API spec '{spec_name}' not found in registry")

            matched = []
            for tool_name, tool_def in self._api_spec_tools[spec_name].items():
                if fnmatch.fnmatch(tool_name, pattern):
                    matched.append(self._make_api_spec_tool(spec_name, tool_name, tool_def))
            if not matched:
                raise ValueError(f"Wildcard 'api:{stripped_ref}' matched no tools")
            return matched

        parts = stripped_ref.split(".")
        if len(parts) < 2:
            raise ValueError(
                f"Invalid API spec tool reference 'api:{stripped_ref}'. "
                "Use 'api:spec_name.tool_name' format (e.g., 'api:my_api.users_get')"
            )

        spec_name = ".".join(parts[:-1])
        tool_name = parts[-1]

        if spec_name not in self._api_spec_tools:
            raise ValueError(f"API spec '{spec_name}' not found in registry")

        spec_tools = self._api_spec_tools[spec_name]
        if tool_name not in spec_tools:
            raise ValueError(
                f"Tool '{tool_name}' not found in API spec '{spec_name}'. "
                f"Available: {', '.join(sorted(spec_tools.keys()))}"
            )

        return [self._make_api_spec_tool(spec_name, tool_name, spec_tools[tool_name])]

    def _make_api_spec_tool(self, spec_name: str, tool_name: str, tool_def: Dict[str, Any]) -> Tool:
        return Tool(
            name=tool_name,
            description=tool_def.get("description", f"{tool_def.get('method', 'GET')} {tool_def.get('path', '')}"),
            func=None,
            is_async=True,
            parameters=tool_def.get("parameters", {"type": "object", "properties": {}, "required": []}),
            is_predefined=True,
            ref=f"api:{spec_name}.{tool_name}",
        )
    
    def _validate_condition(self, condition: str, tool_ref: str) -> None:
        """Validate that a condition expression is syntactically valid Python."""
        try:
            ast.parse(condition, mode='eval')
        except SyntaxError as e:
            raise ValueError(
                f"Invalid condition syntax '{condition}' for tool '{tool_ref}': {e}"
            )

    def _create_predefined_tool_marker(self, tool_name: str) -> Tool:
        """
        Create a marker for a predefined tool.
        The actual implementation will be injected by the runner at build time.
        """
        return Tool(
            name=tool_name,
            description="",  # Will be set by runner
            func=None,       # Will be injected by runner
            is_async=True,   # Will be set by runner
            parameters={},   # Will be set by runner
            is_predefined=True,  # Marker for runner to inject implementation
            ref=tool_name,
        )

    def _load_schema(self, schema_name: str) -> Dict[str, Any]:
        """
        Load a JSON Schema file from the schemas/ directory.
        
        Args:
            schema_name: Name of the schema file (without .json extension)
            
        Returns:
            The parsed JSON Schema as a dictionary
            
        Raises:
            FileNotFoundError: If schema file doesn't exist
            json.JSONDecodeError: If schema file is not valid JSON
        """
        # Check cache first
        if schema_name in self._loaded_schemas:
            return self._loaded_schemas[schema_name]
        
        schema_file = self.schemas_dir / f"{schema_name}.json"
        if not schema_file.exists():
            raise FileNotFoundError(f"Schema '{schema_name}' not found at {schema_file}")
        
        with open(schema_file, "r") as f:
            schema_dict = json.load(f)
        
        # Validate it's a valid JSON Schema structure
        if not isinstance(schema_dict, dict):
            raise ValueError(f"Schema '{schema_name}' must be a JSON object")
        
        if "type" not in schema_dict:
            raise ValueError(f"Schema '{schema_name}' must have a 'type' field")
        
        # Cache the loaded schema
        self._loaded_schemas[schema_name] = schema_dict
        return schema_dict

    def discover_schemas(self) -> List[str]:
        """
        Discover all available schemas in the schemas/ directory.
        
        Returns:
            List of schema names (without .json extension)
        """
        if not self.schemas_dir.exists():
            return []
        
        schemas = []
        for schema_file in self.schemas_dir.glob("*.json"):
            if not schema_file.name.startswith("_"):
                schemas.append(schema_file.stem)
        
        return sorted(schemas)

    def _generate_schema(self, func) -> Dict[str, Any]:
        """
        Generate a JSON Schema for a function's parameters.
        
        Uses type hints and docstring to build a schema suitable for LLM function calling.
        """
        sig = inspect.signature(func)
        
        # Try to get type hints (handles forward references)
        try:
            hints = get_type_hints(func)
        except Exception:
            hints = {}
        
        # Parse docstring for parameter descriptions
        param_docs = self._parse_docstring_params(func.__doc__ or "")
        
        properties = {}
        required = []

        for name, param in sig.parameters.items():
            # Skip hidden parameters that are auto-injected at runtime
            if name == 'context':
                continue
            
            # Get type from hints or annotation
            annotation = hints.get(name, param.annotation)
            
            # Convert Python type to JSON Schema type
            prop_schema = self._type_to_schema(annotation)
            
            # Add description from docstring if available
            if name in param_docs:
                prop_schema["description"] = param_docs[name]
            
            properties[name] = prop_schema
            
            # Parameter is required if it has no default value
            if param.default == inspect.Parameter.empty:
                required.append(name)
                
        return {
            "type": "object",
            "properties": properties,
            "required": required
        }
    
    def _type_to_schema(self, annotation) -> Dict[str, Any]:
        """Convert a Python type annotation to JSON Schema."""
        if annotation == inspect.Parameter.empty:
            return {"type": "string"}
        
        # Handle None type
        if annotation is type(None):
            return {"type": "null"}
        
        # Basic type mapping
        type_map = {
            str: {"type": "string"},
            int: {"type": "integer"},
            float: {"type": "number"},
            bool: {"type": "boolean"},
            list: {"type": "array"},
            dict: {"type": "object"},
            type(None): {"type": "null"},
        }
        
        # Check for basic types first
        if annotation in type_map:
            return type_map[annotation].copy()
        
        # Handle generic types (List[X], Dict[K, V], Optional[X], etc.)
        origin = get_origin(annotation)
        args = get_args(annotation)
        
        if origin is Union:
            # Handle Optional[X] which is Union[X, None]
            non_none_args = [a for a in args if a is not type(None)]
            if len(non_none_args) == 1:
                # This is Optional[X]
                return self._type_to_schema(non_none_args[0])
            # General Union - just use first type for simplicity
            if non_none_args:
                return self._type_to_schema(non_none_args[0])
            return {"type": "string"}
        
        if origin is list:
            schema: Dict[str, Any] = {"type": "array"}
            if args:
                schema["items"] = self._type_to_schema(args[0])
            return schema

        if origin is dict:
            schema: Dict[str, Any] = {"type": "object"}
            if len(args) >= 2:
                schema["additionalProperties"] = self._type_to_schema(args[1])
            return schema
        
        # Default to string for unknown types
        return {"type": "string"}
    
    def _parse_docstring_params(self, docstring: str) -> Dict[str, str]:
        """
        Parse parameter descriptions from a docstring.
        
        Supports Google-style docstrings:
            Args:
                param_name: Description of the parameter
        """
        params = {}
        
        if not docstring:
            return params
        
        lines = docstring.split('\n')
        in_args_section = False
        current_param = None
        current_desc = []
        
        for line in lines:
            stripped = line.strip()
            
            # Check for Args: section start
            if stripped.lower() in ('args:', 'arguments:', 'parameters:'):
                in_args_section = True
                continue
            
            # Check for section end (Returns:, Raises:, etc.)
            if stripped.lower().endswith(':') and not stripped.startswith(' '):
                if in_args_section and current_param:
                    params[current_param] = ' '.join(current_desc).strip()
                in_args_section = False
                current_param = None
                current_desc = []
                continue
            
            if in_args_section and stripped:
                # Check if this is a new parameter (contains ':')
                if ':' in stripped and not stripped.startswith(' '):
                    # Save previous parameter
                    if current_param:
                        params[current_param] = ' '.join(current_desc).strip()
                    
                    # Parse new parameter
                    parts = stripped.split(':', 1)
                    # Handle "param_name (type)" format
                    param_part = parts[0].strip()
                    if '(' in param_part:
                        param_part = param_part.split('(')[0].strip()
                    current_param = param_part
                    current_desc = [parts[1].strip()] if len(parts) > 1 else []
                elif current_param:
                    # Continuation of previous parameter description
                    current_desc.append(stripped)
        
        # Don't forget the last parameter
        if current_param:
            params[current_param] = ' '.join(current_desc).strip()
        
        return params

    def _load_tool_module(self, module_name: str):
        """
        Dynamically loads a Python module from the tools/ directory.
        In validation mode, uses AST parsing to extract function metadata.

        Args:
            module_name: Exact dotted module name relative to tools/
            
        Returns:
            The loaded module object
        """
        if module_name in self._loaded_modules:
            return self._loaded_modules[module_name]

        tool_modules = self._discover_tool_modules()
        file_path = tool_modules.get(module_name)
        if file_path is None:
            raise FileNotFoundError(f"Tool module '{module_name}' not found under {self.tools_dir}")

        if self._validation_only:
            return self._load_tool_module_from_ast(module_name, file_path)

        import_name = f"tools.{module_name}"
        spec = importlib.util.spec_from_file_location(import_name, file_path)
        if not spec or not spec.loader:
            raise ImportError(f"Could not load module spec for {file_path}")

        module = importlib.util.module_from_spec(spec)

        # Add to sys.modules so imports inside the module work
        sys.modules[import_name] = module

        spec.loader.exec_module(module)
        self._loaded_modules[module_name] = module
        return module

    def _load_tool_module_from_ast(self, module_name: str, file_path: Path):
        """
        Parse a tool module via AST to extract function metadata without executing code.
        Creates a synthetic module with stub functions that have correct signatures,
        docstrings, and async flags for validation and schema generation.
        """
        source = file_path.read_text()
        tree = ast.parse(source, filename=str(file_path))

        import_name = f"tools.{module_name}"
        module = types.ModuleType(import_name)
        module.__file__ = str(file_path)
        module.__name__ = import_name

        for node in ast.iter_child_nodes(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if node.name.startswith("_"):
                continue

            stub = self._create_ast_stub(node, import_name)
            setattr(module, node.name, stub)

        sys.modules[import_name] = module
        self._loaded_modules[module_name] = module
        return module

    def _create_ast_stub(self, node: ast.AST, module_name: str):
        """Create a stub function from an AST FunctionDef/AsyncFunctionDef node."""
        is_async = isinstance(node, ast.AsyncFunctionDef)

        if is_async:
            async def stub(**kwargs): pass
        else:
            def stub(**kwargs): pass

        stub.__name__ = node.name
        stub.__qualname__ = node.name
        stub.__module__ = module_name
        stub.__doc__ = ast.get_docstring(node)

        # Build inspect.Parameter list from AST args
        parameters = []
        args = node.args
        num_defaults = len(args.defaults)
        num_args = len(args.args)
        first_default_idx = num_args - num_defaults

        for i, arg in enumerate(args.args):
            if arg.arg == "self":
                continue

            annotation = inspect.Parameter.empty
            if arg.annotation:
                annotation = self._resolve_ast_annotation(arg.annotation)

            default = inspect.Parameter.empty
            if i >= first_default_idx:
                default = self._resolve_ast_default(args.defaults[i - first_default_idx])

            parameters.append(inspect.Parameter(
                name=arg.arg,
                kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                default=default,
                annotation=annotation,
            ))

        stub.__signature__ = inspect.Signature(parameters)

        annotations = {}
        for param in parameters:
            if param.annotation != inspect.Parameter.empty:
                annotations[param.name] = param.annotation
        stub.__annotations__ = annotations

        return stub

    _AST_BUILTIN_TYPES = {
        "str": str, "int": int, "float": float, "bool": bool,
        "list": list, "dict": dict, "None": type(None),
    }

    def _resolve_ast_annotation(self, node: ast.AST):
        """Map an AST annotation node to a Python type. Returns Parameter.empty for unresolvable types."""
        if isinstance(node, ast.Name):
            return self._AST_BUILTIN_TYPES.get(node.id, inspect.Parameter.empty)
        if isinstance(node, ast.Constant):
            if node.value is None:
                return type(None)
            if isinstance(node.value, str):
                return self._AST_BUILTIN_TYPES.get(node.value, inspect.Parameter.empty)
        if isinstance(node, ast.Attribute):
            return inspect.Parameter.empty
        if isinstance(node, ast.Subscript):
            # Handle Optional[X], List[X], Dict[K, V]
            if isinstance(node.value, ast.Name):
                base = node.value.id
                if base == "Optional":
                    # Optional[X] -> resolve X
                    return self._resolve_ast_annotation(node.slice)
                if base == "List" or base == "list":
                    return list
                if base == "Dict" or base == "dict":
                    return dict
        return inspect.Parameter.empty

    def _resolve_ast_default(self, node: ast.AST):
        """Extract a literal default value from an AST node."""
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name) and node.id == "None":
            return None
        if isinstance(node, ast.List) and not node.elts:
            return []
        if isinstance(node, ast.Dict) and not node.keys:
            return {}
        # For complex defaults, return None to mark as "has a default"
        return None

    def _discover_tool_files(self) -> List[Path]:
        """Discover tool modules recursively under tools/."""
        if not self.tools_dir.exists():
            return []

        tool_files: List[Path] = []
        seen_paths = set()

        for tool_file in self.tools_dir.rglob("*.py"):
            relative_parts = tool_file.relative_to(self.tools_dir).parts
            if any(part.startswith(".") for part in relative_parts):
                continue
            if tool_file.name.startswith("_"):
                continue

            resolved_path = tool_file.resolve()
            if resolved_path in seen_paths:
                continue

            seen_paths.add(resolved_path)
            tool_files.append(tool_file)

        return sorted(tool_files, key=lambda path: path.relative_to(self.tools_dir).as_posix())

    def _tool_module_name_from_path(self, tool_file: Path) -> str:
        """Convert a tool path to a dotted module name."""
        relative_path = tool_file.relative_to(self.tools_dir)
        return ".".join(relative_path.with_suffix("").parts)

    def _discover_tool_modules(self) -> Dict[str, Path]:
        """Build an index of exact tool module names to paths."""
        return {
            self._tool_module_name_from_path(tool_file): tool_file
            for tool_file in self._discover_tool_files()
        }

    def _resolve_tool_module_name(self, module_name: str) -> str:
        """Resolve a tool module reference to its exact dotted module name."""
        tool_modules = self._discover_tool_modules()
        if module_name in tool_modules:
            return module_name

        raise FileNotFoundError(
            f"Tool module '{module_name}' not found under {self.tools_dir}. "
            "Use the exact dotted path relative to tools/ (for example, 'math.calculator')."
        )

    def discover_tools(self) -> Dict[str, List[str]]:
        """
        Discover all available tools in the project.
        
        Returns:
            Dict mapping dotted module names to lists of function names
        """
        if not self.tools_dir.exists():
            return {}
        
        tools = {}
        for tool_file in self._discover_tool_files():
            module_name = self._tool_module_name_from_path(tool_file)
            try:
                module = self._load_tool_module(module_name)
                functions = []
                for name, obj in inspect.getmembers(module, inspect.isfunction):
                    # Only include public functions defined in this module
                    if not name.startswith("_") and obj.__module__ == f"tools.{module_name}":
                        functions.append(name)
                if functions:
                    tools[module_name] = functions
            except Exception as e:
                self._load_errors.append(f"Tool module '{module_name}': failed to import: {e}")
        
        return tools

    def load_middleware(self, agent_name: str) -> Optional[Middleware]:
        """
        Load middleware for a specific agent by name.
        
        Middleware files are automatically discovered from the middleware/ directory.
        The file must be named after the agent (e.g., middleware/assistant.py for agent 'assistant').
        
        Args:
            agent_name: Name of the agent (matches YAML filename without extension)
            
        Returns:
            Middleware object with before/after functions, or None if no middleware exists
        """
        # Check cache first
        if agent_name in self._loaded_middlewares:
            return self._loaded_middlewares[agent_name]
        
        middleware_file = self.middleware_dir / f"{agent_name}.py"
        if not middleware_file.exists():
            self._loaded_middlewares[agent_name] = None
            return None
        
        try:
            # Load the middleware module
            spec = importlib.util.spec_from_file_location(
                f"middleware.{agent_name}", middleware_file
            )
            if not spec or not spec.loader:
                self._loaded_middlewares[agent_name] = None
                return None
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[f"middleware.{agent_name}"] = module
            spec.loader.exec_module(module)
            
            # Extract before and after functions
            before_func = getattr(module, 'before', None)
            after_func = getattr(module, 'after', None)
            
            # Validate they're callable if present
            if before_func is not None and not callable(before_func):
                before_func = None
            if after_func is not None and not callable(after_func):
                after_func = None
            
            # If neither exists, return None
            if before_func is None and after_func is None:
                self._loaded_middlewares[agent_name] = None
                return None
            
            middleware = Middleware(before=before_func, after=after_func)
            self._loaded_middlewares[agent_name] = middleware
            return middleware
            
        except Exception as e:
            print(f"Warning: Failed to load middleware for {agent_name}: {e}")
            self._loaded_middlewares[agent_name] = None
            return None

    def discover_middlewares(self) -> Dict[str, List[str]]:
        """
        Discover all middleware files and their available hooks.
        
        Returns:
            Dict mapping agent names to lists of available hooks ('before', 'after')
        """
        if not self.middleware_dir.exists():
            return {}
        
        middlewares = {}
        for mw_file in self.middleware_dir.glob("*.py"):
            if mw_file.name.startswith("_"):
                continue
            
            agent_name = mw_file.stem
            try:
                mw = self.load_middleware(agent_name)
                if mw:
                    hooks = []
                    if mw.before is not None:
                        hooks.append("before")
                    if mw.after is not None:
                        hooks.append("after")
                    if hooks:
                        middlewares[agent_name] = hooks
            except Exception as e:
                print(f"Warning: Could not discover middleware for {agent_name}: {e}")
        
        return middlewares

    def load_tool_hooks(self, agent_name: str) -> Optional[ToolHook]:
        """
        Load tool hooks for a specific agent by name.

        Hook files are automatically discovered from the hooks/ directory.
        The file must be named after the agent (e.g., hooks/assistant.py for agent 'assistant').

        Args:
            agent_name: Name of the agent (matches YAML filename without extension)

        Returns:
            ToolHook object with before/after functions, or None if no hooks exist
        """
        if agent_name in self._loaded_tool_hooks:
            return self._loaded_tool_hooks[agent_name]

        hook_file = self.hooks_dir / f"{agent_name}.py"
        if not hook_file.exists():
            self._loaded_tool_hooks[agent_name] = None
            return None

        try:
            spec = importlib.util.spec_from_file_location(
                f"hooks.{agent_name}", hook_file
            )
            if not spec or not spec.loader:
                self._loaded_tool_hooks[agent_name] = None
                return None

            module = importlib.util.module_from_spec(spec)
            sys.modules[f"hooks.{agent_name}"] = module
            spec.loader.exec_module(module)

            before_func = getattr(module, 'before', None)
            after_func = getattr(module, 'after', None)

            if before_func is not None and not callable(before_func):
                before_func = None
            if after_func is not None and not callable(after_func):
                after_func = None

            if before_func is None and after_func is None:
                self._loaded_tool_hooks[agent_name] = None
                return None

            hook = ToolHook(before=before_func, after=after_func)
            self._loaded_tool_hooks[agent_name] = hook
            return hook

        except Exception as e:
            print(f"Warning: Failed to load tool hooks for {agent_name}: {e}")
            self._loaded_tool_hooks[agent_name] = None
            return None

    def discover_tool_hooks(self) -> Dict[str, List[str]]:
        """
        Discover all hook files and their available hooks.

        Returns:
            Dict mapping agent names to lists of available hooks ('before', 'after')
        """
        if not self.hooks_dir.exists():
            return {}

        hooks = {}
        for hook_file in self.hooks_dir.glob("*.py"):
            if hook_file.name.startswith("_"):
                continue

            agent_name = hook_file.stem
            try:
                hook = self.load_tool_hooks(agent_name)
                if hook:
                    available = []
                    if hook.before is not None:
                        available.append("before")
                    if hook.after is not None:
                        available.append("after")
                    if available:
                        hooks[agent_name] = available
            except Exception as e:
                print(f"Warning: Could not discover hooks for {agent_name}: {e}")

        return hooks

    def load_guardrail(self, name: str) -> Optional[CustomGuardrail]:
        """
        Load a custom guardrail by name.
        
        Custom guardrail files live in the guardrails/ directory and must
        export a ``check(content: str, context: dict) -> GuardrailResult``
        function.
        
        Args:
            name: Name of the guardrail (matches filename without .py)
            
        Returns:
            CustomGuardrail object, or None if no guardrail file exists
        """
        if name in self._loaded_guardrails:
            return self._loaded_guardrails[name]
        
        guardrail_file = self.guardrails_dir / f"{name}.py"
        if not guardrail_file.exists():
            self._loaded_guardrails[name] = None
            return None
        
        try:
            spec = importlib.util.spec_from_file_location(
                f"guardrails.{name}", guardrail_file
            )
            if not spec or not spec.loader:
                self._loaded_guardrails[name] = None
                return None
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[f"guardrails.{name}"] = module
            spec.loader.exec_module(module)
            
            check_func = getattr(module, 'check', None)
            
            if check_func is None or not callable(check_func):
                self._load_errors.append(
                    f"Custom guardrail '{name}': missing or non-callable 'check' function"
                )
                self._loaded_guardrails[name] = None
                return None
            
            is_async = asyncio.iscoroutinefunction(check_func)
            guardrail = CustomGuardrail(name=name, check=check_func, is_async=is_async)
            self._loaded_guardrails[name] = guardrail
            return guardrail
            
        except Exception as e:
            print(f"Warning: Failed to load guardrail '{name}': {e}")
            self._loaded_guardrails[name] = None
            return None

    def discover_guardrails(self) -> List[str]:
        """
        Discover all custom guardrail files in the guardrails/ directory.
        
        Returns:
            List of guardrail names (filenames without .py extension)
        """
        if not self.guardrails_dir.exists():
            return []
        
        guardrails = []
        for gf in self.guardrails_dir.glob("*.py"):
            if not gf.name.startswith("_"):
                guardrails.append(gf.stem)
        
        return sorted(guardrails)
