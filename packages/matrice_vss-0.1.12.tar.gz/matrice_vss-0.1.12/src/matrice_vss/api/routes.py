"""
VSS API Routes
FastAPI endpoint definitions for Mode 1 queries.

IMPORTANT: This file matches the EXISTING codebase signatures.
- get_llm() is SYNC (not async)
- get_vlm() is SYNC (not async)
- ClickHouse uses test_connection() method
"""

import logging

from datetime import datetime, timezone
from typing import Optional, Dict

from fastapi import APIRouter, HTTPException

from .schemas import (
    QueryRequest,
    QueryWithMediaRequest,
    QueryResponseWithTrace,
    HealthResponse,
    HealthComponent,
)
from ..orchestration.graph import VSSOrchestrator
from ..storage.clickhouse_client import get_clickhouse
from ..inference.llm_client import get_llm  # SYNC function
from ..inference.vlm_client import get_vlm  # SYNC function
from ..config.settings import get_settings

logger = logging.getLogger(__name__)

router = APIRouter()

# Global orchestrator instance
_orchestrator: Optional[VSSOrchestrator] = None


def get_orchestrator() -> VSSOrchestrator:
    """Get or create orchestrator singleton."""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = VSSOrchestrator()
    return _orchestrator


# === Query Endpoints ===


@router.post("/query", response_model=QueryResponseWithTrace)
async def query(request: QueryRequest) -> QueryResponseWithTrace:
    """
    Process a natural language query (text only).
    Routes to SQL or VLM based on intent classification.
    """
    logger.info("Query received: %s", request.query[:100])

    try:
        orchestrator = get_orchestrator()
        state = await orchestrator.run(query=request.query)

        # Only include trace entries in the HTTP response when explicitly requested.
        # The full trace is always persisted to logs/vss_trace.log regardless.
        trace_out = state.get("trace", []) if request.include_trace else []

        return QueryResponseWithTrace(
            request_id=state.get("request_id", "unknown"),
            status="success" if state.get("status") == "completed" else "error",
            response=state.get("final_response", "No response generated"),
            processing_time_ms=state.get("processing_time_ms"),
            trace=trace_out,
            metadata={
                "intent": state.get("intent"),
                "intent_confidence": state.get("intent_confidence"),
                "response_source": state.get("response_source"),
                "escalated": state.get("escalated", False),
                "escalation_reason": state.get("escalation_reason"),
                "sql_query": state.get("sql_query"),
                "routing_reason": state.get("routing_reason"),
            },
        )

    except Exception as exc:
        logger.error("Query failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred while processing your query. Please try again.",
        ) from exc


@router.post("/query/media", response_model=QueryResponseWithTrace)
async def query_with_media(request: QueryWithMediaRequest) -> QueryResponseWithTrace:
    """
    Process a query with image/media upload.
    Always routes to VLM for visual analysis.
    Requires VSS_VLM_ENABLED=true; returns 503 when VLM is disabled.
    """
    settings = get_settings()
    if not settings.vlm_enabled:
        raise HTTPException(
            status_code=503,
            detail="VLM is not enabled. Set VSS_VLM_ENABLED=true to enable media queries.",
        )

    logger.info("Media query received: %s", request.query[:100])

    try:
        # Build media dict - use the schema field names from existing code
        media_dict = {
            "type": "image",
            "data": request.media_base64,  # Existing schema uses media_base64
        }

        orchestrator = get_orchestrator()
        state = await orchestrator.run(query=request.query, media=media_dict)

        return QueryResponseWithTrace(
            request_id=state.get("request_id", "unknown"),
            status="success" if state.get("status") == "completed" else "error",
            response=state.get("final_response", "No response generated"),
            processing_time_ms=state.get("processing_time_ms"),
            trace=state.get("trace", []),
            metadata={
                "intent": state.get("intent"),
                "intent_confidence": state.get("intent_confidence"),
                "response_source": state.get("response_source"),
                "escalated": state.get("escalated", False),
                "media_type": "image",
            },
        )

    except Exception as e:
        logger.error("Media query failed: %s", e, exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="An internal error occurred while processing your media query. Please try again.",
        ) from e


# === Health Endpoint ===


def _component_from_bool(ok: bool, error_message: str) -> HealthComponent:
    """Convert a boolean probe result into a HealthComponent."""
    if ok:
        return HealthComponent(status="ok")
    return HealthComponent(status="error", message=error_message)


def _component_from_error(exc: Exception) -> HealthComponent:
    """Build a failing HealthComponent from an exception."""
    return HealthComponent(status="error", message=str(exc))


async def _probe_clickhouse() -> HealthComponent:
    try:
        ch = get_clickhouse()
        return _component_from_bool(ch.test_connection(), "Connection failed")
    except Exception as e:
        return _component_from_error(e)


async def _probe_llm() -> HealthComponent:
    try:
        llm = get_llm()
        ok = await llm.health_check()
        return _component_from_bool(ok, "Service unavailable")
    except Exception as e:
        return _component_from_error(e)


async def _probe_vlm() -> HealthComponent:
    settings = get_settings()
    if not settings.vlm_enabled:
        return HealthComponent(
            status="disabled",
            message="VLM not enabled (VSS_VLM_ENABLED=false)",
        )
    try:
        vlm = get_vlm()
        ok = await vlm.health_check()
        return _component_from_bool(ok, "Service unavailable")
    except Exception as e:
        return _component_from_error(e)


def _overall_status(components: Dict[str, HealthComponent]) -> str:
    error_count = sum(1 for c in components.values() if c.status == "error")
    if error_count == 0:
        return "healthy"
    if error_count < len(components):
        return "degraded"
    return "unhealthy"


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """
    Check service health and component status.
    """
    components: Dict[str, HealthComponent] = {
        "clickhouse": await _probe_clickhouse(),
        "llm": await _probe_llm(),
        "vlm": await _probe_vlm(),
    }

    return HealthResponse(
        status=_overall_status(components),
        timestamp=datetime.now(timezone.utc),
        components=components,
    )
