"""
matrice_vss - Video Search & Summarization service for Matrice.ai
"""

from pathlib import Path

__version__ = "0.1.0"

# Package directory
PACKAGE_DIR = Path(__file__).parent

# Path to bundled requirements.txt
REQUIREMENTS_PATH = PACKAGE_DIR / "requirements.txt"


def get_requirements_path() -> Path:
    """Return path to bundled requirements.txt file."""
    if not REQUIREMENTS_PATH.exists():
        raise FileNotFoundError(f"requirements.txt not found at {REQUIREMENTS_PATH}")
    return REQUIREMENTS_PATH
