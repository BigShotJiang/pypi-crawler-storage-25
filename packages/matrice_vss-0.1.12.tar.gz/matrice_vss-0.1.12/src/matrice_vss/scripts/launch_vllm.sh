#!/bin/bash
# VSS - vLLM Server for Cosmos-Reason2-8B
# GPU: 6

set -e

MODEL="${VLM_MODEL:-nvidia/Cosmos-Reason2-8B}"
PORT="${VLM_PORT:-8000}"
GPU="${VLM_GPU:-6}"
GPU_MEM="${VLM_GPU_MEM:-0.85}"

echo "=========================================="
echo "VSS - Cosmos-Reason2-8B VLM Server"
echo "=========================================="
echo "Model:    $MODEL"
echo "Port:     $PORT"
echo "GPU:      $GPU"
echo "Memory:   $GPU_MEM"
echo ""

export CUDA_VISIBLE_DEVICES=$GPU

echo "Checking GPU..."
nvidia-smi --id=$GPU --query-gpu=name,memory.total,memory.free --format=csv
echo ""

echo "Starting vLLM server..."
python -m vllm.entrypoints.openai.api_server \
    --model "$MODEL" \
    --port $PORT \
    --host 0.0.0.0 \
    --gpu-memory-utilization $GPU_MEM \
    --max-model-len 8192 \
    --trust-remote-code \
    --dtype auto \
    2>&1 | tee vllm_cosmos.log