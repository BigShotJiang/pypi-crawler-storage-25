#!/bin/bash
# VSS - Ollama Setup for Llama 3.1 8B
# GPU: 7

set -e

MODEL="${LLM_MODEL:-llama3.1:8b}"
PORT="${OLLAMA_PORT:-11434}"
GPU="${LLM_GPU:-7}"

echo "=========================================="
echo "VSS - Ollama LLM Setup (Llama 3.1 8B)"
echo "=========================================="
echo "Model:  $MODEL"
echo "Port:   $PORT"
echo "GPU:    $GPU"
echo ""

export CUDA_VISIBLE_DEVICES=$GPU

# Check if Ollama installed
if ! command -v ollama &> /dev/null; then
    echo "Installing Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
fi

# Start Ollama serve if not running
if ! pgrep -x "ollama" > /dev/null; then
    echo "Starting Ollama server..."
    OLLAMA_HOST="0.0.0.0:$PORT" ollama serve &
    sleep 5
fi

# Pull model if needed
if ! ollama list | grep -q "$MODEL"; then
    echo "Pulling $MODEL..."
    ollama pull "$MODEL"
fi

echo ""
echo "Ollama ready at http://localhost:$PORT"
echo "Model: $MODEL"
ollama list