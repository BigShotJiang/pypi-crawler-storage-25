"""
Build configuration for matrice_vss.

Pure Python package build (no mypyc compilation).
Version is controlled via PACKAGE_VERSION environment variable.
"""
import os
from pathlib import Path

from setuptools import setup, find_packages

# Package configuration
PACKAGE_NAME = "matrice_vss"
SOURCE_DIR = f"src/{PACKAGE_NAME}"


def get_version() -> str:
    """Get version from PACKAGE_VERSION environment variable."""
    version = os.environ.get("PACKAGE_VERSION", "0.0.0.dev0")
    print(f"Building version: {version}")
    return version


def ensure_py_typed():
    """Create py.typed marker file for PEP 561 compliance."""
    py_typed = Path(SOURCE_DIR) / "py.typed"
    py_typed.parent.mkdir(parents=True, exist_ok=True)
    if not py_typed.exists():
        py_typed.write_text("")
        print("Created py.typed file")


# Build preparation
ensure_py_typed()

# Setup
setup(
    name=PACKAGE_NAME,
    version=get_version(),
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    package_data={
        PACKAGE_NAME: [
            "py.typed",
            "*.pyi",
            "**/*.pyi",
            "requirements.txt",
            "config/*.yaml",
        ],
    },
    zip_safe=False,
    python_requires=">=3.11",
)