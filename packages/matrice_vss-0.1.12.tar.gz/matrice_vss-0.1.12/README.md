# Py Vss

Platform tooling and documentation

## Overview

This repository is part of the **matrice-ai** platform (Other category).

## Getting Started

Refer to the [matrice-hub](https://github.com/matrice-ai/matrice-hub) for architecture and contribution guidelines.

## Contributing

- Default branch: `prod`
- Development branch: `dev`
- All PRs require 2 approvals for `prod`, 1 for `dev`
- See [CODEOWNERS](.github/CODEOWNERS) for reviewer assignments

## License

Apache License 2.0
