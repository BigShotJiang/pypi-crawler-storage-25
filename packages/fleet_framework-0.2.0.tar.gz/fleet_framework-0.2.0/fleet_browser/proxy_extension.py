from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, NamedTuple
from urllib.parse import urlparse


class ProxySpec(NamedTuple):
    scheme: str  # "http" | "https" | "socks5"
    host: str
    port: int
    username: str | None
    password: str | None

    @property
    def has_auth(self) -> bool:
        return bool(self.username and self.password)

    @property
    def chromium_proxy_server(self) -> str:
        return f"{self.scheme}://{self.host}:{self.port}"


def parse_proxy_url(url: str) -> ProxySpec:
    if "://" not in url:
        url = "http://" + url
    p = urlparse(url)
    if not p.hostname or not p.port:
        raise ValueError(f"proxy URL missing host or port: {url!r}")
    scheme = (p.scheme or "http").lower()
    if scheme not in ("http", "https", "socks5", "socks5h"):
        raise ValueError(f"unsupported proxy scheme: {scheme!r}")
    return ProxySpec(
        scheme=scheme,
        host=p.hostname,
        port=p.port,
        username=p.username,
        password=p.password,
    )


@dataclass
class ProxyAuthExtension:
    directory: Path
    proxy: ProxySpec


_MANIFEST_TEMPLATE = {
    "name": "Turnstile Farm Proxy Auth",
    "version": "1.0.0",
    "manifest_version": 2,
    "permissions": [
        "proxy",
        "tabs",
        "unlimitedStorage",
        "storage",
        "<all_urls>",
        "webRequest",
        "webRequestBlocking",
    ],
    "background": {"scripts": ["background.js"]},
    "minimum_chrome_version": "76.0.0",
}


_DEFAULT_BYPASS = ("localhost", "127.0.0.1", "<local>")


def _background_js(proxy: ProxySpec, bypass_hosts: tuple[str, ...]) -> str:
    config = {
        "scheme": proxy.scheme,
        "host": proxy.host,
        "port": proxy.port,
    }
    creds = {"username": proxy.username or "", "password": proxy.password or ""}
    return (
        "var config = {\n"
        '  mode: "fixed_servers",\n'
        '  rules: {\n'
        f'    singleProxy: {json.dumps(config)},\n'
        f'    bypassList: {json.dumps(list(bypass_hosts))}\n'
        '  }\n'
        '};\n'
        'chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});\n'
        '\n'
        'chrome.webRequest.onAuthRequired.addListener(\n'
        f'  function(details) {{ return {{ authCredentials: {json.dumps(creds)} }}; }},\n'
        '  { urls: ["<all_urls>"] },\n'
        '  ["blocking"]\n'
        ');\n'
    )


def build_proxy_auth_extension(
    proxy: ProxySpec,
    *,
    base_dir: Path | None = None,
    bypass_hosts: Iterable[str] = (),
) -> ProxyAuthExtension:
    if not proxy.has_auth:
        raise ValueError("build_proxy_auth_extension called without credentials")

    bypass = tuple(_DEFAULT_BYPASS) + tuple(
        h for h in bypass_hosts if h not in _DEFAULT_BYPASS
    )

    base = base_dir if base_dir is not None else Path(tempfile.gettempdir())
    creds_id = hashlib.sha256(
        f"{proxy.username}:{proxy.password}@{proxy.host}:{proxy.port}|"
        f"bypass={','.join(bypass)}".encode()
    ).hexdigest()[:24]
    ext_dir = base / f"turnstile-farm-proxy-auth-{creds_id}"
    ext_dir.mkdir(parents=True, exist_ok=True)

    (ext_dir / "manifest.json").write_text(json.dumps(_MANIFEST_TEMPLATE, indent=2))
    (ext_dir / "background.js").write_text(_background_js(proxy, bypass))

    return ProxyAuthExtension(directory=ext_dir, proxy=proxy)
