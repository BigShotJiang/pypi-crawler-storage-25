from __future__ import annotations

import logging
import math
import random
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from DrissionPage import ChromiumPage

logger = logging.getLogger(__name__)


def _bezier_path(
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    steps: int,
    rng: random.Random,
) -> list[tuple[float, float]]:
    sx, sy = start
    ex, ey = end
    mx = (sx + ex) / 2
    my = (sy + ey) / 2
    span = max(50.0, math.hypot(ex - sx, ey - sy))
    jitter = span / 3
    cp1 = (mx + rng.uniform(-jitter, jitter), my + rng.uniform(-jitter, jitter))
    cp2 = (mx + rng.uniform(-jitter, jitter), my + rng.uniform(-jitter, jitter))

    pts = []
    for i in range(steps + 1):
        t = i / steps
        # Ease-in-out via cubic (slower start/end, faster middle).
        t = 3 * t * t - 2 * t * t * t
        b = (
            (1 - t) ** 3 * sx
            + 3 * (1 - t) ** 2 * t * cp1[0]
            + 3 * (1 - t) * t ** 2 * cp2[0]
            + t ** 3 * ex,
            (1 - t) ** 3 * sy
            + 3 * (1 - t) ** 2 * t * cp1[1]
            + 3 * (1 - t) * t ** 2 * cp2[1]
            + t ** 3 * ey,
        )
        pts.append(b)
    return pts


def _viewport_size(page: "ChromiumPage") -> tuple[int, int]:
    try:
        result = page.run_js("return [window.innerWidth, window.innerHeight]")
        if result and len(result) == 2:
            w, h = int(result[0]), int(result[1])
            if w > 100 and h > 100:
                return w, h
    except Exception:
        pass
    return 1280, 800


def _mouse_move(page: "ChromiumPage", x: float, y: float) -> None:
    page.run_cdp(
        "Input.dispatchMouseEvent",
        type="mouseMoved",
        x=x, y=y,
        button="none", buttons=0,
    )


def _mouse_wheel(page: "ChromiumPage", x: float, y: float, dy: float) -> None:
    page.run_cdp(
        "Input.dispatchMouseEvent",
        type="mouseWheel",
        x=x, y=y,
        deltaX=0, deltaY=dy,
    )


class Humanizer:

    def __init__(
        self,
        page: "ChromiumPage",
        *,
        seed: int | None = None,
        idle_min_s: float = 1.0,
        idle_max_s: float = 4.0,
    ) -> None:
        self._page = page
        self._rng = random.Random(seed)
        self._idle_min = idle_min_s
        self._idle_max = idle_max_s
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._move_count = 0
        self._scroll_count = 0

    @property
    def move_count(self) -> int:
        return self._move_count

    @property
    def scroll_count(self) -> int:
        return self._scroll_count

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run, name="Humanizer", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None

    def _run(self) -> None:
        rng = self._rng
        try:
            w, h = _viewport_size(self._page)
        except Exception:
            w, h = 1280, 800

        # Start somewhere plausible — mid-screen-ish.
        cur_x = w / 2 + rng.uniform(-100, 100)
        cur_y = h / 2 + rng.uniform(-100, 100)

        while not self._stop.is_set():
            try:
                tgt_x = rng.uniform(40, w - 40)
                tgt_y = rng.uniform(40, h - 40)
                steps = rng.randint(8, 25)
                path = _bezier_path((cur_x, cur_y), (tgt_x, tgt_y), steps=steps, rng=rng)
                for x, y in path:
                    if self._stop.is_set():
                        return
                    _mouse_move(self._page, x, y)
                    self._move_count += 1
                    self._stop.wait(rng.uniform(0.012, 0.035))

                cur_x, cur_y = tgt_x, tgt_y

                # Occasional small scroll
                if rng.random() < 0.10:
                    dy = rng.choice((-180, -120, -80, 80, 120, 180))
                    _mouse_wheel(self._page, cur_x, cur_y, dy)
                    self._scroll_count += 1

                # Idle pause
                self._stop.wait(rng.uniform(self._idle_min, self._idle_max))
            except Exception as e:
                logger.debug("humanizer iteration failed: %s", e)
                self._stop.wait(0.5)
