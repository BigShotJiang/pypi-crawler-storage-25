from __future__ import annotations

import logging
from typing import Any, Optional, Protocol, runtime_checkable

from fleet_browser.fingerprint import Fingerprint

logger = logging.getLogger(__name__)


@runtime_checkable
class Stealth(Protocol):
    """Pluggable browser hardening — anything that prepares a Chromium page
    against fingerprinting / anti-bot detection.

    Two hooks: `launch_user_agent()` returns the UA string to wire into
    Chromium *before* it launches (so pre-CDP requests look right); and
    `apply_post_launch(page)` runs once the page exists, typically using
    CDP (Network.setUserAgentOverride / setExtraHTTPHeaders /
    Page.addScriptToEvaluateOnNewDocument) to install overrides.

    Implementations must be safe to call once per browser launch.
    """

    name: str

    def launch_user_agent(self) -> Optional[str]: ...
    def apply_post_launch(self, page: Any) -> None: ...


class NoOpStealth:
    """No-op stealth. Useful for tests and for environments where a stock
    Chromium fingerprint is acceptable."""

    name = "noop"

    def launch_user_agent(self) -> Optional[str]:
        return None

    def apply_post_launch(self, page: Any) -> None:  # noqa: ARG002
        return None


class FingerprintStealth:
    """Default stealth: applies a uaforge-derived Windows-Chrome
    fingerprint via CDP (UA + UA-CH metadata + Accept-Language +
    navigator.* overrides)."""

    name = "fingerprint"

    def __init__(self, fingerprint: Fingerprint) -> None:
        self._fp = fingerprint

    @property
    def fingerprint(self) -> Fingerprint:
        return self._fp

    def launch_user_agent(self) -> Optional[str]:
        return self._fp.user_agent

    def apply_post_launch(self, page: Any) -> None:
        fp = self._fp
        page.run_cdp(
            "Network.setUserAgentOverride",
            userAgent=fp.user_agent,
            userAgentMetadata=fp.to_cdp_user_agent_metadata(),
            acceptLanguage=",".join(
                f"{lang};q=0.{9 - i}" if i else lang
                for i, lang in enumerate(fp.languages)
            ),
            platform=fp.platform,
        )
        page.run_cdp(
            "Network.setExtraHTTPHeaders",
            headers=fp.to_extra_http_headers(),
        )
        page.run_cdp(
            "Page.addScriptToEvaluateOnNewDocument",
            source=fp.navigator_overrides_js(),
        )
