from __future__ import annotations

import asyncio
import logging
import os
import shutil
import socket
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import psutil
from DrissionPage import ChromiumOptions, ChromiumPage

from fleet_browser.cloak import (
    CLOAK_IGNORE_DEFAULT_ARGS,
    cloak_stealth_args,
    ensure_cloak_binary,
    resolve_engine,
)
from fleet_browser.proxy_extension import build_proxy_auth_extension, parse_proxy_url
from fleet_browser.smart_router import DEFAULT_RULES, SmartRouter, SmartRule
from fleet_browser.stealth import Stealth

logger = logging.getLogger(__name__)


def _kill_processes_for_userdir(user_data_dir: Optional[Path]) -> int:
    if not user_data_dir:
        return 0
    needle = str(user_data_dir)
    killed = 0
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            cmdline = proc.info.get("cmdline") or []
            if any(needle in arg for arg in cmdline):
                proc.kill()
                killed += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return killed

# Precedence for `prefer=`: Thorium (fastest fork), then Brave (CF fallback).
_DEFAULT_BROWSER_PATHS = [
    "/usr/bin/thorium-browser",
    "/opt/chromium.org/thorium/thorium-browser",
    "/usr/bin/brave-browser",
    "/usr/bin/brave-browser-stable",
    "/usr/bin/brave-browser-nightly",
    "/opt/brave.com/brave/brave",
    "/opt/brave.com/brave-nightly/brave",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
]


def _find_browser_binary(prefer: Optional[str] = None) -> str:
    if prefer:
        for p in _DEFAULT_BROWSER_PATHS:
            if prefer.lower() in p.lower() and Path(p).is_file() and os.access(p, os.X_OK):
                return p
    for p in _DEFAULT_BROWSER_PATHS:
        if Path(p).is_file() and os.access(p, os.X_OK):
            return p
    raise RuntimeError(
        "No Chromium-fork browser binary found. Install thorium-browser "
        "or chromium, or set browser_binary explicitly."
    )


def _pick_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@dataclass
class BrowserConfig:
    page_url: str
    """URL the worker will navigate to. Use the public hostname (e.g.
    https://bot.hackmap.win:8765/) when host_resolver_rules is set, so
    window.location.hostname matches the Turnstile sitekey's domain."""

    proxy: Optional[str] = None
    """Proxy URL: http://host:port or http://user:pass@host:port. Optional."""

    proxy_bypass: tuple[str, ...] = ()
    """Hostnames that should NOT go through the proxy. Always include any
    custom host_resolver_rules destination so local TokenServer traffic
    skips the proxy. localhost / 127.0.0.1 are always bypassed."""

    user_agent: Optional[str] = None
    """Override just the UA string. Prefer `fingerprint=` for full Windows
    Chrome impersonation (UA + client hints + navigator overrides)."""

    stealth: Optional[Stealth] = None
    """Pluggable browser hardening. Default is `FingerprintStealth`, which
    applies a uaforge-derived Windows-Chrome fingerprint via CDP. Set to
    `NoOpStealth()` to ship a stock Chromium. Takes precedence over
    `user_agent` for the launch UA when `launch_user_agent()` is non-None."""

    browser_binary: Optional[str] = None
    """Path to the browser binary (Thorium, Chromium, Chrome).
    None = auto-detect, preferring Thorium."""

    prefer_browser: Optional[str] = None
    """When auto-detecting, prefer a binary whose path contains this
    substring (e.g. "thorium", "chromium"). Ignored if browser_binary
    is set explicitly."""

    headless: bool = False
    """Run headless. Turnstile sometimes scores headless lower; default visible."""

    window_size: tuple[int, int] = (1280, 800)

    host_resolver_rules: Optional[str] = None
    """Chromium --host-resolver-rules value, e.g.
    'MAP bot.hackmap.win:8765 127.0.0.1:8765'.
    Used to make page_url's hostname resolve to the local TokenServer."""

    ignore_cert_errors: bool = False
    """Pass --ignore-certificate-errors. Required when serving HTTPS with
    a self-signed cert via TokenServer."""

    extra_args: tuple[str, ...] = ()

    engine: str = "auto"
    """Which Chromium build to launch. `"auto"` picks `"cloak"` when the
    cloakbrowser package is installed, else falls back to `"chrome"`.
    Set explicitly to override:
      - `"chrome"`: use the system Chromium / Brave / Thorium auto-detect path
      - `"cloak"`: use the CloakBrowser patched binary (downloads on first
        use, raises if `cloakbrowser` isn't installed)
    Cloak applies source-level canvas/WebGL/audio/font/WebRTC patches that
    JS-level stealth can't reach. Stack FingerprintStealth on top to add
    per-launch UA/version diversity from the uaforge corpus."""

    cloak_cache_dir: Optional[str] = None
    """Override the cloak binary cache dir (default ~/.cloakbrowser/)."""

    cloak_fingerprint_seed: Optional[int] = None
    """Force a specific cloak --fingerprint=N seed. Default: random per
    launch. Pin a seed for reproducible tests."""

    cloak_platform: str = "windows"
    """`--fingerprint-platform` flag for cloak's binary. Must match the
    OS family FingerprintStealth's UA claims (uaforge default is Windows).
    Set 'macos' if you switch uaforge to a Mac corpus."""

    cloak_timezone: Optional[str] = None
    """IANA timezone for cloak's `--fingerprint-timezone` flag. Set when
    using residential proxies so the spoofed timezone matches the egress
    geo (otherwise CF flags the mismatch). Falls back to system tz."""

    cloak_webrtc_ip: Optional[str] = None
    """Public IP cloak should advertise via WebRTC. Set to the proxy's exit
    IP when using residential — otherwise WebRTC leaks your real LAN IP
    and CF correlates the mismatch."""

    smart_routing: bool = True
    """When True AND `proxy` is set, spawn a local mitmproxy that does per-flow
    routing: only the rules-matching flows (e.g. /search) go through the paid
    upstream, everything else goes direct. Cuts residential bandwidth ~85–95%
    on Google/Bing/etc. without changing the SERP fetch's IP. Disable only when
    you specifically need every byte through the proxy (rare)."""

    smart_routing_rules: tuple[SmartRule, ...] = DEFAULT_RULES
    """Per-flow routing rules. Built-ins handle Google/Bing/Yahoo/DDG /search
    plus a block-list of trackers. Plugins can extend with additional rules
    via tuple concat: `DEFAULT_RULES + (SmartRule(host="amazon.com", path="/s"),)`."""


class ChromiumWorker:

    def __init__(self, config: BrowserConfig) -> None:
        self.config = config
        self.page: Optional[ChromiumPage] = None
        self._smart_router: Optional[SmartRouter] = None

    @property
    def smart_router(self) -> Optional[SmartRouter]:
        """The active SmartRouter for this worker, or None if smart routing
        wasn't engaged. Stats are populated after `stop()` runs."""
        return self._smart_router
        self._user_data_dir: Optional[Path] = None
        self._owns_user_data_dir = False

    def start(self) -> ChromiumPage:
        if self.page is not None:
            return self.page

        engine = resolve_engine(self.config.engine)
        if engine == "cloak":
            # Caller may still pin browser_binary explicitly — honor it.
            binary = self.config.browser_binary or ensure_cloak_binary(
                self.config.cloak_cache_dir
            )
        else:
            binary = self.config.browser_binary or _find_browser_binary(
                prefer=self.config.prefer_browser,
            )

        self._user_data_dir = Path(tempfile.mkdtemp(prefix="chromium-worker-"))
        self._owns_user_data_dir = True

        opts = ChromiumOptions()
        # auto_port would forcibly overwrite user_data_path; pick our own.
        opts.set_local_port(_pick_free_port())
        opts.set_browser_path(binary)
        opts.set_user_data_path(str(self._user_data_dir))
        opts.set_argument(f"--window-size={self.config.window_size[0]},{self.config.window_size[1]}")

        if engine == "cloak":
            for arg in cloak_stealth_args(
                platform=self.config.cloak_platform,
                timezone=self.config.cloak_timezone,
                webrtc_ip=self.config.cloak_webrtc_ip,
                seed=self.config.cloak_fingerprint_seed,
            ):
                opts.set_argument(arg)
            # Suppress Chromium defaults that leak automation signals.
            # DrissionPage doesn't expose ignore_default_args; pass as
            # --disable-features-replacement via plain args. The cloak
            # binary recognises --no-enable-automation as an inversion.
            for kill in CLOAK_IGNORE_DEFAULT_ARGS:
                # Chromium accepts --disable-foo as the inverse of --enable-foo.
                inv = kill.replace("--enable-", "--disable-", 1)
                opts.set_argument(inv)

        # HttpsUpgrades is off so self-signed HTTPS (TokenServer) isn't rewritten.
        # Brave's ad/tracker/sync features both pollute the fingerprint and
        # sometimes break Turnstile's iframe; disable them when running Brave.
        if "brave" in binary.lower():
            opts.set_argument(
                "--disable-features="
                "BraveAdBlock,BraveTrackerBlocking,BraveSyncV2,HttpsUpgrades"
            )
        else:
            opts.set_argument("--disable-features=HttpsUpgrades")

        opts.set_argument("--disable-blink-features=AutomationControlled")
        opts.set_argument("--no-first-run")
        opts.set_argument("--no-default-browser-check")
        opts.set_argument("--disable-default-apps")
        opts.set_argument("--disable-dev-shm-usage")
        opts.set_argument("--disable-popup-blocking")
        opts.set_argument("--disable-infobars")
        opts.set_argument("--mute-audio")
        # In plain Docker / as root, sandbox setup fails fatally; risk is
        # bounded since each worker uses its own throwaway profile.
        running_in_docker = (
            os.environ.get("DOCKER_CONTAINER") or os.path.exists("/.dockerenv")
        )
        running_as_root = hasattr(os, "geteuid") and os.geteuid() == 0
        if running_in_docker or running_as_root:
            opts.set_argument("--no-sandbox")
            opts.set_argument("--disable-setuid-sandbox")

        if self.config.headless:
            opts.set_argument("--headless=new")

        if self.config.proxy:
            # When smart_routing is on, spawn a SmartRouter and point Chromium
            # at THAT instead of the upstream proxy. The router decides per-flow
            # whether to forward upstream (paid) or direct (free). 85-95%
            # bandwidth reduction on search engines.
            effective_proxy = self.config.proxy
            if self.config.smart_routing:
                try:
                    self._smart_router = SmartRouter(
                        upstream_proxy=self.config.proxy,
                        rules=self.config.smart_routing_rules,
                    )
                    self._smart_router.start()
                    effective_proxy = self._smart_router.proxy_url
                except Exception:
                    logger.exception(
                        "smart-router failed to start, falling back to direct upstream proxy"
                    )
                    self._smart_router = None

            proxy_spec = parse_proxy_url(effective_proxy)
            # Chromium 122+ accepts user:pass in --proxy-server. The MV2
            # auth-extension is kept as a fallback for older Chromium.
            if proxy_spec.has_auth:
                proxy_with_auth = (
                    f"{proxy_spec.scheme}://"
                    f"{proxy_spec.username}:{proxy_spec.password}@"
                    f"{proxy_spec.host}:{proxy_spec.port}"
                )
                opts.set_argument(f"--proxy-server={proxy_with_auth}")
            else:
                opts.set_argument(f"--proxy-server={proxy_spec.chromium_proxy_server}")
            # Keep TokenServer and host_resolver_rules targets off the proxy.
            opts.set_argument(
                f"--proxy-bypass-list={';'.join(('localhost', '127.0.0.1', *self.config.proxy_bypass))}"
            )
            if proxy_spec.has_auth:
                ext = build_proxy_auth_extension(
                    proxy_spec, bypass_hosts=self.config.proxy_bypass,
                )
                opts.add_extension(str(ext.directory))

        # Pass UA at launch so pre-CDP requests look right; stealth wins.
        launch_ua = (
            self.config.stealth.launch_user_agent() if self.config.stealth
            else None
        ) or self.config.user_agent
        if launch_ua:
            opts.set_user_agent(launch_ua)

        if self.config.host_resolver_rules:
            opts.set_argument(f"--host-resolver-rules={self.config.host_resolver_rules}")

        if self.config.ignore_cert_errors:
            opts.set_argument("--ignore-certificate-errors")
            opts.set_argument("--allow-insecure-localhost")

        for arg in self.config.extra_args:
            opts.set_argument(arg)

        self.page = ChromiumPage(opts)

        # Focus emulation + no CPU throttling: Turnstile checks document
        # focus/visibility, and DevTools-style throttling is fingerprintable.
        try:
            self.page.run_cdp("Emulation.setFocusEmulationEnabled", enabled=True)
            self.page.run_cdp("Emulation.setCPUThrottlingRate", rate=1)
        except Exception:
            pass

        if self.config.stealth is not None:
            try:
                self.config.stealth.apply_post_launch(self.page)
            except Exception:
                logger.exception(
                    "[browser] stealth.apply_post_launch failed (name=%s)",
                    getattr(self.config.stealth, "name", "?"),
                )

        return self.page

    def stop(self) -> None:
        if self.page is not None:
            try:
                self.page.quit()
            except Exception:
                pass
            self.page = None

        if self._smart_router is not None:
            try:
                self._smart_router.stop()
            except Exception:
                logger.exception("[browser] smart-router stop failed")
            # Keep the reference so callers can read stats after stop.

        # SIGKILL anything still running with our --user-data-dir; page.quit
        # sometimes leaves renderer/zygote/utility children orphaned to PID 1.
        if self._user_data_dir is not None:
            try:
                killed = _kill_processes_for_userdir(self._user_data_dir)
                if killed:
                    logger.debug(
                        "[browser] SIGKILLed %d leftover process(es) for %s",
                        killed, self._user_data_dir,
                    )
            except Exception:
                logger.debug("[browser] cleanup scan failed", exc_info=True)

        if self._owns_user_data_dir and self._user_data_dir and self._user_data_dir.exists():
            shutil.rmtree(self._user_data_dir, ignore_errors=True)
        self._user_data_dir = None
        self._owns_user_data_dir = False

    async def stop_async(self) -> None:
        await asyncio.to_thread(self.stop)

    def __enter__(self) -> ChromiumPage:
        return self.start()

    def __exit__(self, *exc) -> None:
        self.stop()
