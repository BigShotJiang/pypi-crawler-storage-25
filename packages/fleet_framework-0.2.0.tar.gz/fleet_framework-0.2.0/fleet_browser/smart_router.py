"""Smart per-flow proxy router for browser-based automation.

The problem this solves: residential proxy bandwidth costs $0.50-1.00/GB.
A vanilla Chromium load of a Google SERP through a residential proxy burns
5+ MB per query (Google's own ML model downloads, gstatic CDN assets, JS
bundles). Only the search-result document actually needs the residential
IP — Google's bot-wall scores the document fetch, not its subresources.

How it works: a local mitmproxy subprocess acts as Chromium's proxy. Per-flow
the addon decides:

  - HOST + PATH matches a "paid" rule → forward through the upstream
    residential proxy → captures the IP-reputation signal
  - Otherwise → flow.server_conn.via = None → forward direct → free, doesn't
    affect the SERP fetch
  - Matches a "block" rule → return 204 immediately

In our measurements: 1.31 MB → 0.17 MB paid per Google query. 87% reduction.

ChromiumWorker spins up a SmartRouter automatically when `BrowserConfig.proxy`
is set AND `smart_routing=True` (the default). Per-process subprocess. Stats
(paid/direct/blocked bytes + counts) are written to a temp file and read on
stop, so callers can attribute cost per task.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import socket
import subprocess
import tempfile
import textwrap
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SmartRule:
    """One routing rule. Fields are AND-ed when both are set.

    `host_match` is matched as a SUFFIX so `google.com` covers www.google.com,
    images.google.com, etc. Use a leading "." for exact subdomain ("google.com"
    matches "google.com" but ".google.com" matches "*.google.com" only).

    `path_prefix` is a literal prefix on the URL path. Empty = match any path.

    `action`:
      - "paid"   → forward through the upstream residential proxy
      - "direct" → forward direct, bypassing the upstream
      - "block"  → drop the request (returns 204; useful for trackers/ads)
    """

    host_match: str
    path_prefix: str = ""
    action: str = "paid"


DEFAULT_RULES: tuple[SmartRule, ...] = (
    SmartRule(host_match="www.google.com", path_prefix="/search", action="paid"),
    SmartRule(host_match="www.bing.com", path_prefix="/search", action="paid"),
    SmartRule(host_match="search.yahoo.com", path_prefix="/search", action="paid"),
    SmartRule(host_match="duckduckgo.com", path_prefix="/?q", action="paid"),
    SmartRule(host_match="duckduckgo.com", path_prefix="/html", action="paid"),
    # Block known-noise endpoints we never want to fetch (also free, so the
    # blocking saves on direct bandwidth + latency, not paid cost).
    SmartRule(host_match="googletagmanager.com", action="block"),
    SmartRule(host_match="googlesyndication.com", action="block"),
    SmartRule(host_match="googleadservices.com", action="block"),
    SmartRule(host_match="doubleclick.net", action="block"),
    SmartRule(host_match="google-analytics.com", action="block"),
    SmartRule(host_match="optimizationguide-pa.googleapis.com", action="block"),
)


@dataclass
class RouterStats:
    paid_bytes: int = 0
    paid_requests: int = 0
    direct_bytes: int = 0
    direct_requests: int = 0
    blocked_requests: int = 0


def _pick_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _is_port_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.15)
        try:
            s.connect((host, port))
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False


def _find_mitmdump() -> Optional[str]:
    """Locate the mitmdump binary. Returns None if not installed."""
    p = shutil.which("mitmdump")
    if p:
        return p
    # mitmproxy is often pip-installed under the venv's bin
    here = Path(__file__).resolve()
    for candidate in (
        here.parents[2] / ".venv" / "bin" / "mitmdump",
        Path.home() / ".local" / "bin" / "mitmdump",
    ):
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


@dataclass
class SmartRouter:
    """Embedded mitmproxy subprocess that does per-flow upstream routing.

    Lifecycle: start() spawns mitmdump, blocks until its listen port is open;
    stop() sends SIGTERM and reads the stats file. Designed for one router
    per ChromiumWorker — cheap to spin up (~150ms cold start).
    """

    upstream_proxy: str
    """Upstream residential proxy URL with auth: http://user:pass@host:port."""

    rules: tuple[SmartRule, ...] = field(default_factory=lambda: DEFAULT_RULES)
    """Routing rules. First matching rule wins. Default for non-matches: direct."""

    default_action: str = "direct"
    """Action when no rule matches. "direct" = free, "paid" = everything paid."""

    listen_host: str = "127.0.0.1"
    listen_port: int = 0
    """0 = auto-pick free port."""

    _proc: Optional[subprocess.Popen] = field(default=None, repr=False, init=False)
    _stats_path: Optional[Path] = field(default=None, repr=False, init=False)
    _addon_path: Optional[Path] = field(default=None, repr=False, init=False)
    _stats: RouterStats = field(default_factory=RouterStats, init=False)

    @property
    def proxy_url(self) -> str:
        return f"http://{self.listen_host}:{self.listen_port}"

    @property
    def stats(self) -> RouterStats:
        return self._stats

    def start(self, *, startup_timeout: float = 10.0) -> None:
        mitmdump = _find_mitmdump()
        if mitmdump is None:
            raise RuntimeError(
                "SmartRouter requires mitmproxy. "
                "Install with: pip install 'fleet-framework[browser]'"
            )
        if self.listen_port == 0:
            self.listen_port = _pick_free_port()

        # Strip auth from upstream URL and pass separately.
        from urllib.parse import urlparse
        u = urlparse(self.upstream_proxy)
        upstream_clean = f"{u.scheme}://{u.hostname}:{u.port or 80}"
        upstream_auth = f"{u.username}:{u.password}" if u.username else None

        # Persist stats to a tmp file the subprocess writes to.
        self._stats_path = Path(tempfile.mktemp(prefix="smart-router-stats-", suffix=".json"))
        # Generate the addon script — embeds the rules so the subprocess has them.
        rules_repr = [asdict(r) for r in self.rules]
        self._addon_path = Path(tempfile.mktemp(prefix="smart-router-addon-", suffix=".py"))
        self._addon_path.write_text(_render_addon_script(
            rules_repr, self.default_action, str(self._stats_path)
        ))

        cmd = [
            mitmdump,
            "-p", str(self.listen_port),
            "--mode", f"upstream:{upstream_clean}",
            "--set", "ssl_insecure=true",
            "-s", str(self._addon_path),
            "--quiet",
        ]
        if upstream_auth:
            cmd.extend(["--upstream-auth", upstream_auth])

        self._proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        # Wait for the listen socket.
        deadline = time.monotonic() + startup_timeout
        while time.monotonic() < deadline:
            if _is_port_open(self.listen_host, self.listen_port):
                logger.info(
                    "smart-router @ %s, %d rules, upstream=%s",
                    self.proxy_url, len(self.rules), upstream_clean,
                )
                return
            if self._proc.poll() is not None:
                err = (self._proc.stderr.read() if self._proc.stderr else b"").decode(errors="replace")
                self._cleanup_files()
                raise RuntimeError(f"SmartRouter mitmdump exited early: {err[:400]}")
            time.sleep(0.1)
        self.stop()
        raise RuntimeError(f"SmartRouter failed to start within {startup_timeout}s")

    def stop(self) -> None:
        # Read stats BEFORE killing the process — the addon flushes on every
        # response, so the file is current up to the last completed flow.
        self._read_stats()
        if self._proc is not None:
            try:
                # Term the whole process group; mitmdump spawns helper threads.
                os.killpg(os.getpgid(self._proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            try:
                self._proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(self._proc.pid), signal.SIGKILL)
                except (ProcessLookupError, OSError):
                    pass
                self._proc.wait(timeout=2)
            self._proc = None
        # Re-read stats one more time in case any flows finished between the
        # first read and the SIGTERM.
        self._read_stats()
        self._cleanup_files()
        logger.info(
            "smart-router stopped. paid=%d B / %d req, direct=%d B / %d req, blocked=%d req",
            self._stats.paid_bytes, self._stats.paid_requests,
            self._stats.direct_bytes, self._stats.direct_requests,
            self._stats.blocked_requests,
        )

    def __enter__(self) -> "SmartRouter":
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.stop()

    def _read_stats(self) -> None:
        if self._stats_path is None or not self._stats_path.exists():
            return
        try:
            data = json.loads(self._stats_path.read_text() or "{}")
            self._stats = RouterStats(
                paid_bytes=int(data.get("paid_bytes", 0)),
                paid_requests=int(data.get("paid_requests", 0)),
                direct_bytes=int(data.get("direct_bytes", 0)),
                direct_requests=int(data.get("direct_requests", 0)),
                blocked_requests=int(data.get("blocked_requests", 0)),
            )
        except (json.JSONDecodeError, ValueError, OSError):
            logger.debug("smart-router stats file unreadable", exc_info=True)

    def _cleanup_files(self) -> None:
        for p in (self._stats_path, self._addon_path):
            if p is not None and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass


def _render_addon_script(rules: list[dict], default_action: str, stats_path: str) -> str:
    """Generate the mitmproxy addon script. Embeds the rules as a literal so
    the subprocess has them at startup without a separate config file."""
    return textwrap.dedent(f"""
        import json
        from mitmproxy import http
        from pathlib import Path

        RULES = {json.dumps(rules)}
        DEFAULT_ACTION = {default_action!r}
        STATS_PATH = {stats_path!r}

        _stats = {{
            "paid_bytes": 0, "paid_requests": 0,
            "direct_bytes": 0, "direct_requests": 0,
            "blocked_requests": 0,
        }}

        def _host_matches(host, pattern):
            return host == pattern or host.endswith("." + pattern) or host.endswith(pattern)

        def _pick_action(host, path):
            for r in RULES:
                if not _host_matches(host, r["host_match"]):
                    continue
                if r["path_prefix"] and not path.startswith(r["path_prefix"]):
                    continue
                return r["action"]
            return DEFAULT_ACTION

        def _persist():
            try:
                Path(STATS_PATH).write_text(json.dumps(_stats))
            except OSError:
                pass

        def request(flow):
            host = flow.request.pretty_host
            path = flow.request.path
            action = _pick_action(host, path)
            flow.metadata["smart_action"] = action
            if action == "block":
                _stats["blocked_requests"] += 1
                flow.response = http.Response.make(
                    204, b"", {{"x-smart-router": "blocked"}}
                )
                _persist()
                return
            if action == "direct" and flow.server_conn.via is not None:
                try:
                    flow.server_conn.via = None
                except Exception:
                    pass

        def response(flow):
            action = flow.metadata.get("smart_action", "direct")
            body = flow.response.raw_content or b""
            resp_h = sum(len(k) + len(v) + 4 for k, v in flow.response.headers.items())
            req_h = sum(len(k) + len(v) + 4 for k, v in flow.request.headers.items())
            wire = len(body) + resp_h + req_h + len(flow.request.raw_content or b"")
            if action == "paid":
                _stats["paid_bytes"] += wire
                _stats["paid_requests"] += 1
            elif action == "direct":
                _stats["direct_bytes"] += wire
                _stats["direct_requests"] += 1
            _persist()
    """).strip()


__all__ = [
    "DEFAULT_RULES",
    "RouterStats",
    "SmartRouter",
    "SmartRule",
]
