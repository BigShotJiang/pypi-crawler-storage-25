from __future__ import annotations

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Awaitable, Callable, Optional, Protocol

from fleet_browser.browser import BrowserConfig, ChromiumWorker
from fleet_browser.fingerprint import FingerprintFactory
from fleet_browser.stealth import FingerprintStealth, Stealth

logger = logging.getLogger(__name__)


@asynccontextmanager
async def slot(
    ctx: Any,
    *,
    page_url: str,
    fingerprint_factory: FingerprintFactory | None = None,
    use_fingerprint: bool = True,
    headless: bool = False,
    prefer_browser: str = "brave",
    extra_args: tuple[str, ...] = (),
    host_resolver_rules: str | None = None,
    ignore_cert_errors: bool = False,
    proxy_bypass: tuple[str, ...] = (),
):
    """One-shot helper. For long-lived reuse across many tasks, use BrowserPool."""
    stealth: Stealth | None = None
    if use_fingerprint:
        factory = fingerprint_factory or FingerprintFactory()
        stealth = FingerprintStealth(factory.next())
    cfg = BrowserConfig(
        page_url=page_url,
        stealth=stealth,
        host_resolver_rules=host_resolver_rules,
        ignore_cert_errors=ignore_cert_errors,
        proxy=ctx.proxy_url,
        proxy_bypass=proxy_bypass,
        headless=headless,
        prefer_browser=prefer_browser,
        extra_args=extra_args,
    )
    worker = ChromiumWorker(cfg)
    loop = asyncio.get_running_loop()
    page = await loop.run_in_executor(None, worker.start)
    try:
        await loop.run_in_executor(None, page.get, page_url)
        yield page
    finally:
        try:
            await worker.stop_async()
        except Exception:
            logger.exception("worker stop_async failed")


class _WorkerLike(Protocol):
    def start(self) -> Any: ...
    def stop(self) -> None: ...


WorkerFactory = Callable[[], _WorkerLike]
ResetFn = Callable[[Any], Awaitable[None]]


@dataclass
class _Entry:
    worker: _WorkerLike
    page: Any
    uses: int = 0
    started_at: float = field(default_factory=time.monotonic)
    healthy: bool = True


class BrowserPool:
    """Pre-warmed pool of Chromium workers, reused across many tasks.

    Each task `async with pool.acquire() as page:` gets a checked-out page;
    on exit, the page is reset (cookies cleared, navigated to about:blank)
    and returned. A background janitor recycles entries past `max_uses` or
    `max_age_seconds`, or any entry the caller flagged unhealthy.
    """

    def __init__(
        self,
        size: int,
        worker_factory: WorkerFactory,
        *,
        max_uses: int = 100,
        max_age_seconds: float = 3600.0,
        janitor_interval_seconds: float = 30.0,
        reset_fn: Optional[ResetFn] = None,
    ) -> None:
        if size <= 0:
            raise ValueError("pool size must be >= 1")
        self._size = size
        self._factory = worker_factory
        self._max_uses = max_uses
        self._max_age = max_age_seconds
        self._janitor_interval = janitor_interval_seconds
        self._reset_fn = reset_fn or _default_reset
        self._queue: asyncio.Queue[_Entry] = asyncio.Queue(maxsize=size)
        self._entries: list[_Entry] = []
        self._janitor: Optional[asyncio.Task[None]] = None
        self._closed = False

    @property
    def size(self) -> int:
        return self._size

    @property
    def stats(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "size": self._size,
            "alive": sum(1 for e in self._entries if e.healthy),
            "idle": self._queue.qsize(),
            "total_uses": sum(e.uses for e in self._entries),
            "oldest_age_seconds": max(
                (now - e.started_at for e in self._entries), default=0.0,
            ),
        }

    async def start(self) -> None:
        await asyncio.gather(*(self._spawn() for _ in range(self._size)))
        self._janitor = asyncio.create_task(self._janitor_loop(), name="browser-pool-janitor")

    async def stop(self) -> None:
        self._closed = True
        if self._janitor is not None:
            self._janitor.cancel()
            try:
                await self._janitor
            except (asyncio.CancelledError, Exception):
                pass
        for entry in list(self._entries):
            await self._dispose(entry)
        self._entries.clear()

    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[Any]:
        if self._closed:
            raise RuntimeError("pool is closed")
        entry = await self._queue.get()
        try:
            yield entry.page
        except Exception:
            entry.healthy = False
            raise
        finally:
            entry.uses += 1
            if entry.healthy and not self._is_stale(entry):
                try:
                    await self._reset_fn(entry.page)
                except Exception:
                    logger.exception("browser-pool: reset_fn failed; marking unhealthy")
                    entry.healthy = False
            if entry.healthy and not self._is_stale(entry):
                await self._queue.put(entry)
            else:
                await self._dispose(entry)
                if not self._closed:
                    await self._spawn()

    def _is_stale(self, entry: _Entry) -> bool:
        if entry.uses >= self._max_uses:
            return True
        if (time.monotonic() - entry.started_at) >= self._max_age:
            return True
        return False

    async def _spawn(self) -> None:
        loop = asyncio.get_running_loop()
        worker = self._factory()
        try:
            page = await loop.run_in_executor(None, worker.start)
        except Exception:
            logger.exception("browser-pool: worker start failed")
            return
        entry = _Entry(worker=worker, page=page)
        self._entries.append(entry)
        await self._queue.put(entry)

    async def _dispose(self, entry: _Entry) -> None:
        if entry in self._entries:
            self._entries.remove(entry)
        try:
            await asyncio.get_running_loop().run_in_executor(None, entry.worker.stop)
        except Exception:
            logger.exception("browser-pool: worker stop failed")

    async def _janitor_loop(self) -> None:
        while not self._closed:
            try:
                await asyncio.sleep(self._janitor_interval)
            except asyncio.CancelledError:
                return
            try:
                await self._sweep_once()
            except Exception:
                logger.exception("browser-pool: janitor sweep failed")

    async def _sweep_once(self) -> None:
        # Drain idle entries, dispose any that need recycling, requeue the
        # rest, and respawn replacements until total entries == size.
        idle: list[_Entry] = []
        while True:
            try:
                idle.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        for entry in idle:
            if entry.healthy and not self._is_stale(entry):
                await self._queue.put(entry)
            else:
                await self._dispose(entry)
        while len(self._entries) < self._size and not self._closed:
            await self._spawn()


async def _default_reset(page: Any) -> None:
    loop = asyncio.get_running_loop()

    def _reset() -> None:
        try:
            page.run_cdp("Network.clearBrowserCookies")
        except Exception:
            pass
        try:
            page.run_cdp("Storage.clearDataForOrigin", origin="*", storageTypes="all")
        except Exception:
            pass
        try:
            page.get("about:blank")
        except Exception:
            pass

    await loop.run_in_executor(None, _reset)
