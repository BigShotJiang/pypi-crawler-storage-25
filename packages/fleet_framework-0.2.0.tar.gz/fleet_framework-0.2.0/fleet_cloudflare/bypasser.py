"""Turnstile iframe locator + checkbox clicker, driven via CDP."""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)


CHALLENGE_TITLE_MARKERS = ("just a moment", "checking your browser")


def is_challenge_page(title: str) -> bool:
    lower = (title or "").lower()
    return any(marker in lower for marker in CHALLENGE_TITLE_MARKERS)


# Recorded shadow roots are scanned in one JS call for the Turnstile
# iframe; walking the DOM via CDP takes 30-60s on complex challenge pages.
_SHADOW_TRACKER_JS = r"""
(function() {
    if (window.__cfbp_tracker_installed) return;
    window.__cfbp_tracker_installed = true;
    window.__cfbp_shadow_roots = [];
    const original = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function(init) {
        const root = original.call(this, init);
        window.__cfbp_shadow_roots.push(root);
        return root;
    };
})();
"""


_LOCATE_TURNSTILE_JS = r"""
(function() {
    function matches(el) {
        const src = (el && el.src) || '';
        return src.indexOf('challenges.cloudflare.com') !== -1
            || src.indexOf('turnstile') !== -1;
    }
    function scan(root) {
        if (!root) return null;
        try {
            const frames = root.querySelectorAll('iframe');
            for (const f of frames) {
                if (matches(f)) {
                    const r = f.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) {
                        return {x: r.x, y: r.y, w: r.width, h: r.height};
                    }
                }
            }
        } catch (_) {}
        return null;
    }
    let hit = scan(document);
    if (hit) return JSON.stringify(hit);
    const roots = window.__cfbp_shadow_roots || [];
    for (const r of roots) {
        hit = scan(r);
        if (hit) return JSON.stringify(hit);
    }
    return null;
})()
"""


def install_shadow_tracker(page: Any) -> None:
    try:
        page.run_cdp(
            "Page.addScriptToEvaluateOnNewDocument",
            source=_SHADOW_TRACKER_JS,
        )
    except Exception:
        logger.debug("cf: shadow tracker install failed", exc_info=True)


class CloudflareBypasser:
    """Clicks the Turnstile checkbox via CDP once its iframe is visible."""

    CLICK_X_OFFSET = 33

    def __init__(
        self,
        page: Any,
        max_attempts: int = 10,
        click_delay: float = 1.5,
        log: bool = False,
    ) -> None:
        self.page = page
        self.max_attempts = max_attempts
        self.click_delay = click_delay
        self.log = log

    def is_bypassed(self) -> bool:
        title = (self.page.title or "").lower()
        return all(m not in title for m in CHALLENGE_TITLE_MARKERS)

    def _locate_turnstile_box(self) -> Optional[dict]:
        try:
            raw = self.page.run_js(_LOCATE_TURNSTILE_JS, as_expr=True)
        except TypeError:
            raw = self.page.run_js(_LOCATE_TURNSTILE_JS)
        except Exception as e:
            self._log(f"locate JS raised: {e}")
            return None
        if not raw:
            return None
        if isinstance(raw, dict):
            return raw
        try:
            return json.loads(raw)
        except (TypeError, ValueError):
            return None

    def click_verification_button(self) -> bool:
        box = self._locate_turnstile_box()
        if not box:
            self._log("turnstile iframe not visible yet")
            return False
        cx = int(box["x"] + self.CLICK_X_OFFSET)
        cy = int(box["y"] + box["h"] / 2)
        try:
            self.page.actions.move_to((cx, cy)).click()
            self._log(f"clicked at ({cx}, {cy})")
            return True
        except Exception:
            try:
                self.page.run_cdp(
                    "Input.dispatchMouseEvent",
                    type="mousePressed", x=cx, y=cy,
                    button="left", clickCount=1,
                )
                self.page.run_cdp(
                    "Input.dispatchMouseEvent",
                    type="mouseReleased", x=cx, y=cy,
                    button="left", clickCount=1,
                )
                self._log(f"clicked at ({cx}, {cy}) via raw CDP")
                return True
            except Exception as e:
                self._log(f"click failed: {e}")
                return False

    def bypass(self) -> bool:
        for attempt in range(self.max_attempts):
            if self.is_bypassed():
                return True
            self._log(f"attempt {attempt + 1}/{self.max_attempts}")
            self.click_verification_button()
            time.sleep(self.click_delay)
        return self.is_bypassed()

    def _log(self, msg: str) -> None:
        if self.log:
            logger.info("cf-bypass: %s", msg)


__all__ = [
    "CHALLENGE_TITLE_MARKERS",
    "CloudflareBypasser",
    "install_shadow_tracker",
    "is_challenge_page",
]
