"""Drive a Chromium page through a CF challenge, return cf_clearance."""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from fleet_cloudflare.bypasser import (
    CloudflareBypasser,
    install_shadow_tracker,
    is_challenge_page,
)

logger = logging.getLogger(__name__)


def _extract_cookies(page: Any) -> list[dict[str, str]]:
    raw = page.cookies() or []
    out: list[dict[str, str]] = []
    for c in raw:
        name = c.get("name", "") if isinstance(c, dict) else getattr(c, "name", "")
        value = c.get("value", "") if isinstance(c, dict) else getattr(c, "value", "")
        if name:
            out.append({"name": name, "value": value})
    return out


def _has_clearance(cookies: list[dict[str, str]]) -> bool:
    return any(c["name"] == "cf_clearance" for c in cookies)


def _cookies_to_dict(cookies: list[dict[str, str]]) -> dict[str, str]:
    return {c["name"]: c["value"] for c in cookies}


_UA_OS_MAP: tuple[tuple[str, str], ...] = (
    ("Windows NT", "Windows"),
    ("Macintosh", "macOS"),
    ("Mac OS X", "macOS"),
    ("Android", "Android"),
    ("iPhone", "iOS"),
    ("iPad", "iOS"),
    ("Linux", "Linux"),
)


def headers_for_ua(user_agent: str) -> dict[str, str]:
    """Low-entropy client hints Chrome sends alongside this UA.

    Returned with the cookie so downstream HTTP clients can replay
    byte-identical headers without CF flagging a UA/CH mismatch.
    """
    if not user_agent:
        return {}
    m = re.search(r"Chrome/(\d+)", user_agent)
    major = m.group(1) if m else ""
    platform = next(
        (name for token, name in _UA_OS_MAP if token in user_agent), "Unknown"
    )
    mobile = "?1" if ("Mobile" in user_agent or "Android" in user_agent) else "?0"
    headers = {
        "user-agent": user_agent,
        "accept-language": "en-US,en;q=0.9",
        "sec-ch-ua-mobile": mobile,
        "sec-ch-ua-platform": f'"{platform}"',
    }
    if major:
        headers["sec-ch-ua"] = (
            f'"Chromium";v="{major}", '
            f'"Google Chrome";v="{major}", '
            f'"Not_A Brand";v="24"'
        )
    return headers


def _install_cookie_watcher(page: Any) -> tuple[dict, Callable[[], None]]:
    # Hook response headers so we can stop the page load the instant CF
    # sets cf_clearance, before the browser fires post-challenge subresources.
    state = {"tripped": False}

    def on_headers(**kwargs: Any) -> None:
        if state["tripped"]:
            return
        headers = kwargs.get("headers") or {}
        if isinstance(headers, dict):
            pairs = headers.items()
        elif isinstance(headers, list):
            pairs = ((h.get("name", ""), h.get("value", "")) for h in headers)
        else:
            return
        for name, value in pairs:
            if not name or not value:
                continue
            if name.lower() != "set-cookie":
                continue
            if "cf_clearance=" in value:
                state["tripped"] = True
                logger.info("cf: cf_clearance seen in headers, stopping load")
                try:
                    page.run_cdp("Page.stopLoading")
                except Exception:
                    pass
                return

    driver = getattr(page, "driver", None)
    if driver is None:
        return state, lambda: None

    try:
        page.run_cdp("Network.enable")
        driver.set_callback("Network.responseReceivedExtraInfo", on_headers)
    except Exception:
        logger.debug("cf: cookie watcher setup failed", exc_info=True)
        return state, lambda: None

    def teardown() -> None:
        try:
            driver.set_callback("Network.responseReceivedExtraInfo", None)
        except Exception:
            pass

    return state, teardown


def _stop_loading(page: Any) -> None:
    try:
        page.run_cdp("Page.stopLoading")
    except Exception:
        pass


@dataclass
class HarvestResult:
    success: bool
    cookies: dict[str, str] = field(default_factory=dict)
    user_agent: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    error: Optional[str] = None
    message: Optional[str] = None
    time_taken_s: float = 0.0


def harvest_clearance(
    page: Any,
    url: str,
    timeout: float = 30.0,
) -> HarvestResult:
    """Drive a browser through a CF challenge and return cf_clearance.

    Always returns a HarvestResult; never raises for user-input issues.
    Caller decides whether to retry on `success=False` failures.
    """
    start = time.monotonic()
    install_shadow_tracker(page)

    try:
        page.set.timeouts(page_load=int(timeout))
    except Exception:
        pass
    # load_mode.none returns from page.get() once the URL is accepted, not
    # when the body finishes; polling cookies lets us cancel the moment
    # cf_clearance appears.
    try:
        page.set.load_mode.none()
    except Exception:
        pass

    _, teardown = _install_cookie_watcher(page)
    try:
        try:
            page.get(url, timeout=int(timeout))
        except Exception as e:
            msg = str(e).lower()
            code = (
                "PROXY_ERROR"
                if any(k in msg for k in ("proxy", "tunnel", "err_proxy"))
                else "BROWSER_ERROR"
            )
            return _failure(code, f"navigation failed: {e}", start)

        cookies = _extract_cookies(page)
        if _has_clearance(cookies):
            _stop_loading(page)
            return _success(cookies, page.user_agent, start)

        title_deadline = time.monotonic() + min(timeout, 10)
        while time.monotonic() < title_deadline:
            title = page.title or ""
            if is_challenge_page(title):
                return _run_bypasser(page, start, timeout)
            cookies = _extract_cookies(page)
            if _has_clearance(cookies):
                _stop_loading(page)
                return _success(cookies, page.user_agent, start)
            if title:
                break
            time.sleep(0.2)

        cookies = _extract_cookies(page)
        if _has_clearance(cookies):
            _stop_loading(page)
            return _success(cookies, page.user_agent, start)
        if is_challenge_page(page.title or ""):
            return _run_bypasser(page, start, timeout)
        return _failure(
            "NO_CHALLENGE", "no CF challenge detected on this URL", start
        )
    finally:
        teardown()


def _run_bypasser(page: Any, start: float, timeout: float) -> HarvestResult:
    bypasser = CloudflareBypasser(page, click_delay=1.0, log=False)
    deadline = start + timeout
    while time.monotonic() < deadline:
        cookies = _extract_cookies(page)
        if _has_clearance(cookies):
            _stop_loading(page)
            return _success(cookies, page.user_agent, start)
        if bypasser.is_bypassed():
            cookies = _extract_cookies(page)
            if _has_clearance(cookies):
                _stop_loading(page)
                return _success(cookies, page.user_agent, start)
            return _failure(
                "NO_CHALLENGE",
                "challenge page cleared but no cf_clearance cookie",
                start,
            )
        bypasser.click_verification_button()
        time.sleep(bypasser.click_delay)
    return _failure(
        "TIMEOUT", f"challenge not solved within {timeout}s", start
    )


def _success(
    cookies: list[dict[str, str]], user_agent: Optional[str], start: float
) -> HarvestResult:
    ua = user_agent or ""
    return HarvestResult(
        success=True,
        cookies=_cookies_to_dict(cookies),
        user_agent=ua,
        headers=headers_for_ua(ua),
        time_taken_s=time.monotonic() - start,
    )


def _failure(code: str, message: str, start: float) -> HarvestResult:
    return HarvestResult(
        success=False,
        error=code,
        message=message,
        time_taken_s=time.monotonic() - start,
    )


__all__ = [
    "HarvestResult",
    "harvest_clearance",
    "headers_for_ua",
]
