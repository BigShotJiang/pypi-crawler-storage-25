from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

from pydantic import BaseModel

from fleet.core.automation import (
    BaseAutomation,
    BatchAutomation,
    ContinuousAutomation,
    Task,
)
from fleet.core.backend import Backend, backend_from_url
from fleet.core.context import Context
from fleet.core.events import EventBus
from fleet.core.logging import bind_log_context, reset_log_context
from fleet.core.metrics import SlotMetrics
from fleet.core.otel import record_exception, span
from fleet.core.proxy import ProxyHandle, ProxyProvider, build_provider

logger = logging.getLogger(__name__)


class _FallbackTaskPayload(BaseModel):
    # used when an automation doesn't declare TaskPayload (shouldn't happen
    # for BatchAutomation — registry rejects it — but defensive).
    payload: dict[str, Any] = {}


class SlotRunner:
    # glue between reconcile loop and plugin's run_slot/run_one.
    # owns Context construction and backend connection per worker.
    def __init__(
        self,
        automation: BaseAutomation,
        worker_id: str,
        redis_url: str,
        on_output: Any,  # async (slot_id, payload_dict) -> None
    ) -> None:
        self._auto = automation
        self._auto_cls = type(automation)
        self._worker_id = worker_id
        self._redis_url = redis_url
        self._on_output = on_output
        self._backend: Optional[Backend] = None
        self._provider_cache: Optional[tuple[str, str, ProxyProvider]] = None

    async def _ensure_backend(self) -> Backend:
        if self._backend is None:
            self._backend = backend_from_url(self._redis_url)
        return self._backend

    async def make_task(
        self,
        slot_id: int,
        config: Any,
        shutdown: asyncio.Event,
        metrics: SlotMetrics,
    ) -> asyncio.Task:
        backend = await self._ensure_backend()
        events = EventBus(backend.r)  # type: ignore[attr-defined]
        log = logging.getLogger(f"{self._auto.automation_type}.slot.{slot_id}")

        async def _emit_raw(payload_dict: dict[str, Any]) -> None:
            await self._on_output(slot_id, payload_dict)

        provider = self._resolve_provider(config)
        proxy_handle = ProxyHandle(provider=provider, slot_id=slot_id)
        proxy_url: Optional[str] = None
        if provider is not None:
            try:
                sess = await provider.acquire(slot_id=slot_id, sticky=True)
                proxy_url = sess.url or None
            except Exception:
                log.exception("provider acquire failed; running without proxy")

        ctx = Context(
            automation_type=self._auto.automation_type,
            worker_id=self._worker_id,
            slot_id=slot_id,
            config=config,
            shutdown=shutdown,
            logger=log,
            _emit_raw=_emit_raw,
            _backend=backend,
            _events=events,
            _metrics=metrics,
            _automation_cls=self._auto_cls,
            _proxy=proxy_handle,
            proxy_url=proxy_url,
        )

        if isinstance(self._auto, ContinuousAutomation):
            return asyncio.create_task(
                self._run_continuous(ctx),
                name=f"slot-{self._auto.automation_type}-{slot_id}",
            )
        if isinstance(self._auto, BatchAutomation):
            return asyncio.create_task(
                self._run_batch(ctx, slot_id, backend),
                name=f"slot-{self._auto.automation_type}-{slot_id}",
            )
        raise TypeError(f"unknown automation kind: {type(self._auto).__name__}")

    def _resolve_provider(self, config: Any) -> Optional[ProxyProvider]:
        name = getattr(config, "proxy_provider", None)
        if name:
            cfg = dict(getattr(config, "proxy_provider_config", None) or {})
        elif getattr(config, "proxy_url", None):
            name = "static"
            cfg = {"url": config.proxy_url}
        else:
            return None
        cfg_hash = json.dumps(cfg, sort_keys=True, default=str)
        if self._provider_cache is not None and self._provider_cache[:2] == (name, cfg_hash):
            return self._provider_cache[2]
        try:
            inst = build_provider(name, cfg)
        except Exception:
            logger.exception("failed to build proxy provider '%s'", name)
            return None
        self._provider_cache = (name, cfg_hash, inst)
        return inst

    async def _run_continuous(self, ctx: Context) -> None:
        token = bind_log_context(
            automation_type=ctx.automation_type,
            worker_id=ctx.worker_id,
            slot_id=ctx.slot_id,
        )
        try:
            with span(
                "slot.run_continuous",
                automation_type=ctx.automation_type,
                worker_id=ctx.worker_id,
                slot_id=ctx.slot_id,
            ):
                await self._auto.run_slot(ctx)  # type: ignore[attr-defined]
        except asyncio.CancelledError:
            raise
        except Exception as e:
            record_exception(e)
            ctx.logger.exception("run_slot crashed")
        finally:
            try:
                await self._auto.cleanup(ctx)
            except Exception:
                ctx.logger.exception("cleanup failed")
            reset_log_context(token)

    async def _run_batch(self, ctx: Context, slot_id: int, backend: Backend) -> None:
        queue_name = self._auto.automation_type
        payload_cls = self._auto_cls.TaskPayload or _FallbackTaskPayload
        default_max_attempts = int(getattr(ctx.config, "max_attempts", 3))
        visibility = int(getattr(ctx.config, "visibility_seconds", 300))
        slot_token = bind_log_context(
            automation_type=ctx.automation_type,
            worker_id=ctx.worker_id,
            slot_id=ctx.slot_id,
        )
        try:
            while not ctx.shutdown.is_set():
                with span(
                    "slot.reserve",
                    automation_type=ctx.automation_type,
                    worker_id=ctx.worker_id,
                    slot_id=ctx.slot_id,
                ):
                    body = await backend.queue_reserve(
                        queue_name,
                        timeout_seconds=2,
                        visibility_seconds=visibility,
                    )
                if body is None:
                    continue
                try:
                    envelope = json.loads(body.decode("utf-8") if isinstance(body, bytes) else body)
                    payload = payload_cls.model_validate(envelope.get("payload", {}))
                    task = Task(id=envelope.get("id", ""), payload=payload)
                except Exception:
                    ctx.logger.exception("bad task envelope; dropping")
                    await backend.queue_dead(queue_name, body)
                    continue
                ttl = envelope.get("ttl_seconds")
                submitted_at = envelope.get("submitted_at")
                if ttl is not None and submitted_at is not None:
                    import time as _time
                    if _time.time() - float(submitted_at) > float(ttl):
                        ctx.logger.info(
                            "task %s past ttl=%ss (submitted %.1fs ago); dropping",
                            task.id, ttl, _time.time() - float(submitted_at),
                        )
                        await backend.queue_ack(queue_name, task.id)
                        continue
                attempt = int(envelope.get("attempt", 0)) + 1
                max_attempts = int(envelope.get("max_attempts", default_max_attempts))
                envelope["attempt"] = attempt
                envelope["max_attempts"] = max_attempts
                task_token = bind_log_context(task_id=task.id)
                try:
                    with span(
                        "slot.run_one",
                        automation_type=ctx.automation_type,
                        worker_id=ctx.worker_id,
                        slot_id=ctx.slot_id,
                        task_id=task.id,
                        attempt=attempt,
                    ):
                        await self._auto.run_one(task, ctx)  # type: ignore[attr-defined]
                except Exception as e:
                    record_exception(e)
                    ctx.logger.exception("run_one failed for task %s", task.id)
                    if attempt >= max_attempts:
                        ctx.logger.warning(
                            "task %s exhausted retries (%d/%d), to DLQ",
                            task.id, attempt, max_attempts,
                        )
                        await backend.queue_dead(queue_name, json.dumps(envelope).encode("utf-8"))
                        await backend.queue_ack(queue_name, task.id)
                    else:
                        delay = _exp_backoff(attempt)
                        ctx.logger.info(
                            "task %s retrying in %.1fs (attempt %d/%d)",
                            task.id, delay, attempt, max_attempts,
                        )
                        await backend.queue_nack(
                            queue_name,
                            task.id,
                            json.dumps(envelope).encode("utf-8"),
                            delay_seconds=delay,
                        )
                else:
                    await backend.queue_ack(queue_name, task.id)
                finally:
                    reset_log_context(task_token)
        finally:
            try:
                await self._auto.cleanup(ctx)
            except Exception:
                ctx.logger.exception("cleanup failed")
            reset_log_context(slot_token)


def _exp_backoff(attempt: int) -> float:
    # 1s, 2s, 4s, 8s, capped at 60s.
    return min(60.0, 2 ** max(0, attempt - 1))

    async def aclose(self) -> None:
        if self._backend is not None and hasattr(self._backend, "aclose"):
            try:
                await self._backend.aclose()  # type: ignore[attr-defined]
            except Exception:
                pass
