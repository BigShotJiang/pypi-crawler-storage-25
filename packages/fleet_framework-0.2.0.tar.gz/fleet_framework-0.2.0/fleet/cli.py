from __future__ import annotations

import asyncio
import json
import os
import socket
import sys

import click
import uvicorn

from fleet.core.logging import configure_logging

configure_logging()


@click.group()
def cli() -> None:
    # fleet — master + worker CLI.
    pass


@cli.command()
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--port", default=8000, show_default=True)
@click.option(
    "--backend-url",
    envvar="FLEET_BACKEND_URL",
    default=None,
    show_default=True,
    help="Backend URL: redis://..., memory://, or any registered scheme. "
         "Defaults to $FLEET_BACKEND_URL, then $REDIS_URL, then redis://localhost:6379/0.",
)
@click.option(
    "--redis-url",
    envvar="REDIS_URL",
    default=None,
    show_default=True,
    help="(Legacy) Use --backend-url instead.",
)
def master(host: str, port: int, backend_url: str | None, redis_url: str | None) -> None:
    """Start the master process. Binds REST + WS + dashboard."""
    from fleet.master import create_app

    url = backend_url or redis_url or "redis://localhost:6379/0"
    if redis_url:
        os.environ.setdefault("REDIS_URL", redis_url)
    os.environ.setdefault("FLEET_BACKEND_URL", url)
    app = create_app(url)
    uvicorn.run(app, host=host, port=port, log_level=os.environ.get("LOG_LEVEL", "info").lower())


@cli.command()
@click.option("--type", "automation_type", required=True, help="automation type name (entry-point key)")
@click.option("--id", "worker_id", default=None, help="worker id (defaults to hostname)")
@click.option("--master-url", envvar="MASTER_URL", required=True)
@click.option("--worker-token", envvar="FLEET_WORKER_TOKEN", required=True)
@click.option(
    "--backend-url",
    envvar="FLEET_BACKEND_URL",
    default=None,
    help="Backend URL; falls back to --redis-url then redis://localhost:6379/0.",
)
@click.option(
    "--redis-url",
    envvar="REDIS_URL",
    default=None,
    help="(Legacy) Use --backend-url instead.",
)
def worker(
    automation_type: str,
    worker_id: str | None,
    master_url: str,
    worker_token: str,
    backend_url: str | None,
    redis_url: str | None,
) -> None:
    """Start a worker process pinned to one automation type."""
    from fleet.worker import Agent

    url = backend_url or redis_url or "redis://localhost:6379/0"
    wid = worker_id or socket.gethostname()
    agent = Agent(
        automation_type=automation_type,
        worker_id=wid,
        master_url=master_url,
        worker_token=worker_token,
        redis_url=url,
    )
    try:
        asyncio.run(agent.run())
    except KeyboardInterrupt:
        sys.exit(0)


def _list_plugins() -> None:
    from fleet.core.automation import load_entry_points
    from fleet.core.proxy import load_provider_entry_points

    reg = load_entry_points()
    if reg:
        click.echo("automations:")
        for name, cls in reg.items():
            kind = cls.__mro__[1].__name__
            click.echo(f"  {name:30} {cls.__module__}.{cls.__name__}  ({kind})")
    else:
        click.echo("automations: (none installed)")
    providers = load_provider_entry_points()
    if providers:
        click.echo("proxy providers:")
        for name in providers:
            click.echo(f"  {name}")


@cli.command()
def plugins() -> None:
    """List installed automations + proxy providers discovered via entry-points."""
    _list_plugins()


@cli.command(name="info")
def info_alias() -> None:
    """Alias of `plugins`. Kept for backwards compatibility."""
    _list_plugins()


@cli.command()
@click.argument("automation_type")
@click.option("--master-url", envvar="MASTER_URL", required=True)
@click.option("--admin-token", envvar="FLEET_ADMIN_TOKEN", required=True)
@click.option("--n", default=10, show_default=True, help="entries per pop")
@click.option("--interval", default=1.0, show_default=True, help="seconds between polls")
@click.option("--peek", is_flag=True, help="non-destructive read instead of pop")
def tail(
    automation_type: str,
    master_url: str,
    admin_token: str,
    n: int,
    interval: float,
    peek: bool,
) -> None:
    """Stream the output of an automation type to stdout, one JSON object per line."""
    import httpx

    headers = {"Authorization": f"Bearer {admin_token}"}
    op = "peek" if peek else "pop"
    base = master_url.rstrip("/")
    try:
        while True:
            try:
                if peek:
                    url = f"{base}/api/v1/automations/{automation_type}/output/peek?n={n}"
                    r = httpx.get(url, headers=headers, timeout=10)
                else:
                    url = f"{base}/api/v1/automations/{automation_type}/output/pop"
                    r = httpx.post(url, headers=headers, json={"n": n}, timeout=10)
                r.raise_for_status()
                for env in r.json():
                    click.echo(json.dumps(env, default=str))
            except Exception as e:
                click.echo(f"# {op} failed: {e}", err=True)
            import time as _t
            _t.sleep(max(0.1, interval))
    except KeyboardInterrupt:
        sys.exit(0)


@cli.command()
@click.argument("automation_type")
@click.argument("payload")  # JSON string or @path
@click.option("--master-url", envvar="MASTER_URL", required=True)
@click.option("--admin-token", envvar="FLEET_ADMIN_TOKEN", required=True)
@click.option("--task-id", default=None, help="override the framework's UUID")
@click.option("--max-attempts", default=None, type=int, help="override per-task retry budget")
def submit(
    automation_type: str,
    payload: str,
    master_url: str,
    admin_token: str,
    task_id: str | None,
    max_attempts: int | None,
) -> None:
    """Submit a single task to a BatchAutomation.

    PAYLOAD is a JSON string or @path/to/file.json. Validated against the
    automation's TaskPayload schema server-side.
    """
    import httpx

    body_text = payload
    if payload.startswith("@"):
        body_text = open(payload[1:]).read()
    try:
        parsed = json.loads(body_text)
    except json.JSONDecodeError as e:
        click.echo(f"payload is not valid JSON: {e}", err=True)
        sys.exit(2)
    req: dict = {"payload": parsed}
    if task_id:
        req["task_id"] = task_id
    if max_attempts is not None:
        req["max_attempts"] = max_attempts
    url = master_url.rstrip("/") + f"/api/v1/automations/{automation_type}/tasks"
    r = httpx.post(url, headers={"Authorization": f"Bearer {admin_token}"}, json=req, timeout=10)
    if r.status_code >= 400:
        click.echo(f"submit failed ({r.status_code}): {r.text}", err=True)
        sys.exit(1)
    click.echo(json.dumps(r.json()))


@cli.command(name="describe")
@click.argument("automation_type")
def describe_cmd(automation_type: str) -> None:
    """Print an automation's TaskPayload, Config and Output schemas.

    Useful before `fleet run`: shows you which `-k key=value` pairs the
    automation accepts.
    """
    from fleet.core.automation import (
        BatchAutomation,
        ContinuousAutomation,
        catalog_doc,
        load_entry_points,
    )

    reg = load_entry_points()
    cls = reg.get(automation_type)
    if cls is None:
        available = ", ".join(sorted(reg)) or "(none installed)"
        click.echo(
            f"automation '{automation_type}' not registered. available: {available}",
            err=True,
        )
        sys.exit(2)

    if issubclass(cls, BatchAutomation):
        kind = "BatchAutomation"
    elif issubclass(cls, ContinuousAutomation):
        kind = "ContinuousAutomation"
    else:
        kind = cls.__mro__[1].__name__

    doc = catalog_doc(cls)
    click.echo(f"name:   {cls.automation_type}")
    click.echo(f"class:  {cls.__module__}.{cls.__name__}")
    click.echo(f"kind:   {kind}")
    click.echo("")
    click.echo("config schema:")
    click.echo(json.dumps(doc["config"], indent=2))
    if "queue" in doc:
        click.echo("")
        click.echo(f"task payload schema (the shape -k / -p builds):")
        click.echo(json.dumps(doc["queue"]["payload"], indent=2))
    if "stream" in doc:
        click.echo("")
        click.echo("emit (Output) schema:")
        click.echo(json.dumps(doc["stream"]["payload"], indent=2))


def _coerce_kv(value: str) -> object:
    """Best-effort JSON, falling back to the raw string. So `--kv n=10` is an
    int while `--kv q=test` is a string and `--kv tags=[\"a\",\"b\"]` is a list."""
    try:
        return json.loads(value)
    except (json.JSONDecodeError, ValueError):
        return value


def _parse_range(spec: str) -> list[int]:
    """`'1-10'` → [1..10]; `'3'` → [3]."""
    if "-" not in spec:
        return [int(spec)]
    lo, hi = spec.split("-", 1)
    return list(range(int(lo), int(hi) + 1))


@cli.command(name="run", context_settings={"show_default": True})
@click.argument("automation_type")
@click.option("-k", "--kv", "kvs", multiple=True, metavar="KEY=VALUE",
              help="Set a payload field; repeatable. Values are JSON-coerced "
                   "(so `n=10` is int, `q=test` is str). Combined into a base "
                   "payload that --pages / --repeat / -p expand from.")
@click.option("-p", "--payload", "payloads_json", multiple=True, metavar="JSON",
              help="One full JSON payload per occurrence. Each becomes a "
                   "separate task. Skips the --kv base payload.")
@click.option("--pages", "pages_spec", default=None, metavar="N-M",
              help="Expand the base payload into one task per integer page in "
                   "[N, M], setting `page=N` on each.")
@click.option("--repeat", "repeat_n", default=None, type=int,
              help="Submit the base payload N times.")
@click.option("--from-jsonl", "from_jsonl", default=None, type=click.Path(exists=True, dir_okay=False),
              help="Read one JSON payload per line; each line becomes one task.")
@click.option("--config", "config_json", default=None, metavar="JSON",
              help="JSON config override for the automation's Config schema.")
@click.option("--concurrency", default=1, type=int,
              help="Max parallel tasks. Defaults to 1 for deterministic output.")
@click.option("--timeout", default=None, type=float,
              help="Per-task wall-clock timeout, in seconds.")
@click.option("--duration", "duration_seconds", default=None, type=float,
              help="ContinuousAutomation only: run for N seconds then stop. "
                   "Default 5s when running a ContinuousAutomation.")
@click.option("--slots", "slots", default=1, type=int,
              help="ContinuousAutomation only: number of parallel slot "
                   "coroutines to spawn.")
def run_cmd(
    automation_type: str,
    kvs: tuple[str, ...],
    payloads_json: tuple[str, ...],
    pages_spec: str | None,
    repeat_n: int | None,
    from_jsonl: str | None,
    config_json: str | None,
    concurrency: int,
    timeout: float | None,
    duration_seconds: float | None,
    slots: int,
) -> None:
    """Run an automation in-process for testing. No master/worker needed.

    Each `ctx.emit(...)` is printed to stdout as one JSON line.

    Works for both BatchAutomation and ContinuousAutomation; use
    --pages/--repeat/-p for batch, --duration/--slots for continuous.

    Examples:

      Batch (run one task per page):
        fleet run serp-bing -k q=anthropic -k locale=en-US --pages 1-3
        fleet run serp-bing -p '{"q":"anthropic","page":1}'
        fleet run cf-harvester -k url=https://example.com --repeat 5
        fleet run serp-bing --from-jsonl queries.jsonl

      Continuous (run slot for N seconds):
        fleet run hello-world --duration 5 --slots 2
        fleet run news-firehose --duration 30 -k feeds=https://...

    Use `fleet describe <type>` to see the payload + config schemas.
    """
    from fleet.core.automation import BatchAutomation, ContinuousAutomation, load_entry_points
    from fleet.core.local_runner import run_local, run_local_continuous

    reg = load_entry_points()
    cls = reg.get(automation_type)
    if cls is None:
        available = ", ".join(sorted(reg)) or "(none installed)"
        click.echo(
            f"automation '{automation_type}' not registered. available: {available}",
            err=True,
        )
        sys.exit(2)

    config = None
    if config_json:
        try:
            config = json.loads(config_json)
        except json.JSONDecodeError as e:
            click.echo(f"--config: {e}", err=True)
            sys.exit(2)

    base: dict[str, object] = {}
    for spec in kvs:
        if "=" not in spec:
            click.echo(f"--kv expects KEY=VALUE, got: {spec!r}", err=True)
            sys.exit(2)
        k, v = spec.split("=", 1)
        base[k] = _coerce_kv(v)

    if issubclass(cls, ContinuousAutomation):
        cont_config = config if config is not None else (base or None)
        try:
            summary = asyncio.run(run_local_continuous(
                cls,
                duration_seconds=duration_seconds if duration_seconds is not None else 5.0,
                config=cont_config,
                slots=slots,
            ))
        except (ValueError, TypeError) as e:
            click.echo(f"error: {e}", err=True)
            sys.exit(1)
        click.echo(f"# ran continuous: {summary['emits']} emits", err=True)
        return

    if not issubclass(cls, BatchAutomation):
        click.echo(
            f"'{automation_type}' is neither BatchAutomation nor ContinuousAutomation",
            err=True,
        )
        sys.exit(1)

    payloads: list[dict] = []
    if payloads_json:
        for raw in payloads_json:
            try:
                payloads.append(json.loads(raw))
            except json.JSONDecodeError as e:
                click.echo(f"--payload {raw!r}: {e}", err=True)
                sys.exit(2)
    if from_jsonl:
        with open(from_jsonl) as f:
            for lineno, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    payloads.append(json.loads(line))
                except json.JSONDecodeError as e:
                    click.echo(f"{from_jsonl}:{lineno}: {e}", err=True)
                    sys.exit(2)
    if pages_spec:
        for page in _parse_range(pages_spec):
            payloads.append({**base, "page": page})
    elif repeat_n is not None:
        for _ in range(repeat_n):
            payloads.append({**base})
    elif not payloads:
        payloads.append(base)

    try:
        summary = asyncio.run(run_local(
            cls,
            payloads,
            config=config,
            concurrency=concurrency,
            timeout=timeout,
        ))
    except (ValueError, TypeError) as e:
        click.echo(f"error: {e}", err=True)
        sys.exit(1)

    click.echo(
        f"# ran {summary['ok']} ok, {summary['failed']} failed "
        f"({len(payloads)} total)",
        err=True,
    )
    if summary["failed"] and summary["ok"] == 0:
        sys.exit(1)


@cli.command()
@click.option("--master-url", envvar="MASTER_URL", default=None)
@click.option("--admin-token", envvar="FLEET_ADMIN_TOKEN", default=None)
@click.option("--worker-token", envvar="FLEET_WORKER_TOKEN", default=None)
@click.option("--backend-url", envvar="FLEET_BACKEND_URL", default=None)
def doctor(
    master_url: str | None,
    admin_token: str | None,
    worker_token: str | None,
    backend_url: str | None,
) -> None:
    """Pre-flight sanity checks: env tokens, plugins, backend, master reachable."""
    asyncio.run(_doctor(master_url, admin_token, worker_token, backend_url))


async def _doctor(master_url, admin_token, worker_token, backend_url) -> None:
    import httpx

    ok = True

    def _check(label: str, condition: bool, detail: str = "") -> None:
        nonlocal ok
        mark = "✓" if condition else "✗"
        ok = ok and condition
        click.echo(f"{mark} {label}" + (f" — {detail}" if detail else ""))

    _check("FLEET_ADMIN_TOKEN set", bool(admin_token))
    _check("FLEET_WORKER_TOKEN set", bool(worker_token))

    from fleet.core.automation import load_entry_points
    reg = load_entry_points()
    _check("automations discovered", bool(reg), f"{len(reg)} found")
    for name in reg:
        click.echo(f"    {name}")

    if backend_url:
        try:
            from fleet.core.backend import RedisBackend, backend_from_url
            be = backend_from_url(backend_url)
            _check("backend constructs", True, type(be).__name__)
            if isinstance(be, RedisBackend):
                try:
                    pong = await be.r.ping()
                    _check("redis ping", bool(pong))
                    info = await be.r.info("persistence")
                    aof = info.get(b"aof_enabled", info.get("aof_enabled"))
                    aof_on = str(aof).strip() in ("1", "True", "true")
                    _check(
                        "redis AOF on", aof_on,
                        "" if aof_on else "data lives only in RAM; configs/pools die on restart",
                    )
                except Exception as e:
                    _check("redis reachable", False, str(e))
                finally:
                    await be.aclose()
        except Exception as e:
            _check("backend constructs", False, str(e))
    else:
        click.echo("· backend-url not set (skipping backend checks)")

    if master_url and admin_token:
        try:
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get(master_url.rstrip("/") + "/healthz")
                _check("master /healthz reachable", r.status_code == 200, f"HTTP {r.status_code}")
                r = await c.get(
                    master_url.rstrip("/") + "/api/v1/automations",
                    headers={"Authorization": f"Bearer {admin_token}"},
                )
                _check("admin token accepted", r.status_code == 200, f"HTTP {r.status_code}")
        except Exception as e:
            _check("master reachable", False, str(e))
    else:
        click.echo("· master-url or admin-token not set (skipping master checks)")

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    cli()
