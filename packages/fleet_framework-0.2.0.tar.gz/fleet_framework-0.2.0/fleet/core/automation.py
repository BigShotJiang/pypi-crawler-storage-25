from __future__ import annotations

import importlib.metadata as md
import logging
from dataclasses import dataclass
from typing import Any, ClassVar, Generic, Optional, TypeVar

from pydantic import BaseModel

from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet.core.contract import Pool, Queue, Stream

C = TypeVar("C", bound=BaseConfig)

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, type["BaseAutomation"]] = {}


@dataclass
class Task:
    id: str
    payload: BaseModel  # typed if the automation declared TaskPayload, else a fallback model


class BaseAutomation(Generic[C]):
    # subclass + decorate with @register("name"). do not instantiate directly.
    Config: ClassVar[type[BaseConfig]] = BaseConfig

    # what other plugins (and the master catalog) need to know about this
    # automation. None means this automation doesn't have that kind of resource.
    Output: ClassVar[Optional[type[BaseModel]]] = None      # stream payload type (one stream per automation, by convention)
    TaskPayload: ClassVar[Optional[type[BaseModel]]] = None # BatchAutomation task payload
    Pools: ClassVar[dict[str, Pool]] = {}                   # pools this automation owns

    automation_type: ClassVar[str] = ""

    async def cleanup(self, ctx: Context[C]) -> None:
        return None

    @classmethod
    def own_stream(cls) -> Optional[Stream]:
        if cls.Output is None:
            return None
        return Stream(cls.automation_type, payload=cls.Output)

    @classmethod
    def own_queue(cls) -> Optional[Queue]:
        if cls.TaskPayload is None:
            return None
        return Queue(cls.automation_type, payload=cls.TaskPayload)


class ContinuousAutomation(BaseAutomation[C]):
    async def run_slot(self, ctx: Context[C]) -> None:
        raise NotImplementedError


class BatchAutomation(BaseAutomation[C]):
    async def run_one(self, task: Task, ctx: Context[C]) -> None:
        raise NotImplementedError


def register(name: str):
    def _wrap(cls: type[BaseAutomation]) -> type[BaseAutomation]:
        if not issubclass(cls, BaseAutomation):
            raise TypeError(f"{cls.__name__} must subclass BaseAutomation")
        # BatchAutomation must declare TaskPayload; ContinuousAutomation should declare Output.
        if issubclass(cls, BatchAutomation) and cls.TaskPayload is None:
            raise TypeError(
                f"{cls.__name__} is a BatchAutomation but did not declare 'TaskPayload'"
            )
        cls.automation_type = name
        if name in _REGISTRY and _REGISTRY[name] is not cls:
            raise ValueError(f"automation '{name}' already registered: {_REGISTRY[name]}")
        _REGISTRY[name] = cls
        logger.debug("registered automation '%s' -> %s", name, cls.__name__)
        return cls

    return _wrap


def get_registry() -> dict[str, type[BaseAutomation]]:
    return dict(_REGISTRY)


def load_entry_points(group: str = "fleet.automations") -> dict[str, type[BaseAutomation]]:
    try:
        eps = md.entry_points(group=group)
    except TypeError:
        eps = md.entry_points().get(group, [])  # type: ignore[assignment]
    for ep in eps:
        try:
            ep.load()
        except Exception:
            logger.exception("failed to load entry-point %s", ep.name)
    return get_registry()


def catalog_doc(cls: type[BaseAutomation]) -> dict[str, Any]:
    # the master serves this. consumers don't need it for typing (they import
    # the same Pool/Queue/Stream specs from the shared contracts package),
    # but it's useful for the dashboard and for write-side validation.
    out: dict[str, Any] = {
        "type": cls.automation_type,
        "kind": cls.__mro__[1].__name__,
        "config": cls.Config.model_json_schema(),
    }
    if cls.Output is not None:
        out["stream"] = {
            "name": cls.automation_type,
            "payload": cls.Output.model_json_schema(),
        }
    if cls.TaskPayload is not None:
        out["queue"] = {
            "name": cls.automation_type,
            "payload": cls.TaskPayload.model_json_schema(),
        }
    if cls.Pools:
        out["pools"] = {
            n: {"payload": p.payload.model_json_schema(), "tags": p.tags.model_json_schema()}
            for n, p in cls.Pools.items()
        }
    return out
