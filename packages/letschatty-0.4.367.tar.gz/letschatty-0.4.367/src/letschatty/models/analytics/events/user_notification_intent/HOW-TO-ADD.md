# How to add a new notification intent type

Follow these steps to add a new `NotificationIntentType` and its metadata without changing existing code (open/closed).

## 1. Add the enum value

**File:** `src/letschatty/models/push_notifications/enums.py`

Add a new member to `NotificationIntentType`:

```python
class NotificationIntentType(StrEnum):
    CHAT_ASSIGNED = "chat_assigned"
    CHAT_MESSAGE_RECEIVED = "chat_message_received"
    YOUR_NEW_TYPE = "your_new_type"  # add this
```

## 2. Add the metadata model

**File:** `user_notification_intent/metadata.py`

- Define a new Pydantic model with an `intent` field set to the new type (for the discriminated union):

```python
class YourNewTypeMetadata(BaseModel):
    intent: Literal[NotificationIntentType.YOUR_NEW_TYPE] = (
        NotificationIntentType.YOUR_NEW_TYPE
    )
    # Add any type-specific fields, e.g.:
    # reason_id: Optional[StrObjectId] = None
```

- Add it to the `NotificationIntentMetadata` union:

```python
NotificationIntentMetadata = Annotated[
    Union[ChatAssignedMetadata, IncomingMessageMetadata, YourNewTypeMetadata],  # add here
    Field(discriminator="intent"),
]
```

## 3. Add a builder (optional but recommended)

**File:** `user_notification_intent/builders.py`

- Implement a builder so callers don’t need to construct the metadata model directly:

```python
def build_your_new_type_metadata(
    # any required/optional args, e.g. reason_id: Optional[StrObjectId] = None,
) -> YourNewTypeMetadata:
    return YourNewTypeMetadata()  # or YourNewTypeMetadata(reason_id=reason_id)
```

- Export it from `user_notification_intent/__init__.py`:

```python
from .builders import (
    build_chat_assigned_metadata,
    build_incoming_message_metadata,
    build_your_new_type_metadata,  # add this
)
```

## 4. Use it from the consuming service

- Build the metadata with the new builder, then call the existing factory (no changes in `EventFactory` or `event.py`):

```python
metadata = build_your_new_type_metadata()  # or with args
events = EventFactory.notification_intent_events(
    company_info=company_info,
    trace_id=trace_id,
    chat_id=chat.id,
    recipient_user_id=recipient_user_id,
    intent=NotificationIntentType.YOUR_NEW_TYPE,
    time=now,
    metadata=metadata,
)
events_manager.queue_events(events)
```

## Summary

| Step | File | Action |
|------|------|--------|
| 1 | `push_notifications/enums.py` | Add value to `NotificationIntentType` |
| 2 | `user_notification_intent/metadata.py` | Add metadata class + include in `NotificationIntentMetadata` union |
| 3 | `user_notification_intent/builders.py` | Add `build_*_metadata()` function |
| 4 | `user_notification_intent/__init__.py` | Export the new builder |
| 5 | Consuming API | Call builder + `EventFactory.notification_intent_events(..., metadata=...)` |

No changes are required in `event.py` or `events_factory.py`; the factory already accepts the metadata union and validates via the discriminator.
