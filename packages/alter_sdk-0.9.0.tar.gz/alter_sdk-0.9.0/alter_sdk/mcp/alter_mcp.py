"""
AlterMCP — FastMCP integration for Alter Vault.

Provides the @alter.tool() decorator that:
1. Creates an AlterContext pre-configured with the provider and any
   code-level scope / constraints declared on the decorator.
2. Sets an ambient audit ContextVar so ``vault.request()`` calls made
   directly from the tool function (or any helper it calls) pick up the
   tool name automatically.
3. Modifies the wrapped function's signature to hide the AlterContext
   parameter from FastMCP's generated tool schema.
4. Catches GrantNotFoundError → returns MCP error with a fresh Connect URL.
5. Catches ScopeReauthRequiredError → returns MCP error with a re-auth hint.
"""

from __future__ import annotations

import functools
import inspect
import logging
from collections.abc import Callable  # — used at runtime in TypeVar bound
from typing import TYPE_CHECKING, Any, TypeVar

from alter_sdk._context import _alter_context_var
from alter_sdk.exceptions import GrantNotFoundError, ScopeReauthRequiredError
from alter_sdk.mcp.context import AlterContext

if TYPE_CHECKING:
    from alter_sdk.client import AlterVault

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


class AlterMCP:
    """FastMCP integration for Alter Vault.

    Usage::

        vault = AlterVault(api_key="alter_key_...")
        alter = AlterMCP(vault)

        @alter.tool(provider="google")
        async def list_emails(ctx: AlterContext, query: str) -> list[dict]:
            resp = await ctx.request("GET", "https://gmail.googleapis.com/...")
            return resp.json()

    Code-level policy (``scope`` / ``constraints``) is a reserved surface —
    the backend does not currently enforce it. The decorator stores the
    declared values on the :class:`AlterContext` for introspection (via
    ``ctx.scope`` / ``ctx.constraints``) but does **not** forward them to
    ``vault.request()``. Once backend enforcement lands the forwarding will
    be enabled transparently — tool authors who adopt the final API shape
    today will not need to change their code.
    """

    def __init__(self, vault: AlterVault) -> None:
        self._vault = vault

    def tool(
        self,
        provider: str,
        *,
        scope: list[str] | None = None,
        constraints: dict[str, Any] | None = None,
    ) -> Callable[[F], F]:
        """Decorator that injects AlterContext into a FastMCP tool function.

        Args:
            provider: OAuth provider ID (e.g., "google", "github", "slack").
            scope: Reserved — list of code-level scopes the tool requires.
                Currently stored on the :class:`AlterContext` for
                introspection only; not yet enforced by the backend.
            constraints: Reserved — dict of code-level constraints the tool
                requires. Same introspection-only behavior as ``scope``.

        Returns:
            Decorator that wraps the tool function with credential handling.
        """
        vault = self._vault

        def decorator(fn: F) -> F:
            # Get the original signature
            sig = inspect.signature(fn)
            params = list(sig.parameters.values())

            # Find the AlterContext parameter (by type annotation).
            # Two paths:
            #   1. Direct class match (``annotation is AlterContext``).
            #   2. String annotation (``from __future__ import annotations``
            #      stringifies all hints). Match ``"AlterContext"`` exactly
            #      or ``"module.path.AlterContext"`` (endswith) to avoid
            #      false-positives on ``Union[AlterContext, X]`` or
            #      unrelated names that contain the substring.
            ctx_param_name: str | None = None
            filtered_params: list[inspect.Parameter] = []
            for p in params:
                annotation = p.annotation
                is_ctx = annotation is AlterContext
                if not is_ctx and isinstance(annotation, str):
                    is_ctx = annotation == "AlterContext" or annotation.endswith(".AlterContext")
                if is_ctx:
                    ctx_param_name = p.name
                else:
                    filtered_params.append(p)

            if ctx_param_name is None:
                raise TypeError(
                    f"@alter.tool() requires a parameter annotated with AlterContext "
                    f"in {fn.__name__}(). Add e.g. `ctx: AlterContext` as the first parameter.",
                )

            # Build new signature without AlterContext (hidden from MCP schema)
            new_sig = sig.replace(parameters=filtered_params)

            @functools.wraps(fn)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                # Audit context dict — surfaces as ``X-Alter-Context`` on the
                # eventual vault.request() call and gets stored in audit logs.
                #
                # Nested @alter.tool() calls: if an outer decorated tool
                # calls an inner decorated tool, the inner tool MUST
                # preserve the outer tool's name in audit logs so the
                # call chain is recoverable. Merge the existing context
                # (set by the outer wrapper) with the inner tool's name
                # rather than shadowing it. The previous tool name is
                # stored under ``parent_tool``.
                parent_context = _alter_context_var.get()
                audit_context: dict[str, str] = dict(parent_context) if parent_context else {}
                # Promote previous ``tool`` value to ``parent_tool`` so
                # the audit log chain reads outer → inner. This is only
                # set when there genuinely IS a parent tool — top-level
                # invocations stay flat.
                previous_tool = audit_context.get("tool")
                if previous_tool and previous_tool != fn.__name__:
                    audit_context["parent_tool"] = previous_tool
                audit_context["tool"] = fn.__name__

                # Create AlterContext with pre-configured provider + policy
                alter_ctx = AlterContext(
                    vault,
                    provider=provider,
                    scope=scope,
                    constraints=constraints,
                    context=audit_context,
                )

                # Set the ambient ContextVar so direct vault.request() calls
                # made from inside the tool (without going through ctx.request)
                # still pick up the tool name. The token is reset on exit so
                # concurrent tools do not bleed audit metadata into each other.
                token = _alter_context_var.set(audit_context)
                try:
                    # Inject AlterContext as the named parameter
                    kwargs[ctx_param_name] = alter_ctx
                    return await fn(*args, **kwargs)

                except GrantNotFoundError:
                    # No grant exists — create Connect session for user to authorize.
                    # We deliberately never serialize the exception body into the
                    # user-facing MCP response because GrantNotFoundError may
                    # contain internal details (grant_id hints, request_id,
                    # backend URLs) that shouldn't leak to the tool caller.
                    logger.info(
                        "No grant found in tool=%s (provider=%s), creating Connect session",
                        fn.__name__,
                        provider,
                    )
                    try:
                        session = await vault.create_connect_session(
                            allowed_providers=[provider],
                        )
                    except Exception:  # — cascade isolation
                        # Log sanitized; don't include exception repr in response.
                        logger.exception(
                            "Failed to create Connect session in tool=%s (provider=%s)",
                            fn.__name__,
                            provider,
                        )
                        return {
                            "error": "authorization_required",
                            "message": (
                                f"Authorization required for {provider}. "
                                f"Please try again later."
                            ),
                        }
                    return {
                        "error": "authorization_required",
                        "message": f"Please authorize access to {provider}",
                        "connect_url": session.connect_url,
                    }

                except ScopeReauthRequiredError:
                    # Grant exists but scopes are insufficient. Same hygiene:
                    # don't serialize the exception body into the MCP response.
                    logger.info(
                        "Scope mismatch in tool=%s (provider=%s), requesting re-auth",
                        fn.__name__,
                        provider,
                    )
                    return {
                        "error": "scope_reauth_required",
                        "message": (
                            f"Additional permissions needed for {provider}. "
                            f"Please re-authorize with the required scopes."
                        ),
                    }
                finally:
                    _alter_context_var.reset(token)

            # Replace signature so MCP schema doesn't include AlterContext
            wrapper.__signature__ = new_sig  # type: ignore[attr-defined]
            return wrapper  # type: ignore[return-value]

        return decorator
