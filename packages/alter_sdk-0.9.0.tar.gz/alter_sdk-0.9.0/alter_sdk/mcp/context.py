"""
AlterContext — pre-configured request context injected by @alter.tool().

Provides a request method that automatically includes the provider,
optional code-level scope/constraints, and audit context from the decorator.
Tool implementations only need to specify method + URL.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

    import httpx

    from alter_sdk.client import AlterVault


class AlterContext:
    """Per-tool-call request context with a pre-configured provider.

    Created by :class:`alter_sdk.mcp.AlterMCP`'s ``@alter.tool()`` decorator
    and injected as a parameter into the tool function. Not intended to be
    constructed directly.

    The following attributes are pre-configured on the context and
    automatically forwarded to every :meth:`request` call:

    - ``provider``: the OAuth provider id declared on the decorator
    - ``context``: audit-correlation dict (e.g. ``{"tool": "list_emails"}``)

    Reserved (stored for introspection, NOT yet forwarded):

    - ``scope``: optional list of code-level scopes
    - ``constraints``: optional dict of code-level constraints

    Code-level policy note
    ----------------------
    ``scope`` and ``constraints`` are a reserved API surface. The backend
    does not yet enforce code-level policy restrictions, so the context
    stores them for introspection but does **not** forward them to the
    underlying :meth:`AlterVault.request` (which would raise
    :class:`NotImplementedError`). Once backend enforcement lands the
    forwarding will be enabled transparently — tool authors who adopt
    the final API shape today will not need to change their code.

    Developers can inspect the reserved values via ``ctx.scope`` /
    ``ctx.constraints`` on the context instance.
    """

    __slots__ = ("_vault", "_provider", "_scope", "_constraints", "_context")

    def __init__(
        self,
        vault: AlterVault,
        *,
        provider: str,
        scope: list[str] | None = None,
        constraints: dict[str, Any] | None = None,
        context: dict[str, str] | None = None,
    ) -> None:
        self._vault = vault
        self._provider = provider
        # Freeze scope list / constraints dict so tool bodies can't mutate
        # them mid-call and leak state across invocations.
        self._scope: tuple[str, ...] | None = tuple(scope) if scope is not None else None
        self._constraints: Mapping[str, Any] | None = (
            MappingProxyType(dict(constraints)) if constraints is not None else None
        )
        # Defensive copy of the audit context so mutations inside the tool
        # body don't corrupt downstream requests.
        self._context: dict[str, str] | None = dict(context) if context else None

    @property
    def provider(self) -> str:
        """The OAuth provider id declared on the ``@alter.tool()`` decorator."""
        return self._provider

    @property
    def scope(self) -> tuple[str, ...] | None:
        """Reserved code-level scope declaration (not yet enforced)."""
        return self._scope

    @property
    def constraints(self) -> Mapping[str, Any] | None:
        """Reserved code-level constraints declaration (not yet enforced)."""
        return self._constraints

    def __repr__(self) -> str:
        tool = (self._context or {}).get("tool", "<unknown>")
        return f"AlterContext(provider={self._provider!r}, tool={tool!r})"

    async def request(
        self,
        method: str,
        url: str,
        *,
        account: str | None = None,
        json: dict[str, Any] | None = None,
        body: bytes | None = None,
        extra_headers: dict[str, str] | None = None,
        query_params: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        reason: str | None = None,
    ) -> httpx.Response:
        """Make an authenticated request using the pre-configured provider.

        The audit ``context`` dict (tool name, framework, run_id, etc.) is
        automatically forwarded. Reserved ``scope`` / ``constraints``
        values are **not** forwarded — see the class docstring.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            url: Provider API URL
            account: Optional account identifier for identity-mode
                resolution when multiple grants exist for the same provider.
            json: Optional JSON request body
            body: Optional raw request body
            extra_headers: Optional additional headers
            query_params: Optional URL query parameters
            path_params: Optional URL path template substitutions
            reason: Optional audit reason

        Returns:
            httpx.Response from the provider API
        """
        return await self._vault.request(
            method,
            url,
            provider=self._provider,
            account=account,
            json=json,
            body=body,
            extra_headers=extra_headers,
            query_params=query_params,
            path_params=path_params,
            reason=reason,
            context=self._context,
            # NOTE: scope/constraints intentionally NOT forwarded — see
            # class docstring. The ambient ContextVar fallback on
            # vault.request() will still pick up self._context.
        )
