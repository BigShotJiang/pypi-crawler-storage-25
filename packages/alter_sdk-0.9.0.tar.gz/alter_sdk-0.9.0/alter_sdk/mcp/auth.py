"""
AlterAuthProvider — FastMCP-compatible auth provider using Alter Connect.

Implements FastMCP's ``TokenVerifier`` protocol to verify incoming bearer
tokens against the app's configured IDP (via the Alter backend). Also
exposes ``create_auth_url`` for out-of-band provider consent (Alter
Connect) — Google/GitHub/etc. OAuth initiation that the host application
typically performs separately from the MCP auth flow.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from fastmcp.server.auth.auth import AccessToken, TokenVerifier

from alter_sdk.exceptions import AlterValueError

if TYPE_CHECKING:
    from alter_sdk.client import AlterVault

logger = logging.getLogger(__name__)


class AlterAuthProvider(TokenVerifier):
    """FastMCP ``TokenVerifier`` that validates bearer tokens via Alter.

    Inheriting from :class:`fastmcp.server.auth.auth.TokenVerifier` is
    essential — FastMCP's HTTP app calls ``auth.get_middleware()`` when
    mounting, which is provided by the base class. Subclassing also
    gives ``get_routes()``, ``get_well_known_routes()``, and
    ``set_mcp_path()``.

    Minimal usage::

        from fastmcp import FastMCP
        from alter_sdk import AlterVault
        from alter_sdk.mcp import AlterAuthProvider, AlterMCP

        vault = AlterVault(api_key="alter_key_...")
        alter = AlterMCP(vault)

        auth = AlterAuthProvider(vault, providers={"google": ["gmail.readonly"]})
        mcp = FastMCP("my-server", auth=auth)

    Mounting the MCP server inside an existing FastAPI app (streamable
    HTTP transport)::

        # FastMCP's http_app() returns a Starlette ASGI app with its own
        # lifespan that initializes the MCP session manager. You MUST
        # pass that lifespan to FastAPI — otherwise MCP requests raise
        # ``RuntimeError: Task group is not initialized``.
        mcp_app = mcp.http_app(path="/")
        app = FastAPI(lifespan=mcp_app.lifespan)
        app.mount("/mcp", mcp_app)

    Subclassing to hook every successful verification (e.g. to capture
    the raw JWT in a ContextVar for downstream identity resolution)::

        from alter_sdk.mcp import AccessToken, AlterAuthProvider

        class MyAuthProvider(AlterAuthProvider):
            async def verify_token(self, token: str) -> AccessToken | None:
                result = await super().verify_token(token)
                if result is not None:
                    _current_user_token.set(token)
                return result
    """

    def __init__(
        self,
        vault: AlterVault,
        *,
        providers: dict[str, list[str]] | None = None,
    ) -> None:
        """Initialize the auth provider.

        Args:
            vault: AlterVault client instance
            providers: Map of provider_id → required scopes for Alter Connect
                       (used by :meth:`create_auth_url`, not FastMCP's own
                       OAuth scope enforcement). E.g.,
                       ``{"google": ["gmail.readonly"], "github": ["repo"]}``

        Note — ``required_scopes`` (FastMCP concept) is intentionally
        **not** exposed. Alter enforces scopes at the grant layer
        (``vault.request`` resolves the user's grant and its authorized
        scopes), not on the IDP JWT. ``verify_token`` returns
        ``AccessToken(scopes=[])`` because the IDP token proves identity,
        not provider-level authorization. Accepting ``required_scopes``
        here would silently deny every request since no token would ever
        satisfy the scope check.
        """
        super().__init__()
        self._vault = vault
        self._providers = providers or {}

    async def create_auth_url(self, **kwargs: Any) -> str:  # noqa: ARG002 - kept for backwards compat, called by host app
        """Create an Alter Connect URL for provider OAuth authorization.

        This is **not** part of the FastMCP auth protocol — inheriting
        from :class:`TokenVerifier` means FastMCP will not call this
        method. It is exposed as an Alter-specific helper so the host
        application (e.g. a FastAPI endpoint or the MCP tool that first
        detects a missing grant) can kick off an Alter Connect session
        for provider consent.

        The Connect session is built with **all** providers declared in
        ``self._providers`` and forwards every provider's scope list to
        ``vault.create_connect_session(required_scopes=...)``. This
        preserves the SDK's scope-attenuation invariant: a non-primary
        provider's scopes can never be silently dropped.

        Scope ceiling: each provider's scopes are forwarded to the
        backend as a per-provider ceiling. The backend validates that
        every requested scope is already in the Dev Portal's configured
        allowlist for that provider — requesting a scope outside the
        allowlist raises ``BackendError`` with ``scope_not_allowed``.
        The Dev Portal remains the authoritative ceiling: this hook can
        only NARROW what the Dev Portal allows, never widen it.

        Returns:
            Connect URL for user to complete OAuth authorization.
        """
        if not self._providers:
            # Raise AlterValueError (not bare ValueError) so callers
            # catching the SDK's base exception hierarchy
            # (AlterSDKError / AlterValueError) don't miss this.
            raise AlterValueError("No providers configured for AlterAuthProvider")

        allowed_providers = list(self._providers.keys())

        # Forward EVERY provider's scope ceiling. Dropping non-primary
        # entries (a previous bug) silently widened those providers'
        # scopes back to the Dev Portal default, breaking the
        # attenuation invariant. Empty/None scope lists are skipped so
        # we don't pin a provider to "no scopes."
        required_scopes: dict[str, list[str]] = {}
        for provider_id, scopes in self._providers.items():
            if scopes:
                required_scopes[provider_id] = list(scopes)

        session = await self._vault.create_connect_session(
            allowed_providers=allowed_providers,
            required_scopes=required_scopes if required_scopes else None,
        )
        return session.connect_url

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify an incoming bearer token against the app's configured IDP.

        Delegates to ``AlterVault.verify_user_token``, which makes an
        HMAC-signed request to the backend's ``POST /sdk/auth/verify-token``
        endpoint. The backend runs the token through the production
        ``JWTValidationService``:

        - Signature verification against the app's IDP JWKS (RS256/ES256/PS256)
        - ``iss`` must match the configured issuer URL
        - ``aud`` must match the configured audience (if set)
        - ``exp`` must be in the future (with 30s clock skew tolerance)
        - Key rotation is handled by the backend's JWKS cache with
          kid-miss refetch
        - SSRF protection on JWKS and discovery fetches

        This is **not** a stub — it is a real auth boundary backed by the
        same verification service the backend uses for identity resolution
        on every SDK token request. Fail-closed: any verification failure
        (expired, bad signature, wrong issuer, wrong audience, network
        error, backend unavailable) returns ``None``, which FastMCP treats
        as "reject the request."

        Args:
            token: Bearer token from the incoming MCP request.

        Returns:
            An :class:`fastmcp.server.auth.auth.AccessToken` on success,
            or ``None`` if the token cannot be trusted for any reason.
            Returning ``None`` MUST cause the caller to reject the request.

        SECURITY: The returned ``AccessToken`` deliberately contains ONLY
        the verified ``sub`` (as ``client_id``) and the raw token string
        (required by FastMCP for downstream context propagation). The
        backend ``verify-token`` endpoint never returns the full JWT
        payload, so PII or scope-bearing claims (email, groups, org
        metadata) cannot leak through this provider into MCP middleware
        downstream of FastMCP.
        """
        if not token:
            return None
        sub = await self._vault.verify_user_token(token)
        if sub is None:
            # Do not log the token or its prefix — nothing about the token
            # is trustworthy at this point and surfacing any part of it in
            # logs would turn this verifier into a free oracle for an
            # attacker with log access.
            logger.info("AlterAuthProvider.verify_token rejected a token")
            return None
        logger.debug(
            "AlterAuthProvider.verify_token accepted token for sub=%s",
            sub,
        )
        # client_id is FastMCP's per-request identity. We use the verified
        # ``sub`` from the IDP so downstream middleware sees the real user
        # identity rather than an opaque client/app ID. ``scopes=[]`` —
        # Alter does not surface JWT scopes through verify_user_token; any
        # scope enforcement happens at the Alter grant layer, not here.
        return AccessToken(token=token, client_id=sub, scopes=[])
