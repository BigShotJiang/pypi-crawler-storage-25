"""
Alter Vault FastMCP Integration.

Provides zero-config OAuth for FastMCP tools. The @alter.tool() decorator
handles credential retrieval, scope enforcement, and Connect flow errors
automatically.

Usage:
    from alter_sdk import AlterVault
    from alter_sdk.mcp import AlterMCP

    vault = AlterVault(api_key="alter_key_...")
    alter = AlterMCP(vault)

    @alter.tool(provider="google", scope=["gmail.readonly"])
    async def list_emails(ctx: AlterContext, query: str) -> list[dict]:
        response = await ctx.request("GET", "https://gmail.googleapis.com/gmail/v1/users/me/messages")
        return response.json()

Requires: pip install 'alter-sdk[mcp]'
"""

from fastmcp.server.auth.auth import AccessToken

from alter_sdk.mcp.alter_mcp import AlterMCP
from alter_sdk.mcp.auth import AlterAuthProvider
from alter_sdk.mcp.context import AlterContext

# ``AccessToken`` is re-exported so subclass authors can annotate their
# ``verify_token`` overrides without reaching into FastMCP's internal
# ``fastmcp.server.auth.auth`` namespace. It is the return type of
# ``AlterAuthProvider.verify_token``.
__all__ = ["AccessToken", "AlterAuthProvider", "AlterContext", "AlterMCP"]
