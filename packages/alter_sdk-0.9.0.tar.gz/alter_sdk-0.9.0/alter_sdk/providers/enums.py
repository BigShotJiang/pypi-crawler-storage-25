"""
Provider and HttpMethod enums for type-safe SDK usage.

Static enum of supported OAuth providers. Strings are also accepted
by the SDK for forward compatibility with new providers.

When adding a new provider to the backend, add it here too.
See .claude/commands/add-oauth.md for the full procedure.
"""

from enum import Enum


class Provider(str, Enum):
    """
    Supported OAuth provider identifiers.

    Use these for type safety and IDE autocomplete. The SDK also accepts
    plain strings for providers not yet in this enum.

    Provider enums can be used for filtering grants:
        ```python
        from alter_sdk import AlterVault, Provider

        vault = AlterVault(api_key="alter_key_...")
        grants = await vault.list_grants(provider_id=Provider.GOOGLE)
        ```
    """

    ACUITY_SCHEDULING = "acuity-scheduling"
    ADOBE = "adobe"
    AIRCALL = "aircall"
    AIRTABLE = "airtable"
    APOLLO = "apollo"
    ASANA = "asana"
    ATLASSIAN = "atlassian"
    ATTIO = "attio"
    AUTODESK = "autodesk"
    BASECAMP = "basecamp"
    BITBUCKET = "bitbucket"
    BITLY = "bitly"
    BOX = "box"
    BREX = "brex"
    CALENDLY = "calendly"
    CAL_COM = "cal-com"
    CANVA = "canva"
    CLICKUP = "clickup"
    CLOSE = "close"
    CONSTANT_CONTACT = "constant-contact"
    CONTENTFUL = "contentful"
    DEEL = "deel"
    DIALPAD = "dialpad"
    DIGITALOCEAN = "digitalocean"
    DISCORD = "discord"
    DOCUSIGN = "docusign"
    DROPBOX = "dropbox"
    EBAY = "ebay"
    EVENTBRITE = "eventbrite"
    FACEBOOK = "facebook"
    FIGMA = "figma"
    GITHUB = "github"
    GOOGLE = "google"
    HUBSPOT = "hubspot"
    INSTAGRAM = "instagram"
    LINEAR = "linear"
    LINKEDIN = "linkedin"
    MAILCHIMP = "mailchimp"
    MERCURY = "mercury"
    MICROSOFT = "microsoft"
    MIRO = "miro"
    MONDAY = "monday"
    NOTION = "notion"
    OUTREACH = "outreach"
    PAGERDUTY = "pagerduty"
    PAYPAL = "paypal"
    PINTEREST = "pinterest"
    PIPEDRIVE = "pipedrive"
    QUICKBOOKS = "quickbooks"
    RAMP = "ramp"
    REDDIT = "reddit"
    RINGCENTRAL = "ringcentral"
    SALESFORCE = "salesforce"
    SENTRY = "sentry"
    SLACK = "slack"
    SNAPCHAT = "snapchat"
    SPOTIFY = "spotify"
    SQUARE = "square"
    SQUARESPACE = "squarespace"
    STRIPE = "stripe"
    TIKTOK = "tiktok"
    TODOIST = "todoist"
    TWITTER = "twitter"
    TYPEFORM = "typeform"
    WEBEX = "webex"
    WEBFLOW = "webflow"

    def __str__(self) -> str:
        """Return the provider ID string value."""
        return self.value


class HttpMethod(str, Enum):
    """
    HTTP methods for type-safe method selection.

    Use these for IDE autocomplete and type safety. Plain strings
    are also accepted for forward compatibility.

    Example:
        ```python
        from alter_sdk import AlterVault, HttpMethod

        vault = AlterVault(api_key="alter_key_...")

        resp = await vault.request(
            "GRANT_ID", HttpMethod.GET,
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
        )
        ```
    """

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"

    def __str__(self) -> str:
        """Return the HTTP method string value."""
        return self.value


class CallerType(str, Enum):
    """
    Caller type for distinguishing AI agents from backend services.

    Use these to classify SDK instances in the Developer Portal:
    - ``AGENT`` — shows up in the Agents tab with audit trail and activity tracking
    - ``SERVICE`` — backend infrastructure; excluded from the Agents tab

    Default is ``AGENT`` — if you only pass ``caller=`` without ``caller_type=``,
    the caller is treated as an AI agent.

    Example:
        ```python
        from alter_sdk import AlterVault, CallerType

        # AI agent (default) — appears in Agents tab
        agent = AlterVault(api_key="alter_key_...", caller="email-assistant")

        # Backend service — excluded from Agents tab
        service = AlterVault(
            api_key="alter_key_...",
            caller="billing-cron",
            caller_type=CallerType.SERVICE,
        )
        ```
    """

    AGENT = "agent"
    SERVICE = "service"

    def __str__(self) -> str:
        """Return the caller type string value."""
        return self.value
