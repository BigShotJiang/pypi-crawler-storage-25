"""
AlterMCPInterceptor — intercepts langchain-mcp-adapters tool calls.

Despite the ``MCP`` in the name, this class lives under ``alter_sdk.langchain``
because it implements the tool-call interceptor protocol exposed by
``langchain-mcp-adapters``. The name is preserved for backward compatibility
with existing imports.

Injects Alter auth headers into MCP tool call requests so that a downstream
MCP server can resolve user identity via Alter Vault.
"""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import socket
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from alter_sdk.exceptions import AlterValueError

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

logger = logging.getLogger(__name__)

# Only allow injecting bearer tokens into requests bound for schemes we
# consider safe to carry secrets over the wire. Plain-text schemes are
# rejected to avoid leaking user tokens to arbitrary downstream URLs.
_ALLOWED_URL_SCHEMES: frozenset[str] = frozenset({"https"})

# IP ranges that must NEVER receive a bearer token, even over HTTPS.
# Mirrors apps/backend/app/domains/oauth/core/services/jwt_validation_service.py
# ``_BLOCKED_NETWORKS`` so the SDK applies the same SSRF policy as the
# backend's JWKS fetcher. Updates to that list MUST be reflected here.
_BLOCKED_NETWORKS: tuple[
    ipaddress.IPv4Network | ipaddress.IPv6Network,
    ...,
] = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local + AWS IMDS
    ipaddress.ip_network("127.0.0.0/8"),  # loopback
    ipaddress.ip_network("::1/128"),  # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),  # IPv6 unique-local
    ipaddress.ip_network("fe80::/10"),  # IPv6 link-local
)

# CRLF characters that must never appear in HTTP header values.
# Per RFC 7230 §3.2.4, header field values must not contain CR/LF.
_CRLF_CHARS: frozenset[str] = frozenset({"\r", "\n"})


def _request_url(request: Any) -> str | None:
    """Best-effort extraction of an outbound URL from a request object."""
    url = getattr(request, "url", None)
    if isinstance(url, str):
        return url
    if url is not None:
        # httpx.URL / yarl.URL / pydantic HttpUrl all stringify cleanly.
        try:
            return str(url)
        except Exception:  # pragma: no cover - defensive
            return None
    return None


def _is_blocked_ip(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Check whether an IP address falls in any blocked network."""
    for network in _BLOCKED_NETWORKS:
        # ip_network rejects mixing IPv4 and IPv6 — check address/network
        # pair matches the same family, then check containment in a
        # single condition to keep the loop body flat.
        same_family_v4 = isinstance(ip, ipaddress.IPv4Address) and isinstance(
            network,
            ipaddress.IPv4Network,
        )
        same_family_v6 = isinstance(ip, ipaddress.IPv6Address) and isinstance(
            network,
            ipaddress.IPv6Network,
        )
        if (same_family_v4 or same_family_v6) and ip in network:
            return True
    return False


async def _validate_url_safety(url: str | None) -> None:  # noqa: PLR0912 - each branch is a distinct SSRF check
    """Validate that ``url`` is safe to attach a bearer token to.

    Raises:
        AlterValueError: If the URL is missing, uses a non-HTTPS scheme,
            has no resolvable hostname, contains a literal IP that falls
            in a blocked range, or resolves via DNS to a blocked range.

    SECURITY: Resolves hostnames via ``asyncio.get_running_loop().getaddrinfo``
    (the async-safe stdlib wrapper — NOT ``socket.getaddrinfo`` directly,
    which would block the event loop for the full duration of DNS lookup
    and stall every other concurrent task). Rejects any address that
    falls in the loopback / link-local / private / metadata-service
    ranges — mirrors the backend's SSRF policy.

    Note: This is a TOCTOU best-effort check — DNS could change between
    this lookup and the actual outbound request. The downstream HTTP
    client should also be configured with no-redirect-to-private-IP
    when possible. See the ``AlterMCPInterceptor`` class docstring for
    the full security limitation discussion.
    """
    if not url:
        raise AlterValueError(
            "AlterMCPInterceptor refusing to attach bearer: empty URL",
        )

    parsed = urlparse(url)

    if parsed.scheme not in _ALLOWED_URL_SCHEMES:
        raise AlterValueError(
            f"AlterMCPInterceptor refusing to attach bearer: "
            f"scheme '{parsed.scheme}' is not in allowed list "
            f"{sorted(_ALLOWED_URL_SCHEMES)}",
        )

    hostname = parsed.hostname
    if not hostname:
        raise AlterValueError(
            "AlterMCPInterceptor refusing to attach bearer: URL has no hostname",
        )

    # Try parsing as a literal IP first. If the URL contains a literal
    # IP, we can short-circuit DNS resolution.
    try:
        literal_ip = ipaddress.ip_address(hostname)
    except ValueError:
        literal_ip = None

    if literal_ip is not None:
        if _is_blocked_ip(literal_ip):
            raise AlterValueError(
                f"AlterMCPInterceptor refusing to attach bearer: "
                f"URL targets blocked IP range ({hostname})",
            )
        return

    # Resolve hostname via DNS on the running event loop's executor so
    # we do NOT block the event loop for the full duration of the
    # getaddrinfo syscall.
    loop = asyncio.get_running_loop()
    try:
        addr_infos = await loop.getaddrinfo(
            hostname,
            None,
            family=socket.AF_UNSPEC,
            type=socket.SOCK_STREAM,
        )
    except socket.gaierror as e:
        raise AlterValueError(
            f"AlterMCPInterceptor refusing to attach bearer: "
            f"cannot resolve hostname '{hostname}' ({e})",
        ) from e

    for addr_info in addr_infos:
        sockaddr = addr_info[4]
        try:
            ip = ipaddress.ip_address(sockaddr[0])
        except (ValueError, IndexError):
            continue
        if _is_blocked_ip(ip):
            raise AlterValueError(
                f"AlterMCPInterceptor refusing to attach bearer: "
                f"hostname '{hostname}' resolves to blocked IP range "
                f"({ip})",
            )


def _validate_header_value(value: str, *, header_name: str) -> str:
    """Strip-or-reject CRLF from a header value.

    Per RFC 7230 §3.2.4, header field values MUST NOT contain CR or LF.
    Allowing them lets an attacker who controls the value inject
    additional headers or split the response — known as HTTP header
    injection (CWE-113). This rejects any value containing those bytes.

    Raises:
        AlterValueError: If ``value`` contains a CR or LF.
    """
    if any(c in _CRLF_CHARS for c in value):
        raise AlterValueError(
            f"AlterMCPInterceptor refusing to attach {header_name!r}: "
            f"value contains CR/LF characters (header injection guard)",
        )
    return value


class AlterMCPInterceptor:
    """Interceptor for langchain-mcp-adapters that injects Alter auth.

    When used with ``langchain-mcp-adapters``, this interceptor reads the
    user identity from LangChain's runtime context and injects an
    ``Authorization: Bearer <user_token>`` header on the outbound MCP
    tool-call request.

    SECURITY NOTES:
      - The ``user_token`` pulled from LangChain's runtime context is treated
        as an **opaque** credential. This interceptor performs NO validation,
        parsing, or signature checking on it.
      - This interceptor enforces a defence-in-depth policy on the
        outbound URL before attaching the bearer header:
        1. Scheme must be ``https`` (no plain-text leakage).
        2. Hostname must resolve to a public IP (no SSRF to loopback,
           link-local, RFC 1918 private ranges, or AWS IMDS at
           169.254.169.254).
      - The token itself is sanitised to ensure it contains no CR/LF
        characters that could be used for HTTP header injection.
      - As a best-effort redirect guard, the interceptor attempts to set
        ``request.follow_redirects = False`` when the attribute is
        present on the underlying MCP request object. This prevents a
        malicious MCP server from responding with ``302 Location:
        https://169.254.169.254/`` and having the client re-issue the
        request (with the bearer header re-attached) against a private
        IP.

    ⚠️  KNOWN SECURITY LIMITATION — SSRF DNS TOCTOU  ⚠️

    The ``_validate_url_safety`` check is inherently time-of-check to
    time-of-use (TOCTOU). Between the DNS lookup performed here and the
    actual outbound TCP connect performed by the MCP transport, a
    hostile resolver or DNS rebinding attack can return a different
    address. This interceptor CANNOT close that window alone.

    Deployments that require strict SSRF guarantees MUST pair this
    interceptor with a transport-level guard in the MCP HTTP client:

      - Pin the resolved address at connect time (e.g. custom
        ``asyncio`` connector that re-resolves once and uses the pinned
        IP), OR
      - Configure the HTTP client with an address-level deny list that
        is re-checked on every socket connect (e.g. ``httpx`` transport
        hook), OR
      - Run the agent in a network namespace / egress firewall that
        blocks RFC 1918 / link-local / IMDS ranges at the kernel
        level.

    Without at least one of the above, a determined attacker who
    controls DNS for the MCP server URL can still reach private IPs.
    This class is documented as the "best effort at the application
    layer" and is NOT a substitute for transport- or network-layer
    controls.

    Usage::

        from langchain_mcp_adapters import MCPToolkit
        from alter_sdk.langchain import AlterMCPInterceptor

        interceptor = AlterMCPInterceptor()

        toolkit = MCPToolkit(
            server="https://mcp.example.com",
            interceptor=interceptor,
        )
    """

    def __init__(self) -> None:
        # No vault reference is required — this interceptor only moves
        # headers around. A previous version accepted an ``AlterVault`` but
        # never used it.
        pass

    async def __call__(
        self,
        request: Any,
        handler: Callable[..., Awaitable[Any]],
    ) -> Any:
        """Intercept an MCP tool call request.

        Reads ``user_token`` from the request's runtime context and injects
        it as a bearer header, provided the outbound URL passes the SSRF
        and scheme checks AND the token contains no CRLF bytes. If any
        check fails the request is forwarded WITHOUT the bearer header
        (rather than dropping the request entirely) so a misconfigured
        MCP server URL surfaces as an authentication failure rather than
        a silent connection drop.

        Args:
            request: MCP tool call request.
            handler: Next handler in the chain.

        Returns:
            Result from the handler.
        """
        runtime = getattr(request, "runtime", None)
        if runtime is not None:
            context = getattr(runtime, "context", None)
            if isinstance(context, dict):
                user_token = context.get("user_token")
                if user_token and hasattr(request, "headers"):
                    await self._maybe_inject_bearer(request, user_token)

        return await handler(request)

    async def _maybe_inject_bearer(self, request: Any, user_token: Any) -> None:
        """Validate URL + token and attach the bearer header on success.

        On any validation failure, logs a warning (without the token)
        and leaves the request headers unchanged. The request still
        proceeds — the downstream server will likely return 401, which
        the caller can handle in their normal error path.

        SECURITY: This coroutine is async because ``_validate_url_safety``
        must run DNS resolution on the event loop's executor — calling
        ``socket.getaddrinfo`` synchronously would block the loop for
        the full DNS timeout (typically several seconds) and stall
        every other concurrent tool call in a FastMCP server.
        """
        url = _request_url(request)
        try:
            await _validate_url_safety(url)
        except AlterValueError as e:
            logger.warning(
                "AlterMCPInterceptor refusing to attach bearer (URL rejected): %s",
                e,
            )
            return

        if not isinstance(user_token, str):
            logger.warning(
                "AlterMCPInterceptor refusing to attach bearer: user_token is %s, expected str",
                type(user_token).__name__,
            )
            return

        try:
            safe_token = _validate_header_value(
                user_token,
                header_name="Authorization",
            )
        except AlterValueError as e:
            logger.warning(
                "AlterMCPInterceptor refusing to attach bearer (token rejected): %s",
                e,
            )
            return

        headers = getattr(request, "headers", {}) or {}
        headers["Authorization"] = f"Bearer {safe_token}"
        request.headers = headers

        # Best-effort redirect guard: if the request object exposes a
        # writable ``follow_redirects`` attribute (httpx-style), disable
        # redirects so a malicious MCP server cannot bounce the client
        # to a private IP via ``302 Location``. This is defence-in-depth
        # only — it does not close the DNS TOCTOU gap documented in the
        # class docstring. The attribute is set via ``setattr`` inside a
        # broad ``try`` because the underlying request object is
        # duck-typed ``Any`` across MCP transports; a read-only property
        # or missing attribute must not break the interceptor.
        try:
            if hasattr(request, "follow_redirects"):
                request.follow_redirects = False
        except Exception:  # — cascade-isolated defence-in-depth
            logger.debug(
                "AlterMCPInterceptor could not set follow_redirects=False "
                "on request object (read-only or unsupported attribute)",
            )
