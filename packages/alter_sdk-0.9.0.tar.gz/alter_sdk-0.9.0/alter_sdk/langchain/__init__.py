"""
Alter Vault LangChain/LangGraph Integration.

Provides the @alter_tool() decorator for LangChain tools and
AlterMCPInterceptor for langchain-mcp-adapters.

Usage:
    from alter_sdk import AlterVault
    from alter_sdk.langchain import alter_tool

    vault = AlterVault(api_key="alter_key_...")

    @alter_tool(vault, provider="google", scope=["gmail.readonly"])
    async def list_emails(query: str) -> str:
        # vault.request() is called automatically
        ...

Requires: pip install 'alter-sdk[langchain]'
"""

from alter_sdk.langchain.interceptor import AlterMCPInterceptor
from alter_sdk.langchain.tool_decorator import alter_tool

__all__ = ["alter_tool", "AlterMCPInterceptor"]
