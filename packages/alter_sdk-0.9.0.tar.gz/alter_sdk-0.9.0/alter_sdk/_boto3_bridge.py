"""
Bridge between boto3/botocore and Alter Vault.

Intercepts botocore's ``before-send`` event so every AWS API call
flows through ``vault.request()`` for credential retrieval, SigV4
signing, policy enforcement, and audit logging.

This module is lazily imported by ``AlterVault.boto3_client()`` only
when the user actually calls that method. ``boto3`` and ``botocore``
are NOT required at module level — they are imported inside
``__call__`` to avoid hard-failing when ``boto3`` is not installed.
"""

from __future__ import annotations

import asyncio
from io import BytesIO
from typing import TYPE_CHECKING, Any

from alter_sdk.exceptions import AlterSDKError

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine, Iterator, Mapping
    from typing import Protocol

    import httpx

    class _AWSPreparedRequest(Protocol):
        """Duck-typed protocol for botocore's AWSPreparedRequest.

        Defines the minimal interface the handler needs from the request
        object passed by botocore's ``before-send`` event.  Using a Protocol
        catches attribute mismatches at type-check time rather than runtime.
        """

        url: str
        method: str
        body: bytes | str | bytearray | None
        headers: Mapping[str, str]


# Headers injected by botocore/boto3 that must NOT be forwarded to
# vault.request().  Vault adds its own User-Agent and the amz-sdk-*
# headers are botocore internals irrelevant to the actual AWS call.
# AWS auth headers (authorization, x-amz-date, x-amz-content-sha256,
# x-amz-security-token) are also stripped because vault.request() performs
# its own SigV4 signing — keeping botocore's stale copies would cause
# duplicate/conflicting headers.  "authorization" is stripped as
# defense-in-depth: botocore.UNSIGNED should prevent it from being added,
# but we strip it to guard against misconfiguration.
_STRIPPED_HEADERS = frozenset(
    {
        "amz-sdk-invocation-id",
        "amz-sdk-request",
        "authorization",
        "user-agent",
        "x-amz-date",
        "x-amz-content-sha256",
        "x-amz-security-token",
    },
)


def normalize_body(raw_body: Any) -> bytes | None:
    """Normalize an AWSPreparedRequest body to bytes or None.

    Handles bytes, bytearray, str, and file-like objects (with ``.read()``).
    """
    if isinstance(raw_body, bytes | bytearray):
        return bytes(raw_body)
    if isinstance(raw_body, str):
        return raw_body.encode("utf-8")
    if hasattr(raw_body, "read"):
        return raw_body.read()
    return None


class _MockRawResponse(BytesIO):
    """Minimal raw-response wrapper matching botocore's expectations.

    ``AWSResponse.content`` calls ``self.raw.stream()``, NOT ``.read()``.
    Same pattern moto uses (``MockRawResponse`` in
    ``moto/core/botocore_stubber.py``).
    """

    def __init__(self, content: bytes) -> None:
        super().__init__(content)

    def stream(self, **_kwargs: Any) -> Iterator[bytes]:
        contents = self.read()
        while contents:
            yield contents
            contents = self.read()


class AlterVaultBoto3Handler:
    """Callable registered on botocore's ``before-send`` event.

    Intercepts the fully-serialized ``AWSPreparedRequest`` and routes
    it through ``vault.request()`` instead of botocore's default HTTP
    transport.  Returns an ``AWSResponse`` so botocore can parse the
    response as usual.
    """

    __slots__ = ("_request_fn", "_timeout", "_is_closed_fn", "_loop")

    def __init__(
        self,
        *,
        request_fn: Callable[..., Coroutine[Any, Any, httpx.Response]],
        timeout: float,
        is_closed_fn: Callable[[], bool],
        loop: asyncio.AbstractEventLoop,
    ) -> None:
        self._request_fn = request_fn
        self._timeout = timeout
        self._is_closed_fn = is_closed_fn
        self._loop = loop

    def __call__(self, *, request: _AWSPreparedRequest, **_kwargs: Any) -> Any:
        # Lazy import — only runs when boto3 is installed.
        from botocore.awsrequest import AWSResponse  # type: ignore[reportMissingImports]

        if self._is_closed_fn():
            raise AlterSDKError(
                message="AlterVault instance has been closed. "
                "Create a new AlterVault instance and call boto3_client() again.",
            )

        # --- Extract request details from AWSPreparedRequest ---
        url: str = request.url
        method: str = request.method

        # --- Normalize body ---
        body_bytes = normalize_body(request.body)

        # --- Filter headers ---
        filtered_headers: dict[str, str] = {}
        for key, value in request.headers.items():
            # Case-insensitive check against stripped set.
            if key.lower() not in _STRIPPED_HEADERS:
                filtered_headers[key] = value

        # --- Route through vault.request() ---
        coro = self._request_fn(
            method=method,
            url=url,
            body=body_bytes,
            headers=filtered_headers,
        )

        # Detect stale/closed event loop (e.g., asyncio.run() finished
        # but the boto3 client was retained and reused).
        if self._loop.is_closed():
            coro.close()  # Prevent "coroutine was never awaited" warning
            raise AlterSDKError(
                message="The event loop used to create this boto3 client has been "
                "closed. Create a new AlterVault instance and call boto3_client() "
                "again from a running event loop.",
            )

        # Detect same-thread misuse: if the caller invokes a boto3
        # method directly from the event loop thread (no asyncio.to_thread),
        # future.result() would deadlock — it blocks the thread that the
        # coroutine needs to make progress.
        #
        # In correct usage (asyncio.to_thread worker), _get_current_loop()
        # returns None (worker threads have no running loop), so the
        # equality check is False and execution proceeds.  When called
        # from a *different* event loop in another thread, the loops
        # differ and run_coroutine_threadsafe works correctly.
        #
        # The timeout on future.result() below acts as a safety net: if
        # this guard ever produces a false negative, the call will time
        # out instead of deadlocking forever.
        if self._loop.is_running() and self._loop == _get_current_loop():
            coro.close()  # Prevent "coroutine was never awaited" warning
            raise AlterSDKError(
                message="boto3_client() calls must be run in a separate thread. "
                "Use `await asyncio.to_thread(client.list_objects_v2, Bucket='...')` "
                "or similar.",
            )

        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            response = future.result(timeout=self._timeout)
        except TimeoutError:
            # Best-effort cancellation: prevents the result from being
            # processed if the coroutine hasn't started yet.  For
            # already-running coroutines, the in-flight HTTP request
            # will complete in the background (audit log still fires).
            future.cancel()
            raise AlterSDKError(
                message=f"Alter Vault request timed out after {self._timeout}s. "
                "Consider increasing the timeout parameter in boto3_client().",
            ) from None

        # --- Convert httpx.Response → AWSResponse ---
        return AWSResponse(
            url=url,
            status_code=response.status_code,
            headers=dict(response.headers),
            raw=_MockRawResponse(response.content),
        )


def _get_current_loop() -> asyncio.AbstractEventLoop | None:
    """Return the running event loop for the current thread, or None."""
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        return None
