"""
Internal audit-context ContextVar.

Provides a :class:`contextvars.ContextVar` that framework integration
packages (``alter_sdk.mcp``, ``alter_sdk.langchain``) use to set a
per-tool-call audit context without forcing user functions to accept an
extra keyword argument.

Flow:

1. An integration decorator (e.g. ``@alter.tool()`` or ``@alter_tool()``)
   extracts framework-specific correlation IDs (``run_id``, ``thread_id``,
   ``tool`` name, etc.) and sets :data:`_alter_context_var` via a
   ``ContextVar.set()`` call inside its wrapper.
2. The wrapped user function calls ``vault.request(...)`` normally — it
   does NOT need to accept or forward any ``_alter_context`` kwarg.
3. ``AlterVault.request`` checks :func:`get_current_audit_context` when
   the caller did not pass an explicit ``context=``. If the ContextVar is
   set, its value is used as the audit context for that request.
4. ``contextvars.ContextVar`` is copy-on-write per asyncio Task, so
   concurrent tool calls (e.g. under ``asyncio.gather``) each see their
   own isolated audit context.

Users who pass ``context=`` explicitly to ``vault.request`` always win —
the ContextVar is only consulted as a fallback when ``context is None``.
"""

from __future__ import annotations

from contextvars import ContextVar

# The ContextVar holds the audit-context dict set by the most recent
# integration-package decorator on the current asyncio Task. Default is
# None, meaning "no decorator-provided context — fall through to whatever
# the caller passes (or None) to vault.request()".
_alter_context_var: ContextVar[dict[str, str] | None] = ContextVar(
    "alter_sdk_alter_context",
    default=None,
)


def get_current_audit_context() -> dict[str, str] | None:
    """Return the decorator-set audit context for the current Task, if any.

    Returns a shallow copy so callers cannot mutate the ContextVar value
    by accident. Returns ``None`` when no decorator has set a context.
    """
    value = _alter_context_var.get()
    if value is None:
        return None
    return dict(value)
