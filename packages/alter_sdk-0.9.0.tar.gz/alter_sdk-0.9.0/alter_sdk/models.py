"""
Pydantic models for Alter SDK.

These models provide type-safe data structures with validation.
"""

from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TokenResponse access token storage uses object.__setattr__ to set a
# private `_access_token` attribute on each frozen Pydantic instance.
# This avoids the id()-reuse hazard of a module-level dict keyed by
# id(instance): Python may recycle id() values after GC, causing a new
# instance to silently lose its token when an old __del__ fires.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TokenResponse(BaseModel):
    """
    OAuth token response from Alter Vault.

    This represents an access token retrieved from the backend.

    Security:
        - frozen=True prevents mutation after creation
        - access_token is NOT stored as a readable attribute — it lives in
          module-private _token_store
        - toJSON/model_dump exclude access token from serialization

    Note: The active token flow in client.py does NOT construct TokenResponse.
    __get_token() returns a raw (auth_header, grant_id) tuple instead.
    This model is retained as a public API type for consumers.
    """

    model_config = ConfigDict(frozen=True)

    token_type: str = Field(default="Bearer", description="Token type (usually Bearer)")
    expires_in: int | None = Field(None, description="Seconds until token expires")
    expires_at: datetime | None = Field(None, description="Absolute expiration time")
    scopes: list[str] = Field(default_factory=list, description="OAuth scopes granted")
    grant_id: str = Field(
        ...,
        description="Grant ID that provided this token",
    )
    provider_id: str | None = Field(default=None, description="Provider ID (google, github, etc.)")
    injection_header: str = Field(
        default="Authorization",
        exclude=True,
        description="HTTP header name for credential injection",
    )
    injection_format: str = Field(
        default="Bearer {token}",
        exclude=True,
        description="Header value format with {token} placeholder",
    )
    additional_credentials: dict[str, str] | None = Field(
        default=None,
        exclude=True,
        description="Extra credentials for multi-part auth (e.g. AWS SigV4)",
    )
    additional_injections: list[dict[str, str]] | None = Field(
        default=None,
        exclude=True,
        description="Additional injection rules for multi-header or query param auth",
    )

    def __init__(self, *, access_token: str, **kwargs: Any) -> None:
        """
        Create a TokenResponse.

        SECURITY: access_token is accepted as a constructor parameter but NOT
        stored as a Pydantic field. It is stored via object.__setattr__ on the
        frozen instance so it cannot be accessed as a normal attribute, and is
        excluded from repr/serialization.
        """
        super().__init__(**kwargs)
        object.__setattr__(self, "_access_token", access_token)

    def __repr__(self) -> str:
        """Exclude access token from repr output."""
        return (
            f"TokenResponse(token_type={self.token_type!r}, "
            f"grant_id={self.grant_id!r}, "
            f"expires_at={self.expires_at!r}, "
            f"scopes={self.scopes!r})"
        )

    def __str__(self) -> str:
        return self.__repr__()

    @field_validator("expires_at", mode="before")
    @classmethod
    def parse_expires_at(cls, v: Any) -> datetime | None:
        """Parse expires_at from ISO string if needed."""
        if v is None:
            return None
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            # Parse ISO format
            dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
            # Ensure timezone aware
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt
        return v  # type: ignore[return-value]

    def is_expired(self, buffer_seconds: int = 0) -> bool:
        """
        Check if token is expired.

        Args:
            buffer_seconds: Consider token expired N seconds before actual expiry.
                           Useful for preventing race conditions.

        Returns:
            True if token is expired or will expire within buffer_seconds.
        """
        if self.expires_at is None:
            # No expiration time means token doesn't expire
            return False

        now = datetime.now(UTC)
        # Make expires_at timezone-aware if needed
        expires_at = self.expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=UTC)

        # Check if expired with buffer
        return expires_at <= now + timedelta(seconds=buffer_seconds)

    def needs_refresh(self, buffer_seconds: int = 300) -> bool:
        """
        Check if token should be refreshed soon.

        Args:
            buffer_seconds: Consider token needing refresh N seconds before expiry.
                           Default 5 minutes (300 seconds).

        Returns:
            True if token will expire within buffer_seconds.
        """
        return self.is_expired(buffer_seconds=buffer_seconds)


class GrantInfo(BaseModel):
    """
    OAuth grant info from Alter Vault.

    Represents a granted OAuth service (e.g., Google, GitHub).
    Returned by list_grants(). Contains metadata only — no tokens.
    """

    model_config = ConfigDict(frozen=True)

    grant_id: str
    provider_id: str
    scopes: list[str] = Field(default_factory=list)
    account_identifier: str | None = None
    account_display_name: str | None = None
    status: str
    scope_mismatch: bool = False
    expires_at: str | None = None
    created_at: str
    last_used_at: str | None = None


class ConnectSession(BaseModel):
    """
    Connect session for initiating OAuth flows.

    Returned by create_connect_session(). Contains a URL the user
    opens in their browser to authorize access.
    """

    model_config = ConfigDict(frozen=True)

    session_token: str
    connect_url: str
    expires_in: int
    expires_at: str


class GrantListResult(BaseModel):
    """
    Paginated list of grants.

    Returned by list_grants(). Contains grant array plus pagination metadata.
    """

    model_config = ConfigDict(frozen=True)

    grants: list[GrantInfo]
    total: int
    limit: int
    offset: int
    has_more: bool


class RevokeGrantResult(BaseModel):
    """
    Result of revoking an OAuth grant.

    Returned by revoke_grant(). Confirms the revocation was successful.
    """

    model_config = ConfigDict(frozen=True)

    success: bool
    message: str
    grant_id: str
    revoked_at: str


class GrantPolicy(BaseModel):
    """Per-grant policy (e.g., TTL expiry)."""

    model_config = ConfigDict(frozen=True)

    expires_at: str | None = Field(None, description="Hard expiry timestamp (ISO 8601 UTC)")
    created_by: str | None = Field(
        None,
        description="Who set the policy: 'developer' or 'end_user'",
    )
    created_at: str | None = Field(None, description="When the policy was set (ISO 8601 UTC)")


class ConnectResult(BaseModel):
    """
    Result of a headless connect() flow.

    Returned by connect() after the user completes OAuth in the browser.
    Contains the grant metadata (no tokens — use request() with
    the grant_id to make authenticated API calls).
    """

    model_config = ConfigDict(frozen=True)

    grant_id: str = Field(..., description="UUID of the created OAuth grant")
    provider_id: str = Field(..., description="Provider ID (e.g., 'google')")
    account_identifier: str | None = Field(
        None,
        description="Account email or username",
    )
    scopes: list[str] = Field(default_factory=list, description="OAuth scopes granted")
    grant_policy: GrantPolicy | None = Field(
        None,
        description="Per-grant policy (e.g., TTL expiry)",
    )


class AuthResult(BaseModel):
    """
    Result of an authenticate() flow.

    Returned by authenticate() after the user completes IDP login in the browser.
    Contains the user_token (IDP JWT) that the SDK uses for subsequent
    identity-based request() calls.
    """

    model_config = ConfigDict(frozen=True)

    user_token: str = Field(..., description="IDP JWT bearer token for identity resolution")
    user_info: dict[str, Any] = Field(
        default_factory=dict,
        description="User info from IDP (sub, email, name)",
    )


class APICallAuditLog(BaseModel):
    """
    Audit log entry for an API call to a provider.

    This is sent to the backend audit endpoint.
    """

    grant_id: UUID
    provider_id: str
    method: str  # GET, POST, PUT, DELETE, etc.
    url: str
    request_headers: dict[str, str] | None = None
    request_body: Any | None = None
    response_status: int
    response_headers: dict[str, str] | None = None
    response_body: Any | None = None
    latency_ms: int
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        exclude=True,
    )
    reason: str | None = None
    context: dict[str, str] | None = None

    def sanitize(self) -> dict[str, Any]:
        """
        Sanitize sensitive data before sending.

        Removes Authorization headers, cookies, etc.
        """
        sensitive_headers = {
            "authorization",
            "cookie",
            "set-cookie",
            "x-api-key",
            "x-auth-token",
            "x-amz-date",
            "x-amz-content-sha256",
            "x-amz-security-token",
        }

        # Use mode='json' to ensure UUIDs and datetimes are serialized
        sanitized = self.model_dump(mode="json")

        # Sanitize request headers
        if sanitized.get("request_headers"):
            sanitized["request_headers"] = {
                k: v
                for k, v in sanitized["request_headers"].items()
                if k.lower() not in sensitive_headers
            }

        # Sanitize response headers
        if sanitized.get("response_headers"):
            sanitized["response_headers"] = {
                k: v
                for k, v in sanitized["response_headers"].items()
                if k.lower() not in sensitive_headers
            }

        return sanitized
