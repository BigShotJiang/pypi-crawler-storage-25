"""
AWS Signature Version 4 signing for Alter Vault SDK.

Pure Python implementation using only stdlib (hashlib, hmac, datetime, urllib.parse).
No AWS SDK dependency required.

Reference: https://docs.aws.amazon.com/general/latest/gr/sigv4_signing.html
"""

from __future__ import annotations

import hashlib
import hmac
import re
from datetime import UTC, datetime
from urllib.parse import quote, unquote, urlparse

# AWS SigV4 constants
_ALGORITHM = "AWS4-HMAC-SHA256"

# Regex to extract region and service from AWS endpoint hostnames.
# Matches patterns like:
#   s3.us-east-1.amazonaws.com        → service=s3, region=us-east-1
#   lambda.eu-west-1.amazonaws.com    → service=lambda, region=eu-west-1
#   bedrock-runtime.us-east-1.amazonaws.com → service=bedrock-runtime, region=us-east-1
_AWS_HOST_RE = re.compile(
    r"^(?P<service>[a-z0-9-]+)\.(?P<region>[a-z]{2}(?:-[a-z0-9]+)+-\d+)\.amazonaws\.com$",
)

# S3 has a special virtual-hosted-style pattern:
#   bucket.s3.us-east-1.amazonaws.com
_S3_VIRTUAL_HOST_RE = re.compile(
    r"^[^.]+\.s3\.(?P<region>[a-z]{2}(?:-[a-z0-9]+)+-\d+)\.amazonaws\.com$",
)

# PrivateLink VPC endpoint pattern:
#   vpce-099deb00b40f00e22-lj2wisx3.monitoring.us-east-2.vpce.amazonaws.com  (regional)
#   vpce-099deb00b40f00e22-lj2wisx3-us-east-2c.monitoring.us-east-2.vpce.amazonaws.com  (zonal)
_VPCE_HOST_RE = re.compile(
    r"^vpce-[a-z0-9-]+\.(?P<service>[a-z0-9-]+)\.(?P<region>[a-z]{2}(?:-[a-z0-9]+)+-\d+)\.vpce\.amazonaws\.com$",
)


def _detect_service_and_region(hostname: str) -> tuple[str | None, str | None]:
    """Auto-detect AWS service and region from the request hostname.

    Returns (service, region) or (None, None) if detection fails.
    """
    hostname = hostname.lower()

    # Standard pattern: service.region.amazonaws.com
    m = _AWS_HOST_RE.match(hostname)
    if m:
        return m.group("service"), m.group("region")

    # S3 virtual-hosted-style: bucket.s3.region.amazonaws.com
    m = _S3_VIRTUAL_HOST_RE.match(hostname)
    if m:
        return "s3", m.group("region")

    # PrivateLink VPC endpoint: vpce-xxx.service.region.vpce.amazonaws.com
    m = _VPCE_HOST_RE.match(hostname)
    if m:
        return m.group("service"), m.group("region")

    return None, None


def _hmac_sha256(key: bytes, message: str) -> bytes:
    """HMAC-SHA256 helper."""
    return hmac.new(key, message.encode("utf-8"), hashlib.sha256).digest()


def _sha256_hex(data: bytes) -> str:
    """SHA-256 hex digest."""
    return hashlib.sha256(data).hexdigest()


def _derive_signing_key(
    secret_key: str,
    date_stamp: str,
    region: str,
    service: str,
) -> bytes:
    """Derive the SigV4 signing key via 4-step HMAC chain.

    SigningKey = HMAC-SHA256(
        HMAC-SHA256(
            HMAC-SHA256(
                HMAC-SHA256("AWS4" + secret, date),
                region),
            service),
        "aws4_request")
    """
    k_date = _hmac_sha256(("AWS4" + secret_key).encode("utf-8"), date_stamp)
    k_region = _hmac_sha256(k_date, region)
    k_service = _hmac_sha256(k_region, service)
    return _hmac_sha256(k_service, "aws4_request")


def _canonical_uri(path: str) -> str:
    """URI-encode path components per SigV4 rules.

    Each path segment is URI-encoded once. Non-S3 services technically
    require double-encoding, but single-encoding works for the vast
    majority of real-world paths (those without %-encoded characters).
    """
    if not path:
        return "/"
    # Normalize: ensure leading slash
    if not path.startswith("/"):
        path = "/" + path
    # URI-encode each segment (preserving /)
    segments = path.split("/")
    return "/".join(quote(seg, safe="~") for seg in segments)


def _canonical_query_string(query: str) -> str:
    """Sort and URI-encode query parameters per SigV4 rules.

    Uses manual splitting instead of ``parse_qs`` because the latter
    decodes ``+`` as a space (HTML form convention), whereas SigV4
    requires ``+`` to stay encoded as ``%2B``.
    """
    if not query:
        return ""
    # Split on & then = manually to avoid parse_qs treating + as space
    pairs: list[tuple[str, str]] = []
    for part in query.split("&"):
        if "=" in part:
            k, v = part.split("=", 1)
        else:
            k, v = part, ""
        pairs.append((quote(unquote(k), safe="~"), quote(unquote(v), safe="~")))
    pairs.sort()
    return "&".join(f"{k}={v}" for k, v in pairs)


def _canonical_headers_and_signed(
    headers: dict[str, str],
) -> tuple[str, str]:
    """Build canonical headers string and signed headers list.

    Returns (canonical_headers_string, signed_headers_string).
    """
    # Lowercase header names, trim values, sort
    canonical = {}
    for name, value in headers.items():
        lower_name = name.lower().strip()
        # Collapse whitespace in values
        trimmed_value = " ".join(value.split())
        canonical[lower_name] = trimmed_value

    sorted_names = sorted(canonical.keys())
    canonical_str = "".join(f"{name}:{canonical[name]}\n" for name in sorted_names)
    signed_str = ";".join(sorted_names)
    return canonical_str, signed_str


def sign_aws_request(
    method: str,
    url: str,
    headers: dict[str, str],
    body: bytes | None = None,
    *,
    access_key_id: str,
    secret_key: str,
    region: str | None = None,
    service: str | None = None,
    timestamp: datetime | None = None,
) -> dict[str, str]:
    """Compute AWS SigV4 headers for an HTTP request.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        url: Full request URL (https://s3.us-east-1.amazonaws.com/bucket/key)
        headers: Existing request headers (Host will be added if missing)
        body: Request body bytes (None for GET requests)
        access_key_id: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region fallback for non-AWS hostnames (auto-detected
            from URL takes precedence for recognized AWS endpoints)
        service: AWS service fallback for non-AWS hostnames (auto-detected
            from URL takes precedence for recognized AWS endpoints)
        timestamp: Override timestamp for testing (defaults to UTC now)

    Returns:
        Dict of headers to merge into the request:
        - Authorization: Full SigV4 authorization header
        - x-amz-date: ISO 8601 timestamp
        - x-amz-content-sha256: SHA-256 of request body
    """
    parsed = urlparse(url)
    hostname = parsed.hostname or ""

    # Auto-detect service and region from URL — detected values take
    # precedence because the URL reflects the actual AWS service being
    # called.  Explicit values are used only as fallback for custom
    # endpoints where auto-detection fails.  This matters because a
    # single AWS access key may be used across multiple services (S3,
    # CloudWatch, Lambda, etc.) and the signing service MUST match the
    # target endpoint.
    detected_service, detected_region = _detect_service_and_region(hostname)
    if detected_region is not None:
        region = detected_region
    if detected_service is not None:
        service = detected_service

    if not region:
        raise ValueError(
            f"Cannot determine AWS region from URL '{url}'. "
            "Pass region explicitly via additional_credentials.",
        )
    if not service:
        raise ValueError(
            f"Cannot determine AWS service from URL '{url}'. "
            "Pass service explicitly via additional_credentials.",
        )

    # Timestamp
    if timestamp is None:
        timestamp = datetime.now(UTC)
    amz_date = timestamp.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = timestamp.strftime("%Y%m%d")

    # Payload hash
    payload_hash = _sha256_hex(body or b"")

    # Build headers to sign (must include host and x-amz-date)
    headers_to_sign: dict[str, str] = {}
    # Add Host if not already present
    if not any(k.lower() == "host" for k in headers):
        port = parsed.port
        if port and port not in (80, 443):
            headers_to_sign["host"] = f"{hostname}:{port}"
        else:
            headers_to_sign["host"] = hostname
    else:
        for k, v in headers.items():
            if k.lower() == "host":
                headers_to_sign["host"] = v
                break

    headers_to_sign["x-amz-date"] = amz_date
    headers_to_sign["x-amz-content-sha256"] = payload_hash

    # Build canonical request
    canonical_uri_str = _canonical_uri(parsed.path)
    canonical_qs = _canonical_query_string(parsed.query)
    canonical_headers_str, signed_headers = _canonical_headers_and_signed(headers_to_sign)

    canonical_request = (
        f"{method.upper()}\n"
        f"{canonical_uri_str}\n"
        f"{canonical_qs}\n"
        f"{canonical_headers_str}\n"
        f"{signed_headers}\n"
        f"{payload_hash}"
    )

    # String to sign
    credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = (
        f"{_ALGORITHM}\n"
        f"{amz_date}\n"
        f"{credential_scope}\n"
        f"{_sha256_hex(canonical_request.encode('utf-8'))}"
    )

    # Signing key and signature
    signing_key = _derive_signing_key(secret_key, date_stamp, region, service)
    signature = hmac.new(
        signing_key,
        string_to_sign.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    # Authorization header
    authorization = (
        f"{_ALGORITHM} "
        f"Credential={access_key_id}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, "
        f"Signature={signature}"
    )

    return {
        "Authorization": authorization,
        "x-amz-date": amz_date,
        "x-amz-content-sha256": payload_hash,
    }
