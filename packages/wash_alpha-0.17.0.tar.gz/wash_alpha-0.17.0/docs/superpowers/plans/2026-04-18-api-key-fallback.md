# API Key Fallback Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the Anthropic API key optional by falling back to hardcoded schemas for known brokers during CSV import.

**Architecture:** We will introduce a static dictionary of known CSV schemas mapped by broker name. The import orchestrator will check this dictionary before demanding an Anthropic API key to detect the schema dynamically.

**Tech Stack:** Python, Typer, SQLModel, pytest

---

### Task 1: Add Known Schemas to Schema Detection

**Files:**
- Modify: `src/net_alpha/import_/schema_detection.py`
- Create: `tests/import_/test_schema_detection.py` (or modify existing)

- [ ] **Step 1: Write the failing test**

```python
# tests/import_/test_schema_detection.py
from net_alpha.import_.schema_detection import KNOWN_BROKER_SCHEMAS, SchemaMapping

def test_known_broker_schemas_exist():
    assert "schwab" in KNOWN_BROKER_SCHEMAS
    assert "robinhood" in KNOWN_BROKER_SCHEMAS

    schwab = KNOWN_BROKER_SCHEMAS["schwab"]
    assert isinstance(schwab, SchemaMapping)
    assert schwab.date == "Date"
    assert schwab.ticker == "Symbol"

    rh = KNOWN_BROKER_SCHEMAS["robinhood"]
    assert isinstance(rh, SchemaMapping)
    assert rh.date == "Activity Date"
    assert rh.ticker == "Instrument"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/import_/test_schema_detection.py -v`
Expected: FAIL with "ImportError: cannot import name 'KNOWN_BROKER_SCHEMAS'"

- [ ] **Step 3: Write minimal implementation**

```python
# src/net_alpha/import_/schema_detection.py
# Add to the bottom of the file:

KNOWN_BROKER_SCHEMAS: dict[str, SchemaMapping] = {
    "schwab": SchemaMapping(
        date="Date",
        ticker="Symbol",
        action="Action",
        quantity="Quantity",
        proceeds="Amount",
        cost_basis="Cost Basis",
        buy_values=["Buy", "Reinvest"],
        sell_values=["Sell"],
        option_format="schwab_human",
    ),
    "robinhood": SchemaMapping(
        date="Activity Date",
        ticker="Instrument",
        action="Trans Code",
        quantity="Quantity",
        proceeds="Amount",
        cost_basis=None,  # Robinhood doesn't provide cost basis in standard export
        buy_values=["Buy"],
        sell_values=["Sell"],
        option_format="robinhood_human",
    ),
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/import_/test_schema_detection.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/schema_detection.py tests/import_/test_schema_detection.py
git commit -m "feat(import): add hardcoded schemas for schwab and robinhood"
```

---

### Task 2: Refactor Importer to use Fallback

**Files:**
- Modify: `src/net_alpha/import_/importer.py`
- Modify: `tests/import_/test_integration.py` (if applicable)

- [ ] **Step 1: Write the failing test**

```python
# tests/import_/test_importer_fallback.py
import pytest
from pathlib import Path
from net_alpha.import_.importer import ImportContext, run_import
from net_alpha.db.repository import TradeRepository, SchemaCacheRepository
from net_alpha.db.connection import get_engine
from sqlmodel import Session

def test_run_import_uses_fallback_no_api_key(tmp_path):
    # Setup dummy db
    engine = get_engine("sqlite:///:memory:")
    # Create tables (assuming a create_all function exists, or mock repos)
    from net_alpha.db.tables import SQLModel
    SQLModel.metadata.create_all(engine)
    
    session = Session(engine)
    
    # Create dummy csv
    csv_file = tmp_path / "schwab.csv"
    csv_file.write_text("Date,Symbol,Action,Quantity,Amount,Cost Basis\n10/15/2024,TSLA,Buy,10,2400.00,2400.00")
    
    ctx = ImportContext(
        csv_path=csv_file,
        broker_name="schwab",
        anthropic_client=None, # NO API KEY
        model="claude-3-5-sonnet-20240620",
        max_retries=1,
        confirm_schema=lambda *args: True,
        trade_repo=TradeRepository(session),
        schema_cache_repo=SchemaCacheRepository(session),
        session=session
    )
    
    result = run_import(ctx)
    assert result.new_imported == 1
    assert result.equities == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/import_/test_importer_fallback.py -v`
Expected: FAIL because `run_import` will try to call `ctx.anthropic_client.messages.create` which is `None`.

- [ ] **Step 3: Write minimal implementation**

Modify `src/net_alpha/import_/importer.py`.

Update `ImportContext`:
```python
# Change type hint in ImportContext:
    anthropic_client: object | None  # Anthropic client instance
```

Update `run_import`:
```python
# In run_import, after checking cache:
    cached = ctx.schema_cache_repo.find_by_broker_and_hash(ctx.broker_name, header_hash)
    if cached is not None:
        mapping = SchemaMapping(**json.loads(cached.column_mapping))
        schema_cache_id = cached.id
    else:
        from net_alpha.import_.schema_detection import KNOWN_BROKER_SCHEMAS
        
        if ctx.broker_name in KNOWN_BROKER_SCHEMAS:
            # Use hardcoded fallback
            mapping = KNOWN_BROKER_SCHEMAS[ctx.broker_name]
            schema_cache_id = None # Don't cache hardcoded schemas
        else:
            # Require AI
            if not ctx.anthropic_client:
                raise RuntimeError(
                    f"We don't have a built-in schema for '{ctx.broker_name}'. "
                    "To import this file, you must set an ANTHROPIC_API_KEY so the AI can analyze it."
                )

            # Anonymize samples before LLM call
            anon_samples = [anonymize_row(row) for row in raw_samples]
            
            # ... rest of LLM call ...
            # User confirmation
            examples = _extract_examples(mapping, raw_samples)
            if not ctx.confirm_schema(mapping, headers, examples):
                return ImportResult(0, 0, 0, 0, 0, 0)
            
            # ... cache the detected schema ...
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/import_/test_importer_fallback.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/importer.py tests/import_/test_importer_fallback.py
git commit -m "feat(import): run_import uses hardcoded schema if cache misses and no API key"
```

---

### Task 3: Make API Key Optional in Import CLI

**Files:**
- Modify: `src/net_alpha/cli/import_cmd.py`

- [ ] **Step 1: Write the failing test**

(Since CLI tests often require more complex mocking of rich consoles, we will focus on direct implementation and manual verification, but write a basic test if a CLI test suite exists).
Assuming `tests/cli/test_import_cmd.py` exists.

```python
# tests/cli/test_import_cmd.py
from typer.testing import CliRunner
from net_alpha.cli.app import app # or wherever the main app is

runner = CliRunner()

def test_import_command_without_api_key(mocker, tmp_path):
    # Mock settings to return None for API key
    mocker.patch("net_alpha.cli.app._bootstrap", return_value=(mocker.Mock(anthropic_api_key=None, anthropic_model="x", llm_max_retries=1), mocker.Mock()))
    
    # Mock run_import to return a dummy result
    from net_alpha.import_.importer import ImportResult
    mocker.patch("net_alpha.cli.import_cmd.run_import", return_value=ImportResult(1,1,0,1,0,0))

    csv_file = tmp_path / "schwab.csv"
    csv_file.write_text("Date,Symbol,Action,Quantity,Amount,Cost Basis\n10/15/2024,TSLA,Buy,10,2400.00,2400.00")
    
    result = runner.invoke(app, ["import", "schwab", str(csv_file)])
    assert result.exit_code == 0
    assert "Imported 1 trades" in result.stdout
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/cli/test_import_cmd.py -v`
Expected: FAIL. The command will print "ANTHROPIC_API_KEY not set" and exit with code 1.

- [ ] **Step 3: Write minimal implementation**

Modify `src/net_alpha/cli/import_cmd.py`.

```python
    # Resolve API key (optional at startup; only required for new schemas)
    api_key = settings.anthropic_api_key
    client = None
    if api_key:
        from anthropic import Anthropic
        client = Anthropic(api_key=api_key)

    ctx = ImportContext(
        csv_path=file,
        broker_name=broker.lower(),
        anthropic_client=client,
        model=settings.anthropic_model,
        max_retries=settings.llm_max_retries,
        confirm_schema=_confirm_schema,
        trade_repo=TradeRepository(session),
        schema_cache_repo=SchemaCacheRepository(session),
        session=session,
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/cli/test_import_cmd.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/import_cmd.py tests/cli/test_import_cmd.py
git commit -m "feat(cli): make API key optional for import command"
```

---

### Task 4: Remove Eager API Key Prompt from Wizard

**Files:**
- Modify: `src/net_alpha/cli/wizard.py`

- [ ] **Step 1: Write the failing test**

*(No strict test required for wizard prompt removal, but we will verify the code).*

- [ ] **Step 2: Write minimal implementation**

Modify `src/net_alpha/cli/wizard.py`.

Remove the `_ensure_api_key(settings)` call from `run_wizard`.

```python
def run_wizard(settings: Settings) -> None:
    """Main interactive wizard mode."""
    console.print()
    console.print("  [bold]net-alpha Interactive Wizard[/bold]")
    console.print()

    # REMOVED: _ensure_api_key(settings)

    while True:
```

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/cli/wizard.py
git commit -m "feat(cli): remove eager api key prompt from interactive wizard"
```
