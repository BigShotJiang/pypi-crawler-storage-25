# Phase 3 — Sim BUY support + Detail page enhancements Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Land Phase 3 of the UI/UX redesign — extend the Sim page to support a unified BUY/SELL what-if planner backed by a new `simulate_buy()` engine function, and upgrade the Detail page with a totals bar, group-by-ticker collapsible rows, and new Lag + Source columns.

**Architecture:** Pure-function additions to the engine (`simulate_buy` alongside `simulate_sell` in `engine/simulator.py`); thin web routes that dispatch on the `action` form field; pure-function aggregations on the detail page (totals + grouping); template updates with Alpine for collapse state. No new dependencies, no schema changes.

**Tech Stack:** Python 3.11+, Pydantic v2, FastAPI + Jinja2 + HTMX + Alpine, pytest + factory_boy. Follows existing `simulate_sell` patterns and the per-page toolbar / fragment-swap conventions documented in CLAUDE.md.

**Spec deviation:** The design doc names `engine/sim.py` for the two pure functions. To minimise churn (3 callers, no semantic change), this plan keeps the existing `engine/simulator.py` filename and adds `simulate_buy()` next to `simulate_sell()`. If a follow-up wants to rename the module, that's a one-line rename — orthogonal to behaviour.

---

## File Map

**Created:**
- `tests/engine/test_simulate_buy.py` — unit tests for the new buy-side simulator
- `src/net_alpha/web/templates/_sim_buy_result.html` — buy-side result partial
- `src/net_alpha/web/templates/_sim_sell_result.html` — sell-side result partial (renamed from `_sim_result.html`)
- `tests/web/test_sim_buy_routes.py` — web route tests for buy dispatch
- `tests/web/test_detail_enhancements.py` — totals + grouping + Lag/Source render tests

**Modified:**
- `src/net_alpha/models/domain.py` — add `SimBuyMatch` and `SimulationBuyOption`
- `src/net_alpha/engine/simulator.py` — add `simulate_buy()`
- `src/net_alpha/web/routes/sim.py` — POST /sim dispatches on `action` form field; GET /sim passes default date
- `src/net_alpha/web/templates/sim.html` — segmented Action control + Date field; renamed heading
- `src/net_alpha/web/routes/detail.py` — compute totals, grouped buckets, lag, source label
- `src/net_alpha/web/templates/detail.html` — embed totals bar, switch to grouped table partial
- `src/net_alpha/web/templates/_detail_table.html` — totals bar + collapsible per-ticker rows + Lag + Source columns

**Deleted:**
- `src/net_alpha/web/templates/_sim_result.html` — replaced by `_sim_sell_result.html`

**Untouched (callers of `_sim_result.html` or `simulate_sell` updated, not renamed):**
- `src/net_alpha/cli/sim.py` — keeps using `simulate_sell` (CLI sim is sell-only and out of scope)
- `tests/engine/test_simulator.py` — existing sell-sim tests keep passing
- `tests/web/test_sim_routes.py` — existing sell-sim route tests keep passing (the existing POST `/sim` body without an `action` field defaults to "sell" — see Task 7)

---

## Sim BUY semantics

`simulate_buy(ticker, qty, price, account, date, accounts, recent_trades, etf_pairs)` returns one `SimulationBuyOption` per candidate buy account.

A candidate match is an unmatched **loss sale** of `ticker` (or a substantially-identical ETF pair) whose sale date falls in `[date - 30 days, date - 1 day]` (strictly before; same-day is not a wash trigger because the buy on day D doesn't pre-exist when a same-day sell happens).

> **Note on look-back range:** The IRS wash-sale window is 30 days *before or after* the loss sale. For `simulate_buy`, the proposed buy is the candidate replacement, so we look at loss sales already on the books in the 30-day **before** window: `loss_sale.date in [proposed_buy.date - 30, proposed_buy.date]`. We include the same-day boundary (`-30 ≤ delta ≤ 0`) because a sale on the morning followed by a buy on the afternoon of the same calendar day is a wash sale per Pub 550. A delta of `+1` (sale after the proposed buy) is out of scope here — that case is `simulate_sell`'s job.

For each candidate loss sale, the disallowed-loss allocation per FIFO:
- `matched_qty = min(loss_sell_qty, remaining_buy_qty)`
- `disallowed_loss = loss_amount(loss_sale) * (matched_qty / loss_sell_qty)`
- `remaining_buy_qty -= matched_qty`
- Stop when `remaining_buy_qty == 0`

The proposed lot's `adjusted_basis = qty * price + sum(disallowed_loss for matches)`.

Confidence per match comes from `get_match_confidence(loss_sale, hypothetical_buy, etf_pairs)`. If the loss sale is on a different ticker (ETF pair), confidence is `Unclear`; same-ticker equities are `Confirmed`.

"Unmatched" means the loss sale does not appear as `loss_trade_id` on any existing `WashSaleViolation`. (If a real buy already triggered a wash sale on this loss, the proposed buy can't disallow the same loss again.)

---

## Detail page semantics

**Totals bar:** Rendered above the table after filters apply. Format:
```
3 violations · $1,840 disallowed · 1 confirmed · 2 probable · 0 unclear
```
Reflects the currently filtered violations (NOT all-time totals).

**Group-by-ticker:** Top-level rows are tickers. Each top-level row shows: `▸/▾ TICKER · N violations · $sum disallowed`. Click toggles expansion; expanded body is a nested table of individual violation rows (existing column set + new Lag + Source columns).

Default state: collapsed when distinct ticker count > 5; expanded otherwise. Implemented with Alpine `x-data` per top-level row + `x-init` reading a server-supplied default.

**Lag column:** `(triggering_buy_date - loss_sale_date).days` formatted as e.g. `12d`. If either date is missing, render `—`. Sortable in v1 means: column header is a link that toggles `?sort=lag&order=asc|desc`. Server-side sort applied before grouping.

**Source column:** Maps from the `WashSaleViolation.source` field plus account comparison:
- `source == "schwab_g_l"` → badge "Schwab" (slate)
- `source == "engine"` and `loss_account != buy_account` → badge "Cross-account" (amber)
- otherwise → badge "Engine" (blue)

---

## Self-Review (post-write)

After all 12 tasks below are written, the author skimmed the spec sections "Sim — combined trade what-if" and "Detail page enhancements". Coverage map:

| Spec requirement | Task |
|---|---|
| Action segmented control (BUY/SELL) | T6 |
| Ticker / Qty / Price / Account / Date fields | T6 |
| `simulate_sell` retained, same shape | (untouched — re-exported) |
| `simulate_buy` returning matches + adjusted basis | T2, T3 |
| POST /sim dispatches on action | T7 |
| `_sim_buy_result.html` / `_sim_sell_result.html` | T6, T7 |
| Boundary tests day 0/30/31 | T4 |
| ETF pair triggering test | T5 |
| Detail totals bar | T9, T11, T12 |
| Group-by-ticker collapsible | T10, T11, T12 |
| Default collapsed when ticker count > 5 | T11, T12 |
| Lag column sortable | T11, T12 |
| Source column badge | T11, T12 |

All spec items map to a task. No placeholders remain. Type names (`SimBuyMatch`, `SimulationBuyOption`) used in T6/T7 templates match the definitions in T2.

---

## Task 1: Sanity baseline

**Files:** none

- [ ] **Step 1.1: Confirm clean baseline**

Run: `uv run pytest --deselect tests/cli/test_ui.py::test_pick_free_port_skips_busy_ports -q`
Expected: 331 passed, 1 skipped, 1 deselected.

The `test_pick_free_port_skips_busy_ports` test is environmentally flaky (depends on port 8765 being free); deselecting it is the documented Phase 2 workaround. Keep using `--deselect` for that test throughout this plan.

---

## Task 2: SimBuyMatch + SimulationBuyOption domain models

**Files:**
- Modify: `src/net_alpha/models/domain.py:213` (append after existing `SimulationOption`)

- [ ] **Step 2.1: Append two new Pydantic models**

Add at the very end of `src/net_alpha/models/domain.py`:

```python
class SimBuyMatch(BaseModel):
    """One pre-existing loss sale that the proposed buy would wash-trigger."""

    loss_trade_id: str
    loss_sale_date: date
    loss_account: str
    loss_ticker: str
    matched_quantity: Decimal
    disallowed_loss: Decimal
    confidence: str  # "Confirmed" | "Probable" | "Unclear"


class SimulationBuyOption(BaseModel):
    """One scenario in `sim`'s buy output: 'buy in this account'."""

    account: Account
    matches: list[SimBuyMatch]
    total_disallowed: Decimal
    proposed_basis: Decimal       # qty * price (raw cost basis pre-adjustment)
    adjusted_basis: Decimal       # proposed_basis + total_disallowed
    clean: bool                   # True iff matches == []
```

- [ ] **Step 2.2: Verify imports compile**

Run: `uv run python -c "from net_alpha.models.domain import SimBuyMatch, SimulationBuyOption; print('OK')"`
Expected: prints `OK` with no exception.

- [ ] **Step 2.3: Commit**

```bash
git add src/net_alpha/models/domain.py
git commit -m "feat(domain): add SimBuyMatch and SimulationBuyOption models"
```

---

## Task 3: simulate_buy() — happy path TDD

**Files:**
- Create: `tests/engine/test_simulate_buy.py`
- Modify: `src/net_alpha/engine/simulator.py:107` (append at end)

- [ ] **Step 3.1: Write failing happy-path tests**

Create `tests/engine/test_simulate_buy.py`:

```python
from datetime import date
from decimal import Decimal

import pytest

from net_alpha.engine.simulator import simulate_buy
from net_alpha.models.domain import Account, Trade


def _sell(account, day, ticker, qty, proceeds, cost):
    return Trade(
        account=account, date=day, ticker=ticker, action="Sell",
        quantity=qty, proceeds=proceeds, cost_basis=cost,
    )


def _buy_trade(account, day, ticker, qty, cost):
    return Trade(
        account=account, date=day, ticker=ticker, action="Buy",
        quantity=qty, proceeds=None, cost_basis=cost,
    )


P = Account(id=1, broker="schwab", label="personal")
R = Account(id=2, broker="schwab", label="roth")


def test_no_recent_losses_returns_clean_option_per_account():
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account=None,
        on_date=date(2025, 6, 1),
        accounts=[P, R],
        recent_trades=[],
        existing_violations=[],
        etf_pairs={},
    )
    assert {o.account.label for o in options} == {"personal", "roth"}
    for opt in options:
        assert opt.clean is True
        assert opt.matches == []
        assert opt.total_disallowed == Decimal("0")
        assert opt.proposed_basis == Decimal("1800")
        assert opt.adjusted_basis == Decimal("1800")


def test_unmatched_loss_within_window_creates_match():
    loss = _sell("schwab/personal", date(2025, 5, 20), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert len(options) == 1
    opt = options[0]
    assert opt.clean is False
    assert len(opt.matches) == 1
    m = opt.matches[0]
    assert m.matched_quantity == Decimal("10")
    # loss_amount = cost - proceeds = 2000 - 1500 = 500
    assert m.disallowed_loss == Decimal("500")
    assert m.confidence == "Confirmed"
    assert opt.proposed_basis == Decimal("1800")
    assert opt.adjusted_basis == Decimal("2300")  # 1800 + 500


def test_account_filter_returns_only_one_option():
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/roth",
        on_date=date(2025, 6, 1),
        accounts=[P, R],
        recent_trades=[],
        existing_violations=[],
        etf_pairs={},
    )
    assert len(options) == 1
    assert options[0].account.label == "roth"


def test_partial_qty_match_when_buy_qty_lt_loss_qty():
    loss = _sell("schwab/personal", date(2025, 5, 20), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("4"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    m = options[0].matches[0]
    assert m.matched_quantity == Decimal("4")
    # 500 disallowed * (4/10) = 200
    assert m.disallowed_loss == Decimal("200")
    assert options[0].adjusted_basis == Decimal("920")  # 720 + 200


def test_loss_already_wash_matched_is_skipped():
    from net_alpha.models.domain import WashSaleViolation
    loss = _sell("schwab/personal", date(2025, 5, 20), "TSLA", qty=10, proceeds=1500, cost=2000)
    existing = WashSaleViolation(
        loss_trade_id=loss.id,
        replacement_trade_id="some-other-buy",
        confidence="Confirmed",
        disallowed_loss=500.0,
        matched_quantity=10.0,
        ticker="TSLA",
        loss_account="schwab/personal",
        buy_account="schwab/personal",
        loss_sale_date=date(2025, 5, 20),
        triggering_buy_date=date(2025, 5, 25),
    )
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[existing],
        etf_pairs={},
    )
    assert options[0].clean is True


def test_gain_sale_in_window_is_not_a_match():
    gain = _sell("schwab/personal", date(2025, 5, 20), "TSLA", qty=10, proceeds=2500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[gain],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is True


def test_loss_in_other_account_still_matches_cross_account():
    loss = _sell("schwab/roth", date(2025, 5, 20), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is False
    assert options[0].matches[0].loss_account == "schwab/roth"
```

- [ ] **Step 3.2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_simulate_buy.py -q`
Expected: ImportError on `simulate_buy` (function not yet defined).

- [ ] **Step 3.3: Implement simulate_buy**

Append to `src/net_alpha/engine/simulator.py`:

```python
def simulate_buy(
    ticker: str,
    qty: Decimal,
    price: Decimal,
    account: str | None,
    on_date: _date,
    accounts: list[Account],
    recent_trades: list[Trade],
    existing_violations: list,  # list[WashSaleViolation]
    etf_pairs: dict[str, list[str]],
) -> list:  # list[SimulationBuyOption]
    """One option per candidate buy account. Cross-account loss scan."""
    from net_alpha.models.domain import SimBuyMatch, SimulationBuyOption

    candidate_accounts = accounts if account is None else [a for a in accounts if a.display() == account]
    matched_loss_ids = {v.loss_trade_id for v in existing_violations}

    # Hypothetical buy used as the right-hand side of get_match_confidence(loss, hypo_buy)
    hypo_buy_template = Trade(
        account="",  # filled per-option
        date=on_date,
        ticker=ticker,
        action="Buy",
        quantity=float(qty),
        proceeds=None,
        cost_basis=float(qty) * float(price),
    )

    # Pre-filter recent_trades to candidate loss sales in the look-back window.
    eligible_losses: list[Trade] = []
    for t in recent_trades:
        if not t.is_sell() or not t.is_loss():
            continue
        if t.id in matched_loss_ids:
            continue
        delta = (on_date - t.date).days
        if not (0 <= delta <= 30):
            continue
        # Quick same-ticker prune; full match check below uses get_match_confidence
        # which also handles ETF pairs.
        eligible_losses.append(t)

    # Stable order: oldest loss first (FIFO consumption of the proposed buy quantity).
    eligible_losses.sort(key=lambda x: (x.date, x.id))

    options: list[SimulationBuyOption] = []
    proposed_basis = Decimal(str(qty)) * Decimal(str(price))

    for acct in candidate_accounts:
        hypo_buy = hypo_buy_template.model_copy(update={"account": acct.display()})
        matches: list[SimBuyMatch] = []
        remaining = float(qty)
        total_disallowed = Decimal("0")

        for loss in eligible_losses:
            if remaining <= 0:
                break
            confidence = get_match_confidence(loss, hypo_buy, etf_pairs)
            if confidence is None:
                continue
            matched_qty = min(remaining, loss.quantity)
            ratio = matched_qty / loss.quantity if loss.quantity else 0.0
            disallowed = loss.loss_amount() * ratio
            disallowed_dec = Decimal(str(round(disallowed, 2)))
            total_disallowed += disallowed_dec
            matches.append(
                SimBuyMatch(
                    loss_trade_id=loss.id,
                    loss_sale_date=loss.date,
                    loss_account=loss.account,
                    loss_ticker=loss.ticker,
                    matched_quantity=Decimal(str(matched_qty)),
                    disallowed_loss=disallowed_dec,
                    confidence=confidence,
                )
            )
            remaining -= matched_qty

        options.append(
            SimulationBuyOption(
                account=acct,
                matches=matches,
                total_disallowed=total_disallowed,
                proposed_basis=proposed_basis,
                adjusted_basis=proposed_basis + total_disallowed,
                clean=(len(matches) == 0),
            )
        )

    return options
```

- [ ] **Step 3.4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_simulate_buy.py -q`
Expected: 7 passed.

- [ ] **Step 3.5: Commit**

```bash
git add tests/engine/test_simulate_buy.py src/net_alpha/engine/simulator.py
git commit -m "feat(engine): add simulate_buy() pure function with per-account FIFO loss matching"
```

---

## Task 4: simulate_buy boundary day 0/30/31 tests

**Files:**
- Modify: `tests/engine/test_simulate_buy.py` (append)

- [ ] **Step 4.1: Add boundary tests**

Append to `tests/engine/test_simulate_buy.py`:

```python
def test_loss_on_day_zero_same_day_as_proposed_buy_matches():
    loss = _sell("schwab/personal", date(2025, 6, 1), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is False


def test_loss_on_day_30_before_buy_still_matches():
    loss = _sell("schwab/personal", date(2025, 5, 2), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),  # exactly 30 days after
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is False


def test_loss_on_day_31_before_buy_does_not_match():
    loss = _sell("schwab/personal", date(2025, 5, 1), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),  # 31 days after
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is True


def test_loss_after_proposed_buy_does_not_match():
    """Future loss is simulate_sell's concern, not simulate_buy."""
    loss = _sell("schwab/personal", date(2025, 6, 5), "TSLA", qty=10, proceeds=1500, cost=2000)
    options = simulate_buy(
        ticker="TSLA",
        qty=Decimal("10"),
        price=Decimal("180"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={},
    )
    assert options[0].clean is True
```

- [ ] **Step 4.2: Run boundary tests**

Run: `uv run pytest tests/engine/test_simulate_buy.py -q`
Expected: 11 passed.

- [ ] **Step 4.3: Commit**

```bash
git add tests/engine/test_simulate_buy.py
git commit -m "test(engine): add day-0/30/31 boundary tests for simulate_buy"
```

---

## Task 5: simulate_buy ETF substantially-identical pair test

**Files:**
- Modify: `tests/engine/test_simulate_buy.py` (append)

- [ ] **Step 5.1: Add ETF pair tests**

Append to `tests/engine/test_simulate_buy.py`:

```python
def test_etf_substantially_identical_loss_matches_with_unclear_confidence():
    # Loss on SPY; proposed buy on VOO — bundled S&P 500 pair.
    loss = _sell("schwab/personal", date(2025, 5, 20), "SPY", qty=10, proceeds=4500, cost=5000)
    options = simulate_buy(
        ticker="VOO",
        qty=Decimal("10"),
        price=Decimal("450"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={"sp500": ["SPY", "VOO", "IVV", "SPLG"]},
    )
    assert options[0].clean is False
    assert len(options[0].matches) == 1
    m = options[0].matches[0]
    assert m.confidence == "Unclear"
    assert m.loss_ticker == "SPY"


def test_etf_unrelated_pair_does_not_match():
    # SPY (S&P 500) vs QQQ (Nasdaq-100) — not in same group.
    loss = _sell("schwab/personal", date(2025, 5, 20), "SPY", qty=10, proceeds=4500, cost=5000)
    options = simulate_buy(
        ticker="QQQ",
        qty=Decimal("10"),
        price=Decimal("400"),
        account="schwab/personal",
        on_date=date(2025, 6, 1),
        accounts=[P],
        recent_trades=[loss],
        existing_violations=[],
        etf_pairs={"sp500": ["SPY", "VOO"], "nasdaq": ["QQQ", "QQQM"]},
    )
    assert options[0].clean is True
```

- [ ] **Step 5.2: Run ETF tests**

Run: `uv run pytest tests/engine/test_simulate_buy.py -q`
Expected: 13 passed.

- [ ] **Step 5.3: Commit**

```bash
git add tests/engine/test_simulate_buy.py
git commit -m "test(engine): add ETF substantially-identical pair tests for simulate_buy"
```

---

## Task 6: Sim form — Action segmented control + Date field

**Files:**
- Modify: `src/net_alpha/web/templates/sim.html`

- [ ] **Step 6.1: Replace `sim.html` form contents**

Overwrite the file with:

```jinja
{% extends "base.html" %}
{% block title %}Sim · net-alpha{% endblock %}
{% block content %}
  <h1 class="text-2xl mb-4">Simulate a trade</h1>

  <form hx-post="/sim" hx-target="#sim-result" hx-swap="innerHTML"
        x-data="{ action: 'sell' }"
        class="kpi-card mb-6">
    <div class="grid grid-cols-6 gap-3 items-end">
      <div class="col-span-1">
        <label class="block text-xs text-slate-500 uppercase mb-1">Action</label>
        <div class="inline-flex rounded-md shadow-sm border border-slate-300 overflow-hidden text-sm">
          <button type="button"
                  @click="action='buy'"
                  :class="action==='buy' ? 'bg-primary text-white' : 'bg-white text-slate-700 hover:bg-slate-50'"
                  class="px-3 py-1.5 font-medium">Buy</button>
          <button type="button"
                  @click="action='sell'"
                  :class="action==='sell' ? 'bg-primary text-white' : 'bg-white text-slate-700 hover:bg-slate-50'"
                  class="px-3 py-1.5 font-medium border-l border-slate-300">Sell</button>
        </div>
        <input type="hidden" name="action" :value="action"/>
      </div>
      <div>
        <label class="block text-xs text-slate-500 uppercase">Ticker</label>
        <input type="text" name="ticker" value="{{ ticker }}" list="ticker-list" required
               class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-full"/>
        <datalist id="ticker-list">
          {% for t in tickers %}<option value="{{ t }}">{% endfor %}
        </datalist>
      </div>
      <div>
        <label class="block text-xs text-slate-500 uppercase">Quantity</label>
        <input type="number" name="qty" step="0.01" required
               class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-full"/>
      </div>
      <div>
        <label class="block text-xs text-slate-500 uppercase">Price</label>
        <input type="number" name="price" step="0.01" required
               class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-full"/>
      </div>
      <div>
        <label class="block text-xs text-slate-500 uppercase">Account (optional)</label>
        <select name="account" class="border border-slate-300 rounded px-2 py-1 text-sm w-full">
          <option value="">All</option>
          {% for a in accounts %}<option value="{{ a }}">{{ a }}</option>{% endfor %}
        </select>
      </div>
      <div>
        <label class="block text-xs text-slate-500 uppercase">Date</label>
        <input type="date" name="trade_date" value="{{ today_iso }}" required
               class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-full"/>
      </div>
    </div>
    <div class="mt-4 text-right">
      <button type="submit" class="btn">Run sim</button>
    </div>
  </form>

  <div id="sim-result"></div>
{% endblock %}
```

- [ ] **Step 6.2: Verify template parses**

Run: `uv run python -c "from jinja2 import Environment, FileSystemLoader; env = Environment(loader=FileSystemLoader('src/net_alpha/web/templates')); env.get_template('sim.html'); print('OK')"`
Expected: prints `OK`.

- [ ] **Step 6.3: Commit**

```bash
git add src/net_alpha/web/templates/sim.html
git commit -m "feat(web): unified sim form with BUY/SELL toggle and date picker"
```

---

## Task 7: POST /sim dispatches on action; rename + add result partials

**Files:**
- Modify: `src/net_alpha/web/routes/sim.py`
- Move: `src/net_alpha/web/templates/_sim_result.html` → `_sim_sell_result.html` (via `git mv`)
- Create: `src/net_alpha/web/templates/_sim_buy_result.html`

- [ ] **Step 7.1: Rename the existing sell partial**

Run: `git mv src/net_alpha/web/templates/_sim_result.html src/net_alpha/web/templates/_sim_sell_result.html`
Expected: file moved cleanly.

- [ ] **Step 7.2: Create the new buy result partial**

Create `src/net_alpha/web/templates/_sim_buy_result.html`:

```jinja
{% if not options %}
  <div class="kpi-card text-slate-500 text-sm">No accounts available.</div>
{% else %}
  <h2 class="text-xl mb-3">Per-account options for buying <span class="font-mono text-primary">{{ ticker }}</span></h2>
  <div class="grid grid-cols-2 gap-4">
    {% for opt in options %}
      <div class="kpi-card">
        <div class="flex justify-between items-baseline mb-2">
          <div class="font-mono text-primary">{{ opt.account.display() }}</div>
          {% if opt.clean %}
            <span class="text-emerald-700 bg-emerald-100 text-xs font-medium px-2 py-0.5 rounded">No wash sale</span>
          {% else %}
            <span class="badge-{{ opt.matches[0].confidence|lower }}">Wash trigger</span>
          {% endif %}
        </div>

        <div class="text-xs text-slate-500 uppercase">Proposed basis</div>
        <div class="text-base font-mono mb-1">${{ "%.2f"|format(opt.proposed_basis|float) }}</div>

        {% if opt.total_disallowed > 0 %}
          <div class="text-xs text-slate-500 uppercase">Disallowed loss rolled in</div>
          <div class="text-base font-mono text-confirmed mb-1">+${{ "%.2f"|format(opt.total_disallowed|float) }}</div>

          <div class="text-xs text-slate-500 uppercase">Adjusted basis on new lot</div>
          <div class="text-lg font-mono mb-2">${{ "%.2f"|format(opt.adjusted_basis|float) }}</div>

          <div class="text-xs text-slate-500 uppercase mb-1">Matched losses</div>
          <table class="w-full text-xs">
            <tbody>
              {% for m in opt.matches %}
                <tr class="border-b border-slate-100 last:border-b-0">
                  <td class="py-1 font-mono">{{ m.loss_sale_date }}</td>
                  <td class="py-1">{{ m.loss_account }}</td>
                  <td class="py-1 font-mono">{{ m.loss_ticker }}</td>
                  <td class="py-1 font-mono text-right">{{ m.matched_quantity }}</td>
                  <td class="py-1 font-mono text-right text-confirmed">${{ "%.2f"|format(m.disallowed_loss|float) }}</td>
                  <td class="py-1"><span class="badge-{{ m.confidence|lower }}">{{ m.confidence }}</span></td>
                </tr>
              {% endfor %}
            </tbody>
          </table>
        {% else %}
          <div class="text-xs text-slate-500 mt-1">Adjusted basis: ${{ "%.2f"|format(opt.adjusted_basis|float) }}</div>
        {% endif %}
      </div>
    {% endfor %}
  </div>
{% endif %}
```

- [ ] **Step 7.3: Replace `routes/sim.py` to dispatch on action**

Overwrite `src/net_alpha/web/routes/sim.py`:

```python
from __future__ import annotations

from datetime import date as _date
from decimal import Decimal

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse

from net_alpha.db.repository import Repository
from net_alpha.engine.etf_pairs import load_etf_pairs
from net_alpha.engine.simulator import simulate_buy, simulate_sell
from net_alpha.web.dependencies import get_repository

router = APIRouter()


@router.get("/sim", response_class=HTMLResponse)
def sim_form(
    request: Request,
    repo: Repository = Depends(get_repository),
    ticker: str | None = None,
) -> HTMLResponse:
    return request.app.state.templates.TemplateResponse(
        request,
        "sim.html",
        {
            "ticker": ticker or "",
            "tickers": repo.list_distinct_tickers(),
            "accounts": [a.display() for a in repo.list_accounts()],
            "today_iso": _date.today().isoformat(),
            "result": None,
        },
    )


@router.post("/sim", response_class=HTMLResponse)
def sim_run(
    request: Request,
    repo: Repository = Depends(get_repository),
    action: str = Form("sell"),
    ticker: str = Form(...),
    qty: float = Form(...),
    price: float = Form(...),
    account: str = Form(""),
    trade_date: str = Form(""),
) -> HTMLResponse:
    on_date = _date.fromisoformat(trade_date) if trade_date else _date.today()
    accounts = repo.list_accounts()
    accounts_filtered = [a for a in accounts if a.display() == account] if account else accounts

    if action.lower() == "buy":
        options = simulate_buy(
            ticker=ticker.upper(),
            qty=Decimal(str(qty)),
            price=Decimal(str(price)),
            account=account or None,
            on_date=on_date,
            accounts=accounts,
            recent_trades=repo.all_trades(),
            existing_violations=repo.all_violations(),
            etf_pairs=load_etf_pairs(),
        )
        return request.app.state.templates.TemplateResponse(
            request,
            "_sim_buy_result.html",
            {"options": options, "ticker": ticker.upper()},
        )

    options = simulate_sell(
        ticker=ticker.upper(),
        qty=Decimal(str(qty)),
        price=Decimal(str(price)),
        accounts=accounts_filtered,
        existing_lots=repo.all_lots(),
        recent_trades=repo.all_trades(),
        today=on_date,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_sim_sell_result.html",
        {"options": options, "ticker": ticker.upper()},
    )
```

- [ ] **Step 7.4: Verify the existing sell-route tests still pass**

Run: `uv run pytest tests/web/test_sim_routes.py -q`
Expected: 3 passed (existing tests post without an `action` field; FastAPI's `Form("sell")` default keeps them on the sell branch, and the rendered template now `_sim_sell_result.html` still contains "schwab/personal" / "No holdings".)

- [ ] **Step 7.5: Commit**

```bash
git add src/net_alpha/web/templates/_sim_sell_result.html \
        src/net_alpha/web/templates/_sim_buy_result.html \
        src/net_alpha/web/routes/sim.py
git commit -m "feat(web): POST /sim dispatches BUY/SELL with date and renders new result partials"
```

---

## Task 8: Web route tests for buy dispatch

**Files:**
- Create: `tests/web/test_sim_buy_routes.py`

- [ ] **Step 8.1: Add buy route tests**

Create `tests/web/test_sim_buy_routes.py`:

```python
from datetime import date


def test_sim_form_includes_action_toggle_and_date(client):
    resp = client.get("/sim")
    assert resp.status_code == 200
    assert "Buy" in resp.text and "Sell" in resp.text
    assert 'name="trade_date"' in resp.text
    assert 'name="action"' in resp.text


def test_sim_post_buy_with_no_recent_losses_returns_clean_options(client, repo):
    repo.get_or_create_account("schwab", "personal")
    resp = client.post(
        "/sim",
        data={
            "action": "buy",
            "ticker": "TSLA",
            "qty": "10",
            "price": "180",
            "account": "schwab/personal",
            "trade_date": "2025-06-01",
        },
    )
    assert resp.status_code == 200
    # Buy partial heading
    assert "options for buying" in resp.text
    # Clean state
    assert "No wash sale" in resp.text


def test_sim_post_buy_with_recent_loss_shows_wash_trigger(client, repo, builders):
    from net_alpha.engine.detector import detect_in_window

    builders.seed_import(
        repo,
        "schwab",
        "personal",
        [
            builders.make_buy("schwab/personal", "TSLA", date(2025, 4, 1), qty=10, cost=2000),
            builders.make_sell("schwab/personal", "TSLA", date(2025, 5, 20), qty=10, proceeds=1500, cost=2000),
        ],
    )
    # Run detector so that any pre-existing buy doesn't accidentally already wash-match.
    win_start, win_end = date(2025, 4, 1), date(2025, 7, 1)
    res = detect_in_window(repo.trades_in_window(win_start, win_end), win_start, win_end, etf_pairs={})
    repo.replace_lots_in_window(win_start, win_end, res.lots)
    repo.replace_violations_in_window(win_start, win_end, res.violations)

    resp = client.post(
        "/sim",
        data={
            "action": "buy",
            "ticker": "TSLA",
            "qty": "10",
            "price": "180",
            "account": "schwab/personal",
            "trade_date": "2025-06-01",
        },
    )
    assert resp.status_code == 200
    assert "Wash trigger" in resp.text
    assert "Disallowed loss rolled in" in resp.text


def test_sim_post_sell_still_works(client, repo, builders):
    from net_alpha.engine.detector import detect_in_window

    builders.seed_import(
        repo,
        "schwab",
        "personal",
        [
            builders.make_buy("schwab/personal", "TSLA", date(2025, 4, 1), qty=10, cost=2000),
        ],
    )
    win_start, win_end = date(2025, 3, 1), date(2025, 7, 1)
    res = detect_in_window(repo.trades_in_window(win_start, win_end), win_start, win_end, etf_pairs={})
    repo.replace_lots_in_window(win_start, win_end, res.lots)

    resp = client.post(
        "/sim",
        data={
            "action": "sell",
            "ticker": "TSLA",
            "qty": "5",
            "price": "150",
            "account": "schwab/personal",
            "trade_date": "2025-06-01",
        },
    )
    assert resp.status_code == 200
    assert "schwab/personal" in resp.text
    # Sell partial heading uses "options for"
    assert "options for" in resp.text
```

- [ ] **Step 8.2: Run buy route tests**

Run: `uv run pytest tests/web/test_sim_buy_routes.py -q`
Expected: 4 passed.

- [ ] **Step 8.3: Commit**

```bash
git add tests/web/test_sim_buy_routes.py
git commit -m "test(web): cover BUY/SELL dispatch on POST /sim with date and account"
```

---

## Task 9: Detail page — totals + grouping pure functions

**Files:**
- Create: `src/net_alpha/portfolio/detail_aggregations.py`
- Create: `tests/portfolio/test_detail_aggregations.py`

- [ ] **Step 9.1: Write failing aggregation tests**

Create `tests/portfolio/test_detail_aggregations.py`:

```python
from datetime import date
from decimal import Decimal

from net_alpha.models.domain import WashSaleViolation
from net_alpha.portfolio.detail_aggregations import (
    DetailSummary,
    TickerGroup,
    compute_detail_summary,
    group_violations_by_ticker,
    lag_days,
    source_label,
)


def _v(**kw):
    defaults = dict(
        loss_trade_id="lt", replacement_trade_id="rt",
        confidence="Confirmed", disallowed_loss=100.0, matched_quantity=10.0,
        ticker="TSLA", loss_account="schwab/personal", buy_account="schwab/personal",
        loss_sale_date=date(2025, 6, 1), triggering_buy_date=date(2025, 6, 13),
        source="engine",
    )
    defaults.update(kw)
    return WashSaleViolation(**defaults)


def test_summary_zero_for_empty_list():
    s = compute_detail_summary([])
    assert s == DetailSummary(violation_count=0, disallowed_total=Decimal("0"),
                              confirmed_count=0, probable_count=0, unclear_count=0)


def test_summary_counts_confidence_and_sums():
    vs = [
        _v(confidence="Confirmed", disallowed_loss=200.0),
        _v(confidence="Probable", disallowed_loss=300.5),
        _v(confidence="Unclear", disallowed_loss=50.0),
    ]
    s = compute_detail_summary(vs)
    assert s.violation_count == 3
    assert s.disallowed_total == Decimal("550.50")
    assert s.confirmed_count == 1
    assert s.probable_count == 1
    assert s.unclear_count == 1


def test_group_by_ticker_sorts_by_disallowed_desc():
    vs = [
        _v(ticker="AAPL", disallowed_loss=100.0),
        _v(ticker="TSLA", disallowed_loss=500.0),
        _v(ticker="TSLA", disallowed_loss=200.0),
    ]
    groups = group_violations_by_ticker(vs)
    assert [g.ticker for g in groups] == ["TSLA", "AAPL"]
    assert groups[0].violation_count == 2
    assert groups[0].disallowed_total == Decimal("700")
    assert groups[1].violation_count == 1
    assert groups[1].disallowed_total == Decimal("100")


def test_lag_days_returns_int():
    v = _v(loss_sale_date=date(2025, 6, 1), triggering_buy_date=date(2025, 6, 13))
    assert lag_days(v) == 12


def test_lag_days_returns_none_when_dates_missing():
    v = _v(loss_sale_date=None)
    assert lag_days(v) is None


def test_source_label_schwab():
    v = _v(source="schwab_g_l")
    assert source_label(v) == "Schwab"


def test_source_label_cross_account():
    v = _v(source="engine", loss_account="schwab/personal", buy_account="schwab/roth")
    assert source_label(v) == "Cross-account"


def test_source_label_engine():
    v = _v(source="engine", loss_account="schwab/personal", buy_account="schwab/personal")
    assert source_label(v) == "Engine"
```

- [ ] **Step 9.2: Run tests to verify they fail**

Run: `uv run pytest tests/portfolio/test_detail_aggregations.py -q`
Expected: ImportError on `net_alpha.portfolio.detail_aggregations`.

- [ ] **Step 9.3: Implement aggregations**

Create `src/net_alpha/portfolio/detail_aggregations.py`:

```python
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from net_alpha.models.domain import WashSaleViolation


@dataclass(frozen=True)
class DetailSummary:
    violation_count: int
    disallowed_total: Decimal
    confirmed_count: int
    probable_count: int
    unclear_count: int


@dataclass(frozen=True)
class TickerGroup:
    ticker: str
    violations: list[WashSaleViolation]
    violation_count: int
    disallowed_total: Decimal


def compute_detail_summary(violations: list[WashSaleViolation]) -> DetailSummary:
    total = Decimal("0")
    confirmed = probable = unclear = 0
    for v in violations:
        total += Decimal(str(v.disallowed_loss))
        c = v.confidence.lower()
        if c == "confirmed":
            confirmed += 1
        elif c == "probable":
            probable += 1
        elif c == "unclear":
            unclear += 1
    return DetailSummary(
        violation_count=len(violations),
        disallowed_total=total,
        confirmed_count=confirmed,
        probable_count=probable,
        unclear_count=unclear,
    )


def group_violations_by_ticker(violations: list[WashSaleViolation]) -> list[TickerGroup]:
    by_ticker: dict[str, list[WashSaleViolation]] = {}
    for v in violations:
        by_ticker.setdefault(v.ticker, []).append(v)

    groups = [
        TickerGroup(
            ticker=ticker,
            violations=vs,
            violation_count=len(vs),
            disallowed_total=sum((Decimal(str(v.disallowed_loss)) for v in vs), Decimal("0")),
        )
        for ticker, vs in by_ticker.items()
    ]
    groups.sort(key=lambda g: (-g.disallowed_total, g.ticker))
    return groups


def lag_days(v: WashSaleViolation) -> int | None:
    if v.loss_sale_date is None or v.triggering_buy_date is None:
        return None
    return (v.triggering_buy_date - v.loss_sale_date).days


def source_label(v: WashSaleViolation) -> str:
    if v.source == "schwab_g_l":
        return "Schwab"
    if v.loss_account and v.buy_account and v.loss_account != v.buy_account:
        return "Cross-account"
    return "Engine"
```

- [ ] **Step 9.4: Run tests to verify they pass**

Run: `uv run pytest tests/portfolio/test_detail_aggregations.py -q`
Expected: 8 passed.

- [ ] **Step 9.5: Commit**

```bash
git add src/net_alpha/portfolio/detail_aggregations.py tests/portfolio/test_detail_aggregations.py
git commit -m "feat(portfolio): add detail-page aggregations (summary, grouping, lag, source label)"
```

---

## Task 10: Detail route — wire summary, grouping, sort

**Files:**
- Modify: `src/net_alpha/web/routes/detail.py`

- [ ] **Step 10.1: Replace the route**

Overwrite `src/net_alpha/web/routes/detail.py`:

```python
from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse

from net_alpha.db.repository import Repository
from net_alpha.portfolio.detail_aggregations import (
    compute_detail_summary,
    group_violations_by_ticker,
    lag_days,
    source_label,
)
from net_alpha.web.dependencies import get_repository

router = APIRouter()

EXPAND_THRESHOLD = 5  # default expand state for group-by-ticker


@router.get("/detail", response_class=HTMLResponse)
def detail_page(
    request: Request,
    repo: Repository = Depends(get_repository),
    ticker: str | None = Query(None),
    account: str | None = Query(None),
    year: int | None = Query(None),
    confidence: str | None = Query(None),
    sort: str | None = Query(None),  # "lag" supported; default = loss_sale_date desc
    order: str | None = Query("desc"),
) -> HTMLResponse:
    violations = repo.all_violations()
    if ticker:
        violations = [v for v in violations if v.ticker == ticker.upper()]
    if account:
        violations = [v for v in violations if account in (v.loss_account, v.buy_account)]
    if year:
        violations = [v for v in violations if v.loss_sale_date and v.loss_sale_date.year == year]
    if confidence:
        violations = [v for v in violations if v.confidence.lower() == confidence.lower()]

    # Sort the flat list (used for view-without-grouping fallback and inside groups)
    reverse = (order or "desc").lower() != "asc"
    if sort == "lag":
        violations.sort(key=lambda v: (lag_days(v) is None, lag_days(v) or 0), reverse=reverse)
    else:
        violations.sort(key=lambda v: (v.loss_sale_date or v.loss_sale_date), reverse=reverse)
        # date | None → coerce missing dates to MIN so sort doesn't crash
        from datetime import date as _date
        violations.sort(key=lambda v: v.loss_sale_date or _date.min, reverse=reverse)

    summary = compute_detail_summary(violations)
    groups = group_violations_by_ticker(violations)

    # Sort each group's violations using the same key
    for g in groups:
        if sort == "lag":
            g.violations.sort(key=lambda v: (lag_days(v) is None, lag_days(v) or 0), reverse=reverse)
        else:
            from datetime import date as _date
            g.violations.sort(key=lambda v: v.loss_sale_date or _date.min, reverse=reverse)

    expand_default = len(groups) <= EXPAND_THRESHOLD

    return request.app.state.templates.TemplateResponse(
        request,
        "detail.html",
        {
            "violations": violations,
            "summary": summary,
            "groups": groups,
            "expand_default": expand_default,
            "lag_days": lag_days,
            "source_label": source_label,
            "filter_ticker": ticker or "",
            "filter_account": account or "",
            "filter_year": year or "",
            "filter_confidence": confidence or "",
            "sort": sort or "",
            "order": order or "desc",
            "next_lag_order": "asc" if (sort == "lag" and (order or "desc") == "desc") else "desc",
            "tickers": repo.list_distinct_tickers(),
            "accounts": [a.display() for a in repo.list_accounts()],
        },
    )
```

- [ ] **Step 10.2: Verify the route still imports**

Run: `uv run python -c "from net_alpha.web.routes.detail import router; print('OK')"`
Expected: prints `OK`.

- [ ] **Step 10.3: Commit**

```bash
git add src/net_alpha/web/routes/detail.py
git commit -m "feat(web): wire detail summary, ticker grouping, and lag-sort into the route"
```

---

## Task 11: Detail template — totals bar + grouped collapsible rows + Lag/Source columns

**Files:**
- Modify: `src/net_alpha/web/templates/detail.html`
- Modify: `src/net_alpha/web/templates/_detail_table.html`

- [ ] **Step 11.1: Update `detail.html` to render totals + table partial**

Overwrite `src/net_alpha/web/templates/detail.html`:

```jinja
{% extends "base.html" %}
{% block title %}Detail · net-alpha{% endblock %}
{% block content %}
  <h1 class="text-2xl mb-4">Violation detail</h1>

  <form method="get" class="kpi-card mb-4 flex gap-3 flex-wrap items-end">
    <div>
      <label class="block text-xs text-slate-500 uppercase">Ticker</label>
      <input type="text" name="ticker" value="{{ filter_ticker }}" list="ticker-list" class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-32"/>
      <datalist id="ticker-list">
        {% for t in tickers %}<option value="{{ t }}">{% endfor %}
      </datalist>
    </div>
    <div>
      <label class="block text-xs text-slate-500 uppercase">Account</label>
      <input type="text" name="account" value="{{ filter_account }}" list="account-list" class="border border-slate-300 rounded px-2 py-1 text-sm w-40"/>
      <datalist id="account-list">
        {% for a in accounts %}<option value="{{ a }}">{{ a }}</option>{% endfor %}
      </datalist>
    </div>
    <div>
      <label class="block text-xs text-slate-500 uppercase">Year</label>
      <input type="number" name="year" value="{{ filter_year }}" class="border border-slate-300 rounded px-2 py-1 font-mono text-sm w-24"/>
    </div>
    <div>
      <label class="block text-xs text-slate-500 uppercase">Confidence</label>
      <select name="confidence" class="border border-slate-300 rounded px-2 py-1 text-sm">
        <option value="">All</option>
        <option value="confirmed" {% if filter_confidence=='confirmed' %}selected{% endif %}>Confirmed</option>
        <option value="probable" {% if filter_confidence=='probable' %}selected{% endif %}>Probable</option>
        <option value="unclear" {% if filter_confidence=='unclear' %}selected{% endif %}>Unclear</option>
      </select>
    </div>
    {# Preserve current sort across filter submits #}
    {% if sort %}<input type="hidden" name="sort" value="{{ sort }}"/>{% endif %}
    {% if order %}<input type="hidden" name="order" value="{{ order }}"/>{% endif %}
    <button type="submit" class="btn">Apply</button>
    <a href="/detail" class="btn-ghost">Reset</a>
  </form>

  {# Totals bar #}
  {% if summary.violation_count > 0 %}
    <div class="kpi-card mb-4 text-sm flex gap-4 items-baseline">
      <div><span class="font-medium">{{ summary.violation_count }}</span> violations</div>
      <div><span class="font-medium text-confirmed">${{ "%.2f"|format(summary.disallowed_total|float) }}</span> disallowed</div>
      <div><span class="badge-confirmed">{{ summary.confirmed_count }} confirmed</span></div>
      <div><span class="badge-probable">{{ summary.probable_count }} probable</span></div>
      <div><span class="badge-unclear">{{ summary.unclear_count }} unclear</span></div>
    </div>
  {% endif %}

  {% include "_detail_table.html" %}
{% endblock %}
```

- [ ] **Step 11.2: Replace `_detail_table.html` with grouped layout**

Overwrite `src/net_alpha/web/templates/_detail_table.html`:

```jinja
{% if not violations %}
  <div class="kpi-card text-slate-500 text-sm">No violations match these filters.</div>
{% else %}
  {# Build the lag-sort URL preserving current filters #}
  {% set lag_qs = [] %}
  {% if filter_ticker %}{% set _ = lag_qs.append('ticker=' ~ filter_ticker) %}{% endif %}
  {% if filter_account %}{% set _ = lag_qs.append('account=' ~ filter_account) %}{% endif %}
  {% if filter_year %}{% set _ = lag_qs.append('year=' ~ filter_year) %}{% endif %}
  {% if filter_confidence %}{% set _ = lag_qs.append('confidence=' ~ filter_confidence) %}{% endif %}
  {% set _ = lag_qs.append('sort=lag') %}
  {% set _ = lag_qs.append('order=' ~ next_lag_order) %}
  {% set lag_url = '/detail?' ~ lag_qs|join('&') %}

  <div class="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
    {% for g in groups %}
      <div x-data="{ open: {{ 'true' if expand_default else 'false' }} }" class="border-b border-slate-200 last:border-b-0">
        <button type="button" @click="open = !open"
                class="w-full flex justify-between items-center px-3 py-2 text-left hover:bg-slate-50">
          <div class="flex items-center gap-2">
            <span x-text="open ? '▾' : '▸'" class="text-slate-400 font-mono"></span>
            <a href="/ticker/{{ g.ticker }}" class="font-mono text-primary underline">{{ g.ticker }}</a>
            <span class="text-xs text-slate-500">{{ g.violation_count }} violation{{ '' if g.violation_count == 1 else 's' }}</span>
          </div>
          <div class="text-sm font-mono text-confirmed">${{ "%.2f"|format(g.disallowed_total|float) }}</div>
        </button>

        <div x-show="open" x-cloak>
          <table class="w-full text-sm">
            <thead class="text-left text-xs text-slate-500 uppercase border-t border-slate-200">
              <tr>
                <th class="px-3 py-2 w-28">Loss date</th>
                <th class="px-3 py-2">Loss → Buy</th>
                <th class="px-3 py-2 w-28">Trigger date</th>
                <th class="px-3 py-2 w-20">
                  <a href="{{ lag_url }}" class="hover:underline">Lag {% if sort == 'lag' %}{{ '▼' if order == 'desc' else '▲' }}{% endif %}</a>
                </th>
                <th class="px-3 py-2 w-28 text-right">Disallowed</th>
                <th class="px-3 py-2 w-20 text-right">Matched qty</th>
                <th class="px-3 py-2 w-28">Confidence</th>
                <th class="px-3 py-2 w-32">Source</th>
              </tr>
            </thead>
            <tbody>
              {% for v in g.violations %}
                {% set lag = lag_days(v) %}
                {% set src = source_label(v) %}
                <tr class="border-t border-slate-100 hover:bg-slate-50">
                  <td class="px-3 py-2 font-mono">{{ v.loss_sale_date or "—" }}</td>
                  <td class="px-3 py-2">{{ v.loss_account or "—" }} → {{ v.buy_account or "—" }}</td>
                  <td class="px-3 py-2 font-mono">{{ v.triggering_buy_date or "—" }}</td>
                  <td class="px-3 py-2 font-mono">{% if lag is not none %}{{ lag }}d{% else %}—{% endif %}</td>
                  <td class="px-3 py-2 font-mono text-right text-confirmed">${{ "%.2f"|format(v.disallowed_loss) }}</td>
                  <td class="px-3 py-2 font-mono text-right">{{ v.matched_quantity }}</td>
                  <td class="px-3 py-2"><span class="badge-{{ v.confidence|lower }}">{{ v.confidence }}</span></td>
                  <td class="px-3 py-2">
                    {% if src == "Schwab" %}
                      <span class="text-slate-700 bg-slate-200 text-xs font-medium px-2 py-0.5 rounded">{{ src }}</span>
                    {% elif src == "Cross-account" %}
                      <span class="text-amber-800 bg-amber-100 text-xs font-medium px-2 py-0.5 rounded">{{ src }}</span>
                    {% else %}
                      <span class="text-blue-800 bg-blue-100 text-xs font-medium px-2 py-0.5 rounded">{{ src }}</span>
                    {% endif %}
                  </td>
                </tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
      </div>
    {% endfor %}
  </div>
{% endif %}
```

> **Tailwind classes:** All classes used here (`text-slate-700`, `bg-slate-200`, `text-amber-800`, `bg-amber-100`, `text-blue-800`, `bg-blue-100`) are stock Tailwind utilities. They're already covered by the existing `web/static/app.css` build because the templates use them via Tailwind's content-scan; no `make build-css` rebuild is required to render them, but if the page's coloring looks wrong locally, run `make build-css` once.

- [ ] **Step 11.3: Verify templates parse**

Run: `uv run python -c "from jinja2 import Environment, FileSystemLoader; env = Environment(loader=FileSystemLoader('src/net_alpha/web/templates')); env.get_template('detail.html'); env.get_template('_detail_table.html'); print('OK')"`
Expected: prints `OK`.

- [ ] **Step 11.4: Verify existing detail route tests still pass**

Run: `uv run pytest tests/web/test_detail_routes.py -q`
Expected: 2 passed.

- [ ] **Step 11.5: Commit**

```bash
git add src/net_alpha/web/templates/detail.html src/net_alpha/web/templates/_detail_table.html
git commit -m "feat(web): detail page totals bar + group-by-ticker + Lag/Source columns"
```

---

## Task 12: Detail enhancements — full integration tests

**Files:**
- Create: `tests/web/test_detail_enhancements.py`

- [ ] **Step 12.1: Write integration tests**

Create `tests/web/test_detail_enhancements.py`:

```python
from datetime import date

from net_alpha.models.domain import WashSaleViolation


def _seed_violations(repo, items: list[dict]) -> None:
    repo.get_or_create_account("schwab", "personal")
    repo.get_or_create_account("schwab", "roth")
    vs = [
        WashSaleViolation(
            loss_trade_id=str(i),
            replacement_trade_id=str(i),
            confidence=item.get("confidence", "Confirmed"),
            disallowed_loss=item.get("disallowed_loss", 100.0),
            matched_quantity=item.get("matched_quantity", 10.0),
            ticker=item.get("ticker", "TSLA"),
            loss_account=item.get("loss_account", "schwab/personal"),
            buy_account=item.get("buy_account", "schwab/personal"),
            loss_sale_date=item.get("loss_sale_date", date(2025, 6, 1)),
            triggering_buy_date=item.get("triggering_buy_date", date(2025, 6, 13)),
            source=item.get("source", "engine"),
        )
        for i, item in enumerate(items)
    ]
    repo.replace_violations_in_window(date(2025, 1, 1), date(2025, 12, 31), vs)


def test_detail_renders_totals_bar(client, repo):
    _seed_violations(repo, [
        {"ticker": "TSLA", "disallowed_loss": 200.0, "confidence": "Confirmed"},
        {"ticker": "AAPL", "disallowed_loss": 300.0, "confidence": "Probable"},
    ])
    resp = client.get("/detail")
    assert resp.status_code == 200
    assert "2 violations" in resp.text
    assert "$500.00" in resp.text
    assert "1 confirmed" in resp.text
    assert "1 probable" in resp.text


def test_detail_groups_by_ticker_and_renders_lag(client, repo):
    _seed_violations(repo, [
        {"ticker": "TSLA", "loss_sale_date": date(2025, 6, 1), "triggering_buy_date": date(2025, 6, 13)},
        {"ticker": "TSLA", "loss_sale_date": date(2025, 6, 5), "triggering_buy_date": date(2025, 6, 20)},
        {"ticker": "AAPL", "loss_sale_date": date(2025, 7, 1), "triggering_buy_date": date(2025, 7, 5)},
    ])
    resp = client.get("/detail")
    assert resp.status_code == 200
    # Both tickers visible as group headers
    assert "TSLA" in resp.text and "AAPL" in resp.text
    # Lag values rendered
    assert "12d" in resp.text  # 6/13 - 6/1
    assert "15d" in resp.text  # 6/20 - 6/5
    assert "4d" in resp.text   # 7/5 - 7/1


def test_detail_renders_source_badges(client, repo):
    _seed_violations(repo, [
        {"ticker": "TSLA", "source": "schwab_g_l"},
        {"ticker": "AAPL", "source": "engine",
         "loss_account": "schwab/personal", "buy_account": "schwab/roth"},
        {"ticker": "MSFT", "source": "engine",
         "loss_account": "schwab/personal", "buy_account": "schwab/personal"},
    ])
    resp = client.get("/detail")
    assert resp.status_code == 200
    assert "Schwab" in resp.text
    assert "Cross-account" in resp.text
    assert "Engine" in resp.text


def test_detail_default_collapsed_when_more_than_5_tickers(client, repo):
    items = [{"ticker": f"TIC{i}", "disallowed_loss": 100.0} for i in range(6)]
    _seed_violations(repo, items)
    resp = client.get("/detail")
    assert resp.status_code == 200
    # Each group's collapsible div uses x-data="{ open: false }"
    assert "open: false" in resp.text


def test_detail_default_expanded_when_5_or_fewer_tickers(client, repo):
    items = [{"ticker": f"TIC{i}", "disallowed_loss": 100.0} for i in range(3)]
    _seed_violations(repo, items)
    resp = client.get("/detail")
    assert resp.status_code == 200
    assert "open: true" in resp.text


def test_detail_sort_by_lag_changes_order(client, repo):
    _seed_violations(repo, [
        {"ticker": "TSLA", "loss_sale_date": date(2025, 6, 1), "triggering_buy_date": date(2025, 6, 13)},  # lag 12
        {"ticker": "TSLA", "loss_sale_date": date(2025, 7, 1), "triggering_buy_date": date(2025, 7, 3)},   # lag 2
    ])
    resp_desc = client.get("/detail?sort=lag&order=desc")
    resp_asc = client.get("/detail?sort=lag&order=asc")
    assert resp_desc.status_code == 200
    assert resp_asc.status_code == 200
    # Ordering check: in desc, "12d" appears before "2d"; in asc, the reverse.
    assert resp_desc.text.find("12d") < resp_desc.text.find("2d")
    assert resp_asc.text.find("2d") < resp_asc.text.find("12d")


def test_detail_filter_then_summary_reflects_filter(client, repo):
    _seed_violations(repo, [
        {"ticker": "TSLA", "disallowed_loss": 200.0, "confidence": "Confirmed"},
        {"ticker": "AAPL", "disallowed_loss": 300.0, "confidence": "Probable"},
    ])
    resp = client.get("/detail?ticker=TSLA")
    assert resp.status_code == 200
    assert "1 violations" in resp.text  # Filtered to one
    assert "$200.00" in resp.text       # Summed to one row's amount
```

- [ ] **Step 12.2: Run tests**

Run: `uv run pytest tests/web/test_detail_enhancements.py -q`
Expected: 7 passed.

- [ ] **Step 12.3: Commit**

```bash
git add tests/web/test_detail_enhancements.py
git commit -m "test(web): integration coverage for detail totals, grouping, lag sort, source"
```

---

## Task 13: Final sweep — format, full test pass

**Files:** none

- [ ] **Step 13.1: Run ruff format**

Run: `uv run ruff format src/ tests/`
Expected: a list of files reformatted (or "0 files reformatted"). If anything changed, stage and commit it as `chore: ruff format` after Step 13.3.

- [ ] **Step 13.2: Run ruff check**

Run: `uv run ruff check src/ tests/`
Expected: `All checks passed!`. If errors, fix them before continuing.

- [ ] **Step 13.3: Run the full test suite**

Run: `uv run pytest --deselect tests/cli/test_ui.py::test_pick_free_port_skips_busy_ports -q`
Expected: previous pass count + at least 32 new passes (Tasks 3+4+5: 13 sim_buy unit tests; Task 8: 4 sim_buy route tests; Task 9: 8 aggregations unit tests; Task 12: 7 detail integration tests = 32 new). All pass.

- [ ] **Step 13.4: Commit format-only changes if any**

```bash
git status --short
# If any files were reformatted in Step 13.1:
git add <reformatted-files>
git commit -m "chore: ruff format"
```

- [ ] **Step 13.5: Quick smoke check that the app starts**

Run: `uv run python -c "from net_alpha.web.app import create_app; from net_alpha.config import Settings; create_app(Settings()); print('OK')"`
Expected: prints `OK` (verifies app construction with all routes wired).

---

## Done criteria

- All 13 tasks above marked `[x]`.
- `uv run pytest --deselect tests/cli/test_ui.py::test_pick_free_port_skips_busy_ports` is green.
- `uv run ruff check src/ tests/` is green.
- The Sim page renders a BUY/SELL toggle with a date picker, and submitting either action returns the right per-account result cards.
- The Detail page renders a totals bar above a group-by-ticker collapsible table with Lag (sortable) and Source columns.
- No business logic added under `src/net_alpha/web/`; all new compute lives in `engine/` or `portfolio/`.
- No new dependencies, no schema migration.
