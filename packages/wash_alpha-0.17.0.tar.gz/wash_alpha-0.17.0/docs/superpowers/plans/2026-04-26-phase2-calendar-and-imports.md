# Phase 2 — Calendar dual-ribbon + Imports relocation & notes

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a monthly realized-P&L bar ribbon stacked above the existing wash-sale dot ribbon on the Calendar page, and turn each row of the Imports page into a self-explanatory record (date range, type breakdown) with an expandable detail panel. Move the drag-drop zone from the Portfolio CTA into the Imports page.

**Architecture:** Two independent feature streams sharing a single schema migration (v3 → v4 adds 6 columns to the `imports` table). Calendar gets a new pure aggregator (`monthly_realized_pl`) and a new partial; the existing wash-sale ribbon is unchanged. Imports gets a pure aggregator (`compute_import_aggregates`), a one-time backfill at app startup, an expand-toggle UI driven by an HTMX detail fragment, and the drop zone relocated into the page shell.

**Tech Stack:** Python 3.11+, FastAPI, Jinja2, HTMX, SQLModel/SQLite, Pydantic v2, pytest, factory_boy.

---

## File structure

### Calendar dual-ribbon
- Modify: `src/net_alpha/portfolio/models.py` — add `MonthlyPnl` dataclass.
- Create: `src/net_alpha/portfolio/calendar_pnl.py` — `monthly_realized_pl()` pure function.
- Create: `tests/portfolio/test_calendar_pnl.py` — unit tests for the aggregator.
- Modify: `src/net_alpha/web/routes/calendar.py` — compute monthly P&L and pass to template.
- Create: `src/net_alpha/web/templates/_calendar_pl_ribbon.html` — new bars-per-month partial.
- Modify: `src/net_alpha/web/templates/calendar.html` — stack the two ribbons.
- Modify: `tests/web/test_calendar.py` — add ribbon-rendering integration test.

### Imports schema, aggregates, backfill
- Modify: `src/net_alpha/db/tables.py` — add 6 nullable columns to `ImportRecordRow`.
- Modify: `src/net_alpha/db/migrations.py` — bump version to 4, add `_migrate_v3_to_v4`.
- Create: `tests/db/test_v3_to_v4_migration.py` — schema migration test.
- Modify: `src/net_alpha/models/domain.py` — extend `ImportRecord` and `ImportSummary` with new fields.
- Create: `src/net_alpha/import_/__init__.py` — make package importable.
- Create: `src/net_alpha/import_/aggregations.py` — `ImportAggregates` model + `compute_import_aggregates()` pure function.
- Create: `tests/import_/__init__.py`
- Create: `tests/import_/test_aggregations.py`
- Create: `src/net_alpha/import_/backfill.py` — one-time backfill helper.
- Create: `tests/import_/test_backfill.py`
- Modify: `src/net_alpha/db/connection.py` — call backfill after migrate.
- Modify: `src/net_alpha/db/repository.py` — persist aggregates on `add_import`, return them in `list_imports`, add `get_import_detail()`.
- Modify: `src/net_alpha/web/routes/imports.py` — compute aggregates on upload, add `GET /imports/{id}/detail` route.

### Imports UI (drop zone + detail panel)
- Modify: `src/net_alpha/web/templates/imports.html` — embed the drop zone, drop the "+ New import" link.
- Modify: `src/net_alpha/web/templates/_imports_table.html` — render summary line + expand toggle.
- Create: `src/net_alpha/web/templates/_imports_detail_row.html` — expanded panel partial.
- Create: `tests/web/test_imports_detail.py` — route tests for detail fragment.
- Modify: `tests/web/test_imports_routes.py` — assertions for new summary line and embedded drop zone.

---

## Worktree

Use `superpowers:using-git-worktrees` to set up an isolated workspace before starting (project convention is `.worktrees/<branch>`). Suggested branch name: `feat/calendar-imports-phase2`.

---

## Task list

### Task 1: `MonthlyPnl` dataclass

**Files:**
- Modify: `src/net_alpha/portfolio/models.py` (append at end of file)
- Test: `tests/portfolio/test_calendar_pnl.py` (will be written in Task 2)

- [ ] **Step 1: Add the model**

Append to `src/net_alpha/portfolio/models.py`:

```python
@dataclass(frozen=True)
class MonthlyPnl:
    """One month's realized P&L for the calendar P&L ribbon."""

    month: int  # 1..12
    net_pl: Decimal  # gain - loss
    gross_gain: Decimal  # sum of positive sell P&L
    gross_loss: Decimal  # sum of |negative sell P&L| (positive number)
    trade_count: int  # number of sell trades contributing
```

- [ ] **Step 2: Verify imports compile**

Run: `uv run python -c "from net_alpha.portfolio.models import MonthlyPnl; print(MonthlyPnl(1, __import__('decimal').Decimal('0'), __import__('decimal').Decimal('0'), __import__('decimal').Decimal('0'), 0))"`
Expected: prints `MonthlyPnl(month=1, net_pl=Decimal('0'), gross_gain=Decimal('0'), gross_loss=Decimal('0'), trade_count=0)`

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/portfolio/models.py
git commit -m "feat(portfolio): add MonthlyPnl model for calendar ribbon"
```

---

### Task 2: `monthly_realized_pl` pure aggregator

**Files:**
- Create: `src/net_alpha/portfolio/calendar_pnl.py`
- Create: `tests/portfolio/test_calendar_pnl.py`

- [ ] **Step 1: Write the failing test**

Create `tests/portfolio/test_calendar_pnl.py`:

```python
import datetime as dt
from decimal import Decimal

from net_alpha.models.domain import Trade
from net_alpha.portfolio.calendar_pnl import monthly_realized_pl


def _sell(day, *, ticker="SPY", account="Tax", proceeds, cost, qty=10.0):
    return Trade(
        account=account,
        date=day,
        ticker=ticker,
        action="Sell",
        quantity=qty,
        proceeds=proceeds,
        cost_basis=cost,
    )


def _buy(day, *, ticker="SPY", account="Tax", cost=1000.0, qty=10.0):
    return Trade(
        account=account,
        date=day,
        ticker=ticker,
        action="Buy",
        quantity=qty,
        proceeds=None,
        cost_basis=cost,
    )


def test_returns_12_months_for_year_with_no_trades():
    out = monthly_realized_pl(trades=[], year=2026, ticker=None, account=None)
    assert len(out) == 12
    assert all(m.net_pl == Decimal("0") for m in out)
    assert all(m.trade_count == 0 for m in out)
    assert [m.month for m in out] == list(range(1, 13))


def test_aggregates_only_sells_in_target_year():
    trades = [
        _sell(dt.date(2026, 3, 5), proceeds=1500, cost=1000),  # gain 500 in Mar
        _sell(dt.date(2025, 3, 5), proceeds=1500, cost=1000),  # different year — skipped
        _buy(dt.date(2026, 3, 5)),                              # buys ignored
    ]
    out = monthly_realized_pl(trades=trades, year=2026, ticker=None, account=None)
    march = next(m for m in out if m.month == 3)
    assert march.net_pl == Decimal("500")
    assert march.gross_gain == Decimal("500")
    assert march.gross_loss == Decimal("0")
    assert march.trade_count == 1
    feb = next(m for m in out if m.month == 2)
    assert feb.net_pl == Decimal("0")
    assert feb.trade_count == 0


def test_mixed_month_splits_gain_and_loss():
    trades = [
        _sell(dt.date(2026, 4, 1), proceeds=1500, cost=1000),  # +500
        _sell(dt.date(2026, 4, 2), proceeds=800, cost=1200),   # -400
    ]
    out = monthly_realized_pl(trades=trades, year=2026, ticker=None, account=None)
    apr = next(m for m in out if m.month == 4)
    assert apr.net_pl == Decimal("100")
    assert apr.gross_gain == Decimal("500")
    assert apr.gross_loss == Decimal("400")
    assert apr.trade_count == 2


def test_ticker_filter_drops_other_tickers():
    trades = [
        _sell(dt.date(2026, 5, 10), ticker="SPY", proceeds=1500, cost=1000),
        _sell(dt.date(2026, 5, 11), ticker="QQQ", proceeds=2000, cost=1000),
    ]
    out = monthly_realized_pl(trades=trades, year=2026, ticker="SPY", account=None)
    may = next(m for m in out if m.month == 5)
    assert may.net_pl == Decimal("500")
    assert may.trade_count == 1


def test_account_filter_drops_other_accounts():
    trades = [
        _sell(dt.date(2026, 6, 10), account="schwab/tax", proceeds=1500, cost=1000),
        _sell(dt.date(2026, 6, 11), account="schwab/ira", proceeds=2000, cost=1000),
    ]
    out = monthly_realized_pl(trades=trades, year=2026, ticker=None, account="schwab/tax")
    jun = next(m for m in out if m.month == 6)
    assert jun.net_pl == Decimal("500")
    assert jun.trade_count == 1


def test_trades_with_missing_proceeds_or_cost_skipped():
    trades = [
        _sell(dt.date(2026, 7, 1), proceeds=1500, cost=1000),
        Trade(account="Tax", date=dt.date(2026, 7, 2), ticker="SPY", action="Sell",
              quantity=10.0, proceeds=None, cost_basis=1000.0),
        Trade(account="Tax", date=dt.date(2026, 7, 3), ticker="SPY", action="Sell",
              quantity=10.0, proceeds=1500.0, cost_basis=None),
    ]
    out = monthly_realized_pl(trades=trades, year=2026, ticker=None, account=None)
    jul = next(m for m in out if m.month == 7)
    assert jul.trade_count == 1
    assert jul.net_pl == Decimal("500")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_calendar_pnl.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.portfolio.calendar_pnl'`.

- [ ] **Step 3: Implement the aggregator**

Create `src/net_alpha/portfolio/calendar_pnl.py`:

```python
"""Monthly realized-P&L aggregation for the calendar dual-ribbon view."""

from __future__ import annotations

from collections.abc import Iterable
from decimal import Decimal

from net_alpha.models.domain import Trade
from net_alpha.portfolio.models import MonthlyPnl


def monthly_realized_pl(
    *,
    trades: Iterable[Trade],
    year: int,
    ticker: str | None,
    account: str | None,
) -> list[MonthlyPnl]:
    """Return 12 MonthlyPnl rows (Jan..Dec) of realized sell P&L for `year`.

    Filters: trades not in `year`, not Sell, missing proceeds/cost, mismatching
    ticker, or mismatching account are excluded.
    """
    buckets: dict[int, dict[str, Decimal | int]] = {
        m: {"gain": Decimal("0"), "loss": Decimal("0"), "count": 0} for m in range(1, 13)
    }
    for t in trades:
        if t.date.year != year:
            continue
        if t.action.lower() != "sell":
            continue
        if t.proceeds is None or t.cost_basis is None:
            continue
        if ticker is not None and t.ticker != ticker:
            continue
        if account is not None and t.account != account:
            continue
        pl = Decimal(str(t.proceeds)) - Decimal(str(t.cost_basis))
        bucket = buckets[t.date.month]
        if pl >= 0:
            bucket["gain"] += pl
        else:
            bucket["loss"] += -pl
        bucket["count"] += 1
    return [
        MonthlyPnl(
            month=m,
            net_pl=buckets[m]["gain"] - buckets[m]["loss"],
            gross_gain=buckets[m]["gain"],
            gross_loss=buckets[m]["loss"],
            trade_count=int(buckets[m]["count"]),
        )
        for m in range(1, 13)
    ]
```

- [ ] **Step 4: Run test to verify pass**

Run: `uv run pytest tests/portfolio/test_calendar_pnl.py -v`
Expected: 6 passed.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/calendar_pnl.py tests/portfolio/test_calendar_pnl.py
git commit -m "feat(portfolio): add monthly_realized_pl aggregator"
```

---

### Task 3: Calendar P&L ribbon partial template

**Files:**
- Create: `src/net_alpha/web/templates/_calendar_pl_ribbon.html`

- [ ] **Step 1: Write the partial**

Create `src/net_alpha/web/templates/_calendar_pl_ribbon.html`:

```html
{% set max_abs = (monthly_pl|map(attribute='net_pl')|map('abs')|max) if monthly_pl else 0 %}
<div class="kpi-card mb-3">
  <div class="text-xs text-slate-500 uppercase mb-2">{{ selected_year }} — monthly realized P&amp;L</div>
  <div class="grid grid-cols-12 gap-1 h-16 items-end">
    {% for m in monthly_pl %}
      {% if max_abs and m.net_pl != 0 %}
        {% set height_pct = ((m.net_pl|abs) / max_abs * 100)|round(1) %}
      {% else %}
        {% set height_pct = 0 %}
      {% endif %}
      <div class="relative h-full flex items-end justify-center" title="{{ '%02d'|format(m.month) }}: net ${{ '%.2f'|format(m.net_pl) }} · gain ${{ '%.2f'|format(m.gross_gain) }} · loss ${{ '%.2f'|format(m.gross_loss) }} · {{ m.trade_count }} trade(s)">
        <div class="w-full rounded-sm transition-opacity hover:opacity-80"
             style="height: {{ height_pct }}%; background-color: {% if m.net_pl > 0 %}#16A34A{% elif m.net_pl < 0 %}#DC2626{% else %}#E2E8F0{% endif %};">
        </div>
      </div>
    {% endfor %}
  </div>
  <div class="grid grid-cols-12 gap-1 mt-1 text-[10px] text-slate-400 text-center">
    {% for label in ["J","F","M","A","M","J","J","A","S","O","N","D"] %}
      <div>{{ label }}</div>
    {% endfor %}
  </div>
</div>
```

- [ ] **Step 2: Render in isolation to validate Jinja syntax**

Run:
```bash
uv run python -c "
from jinja2 import Environment, FileSystemLoader
from decimal import Decimal
from net_alpha.portfolio.models import MonthlyPnl
env = Environment(loader=FileSystemLoader('src/net_alpha/web/templates'))
tpl = env.get_template('_calendar_pl_ribbon.html')
html = tpl.render(selected_year=2026, monthly_pl=[
    MonthlyPnl(m, Decimal('100' if m == 3 else '-50' if m == 5 else '0'), Decimal('100' if m == 3 else '0'), Decimal('50' if m == 5 else '0'), 1 if m in (3, 5) else 0)
    for m in range(1, 13)
])
assert '#16A34A' in html and '#DC2626' in html
print('OK')
"
```
Expected: `OK`.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/_calendar_pl_ribbon.html
git commit -m "feat(web): add monthly P&L ribbon partial"
```

---

### Task 4: Wire P&L ribbon into calendar route + stack ribbons

**Files:**
- Modify: `src/net_alpha/web/routes/calendar.py`
- Modify: `src/net_alpha/web/templates/calendar.html`

- [ ] **Step 1: Update the route**

Edit `src/net_alpha/web/routes/calendar.py`. After the existing imports, add:

```python
from net_alpha.portfolio.calendar_pnl import monthly_realized_pl
```

Inside `calendar_page`, after the line `years = sorted({v.loss_sale_date.year ...`, add:

```python
    pl_trades = repo.all_trades()
    if ticker:
        pl_trades = [t for t in pl_trades if t.ticker == ticker.upper()]
    monthly_pl = monthly_realized_pl(
        trades=pl_trades,
        year=selected_year,
        ticker=ticker.upper() if ticker else None,
        account=account or None,
    )
```

Then in the `TemplateResponse(...)` context dict, add the new key:

```python
            "monthly_pl": monthly_pl,
```

The full revised context block should look like:

```python
    return request.app.state.templates.TemplateResponse(
        request,
        "calendar.html",
        {
            "markers": markers,
            "selected_year": selected_year,
            "years": years,
            "filter_ticker": ticker or "",
            "filter_account": account or "",
            "filter_confidence": confidence or "",
            "tickers": repo.list_distinct_tickers(),
            "accounts": [a.display() for a in repo.list_accounts()],
            "monthly_pl": monthly_pl,
        },
    )
```

- [ ] **Step 2: Stack the ribbons in the template**

Edit `src/net_alpha/web/templates/calendar.html`. Replace the line:

```jinja
  {% include "_calendar_ribbon.html" %}
```

with:

```jinja
  {% include "_calendar_pl_ribbon.html" %}
  {% include "_calendar_ribbon.html" %}
```

- [ ] **Step 3: Add an integration assertion**

Edit `tests/web/test_calendar.py`. Append:

```python
def test_calendar_renders_monthly_pl_ribbon(client, repo, builders):
    from datetime import date
    trades = [
        builders.make_sell("schwab/personal", "AAPL", date(2026, 3, 5), qty=10, proceeds=1500, cost=1000),
        builders.make_sell("schwab/personal", "AAPL", date(2026, 5, 12), qty=10, proceeds=800, cost=1200),
    ]
    builders.seed_import(repo, "schwab", "personal", trades)
    resp = client.get("/calendar?year=2026")
    assert resp.status_code == 200
    body = resp.text
    assert "monthly realized" in body.lower()
    # Green bar for March (gain) and red bar for May (loss) both rendered.
    assert "#16A34A" in body
    assert "#DC2626" in body
```

- [ ] **Step 4: Run all calendar tests**

Run: `uv run pytest tests/web/test_calendar.py tests/portfolio/test_calendar_pnl.py -v`
Expected: all pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/calendar.py src/net_alpha/web/templates/calendar.html tests/web/test_calendar.py
git commit -m "feat(web): stack monthly P&L ribbon above wash-sale dots"
```

---

### Task 5: Schema v3 → v4 — add 6 columns to `imports`

**Files:**
- Modify: `src/net_alpha/db/tables.py`
- Modify: `src/net_alpha/db/migrations.py`

- [ ] **Step 1: Add columns to `ImportRecordRow`**

Edit `src/net_alpha/db/tables.py`. Replace the existing `ImportRecordRow` class with:

```python
class ImportRecordRow(SQLModel, table=True):
    __tablename__ = "imports"

    id: int | None = Field(default=None, primary_key=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    csv_filename: str
    csv_sha256: str = Field(index=True)
    imported_at: datetime
    trade_count: int

    # v4 additions — populated on import or backfilled at startup.
    min_trade_date: str | None = None
    max_trade_date: str | None = None
    equity_count: int | None = None
    option_count: int | None = None
    option_expiry_count: int | None = None
    parse_warnings_json: str | None = None  # JSON-encoded list[str]; "[]" = no warnings
```

- [ ] **Step 2: Add the migration step**

Edit `src/net_alpha/db/migrations.py`. Update `CURRENT_SCHEMA_VERSION` to `4`. Update the docstring at the top to add:

```
  v4 — Adds aggregate columns to imports (date range, type counts, parse warnings).
```

After `_migrate_v2_to_v3`, add:

```python
def _migrate_v3_to_v4(session: Session) -> None:
    """Add 6 nullable aggregate columns to imports. Backfill happens later via
    `import_.backfill.backfill_import_aggregates`, called from init_db."""
    additions = [
        ("min_trade_date", "TEXT"),
        ("max_trade_date", "TEXT"),
        ("equity_count", "INTEGER"),
        ("option_count", "INTEGER"),
        ("option_expiry_count", "INTEGER"),
        ("parse_warnings_json", "TEXT"),
    ]
    for col, sqltype in additions:
        if not _column_exists(session, "imports", col):
            session.exec(text(f"ALTER TABLE imports ADD COLUMN {col} {sqltype}"))
    session.commit()
```

Update `migrate()` — replace the existing function body with:

```python
def migrate(session: Session) -> None:
    """Apply pending migrations idempotently."""
    current = get_schema_version(session)
    if current == 0:
        # Fresh DB: SQLModel.metadata.create_all has already produced the
        # current-shape tables. Just stamp the version.
        set_schema_version(session, CURRENT_SCHEMA_VERSION)
        return
    if current == 1:
        _migrate_v1_to_v2(session)
        set_schema_version(session, 2)
        current = 2
    if current == 2:
        _migrate_v2_to_v3(session)
        set_schema_version(session, 3)
        current = 3
    if current == 3:
        _migrate_v3_to_v4(session)
        set_schema_version(session, 4)
        return
    if current > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"DB schema_version={current} is newer than this binary "
            f"(supports {CURRENT_SCHEMA_VERSION}). Upgrade net-alpha."
        )
```

- [ ] **Step 3: Run existing DB tests**

Run: `uv run pytest tests/db/ -v`
Expected: all pass (we're additive on the table; existing tests don't reference the new columns).

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/db/tables.py src/net_alpha/db/migrations.py
git commit -m "feat(db): schema v4 — add aggregate columns to imports"
```

---

### Task 6: Migration test for v3 → v4

**Files:**
- Create: `tests/db/test_v3_to_v4_migration.py`

- [ ] **Step 1: Write the migration test**

Create `tests/db/test_v3_to_v4_migration.py`:

```python
"""Schema migration test: v3 DB upgrades cleanly to v4 with new NULL columns."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import text
from sqlmodel import Session, create_engine

from net_alpha.db.migrations import _migrate_v3_to_v4, get_schema_version, migrate, set_schema_version


def _build_v3_db(db_path: Path):
    """Construct a minimal v3-shape DB with a couple of import rows."""
    eng = create_engine(f"sqlite:///{db_path}", echo=False)
    with Session(eng) as s:
        s.exec(text("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)"))
        s.exec(
            text(
                "CREATE TABLE accounts (id INTEGER PRIMARY KEY, broker TEXT, label TEXT)"
            )
        )
        s.exec(
            text(
                "CREATE TABLE imports ("
                "id INTEGER PRIMARY KEY, account_id INTEGER, csv_filename TEXT, "
                "csv_sha256 TEXT, imported_at DATETIME, trade_count INTEGER)"
            )
        )
        s.exec(text("INSERT INTO accounts(broker, label) VALUES ('schwab', 'tax')"))
        s.exec(
            text(
                "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
                "VALUES (1, 'old.csv', 'abc', '2026-01-01 00:00:00', 5)"
            )
        )
        s.commit()
        set_schema_version(s, 3)
    return eng


def test_v3_to_v4_adds_columns_and_bumps_version(tmp_path: Path):
    eng = _build_v3_db(tmp_path / "v3.db")
    with Session(eng) as s:
        assert get_schema_version(s) == 3
        migrate(s)
        assert get_schema_version(s) == 4
        cols = {r[1] for r in s.exec(text("PRAGMA table_info(imports)")).all()}
        for col in [
            "min_trade_date",
            "max_trade_date",
            "equity_count",
            "option_count",
            "option_expiry_count",
            "parse_warnings_json",
        ]:
            assert col in cols, f"missing column: {col}"
        # Existing row preserved with NULL aggregates.
        row = s.exec(
            text("SELECT min_trade_date, equity_count FROM imports WHERE id = 1")
        ).first()
        assert row[0] is None
        assert row[1] is None


def test_v3_to_v4_idempotent(tmp_path: Path):
    eng = _build_v3_db(tmp_path / "v3.db")
    with Session(eng) as s:
        _migrate_v3_to_v4(s)
        # Run a second time — should not raise.
        _migrate_v3_to_v4(s)
        cols = {r[1] for r in s.exec(text("PRAGMA table_info(imports)")).all()}
        assert "min_trade_date" in cols
```

- [ ] **Step 2: Run the test**

Run: `uv run pytest tests/db/test_v3_to_v4_migration.py -v`
Expected: 2 passed.

- [ ] **Step 3: Commit**

```bash
git add tests/db/test_v3_to_v4_migration.py
git commit -m "test(db): cover v3 → v4 migration"
```

---

### Task 7: Domain model fields on `ImportRecord` and `ImportSummary`

**Files:**
- Modify: `src/net_alpha/models/domain.py`

- [ ] **Step 1: Extend the models**

Edit `src/net_alpha/models/domain.py`. Replace the `ImportRecord` class with:

```python
class ImportRecord(BaseModel):
    """Metadata for one CSV import. Trades hold a FK to this."""

    id: int | None = None
    account_id: int
    csv_filename: str
    csv_sha256: str
    imported_at: datetime
    trade_count: int
    # v4 additions — optional; populated by import path or backfill.
    min_trade_date: date | None = None
    max_trade_date: date | None = None
    equity_count: int | None = None
    option_count: int | None = None
    option_expiry_count: int | None = None
    parse_warnings: list[str] = Field(default_factory=list)
```

Replace the `ImportSummary` class with:

```python
class ImportSummary(BaseModel):
    """Display row for `net-alpha imports`."""

    id: int
    account_display: str
    csv_filename: str
    trade_count: int
    imported_at: datetime
    gl_lot_count: int = 0
    # v4 additions; None means "not yet aggregated" (rendered as em-dash).
    min_trade_date: date | None = None
    max_trade_date: date | None = None
    equity_count: int | None = None
    option_count: int | None = None
    option_expiry_count: int | None = None
    parse_warnings: list[str] = Field(default_factory=list)
```

- [ ] **Step 2: Verify existing tests still pass**

Run: `uv run pytest tests/models/ -v`
Expected: all pass (existing tests do not assert that absent fields are absent).

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/models/domain.py
git commit -m "feat(models): extend ImportRecord and ImportSummary with v4 aggregate fields"
```

---

### Task 8: `compute_import_aggregates` pure function

**Files:**
- Create: `src/net_alpha/import_/__init__.py`
- Create: `src/net_alpha/import_/aggregations.py`
- Create: `tests/import_/__init__.py`
- Create: `tests/import_/test_aggregations.py`

- [ ] **Step 1: Add package init files**

Create empty file `src/net_alpha/import_/__init__.py` (zero bytes).
Create empty file `tests/import_/__init__.py` (zero bytes).

```bash
touch src/net_alpha/import_/__init__.py tests/import_/__init__.py
```

- [ ] **Step 2: Write the failing test**

Create `tests/import_/test_aggregations.py`:

```python
import datetime as dt

from net_alpha.import_.aggregations import compute_import_aggregates
from net_alpha.models.domain import OptionDetails, Trade


def _t(day, *, ticker="AAPL", action="Buy", opt=None):
    return Trade(
        account="schwab/tax",
        date=day,
        ticker=ticker,
        action=action,
        quantity=10.0,
        proceeds=None if action == "Buy" else 1000.0,
        cost_basis=1000.0 if action == "Buy" else None,
        option_details=opt,
    )


def _opt(strike=100.0, expiry=dt.date(2026, 6, 19), call_put="C"):
    return OptionDetails(strike=strike, expiry=expiry, call_put=call_put)


def test_empty_returns_zero_counts_and_none_dates():
    out = compute_import_aggregates(trades=[], parse_warnings=[])
    assert out.min_trade_date is None
    assert out.max_trade_date is None
    assert out.equity_count == 0
    assert out.option_count == 0
    assert out.option_expiry_count == 0
    assert out.parse_warnings == []


def test_date_range_min_and_max():
    out = compute_import_aggregates(
        trades=[
            _t(dt.date(2026, 1, 5)),
            _t(dt.date(2026, 3, 12)),
            _t(dt.date(2026, 2, 28)),
        ],
        parse_warnings=[],
    )
    assert out.min_trade_date == dt.date(2026, 1, 5)
    assert out.max_trade_date == dt.date(2026, 3, 12)


def test_equity_vs_option_split():
    trades = [
        _t(dt.date(2026, 1, 5)),                              # equity
        _t(dt.date(2026, 1, 6)),                              # equity
        _t(dt.date(2026, 1, 7), opt=_opt()),                  # option
    ]
    out = compute_import_aggregates(trades=trades, parse_warnings=[])
    assert out.equity_count == 2
    assert out.option_count == 1
    assert out.option_expiry_count == 0


def test_parse_warnings_passed_through():
    out = compute_import_aggregates(trades=[], parse_warnings=["row 4: bad date", "row 7: skipped"])
    assert out.parse_warnings == ["row 4: bad date", "row 7: skipped"]
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/import_/test_aggregations.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.import_.aggregations'`.

- [ ] **Step 4: Implement the aggregator**

Create `src/net_alpha/import_/aggregations.py`:

```python
"""Pure aggregator for import metadata shown on the Imports page detail panel.

Inputs are the parsed Trade list for a single import plus any parse warnings
captured by the broker parser. Output is persisted to the imports table by
the caller (the upload route) and read back by list_imports / detail.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import date

from net_alpha.models.domain import Trade


@dataclass(frozen=True)
class ImportAggregates:
    min_trade_date: date | None
    max_trade_date: date | None
    equity_count: int
    option_count: int
    option_expiry_count: int  # currently always 0 — Schwab parser drops "Expired" rows;
    # column reserved for when raw broker actions are preserved.
    parse_warnings: list[str] = field(default_factory=list)


def compute_import_aggregates(
    *,
    trades: Iterable[Trade],
    parse_warnings: Iterable[str],
) -> ImportAggregates:
    trades_list = list(trades)
    if not trades_list:
        return ImportAggregates(
            min_trade_date=None,
            max_trade_date=None,
            equity_count=0,
            option_count=0,
            option_expiry_count=0,
            parse_warnings=list(parse_warnings),
        )
    dates = [t.date for t in trades_list]
    equity = sum(1 for t in trades_list if t.option_details is None)
    option = sum(1 for t in trades_list if t.option_details is not None)
    return ImportAggregates(
        min_trade_date=min(dates),
        max_trade_date=max(dates),
        equity_count=equity,
        option_count=option,
        option_expiry_count=0,
        parse_warnings=list(parse_warnings),
    )
```

- [ ] **Step 5: Run test to verify pass**

Run: `uv run pytest tests/import_/test_aggregations.py -v`
Expected: 4 passed.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/import_/__init__.py src/net_alpha/import_/aggregations.py tests/import_/__init__.py tests/import_/test_aggregations.py
git commit -m "feat(import): add compute_import_aggregates pure function"
```

---

### Task 9: Repository `add_import` persists aggregates; `list_imports` returns them; `get_import_detail`

**Files:**
- Modify: `src/net_alpha/db/repository.py`

- [ ] **Step 1: Persist aggregates in `add_import`**

Edit `src/net_alpha/db/repository.py`. In the `add_import` method, change the construction of `ImportRecordRow` (around line 112) to include the v4 fields:

```python
            ir = ImportRecordRow(
                account_id=account.id,
                csv_filename=record.csv_filename,
                csv_sha256=record.csv_sha256,
                imported_at=record.imported_at,
                trade_count=len(trades),
                min_trade_date=record.min_trade_date.isoformat() if record.min_trade_date else None,
                max_trade_date=record.max_trade_date.isoformat() if record.max_trade_date else None,
                equity_count=record.equity_count,
                option_count=record.option_count,
                option_expiry_count=record.option_expiry_count,
                parse_warnings_json=__import__("json").dumps(record.parse_warnings) if record.parse_warnings else None,
            )
```

(The `__import__("json")` call avoids adding a new top-level import; if you prefer, add `import json` at the top of the file and call `json.dumps(...)`. Either is fine — pick the cleaner one.)

- [ ] **Step 2: Surface aggregates in `list_imports`**

Inside `list_imports`, replace the `ImportSummary(...)` construction with:

```python
                out.append(
                    ImportSummary(
                        id=ir.id,
                        account_display=f"{a.broker}/{a.label}",
                        csv_filename=ir.csv_filename,
                        trade_count=ir.trade_count,
                        imported_at=ir.imported_at,
                        gl_lot_count=int(gl_count or 0),
                        min_trade_date=date.fromisoformat(ir.min_trade_date) if ir.min_trade_date else None,
                        max_trade_date=date.fromisoformat(ir.max_trade_date) if ir.max_trade_date else None,
                        equity_count=ir.equity_count,
                        option_count=ir.option_count,
                        option_expiry_count=ir.option_expiry_count,
                        parse_warnings=__import__("json").loads(ir.parse_warnings_json) if ir.parse_warnings_json else [],
                    )
                )
```

- [ ] **Step 3: Add `get_import_detail` and `update_import_aggregates`**

Append to the `Repository` class (place near the other import-related methods, after `remove_import`):

```python
    def update_import_aggregates(
        self,
        *,
        import_id: int,
        min_trade_date: date | None,
        max_trade_date: date | None,
        equity_count: int,
        option_count: int,
        option_expiry_count: int,
        parse_warnings: list[str],
    ) -> None:
        """Persist aggregate columns. Used by the backfill helper."""
        import json

        with Session(self.engine) as s:
            row = s.get(ImportRecordRow, import_id)
            if row is None:
                raise LookupError(f"Import #{import_id} not found")
            row.min_trade_date = min_trade_date.isoformat() if min_trade_date else None
            row.max_trade_date = max_trade_date.isoformat() if max_trade_date else None
            row.equity_count = equity_count
            row.option_count = option_count
            row.option_expiry_count = option_expiry_count
            row.parse_warnings_json = json.dumps(parse_warnings) if parse_warnings else None
            s.add(row)
            s.commit()

    def get_import_detail(self, import_id: int) -> dict | None:
        """Return a dict of detail-panel fields for the imports detail fragment.

        Includes: aggregate columns, plus an account hint (the first ticker count),
        plus distinct-ticker info pulled live from the joined trade rows.
        Returns None if the import does not exist.
        """
        rec = self.get_import(import_id)
        if rec is None:
            return None
        trades = self.trades_for_import(import_id)
        distinct_tickers = sorted({t.ticker for t in trades})
        with Session(self.engine) as s:
            ir = s.get(ImportRecordRow, import_id)
            account_row = s.exec(select(AccountRow).where(AccountRow.id == ir.account_id)).first()
            broker = account_row.broker if account_row else "unknown"
            label = account_row.label if account_row else "unknown"
            warnings = []
            if ir.parse_warnings_json:
                import json
                warnings = json.loads(ir.parse_warnings_json)
        return {
            "id": import_id,
            "broker": broker,
            "account_label": label,
            "csv_filename": rec.csv_filename,
            "min_trade_date": rec.min_trade_date,
            "max_trade_date": rec.max_trade_date,
            "equity_count": rec.equity_count or 0,
            "option_count": rec.option_count or 0,
            "option_expiry_count": rec.option_expiry_count or 0,
            "distinct_ticker_count": len(distinct_tickers),
            "tickers_preview": distinct_tickers[:5],
            "parse_warnings": warnings,
        }
```

- [ ] **Step 4: Run repository tests**

Run: `uv run pytest tests/db/ -v`
Expected: all pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py
git commit -m "feat(repo): persist and surface import aggregates; add get_import_detail"
```

---

### Task 10: Backfill helper for legacy imports

**Files:**
- Create: `src/net_alpha/import_/backfill.py`
- Create: `tests/import_/test_backfill.py`

- [ ] **Step 1: Write the failing test**

Create `tests/import_/test_backfill.py`:

```python
from datetime import date, datetime
from pathlib import Path

from sqlmodel import SQLModel

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.import_.backfill import backfill_import_aggregates
from net_alpha.models.domain import ImportRecord, Trade


def _settings(tmp_path: Path) -> Settings:
    return Settings(data_dir=tmp_path)


def _make_repo(tmp_path: Path) -> Repository:
    eng = get_engine(_settings(tmp_path).db_path)
    SQLModel.metadata.create_all(eng)
    return Repository(eng)


def _trade(account, day, ticker="AAPL"):
    return Trade(
        account=account,
        date=day,
        ticker=ticker,
        action="Buy",
        quantity=10.0,
        proceeds=None,
        cost_basis=1000.0,
    )


def test_backfill_fills_missing_aggregates(tmp_path: Path):
    repo = _make_repo(tmp_path)
    acct = repo.get_or_create_account("schwab", "tax")
    rec = ImportRecord(
        account_id=acct.id,
        csv_filename="legacy.csv",
        csv_sha256="x",
        imported_at=datetime(2026, 1, 1),
        trade_count=2,
        # Aggregate fields intentionally omitted to simulate a legacy v3 row.
    )
    trades = [_trade(acct.display(), date(2026, 1, 5)), _trade(acct.display(), date(2026, 1, 10))]
    repo.add_import(acct, rec, trades)

    # Confirm aggregates start empty for this row.
    summary_before = repo.list_imports()[0]
    assert summary_before.min_trade_date is None

    n = backfill_import_aggregates(repo)
    assert n == 1

    summary = repo.list_imports()[0]
    assert summary.min_trade_date == date(2026, 1, 5)
    assert summary.max_trade_date == date(2026, 1, 10)
    assert summary.equity_count == 2
    assert summary.option_count == 0


def test_backfill_is_idempotent(tmp_path: Path):
    repo = _make_repo(tmp_path)
    acct = repo.get_or_create_account("schwab", "tax")
    rec = ImportRecord(
        account_id=acct.id,
        csv_filename="legacy.csv",
        csv_sha256="x",
        imported_at=datetime(2026, 1, 1),
        trade_count=1,
    )
    repo.add_import(acct, rec, [_trade(acct.display(), date(2026, 1, 5))])

    assert backfill_import_aggregates(repo) == 1
    assert backfill_import_aggregates(repo) == 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/import_/test_backfill.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.import_.backfill'`.

- [ ] **Step 3: Implement the backfill helper**

Create `src/net_alpha/import_/backfill.py`:

```python
"""One-time backfill of aggregate columns for legacy import rows.

Idempotent: only updates rows where aggregate columns are still NULL.
Called from db.connection.init_db immediately after migrate().
"""

from __future__ import annotations

from sqlmodel import Session, select

from net_alpha.db.repository import Repository
from net_alpha.db.tables import ImportRecordRow
from net_alpha.import_.aggregations import compute_import_aggregates


def backfill_import_aggregates(repo: Repository) -> int:
    """Recompute and persist aggregates for any import row missing them.

    Returns the number of rows updated.
    """
    with Session(repo.engine) as s:
        candidate_ids = [
            row.id
            for row in s.exec(select(ImportRecordRow).where(ImportRecordRow.min_trade_date.is_(None))).all()
        ]
    updated = 0
    for import_id in candidate_ids:
        trades = repo.trades_for_import(import_id)
        aggregates = compute_import_aggregates(trades=trades, parse_warnings=[])
        repo.update_import_aggregates(
            import_id=import_id,
            min_trade_date=aggregates.min_trade_date,
            max_trade_date=aggregates.max_trade_date,
            equity_count=aggregates.equity_count,
            option_count=aggregates.option_count,
            option_expiry_count=aggregates.option_expiry_count,
            parse_warnings=aggregates.parse_warnings,
        )
        updated += 1
    return updated
```

- [ ] **Step 4: Run test**

Run: `uv run pytest tests/import_/test_backfill.py -v`
Expected: 2 passed.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/backfill.py tests/import_/test_backfill.py
git commit -m "feat(import): backfill aggregates for legacy import rows"
```

---

### Task 11: Wire backfill into `init_db`

**Files:**
- Modify: `src/net_alpha/db/connection.py`

- [ ] **Step 1: Call backfill after migrate**

Edit `src/net_alpha/db/connection.py`. Replace `init_db` with:

```python
def init_db(engine) -> None:
    """Create all tables (idempotent), run pending migrations, and backfill
    aggregate columns on legacy import rows."""
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        migrate(session)
    # Backfill must run after migrate so the v4 columns exist; uses its own
    # sessions internally via Repository.
    from net_alpha.db.repository import Repository
    from net_alpha.import_.backfill import backfill_import_aggregates

    backfill_import_aggregates(Repository(engine))
```

- [ ] **Step 2: Run the full DB + import test suite**

Run: `uv run pytest tests/db/ tests/import_/ tests/web/ -v`
Expected: all pass.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/db/connection.py
git commit -m "feat(db): backfill import aggregates on init_db"
```

---

### Task 12: Compute and persist aggregates during upload

**Files:**
- Modify: `src/net_alpha/web/routes/imports.py`

- [ ] **Step 1: Wire `compute_import_aggregates` into the upload path**

Edit `src/net_alpha/web/routes/imports.py`. Add to the imports block at the top:

```python
from net_alpha.import_.aggregations import compute_import_aggregates
```

Inside the `upload` function, find both `ImportRecord(...)` constructions (one for the SchwabParser branch, one for the SchwabRealizedGLParser branch). Replace the SchwabParser branch's `ImportRecord(...)` with:

```python
            agg = compute_import_aggregates(trades=new_trades, parse_warnings=[])
            record = ImportRecord(
                account_id=acct.id,
                csv_filename=filename,
                csv_sha256=sha,
                imported_at=datetime.now(),
                trade_count=len(new_trades),
                min_trade_date=agg.min_trade_date,
                max_trade_date=agg.max_trade_date,
                equity_count=agg.equity_count,
                option_count=agg.option_count,
                option_expiry_count=agg.option_expiry_count,
                parse_warnings=agg.parse_warnings,
            )
```

For the `SchwabRealizedGLParser` branch — G/L lots have a `closed_date`. Replace its `ImportRecord(...)` with:

```python
            from datetime import date as _date
            gl_dates = [lot.closed_date for lot in lots] if lots else []
            min_d = min(gl_dates) if gl_dates else None
            max_d = max(gl_dates) if gl_dates else None
            equity_n = sum(1 for lot in lots if lot.option_strike is None)
            option_n = sum(1 for lot in lots if lot.option_strike is not None)
            record = ImportRecord(
                account_id=acct.id,
                csv_filename=filename,
                csv_sha256=sha,
                imported_at=datetime.now(),
                trade_count=0,
                min_trade_date=min_d,
                max_trade_date=max_d,
                equity_count=equity_n,
                option_count=option_n,
                option_expiry_count=0,
                parse_warnings=[],
            )
```

- [ ] **Step 2: Run upload tests**

Run: `uv run pytest tests/web/test_imports_routes.py tests/web/test_upload_flow.py tests/web/test_multi_file_upload.py tests/web/test_imports_table_files_column.py -v`
Expected: all pass.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/routes/imports.py
git commit -m "feat(web): compute and persist import aggregates on upload"
```

---

### Task 13: Updated imports table — summary line + expand toggle

**Files:**
- Modify: `src/net_alpha/web/templates/_imports_table.html`

- [ ] **Step 1: Replace the table partial**

Edit `src/net_alpha/web/templates/_imports_table.html`. Replace the entire file with:

```html
{% if not imports %}
  <div class="kpi-card text-slate-500 text-sm">No imports yet.</div>
{% else %}
  <table class="w-full text-sm bg-white rounded-lg shadow-sm border border-slate-200">
    <thead class="text-left text-xs text-slate-500 uppercase border-b border-slate-200">
      <tr>
        <th class="px-3 py-2"></th>
        <th class="px-3 py-2">ID</th>
        <th class="px-3 py-2">Imported at</th>
        <th class="px-3 py-2">Account</th>
        <th class="px-3 py-2">Filename</th>
        <th class="px-3 py-2">Summary</th>
        <th class="px-3 py-2">Actions</th>
      </tr>
    </thead>
    <tbody>
      {% for imp in imports %}
        {% set has_dates = imp.min_trade_date and imp.max_trade_date %}
        {% set total_units = (imp.trade_count or 0) + (imp.gl_lot_count or 0) %}
        <tr id="import-row-{{ imp.id }}" class="border-b border-slate-100 last:border-b-0 align-top">
          <td class="px-3 py-2">
            <button class="text-slate-400 hover:text-primary text-xs"
                    hx-get="/imports/{{ imp.id }}/detail"
                    hx-target="#import-detail-{{ imp.id }}"
                    hx-swap="innerHTML"
                    onclick="this.classList.toggle('rotate-90')">▸</button>
          </td>
          <td class="px-3 py-2 font-mono">#{{ imp.id }}</td>
          <td class="px-3 py-2 font-mono text-xs">{{ imp.imported_at.strftime("%Y-%m-%d %H:%M") }}</td>
          <td class="px-3 py-2">{{ imp.account_display }}</td>
          <td class="px-3 py-2">{{ imp.csv_filename }}</td>
          <td class="px-3 py-2 text-xs text-slate-600">
            {%- if has_dates -%}
              {{ imp.min_trade_date }} → {{ imp.max_trade_date }} ·
            {%- endif -%}
            {%- if imp.trade_count -%}
              {{ imp.trade_count }} trade{{ "s" if imp.trade_count != 1 else "" }}
            {%- endif -%}
            {%- if imp.gl_lot_count -%}
              {%- if imp.trade_count %} · {% endif -%}
              {{ imp.gl_lot_count }} G/L lot{{ "s" if imp.gl_lot_count != 1 else "" }}
            {%- endif -%}
            {%- if not total_units -%}<span class="text-slate-400">no records</span>{%- endif -%}
          </td>
          <td class="px-3 py-2">
            <button class="btn-ghost text-confirmed border-confirmed/30"
                    hx-delete="/imports/{{ imp.id }}"
                    hx-confirm="Remove import #{{ imp.id }} ({{ imp.trade_count }} trades, {{ imp.gl_lot_count }} G/L lots)? Wash sales will be recomputed."
                    hx-target="#imports-table"
                    hx-swap="innerHTML">
              Remove
            </button>
          </td>
        </tr>
        <tr id="import-detail-{{ imp.id }}" class="border-b border-slate-100 last:border-b-0 bg-slate-50">
          <!-- Empty initially; HTMX swaps in _imports_detail_row.html on first expand. -->
        </tr>
      {% endfor %}
    </tbody>
  </table>
{% endif %}
```

- [ ] **Step 2: Run the affected tests**

Run: `uv run pytest tests/web/test_imports_routes.py tests/web/test_imports_table_files_column.py -v`
Expected: pass — the existing assertions for `csv_filename`, `gl_lot_count`, and the "Remove" button are still met.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/_imports_table.html
git commit -m "feat(web): summary line and expand toggle on imports table"
```

---

### Task 14: `GET /imports/{id}/detail` route + detail partial

**Files:**
- Modify: `src/net_alpha/web/routes/imports.py`
- Create: `src/net_alpha/web/templates/_imports_detail_row.html`
- Create: `tests/web/test_imports_detail.py`

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_imports_detail.py`:

```python
from datetime import date


def test_import_detail_returns_fragment(client, repo, builders):
    trades = [
        builders.make_buy("schwab/personal", "AAPL", date(2026, 1, 5), qty=10, cost=1500),
        builders.make_buy("schwab/personal", "MSFT", date(2026, 1, 10), qty=5, cost=2000),
    ]
    _, import_id = builders.seed_import(repo, "schwab", "personal", trades, csv_filename="trades.csv")

    resp = client.get(f"/imports/{import_id}/detail")
    assert resp.status_code == 200
    assert "DOCTYPE" not in resp.text
    body = resp.text
    assert "schwab" in body.lower()
    assert "personal" in body
    assert "AAPL" in body
    assert "MSFT" in body
    # Distinct ticker count surfaced.
    assert "2" in body


def test_import_detail_404_for_unknown_id(client):
    resp = client.get("/imports/999999/detail")
    assert resp.status_code == 404
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_imports_detail.py -v`
Expected: FAIL — route does not exist (404 → wrong HTTP semantics, will produce a `404 Not Found` for first test too because route is missing).

- [ ] **Step 3: Implement the route**

Edit `src/net_alpha/web/routes/imports.py`. After the `remove_import` function, append:

```python
@router.get("/imports/{import_id}/detail", response_class=HTMLResponse)
def import_detail(
    import_id: int,
    request: Request,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    detail = repo.get_import_detail(import_id)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"Import #{import_id} not found")
    return request.app.state.templates.TemplateResponse(
        request,
        "_imports_detail_row.html",
        {"detail": detail},
    )
```

- [ ] **Step 4: Implement the detail partial**

Create `src/net_alpha/web/templates/_imports_detail_row.html`:

```html
<td colspan="7" class="px-6 py-3 text-xs text-slate-700">
  <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
    <div>
      <div class="text-slate-400 uppercase text-[10px]">Detected</div>
      <div class="font-mono">{{ detail.broker }} / {{ detail.account_label }}</div>
    </div>
    <div>
      <div class="text-slate-400 uppercase text-[10px]">Filename</div>
      <div class="font-mono break-all">{{ detail.csv_filename }}</div>
    </div>
    <div>
      <div class="text-slate-400 uppercase text-[10px]">Date range</div>
      <div class="font-mono">
        {% if detail.min_trade_date and detail.max_trade_date %}
          {{ detail.min_trade_date }} → {{ detail.max_trade_date }}
        {% else %}
          —
        {% endif %}
      </div>
    </div>
    <div>
      <div class="text-slate-400 uppercase text-[10px]">Equity / Option / Expiry</div>
      <div class="font-mono">{{ detail.equity_count }} · {{ detail.option_count }} · {{ detail.option_expiry_count }}</div>
    </div>
    <div>
      <div class="text-slate-400 uppercase text-[10px]">Distinct tickers</div>
      <div class="font-mono">
        {{ detail.distinct_ticker_count }}{% if detail.tickers_preview %}: {{ detail.tickers_preview|join(", ") }}{% if detail.distinct_ticker_count > detail.tickers_preview|length %} …{% endif %}{% endif %}
      </div>
    </div>
    {% if detail.parse_warnings %}
      <div class="md:col-span-3">
        <div class="text-slate-400 uppercase text-[10px]">Parse warnings</div>
        <ul class="list-disc list-inside text-confirmed">
          {% for w in detail.parse_warnings %}<li>{{ w }}</li>{% endfor %}
        </ul>
      </div>
    {% endif %}
  </div>
</td>
```

- [ ] **Step 5: Run the new test**

Run: `uv run pytest tests/web/test_imports_detail.py -v`
Expected: 2 passed.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/imports.py src/net_alpha/web/templates/_imports_detail_row.html tests/web/test_imports_detail.py
git commit -m "feat(web): GET /imports/{id}/detail returns expandable detail panel"
```

---

### Task 15: Embed drop zone in `imports.html`; remove "+ New import" link

**Files:**
- Modify: `src/net_alpha/web/templates/imports.html`
- Modify: `tests/web/test_imports_routes.py`

- [ ] **Step 1: Update the page template**

Edit `src/net_alpha/web/templates/imports.html`. Replace the entire file with:

```html
{% extends "base.html" %}
{% block title %}Imports · net-alpha{% endblock %}
{% block content %}
  <h1 class="text-2xl mb-4">Imports</h1>

  <div class="mb-4">
    {% include "_drop_zone.html" %}
  </div>

  <div id="imports-table">
    {% include "_imports_table.html" %}
  </div>
{% endblock %}
```

- [ ] **Step 2: Add a regression assertion**

Edit `tests/web/test_imports_routes.py`. Append:

```python
def test_imports_page_embeds_drop_zone(client):
    resp = client.get("/imports")
    assert resp.status_code == 200
    body = resp.text
    # Drop-zone is embedded directly on the page (not behind a "+ New import" link).
    assert "drop-zone" in body
    assert "+ New import" not in body
```

- [ ] **Step 3: Run all imports tests**

Run: `uv run pytest tests/web/test_imports_routes.py tests/web/test_imports_detail.py tests/web/test_upload_flow.py tests/web/test_multi_file_upload.py tests/web/test_imports_table_files_column.py -v`
Expected: all pass.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/templates/imports.html tests/web/test_imports_routes.py
git commit -m "feat(web): embed drop zone on imports page"
```

---

### Task 16: Full-suite regression sweep

- [ ] **Step 1: Run the entire test suite**

Run: `uv run pytest`
Expected: all green. If any test fails, fix root cause before proceeding (do NOT mark the task complete on red).

- [ ] **Step 2: Run lint + format**

Run: `uv run ruff check . && uv run ruff format --check .`
Expected: clean. If format-check fails, run `uv run ruff format .` and commit any formatting changes as a separate commit.

- [ ] **Step 3: Smoke-test the UI manually**

Start the server and verify the new behaviors in a browser:

```bash
uv run net-alpha ui --no-browser --port 8765
```

Open `http://127.0.0.1:8765/calendar` — expect to see the monthly P&L bar ribbon stacked above the wash-sale dot ribbon.
Open `http://127.0.0.1:8765/imports` — expect the drop-zone embedded above the table; each row shows a summary line (date range · trade count · G/L lots); clicking ▸ expands the detail panel.

Report back PASS/FAIL on each.

- [ ] **Step 4: Commit any formatting touch-ups (if Step 2 produced changes)**

```bash
git add -A
git commit -m "chore: ruff format"
```

---

## Self-review checklist (run before handoff)

After completing all tasks, verify:

1. **Calendar dual-ribbon (spec §Calendar):**
   - `MonthlyPnl` model present (Task 1) ✔
   - `monthly_realized_pl` pure function with year/ticker/account filters (Tasks 2) ✔
   - New partial `_calendar_pl_ribbon.html` (Task 3) ✔
   - Both ribbons stacked, route wired (Task 4) ✔
   - Tooltip shows month, net, gain, loss, trade count (Task 3 template) ✔

2. **Imports schema migration (spec §Imports):**
   - 6 new columns on `imports` (Task 5) ✔
   - Migration is idempotent (Task 6 second test) ✔
   - Domain models extended (Task 7) ✔

3. **Imports aggregates + backfill:**
   - Pure aggregator (Task 8) ✔
   - Backfill runs at startup, idempotent (Tasks 10, 11) ✔
   - Upload path persists aggregates for both Schwab parsers (Task 12) ✔

4. **Imports UI:**
   - Summary line on each row (Task 13) ✔
   - Expandable detail fragment (Task 14) ✔
   - Drop zone embedded; "+ New import" gone (Task 15) ✔

5. **Tests + clean tree:**
   - Full suite green (Task 16) ✔
   - Lint clean (Task 16) ✔

## Notes & known limitations

- **`option_expiry_count` is always 0** in this phase. The Schwab parser drops "Expired" rows because they don't fit the `Buy`/`Sell` action shape used downstream. The column is reserved so future work that preserves raw broker actions can populate it without another schema migration.
- **`parse_warnings` is always `[]`** in this phase. No parser currently emits warnings up to the route. Threading warnings end-to-end is a follow-up; the column and field are in place so it is purely additive when wired.
- **No new dependencies.** No CDN, no JS chart libs, no new Python deps. Bars are pure CSS/HTML in a 12-column grid.
- **Confidence filter** on the calendar is a no-op for the new top ribbon (per spec) — it only narrows the wash-sale dot layer beneath it. Visually correlating remains the point.
