# Phase 1 — Pricing Foundation + Portfolio Rebuild Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the wash-sale-focused Dashboard with a Portfolio overview backed by a new local-first pricing subsystem (Yahoo Finance via `yfinance`, 15-min SQLite cache).

**Architecture:** New `pricing/` module supplies current quotes through a `PriceProvider` ABC + read-through cache. New `portfolio/` module computes positions, P&L, treemap layout, equity curve, and lot aging — all pure functions. New `routes/portfolio.py` serves the page shell plus 5 HTMX fragments lazy-loaded into `portfolio.html`.

**Tech Stack:** Python 3.11, FastAPI, SQLModel, Jinja2, HTMX, Tailwind CSS, `yfinance`, pytest, factory_boy.

**Spec:** `docs/superpowers/specs/2026-04-26-ui-ux-redesign-design.md`

---

## File Structure

### New files

```
src/net_alpha/
  pricing/
    __init__.py
    provider.py          # PriceProvider ABC, Quote model, PriceFetchError
    cache.py             # SQLite-backed read-through cache with TTL
    yahoo.py             # YahooPriceProvider implementation
    service.py           # Orchestrates provider + cache; public entry point
  portfolio/
    __init__.py
    models.py            # PositionRow, KpiSet, Tile, EquityPoint, AgingLot, etc.
    positions.py         # Open positions per (symbol, account)
    pnl.py               # Realized + unrealized P&L, period/account-scoped
    treemap.py           # Slice-and-dice layout for allocation treemap
    equity_curve.py      # Cumulative realized series + present-day unrealized point
    lot_aging.py         # Top-N open lots crossing LTCG threshold
  web/
    routes/
      portfolio.py       # Page shell + 5 fragment routes + POST /prices/refresh
    templates/
      portfolio.html
      _portfolio_toolbar.html
      _portfolio_kpis.html
      _portfolio_table.html
      _portfolio_treemap.html
      _portfolio_equity_curve.html
      _portfolio_wash_impact.html
      _portfolio_lot_aging.html
      _portfolio_empty_state.html
tests/
  pricing/
    __init__.py
    test_quote_model.py
    test_cache.py
    test_yahoo_provider.py     # network-gated
    test_service.py
  portfolio/
    __init__.py
    test_positions.py
    test_pnl.py
    test_treemap.py
    test_equity_curve.py
    test_lot_aging.py
  web/
    test_portfolio_routes.py
    test_prices_refresh_route.py
```

### Modified files

```
src/net_alpha/
  config.py              # Add PricingConfig + load from ~/.net_alpha/config.yaml
  db/
    migrations.py        # Add v2→v3 migration for price_cache table
    tables.py            # Add PriceCacheRow SQLModel
  web/
    app.py               # Mount portfolio router; remove dashboard router
    dependencies.py      # Add get_pricing_service
    templates/
      base.html          # Nav: "Dashboard" → "Portfolio"; price-disclosure footer
pyproject.toml           # Add yfinance to [ui] extras
CLAUDE.md                # Price-data privacy section + new module references
```

### Files to delete

```
src/net_alpha/web/routes/dashboard.py
src/net_alpha/web/templates/dashboard.html
src/net_alpha/web/templates/_ytd_impact.html
src/net_alpha/web/templates/_watch_list.html
src/net_alpha/web/templates/_drop_zone.html       # MOVED in Phase 2 — keep until then
tests/web/test_dashboard.py
```

> **Phase boundary note:** `_drop_zone.html` move from Dashboard to Imports happens in Phase 2. For Phase 1, the new portfolio page simply does not include the drop zone. The file stays on disk, unused by Portfolio.

---

## Task 1: Add `yfinance` dependency

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Add `yfinance` to the `[ui]` optional extras**

Edit `pyproject.toml` lines 31-36, change:

```toml
ui = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "jinja2>=3.1",
    "python-multipart>=0.0.9",
]
```

to:

```toml
ui = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "jinja2>=3.1",
    "python-multipart>=0.0.9",
    "yfinance>=0.2.40",
]
```

- [ ] **Step 2: Sync deps**

Run: `uv sync --extra ui --extra dev`
Expected: succeeds, `yfinance` and transitive deps installed.

- [ ] **Step 3: Sanity check the import works**

Run: `uv run python -c "import yfinance; print(yfinance.__version__)"`
Expected: prints a version string ≥ 0.2.40.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "chore(deps): add yfinance to [ui] extras for portfolio pricing"
```

---

## Task 2: Add `PricingConfig` + load from `~/.net_alpha/config.yaml`

**Files:**
- Modify: `src/net_alpha/config.py`
- Test: `tests/test_config.py`

- [ ] **Step 1: Write failing tests for the new config layer**

Append to `tests/test_config.py`:

```python
from pathlib import Path

import yaml

from net_alpha.config import PricingConfig, Settings, load_pricing_config


def test_pricing_config_defaults_when_no_file(tmp_path):
    cfg = load_pricing_config(tmp_path / "config.yaml")
    assert cfg.enable_remote is True
    assert cfg.source == "yahoo"
    assert cfg.cache_ttl_seconds == 900


def test_pricing_config_reads_from_yaml(tmp_path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.safe_dump({"prices": {"enable_remote": False, "cache_ttl_seconds": 60}}))
    cfg = load_pricing_config(config_file)
    assert cfg.enable_remote is False
    assert cfg.source == "yahoo"  # default preserved
    assert cfg.cache_ttl_seconds == 60


def test_settings_exposes_config_yaml_path():
    settings = Settings(data_dir=Path("/tmp/x"))
    assert settings.config_yaml_path == Path("/tmp/x/config.yaml")
```

- [ ] **Step 2: Run the new tests to confirm they fail**

Run: `uv run pytest tests/test_config.py -v`
Expected: 3 new tests fail with `ImportError` (PricingConfig / load_pricing_config not defined).

- [ ] **Step 3: Add PricingConfig and loader to `src/net_alpha/config.py`**

Append to `src/net_alpha/config.py`:

```python
import yaml


class PricingConfig(BaseModel):
    model_config = {"extra": "ignore"}
    enable_remote: bool = True
    source: str = "yahoo"
    cache_ttl_seconds: int = 900


def load_pricing_config(path: Path) -> PricingConfig:
    """Load PricingConfig from a YAML file; returns defaults if missing/invalid."""
    if not path.exists():
        return PricingConfig()
    try:
        data = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError:
        return PricingConfig()
    return PricingConfig(**(data.get("prices") or {}))
```

Also add a `config_yaml_path` property to `Settings`:

```python
    @property
    def config_yaml_path(self) -> Path:
        return self.data_dir / "config.yaml"
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_config.py -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/config.py tests/test_config.py
git commit -m "feat(config): PricingConfig + YAML loader from ~/.net_alpha/config.yaml"
```

---

## Task 3: Schema migration v2 → v3 (add `price_cache` table)

**Files:**
- Modify: `src/net_alpha/db/tables.py`
- Modify: `src/net_alpha/db/migrations.py`
- Test: `tests/db/test_migration_v2_v3.py` (new)

- [ ] **Step 1: Write failing migration test**

Create `tests/db/test_migration_v2_v3.py`:

```python
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import text
from sqlmodel import Session, SQLModel, create_engine

from net_alpha.db.migrations import (
    CURRENT_SCHEMA_VERSION,
    _table_exists,
    get_schema_version,
    migrate,
)


def test_migration_creates_price_cache_table(tmp_path):
    """Fresh DB → init_db creates price_cache, version stamped to 3."""
    import net_alpha.db.tables as _tables  # noqa: F401 — registers tables

    engine = create_engine(f"sqlite:///{tmp_path / 'x.db'}")
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        migrate(s)
        assert _table_exists(s, "price_cache")
        assert get_schema_version(s) == 3
        assert CURRENT_SCHEMA_VERSION == 3


def test_v2_db_migrates_to_v3(tmp_path):
    """DB stamped at v2 with no price_cache table → migrate adds it and bumps version."""
    import net_alpha.db.tables as _tables  # noqa: F401

    engine = create_engine(f"sqlite:///{tmp_path / 'y.db'}")
    SQLModel.metadata.create_all(engine)

    # Drop price_cache and pin version to 2 to simulate a v2 DB.
    with Session(engine) as s:
        s.exec(text("DROP TABLE IF EXISTS price_cache"))
        s.exec(text("UPDATE meta SET value='2' WHERE key='schema_version'"))
        s.commit()
        assert not _table_exists(s, "price_cache")

    with Session(engine) as s:
        migrate(s)
        assert _table_exists(s, "price_cache")
        assert get_schema_version(s) == 3


def test_price_cache_roundtrip(tmp_path):
    """After migration the price_cache table accepts inserts and reads."""
    import net_alpha.db.tables as _tables  # noqa: F401

    engine = create_engine(f"sqlite:///{tmp_path / 'z.db'}")
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        migrate(s)
        s.exec(
            text(
                "INSERT INTO price_cache(symbol, price, as_of, fetched_at, source) "
                "VALUES ('SPY', 460.5, :a, :f, 'yahoo')"
            ),
            params={"a": "2026-04-26T14:30:00+00:00", "f": datetime.now(timezone.utc).isoformat()},
        )
        s.commit()
        row = s.exec(text("SELECT symbol, price, source FROM price_cache WHERE symbol='SPY'")).first()
        assert row[0] == "SPY"
        assert row[1] == 460.5
        assert row[2] == "yahoo"
```

- [ ] **Step 2: Run tests to confirm they fail**

Run: `uv run pytest tests/db/test_migration_v2_v3.py -v`
Expected: fails because `price_cache` table doesn't exist and `CURRENT_SCHEMA_VERSION` is still 2.

- [ ] **Step 3: Add `PriceCacheRow` SQLModel**

Append to `src/net_alpha/db/tables.py`:

```python
class PriceCacheRow(SQLModel, table=True):
    __tablename__ = "price_cache"

    symbol: str = Field(primary_key=True)
    price: float
    as_of: str        # ISO 8601 timestamp from provider
    fetched_at: str   # ISO 8601 timestamp when we stored the row
    source: str       # e.g. "yahoo"
```

- [ ] **Step 4: Bump schema version + add v2→v3 migration**

Modify `src/net_alpha/db/migrations.py`. Update the docstring and constant:

```python
"""Hand-written migrations.

Schema versions:
  v1 — Initial v2.x schema (TradeRow, LotRow, WashSaleViolationRow, etc.)
  v2 — Adds RealizedGLLotRow table; adds Trade.basis_source, WashSaleViolation.source columns.
  v3 — Adds PriceCacheRow table for the pricing subsystem.
"""
```

Change `CURRENT_SCHEMA_VERSION = 2` to `CURRENT_SCHEMA_VERSION = 3`.

Add a v2→v3 helper before `migrate()`:

```python
def _migrate_v2_to_v3(session: Session) -> None:
    # price_cache table is created by SQLModel.metadata.create_all in init_db.
    # Nothing to do beyond bumping the version stamp.
    if not _table_exists(session, "price_cache"):
        session.exec(
            text(
                "CREATE TABLE price_cache ("
                "symbol TEXT PRIMARY KEY, "
                "price REAL NOT NULL, "
                "as_of TEXT NOT NULL, "
                "fetched_at TEXT NOT NULL, "
                "source TEXT NOT NULL)"
            )
        )
        session.commit()
```

Update `migrate()` to chain the new step:

```python
def migrate(session: Session) -> None:
    """Apply pending migrations idempotently."""
    current = get_schema_version(session)
    if current == 0:
        set_schema_version(session, CURRENT_SCHEMA_VERSION)
        return
    if current == 1:
        _migrate_v1_to_v2(session)
        set_schema_version(session, 2)
        current = 2
    if current == 2:
        _migrate_v2_to_v3(session)
        set_schema_version(session, 3)
        return
    if current > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"DB schema_version={current} is newer than this binary "
            f"(supports {CURRENT_SCHEMA_VERSION}). Upgrade net-alpha."
        )
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_migration_v2_v3.py tests/db/test_migration_v1_v2.py -v`
Expected: all tests pass; existing v1→v2 test still passes.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/tables.py src/net_alpha/db/migrations.py tests/db/test_migration_v2_v3.py
git commit -m "feat(db): schema v3 — add price_cache table for pricing subsystem"
```

---

## Task 4: Pricing — `Quote` model and `PriceProvider` ABC

**Files:**
- Create: `src/net_alpha/pricing/__init__.py`
- Create: `src/net_alpha/pricing/provider.py`
- Create: `tests/pricing/__init__.py`
- Create: `tests/pricing/test_quote_model.py`

- [ ] **Step 1: Write failing tests for `Quote`**

Create `tests/pricing/__init__.py` (empty file).

Create `tests/pricing/test_quote_model.py`:

```python
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from net_alpha.pricing.provider import PriceFetchError, PriceProvider, Quote


def test_quote_holds_required_fields():
    q = Quote(symbol="SPY", price=Decimal("460.5"), as_of=datetime(2026, 4, 26, 14, 30, tzinfo=timezone.utc), source="yahoo")
    assert q.symbol == "SPY"
    assert q.price == Decimal("460.5")
    assert q.source == "yahoo"


def test_quote_rejects_missing_fields():
    with pytest.raises(Exception):
        Quote(symbol="SPY")


def test_provider_is_abstract():
    with pytest.raises(TypeError):
        PriceProvider()


def test_price_fetch_error_carries_context():
    err = PriceFetchError("timeout", symbols=["SPY", "QQQ"])
    assert "timeout" in str(err)
    assert err.symbols == ["SPY", "QQQ"]
```

- [ ] **Step 2: Run to confirm they fail**

Run: `uv run pytest tests/pricing/test_quote_model.py -v`
Expected: ImportError — `pricing.provider` not found.

- [ ] **Step 3: Implement `Quote`, `PriceFetchError`, and `PriceProvider`**

Create `src/net_alpha/pricing/__init__.py` (empty file).

Create `src/net_alpha/pricing/provider.py`:

```python
"""Pricing provider abstraction — Quote model + PriceProvider ABC.

External price providers (Yahoo, Schwab, etc.) implement PriceProvider.
Quote is the normalized result type returned for a single symbol.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel


class Quote(BaseModel):
    model_config = {"frozen": True}
    symbol: str
    price: Decimal
    as_of: datetime
    source: str


class PriceFetchError(Exception):
    """Raised when a provider fails to fetch quotes for the requested symbols."""

    def __init__(self, message: str, symbols: list[str] | None = None) -> None:
        super().__init__(message)
        self.symbols = symbols or []


class PriceProvider(ABC):
    """Fetch live quotes for a list of symbols."""

    @abstractmethod
    def get_quotes(self, symbols: list[str]) -> dict[str, Quote]:
        """Return {symbol: Quote} for symbols the provider could fetch.

        Symbols missing from the result were unavailable. Raises PriceFetchError
        on systemic failures (network down, rate-limit), not on per-symbol misses.
        """
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/pricing/test_quote_model.py -v`
Expected: all 4 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/pricing/__init__.py src/net_alpha/pricing/provider.py tests/pricing/__init__.py tests/pricing/test_quote_model.py
git commit -m "feat(pricing): Quote model and PriceProvider ABC"
```

---

## Task 5: Pricing — read-through SQLite cache

**Files:**
- Create: `src/net_alpha/pricing/cache.py`
- Create: `tests/pricing/test_cache.py`

- [ ] **Step 1: Write failing tests**

Create `tests/pricing/test_cache.py`:

```python
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlmodel import SQLModel, create_engine

import net_alpha.db.tables as _tables  # noqa: F401
from net_alpha.db.connection import init_db
from net_alpha.pricing.cache import CachedQuote, PriceCache
from net_alpha.pricing.provider import Quote


def _engine(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path / 'cache.db'}")
    SQLModel.metadata.create_all(eng)
    init_db(eng)
    return eng


def _quote(symbol="SPY", price="460.5", as_of=None):
    return Quote(
        symbol=symbol,
        price=Decimal(price),
        as_of=as_of or datetime(2026, 4, 26, 14, 30, tzinfo=timezone.utc),
        source="yahoo",
    )


def test_cache_miss_returns_none(tmp_path):
    cache = PriceCache(_engine(tmp_path), ttl_seconds=900)
    assert cache.get("SPY") is None


def test_cache_put_then_get_within_ttl(tmp_path):
    cache = PriceCache(_engine(tmp_path), ttl_seconds=900)
    cache.put_many([_quote()])
    cached = cache.get("SPY")
    assert cached is not None
    assert cached.quote.symbol == "SPY"
    assert cached.quote.price == Decimal("460.5")
    assert cached.stale is False


def test_cache_returns_stale_after_ttl(tmp_path):
    cache = PriceCache(_engine(tmp_path), ttl_seconds=1)
    cache.put_many([_quote()])
    # Force fetched_at into the past by overriding the stored row.
    with cache._engine.begin() as conn:
        from sqlalchemy import text
        conn.execute(
            text("UPDATE price_cache SET fetched_at=:t WHERE symbol='SPY'"),
            {"t": (datetime.now(timezone.utc) - timedelta(seconds=10)).isoformat()},
        )
    cached = cache.get("SPY")
    assert cached is not None
    assert cached.stale is True


def test_cache_invalidate_drops_entry(tmp_path):
    cache = PriceCache(_engine(tmp_path), ttl_seconds=900)
    cache.put_many([_quote()])
    cache.invalidate(["SPY"])
    assert cache.get("SPY") is None


def test_cache_get_many_returns_only_present(tmp_path):
    cache = PriceCache(_engine(tmp_path), ttl_seconds=900)
    cache.put_many([_quote("SPY"), _quote("QQQ", "390.0")])
    out = cache.get_many(["SPY", "QQQ", "TSLA"])
    assert set(out.keys()) == {"SPY", "QQQ"}
    assert out["QQQ"].quote.price == Decimal("390.0")
```

- [ ] **Step 2: Run to confirm they fail**

Run: `uv run pytest tests/pricing/test_cache.py -v`
Expected: ImportError on `pricing.cache`.

- [ ] **Step 3: Implement `PriceCache` and `CachedQuote`**

Create `src/net_alpha/pricing/cache.py`:

```python
"""SQLite-backed read-through cache for price quotes.

PriceCache.get returns CachedQuote(quote, stale) — stale=True when the row
exists but fetched_at is older than ttl_seconds. Callers decide whether to
serve stale data or refetch.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from sqlalchemy import text
from sqlalchemy.engine import Engine

from net_alpha.pricing.provider import Quote


@dataclass(frozen=True)
class CachedQuote:
    quote: Quote
    stale: bool


class PriceCache:
    def __init__(self, engine: Engine, ttl_seconds: int = 900) -> None:
        self._engine = engine
        self._ttl = timedelta(seconds=ttl_seconds)

    def get(self, symbol: str) -> CachedQuote | None:
        result = self.get_many([symbol])
        return result.get(symbol)

    def get_many(self, symbols: list[str]) -> dict[str, CachedQuote]:
        if not symbols:
            return {}
        placeholders = ",".join(f":s{i}" for i in range(len(symbols)))
        params = {f"s{i}": s for i, s in enumerate(symbols)}
        with self._engine.connect() as conn:
            rows = conn.execute(
                text(
                    f"SELECT symbol, price, as_of, fetched_at, source "
                    f"FROM price_cache WHERE symbol IN ({placeholders})"
                ),
                params,
            ).all()
        out: dict[str, CachedQuote] = {}
        now = datetime.now(timezone.utc)
        for symbol, price, as_of, fetched_at, source in rows:
            quote = Quote(
                symbol=symbol,
                price=price,
                as_of=datetime.fromisoformat(as_of),
                source=source,
            )
            stale = now - datetime.fromisoformat(fetched_at) > self._ttl
            out[symbol] = CachedQuote(quote=quote, stale=stale)
        return out

    def put_many(self, quotes: list[Quote]) -> None:
        if not quotes:
            return
        now_iso = datetime.now(timezone.utc).isoformat()
        with self._engine.begin() as conn:
            for q in quotes:
                conn.execute(
                    text(
                        "INSERT INTO price_cache(symbol, price, as_of, fetched_at, source) "
                        "VALUES (:symbol, :price, :as_of, :fetched_at, :source) "
                        "ON CONFLICT(symbol) DO UPDATE SET "
                        "price=:price, as_of=:as_of, fetched_at=:fetched_at, source=:source"
                    ),
                    {
                        "symbol": q.symbol,
                        "price": float(q.price),
                        "as_of": q.as_of.isoformat(),
                        "fetched_at": now_iso,
                        "source": q.source,
                    },
                )

    def invalidate(self, symbols: list[str]) -> None:
        if not symbols:
            return
        placeholders = ",".join(f":s{i}" for i in range(len(symbols)))
        params = {f"s{i}": s for i, s in enumerate(symbols)}
        with self._engine.begin() as conn:
            conn.execute(text(f"DELETE FROM price_cache WHERE symbol IN ({placeholders})"), params)
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/pricing/test_cache.py -v`
Expected: all 5 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/pricing/cache.py tests/pricing/test_cache.py
git commit -m "feat(pricing): SQLite-backed PriceCache with TTL + stale detection"
```

---

## Task 6: Pricing — `YahooPriceProvider`

**Files:**
- Create: `src/net_alpha/pricing/yahoo.py`
- Create: `tests/pricing/test_yahoo_provider.py`

- [ ] **Step 1: Write failing tests**

Create `tests/pricing/test_yahoo_provider.py`:

```python
"""Tests for YahooPriceProvider.

The unit test uses a stub instead of hitting the network. The network-gated
test below runs only when --run-network is passed.
"""

from datetime import datetime, timezone
from decimal import Decimal
from unittest.mock import patch

import pytest

from net_alpha.pricing.provider import PriceFetchError, Quote
from net_alpha.pricing.yahoo import YahooPriceProvider


class _FakeTicker:
    def __init__(self, symbol: str, price: float | None) -> None:
        self.info = {"regularMarketPrice": price} if price is not None else {}
        self.symbol = symbol


def test_get_quotes_returns_present_symbols_only():
    provider = YahooPriceProvider()
    fake = {"SPY": _FakeTicker("SPY", 460.5), "TSLA": _FakeTicker("TSLA", None)}
    with patch("net_alpha.pricing.yahoo.yf.Ticker", side_effect=lambda s: fake[s]):
        quotes = provider.get_quotes(["SPY", "TSLA"])
    assert set(quotes.keys()) == {"SPY"}
    assert quotes["SPY"].price == Decimal("460.5")
    assert quotes["SPY"].source == "yahoo"


def test_get_quotes_empty_symbols_returns_empty():
    provider = YahooPriceProvider()
    assert provider.get_quotes([]) == {}


def test_get_quotes_wraps_systemic_errors_in_price_fetch_error():
    provider = YahooPriceProvider()
    with patch("net_alpha.pricing.yahoo.yf.Ticker", side_effect=RuntimeError("connection refused")):
        with pytest.raises(PriceFetchError) as excinfo:
            provider.get_quotes(["SPY"])
    assert "connection refused" in str(excinfo.value)
    assert excinfo.value.symbols == ["SPY"]


@pytest.mark.network
def test_yahoo_live_fetch_for_spy():
    """Live network test — requires --run-network. Skipped by default."""
    provider = YahooPriceProvider()
    quotes = provider.get_quotes(["SPY"])
    assert "SPY" in quotes
    assert quotes["SPY"].price > 0
```

- [ ] **Step 2: Add `network` marker config**

Append to `pyproject.toml` `[tool.pytest.ini_options]` section, replacing:

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
```

with:

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
markers = [
    "network: tests that hit external services; run only with --run-network",
]
addopts = "-m 'not network'"
```

Also add a `--run-network` flag in `tests/conftest.py`. Open `tests/conftest.py` (already exists) and append:

```python
def pytest_addoption(parser):
    parser.addoption("--run-network", action="store_true", default=False, help="Run network-gated tests")


def pytest_collection_modifyitems(config, items):
    if config.getoption("--run-network"):
        # Override the addopts deselection by removing the marker filter.
        return
    skip_net = __import__("pytest").mark.skip(reason="network-gated; pass --run-network")
    for item in items:
        if "network" in item.keywords:
            item.add_marker(skip_net)
```

- [ ] **Step 3: Run to confirm tests fail**

Run: `uv run pytest tests/pricing/test_yahoo_provider.py -v`
Expected: ImportError on `pricing.yahoo`.

- [ ] **Step 4: Implement `YahooPriceProvider`**

Create `src/net_alpha/pricing/yahoo.py`:

```python
"""Yahoo Finance price provider via yfinance.

Bulk fetches quotes per symbol (yfinance's batch API for `.info` is unreliable;
we iterate per symbol but keep the call inside one network session). Maps any
systemic exception to PriceFetchError; per-symbol misses (no price field) are
silently dropped from the result.
"""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

import yfinance as yf
from loguru import logger

from net_alpha.pricing.provider import PriceFetchError, PriceProvider, Quote


class YahooPriceProvider(PriceProvider):
    source_name = "yahoo"

    def get_quotes(self, symbols: list[str]) -> dict[str, Quote]:
        if not symbols:
            return {}
        out: dict[str, Quote] = {}
        try:
            now = datetime.now(timezone.utc)
            for symbol in symbols:
                ticker = yf.Ticker(symbol)
                price = ticker.info.get("regularMarketPrice")
                if price is None:
                    logger.warning("yahoo: no price for {}", symbol)
                    continue
                out[symbol] = Quote(
                    symbol=symbol,
                    price=Decimal(str(price)),
                    as_of=now,
                    source=self.source_name,
                )
        except Exception as exc:  # network failures, yfinance internals, etc.
            raise PriceFetchError(str(exc), symbols=symbols) from exc
        return out
```

- [ ] **Step 5: Verify unit tests pass; network test stays skipped by default**

Run: `uv run pytest tests/pricing/test_yahoo_provider.py -v`
Expected: 3 unit tests pass; live test skipped with reason.

Run: `uv run pytest tests/pricing/test_yahoo_provider.py -v --run-network -m network`
Expected: live test passes (requires internet).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/pricing/yahoo.py tests/pricing/test_yahoo_provider.py pyproject.toml tests/conftest.py
git commit -m "feat(pricing): YahooPriceProvider via yfinance + network test marker"
```

---

## Task 7: Pricing — `PricingService` (provider + cache orchestrator)

**Files:**
- Create: `src/net_alpha/pricing/service.py`
- Create: `tests/pricing/test_service.py`

- [ ] **Step 1: Write failing tests**

Create `tests/pricing/test_service.py`:

```python
from datetime import datetime, timezone
from decimal import Decimal

from sqlmodel import SQLModel, create_engine

import net_alpha.db.tables as _tables  # noqa: F401
from net_alpha.db.connection import init_db
from net_alpha.pricing.cache import PriceCache
from net_alpha.pricing.provider import PriceFetchError, PriceProvider, Quote
from net_alpha.pricing.service import PricingService


class _FakeProvider(PriceProvider):
    def __init__(self, returns=None, raises=None):
        self.returns = returns or {}
        self.raises = raises
        self.calls: list[list[str]] = []

    def get_quotes(self, symbols):
        self.calls.append(list(symbols))
        if self.raises:
            raise self.raises
        return {s: self.returns[s] for s in symbols if s in self.returns}


def _engine(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path / 's.db'}")
    SQLModel.metadata.create_all(eng)
    init_db(eng)
    return eng


def _quote(symbol, price):
    return Quote(symbol=symbol, price=Decimal(price), as_of=datetime.now(timezone.utc), source="yahoo")


def test_disabled_service_returns_empty(tmp_path):
    cache = PriceCache(_engine(tmp_path))
    svc = PricingService(provider=_FakeProvider(), cache=cache, enabled=False)
    assert svc.get_prices(["SPY"]) == {}


def test_first_call_fetches_and_caches(tmp_path):
    cache = PriceCache(_engine(tmp_path))
    provider = _FakeProvider(returns={"SPY": _quote("SPY", "460.5")})
    svc = PricingService(provider=provider, cache=cache, enabled=True)
    prices = svc.get_prices(["SPY"])
    assert prices["SPY"].price == Decimal("460.5")
    # Second call hits cache, no extra provider call.
    svc.get_prices(["SPY"])
    assert len(provider.calls) == 1


def test_partial_cache_only_fetches_missing(tmp_path):
    cache = PriceCache(_engine(tmp_path))
    provider = _FakeProvider(returns={"QQQ": _quote("QQQ", "390.0")})
    svc = PricingService(provider=provider, cache=cache, enabled=True)
    cache.put_many([_quote("SPY", "460.5")])
    out = svc.get_prices(["SPY", "QQQ"])
    assert provider.calls == [["QQQ"]]
    assert out["SPY"].price == Decimal("460.5")
    assert out["QQQ"].price == Decimal("390.0")


def test_provider_failure_serves_stale_with_flag(tmp_path):
    """When provider raises, return whatever stale cache exists, marked stale."""
    cache = PriceCache(_engine(tmp_path), ttl_seconds=0)  # everything stale immediately
    cache.put_many([_quote("SPY", "460.5")])
    provider = _FakeProvider(raises=PriceFetchError("net down"))
    svc = PricingService(provider=provider, cache=cache, enabled=True)
    out = svc.get_prices(["SPY"])
    assert out["SPY"].price == Decimal("460.5")
    snap = svc.last_snapshot()
    assert snap.degraded is True


def test_invalidate_and_refresh(tmp_path):
    cache = PriceCache(_engine(tmp_path))
    provider = _FakeProvider(returns={"SPY": _quote("SPY", "460.5")})
    svc = PricingService(provider=provider, cache=cache, enabled=True)
    svc.get_prices(["SPY"])
    assert len(provider.calls) == 1
    svc.refresh(["SPY"])
    assert len(provider.calls) == 2
```

- [ ] **Step 2: Run to confirm they fail**

Run: `uv run pytest tests/pricing/test_service.py -v`
Expected: ImportError on `pricing.service`.

- [ ] **Step 3: Implement `PricingService`**

Create `src/net_alpha/pricing/service.py`:

```python
"""PricingService — orchestrates a PriceProvider with the PriceCache.

Public surface: get_prices, refresh, last_snapshot. Designed to be constructed
once per request (cheap) and never raise on price-fetch failures: instead, it
serves stale cache when present and reports `degraded=True` via last_snapshot().
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from loguru import logger

from net_alpha.pricing.cache import PriceCache
from net_alpha.pricing.provider import PriceFetchError, PriceProvider, Quote


@dataclass
class PricingSnapshot:
    """Diagnostic info about the most recent get_prices call."""
    fetched_at: datetime | None = None
    source: str = ""
    degraded: bool = False
    stale_symbols: list[str] = field(default_factory=list)
    missing_symbols: list[str] = field(default_factory=list)


class PricingService:
    def __init__(self, *, provider: PriceProvider, cache: PriceCache, enabled: bool) -> None:
        self._provider = provider
        self._cache = cache
        self._enabled = enabled
        self._snapshot = PricingSnapshot()

    def last_snapshot(self) -> PricingSnapshot:
        return self._snapshot

    def get_prices(self, symbols: list[str]) -> dict[str, Quote]:
        """Return {symbol: Quote} for every symbol we have a price for (live or stale).

        When pricing is disabled, returns {}. When the provider fails, returns
        whatever stale cache exists.
        """
        if not self._enabled or not symbols:
            self._snapshot = PricingSnapshot()
            return {}

        cached = self._cache.get_many(symbols)
        fresh = {s: cq.quote for s, cq in cached.items() if not cq.stale}
        stale_only = {s: cq.quote for s, cq in cached.items() if cq.stale}
        to_fetch = [s for s in symbols if s not in fresh]

        snap = PricingSnapshot(stale_symbols=list(stale_only.keys()))

        if to_fetch:
            try:
                fetched = self._provider.get_quotes(to_fetch)
                self._cache.put_many(list(fetched.values()))
                fresh.update(fetched)
                snap.fetched_at = max((q.as_of for q in fetched.values()), default=None)
                if fetched:
                    snap.source = next(iter(fetched.values())).source
            except PriceFetchError as exc:
                logger.warning("pricing: provider failed: {}", exc)
                snap.degraded = True
                # Fall back to stale cache for the requested symbols.
                for s in to_fetch:
                    if s in stale_only:
                        fresh[s] = stale_only[s]

        snap.missing_symbols = [s for s in symbols if s not in fresh]
        self._snapshot = snap
        return fresh

    def refresh(self, symbols: list[str]) -> dict[str, Quote]:
        self._cache.invalidate(symbols)
        return self.get_prices(symbols)
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/pricing/test_service.py -v`
Expected: all 5 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/pricing/service.py tests/pricing/test_service.py
git commit -m "feat(pricing): PricingService orchestrating provider + cache"
```

---

## Task 8: Wire `PricingService` into FastAPI dependencies

**Files:**
- Modify: `src/net_alpha/web/dependencies.py`
- Modify: `src/net_alpha/web/app.py`

- [ ] **Step 1: Add provider + service to app state during `create_app`**

Modify `src/net_alpha/web/app.py`. Add imports near the top:

```python
from net_alpha.config import load_pricing_config
from net_alpha.pricing.cache import PriceCache
from net_alpha.pricing.yahoo import YahooPriceProvider
```

Inside `create_app`, after `init_db(engine)`, add:

```python
    pricing_config = load_pricing_config(settings.config_yaml_path)
    app.state.pricing_config = pricing_config
    app.state.price_provider = YahooPriceProvider() if pricing_config.source == "yahoo" else None
    app.state.price_cache = PriceCache(engine, ttl_seconds=pricing_config.cache_ttl_seconds)
```

- [ ] **Step 2: Add `get_pricing_service` dependency**

Modify `src/net_alpha/web/dependencies.py`. Add at the bottom:

```python
from net_alpha.pricing.service import PricingService


def get_pricing_service(request: Request) -> PricingService:
    return PricingService(
        provider=request.app.state.price_provider,
        cache=request.app.state.price_cache,
        enabled=request.app.state.pricing_config.enable_remote
        and request.app.state.price_provider is not None,
    )
```

- [ ] **Step 3: Smoke test the existing app still boots**

Run: `uv run pytest tests/web/test_app_factory.py -v`
Expected: existing app-factory test passes.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/app.py src/net_alpha/web/dependencies.py
git commit -m "feat(web): wire PricingService into FastAPI app state and DI"
```

---

## Task 9: `POST /prices/refresh` route

**Files:**
- Create: `src/net_alpha/web/routes/portfolio.py`
- Modify: `src/net_alpha/web/app.py`
- Create: `tests/web/test_prices_refresh_route.py`

- [ ] **Step 1: Write failing route test**

Create `tests/web/test_prices_refresh_route.py`:

```python
from datetime import datetime, timezone
from decimal import Decimal
from unittest.mock import patch

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.pricing.provider import Quote
from net_alpha.web.app import create_app


def _client(tmp_path):
    settings = Settings(data_dir=tmp_path)
    app = create_app(settings)
    return TestClient(app), app


def test_refresh_invalidates_and_refetches(tmp_path):
    client, app = _client(tmp_path)

    fake_quote = Quote(
        symbol="SPY",
        price=Decimal("460.5"),
        as_of=datetime.now(timezone.utc),
        source="yahoo",
    )
    with patch.object(app.state.price_provider, "get_quotes", return_value={"SPY": fake_quote}) as mock:
        # Prime the cache once.
        client.post("/prices/refresh", params={"symbols": "SPY"})
        # Refresh again — should invalidate and refetch.
        response = client.post("/prices/refresh", params={"symbols": "SPY"})
        assert response.status_code == 200
        assert mock.call_count == 2


def test_refresh_with_no_symbols_returns_400(tmp_path):
    client, _ = _client(tmp_path)
    response = client.post("/prices/refresh")
    assert response.status_code == 400
```

- [ ] **Step 2: Create the portfolio router with the refresh endpoint**

Create `src/net_alpha/web/routes/portfolio.py`:

```python
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from net_alpha.pricing.service import PricingService
from net_alpha.web.dependencies import get_pricing_service

router = APIRouter()


@router.post("/prices/refresh")
def refresh_prices(
    symbols: str | None = Query(default=None),
    svc: PricingService = Depends(get_pricing_service),
) -> dict[str, object]:
    if not symbols:
        raise HTTPException(status_code=400, detail="symbols query param required")
    sym_list = [s.strip() for s in symbols.split(",") if s.strip()]
    if not sym_list:
        raise HTTPException(status_code=400, detail="symbols query param required")
    quotes = svc.refresh(sym_list)
    snap = svc.last_snapshot()
    return {
        "fetched": list(quotes.keys()),
        "missing": snap.missing_symbols,
        "degraded": snap.degraded,
    }
```

- [ ] **Step 3: Mount the router in `app.py`**

In `src/net_alpha/web/app.py`, add to the imports:

```python
from net_alpha.web.routes import portfolio as portfolio_routes
```

And add `app.include_router(portfolio_routes.router)` in the includes block (alongside the existing routers, before `system.register_error_handlers(app)`).

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/web/test_prices_refresh_route.py -v`
Expected: both pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/app.py tests/web/test_prices_refresh_route.py
git commit -m "feat(web): POST /prices/refresh — invalidate + refetch quotes"
```

---

## Task 10: Portfolio — domain models

**Files:**
- Create: `src/net_alpha/portfolio/__init__.py`
- Create: `src/net_alpha/portfolio/models.py`
- Create: `tests/portfolio/__init__.py`

- [ ] **Step 1: Create the package and model definitions**

Create `src/net_alpha/portfolio/__init__.py` (empty file).
Create `tests/portfolio/__init__.py` (empty file).

Create `src/net_alpha/portfolio/models.py`:

```python
"""Portfolio view models.

These are the renderer-facing shapes returned by the portfolio.* compute
functions. They are NOT persisted — recomputed on each request.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal


@dataclass(frozen=True)
class PositionRow:
    symbol: str
    accounts: tuple[str, ...]
    qty: Decimal
    market_value: Decimal | None       # None when no price is available
    open_cost: Decimal                  # sum of (open_qty × adjusted_basis)
    avg_basis: Decimal                  # open_cost / qty (formula C)
    cash_sunk_per_share: Decimal        # (buys − sells − option_premium) / qty (formula A)
    realized_pl: Decimal                # period-scoped
    unrealized_pl: Decimal | None       # None when no price


@dataclass(frozen=True)
class KpiSet:
    period_label: str
    period_realized: Decimal
    period_unrealized: Decimal | None
    lifetime_realized: Decimal
    lifetime_unrealized: Decimal | None
    open_position_value: Decimal | None


@dataclass(frozen=True)
class TreemapTile:
    symbol: str           # "OTHER" used for the long-tail aggregate tile
    market_value: Decimal
    unrealized_pl: Decimal | None
    x_pct: float          # 0–100, percent of container width
    y_pct: float
    width_pct: float
    height_pct: float


@dataclass(frozen=True)
class EquityPoint:
    on: date
    cumulative_realized: Decimal
    unrealized: Decimal | None  # only on the present-day point


@dataclass(frozen=True)
class WashImpact:
    period_label: str
    disallowed_total: Decimal
    violation_count: int
    confirmed_count: int
    probable_count: int
    unclear_count: int


@dataclass(frozen=True)
class AgingLot:
    symbol: str
    account: str
    qty: Decimal
    acquired_on: date
    days_to_ltcg: int  # negative if already long-term (excluded by callers)
```

- [ ] **Step 2: Smoke test imports**

Run: `uv run python -c "from net_alpha.portfolio.models import PositionRow, KpiSet, TreemapTile, EquityPoint, WashImpact, AgingLot; print('ok')"`
Expected: prints `ok`.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/portfolio/__init__.py src/net_alpha/portfolio/models.py tests/portfolio/__init__.py
git commit -m "feat(portfolio): view-model dataclasses for positions/KPIs/charts"
```

---

## Task 11: Portfolio — `compute_open_positions`

**Files:**
- Create: `src/net_alpha/portfolio/positions.py`
- Create: `tests/portfolio/test_positions.py`

- [ ] **Step 1: Write failing tests**

Create `tests/portfolio/test_positions.py`:

```python
from decimal import Decimal

from net_alpha.models.domain import Lot, Trade
from net_alpha.portfolio.positions import compute_open_positions
from net_alpha.pricing.provider import Quote
from datetime import datetime, timezone


def _trade(**kw):
    defaults = dict(
        id="t1", account="Schwab Tax", date=__import__("datetime").date(2025, 1, 15),
        ticker="SPY", action="Buy", quantity=100.0, proceeds=None, cost_basis=40_000.0,
        basis_unknown=False, option_details=None,
    )
    defaults.update(kw)
    return Trade(**defaults)


def _lot(**kw):
    defaults = dict(
        id="l1", trade_id="t1", account="Schwab Tax", date=__import__("datetime").date(2025, 1, 15),
        ticker="SPY", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0, option_details=None,
    )
    defaults.update(kw)
    return Lot(**defaults)


def _quote(symbol, price):
    return Quote(symbol=symbol, price=Decimal(str(price)), as_of=datetime.now(timezone.utc), source="yahoo")


def test_single_lot_single_buy_no_sells():
    trades = [_trade()]
    lots = [_lot()]
    rows = compute_open_positions(trades=trades, lots=lots, prices={"SPY": _quote("SPY", 460)}, period=None, account=None)
    assert len(rows) == 1
    r = rows[0]
    assert r.symbol == "SPY"
    assert r.qty == Decimal("100")
    assert r.market_value == Decimal("46000")
    assert r.open_cost == Decimal("40000")
    assert r.avg_basis == Decimal("400")
    assert r.cash_sunk_per_share == Decimal("400")  # no sells → buys / qty
    assert r.unrealized_pl == Decimal("6000")


def test_position_with_sell_reduces_cash_sunk():
    trades = [
        _trade(id="t1", quantity=100.0, cost_basis=40_000.0),
        _trade(id="t2", action="Sell", quantity=50.0, proceeds=25_000.0, cost_basis=20_000.0,
               date=__import__("datetime").date(2025, 6, 10)),
    ]
    lots = [_lot(quantity=50.0, cost_basis=20_000.0, adjusted_basis=20_000.0)]
    rows = compute_open_positions(trades=trades, lots=lots, prices={"SPY": _quote("SPY", 520)}, period=None, account=None)
    r = rows[0]
    assert r.qty == Decimal("50")
    assert r.open_cost == Decimal("20000")
    assert r.cash_sunk_per_share == Decimal("300")  # (40000 − 25000) / 50


def test_missing_price_yields_none_market_value_and_unrealized():
    trades = [_trade()]
    lots = [_lot()]
    rows = compute_open_positions(trades=trades, lots=lots, prices={}, period=None, account=None)
    r = rows[0]
    assert r.market_value is None
    assert r.unrealized_pl is None


def test_account_filter_drops_other_accounts():
    trades = [
        _trade(id="t1", account="Schwab Tax"),
        _trade(id="t2", account="Schwab IRA", quantity=10.0, cost_basis=4_000.0),
    ]
    lots = [
        _lot(id="l1", account="Schwab Tax"),
        _lot(id="l2", account="Schwab IRA", quantity=10.0, cost_basis=4_000.0, adjusted_basis=4_000.0),
    ]
    rows = compute_open_positions(trades=trades, lots=lots, prices={"SPY": _quote("SPY", 460)}, period=None, account="Schwab Tax")
    assert len(rows) == 1
    assert rows[0].qty == Decimal("100")


def test_accounts_field_lists_all_holders():
    trades = [
        _trade(id="t1", account="Schwab Tax"),
        _trade(id="t2", account="Schwab IRA", quantity=10.0, cost_basis=4_000.0),
    ]
    lots = [
        _lot(id="l1", account="Schwab Tax"),
        _lot(id="l2", account="Schwab IRA", quantity=10.0, cost_basis=4_000.0, adjusted_basis=4_000.0),
    ]
    rows = compute_open_positions(trades=trades, lots=lots, prices={"SPY": _quote("SPY", 460)}, period=None, account=None)
    r = rows[0]
    assert set(r.accounts) == {"Schwab Tax", "Schwab IRA"}
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_positions.py -v`
Expected: ImportError on `portfolio.positions`.

- [ ] **Step 3: Implement `compute_open_positions`**

Create `src/net_alpha/portfolio/positions.py`:

```python
"""Compute per-symbol open positions from trades + lots, scoped by account.

Pure function. Options are merged into their underlying ticker for
quantity/market value (equity-only) but contribute their cash flows to
cash_sunk_per_share. Period filtering applies to *realized P&L*, not to
the lots used for open positions (open positions are always "now").
"""

from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import Iterable

from net_alpha.models.domain import Lot, Trade
from net_alpha.portfolio.models import PositionRow
from net_alpha.pricing.provider import Quote


def compute_open_positions(
    *,
    trades: Iterable[Trade],
    lots: Iterable[Lot],
    prices: dict[str, Quote],
    period: tuple[int, int] | None = None,  # (year_start, year_end_exclusive); None = all time
    account: str | None = None,
) -> list[PositionRow]:
    """Return positions sorted by market value desc (None last)."""
    trades = list(trades)
    lots = list(lots)

    # Account scope
    if account:
        trades = [t for t in trades if t.account == account]
        lots = [lot for lot in lots if lot.account == account]

    # Equity-only quantities and basis come from open lots that are NOT options.
    qty_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    open_cost_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    accounts_by_sym: dict[str, set[str]] = defaultdict(set)
    for lot in lots:
        if lot.option_details is not None:
            continue  # options excluded from equity qty/basis (rolled into cash flows below)
        qty_by_sym[lot.ticker] += Decimal(str(lot.quantity))
        open_cost_by_sym[lot.ticker] += Decimal(str(lot.adjusted_basis)) * Decimal(str(lot.quantity))
        accounts_by_sym[lot.ticker].add(lot.account)

    # Cash flows include ALL trades on the underlying ticker (equity AND options).
    buys_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    sells_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    realized_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    for t in trades:
        sym = t.ticker
        accounts_by_sym[sym].add(t.account)  # ensure account is captured even if no open lot
        if t.action.lower() == "buy":
            buys_by_sym[sym] += Decimal(str(t.cost_basis or 0))
        elif t.action.lower() == "sell":
            sells_by_sym[sym] += Decimal(str(t.proceeds or 0))
            in_period = period is None or (t.date.year >= period[0] and t.date.year < period[1])
            if in_period:
                realized_by_sym[sym] += Decimal(str((t.proceeds or 0) - (t.cost_basis or 0)))

    rows: list[PositionRow] = []
    for sym, qty in qty_by_sym.items():
        if qty == 0:
            continue
        open_cost = open_cost_by_sym[sym]
        avg_basis = (open_cost / qty) if qty else Decimal("0")
        cash_sunk = (buys_by_sym[sym] - sells_by_sym[sym]) / qty if qty else Decimal("0")
        quote = prices.get(sym)
        market_value = (qty * quote.price) if quote else None
        unrealized = (market_value - open_cost) if market_value is not None else None
        rows.append(PositionRow(
            symbol=sym,
            accounts=tuple(sorted(accounts_by_sym[sym])),
            qty=qty,
            market_value=market_value,
            open_cost=open_cost,
            avg_basis=avg_basis,
            cash_sunk_per_share=cash_sunk,
            realized_pl=realized_by_sym[sym],
            unrealized_pl=unrealized,
        ))
    rows.sort(key=lambda r: (r.market_value is None, -(r.market_value or Decimal("0"))))
    return rows
```

- [ ] **Step 4: Run tests, expect pass**

Run: `uv run pytest tests/portfolio/test_positions.py -v`
Expected: all 5 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/positions.py tests/portfolio/test_positions.py
git commit -m "feat(portfolio): compute_open_positions with account/period scoping"
```

---

## Task 12: Portfolio — `compute_kpis`

**Files:**
- Create: `src/net_alpha/portfolio/pnl.py`
- Create: `tests/portfolio/test_pnl.py`

- [ ] **Step 1: Write failing tests**

Create `tests/portfolio/test_pnl.py`:

```python
from datetime import date, datetime, timezone
from decimal import Decimal

from net_alpha.models.domain import Lot, Trade
from net_alpha.portfolio.pnl import compute_kpis
from net_alpha.pricing.provider import Quote


def _trade(**kw):
    defaults = dict(
        id="t1", account="Tax", date=date(2025, 1, 15), ticker="SPY",
        action="Buy", quantity=100.0, proceeds=None, cost_basis=40_000.0,
        basis_unknown=False, option_details=None,
    )
    defaults.update(kw)
    return Trade(**defaults)


def _lot(**kw):
    defaults = dict(
        id="l1", trade_id="t1", account="Tax", date=date(2025, 1, 15),
        ticker="SPY", quantity=100.0, cost_basis=40_000.0, adjusted_basis=40_000.0, option_details=None,
    )
    defaults.update(kw)
    return Lot(**defaults)


def _quote(symbol, price):
    return Quote(symbol=symbol, price=Decimal(str(price)), as_of=datetime.now(timezone.utc), source="yahoo")


def test_kpis_zero_when_no_trades():
    k = compute_kpis(trades=[], lots=[], prices={}, period_label="YTD", period=(2026, 2027), account=None)
    assert k.period_realized == Decimal("0")
    assert k.lifetime_realized == Decimal("0")
    assert k.open_position_value == Decimal("0")


def test_kpis_realized_split_by_period():
    trades = [
        _trade(id="t1", action="Sell", date=date(2025, 6, 10), quantity=10, proceeds=5_000, cost_basis=4_000),
        _trade(id="t2", action="Sell", date=date(2026, 3, 1), quantity=10, proceeds=6_000, cost_basis=4_500),
    ]
    k = compute_kpis(trades=trades, lots=[], prices={}, period_label="YTD", period=(2026, 2027), account=None)
    assert k.period_realized == Decimal("1500")
    assert k.lifetime_realized == Decimal("2500")


def test_kpis_unrealized_uses_prices_when_available():
    lots = [_lot()]
    k = compute_kpis(
        trades=[_trade()], lots=lots, prices={"SPY": _quote("SPY", 460)},
        period_label="YTD", period=(2026, 2027), account=None,
    )
    assert k.open_position_value == Decimal("46000")
    assert k.period_unrealized == Decimal("6000")
    assert k.lifetime_unrealized == Decimal("6000")


def test_kpis_unrealized_none_when_prices_missing():
    lots = [_lot()]
    k = compute_kpis(trades=[_trade()], lots=lots, prices={}, period_label="YTD", period=(2026, 2027), account=None)
    assert k.open_position_value is None
    assert k.period_unrealized is None
    assert k.lifetime_unrealized is None
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_pnl.py -v`
Expected: ImportError on `portfolio.pnl`.

- [ ] **Step 3: Implement `compute_kpis`**

Create `src/net_alpha/portfolio/pnl.py`:

```python
"""KPI aggregations for the Portfolio page header.

period: (year_start_inclusive, year_end_exclusive), e.g. (2026, 2027) for YTD 2026,
or None for "Lifetime" (no period filter).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from net_alpha.models.domain import Lot, Trade
from net_alpha.portfolio.models import KpiSet
from net_alpha.pricing.provider import Quote


def _realized_in(trades: Iterable[Trade], period: tuple[int, int] | None) -> Decimal:
    total = Decimal("0")
    for t in trades:
        if t.action.lower() != "sell":
            continue
        if period is not None and not (period[0] <= t.date.year < period[1]):
            continue
        total += Decimal(str((t.proceeds or 0) - (t.cost_basis or 0)))
    return total


def _open_market_and_basis(
    lots: Iterable[Lot],
    prices: dict[str, Quote],
) -> tuple[Decimal | None, Decimal]:
    """Return (sum(qty × price), sum(qty × adjusted_basis)) or (None, basis) when any lot is unpriced."""
    total_value: Decimal = Decimal("0")
    total_basis: Decimal = Decimal("0")
    any_missing = False
    for lot in lots:
        if lot.option_details is not None:
            continue  # equity-only for KPI market value
        qty = Decimal(str(lot.quantity))
        total_basis += qty * Decimal(str(lot.adjusted_basis))
        quote = prices.get(lot.ticker)
        if quote is None:
            any_missing = True
            continue
        total_value += qty * quote.price
    return (None if any_missing else total_value, total_basis)


def compute_kpis(
    *,
    trades: Iterable[Trade],
    lots: Iterable[Lot],
    prices: dict[str, Quote],
    period_label: str,
    period: tuple[int, int] | None,
    account: str | None,
) -> KpiSet:
    trades = list(trades)
    lots = list(lots)
    if account:
        trades = [t for t in trades if t.account == account]
        lots = [lot for lot in lots if lot.account == account]

    period_realized = _realized_in(trades, period)
    lifetime_realized = _realized_in(trades, None)

    market, basis = _open_market_and_basis(lots, prices)
    if market is None:
        period_unrealized = None
        lifetime_unrealized = None
        open_value = None
    else:
        unrealized = market - basis
        period_unrealized = unrealized   # unrealized is "now"; period only relabels the card
        lifetime_unrealized = unrealized
        open_value = market

    return KpiSet(
        period_label=period_label,
        period_realized=period_realized,
        period_unrealized=period_unrealized,
        lifetime_realized=lifetime_realized,
        lifetime_unrealized=lifetime_unrealized,
        open_position_value=open_value,
    )
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/portfolio/test_pnl.py -v`
Expected: all 4 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/pnl.py tests/portfolio/test_pnl.py
git commit -m "feat(portfolio): compute_kpis (period + lifetime, account-scoped)"
```

---

## Task 13: Portfolio — treemap layout (slice-and-dice)

**Files:**
- Create: `src/net_alpha/portfolio/treemap.py`
- Create: `tests/portfolio/test_treemap.py`

- [ ] **Step 1: Write failing tests**

Create `tests/portfolio/test_treemap.py`:

```python
from decimal import Decimal

from net_alpha.portfolio.models import PositionRow
from net_alpha.portfolio.treemap import build_treemap


def _row(symbol, value, unrealized=None):
    return PositionRow(
        symbol=symbol, accounts=("Tax",), qty=Decimal("1"),
        market_value=Decimal(str(value)) if value is not None else None,
        open_cost=Decimal("0"), avg_basis=Decimal("0"),
        cash_sunk_per_share=Decimal("0"),
        realized_pl=Decimal("0"),
        unrealized_pl=Decimal(str(unrealized)) if unrealized is not None else None,
    )


def test_empty_input_yields_no_tiles():
    assert build_treemap(positions=[], top_n=5) == []


def test_single_position_fills_entire_area():
    tiles = build_treemap(positions=[_row("SPY", 100, 10)], top_n=5)
    assert len(tiles) == 1
    t = tiles[0]
    assert t.symbol == "SPY"
    assert t.x_pct == 0.0 and t.y_pct == 0.0
    assert abs(t.width_pct - 100.0) < 0.01
    assert abs(t.height_pct - 100.0) < 0.01


def test_top_n_aggregates_long_tail_into_other():
    rows = [_row(s, v) for s, v in [("SPY", 50), ("QQQ", 30), ("AAPL", 10), ("TSLA", 5), ("AMD", 3), ("INTC", 2)]]
    tiles = build_treemap(positions=rows, top_n=3)
    symbols = [t.symbol for t in tiles]
    assert symbols[:3] == ["SPY", "QQQ", "AAPL"]
    assert "OTHER" in symbols
    other = next(t for t in tiles if t.symbol == "OTHER")
    assert other.market_value == Decimal("10")  # 5 + 3 + 2


def test_skips_positions_with_no_market_value():
    tiles = build_treemap(positions=[_row("SPY", None)], top_n=5)
    assert tiles == []


def test_tiles_total_area_approximates_full_box():
    rows = [_row(s, v) for s, v in [("SPY", 60), ("QQQ", 40)]]
    tiles = build_treemap(positions=rows, top_n=5)
    total_area = sum(t.width_pct * t.height_pct for t in tiles) / 100  # in pct² / 100 → pct
    assert abs(total_area - 100.0) < 0.5
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_treemap.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement slice-and-dice layout**

Create `src/net_alpha/portfolio/treemap.py`:

```python
"""Slice-and-dice treemap layout — pure layout in Python.

Renders to a list of TreemapTile rectangles in percent coordinates (0–100)
relative to the container. The renderer (Jinja template) just maps these to
inline CSS positions.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from net_alpha.portfolio.models import PositionRow, TreemapTile


def build_treemap(*, positions: Iterable[PositionRow], top_n: int = 8) -> list[TreemapTile]:
    """Return tiles laid out via simple slice-and-dice (alternating split direction)."""
    valued = [p for p in positions if p.market_value is not None and p.market_value > 0]
    valued.sort(key=lambda p: p.market_value or Decimal("0"), reverse=True)
    if not valued:
        return []

    head = valued[:top_n]
    tail = valued[top_n:]
    items: list[tuple[str, Decimal, Decimal | None]] = [
        (p.symbol, p.market_value, p.unrealized_pl) for p in head
    ]
    if tail:
        other_value = sum((p.market_value for p in tail), start=Decimal("0"))
        other_unrealized = sum(
            (p.unrealized_pl for p in tail if p.unrealized_pl is not None),
            start=Decimal("0"),
        )
        items.append(("OTHER", other_value, other_unrealized))

    total = sum(v for _, v, _ in items)
    return _layout(items, x=0.0, y=0.0, w=100.0, h=100.0, total=float(total), horizontal=True)


def _layout(
    items: list[tuple[str, Decimal, Decimal | None]],
    *, x: float, y: float, w: float, h: float, total: float, horizontal: bool,
) -> list[TreemapTile]:
    if not items or total <= 0:
        return []
    if len(items) == 1:
        sym, val, unr = items[0]
        return [TreemapTile(
            symbol=sym, market_value=val, unrealized_pl=unr,
            x_pct=x, y_pct=y, width_pct=w, height_pct=h,
        )]
    # Take the largest item, place it in a slice, recurse on the remainder.
    sym, val, unr = items[0]
    rest = items[1:]
    fraction = float(val) / total
    if horizontal:
        slice_w = w * fraction
        first = TreemapTile(symbol=sym, market_value=val, unrealized_pl=unr,
                            x_pct=x, y_pct=y, width_pct=slice_w, height_pct=h)
        rest_total = total - float(val)
        return [first] + _layout(rest, x=x + slice_w, y=y, w=w - slice_w, h=h,
                                  total=rest_total, horizontal=False)
    else:
        slice_h = h * fraction
        first = TreemapTile(symbol=sym, market_value=val, unrealized_pl=unr,
                            x_pct=x, y_pct=y, width_pct=w, height_pct=slice_h)
        rest_total = total - float(val)
        return [first] + _layout(rest, x=x, y=y + slice_h, w=w, h=h - slice_h,
                                  total=rest_total, horizontal=True)
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/portfolio/test_treemap.py -v`
Expected: all 5 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/treemap.py tests/portfolio/test_treemap.py
git commit -m "feat(portfolio): slice-and-dice treemap layout"
```

---

## Task 14: Portfolio — equity curve (cumulative realized + present-day point)

**Files:**
- Create: `src/net_alpha/portfolio/equity_curve.py`
- Create: `tests/portfolio/test_equity_curve.py`

- [ ] **Step 1: Write failing tests**

Create `tests/portfolio/test_equity_curve.py`:

```python
from datetime import date
from decimal import Decimal

from net_alpha.models.domain import Trade
from net_alpha.portfolio.equity_curve import build_equity_curve


def _sell(d, gain):
    return Trade(
        id="t", account="Tax", date=d, ticker="SPY", action="Sell",
        quantity=10.0, proceeds=10_000 + gain, cost_basis=10_000.0,
        basis_unknown=False, option_details=None,
    )


def test_empty_year_yields_zero_baseline_only():
    pts = build_equity_curve(trades=[], year=2026, present_unrealized=None)
    assert len(pts) == 1
    assert pts[0].cumulative_realized == Decimal("0")


def test_cumulative_realized_sorted_by_date():
    trades = [_sell(date(2026, 3, 10), 500), _sell(date(2026, 1, 5), 200)]
    pts = build_equity_curve(trades=trades, year=2026, present_unrealized=None)
    assert pts[0].cumulative_realized == Decimal("0")
    assert pts[1].cumulative_realized == Decimal("200")
    assert pts[2].cumulative_realized == Decimal("700")


def test_trades_outside_year_excluded():
    trades = [_sell(date(2025, 12, 31), 1_000), _sell(date(2026, 2, 1), 250)]
    pts = build_equity_curve(trades=trades, year=2026, present_unrealized=None)
    finals = [p.cumulative_realized for p in pts]
    assert finals[-1] == Decimal("250")


def test_present_day_point_carries_unrealized():
    trades = [_sell(date(2026, 1, 5), 200)]
    pts = build_equity_curve(trades=trades, year=2026, present_unrealized=Decimal("400"))
    last = pts[-1]
    assert last.unrealized == Decimal("400")
    assert last.cumulative_realized == Decimal("200")
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_equity_curve.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement `build_equity_curve`**

Create `src/net_alpha/portfolio/equity_curve.py`:

```python
"""Year-scoped cumulative realized P&L line + present-day unrealized dot.

Phase 1 limitation: backfill of historical unrealized requires end-of-day price
snapshots, which we don't yet persist. The line is realized-only across the
year; only the present-day point carries `unrealized`.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Iterable

from net_alpha.models.domain import Trade
from net_alpha.portfolio.models import EquityPoint


def build_equity_curve(
    *,
    trades: Iterable[Trade],
    year: int,
    present_unrealized: Decimal | None,
) -> list[EquityPoint]:
    sells = sorted(
        (t for t in trades if t.action.lower() == "sell" and t.date.year == year),
        key=lambda t: t.date,
    )

    points: list[EquityPoint] = [
        EquityPoint(on=date(year, 1, 1), cumulative_realized=Decimal("0"), unrealized=None)
    ]
    cum = Decimal("0")
    for t in sells:
        cum += Decimal(str((t.proceeds or 0) - (t.cost_basis or 0)))
        points.append(EquityPoint(on=t.date, cumulative_realized=cum, unrealized=None))

    today = date.today()
    last_day = today if today.year == year else date(year, 12, 31)
    if not points or points[-1].on != last_day:
        points.append(EquityPoint(on=last_day, cumulative_realized=cum, unrealized=present_unrealized))
    elif present_unrealized is not None:
        points[-1] = EquityPoint(on=last_day, cumulative_realized=cum, unrealized=present_unrealized)
    return points
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/portfolio/test_equity_curve.py -v`
Expected: all 4 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/equity_curve.py tests/portfolio/test_equity_curve.py
git commit -m "feat(portfolio): equity curve — realized cumulative + present-day point"
```

---

## Task 15: Portfolio — lot aging (top-N crossing LTCG)

**Files:**
- Create: `src/net_alpha/portfolio/lot_aging.py`
- Create: `tests/portfolio/test_lot_aging.py`

- [ ] **Step 1: Write failing tests**

Create `tests/portfolio/test_lot_aging.py`:

```python
from datetime import date, timedelta
from decimal import Decimal

from net_alpha.models.domain import Lot
from net_alpha.portfolio.lot_aging import top_lots_crossing_ltcg


def _lot(symbol, account, days_old, qty=10):
    today = date.today()
    return Lot(
        id="l", trade_id="t", account=account,
        date=today - timedelta(days=days_old),
        ticker=symbol, quantity=float(qty),
        cost_basis=1000.0, adjusted_basis=1000.0, option_details=None,
    )


def test_returns_empty_when_no_lots_within_window():
    assert top_lots_crossing_ltcg(lots=[_lot("SPY", "Tax", 10)], horizon_days=90, top_n=5) == []


def test_includes_only_lots_within_horizon():
    lots = [
        _lot("NVDA", "IRA", 357),  # 8 days to 1y
        _lot("AMD", "Tax", 344),    # 21 days
        _lot("FOO", "Tax", 200),    # >90 days away
    ]
    out = top_lots_crossing_ltcg(lots=lots, horizon_days=90, top_n=5)
    assert [l.symbol for l in out] == ["NVDA", "AMD"]


def test_excludes_already_long_term_lots():
    lots = [_lot("OLD", "Tax", 400)]
    assert top_lots_crossing_ltcg(lots=lots, horizon_days=90, top_n=5) == []


def test_caps_to_top_n_by_urgency():
    lots = [_lot(f"S{i}", "Tax", 365 - (1 + i)) for i in range(8)]  # 1d..8d to LTCG
    out = top_lots_crossing_ltcg(lots=lots, horizon_days=90, top_n=3)
    assert len(out) == 3
    # Most urgent first
    assert out[0].days_to_ltcg < out[-1].days_to_ltcg
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_lot_aging.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement `top_lots_crossing_ltcg`**

Create `src/net_alpha/portfolio/lot_aging.py`:

```python
"""Top open lots about to cross the long-term capital gains threshold.

LTCG threshold = acquired_on + 365 days. Returns lots whose days_to_ltcg is
in [1, horizon_days], sorted by urgency (smallest days_to_ltcg first).
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable

from net_alpha.models.domain import Lot
from net_alpha.portfolio.models import AgingLot


def top_lots_crossing_ltcg(*, lots: Iterable[Lot], horizon_days: int = 90, top_n: int = 5) -> list[AgingLot]:
    today = date.today()
    candidates: list[AgingLot] = []
    for lot in lots:
        if lot.option_details is not None or lot.quantity <= 0:
            continue
        ltcg_date = lot.date + timedelta(days=365)
        days = (ltcg_date - today).days
        if days < 1 or days > horizon_days:
            continue
        candidates.append(AgingLot(
            symbol=lot.ticker, account=lot.account,
            qty=Decimal(str(lot.quantity)),
            acquired_on=lot.date, days_to_ltcg=days,
        ))
    candidates.sort(key=lambda a: a.days_to_ltcg)
    return candidates[:top_n]
```

- [ ] **Step 4: Verify tests pass**

Run: `uv run pytest tests/portfolio/test_lot_aging.py -v`
Expected: all 4 pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/lot_aging.py tests/portfolio/test_lot_aging.py
git commit -m "feat(portfolio): lot_aging — top-N lots crossing LTCG threshold"
```

---

## Task 16: Portfolio — wash-sale impact aggregation

**Files:**
- Modify: `src/net_alpha/portfolio/pnl.py`
- Modify: `tests/portfolio/test_pnl.py`

- [ ] **Step 1: Write failing test for `compute_wash_impact`**

Append to `tests/portfolio/test_pnl.py`:

```python
from net_alpha.models.domain import WashSaleViolation
from net_alpha.portfolio.pnl import compute_wash_impact


def _violation(loss_date, *, disallowed=100.0, confidence="Confirmed", loss_account="Tax", buy_account="Tax"):
    return WashSaleViolation(
        id="v", loss_trade_id="t1", replacement_trade_id="t2",
        loss_account=loss_account, buy_account=buy_account,
        loss_sale_date=loss_date, triggering_buy_date=loss_date, ticker="SPY",
        confidence=confidence, disallowed_loss=disallowed, matched_quantity=10.0,
        source="engine",
    )


def test_wash_impact_period_filters_by_loss_date():
    violations = [
        _violation(date(2026, 3, 1), disallowed=200, confidence="Confirmed"),
        _violation(date(2025, 3, 1), disallowed=300, confidence="Probable"),
    ]
    out = compute_wash_impact(violations=violations, period_label="YTD", period=(2026, 2027), account=None)
    assert out.violation_count == 1
    assert out.disallowed_total == Decimal("200")
    assert out.confirmed_count == 1
    assert out.probable_count == 0


def test_wash_impact_account_filter_matches_either_side():
    v1 = _violation(date(2026, 3, 1), loss_account="IRA", buy_account="IRA")
    v2 = _violation(date(2026, 3, 2), loss_account="Tax", buy_account="Tax")
    v3 = _violation(date(2026, 3, 3), loss_account="IRA", buy_account="Tax")  # cross-account
    out = compute_wash_impact(violations=[v1, v2, v3], period_label="YTD", period=(2026, 2027), account="Tax")
    # v2 (both Tax) and v3 (Tax on buy side) match; v1 (both IRA) does not
    assert out.violation_count == 2


def test_wash_impact_lifetime_when_period_is_none():
    violations = [
        _violation(date(2024, 6, 1), confidence="Unclear"),
        _violation(date(2025, 6, 1), confidence="Probable"),
    ]
    out = compute_wash_impact(violations=violations, period_label="Lifetime", period=None, account=None)
    assert out.violation_count == 2
    assert out.unclear_count == 1
    assert out.probable_count == 1
```

- [ ] **Step 2: Run to confirm failure**

Run: `uv run pytest tests/portfolio/test_pnl.py -v`
Expected: 3 new tests fail (ImportError on compute_wash_impact).

- [ ] **Step 3: Add `compute_wash_impact`**

Append to `src/net_alpha/portfolio/pnl.py`:

```python
from net_alpha.models.domain import WashSaleViolation
from net_alpha.portfolio.models import WashImpact


def compute_wash_impact(
    *,
    violations: Iterable[WashSaleViolation],
    period_label: str,
    period: tuple[int, int] | None,
    account: str | None,
) -> WashImpact:
    rows = list(violations)
    if account:
        rows = [v for v in rows if v.loss_account == account or v.buy_account == account]
    if period is not None:
        rows = [v for v in rows if v.loss_sale_date and period[0] <= v.loss_sale_date.year < period[1]]
    disallowed = sum((Decimal(str(v.disallowed_loss)) for v in rows), start=Decimal("0"))
    return WashImpact(
        period_label=period_label,
        disallowed_total=disallowed,
        violation_count=len(rows),
        confirmed_count=sum(1 for v in rows if v.confidence == "Confirmed"),
        probable_count=sum(1 for v in rows if v.confidence == "Probable"),
        unclear_count=sum(1 for v in rows if v.confidence == "Unclear"),
    )
```

- [ ] **Step 4: Verify all `pnl` tests pass**

Run: `uv run pytest tests/portfolio/test_pnl.py -v`
Expected: all tests pass (original 4 + new 3).

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/pnl.py tests/portfolio/test_pnl.py
git commit -m "feat(portfolio): compute_wash_impact for portfolio mini-grid"
```

---

## Task 17: Portfolio — page shell route + base template

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Modify: `src/net_alpha/web/templates/base.html`
- Create: `src/net_alpha/web/templates/portfolio.html`
- Create: `src/net_alpha/web/templates/_portfolio_toolbar.html`
- Create: `src/net_alpha/web/templates/_portfolio_empty_state.html`
- Create: `tests/web/test_portfolio_routes.py`

- [ ] **Step 1: Read the existing base.html to understand nav structure**

Run: `cat src/net_alpha/web/templates/base.html`
Note the nav block — we'll change `Dashboard` link text to `Portfolio` (URL stays `/`).

- [ ] **Step 2: Write failing route tests**

Create `tests/web/test_portfolio_routes.py`:

```python
from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.web.app import create_app


def _client(tmp_path):
    return TestClient(create_app(Settings(data_dir=tmp_path)))


def test_root_renders_portfolio_when_no_imports(tmp_path):
    client = _client(tmp_path)
    response = client.get("/")
    assert response.status_code == 200
    assert "Portfolio" in response.text
    assert "Import your first CSV" in response.text


def test_root_renders_portfolio_toolbar_when_imports_exist(tmp_path, monkeypatch):
    client = _client(tmp_path)
    # Quick way to exercise the "with imports" path: insert one stub import.
    from sqlalchemy import text
    from net_alpha.db.connection import get_engine

    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab', 'Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 0)"
        ))
    response = client.get("/")
    assert response.status_code == 200
    assert "Period:" in response.text  # toolbar present
    assert "Account:" in response.text
```

- [ ] **Step 3: Replace the dashboard router with portfolio shell route**

Modify `src/net_alpha/web/routes/portfolio.py`. Add at the top:

```python
from datetime import date

from fastapi.responses import HTMLResponse
from fastapi import Request

from net_alpha.db.repository import Repository
from net_alpha.web.dependencies import get_repository
```

Add after the existing `refresh_prices` endpoint:

```python
@router.get("/", response_class=HTMLResponse)
def portfolio_page(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    group_options: str = "merge",
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    imports = repo.list_imports()
    accounts = sorted({imp.account_display for imp in imports})

    today = date.today()
    current_year = today.year
    available_years = sorted({int(yr) for yr in {imp.imported_at.year for imp in imports}} | {current_year}, reverse=True)

    selected_period = period or "ytd"
    return request.app.state.templates.TemplateResponse(
        request,
        "portfolio.html",
        {
            "imports": imports,
            "accounts": accounts,
            "available_years": available_years,
            "current_year": current_year,
            "selected_period": selected_period,
            "selected_account": account or "",
            "group_options": group_options,
        },
    )
```

- [ ] **Step 4: Drop the old dashboard router from `app.py` and include only portfolio**

Modify `src/net_alpha/web/app.py`. Change the import line:

```python
from net_alpha.web.routes import calendar, dashboard, detail, sim, system, ticker
```

to:

```python
from net_alpha.web.routes import calendar, detail, portfolio as portfolio_routes, sim, system, ticker
```

Remove the line `app.include_router(dashboard.router)`. The line `app.include_router(portfolio_routes.router)` should already be present from Task 9; ensure it's there.

- [ ] **Step 5: Update base.html nav and add portfolio template files**

Modify `src/net_alpha/web/templates/base.html`. Find the nav link reading `Dashboard` and change the visible text to `Portfolio`. Keep `href="/"` as-is.

Create `src/net_alpha/web/templates/portfolio.html`:

```html
{% extends "base.html" %}
{% block title %}Portfolio · net-alpha{% endblock %}
{% block content %}
  <h1 class="text-2xl mb-4">Portfolio</h1>

  {% if not imports %}
    {% include "_portfolio_empty_state.html" %}
  {% else %}
    {% include "_portfolio_toolbar.html" %}

    <div id="portfolio-kpis"
         hx-get="/portfolio/kpis?period={{ selected_period }}&account={{ selected_account }}"
         hx-trigger="load"
         hx-swap="innerHTML"
         class="mt-4"></div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
      <div id="portfolio-treemap"
           hx-get="/portfolio/treemap?account={{ selected_account }}"
           hx-trigger="load"
           hx-swap="innerHTML"
           class="kpi-card"></div>
      <div id="portfolio-equity"
           hx-get="/portfolio/equity-curve?period={{ selected_period }}&account={{ selected_account }}"
           hx-trigger="load"
           hx-swap="innerHTML"
           class="kpi-card"></div>
      <div id="portfolio-wash"
           hx-get="/portfolio/wash-impact?period={{ selected_period }}&account={{ selected_account }}"
           hx-trigger="load"
           hx-swap="innerHTML"
           class="kpi-card"></div>
      <div id="portfolio-aging"
           hx-get="/portfolio/lot-aging?account={{ selected_account }}"
           hx-trigger="load"
           hx-swap="innerHTML"
           class="kpi-card"></div>
    </div>

    <div id="portfolio-positions"
         hx-get="/portfolio/positions?period={{ selected_period }}&account={{ selected_account }}&group_options={{ group_options }}"
         hx-trigger="load"
         hx-swap="innerHTML"
         class="mt-6"></div>
  {% endif %}
{% endblock %}
```

Create `src/net_alpha/web/templates/_portfolio_empty_state.html`:

```html
<div class="kpi-card text-center text-slate-500 py-12">
  <p class="text-lg mb-2">No imports yet</p>
  <p class="text-sm mb-4">Import your first CSV to see your portfolio.</p>
  <a href="/imports" class="btn">+ Import your first CSV</a>
</div>
```

Create `src/net_alpha/web/templates/_portfolio_toolbar.html`:

```html
<form method="get" action="/" class="kpi-card flex gap-3 flex-wrap items-end text-sm">
  <div>
    <label class="block text-xs text-slate-500 uppercase">Period</label>
    <select name="period" onchange="this.form.submit()" class="border border-slate-300 rounded px-2 py-1 bg-white">
      <option value="ytd" {% if selected_period == 'ytd' %}selected{% endif %}>YTD ({{ current_year }})</option>
      {% for y in available_years %}
        {% if y != current_year %}
          <option value="{{ y }}" {% if selected_period == y|string %}selected{% endif %}>{{ y }}</option>
        {% endif %}
      {% endfor %}
      <option value="lifetime" {% if selected_period == 'lifetime' %}selected{% endif %}>Lifetime</option>
    </select>
  </div>
  <div>
    <label class="block text-xs text-slate-500 uppercase">Account</label>
    <select name="account" onchange="this.form.submit()" class="border border-slate-300 rounded px-2 py-1 bg-white">
      <option value="" {% if not selected_account %}selected{% endif %}>All accounts</option>
      {% for a in accounts %}
        <option value="{{ a }}" {% if selected_account == a %}selected{% endif %}>{{ a }}</option>
      {% endfor %}
    </select>
  </div>
  <div>
    <label class="block text-xs text-slate-500 uppercase">Options</label>
    <select name="group_options" onchange="this.form.submit()" class="border border-slate-300 rounded px-2 py-1 bg-white">
      <option value="merge" {% if group_options == 'merge' %}selected{% endif %}>Merge to underlying</option>
      <option value="separate" {% if group_options == 'separate' %}selected{% endif %}>Show separately</option>
    </select>
  </div>
  <div class="ml-auto flex items-center gap-2">
    <span id="price-status" class="text-xs text-slate-500">Prices: loading…</span>
    <button type="button"
            hx-post="/prices/refresh?symbols=ALL"
            hx-target="body" hx-swap="none"
            onclick="window.location.reload()"
            class="btn-ghost">↻ Refresh</button>
  </div>
</form>
```

- [ ] **Step 6: Verify route tests pass**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`
Expected: both pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/app.py \
       src/net_alpha/web/templates/base.html src/net_alpha/web/templates/portfolio.html \
       src/net_alpha/web/templates/_portfolio_toolbar.html \
       src/net_alpha/web/templates/_portfolio_empty_state.html \
       tests/web/test_portfolio_routes.py
git commit -m "feat(web): portfolio page shell with HTMX-loaded fragments + empty state"
```

---

## Task 18: Portfolio fragment — KPIs

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `src/net_alpha/web/templates/_portfolio_kpis.html`
- Modify: `tests/web/test_portfolio_routes.py`

- [ ] **Step 1: Helper to parse `period` query param to `(start, end_excl) | None`**

Add to `src/net_alpha/web/routes/portfolio.py` (top-level):

```python
def _parse_period(period: str | None, current_year: int) -> tuple[tuple[int, int] | None, str]:
    """Return ((start, end_exclusive) | None, label)."""
    if not period or period == "ytd":
        return ((current_year, current_year + 1), f"YTD {current_year}")
    if period == "lifetime":
        return (None, "Lifetime")
    try:
        y = int(period)
        return ((y, y + 1), str(y))
    except ValueError:
        return ((current_year, current_year + 1), f"YTD {current_year}")
```

- [ ] **Step 2: Add the KPIs fragment route**

Append to `src/net_alpha/web/routes/portfolio.py`:

```python
from net_alpha.portfolio.pnl import compute_kpis
from net_alpha.pricing.service import PricingService
from net_alpha.web.dependencies import get_pricing_service


@router.get("/portfolio/kpis", response_class=HTMLResponse)
def portfolio_kpis(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    trades = repo.all_trades()
    lots = repo.all_lots()
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    kpis = compute_kpis(
        trades=trades, lots=lots, prices=prices,
        period_label=period_label, period=period_tuple, account=account or None,
    )
    snap = svc.last_snapshot()
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_kpis.html",
        {"kpis": kpis, "snapshot": snap},
    )
```

- [ ] **Step 3: Create the KPIs partial**

Create `src/net_alpha/web/templates/_portfolio_kpis.html`:

```html
<div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
  <div class="kpi-card">
    <div class="text-xs text-slate-500 uppercase">{{ kpis.period_label }} Realized</div>
    <div class="text-2xl font-mono mt-1 {% if kpis.period_realized < 0 %}text-confirmed{% else %}text-emerald-600{% endif %}">
      {% if kpis.period_realized < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(kpis.period_realized|float|abs) }}
    </div>
  </div>
  <div class="kpi-card">
    <div class="text-xs text-slate-500 uppercase">{{ kpis.period_label }} Unrealized</div>
    <div class="text-2xl font-mono mt-1">
      {% if kpis.period_unrealized is none %}
        <span class="text-slate-400">—</span>
      {% elif kpis.period_unrealized < 0 %}
        <span class="text-confirmed">-${{ "%.2f"|format(kpis.period_unrealized|float|abs) }}</span>
      {% else %}
        <span class="text-emerald-600">+${{ "%.2f"|format(kpis.period_unrealized|float) }}</span>
      {% endif %}
    </div>
  </div>
  <div class="kpi-card">
    <div class="text-xs text-slate-500 uppercase">Lifetime Realized</div>
    <div class="text-2xl font-mono mt-1 {% if kpis.lifetime_realized < 0 %}text-confirmed{% else %}text-emerald-600{% endif %}">
      {% if kpis.lifetime_realized < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(kpis.lifetime_realized|float|abs) }}
    </div>
  </div>
  <div class="kpi-card">
    <div class="text-xs text-slate-500 uppercase">Lifetime Unrealized</div>
    <div class="text-2xl font-mono mt-1">
      {% if kpis.lifetime_unrealized is none %}
        <span class="text-slate-400">—</span>
      {% elif kpis.lifetime_unrealized < 0 %}
        <span class="text-confirmed">-${{ "%.2f"|format(kpis.lifetime_unrealized|float|abs) }}</span>
      {% else %}
        <span class="text-emerald-600">+${{ "%.2f"|format(kpis.lifetime_unrealized|float) }}</span>
      {% endif %}
    </div>
  </div>
  <div class="kpi-card">
    <div class="text-xs text-slate-500 uppercase">Open Position $</div>
    <div class="text-2xl font-mono mt-1">
      {% if kpis.open_position_value is none %}
        <span class="text-slate-400">—</span>
      {% else %}
        ${{ "%.2f"|format(kpis.open_position_value|float) }}
      {% endif %}
    </div>
  </div>
</div>
{% if snapshot.degraded %}
  <div class="text-xs text-amber-600 mt-2">Showing stale prices (provider unavailable).</div>
{% endif %}
```

- [ ] **Step 4: Append fragment test**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_kpis_fragment_renders_with_no_data(tmp_path):
    client = _client(tmp_path)
    response = client.get("/portfolio/kpis?period=ytd")
    assert response.status_code == 200
    assert "Realized" in response.text
    assert "Unrealized" in response.text
```

- [ ] **Step 5: Run and verify**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`
Expected: all pass.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/templates/_portfolio_kpis.html tests/web/test_portfolio_routes.py
git commit -m "feat(web): /portfolio/kpis fragment + KPI partial"
```

---

## Task 19: Portfolio fragment — positions table

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `src/net_alpha/web/templates/_portfolio_table.html`
- Modify: `tests/web/test_portfolio_routes.py`

- [ ] **Step 1: Add the positions fragment route**

Append to `src/net_alpha/web/routes/portfolio.py`:

```python
from net_alpha.portfolio.positions import compute_open_positions


@router.get("/portfolio/positions", response_class=HTMLResponse)
def portfolio_positions(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    group_options: str = "merge",
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    trades = repo.all_trades()
    lots = repo.all_lots()
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    rows = compute_open_positions(
        trades=trades, lots=lots, prices=prices,
        period=period_tuple, account=account or None,
    )
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_table.html",
        {"rows": rows, "period_label": period_label},
    )
```

- [ ] **Step 2: Create the table partial**

Create `src/net_alpha/web/templates/_portfolio_table.html`:

```html
{% if not rows %}
  <div class="kpi-card text-slate-500 text-sm">No open positions.</div>
{% else %}
  <table class="w-full text-sm bg-white rounded-lg shadow-sm border border-slate-200">
    <thead class="text-left text-xs text-slate-500 uppercase border-b border-slate-200">
      <tr>
        <th class="px-3 py-2">Symbol</th>
        <th class="px-3 py-2">Accounts</th>
        <th class="px-3 py-2 text-right">Qty</th>
        <th class="px-3 py-2 text-right">Mkt $</th>
        <th class="px-3 py-2 text-right">Open Cost</th>
        <th class="px-3 py-2 text-right">Avg Basis</th>
        <th class="px-3 py-2 text-right">Cash Sunk/sh</th>
        <th class="px-3 py-2 text-right">{{ period_label }} Realized</th>
        <th class="px-3 py-2 text-right">Unrealized</th>
      </tr>
    </thead>
    <tbody>
      {% for r in rows %}
        <tr class="row-hover border-b border-slate-100 last:border-b-0 cursor-pointer"
            onclick="window.location='/ticker/{{ r.symbol }}'">
          <td class="px-3 py-2 font-mono">{{ r.symbol }}</td>
          <td class="px-3 py-2 text-xs text-slate-500">
            {% if r.accounts|length <= 3 %}
              {{ r.accounts|join(' · ') }}
            {% else %}
              {{ r.accounts[0] }} +{{ r.accounts|length - 1 }} more
            {% endif %}
          </td>
          <td class="px-3 py-2 font-mono text-right">{{ "%.4f"|format(r.qty|float) }}</td>
          <td class="px-3 py-2 font-mono text-right">
            {% if r.market_value is none %}<span class="text-slate-400">—</span>
            {% else %}${{ "%.2f"|format(r.market_value|float) }}{% endif %}
          </td>
          <td class="px-3 py-2 font-mono text-right">${{ "%.2f"|format(r.open_cost|float) }}</td>
          <td class="px-3 py-2 font-mono text-right">${{ "%.2f"|format(r.avg_basis|float) }}</td>
          <td class="px-3 py-2 font-mono text-right">${{ "%.2f"|format(r.cash_sunk_per_share|float) }}</td>
          <td class="px-3 py-2 font-mono text-right {% if r.realized_pl < 0 %}text-confirmed{% elif r.realized_pl > 0 %}text-emerald-600{% endif %}">
            {% if r.realized_pl != 0 %}{% if r.realized_pl < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(r.realized_pl|float|abs) }}{% else %}—{% endif %}
          </td>
          <td class="px-3 py-2 font-mono text-right {% if r.unrealized_pl is not none and r.unrealized_pl < 0 %}text-confirmed{% elif r.unrealized_pl is not none and r.unrealized_pl > 0 %}text-emerald-600{% endif %}">
            {% if r.unrealized_pl is none %}<span class="text-slate-400">—</span>
            {% else %}{% if r.unrealized_pl < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(r.unrealized_pl|float|abs) }}{% endif %}
          </td>
        </tr>
      {% endfor %}
    </tbody>
  </table>
{% endif %}
```

- [ ] **Step 3: Append fragment test**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_positions_fragment_empty_state(tmp_path):
    client = _client(tmp_path)
    response = client.get("/portfolio/positions?period=ytd")
    assert response.status_code == 200
    assert "No open positions" in response.text
```

- [ ] **Step 4: Run and verify**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`
Expected: all pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/templates/_portfolio_table.html tests/web/test_portfolio_routes.py
git commit -m "feat(web): /portfolio/positions fragment + per-symbol table"
```

---

## Task 20: Portfolio fragments — treemap, equity curve, wash impact, lot aging

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `src/net_alpha/web/templates/_portfolio_treemap.html`
- Create: `src/net_alpha/web/templates/_portfolio_equity_curve.html`
- Create: `src/net_alpha/web/templates/_portfolio_wash_impact.html`
- Create: `src/net_alpha/web/templates/_portfolio_lot_aging.html`
- Modify: `tests/web/test_portfolio_routes.py`

- [ ] **Step 1: Add four fragment routes**

Append to `src/net_alpha/web/routes/portfolio.py`:

```python
from net_alpha.portfolio.equity_curve import build_equity_curve
from net_alpha.portfolio.lot_aging import top_lots_crossing_ltcg
from net_alpha.portfolio.pnl import compute_wash_impact
from net_alpha.portfolio.treemap import build_treemap


@router.get("/portfolio/treemap", response_class=HTMLResponse)
def portfolio_treemap(
    request: Request,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    today = date.today()
    trades = repo.all_trades()
    lots = repo.all_lots()
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    rows = compute_open_positions(
        trades=trades, lots=lots, prices=prices,
        period=(today.year, today.year + 1), account=account or None,
    )
    tiles = build_treemap(positions=rows, top_n=8)
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_treemap.html", {"tiles": tiles},
    )


@router.get("/portfolio/equity-curve", response_class=HTMLResponse)
def portfolio_equity_curve(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    year = period_tuple[0] if period_tuple else today.year
    trades = repo.all_trades()
    if account:
        trades = [t for t in trades if t.account == account]
    lots = repo.all_lots()
    if account:
        lots = [l for l in lots if l.account == account]
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    kpis = compute_kpis(
        trades=trades, lots=lots, prices=prices,
        period_label=period_label, period=period_tuple, account=None,  # already filtered
    )
    points = build_equity_curve(trades=trades, year=year, present_unrealized=kpis.period_unrealized)
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_equity_curve.html", {"points": points, "year": year},
    )


@router.get("/portfolio/wash-impact", response_class=HTMLResponse)
def portfolio_wash_impact(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    impact = compute_wash_impact(
        violations=repo.all_violations(),
        period_label=period_label, period=period_tuple, account=account or None,
    )
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_wash_impact.html", {"impact": impact},
    )


@router.get("/portfolio/lot-aging", response_class=HTMLResponse)
def portfolio_lot_aging(
    request: Request,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    lots = repo.all_lots()
    if account:
        lots = [l for l in lots if l.account == account]
    aging = top_lots_crossing_ltcg(lots=lots, horizon_days=90, top_n=5)
    return request.app.state.templates.TemplateResponse(
        request, "_portfolio_lot_aging.html", {"aging": aging},
    )
```

- [ ] **Step 2: Create the four partials**

Create `src/net_alpha/web/templates/_portfolio_treemap.html`:

```html
<div class="text-xs text-slate-500 uppercase mb-1">Allocation</div>
{% if not tiles %}
  <div class="text-sm text-slate-400">No priced positions.</div>
{% else %}
  <div class="relative" style="height:160px">
    {% for t in tiles %}
      <div class="absolute text-white text-xs p-1 overflow-hidden rounded"
           style="left:{{ '%.2f'|format(t.x_pct) }}%; top:{{ '%.2f'|format(t.y_pct) }}%;
                  width:{{ '%.2f'|format(t.width_pct) }}%; height:{{ '%.2f'|format(t.height_pct) }}%;
                  background-color: {% if t.unrealized_pl is none %}#64748b
                                    {% elif t.unrealized_pl > 0 %}#16a34a
                                    {% elif t.unrealized_pl < 0 %}#dc2626
                                    {% else %}#64748b{% endif %};">
        <div class="font-mono">{{ t.symbol }}</div>
        <div class="text-[10px] opacity-80">${{ "%.0f"|format(t.market_value|float) }}</div>
      </div>
    {% endfor %}
  </div>
{% endif %}
```

Create `src/net_alpha/web/templates/_portfolio_equity_curve.html`:

```html
<div class="text-xs text-slate-500 uppercase mb-1">{{ year }} equity curve</div>
{% if points|length <= 1 %}
  <div class="text-sm text-slate-400">No realized activity in {{ year }}.</div>
{% else %}
  {% set max_v = points|map(attribute='cumulative_realized')|map('float')|max %}
  {% set min_v = points|map(attribute='cumulative_realized')|map('float')|min %}
  {% set span = (max_v - min_v) if (max_v - min_v) > 0 else 1.0 %}
  <svg viewBox="0 0 100 60" preserveAspectRatio="none" class="w-full h-32">
    <polyline fill="none" stroke="#16a34a" stroke-width="0.5"
      points="
      {% for p in points %}
        {% set x = loop.index0 / (points|length - 1) * 100 %}
        {% set y = 60 - ((p.cumulative_realized|float - min_v) / span * 60) %}
        {{ '%.2f'|format(x) }},{{ '%.2f'|format(y) }}
      {% endfor %}
      "/>
    {% set last = points[-1] %}
    {% if last.unrealized is not none %}
      {% set last_x = 100 %}
      {% set last_y = 60 - ((last.cumulative_realized|float + last.unrealized|float - min_v) / span * 60) %}
      <circle cx="{{ '%.2f'|format(last_x) }}" cy="{{ '%.2f'|format(last_y) }}" r="1.5"
              fill="{% if last.unrealized > 0 %}#16a34a{% else %}#dc2626{% endif %}"/>
    {% endif %}
  </svg>
  <div class="text-[10px] text-slate-400 mt-1">Line: cumulative realized · Dot: + present-day unrealized</div>
{% endif %}
```

Create `src/net_alpha/web/templates/_portfolio_wash_impact.html`:

```html
<div class="text-xs text-slate-500 uppercase mb-1">Wash impact ({{ impact.period_label }})</div>
<div class="grid grid-cols-2 gap-2 text-xs">
  <div class="p-2 bg-amber-50 rounded">
    <div class="font-mono text-base">${{ "%.2f"|format(impact.disallowed_total|float) }}</div>
    <div class="text-slate-500">disallowed</div>
  </div>
  <div class="p-2 bg-amber-50 rounded">
    <div class="font-mono text-base">{{ impact.violation_count }}</div>
    <div class="text-slate-500">violations</div>
  </div>
  <a href="/calendar?confidence=confirmed" class="p-2 bg-red-50 rounded block hover:bg-red-100">
    <div class="font-mono text-base text-confirmed">{{ impact.confirmed_count }}</div>
    <div class="text-slate-500">confirmed</div>
  </a>
  <div class="p-2 bg-amber-50 rounded">
    <div class="font-mono text-base text-amber-600">{{ impact.probable_count }}</div>
    <div class="text-slate-500">probable</div>
  </div>
</div>
```

Create `src/net_alpha/web/templates/_portfolio_lot_aging.html`:

```html
<div class="text-xs text-slate-500 uppercase mb-1">Lots crossing LTCG soon</div>
{% if not aging %}
  <div class="text-sm text-slate-400">No lots crossing the LTCG threshold within 90 days.</div>
{% else %}
  <div class="text-xs">
    {% for a in aging %}
      <a href="/ticker/{{ a.symbol }}" class="flex justify-between py-1 border-b border-dashed border-slate-200 last:border-0 hover:bg-slate-50">
        <span class="font-mono">{{ a.symbol }}</span>
        <span class="{% if a.days_to_ltcg <= 14 %}text-confirmed{% elif a.days_to_ltcg <= 45 %}text-amber-600{% else %}text-slate-700{% endif %}">
          {{ a.days_to_ltcg }} days
        </span>
      </a>
    {% endfor %}
  </div>
{% endif %}
```

- [ ] **Step 3: Append fragment tests**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_treemap_fragment_empty(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/treemap")
    assert r.status_code == 200
    assert "No priced positions" in r.text


def test_equity_curve_fragment_no_data(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/equity-curve?period=ytd")
    assert r.status_code == 200
    assert "equity curve" in r.text


def test_wash_impact_fragment_zero(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/wash-impact?period=ytd")
    assert r.status_code == 200
    assert "disallowed" in r.text


def test_lot_aging_fragment_empty(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/lot-aging")
    assert r.status_code == 200
    assert "No lots crossing" in r.text
```

- [ ] **Step 4: Run and verify**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`
Expected: all pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py \
       src/net_alpha/web/templates/_portfolio_treemap.html \
       src/net_alpha/web/templates/_portfolio_equity_curve.html \
       src/net_alpha/web/templates/_portfolio_wash_impact.html \
       src/net_alpha/web/templates/_portfolio_lot_aging.html \
       tests/web/test_portfolio_routes.py
git commit -m "feat(web): treemap, equity curve, wash-impact, lot-aging fragments"
```

---

## Task 21: Disclaimer footer — add price-source line

**Files:**
- Modify: `src/net_alpha/output/disclaimer.py`
- Modify: `src/net_alpha/web/app.py`
- Modify: `src/net_alpha/web/templates/base.html`

- [ ] **Step 1: Read existing disclaimer module**

Run: `cat src/net_alpha/output/disclaimer.py`
Note current `render()` signature.

- [ ] **Step 2: Add a sibling line for prices**

Modify `src/net_alpha/output/disclaimer.py`. Add a function `price_source_line()`:

```python
def price_source_line(source: str | None = "Yahoo Finance") -> str:
    if not source:
        return ""
    return f"Prices via {source}, ~15 min delayed."
```

(Keep the existing `render()` unchanged.)

- [ ] **Step 3: Expose `price_source_line` to Jinja globals**

Modify `src/net_alpha/web/app.py`. Replace:

```python
templates.env.globals["disclaimer"] = disclaimer_render()
```

with:

```python
from net_alpha.output.disclaimer import price_source_line
templates.env.globals["disclaimer"] = disclaimer_render()
templates.env.globals["price_disclosure"] = (
    price_source_line("Yahoo Finance") if pricing_config.enable_remote else ""
)
```

- [ ] **Step 4: Render `price_disclosure` in `base.html` footer**

Modify `src/net_alpha/web/templates/base.html`. Find the existing disclaimer footer block and add immediately after it:

```html
{% if price_disclosure %}
  <div class="text-xs text-slate-400 text-center mt-1">{{ price_disclosure }}</div>
{% endif %}
```

- [ ] **Step 5: Quick render check**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`
Expected: still passes; if any test inspects the page text, the disclosure line appears.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/output/disclaimer.py src/net_alpha/web/app.py src/net_alpha/web/templates/base.html
git commit -m "feat(web): add 'Prices via Yahoo Finance' footer line when remote prices enabled"
```

---

## Task 22: Delete the old dashboard

**Files:**
- Delete: `src/net_alpha/web/routes/dashboard.py`
- Delete: `src/net_alpha/web/templates/dashboard.html`
- Delete: `src/net_alpha/web/templates/_ytd_impact.html`
- Delete: `src/net_alpha/web/templates/_watch_list.html`
- Delete: `tests/web/test_dashboard.py`

- [ ] **Step 1: Verify nothing else imports `routes.dashboard`**

Run: `grep -rn "routes.dashboard\|web/routes/dashboard\|dashboard\.router" src/ tests/`
Expected: only the import in `app.py` (already removed in Task 17). If anything else turns up, fix that first.

- [ ] **Step 2: Verify `dashboard.html`, `_ytd_impact.html`, `_watch_list.html` aren't included anywhere**

Run: `grep -rn "dashboard.html\|_ytd_impact\|_watch_list" src/ tests/`
Expected: no hits left after Task 17. If hits remain, update those templates first.

- [ ] **Step 3: Delete the files**

```bash
rm src/net_alpha/web/routes/dashboard.py
rm src/net_alpha/web/templates/dashboard.html
rm src/net_alpha/web/templates/_ytd_impact.html
rm src/net_alpha/web/templates/_watch_list.html
rm tests/web/test_dashboard.py
```

- [ ] **Step 4: Run the full test suite**

Run: `uv run pytest -q`
Expected: all tests pass; no references to deleted files remain.

- [ ] **Step 5: Commit**

```bash
git add -u src/net_alpha/web/routes/dashboard.py src/net_alpha/web/templates/dashboard.html \
           src/net_alpha/web/templates/_ytd_impact.html src/net_alpha/web/templates/_watch_list.html \
           tests/web/test_dashboard.py
git commit -m "chore(web): remove obsolete dashboard route, templates, and tests"
```

---

## Task 23: Update CLAUDE.md with Phase 1 changes

**Files:**
- Modify: `CLAUDE.md`

- [ ] **Step 1: Add a "Price data" subsection under "Data Privacy Constraints"**

Find the section in `CLAUDE.md`:

```
## Data Privacy Constraints

All trade data stays local. There are no remote calls. No telemetry.
```

Replace with:

```
## Data Privacy Constraints

All trade data stays local. No telemetry.

### Price data (Phase 1+)

Symbols are sent to Yahoo Finance to fetch current quotes for the Portfolio
page. Trade data, accounts, P&L, and any other personally-identifying data
never leave the box. Disable price fetches by setting
`prices.enable_remote: false` in `~/.net_alpha/config.yaml`.
```

- [ ] **Step 2: Update the architecture/module list**

Find the "Architecture" section. Under "Data Flow" or near it, add a sentence near the existing module list:

```
- Pricing subsystem: `pricing/` — PriceProvider ABC, YahooPriceProvider, SQLite-backed PriceCache, PricingService orchestrator.
- Portfolio aggregations: `portfolio/` — pure functions for positions, KPIs, treemap, equity curve, lot aging.
```

(Place these wherever the existing module enumeration lives in your file.)

- [ ] **Step 3: Add a brief "Web UI conventions" subsection**

Append (or place near the existing Web UI block):

```
### Web UI conventions

Each scoped page uses a top-of-page toolbar: `Period` (YTD / specific year / Lifetime) + `Account` (All / per-account). State is per-page (not global). Heavy panels load lazily as HTMX fragments under stable IDs.
```

- [ ] **Step 4: Quick sanity check formatting**

Run: `head -100 CLAUDE.md`
Expected: the additions read naturally; markdown headings line up.

- [ ] **Step 5: Commit**

```bash
git add CLAUDE.md
git commit -m "docs(claude.md): document price-data privacy + portfolio modules + UI conventions"
```

---

## Task 24: End-to-end smoke test

**Files:**
- Create: `tests/integration/test_portfolio_e2e.py`

- [ ] **Step 1: Write an end-to-end integration test**

Create (or add to existing) `tests/integration/test_portfolio_e2e.py`:

```python
"""End-to-end: import a fixture CSV, hit Portfolio page, verify all fragments load."""

from datetime import datetime, timezone
from decimal import Decimal
from unittest.mock import patch

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.pricing.provider import Quote
from net_alpha.web.app import create_app


def test_portfolio_page_full_render(tmp_path):
    settings = Settings(data_dir=tmp_path)
    app = create_app(settings)
    client = TestClient(app)

    # Patch the provider so no network is needed.
    fake = {
        "SPY": Quote(symbol="SPY", price=Decimal("460.5"),
                     as_of=datetime.now(timezone.utc), source="yahoo"),
    }
    with patch.object(app.state.price_provider, "get_quotes", return_value=fake):
        # Empty state: page renders with CTA.
        r = client.get("/")
        assert r.status_code == 200
        assert "No imports yet" in r.text

        # Insert a stub trade + lot directly to exercise the populated path.
        from sqlalchemy import text
        from net_alpha.db.connection import get_engine
        engine = get_engine(settings.db_path)
        with engine.begin() as conn:
            conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab', 'Tax')"))
            conn.execute(text(
                "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
                "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
            ))
            conn.execute(text(
                "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
                "quantity, proceeds, cost_basis, basis_unknown, basis_source) "
                "VALUES (1, 1, 'k1', 'SPY', '2025-01-15', 'Buy', 100, NULL, 40000, 0, 'broker_csv')"
            ))
            conn.execute(text(
                "INSERT INTO lots(trade_id, account_id, ticker, trade_date, quantity, cost_basis, adjusted_basis) "
                "VALUES (1, 1, 'SPY', '2025-01-15', 100, 40000, 40000)"
            ))

        # Page now shows toolbar.
        r = client.get("/")
        assert r.status_code == 200
        assert "Period:" in r.text

        # All fragments respond 200 with content.
        for path in [
            "/portfolio/kpis?period=ytd",
            "/portfolio/positions?period=ytd",
            "/portfolio/treemap",
            "/portfolio/equity-curve?period=ytd",
            "/portfolio/wash-impact?period=ytd",
            "/portfolio/lot-aging",
        ]:
            r = client.get(path)
            assert r.status_code == 200, f"{path} returned {r.status_code}"
            assert len(r.text.strip()) > 0
```

- [ ] **Step 2: Run the e2e test**

Run: `uv run pytest tests/integration/test_portfolio_e2e.py -v`
Expected: passes.

- [ ] **Step 3: Run the full suite**

Run: `uv run pytest -q`
Expected: all tests pass.

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_portfolio_e2e.py
git commit -m "test(integration): end-to-end portfolio page render with mocked prices"
```

---

## Task 25: Final cleanup — lint, format, manual smoke

**Files:** all touched files

- [ ] **Step 1: Lint**

Run: `uv run ruff check . && uv run ruff format .`
Expected: clean. Fix any reported issues.

- [ ] **Step 2: Final test pass**

Run: `uv run pytest -q`
Expected: all tests pass.

- [ ] **Step 3: Manual UI smoke test**

```bash
uv run net-alpha ui --no-browser --port 7100
```

Open `http://127.0.0.1:7100/` in a browser. Verify:
- Empty-state shows the CTA when no data.
- (After importing a CSV via `/imports`) toolbar appears, KPIs render, treemap renders if SPY etc. are priced, table populates.
- Footer shows the new `Prices via Yahoo Finance` line.
- `↻ Refresh` button reloads the page.

- [ ] **Step 4: Commit any formatting fixes**

```bash
git add -A
git commit -m "chore: lint + format" --allow-empty
```

(Skip if there's nothing to commit.)

---

## Plan complete

Phase 1 ships when all 25 tasks are done. Phase 2 (Calendar dual-ribbon + Imports relocation/notes) and Phase 3 (Sim buy + Detail enhancements) get their own plans, both independent of each other and only depending on Phase 1's structural changes (nav rename, base template).
