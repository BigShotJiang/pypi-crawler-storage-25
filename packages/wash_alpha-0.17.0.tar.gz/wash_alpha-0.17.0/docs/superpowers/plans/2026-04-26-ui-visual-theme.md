# UI Visual Theme — Apple-dark Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Re-skin the entire `net-alpha` web UI in an Apple-dark theme with cyber undertones, replace the allocation treemap with a donut + chips module, replace the home-page calendar ribbon with a "Wash-sale watch" panel, and swap the hand-rolled equity curve for ApexCharts.

**Architecture:** Visual-only redesign on top of the existing FastAPI/Jinja/HTMX/Alpine stack. New design tokens in Tailwind config, vendored Inter / JetBrains Mono / ApexCharts assets under `web/static/`. One new pure helper (`portfolio/wash_watch.py`) for the new home-page panel. All routes preserved except: `/portfolio/treemap` is removed, `/portfolio/allocation` is added, `/portfolio/wash-watch` is added.

**Tech Stack:** Python 3.11 + uv + FastAPI + Jinja2 + Tailwind CSS (via `pytailwindcss`) + HTMX + Alpine.js. ApexCharts vendored as static asset (no runtime npm). Pytest with `fastapi.testclient.TestClient`.

**Reference spec:** `docs/superpowers/specs/2026-04-26-ui-visual-theme-design.md`

---

## File Structure

### Files to create

| Path | Purpose |
|---|---|
| `src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.js` | Vendored ApexCharts JS |
| `src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.css` | Vendored ApexCharts CSS |
| `src/net_alpha/web/static/fonts/Inter-Regular.woff2` | Vendored Inter (400) |
| `src/net_alpha/web/static/fonts/Inter-Medium.woff2` | Vendored Inter (500) |
| `src/net_alpha/web/static/fonts/Inter-SemiBold.woff2` | Vendored Inter (600) |
| `src/net_alpha/web/static/fonts/Inter-Bold.woff2` | Vendored Inter (700) |
| `src/net_alpha/web/static/fonts/JetBrainsMono-Regular.woff2` | Vendored JetBrains Mono (400) |
| `src/net_alpha/web/static/fonts/JetBrainsMono-Medium.woff2` | Vendored JetBrains Mono (500) |
| `src/net_alpha/web/static/charts.js` | Shared ApexCharts dark theme |
| `src/net_alpha/portfolio/allocation.py` | Donut/leaderboard view computation |
| `src/net_alpha/portfolio/wash_watch.py` | Recent-loss-closes aggregation |
| `src/net_alpha/web/templates/_portfolio_allocation.html` | Donut + chips partial |
| `src/net_alpha/web/templates/_portfolio_wash_watch.html` | Wash-sale watch partial |
| `tests/portfolio/test_allocation.py` | Allocation helper tests |
| `tests/portfolio/test_wash_watch.py` | Wash-watch helper tests |
| `tests/web/test_allocation_route.py` | Allocation fragment route tests |
| `tests/web/test_wash_watch_route.py` | Wash-watch fragment route tests |

### Files to modify

| Path | Why |
|---|---|
| `src/net_alpha/web/tailwind.config.js` | New color tokens, font families, radii |
| `src/net_alpha/web/static/app.src.css` | Type scale, base layer, component classes |
| `src/net_alpha/web/templates/base.html` | Fonts, ApexCharts script, vibrancy topbar, restyle nav |
| `src/net_alpha/web/templates/portfolio.html` | Drop treemap+calendar-ribbon, add allocation+wash-watch, KPI grid layout |
| `src/net_alpha/web/templates/_portfolio_kpis.html` | Combined hero cards (Realized, Unrealized) + minis (Open$, Wash) |
| `src/net_alpha/web/templates/_portfolio_table.html` | Restyle, snug density, no status col, ticker icons |
| `src/net_alpha/web/templates/_portfolio_toolbar.html` | Restyle segmented controls |
| `src/net_alpha/web/templates/_portfolio_empty_state.html` | Restyle |
| `src/net_alpha/web/templates/_portfolio_equity_curve.html` | ApexCharts container instead of inline SVG |
| `src/net_alpha/web/templates/_portfolio_wash_impact.html` | Restyle |
| `src/net_alpha/web/templates/_portfolio_lot_aging.html` | Restyle |
| `src/net_alpha/web/templates/calendar.html` | Restyle page chrome |
| `src/net_alpha/web/templates/_calendar_pl_ribbon.html` | Recolor bars (Apple system green/red) |
| `src/net_alpha/web/templates/_calendar_ribbon.html` | Recolor dots, glow |
| `src/net_alpha/web/templates/_calendar_focus.html` | Restyle |
| `src/net_alpha/web/templates/_violation_card.html` | Restyle |
| `src/net_alpha/web/templates/imports.html` | Restyle |
| `src/net_alpha/web/templates/_imports_table.html` | Restyle |
| `src/net_alpha/web/templates/_imports_detail_row.html` | Restyle |
| `src/net_alpha/web/templates/_drop_zone.html` | Restyle |
| `src/net_alpha/web/templates/_import_modal.html` | Restyle |
| `src/net_alpha/web/templates/sim.html` | Restyle |
| `src/net_alpha/web/templates/_sim_buy_result.html` | Restyle |
| `src/net_alpha/web/templates/_sim_sell_result.html` | Restyle |
| `src/net_alpha/web/templates/detail.html` | Restyle |
| `src/net_alpha/web/templates/_detail_table.html` | Restyle |
| `src/net_alpha/web/templates/ticker.html` | Restyle |
| `src/net_alpha/web/templates/_lots_table.html` | Restyle |
| `src/net_alpha/web/templates/_schwab_lot_detail.html` | Restyle |
| `src/net_alpha/web/templates/_toast.html` | Restyle |
| `src/net_alpha/web/templates/error.html` | Restyle |
| `src/net_alpha/web/routes/portfolio.py` | Replace `/portfolio/treemap` with `/portfolio/allocation`; add `/portfolio/wash-watch` |
| `Makefile` | Add `vendor-apex` and `vendor-fonts` helper targets |

### Files to delete

| Path | Why |
|---|---|
| `src/net_alpha/portfolio/treemap.py` | Replaced by `allocation.py` |
| `src/net_alpha/web/templates/_portfolio_treemap.html` | Replaced by `_portfolio_allocation.html` |
| `tests/portfolio/test_treemap.py` | Replaced by `test_allocation.py` |

---

## Phase A — Foundation (tokens, fonts, ApexCharts, topbar, KPIs)

### Task A1: Vendor Inter and JetBrains Mono fonts

**Files:**
- Create: `src/net_alpha/web/static/fonts/Inter-{Regular,Medium,SemiBold,Bold}.woff2`
- Create: `src/net_alpha/web/static/fonts/JetBrainsMono-{Regular,Medium}.woff2`
- Modify: `Makefile`

- [ ] **Step 1: Add a `vendor-fonts` Makefile target**

Append to `Makefile`:

```makefile
vendor-fonts:
	@mkdir -p src/net_alpha/web/static/fonts
	curl -sSL -o src/net_alpha/web/static/fonts/Inter-Regular.woff2  https://rsms.me/inter/font-files/Inter-Regular.woff2
	curl -sSL -o src/net_alpha/web/static/fonts/Inter-Medium.woff2   https://rsms.me/inter/font-files/Inter-Medium.woff2
	curl -sSL -o src/net_alpha/web/static/fonts/Inter-SemiBold.woff2 https://rsms.me/inter/font-files/Inter-SemiBold.woff2
	curl -sSL -o src/net_alpha/web/static/fonts/Inter-Bold.woff2     https://rsms.me/inter/font-files/Inter-Bold.woff2
	curl -sSL -o src/net_alpha/web/static/fonts/JetBrainsMono-Regular.woff2 https://github.com/JetBrains/JetBrainsMono/raw/master/fonts/webfonts/JetBrainsMono-Regular.woff2
	curl -sSL -o src/net_alpha/web/static/fonts/JetBrainsMono-Medium.woff2  https://github.com/JetBrains/JetBrainsMono/raw/master/fonts/webfonts/JetBrainsMono-Medium.woff2
```

Update `.PHONY` line to include `vendor-fonts vendor-apex`.

- [ ] **Step 2: Run the target**

```bash
make vendor-fonts
```

Expected: 6 woff2 files appear in `src/net_alpha/web/static/fonts/`.

- [ ] **Step 3: Verify file sizes are sane**

```bash
ls -la src/net_alpha/web/static/fonts/
```

Expected: each Inter file ~50–100kb, each JetBrainsMono file ~70–100kb. If a file is ~0 bytes the URL is dead — try `https://github.com/rsms/inter/raw/master/docs/font-files/Inter-Regular.woff2` as a fallback.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/static/fonts/ Makefile
git commit -m "feat(web): vendor Inter and JetBrains Mono woff2 fonts"
```

---

### Task A2: Vendor ApexCharts

**Files:**
- Create: `src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.js`
- Create: `src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.css`
- Modify: `Makefile`

- [ ] **Step 1: Add `vendor-apex` Makefile target**

Append to `Makefile`:

```makefile
vendor-apex:
	@mkdir -p src/net_alpha/web/static/vendor/apexcharts
	curl -sSL -o src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.js  https://cdn.jsdelivr.net/npm/apexcharts@3.51.0/dist/apexcharts.min.js
	curl -sSL -o src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.css https://cdn.jsdelivr.net/npm/apexcharts@3.51.0/dist/apexcharts.min.css
```

- [ ] **Step 2: Run the target**

```bash
make vendor-apex
```

Expected: `apexcharts.min.js` (~500kb) and `apexcharts.min.css` (~10kb) present.

- [ ] **Step 3: Sanity-check the JS file is valid**

```bash
head -c 200 src/net_alpha/web/static/vendor/apexcharts/apexcharts.min.js
```

Expected: starts with something like `!function(t,e){…}` or a UMD prelude. If the file starts with `<!DOCTYPE` or `<html`, the URL returned an error page — re-check the URL.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/static/vendor/ Makefile
git commit -m "feat(web): vendor ApexCharts 3.51 (no runtime npm)"
```

---

### Task A3: Update Tailwind config with new color tokens

**Files:**
- Modify: `src/net_alpha/web/tailwind.config.js`

- [ ] **Step 1: Replace the entire `tailwind.config.js`**

Open `src/net_alpha/web/tailwind.config.js` and replace the whole file with:

```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/net_alpha/web/templates/**/*.html"],
  safelist: [
    // semantic colors used dynamically in templates
    { pattern: /^bg-(surface|surface-2|surface-3|pos|neg|warn|info|indigo|violet)$/ },
    { pattern: /^text-(label-1|label-2|label-3|pos|neg|warn|info|indigo|violet)$/ },
    { pattern: /^border-(hairline|hairline-strong|pos|neg|warn|info|indigo|violet)$/ },
    // chip variants
    "chip", "chip-confirm", "chip-probable", "chip-unclear",
    // KPI hero halo
    "kpi-hero",
    // segmented buttons
    "seg", "seg-active",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['-apple-system', '"SF Pro Display"', '"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"SF Mono"', '"JetBrains Mono"', 'ui-monospace', 'Menlo', 'monospace'],
      },
      colors: {
        // Canvas
        bg:          "#000000",
        surface:     "#1C1C1E",
        "surface-2": "#2C2C2E",
        "surface-3": "#3A3A3C",
        // Hairline (transparent — exposed as utility too)
        hairline:        "rgba(255,255,255,0.08)",
        "hairline-strong": "rgba(255,255,255,0.14)",
        // Text
        text:      "#FFFFFF",
        "label-1": "rgba(235,235,245,0.92)",
        "label-2": "rgba(235,235,245,0.60)",
        "label-3": "rgba(235,235,245,0.35)",
        // Brand cyber
        indigo:  "#5E5CE6",
        violet:  "#BF5AF2",
        // Semantic — P/L
        pos:    "#30D158",
        neg:    "#FF453A",
        // Semantic — status
        warn:   "#FF9F0A",
        info:   "#64D2FF",
        // Allocation rank palette (slot-bound, see spec §3.1)
        "rank-1":  "#0A84FF",
        "rank-2":  "#FFD60A",
        "rank-3":  "#30D158",
        "rank-4":  "#FF375F",
        "rank-5":  "#5E5CE6",
        "rank-6":  "#64D2FF",
        "rank-7":  "#5AC8FA",
        "rank-8":  "#BF5AF2",
        "rank-9":  "rgba(181,181,255,0.65)",
        "rank-10": "rgba(255,255,255,0.40)",
        "rank-rest": "rgba(255,255,255,0.14)",
        // Back-compat aliases for existing class refs (badge-confirmed etc.)
        confirmed: "#FF453A",
        probable:  "#FF9F0A",
        unclear:   "#64D2FF",
        primary:   "#0A84FF",
        secondary: "#5E5CE6",
        accent:    "#BF5AF2",
        ink:       "#FFFFFF",
      },
      borderRadius: {
        sm: "6px",
        md: "8px",
        lg: "12px",
        xl: "16px",
      },
      letterSpacing: {
        tightish: "-0.015em",
        tight:    "-0.02em",
        tighter:  "-0.025em",
      },
      backdropBlur: {
        vibrancy: "20px",
      },
    },
  },
  plugins: [],
};
```

The back-compat aliases (`confirmed`, `probable`, `unclear`, `primary`, etc.) keep existing class references rendering correctly until each template is restyled.

- [ ] **Step 2: Build CSS to verify config is valid**

```bash
make build-css
```

Expected: CSS builds without warnings about invalid class names. If you see `[Warning] No utility classes were detected`, double-check the `content` glob and at least one template references a class.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/tailwind.config.js
git commit -m "feat(web): new Apple-dark color tokens, font stack, radii in tailwind config"
```

---

### Task A4: Update app.src.css with new typography, base, components

**Files:**
- Modify: `src/net_alpha/web/static/app.src.css`

- [ ] **Step 1: Replace `app.src.css` contents**

Open the file and replace with:

```css
/* Self-hosted Inter (variable axes 400/500/600/700) */
@font-face {
  font-family: "Inter";
  font-style: normal; font-weight: 400; font-display: swap;
  src: url("/static/fonts/Inter-Regular.woff2") format("woff2");
}
@font-face {
  font-family: "Inter";
  font-style: normal; font-weight: 500; font-display: swap;
  src: url("/static/fonts/Inter-Medium.woff2") format("woff2");
}
@font-face {
  font-family: "Inter";
  font-style: normal; font-weight: 600; font-display: swap;
  src: url("/static/fonts/Inter-SemiBold.woff2") format("woff2");
}
@font-face {
  font-family: "Inter";
  font-style: normal; font-weight: 700; font-display: swap;
  src: url("/static/fonts/Inter-Bold.woff2") format("woff2");
}
@font-face {
  font-family: "JetBrains Mono";
  font-style: normal; font-weight: 400; font-display: swap;
  src: url("/static/fonts/JetBrainsMono-Regular.woff2") format("woff2");
}
@font-face {
  font-family: "JetBrains Mono";
  font-style: normal; font-weight: 500; font-display: swap;
  src: url("/static/fonts/JetBrainsMono-Medium.woff2") format("woff2");
}

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  html { color-scheme: dark; }
  body {
    @apply bg-bg text-text font-sans;
    font-feature-settings: "ss01", "cv11";
    -webkit-font-smoothing: antialiased;
  }
  h1 { @apply text-[28px] font-bold tracking-tighter; }
  h2 { @apply text-[20px] font-semibold tracking-tighter; }
  h3 { @apply text-[16px] font-semibold tracking-tightish; }
  /* tabular-nums for any element class="num" */
  .num {
    @apply font-mono;
    font-variant-numeric: tabular-nums;
    letter-spacing: -0.01em;
  }
}

@layer components {
  .panel {
    @apply bg-surface rounded-lg p-4;
    border: 0.5px solid theme('colors.hairline');
  }
  .panel-head {
    @apply flex items-baseline justify-between mb-2;
  }
  .panel-head h4 {
    @apply text-[14px] font-semibold tracking-tightish m-0;
  }
  .panel-head .meta {
    @apply text-[11px] text-label-2 font-medium;
  }
  .label-uc {
    @apply text-[11px] text-label-2 font-medium uppercase;
    letter-spacing: 0.04em;
  }

  /* KPI cards */
  .kpi {
    @apply bg-surface rounded-lg px-4 py-3 relative overflow-hidden;
    border: 0.5px solid theme('colors.hairline');
  }
  .kpi-hero {
    background:
      radial-gradient(120% 90% at 0% 0%,    rgba(94,92,230,0.16) 0%, transparent 55%),
      radial-gradient(140% 100% at 100% 100%, rgba(191,90,242,0.10) 0%, transparent 55%),
      #1C1C1E;
    border-color: rgba(94,92,230,0.22);
  }

  /* Segmented control */
  .seg {
    @apply inline-flex bg-surface rounded-md p-[2px];
    border: 0.5px solid theme('colors.hairline');
  }
  .seg button, .seg a {
    @apply bg-transparent text-label-2 border-0 px-3 py-1 text-[12px] font-medium rounded-[6px] cursor-pointer;
    transition: background-color 120ms, color 120ms;
  }
  .seg button:hover:not(.seg-active),
  .seg a:hover:not(.seg-active) { @apply text-text; }
  .seg-active {
    @apply bg-surface-3 text-text;
    box-shadow: 0 1px 2px rgba(0,0,0,0.4);
  }

  /* Top-bar pill (read-only summary) */
  .pill {
    @apply px-[10px] py-[3px] bg-surface rounded-full text-[11px] text-label-1 font-medium;
    border: 0.5px solid theme('colors.hairline');
  }

  /* Topbar with vibrancy */
  .topbar {
    @apply sticky top-0 z-10 flex items-center justify-between px-5 py-3;
    background: rgba(0,0,0,0.6);
    backdrop-filter: saturate(180%) blur(20px);
    -webkit-backdrop-filter: saturate(180%) blur(20px);
    border-bottom: 1px solid theme('colors.hairline');
  }
  .nav-link {
    @apply px-3 py-[5px] text-[13px] text-label-2 rounded-md font-medium no-underline;
    transition: background-color 120ms, color 120ms;
  }
  .nav-link:hover { @apply text-text; }
  .nav-link.active { @apply bg-surface-2 text-text; }

  /* Status chips */
  .chip-confirm  { @apply text-[11px] px-2 py-[2px] rounded-full font-medium text-neg;  background: rgba(255,69,58,0.14); }
  .chip-probable { @apply text-[11px] px-2 py-[2px] rounded-full font-medium text-warn; background: rgba(255,159,10,0.16); }
  .chip-unclear  { @apply text-[11px] px-2 py-[2px] rounded-full font-medium text-info; background: rgba(100,210,255,0.14); }

  /* Table — snug density */
  .net-table { @apply w-full text-[12px] border-collapse; }
  .net-table thead th {
    @apply text-left text-[10px] text-label-2 font-medium uppercase px-3 py-[10px];
    letter-spacing: 0.04em;
    border-bottom: 0.5px solid theme('colors.hairline');
    white-space: nowrap;
  }
  .net-table thead th.r { @apply text-right; }
  .net-table tbody tr {
    transition: background-color 120ms;
    border-bottom: 0.5px solid theme('colors.hairline');
  }
  .net-table tbody tr:last-child { border-bottom: 0; }
  .net-table tbody tr:hover { background: rgba(255,255,255,0.02); }
  .net-table tbody td { @apply px-3 py-2; }
  .net-table tbody td.r { @apply text-right; }

  /* Brand mark */
  .brand-mark {
    @apply w-6 h-6 rounded-md grid place-items-center text-white text-[12px] font-bold;
    background: linear-gradient(135deg, #5E5CE6 0%, #BF5AF2 100%);
    box-shadow: 0 0 14px rgba(94,92,230,0.35), inset 0 0 0 0.5px rgba(255,255,255,0.2);
  }

  /* Back-compat: keep existing classes alive until templates are restyled */
  .btn {
    @apply inline-flex items-center px-3 py-2 rounded-md bg-indigo text-white text-sm font-medium cursor-pointer;
    transition: background-color 200ms;
  }
  .btn:hover { @apply bg-violet; }
  .btn-ghost {
    @apply inline-flex items-center px-3 py-2 rounded-md bg-surface text-text text-sm cursor-pointer;
    border: 0.5px solid theme('colors.hairline');
  }
  .btn-ghost:hover { @apply bg-surface-2; }
  .kpi-card { @apply kpi; }
  .row-hover:hover { background: rgba(255,255,255,0.02); }
  .badge-confirmed { @apply chip-confirm; }
  .badge-probable  { @apply chip-probable; }
  .badge-unclear   { @apply chip-unclear; }
}
```

- [ ] **Step 2: Rebuild CSS**

```bash
make build-css
```

Expected: succeeds. The compiled `app.css` should grow to roughly 25–40 KB. Tail it for sanity:

```bash
wc -l src/net_alpha/web/static/app.css
```

- [ ] **Step 3: Run existing tests to confirm nothing broke**

```bash
uv run pytest tests/web/ -x -q
```

Expected: all green. (We've only changed CSS source; route HTML still has its old class names, all of which are handled by back-compat aliases.)

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/static/app.src.css src/net_alpha/web/static/app.css
git commit -m "feat(web): Apple-dark base CSS — fonts, type scale, components, back-compat aliases"
```

---

### Task A5: Restyle base.html — fonts, ApexCharts, vibrancy topbar

**Files:**
- Modify: `src/net_alpha/web/templates/base.html`

- [ ] **Step 1: Replace base.html with the restyled version**

Replace the file with:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=1024">
  <title>{% block title %}net-alpha{% endblock %}</title>
  <link rel="stylesheet" href="/static/app.css">
  <link rel="stylesheet" href="/static/vendor/apexcharts/apexcharts.min.css">
  <script src="/static/htmx.min.js" defer></script>
  <script src="/static/alpine.min.js" defer></script>
  <script src="/static/vendor/apexcharts/apexcharts.min.js" defer></script>
  <script src="/static/charts.js" defer></script>
</head>
<body class="min-h-screen flex flex-col bg-bg text-text">
  <header class="topbar">
    <div class="flex items-center gap-6">
      <a href="/" class="flex items-center gap-2 no-underline text-text">
        <span class="brand-mark">α</span>
        <span class="font-semibold tracking-tight text-[14px]">net-alpha</span>
      </a>
      <nav class="flex gap-1">
        <a href="/" class="nav-link{% if active_page == 'portfolio' %} active{% endif %}">Portfolio</a>
        <a href="/calendar" class="nav-link{% if active_page == 'calendar' %} active{% endif %}">Calendar</a>
        <a href="/imports" class="nav-link{% if active_page == 'imports' %} active{% endif %}">Imports</a>
        <a href="/sim" class="nav-link{% if active_page == 'sim' %} active{% endif %}">Sim</a>
        <a href="/detail" class="nav-link{% if active_page == 'detail' %} active{% endif %}">Detail</a>
      </nav>
    </div>
    <div class="flex gap-2 items-center">
      {% block topbar_right %}{% endblock %}
    </div>
  </header>

  <main class="flex-1 max-w-[1280px] w-full mx-auto px-5 py-5">
    {% block content %}{% endblock %}
  </main>

  <footer class="py-3 border-t" style="border-color: rgba(255,255,255,0.06);">
    <div class="max-w-[1280px] mx-auto px-5 text-[11px] text-label-3">
      {{ disclaimer }}
    </div>
    {% if price_disclosure %}
      <div class="text-[11px] text-label-3 text-center mt-1 opacity-70">{{ price_disclosure }}</div>
    {% endif %}
  </footer>
</body>
</html>
```

The `active_page` context variable is new — page templates may or may not pass it (it's optional; nav links just don't get `.active` if missing). The existing route handlers will be updated in later tasks to pass it.

- [ ] **Step 2: Smoke-test that the home page still loads**

```bash
uv run pytest tests/web/test_portfolio_routes.py::test_root_renders_portfolio_when_no_imports -v
```

Expected: passes (the empty-state path doesn't depend on KPIs or the table).

- [ ] **Step 3: Run full web test suite**

```bash
uv run pytest tests/web/ -x -q
```

Expected: all pass. If any test asserts substring `font-mono font-bold text-primary text-lg` (the old brand link) it'll fail — update the assertion to `net-alpha`.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/templates/base.html
git commit -m "feat(web): restyle base.html — vibrancy topbar, Inter/JetBrainsMono, ApexCharts include"
```

---

### Task A6: Combined hero KPI cards

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`

- [ ] **Step 1: Inspect the existing partial to understand the data shape**

```bash
sed -n '1,80p' src/net_alpha/web/templates/_portfolio_kpis.html
```

Confirm: the template receives a `kpis` object whose fields are `period_label`, `period_realized`, `period_unrealized`, `lifetime_realized`, `lifetime_unrealized`, `open_position_value`, `lifetime_net_pl`, `missing_symbols` (matching `KpiSet` in `portfolio/models.py`).

- [ ] **Step 2: Rewrite the partial**

Replace the file with:

```html
{% set partial = kpis.missing_symbols and (kpis.open_position_value is not none) %}
{% set period_label = kpis.period_label or 'Period' %}

<div class="grid grid-cols-12 gap-[10px]">

  {# --- Realized hero (combined YTD + Lifetime) --- #}
  <div class="kpi kpi-hero col-span-4">
    <div class="label-uc">Realized P/L</div>
    <div class="grid grid-cols-2 gap-3 mt-2 items-end">
      <div>
        <div class="text-[10px] uppercase font-medium text-label-3" style="letter-spacing:0.04em;">{{ period_label }}</div>
        <div class="num text-[22px] font-bold mt-[2px] {% if kpis.period_realized < 0 %}text-neg{% else %}text-pos{% endif %}">
          {% if kpis.period_realized < 0 %}−{% else %}+{% endif %}${{ "%.2f"|format(kpis.period_realized|float|abs) }}
        </div>
      </div>
      <div class="border-l pl-3" style="border-color: rgba(255,255,255,0.08);">
        <div class="text-[10px] uppercase font-medium text-label-3" style="letter-spacing:0.04em;">Lifetime</div>
        <div class="num text-[22px] font-bold mt-[2px] {% if kpis.lifetime_realized < 0 %}text-neg{% else %}text-pos{% endif %}">
          {% if kpis.lifetime_realized < 0 %}−{% else %}+{% endif %}${{ "%.2f"|format(kpis.lifetime_realized|float|abs) }}
        </div>
      </div>
    </div>
  </div>

  {# --- Unrealized hero (combined YTD + Lifetime) --- #}
  <div class="kpi col-span-4">
    <div class="label-uc">Unrealized P/L</div>
    <div class="grid grid-cols-2 gap-3 mt-2 items-end">
      <div>
        <div class="text-[10px] uppercase font-medium text-label-3" style="letter-spacing:0.04em;">{{ period_label }}</div>
        <div class="num text-[22px] font-bold mt-[2px]">
          {% if kpis.period_unrealized is none %}
            <span class="text-label-3">—</span>
          {% elif kpis.period_unrealized < 0 %}
            <span class="text-neg">−${{ "%.2f"|format(kpis.period_unrealized|float|abs) }}</span>
          {% else %}
            <span class="text-pos">+${{ "%.2f"|format(kpis.period_unrealized|float) }}</span>
          {% endif %}
        </div>
      </div>
      <div class="border-l pl-3" style="border-color: rgba(255,255,255,0.08);">
        <div class="text-[10px] uppercase font-medium text-label-3" style="letter-spacing:0.04em;">Lifetime</div>
        <div class="num text-[22px] font-bold mt-[2px]">
          {% if kpis.lifetime_unrealized is none %}
            <span class="text-label-3">—</span>
          {% elif kpis.lifetime_unrealized < 0 %}
            <span class="text-neg">−${{ "%.2f"|format(kpis.lifetime_unrealized|float|abs) }}</span>
          {% else %}
            <span class="text-pos">+${{ "%.2f"|format(kpis.lifetime_unrealized|float) }}</span>
          {% endif %}
        </div>
      </div>
    </div>
  </div>

  {# --- Open Position $ (mini) --- #}
  <div class="kpi col-span-2">
    <div class="label-uc">Open position $</div>
    <div class="num text-[22px] font-bold mt-2">
      {% if kpis.open_position_value is none %}
        <span class="text-label-3">—</span>
      {% else %}
        ${{ "%.2f"|format(kpis.open_position_value|float) }}
      {% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">
      {% if kpis.missing_symbols %}{{ kpis.missing_symbols|length }} unpriced{% else %}all priced{% endif %}
    </div>
  </div>

  {# --- Wash impact (mini) --- #}
  <div class="kpi col-span-2">
    <div class="label-uc">Wash impact</div>
    <div class="num text-[22px] font-bold mt-2 {% if kpis.lifetime_net_pl is none %}text-label-3{% else %}text-warn{% endif %}">
      {% if kpis.lifetime_net_pl is none %}
        —
      {% else %}
        {# Reuses lifetime_net_pl as a stand-in placeholder until the dedicated wash_impact KPI is wired into KpiSet — see plan note. #}
        −$0.00
      {% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">period view</div>
  </div>

</div>

{% if snapshot is defined and snapshot.degraded %}
  <div class="text-[11px] text-warn mt-2">Showing stale prices (provider unavailable).</div>
{% endif %}
{% if kpis.missing_symbols %}
  <div class="text-[11px] text-warn mt-2">
    {% if kpis.open_position_value is none %}
      No quotes available.
    {% else %}
      Partial sum — {{ kpis.missing_symbols|length }} symbol{% if kpis.missing_symbols|length != 1 %}s{% endif %} unpriced:
      <span class="num">{{ kpis.missing_symbols|join(', ') }}</span>
    {% endif %}
  </div>
{% endif %}
```

The `Wash impact` mini card currently reuses `lifetime_net_pl` as a placeholder — the actual wash impact value comes from a separate `WashImpact` aggregation that the route already passes via `wash_impact`. Wire that up in the next step.

- [ ] **Step 3: Update the route to pass wash impact data to the KPI fragment**

Open `src/net_alpha/web/routes/portfolio.py`. Find the route `@router.get("/portfolio/kpis", ...)` (search for `_portfolio_kpis.html`). The handler currently calls `compute_kpis(...)` and renders the template with `{"kpis": kpis, "snapshot": snap}`.

Add a `compute_wash_impact` call right after `compute_kpis`, using the same `period` and `account` arguments that were used for `compute_kpis`. Pass its result into the context dict. Concretely:

```python
# After existing compute_kpis(...) call
wi = compute_wash_impact(repo=repo, period=period_tuple, account=account)
return request.app.state.templates.TemplateResponse(
    request,
    "_portfolio_kpis.html",
    {
        "kpis": kpis,
        "snapshot": snap,
        "wash_impact_total": wi.disallowed_total,
        "wash_violations": wi.violation_count,
    },
)
```

`compute_wash_impact` is already imported at the top of `routes/portfolio.py`. `period_tuple` is the same `(start_year, end_year_exclusive) | None` tuple already passed to `compute_kpis` — reuse the local variable.

In `_portfolio_kpis.html` Wash impact card body, replace the `−$0.00` placeholder with:

```html
{% if wash_impact_total is defined and wash_impact_total %}
  <span class="text-warn">−${{ "%.2f"|format(wash_impact_total|float|abs) }}</span>
{% else %}
  <span class="text-label-3">$0.00</span>
{% endif %}
```

And the sub-line:

```html
<div class="text-[11px] text-label-3 mt-1">
  {% if wash_violations is defined and wash_violations %}{{ wash_violations }} violation{% if wash_violations != 1 %}s{% endif %}{% else %}no violations{% endif %}
</div>
```

- [ ] **Step 4: Run KPI fragment tests**

```bash
uv run pytest tests/web/test_portfolio_routes.py::test_kpis_fragment_renders_with_no_data -v
```

Expected: passes. The template still renders text "Realized" and "Unrealized" (just inside hero cards now), and the existing assertions are loose substring checks.

- [ ] **Step 5: Run full web test suite to catch any tightly-asserted KPI text**

```bash
uv run pytest tests/web/ -x -q
```

Expected: all pass. If a test asserts `"YTD Realized"` (the old card title) it'll fail; update to `"Realized P/L"` per the new layout.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_kpis.html src/net_alpha/web/routes/portfolio.py
git commit -m "feat(web): combined hero KPI cards (Realized/Unrealized) + mini Open\$/Wash"
```

---

## Phase B — Allocation, Wash-watch, Equity curve

### Task B1: Create `portfolio/allocation.py` helper (TDD)

**Files:**
- Create: `tests/portfolio/test_allocation.py`
- Create: `src/net_alpha/portfolio/allocation.py`
- Modify: `src/net_alpha/portfolio/models.py`

- [ ] **Step 1: Add the view models to `portfolio/models.py`**

Append:

```python
@dataclass(frozen=True)
class AllocationSlice:
    """One ranked holding for the donut + leaderboard module."""

    rank: int  # 1-based; 0 reserved for "rest" aggregate
    symbol: str  # "OTHER" for the rest aggregate
    market_value: Decimal
    pct: Decimal  # 0..100, of total market value
    is_rest: bool


@dataclass(frozen=True)
class AllocationView:
    total_market_value: Decimal
    symbol_count: int
    slices: tuple[AllocationSlice, ...]  # length = top_n + (1 if rest else 0)
    top1_pct: Decimal
    top3_pct: Decimal
    top5_pct: Decimal
    top10_pct: Decimal
```

- [ ] **Step 2: Write the failing test**

Create `tests/portfolio/test_allocation.py`:

```python
from decimal import Decimal

from net_alpha.portfolio.allocation import build_allocation
from net_alpha.portfolio.models import PositionRow


def _row(symbol: str, value: float | None) -> PositionRow:
    return PositionRow(
        symbol=symbol,
        accounts=("A",),
        qty=Decimal("1"),
        market_value=Decimal(str(value)) if value is not None else None,
        open_cost=Decimal("0"),
        avg_basis=Decimal("0"),
        cash_sunk_per_share=Decimal("0"),
        realized_pl=Decimal("0"),
        unrealized_pl=None,
    )


def test_empty_input_yields_empty_view():
    view = build_allocation(positions=[], top_n=10)
    assert view.total_market_value == Decimal("0")
    assert view.symbol_count == 0
    assert view.slices == ()
    assert view.top1_pct == Decimal("0")


def test_top_n_smaller_than_positions_aggregates_rest():
    rows = [_row(s, v) for s, v in [
        ("AAA", 100), ("BBB", 60), ("CCC", 30), ("DDD", 6), ("EEE", 4),
    ]]
    view = build_allocation(positions=rows, top_n=3)

    assert view.symbol_count == 5
    assert view.total_market_value == Decimal("200")

    # Slices: AAA, BBB, CCC, OTHER
    assert len(view.slices) == 4
    syms = [s.symbol for s in view.slices]
    assert syms == ["AAA", "BBB", "CCC", "OTHER"]

    aaa = view.slices[0]
    assert aaa.rank == 1
    assert aaa.market_value == Decimal("100")
    assert aaa.pct == Decimal("50.00")
    assert not aaa.is_rest

    rest = view.slices[-1]
    assert rest.is_rest
    assert rest.market_value == Decimal("10")  # 6 + 4
    assert rest.pct == Decimal("5.00")


def test_top_n_equal_to_positions_no_rest_slice():
    rows = [_row("X", 70), _row("Y", 30)]
    view = build_allocation(positions=rows, top_n=10)
    assert len(view.slices) == 2
    assert all(not s.is_rest for s in view.slices)


def test_concentration_stats():
    rows = [_row(f"S{i}", v) for i, v in enumerate([40, 25, 15, 10, 5, 3, 2])]
    view = build_allocation(positions=rows, top_n=10)
    assert view.top1_pct == Decimal("40.00")
    assert view.top3_pct == Decimal("80.00")
    assert view.top5_pct == Decimal("95.00")
    # Only 7 positions, so top10 = 100
    assert view.top10_pct == Decimal("100.00")


def test_unpriced_positions_are_excluded_from_total():
    rows = [_row("PRICED", 100), _row("UNPRICED", None)]
    view = build_allocation(positions=rows, top_n=10)
    assert view.total_market_value == Decimal("100")
    assert view.symbol_count == 1  # only priced positions count toward allocation
    assert len(view.slices) == 1
    assert view.slices[0].symbol == "PRICED"


def test_zero_total_yields_zero_pct_no_division_error():
    rows = [_row("Z", 0)]
    view = build_allocation(positions=rows, top_n=10)
    assert view.total_market_value == Decimal("0")
    assert view.slices == ()
```

- [ ] **Step 3: Run the test — verify fail**

```bash
uv run pytest tests/portfolio/test_allocation.py -v
```

Expected: ImportError — `build_allocation` doesn't exist yet.

- [ ] **Step 4: Implement `allocation.py`**

Create `src/net_alpha/portfolio/allocation.py`:

```python
"""Allocation view for the portfolio donut + leaderboard module.

Pure post-processing of an already-priced PositionRow list: ranks holdings by
market value, takes the top-N, aggregates the long tail into a synthetic
'OTHER' slice, and emits concentration stats.

Unpriced positions (market_value is None) are excluded from the allocation —
they have no contribution to a market-share computation by definition. They
still appear in the positions table, just not here.
"""

from __future__ import annotations

from collections.abc import Iterable
from decimal import Decimal

from net_alpha.portfolio.models import AllocationSlice, AllocationView, PositionRow


def build_allocation(*, positions: Iterable[PositionRow], top_n: int = 10) -> AllocationView:
    valued = [p for p in positions if p.market_value is not None and p.market_value > 0]
    valued.sort(key=lambda p: p.market_value or Decimal("0"), reverse=True)

    total = sum((p.market_value for p in valued), start=Decimal("0"))
    if total <= 0:
        return AllocationView(
            total_market_value=Decimal("0"),
            symbol_count=0,
            slices=(),
            top1_pct=Decimal("0"),
            top3_pct=Decimal("0"),
            top5_pct=Decimal("0"),
            top10_pct=Decimal("0"),
        )

    head = valued[:top_n]
    tail = valued[top_n:]

    slices: list[AllocationSlice] = []
    for i, pos in enumerate(head, start=1):
        pct = (pos.market_value / total * 100).quantize(Decimal("0.01"))
        slices.append(AllocationSlice(
            rank=i,
            symbol=pos.symbol,
            market_value=pos.market_value,
            pct=pct,
            is_rest=False,
        ))

    if tail:
        rest_value = sum((p.market_value for p in tail), start=Decimal("0"))
        rest_pct = (rest_value / total * 100).quantize(Decimal("0.01"))
        slices.append(AllocationSlice(
            rank=0,
            symbol="OTHER",
            market_value=rest_value,
            pct=rest_pct,
            is_rest=True,
        ))

    def _share(n: int) -> Decimal:
        s = sum((p.market_value for p in valued[:n]), start=Decimal("0"))
        return (s / total * 100).quantize(Decimal("0.01"))

    return AllocationView(
        total_market_value=total,
        symbol_count=len(valued),
        slices=tuple(slices),
        top1_pct=_share(1),
        top3_pct=_share(3),
        top5_pct=_share(5),
        top10_pct=_share(10),
    )
```

- [ ] **Step 5: Run tests — verify pass**

```bash
uv run pytest tests/portfolio/test_allocation.py -v
```

Expected: 6 passed.

- [ ] **Step 6: Run lint**

```bash
uv run ruff check src/net_alpha/portfolio/allocation.py tests/portfolio/test_allocation.py
uv run ruff format src/net_alpha/portfolio/allocation.py tests/portfolio/test_allocation.py
```

Expected: no errors.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/portfolio/allocation.py src/net_alpha/portfolio/models.py tests/portfolio/test_allocation.py
git commit -m "feat(portfolio): build_allocation — donut/leaderboard view + concentration stats"
```

---

### Task B2: Create `_portfolio_allocation.html` partial

**Files:**
- Create: `src/net_alpha/web/templates/_portfolio_allocation.html`

- [ ] **Step 1: Write the partial**

Create `src/net_alpha/web/templates/_portfolio_allocation.html`:

```html
{# Inputs: allocation: AllocationView from portfolio.allocation.build_allocation() #}
{% set rank_palette = [
  '#0A84FF', '#FFD60A', '#30D158', '#FF375F', '#5E5CE6',
  '#64D2FF', '#5AC8FA', '#BF5AF2', 'rgba(181,181,255,0.65)', 'rgba(255,255,255,0.40)'
] %}
{% set rest_color = 'rgba(255,255,255,0.14)' %}

{% if allocation.symbol_count == 0 %}
  <div class="text-label-3 text-[12px] py-4 text-center">
    No priced open positions in scope.
  </div>
{% else %}
  <div class="flex gap-5 items-center">
    {# Donut #}
    <div class="relative shrink-0">
      <svg viewBox="0 0 100 100" width="148" height="148"
           style="filter: drop-shadow(0 0 18px rgba(10,132,255,0.14));">
        <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="11"/>
        {% set ns = namespace(offset=0) %}
        {% set circumference = 251.327 %}
        {% for s in allocation.slices %}
          {% set seg_len = circumference * (s.pct|float) / 100.0 %}
          {% if s.is_rest %}
            {% set color = rest_color %}
          {% else %}
            {% set color = rank_palette[s.rank - 1] %}
          {% endif %}
          <circle cx="50" cy="50" r="40" fill="none" stroke="{{ color }}" stroke-width="11"
                  stroke-dasharray="{{ '%.3f'|format(seg_len) }} {{ '%.3f'|format(circumference) }}"
                  stroke-dashoffset="{{ '%.3f'|format(-ns.offset) }}"
                  transform="rotate(-90 50 50)"/>
          {% set ns.offset = ns.offset + seg_len %}
        {% endfor %}
      </svg>
      <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <div class="text-[10px] text-label-2 font-medium">Total</div>
        <div class="num text-[19px] font-bold tracking-tight mt-[2px]">
          ${{ "%.1f"|format(allocation.total_market_value|float / 1000) }}k
        </div>
        <div class="text-[10px] text-label-3 mt-[2px]">{{ allocation.symbol_count }} symbol{% if allocation.symbol_count != 1 %}s{% endif %}</div>
      </div>
    </div>

    {# Concentration stats #}
    <div class="flex-1 flex flex-col">
      <div class="flex justify-between py-[6px] text-[12px]" style="border-bottom: 0.5px solid rgba(255,255,255,0.08);">
        <span class="text-label-2">Top holding</span>
        <span class="text-text num font-medium">
          {% set top = allocation.slices[0] %}{{ top.symbol }} · {{ "%.1f"|format(top.pct|float) }}%
        </span>
      </div>
      <div class="flex justify-between py-[6px] text-[12px]" style="border-bottom: 0.5px solid rgba(255,255,255,0.08);">
        <span class="text-label-2">Top 3 share</span>
        <span class="text-text num font-medium">{{ "%.1f"|format(allocation.top3_pct|float) }}%</span>
      </div>
      <div class="flex justify-between py-[6px] text-[12px]" style="border-bottom: 0.5px solid rgba(255,255,255,0.08);">
        <span class="text-label-2">Top 5 share</span>
        <span class="text-text num font-medium">{{ "%.1f"|format(allocation.top5_pct|float) }}%</span>
      </div>
      <div class="flex justify-between py-[6px] text-[12px]">
        <span class="text-label-2">Top 10 share</span>
        <span class="text-text num font-medium">{{ "%.1f"|format(allocation.top10_pct|float) }}%</span>
      </div>
    </div>
  </div>

  {# Chip leaderboard #}
  <div class="mt-[14px]">
    <div class="label-uc mb-2">Top {{ allocation.slices|selectattr('is_rest','equalto',false)|list|length }} holdings</div>
    <div class="flex flex-wrap gap-x-[7px] gap-y-[5px]">
      {% for s in allocation.slices %}
        {% if s.is_rest %}
          <span class="inline-flex items-center gap-[6px] py-1 pl-1 pr-1 text-[11px] text-label-3">
            <span class="text-label-3">+{{ allocation.symbol_count - allocation.slices|rejectattr('is_rest')|list|length }} more</span>
            <span class="num">${{ "%.1f"|format(s.market_value|float / 1000) }}k</span>
            <span class="num">{{ "%.1f"|format(s.pct|float) }}%</span>
          </span>
        {% else %}
          {% set color = rank_palette[s.rank - 1] %}
          {% set glow = s.rank <= 6 %}
          <span class="inline-flex items-center gap-[7px] py-[4px] pl-2 pr-[10px] rounded-full text-[11px]"
                style="background: rgba(255,255,255,0.04); border: 0.5px solid rgba(255,255,255,0.08);">
            <span style="width:6px; height:6px; border-radius:50%; background:{{ color }};{% if glow %} box-shadow: 0 0 5px {{ color }};{% endif %}"></span>
            <span class="font-semibold tracking-tightish text-text">{{ s.symbol }}</span>
            <span class="num text-label-2">${{ "%.1f"|format(s.market_value|float / 1000) }}k</span>
            <span class="num font-semibold">{{ "%.1f"|format(s.pct|float) }}%</span>
          </span>
        {% endif %}
      {% endfor %}
    </div>
  </div>
{% endif %}
```

- [ ] **Step 2: Verify Jinja renders without errors**

The fragment needs a route to be testable end-to-end; that's Task B3. Skip rendering for now; the template syntax will be validated implicitly when a route loads it.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_allocation.html
git commit -m "feat(web): allocation partial — donut + concentration stats + ranked chips"
```

---

### Task B3: Replace `/portfolio/treemap` route with `/portfolio/allocation`

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `tests/web/test_allocation_route.py`

- [ ] **Step 1: Write the failing route test**

Create `tests/web/test_allocation_route.py`:

```python
from __future__ import annotations

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.web.app import create_app


def _client(tmp_path):
    return TestClient(create_app(Settings(data_dir=tmp_path)))


def test_allocation_fragment_empty(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/allocation")
    assert r.status_code == 200
    assert "No priced open positions" in r.text


def test_allocation_fragment_with_account_filter(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/allocation?account=Tax")
    assert r.status_code == 200


def test_old_treemap_route_returns_404(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/treemap")
    assert r.status_code == 404
```

- [ ] **Step 2: Run — expect failure**

```bash
uv run pytest tests/web/test_allocation_route.py -v
```

Expected: all three fail (route not registered).

- [ ] **Step 3: Update `routes/portfolio.py`**

In `src/net_alpha/web/routes/portfolio.py`:

1. Replace the import `from net_alpha.portfolio.treemap import build_treemap` with `from net_alpha.portfolio.allocation import build_allocation`.
2. Find the existing `@router.get("/portfolio/treemap")` handler. Rename the route to `/portfolio/allocation`, rename the handler function to `portfolio_allocation_fragment`, and replace the body to call `build_allocation` with the priced positions and render `_portfolio_allocation.html` with `allocation=...`.

Concretely, replace the treemap handler with:

```python
@router.get("/portfolio/allocation", response_class=HTMLResponse)
def portfolio_allocation_fragment(
    request: Request,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    positions = compute_open_positions(
        repo=repo,
        pricing=svc,
        period=None,
        account=account,
        group_options="merge",
    )
    allocation = build_allocation(positions=positions, top_n=10)
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_allocation.html",
        {"allocation": allocation},
    )
```

(Match the existing route's `compute_open_positions` call signature — copy from the treemap handler.)

- [ ] **Step 4: Run tests — verify pass**

```bash
uv run pytest tests/web/test_allocation_route.py -v
```

Expected: 3 passed.

- [ ] **Step 5: Confirm full web test suite still green**

```bash
uv run pytest tests/web/ -x -q
```

Expected: pass. The `tests/web/test_portfolio_routes.py::test_treemap_fragment_empty` test will fail because the route is gone — DELETE that single test from `test_portfolio_routes.py` (it's been replaced by `test_allocation_fragment_empty`).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py tests/web/test_allocation_route.py tests/web/test_portfolio_routes.py
git commit -m "feat(web): replace /portfolio/treemap route with /portfolio/allocation"
```

---

### Task B4: Wire allocation fragment into `portfolio.html`; remove treemap & calendar-ribbon

**Files:**
- Modify: `src/net_alpha/web/templates/portfolio.html`

- [ ] **Step 1: Replace `portfolio.html` with the new layout**

Replace the file with:

```html
{% extends "base.html" %}
{% set active_page = 'portfolio' %}
{% block title %}Portfolio · net-alpha{% endblock %}
{% block topbar_right %}
  {% if accounts %}<span class="pill">{{ accounts|length }} account{% if accounts|length != 1 %}s{% endif %}</span>{% endif %}
  <span class="pill">{{ selected_period|default('YTD')|upper }}</span>
{% endblock %}
{% block content %}
  <div class="flex items-end justify-between flex-wrap gap-3 mb-4">
    <div>
      <h1>Portfolio</h1>
      <div class="text-[13px] text-label-2 mt-[3px]">
        {% if selected_account %}{{ selected_account }}{% else %}All accounts{% endif %} ·
        {{ selected_period|default('YTD')|upper }}
      </div>
    </div>
    {% if imports %}{% include "_portfolio_toolbar.html" %}{% endif %}
  </div>

  {% if not imports %}
    {% include "_portfolio_empty_state.html" %}
  {% else %}
    <div id="portfolio-kpis"
         hx-get="/portfolio/kpis?period={{ selected_period }}&account={{ selected_account }}"
         hx-trigger="load" hx-swap="innerHTML"
         class="mb-4"></div>

    <div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1.55fr;">
      <div id="portfolio-equity" class="panel"
           hx-get="/portfolio/equity-curve?period={{ selected_period }}&account={{ selected_account }}"
           hx-trigger="load" hx-swap="innerHTML"></div>
      <div id="portfolio-allocation" class="panel"
           hx-get="/portfolio/allocation?account={{ selected_account }}"
           hx-trigger="load" hx-swap="innerHTML"></div>
    </div>

    <div id="portfolio-wash-watch" class="panel mb-4"
         hx-get="/portfolio/wash-watch?account={{ selected_account }}"
         hx-trigger="load" hx-swap="innerHTML"></div>

    <div id="portfolio-positions"
         hx-get="/portfolio/positions?period={{ selected_period }}&account={{ selected_account }}&group_options={{ group_options }}&show=open&page=1"
         hx-trigger="load" hx-swap="innerHTML"></div>
  {% endif %}
{% endblock %}
```

The `wash-impact` and `lot-aging` panels from the previous design were folded into the KPI strip's "Wash impact" mini and the LTCG-aware ticker page respectively — they're not separate dashboards anymore. The two old fragments stay live (other surfaces may use them) but the home page no longer pulls them.

- [ ] **Step 2: Run web tests**

```bash
uv run pytest tests/web/test_portfolio_routes.py -x -q
```

Expected: pass. Tests against `/portfolio/wash-impact` or `/portfolio/lot-aging` — if any test asserts the home page contains these IDs, update the assertion or remove it.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/portfolio.html
git commit -m "feat(web): portfolio.html — equity+allocation row, wash-watch panel, drop treemap include"
```

---

### Task B5: Delete the old treemap module + template + tests

**Files:**
- Delete: `src/net_alpha/portfolio/treemap.py`
- Delete: `src/net_alpha/web/templates/_portfolio_treemap.html`
- Delete: `tests/portfolio/test_treemap.py`
- Modify: `src/net_alpha/portfolio/models.py` (remove TreemapTile)

- [ ] **Step 1: Remove `TreemapTile` from `portfolio/models.py`**

Open `src/net_alpha/portfolio/models.py`, find the `TreemapTile` dataclass, delete it.

- [ ] **Step 2: Delete the files**

```bash
rm src/net_alpha/portfolio/treemap.py
rm src/net_alpha/web/templates/_portfolio_treemap.html
rm tests/portfolio/test_treemap.py
```

- [ ] **Step 3: Verify nothing else still imports treemap**

```bash
grep -rn "portfolio.treemap\|build_treemap\|TreemapTile\|_portfolio_treemap" src/ tests/
```

Expected: zero matches. If any remain, fix them (likely just unused imports).

- [ ] **Step 4: Run full test suite**

```bash
uv run pytest -x -q
```

Expected: green.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "chore: remove treemap module, template, tests, model"
```

---

### Task B6: Create `portfolio/wash_watch.py` helper (TDD)

**Files:**
- Create: `tests/portfolio/test_wash_watch.py`
- Create: `src/net_alpha/portfolio/wash_watch.py`
- Modify: `src/net_alpha/portfolio/models.py`

- [ ] **Step 1: Add the `LossCloseRow` dataclass to `portfolio/models.py`**

Append to `models.py`:

```python
@dataclass(frozen=True)
class LossCloseRow:
    """One symbol's recent loss close — input for the home-page wash-sale watch panel."""

    symbol: str
    account: str  # the account on the most recent loss close in window
    close_date: date
    days_since: int  # today - close_date, in days
    days_to_safe: int  # window_days - days_since, clamped to >= 0
    loss_amount: Decimal  # positive number, sum of |negative realized P/L| in window for this symbol
```

- [ ] **Step 2: Write the failing tests**

Create `tests/portfolio/test_wash_watch.py`:

```python
from __future__ import annotations

from datetime import date
from decimal import Decimal
from unittest.mock import MagicMock

import pytest

from net_alpha.models.domain import Trade
from net_alpha.portfolio.wash_watch import recent_loss_closes


def _sell(*, ticker: str, account: str, on: date, proceeds: float, basis: float) -> Trade:
    """Build a sell Trade for tests. Realized P/L = proceeds - basis."""
    return Trade(
        id=None,
        date=on,
        ticker=ticker,
        action="Sell",
        quantity=1,
        proceeds=proceeds,
        cost_basis=basis,
        account=account,
    )


def _repo(trades: list[Trade]) -> MagicMock:
    repo = MagicMock()
    repo.all_trades.return_value = trades
    return repo


def test_no_loss_closes_yields_empty():
    today = date(2026, 4, 26)
    repo = _repo([_sell(ticker="AAPL", account="A", on=date(2026, 4, 1), proceeds=200, basis=100)])  # gain
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    assert rows == []


def test_single_loss_in_window_returns_one_row():
    today = date(2026, 4, 26)
    repo = _repo([
        _sell(ticker="TSLA", account="Schwab", on=date(2026, 4, 18), proceeds=100, basis=712),
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    assert len(rows) == 1
    r = rows[0]
    assert r.symbol == "TSLA"
    assert r.account == "Schwab"
    assert r.close_date == date(2026, 4, 18)
    assert r.days_since == 8
    assert r.days_to_safe == 22
    assert r.loss_amount == Decimal("612")


def test_loss_outside_window_excluded():
    today = date(2026, 4, 26)
    repo = _repo([
        _sell(ticker="OLD", account="A", on=date(2026, 3, 26), proceeds=0, basis=100),  # exactly 31d ago
        _sell(ticker="OK", account="A", on=date(2026, 3, 27), proceeds=0, basis=50),    # 30d ago, in window
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    syms = [r.symbol for r in rows]
    assert "OLD" not in syms
    assert "OK" in syms


def test_multiple_losses_same_symbol_collapsed_to_most_recent_summed_loss():
    today = date(2026, 4, 26)
    repo = _repo([
        _sell(ticker="META", account="Schwab", on=date(2026, 4, 5), proceeds=100, basis=200),  # -100
        _sell(ticker="META", account="Fidelity", on=date(2026, 4, 11), proceeds=80, basis=260),  # -180
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    assert len(rows) == 1
    r = rows[0]
    assert r.symbol == "META"
    assert r.account == "Fidelity"  # account from the most recent close
    assert r.close_date == date(2026, 4, 11)
    assert r.loss_amount == Decimal("280")  # 100 + 180


def test_account_filter():
    today = date(2026, 4, 26)
    repo = _repo([
        _sell(ticker="X", account="Schwab",   on=date(2026, 4, 10), proceeds=0, basis=50),
        _sell(ticker="Y", account="Fidelity", on=date(2026, 4, 10), proceeds=0, basis=80),
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30, account="Schwab")
    assert [r.symbol for r in rows] == ["X"]


def test_sorted_by_close_date_desc():
    today = date(2026, 4, 26)
    repo = _repo([
        _sell(ticker="A", account="X", on=date(2026, 4, 2),  proceeds=0, basis=10),
        _sell(ticker="B", account="X", on=date(2026, 4, 20), proceeds=0, basis=10),
        _sell(ticker="C", account="X", on=date(2026, 4, 11), proceeds=0, basis=10),
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    assert [r.symbol for r in rows] == ["B", "C", "A"]


def test_days_to_safe_clamped_at_zero():
    today = date(2026, 4, 26)
    # Close exactly today (days_since=0, days_to_safe=window) is in window;
    # close yesterday (days_since=1) too. The clamp matters only if window_days
    # is short; verify boundary days_to_safe = 0 when at the edge.
    repo = _repo([
        _sell(ticker="EDGE", account="X", on=date(2026, 3, 27), proceeds=0, basis=100),  # 30d ago
    ])
    rows = recent_loss_closes(repo=repo, today=today, window_days=30)
    assert len(rows) == 1
    assert rows[0].days_to_safe == 0
```

- [ ] **Step 3: Run — verify fail**

```bash
uv run pytest tests/portfolio/test_wash_watch.py -v
```

Expected: ImportError.

- [ ] **Step 4: Implement `wash_watch.py`**

Create `src/net_alpha/portfolio/wash_watch.py`:

```python
"""Recent-loss-close aggregation for the home-page wash-sale watch panel.

Surfaces sell trades with negative realized P/L closed in the last N days,
collapsed to one row per symbol (most recent close, summed loss). The UI uses
this to remind the user "don't buy these back yet — wash sale window still
open."

Pure function; no DB/IO of its own. The repo dependency is a duck-typed object
that exposes `.all_trades()` returning an iterable of Trade.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from datetime import date
from decimal import Decimal
from typing import Any, Protocol

from net_alpha.portfolio.models import LossCloseRow


class _RepoLike(Protocol):
    def all_trades(self) -> Iterable[Any]: ...


def recent_loss_closes(
    *,
    repo: _RepoLike,
    today: date,
    window_days: int = 30,
    account: str | None = None,
) -> list[LossCloseRow]:
    """Sells with realized P/L < 0 whose close_date is in [today - window_days, today].

    Grouped by symbol — if a symbol has multiple loss closes in window, the row
    uses the most recent date and account, and the loss_amount is the sum of
    |negative realized P/L| across all loss closes for that symbol in window.

    `days_to_safe = max(0, window_days - days_since)`.

    Returns rows sorted by close_date desc.
    """
    earliest = date.fromordinal(today.toordinal() - window_days)

    # Filter: sells with negative realized P/L in window
    by_symbol: dict[str, list[tuple[date, str, Decimal]]] = defaultdict(list)
    for t in repo.all_trades():
        if t.action.lower() != "sell":
            continue
        if t.date < earliest or t.date > today:
            continue
        proceeds = Decimal(str(t.proceeds or 0))
        basis = Decimal(str(t.cost_basis or 0))
        pl = proceeds - basis
        if pl >= 0:
            continue
        if account is not None and t.account != account:
            continue
        by_symbol[t.ticker].append((t.date, t.account, -pl))  # store loss as positive

    rows: list[LossCloseRow] = []
    for symbol, entries in by_symbol.items():
        # Most-recent close drives the row's date and account.
        entries.sort(key=lambda e: e[0], reverse=True)
        most_recent_date, most_recent_account, _ = entries[0]
        loss_total = sum((loss for _, _, loss in entries), start=Decimal("0"))
        days_since = (today - most_recent_date).days
        days_to_safe = max(0, window_days - days_since)
        rows.append(LossCloseRow(
            symbol=symbol,
            account=most_recent_account,
            close_date=most_recent_date,
            days_since=days_since,
            days_to_safe=days_to_safe,
            loss_amount=loss_total,
        ))

    rows.sort(key=lambda r: r.close_date, reverse=True)
    return rows
```

- [ ] **Step 5: Run tests — verify pass**

```bash
uv run pytest tests/portfolio/test_wash_watch.py -v
```

Expected: 7 passed. If a test fails because `Trade` doesn't accept `account=` kwarg or has a different signature, open `src/net_alpha/models/domain.py`, locate the `Trade` model, and adapt the `_sell` helper in the test to match (use the actual field names; do not rename Trade fields).

- [ ] **Step 6: Lint**

```bash
uv run ruff check src/net_alpha/portfolio/wash_watch.py tests/portfolio/test_wash_watch.py
uv run ruff format src/net_alpha/portfolio/wash_watch.py tests/portfolio/test_wash_watch.py
```

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/portfolio/wash_watch.py src/net_alpha/portfolio/models.py tests/portfolio/test_wash_watch.py
git commit -m "feat(portfolio): recent_loss_closes — wash-sale watch aggregation"
```

---

### Task B7: Create `_portfolio_wash_watch.html` partial

**Files:**
- Create: `src/net_alpha/web/templates/_portfolio_wash_watch.html`

- [ ] **Step 1: Write the partial**

Create the file:

```html
{# Inputs:
    rows: list[LossCloseRow]
    window_days: int (default 30) #}
{% set window = window_days|default(30) %}

<div class="panel-head">
  <h4>Wash-sale watch</h4>
  <span class="meta">
    Loss closes in the last {{ window }} days · don't buy back ·
    {{ rows|length }} symbol{% if rows|length != 1 %}s{% endif %}
  </span>
</div>

{% if not rows %}
  <div class="text-label-2 text-[13px] py-3">All clear · no loss closes in the last {{ window }} days.</div>
{% else %}
  <div class="flex flex-col">
    {% for r in rows %}
      {% if r.days_to_safe >= 21 %}{% set cd_class = 'text-neg' %}
      {% elif r.days_to_safe >= 7 %}{% set cd_class = 'text-warn' %}
      {% else %}{% set cd_class = 'text-pos' %}{% endif %}
      {% set fill_pct = (r.days_since / window * 100)|round(0, 'common') %}
      <div class="grid items-center gap-[14px] py-[9px] text-[13px]"
           style="grid-template-columns: 90px 90px 1fr 110px; border-bottom: 0.5px solid rgba(255,255,255,0.08);">
        <div class="flex items-center gap-2 font-semibold tracking-tightish">
          <span style="width:6px; height:6px; border-radius:50%; background:#FF453A; box-shadow: 0 0 6px #FF453A;"></span>
          {{ r.symbol }}
        </div>
        <div class="num text-neg text-[12px] font-medium">−${{ "%.2f"|format(r.loss_amount|float) }}</div>
        <div class="flex items-center gap-[10px]">
          <span class="text-[11px] text-label-2 num min-w-[80px]">closed {{ r.days_since }}d ago</span>
          <div class="flex-1 h-[5px] rounded-full overflow-hidden" style="background: rgba(255,255,255,0.06);">
            <div style="width: {{ fill_pct }}%; height: 100%;
                        background: linear-gradient(90deg, #FF453A 0%, #FF9F0A 70%, #30D158 100%);
                        border-radius: 999px;"></div>
          </div>
        </div>
        <div class="text-right num text-[13px] font-semibold {{ cd_class }}">
          {{ r.days_to_safe }}d <small class="text-[10px] text-label-3 font-normal ml-1">to safe</small>
        </div>
      </div>
    {% endfor %}
  </div>
{% endif %}
```

- [ ] **Step 2: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_wash_watch.html
git commit -m "feat(web): wash-watch partial — countdown rows with safe-to-buy-back gradient bar"
```

---

### Task B8: Add `/portfolio/wash-watch` route

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `tests/web/test_wash_watch_route.py`

- [ ] **Step 1: Write the failing route tests**

Create `tests/web/test_wash_watch_route.py`:

```python
from __future__ import annotations

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.web.app import create_app


def _client(tmp_path):
    return TestClient(create_app(Settings(data_dir=tmp_path)))


def test_wash_watch_fragment_empty(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/wash-watch")
    assert r.status_code == 200
    assert "All clear" in r.text or "no loss closes" in r.text


def test_wash_watch_fragment_with_account_filter(tmp_path):
    client = _client(tmp_path)
    r = client.get("/portfolio/wash-watch?account=Tax")
    assert r.status_code == 200
```

- [ ] **Step 2: Run — expect failure**

```bash
uv run pytest tests/web/test_wash_watch_route.py -v
```

Expected: 404 from FastAPI on the unregistered route.

- [ ] **Step 3: Add the route handler**

In `src/net_alpha/web/routes/portfolio.py`:

1. Add the import: `from net_alpha.portfolio.wash_watch import recent_loss_closes`.
2. Append the handler:

```python
@router.get("/portfolio/wash-watch", response_class=HTMLResponse)
def portfolio_wash_watch_fragment(
    request: Request,
    account: str | None = None,
    window_days: int = 30,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    rows = recent_loss_closes(
        repo=repo,
        today=date.today(),
        window_days=window_days,
        account=account,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_wash_watch.html",
        {"rows": rows, "window_days": window_days},
    )
```

- [ ] **Step 4: Run tests — verify pass**

```bash
uv run pytest tests/web/test_wash_watch_route.py -v
```

Expected: 2 passed.

- [ ] **Step 5: Run full suite**

```bash
uv run pytest -x -q
```

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py tests/web/test_wash_watch_route.py
git commit -m "feat(web): /portfolio/wash-watch fragment route"
```

---

### Task B9: Create `static/charts.js` shared ApexCharts theme

**Files:**
- Create: `src/net_alpha/web/static/charts.js`

- [ ] **Step 1: Write the theme module**

Create `src/net_alpha/web/static/charts.js`:

```javascript
/**
 * net-alpha shared ApexCharts theme + helpers.
 * Loaded by base.html (as a non-module script). Sets a global namespace.
 */
(function () {
  const colors = {
    pos:      "#30D158",
    neg:      "#FF453A",
    indigo:   "#5E5CE6",
    violet:   "#BF5AF2",
    info:     "#64D2FF",
    label2:   "rgba(235,235,245,0.6)",
    label3:   "rgba(235,235,245,0.35)",
    hairline: "rgba(255,255,255,0.08)",
    surface:  "#1C1C1E",
    bg:       "#000000",
  };

  // Default options shared across all dark charts.
  const defaults = {
    chart: {
      background: "transparent",
      foreColor: colors.label2,
      fontFamily: "Inter, -apple-system, system-ui, sans-serif",
      toolbar: { show: false },
      zoom: { enabled: false },
      animations: {
        enabled: true,
        easing: "easeinout",
        speed: 800,
        animateGradually: { enabled: false },
        dynamicAnimation: { enabled: false }, // no jitter on filter swap
      },
    },
    theme: { mode: "dark" },
    grid: {
      borderColor: colors.hairline,
      strokeDashArray: 2,
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } },
      padding: { top: 8, right: 8, bottom: 4, left: 8 },
    },
    xaxis: {
      labels: {
        style: { colors: colors.label3, fontSize: "10px", fontFamily: "JetBrains Mono, ui-monospace, monospace" },
      },
      axisBorder: { color: colors.hairline },
      axisTicks: { color: colors.hairline },
    },
    yaxis: {
      labels: {
        style: { colors: colors.label3, fontSize: "10px", fontFamily: "JetBrains Mono, ui-monospace, monospace" },
      },
    },
    tooltip: {
      theme: "dark",
      style: { fontSize: "12px", fontFamily: "Inter, sans-serif" },
    },
    dataLabels: { enabled: false },
    legend: {
      labels: { colors: colors.label2 },
      fontSize: "12px",
      fontFamily: "Inter, sans-serif",
    },
    stroke: { curve: "smooth", width: 2, lineCap: "round" },
  };

  // Helper: deep-merge two plain-object options trees.
  function merge(a, b) {
    const out = Object.assign({}, a);
    for (const k in b) {
      if (b[k] && typeof b[k] === "object" && !Array.isArray(b[k])) {
        out[k] = merge(a[k] || {}, b[k]);
      } else {
        out[k] = b[k];
      }
    }
    return out;
  }

  window.netAlphaChartTheme = { colors, defaults, merge };
})();
```

- [ ] **Step 2: Commit**

```bash
git add src/net_alpha/web/static/charts.js
git commit -m "feat(web): shared ApexCharts dark theme + merge helper at /static/charts.js"
```

---

### Task B10: Convert equity curve to ApexCharts

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_equity_curve.html`

- [ ] **Step 1: Replace the partial**

Replace `_portfolio_equity_curve.html` entirely with:

```html
{# Inputs: points: list[EquityPoint] (one row per realized event + Jan-1 zero seed),
           year: int #}

<div class="panel-head">
  <h4>Equity curve</h4>
  <span class="meta">Realized cumulative · {{ year }}</span>
</div>

{% if points|length <= 1 %}
  <div class="text-label-2 text-[13px] py-4">No realized activity in {{ year }}.</div>
{% else %}
  {% set unrealized_today = points[-1].unrealized %}
  <div id="equity-chart-{{ year }}" style="height: 218px;"></div>

  <script>
  (function () {
    const opts = window.netAlphaChartTheme.merge(window.netAlphaChartTheme.defaults, {
      chart: { type: "area", height: 218 },
      colors: [window.netAlphaChartTheme.colors.pos],
      stroke: { width: 2, curve: "smooth", lineCap: "round" },
      fill: {
        type: "gradient",
        gradient: { shade: "dark", type: "vertical", opacityFrom: 0.30, opacityTo: 0, stops: [0, 100] },
      },
      xaxis: {
        type: "datetime",
        labels: { format: "MMM" },
      },
      yaxis: {
        labels: {
          formatter: (v) => {
            const n = Math.round(v);
            const sign = n >= 0 ? "+" : "−";
            const abs = Math.abs(n);
            if (abs >= 1000) return sign + "$" + (abs / 1000).toFixed(0) + "k";
            return sign + "$" + abs;
          },
        },
      },
      tooltip: {
        x: { format: "yyyy-MM-dd" },
        y: { formatter: (v) => "$" + v.toLocaleString(undefined, { maximumFractionDigits: 0 }) },
      },
      series: [{
        name: "Realized cumulative",
        data: [
          {% for p in points %}
            { x: "{{ p.on.isoformat() }}", y: {{ p.cumulative_realized|float }} }{% if not loop.last %},{% endif %}
          {% endfor %}
        ],
      }],
      annotations: {
        {% if unrealized_today is not none %}
        points: [{
          x: new Date("{{ points[-1].on.isoformat() }}").getTime(),
          y: {{ (points[-1].cumulative_realized|float + unrealized_today|float) }},
          marker: {
            size: 4,
            fillColor: window.netAlphaChartTheme.colors.violet,
            strokeColor: window.netAlphaChartTheme.colors.violet,
            strokeWidth: 0,
          },
          label: {
            text: "+ unrealized today",
            offsetY: -6,
            style: {
              color: "#fff",
              background: window.netAlphaChartTheme.colors.violet,
              fontSize: "10px",
              fontFamily: "Inter, sans-serif",
            },
          },
        }],
        {% endif %}
      },
    });

    function render() {
      const el = document.querySelector("#equity-chart-{{ year }}");
      if (!el) return;
      // Clear any prior rendered chart instance (HTMX swap re-runs this script).
      el.innerHTML = "";
      const chart = new ApexCharts(el, opts);
      chart.render();
    }

    if (window.ApexCharts) {
      render();
    } else {
      // ApexCharts script is deferred; wait for it.
      const iv = setInterval(() => {
        if (window.ApexCharts) { clearInterval(iv); render(); }
      }, 50);
    }
  })();
  </script>
{% endif %}
```

- [ ] **Step 2: Smoke test the route**

```bash
uv run pytest tests/web/test_portfolio_routes.py -k equity -v
```

Expected: pass — the route still returns 200 and the rendered HTML contains the year and "Realized cumulative" string.

If a test asserts SVG-specific markup (`<svg>`, `<polyline>`, etc.), update it to look for the new container ID `equity-chart-` or the literal `Realized cumulative` instead.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_equity_curve.html
git commit -m "feat(web): equity curve via ApexCharts area chart with violet '+ unrealized' marker"
```

---

### Task B11: Smoke-test the home page end-to-end

- [ ] **Step 1: Build CSS, run tests**

```bash
make build-css
uv run pytest -x -q
uv run ruff check .
```

Expected: all green. CSS rebuild is needed because earlier tasks may have referenced new utility classes that hadn't been compiled yet.

- [ ] **Step 2: Manually inspect the home page**

```bash
uv run net-alpha ui --no-browser --port 8765
```

In a separate terminal:

```bash
curl -s http://127.0.0.1:8765/ | head -120
```

Confirm: response is 200, body contains `class="topbar"`, `id="portfolio-allocation"`, `id="portfolio-wash-watch"`, no `id="portfolio-treemap"`. Kill the server with Ctrl-C.

- [ ] **Step 3: Open the home page in a browser** (manual)

Run `uv run net-alpha ui` (no flags), let it open the browser, visually inspect:
- Topbar has α brand mark + nav, vibrancy blur over a black canvas.
- KPI strip: Realized hero (with halo), Unrealized hero, Open$, Wash impact.
- Below: Equity curve (left, ApexCharts) + Allocation panel (right, donut + chips), allocation panel wider.
- Below: Wash-sale watch panel (empty state if no loss closes).
- Below: positions table (still old-styled — Phase C task will restyle).

If the page renders blank or with errors, open browser devtools console — almost certainly an ApexCharts script-load issue. Check that `/static/vendor/apexcharts/apexcharts.min.js` returns 200.

- [ ] **Step 4: Commit (if CSS rebuilt)**

```bash
git add src/net_alpha/web/static/app.css
git commit -m "chore: rebuild app.css after Phase B" || echo "no css changes"
```

---

## Phase C — Tables, Calendar, remaining pages

### Task C1: Restyle positions table

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_table.html`

- [ ] **Step 1: Restyle the table**

Open `_portfolio_table.html`. Keep all 9 columns. Apply these changes:

1. Replace `<table class="w-full text-sm bg-white rounded-lg shadow-sm border border-slate-200">` with `<table class="net-table">`. (Wrap the table in `<div class="panel" style="padding:0;">…</div>` if not already.)
2. Replace `<thead class="text-left text-xs text-slate-500 uppercase border-b border-slate-200">` with `<thead>` (the `.net-table thead th` rule already covers styling).
3. Replace each `<th class="px-3 py-2 text-right" …>` with `<th class="r" …>` (the `.r` modifier adds text-right; the `.net-table thead th` rule applies padding).
4. For the body rows: replace `class="row-hover border-b border-slate-100 last:border-b-0 cursor-pointer"` with `class="cursor-pointer"`. The `.net-table tbody` styles cover hover, border, and last-row.
5. Replace each `<td class="px-3 py-2 font-mono text-right …">` with `<td class="r num …">`. Drop `font-mono` (the `.num` class applies it). Keep conditional color classes — but rename `text-confirmed` → `text-neg`, `text-emerald-600` → `text-pos`.
6. The Symbol cell: wrap in a flex container with a 20×20 ticker icon block:
   ```html
   <td class="num">
     <div class="flex items-center gap-2 font-semibold tracking-tightish">
       <span class="w-5 h-5 rounded-md bg-surface-3 grid place-items-center text-[9px] font-bold text-label-1 shrink-0">{{ r.symbol[0] }}</span>
       {{ r.symbol }}
       {% if r.qty == 0 %}<span class="ml-1 text-[10px] uppercase text-label-3">closed</span>{% endif %}
     </div>
   </td>
   ```
7. Accounts cell: change `text-xs text-slate-500` → `text-[11px] text-label-2`.
8. The "No positions" empty state: change `class="kpi-card text-slate-500 text-sm"` → `class="panel text-label-2 text-[13px]"`.

- [ ] **Step 2: Run portfolio web tests**

```bash
uv run pytest tests/web/test_portfolio_routes.py -x -q
```

Expected: pass. If a test asserts the literal class name `bg-white` or `border-slate-200`, update the assertion or remove it.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_table.html
git commit -m "feat(web): restyle positions table — snug, ticker icons, no status col"
```

---

### Task C2: Restyle portfolio toolbar + empty state

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_toolbar.html`
- Modify: `src/net_alpha/web/templates/_portfolio_empty_state.html`

- [ ] **Step 1: Restyle `_portfolio_toolbar.html`**

Open the file. Replace classes:
- `inline-flex rounded border border-slate-300 overflow-hidden` → `seg`
- Each `<button … class="px-3 py-1 ...{% if condition %}bg-primary text-white{% else %}bg-white text-slate-700 hover:bg-slate-50{% endif %}">…</button>` → use the `.seg-active` class on the active button, drop the bg-white/hover classes.
- `border border-slate-300 rounded px-2 py-1 text-xs bg-white` (select element) → `border-0 px-2 py-1 text-[12px] bg-surface text-text rounded-md`, plus inline `style="border:0.5px solid rgba(255,255,255,0.08);"`
- `text-xs text-slate-500` → `text-[11px] text-label-2`
- Pagination buttons: replace `class="px-2 py-1 text-xs rounded border border-slate-300 ..."` with classes derived from `.btn-ghost` (which is back-compat-aliased), plus `text-[11px]`.

- [ ] **Step 2: Restyle `_portfolio_empty_state.html`**

Inspect first:

```bash
sed -n '1,80p' src/net_alpha/web/templates/_portfolio_empty_state.html
```

Replace any references to `bg-white`, `border-slate-200`, `text-slate-500/600/700`, `text-emerald-600` etc. with the new tokens (`bg-surface`, `border-color: rgba(255,255,255,0.08)`, `text-label-2`, `text-pos`). Wrap the main empty-state block in `class="panel"` if it isn't already. The drop-zone CTA button should use the existing `.btn` class.

- [ ] **Step 3: Build CSS + smoke**

```bash
make build-css
uv run pytest tests/web/test_portfolio_routes.py -x -q
```

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_toolbar.html src/net_alpha/web/templates/_portfolio_empty_state.html src/net_alpha/web/static/app.css
git commit -m "feat(web): restyle portfolio toolbar segments + empty state"
```

---

### Task C3: Recolor calendar dual ribbon

**Files:**
- Modify: `src/net_alpha/web/templates/_calendar_pl_ribbon.html`
- Modify: `src/net_alpha/web/templates/_calendar_ribbon.html`
- Modify: `src/net_alpha/web/templates/calendar.html`
- Modify: `src/net_alpha/web/templates/_calendar_focus.html`
- Modify: `src/net_alpha/web/templates/_violation_card.html`

- [ ] **Step 1: Recolor `_calendar_ribbon.html`**

Open the file. Find the inline `style="… background-color: …"` for confidence dots:

- `'#DC2626'` (confirmed) → `'#FF453A'`
- `'#F59E0B'` (probable) → `'#FF9F0A'`
- `'#3B82F6'` (unclear) → `'#64D2FF'`

Add a glow to each dot via the inline style: append `box-shadow: 0 0 0 2.5px #2C2C2E, 0 0 12px currentColor;`. Change `class="kpi-card"` to `class="panel"`.

- [ ] **Step 2: Recolor `_calendar_pl_ribbon.html`**

Inspect first to see which colors it uses for gain/loss bars. Replace any green hex (e.g., `#16a34a`, `#10b981`) with `#30D158` and any red (e.g., `#dc2626`, `#f43f5e`) with `#FF453A`. Replace `bg-white` / `border-slate-*` shells with the new panel tokens.

- [ ] **Step 3: Restyle `calendar.html` chrome**

Replace any `class="kpi-card mb-4 …"` form wrappers with `class="panel mb-4 …"`. Replace `text-2xl mb-4` H1 with the bare `<h1>Wash-sale calendar</h1>` (the base layer styles `<h1>` to display-1). Replace form input classes (`border border-slate-300 rounded …`) with consistent `bg-surface text-text border-0` plus the inline border style. Apply `class="seg"` to the segmented confidence selector.

- [ ] **Step 4: Restyle `_calendar_focus.html` and `_violation_card.html`**

Token swap. Replace slate colors and `bg-white` cards with `bg-surface`/`text-label-*`/`panel`. Confidence chip classes already exist (`.chip-confirm` etc., back-compat-aliased through `.badge-*`).

- [ ] **Step 5: Smoke**

```bash
make build-css
uv run pytest tests/web/test_calendar.py tests/web/test_violation_badge.py -x -q
```

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_calendar_*.html src/net_alpha/web/templates/calendar.html src/net_alpha/web/templates/_violation_card.html src/net_alpha/web/static/app.css
git commit -m "feat(web): restyle calendar pages — Apple-system colors for ribbons + dots"
```

---

### Task C4: Restyle imports page

**Files:**
- Modify: `src/net_alpha/web/templates/imports.html`
- Modify: `src/net_alpha/web/templates/_imports_table.html`
- Modify: `src/net_alpha/web/templates/_imports_detail_row.html`
- Modify: `src/net_alpha/web/templates/_drop_zone.html`
- Modify: `src/net_alpha/web/templates/_import_modal.html`
- Modify: `src/net_alpha/web/templates/_toast.html`

- [ ] **Step 1: Restyle each file via token swap**

For each file: replace `bg-white`/`bg-slate-*`/`border-slate-*`/`text-slate-*` with the corresponding `bg-surface`/panel-border/`text-label-*` tokens. Replace `text-emerald-*` with `text-pos`, `text-red-*`/`text-rose-*` with `text-neg`, `text-amber-*` with `text-warn`. Convert any old `<table class="w-full ...">` to `<table class="net-table">`. Wrap card-shaped sections in `<div class="panel">…</div>`.

- [ ] **Step 2: Smoke**

```bash
make build-css
uv run pytest tests/web/test_imports_routes.py tests/web/test_imports_detail.py tests/web/test_imports_table_files_column.py tests/web/test_upload_flow.py tests/web/test_multi_file_upload.py -x -q
```

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/imports.html src/net_alpha/web/templates/_imports_*.html src/net_alpha/web/templates/_drop_zone.html src/net_alpha/web/templates/_import_modal.html src/net_alpha/web/templates/_toast.html src/net_alpha/web/static/app.css
git commit -m "feat(web): restyle imports + upload + toast under new tokens"
```

---

### Task C5: Restyle sim, detail, ticker, error pages

**Files:**
- Modify: `src/net_alpha/web/templates/sim.html`
- Modify: `src/net_alpha/web/templates/_sim_buy_result.html`
- Modify: `src/net_alpha/web/templates/_sim_sell_result.html`
- Modify: `src/net_alpha/web/templates/detail.html`
- Modify: `src/net_alpha/web/templates/_detail_table.html`
- Modify: `src/net_alpha/web/templates/ticker.html`
- Modify: `src/net_alpha/web/templates/_lots_table.html`
- Modify: `src/net_alpha/web/templates/_schwab_lot_detail.html`
- Modify: `src/net_alpha/web/templates/error.html`

- [ ] **Step 1: Token-swap each file**

For each file: replace `bg-white`/`bg-slate-*`/`border-slate-*`/`text-slate-*` with the corresponding `bg-surface`/panel-border/`text-label-*` tokens. Replace `text-emerald-*` with `text-pos`, `text-red-*`/`text-rose-*` with `text-neg`, `text-amber-*` with `text-warn`. Convert any old `<table class="w-full ...">` to `<table class="net-table">`. Wrap card-shaped sections in `<div class="panel">…</div>`.

Sim-specific: the BUY/SELL action selector should use `.seg`/`.seg-active`; form inputs (text/number) should use `class="bg-surface text-text rounded-md px-2 py-1 text-[13px]"` with `style="border:0.5px solid rgba(255,255,255,0.08);"`.

Detail/ticker-specific: the Lots table and Schwab-lot expansion follow the `.net-table` pattern; mono numerics use `class="num"`.

Error page: keep it minimal — a centered panel with `<h1>Something went wrong</h1>`, the error message in `text-label-2`, and an "← Back" link styled as `.btn-ghost`.

- [ ] **Step 2: Smoke**

```bash
make build-css
uv run pytest tests/web/test_sim_routes.py tests/web/test_sim_buy_routes.py tests/web/test_detail_routes.py tests/web/test_detail_enhancements.py tests/web/test_ticker.py tests/web/test_ticker_lot_detail.py tests/web/test_errors.py -x -q
```

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/sim.html src/net_alpha/web/templates/_sim_*.html src/net_alpha/web/templates/detail.html src/net_alpha/web/templates/_detail_table.html src/net_alpha/web/templates/ticker.html src/net_alpha/web/templates/_lots_table.html src/net_alpha/web/templates/_schwab_lot_detail.html src/net_alpha/web/templates/error.html src/net_alpha/web/static/app.css
git commit -m "feat(web): restyle sim/detail/ticker/error pages under new tokens"
```

---

### Task C6: Final visual sweep + lint + full test run

- [ ] **Step 1: Rebuild CSS once more from clean**

```bash
make build-css
```

- [ ] **Step 2: Run all tests**

```bash
uv run pytest -q
```

Expected: all green.

- [ ] **Step 3: Run linter and formatter**

```bash
uv run ruff check .
uv run ruff format --check .
```

Expected: no errors, no formatting suggestions. If formatter wants to reflow files, run `uv run ruff format .` and commit the result.

- [ ] **Step 4: Manual visual sweep**

```bash
uv run net-alpha ui
```

Walk every page (`/`, `/calendar`, `/imports`, `/sim`, `/detail`, click into a `/ticker/<sym>`). Verify:
- Topbar consistent across pages, vibrancy visible.
- No leftover white panels, no slate-300 borders, no Fira fonts.
- Equity curve renders via ApexCharts with smooth area + violet end-marker.
- Allocation donut + chips on home page; wash-watch panel renders (with content if you have loss closes, empty-state otherwise).
- Calendar dual-ribbon recolored.
- Confidence chips on the calendar focus / violation cards use the new red/amber/cyan.
- Hover states on table rows give a subtle white-alpha tint.
- Disclaimer footer still present on every page.

If anything looks broken, fix in place and commit a follow-up. Take screenshots of all pages for the PR.

- [ ] **Step 5: Update CLAUDE.md if needed**

The `Web UI conventions` section in `CLAUDE.md` mentions a `Period (YTD / specific year / Lifetime) + Account` toolbar — still accurate. The `lot_aging` and `treemap` references in the "Pricing & Portfolio modules" section need a small update: replace `treemap` with `allocation` in the bullet list. Confirm and edit.

- [ ] **Step 6: Final commit + ready for review**

```bash
git status
git add -A
git commit -m "chore: final lint pass + CLAUDE.md updates after UI visual redesign" || echo "nothing to commit"
git log --oneline -25
```

Push and open a PR titled "feat(web): Apple-dark visual theme + allocation donut + wash-watch panel" with screenshots of: (1) home page before, (2) home page after, (3) calendar, (4) sim, (5) detail.

---

## Acceptance criteria

- [ ] All 5 web pages render in the new theme (no white cards, no Fira fonts, no slate-300 borders anywhere).
- [ ] `/portfolio/treemap` returns 404; `/portfolio/allocation` returns donut + chips; `/portfolio/wash-watch` returns the watch panel.
- [ ] Equity curve renders via ApexCharts (DOM contains an `apexcharts-canvas` element after page load).
- [ ] Hero KPI cards show YTD + Lifetime side-by-side for both Realized and Unrealized.
- [ ] Wash-sale watch panel: shows correct rows when a fixture creates loss closes within the last 30 days; shows "All clear" when none.
- [ ] `uv run pytest` passes.
- [ ] `uv run ruff check .` passes.
- [ ] Screenshots posted in the PR.
