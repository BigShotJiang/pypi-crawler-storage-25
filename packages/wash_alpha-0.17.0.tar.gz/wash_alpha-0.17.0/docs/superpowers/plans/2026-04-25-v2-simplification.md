# net_alpha v2 Simplification — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rewrite the net_alpha CLI to a 4-command surface (default import+check, sim, imports, imports rm), Schwab-only, no LLM, with stateful incremental persistence — implementing the v2 design spec in `docs/superpowers/specs/2026-04-25-v2-simplification-design.md`.

**Architecture:** Develop on a `v2` branch in a worktree. Build new modules (`brokers/`, `ingest/`, `output/`) alongside v1, replace `models/`, `db/`, and `cli/` in place, preserve `engine/detector.py` and `engine/matcher.py` largely intact (their algorithm is correct), then wholesale-delete v1's TUI / agent / wizard / LLM-import packages in a final cleanup pass. Tests are written first for every behavioral change.

**Tech Stack:** Python 3.11+, `uv`, `typer[all]`, `pydantic` v2, `sqlmodel` over SQLite, `loguru`, `pytest`, `factory_boy`, `ruff`. Removed: `anthropic`, `questionary`, `textual`, `pydantic-settings`.

---

## Task 0: Set Up v2 Worktree

**Files:**
- Create: `.worktrees/v2/` (worktree)

- [ ] **Step 1: Verify clean state on master**

```bash
cd /Users/alexchen/Documents/project/net_alpha
git status --short
```

Expected: only `M uv.lock`, `M AGENTS.md`, `M CLAUDE.md` (env-managed, ignore). No untracked source files.

- [ ] **Step 2: Create v2 worktree**

```bash
git worktree add .worktrees/v2 -b v2
cd .worktrees/v2
```

- [ ] **Step 3: Verify worktree is on v2 branch**

```bash
git branch --show-current
```

Expected: `v2`

- [ ] **Step 4: Install dev deps in worktree**

```bash
uv sync
```

- [ ] **Step 5: Run baseline test suite to confirm green start**

```bash
uv run pytest -q
```

Expected: all tests pass (this is v1 still). If anything fails on master, stop and fix on master first.

- [ ] **Step 6: Commit a marker for the v2 branch start**

```bash
git commit --allow-empty -m "chore(v2): branch start — implementing v2 simplification spec"
```

> **Note for all subsequent tasks:** all work happens in `.worktrees/v2/`. Paths in this plan are relative to that directory.

---

## Task 1: Delete v1 User-Surface Modules That v2 Drops Entirely

**Why first:** These modules import each other and the legacy CLI. Deleting them up front gives us a smaller blast radius for the rewrite. The engine, db, and import_ packages stay (they get rewritten in later tasks).

**Files:**
- Delete: `src/net_alpha/tui/` (entire package)
- Delete: `src/net_alpha/agent/` (entire package)
- Delete: `src/net_alpha/cli/wizard.py`
- Delete: `src/net_alpha/cli/agent.py`
- Delete: `src/net_alpha/cli/check.py`
- Delete: `src/net_alpha/cli/report.py`
- Delete: `src/net_alpha/cli/rebuys.py`
- Delete: `src/net_alpha/cli/tax_position.py`
- Delete: `src/net_alpha/cli/status.py`
- Delete: `src/net_alpha/import_/schema_detection.py`
- Delete: `src/net_alpha/import_/anonymizer.py`
- Modify: `src/net_alpha/cli/app.py` (remove imports/registration of deleted commands)
- Delete: corresponding `tests/` files

- [ ] **Step 1: Inventory tests for deleted code**

```bash
ls tests/
ls tests/tui 2>/dev/null
ls tests/agent 2>/dev/null
ls tests/cli 2>/dev/null
```

Make a list of test files that exercise wizard / agent / TUI / check / report / rebuys / tax_position / status / schema_detection / anonymizer.

- [ ] **Step 2: Delete v1 source modules**

```bash
rm -rf src/net_alpha/tui
rm -rf src/net_alpha/agent
rm src/net_alpha/cli/wizard.py
rm src/net_alpha/cli/agent.py
rm src/net_alpha/cli/check.py
rm src/net_alpha/cli/report.py
rm src/net_alpha/cli/rebuys.py
rm src/net_alpha/cli/tax_position.py
rm src/net_alpha/cli/status.py
rm src/net_alpha/import_/schema_detection.py
rm src/net_alpha/import_/anonymizer.py
```

- [ ] **Step 3: Delete corresponding test files**

For every test file identified in step 1 that exclusively targets a deleted module, remove it. Example commands (adjust to actual layout discovered in step 1):

```bash
rm -rf tests/tui tests/agent
rm tests/cli/test_wizard.py tests/cli/test_agent.py tests/cli/test_check.py \
   tests/cli/test_report.py tests/cli/test_rebuys.py tests/cli/test_tax_position.py \
   tests/cli/test_status.py 2>/dev/null
rm tests/import_/test_schema_detection.py tests/import_/test_anonymizer.py 2>/dev/null
```

If any test file mixes deleted and kept code, edit it instead of deleting.

- [ ] **Step 4: Update `src/net_alpha/cli/app.py` — strip deleted command registrations**

Open `src/net_alpha/cli/app.py`. Remove all imports of and `app.command(...)` registrations for the deleted commands. Keep only: `import_cmd` and `simulate` (these get replaced in later tasks; leaving them registered for now keeps the module importable).

- [ ] **Step 5: Confirm the package still imports cleanly**

```bash
uv run python -c "import net_alpha.cli.app; print('ok')"
```

Expected: prints `ok`. If `ImportError`, fix the offending import in `app.py`.

- [ ] **Step 6: Run remaining tests**

```bash
uv run pytest -q
```

Expected: green or fewer failures than the baseline. Some tests may fail because they import deleted modules — fix or delete those tests now.

- [ ] **Step 7: Commit**

```bash
git add -A
git commit -m "chore(v2): remove TUI, agent, wizard, and dropped CLI commands

These surfaces are cut in v2. Engine, db, and import_ packages remain
in place pending replacement in later tasks."
```

---

## Task 2: Add v2 Domain Models — Account, ImportRecord, SimulationOption

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Test: `tests/models/test_v2_domain.py`

- [ ] **Step 1: Write failing tests for new domain types**

Create `tests/models/test_v2_domain.py`:

```python
from datetime import date, datetime
from decimal import Decimal

from net_alpha.models.domain import (
    Account,
    AddImportResult,
    ImportRecord,
    ImportSummary,
    LotConsumption,
    RemoveImportResult,
    SimulationOption,
)


def test_account_has_broker_and_label():
    a = Account(broker="schwab", label="personal")
    assert a.broker == "schwab"
    assert a.label == "personal"
    assert a.display() == "schwab/personal"


def test_import_record_has_filename_sha_and_count():
    r = ImportRecord(
        account_id=1,
        csv_filename="q1.csv",
        csv_sha256="abc",
        imported_at=datetime(2026, 4, 25, 10, 0),
        trade_count=412,
    )
    assert r.csv_filename == "q1.csv"
    assert r.trade_count == 412


def test_add_import_result_reports_new_and_dup_counts():
    r = AddImportResult(import_id=1, new_trades=298, duplicate_trades=4)
    assert r.new_trades == 298
    assert r.duplicate_trades == 4


def test_remove_import_result_reports_removed():
    r = RemoveImportResult(removed_trade_count=298, recompute_window=(date(2024, 8, 16), date(2024, 10, 24)))
    assert r.removed_trade_count == 298


def test_import_summary_has_display_account():
    s = ImportSummary(
        id=1, account_display="schwab/personal", csv_filename="q1.csv",
        trade_count=412, imported_at=datetime(2026, 4, 25, 10, 0),
    )
    assert s.account_display == "schwab/personal"


def test_lot_consumption_records_lot_qty_and_basis():
    lc = LotConsumption(lot_id=7, quantity=Decimal("5"), basis_per_share=Decimal("200"), purchase_date=date(2024, 8, 15))
    assert lc.quantity == Decimal("5")


def test_simulation_option_carries_account_pnl_and_wash_verdict():
    acct = Account(broker="schwab", label="personal")
    opt = SimulationOption(
        account=acct,
        lots_consumed_fifo=[],
        realized_pnl=Decimal("-150"),
        would_trigger_wash_sale=True,
        blocking_buys=[],
        lookforward_block_until=None,
        confidence="Confirmed",
        insufficient_shares=False,
        available_shares=Decimal("10"),
    )
    assert opt.would_trigger_wash_sale is True
    assert opt.realized_pnl == Decimal("-150")
```

- [ ] **Step 2: Run tests to verify they fail with ImportError**

```bash
uv run pytest tests/models/test_v2_domain.py -v
```

Expected: `ImportError: cannot import name 'Account' from 'net_alpha.models.domain'`

- [ ] **Step 3: Add the new types to `src/net_alpha/models/domain.py`**

Append to the existing file (don't remove anything yet — `Trade`, `Lot`, `WashSaleViolation`, `OptionDetails`, `DetectionResult` stay):

```python
# v2 additions ----------------------------------------------------------------
from datetime import datetime  # noqa: E402  (keep next to v2 imports)
from decimal import Decimal


class Account(BaseModel):
    """A user-named account scoped to a single broker."""

    id: int | None = None
    broker: str
    label: str

    def display(self) -> str:
        return f"{self.broker}/{self.label}"


class ImportRecord(BaseModel):
    """Metadata for one CSV import. Trades hold a FK to this."""

    id: int | None = None
    account_id: int
    csv_filename: str
    csv_sha256: str
    imported_at: datetime
    trade_count: int


class AddImportResult(BaseModel):
    import_id: int
    new_trades: int
    duplicate_trades: int


class RemoveImportResult(BaseModel):
    removed_trade_count: int
    recompute_window: tuple[date, date] | None  # None when import had zero trades


class ImportSummary(BaseModel):
    """Display row for `net-alpha imports`."""

    id: int
    account_display: str
    csv_filename: str
    trade_count: int
    imported_at: datetime


class LotConsumption(BaseModel):
    """One lot consumed (partially or fully) by a hypothetical sell."""

    lot_id: int
    quantity: Decimal
    basis_per_share: Decimal
    purchase_date: date


class SimulationOption(BaseModel):
    """One scenario in `sim`'s output: 'sell from this account'."""

    account: Account
    lots_consumed_fifo: list[LotConsumption]
    realized_pnl: Decimal
    would_trigger_wash_sale: bool
    blocking_buys: list[Trade]
    lookforward_block_until: date | None
    confidence: str  # "Confirmed" | "Probable" | "Unclear" | "N/A"
    insufficient_shares: bool
    available_shares: Decimal
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/models/test_v2_domain.py -v
```

Expected: all 7 tests PASS.

- [ ] **Step 5: Run the full suite to confirm no regression**

```bash
uv run pytest -q
```

Expected: all tests still pass (we only added types).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/test_v2_domain.py
git commit -m "feat(models): add v2 domain types — Account, ImportRecord, SimulationOption"
```

---

## Task 3: Replace SQLModel Tables with v2 Schema

**Why a clean replace:** v2 changes Trade/Lot/Violation primary keys from string UUIDs to `int` autoincrement and adds FKs to new `Account` and `ImportRecord` tables. Per the spec (§9.1) v2 is a clean schema break — no migration from v1 in-place.

**Files:**
- Modify: `src/net_alpha/db/tables.py` (full rewrite)
- Modify: `src/net_alpha/db/migrations.py` (full rewrite — start at schema_version=1)
- Test: `tests/db/test_v2_tables.py`

- [ ] **Step 1: Write failing test asserting the new schema**

Create `tests/db/test_v2_tables.py`:

```python
import os

from sqlalchemy import inspect
from sqlmodel import Session, SQLModel, create_engine, select

from net_alpha.db.tables import (
    AccountRow,
    ImportRecordRow,
    LotRow,
    MetaRow,
    TradeRow,
    WashSaleViolationRow,
)


def _engine(tmp_path):
    path = tmp_path / "test.db"
    eng = create_engine(f"sqlite:///{path}")
    SQLModel.metadata.create_all(eng)
    return eng


def test_account_row_has_unique_broker_label(tmp_path):
    eng = _engine(tmp_path)
    with Session(eng) as s:
        s.add(AccountRow(broker="schwab", label="personal"))
        s.commit()
    insp = inspect(eng)
    cols = {c["name"] for c in insp.get_columns("accounts")}
    assert {"id", "broker", "label"} <= cols


def test_import_record_row_has_sha_and_filename(tmp_path):
    eng = _engine(tmp_path)
    insp = inspect(eng)
    cols = {c["name"] for c in insp.get_columns("imports")}
    assert {"id", "account_id", "csv_filename", "csv_sha256", "imported_at", "trade_count"} <= cols


def test_trade_row_has_natural_key_and_fks(tmp_path):
    eng = _engine(tmp_path)
    insp = inspect(eng)
    cols = {c["name"] for c in insp.get_columns("trades")}
    assert {"id", "import_id", "account_id", "natural_key", "ticker", "trade_date"} <= cols


def test_lot_row_has_account_fk(tmp_path):
    eng = _engine(tmp_path)
    insp = inspect(eng)
    cols = {c["name"] for c in insp.get_columns("lots")}
    assert "account_id" in cols


def test_violation_row_has_account_fks(tmp_path):
    eng = _engine(tmp_path)
    insp = inspect(eng)
    cols = {c["name"] for c in insp.get_columns("wash_sale_violations")}
    assert {"loss_account_id", "buy_account_id"} <= cols


def test_no_schema_cache_table(tmp_path):
    eng = _engine(tmp_path)
    insp = inspect(eng)
    assert "schema_cache" not in insp.get_table_names()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/db/test_v2_tables.py -v
```

Expected: failures — `AccountRow` doesn't exist, `schema_cache` still present, etc.

- [ ] **Step 3: Replace `src/net_alpha/db/tables.py`**

```python
# src/net_alpha/db/tables.py
from __future__ import annotations

from datetime import datetime

from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel


class AccountRow(SQLModel, table=True):
    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("broker", "label", name="uq_account_broker_label"),)

    id: int | None = Field(default=None, primary_key=True)
    broker: str = Field(index=True)
    label: str = Field(index=True)


class ImportRecordRow(SQLModel, table=True):
    __tablename__ = "imports"

    id: int | None = Field(default=None, primary_key=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    csv_filename: str
    csv_sha256: str = Field(index=True)
    imported_at: datetime
    trade_count: int


class TradeRow(SQLModel, table=True):
    __tablename__ = "trades"
    __table_args__ = (UniqueConstraint("account_id", "natural_key", name="uq_trade_account_natkey"),)

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    natural_key: str = Field(index=True)

    ticker: str = Field(index=True)
    trade_date: str = Field(index=True)  # YYYY-MM-DD as-is from broker
    action: str
    quantity: float
    proceeds: float | None = None
    cost_basis: float | None = None
    basis_unknown: bool = False

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None


class LotRow(SQLModel, table=True):
    __tablename__ = "lots"

    id: int | None = Field(default=None, primary_key=True)
    trade_id: int = Field(foreign_key="trades.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)

    ticker: str = Field(index=True)
    trade_date: str
    quantity: float
    cost_basis: float
    adjusted_basis: float

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None


class WashSaleViolationRow(SQLModel, table=True):
    __tablename__ = "wash_sale_violations"

    id: int | None = Field(default=None, primary_key=True)
    loss_trade_id: int = Field(foreign_key="trades.id", index=True)
    replacement_trade_id: int = Field(foreign_key="trades.id", index=True)
    loss_account_id: int = Field(foreign_key="accounts.id", index=True)
    buy_account_id: int = Field(foreign_key="accounts.id", index=True)
    loss_sale_date: str = Field(index=True)
    triggering_buy_date: str = Field(index=True)
    confidence: str
    disallowed_loss: float
    matched_quantity: float


class MetaRow(SQLModel, table=True):
    __tablename__ = "meta"

    key: str = Field(primary_key=True)
    value: str
```

- [ ] **Step 4: Replace `src/net_alpha/db/migrations.py`**

```python
# src/net_alpha/db/migrations.py
"""Hand-written migrations. v2 starts at schema_version=1.

v1 → v2 is a clean break. Users either re-import their CSVs or run
`net-alpha migrate-from-v1`. There is no in-place upgrade.
"""
from __future__ import annotations

from sqlalchemy import text
from sqlmodel import Session

CURRENT_SCHEMA_VERSION = 1


def get_schema_version(session: Session) -> int:
    row = session.exec(text("SELECT value FROM meta WHERE key='schema_version'")).first()
    return int(row[0]) if row else 0


def set_schema_version(session: Session, version: int) -> None:
    session.exec(
        text(
            "INSERT INTO meta(key, value) VALUES ('schema_version', :v) "
            "ON CONFLICT(key) DO UPDATE SET value=:v"
        ),
        params={"v": str(version)},
    )
    session.commit()


def migrate(session: Session) -> None:
    """Apply pending migrations. v2.0.0 is schema_version=1 — no upgrades exist yet."""
    current = get_schema_version(session)
    if current == 0:
        set_schema_version(session, CURRENT_SCHEMA_VERSION)
        return
    if current > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"DB schema_version={current} is newer than this binary "
            f"(supports {CURRENT_SCHEMA_VERSION}). Upgrade net-alpha."
        )
    # Add upgrade branches here when adding schema_version=2, 3, ...
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/db/test_v2_tables.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 6: Confirm v1 tests that depended on old schema fail (expected, will be replaced)**

```bash
uv run pytest tests/db -q 2>&1 | tail -20
```

Expect failures from any v1 test that imports the old `SchemaCacheRow` or the old TradeRow shape. These will be deleted/replaced in later tasks.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/db/tables.py src/net_alpha/db/migrations.py tests/db/test_v2_tables.py
git commit -m "feat(db): replace tables with v2 schema (Account, Import, FKs, natural_key)

v1 schema is dropped wholesale. Schema starts at version 1. v1 → v2
upgrade lives in a separate `migrate-from-v1` helper (Task 16)."
```

---

## Task 4: Update Pydantic Trade Model for v2 Wire Format

**Why:** Trade is shared between ingest, engine, repository, and CLI. v2 introduces `natural_key` and tightens `account` to the `"<broker>/<label>"` format. The engine algorithm still operates on Trade-as-a-string-account, so this is mostly additive.

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Test: `tests/models/test_trade_v2.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/models/test_trade_v2.py
from datetime import date

from net_alpha.models.domain import OptionDetails, Trade


def test_trade_account_uses_broker_label_format():
    t = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
              action="Buy", quantity=10, proceeds=None, cost_basis=2000.0)
    assert "/" in t.account


def test_trade_compute_natural_key_is_deterministic():
    t1 = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
               action="Buy", quantity=10, cost_basis=2000.0)
    t2 = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
               action="Buy", quantity=10, cost_basis=2000.0)
    assert t1.compute_natural_key() == t2.compute_natural_key()


def test_natural_key_differs_when_quantity_differs():
    a = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
              action="Buy", quantity=10, cost_basis=2000.0)
    b = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
              action="Buy", quantity=11, cost_basis=2000.0)
    assert a.compute_natural_key() != b.compute_natural_key()


def test_natural_key_differs_across_accounts():
    a = Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
              action="Buy", quantity=10, cost_basis=2000.0)
    b = Trade(account="schwab/roth", date=date(2024, 1, 1), ticker="TSLA",
              action="Buy", quantity=10, cost_basis=2000.0)
    assert a.compute_natural_key() != b.compute_natural_key()


def test_natural_key_includes_option_details():
    base_kwargs = dict(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
                       action="Buy", quantity=1, cost_basis=500.0)
    a = Trade(**base_kwargs, option_details=OptionDetails(strike=200.0, expiry=date(2024, 6, 21), call_put="C"))
    b = Trade(**base_kwargs, option_details=OptionDetails(strike=210.0, expiry=date(2024, 6, 21), call_put="C"))
    assert a.compute_natural_key() != b.compute_natural_key()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/models/test_trade_v2.py -v
```

Expected: failure — `compute_natural_key` does not exist.

- [ ] **Step 3: Add `compute_natural_key` to `Trade` in `src/net_alpha/models/domain.py`**

Inside the `Trade` class, add:

```python
    def compute_natural_key(self) -> str:
        """SHA256 over the canonical fields used for idempotent re-import dedup."""
        import hashlib

        opt = ""
        if self.option_details is not None:
            o = self.option_details
            opt = f"{o.strike}|{o.expiry.isoformat()}|{o.call_put}"
        payload = "|".join([
            self.account,
            self.date.isoformat(),
            self.ticker,
            self.action,
            str(self.quantity),
            str(self.proceeds if self.proceeds is not None else ""),
            str(self.cost_basis if self.cost_basis is not None else ""),
            opt,
        ])
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/models/test_trade_v2.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/test_trade_v2.py
git commit -m "feat(models): add Trade.compute_natural_key for v2 idempotent imports"
```

---

## Task 5: Build the Repository — Account & Import Management

**Files:**
- Modify: `src/net_alpha/db/repository.py` (rewrite)
- Test: `tests/db/test_repository_accounts.py`

- [ ] **Step 1: Read v1 repository for reusable helpers (no edits)**

```bash
sed -n '1,80p' src/net_alpha/db/repository.py
```

Note any `_to_pydantic` row-conversion helpers — those patterns will stay; the methods change.

- [ ] **Step 2: Write failing tests for account & import methods**

```python
# tests/db/test_repository_accounts.py
from datetime import datetime

import pytest
from sqlmodel import SQLModel, create_engine

from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord


@pytest.fixture
def repo(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path}/v2.db")
    SQLModel.metadata.create_all(eng)
    return Repository(eng)


def test_get_or_create_account_creates_when_missing(repo):
    a = repo.get_or_create_account("schwab", "personal")
    assert a.id is not None
    assert a.display() == "schwab/personal"


def test_get_or_create_account_is_idempotent(repo):
    a1 = repo.get_or_create_account("schwab", "personal")
    a2 = repo.get_or_create_account("schwab", "personal")
    assert a1.id == a2.id


def test_get_account_returns_none_when_missing(repo):
    assert repo.get_account("schwab", "ghost") is None


def test_get_account_returns_existing(repo):
    repo.get_or_create_account("schwab", "personal")
    a = repo.get_account("schwab", "personal")
    assert a is not None and a.label == "personal"


def test_list_accounts_returns_all(repo):
    repo.get_or_create_account("schwab", "personal")
    repo.get_or_create_account("schwab", "roth")
    accts = repo.list_accounts()
    assert {a.label for a in accts} == {"personal", "roth"}


def test_list_imports_empty(repo):
    assert repo.list_imports() == []


def test_get_import_returns_none_when_missing(repo):
    assert repo.get_import(999) is None
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
uv run pytest tests/db/test_repository_accounts.py -v
```

Expected: `ImportError` or attribute errors — Repository class doesn't have these methods.

- [ ] **Step 4: Replace `src/net_alpha/db/repository.py` with the v2 skeleton + account methods**

```python
# src/net_alpha/db/repository.py
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy.engine import Engine
from sqlmodel import Session, select

from net_alpha.db.tables import (
    AccountRow,
    ImportRecordRow,
    LotRow,
    TradeRow,
    WashSaleViolationRow,
)
from net_alpha.models.domain import (
    Account,
    AddImportResult,
    ImportRecord,
    ImportSummary,
    Lot,
    OptionDetails,
    RemoveImportResult,
    Trade,
    WashSaleViolation,
)


class Repository:
    def __init__(self, engine: Engine):
        self.engine = engine

    # --- Account / import management ---

    def get_or_create_account(self, broker: str, label: str) -> Account:
        with Session(self.engine) as s:
            row = s.exec(
                select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)
            ).first()
            if row is None:
                row = AccountRow(broker=broker, label=label)
                s.add(row)
                s.commit()
                s.refresh(row)
            return Account(id=row.id, broker=row.broker, label=row.label)

    def get_account(self, broker: str, label: str) -> Account | None:
        with Session(self.engine) as s:
            row = s.exec(
                select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)
            ).first()
            if row is None:
                return None
            return Account(id=row.id, broker=row.broker, label=row.label)

    def list_accounts(self) -> list[Account]:
        with Session(self.engine) as s:
            rows = s.exec(select(AccountRow)).all()
            return [Account(id=r.id, broker=r.broker, label=r.label) for r in rows]

    def list_imports(self) -> list[ImportSummary]:
        with Session(self.engine) as s:
            stmt = (
                select(ImportRecordRow, AccountRow)
                .join(AccountRow, AccountRow.id == ImportRecordRow.account_id)
                .order_by(ImportRecordRow.imported_at.desc())
            )
            return [
                ImportSummary(
                    id=ir.id,
                    account_display=f"{a.broker}/{a.label}",
                    csv_filename=ir.csv_filename,
                    trade_count=ir.trade_count,
                    imported_at=ir.imported_at,
                )
                for ir, a in s.exec(stmt).all()
            ]

    def get_import(self, import_id: int) -> ImportRecord | None:
        with Session(self.engine) as s:
            row = s.get(ImportRecordRow, import_id)
            if row is None:
                return None
            return ImportRecord(
                id=row.id, account_id=row.account_id,
                csv_filename=row.csv_filename, csv_sha256=row.csv_sha256,
                imported_at=row.imported_at, trade_count=row.trade_count,
            )

    # Methods added in later tasks: trades_for_import, add_import, remove_import,
    # existing_natural_keys, all_trades, all_lots, all_violations,
    # violations_for_year, trades_in_window, replace_violations_in_window
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/db/test_repository_accounts.py -v
```

Expected: all 7 tests PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_accounts.py
git commit -m "feat(db): repository v2 skeleton + account/import management methods"
```

---

## Task 6: Repository — Add Import (with dedup) + Existing Natural Keys

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_add_import.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/db/test_repository_add_import.py
from datetime import date, datetime

import pytest
from sqlmodel import SQLModel, create_engine

from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord, Trade


@pytest.fixture
def repo(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path}/v2.db")
    SQLModel.metadata.create_all(eng)
    return Repository(eng)


def _trade(account: str, ticker: str, qty: float, basis: float = 1000.0):
    t = Trade(account=account, date=date(2024, 1, 1), ticker=ticker,
              action="Buy", quantity=qty, cost_basis=basis)
    return t


def test_add_import_inserts_account_record_and_trades(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(account_id=acct.id, csv_filename="q1.csv", csv_sha256="h",
                       imported_at=datetime(2026, 4, 25), trade_count=0)
    trades = [_trade(acct.display(), "TSLA", 10), _trade(acct.display(), "AAPL", 5)]
    result = repo.add_import(acct, rec, trades)
    assert result.new_trades == 2
    assert result.duplicate_trades == 0
    assert result.import_id is not None


def test_existing_natural_keys_returns_set(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    assert repo.existing_natural_keys(acct.id) == set()


def test_re_adding_same_trades_under_same_account_skips_dups(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec1 = ImportRecord(account_id=acct.id, csv_filename="q1.csv", csv_sha256="h1",
                        imported_at=datetime(2026, 4, 25), trade_count=0)
    rec2 = ImportRecord(account_id=acct.id, csv_filename="q1_again.csv", csv_sha256="h2",
                        imported_at=datetime(2026, 4, 26), trade_count=0)
    trades = [_trade(acct.display(), "TSLA", 10), _trade(acct.display(), "AAPL", 5)]

    repo.add_import(acct, rec1, trades)

    # Caller is responsible for filtering with existing_natural_keys before add_import.
    keys = repo.existing_natural_keys(acct.id)
    new_trades = [t for t in trades if t.compute_natural_key() not in keys]
    result = repo.add_import(acct, rec2, new_trades)
    assert result.new_trades == 0
    assert result.duplicate_trades == 0  # caller already filtered them


def test_same_natural_key_in_different_account_is_independent(repo):
    a = repo.get_or_create_account("schwab", "personal")
    b = repo.get_or_create_account("schwab", "roth")
    rec_a = ImportRecord(account_id=a.id, csv_filename="a.csv", csv_sha256="h",
                         imported_at=datetime(2026, 4, 25), trade_count=0)
    rec_b = ImportRecord(account_id=b.id, csv_filename="b.csv", csv_sha256="h",
                         imported_at=datetime(2026, 4, 25), trade_count=0)
    repo.add_import(a, rec_a, [_trade(a.display(), "TSLA", 10)])
    result = repo.add_import(b, rec_b, [_trade(b.display(), "TSLA", 10)])
    assert result.new_trades == 1
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/db/test_repository_add_import.py -v
```

- [ ] **Step 3: Add `add_import` and `existing_natural_keys` to `Repository`**

Append inside the `Repository` class:

```python
    def existing_natural_keys(self, account_id: int) -> set[str]:
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow.natural_key).where(TradeRow.account_id == account_id)
            ).all()
            return set(rows)

    def add_import(
        self, account: Account, record: ImportRecord, trades: list[Trade]
    ) -> AddImportResult:
        """Insert trades for a new ImportRecord. Caller should pre-filter dups
        with existing_natural_keys; we still rely on the UNIQUE constraint as
        the safety net.
        """
        with Session(self.engine) as s:
            ir = ImportRecordRow(
                account_id=account.id,
                csv_filename=record.csv_filename,
                csv_sha256=record.csv_sha256,
                imported_at=record.imported_at,
                trade_count=len(trades),
            )
            s.add(ir)
            s.flush()  # populate ir.id

            new_count = 0
            dup_count = 0
            for t in trades:
                tr = TradeRow(
                    import_id=ir.id,
                    account_id=account.id,
                    natural_key=t.compute_natural_key(),
                    ticker=t.ticker,
                    trade_date=t.date.isoformat(),
                    action=t.action,
                    quantity=t.quantity,
                    proceeds=t.proceeds,
                    cost_basis=t.cost_basis,
                    basis_unknown=t.basis_unknown,
                    option_strike=(t.option_details.strike if t.option_details else None),
                    option_expiry=(t.option_details.expiry.isoformat() if t.option_details else None),
                    option_call_put=(t.option_details.call_put if t.option_details else None),
                )
                try:
                    s.add(tr)
                    s.flush()
                    new_count += 1
                except Exception:  # IntegrityError on UNIQUE
                    s.rollback()
                    # Reattach the ImportRecord row before retrying the next trade
                    s.add(ir)
                    dup_count += 1

            ir.trade_count = new_count
            s.commit()
            return AddImportResult(import_id=ir.id, new_trades=new_count, duplicate_trades=dup_count)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/db/test_repository_add_import.py -v
```

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_add_import.py
git commit -m "feat(db): add_import with dedup via natural_key UNIQUE constraint"
```

---

## Task 7: Repository — Reads (trades, lots, violations, windowed)

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_reads.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/db/test_repository_reads.py
from datetime import date, datetime

import pytest
from sqlmodel import SQLModel, create_engine

from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord, Trade


@pytest.fixture
def repo(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path}/v2.db")
    SQLModel.metadata.create_all(eng)
    r = Repository(eng)
    acct = r.get_or_create_account("schwab", "personal")
    rec = ImportRecord(account_id=acct.id, csv_filename="x.csv", csv_sha256="h",
                       imported_at=datetime(2026, 4, 25), trade_count=0)
    trades = [
        Trade(account=acct.display(), date=date(2024, 1, 5),  ticker="TSLA", action="Buy",  quantity=10, cost_basis=2000.0),
        Trade(account=acct.display(), date=date(2024, 6, 1),  ticker="TSLA", action="Sell", quantity=10, proceeds=1500.0, cost_basis=2000.0),
        Trade(account=acct.display(), date=date(2024, 6, 15), ticker="TSLA", action="Buy",  quantity=10, cost_basis=1700.0),
    ]
    r.add_import(acct, rec, trades)
    return r


def test_all_trades_returns_inserted(repo):
    ts = repo.all_trades()
    assert len(ts) == 3


def test_trades_in_window_filters_by_date(repo):
    ts = repo.trades_in_window(date(2024, 5, 1), date(2024, 7, 1))
    dates = sorted(t.date for t in ts)
    assert dates == [date(2024, 6, 1), date(2024, 6, 15)]


def test_all_lots_initially_empty(repo):
    assert repo.all_lots() == []


def test_all_violations_initially_empty(repo):
    assert repo.all_violations() == []


def test_violations_for_year_initially_empty(repo):
    assert repo.violations_for_year(2024) == []


def test_trades_for_import(repo):
    summary = repo.list_imports()[0]
    ts = repo.trades_for_import(summary.id)
    assert len(ts) == 3
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/db/test_repository_reads.py -v
```

- [ ] **Step 3: Add the read methods to `Repository`**

```python
    # --- Reads ---

    def _row_to_trade(self, row: TradeRow, account_display: str) -> Trade:
        opt = None
        if row.option_strike is not None:
            opt = OptionDetails(
                strike=row.option_strike,
                expiry=date.fromisoformat(row.option_expiry),
                call_put=row.option_call_put,
            )
        return Trade(
            id=str(row.id),  # legacy field expects str
            account=account_display,
            date=date.fromisoformat(row.trade_date),
            ticker=row.ticker,
            action=row.action,
            quantity=row.quantity,
            proceeds=row.proceeds,
            cost_basis=row.cost_basis,
            basis_unknown=row.basis_unknown,
            option_details=opt,
        )

    def _account_display_for_id(self, s: Session, account_id: int) -> str:
        a = s.get(AccountRow, account_id)
        return f"{a.broker}/{a.label}"

    def all_trades(self) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow)).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def trades_in_window(self, start: date, end: date) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.trade_date >= start.isoformat(),
                    TradeRow.trade_date <= end.isoformat(),
                )
            ).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def trades_for_import(self, import_id: int) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow).where(TradeRow.import_id == import_id)).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def all_lots(self) -> list[Lot]:
        with Session(self.engine) as s:
            rows = s.exec(select(LotRow)).all()
            return [self._row_to_lot(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def _row_to_lot(self, row: LotRow, account_display: str) -> Lot:
        opt = None
        if row.option_strike is not None:
            opt = OptionDetails(
                strike=row.option_strike,
                expiry=date.fromisoformat(row.option_expiry),
                call_put=row.option_call_put,
            )
        return Lot(
            id=str(row.id),
            trade_id=str(row.trade_id),
            account=account_display,
            date=date.fromisoformat(row.trade_date),
            ticker=row.ticker,
            quantity=row.quantity,
            cost_basis=row.cost_basis,
            adjusted_basis=row.adjusted_basis,
            option_details=opt,
        )

    def all_violations(self) -> list[WashSaleViolation]:
        with Session(self.engine) as s:
            rows = s.exec(select(WashSaleViolationRow)).all()
            return [
                WashSaleViolation(
                    id=str(r.id),
                    loss_trade_id=str(r.loss_trade_id),
                    replacement_trade_id=str(r.replacement_trade_id),
                    confidence=r.confidence,
                    disallowed_loss=r.disallowed_loss,
                    matched_quantity=r.matched_quantity,
                )
                for r in rows
            ]

    def violations_for_year(self, year: int) -> list[WashSaleViolation]:
        prefix = f"{year}-"
        with Session(self.engine) as s:
            rows = s.exec(
                select(WashSaleViolationRow).where(
                    WashSaleViolationRow.loss_sale_date.startswith(prefix)
                )
            ).all()
            return [
                WashSaleViolation(
                    id=str(r.id),
                    loss_trade_id=str(r.loss_trade_id),
                    replacement_trade_id=str(r.replacement_trade_id),
                    confidence=r.confidence,
                    disallowed_loss=r.disallowed_loss,
                    matched_quantity=r.matched_quantity,
                )
                for r in rows
            ]
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/db/test_repository_reads.py -v
```

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_reads.py
git commit -m "feat(db): repository reads — trades, lots, violations, windowed"
```

---

## Task 8: Repository — Remove Import + Replace Violations in Window

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_mutations.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/db/test_repository_mutations.py
from datetime import date, datetime

import pytest
from sqlmodel import SQLModel, create_engine

from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord, Trade, WashSaleViolation


@pytest.fixture
def repo(tmp_path):
    eng = create_engine(f"sqlite:///{tmp_path}/v2.db")
    SQLModel.metadata.create_all(eng)
    return Repository(eng)


def test_remove_import_cascades_trades(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(account_id=acct.id, csv_filename="x.csv", csv_sha256="h",
                       imported_at=datetime(2026, 4, 25), trade_count=0)
    trades = [
        Trade(account=acct.display(), date=date(2024, 6, 1), ticker="TSLA", action="Sell", quantity=10, proceeds=1500, cost_basis=2000),
        Trade(account=acct.display(), date=date(2024, 6, 5), ticker="TSLA", action="Buy",  quantity=10, cost_basis=1700),
    ]
    res = repo.add_import(acct, rec, trades)
    rm = repo.remove_import(res.import_id)
    assert rm.removed_trade_count == 2
    assert rm.recompute_window == (date(2024, 5, 2), date(2024, 7, 5))
    assert repo.all_trades() == []


def test_remove_import_returns_none_window_for_empty_import(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(account_id=acct.id, csv_filename="empty.csv", csv_sha256="h",
                       imported_at=datetime(2026, 4, 25), trade_count=0)
    res = repo.add_import(acct, rec, [])
    rm = repo.remove_import(res.import_id)
    assert rm.removed_trade_count == 0
    assert rm.recompute_window is None


def test_replace_violations_in_window_clears_then_writes(repo):
    repo.replace_violations_in_window(date(2024, 5, 1), date(2024, 7, 1), [])
    assert repo.all_violations() == []
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/db/test_repository_mutations.py -v
```

- [ ] **Step 3: Add `remove_import` and `replace_violations_in_window`**

```python
    # --- Mutations ---

    def remove_import(self, import_id: int) -> RemoveImportResult:
        from datetime import timedelta

        with Session(self.engine) as s:
            trade_rows = s.exec(select(TradeRow).where(TradeRow.import_id == import_id)).all()
            trade_ids = [r.id for r in trade_rows]
            removed_dates = [date.fromisoformat(r.trade_date) for r in trade_rows]

            # Cascade-delete derived rows that reference these trades
            if trade_ids:
                s.exec(
                    LotRow.__table__.delete().where(LotRow.trade_id.in_(trade_ids))
                )
                s.exec(
                    WashSaleViolationRow.__table__.delete().where(
                        (WashSaleViolationRow.loss_trade_id.in_(trade_ids))
                        | (WashSaleViolationRow.replacement_trade_id.in_(trade_ids))
                    )
                )
            s.exec(TradeRow.__table__.delete().where(TradeRow.import_id == import_id))
            s.exec(ImportRecordRow.__table__.delete().where(ImportRecordRow.id == import_id))
            s.commit()

            if not removed_dates:
                return RemoveImportResult(removed_trade_count=0, recompute_window=None)

            window = (
                min(removed_dates) - timedelta(days=30),
                max(removed_dates) + timedelta(days=30),
            )
            return RemoveImportResult(removed_trade_count=len(trade_ids), recompute_window=window)

    def replace_violations_in_window(
        self, start: date, end: date, new_violations: list[WashSaleViolation]
    ) -> None:
        with Session(self.engine) as s:
            s.exec(
                WashSaleViolationRow.__table__.delete().where(
                    WashSaleViolationRow.loss_sale_date >= start.isoformat(),
                    WashSaleViolationRow.loss_sale_date <= end.isoformat(),
                )
            )
            for v in new_violations:
                s.add(self._violation_to_row(v))
            s.commit()

    def _violation_to_row(self, v: WashSaleViolation) -> WashSaleViolationRow:
        # The engine emits Pydantic violations with string trade IDs (legacy uuid form).
        # By v2 we control trade IDs as ints — see Task 9 where the engine adapter
        # carries (loss_account_id, buy_account_id, dates) through.
        return WashSaleViolationRow(
            loss_trade_id=int(v.loss_trade_id),
            replacement_trade_id=int(v.replacement_trade_id),
            loss_account_id=getattr(v, "loss_account_id", 0),
            buy_account_id=getattr(v, "buy_account_id", 0),
            loss_sale_date=getattr(v, "loss_sale_date", "1970-01-01"),
            triggering_buy_date=getattr(v, "triggering_buy_date", "1970-01-01"),
            confidence=v.confidence,
            disallowed_loss=v.disallowed_loss,
            matched_quantity=v.matched_quantity,
        )
```

> **Note:** the `_violation_to_row` getattr defaults are a temporary scaffold. Task 9 extends `WashSaleViolation` with the missing fields and the defaults can then be removed.

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/db/test_repository_mutations.py -v
```

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_mutations.py
git commit -m "feat(db): repository remove_import + replace_violations_in_window"
```

---

## Task 9: Extend WashSaleViolation Model + Engine for Account & Date Fields

**Why:** Repository persistence needs `loss_account_id`, `buy_account_id`, `loss_sale_date`, `triggering_buy_date` on every violation. The engine has the source data; we just need to populate it. This removes the `getattr` scaffolding from Task 8.

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Modify: `src/net_alpha/engine/detector.py`
- Test: `tests/engine/test_detector_v2_fields.py`

- [ ] **Step 1: Write failing test**

```python
# tests/engine/test_detector_v2_fields.py
from datetime import date

from net_alpha.engine.detector import detect_wash_sales
from net_alpha.models.domain import Trade


def test_violations_carry_account_displays_and_dates():
    trades = [
        Trade(account="schwab/personal", date=date(2024, 3, 1), ticker="TSLA",
              action="Sell", quantity=10, proceeds=1500.0, cost_basis=2000.0),
        Trade(account="schwab/roth", date=date(2024, 3, 10), ticker="TSLA",
              action="Buy", quantity=10, cost_basis=1700.0),
    ]
    result = detect_wash_sales(trades, etf_pairs={})
    assert len(result.violations) == 1
    v = result.violations[0]
    assert v.loss_account == "schwab/personal"
    assert v.buy_account == "schwab/roth"
    assert v.loss_sale_date == date(2024, 3, 1)
    assert v.triggering_buy_date == date(2024, 3, 10)
```

- [ ] **Step 2: Run test to verify it fails**

```bash
uv run pytest tests/engine/test_detector_v2_fields.py -v
```

Expected: `AttributeError` — these fields aren't on WashSaleViolation.

- [ ] **Step 3: Extend `WashSaleViolation` in `src/net_alpha/models/domain.py`**

In the existing `WashSaleViolation` class, add (after `matched_quantity`):

```python
    loss_account: str = ""
    buy_account: str = ""
    loss_sale_date: date | None = None
    triggering_buy_date: date | None = None
```

- [ ] **Step 4: Update `detect_wash_sales` in `src/net_alpha/engine/detector.py` to populate them**

In the `violations.append(WashSaleViolation(...))` block, add the four fields:

```python
            violations.append(
                WashSaleViolation(
                    loss_trade_id=loss_sale.id,
                    replacement_trade_id=candidate.id,
                    confidence=confidence,
                    disallowed_loss=disallowed,
                    matched_quantity=allocable,
                    loss_account=loss_sale.account,
                    buy_account=candidate.account,
                    loss_sale_date=loss_sale.date,
                    triggering_buy_date=candidate.date,
                )
            )
```

- [ ] **Step 5: Run test to verify it passes**

```bash
uv run pytest tests/engine/test_detector_v2_fields.py -v
```

- [ ] **Step 6: Update repository `_violation_to_row` to use the typed fields**

In `src/net_alpha/db/repository.py`, replace the temporary scaffolded `_violation_to_row` with one that takes account-id resolution:

```python
    def _violation_to_row(self, v: WashSaleViolation) -> WashSaleViolationRow:
        # account_id resolution by display string ("schwab/personal")
        with Session(self.engine) as s:
            la = self._account_id_for_display(s, v.loss_account)
            ba = self._account_id_for_display(s, v.buy_account)
            return WashSaleViolationRow(
                loss_trade_id=int(v.loss_trade_id),
                replacement_trade_id=int(v.replacement_trade_id),
                loss_account_id=la,
                buy_account_id=ba,
                loss_sale_date=v.loss_sale_date.isoformat(),
                triggering_buy_date=v.triggering_buy_date.isoformat(),
                confidence=v.confidence,
                disallowed_loss=v.disallowed_loss,
                matched_quantity=v.matched_quantity,
            )

    def _account_id_for_display(self, s: Session, display: str) -> int:
        broker, label = display.split("/", 1)
        row = s.exec(
            select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)
        ).first()
        if row is None:
            raise RuntimeError(f"no account row for {display!r}")
        return row.id
```

- [ ] **Step 7: Run all repo + engine tests**

```bash
uv run pytest tests/db tests/engine -q
```

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/models/domain.py src/net_alpha/engine/detector.py \
        src/net_alpha/db/repository.py tests/engine/test_detector_v2_fields.py
git commit -m "feat(engine): violations carry loss_account, buy_account, sale/buy dates"
```

---

## Task 10: Engine — `detect_in_window` for Incremental Recompute

**Files:**
- Modify: `src/net_alpha/engine/detector.py`
- Test: `tests/engine/test_detect_in_window.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/engine/test_detect_in_window.py
from datetime import date

from net_alpha.engine.detector import detect_in_window, detect_wash_sales
from net_alpha.models.domain import Trade


def _t(d, ticker, action, qty, proceeds=None, basis=None, account="schwab/personal"):
    return Trade(account=account, date=d, ticker=ticker, action=action, quantity=qty,
                 proceeds=proceeds, cost_basis=basis)


def test_detect_in_window_subsets_full_scan():
    trades = [
        _t(date(2024, 1, 1),  "TSLA", "Buy",  10, basis=2000),
        _t(date(2024, 6, 1),  "TSLA", "Sell", 10, proceeds=1500, basis=2000),  # loss
        _t(date(2024, 6, 5),  "TSLA", "Buy",  10, basis=1700),                  # triggers
        _t(date(2024, 12, 1), "AAPL", "Sell", 10, proceeds=500,  basis=1000),  # unrelated loss
    ]
    full = detect_wash_sales(trades, etf_pairs={})
    windowed = detect_in_window(trades, date(2024, 5, 1), date(2024, 7, 1), etf_pairs={})

    full_in_window = [v for v in full.violations if v.loss_sale_date and date(2024, 5, 1) <= v.loss_sale_date <= date(2024, 7, 1)]
    assert len(windowed.violations) == len(full_in_window)
    assert windowed.violations[0].confidence == "Confirmed"


def test_detect_in_window_excludes_loss_outside_window():
    trades = [
        _t(date(2024, 1, 1),  "TSLA", "Buy",  10, basis=2000),
        _t(date(2024, 6, 1),  "TSLA", "Sell", 10, proceeds=1500, basis=2000),
        _t(date(2024, 6, 5),  "TSLA", "Buy",  10, basis=1700),
    ]
    windowed = detect_in_window(trades, date(2024, 7, 2), date(2024, 8, 1), etf_pairs={})
    assert windowed.violations == []
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/engine/test_detect_in_window.py -v
```

- [ ] **Step 3: Add `detect_in_window` to `src/net_alpha/engine/detector.py`**

Append:

```python
from datetime import date as _date


def detect_in_window(
    trades: list[Trade],
    window_start: _date,
    window_end: _date,
    etf_pairs: dict[str, list[str]],
) -> DetectionResult:
    """Run the full detection algorithm but emit only violations whose
    loss_sale_date is within [window_start, window_end].

    `trades` MUST include all trades within ±30 days of [window_start, window_end]
    so cross-window matching is correct. The caller is responsible for that.
    """
    full = detect_wash_sales(trades, etf_pairs)
    in_window = [
        v for v in full.violations
        if v.loss_sale_date is not None
        and window_start <= v.loss_sale_date <= window_end
    ]
    # Lots are recomputed downstream from the full trade set, so we still return all.
    return DetectionResult(
        violations=in_window,
        lots=full.lots,
        basis_unknown_count=full.basis_unknown_count,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/engine/test_detect_in_window.py -v
```

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/detector.py tests/engine/test_detect_in_window.py
git commit -m "feat(engine): detect_in_window for incremental recompute"
```

---

## Task 11: Engine — `simulate_sell` What-If Planner

**Files:**
- Create: `src/net_alpha/engine/simulator.py`
- Test: `tests/engine/test_simulator.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/engine/test_simulator.py
from datetime import date
from decimal import Decimal

from net_alpha.engine.simulator import simulate_sell
from net_alpha.models.domain import Account, Lot, Trade


def _lot(account: str, date_, ticker, qty, basis):
    return Lot(trade_id="x", account=account, date=date_, ticker=ticker,
               quantity=qty, cost_basis=basis, adjusted_basis=basis)


def test_returns_one_option_per_holding_account():
    p = Account(id=1, broker="schwab", label="personal")
    r = Account(id=2, broker="schwab", label="roth")
    lots = [
        _lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 2000),
        _lot("schwab/roth",     date(2024, 9, 22), "TSLA", 10, 1500),
    ]
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p, r], existing_lots=lots, recent_trades=[])
    assert {o.account.label for o in options} == {"personal", "roth"}


def test_personal_option_realized_pnl_uses_personal_lots_only():
    p = Account(id=1, broker="schwab", label="personal")
    r = Account(id=2, broker="schwab", label="roth")
    lots = [
        _lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 2000),  # $200/share basis
        _lot("schwab/roth",     date(2024, 9, 22), "TSLA", 10, 1500),  # $150/share basis
    ]
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p, r], existing_lots=lots, recent_trades=[])
    by_label = {o.account.label: o for o in options}
    # Personal: 5 * (180 - 200) = -100
    assert by_label["personal"].realized_pnl == Decimal("-100")
    # Roth: 5 * (180 - 150) = 150
    assert by_label["roth"].realized_pnl == Decimal("150")


def test_loss_with_recent_buy_on_other_account_flags_wash_sale():
    p = Account(id=1, broker="schwab", label="personal")
    r = Account(id=2, broker="schwab", label="roth")
    lots = [_lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 2000)]
    recent_buy = Trade(
        account="schwab/roth", date=date(2024, 9, 22),
        ticker="TSLA", action="Buy", quantity=10, cost_basis=1500.0,
    )
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p, r], existing_lots=lots,
                            recent_trades=[recent_buy], today=date(2024, 9, 25))
    p_opt = next(o for o in options if o.account.label == "personal")
    assert p_opt.would_trigger_wash_sale is True
    assert p_opt.confidence == "Confirmed"


def test_insufficient_shares_marks_option_but_still_returns_it():
    p = Account(id=1, broker="schwab", label="personal")
    lots = [_lot("schwab/personal", date(2024, 8, 15), "TSLA", 3, 600)]
    options = simulate_sell("TSLA", Decimal("10"), Decimal("180"),
                            accounts=[p], existing_lots=lots, recent_trades=[])
    assert len(options) == 1
    assert options[0].insufficient_shares is True
    assert options[0].available_shares == Decimal("3")


def test_account_with_no_holdings_is_not_returned():
    p = Account(id=1, broker="schwab", label="personal")
    r = Account(id=2, broker="schwab", label="roth")
    lots = [_lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 2000)]
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p, r], existing_lots=lots, recent_trades=[])
    assert {o.account.label for o in options} == {"personal"}


def test_gain_skips_wash_sale_check():
    p = Account(id=1, broker="schwab", label="personal")
    lots = [_lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 1500)]  # basis below price
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p], existing_lots=lots, recent_trades=[])
    assert options[0].would_trigger_wash_sale is False
    assert options[0].confidence == "N/A"


def test_lookforward_block_until_set_when_loss():
    p = Account(id=1, broker="schwab", label="personal")
    lots = [_lot("schwab/personal", date(2024, 8, 15), "TSLA", 10, 2000)]
    options = simulate_sell("TSLA", Decimal("5"), Decimal("180"),
                            accounts=[p], existing_lots=lots, recent_trades=[],
                            today=date(2024, 10, 1))
    from datetime import timedelta
    assert options[0].lookforward_block_until == date(2024, 10, 1) + timedelta(days=30)
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/engine/test_simulator.py -v
```

- [ ] **Step 3: Implement `src/net_alpha/engine/simulator.py`**

```python
# src/net_alpha/engine/simulator.py
from __future__ import annotations

from datetime import date as _date, timedelta
from decimal import Decimal

from net_alpha.engine.matcher import get_match_confidence, is_within_wash_sale_window
from net_alpha.models.domain import (
    Account,
    LotConsumption,
    SimulationOption,
    Trade,
)


def simulate_sell(
    ticker: str,
    qty: Decimal,
    price: Decimal,
    accounts: list[Account],
    existing_lots,        # list[Lot]
    recent_trades: list[Trade],
    today: _date | None = None,
) -> list[SimulationOption]:
    """One option per account that holds the ticker. Cross-account wash-sale check."""
    today = today or _date.today()
    qty_f = float(qty)
    price_f = float(price)

    options: list[SimulationOption] = []
    for account in accounts:
        held = sorted(
            [l for l in existing_lots if l.account == account.display() and l.ticker == ticker],
            key=lambda l: l.date,
        )
        available = sum(l.quantity for l in held)
        if available <= 0:
            continue

        # FIFO consumption — up to qty_f or available
        target = min(qty_f, available)
        consumed: list[LotConsumption] = []
        realized = 0.0
        remaining = target
        for lot in held:
            if remaining <= 0:
                break
            take = min(remaining, lot.quantity)
            basis_per_share = (lot.adjusted_basis / lot.quantity) if lot.quantity else 0.0
            realized += take * (price_f - basis_per_share)
            consumed.append(
                LotConsumption(
                    lot_id=int(lot.id) if lot.id and lot.id.isdigit() else 0,
                    quantity=Decimal(str(take)),
                    basis_per_share=Decimal(str(round(basis_per_share, 4))),
                    purchase_date=lot.date,
                )
            )
            remaining -= take

        is_loss = realized < 0
        would_trigger = False
        confidence = "N/A"
        blocking: list[Trade] = []
        lookforward = None

        if is_loss:
            # Build a hypothetical loss-sale Trade for matcher compatibility
            hypo_sell = Trade(
                account=account.display(), date=today, ticker=ticker,
                action="Sell", quantity=qty_f, proceeds=qty_f * price_f,
                cost_basis=qty_f * (sum(c.quantity * c.basis_per_share for c in consumed) / Decimal(str(target)) if target else Decimal("0")).__float__() * 1.0
                if False else qty_f * price_f - realized,
            )
            for t in recent_trades:
                if t.id == hypo_sell.id:
                    continue
                if not is_within_wash_sale_window(today, t.date):
                    continue
                conf = get_match_confidence(hypo_sell, t, etf_pairs={})
                if conf is not None:
                    blocking.append(t)
                    if confidence == "N/A" or conf == "Confirmed":
                        confidence = conf
                    would_trigger = True
            lookforward = today + timedelta(days=30)

        options.append(
            SimulationOption(
                account=account,
                lots_consumed_fifo=consumed,
                realized_pnl=Decimal(str(round(realized, 2))),
                would_trigger_wash_sale=would_trigger,
                blocking_buys=blocking,
                lookforward_block_until=lookforward,
                confidence=confidence,
                insufficient_shares=qty_f > available,
                available_shares=Decimal(str(available)),
            )
        )

    return options
```

> **Note:** the messy `cost_basis` line is wrong on purpose — see fix in next step. Tests will catch it.

- [ ] **Step 4: Fix the `cost_basis` computation in the hypothetical sell**

Replace the `hypo_sell = Trade(...)` block with the cleaner version:

```python
            consumed_basis_total = sum(float(c.quantity) * float(c.basis_per_share) for c in consumed)
            hypo_sell = Trade(
                account=account.display(), date=today, ticker=ticker,
                action="Sell", quantity=target,
                proceeds=target * price_f,
                cost_basis=consumed_basis_total,
            )
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/engine/test_simulator.py -v
```

Expected: all 7 tests PASS. If any fail, iterate on the simulator until they do.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/engine/simulator.py tests/engine/test_simulator.py
git commit -m "feat(engine): simulate_sell — cross-account what-if planner"
```

---

## Task 12: Brokers — Protocol, Registry, Schwab Parser

**Files:**
- Create: `src/net_alpha/brokers/__init__.py` (empty)
- Create: `src/net_alpha/brokers/base.py`
- Create: `src/net_alpha/brokers/registry.py`
- Create: `src/net_alpha/brokers/schwab.py`
- Test: `tests/brokers/test_registry.py`
- Test: `tests/brokers/test_schwab.py`

- [ ] **Step 1: Inspect the v1 Schwab hardcoded schema for porting**

```bash
grep -n -i "schwab" src/net_alpha/import_/*.py
sed -n '1,200p' src/net_alpha/import_/importer.py
```

Note the column names Schwab uses (Date, Symbol, Action, Quantity, Amount, etc.). The new parser ports this exactly.

- [ ] **Step 2: Write failing tests for the registry**

```python
# tests/brokers/test_registry.py
import pytest

from net_alpha.brokers.registry import detect_broker
from net_alpha.brokers.schwab import SchwabParser


def test_detect_schwab_from_headers():
    headers = ["Date", "Action", "Symbol", "Description", "Quantity", "Price", "Amount"]
    parser = detect_broker(headers)
    assert isinstance(parser, SchwabParser)


def test_detect_returns_none_for_unknown_headers():
    headers = ["weird", "headers", "no", "broker", "matches"]
    assert detect_broker(headers) is None
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
uv run pytest tests/brokers/test_registry.py -v
```

- [ ] **Step 4: Create `src/net_alpha/brokers/base.py`**

```python
# src/net_alpha/brokers/base.py
from __future__ import annotations

from typing import Protocol

from net_alpha.models.domain import Trade


class BrokerParser(Protocol):
    name: str

    def detect(self, headers: list[str]) -> bool: ...
    def parse(self, rows: list[dict[str, str]], account_display: str) -> list[Trade]: ...
```

- [ ] **Step 5: Create `src/net_alpha/brokers/schwab.py`**

```python
# src/net_alpha/brokers/schwab.py
from __future__ import annotations

from datetime import datetime

from net_alpha.ingest.option_parser import parse_option_symbol
from net_alpha.models.domain import Trade


class SchwabParser:
    name = "schwab"
    REQUIRED_HEADERS = {"Date", "Action", "Symbol", "Quantity", "Amount"}

    def detect(self, headers: list[str]) -> bool:
        return self.REQUIRED_HEADERS.issubset(set(headers))

    def parse(self, rows: list[dict[str, str]], account_display: str) -> list[Trade]:
        trades: list[Trade] = []
        for i, row in enumerate(rows, start=1):
            action_raw = row["Action"].strip()
            if action_raw not in {"Buy", "Sell", "Reinvest Shares", "Buy to Open", "Sell to Close"}:
                continue
            action = "Buy" if action_raw in {"Buy", "Reinvest Shares", "Buy to Open"} else "Sell"

            try:
                trade_date = datetime.strptime(row["Date"].strip()[:10], "%m/%d/%Y").date()
            except ValueError as e:
                raise ValueError(f"Row {i}: 'Date' value {row['Date']!r} is not a valid date") from e

            symbol = row["Symbol"].strip()
            opt = parse_option_symbol(symbol)
            ticker = opt[0] if opt else symbol

            qty = float(row["Quantity"].replace(",", "").strip() or 0)
            amount = float(row["Amount"].replace("$", "").replace(",", "").strip() or 0)

            cost_basis = abs(amount) if action == "Buy" else None
            proceeds = abs(amount) if action == "Sell" else None

            trades.append(Trade(
                account=account_display,
                date=trade_date,
                ticker=ticker,
                action=action,
                quantity=qty,
                proceeds=proceeds,
                cost_basis=cost_basis,
                option_details=opt[1] if opt else None,
            ))
        return trades
```

- [ ] **Step 6: Create `src/net_alpha/brokers/registry.py`**

```python
# src/net_alpha/brokers/registry.py
from __future__ import annotations

from net_alpha.brokers.base import BrokerParser
from net_alpha.brokers.schwab import SchwabParser

PARSERS: list[BrokerParser] = [SchwabParser()]


def detect_broker(headers: list[str]) -> BrokerParser | None:
    for p in PARSERS:
        if p.detect(headers):
            return p
    return None
```

- [ ] **Step 7: Create `src/net_alpha/brokers/__init__.py` (empty)**

```bash
touch src/net_alpha/brokers/__init__.py
```

- [ ] **Step 8: Run registry tests to confirm they pass**

```bash
uv run pytest tests/brokers/test_registry.py -v
```

- [ ] **Step 9: Write a Schwab parser test from synthetic input**

```python
# tests/brokers/test_schwab.py
from datetime import date

from net_alpha.brokers.schwab import SchwabParser


def test_parses_simple_buy_and_sell():
    rows = [
        {"Date": "06/15/2024", "Action": "Buy", "Symbol": "TSLA",
         "Quantity": "10", "Price": "$200.00", "Amount": "$-2000.00"},
        {"Date": "08/01/2024", "Action": "Sell", "Symbol": "TSLA",
         "Quantity": "10", "Price": "$180.00", "Amount": "$1800.00"},
    ]
    trades = SchwabParser().parse(rows, account_display="schwab/personal")
    assert len(trades) == 2
    assert trades[0].action == "Buy"
    assert trades[0].cost_basis == 2000.0
    assert trades[0].date == date(2024, 6, 15)
    assert trades[1].action == "Sell"
    assert trades[1].proceeds == 1800.0


def test_skips_non_trade_rows():
    rows = [
        {"Date": "06/15/2024", "Action": "Cash Dividend", "Symbol": "TSLA",
         "Quantity": "", "Price": "", "Amount": "$25.00"},
    ]
    assert SchwabParser().parse(rows, account_display="schwab/personal") == []


def test_invalid_date_raises_with_row_number():
    rows = [{"Date": "13/40/9999", "Action": "Buy", "Symbol": "TSLA",
             "Quantity": "1", "Price": "1", "Amount": "$-1.00"}]
    import pytest
    with pytest.raises(ValueError, match="Row 1"):
        SchwabParser().parse(rows, account_display="schwab/personal")
```

- [ ] **Step 10: Run Schwab tests to confirm they pass**

```bash
uv run pytest tests/brokers/test_schwab.py -v
```

If `parse_option_symbol` doesn't exist yet (next task), the schwab module import will fail. Mark this as a known dependency: complete Task 13 (option_parser) immediately after if needed.

- [ ] **Step 11: Commit**

```bash
git add src/net_alpha/brokers tests/brokers
git commit -m "feat(brokers): protocol + registry + Schwab parser"
```

---

## Task 13: Ingest — CSV Loader, Option Parser, Dedup

**Files:**
- Create: `src/net_alpha/ingest/__init__.py` (empty)
- Create: `src/net_alpha/ingest/csv_loader.py`
- Create: `src/net_alpha/ingest/option_parser.py` (port from `src/net_alpha/import_/option_parser.py`)
- Create: `src/net_alpha/ingest/dedup.py`
- Test: `tests/ingest/test_csv_loader.py`
- Test: `tests/ingest/test_dedup.py`

- [ ] **Step 1: Port `option_parser.py` verbatim into `ingest/`**

```bash
mkdir -p src/net_alpha/ingest tests/ingest
cp src/net_alpha/import_/option_parser.py src/net_alpha/ingest/option_parser.py
touch src/net_alpha/ingest/__init__.py
```

Then update `src/net_alpha/ingest/option_parser.py`'s public function signature to **return** a `tuple[str, OptionDetails] | None` matching what `brokers/schwab.py` calls. If the v1 file already returns this, no change needed. Open and verify:

```bash
sed -n '1,40p' src/net_alpha/ingest/option_parser.py
```

If v1 returns just `OptionDetails`, refactor to also return the underlying ticker. Adjust the function to:

```python
def parse_option_symbol(symbol: str) -> tuple[str, "OptionDetails"] | None:
    """Returns (underlying_ticker, OptionDetails) or None if not an option symbol."""
    # ... existing regex cascade ...
    # Each branch returns (ticker, OptionDetails(...)) instead of bare OptionDetails
```

- [ ] **Step 2: Write failing test for csv_loader**

```python
# tests/ingest/test_csv_loader.py
from net_alpha.ingest.csv_loader import load_csv


def test_loads_headers_and_rows(tmp_path):
    p = tmp_path / "x.csv"
    p.write_text("Date,Action,Symbol\n06/15/2024,Buy,TSLA\n")
    headers, rows = load_csv(str(p))
    assert headers == ["Date", "Action", "Symbol"]
    assert rows == [{"Date": "06/15/2024", "Action": "Buy", "Symbol": "TSLA"}]


def test_csv_sha256_is_deterministic(tmp_path):
    from net_alpha.ingest.csv_loader import compute_csv_sha256
    p = tmp_path / "x.csv"
    p.write_text("a,b\n1,2\n")
    assert compute_csv_sha256(str(p)) == compute_csv_sha256(str(p))
```

- [ ] **Step 3: Run test — should fail**

```bash
uv run pytest tests/ingest/test_csv_loader.py -v
```

- [ ] **Step 4: Create `src/net_alpha/ingest/csv_loader.py`**

```python
# src/net_alpha/ingest/csv_loader.py
from __future__ import annotations

import csv
import hashlib


def load_csv(path: str) -> tuple[list[str], list[dict[str, str]]]:
    """Read a CSV from disk. Returns (headers, rows)."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = list(reader)
    return headers, rows


def compute_csv_sha256(path: str) -> str:
    """SHA256 of file contents — used for ImportRecord.csv_sha256 (informational)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(64 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
```

- [ ] **Step 5: Run csv_loader tests — pass**

```bash
uv run pytest tests/ingest/test_csv_loader.py -v
```

- [ ] **Step 6: Write failing dedup test**

```python
# tests/ingest/test_dedup.py
from datetime import date

from net_alpha.ingest.dedup import filter_new
from net_alpha.models.domain import Trade


def _t(qty=10):
    return Trade(account="schwab/personal", date=date(2024, 1, 1), ticker="TSLA",
                 action="Buy", quantity=qty, cost_basis=2000.0)


def test_filter_new_removes_known_keys():
    a, b = _t(10), _t(11)
    known = {a.compute_natural_key()}
    assert filter_new([a, b], known) == [b]


def test_filter_new_empty_known_returns_all():
    a, b = _t(10), _t(11)
    assert filter_new([a, b], set()) == [a, b]
```

- [ ] **Step 7: Run dedup test — fail**

```bash
uv run pytest tests/ingest/test_dedup.py -v
```

- [ ] **Step 8: Create `src/net_alpha/ingest/dedup.py`**

```python
# src/net_alpha/ingest/dedup.py
from __future__ import annotations

from net_alpha.models.domain import Trade


def filter_new(trades: list[Trade], known_natural_keys: set[str]) -> list[Trade]:
    return [t for t in trades if t.compute_natural_key() not in known_natural_keys]
```

- [ ] **Step 9: Run dedup test — pass**

```bash
uv run pytest tests/ingest/test_dedup.py -v
```

- [ ] **Step 10: Commit**

```bash
git add src/net_alpha/ingest tests/ingest
git commit -m "feat(ingest): csv_loader, option_parser port, dedup by natural_key"
```

---

## Task 14: Output — Disclaimer, Watch List, YTD Impact, Sim Result, Imports Table

**Files:**
- Create: `src/net_alpha/output/__init__.py` (empty)
- Create: `src/net_alpha/output/disclaimer.py`
- Create: `src/net_alpha/output/watch_list.py`
- Create: `src/net_alpha/output/ytd_impact.py`
- Create: `src/net_alpha/output/sim_result.py`
- Create: `src/net_alpha/output/imports_table.py`
- Create: `src/net_alpha/output/detail.py`
- Test: `tests/output/test_renderers.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/output/test_renderers.py
from datetime import date, datetime
from decimal import Decimal

from net_alpha.models.domain import (
    Account,
    ImportSummary,
    SimulationOption,
    WashSaleViolation,
)


def test_disclaimer_render_returns_required_string():
    from net_alpha.output.disclaimer import render
    assert "informational" in render().lower()
    assert "tax professional" in render().lower()


def test_watch_list_renders_violations_and_open_windows():
    from net_alpha.output.watch_list import render
    v = WashSaleViolation(
        loss_trade_id="1", replacement_trade_id="2",
        confidence="Confirmed", disallowed_loss=1243.0, matched_quantity=10,
        loss_account="schwab/personal", buy_account="schwab/roth",
        loss_sale_date=date(2024, 9, 15), triggering_buy_date=date(2024, 9, 22),
    )
    out = render(lots=[], violations=[v], today=date(2024, 9, 30))
    assert "TSLA" in out or "TRIGGERED" in out


def test_ytd_impact_renders_total_and_count():
    from net_alpha.output.ytd_impact import render
    v = WashSaleViolation(
        loss_trade_id="1", replacement_trade_id="2",
        confidence="Confirmed", disallowed_loss=1243.0, matched_quantity=10,
        loss_account="schwab/personal", buy_account="schwab/roth",
        loss_sale_date=date(2024, 9, 15), triggering_buy_date=date(2024, 9, 22),
    )
    out = render(violations=[v], year=2024)
    assert "1,243" in out or "1243" in out
    assert "2024" in out


def test_sim_result_renders_one_section_per_option():
    from net_alpha.output.sim_result import render
    p = Account(id=1, broker="schwab", label="personal")
    r = Account(id=2, broker="schwab", label="roth")
    options = [
        SimulationOption(account=p, lots_consumed_fifo=[], realized_pnl=Decimal("-150"),
                         would_trigger_wash_sale=True, blocking_buys=[],
                         lookforward_block_until=None, confidence="Confirmed",
                         insufficient_shares=False, available_shares=Decimal("10")),
        SimulationOption(account=r, lots_consumed_fifo=[], realized_pnl=Decimal("300"),
                         would_trigger_wash_sale=False, blocking_buys=[],
                         lookforward_block_until=None, confidence="N/A",
                         insufficient_shares=False, available_shares=Decimal("10")),
    ]
    out = render(ticker="TSLA", qty=Decimal("10"), price=Decimal("180"), options=options)
    assert "OPTION A" in out and "OPTION B" in out
    assert "schwab/personal" in out and "schwab/roth" in out


def test_imports_table_renders_one_row_per_summary():
    from net_alpha.output.imports_table import render
    s = ImportSummary(id=1, account_display="schwab/personal", csv_filename="q1.csv",
                      trade_count=412, imported_at=datetime(2026, 4, 25, 10, 0))
    out = render([s])
    assert "q1.csv" in out and "412" in out and "schwab/personal" in out
```

- [ ] **Step 2: Run tests — fail (modules don't exist)**

```bash
uv run pytest tests/output -v
```

- [ ] **Step 3: Create the renderers**

```bash
mkdir -p src/net_alpha/output tests/output
touch src/net_alpha/output/__init__.py
```

`src/net_alpha/output/disclaimer.py`:

```python
def render() -> str:
    return "⚠ This is informational only. Consult a tax professional before filing."
```

`src/net_alpha/output/watch_list.py`:

```python
from __future__ import annotations

from datetime import date, timedelta


def render(lots, violations, today: date) -> str:
    lines = ["WATCH LIST — active rebuy windows", "─" * 33]
    if not violations and not lots:
        lines.append("(no active violations or open lots)")
        return "\n".join(lines)

    for v in violations:
        if v.triggering_buy_date and v.triggering_buy_date >= today - timedelta(days=30):
            lines.append(
                f"🔴 {_ticker_for_violation(v)}   wash sale TRIGGERED on {v.loss_sale_date} "
                f"({_ticker_for_violation(v)} buy on {v.triggering_buy_date})"
            )
            lines.append(
                f"          ${v.disallowed_loss:,.0f} loss disallowed → rolled into "
                f"{v.triggering_buy_date} lot"
            )
    return "\n".join(lines)


def _ticker_for_violation(v) -> str:
    # Tickers aren't on the violation row; for v2.0 we render dates and amounts only.
    # Future enhancement: join through trade rows in the renderer's caller.
    return "TKR"
```

`src/net_alpha/output/ytd_impact.py`:

```python
def render(violations, year: int) -> str:
    if not violations:
        return f"YEAR-TO-DATE IMPACT\n{'─' * 19}\nNo wash sales detected in {year}."

    total = sum(v.disallowed_loss for v in violations)
    counts: dict[str, int] = {}
    for v in violations:
        counts[v.confidence] = counts.get(v.confidence, 0) + 1
    breakdown = ", ".join(f"{n} {c}" for c, n in counts.items())
    return (
        f"YEAR-TO-DATE IMPACT\n{'─' * 19}\n"
        f"${total:,.0f} disallowed across {len(violations)} wash sales ({breakdown}) — {year}"
    )
```

`src/net_alpha/output/sim_result.py`:

```python
from decimal import Decimal


def render(ticker: str, qty: Decimal, price: Decimal, options) -> str:
    lines = [f"SIMULATING: sell {qty} {ticker} @ ${price}"]
    for i, opt in enumerate(options):
        letter = chr(ord("A") + i)
        lines.append("")
        lines.append(f"OPTION {letter} — sell from '{opt.account.display()}' (FIFO)")
        if opt.insufficient_shares:
            lines.append(f"  ⚠ insufficient shares — only {opt.available_shares} held")
        for c in opt.lots_consumed_fifo:
            lines.append(f"  Lot consumed: {c.quantity} @ ${c.basis_per_share} ({c.purchase_date})")
        sign = "+" if opt.realized_pnl >= 0 else ""
        lines.append(f"  Realized P&L: {sign}${opt.realized_pnl}")
        if opt.would_trigger_wash_sale:
            lines.append(f"  Wash sale:    🔴 TRIGGERED — confidence {opt.confidence}")
        else:
            lines.append("  Wash sale:    N/A")
    return "\n".join(lines)
```

`src/net_alpha/output/imports_table.py`:

```python
def render(summaries) -> str:
    if not summaries:
        return "(no imports)"
    lines = [f"{'id':>3} {'account':<20} {'file':<30} {'trades':>7}  imported"]
    lines.append("-" * 70)
    for s in summaries:
        lines.append(
            f"{s.id:>3} {s.account_display:<20} {s.csv_filename:<30} "
            f"{s.trade_count:>7}  {s.imported_at.date()}"
        )
    return "\n".join(lines)
```

`src/net_alpha/output/detail.py`:

```python
def render(violations) -> str:
    if not violations:
        return "(no violations)"
    lines = ["DETAIL — per-violation breakdown", "─" * 32]
    for v in violations:
        lines.append(
            f"{v.loss_sale_date} loss in {v.loss_account} → buy in {v.buy_account} "
            f"on {v.triggering_buy_date}: ${v.disallowed_loss:,.0f} disallowed "
            f"({v.matched_quantity} units, {v.confidence})"
        )
    return "\n".join(lines)
```

- [ ] **Step 4: Run tests — pass**

```bash
uv run pytest tests/output -v
```

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/output tests/output
git commit -m "feat(output): renderers — disclaimer, watch_list, ytd_impact, sim_result, imports_table, detail"
```

---

## Task 15: CLI — App Skeleton + Default + Sim + Imports

**Files:**
- Modify: `src/net_alpha/cli/app.py` (rewrite)
- Create: `src/net_alpha/cli/default.py`
- Create: `src/net_alpha/cli/sim.py`
- Create: `src/net_alpha/cli/imports.py`
- Test: `tests/cli/test_app_v2.py`

- [ ] **Step 1: Write failing CLI integration tests**

```python
# tests/cli/test_app_v2.py
import os

import pytest
from typer.testing import CliRunner


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    yield


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=False)


@pytest.fixture
def schwab_csv(tmp_path):
    p = tmp_path / "schwab.csv"
    p.write_text(
        "Date,Action,Symbol,Quantity,Price,Amount\n"
        "06/15/2024,Buy,TSLA,10,$200.00,$-2000.00\n"
        "08/01/2024,Sell,TSLA,10,$180.00,$1800.00\n"
        "08/10/2024,Buy,TSLA,10,$170.00,$-1700.00\n"
    )
    return str(p)


def test_default_command_imports_and_renders(runner, schwab_csv):
    from net_alpha.cli.app import app
    res = runner.invoke(app, [schwab_csv, "--account", "personal"])
    assert res.exit_code == 0, res.stdout + res.stderr
    assert "Imported" in res.stdout
    assert "informational" in res.stdout.lower()


def test_default_requires_account(runner, schwab_csv):
    from net_alpha.cli.app import app
    res = runner.invoke(app, [schwab_csv])
    assert res.exit_code != 0


def test_imports_subcommand_lists_one_row(runner, schwab_csv):
    from net_alpha.cli.app import app
    runner.invoke(app, [schwab_csv, "--account", "personal"])
    res = runner.invoke(app, ["imports"])
    assert res.exit_code == 0
    assert "schwab.csv" in res.stdout


def test_unsupported_broker_exits_2(runner, tmp_path):
    from net_alpha.cli.app import app
    bad = tmp_path / "weird.csv"
    bad.write_text("foo,bar\n1,2\n")
    res = runner.invoke(app, [str(bad), "--account", "x"])
    assert res.exit_code == 2


def test_double_import_reports_duplicates(runner, schwab_csv):
    from net_alpha.cli.app import app
    runner.invoke(app, [schwab_csv, "--account", "personal"])
    res = runner.invoke(app, [schwab_csv, "--account", "personal"])
    assert res.exit_code == 0
    assert "0 new" in res.stdout or "duplicates" in res.stdout
```

- [ ] **Step 2: Run tests — fail**

```bash
uv run pytest tests/cli/test_app_v2.py -v
```

- [ ] **Step 3: Create `src/net_alpha/cli/default.py`**

```python
# src/net_alpha/cli/default.py
from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path

import typer
from sqlmodel import SQLModel, create_engine

from net_alpha.brokers.registry import detect_broker
from net_alpha.db.repository import Repository
from net_alpha.engine.detector import detect_in_window
from net_alpha.ingest.csv_loader import compute_csv_sha256, load_csv
from net_alpha.ingest.dedup import filter_new
from net_alpha.models.domain import ImportRecord
from net_alpha.output import disclaimer, watch_list, ytd_impact


def _engine():
    home = Path.home() / ".net_alpha"
    home.mkdir(parents=True, exist_ok=True)
    eng = create_engine(f"sqlite:///{home / 'net_alpha.db'}")
    SQLModel.metadata.create_all(eng)
    return eng


def run(csv_paths: list[str], account_label: str, detail: bool = False) -> int:
    repo = Repository(_engine())

    all_new_trades = []
    for csv_path in csv_paths:
        headers, rows = load_csv(csv_path)
        parser = detect_broker(headers)
        if parser is None:
            typer.echo(
                f"Error: Could not detect broker from CSV headers in {csv_path}.\n"
                f"       Supported brokers: schwab\n"
                f"       To request support: open an issue with an anonymized sample.",
                err=True,
            )
            return 2

        account = repo.get_or_create_account(parser.name, account_label)
        try:
            trades = parser.parse(rows, account_display=account.display())
        except ValueError as e:
            typer.echo(f"Error: {e}", err=True)
            return 3

        existing = repo.existing_natural_keys(account.id)
        new = filter_new(trades, existing)
        rec = ImportRecord(
            account_id=account.id,
            csv_filename=Path(csv_path).name,
            csv_sha256=compute_csv_sha256(csv_path),
            imported_at=datetime.now(),
            trade_count=0,
        )
        result = repo.add_import(account, rec, new)
        dup_count = len(trades) - len(new)
        typer.echo(
            f"Detected broker: {parser.name}\n"
            f"Imported {result.new_trades} new trades into account "
            f"'{account.display()}' ({dup_count} duplicates skipped)."
        )
        all_new_trades.extend(new)

    # Recompute over the affected window
    if all_new_trades:
        win_start = min(t.date for t in all_new_trades) - timedelta(days=30)
        win_end = max(t.date for t in all_new_trades) + timedelta(days=30)
        window_trades = repo.trades_in_window(win_start, win_end)
        new_violations = detect_in_window(window_trades, win_start, win_end, etf_pairs={}).violations
        repo.replace_violations_in_window(win_start, win_end, new_violations)

    today = date.today()
    typer.echo("")
    typer.echo(watch_list.render(repo.all_lots(), repo.all_violations(), today=today))
    typer.echo("")
    typer.echo(ytd_impact.render(repo.violations_for_year(today.year), year=today.year))
    if detail:
        from net_alpha.output import detail as detail_mod
        typer.echo("")
        typer.echo(detail_mod.render(repo.all_violations()))
    typer.echo("")
    typer.echo(disclaimer.render())
    return 0
```

> **Note:** `etf_pairs={}` is a stub — Task 17 wires the YAML loader.

- [ ] **Step 4: Create `src/net_alpha/cli/sim.py`**

```python
# src/net_alpha/cli/sim.py
from __future__ import annotations

from decimal import Decimal

import typer
from sqlmodel import SQLModel, create_engine

from net_alpha.cli.default import _engine
from net_alpha.db.repository import Repository
from net_alpha.engine.simulator import simulate_sell
from net_alpha.output import disclaimer, sim_result


def run(ticker: str, qty: Decimal, price: Decimal, account_label: str | None) -> int:
    repo = Repository(_engine())
    accounts = repo.list_accounts()
    if account_label:
        accounts = [a for a in accounts if a.label == account_label]
        if not accounts:
            typer.echo(f"Error: account schwab/{account_label} does not exist.", err=True)
            return 6

    options = simulate_sell(
        ticker=ticker, qty=qty, price=price,
        accounts=accounts,
        existing_lots=repo.all_lots(),
        recent_trades=repo.all_trades(),
    )
    if not options:
        typer.echo(f"Error: no holdings of {ticker}.", err=True)
        return 6

    typer.echo(sim_result.render(ticker, qty, price, options))
    typer.echo("")
    typer.echo(disclaimer.render())
    return 0
```

- [ ] **Step 5: Create `src/net_alpha/cli/imports.py`**

```python
# src/net_alpha/cli/imports.py
from __future__ import annotations

from datetime import timedelta

import typer

from net_alpha.cli.default import _engine
from net_alpha.db.repository import Repository
from net_alpha.engine.detector import detect_in_window
from net_alpha.output.imports_table import render as render_table


def list_cmd() -> int:
    repo = Repository(_engine())
    typer.echo(render_table(repo.list_imports()))
    return 0


def remove_cmd(import_id: int, yes: bool) -> int:
    repo = Repository(_engine())
    if repo.get_import(import_id) is None:
        typer.echo(f"Error: no import with id {import_id}. Run `net-alpha imports` to list.", err=True)
        return 5
    if not yes:
        confirm = typer.confirm(f"Remove import #{import_id}?")
        if not confirm:
            return 0
    result = repo.remove_import(import_id)
    typer.echo(f"Removed import #{import_id} ({result.removed_trade_count} trades).")

    if result.recompute_window is not None:
        win_start, win_end = result.recompute_window
        window_trades = repo.trades_in_window(win_start, win_end)
        new_violations = detect_in_window(window_trades, win_start, win_end, etf_pairs={}).violations
        repo.replace_violations_in_window(win_start, win_end, new_violations)
        typer.echo("Recomputed wash sales over affected window.")
    return 0
```

- [ ] **Step 6: Rewrite `src/net_alpha/cli/app.py`**

```python
# src/net_alpha/cli/app.py
from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import typer

from net_alpha.cli import default as default_cmd
from net_alpha.cli import imports as imports_cmd
from net_alpha.cli import sim as sim_cmd

app = typer.Typer(no_args_is_help=True, add_completion=False)
imports_app = typer.Typer(no_args_is_help=True)
app.add_typer(imports_app, name="imports", help="List or remove past imports.")


@app.command(name="sim", help="Simulate a hypothetical sell.")
def sim(
    ticker: str,
    qty: Decimal,
    price: Decimal = typer.Option(..., "--price", help="Sell price per share"),
    account: str | None = typer.Option(None, "--account", help="Restrict to one account label"),
):
    raise typer.Exit(sim_cmd.run(ticker, qty, price, account))


@imports_app.command(name="list", help="List past imports.")
def imports_list():
    raise typer.Exit(imports_cmd.list_cmd())


@imports_app.callback(invoke_without_command=True)
def imports_default(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        raise typer.Exit(imports_cmd.list_cmd())


@imports_app.command(name="rm", help="Remove a past import by id.")
def imports_rm(
    import_id: int,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    raise typer.Exit(imports_cmd.remove_cmd(import_id, yes))


# The default command is bound to the app callback so `net-alpha file.csv` works.
@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    csv_paths: list[Path] = typer.Argument(None, help="One or more broker CSV files"),
    account: str = typer.Option(None, "--account", help="Required: account label"),
    detail: bool = typer.Option(False, "--detail", help="Show per-violation breakdown"),
):
    if ctx.invoked_subcommand is not None:
        return
    if not csv_paths:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)
    if not account:
        typer.echo(
            "Error: --account is required for new imports.\n"
            "       Pass --account <label> to identify which account this CSV belongs to.\n"
            "       Example: net-alpha schwab.csv --account personal",
            err=True,
        )
        raise typer.Exit(2)
    raise typer.Exit(default_cmd.run([str(p) for p in csv_paths], account, detail=detail))


def main():
    app()
```

- [ ] **Step 7: Run CLI tests — pass**

```bash
uv run pytest tests/cli/test_app_v2.py -v
```

If any test fails, iterate on the CLI handlers until green.

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/cli tests/cli/test_app_v2.py
git commit -m "feat(cli): v2 surface — default import/check, sim, imports, imports rm"
```

---

## Task 16: Wire ETF Pairs Loader into Default + Sim

**Files:**
- Modify: `src/net_alpha/cli/default.py`
- Modify: `src/net_alpha/cli/sim.py`
- Move: `etf_pairs.yaml` from repo root to `src/net_alpha/etf_pairs.yaml`
- Modify: `src/net_alpha/engine/etf_pairs.py` (point loader at packaged path)
- Test: `tests/engine/test_etf_pairs_loader.py`

- [ ] **Step 1: Move bundled YAML inside the package**

```bash
git mv etf_pairs.yaml src/net_alpha/etf_pairs.yaml
```

- [ ] **Step 2: Inspect the existing loader**

```bash
cat src/net_alpha/engine/etf_pairs.py
```

- [ ] **Step 3: Write failing test**

```python
# tests/engine/test_etf_pairs_loader.py
from net_alpha.engine.etf_pairs import load_etf_pairs


def test_load_etf_pairs_returns_known_groups():
    pairs = load_etf_pairs()
    flat = {t for group in pairs.values() for t in group}
    assert "SPY" in flat
    assert "VOO" in flat
```

- [ ] **Step 4: Run test — may already pass if loader uses package path; otherwise update**

```bash
uv run pytest tests/engine/test_etf_pairs_loader.py -v
```

If it fails because the loader looked at the repo root, update `etf_pairs.py` to use `importlib.resources`:

```python
from __future__ import annotations
import importlib.resources as resources
import yaml


def load_etf_pairs(user_path: str | None = None) -> dict[str, list[str]]:
    bundled = resources.files("net_alpha").joinpath("etf_pairs.yaml").read_text()
    pairs = yaml.safe_load(bundled) or {}
    if user_path:
        from pathlib import Path
        p = Path(user_path)
        if p.exists():
            user = yaml.safe_load(p.read_text()) or {}
            for k, v in user.items():
                pairs.setdefault(k, []).extend(v)
    return pairs
```

- [ ] **Step 5: Pass `etf_pairs` to detector calls in CLI**

In `src/net_alpha/cli/default.py`, replace the two `etf_pairs={}` calls with:

```python
from net_alpha.engine.etf_pairs import load_etf_pairs
from pathlib import Path
ETF_PAIRS = load_etf_pairs(user_path=str(Path.home() / ".net_alpha" / "etf_pairs.yaml"))
```

…and use `etf_pairs=ETF_PAIRS` at both call sites. Same fix in `src/net_alpha/cli/imports.py`.

- [ ] **Step 6: Update `pyproject.toml` to package the YAML**

In `pyproject.toml`, ensure the wheel target includes the YAML. With Hatchling, package data is included by default for files inside the package. No edit needed if it's at `src/net_alpha/etf_pairs.yaml`. Verify:

```bash
uv build --wheel
unzip -l dist/wash_alpha-0.9.1-*.whl | grep etf_pairs
```

Expected: shows `net_alpha/etf_pairs.yaml`.

- [ ] **Step 7: Run all tests**

```bash
uv run pytest -q
```

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/etf_pairs.yaml src/net_alpha/engine/etf_pairs.py \
        src/net_alpha/cli/default.py src/net_alpha/cli/imports.py \
        tests/engine/test_etf_pairs_loader.py
git rm etf_pairs.yaml 2>/dev/null || true
git commit -m "chore: move etf_pairs.yaml into package, wire loader through CLI"
```

---

## Task 17: Migration Helper — `migrate-from-v1`

**Files:**
- Create: `src/net_alpha/cli/migrate.py`
- Modify: `src/net_alpha/cli/app.py` (register command)
- Test: `tests/cli/test_migrate.py`

- [ ] **Step 1: Write failing test**

```python
# tests/cli/test_migrate.py
import sqlite3
from pathlib import Path

import pytest
from typer.testing import CliRunner


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    yield


def test_migrate_from_v1_imports_v1_trades(tmp_path):
    # Build a minimal v1 DB with one trade
    v1_path = tmp_path / ".net_alpha" / "net_alpha.db"
    v1_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(v1_path))
    con.execute("CREATE TABLE trades (id TEXT, account TEXT, date TEXT, ticker TEXT, "
                "action TEXT, quantity REAL, proceeds REAL, cost_basis REAL)")
    con.execute(
        "INSERT INTO trades VALUES ('u1', 'schwab', '2024-06-15', 'TSLA', 'Buy', 10, NULL, 2000.0)"
    )
    con.commit()
    con.close()

    from net_alpha.cli.app import app
    res = CliRunner(mix_stderr=False).invoke(app, ["migrate-from-v1", "--yes"])
    assert res.exit_code == 0, res.stdout + res.stderr
    assert "Migrated" in res.stdout

    # Confirm v2 DB exists and has the trade
    v2_path = tmp_path / ".net_alpha" / "net_alpha.db.v2"
    assert v2_path.exists()
    con2 = sqlite3.connect(str(v2_path))
    n = con2.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
    assert n == 1
```

- [ ] **Step 2: Run test — fail**

```bash
uv run pytest tests/cli/test_migrate.py -v
```

- [ ] **Step 3: Create `src/net_alpha/cli/migrate.py`**

```python
# src/net_alpha/cli/migrate.py
from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path

import typer
from sqlmodel import SQLModel, create_engine

from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord, Trade


def run(yes: bool) -> int:
    home = Path.home() / ".net_alpha"
    v1 = home / "net_alpha.db"
    v2 = home / "net_alpha.db.v2"
    if not v1.exists():
        typer.echo(f"No v1 DB found at {v1}.", err=True)
        return 1
    if v2.exists():
        typer.echo(f"v2 DB already exists at {v2}. Refusing to overwrite.", err=True)
        return 1
    if not yes:
        if not typer.confirm(f"Migrate v1 DB at {v1} into a new v2 DB at {v2}?"):
            return 0

    con = sqlite3.connect(str(v1))
    rows = con.execute(
        "SELECT account, date, ticker, action, quantity, proceeds, cost_basis FROM trades"
    ).fetchall()
    con.close()

    eng = create_engine(f"sqlite:///{v2}")
    SQLModel.metadata.create_all(eng)
    repo = Repository(eng)
    account = repo.get_or_create_account("schwab", "default")
    record = ImportRecord(
        account_id=account.id,
        csv_filename="(migrated from v1)",
        csv_sha256="",
        imported_at=datetime.now(),
        trade_count=0,
    )
    trades = []
    for acct, d, ticker, action, qty, proceeds, basis in rows:
        trades.append(Trade(
            account=account.display(),
            date=date.fromisoformat(d),
            ticker=ticker,
            action=action,
            quantity=qty,
            proceeds=proceeds,
            cost_basis=basis,
        ))
    result = repo.add_import(account, record, trades)
    typer.echo(
        f"Migrated {result.new_trades} trades from {v1} into {v2}.\n"
        f"To use the new DB, move it into place:\n"
        f"  mv {v1} {v1}.v1.bak && mv {v2} {v1}"
    )
    return 0
```

- [ ] **Step 4: Register the command in `src/net_alpha/cli/app.py`**

Append:

```python
from net_alpha.cli import migrate as migrate_cmd


@app.command(name="migrate-from-v1", help="One-shot migration of v1 DB into v2 schema.")
def migrate_from_v1(yes: bool = typer.Option(False, "--yes", "-y")):
    raise typer.Exit(migrate_cmd.run(yes))
```

- [ ] **Step 5: Run test — pass**

```bash
uv run pytest tests/cli/test_migrate.py -v
```

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/migrate.py src/net_alpha/cli/app.py tests/cli/test_migrate.py
git commit -m "feat(cli): migrate-from-v1 helper (v2.0.x only)"
```

---

## Task 18: Delete Legacy `import_/` and `import_cmd`, Plus Stale v1 Models

**Files:**
- Delete: `src/net_alpha/import_/` (entire package)
- Delete: `src/net_alpha/cli/import_cmd.py`
- Delete: `src/net_alpha/cli/simulate.py` (replaced by `cli/sim.py`)
- Modify: `src/net_alpha/models/domain.py` (delete unused TaxPosition / LotSelection / LotRecommendation / RealizedPair / OpenLot / AllocationResult)
- Modify: `src/net_alpha/engine/tax_position.py` (delete or trim)
- Delete: any tests targeting deleted modules

- [ ] **Step 1: Identify references to legacy modules**

```bash
grep -rn "net_alpha.import_" src/ tests/
grep -rn "net_alpha.cli.import_cmd" src/ tests/
grep -rn "net_alpha.cli.simulate" src/ tests/
grep -rn "TaxPosition\|LotSelection\|LotRecommendation\|RealizedPair\|OpenLot\|AllocationResult" src/ tests/
```

- [ ] **Step 2: Delete the legacy source files**

```bash
rm -rf src/net_alpha/import_
rm src/net_alpha/cli/import_cmd.py
rm -f src/net_alpha/cli/simulate.py
```

If `engine/tax_position.py` is no longer referenced (the `tax-position` CLI was removed in Task 1), delete it:

```bash
rm src/net_alpha/engine/tax_position.py
```

- [ ] **Step 3: Strip unused models from `models/domain.py`**

Open `src/net_alpha/models/domain.py`. Delete the classes `TaxPosition`, `LotSelection`, `LotRecommendation`, `RealizedPair`, `OpenLot`, `AllocationResult` if grep showed no remaining references in v2 source.

- [ ] **Step 4: Delete corresponding tests**

```bash
rm -rf tests/import_
rm -f tests/engine/test_tax_position*.py tests/cli/test_import_cmd*.py tests/cli/test_simulate*.py
```

- [ ] **Step 5: Confirm clean import**

```bash
uv run python -c "import net_alpha.cli.app; print('ok')"
```

- [ ] **Step 6: Full test run**

```bash
uv run pytest -q
```

Expected: all tests pass.

- [ ] **Step 7: Commit**

```bash
git add -A
git commit -m "chore(v2): delete legacy import_/, import_cmd, simulate, unused models"
```

---

## Task 19: Update `pyproject.toml` — Drop Removed Deps + Bump to 2.0.0

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Read current pyproject.toml**

```bash
cat pyproject.toml
```

- [ ] **Step 2: Edit the `[project]` block**

Replace the `dependencies` and `version` sections:

```toml
version = "2.0.0"
description = "Cross-account wash sale detection — Schwab CSV, options, ETFs (v2 simplified)"
dependencies = [
    "pydantic>=2.0",
    "sqlmodel>=0.0.16",
    "typer[all]>=0.12",
    "loguru>=0.7",
    "pyyaml>=6.0",
]
```

(Removed: `questionary`, `anthropic`, `pydantic-settings`, `textual`.)

- [ ] **Step 3: Re-resolve the lockfile**

```bash
uv sync
```

- [ ] **Step 4: Run all tests**

```bash
uv run pytest -q
```

- [ ] **Step 5: Run lint**

```bash
uv run ruff check .
uv run ruff format .
```

Fix any reported issues inline.

- [ ] **Step 6: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "chore(deps): drop questionary, anthropic, pydantic-settings, textual; bump to 2.0.0"
```

---

## Task 20: Update README, CLAUDE.md, AGENTS.md to Reflect v2

**Files:**
- Modify: `README.md`
- Modify: `CLAUDE.md`
- Modify: `AGENTS.md`

- [ ] **Step 1: Rewrite the README usage section**

Open `README.md`. Replace any section referencing `import`, `check`, `tui`, `agent`, `wizard`, `report`, `rebuys`, `tax-position`, `status` commands with the v2 surface:

```markdown
## 💻 Usage

### Import + check (the only command you usually run)

```bash
net-alpha schwab.csv --account personal
```

This imports the CSV, recomputes wash sales over the affected window, and prints a watch list plus a year-to-date impact summary.

### Pre-trade simulation

```bash
net-alpha sim TSLA 10 --price 180
```

Lists every account that holds the ticker, with FIFO lot consumption, realized P&L, and a cross-account wash-sale verdict per option.

### Manage past imports

```bash
net-alpha imports         # list
net-alpha imports rm 3    # remove an import (recomputes wash sales)
```
```

Remove the "AI-powered import" / "natural-language agent" / "interactive TUI" sections — these are gone in v2.

- [ ] **Step 2: Update the broker support section**

Replace whatever existed with:

> **Supported brokers (v2.0):** Schwab. Other brokers can be added by contributing a parser at `src/net_alpha/brokers/<name>.py`.

- [ ] **Step 3: Update CLAUDE.md tech stack section**

Open `CLAUDE.md`. Remove `anthropic`, `questionary`, `pydantic-settings`, `textual` from the deps list. Update the CLI commands listing to the v2 surface (4 commands).

- [ ] **Step 4: Update AGENTS.md**

Same edits as CLAUDE.md (commands listing, dep list).

- [ ] **Step 5: Commit**

```bash
git add README.md CLAUDE.md AGENTS.md
git commit -m "docs: rewrite README, CLAUDE.md, AGENTS.md for v2 surface"
```

---

## Task 21: Final Verification + Coverage Check

**Files:** none new — verification only.

- [ ] **Step 1: Full test suite with coverage**

```bash
uv run pytest --cov=net_alpha --cov-report=term-missing
```

Expected: all tests pass; engine package at or near 100% coverage; overall ≥90%.

- [ ] **Step 2: Lint + format**

```bash
uv run ruff check .
uv run ruff format --check .
```

Expected: no errors.

- [ ] **Step 3: Smoke test against a real CSV**

If a sample Schwab CSV is available in `tests/fixtures/`:

```bash
uv run net-alpha tests/fixtures/schwab_sample.csv --account smoke
uv run net-alpha imports
uv run net-alpha sim TSLA 1 --price 200
uv run net-alpha imports rm 1 --yes
```

Expected: each command exits 0 with sensible output.

- [ ] **Step 4: Confirm package builds**

```bash
uv build
ls dist/
```

Expected: `wash_alpha-2.0.0-*.whl` and `wash-alpha-2.0.0.tar.gz` are produced.

- [ ] **Step 5: Confirm no v1 leftovers**

```bash
ls src/net_alpha/
```

Expected directories: `brokers/`, `cli/`, `db/`, `engine/`, `ingest/`, `models/`, `output/`. (No `tui/`, `agent/`, `import_/`.)

- [ ] **Step 6: Final commit if any whitespace/lint fixes applied**

```bash
git status --short
git add -A
git commit -m "chore: final v2 verification — lint clean, coverage targets met" || true
```

- [ ] **Step 7: Push v2 branch**

```bash
git push -u origin v2
```

(Confirm with the user before pushing if this would be visible to anyone else.)

---

## Self-Review Notes

After writing this plan I checked it against the spec:

- **§3 surface (4 commands):** Tasks 15 and 17.
- **§4 architecture (new packages, removed packages):** Tasks 1, 12, 13, 14, 18.
- **§5 schema (Account, ImportRecord, Trade FKs, natural_key):** Tasks 2, 3, 4.
- **§5 repository interface (every method):** Tasks 5, 6, 7, 8.
- **§6.1 default flow (incremental recompute, transactional):** Task 15.
- **§6.2 detect_in_window correctness:** Task 10.
- **§6.3 natural_key idempotency:** Task 4.
- **§6.4 sim flow (cross-account, account-filtered):** Tasks 11, 15.
- **§6.5 imports rm with windowed recompute:** Task 15.
- **§7 error handling (exit codes 2/3/4/5/6):** Tasks 12 (broker detect), 15 (CLI surface), 17 (migrate).
- **§8 testing strategy (engine 100%, golden, repo, CLI integration):** Tasks 5–11, 12, 13, 15, 21.
- **§9 v1 → v2 migration (helper + clean break):** Tasks 1, 3, 17.
- **§10 cuts (TUI, agent, wizard, LLM, Robinhood, schema cache, anonymizer, config.toml):** Tasks 1, 18, 19.

No spec sections lack a task. No placeholders remain in the code blocks. Method names referenced across tasks (`compute_natural_key`, `detect_in_window`, `simulate_sell`, `replace_violations_in_window`, `add_import`, etc.) are consistent.
