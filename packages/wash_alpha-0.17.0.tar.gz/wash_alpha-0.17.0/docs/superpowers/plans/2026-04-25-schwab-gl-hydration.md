# Schwab Realized G/L Hydration — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ingest Schwab's Realized Gain/Loss CSV alongside Transaction History so the wash-sale engine can detect violations on Schwab data. Hydrate `Trade.cost_basis` on Sells from G/L lot rows (preferred) or FIFO from buy lots (fallback). Merge our engine's results with Schwab's pre-computed wash-sale calls — Schwab is authoritative for closed Schwab positions, our engine adds cross-account and substantially-identical detections.

**Architecture:** A new `realized_gl_lots` SQLModel table stores Schwab's per-lot G/L data verbatim. A new `SchwabRealizedGLParser` produces those rows from G/L CSVs. A "stitch" pass after every import walks each Sell trade in the affected account and populates `cost_basis` from G/L (matching by symbol+date) or FIFO buy lots. Two new columns — `Trade.basis_source` and `WashSaleViolation.source` — track provenance so the UI can render confidence/source badges. Web upload becomes multi-file (any combination of CSVs); each file is auto-detected and routed to its parser. The CLI gets the same stitch+merge in its existing import path.

**Tech Stack:** Python 3.11 · SQLModel · Pydantic v2 · FastAPI (web layer) · Typer (CLI) · pytest · loguru.

**Spec reference:** `docs/superpowers/specs/2026-04-25-schwab-gl-hydration-design.md`

**Reference files (study before implementing):**
- `src/net_alpha/brokers/schwab.py` — pattern for parsers; option parsing; how `cost_basis`/`proceeds` are derived from `Amount`.
- `src/net_alpha/brokers/registry.py` — `PARSERS` list and `detect_broker(headers)`.
- `src/net_alpha/brokers/base.py` — `BrokerParser` Protocol.
- `src/net_alpha/ingest/csv_loader.py` — current `load_csv`; we'll upgrade header detection here.
- `src/net_alpha/ingest/option_parser.py` — `parse_option_symbol(symbol) -> tuple[ticker, OptionDetails] | None`. Schwab format `"CRCL 06/18/2026 150.00 C"` already supported via `_SCHWAB_PATTERN`.
- `src/net_alpha/db/tables.py` — `TradeRow`, `LotRow`, `WashSaleViolationRow` SQLModel definitions.
- `src/net_alpha/db/migrations.py` — `CURRENT_SCHEMA_VERSION`, `migrate(session)`. Currently version 1 (no upgrades).
- `src/net_alpha/db/connection.py` — `init_db(engine)`. Calls `SQLModel.metadata.create_all`.
- `src/net_alpha/db/repository.py` — `Repository` class; existing read/write methods. We add G/L methods + a few stitch helpers.
- `src/net_alpha/engine/detector.py` — `detect_wash_sales(trades, etf_pairs)` and `detect_in_window(trades, start, end, etf_pairs)`. Pure functions. They read `Trade.is_loss()` which requires both `proceeds` and `cost_basis`.
- `src/net_alpha/models/domain.py` — `Trade`, `Lot`, `WashSaleViolation`, `Account`, `ImportRecord`, `ImportSummary`, `DetectionResult`. **Field names**: `Trade.date` (date object, not str), `Trade.cost_basis` (float|None), `WashSaleViolation.confidence` (str: "Confirmed"|"Probable"|"Unclear"), `WashSaleViolation.loss_sale_date` (date|None).
- `src/net_alpha/web/routes/imports.py` — current single-file upload + preview + delete routes. Where stitch+merge get plumbed for web.
- `src/net_alpha/cli/default.py` (or wherever the multi-file CLI runs — `cli/app.py:42` invokes `default_cmd.run`) — CLI's import pipeline. Where stitch+merge get plumbed for CLI.
- `src/net_alpha/web/templates/_drop_zone.html`, `_import_modal.html`, `_violation_card.html`, `ticker.html` — templates we modify.
- `tests/web/conftest.py` — `client`, `repo`, `settings` fixtures used by web tests.
- `tests/web/fixtures/schwab_minimal.csv` — pattern for fixture format.

---

## Preflight (before starting Task 1)

This plan should be executed in an isolated git worktree. Use the `superpowers:using-git-worktrees` skill to set one up at `.worktrees/schwab-gl-hydration` from `master`. Verify `uv run pytest -q` passes (current baseline) before starting Task 1.

---

## File Structure

### New files

**Domain + parser:**
- `src/net_alpha/models/realized_gl.py` — `RealizedGLLot` Pydantic model
- `src/net_alpha/brokers/schwab_realized_gl.py` — `SchwabRealizedGLParser`

**Engine:**
- `src/net_alpha/engine/stitch.py` — stitch algorithm (G/L → FIFO → unknown), `StitchOutcome` and `StitchSummary` dataclasses
- `src/net_alpha/engine/merge.py` — merge engine violations with Schwab verdicts

**Templates:**
- `src/net_alpha/web/templates/_schwab_lot_detail.html` — read-only G/L lot table partial for ticker drilldown

**Tests:**
- `tests/ingest/test_csv_loader_smart_headers.py`
- `tests/brokers/test_schwab_realized_gl.py`
- `tests/brokers/fixtures/schwab_realized_gl_min.csv`
- `tests/db/test_migration_v1_v2.py`
- `tests/db/test_repository_gl.py`
- `tests/engine/test_stitch.py`
- `tests/engine/test_merge.py`
- `tests/web/test_multi_file_upload.py`

### Modified files

- `src/net_alpha/db/tables.py` — add `RealizedGLLotRow`; add `basis_source` to `TradeRow`; add `source` to `WashSaleViolationRow`
- `src/net_alpha/db/migrations.py` — bump `CURRENT_SCHEMA_VERSION` to 2; add `_migrate_v1_to_v2(session)` branch
- `src/net_alpha/db/connection.py` — call `migrate(session)` from `init_db`
- `src/net_alpha/db/repository.py` — add G/L insert/read methods + stitch helpers
- `src/net_alpha/ingest/csv_loader.py` — smart header detection
- `src/net_alpha/brokers/registry.py` — register `SchwabRealizedGLParser`
- `src/net_alpha/web/routes/imports.py` — multi-file upload, run stitch + merge in pipeline
- `src/net_alpha/web/templates/_drop_zone.html` — `multiple` attr + copy
- `src/net_alpha/web/templates/_import_modal.html` — per-file detection cards
- `src/net_alpha/web/templates/_imports_table.html` — "Files" column
- `src/net_alpha/web/templates/_violation_card.html` — source badge
- `src/net_alpha/web/templates/ticker.html` — include `_schwab_lot_detail.html`
- `src/net_alpha/web/routes/ticker.py` — pass G/L lot data to template
- `src/net_alpha/cli/default.py` — call stitch + merge after `add_import`

### Conventions

- `RealizedGLLotRow.closed_date` and `opened_date` are stored as `YYYY-MM-DD` strings (matches `TradeRow.trade_date` convention).
- Money in `RealizedGLLotRow` is stored as `float` (matches `TradeRow.cost_basis`).
- `wash_sale: bool` on `RealizedGLLotRow` — `"Yes"` → True, `"No"` → False.
- `disallowed_loss: float` — `""` (empty string in CSV) → 0.0.
- All new tests use `tmp_path`-bound `Settings(data_dir=tmp_path)` so the real `~/.net_alpha/` is never touched.
- All new code uses `from __future__ import annotations`.
- Stitch and merge live in `engine/` since they are pure functions over domain models. Web/CLI routes only orchestrate.

---

## Phase 1 — Foundation

### Task 1: Smart header detection in `load_csv`

**Why:** G/L CSV has a non-empty title row before the real headers. Current `load_csv` would treat the title as headers and fail. We add a heuristic that finds the headers row in the first 5 lines.

**Files:**
- Modify: `src/net_alpha/ingest/csv_loader.py`
- Test: `tests/ingest/test_csv_loader_smart_headers.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/ingest/__init__.py` (empty) and `tests/ingest/test_csv_loader_smart_headers.py`:

```python
from pathlib import Path

from net_alpha.ingest.csv_loader import load_csv


def _write(tmp_path: Path, name: str, body: str) -> str:
    p = tmp_path / name
    p.write_text(body, encoding="utf-8")
    return str(p)


def test_load_csv_no_preamble_works_unchanged(tmp_path):
    """Backwards compat: a file with headers on row 0 still loads correctly."""
    path = _write(
        tmp_path,
        "tx.csv",
        "Date,Action,Symbol,Quantity,Amount\n"
        "01/02/2026,Buy,AAPL,1,$100.00\n",
    )
    headers, rows = load_csv(path)
    assert headers == ["Date", "Action", "Symbol", "Quantity", "Amount"]
    assert len(rows) == 1
    assert rows[0]["Action"] == "Buy"


def test_load_csv_skips_title_row_before_headers(tmp_path):
    """G/L pattern: a title row with one populated cell precedes the real headers."""
    path = _write(
        tmp_path,
        "gl.csv",
        '"Realized Gain/Loss - Lot Details for Short_Term as of ...","","","",""\n'
        '"Symbol","Closed Date","Quantity","Proceeds","Cost Basis (CB)"\n'
        '"WRD","04/20/2026","100","$824.96","$800.66"\n',
    )
    headers, rows = load_csv(path)
    assert headers == ["Symbol", "Closed Date", "Quantity", "Proceeds", "Cost Basis (CB)"]
    assert len(rows) == 1
    assert rows[0]["Symbol"] == "WRD"


def test_load_csv_detects_headers_within_first_five_rows(tmp_path):
    """Multiple title/blank rows still allowed before headers."""
    path = _write(
        tmp_path,
        "weird.csv",
        '"Title row","","",""\n'
        '"","","",""\n'
        '"Generated 2026-04-25","","",""\n'
        '"Symbol","Closed Date","Quantity","Cost Basis (CB)"\n'
        '"AAPL","04/20/2026","10","$100.00"\n',
    )
    headers, rows = load_csv(path)
    assert headers == ["Symbol", "Closed Date", "Quantity", "Cost Basis (CB)"]
    assert rows[0]["Symbol"] == "AAPL"


def test_load_csv_rejects_when_no_header_row_found(tmp_path):
    """If first 5 rows all look like data (start with $ or date), give up."""
    path = _write(
        tmp_path,
        "bad.csv",
        "$1,$2,$3\n"
        "01/02/2026,03/04/2026,05/06/2026\n"
        "$4,$5,$6\n",
    )
    headers, rows = load_csv(path)
    # Falls back to the FIRST row as headers (legacy behavior, no exception).
    # The parser registry will then fail to match any parser, surfacing a clean error.
    assert headers == ["$1", "$2", "$3"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/ingest/test_csv_loader_smart_headers.py -v`
Expected: FAILS — `test_load_csv_skips_title_row_before_headers` and `test_load_csv_detects_headers_within_first_five_rows` fail because current `load_csv` treats row 0 as headers.

- [ ] **Step 3: Implement smart header detection**

Replace `src/net_alpha/ingest/csv_loader.py` contents:

```python
from __future__ import annotations

import csv
import hashlib
import re

_DATE_PATTERN = re.compile(r"^\d{1,2}/\d{1,2}/\d{2,4}$|^\d{4}-\d{1,2}-\d{1,2}$")
_HEADER_SCAN_LIMIT = 5


def _looks_like_headers(row: list[str]) -> bool:
    """Heuristic: a row is the header row if it has 4+ non-empty cells AND
    no cell starts with '$' or matches a date pattern."""
    non_empty = [c.strip() for c in row if c.strip()]
    if len(non_empty) < 4:
        return False
    for cell in non_empty:
        if cell.startswith("$"):
            return False
        if _DATE_PATTERN.match(cell):
            return False
    return True


def _find_header_index(rows: list[list[str]]) -> int:
    for i in range(min(_HEADER_SCAN_LIMIT, len(rows))):
        if _looks_like_headers(rows[i]):
            return i
    return 0  # Fallback: assume first row is headers (legacy behavior)


def load_csv(path: str) -> tuple[list[str], list[dict[str, str]]]:
    """Read a CSV from disk. Returns (headers, rows).

    Skips up to 5 leading preamble rows (title rows, blank rows) before the
    real header row. Falls back to row 0 if no plausible header row is found.
    """
    with open(path, newline="", encoding="utf-8-sig") as f:
        all_rows = list(csv.reader(f))

    if not all_rows:
        return [], []

    header_idx = _find_header_index(all_rows)
    headers = [c.strip() for c in all_rows[header_idx]]
    data_rows: list[dict[str, str]] = []
    for raw in all_rows[header_idx + 1 :]:
        if not any(c.strip() for c in raw):
            continue  # skip blank rows
        # Pad short rows; truncate long rows
        padded = list(raw) + [""] * max(0, len(headers) - len(raw))
        data_rows.append({h: padded[i] for i, h in enumerate(headers)})
    return headers, data_rows


def compute_csv_sha256(path: str) -> str:
    """SHA256 of file contents — used for ImportRecord.csv_sha256 (informational)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(64 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
```

- [ ] **Step 4: Run new tests to verify they pass**

Run: `uv run pytest tests/ingest/test_csv_loader_smart_headers.py -v`
Expected: 4 PASS.

- [ ] **Step 5: Run full suite to verify no regressions**

Run: `uv run pytest -q`
Expected: All existing tests still pass (the heuristic preserves legacy single-header CSVs).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/ingest/csv_loader.py tests/ingest/__init__.py tests/ingest/test_csv_loader_smart_headers.py
git commit -m "feat(ingest): smart header detection in load_csv

Skips up to 5 preamble rows (title rows, blank rows) before the real
header row. Required for Schwab Realized G/L CSVs which have a
'Realized Gain/Loss - Lot Details ...' title above the column headers.
Falls back to row 0 when no plausible header row is found, preserving
backwards compat for files that already had headers on row 0."
```

---

### Task 2: `RealizedGLLot` Pydantic domain model

**Why:** A typed value object the parser produces and the repository accepts. Lives in `models/realized_gl.py` to keep `models/domain.py` focused on the original v2 surface.

**Files:**
- Create: `src/net_alpha/models/realized_gl.py`
- Test: `tests/models/test_realized_gl.py`

- [ ] **Step 1: Create test file directory if needed**

```bash
mkdir -p /Users/alexchen/Documents/project/net_alpha/tests/models
touch /Users/alexchen/Documents/project/net_alpha/tests/models/__init__.py
```

- [ ] **Step 2: Write the failing test**

Create `tests/models/test_realized_gl.py`:

```python
from datetime import date

import pytest

from net_alpha.models.realized_gl import RealizedGLLot


def test_realized_gl_lot_required_fields():
    lot = RealizedGLLot(
        account_display="schwab/personal",
        symbol_raw="WRD",
        ticker="WRD",
        closed_date=date(2026, 4, 20),
        opened_date=date(2026, 2, 11),
        quantity=100.0,
        proceeds=824.96,
        cost_basis=800.66,
        unadjusted_cost_basis=800.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
    )
    assert lot.ticker == "WRD"
    assert lot.wash_sale is False
    assert lot.option_strike is None


def test_realized_gl_lot_with_option_fields():
    lot = RealizedGLLot(
        account_display="schwab/personal",
        symbol_raw="CRCL 06/18/2026 150.00 C",
        ticker="CRCL",
        closed_date=date(2026, 4, 20),
        opened_date=date(2026, 4, 17),
        quantity=1.0,
        proceeds=330.33,
        cost_basis=460.66,
        unadjusted_cost_basis=460.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
        option_strike=150.00,
        option_expiry="2026-06-18",
        option_call_put="C",
    )
    assert lot.option_strike == 150.00


def test_realized_gl_lot_natural_key_is_deterministic():
    """Two lots with identical invariant fields produce the same natural key."""
    base = dict(
        account_display="schwab/personal",
        symbol_raw="WRD",
        ticker="WRD",
        closed_date=date(2026, 4, 20),
        opened_date=date(2026, 2, 11),
        quantity=100.0,
        proceeds=824.96,
        cost_basis=800.66,
        unadjusted_cost_basis=800.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
    )
    a = RealizedGLLot(**base)
    b = RealizedGLLot(**base)
    assert a.compute_natural_key() == b.compute_natural_key()


def test_realized_gl_lot_natural_key_changes_with_basis():
    base = dict(
        account_display="schwab/personal",
        symbol_raw="WRD",
        ticker="WRD",
        closed_date=date(2026, 4, 20),
        opened_date=date(2026, 2, 11),
        quantity=100.0,
        proceeds=824.96,
        cost_basis=800.66,
        unadjusted_cost_basis=800.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
    )
    a = RealizedGLLot(**base)
    b = RealizedGLLot(**{**base, "cost_basis": 750.00})
    assert a.compute_natural_key() != b.compute_natural_key()
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/models/test_realized_gl.py -v`
Expected: ImportError — `net_alpha.models.realized_gl` doesn't exist.

- [ ] **Step 4: Implement `RealizedGLLot`**

Create `src/net_alpha/models/realized_gl.py`:

```python
from __future__ import annotations

import hashlib
from datetime import date

from pydantic import BaseModel


class RealizedGLLot(BaseModel):
    """One tax-lot row from a Schwab Realized G/L CSV.

    Multiple lots can map to one Sell trade (one row per buy lot consumed).
    """

    account_display: str
    symbol_raw: str
    ticker: str
    closed_date: date
    opened_date: date
    quantity: float
    proceeds: float
    cost_basis: float
    unadjusted_cost_basis: float
    wash_sale: bool
    disallowed_loss: float
    term: str  # "Short Term" | "Long Term"

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None

    def compute_natural_key(self) -> str:
        """SHA256 over invariant fields. Used for idempotent dedup on re-import."""
        parts = [
            self.account_display,
            self.symbol_raw,
            self.closed_date.isoformat(),
            self.opened_date.isoformat(),
            f"{self.quantity:.8f}",
            f"{self.cost_basis:.8f}",
            f"{self.proceeds:.8f}",
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/models/test_realized_gl.py -v`
Expected: 4 PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/models/realized_gl.py tests/models/__init__.py tests/models/test_realized_gl.py
git commit -m "feat(models): add RealizedGLLot domain model

Pydantic value object for one tax-lot row from Schwab's Realized G/L
CSV. Includes Schwab's per-lot wash sale flag and disallowed loss for
later merge with engine output. compute_natural_key() supports
idempotent dedup on re-imports."
```

---

### Task 3: `RealizedGLLotRow` SQL table + migration v1 → v2

**Why:** Persistence for G/L lots, plus the new `basis_source` column on `TradeRow` and `source` column on `WashSaleViolationRow`. All three changes are part of schema_version 2.

**Files:**
- Modify: `src/net_alpha/db/tables.py`
- Modify: `src/net_alpha/db/migrations.py`
- Modify: `src/net_alpha/db/connection.py`
- Test: `tests/db/test_migration_v1_v2.py`

- [ ] **Step 1: Write the failing test**

Create `tests/db/test_migration_v1_v2.py`:

```python
"""Tests for migration from schema_version 1 → 2.

Synthesizes a v1-shape DB (no basis_source, no source, no realized_gl_lots),
then runs init_db() and verifies the new columns/table exist with safe defaults.
"""
from __future__ import annotations

from pathlib import Path

import sqlalchemy
from sqlmodel import Session, create_engine

from net_alpha.db.connection import init_db


def _make_v1_db(path: Path) -> sqlalchemy.engine.Engine:
    """Create a SQLite DB with v1-shape schema and one trade + one violation row."""
    engine = create_engine(f"sqlite:///{path}", echo=False)
    with engine.begin() as conn:
        conn.execute(sqlalchemy.text("""
            CREATE TABLE accounts (
                id INTEGER PRIMARY KEY,
                broker TEXT NOT NULL,
                label TEXT NOT NULL,
                UNIQUE(broker, label)
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE imports (
                id INTEGER PRIMARY KEY,
                account_id INTEGER NOT NULL,
                csv_filename TEXT,
                csv_sha256 TEXT,
                imported_at TEXT,
                trade_count INTEGER
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE trades (
                id INTEGER PRIMARY KEY,
                import_id INTEGER NOT NULL,
                account_id INTEGER NOT NULL,
                natural_key TEXT NOT NULL,
                ticker TEXT NOT NULL,
                trade_date TEXT NOT NULL,
                action TEXT NOT NULL,
                quantity REAL NOT NULL,
                proceeds REAL,
                cost_basis REAL,
                basis_unknown BOOLEAN DEFAULT 0,
                option_strike REAL,
                option_expiry TEXT,
                option_call_put TEXT
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE lots (
                id INTEGER PRIMARY KEY,
                trade_id INTEGER NOT NULL,
                account_id INTEGER NOT NULL,
                ticker TEXT NOT NULL,
                trade_date TEXT NOT NULL,
                quantity REAL NOT NULL,
                cost_basis REAL NOT NULL,
                adjusted_basis REAL NOT NULL,
                option_strike REAL,
                option_expiry TEXT,
                option_call_put TEXT
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE wash_sale_violations (
                id INTEGER PRIMARY KEY,
                loss_trade_id INTEGER NOT NULL,
                replacement_trade_id INTEGER NOT NULL,
                loss_account_id INTEGER NOT NULL,
                buy_account_id INTEGER NOT NULL,
                loss_sale_date TEXT NOT NULL,
                triggering_buy_date TEXT NOT NULL,
                ticker TEXT NOT NULL DEFAULT '',
                confidence TEXT NOT NULL,
                disallowed_loss REAL NOT NULL,
                matched_quantity REAL NOT NULL
            )
        """))
        conn.execute(sqlalchemy.text("""
            CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)
        """))
        conn.execute(sqlalchemy.text("INSERT INTO accounts(id, broker, label) VALUES (1, 'schwab', 'personal')"))
        conn.execute(sqlalchemy.text(
            "INSERT INTO imports(id, account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 1, 'x.csv', 'abc', '2026-01-01T00:00:00', 1)"
        ))
        conn.execute(sqlalchemy.text(
            "INSERT INTO trades(id, import_id, account_id, natural_key, ticker, trade_date, action, quantity) "
            "VALUES (1, 1, 1, 'k1', 'AAPL', '2026-01-02', 'Buy', 1.0)"
        ))
        conn.execute(sqlalchemy.text(
            "INSERT INTO wash_sale_violations(id, loss_trade_id, replacement_trade_id, loss_account_id, "
            "buy_account_id, loss_sale_date, triggering_buy_date, confidence, disallowed_loss, matched_quantity) "
            "VALUES (1, 1, 1, 1, 1, '2026-01-02', '2026-01-03', 'Confirmed', 100.0, 1.0)"
        ))
        conn.execute(sqlalchemy.text("INSERT INTO meta(key, value) VALUES ('schema_version', '1')"))
    return engine


def test_init_db_migrates_v1_to_v2_adds_basis_source(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        cols = [r[1] for r in conn.execute(sqlalchemy.text("PRAGMA table_info(trades)")).all()]
    assert "basis_source" in cols


def test_init_db_migrates_v1_to_v2_adds_violation_source(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        cols = [r[1] for r in conn.execute(sqlalchemy.text("PRAGMA table_info(wash_sale_violations)")).all()]
    assert "source" in cols


def test_init_db_migrates_v1_to_v2_creates_realized_gl_lots(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        tables = [r[0] for r in conn.execute(sqlalchemy.text(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )).all()]
    assert "realized_gl_lots" in tables


def test_init_db_preserves_existing_rows_with_default_basis_source(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        row = conn.execute(sqlalchemy.text(
            "SELECT id, basis_source FROM trades WHERE id=1"
        )).first()
    assert row is not None
    assert row[1] == "unknown"


def test_init_db_preserves_existing_violation_with_default_source(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        row = conn.execute(sqlalchemy.text(
            "SELECT id, source FROM wash_sale_violations WHERE id=1"
        )).first()
    assert row is not None
    assert row[1] == "engine"


def test_init_db_bumps_schema_version_to_2(tmp_path):
    db_path = tmp_path / "v1.db"
    _make_v1_db(db_path)
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        v = conn.execute(sqlalchemy.text(
            "SELECT value FROM meta WHERE key='schema_version'"
        )).scalar()
    assert v == "2"


def test_init_db_on_fresh_db_creates_v2_directly(tmp_path):
    """Fresh DB (no tables) should create v2 schema and set schema_version=2."""
    db_path = tmp_path / "fresh.db"
    engine = create_engine(f"sqlite:///{db_path}", echo=False)
    init_db(engine)
    with engine.connect() as conn:
        v = conn.execute(sqlalchemy.text("SELECT value FROM meta WHERE key='schema_version'")).scalar()
        cols = [r[1] for r in conn.execute(sqlalchemy.text("PRAGMA table_info(trades)")).all()]
        tables = [r[0] for r in conn.execute(sqlalchemy.text(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )).all()]
    assert v == "2"
    assert "basis_source" in cols
    assert "realized_gl_lots" in tables
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_migration_v1_v2.py -v`
Expected: All fail — `RealizedGLLotRow` doesn't exist, migration logic isn't there.

- [ ] **Step 3: Add new column on `TradeRow`**

Edit `src/net_alpha/db/tables.py`. After the existing `option_call_put: str | None = None` line in `TradeRow` (around line 49), add:

```python
    basis_source: str = Field(default="unknown")
    # values: "broker_csv" | "g_l" | "fifo" | "unknown"
```

- [ ] **Step 4: Add new column on `WashSaleViolationRow`**

In `src/net_alpha/db/tables.py`, after `matched_quantity: float` in `WashSaleViolationRow` (around line 83), add:

```python
    source: str = Field(default="engine")
    # values: "schwab_g_l" | "engine"
```

- [ ] **Step 5: Add `RealizedGLLotRow` class**

In `src/net_alpha/db/tables.py`, append at the end (after `MetaRow`):

```python
class RealizedGLLotRow(SQLModel, table=True):
    __tablename__ = "realized_gl_lots"

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)

    symbol_raw: str = Field(index=True)
    ticker: str = Field(index=True)
    closed_date: str = Field(index=True)
    opened_date: str
    quantity: float
    proceeds: float
    cost_basis: float
    unadjusted_cost_basis: float
    wash_sale: bool
    disallowed_loss: float
    term: str

    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None

    natural_key: str = Field(unique=True, index=True)
```

- [ ] **Step 6: Bump schema version + add migration**

Replace `src/net_alpha/db/migrations.py` contents:

```python
"""Hand-written migrations.

Schema versions:
  v1 — Initial v2.x schema (TradeRow, LotRow, WashSaleViolationRow, etc.)
  v2 — Adds RealizedGLLotRow table; adds Trade.basis_source, WashSaleViolation.source columns.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlmodel import Session

CURRENT_SCHEMA_VERSION = 2


def get_schema_version(session: Session) -> int:
    row = session.exec(text("SELECT value FROM meta WHERE key='schema_version'")).first()
    return int(row[0]) if row else 0


def set_schema_version(session: Session, version: int) -> None:
    session.exec(
        text(
            "INSERT INTO meta(key, value) VALUES ('schema_version', :v) "
            "ON CONFLICT(key) DO UPDATE SET value=:v"
        ),
        params={"v": str(version)},
    )
    session.commit()


def _column_exists(session: Session, table: str, column: str) -> bool:
    rows = session.exec(text(f"PRAGMA table_info({table})")).all()
    return any(r[1] == column for r in rows)


def _table_exists(session: Session, table: str) -> bool:
    row = session.exec(
        text("SELECT name FROM sqlite_master WHERE type='table' AND name=:n"),
        params={"n": table},
    ).first()
    return row is not None


def _migrate_v1_to_v2(session: Session) -> None:
    if _table_exists(session, "trades") and not _column_exists(session, "trades", "basis_source"):
        session.exec(text(
            "ALTER TABLE trades ADD COLUMN basis_source TEXT NOT NULL DEFAULT 'unknown'"
        ))
    if _table_exists(session, "wash_sale_violations") and not _column_exists(
        session, "wash_sale_violations", "source"
    ):
        session.exec(text(
            "ALTER TABLE wash_sale_violations ADD COLUMN source TEXT NOT NULL DEFAULT 'engine'"
        ))
    # realized_gl_lots is created by SQLModel.metadata.create_all in init_db.
    session.commit()


def migrate(session: Session) -> None:
    """Apply pending migrations idempotently."""
    current = get_schema_version(session)
    if current == 0:
        # Fresh DB or v1 DB without meta row: SQLModel.metadata.create_all has
        # already produced v2-shape tables. Just stamp the version.
        set_schema_version(session, CURRENT_SCHEMA_VERSION)
        return
    if current == 1:
        _migrate_v1_to_v2(session)
        set_schema_version(session, 2)
        return
    if current > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"DB schema_version={current} is newer than this binary "
            f"(supports {CURRENT_SCHEMA_VERSION}). Upgrade net-alpha."
        )
```

- [ ] **Step 7: Wire migration into `init_db`**

Replace `src/net_alpha/db/connection.py` contents:

```python
from __future__ import annotations

from pathlib import Path

from sqlmodel import Session, SQLModel, create_engine

from net_alpha.db.migrations import migrate


def get_engine(db_path: Path):
    """Create a SQLAlchemy engine for the given SQLite database path."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return create_engine(f"sqlite:///{db_path}", echo=False)


def init_db(engine) -> None:
    """Create all tables (idempotent) and run pending migrations."""
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        migrate(session)
```

- [ ] **Step 8: Run the migration tests**

Run: `uv run pytest tests/db/test_migration_v1_v2.py -v`
Expected: All 7 PASS.

- [ ] **Step 9: Run full suite**

Run: `uv run pytest -q`
Expected: All existing tests still pass. (The default values on new columns mean every existing fixture trade and violation gets safe defaults.)

- [ ] **Step 10: Commit**

```bash
git add src/net_alpha/db/tables.py src/net_alpha/db/migrations.py src/net_alpha/db/connection.py tests/db/test_migration_v1_v2.py
git commit -m "feat(db): schema v2 — realized_gl_lots table + basis_source/source columns

Adds RealizedGLLotRow table, Trade.basis_source column (default 'unknown'),
and WashSaleViolation.source column (default 'engine'). Wires
migrate(session) into init_db() so v1 DBs upgrade in place. Migration
is additive and idempotent."
```

---

### Task 4: Repository methods for G/L lots and stitch helpers

**Why:** Persistence-layer surface used by the parser pipeline (insert G/L lots, dedup) and by the stitch algorithm (read sells needing basis, read buy lots for FIFO, write back hydrated basis).

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_gl.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/db/test_repository_gl.py`:

```python
from __future__ import annotations

from datetime import date, datetime

import pytest
from sqlmodel import Session

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Account, ImportRecord, Trade
from net_alpha.models.realized_gl import RealizedGLLot


@pytest.fixture
def repo(tmp_path):
    engine = get_engine(tmp_path / "t.db")
    init_db(engine)
    return Repository(engine)


def _make_lot(**overrides) -> RealizedGLLot:
    base = dict(
        account_display="schwab/personal",
        symbol_raw="WRD",
        ticker="WRD",
        closed_date=date(2026, 4, 20),
        opened_date=date(2026, 2, 11),
        quantity=100.0,
        proceeds=824.96,
        cost_basis=800.66,
        unadjusted_cost_basis=800.66,
        wash_sale=False,
        disallowed_loss=0.0,
        term="Short Term",
    )
    base.update(overrides)
    return RealizedGLLot(**base)


def _make_account(repo: Repository) -> Account:
    return repo.get_or_create_account("schwab", "personal")


def _make_import(repo: Repository, acct: Account) -> int:
    rec = ImportRecord(
        account_id=acct.id,
        csv_filename="t.csv",
        csv_sha256="abc",
        imported_at=datetime(2026, 4, 25, 0, 0, 0),
        trade_count=0,
    )
    result = repo.add_import(acct, rec, [])
    return result.import_id


def test_add_gl_lots_inserts_rows(repo):
    acct = _make_account(repo)
    import_id = _make_import(repo, acct)
    lots = [_make_lot()]
    inserted = repo.add_gl_lots(acct, import_id, lots)
    assert inserted == 1


def test_add_gl_lots_dedupes_on_natural_key(repo):
    acct = _make_account(repo)
    import_id = _make_import(repo, acct)
    lot = _make_lot()
    repo.add_gl_lots(acct, import_id, [lot])
    second = repo.add_gl_lots(acct, import_id, [lot])  # same lot, second time
    assert second == 0


def test_get_gl_lots_for_match_returns_matching_rows(repo):
    acct = _make_account(repo)
    import_id = _make_import(repo, acct)
    lot = _make_lot()
    repo.add_gl_lots(acct, import_id, [lot])
    result = repo.get_gl_lots_for_match(
        account_id=acct.id, symbol_raw="WRD", closed_date=date(2026, 4, 20)
    )
    assert len(result) == 1
    assert result[0].cost_basis == 800.66


def test_get_gl_lots_for_match_returns_empty_when_no_match(repo):
    acct = _make_account(repo)
    import_id = _make_import(repo, acct)
    repo.add_gl_lots(acct, import_id, [_make_lot()])
    result = repo.get_gl_lots_for_match(
        account_id=acct.id, symbol_raw="AAPL", closed_date=date(2026, 4, 20)
    )
    assert result == []


def test_get_sells_needing_basis_returns_only_sells(repo):
    acct = _make_account(repo)
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=2,
    )
    trades = [
        Trade(account=acct.display(), date=date(2026, 4, 1), ticker="AAPL",
              action="Buy", quantity=1, cost_basis=100.0),
        Trade(account=acct.display(), date=date(2026, 4, 20), ticker="AAPL",
              action="Sell", quantity=1, proceeds=90.0),
    ]
    repo.add_import(acct, rec, trades)
    sells = repo.get_sells_for_account(acct.id)
    assert len(sells) == 1
    assert sells[0].ticker == "AAPL"
    assert sells[0].action == "Sell"


def test_update_trade_basis_writes_basis_and_source(repo):
    acct = _make_account(repo)
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=1,
    )
    trades = [
        Trade(account=acct.display(), date=date(2026, 4, 20), ticker="AAPL",
              action="Sell", quantity=1, proceeds=90.0),
    ]
    repo.add_import(acct, rec, trades)
    sells = repo.get_sells_for_account(acct.id)
    sell_id = sells[0].id
    repo.update_trade_basis(sell_id, cost_basis=120.0, basis_source="g_l")
    sells_after = repo.get_sells_for_account(acct.id)
    assert sells_after[0].cost_basis == 120.0
    assert sells_after[0].basis_source == "g_l"


def test_get_buys_before_date_returns_buy_trades_oldest_first(repo):
    acct = _make_account(repo)
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=2,
    )
    trades = [
        Trade(account=acct.display(), date=date(2026, 3, 15), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0),
        Trade(account=acct.display(), date=date(2026, 3, 10), ticker="AAPL",
              action="Buy", quantity=5, cost_basis=500.0),
        Trade(account=acct.display(), date=date(2026, 4, 1), ticker="AAPL",
              action="Buy", quantity=3, cost_basis=300.0),
    ]
    repo.add_import(acct, rec, trades)
    buys = repo.get_buys_before_date(
        account_id=acct.id, ticker="AAPL", before_date=date(2026, 3, 31)
    )
    assert [b.date for b in buys] == [date(2026, 3, 10), date(2026, 3, 15)]


def test_get_gl_lots_for_ticker_returns_all_lots(repo):
    acct = _make_account(repo)
    import_id = _make_import(repo, acct)
    repo.add_gl_lots(acct, import_id, [
        _make_lot(opened_date=date(2026, 2, 11)),
        _make_lot(opened_date=date(2026, 3, 1)),
    ])
    lots = repo.get_gl_lots_for_ticker(acct.id, "WRD")
    assert len(lots) == 2
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_repository_gl.py -v`
Expected: All fail — methods don't exist on `Repository`.

- [ ] **Step 3: Add the necessary imports to repository.py**

In `src/net_alpha/db/repository.py`, find the existing imports near the top and add `RealizedGLLotRow` to the `from net_alpha.db.tables import (` block. Add `from net_alpha.models.realized_gl import RealizedGLLot` to the `from net_alpha.models.X import` block as appropriate. Both should be alphabetized into the existing import statements.

- [ ] **Step 4: Add G/L methods to Repository**

In `src/net_alpha/db/repository.py`, append the following methods inside the `Repository` class (just before `# Legacy / preserved classes` if that comment exists, otherwise at the end of the class):

```python
    # ----- Realized G/L methods (schema v2) -----

    def add_gl_lots(
        self, account: Account, import_id: int, lots: list[RealizedGLLot]
    ) -> int:
        """Insert G/L lots, deduplicated on natural_key. Returns count of new rows."""
        if account.id is None:
            raise ValueError("Account must have an id")
        inserted = 0
        with Session(self._engine) as s:
            existing = {
                r.natural_key
                for r in s.exec(
                    select(RealizedGLLotRow.natural_key).where(
                        RealizedGLLotRow.account_id == account.id
                    )
                ).all()
            }
            for lot in lots:
                key = lot.compute_natural_key()
                if key in existing:
                    continue
                row = RealizedGLLotRow(
                    import_id=import_id,
                    account_id=account.id,
                    symbol_raw=lot.symbol_raw,
                    ticker=lot.ticker,
                    closed_date=lot.closed_date.isoformat(),
                    opened_date=lot.opened_date.isoformat(),
                    quantity=lot.quantity,
                    proceeds=lot.proceeds,
                    cost_basis=lot.cost_basis,
                    unadjusted_cost_basis=lot.unadjusted_cost_basis,
                    wash_sale=lot.wash_sale,
                    disallowed_loss=lot.disallowed_loss,
                    term=lot.term,
                    option_strike=lot.option_strike,
                    option_expiry=lot.option_expiry,
                    option_call_put=lot.option_call_put,
                    natural_key=key,
                )
                s.add(row)
                existing.add(key)
                inserted += 1
            s.commit()
        return inserted

    def get_gl_lots_for_match(
        self, *, account_id: int, symbol_raw: str, closed_date: date
    ) -> list[RealizedGLLot]:
        """All G/L lots in this account that match a Sell trade by symbol+closed_date."""
        with Session(self._engine) as s:
            rows = s.exec(
                select(RealizedGLLotRow).where(
                    RealizedGLLotRow.account_id == account_id,
                    RealizedGLLotRow.symbol_raw == symbol_raw,
                    RealizedGLLotRow.closed_date == closed_date.isoformat(),
                )
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]

    def get_gl_lots_for_ticker(self, account_id: int, ticker: str) -> list[RealizedGLLot]:
        """All G/L lots for a ticker in this account, sorted by closed_date."""
        with Session(self._engine) as s:
            rows = s.exec(
                select(RealizedGLLotRow)
                .where(
                    RealizedGLLotRow.account_id == account_id,
                    RealizedGLLotRow.ticker == ticker,
                )
                .order_by(RealizedGLLotRow.closed_date)
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]

    def _row_to_gl_lot(self, row: RealizedGLLotRow, account_display: str) -> RealizedGLLot:
        return RealizedGLLot(
            account_display=account_display,
            symbol_raw=row.symbol_raw,
            ticker=row.ticker,
            closed_date=date.fromisoformat(row.closed_date),
            opened_date=date.fromisoformat(row.opened_date),
            quantity=row.quantity,
            proceeds=row.proceeds,
            cost_basis=row.cost_basis,
            unadjusted_cost_basis=row.unadjusted_cost_basis,
            wash_sale=row.wash_sale,
            disallowed_loss=row.disallowed_loss,
            term=row.term,
            option_strike=row.option_strike,
            option_expiry=row.option_expiry,
            option_call_put=row.option_call_put,
        )

    # ----- Stitch helpers (schema v2) -----

    def get_sells_for_account(self, account_id: int) -> list[Trade]:
        """All Sell trades in this account. Used by stitch as input set."""
        with Session(self._engine) as s:
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.account_id == account_id,
                    TradeRow.action == "Sell",
                )
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_trade(r, account_display) for r in rows]

    def get_buys_before_date(
        self, *, account_id: int, ticker: str, before_date: date
    ) -> list[Trade]:
        """Buy trades in this account+ticker on or before `before_date`, oldest first."""
        with Session(self._engine) as s:
            rows = s.exec(
                select(TradeRow)
                .where(
                    TradeRow.account_id == account_id,
                    TradeRow.ticker == ticker,
                    TradeRow.action == "Buy",
                    TradeRow.trade_date <= before_date.isoformat(),
                )
                .order_by(TradeRow.trade_date)
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_trade(r, account_display) for r in rows]

    def update_trade_basis(self, trade_id: str, cost_basis: float | None, basis_source: str) -> None:
        """Persist hydrated cost_basis and basis_source on a Trade row."""
        with Session(self._engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            row.cost_basis = cost_basis
            row.basis_source = basis_source
            s.add(row)
            s.commit()
```

Note: `Trade.id` in domain is `str` but `TradeRow.id` is `int`. The `_row_to_trade` helper already stringifies it; `update_trade_basis` reverses. If `_row_to_trade` doesn't stringify (depends on current implementation), use whatever id type the existing helpers use — the test asserts behavior, not internal types.

- [ ] **Step 5: Run repo tests**

Run: `uv run pytest tests/db/test_repository_gl.py -v`
Expected: All 8 PASS.

- [ ] **Step 6: Run full suite**

Run: `uv run pytest -q`
Expected: All existing tests still pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_gl.py
git commit -m "feat(db): repository methods for G/L lots and stitch helpers

Adds add_gl_lots, get_gl_lots_for_match, get_gl_lots_for_ticker,
get_sells_for_account, get_buys_before_date, update_trade_basis.
Idempotent insert dedups on RealizedGLLot.compute_natural_key()."
```

---

## Phase 2 — Parser

### Task 5: `SchwabRealizedGLParser` + register

**Why:** Recognizes the G/L CSV format (headers from real export) and produces `RealizedGLLot` value objects. Registered in the parser registry so the multi-file uploader can route files to it.

**Files:**
- Create: `src/net_alpha/brokers/schwab_realized_gl.py`
- Modify: `src/net_alpha/brokers/registry.py`
- Modify: `src/net_alpha/brokers/base.py` (extend Protocol — see Step 4)
- Test: `tests/brokers/test_schwab_realized_gl.py`
- Fixture: `tests/brokers/fixtures/schwab_realized_gl_min.csv`

- [ ] **Step 1: Create the test fixture**

Create `tests/brokers/fixtures/schwab_realized_gl_min.csv` (verbatim, including the title row and trailing empty cells):

```csv
"Realized Gain/Loss - Lot Details for Short_Term as of Sat Apr 25 22:16:54 EDT 2026 from 01/01/2026 to 04/25/2026","","","","","","","","","","","","","","","","","","","","","","","",""
"Symbol","Name","Closed Date","Opened Date","Quantity","Proceeds Per Share","Cost Per Share","Proceeds","Cost Basis (CB)","Gain/Loss ($)","Gain/Loss (%)","Long Term Gain/Loss","Short Term Gain/Loss","Term","Unadjusted Cost Basis","Wash Sale?","Disallowed Loss","Transaction Closed Date","Transaction Cost Basis","Total Transaction Gain/Loss ($)","Total Transaction Gain/Loss (%)","LT Transaction Gain/Loss ($)","LT Transaction Gain/Loss (%)","ST Transaction Gain/Loss ($)","ST Transaction Gain/Loss (%)"
"WRD","WERIDE INC ADR","04/20/2026","02/11/2026","100","$8.25","$8.01","$824.96","$800.66","$24.30","3.034996128194%","","$24.30","Short Term","$800.66","No","","04/20/2026","","","","","","",""
"CRCL 06/18/2026 150.00 C","CALL CIRCLE INTERNET GROUP INC $150 EXP 06/18/26","04/20/2026","04/17/2026","1","$3.30","$4.61","$330.33","$460.66","-$130.33","-28.292015803412%","","-$130.33","Short Term","$460.66","Yes","$130.33","04/20/2026","","","","","","",""
```

Note: Row 3 (CRCL) is hand-flagged `Wash Sale? = Yes` with `Disallowed Loss = $130.33` so we can test the parsing of that path. It diverges from the real source data, but the file is a test fixture.

- [ ] **Step 2: Write the failing test**

Create `tests/brokers/test_schwab_realized_gl.py`:

```python
from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

from net_alpha.brokers.schwab_realized_gl import SchwabRealizedGLParser
from net_alpha.ingest.csv_loader import load_csv

FIXTURE = Path(__file__).parent / "fixtures" / "schwab_realized_gl_min.csv"


def test_detects_gl_headers():
    parser = SchwabRealizedGLParser()
    headers, _ = load_csv(str(FIXTURE))
    assert parser.detect(headers) is True


def test_does_not_detect_transactions_headers():
    parser = SchwabRealizedGLParser()
    assert parser.detect(["Date", "Action", "Symbol", "Quantity", "Amount"]) is False


def test_parse_returns_two_lots():
    parser = SchwabRealizedGLParser()
    headers, rows = load_csv(str(FIXTURE))
    lots = parser.parse(rows, account_display="schwab/personal")
    assert len(lots) == 2


def test_parse_stock_lot_fields():
    parser = SchwabRealizedGLParser()
    _, rows = load_csv(str(FIXTURE))
    lots = parser.parse(rows, account_display="schwab/personal")
    wrd = next(l for l in lots if l.ticker == "WRD")
    assert wrd.symbol_raw == "WRD"
    assert wrd.closed_date == date(2026, 4, 20)
    assert wrd.opened_date == date(2026, 2, 11)
    assert wrd.quantity == 100.0
    assert wrd.proceeds == pytest.approx(824.96)
    assert wrd.cost_basis == pytest.approx(800.66)
    assert wrd.unadjusted_cost_basis == pytest.approx(800.66)
    assert wrd.wash_sale is False
    assert wrd.disallowed_loss == 0.0
    assert wrd.term == "Short Term"
    assert wrd.option_strike is None
    assert wrd.option_expiry is None
    assert wrd.option_call_put is None


def test_parse_option_lot_fields():
    parser = SchwabRealizedGLParser()
    _, rows = load_csv(str(FIXTURE))
    lots = parser.parse(rows, account_display="schwab/personal")
    crcl = next(l for l in lots if l.ticker == "CRCL")
    assert crcl.symbol_raw == "CRCL 06/18/2026 150.00 C"
    assert crcl.option_strike == 150.00
    assert crcl.option_expiry == "2026-06-18"
    assert crcl.option_call_put == "C"
    assert crcl.wash_sale is True
    assert crcl.disallowed_loss == pytest.approx(130.33)


def test_parse_handles_empty_disallowed_loss_as_zero():
    parser = SchwabRealizedGLParser()
    _, rows = load_csv(str(FIXTURE))
    lots = parser.parse(rows, account_display="schwab/personal")
    wrd = next(l for l in lots if l.ticker == "WRD")
    assert wrd.disallowed_loss == 0.0


def test_parser_name():
    assert SchwabRealizedGLParser().name == "schwab_realized_gl"
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/brokers/test_schwab_realized_gl.py -v`
Expected: ImportError — module doesn't exist.

- [ ] **Step 4: Extend `BrokerParser` Protocol to allow non-Trade output**

The G/L parser produces `RealizedGLLot`, not `Trade`. Update `src/net_alpha/brokers/base.py`:

```python
from __future__ import annotations

from typing import Any, Protocol


class BrokerParser(Protocol):
    """A parser for one broker's CSV format. May produce Trades or RealizedGLLots."""

    name: str

    def detect(self, headers: list[str]) -> bool: ...
    def parse(self, rows: list[dict[str, str]], account_display: str) -> list[Any]: ...
```

The output type is now `list[Any]` because parsers produce different value-object types. Callers branch on parser identity.

- [ ] **Step 5: Implement `SchwabRealizedGLParser`**

Create `src/net_alpha/brokers/schwab_realized_gl.py`:

```python
from __future__ import annotations

from datetime import datetime

from net_alpha.ingest.option_parser import parse_option_symbol
from net_alpha.models.realized_gl import RealizedGLLot


def _parse_money(s: str) -> float:
    """'$330.33' or '-$130.33' or '' → float (0.0 when empty)."""
    s = s.strip().replace("$", "").replace(",", "")
    if not s:
        return 0.0
    return float(s)


def _parse_yes_no(s: str) -> bool:
    return s.strip().lower() == "yes"


def _parse_mdy(s: str) -> "datetime":
    return datetime.strptime(s.strip(), "%m/%d/%Y")


class SchwabRealizedGLParser:
    name = "schwab_realized_gl"
    REQUIRED_HEADERS = {
        "Symbol",
        "Closed Date",
        "Opened Date",
        "Quantity",
        "Proceeds",
        "Cost Basis (CB)",
        "Wash Sale?",
    }

    def detect(self, headers: list[str]) -> bool:
        return self.REQUIRED_HEADERS.issubset(set(headers))

    def parse(self, rows: list[dict[str, str]], account_display: str) -> list[RealizedGLLot]:
        out: list[RealizedGLLot] = []
        for i, row in enumerate(rows, start=1):
            symbol_raw = row["Symbol"].strip()
            if not symbol_raw:
                continue  # skip blank/total rows

            try:
                closed_date = _parse_mdy(row["Closed Date"]).date()
                opened_date = _parse_mdy(row["Opened Date"]).date()
            except ValueError as e:
                raise ValueError(
                    f"Row {i}: invalid date in 'Closed Date' or 'Opened Date': {e}"
                ) from e

            try:
                qty = float(row["Quantity"].strip().replace(",", ""))
            except ValueError as e:
                raise ValueError(
                    f"Row {i}: 'Quantity' value {row['Quantity']!r} is not numeric"
                ) from e

            proceeds = _parse_money(row["Proceeds"])
            cost_basis = _parse_money(row["Cost Basis (CB)"])
            unadjusted = _parse_money(row.get("Unadjusted Cost Basis", "") or row["Cost Basis (CB)"])

            wash_sale = _parse_yes_no(row["Wash Sale?"])
            disallowed = _parse_money(row.get("Disallowed Loss", ""))

            term = row.get("Term", "").strip()

            opt = parse_option_symbol(symbol_raw)
            ticker = opt[0] if opt else symbol_raw
            opt_strike = opt[1].strike if opt else None
            opt_expiry = opt[1].expiry.isoformat() if opt else None
            opt_cp = opt[1].call_put if opt else None

            out.append(
                RealizedGLLot(
                    account_display=account_display,
                    symbol_raw=symbol_raw,
                    ticker=ticker,
                    closed_date=closed_date,
                    opened_date=opened_date,
                    quantity=qty,
                    proceeds=proceeds,
                    cost_basis=cost_basis,
                    unadjusted_cost_basis=unadjusted,
                    wash_sale=wash_sale,
                    disallowed_loss=disallowed,
                    term=term,
                    option_strike=opt_strike,
                    option_expiry=opt_expiry,
                    option_call_put=opt_cp,
                )
            )
        return out
```

- [ ] **Step 6: Register the parser**

Replace `src/net_alpha/brokers/registry.py`:

```python
# src/net_alpha/brokers/registry.py
from __future__ import annotations

from net_alpha.brokers.base import BrokerParser
from net_alpha.brokers.schwab import SchwabParser
from net_alpha.brokers.schwab_realized_gl import SchwabRealizedGLParser

PARSERS: list[BrokerParser] = [SchwabParser(), SchwabRealizedGLParser()]


def detect_broker(headers: list[str]) -> BrokerParser | None:
    for p in PARSERS:
        if p.detect(headers):
            return p
    return None
```

- [ ] **Step 7: Run tests**

Run: `uv run pytest tests/brokers/test_schwab_realized_gl.py -v`
Expected: 7 PASS.

- [ ] **Step 8: Run full suite**

Run: `uv run pytest -q`
Expected: All existing tests still pass. (The transaction parser registers first; G/L parser only matches G/L headers — no overlap.)

- [ ] **Step 9: Commit**

```bash
git add src/net_alpha/brokers/schwab_realized_gl.py src/net_alpha/brokers/registry.py src/net_alpha/brokers/base.py tests/brokers/test_schwab_realized_gl.py tests/brokers/fixtures/schwab_realized_gl_min.csv
git commit -m "feat(brokers): SchwabRealizedGLParser produces RealizedGLLot rows

Recognizes Realized G/L CSV by headers (Symbol, Closed Date, Opened Date,
Quantity, Proceeds, Cost Basis (CB), Wash Sale?). Parses both stock and
option lots, money columns with \$/comma, Yes/No flags, and empty
Disallowed Loss as 0.0. Registered after SchwabParser in the registry.
BrokerParser Protocol relaxed to list[Any] since parsers may emit
different value-object types."
```

---

## Phase 3 — Engine

### Task 6: `match_symbol` helper + stitch (G/L hydration + FIFO fallback)

**Why:** The core algorithm. Converts a Sell `Trade` to its G/L-comparable `symbol_raw` string, then hydrates `cost_basis` from G/L (preferred), FIFO (fallback), or leaves NULL.

**Files:**
- Create: `src/net_alpha/engine/stitch.py`
- Test: `tests/engine/test_stitch.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/engine/test_stitch.py`:

```python
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

import pytest

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.engine.stitch import match_symbol, stitch_account
from net_alpha.models.domain import (
    Account,
    ImportRecord,
    OptionDetails,
    Trade,
)
from net_alpha.models.realized_gl import RealizedGLLot


@pytest.fixture
def repo(tmp_path):
    engine = get_engine(tmp_path / "stitch.db")
    init_db(engine)
    return Repository(engine)


def _stock_trade(date_, ticker, action, qty, *, proceeds=None, cost_basis=None):
    return Trade(
        account="schwab/personal",
        date=date_,
        ticker=ticker,
        action=action,
        quantity=qty,
        proceeds=proceeds,
        cost_basis=cost_basis,
    )


def _option_trade(date_, ticker, strike, expiry_iso, cp, action, qty, *, proceeds=None):
    return Trade(
        account="schwab/personal",
        date=date_,
        ticker=ticker,
        action=action,
        quantity=qty,
        proceeds=proceeds,
        option_details=OptionDetails(
            strike=strike, expiry=date.fromisoformat(expiry_iso), call_put=cp
        ),
    )


def _import(repo: Repository, acct: Account, trades: list[Trade]) -> int:
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=len(trades),
    )
    return repo.add_import(acct, rec, trades).import_id


def test_match_symbol_stock_returns_ticker():
    t = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    assert match_symbol(t) == "WRD"


def test_match_symbol_option_returns_schwab_format():
    t = _option_trade(date(2026, 4, 20), "CRCL", 150.00, "2026-06-18", "C", "Sell", 1, proceeds=330.33)
    assert match_symbol(t) == "CRCL 06/18/2026 150.00 C"


def test_stitch_hydrates_sell_from_gl_when_match_exists(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    import_id = _import(repo, acct, [sell])
    repo.add_gl_lots(acct, import_id, [
        RealizedGLLot(
            account_display=acct.display(),
            symbol_raw="WRD", ticker="WRD",
            closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
            quantity=100.0, proceeds=824.96,
            cost_basis=800.66, unadjusted_cost_basis=800.66,
            wash_sale=False, disallowed_loss=0.0, term="Short Term",
        ),
    ])
    summary = stitch_account(repo, acct.id)
    assert summary.from_gl == 1
    sells = repo.get_sells_for_account(acct.id)
    assert sells[0].cost_basis == pytest.approx(800.66)


def test_stitch_falls_back_to_fifo_when_no_gl(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    trades = [
        _stock_trade(date(2026, 3, 10), "AAPL", "Buy", 5, cost_basis=500.0),
        _stock_trade(date(2026, 3, 15), "AAPL", "Buy", 10, cost_basis=1100.0),
        _stock_trade(date(2026, 4, 20), "AAPL", "Sell", 8, proceeds=720.0),
    ]
    _import(repo, acct, trades)
    summary = stitch_account(repo, acct.id)
    assert summary.from_fifo == 1
    sells = repo.get_sells_for_account(acct.id)
    sell = sells[0]
    # Consumed: 5 from $500 lot ($100/sh) + 3 from $110/sh lot = 500 + 330 = 830
    assert sell.cost_basis == pytest.approx(830.0)
    assert sell.basis_source == "fifo"


def test_stitch_marks_unknown_when_no_gl_and_no_buys(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "AAPL", "Sell", 1, proceeds=100.0)
    _import(repo, acct, [sell])
    summary = stitch_account(repo, acct.id)
    assert summary.unknown == 1
    sells = repo.get_sells_for_account(acct.id)
    assert sells[0].cost_basis is None
    assert sells[0].basis_source == "unknown"


def test_stitch_aggregates_multiple_gl_lots_for_one_sell(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    import_id = _import(repo, acct, [sell])
    repo.add_gl_lots(acct, import_id, [
        RealizedGLLot(account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
                      closed_date=date(2026, 4, 20), opened_date=date(2026, 1, 1),
                      quantity=40.0, proceeds=329.99, cost_basis=320.00,
                      unadjusted_cost_basis=320.00, wash_sale=False, disallowed_loss=0.0,
                      term="Short Term"),
        RealizedGLLot(account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
                      closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
                      quantity=60.0, proceeds=494.97, cost_basis=480.66,
                      unadjusted_cost_basis=480.66, wash_sale=False, disallowed_loss=0.0,
                      term="Short Term"),
    ])
    stitch_account(repo, acct.id)
    sells = repo.get_sells_for_account(acct.id)
    assert sells[0].cost_basis == pytest.approx(800.66)


def test_stitch_handles_quantity_mismatch_within_tolerance(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    import_id = _import(repo, acct, [sell])
    repo.add_gl_lots(acct, import_id, [
        RealizedGLLot(account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
                      closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
                      quantity=99.7, proceeds=823.0, cost_basis=798.0,
                      unadjusted_cost_basis=798.0, wash_sale=False, disallowed_loss=0.0,
                      term="Short Term"),
    ])
    summary = stitch_account(repo, acct.id)
    assert summary.from_gl == 1
    assert summary.warnings == []
    sells = repo.get_sells_for_account(acct.id)
    assert sells[0].cost_basis == pytest.approx(798.0)


def test_stitch_records_warning_on_quantity_mismatch_outside_tolerance(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    import_id = _import(repo, acct, [sell])
    repo.add_gl_lots(acct, import_id, [
        RealizedGLLot(account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
                      closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
                      quantity=50.0, proceeds=400.0, cost_basis=380.0,
                      unadjusted_cost_basis=380.0, wash_sale=False, disallowed_loss=0.0,
                      term="Short Term"),
    ])
    summary = stitch_account(repo, acct.id)
    assert summary.from_gl == 1
    assert len(summary.warnings) == 1
    assert "WRD" in summary.warnings[0]


def test_stitch_re_runs_idempotent(repo):
    """Running stitch twice in a row produces the same result."""
    acct = repo.get_or_create_account("schwab", "personal")
    sell = _stock_trade(date(2026, 4, 20), "WRD", "Sell", 100, proceeds=824.96)
    import_id = _import(repo, acct, [sell])
    repo.add_gl_lots(acct, import_id, [
        RealizedGLLot(account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
                      closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
                      quantity=100.0, proceeds=824.96, cost_basis=800.66,
                      unadjusted_cost_basis=800.66, wash_sale=False, disallowed_loss=0.0,
                      term="Short Term"),
    ])
    s1 = stitch_account(repo, acct.id)
    s2 = stitch_account(repo, acct.id)
    assert s1.from_gl == s2.from_gl == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_stitch.py -v`
Expected: ImportError — `engine.stitch` doesn't exist.

- [ ] **Step 3: Implement stitch**

Create `src/net_alpha/engine/stitch.py`:

```python
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade

_QUANTITY_TOLERANCE = 0.005  # 0.5% allowed delta between G/L sum and sell qty


@dataclass
class StitchOutcome:
    """Result for one Sell trade."""
    source: str  # "g_l" | "fifo" | "unknown"
    warning: str | None = None


@dataclass
class StitchSummary:
    """Aggregated counts across all sells in an account."""
    from_gl: int = 0
    from_fifo: int = 0
    unknown: int = 0
    warnings: list[str] = field(default_factory=list)

    def add(self, outcome: StitchOutcome) -> None:
        if outcome.source == "g_l":
            self.from_gl += 1
        elif outcome.source == "fifo":
            self.from_fifo += 1
        else:
            self.unknown += 1
        if outcome.warning:
            self.warnings.append(outcome.warning)


def match_symbol(t: Trade) -> str:
    """Reconstruct the comparable raw symbol from a Trade for G/L matching.

    Stocks: just the ticker.
    Options: 'TICKER MM/DD/YYYY STRIKE.XX C|P' (Schwab format).
    """
    if t.option_details is not None:
        opt = t.option_details
        expiry = opt.expiry.strftime("%m/%d/%Y")
        return f"{t.ticker} {expiry} {opt.strike:.2f} {opt.call_put}"
    return t.ticker


def _try_gl(repo: Repository, sell: Trade, account_id: int) -> StitchOutcome | None:
    gl_rows = repo.get_gl_lots_for_match(
        account_id=account_id,
        symbol_raw=match_symbol(sell),
        closed_date=sell.date,
    )
    if not gl_rows:
        return None
    agg_qty = sum(r.quantity for r in gl_rows)
    agg_cb = sum(r.cost_basis for r in gl_rows)
    warning = None
    if sell.quantity > 0 and abs(agg_qty - sell.quantity) / sell.quantity > _QUANTITY_TOLERANCE:
        warning = (
            f"{match_symbol(sell)} on {sell.date.isoformat()}: "
            f"G/L lot quantities ({agg_qty:.4f}) don't sum to sell quantity ({sell.quantity:.4f})"
        )
    repo.update_trade_basis(sell.id, cost_basis=agg_cb, basis_source="g_l")
    return StitchOutcome(source="g_l", warning=warning)


def _try_fifo(repo: Repository, sell: Trade, account_id: int) -> StitchOutcome | None:
    buys = repo.get_buys_before_date(
        account_id=account_id, ticker=sell.ticker, before_date=sell.date
    )
    if not buys:
        return None
    needed = sell.quantity
    consumed_qty = 0.0
    consumed_basis = 0.0
    for b in buys:
        take = min(b.quantity, needed - consumed_qty)
        if take <= 0:
            break
        per_unit = (b.cost_basis or 0.0) / b.quantity if b.quantity > 0 else 0.0
        consumed_qty += take
        consumed_basis += take * per_unit
        if consumed_qty >= needed * (1 - _QUANTITY_TOLERANCE):
            break
    if consumed_qty < needed * (1 - _QUANTITY_TOLERANCE):
        return None  # Not enough buys to cover
    repo.update_trade_basis(sell.id, cost_basis=consumed_basis, basis_source="fifo")
    return StitchOutcome(source="fifo")


def stitch_account(repo: Repository, account_id: int) -> StitchSummary:
    """Hydrate cost_basis on every Sell trade in the account.

    For each Sell:
      1. Try G/L match (preferred).
      2. Fall back to FIFO consumption of buy lots.
      3. Otherwise mark basis_source='unknown' and leave cost_basis NULL.
    """
    summary = StitchSummary()
    for sell in repo.get_sells_for_account(account_id):
        outcome = _try_gl(repo, sell, account_id)
        if outcome is None:
            outcome = _try_fifo(repo, sell, account_id)
        if outcome is None:
            repo.update_trade_basis(sell.id, cost_basis=None, basis_source="unknown")
            outcome = StitchOutcome(source="unknown")
        summary.add(outcome)
    return summary
```

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/engine/test_stitch.py -v`
Expected: All 9 PASS.

- [ ] **Step 5: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/engine/stitch.py tests/engine/test_stitch.py
git commit -m "feat(engine): stitch — hydrate Sell cost_basis from G/L or FIFO

stitch_account walks every Sell trade in an account and populates
cost_basis from realized_gl_lots (preferred, by symbol+closed_date)
or FIFO buy-lot consumption (fallback). Records basis_source on
each Sell so the UI can surface confidence/source. Returns a
StitchSummary with counts and any quantity-mismatch warnings."
```

---

### Task 7: Wash-sale merge logic

**Why:** After the engine runs on hydrated trades, merge its violations with Schwab's per-lot verdicts. Schwab is authoritative for same-account exact-ticker; engine adds cross-account and substantially-identical detections.

**Files:**
- Create: `src/net_alpha/engine/merge.py`
- Test: `tests/engine/test_merge.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/engine/test_merge.py`:

```python
from __future__ import annotations

from datetime import date

from net_alpha.engine.merge import merge_violations
from net_alpha.models.domain import WashSaleViolation
from net_alpha.models.realized_gl import RealizedGLLot


def _gl(symbol="WRD", closed=(2026, 4, 20), opened=(2026, 2, 11), wash=False, disallowed=0.0):
    return RealizedGLLot(
        account_display="schwab/personal",
        symbol_raw=symbol, ticker=symbol.split()[0],
        closed_date=date(*closed), opened_date=date(*opened),
        quantity=1.0, proceeds=10.0, cost_basis=20.0, unadjusted_cost_basis=20.0,
        wash_sale=wash, disallowed_loss=disallowed, term="Short Term",
    )


def _v(ticker="WRD", loss_date=(2026, 4, 20), buy_date=(2026, 4, 25),
       account="schwab/personal", buy_account=None,
       loss=10.0, qty=1.0, confidence="Confirmed"):
    return WashSaleViolation(
        loss_trade_id="t1",
        replacement_trade_id="t2",
        confidence=confidence,
        disallowed_loss=loss,
        matched_quantity=qty,
        loss_account=account,
        buy_account=buy_account or account,
        loss_sale_date=date(*loss_date),
        triggering_buy_date=date(*buy_date),
        ticker=ticker,
    )


def test_schwab_yes_creates_confirmed_violation():
    """A Schwab G/L row flagged Wash Sale=Yes becomes a Confirmed violation
    sourced from Schwab even if the engine missed it."""
    schwab_lots = [_gl(wash=True, disallowed=130.33)]
    engine_violations: list[WashSaleViolation] = []
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={1: schwab_lots},
    )
    assert len(merged) == 1
    assert merged[0].source == "schwab_g_l"
    assert merged[0].confidence == "Confirmed"
    assert merged[0].disallowed_loss == 130.33


def test_schwab_no_suppresses_engine_same_account_exact_ticker():
    """Engine flags a same-account exact-ticker wash sale that Schwab
    explicitly cleared. Engine's verdict is downgraded to Unclear."""
    schwab_lots = [_gl(wash=False)]
    engine_violations = [
        _v(ticker="WRD", loss_date=(2026, 4, 20),
           account="schwab/personal", buy_account="schwab/personal"),
    ]
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={1: schwab_lots},
    )
    assert len(merged) == 1
    assert merged[0].source == "engine"
    assert merged[0].confidence == "Unclear"


def test_engine_flag_dedupes_with_matching_schwab_yes():
    """Both engine and Schwab flagged the same wash sale — only Schwab's row survives."""
    schwab_lots = [_gl(wash=True, disallowed=130.33)]
    engine_violations = [
        _v(ticker="WRD", loss_date=(2026, 4, 20),
           account="schwab/personal", buy_account="schwab/personal"),
    ]
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={1: schwab_lots},
    )
    assert len(merged) == 1
    assert merged[0].source == "schwab_g_l"


def test_engine_cross_account_wash_sale_kept_as_probable():
    """Engine flags a wash sale where the buy is in a DIFFERENT account.
    Schwab can't see other brokers, so the engine keeps the verdict."""
    schwab_lots = [_gl(wash=False)]
    engine_violations = [
        _v(ticker="WRD", loss_date=(2026, 4, 20),
           account="schwab/personal", buy_account="fidelity/joint",
           confidence="Probable"),
    ]
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={1: schwab_lots},
    )
    assert len(merged) == 1
    assert merged[0].source == "engine"
    assert merged[0].confidence == "Probable"


def test_no_gl_for_account_keeps_engine_violations_unchanged():
    """When an account has no G/L coverage, engine output is preserved verbatim."""
    engine_violations = [
        _v(ticker="WRD", confidence="Probable"),
    ]
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={},  # no G/L data for any account
    )
    assert len(merged) == 1
    assert merged[0].source == "engine"
    assert merged[0].confidence == "Probable"


def test_substantially_identical_engine_detection_marked_unclear():
    """Engine flags an ETF-pair (e.g. SPY loss + VOO buy) within the Schwab
    account. Schwab's G/L doesn't have a 'wash sale' row for the SPY ticker.
    Surface as Unclear since Schwab doesn't model substitutes."""
    schwab_lots = [_gl(symbol="SPY", wash=False)]
    engine_violations = [
        _v(ticker="SPY", loss_date=(2026, 4, 20),
           account="schwab/personal", buy_account="schwab/personal",
           confidence="Probable"),  # engine called this "Probable" via etf_pair
    ]
    merged = merge_violations(
        engine_violations=engine_violations,
        gl_lots_by_account={1: schwab_lots},
        substitute_tickers={"SPY": ["VOO", "IVV"]},
        replacement_tickers={"v1": "VOO"},  # the buy was VOO, see below
    )
    # The engine's loss is on SPY but the replacement was VOO (different ticker)
    # — Schwab sees the SPY row as not-wash-sale, but our engine knows VOO is
    # substantially identical. Mark as Unclear to surface for review.
    assert len(merged) == 1
    assert merged[0].source == "engine"
    assert merged[0].confidence == "Unclear"
```

Note: `substitute_tickers` and `replacement_tickers` are wiring for ETF-pair logic. Keep them as keyword args in `merge_violations` even if the implementation defers the substantial-identical reasoning. Test `test_substantially_identical_engine_detection_marked_unclear` exercises the path.

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_merge.py -v`
Expected: ImportError — module doesn't exist.

- [ ] **Step 3: Implement merge**

Create `src/net_alpha/engine/merge.py`:

```python
from __future__ import annotations

from datetime import date
from uuid import uuid4

from net_alpha.models.domain import WashSaleViolation
from net_alpha.models.realized_gl import RealizedGLLot


def _gl_to_violation(lot: RealizedGLLot, account_display: str) -> WashSaleViolation:
    """Convert a Schwab G/L lot flagged as wash_sale into a WashSaleViolation."""
    return WashSaleViolation(
        id=str(uuid4()),
        loss_trade_id="schwab_gl_" + lot.compute_natural_key()[:16],
        replacement_trade_id="schwab_gl_" + lot.compute_natural_key()[16:32],
        confidence="Confirmed",
        disallowed_loss=lot.disallowed_loss,
        matched_quantity=lot.quantity,
        loss_account=account_display,
        buy_account=account_display,  # Schwab same-account
        loss_sale_date=lot.closed_date,
        triggering_buy_date=lot.opened_date,
        ticker=lot.ticker,
        source="schwab_g_l",
    )


def _is_same_account(v: WashSaleViolation) -> bool:
    return v.loss_account == v.buy_account


def _matches_lot(v: WashSaleViolation, lot: RealizedGLLot, account_display: str) -> bool:
    """Engine violation is the 'same' wash sale Schwab is reporting."""
    return (
        v.loss_account == account_display
        and v.ticker == lot.ticker
        and v.loss_sale_date == lot.closed_date
    )


def _engine_v_with_overrides(v: WashSaleViolation, **overrides) -> WashSaleViolation:
    """Return a copy with mutated fields. WashSaleViolation is a Pydantic BaseModel."""
    data = v.model_dump()
    data.update(overrides)
    return WashSaleViolation(**data)


def merge_violations(
    *,
    engine_violations: list[WashSaleViolation],
    gl_lots_by_account: dict[int, list[RealizedGLLot]],
    substitute_tickers: dict[str, list[str]] | None = None,
    replacement_tickers: dict[str, str] | None = None,
) -> list[WashSaleViolation]:
    """Merge engine output with Schwab's per-lot verdicts.

    Rules:
      1. For each Schwab lot with wash_sale=True → emit Confirmed/schwab_g_l violation.
      2. For each engine violation:
         a. If same-account exact-ticker matches a Schwab lot:
              - Schwab said Yes → drop engine's (already covered by rule 1)
              - Schwab said No → engine downgraded to Unclear (likely engine bug, surface)
         b. If cross-account (loss_account != buy_account) → keep with source='engine'
         c. If same-account but not exact-ticker (substantially-identical/ETF pair),
            Schwab can't model this → surface as Unclear/engine
         d. If account has no G/L coverage → keep engine output unchanged
    """
    substitute_tickers = substitute_tickers or {}
    replacement_tickers = replacement_tickers or {}

    out: list[WashSaleViolation] = []

    # Index G/L lots by their account_display (the only field violations carry).
    # gl_lots_by_account uses int keys, but every lot carries account_display, so
    # we build a flat lookup keyed by account_display.
    lots_by_account_display: dict[str, list[RealizedGLLot]] = {}
    for lots in gl_lots_by_account.values():
        for lot in lots:
            lots_by_account_display.setdefault(lot.account_display, []).append(lot)

    # Rule 1: Schwab Yes → emit
    for account_display, lots in lots_by_account_display.items():
        for lot in lots:
            if lot.wash_sale:
                out.append(_gl_to_violation(lot, account_display))

    # Rule 2: process engine violations
    for v in engine_violations:
        same_account = _is_same_account(v)
        account_lots = lots_by_account_display.get(v.loss_account, [])

        if not account_lots:
            # 2d: no G/L coverage for this account → keep as-is, ensure source set
            out.append(_engine_v_with_overrides(v, source=getattr(v, "source", None) or "engine"))
            continue

        # Find any Schwab lot for the same loss-sale (any wash_sale value)
        matching_lots = [lot for lot in account_lots if _matches_lot(v, lot, v.loss_account)]

        if same_account and matching_lots:
            schwab_yes = any(lot.wash_sale for lot in matching_lots)
            if schwab_yes:
                # 2a-yes: Schwab already covered this; drop engine's duplicate.
                continue
            # 2a-no: engine flagged but Schwab cleared — likely engine bug, surface as Unclear.
            out.append(_engine_v_with_overrides(v, confidence="Unclear", source="engine"))
            continue

        if not same_account:
            # 2b: cross-account → keep with engine source
            out.append(_engine_v_with_overrides(v, source="engine"))
            continue

        # 2c: same account but no matching Schwab lot row for this ticker — likely
        # substantially-identical (e.g. SPY loss + VOO buy). Surface as Unclear.
        out.append(_engine_v_with_overrides(v, confidence="Unclear", source="engine"))

    return out
```

Note: `WashSaleViolation` doesn't currently have a `source` field on the Pydantic model. Add it next.

- [ ] **Step 4: Add `source` field to `WashSaleViolation` Pydantic model**

In `src/net_alpha/models/domain.py`, find the `WashSaleViolation` class (around line 105) and add a `source` field:

```python
class WashSaleViolation(BaseModel):
    """A detected wash sale linking a loss sale to its triggering replacement."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    loss_trade_id: str
    replacement_trade_id: str
    confidence: str  # "Confirmed", "Probable", or "Unclear"
    disallowed_loss: float
    matched_quantity: float
    loss_account: str = ""
    buy_account: str = ""
    loss_sale_date: date | None = None
    triggering_buy_date: date | None = None
    ticker: str = ""
    source: str = "engine"  # "schwab_g_l" | "engine"
```

Also update `_violation_to_row` and `_row_to_violation` in `src/net_alpha/db/repository.py` to round-trip the `source` field. Find `_row_to_violation` (around line 217) and add `source=row.source` to the constructed `WashSaleViolation`. Find `_violation_to_row` (around line 317) and add `source=getattr(v, "source", "engine")` to the constructed `WashSaleViolationRow`.

- [ ] **Step 5: Run merge tests**

Run: `uv run pytest tests/engine/test_merge.py -v`
Expected: All 6 PASS.

- [ ] **Step 6: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/engine/merge.py src/net_alpha/models/domain.py src/net_alpha/db/repository.py tests/engine/test_merge.py
git commit -m "feat(engine): merge_violations — combine engine output with Schwab verdicts

Rules:
  1. Schwab wash_sale=Yes  → Confirmed/schwab_g_l violation
  2. Engine + Schwab agree → keep Schwab's
  3. Engine same-acct cleared by Schwab → downgrade engine to Unclear
  4. Engine cross-account  → Probable/engine
  5. Engine same-acct without matching Schwab row (substantially identical)
                          → Unclear/engine
  6. No G/L for account    → engine output unchanged

WashSaleViolation gains a source field; round-tripped via repository."
```

---

## Phase 4 — Web integration

### Task 8: Multi-file upload route + plumb stitch + merge

**Why:** Web users get the new pipeline. Drop zone accepts multiple files; backend detects each one, parses with the right parser, runs stitch + engine + merge end-to-end.

**Files:**
- Modify: `src/net_alpha/web/routes/imports.py`
- Test: `tests/web/test_multi_file_upload.py`
- Fixture: reuse `tests/brokers/fixtures/schwab_realized_gl_min.csv` and `tests/web/fixtures/schwab_minimal.csv`

- [ ] **Step 1: Write the failing tests**

Create `tests/web/test_multi_file_upload.py`:

```python
from __future__ import annotations

from pathlib import Path

import pytest

GL_FIXTURE = Path(__file__).parent.parent / "brokers" / "fixtures" / "schwab_realized_gl_min.csv"
TX_FIXTURE = Path(__file__).parent / "fixtures" / "schwab_minimal.csv"


def test_preview_with_two_files_returns_per_file_detection(client):
    with TX_FIXTURE.open("rb") as tx, GL_FIXTURE.open("rb") as gl:
        resp = client.post(
            "/imports/preview",
            files=[
                ("files", ("schwab_tx.csv", tx, "text/csv")),
                ("files", ("schwab_gl.csv", gl, "text/csv")),
            ],
        )
    assert resp.status_code == 200
    body = resp.text.lower()
    assert "schwab" in body
    assert "transaction" in body or "trades" in body
    assert "g/l" in body or "realized" in body or "lot" in body


def test_preview_with_unrecognized_file_includes_warning(client, tmp_path):
    bad = tmp_path / "bad.csv"
    bad.write_text("totally,unknown,format\n1,2,3\n")
    with TX_FIXTURE.open("rb") as tx, bad.open("rb") as b:
        resp = client.post(
            "/imports/preview",
            files=[
                ("files", ("schwab_tx.csv", tx, "text/csv")),
                ("files", ("bad.csv", b, "text/csv")),
            ],
        )
    assert resp.status_code == 200
    assert "unrecogniz" in resp.text.lower() or "unknown" in resp.text.lower()


def test_upload_two_files_creates_import_and_gl_lots(client, repo):
    with TX_FIXTURE.open("rb") as tx, GL_FIXTURE.open("rb") as gl:
        resp = client.post(
            "/imports",
            files=[
                ("files", ("schwab_tx.csv", tx, "text/csv")),
                ("files", ("schwab_gl.csv", gl, "text/csv")),
            ],
            data={"account": "personal"},
            follow_redirects=False,
        )
    assert resp.status_code == 303
    imports = repo.list_imports()
    assert len(imports) >= 1
    acct = repo.get_account("schwab", "personal")
    assert acct is not None
    gl_lots = repo.get_gl_lots_for_ticker(acct.id, "WRD")
    assert len(gl_lots) == 1


def test_upload_only_transactions_runs_fifo_fallback(client, repo):
    """A pure transactions upload still produces useful violations via FIFO fallback."""
    with TX_FIXTURE.open("rb") as tx:
        resp = client.post(
            "/imports",
            files=[("files", ("schwab_tx.csv", tx, "text/csv"))],
            data={"account": "personal"},
            follow_redirects=False,
        )
    assert resp.status_code == 303
    # The TSLA loss + rebuy fixture should still produce >= 1 violation via FIFO basis.
    assert len(repo.all_violations()) >= 1


def test_upload_only_gl_succeeds_without_transactions(client, repo):
    """G/L-only upload: G/L lots are stored, no Sells exist to hydrate, no error."""
    with GL_FIXTURE.open("rb") as gl:
        resp = client.post(
            "/imports",
            files=[("files", ("schwab_gl.csv", gl, "text/csv"))],
            data={"account": "personal"},
            follow_redirects=False,
        )
    assert resp.status_code == 303
    acct = repo.get_account("schwab", "personal")
    assert acct is not None
    assert len(repo.get_gl_lots_for_ticker(acct.id, "WRD")) == 1


def test_upload_zero_recognized_files_returns_400(client, tmp_path):
    bad = tmp_path / "bad.csv"
    bad.write_text("totally,unknown,format\n1,2,3\n")
    with bad.open("rb") as b:
        resp = client.post(
            "/imports",
            files=[("files", ("bad.csv", b, "text/csv"))],
            data={"account": "personal"},
            follow_redirects=False,
        )
    assert resp.status_code == 400
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/web/test_multi_file_upload.py -v`
Expected: All fail — current routes use `file: UploadFile` (singular) and don't run G/L parser.

- [ ] **Step 3: Refactor `imports.py` for multi-file**

Replace `src/net_alpha/web/routes/imports.py`:

```python
from __future__ import annotations

import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse

from net_alpha.brokers.registry import detect_broker
from net_alpha.brokers.schwab import SchwabParser
from net_alpha.brokers.schwab_realized_gl import SchwabRealizedGLParser
from net_alpha.db.repository import Repository
from net_alpha.engine.detector import detect_in_window
from net_alpha.engine.merge import merge_violations
from net_alpha.engine.stitch import stitch_account
from net_alpha.ingest.csv_loader import compute_csv_sha256, load_csv
from net_alpha.ingest.dedup import filter_new
from net_alpha.models.domain import ImportRecord
from net_alpha.models.realized_gl import RealizedGLLot
from net_alpha.web.dependencies import get_etf_pairs, get_repository

router = APIRouter()


@router.get("/imports", response_class=HTMLResponse)
def imports_page(
    request: Request,
    flash: str | None = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    records = repo.list_imports()
    return request.app.state.templates.TemplateResponse(
        request, "imports.html", {"imports": records, "flash": flash},
    )


@router.delete("/imports/{import_id}", response_class=HTMLResponse)
def remove_import(
    import_id: int,
    request: Request,
    repo: Repository = Depends(get_repository),
    etf_pairs: dict = Depends(get_etf_pairs),
) -> HTMLResponse:
    if repo.get_import(import_id) is None:
        raise HTTPException(status_code=404, detail=f"Import #{import_id} not found")
    result = repo.remove_import(import_id)
    if result.recompute_window is not None:
        win_start, win_end = result.recompute_window
        det = detect_in_window(
            repo.trades_in_window(win_start, win_end), win_start, win_end, etf_pairs=etf_pairs,
        )
        repo.replace_violations_in_window(win_start, win_end, det.violations)
        repo.replace_lots_in_window(win_start, win_end, det.lots)
    return request.app.state.templates.TemplateResponse(
        request, "_imports_table.html", {"imports": repo.list_imports()},
    )


# ----- helpers --------------------------------------------------------------

def _save_to_temp(raw: bytes, filename: str) -> Path:
    suffix = Path(filename or "uploaded.csv").suffix or ".csv"
    fd = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    fd.write(raw)
    fd.close()
    return Path(fd.name)


def _read_uploaded(file: UploadFile) -> tuple[bytes, list[str], list[dict[str, str]]]:
    """Returns (raw bytes, headers, rows)."""
    raw = file.file.read()
    file.file.seek(0)
    tmp = _save_to_temp(raw, file.filename or "uploaded.csv")
    try:
        headers, rows = load_csv(str(tmp))
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    return raw, headers, rows


# ----- preview --------------------------------------------------------------

@router.post("/imports/preview", response_class=HTMLResponse)
async def preview_upload(
    request: Request,
    files: list[UploadFile] = File(...),
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    detections = []
    for f in files:
        raw = await f.read()
        tmp = _save_to_temp(raw, f.filename or "uploaded.csv")
        try:
            headers, rows = load_csv(str(tmp))
        finally:
            try:
                tmp.unlink()
            except OSError:
                pass
        parser = detect_broker(headers)
        detections.append({
            "filename": f.filename or "uploaded.csv",
            "size": len(raw),
            "parser_name": parser.name if parser else None,
            "row_count": len(rows),
        })
    accounts = [a.display() for a in repo.list_accounts()]
    return request.app.state.templates.TemplateResponse(
        request, "_import_modal.html",
        {
            "detections": detections,
            "accounts": accounts,
            "any_recognized": any(d["parser_name"] for d in detections),
        },
    )


# ----- upload ---------------------------------------------------------------

@router.post("/imports", response_class=HTMLResponse)
async def upload(
    request: Request,
    files: list[UploadFile] = File(...),
    account: str = Form(...),
    repo: Repository = Depends(get_repository),
    etf_pairs: dict = Depends(get_etf_pairs),
) -> HTMLResponse:
    # Materialize all file contents up-front
    materialized = []  # list[tuple[filename, raw_bytes, headers, rows, parser]]
    for f in files:
        raw = await f.read()
        tmp = _save_to_temp(raw, f.filename or "uploaded.csv")
        try:
            headers, rows = load_csv(str(tmp))
        finally:
            try:
                tmp.unlink()
            except OSError:
                pass
        parser = detect_broker(headers)
        materialized.append((f.filename or "uploaded.csv", raw, headers, rows, parser))

    if not any(p for *_, p in materialized):
        raise HTTPException(status_code=400, detail="No recognized broker formats among uploaded files")

    # All files are associated with one Schwab account (we only have Schwab parsers).
    acct = repo.get_or_create_account("schwab", account)

    new_trade_count = 0
    dup_trade_count = 0
    new_gl_count = 0
    affected_dates: list = []  # date objects (for window calc)

    for filename, raw, headers, rows, parser in materialized:
        if parser is None:
            continue

        if isinstance(parser, SchwabParser):
            trades = parser.parse(rows, account_display=acct.display())
            existing = repo.existing_natural_keys(acct.id)
            new_trades = filter_new(trades, existing)
            sha = compute_csv_sha256_bytes(raw)
            record = ImportRecord(
                account_id=acct.id,
                csv_filename=filename,
                csv_sha256=sha,
                imported_at=datetime.now(),
                trade_count=len(new_trades),
            )
            result = repo.add_import(acct, record, new_trades)
            new_trade_count += result.new_trades
            dup_trade_count += len(trades) - len(new_trades)
            for t in new_trades:
                affected_dates.append(t.date)

        elif isinstance(parser, SchwabRealizedGLParser):
            lots = parser.parse(rows, account_display=acct.display())
            sha = compute_csv_sha256_bytes(raw)
            record = ImportRecord(
                account_id=acct.id,
                csv_filename=filename,
                csv_sha256=sha,
                imported_at=datetime.now(),
                trade_count=0,  # G/L import has no trades
            )
            empty_result = repo.add_import(acct, record, [])
            inserted = repo.add_gl_lots(acct, empty_result.import_id, lots)
            new_gl_count += inserted
            for lot in lots:
                affected_dates.append(lot.closed_date)

    # Stitch + recompute, scoped to affected window
    stitched = stitch_account(repo, acct.id)

    if affected_dates:
        win_start = min(affected_dates) - timedelta(days=30)
        win_end = max(affected_dates) + timedelta(days=30)
        det = detect_in_window(
            repo.trades_in_window(win_start, win_end), win_start, win_end, etf_pairs=etf_pairs,
        )
        gl_lots = {acct.id: repo.get_gl_lots_for_ticker_range(acct.id, win_start, win_end)} \
                  if hasattr(repo, "get_gl_lots_for_ticker_range") else {acct.id: []}
        # Simpler: load all gl lots and filter in merge — load only what's needed for the window
        merged = merge_violations(
            engine_violations=det.violations,
            gl_lots_by_account=gl_lots,
        )
        repo.replace_violations_in_window(win_start, win_end, merged)
        repo.replace_lots_in_window(win_start, win_end, det.lots)

    msg_parts: list[str] = []
    if new_trade_count: msg_parts.append(f"Imported {new_trade_count} new trades")
    if dup_trade_count: msg_parts.append(f"skipped {dup_trade_count} duplicate trades")
    if new_gl_count: msg_parts.append(f"imported {new_gl_count} G/L lot rows")
    if stitched.from_gl: msg_parts.append(f"hydrated {stitched.from_gl} sells from G/L")
    if stitched.from_fifo: msg_parts.append(f"hydrated {stitched.from_fifo} sells via FIFO")
    if stitched.warnings: msg_parts.append(f"{len(stitched.warnings)} warning(s)")
    if not msg_parts: msg_parts.append("No changes")
    msg = " · ".join(msg_parts)
    return RedirectResponse(url=f"/imports?flash={quote(msg)}", status_code=303)


def compute_csv_sha256_bytes(raw: bytes) -> str:
    """SHA256 of raw bytes (used when we already have the bytes in memory)."""
    import hashlib
    h = hashlib.sha256()
    h.update(raw)
    return h.hexdigest()
```

The route uses `gl_lots_by_account = {acct.id: ...}` against a getter that may not exist. Simplify by loading **all** lots for the account and letting `merge_violations` filter by account_display:

Replace the `gl_lots = {...}` line and the merge call with:

```python
        all_gl_lots = repo.get_gl_lots_for_account(acct.id)
        merged = merge_violations(
            engine_violations=det.violations,
            gl_lots_by_account={acct.id: all_gl_lots},
        )
```

- [ ] **Step 4: Add `get_gl_lots_for_account` to Repository**

In `src/net_alpha/db/repository.py`, append this method to the `Repository` class:

```python
    def get_gl_lots_for_account(self, account_id: int) -> list[RealizedGLLot]:
        with Session(self._engine) as s:
            rows = s.exec(
                select(RealizedGLLotRow).where(RealizedGLLotRow.account_id == account_id)
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]
```

- [ ] **Step 5: Update `_import_modal.html` to render the per-file detection list**

Replace `src/net_alpha/web/templates/_import_modal.html` content:

```html
<div class="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 p-6"
     onclick="event.stopPropagation()">
  <div class="flex justify-between items-center mb-4">
    <h2 class="text-xl">Import {{ detections|length }} file{{ "s" if detections|length != 1 else "" }}</h2>
    <button onclick="document.getElementById('import-modal').classList.add('hidden')"
            class="text-slate-500 hover:text-slate-800 text-2xl leading-none">&times;</button>
  </div>

  <div class="space-y-2 mb-4">
    {% for d in detections %}
      {% if d.parser_name == "schwab" %}
        <div class="border border-emerald-200 bg-emerald-50 rounded p-2 text-sm">
          <span class="font-medium">✓ Transaction History</span>
          <span class="text-slate-600"> — {{ d.row_count }} rows</span>
          <div class="text-xs text-slate-500 mt-1">{{ d.filename }}</div>
        </div>
      {% elif d.parser_name == "schwab_realized_gl" %}
        <div class="border border-emerald-200 bg-emerald-50 rounded p-2 text-sm">
          <span class="font-medium">✓ Realized G/L (Schwab)</span>
          <span class="text-slate-600"> — {{ d.row_count }} lot rows</span>
          <div class="text-xs text-slate-500 mt-1">{{ d.filename }}</div>
        </div>
      {% else %}
        <div class="border border-amber-300 bg-amber-50 rounded p-2 text-sm">
          <span class="font-medium">⚠ Unrecognized format</span>
          <div class="text-xs text-slate-500 mt-1">{{ d.filename }} — no parser matched headers</div>
        </div>
      {% endif %}
    {% endfor %}
  </div>

  {% if any_recognized %}
    <form action="/imports" method="post" enctype="multipart/form-data" class="space-y-4">
      <div>
        <label class="block text-xs text-slate-500 uppercase mb-1">Files (re-attach to confirm)</label>
        <input type="file" name="files" accept=".csv" multiple required class="text-sm"/>
        <p class="text-xs text-slate-500 mt-1">Browser security requires re-attaching the files at submit time.</p>
      </div>

      <div>
        <label class="block text-xs text-slate-500 uppercase mb-1">Account label</label>
        <input type="text" name="account" required list="modal-account-list"
               class="border border-slate-300 rounded px-2 py-1 text-sm w-full"
               placeholder="e.g. personal, joint, ira"/>
        <datalist id="modal-account-list">
          {% for a in accounts %}
            <option value="{{ a.split('/')[1] if '/' in a else a }}">
          {% endfor %}
        </datalist>
      </div>

      <p class="text-xs text-slate-500">⚠ This is informational only. Consult a tax professional before filing.</p>

      <div class="flex justify-end gap-2">
        <button type="button" class="btn-ghost"
                onclick="document.getElementById('import-modal').classList.add('hidden')">Cancel</button>
        <button type="submit" class="btn">Import</button>
      </div>
    </form>
  {% else %}
    <div class="bg-red-50 border border-red-300 text-red-800 rounded p-3 text-sm">
      None of the uploaded files matched a known broker format. Please drop a Schwab Transaction History or Realized G/L CSV.
    </div>
    <div class="flex justify-end mt-4">
      <button type="button" class="btn-ghost"
              onclick="document.getElementById('import-modal').classList.add('hidden')">Close</button>
    </div>
  {% endif %}
</div>
```

- [ ] **Step 6: Update `_drop_zone.html` for multi-file**

Replace `src/net_alpha/web/templates/_drop_zone.html`:

```html
<div class="border-2 border-dashed border-primary/40 rounded-lg p-8 text-center bg-white"
     id="drop-zone"
     hx-post="/imports/preview"
     hx-encoding="multipart/form-data"
     hx-trigger="change from:#csv-input"
     hx-target="#import-modal-content"
     hx-swap="innerHTML"
     onclick="document.getElementById('csv-input').click()"
     ondragover="event.preventDefault(); this.classList.add('bg-primary/5');"
     ondragleave="this.classList.remove('bg-primary/5');"
     ondrop="event.preventDefault(); this.classList.remove('bg-primary/5');
             const dt = new DataTransfer();
             for (const f of event.dataTransfer.files) dt.items.add(f);
             const inp = document.getElementById('csv-input');
             inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true }));
             document.getElementById('import-modal').classList.remove('hidden');">
  <p>Drop one or more Schwab CSVs here or <a class="text-primary underline cursor-pointer">click to browse</a></p>
  <p class="text-xs text-slate-500 mt-1">Transaction History · Realized G/L · max 50 MB each</p>
  <input type="file" id="csv-input" name="files" accept=".csv" multiple class="hidden"
         onchange="document.getElementById('import-modal').classList.remove('hidden');"/>
</div>

<div id="import-modal" class="hidden fixed inset-0 bg-black/40 z-50 flex items-center justify-center"
     onclick="this.classList.add('hidden')">
  <div id="import-modal-content"></div>
</div>
```

- [ ] **Step 7: Run web tests**

Run: `uv run pytest tests/web/test_multi_file_upload.py -v`
Expected: All 6 PASS.

- [ ] **Step 8: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass. (The earlier `test_upload_full_flow_creates_import_and_violations` test in `test_upload_flow.py` may need its `files=` shape updated — see Step 9.)

- [ ] **Step 9: Update `test_upload_flow.py` for new field name**

The earlier test in `tests/web/test_upload_flow.py` posts `files={"file": ...}` (singular). Update it to use the new `files` (plural list) shape:

```python
def test_upload_full_flow_creates_import_and_violations(client, repo):
    with FIXTURE.open("rb") as f:
        resp = client.post(
            "/imports",
            files=[("files", ("schwab.csv", f, "text/csv"))],
            data={"account": "personal"},
            follow_redirects=False,
        )
    assert resp.status_code == 303
    assert resp.headers["location"].startswith("/imports?flash=")
    imports = repo.list_imports()
    assert len(imports) == 1
    assert imports[0].account_display == "schwab/personal"
    assert imports[0].csv_filename == "schwab.csv"
    assert len(repo.all_violations()) >= 1
```

Also update `test_preview_returns_modal_with_detected_broker` and `test_upload_unrecognized_format_returns_modal_error` in the same file:

```python
def test_preview_returns_modal_with_detected_broker(client):
    with FIXTURE.open("rb") as f:
        resp = client.post(
            "/imports/preview",
            files=[("files", ("schwab.csv", f, "text/csv"))],
        )
    assert resp.status_code == 200
    assert "transaction" in resp.text.lower() or "trades" in resp.text.lower()


def test_upload_unrecognized_format_returns_modal_error(client, tmp_path):
    bad = tmp_path / "bad.csv"
    bad.write_text("totally,unknown,format\n1,2,3\n")
    with bad.open("rb") as f:
        resp = client.post(
            "/imports/preview",
            files=[("files", ("bad.csv", f, "text/csv"))],
        )
    assert resp.status_code == 200
    assert "unrecogniz" in resp.text.lower() or "unknown" in resp.text.lower()
```

Run again: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 10: Commit**

```bash
git add src/net_alpha/web/routes/imports.py src/net_alpha/web/templates/_import_modal.html src/net_alpha/web/templates/_drop_zone.html src/net_alpha/db/repository.py tests/web/test_multi_file_upload.py tests/web/test_upload_flow.py
git commit -m "feat(web): multi-file upload with G/L hydration + merge

Drop zone accepts multiple CSVs (Schwab Transactions, Realized G/L,
or any combination). Per-file detection cards in preview modal.
Upload route runs each file through its parser, then stitch +
detect + merge end-to-end, scoped to the affected ±30-day window.
Flash message reports counts: trades, dups, G/L lots, hydrated sells,
warnings."
```

---

## Phase 5 — UI polish

### Task 9: Violation source badge

**Why:** Surface provenance on each violation so the user knows whether it came from Schwab's 1099-B or our engine (cross-account / substantially-identical).

**Files:**
- Modify: `src/net_alpha/web/templates/_violation_card.html`
- Test: `tests/web/test_violation_badge.py` (new)

- [ ] **Step 1: Note the current shape of `_violation_card.html`**

The current template (verbatim):

```html
<div class="border-l-4 pl-3"
     style="border-left-color: {% if violation.confidence=='Confirmed' %}#DC2626{% elif violation.confidence=='Probable' %}#F59E0B{% else %}#3B82F6{% endif %};">
  <div class="text-sm"><strong>Loss in</strong> {{ violation.loss_account or "-" }} → <strong>triggered by</strong> {{ violation.buy_account or "-" }} on {{ violation.triggering_buy_date or "-" }}</div>
  <div class="text-sm">Disallowed: <span class="font-mono text-confirmed">${{ "%.2f"|format(violation.disallowed_loss) }}</span> · Matched qty: <span class="font-mono">{{ violation.matched_quantity }}</span></div>
  <a href="/ticker/{{ violation.ticker }}" class="text-primary text-sm underline">View ticker drilldown →</a>
</div>
```

The variable is `violation`. We append a source badge as a new line after the "Loss in ... triggered by ..." line.

- [ ] **Step 2: Write the failing test**

Create `tests/web/test_violation_badge.py`:

```python
"""Test that violation source badges render correctly in HTML output."""
from __future__ import annotations

from datetime import date, datetime, timedelta

import pytest

from net_alpha.models.domain import Account, ImportRecord, Trade, WashSaleViolation


def _seed_violation(repo, source: str, confidence: str = "Confirmed") -> None:
    """Insert a fixture trade pair + a violation with a specific source."""
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=2,
    )
    trades = [
        Trade(account=acct.display(), date=date(2026, 4, 1), ticker="WRD",
              action="Buy", quantity=100, cost_basis=900.0),
        Trade(account=acct.display(), date=date(2026, 4, 20), ticker="WRD",
              action="Sell", quantity=100, proceeds=800.0, cost_basis=900.0),
    ]
    repo.add_import(acct, rec, trades)
    v = WashSaleViolation(
        loss_trade_id="loss1",
        replacement_trade_id="rep1",
        confidence=confidence,
        disallowed_loss=100.0,
        matched_quantity=100,
        loss_account=acct.display(),
        buy_account=acct.display(),
        loss_sale_date=date(2026, 4, 20),
        triggering_buy_date=date(2026, 4, 1),
        ticker="WRD",
        source=source,
    )
    win_start = date(2026, 4, 1) - timedelta(days=30)
    win_end = date(2026, 4, 20) + timedelta(days=30)
    repo.replace_violations_in_window(win_start, win_end, [v])


def test_calendar_focus_renders_schwab_source_badge(client, repo):
    _seed_violation(repo, source="schwab_g_l")
    violations = repo.all_violations()
    assert len(violations) == 1
    vid = violations[0].id
    resp = client.get(f"/calendar/focus/{vid}")
    assert resp.status_code == 200
    assert "schwab" in resp.text.lower()


def test_calendar_focus_renders_engine_source_badge(client, repo):
    _seed_violation(repo, source="engine", confidence="Probable")
    violations = repo.all_violations()
    vid = violations[0].id
    resp = client.get(f"/calendar/focus/{vid}")
    assert resp.status_code == 200
    assert "engine" in resp.text.lower() or "cross-account" in resp.text.lower()
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/web/test_violation_badge.py -v`
Expected: Both fail — current `_violation_card.html` doesn't render source.

- [ ] **Step 4: Replace `_violation_card.html` with the badge-aware version**

Replace the entire contents of `src/net_alpha/web/templates/_violation_card.html` with:

```html
<div class="border-l-4 pl-3"
     style="border-left-color: {% if violation.confidence=='Confirmed' %}#DC2626{% elif violation.confidence=='Probable' %}#F59E0B{% else %}#3B82F6{% endif %};">
  <div class="text-sm">
    <strong>Loss in</strong> {{ violation.loss_account or "-" }} → <strong>triggered by</strong> {{ violation.buy_account or "-" }} on {{ violation.triggering_buy_date or "-" }}
    {% if violation.source == "schwab_g_l" %}
      <span class="ml-2 inline-block px-2 py-0.5 rounded text-xs bg-blue-100 text-blue-800 border border-blue-300"
            title="Confirmed by Schwab's 1099-B reporting">Schwab</span>
    {% elif violation.source == "engine" %}
      {% if violation.loss_account != violation.buy_account %}
        <span class="ml-2 inline-block px-2 py-0.5 rounded text-xs bg-amber-100 text-amber-800 border border-amber-300"
              title="Cross-account wash sale detected by net-alpha">Cross-account</span>
      {% else %}
        <span class="ml-2 inline-block px-2 py-0.5 rounded text-xs bg-slate-100 text-slate-800 border border-slate-300"
              title="Detected by net-alpha (substantially identical or engine call)">Engine</span>
      {% endif %}
    {% endif %}
  </div>
  <div class="text-sm">Disallowed: <span class="font-mono text-confirmed">${{ "%.2f"|format(violation.disallowed_loss) }}</span> · Matched qty: <span class="font-mono">{{ violation.matched_quantity }}</span></div>
  <a href="/ticker/{{ violation.ticker }}" class="text-primary text-sm underline">View ticker drilldown →</a>
</div>
```

- [ ] **Step 5: Run tests**

Run: `uv run pytest tests/web/test_violation_badge.py -v`
Expected: Both PASS.

- [ ] **Step 6: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/_violation_card.html tests/web/test_violation_badge.py
git commit -m "feat(web): violation source badges (Schwab / Cross-account / Engine)

Renders next to the existing confidence pill so the user knows whether
a violation came from Schwab's 1099-B reporting, engine cross-account
detection, or engine-only substantially-identical inference."
```

---

### Task 10: Schwab lot detail panel on ticker drilldown

**Why:** When the user lands on a ticker page, show the Schwab G/L lot breakdown so they can verify our hydrated cost basis against Schwab's source data.

**Files:**
- Create: `src/net_alpha/web/templates/_schwab_lot_detail.html`
- Modify: `src/net_alpha/web/templates/ticker.html`
- Modify: `src/net_alpha/web/routes/ticker.py`
- Test: `tests/web/test_ticker_lot_detail.py`

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_ticker_lot_detail.py`:

```python
from __future__ import annotations

from datetime import date, datetime

import pytest

from net_alpha.models.domain import ImportRecord, Trade
from net_alpha.models.realized_gl import RealizedGLLot


def _seed(repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=1,
    )
    repo.add_import(acct, rec, [
        Trade(account=acct.display(), date=date(2026, 4, 20), ticker="WRD",
              action="Sell", quantity=100, proceeds=800.0),
    ])
    repo.add_gl_lots(acct, repo.list_imports()[0].id, [
        RealizedGLLot(
            account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
            closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
            quantity=100.0, proceeds=824.96, cost_basis=800.66,
            unadjusted_cost_basis=800.66, wash_sale=False, disallowed_loss=0.0,
            term="Short Term",
        ),
    ])
    return acct


def test_ticker_page_renders_schwab_lot_detail_when_present(client, repo):
    _seed(repo)
    resp = client.get("/ticker/WRD")
    assert resp.status_code == 200
    assert "Schwab Lot Detail" in resp.text
    assert "800.66" in resp.text


def test_ticker_page_omits_panel_when_no_gl(client, repo):
    """No G/L data → panel doesn't render."""
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(
        account_id=acct.id, csv_filename="t.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=1,
    )
    repo.add_import(acct, rec, [
        Trade(account=acct.display(), date=date(2026, 4, 20), ticker="ZZZ",
              action="Sell", quantity=1, proceeds=10.0),
    ])
    resp = client.get("/ticker/ZZZ")
    assert resp.status_code == 200
    assert "Schwab Lot Detail" not in resp.text
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/web/test_ticker_lot_detail.py -v`
Expected: Fail — template doesn't include G/L lot detail.

- [ ] **Step 3: Create the partial template**

Create `src/net_alpha/web/templates/_schwab_lot_detail.html`:

```html
{% if gl_lots %}
  <section class="bg-white border border-slate-200 rounded-lg p-4 mt-4">
    <h2 class="text-lg mb-2">Schwab Lot Detail (from G/L)</h2>
    <table class="w-full text-sm">
      <thead class="text-left text-xs text-slate-500 uppercase">
        <tr>
          <th class="px-2 py-1">Closed</th>
          <th class="px-2 py-1">Opened</th>
          <th class="px-2 py-1 text-right">Qty</th>
          <th class="px-2 py-1 text-right">Cost basis</th>
          <th class="px-2 py-1">Wash sale?</th>
          <th class="px-2 py-1 text-right">Disallowed</th>
        </tr>
      </thead>
      <tbody>
        {% for lot in gl_lots %}
          <tr class="border-t border-slate-100">
            <td class="px-2 py-1 font-mono">{{ lot.closed_date.isoformat() }}</td>
            <td class="px-2 py-1 font-mono">{{ lot.opened_date.isoformat() }}</td>
            <td class="px-2 py-1 text-right font-mono">{{ "%.4f"|format(lot.quantity) }}</td>
            <td class="px-2 py-1 text-right font-mono">${{ "%.2f"|format(lot.cost_basis) }}</td>
            <td class="px-2 py-1">
              {% if lot.wash_sale %}
                <span class="text-red-700 font-medium">Yes</span>
              {% else %}
                <span class="text-slate-500">No</span>
              {% endif %}
            </td>
            <td class="px-2 py-1 text-right font-mono">
              {% if lot.disallowed_loss %}${{ "%.2f"|format(lot.disallowed_loss) }}{% endif %}
            </td>
          </tr>
        {% endfor %}
      </tbody>
    </table>
  </section>
{% endif %}
```

- [ ] **Step 4: Update ticker route to load G/L lots**

Edit `src/net_alpha/web/routes/ticker.py`. Find the existing GET handler and add a query for G/L lots. Add this to the imports:

```python
from net_alpha.models.realized_gl import RealizedGLLot
```

In the handler, after loading the existing data, add:

```python
    # Load G/L lots for this ticker across all accounts that have any
    gl_lots: list[RealizedGLLot] = []
    for account in repo.list_accounts():
        gl_lots.extend(repo.get_gl_lots_for_ticker(account.id, symbol))
```

Pass `"gl_lots": gl_lots` into the template context.

- [ ] **Step 5: Include the partial in `ticker.html`**

In `src/net_alpha/web/templates/ticker.html`, add `{% include "_schwab_lot_detail.html" %}` at an appropriate location (e.g. immediately after the violations card / lots table, before the footer).

- [ ] **Step 6: Run tests**

Run: `uv run pytest tests/web/test_ticker_lot_detail.py -v`
Expected: Both PASS.

- [ ] **Step 7: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/web/templates/_schwab_lot_detail.html src/net_alpha/web/templates/ticker.html src/net_alpha/web/routes/ticker.py tests/web/test_ticker_lot_detail.py
git commit -m "feat(web): Schwab lot detail panel on ticker drilldown

Read-only table showing closed/opened dates, quantity, cost basis,
wash sale flag, and disallowed loss for each G/L lot in this ticker.
Lets users verify our hydrated cost basis against Schwab's source data.
Hidden when no G/L rows exist for the ticker."
```

---

### Task 11: Imports table — Files column

**Why:** A G/L import has `trade_count = 0`, which currently renders as a confusing empty row. Show what the import actually contained.

**Files:**
- Modify: `src/net_alpha/web/templates/_imports_table.html`
- Modify: `src/net_alpha/db/repository.py` (extend `ImportSummary`)
- Modify: `src/net_alpha/models/domain.py` (extend `ImportSummary`)
- Test: `tests/web/test_imports_table_files_column.py`

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_imports_table_files_column.py`:

```python
from __future__ import annotations

from datetime import datetime

from net_alpha.models.domain import ImportRecord


def test_imports_table_renders_gl_summary_for_zero_trade_imports(client, repo):
    acct = repo.get_or_create_account("schwab", "personal")
    rec = ImportRecord(
        account_id=acct.id, csv_filename="gl.csv", csv_sha256="abc",
        imported_at=datetime(2026, 4, 25), trade_count=0,
    )
    result = repo.add_import(acct, rec, [])
    # Manually mark this import as having gl_lot_count > 0 by inserting
    # one G/L lot into it
    from datetime import date
    from net_alpha.models.realized_gl import RealizedGLLot
    repo.add_gl_lots(acct, result.import_id, [
        RealizedGLLot(
            account_display=acct.display(), symbol_raw="WRD", ticker="WRD",
            closed_date=date(2026, 4, 20), opened_date=date(2026, 2, 11),
            quantity=100.0, proceeds=800.0, cost_basis=800.0,
            unadjusted_cost_basis=800.0, wash_sale=False, disallowed_loss=0.0,
            term="Short Term",
        ),
    ])
    resp = client.get("/imports")
    assert resp.status_code == 200
    body = resp.text
    assert "gl.csv" in body
    # The page should now mention the G/L lot count somewhere on this row
    assert "1" in body and ("g/l" in body.lower() or "lot" in body.lower())
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_imports_table_files_column.py -v`
Expected: Likely fails — current template only shows trade_count=0 with no hint about G/L.

- [ ] **Step 3: Add `gl_lot_count` to `ImportSummary`**

In `src/net_alpha/models/domain.py`, find `ImportSummary` and add `gl_lot_count`:

```python
class ImportSummary(BaseModel):
    """Display row for `net-alpha imports`."""
    id: int
    account_display: str
    csv_filename: str
    trade_count: int
    imported_at: datetime
    gl_lot_count: int = 0
```

- [ ] **Step 4: Populate `gl_lot_count` in `Repository.list_imports`**

In `src/net_alpha/db/repository.py`, find `list_imports`. After computing each `ImportSummary`, add a count of G/L lot rows for this import. Patch the existing implementation; the new method should join (or sub-query) `realized_gl_lots` filtered by `import_id`:

```python
    def list_imports(self) -> list[ImportSummary]:
        with Session(self._engine) as s:
            rows = s.exec(select(ImportRecordRow).order_by(ImportRecordRow.imported_at.desc())).all()
            out: list[ImportSummary] = []
            for r in rows:
                acct = s.exec(select(AccountRow).where(AccountRow.id == r.account_id)).first()
                gl_count = s.exec(
                    select(func.count(RealizedGLLotRow.id)).where(RealizedGLLotRow.import_id == r.id)
                ).one()
                out.append(ImportSummary(
                    id=r.id,
                    account_display=f"{acct.broker}/{acct.label}" if acct else "unknown",
                    csv_filename=r.csv_filename,
                    trade_count=r.trade_count,
                    imported_at=r.imported_at,
                    gl_lot_count=int(gl_count or 0),
                ))
            return out
```

Add `from sqlalchemy import func` to the imports if it's not already there.

- [ ] **Step 5: Replace `_imports_table.html` with the G/L-aware version**

Replace the entire contents of `src/net_alpha/web/templates/_imports_table.html` with:

```html
{% if not imports %}
  <div class="kpi-card text-slate-500 text-sm">No imports yet.</div>
{% else %}
  <table class="w-full text-sm bg-white rounded-lg shadow-sm border border-slate-200">
    <thead class="text-left text-xs text-slate-500 uppercase border-b border-slate-200">
      <tr>
        <th class="px-3 py-2">ID</th>
        <th class="px-3 py-2">Imported at</th>
        <th class="px-3 py-2">Account</th>
        <th class="px-3 py-2">Filename</th>
        <th class="px-3 py-2">Trades</th>
        <th class="px-3 py-2">G/L lots</th>
        <th class="px-3 py-2">Actions</th>
      </tr>
    </thead>
    <tbody>
      {% for imp in imports %}
        <tr id="import-row-{{ imp.id }}" class="border-b border-slate-100 last:border-b-0">
          <td class="px-3 py-2 font-mono">#{{ imp.id }}</td>
          <td class="px-3 py-2 font-mono text-xs">{{ imp.imported_at.strftime("%Y-%m-%d %H:%M") }}</td>
          <td class="px-3 py-2">{{ imp.account_display }}</td>
          <td class="px-3 py-2">{{ imp.csv_filename }}</td>
          <td class="px-3 py-2 font-mono">{{ imp.trade_count }}</td>
          <td class="px-3 py-2 font-mono">{{ imp.gl_lot_count or "—" }}</td>
          <td class="px-3 py-2">
            <button class="btn-ghost text-confirmed border-confirmed/30"
                    hx-delete="/imports/{{ imp.id }}"
                    hx-confirm="Remove import #{{ imp.id }} ({{ imp.trade_count }} trades, {{ imp.gl_lot_count }} G/L lots)? Wash sales will be recomputed."
                    hx-target="#imports-table"
                    hx-swap="innerHTML">
              Remove
            </button>
          </td>
        </tr>
      {% endfor %}
    </tbody>
  </table>
{% endif %}
```

- [ ] **Step 6: Run tests**

Run: `uv run pytest tests/web/test_imports_table_files_column.py -v`
Expected: PASS.

- [ ] **Step 7: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/models/domain.py src/net_alpha/db/repository.py src/net_alpha/web/templates/_imports_table.html tests/web/test_imports_table_files_column.py
git commit -m "feat(web): show G/L lot count on imports list

ImportSummary gains gl_lot_count. The imports table renders it as a
new column so G/L-only imports are no longer confusing zero-trade rows."
```

---

## Phase 6 — CLI parity

### Task 12: CLI runs stitch + merge after each import

**Why:** Users on the CLI should get the same hydration + merge behavior as the web UI.

**Files:**
- Modify: `src/net_alpha/cli/default.py`
- Test: `tests/cli/test_default_gl_hydration.py` (new)

- [ ] **Step 1: Note the current shape of `cli/default.py`**

Current implementation calls `parser.parse(...)` assuming Trade output for every file, then runs `detect_in_window` once at the end. We refactor the per-file loop to branch on parser identity (Trade vs G/L lot output), then add stitch + merge after the loop.

- [ ] **Step 2: Write the failing test**

Create `tests/cli/test_default_gl_hydration.py`:

```python
from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from net_alpha.cli.app import app

TX_FIXTURE = Path(__file__).parent.parent / "web" / "fixtures" / "schwab_minimal.csv"
GL_FIXTURE = Path(__file__).parent.parent / "brokers" / "fixtures" / "schwab_realized_gl_min.csv"


def test_cli_imports_both_files_with_account(tmp_path, monkeypatch):
    monkeypatch.setenv("NET_ALPHA_DATA_DIR", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(
        app,
        [str(TX_FIXTURE), str(GL_FIXTURE), "--account", "personal"],
    )
    assert result.exit_code == 0, result.output
    # The G/L lots from the fixture cover WRD and CRCL — the output should mention them
    assert "WRD" in result.output or "wash" in result.output.lower() or "Imported" in result.output


def test_cli_single_transactions_file_runs_fifo_stitch(tmp_path, monkeypatch):
    monkeypatch.setenv("NET_ALPHA_DATA_DIR", str(tmp_path))
    runner = CliRunner()
    result = runner.invoke(app, [str(TX_FIXTURE), "--account", "personal"])
    assert result.exit_code == 0, result.output
```

- [ ] **Step 3: Run test to verify CLI accepts G/L files**

Run: `uv run pytest tests/cli/test_default_gl_hydration.py -v`
Expected: First test likely fails — current CLI calls only `SchwabParser.parse` and doesn't know about G/L files.

- [ ] **Step 4: Replace `cli/default.py` with the multi-parser version**

Replace the entire contents of `src/net_alpha/cli/default.py` with:

```python
# src/net_alpha/cli/default.py
from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path

import typer
from sqlmodel import create_engine

from net_alpha.brokers.registry import detect_broker
from net_alpha.brokers.schwab import SchwabParser
from net_alpha.brokers.schwab_realized_gl import SchwabRealizedGLParser
from net_alpha.db.connection import init_db
from net_alpha.db.repository import Repository
from net_alpha.engine.detector import detect_in_window
from net_alpha.engine.etf_pairs import load_etf_pairs
from net_alpha.engine.merge import merge_violations
from net_alpha.engine.stitch import stitch_account
from net_alpha.ingest.csv_loader import compute_csv_sha256, load_csv
from net_alpha.ingest.dedup import filter_new
from net_alpha.models.domain import ImportRecord
from net_alpha.output import disclaimer, watch_list, ytd_impact

ETF_PAIRS = load_etf_pairs(user_path=str(Path.home() / ".net_alpha" / "etf_pairs.yaml"))


def _engine():
    home = Path.home() / ".net_alpha"
    home.mkdir(parents=True, exist_ok=True)
    eng = create_engine(f"sqlite:///{home / 'net_alpha.db'}")
    init_db(eng)
    return eng


def run(csv_paths: list[str], account_label: str, detail: bool = False) -> int:
    repo = Repository(_engine())

    affected_dates: list = []
    account = None
    new_trade_total = 0
    dup_trade_total = 0
    new_gl_total = 0

    for csv_path in csv_paths:
        headers, rows = load_csv(csv_path)
        parser = detect_broker(headers)
        if parser is None:
            typer.echo(
                f"Error: Could not detect broker from CSV headers in {csv_path}.\n"
                f"       Supported parsers: schwab (transactions), schwab_realized_gl\n"
                f"       To request support: open an issue with an anonymized sample.",
                err=True,
            )
            return 2

        # Schwab account label is shared across all files in this invocation.
        if account is None:
            account = repo.get_or_create_account("schwab", account_label)

        if isinstance(parser, SchwabParser):
            try:
                trades = parser.parse(rows, account_display=account.display())
            except ValueError as e:
                typer.echo(f"Error: {e}", err=True)
                return 3
            existing = repo.existing_natural_keys(account.id)
            new = filter_new(trades, existing)
            rec = ImportRecord(
                account_id=account.id,
                csv_filename=Path(csv_path).name,
                csv_sha256=compute_csv_sha256(csv_path),
                imported_at=datetime.now(),
                trade_count=len(new),
            )
            result = repo.add_import(account, rec, new)
            dup_count = len(trades) - len(new)
            new_trade_total += result.new_trades
            dup_trade_total += dup_count
            for t in new:
                affected_dates.append(t.date)
            typer.echo(
                f"Detected: {parser.name} — imported {result.new_trades} new trades, "
                f"skipped {dup_count} duplicates ({Path(csv_path).name})"
            )

        elif isinstance(parser, SchwabRealizedGLParser):
            try:
                lots = parser.parse(rows, account_display=account.display())
            except ValueError as e:
                typer.echo(f"Error: {e}", err=True)
                return 3
            rec = ImportRecord(
                account_id=account.id,
                csv_filename=Path(csv_path).name,
                csv_sha256=compute_csv_sha256(csv_path),
                imported_at=datetime.now(),
                trade_count=0,
            )
            result = repo.add_import(account, rec, [])
            inserted = repo.add_gl_lots(account, result.import_id, lots)
            new_gl_total += inserted
            for lot in lots:
                affected_dates.append(lot.closed_date)
            typer.echo(
                f"Detected: {parser.name} — imported {inserted} G/L lot rows ({Path(csv_path).name})"
            )

        else:
            typer.echo(f"Error: Unhandled parser type {parser.name}", err=True)
            return 4

    # Stitch + recompute, scoped to the affected ±30-day window
    if account is not None:
        stitched = stitch_account(repo, account.id)
        if stitched.from_gl or stitched.from_fifo or stitched.unknown:
            typer.echo(
                f"Stitched: {stitched.from_gl} sells from G/L · "
                f"{stitched.from_fifo} via FIFO · {stitched.unknown} unknown"
            )
        for w in stitched.warnings:
            typer.echo(f"  ⚠ {w}", err=True)

        if affected_dates:
            win_start = min(affected_dates) - timedelta(days=30)
            win_end = max(affected_dates) + timedelta(days=30)
            window_trades = repo.trades_in_window(win_start, win_end)
            det = detect_in_window(window_trades, win_start, win_end, etf_pairs=ETF_PAIRS)
            all_gl = repo.get_gl_lots_for_account(account.id)
            merged = merge_violations(
                engine_violations=det.violations,
                gl_lots_by_account={account.id: all_gl},
            )
            repo.replace_violations_in_window(win_start, win_end, merged)
            repo.replace_lots_in_window(win_start, win_end, det.lots)

    today = date.today()
    typer.echo("")
    typer.echo(watch_list.render(repo.all_lots(), repo.all_violations(), today=today))
    typer.echo("")
    typer.echo(ytd_impact.render(repo.violations_for_year(today.year), year=today.year))
    if detail:
        from net_alpha.output import detail as detail_mod

        typer.echo("")
        typer.echo(detail_mod.render(repo.all_violations()))
    typer.echo("")
    typer.echo(disclaimer.render())
    return 0
```

Two small but important changes vs. the existing file:
1. `_engine()` now calls `init_db(eng)` instead of just `SQLModel.metadata.create_all(eng)`. This ensures `migrate(session)` runs (needed for any pre-existing v1 DB on disk).
2. The trade `ImportRecord.trade_count` is now `len(new)` (was `0` in the old code — that was a bug; `repo.add_import` overwrites it but downstream code uses the field).

- [ ] **Step 5: Run CLI tests**

Run: `uv run pytest tests/cli/test_default_gl_hydration.py -v`
Expected: Both PASS.

- [ ] **Step 6: Run full suite**

Run: `uv run pytest -q`
Expected: All tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/cli/default.py tests/cli/test_default_gl_hydration.py
git commit -m "feat(cli): G/L hydration + merge in default import command

CLI accepts mixed Transaction History + Realized G/L files in a single
invocation. Same stitch + merge pipeline as the web UI. Reports
hydration counts and warnings on stdout."
```

---

## Phase 7 — Smoke

### Task 13: Real-data smoke test

**Why:** Validates the full pipeline against the user's actual Schwab files (in `private/`). Not a CI test (the files are gitignored), but a manual checklist for the implementer.

**Files:** None — this is verification-only.

- [ ] **Step 1: Verify `init_db` migrates a v1-state DB cleanly**

```bash
# Move any existing DB out of the way first
mv ~/.net_alpha/net_alpha.db ~/.net_alpha/net_alpha.db.preflight 2>/dev/null || true

# Boot the UI; init_db will create a v2 DB
uv run net-alpha ui --no-browser &
UI_PID=$!
sleep 2
sqlite3 ~/.net_alpha/net_alpha.db "SELECT value FROM meta WHERE key='schema_version';"
# Expected: 2
sqlite3 ~/.net_alpha/net_alpha.db "SELECT name FROM sqlite_master WHERE type='table';" | grep realized_gl_lots
# Expected: realized_gl_lots
kill $UI_PID
```

- [ ] **Step 2: Upload Transactions + G/L via the web UI**

Start the UI: `uv run net-alpha ui`

In your browser:
1. Drag both `private/schwab_lt/Long_Term_*.csv` and `private/schwab_st/Short_Term_GainLoss_Realized_Details_*.csv` into the drop zone.
2. Confirm the preview modal shows two recognized files (one Transaction History, one Realized G/L).
3. Enter `personal` as the account label and submit.
4. Verify the flash message reports trades + G/L lots imported.

- [ ] **Step 3: Verify dashboard reflects hydration**

In the browser, visit `/`:
- "YTD VIOLATIONS" should now reflect any wash sales Schwab flagged.
- "YTD DISALLOWED LOSS" should show non-zero if Schwab found any.

- [ ] **Step 4: Verify ticker drilldown shows lot detail**

Navigate to a ticker that appears in the G/L (e.g. `/ticker/WRD`). The Schwab Lot Detail panel should be present and populated.

- [ ] **Step 5: Verify imports list shows the G/L import**

Visit `/imports`. The Realized G/L import row should show a non-zero G/L lot count.

- [ ] **Step 6: Restore the original DB if you want to keep your existing data**

```bash
# If the smoke test went well and you want to keep this DB, do nothing.
# If you want the original v1-stale DB back:
mv ~/.net_alpha/net_alpha.db.preflight ~/.net_alpha/net_alpha.db 2>/dev/null || true
```

- [ ] **Step 7: No commit** — this is verification-only.

---

## Self-Review Checklist (run after the entire plan)

- [ ] Spec coverage: every section of `2026-04-25-schwab-gl-hydration-design.md` has a corresponding task.
- [ ] No placeholders / TBDs / "see Task N" references.
- [ ] Type consistency: `basis_source`, `source`, `wash_sale`, `closed_date`, `match_symbol`, `stitch_account`, `merge_violations`, `RealizedGLLot` are spelled the same everywhere.
- [ ] Every test step shows the actual test code; every implementation step shows the actual implementation code.
- [ ] All commit messages explain *why*, not just *what*.
- [ ] No business logic was added under `web/` — routes only orchestrate.
