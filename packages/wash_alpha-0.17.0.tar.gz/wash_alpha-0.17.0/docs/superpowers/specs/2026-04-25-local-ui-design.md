# Local UI for net-alpha — Design Spec

**Status:** Draft
**Date:** 2026-04-25
**Target version:** v2.1.0
**Supersedes:** none (additive on top of v2.0)

---

## 1. Goal

Add an optional, ephemeral, local-only web UI that wraps the existing v2 engine. Drag a CSV in, see your wash-sale exposure visualized — without giving up the CLI.

**One-line pitch:** *"`net-alpha ui` opens a browser. Drop your CSV. See the rule, not just the rows."*

---

## 2. Why this exists

The v2 simplification cleaned up the CLI but the user wants visual feedback — calendars, drilldowns, drag-drop — that a terminal can't deliver well. Existing options either (a) re-introduce all the complexity v2 cut (Docker, daemons, multi-user) or (b) give up too much polish (TUI). The compromise: a single command that boots a local server, opens the browser, and dies on Ctrl-C. Forget-proof and add-only.

This UI is **a companion to the CLI**, not a replacement. The CLI remains canonical for scripting and CI; the UI is the everyday driver for personal use.

---

## 3. Scope

### In scope (v1 of the UI)

- CLI parity: import (drag-drop), watch list, YTD impact, sim, imports management, detail view.
- New visualizations: wash-sale annual ribbon + ±30-day focus strip; ticker drilldown.
- One CLI command: `net-alpha ui` with optional `--port` and `--no-browser` flags, plus `--reload` for dev.
- Tailwind-styled HTML, vendored htmx/alpine, no node/npm.

### Out of scope (v1)

- Auth, user accounts, multi-user. Loopback-only binding is the security model.
- Live market prices. Lots show *adjusted basis*, not unrealized P&L.
- Tax-loss harvest scanner.
- Brokers beyond Schwab (same support as the CLI).
- LLM CSV detection.
- Mobile layout. Desktop only, responsive down to ~1024px.
- Dark mode. Light theme only.
- Standalone binary packaging.
- WebSocket / push updates. Request/response only.
- Background job queue. Imports are synchronous in the request handler.
- i18n. English only.
- Print/PDF export.
- Visual regression testing infrastructure.

### Reserved for follow-ups

- Multi-year calendar scrolling.
- Saved filter views / saved dashboards.
- Per-broker theming on trade timelines.
- Polish on multi-file drop (basic version is in v1).

---

## 4. Architecture & Lifecycle

### 4.1 Code layout

New subpackage `src/net_alpha/web/`:

```
src/net_alpha/web/
├── __init__.py
├── app.py                  # FastAPI app factory
├── routes/
│   ├── __init__.py
│   ├── dashboard.py        # GET /
│   ├── imports.py          # GET/POST/DELETE /imports
│   ├── calendar.py         # GET /calendar
│   ├── ticker.py           # GET /ticker/{symbol}
│   ├── sim.py              # GET/POST /sim
│   ├── detail.py           # GET /detail
│   └── system.py           # POST /quit, error handlers
├── templates/              # Jinja2 templates
│   ├── base.html
│   ├── dashboard.html
│   ├── _watch_list.html    # partials prefixed with _
│   └── ...
└── static/
    ├── htmx.min.js         # vendored, ~14KB
    ├── alpine.min.js       # vendored, ~7KB
    └── app.css             # built from Tailwind, committed
```

### 4.2 Boundary discipline

The web layer is a **view layer**. It only calls public seams the CLI already uses:
- `Repository` (read trades, lots, violations, imports; write imports)
- `csv_loader.load_csv`, `BrokerParser` registry
- `engine.detect_in_window`, `engine.simulate_sell`
- `output.disclaimer.render` (reused for footer text)

Routes are thin: parse request → call engine → render template. **No business logic in `web/`.** If a route needs new data the engine doesn't expose, the new method goes on `Repository` (with unit tests), not in the route handler.

### 4.3 Lifecycle (`net-alpha ui`)

1. New CLI command in `src/net_alpha/cli/ui.py` registered on the Typer app.
2. Picks a free port: tries 8765, increments to 8775, errors with "All ports in use, pass `--port`" if all busy.
3. Boots uvicorn programmatically (`uvicorn.run(...)`), single worker, `host="127.0.0.1"`.
4. Opens default browser to `http://127.0.0.1:<port>` (skip if `--no-browser`).
5. Loopback-only binding — no `0.0.0.0`, no auth needed.
6. Ctrl-C → uvicorn graceful shutdown → process exits. Forget-proof.
7. Optional: `POST /quit` endpoint the UI's "Stop server" button calls — but Ctrl-C is canonical.
8. `--reload` flag enables uvicorn auto-reload for template/code changes during dev. Off by default.

---

## 5. Routes & Page Map

| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Dashboard — drag-drop zone, watch list, YTD KPIs |
| `/imports` | POST | Handle CSV upload (multipart) with account label |
| `/imports/preview` | POST | Lightweight preview — broker detect + first 5 rows |
| `/imports` | GET | Imports management page (list + remove) |
| `/imports/{id}` | DELETE | Remove import (HTMX partial swap) |
| `/calendar` | GET | Annual ribbon + focus strip; query params `?account=&ticker=&year=&confidence=&violation=` |
| `/ticker/{symbol}` | GET | Ticker drilldown |
| `/sim` | GET | Sim form |
| `/sim` | POST | Run sim, render result |
| `/detail` | GET | Full violations list (CLI `--detail` equivalent) |
| `/static/*` | GET | Vendored htmx, alpine, built app.css |
| `/quit` | POST | Optional graceful shutdown button |

**Top nav (always visible):** logo · Dashboard · Calendar · Imports · Sim

**Navigation principles:**
- Dashboard = home. Open browser → drag CSV → done.
- Calendar and Ticker views are linked from violations: click a watch-list row → ticker drilldown; click a violation marker on the calendar → focus strip.
- HTMX swaps for in-page actions (filter, remove import, expand row). No full page reload.
- Every page is a real bookmarkable URL. No client-side routing.

---

## 6. Drag-Drop Import Flow

### 6.1 Interaction

1. **Drop zone on Dashboard** — large dashed-border area at top, "Drop CSV here or click to browse." Alpine highlights on dragover.
2. **Drop file(s)** — JS reads file metadata and the first 2KB, sends `POST /imports/preview` for broker detection.
3. **Modal opens** containing:
   - **Detected broker badge** — `✓ Schwab CSV detected` or `❌ Unknown format` with a link to the contributor docs.
   - **Account label dropdown** — pre-populated with existing accounts (`schwab/personal`, etc.), plus `+ New account` option that reveals a text input.
   - **Trade preview** — table showing the first 5 parsed rows so the user can sanity-check before commit.
   - **Disclaimer line** — short reminder.
   - Buttons: `Cancel` | `Import N trades`.
4. **Submit** — `POST /imports` (full multipart upload + account label) → server runs the existing CLI path: `csv_loader.load_csv` → dedup → `Repository.add_import` → `detect_in_window` → `replace_violations_in_window` + `replace_lots_in_window`.
5. **Success** — modal closes, dashboard re-renders via HTMX swap, toast appears: `Imported 847 new trades · skipped 12 duplicates · 3 new violations detected`.

### 6.2 Multiple-file drop

Allowed. Modal lists each file with its own account picker (default: same account as previous file). One submit = N imports queued sequentially server-side, single recompute at the end.

### 6.3 Errors

Handled in the modal, not as 500s:
- Unrecognized broker → "We couldn't detect a known broker format. Currently supported: Schwab."
- Parse warnings → yellow note above preview table; user can still proceed.
- Pure duplicate (every row already imported) → "All N rows already imported under `<account>`. Nothing to do." Submit disabled.

### 6.4 Limits

- Max upload size: 50MB (configurable via `WASH_ALPHA_MAX_UPLOAD_MB` env var).
- Single import per request (multiple files = multiple sequential requests, batched in one modal).

---

## 7. Wash-Sale Calendar View

The centerpiece visualization — show that a loss sale "casts a 60-day shadow" and any matching buy that lands in that shadow triggers a wash sale.

### 7.1 Layout (top to bottom)

**A. Header bar — filters:**
- Year selector (current year default)
- Account filter (multi-select)
- Ticker filter (autocomplete on existing tickers)
- Confidence filter (Confirmed / Probable / Unclear, multi-select)
- Hide-resolved toggle (hide violations whose look-forward window has closed without further triggers)

**B. Annual ribbon (overview):**
- Full year laid out left-to-right, one tick per week.
- Each violation appears as a colored dot anchored at the **loss-sale date**:
  - Red = Confirmed
  - Amber = Probable
  - Blue = Unclear
- Hover → tooltip with `<TICKER> · loss in <account> · <date> · $<disallowed>`.
- Click → loads focus strip below for that violation.

**C. ±30-day focus strip (the rule visualized):**
- Horizontal 61-day strip centered on the selected loss sale.
- Day 0 (loss sale) = heavy vertical line + red label.
- Days -30 to +30 = shaded "shadow zone" background.
- Every trade for the same ticker (across all accounts, color-coded per account) plotted as a marker on its day.
- Triggering buy(s) get an amber halo + connecting line back to the loss sale.
- Below the strip: violation card (loss amount, disallowed loss, replacement lot, confidence label, link to ticker drilldown).

**D. Empty state:**
- "No wash sales in this view. Try widening filters or import more data."

### 7.2 Why this layout

- Annual ribbon = scan a year of pain at a glance.
- Focus strip = understand any single violation in context.
- The pair lets you go from "where" to "why" in one click without losing either view.

### 7.3 What's NOT in this view

- Traditional month-grid calendar (mostly empty cells for retail traders).
- Per-day trade journal (that's the ticker drilldown's job).
- Live price overlay.

---

## 8. Ticker Drilldown View

**URL:** `/ticker/{symbol}` (e.g., `/ticker/TSLA`).

### 8.1 KPI strip (5 cards, single row)

1. **Open lots** — count + total adjusted basis
2. **YTD realized P&L** — green if positive, red if negative
3. **Disallowed loss YTD** — red, links to violations section
4. **Active accounts** — count + names (e.g., `2 · schwab/personal, schwab/joint`)
5. **Last trade** — date + action (e.g., `Sold 10 · 2024-11-04`)

### 8.2 Stacked sections (each collapsible, all expanded by default)

**§ Timeline** — horizontal track, full trade history for this ticker chronologically. One row per account (color-coded). Buy markers (▲), sell markers (▼ red if loss, gray if gain), option expirations (◇). Hover shows trade details. Click a marker scrolls Lots/Violations sections to the relevant entry.

**§ Open lots** — table sorted by `acquired_date`:

| Account | Acquired | Qty | Original basis | Adjusted basis | Δ (wash-sale adj) | Age |
|---|---|---|---|---|---|---|
| schwab/personal | 2024-08-01 | 10 | $1,800 | $2,140 | +$340 | 87d |

Lots with non-zero adjustment get an amber row tint with a tooltip explaining which violation caused the bump.

**§ Violations involving this ticker** — same card layout as the watch list. Confidence color stripe on the left edge. "View on calendar" link jumps to `/calendar?ticker={symbol}&violation={id}`.

**§ Per-account breakdown** — collapsed by default. Sub-card per account: open lots, realized P&L, count of violations.

### 8.3 Sticky right rail

Mini sim widget — `Simulate selling [N] shares at [$P]` form pre-filled for this ticker. Submit → renders a small per-account preview inline (no nav change).

### 8.4 Asset-type behavior

- **Options:** timeline rows split into `underlying / options`. Option markers show `strike+expiry` on hover.
- **ETFs:** the substantially-identical pairs note appears (e.g., on `/ticker/SPY`: "Buys of VOO/IVV/SPLG within window are also flagged per IRS guidance.").

---

## 9. CLI Parity Views

### 9.1 Sim (`/sim`)

- **Form (left):** Ticker (text), Quantity (number), Price (number), Optional account filter (multi-select).
- **Result (right, swaps via HTMX on submit):**
  - **Cross-account verdict banner** — green "No wash sale" / red "Wash sale: triggered by buy in `<account>` on `<date>`" / amber "Probable" / blue "Unclear".
  - **Per-account option cards** — one card per account holding the ticker. Each shows: FIFO lot consumption table, realized P&L, per-account verdict.
  - Bottom: "Sell from `<account>` to avoid wash sale" suggestions if any account is clean.
- "Open ticker view" link → `/ticker/{symbol}`.

### 9.2 Imports management (`/imports`, GET)

- Table: ID | Imported at | Account | Filename | Trade count | Actions.
- "Remove" button → confirms in modal → `DELETE /imports/{id}` → HTMX swaps row out + recomputes wash sales server-side. Toast: "Removed import #3 (847 trades). Re-detected 2 violations."
- Top button: "+ New import" → opens the same drag-drop modal as Dashboard.

### 9.3 Detail (`/detail`)

- Equivalent to CLI's `--detail`: full violation list with per-violation breakdown.
- Columns: Date | Ticker | Account (loss → buy) | Type | Loss → Disallowed | Confidence | Replacement lot.
- Filterable: ticker, account, year, confidence, status (open/closed window).
- Click a row → expands inline showing match path, partial-wash math, FIFO allocation reasoning.
- "Download CSV" export uses the same disallowed-loss math the CLI exports.

### 9.4 Disclaimer

Every page footer carries the exact disclaimer string the CLI uses (sourced from `output.disclaimer.render()`). The leading ⚠ character is part of the disclaimer text and stays — it is *text*, not a UI icon, so the "no emoji icons" rule from §10.5 does not apply.

---

## 10. Visual Direction

Sourced from `ui-ux-pro-max` skill output for "fintech tax dashboard wash sale data visualization professional."

### 10.1 Style

**Data-Dense Dashboard** — Bloomberg-terminal feel. KPI cards, tight tables, drill-down. Minimal padding, grid layout, maximum data visibility. WCAG AA contrast.

### 10.2 Palette

| Role | Hex |
|---|---|
| Primary | `#1E40AF` (deep blue) |
| Secondary | `#3B82F6` (medium blue) |
| CTA / accent | `#F59E0B` (amber) |
| Background | `#F8FAFC` (slate-50) |
| Text | `#1E3A8A` (heading), `#0F172A` (body) |

Confidence label colors (must remain stable across views):
- Confirmed = red `#DC2626`
- Probable = amber `#F59E0B`
- Unclear = blue `#3B82F6`

### 10.3 Typography

- **Headings & numbers:** Fira Code (monospace) — emphasizes precision, trader-native.
- **Body:** Fira Sans.
- **Loaded via:** Google Fonts `<link>` in `base.html`. Single weight set.

### 10.4 Effects

- Hover tooltips on calendar dots, KPI cards, lot rows.
- Smooth transitions (150–300ms) on hover/expand.
- Row highlighting on table hover.
- Skeleton/spinner for any HTMX request that may exceed 200ms.
- `prefers-reduced-motion` respected.

### 10.5 Anti-patterns to avoid (per skill)

- Ornate design.
- No filtering (every list view must have at least one filter).
- Emoji as icons (use Heroicons SVG inline).
- Glass/transparent cards in light mode (insufficient contrast).

### 10.6 Pre-delivery checklist (per skill)

- [ ] No emojis as icons.
- [ ] `cursor-pointer` on all clickable elements.
- [ ] Hover states with smooth transitions (150–300ms).
- [ ] Light mode text contrast ≥ 4.5:1.
- [ ] Focus states visible for keyboard nav.
- [ ] `prefers-reduced-motion` respected.
- [ ] Responsive at 1024px, 1280px, 1440px (no mobile target).

---

## 11. Stack & Isolation

### 11.1 Stack

- **FastAPI** (backend, web framework)
- **Uvicorn** (ASGI server, programmatically invoked)
- **Jinja2** (server-side templates)
- **python-multipart** (multipart upload parsing)
- **HTMX** (vendored, ~14KB) — partial swap interactions
- **Alpine.js** (vendored, ~7KB) — tiny client state (drag highlight, modal open/close)
- **Tailwind CSS** (built once via standalone CLI binary, committed as `app.css`) — utility-class styling
- **Heroicons SVG** — inlined into templates as needed

### 11.2 Isolation guarantees

- All Python deps go under a new optional dependency group:

```toml
[project.optional-dependencies]
ui = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "jinja2>=3.1",
    "python-multipart>=0.0.9",
]
```

- Install via `uv sync --extra ui`. Never touches system Python — lives in `.venv/`.
- CLI-only users run `uv sync` and skip UI deps entirely.
- HTMX + Alpine vendored as static files inside `src/net_alpha/web/static/`. Bundled with the wheel. **Zero CDN at runtime, zero network calls.**
- Tailwind: standalone CLI binary builds `app.css` once at dev time. Committed to repo. **No node, no npm, ever.**
- No Docker, no daemons, no system tools.

### 11.3 Build process

- Dev: `make build-css` invokes `tailwindcss -i src/net_alpha/web/static/app.src.css -o src/net_alpha/web/static/app.css --minify` (binary downloaded once via Makefile target).
- The built `app.css` is committed to the repo. End users never run Tailwind.

---

## 12. Error Handling & Edge Cases

### 12.1 Server-side

- **Unhandled exceptions** → custom 500 handler renders a clean error page with exception message + "Copy traceback" button (data is local — no privacy risk to surface).
- **DB missing on first run** → app startup runs `migrate(session)`; creates DB with v2 schema if missing. Dashboard shows empty state.
- **DB schema version > binary version** → app refuses to start with clear message: "Database schema is newer than this version. Upgrade `wash-alpha`."
- **DB locked** → set `journal_mode=WAL` + `busy_timeout=5000` on connection (theoretical issue with single-user local use, but two lines of config).
- **Port in use** → `cli/ui.py` increments port from 8765 up to 8775; if all busy, error with "All ports in use, pass `--port`."
- **CSV upload too large** → 413 with clear message in modal.
- **Bad CSV** → caught at parse time, error rendered in upload modal.

### 12.2 Client-side

- **JS disabled** → core flows degrade: forms POST normally (no HTMX magic), drag-drop falls back to file input. `<noscript>` notice on dashboard.
- **Browser closed without quitting server** → server keeps running until Ctrl-C. Terminal where user launched it shows: "Server running at http://127.0.0.1:8765 — press Ctrl-C to stop."
- **Multiple browser tabs** → safe; all read same DB. Toast appears only in the tab that did the upload; other tabs see new data on next page action.

### 12.3 Concurrency

- All writes wrapped in single SQLite transaction.
- One uvicorn worker by default — no race conditions to design around.
- All recomputes synchronous in request handler. No background jobs.

### 12.4 Not handled (deliberately)

- Network outage (no network calls made).
- Auth (loopback binding is the auth model).
- Multi-user (single-user tool by design).

---

## 13. Testing Strategy

Existing tests stay as-is. The web layer is purely additive.

### 13.1 New tests

**1. Route smoke tests** (`tests/web/test_routes.py`):
- Each GET route returns 200 with empty DB.
- Each GET route returns 200 with seeded DB.
- Assertions check key strings (titles, ticker symbols, account labels), not pixel-level HTML.

**2. Upload flow integration test** (`tests/web/test_upload.py`):
- POST a fixture Schwab CSV via `TestClient` with multipart + account label.
- Assert response = redirect to `/`.
- Assert `Repository` shows new import + new trades + new violations.
- Assert subsequent GET `/` includes new violations in HTML.

**3. Imports management test** (`tests/web/test_imports_mgmt.py`):
- Seed two imports, DELETE one via `TestClient`, assert other survives + recompute ran.

**4. Repository additions** — any new methods added for the UI (e.g., `list_distinct_tickers`, `get_trades_for_ticker`) get standard unit tests in `tests/db/`.

**5. CLI `ui` command test** (`tests/cli/test_ui.py`):
- Test port-pick logic in isolation (find free port).
- Don't test actual server boot (uvicorn lifecycle is FastAPI's responsibility).

### 13.2 Not tested

- Tailwind output, HTMX behavior, browser rendering (manual QA).
- No snapshot/visual-regression testing.

### 13.3 Coverage target

Engine stays at current high coverage (it's the source of truth). Web layer tests prove integration, not coverage-for-coverage's-sake.

### 13.4 Manual test plan

1. `uv run net-alpha ui` → browser opens, dashboard renders.
2. Drop a real Schwab CSV → modal appears with detected broker + preview.
3. Pick account label → submit → toast appears, watch list updates.
4. Click a violation in watch list → land on ticker drilldown.
5. Click ticker on calendar ribbon → focus strip renders.
6. Run sim with held ticker → see per-account options.
7. Remove an import via `/imports` → recomputed violations reflect removal.
8. Ctrl-C in terminal → server exits cleanly; revisit `localhost:8765` → connection refused.
9. Re-launch with `--port 9000` → uses specified port.
10. Re-launch with `--no-browser` → server starts, no browser opens.

---

## 14. Open Questions

None at design time. Outstanding implementation choices (e.g., specific Heroicons set, exact Tailwind config) are deferred to the implementation plan.

---

## 15. Migration & Compatibility

- **No DB schema changes.** UI reads/writes through existing `Repository` v2 methods only. New repository methods (read-only convenience) are additive — no migration needed.
- **No CLI surface changes** to existing commands. `net-alpha ui` is an additive command.
- **Backward compatibility:** existing `~/.net_alpha/net_alpha.db` (v2) works unchanged.
- **Version target:** v2.1.0 (minor bump — additive feature, no breaking changes).

---

*End of spec.*
