# net_alpha v2 — Simplification Design

**Version:** 2.0.0 (proposed)
**Date:** 2026-04-25
**Status:** Approved (design phase)
**Supersedes:** Surface and architecture decisions in `2026-04-12-net-alpha-product-design.md`, `2026-04-14-cli-ux-improvements-design.md`, `2026-04-15-ai-agent-wrapper-design.md`, `2026-04-18-interactive-simulator-tui-design.md`, `2026-04-18-interactive-wizard-design.md`, `2026-04-18-api-key-fallback-design.md`

---

## 1. Context & Motivation

v1 (currently at 0.9.1) ships a working wash sale engine but accreted multiple competing user surfaces — a multi-command CLI, a first-run wizard, a TUI dashboard, a natural-language ReAct agent, an LLM-powered CSV importer with schema confirmation prompts, and a config file. The author's own assessment: it is too complicated for users — and for the author — to use.

The complexity has two distinct sources:

1. **Surface sprawl.** Ten CLI commands plus a wizard, TUI, and agent. Users must learn what each does and when to reach for which. Internally, ~4000 lines of code spread across `cli/`, `tui/`, `agent/`, `import_/`, plus six narrowly-scoped CLI modules.
2. **Setup ceremony.** The path from "I have a CSV" to "I have an answer" runs through API key configuration, a config file, broker selection, schema confirmation prompts, and a separate `import`/`check` two-step.

v2 collapses both. The goal is a focused product that the author can confidently maintain and that a new user can run in under a minute with no configuration.

---

## 2. Goals & Non-Goals

### Goals

- **One primary surface.** A single default command does import + check + report. Three small management commands cover simulation and import management.
- **Zero-config first run.** No API key. No config file. No schema confirmation prompts. No first-run wizard.
- **Deterministic output.** No LLM in any execution path. Output is reproducible and auditable.
- **Stateful and incremental.** Persistent SQLite. Re-imports are idempotent. Adding new CSVs over time accumulates correctly. Past imports can be inspected and removed.
- **Substantial code reduction.** Estimated ~4000 LOC → ~1800 LOC, primarily by removing the TUI, agent, wizard, and LLM-based CSV importer.

### Non-Goals (v2)

- **No multi-broker support at launch.** Schwab only. Adding Robinhood and others is a one-file-per-broker addition deferred until after v2 ships.
- **No LLM CSV detection.** The LLM-based "any broker" path is removed entirely. v2 declines unsupported CSVs with a clear message.
- **No TUI, no natural-language agent, no wizard.** Cut.
- **No web UI, no real-time brokerage API integration, no tax filing integration.** Same as v1 non-goals.
- **No backwards compatibility with v1 databases.** v2 ships a clean schema. Users migrate by re-importing CSVs (recommended) or by running a one-shot migration helper that exists only for the v2.0.x line.

---

## 3. User Surface

The entire CLI surface, exhaustively:

```
net-alpha <csv> [<csv>...] --account <label>            # import + check + render
net-alpha sim <ticker> <qty> --price P [--account <l>]  # pre-trade what-if planner
net-alpha imports                                       # list past imports
net-alpha imports rm <id>                               # remove an import
```

Removed from v1: `import`, `check`, `report`, `rebuys`, `tax-position`, `status`, `agent`, `tui`, the first-run `net-alpha` wizard.

### 3.1 Default command: `net-alpha <csv> --account <label>`

- Accepts one or more CSV files. All files in a single invocation are imported under the same `--account` label.
- `--account` is required for every import. There is no default. The user must explicitly name the account a CSV belongs to.
- After import, runs the wash sale engine (incrementally — see §6) and renders the standard two-section output.

Sample output:

```
$ net-alpha schwab_q3.csv --account personal
Detected broker: schwab
Imported 298 new trades into account 'schwab/personal' (4 duplicates skipped).

WATCH LIST — active rebuy windows
─────────────────────────────────
🔴 TSLA   wash sale TRIGGERED on 2024-09-15 (TSLA buy on 09-22)
          $1,243 loss disallowed → rolled into 2024-09-22 lot
🟡 NVDA   loss sold 2024-09-25, safe to rebuy after 2024-10-25 (in 12 days)
🟡 AAPL   loss sold 2024-09-18, safe to rebuy after 2024-10-18 (in 5 days)

YEAR-TO-DATE IMPACT
───────────────────
$3,420 disallowed across 7 wash sales (5 Confirmed, 2 Probable)
$12,847 deductible losses preserved

Run with --detail for per-violation breakdown.
⚠ This is informational only. Consult a tax professional before filing.
```

### 3.2 `net-alpha sim <ticker> <qty> --price P [--account <label>]`

Pre-trade what-if planner. Hypothetical sell against the current state of the database.

By default, the simulator **enumerates every account that holds the ticker** and shows one option per account. Each option reports: which lots would be consumed FIFO from that account, the realized P&L, and the wash-sale verdict for that scenario.

The wash-sale check is **always cross-account**: for any option, the simulator looks at buys in *all* accounts within the ±30-day window when deciding if it triggers.

`--price` is required: realized P&L cannot be computed without it, and there is no price feed in v2.

`--account` is optional: when passed, the simulator restricts output to that single account's option (useful when you already know which account you'd sell from). When omitted, all accounts holding the ticker are shown.

Sample output:

```
$ net-alpha sim TSLA 10 --price 180

SIMULATING: sell 10 TSLA @ $180.00

OPTION A — sell from 'schwab/personal' (FIFO)
  Lots consumed:  5 @ $200 (2024-08-15)
                  5 @ $190 (2024-09-01)
  Realized P&L:   -$150 (loss)
  Wash sale:      🔴 TRIGGERED — buy in 'schwab/roth' on 2024-09-22
                  $150 disallowed → would roll into Roth lot

OPTION B — sell from 'schwab/roth' (FIFO)
  Lots consumed:  10 @ $150 (2024-09-22)
  Realized P&L:   +$300 (gain)
  Wash sale:      N/A (gains do not trigger wash sales)

⚠ This is informational only. Consult a tax professional before filing.
```

Behavior at the edges:

- **Ticker held in zero accounts:** error, exit code 6 (`no holdings of TSLA`).
- **Requested qty exceeds an account's holdings:** that account is shown with a `⚠ insufficient shares — only N held` note instead of being silently dropped, so the user sees the constraint.
- **`--account <label>` for an account that doesn't hold the ticker:** error, exit code 6.

### 3.3 `net-alpha imports`

Tabular listing of past imports: `id`, `account`, `csv_filename`, `trade_count`, `imported_at`. Newest first.

### 3.4 `net-alpha imports rm <id>`

Removes an import (cascading delete of its trades). Recomputes wash sales over the affected window. Prompts for confirmation; `--yes` bypasses.

---

## 4. Architecture

### 4.1 Package layout

```
src/net_alpha/
├── cli/
│   ├── app.py              # Typer app, registers 4 commands
│   ├── default.py          # `net-alpha <csv>` handler
│   ├── sim.py              # `net-alpha sim` handler
│   └── imports.py          # `net-alpha imports [list|rm]` handler
│
├── brokers/                # NEW
│   ├── base.py             # BrokerParser protocol
│   ├── schwab.py           # Schwab implementation
│   └── registry.py         # ordered list of parsers; first match wins
│
├── ingest/                 # renamed from `import_`, narrower
│   ├── csv_loader.py       # raw CSV → list[dict[str, str]]
│   ├── option_parser.py    # OCC / Schwab-human regex (preserved)
│   └── dedup.py            # natural-key based; pure function
│
├── engine/
│   ├── detector.py         # main wash sale algorithm (preserved)
│   ├── matcher.py          # equity/option/ETF identity rules (preserved)
│   ├── etf_pairs.py        # bundled + user override loader (preserved)
│   ├── tax_position.py     # YTD impact aggregation (preserved, narrower)
│   └── simulator.py        # NEW: hypothetical sell evaluator
│
├── models/
│   └── domain.py           # Pydantic Trade, Lot, Violation, OptionDetails,
│                           # NEW: Account, ImportRecord
│
├── db/
│   ├── connection.py       # SQLite engine
│   ├── tables.py           # SQLModel tables
│   ├── repository.py       # narrowed; one method per CLI need
│   └── migrations.py       # hand-written; v2 starts at schema_version=1
│
├── output/                 # NEW — central rendering
│   ├── watch_list.py
│   ├── ytd_impact.py
│   ├── detail.py
│   ├── sim_result.py
│   ├── disclaimer.py
│   └── styles.py
│
└── etf_pairs.yaml
```

### 4.2 Removed from v1

- `src/net_alpha/cli/wizard.py`, `agent.py`, `check.py`, `report.py`, `rebuys.py`, `tax_position.py`, `status.py`, `import_cmd.py`
- `src/net_alpha/tui/` (entire package)
- `src/net_alpha/agent/` (entire package)
- `src/net_alpha/import_/schema_detection.py`, `anonymizer.py`

### 4.3 Dependencies removed

- `anthropic` (no LLM in any path)
- `questionary` (no interactive prompts beyond y/n confirmations, which use Typer's built-in)
- `textual` and any TUI-only dependencies
- `pydantic-settings` (no config file)

### 4.4 Two intentional design constraints

- **`brokers/` is the only place broker-specific code lives.** Adding a future broker is one new file plus a one-line registry entry. Engine, ingest, db, and output stay broker-agnostic.
- **`output/` is the only place that renders.** Engine and repository return data; output formats it. v1's per-command rendering created drift; centralizing fixes it.

---

## 5. Components

### 5.1 Key interfaces

```python
# brokers/base.py
class BrokerParser(Protocol):
    name: str
    def detect(self, headers: list[str]) -> bool: ...
    def parse(self, rows: list[dict[str, str]]) -> list[Trade]: ...
```

```python
# engine/simulator.py
def simulate_sell(
    ticker: str,
    qty: Decimal,
    price: Decimal,
    accounts: list[Account],            # accounts to enumerate; usually all accounts
    existing_lots: list[Lot],           # all lots, all accounts
    recent_trades: list[Trade],         # all trades, all accounts (cross-account lookback)
) -> list[SimulationOption]: ...        # one entry per account that holds the ticker

@dataclass
class SimulationOption:
    account: Account                    # which account this option sells from
    lots_consumed_fifo: list[LotConsumption]
    realized_pnl: Decimal
    would_trigger_wash_sale: bool
    blocking_buys: list[Trade]          # buys in lookback window (any account)
    lookforward_block_until: date | None
    confidence: ConfidenceLabel
    insufficient_shares: bool           # true when qty exceeds this account's holdings
    available_shares: Decimal           # this account's total holdings of the ticker
```

`SimulationOption`, `LotConsumption`, `AddImportResult`, `RemoveImportResult`, `ImportSummary`, and `ConfidenceLabel` (the existing Confirmed/Probable/Unclear enum) all live in `models/domain.py` alongside the persistent models.

The simulator is pure: given the same inputs it returns the same list of options. The CLI handler decides whether to filter by `--account` before passing accounts in, or render all of them.

```python
# db/repository.py — one method per CLI need, no leaky queries
class Repository:
    # Account / import management
    def get_or_create_account(self, broker: str, label: str) -> Account: ...
    def get_account(self, broker: str, label: str) -> Account | None: ...
    def list_accounts(self) -> list[Account]: ...
    def list_imports(self) -> list[ImportSummary]: ...
    def get_import(self, import_id: int) -> ImportRecord | None: ...
    def trades_for_import(self, import_id: int) -> list[Trade]: ...

    # Trade ingest
    def add_import(
        self, account: Account, record: ImportRecord, trades: list[Trade]
    ) -> AddImportResult: ...
    def remove_import(self, import_id: int) -> RemoveImportResult: ...
    def existing_natural_keys(self, account_id: int) -> set[str]: ...

    # Trade / lot / violation reads
    def all_trades(self) -> list[Trade]: ...
    def all_lots(self) -> list[Lot]: ...
    def all_violations(self) -> list[Violation]: ...
    def violations_for_year(self, year: int) -> list[Violation]: ...
    def trades_in_window(self, start: date, end: date) -> list[Trade]: ...

    # Recompute support
    def replace_violations_in_window(
        self, start: date, end: date, new_violations: list[Violation]
    ) -> None: ...
```

### 5.2 Schema

New tables in v2:

```python
class Account(SQLModel, table=True):
    id: int | None = Field(primary_key=True)
    broker: str                              # "schwab"
    label: str                               # "personal", "roth", "joint"
    # UNIQUE (broker, label)

class ImportRecord(SQLModel, table=True):
    id: int | None = Field(primary_key=True)
    account_id: int = Field(foreign_key="account.id")
    csv_filename: str
    csv_sha256: str                          # for "have I seen this exact file?"
    imported_at: datetime
    trade_count: int                         # rows actually inserted (post-dedup)

class Trade(SQLModel, table=True):
    id: int | None = Field(primary_key=True)
    import_id: int = Field(foreign_key="importrecord.id")
    account_id: int = Field(foreign_key="account.id")  # denormalized for query speed
    ticker: str
    trade_date: date
    action: str                              # buy, sell, etc.
    quantity: Decimal
    proceeds: Decimal
    cost_basis: Decimal
    option_details_json: str | None          # serialized OptionDetails or NULL
    natural_key: str                         # SHA256 — see §6
    # UNIQUE (account_id, natural_key)

class Lot(SQLModel, table=True):
    # mostly preserved from v1; gains account_id FK
    ...

class Violation(SQLModel, table=True):
    # mostly preserved from v1; gains loss_account_id, buy_account_id FKs
    ...
```

`Trade` is append-only (mutation only via `imports rm` cascading delete). `Lot` and `Violation` are pure derivatives of `Trade` and are regenerated by the engine.

---

## 6. Data Flow

### 6.1 Default command flow

```
CSV path(s)
  │
  ▼
csv_loader.load(path)                          → list[dict[str, str]]
  │
  ▼
brokers.registry.detect(headers)               → SchwabParser
  │  (or exit code 2: unsupported broker)
  ▼
SchwabParser.parse(rows)                       → list[Trade]
  │  (option symbols parsed via ingest.option_parser)
  ▼
account = repo.get_or_create_account("schwab", args.account)
  │
  ▼
existing_keys = repo.existing_natural_keys(account.id)
new_trades   = dedup.filter_new(trades, existing_keys)
  │
  ▼
repo.add_import(account, ImportRecord(filename, sha256, ts), new_trades)
  │
  ▼
INCREMENTAL RECOMPUTE (transactional):
  if new_trades:
    win_start = min(t.trade_date for t in new_trades) - 30 days
    win_end   = max(t.trade_date for t in new_trades) + 30 days
    window_trades = repo.trades_in_window(win_start, win_end)
    new_violations = engine.detector.detect_in_window(window_trades, win_start, win_end)
    repo.replace_violations_in_window(win_start, win_end, new_violations)
  │
  ▼
RENDER:
  output.watch_list.render(repo.all_lots(), repo.all_violations(), today=date.today())
  output.ytd_impact.render(repo.violations_for_year(current_year), year=current_year)
  output.disclaimer.render()
```

### 6.2 Why incremental, not full re-scan

Wash sale rules involve trades within ±30 calendar days of each other. New or removed trades cannot affect violations whose loss date and triggering buy date both fall outside `[min(changed_dates) - 30, max(changed_dates) + 30]`. The incremental recompute is therefore correct and bounded.

`engine.detector.detect_in_window(trades, start, end)` differs from `detect()` only in that it emits violations whose loss_sale_date falls within `[start, end]`. The set of trades passed in must include all trades within the window so cross-window matching works.

For `imports rm`, the same window is computed from removed trades and the same recompute runs.

### 6.3 Idempotency: the natural key

```
natural_key = sha256(
    account_id || trade_date.isoformat() || ticker || action ||
    str(quantity) || str(proceeds) || str(cost_basis) ||
    (option_details_json or "")
)
```

Stored as a UNIQUE column on `Trade`. Re-importing the same CSV inserts zero rows. Re-importing a CSV that has been extended (more recent rows added by Schwab) inserts only the new rows.

`csv_sha256` on `ImportRecord` is for human-facing "have I imported this exact file?" inspection in `net-alpha imports`, not for dedup. Dedup is per-trade.

### 6.4 Sim flow

```
all_accounts = repo.list_accounts()
trades       = repo.all_trades()                      # cross-account for wash-sale lookback
lots         = repo.all_lots()                        # all accounts; simulator filters per-option

if args.account:
    accounts = [repo.get_account("schwab", args.account)]   # or error: not found
else:
    accounts = all_accounts

options = engine.simulator.simulate_sell(
    ticker, qty, price,
    accounts=accounts,
    existing_lots=lots,
    recent_trades=trades,
)
# options is a list, one entry per account holding the ticker.
# error if options is empty (ticker held in zero matching accounts).

output.sim_result.render(options)
output.disclaimer.render()
```

Note: `repo.list_accounts()` is added to the repository interface (omitted from §5.1 for brevity; trivially `SELECT * FROM account`).

### 6.5 Imports management flow

```
list:    repo.list_imports() → output.imports_table.render()

rm <id>: confirm prompt (skip with --yes)
       → import_record = repo.get_import(id)            # or error: not found
       → trades_to_remove = repo.trades_for_import(id)
       → removed_dates = [t.trade_date for t in trades_to_remove]
       → repo.remove_import(id)                          # CASCADE delete trades
       → recompute over [min(removed_dates) - 30, max(removed_dates) + 30]
       → confirm count to user
```

### 6.6 Cross-flow invariants

- **Trade is the source of truth.** Lots and Violations are pure derivatives.
- **Account identity is `(broker, label)`.** No fuzzy matching, no auto-renaming.
- **No silent state mutation.** Every mutation is triggered by an explicit user command.

---

## 7. Error Handling

### 7.1 Failure surfaces

| # | Surface | Exit code | Behavior |
|---|---------|-----------|----------|
| 1 | Unsupported broker | 2 | Print supported brokers, suggest opening an issue with anonymized sample. |
| 2 | Malformed CSV row | 3 | Abort entire import. No partial state. Identify row number. |
| 3 | Duplicate import | 0 | Informational. Render "0 new trades, N duplicates skipped." Continue to render watch list / YTD. |
| 4 | Missing required argument | 2 | Typer's standard error; for `--account`, include example. |
| 5 | DB unwritable / corrupt | 4 | Print path and sqlite error; suggest moving aside and re-importing. No auto-recovery. |
| 6 | `imports rm <bad_id>` | 5 | "no import with id N. Run `net-alpha imports` to list." |
| 7 | `sim` ticker not held in any (or any matching) account | 6 | "no holdings of TSLA" — or, with `--account x`, "account schwab/x holds no TSLA". |

### 7.2 Cross-cutting policy

- Every error path returns a non-zero exit code suitable for shell composition.
- No exception traceback on stderr by default. Tracebacks gated behind `NET_ALPHA_DEBUG=1`.
- One-line error message + recovery hint. No multi-paragraph diagnostics in user output.
- Loguru remains for internal logging. Default: WARNING+ to stderr, INFO+ to `~/.net_alpha/net_alpha.log` (rotated).
- No silent fallbacks. If the user passes an unknown account label, error rather than auto-create — auto-creation produces "I have three accounts named 'personal'" bugs.

---

## 8. Testing Strategy

### 8.1 Engine unit tests — pure, no I/O, no mocks

100% coverage of `engine/`. `factory_boy` fixtures for trade/lot construction.

Required cases:

- Window boundaries: day -30, -1, 0 (same-day), +1, +30, +31
- Partial wash sale (sold 100, bought 30 → 30/100 of loss disallowed)
- FIFO multi-buy allocation when N buys land in the window
- Cross-account match (loss in account A, buy in account B)
- All three confidence labels emitted by appropriate scenarios
- Cross-year window (sell Dec 20, buy Jan 5)
- ETF same-ticker; ETF substantially-identical (SPY → VOO)
- Option same strike/expiry; option same underlying different strike
- Option-stock cross (sold stock at loss, bought call within 30d)
- Expired worthless option treated as loss

NEW for v2:

- `detect_in_window` correctness: same trades + window must produce the same violations as a full scan over the same trades.
- `simulate_sell` returns one `SimulationOption` per account that holds the ticker.
- `simulate_sell` lookback flags wash sale when a buy in any account in the past 30 days would trigger (cross-account).
- `simulate_sell` lookforward populates `lookforward_block_until` when this sell would block a rebuy.
- `simulate_sell` marks `insufficient_shares=True` when qty exceeds an account's holdings, and reports `available_shares` correctly.
- `simulate_sell` returns an empty list when no account holds the ticker (caller raises the user-facing error).

### 8.2 Broker parser tests — golden file

For each broker (Schwab only at launch):

- `tests/brokers/schwab/golden/<scenario>.csv` (anonymized real export)
- `tests/brokers/schwab/golden/<scenario>.expected.json` (expected `list[Trade]`)
- Test asserts `SchwabParser.parse(load(csv)) == expected`

Scenarios at launch: equities-only, mixed equities+options, options-only, ETFs, edge cases (zero-qty rows, dividends-as-buys, expired options).

When Schwab changes their CSV format, the workflow is: drop in new golden file pair, fix parser, all other tests stay green.

### 8.3 Repository tests — real SQLite, temp file

No mocks. Each test gets a fresh temp DB.

- `add_import` with 0 / N / all duplicate trades
- `remove_import` cascades trades and triggers windowed recompute
- `list_imports` returns expected order
- Foreign-key constraints enforced
- `Account (broker, label)` uniqueness enforced

### 8.4 CLI integration tests — Typer's `CliRunner`

End-to-end against a temp `~/.net_alpha`:

- Import once → exit 0, watch list rendered, YTD rendered, disclaimer at end
- Import same file twice → "0 new trades, N duplicates"
- `net-alpha sim TSLA 10 --price 150` after import → renders one option per holding-account; wash-sale check is cross-account
- `net-alpha sim TSLA 10 --price 150 --account roth` → restricted to Roth account only
- `net-alpha sim ZZZZ 10 --price 1` (ticker not held) → exit 6, "no holdings"
- `net-alpha sim TSLA 9999 --price 150` (more than held in any account) → renders all options with `insufficient shares` warning per account
- `net-alpha imports` → table with one row
- `net-alpha imports rm 1 --yes` → trades cleared, second `imports` shows empty
- `net-alpha unknown_broker.csv --account x` → exit 2, helpful message
- `net-alpha schwab.csv` (no `--account`) → non-zero exit, helpful message

### 8.5 Coverage targets

- Overall: 90%+
- `engine/`: 100%
- Enforced in CI via `pytest-cov` thresholds.

### 8.6 What's NOT tested

- No LLM tests (no LLM in v2)
- No TUI / agent tests (gone)
- No wizard tests (gone)

---

## 9. v1 → v2 Migration

### 9.1 Schema break

v2 schema is incompatible with v1 (new tables for `Account` and `ImportRecord`, new FKs on `Trade`, new natural-key column). v1 databases will not be read by v2.

### 9.2 User-facing migration paths

**Recommended: re-import from CSV.** v1 users still have their broker CSV exports. Running `net-alpha schwab_2024.csv --account personal` against a fresh v2 install reproduces the v1 state correctly.

**Optional one-shot helper:** `net-alpha migrate-from-v1` reads `~/.net_alpha/net_alpha.db` (v1 schema), creates a default `Account("schwab", "default")`, computes natural keys, and inserts trades into a new v2 database at `~/.net_alpha/net_alpha.db.v2`. This command exists only in v2.0.x and is removed in v2.1.

The user is told upfront that re-importing is the recommended path.

### 9.3 No long-lived compat shims

The codebase does not retain v1 schema knowledge beyond the migration helper. No backwards-compat code paths in the engine, ingest, or repository layers.

---

## 10. Out of Scope (v2)

Cuts vs. v1, made explicit so they are not reintroduced inadvertently:

- LLM-based CSV schema detection (entire pipeline: anonymizer, schema_detection, schema cache table, retry/backoff logic)
- Robinhood support (the existing hardcoded parser is removed in v2; can be reintroduced as a `brokers/robinhood.py` post-launch)
- TUI / Textual dashboard
- Natural-language ReAct agent
- First-run interactive wizard
- `~/.net_alpha/config.toml` config file
- `pydantic-settings` dependency
- Standalone `import`, `check`, `report`, `rebuys`, `tax-position`, `status`, `agent` commands (folded into default output or removed)
- Schema confirmation prompts before import
- API key prompting on any path

---

## 11. Open Questions

(All design questions resolved during brainstorming. Listed below for traceability.)

Resolved during design:

- ✅ `migrate-from-v1` helper ships in v2.0.x, removed in v2.1. Re-import is the documented primary path (§9).
- ✅ `etf_pairs.yaml` moves inside the package at `src/net_alpha/etf_pairs.yaml` so `pip install` ships it. User override at `~/.net_alpha/etf_pairs.yaml` adds to defaults (§4.1).
- ✅ Sim requires `--price`; no price feed in v2 (§3.2).
- ✅ Sim's `--account` is **optional**. By default, sim enumerates every account holding the ticker and shows one option per account; the wash-sale check for each option is cross-account. `--account` filters to one account when the user already knows which they want (§3.2).
- ✅ `--detail` is a flag on the default command, not a separate subcommand. Keeps the surface to four commands.
- ✅ Account display format: `"schwab/personal"`. User passes `--account personal`; broker is implicit from the CSV being imported.
- ✅ Stateful, incremental, persistent SQLite — no move to stateless or snapshot cache (§4, §6).

---

## 12. Estimated Impact

| Metric | v1 | v2 (estimated) |
|---|---|---|
| CLI entry points | 10 | 4 |
| Source LOC | ~4000 | ~1800 |
| Top-level packages under `net_alpha/` | 7 (`cli`, `tui`, `agent`, `import_`, `engine`, `db`, `models`) | 7 (`cli`, `brokers`, `ingest`, `engine`, `db`, `models`, `output`) |
| Runtime dependencies | 12+ (incl. `anthropic`, `questionary`, `textual`, `pydantic-settings`) | 7 (`typer`, `pydantic`, `sqlmodel`, `loguru`, `pyyaml`, `rich`, `python-dateutil` if needed) |
| Required setup before first useful run | API key, config file, broker arg, schema confirmation, two-step import/check | `--account` flag |
| Bundled brokers | 2 (Schwab, Robinhood) + LLM fallback | 1 (Schwab) |

---

*This document is a living spec. All decisions are open to revision based on user feedback before implementation begins.*
