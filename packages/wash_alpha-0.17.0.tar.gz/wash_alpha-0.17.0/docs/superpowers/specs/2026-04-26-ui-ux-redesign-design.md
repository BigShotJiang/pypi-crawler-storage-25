# UI/UX Redesign — Portfolio, Calendar, Imports, Sim, Detail

**Date:** 2026-04-26
**Status:** Design — pending implementation plan
**Scope:** All five web UI pages plus a new pricing subsystem
**Phasing:** 3 phases (foundation+portfolio → calendar+imports → sim+detail)

## Motivation

`net-alpha` was conceived as a wash-sale detector. The web UI grew to match: a "Dashboard" focused on watch-list violations, with import drop and KPIs around them. After live use, the user wants the home page repositioned as a **portfolio overview** — wash-sale detection becomes one signal among realized/unrealized P&L, per-symbol holdings, allocation, and lot aging. Other pages need targeted tightening: the calendar should expose all loss months (not just wash-sale months), import rows should explain themselves, the sim should also model buys (which can trigger wash sales on the replacement side), and the detail table can group, total, and add a few missing columns already in the data model.

## Policy change: external price data

The current `CLAUDE.md` line "no remote calls. no telemetry." is relaxed for **prices only**. Symbols leave the box; trade data, accounts, P&L never do. This is the only way to compute meaningful unrealized P&L and open-position market values without manual data entry. A config key (`enable_remote_prices`, default `true`) lets a user opt out and fall back to "no prices" mode (unrealized columns blank). `CLAUDE.md` and the user-facing disclaimer text get updated to reflect this.

---

## Phase 1 — Pricing foundation + Portfolio rebuild

### Pricing subsystem (`src/net_alpha/pricing/`)

New module, three pieces:

- **`provider.py`** — abstract base `PriceProvider` with `get_quotes(symbols: list[str]) -> dict[str, Quote]`. `Quote` is a Pydantic model: `{symbol, price: Decimal, as_of: datetime, source: str}`.
- **`yahoo.py`** — `YahooPriceProvider` implementation using `yfinance`. Bulk-fetches when possible. Supports OCC option symbols. Maps yfinance errors to a `PriceFetchError` with structured context. Network calls only.
- **`cache.py`** — read-through SQLite cache. New table `price_cache(symbol PK, price, as_of, fetched_at, source)`. TTL default 15 min, configurable. Public API: `get_price(symbol) -> Quote | None`, `get_prices_bulk(symbols) -> dict[str, Quote]`, `invalidate(symbols)`. Stale entries are still returned alongside a `stale=True` flag when the provider is unavailable; rendering layers decide how to display.

**Failure mode:** any provider error logs a warning and serves cache (with `stale=True`) when present. If no cache and no live quote, the symbol's price is `None` — table cells render `—`, unrealized G/L excludes that symbol from totals, and a yellow toolbar badge surfaces the partial-data state.

**Manual refresh:** `POST /prices/refresh?symbols=...` invalidates the cache for those symbols and triggers a fresh fetch. Used by the dashboard's `↻ Refresh` button.

**Privacy + disclosures:** the existing footer disclaimer line remains. When prices are remote-fetched and visible on the page, an additional line is rendered: `"Prices via Yahoo Finance, ~15 min delayed."` `CLAUDE.md` is updated with a "Price data" subsection under "Data Privacy Constraints" describing what does and does not leave the box.

**Schema migration:** add the `price_cache` table. Schema version bump.

### Portfolio page (replaces Dashboard)

**Route:** `GET /` (unchanged). Nav label and `<title>` change to "Portfolio".

**Toolbar (new):**
- Period selector: `YTD (current year)` / one option per distinct year with trades / `Lifetime`. Default YTD. Drives both KPI cards and per-symbol table.
- Account dropdown: `All accounts` / one per imported account. Default `All`.
- Options grouping: `Merge to underlying` (default) / `Show separately`.
- Right side: `Prices as of HH:MM · <source>` text + `↻ Refresh` button.

**KPI row (5 cards):**
1. `<Period> Realized` — sum of realized P&L within scope (period × account).
2. `<Period> Unrealized` — current market value − wash-adjusted basis for open lots in scope.
3. `Lifetime Realized` — always lifetime, ignores period toggle.
4. `Lifetime Unrealized` — always lifetime, ignores period toggle.
5. `Open Position $` — sum of (open_qty × current_price) across open lots in scope.

When the period toggle is set to `Lifetime`, cards 1–2 collapse to read identically to 3–4. We render the duplicate set anyway (no special-casing) so the layout doesn't shift. Acceptable redundancy.

**Visualization row (4 cards):**
- **Allocation treemap** — tile per top-N positions, sized by market value, colored by unrealized direction (green/red/gray). Remaining tile aggregates the long tail. Implemented as raw SVG/CSS grid (no JS chart lib for v1; treemap with simple slice-and-dice layout in Python, rendered to HTML).
- **YTD equity curve** — line of cumulative (realized + unrealized) across the year. Backfill caveat: only realized P&L is reconstructable from history; unrealized is a single "today" point. The chart shows realized cumulative as the line, with the present-day unrealized as a separate dot, and a tooltip notes the limitation. Going forward, end-of-day price snapshots will be persisted (deferred to Phase 1.5 if scope creeps; not blocking).
- **Wash-sale impact (period-scoped)** — 4-cell mini-grid: $ disallowed, total violations, confirmed count, probable count. Confirmed cell links to `/calendar?confidence=confirmed`.
- **Lots crossing LTCG soon** — top 5 open lots within 90 days of the 1-year mark (acquisition date + 365 days), sorted by urgency. Color-coded (red ≤14d, amber ≤45d, neutral otherwise). Each row links to `/ticker/{symbol}`. If no lots match, the card renders an empty-state line: `"No lots crossing the LTCG threshold within 90 days."`

**Per-symbol table:**

| Column | Source |
|---|---|
| Symbol | Trade.ticker (underlying) |
| Accounts | Distinct accounts holding open lots, comma-joined badge. If >3 accounts hold the position, render `<first> +N more` with a tooltip listing all. |
| Qty | Σ open_qty across lots in scope |
| Mkt $ | Qty × current_price |
| Open Cost | Σ (open_qty × adjusted_basis) |
| Avg Basis (C) | Open Cost ÷ Qty |
| Cash Sunk/sh (A) | (Σ buy_cash − Σ sell_cash − Σ option_premium) ÷ Qty held |
| Realized (period) | Realized P&L from sells in scope |
| Unrealized | Mkt $ − Open Cost |

Sorted by Mkt $ desc by default. Click row → `/ticker/{symbol}` (existing). Per-account split is shown on the ticker page (already implemented).

When option grouping is `Show separately`, option positions appear as their own rows with the OCC symbol; otherwise their cash flows roll into the underlying's `Cash Sunk/sh` and `Realized` columns, but contribute zero to `Qty`/`Mkt $` (which remain equity-only).

**Empty state:** when no imports exist, KPI cards and viz row are hidden. A single CTA: `+ Import your first CSV → /imports`. The drag-drop zone no longer lives on this page.

**New backend modules** (under `src/net_alpha/portfolio/`):
- `positions.py` — `compute_open_positions(period, account, group_options) -> list[PositionRow]`. Pure.
- `pnl.py` — realized & unrealized P&L computations, scoped by period/account. Pure.
- `treemap.py` — slice-and-dice layout for the treemap, returns positioned tiles.
- `equity_curve.py` — cumulative realized series + present-day unrealized point.
- `lot_aging.py` — top-N lots crossing LTCG threshold within window.

**Routes** (under `routes/portfolio.py`):
- `GET /` — page shell.
- `GET /portfolio/positions` — HTMX fragment for the table (re-rendered on toolbar change).
- `GET /portfolio/treemap` — fragment.
- `GET /portfolio/equity-curve` — fragment.
- `GET /portfolio/wash-impact` — fragment.
- `GET /portfolio/lot-aging` — fragment.

Lazy-loading these as separate fragments keeps initial paint snappy and isolates failure (a price-fetch hiccup in the treemap doesn't block the table).

**Tests:**
- 100% unit coverage of `portfolio/` pure functions, factory-built fixtures.
- Golden-file tests for each rendered fragment.
- Pricing: `FakePriceProvider` for unit tests; one network-gated test for `YahooPriceProvider` (skipped without `--run-network`).
- Cache: TTL behavior, stale-on-failure, manual invalidation.

---

## Phase 2 — Calendar dual-ribbon + Imports relocation & notes

### Calendar — stacked dual ribbon

Restructure the existing single ribbon into two stacked ribbons sharing the same month axis:

- **Top ribbon: monthly realized P&L bars.** One vertical bar per month. Height proportional to `|net_pl|`. Green if net gain, red if net loss. Tooltip: month, net P&L, gross gain, gross loss, trade count. Reflects current filter (year, ticker, account; confidence filter is a no-op for this layer).
- **Bottom ribbon: wash-sale dots.** Unchanged — current `_calendar_ribbon.html` content.

Visual correlation between the two layers is the whole point — a red bar with dots above = "October losses that triggered wash sales"; a red bar without dots = "losses available for harvesting."

**Backend:**
- New helper `monthly_realized_pl(year, ticker, account) -> list[MonthlyPnl]` in `routes/calendar.py` (or a small `calendar/aggregations.py` if it grows). Pure.
- New partial `_calendar_pl_ribbon.html`. Existing `_calendar_ribbon.html` unchanged.
- `calendar.html` template stacks the two partials.

**Tests:** unit tests for `monthly_realized_pl` covering empty months, gain-only months, loss-only months, mixed months, account/ticker filtering.

### Imports — drop zone relocation + per-row interpretation note

**Drop zone move:** delete the `{% include "_drop_zone.html" %}` from `dashboard.html`. Add it above the imports table in `imports.html`. No logic change.

**Per-row interpretation note:**

Default visible: `<broker> <file-type> · <date-range> · <trade-count> trades · <gl-lot-count> G/L lots`.
Example: `Schwab realized G/L · 2026-01-01 → 2026-02-28 · 47 trades · 12 G/L lots`.

Click ▸ to expand a detail panel below the row (HTMX swap):
- Detected broker/format
- Account hint (filename or CSV header)
- Trade-type breakdown: equity / option-open / option-close / option-expiry counts
- Distinct tickers count + first 5 tickers
- Parse warnings (if any) — shown red

**Schema migration** (next `meta.schema_version`):
Add columns to `import_record`:
- `min_trade_date TEXT`
- `max_trade_date TEXT`
- `equity_count INTEGER`
- `option_count INTEGER`
- `option_expiry_count INTEGER`
- `parse_warnings_json TEXT`

Backfill: on first run after migration, recompute these from joined trades for each existing `ImportRecord`. Idempotent.

**New routes:** `GET /imports/{id}/detail` returning the expanded detail panel as HTMX fragment.

**New partials:** `_imports_table.html` updated to support expand toggle; `_imports_detail_row.html` for the expanded content.

**Tests:**
- Unit test for date-range / type-breakdown computation from a fixture trade list.
- Migration test: open a v(N-1) DB, run migration, verify backfill produces expected aggregates.
- Golden-file test for `_imports_detail_row.html`.

---

## Phase 3 — Sim buy support + Detail enhancements

### Sim — combined trade what-if

Replace the sell-only form with a unified one.

**Form fields:**
- `Action`: BUY / SELL (segmented control)
- `Ticker` (autocomplete from existing tickers)
- `Quantity`
- `Price`
- `Account` (optional dropdown)
- `Date` (default today)

**Backend:** two pure functions in `engine/sim.py`:
- `simulate_sell(ticker, qty, price, account, date) -> SimSellResult` — refactor from the current sim code; same shape (lot trail, realized P&L, wash-trigger check on ±30-day window).
- `simulate_buy(ticker, qty, price, account, date) -> SimBuyResult` — for the proposed buy, scan unmatched losses on the same ticker (and substantially-identical ETF pairs) within the 30 days before `date`. If any qualifying loss exists, return the matched loss(es), the disallowed amount, and the resulting adjusted basis on the new lot. If none, return `clean=True`.

Routes: `POST /sim` dispatches on `action`. Renders `_sim_buy_result.html` or `_sim_sell_result.html` (rename of current `_sim_result.html`).

**Tests:** parametric unit tests for both simulators covering: no recent activity, exact day-30 / day-31 boundaries, partial qty replacement, cross-account scope, ETF substantially-identical pair triggering. Existing sell-sim test cases adapted to the renamed function.

### Detail page enhancements

- **Total bar above table:** `<n> violations · $<sum> disallowed · <c> confirmed · <p> probable · <u> unclear`. Reflects current filter.
- **Group by ticker (collapsible):** top-level rows are tickers (`SPY · 3 violations · $1,840 disallowed`); click ▸ to expand into individual violation rows. Default collapsed when ticker count > 5, expanded otherwise.
- **New column "Lag":** days between loss sale and triggering buy, displayed as `12d`. Sortable.
- **New column "Source":** `Schwab` / `Cross-account` / `Engine` badge — same component as the ticker page.

Existing filters (ticker, account, year, confidence) unchanged.

**Backend:** `routes/detail.py` adds totals computation and a group-by-ticker pre-aggregation step. Lag and source data already exist on the violation model.

**Tests:** unit tests for grouping logic and totals computation; golden-file test for the rendered grouped table.

---

## Cross-cutting

### Navigation

Top nav label `Dashboard` → `Portfolio`. Other labels (`Calendar`, `Imports`, `Sim`, `Detail`) unchanged.

### Account / period filter behavior

Same control pattern (period toggle, account dropdown) on Portfolio, Calendar, and Detail. State is per-page, not global — switching pages does not carry filter context. This is intentional: each page has different default scopes (Portfolio defaults to YTD; Detail defaults to "no filter / all").

### Disclaimer footer

Existing line ("This is informational only…") stays. When prices are remote-fetched and visible on the current page, a sibling line is rendered: `"Prices via Yahoo Finance, ~15 min delayed."`

### Dependencies

Add to `[ui]` extras in `pyproject.toml`:
- `yfinance` — Yahoo provider

No new chart libraries — treemap, equity curve, mini-bars all built with SVG/CSS using existing Tailwind utilities. This keeps the "no node, no npm" constraint intact.

### Configuration

`~/.net_alpha/config.yaml` (new file, optional):
```yaml
prices:
  enable_remote: true
  source: yahoo
  cache_ttl_seconds: 900
```

When `enable_remote: false`, all price-dependent UI degrades to "—" cells and unrealized totals show `n/a`. The `Refresh` button is hidden.

### CLAUDE.md updates

- Add a "Price data" subsection under "Data Privacy Constraints" stating: symbols leave the box for quote fetches; trade data, accounts, P&L never do; can be disabled via config.
- Update the architecture section with the new `pricing/` and `portfolio/` modules.
- Add a "Web UI conventions" subsection with the period/account toggle pattern.

---

## Phasing summary

| Phase | Scope | Independent? |
|---|---|---|
| 1 | Pricing subsystem + Portfolio page rebuild + nav rename + `enable_remote_prices` config | Foundation — must ship first |
| 2 | Calendar dual-ribbon + Imports drop-zone move + interpretation notes (incl. schema migration) | Independent of Phase 3 |
| 3 | Sim buy support + Detail page enhancements | Independent of Phase 2 |

Each phase becomes its own implementation plan and PR.

## Out of scope

- Schwab API price provider (deferred — Yahoo first, Schwab a future option once OAuth is needed elsewhere).
- End-of-day price snapshotting for a real historical equity curve (deferred to Phase 1.5; Phase 1 ships realized-only line + present-day point).
- Bulk export of detail-page filtered violations to CSV (separate workflow worth its own discussion).
- Inline lot-trail expansion on the detail page (duplicates ticker page; revisit only if asked).
- Cash position / cash-drag indicator (no source of truth for cash balance from current imports).
