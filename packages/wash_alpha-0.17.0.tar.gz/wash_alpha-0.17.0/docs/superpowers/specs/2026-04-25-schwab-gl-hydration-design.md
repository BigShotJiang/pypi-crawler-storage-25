# Schwab Realized G/L Hydration — Design Spec

**Date:** 2026-04-25
**Status:** Approved (brainstormed and validated)

## Goal

Enable accurate wash-sale detection for Schwab users by ingesting their Realized Gain/Loss CSV alongside Transaction History. Schwab's Transaction History export does not carry cost basis on Sell rows, so the engine currently sees zero loss sales and produces zero violations even when wash sales exist. The Realized G/L export carries Schwab's lot-matched cost basis. Together, the two files give the engine enough data to detect wash sales — and to verify our results against Schwab's own calculations.

## Background — why this matters

When a Schwab user uploads only a Transaction History CSV today:

1. Buys get `cost_basis = abs(Amount)` (correct)
2. Sells get `cost_basis = NULL` (no source for it)
3. `Trade.is_loss()` returns `False` for every sell because it requires both `proceeds` and `cost_basis`
4. Detector sees zero loss sales → zero violations → empty dashboard

Schwab provides cost basis on a separate report: **Accounts → Cost Basis → Realized Gain/Loss → Export**. That report contains every closed lot with cost basis, original buy date, and Schwab's own wash-sale flag. We import it as a "hydration" source for the Sell rows already in the database.

## Scope decisions (from brainstorming)

| # | Decision |
|---|---|
| 1 | **Single upload action, multi-select drop zone.** User drops one or more CSVs at once. |
| 2 | **G/L file is per-lot, not per-sale.** One row per tax-lot consumed by a sale. Multiple rows can sum to one Sell trade. |
| 3 | **Trust Schwab for closed Schwab positions; engine adds cross-account wash sales.** Schwab is authoritative for what they can see; engine's job is to add value where they can't (other brokers, substantially-identical pairs). |
| 4 | **Cost basis fallback: G/L → FIFO → NULL.** Confidence label reflects source (Confirmed / Probable / Unclear maps onto the existing 3-tier system). |
| 5 | **Drop zone accepts any combination, any count.** Auto-detect each file's type from headers. Works even if user only has G/L (no transactions yet) or wants to refresh just one file. |

## Architecture overview

```
Drop CSVs (any combo) ──▶ Detect each file type from headers
                          ├─ SchwabTransactionsParser ─▶ TradeRow inserts
                          └─ SchwabRealizedGLParser  ─▶ RealizedGLLotRow inserts
                                          │
                                          ▼
                          Stitch pass (per affected account):
                          For each Sell trade:
                            1. Match G/L lot rows  → hydrate cost_basis (basis_source='g_l')
                            2. else FIFO buy lots  → hydrate cost_basis (basis_source='fifo')
                            3. else NULL           → basis_source='unknown'
                                          │
                                          ▼
                          Engine recompute on ±30-day window
                                          │
                                          ▼
                          Merge with Schwab's verdicts:
                            - Schwab Yes  → source='schwab_g_l',  confidence='Confirmed'
                            - Engine cross-account → source='engine', confidence='Probable'
                            - Engine substantially-identical → source='engine', confidence='Unclear'
```

## Data model

### New table: `realized_gl_lots`

```python
class RealizedGLLotRow(SQLModel, table=True):
    __tablename__ = "realized_gl_lots"

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)

    # Match keys
    symbol_raw: str = Field(index=True)      # "CRCL 06/18/2026 150.00 C" or "WRD"
    ticker: str = Field(index=True)          # "CRCL" or "WRD" (underlying)
    closed_date: str = Field(index=True)     # YYYY-MM-DD; joins with Sell.trade_date
    opened_date: str                          # YYYY-MM-DD; original buy

    quantity: float
    proceeds: float
    cost_basis: float                         # adjusted (post-wash-sale carryforward)
    unadjusted_cost_basis: float              # pre-adjustment

    # Schwab's wash-sale call (per lot)
    wash_sale: bool                           # True if Schwab's "Wash Sale?" == "Yes"
    disallowed_loss: float                    # 0.0 when not a wash sale

    term: str                                 # "Short Term" | "Long Term"

    # Option fields parsed from symbol_raw
    option_strike: float | None = None
    option_expiry: str | None = None
    option_call_put: str | None = None

    # Idempotent dedup
    raw_row_hash: str = Field(unique=True, index=True)
```

`raw_row_hash` is computed over `(account_id, symbol_raw, closed_date, opened_date, quantity, cost_basis)`. Re-importing the same G/L file → no duplicate rows.

### Modified `TradeRow`

Add one column:

```python
basis_source: str = Field(default="unknown")
# values: "broker_csv" | "g_l" | "fifo" | "unknown"
```

Lets us tell at query time why a sell has the cost basis it does — drives the confidence label.

### Modified `WashSaleViolationRow`

Add one column:

```python
source: str = Field(default="engine")
# values: "schwab_g_l" | "engine"
```

Combined with existing `confidence`, lets the UI render "Confirmed by Schwab" vs "Cross-account (engine)".

### Schema migration: version 1 → 2

```sql
ALTER TABLE trades ADD COLUMN basis_source TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE wash_sale_violations ADD COLUMN source TEXT NOT NULL DEFAULT 'engine';
CREATE TABLE IF NOT EXISTS realized_gl_lots ( ... );
UPDATE meta SET value='2' WHERE key='schema_version';
```

Wrapped in `_migrate_v1_to_v2()` called from `init_db()` when `schema_version=1` is detected. All ALTERs are additive with defaults — existing rows remain valid.

## Parser changes

### Smart header detection in `load_csv`

The G/L file has a non-empty title row before the actual headers:

```
"Realized Gain/Loss - Lot Details for Short_Term as of ...","","",...
"Symbol","Name","Closed Date","Opened Date",...
```

`load_csv` scans the first 5 rows and picks the one that looks like headers using a heuristic:
- Has 4+ non-empty cells, AND
- No cell starts with `$`, AND
- No cell matches a date pattern (`MM/DD/YYYY` or `YYYY-MM-DD`)

This stays generic enough to handle future brokers with similar preambles.

### Parser registry

Two parsers, registered in `brokers/registry.py`:

| Parser | Required headers (subset must match) |
|---|---|
| `SchwabTransactionsParser` (rename of current `SchwabParser`) | `Date, Action, Symbol, Quantity, Amount` |
| `SchwabRealizedGLParser` (new) | `Symbol, Closed Date, Opened Date, Quantity, Proceeds, Cost Basis (CB), Wash Sale?` |

The registry's `detect_broker(headers)` returns the first matching parser. Headers are unique enough that ambiguity isn't a concern.

### `SchwabRealizedGLParser` skeleton

```python
class SchwabRealizedGLParser:
    name = "schwab_realized_gl"
    REQUIRED_HEADERS = {
        "Symbol", "Closed Date", "Opened Date",
        "Quantity", "Proceeds", "Cost Basis (CB)", "Wash Sale?",
    }

    def detect(self, headers): return self.REQUIRED_HEADERS.issubset(set(headers))

    def parse(self, rows, account_display) -> list[RealizedGLLot]:
        # For each row:
        #   Symbol → strip whitespace
        #   Closed Date / Opened Date → parse "MM/DD/YYYY" → date.isoformat()
        #   Quantity → float
        #   Proceeds, Cost Basis (CB), Unadjusted Cost Basis → strip "$" and "," → float
        #   Wash Sale? → "Yes" → True, else False
        #   Disallowed Loss → strip "$" → float; "" → 0.0
        #   Term → as-is
        #   parse_option_symbol(Symbol) → option_strike/expiry/call_put + ticker
        # Returns list[RealizedGLLot]
```

Both Short Term and Long Term G/L use the same schema, so one parser handles both — only the title row differs (and `load_csv` skips it).

## Stitch algorithm

Runs after every import that touches a Schwab account. Operates per-account.

For each Sell trade in the affected account:

```python
def stitch_sell(sell: TradeRow, repo: Repository) -> StitchOutcome:
    # 1. Try G/L hydration
    gl_rows = repo.get_gl_lots(
        account_id=sell.account_id,
        symbol_raw=match_symbol(sell),
        closed_date=sell.trade_date,
    )

    if gl_rows:
        agg_qty = sum(r.quantity for r in gl_rows)
        agg_cb  = sum(r.cost_basis for r in gl_rows)
        warning = None
        if abs(agg_qty - sell.quantity) / sell.quantity > 0.005:
            warning = f"G/L lot quantities ({agg_qty}) don't sum to sell quantity ({sell.quantity})"
        sell.cost_basis  = agg_cb
        sell.basis_source = "g_l"
        return StitchOutcome(source="g_l", warning=warning)

    # 2. FIFO fallback from buy lots
    buy_lots = repo.get_buy_lots_for_ticker(
        account_id=sell.account_id,
        ticker=sell.ticker,
        before_date=sell.trade_date,
    )
    consumed_qty, consumed_basis = _consume_fifo(buy_lots, sell.quantity)
    if consumed_qty >= sell.quantity * 0.995:
        sell.cost_basis  = consumed_basis
        sell.basis_source = "fifo"
        return StitchOutcome(source="fifo")

    # 3. No basis available
    sell.cost_basis  = None
    sell.basis_source = "unknown"
    return StitchOutcome(source="unknown")


def match_symbol(t: TradeRow) -> str:
    """Reconstruct the comparable raw symbol from a Trade for G/L matching."""
    if t.option_strike is not None and t.option_expiry is not None and t.option_call_put is not None:
        expiry = datetime.strptime(t.option_expiry, "%Y-%m-%d").strftime("%m/%d/%Y")
        return f"{t.ticker} {expiry} {t.option_strike:.2f} {t.option_call_put}"
    return t.ticker
```

After stitching, the engine's `detect_in_window()` runs against the trades table — same code path as before, but now sells have hydrated cost basis where G/L provided it.

## Wash-sale merge logic

After the engine produces its violation set, merge with Schwab's verdict from `realized_gl_lots`:

| Scenario | Source | Confidence |
|---|---|---|
| Schwab G/L row says `wash_sale=Yes` (same-account, exact-ticker) | `schwab_g_l` | `Confirmed` |
| Engine flags same-account exact-ticker wash sale that Schwab also flagged | dedup — keep the Schwab one | — |
| Engine flags cross-account wash sale (Schwab can't see other broker) | `engine` | `Probable` |
| Engine flags substantially-identical (ETF-pair, e.g. SPY/VOO) within Schwab | `engine` | `Unclear` (Schwab doesn't model substitutes) |
| Engine flags same-account exact-ticker wash sale, but Schwab said `No` | `engine` | `Unclear` (likely engine bug, surface for investigation) |
| No G/L coverage for this account → pure engine output | `engine` | engine's existing confidence label |

Key rule: **we never silently override Schwab on what they explicitly cleared**, but we add value where they can't see (other brokers, substantially-identical pairs).

Engine-only detections that Schwab would have caught (same account, exact ticker, but Schwab said No) are downgraded to `confidence='Unclear'` and kept visible — they may indicate a discrepancy worth investigating.

## UI changes

### Drop zone (`_drop_zone.html`)

- `<input type="file" multiple accept=".csv">` — accepts multiple files at once
- Drag-drop handler accepts `e.dataTransfer.files` (any count)
- Subtitle changes to "Drop one or more Schwab CSVs · max 50 MB each"

### Preview modal (`_import_modal.html`)

Per-file detection cards:

```
Detected files:
┌─────────────────────────────────────────────────┐
│ ✓ Transaction History — 58 trades preview       │
│   Long_Term_XXX623_Transactions_*.csv           │
├─────────────────────────────────────────────────┤
│ ✓ Realized G/L (Short Term) — 30 lot rows       │
│   Short_Term_GainLoss_Realized_*.csv            │
├─────────────────────────────────────────────────┤
│ ⚠ Unrecognized format                            │
│   some_other.csv — no parser matched headers    │
└─────────────────────────────────────────────────┘

Account: [personal ▾]
            [ Cancel ]  [ Import 2 files ]
```

- Account label is single (one input applies to all files — they belong to the same Schwab account)
- Unrecognized files show ⚠ but don't block submit; they're just skipped
- Submit disabled if zero recognized files

### Backend route changes

`POST /imports/preview` and `POST /imports`:
- Accept `files: list[UploadFile] = File(...)` instead of single `file`
- Preview returns per-file detection result for the modal
- Upload runs each file through its detected parser, then runs the stitch pass once at the end

### Flash message after upload

Adapts to what was actually uploaded:

> "Imported 58 new trades · 30 G/L lot records · skipped 0 duplicates · hydrated 12 sells from G/L · 0 warnings"

### Violations rendering — new source badge

Each violation card / table row gets a small badge next to the confidence pill:

| Confidence | Source badge |
|---|---|
| 🔴 Confirmed | "Schwab" or "Engine" |
| 🟡 Probable | "Cross-account" |
| 🔵 Unclear | "Substantially identical" or "Disagreement" |

Tooltip on the badge explains why it has that source.

### Ticker drilldown — new "Schwab lot detail" panel

When `realized_gl_lots` rows exist for the ticker, render a small read-only table below the violations card:

```
Schwab Lot Detail (from G/L)
Closed       Opened       Qty    Cost basis    Wash sale?    Disallowed
04/20/2026   04/17/2026   1      $460.66       No
04/20/2026   04/15/2026   1      $230.00       Yes           $30.00
...
```

Helps user verify our numbers against Schwab's source data.

### Imports list (`_imports_table.html`)

- New column: "Files" — instead of single CSV name, show count + types: "Transactions + Short G/L"
- Each ImportRecord becomes one row in this table per upload session, tagged with what it contained

### CLI parity (`net-alpha <csv>...`)

The CLI already accepts multiple files. The stitch pass needs to run there too. Same algorithm, same merge rules, same output. The web UI gets a cleaner per-file preview, but the CLI gets text-equivalent output.

## Out of scope (deferred)

- **Non-Schwab brokers.** Fidelity, Vanguard, IBKR G/L parsers are separate work — but the architecture (sidecar `realized_gl_lots` table + parser registry) accepts them cleanly later.
- **User-elected accounting method.** We assume Schwab's G/L reflects whatever method the user has set on Schwab. If their election changes mid-period and G/L data is mixed, undefined behavior — surface as a known limitation in docs.
- **Wash-sale "Yes" rows where engine missed it entirely.** Section "Wash-sale merge logic" handles this by ingesting Schwab's verdict directly. We don't try to retroactively explain why our engine disagreed.
- **Re-upload of G/L for the same period.** Will work via `raw_row_hash` dedup — existing rows skipped, new rows added, stitch re-runs. Not specifically optimized, but correct.
- **Long-term G/L is parsed and stored** but our wash-sale focus stays on short-term losses (long-term wash sales are rare and our engine handles them generically anyway via the ±30-day window check, regardless of holding period).
- **1099-B PDF import.** Out of scope. Users export the G/L CSV from the Cost Basis page.
- **Bulk operations on G/L records.** No "delete all G/L for account X" admin tool. Use `net-alpha imports rm <id>` to remove an import (which removes its G/L rows too via FK).

## Known risks (tracked, not blocking)

1. **Quantity-mismatch tolerance of 0.5%** is a guess. May need to relax to 1% if Schwab's rounding gets weird with options multipliers. Will tune based on real data.
2. **Option symbol matching** assumes Schwab format `"TICKER MM/DD/YYYY STRIKE.XX C|P"` is consistent across both Transactions and G/L exports. If formats drift (different decimal precision, etc.), normalize defensively in `match_symbol()`.
3. **`Wash Sale?` flag granularity.** Schwab flags it per-lot. If a sell consumed 3 lots and 2 of them were wash sales, we'll have 2 violations from that one sell — which is technically what Schwab reports. Engine has to handle multiple violations per sell trade (mostly already does, but worth verifying in tests).
4. **Schema migration on populated v1 DBs.** The migration is additive and safe in theory, but no real v1 DB has been migrated yet because `init_db()` was added recently. Test with a synthesized v1-shape DB before shipping.

## Testing strategy

### Parser unit tests

`tests/brokers/test_schwab_realized_gl.py`:
- Anonymized fixture file with all relevant column variants
- Test: parses headers correctly with title row preamble
- Test: handles `$` and `,` in money fields
- Test: parses `Yes`/`No` → bool
- Test: parses option symbols correctly
- Test: rejects rows with malformed dates / quantities
- Test: handles empty `Disallowed Loss` cell → 0.0

### Stitch unit tests

`tests/engine/test_stitch.py`:
- G/L exact match: hydrates cost_basis, sets `basis_source='g_l'`
- G/L quantity mismatch within 0.5%: hydrates with warning
- G/L quantity mismatch outside 0.5%: hydrates with louder warning, source still `g_l`
- No G/L, sufficient buy lots: FIFO consumption, source `fifo`
- No G/L, insufficient buy lots: stays NULL, source `unknown`
- Multi-lot G/L sum matches sell quantity: hydrates with sum
- Option symbol matching: round-trips ticker+strike+expiry+call_put correctly

### Wash-sale merge tests

`tests/engine/test_merge.py`:
- Schwab `wash_sale=Yes` + engine agrees: one violation, source=`schwab_g_l`, confidence=`Confirmed`
- Schwab `wash_sale=Yes` + engine misses: violation ingested from Schwab, source=`schwab_g_l`
- Engine flags cross-account: source=`engine`, confidence=`Probable`
- Engine flags ETF-pair within Schwab: source=`engine`, confidence=`Unclear`
- No G/L for account: pure engine output unchanged

### Web integration tests

`tests/web/test_multi_file_upload.py`:
- POST `/imports/preview` with 2 files: returns per-file detection
- POST `/imports/preview` with 1 unrecognized file: returns `⚠` row, no error
- POST `/imports` with Transactions + G/L: 303 redirect with flash message
- POST `/imports` with G/L only (no transactions): still works, no stitch effect
- POST `/imports` with Transactions only: stitches via FIFO, source `fifo`
- After upload, `/ticker/<symbol>` renders Schwab lot detail panel when G/L rows exist

### Migration test

`tests/db/test_migration.py`:
- Synthesize a v1-shape DB (no `basis_source`, no `source`, no `realized_gl_lots`)
- Call `init_db()` → schema_version becomes 2, columns/table added, existing rows preserved with default values

### Real-data smoke test

Manual: re-upload `private/schwab_lt/Long_Term_XXX623_Transactions_*.csv` + `private/schwab_st/Short_Term_GainLoss_Realized_Details_*.csv` → dashboard should reflect Schwab's wash-sale calls (zero in this case, but with non-zero disallowed loss totals where Schwab flagged anything).
