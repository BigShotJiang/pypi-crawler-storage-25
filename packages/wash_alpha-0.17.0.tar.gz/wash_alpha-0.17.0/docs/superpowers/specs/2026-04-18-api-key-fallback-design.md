# API Key Fallback Architecture for Schema Detection

## Objective
Make the Anthropic API key optional for the most common onboarding paths in the `net-alpha` CLI application. The application will fall back to hardcoded schemas for popular brokers, only requiring an API key for unknown, novel CSV formats.

## Motivation
Currently, users are blocked from importing trades (via `import_cmd.py` and `wizard.py`) unless they provide an Anthropic API key. This creates friction during the first-time user experience. By implementing built-in schemas for the most common brokers (e.g., Schwab, Robinhood), we remove this friction while preserving the AI's ability to gracefully handle edge cases.

## Design

### 1. Data Flow

The `run_import` orchestrator (`src/net_alpha/import_/importer.py`) will resolve the CSV schema in the following order:

1. **Cache (`SchemaCacheRepository`)**: Has the user already imported a CSV with this exact header signature?
2. **Hardcoded Fallback**: Does the `broker_name` (e.g., "schwab", "robinhood") match a known, built-in `SchemaMapping`?
3. **AI Detection**: If an API key is available, send the header and anonymized sample rows to the LLM to dynamically determine the schema. Prompt the user to confirm.
4. **Error**: If no API key is available, abort with a friendly error informing the user that they need to provide one (`ANTHROPIC_API_KEY`) to parse this unknown broker format.

### 2. Component Refactoring

#### `src/net_alpha/import_/schema_detection.py`
Add a dictionary of known `SchemaMapping` configurations.
```python
KNOWN_BROKER_SCHEMAS: dict[str, SchemaMapping] = {
    "schwab": SchemaMapping(...),
    "robinhood": SchemaMapping(...),
    # Can be extended in the future
}
```

#### `src/net_alpha/cli/wizard.py`
- Remove the eager `_ensure_api_key` check from the main startup loop (`run_wizard`).
- The wizard should start cleanly without demanding an API key upfront. The AI Agent action should handle its own API key check, and `import` will handle its own.

#### `src/net_alpha/cli/import_cmd.py`
- Make the `client` (Anthropic) optional when initializing the `ImportContext`. Do not raise an immediate `Exit` if the `api_key` is missing.

#### `src/net_alpha/import_/importer.py`
- Refactor the `run_import` function to implement the data flow (Cache -> Fallback -> AI -> Error).
- Update `ImportContext` to accept `Optional[object]` for the Anthropic client.
- Handle the error case gracefully if the fallback fails and the client is `None`.

## Security & Constraints
- No new environment variables are needed.
- No schema caching is performed for hardcoded fallbacks (they are static).
- Ensure the user confirmation callback (`_confirm_schema`) is still only triggered for AI-detected schemas, not hardcoded ones, to maintain a smooth UX for known brokers.
