# UI Visual Theme — Apple-dark with cyber undertone

**Date:** 2026-04-26
**Status:** Design — pending implementation plan
**Scope:** Visual theme, color tokens, typography, components, chart library, two component-level changes (allocation viz format, home-page wash-sale module)
**Sibling spec:** `2026-04-26-ui-ux-redesign-design.md` (the feature/route redesign on the same date). This spec sits **on top of** that one — same routes, same data, restyled layer.

## 1. Motivation

The current web UI is a textbook "data-dense Tailwind dashboard": clean utilities, clear contrast, but generic. The user's read is "too toy and ugly" for a tool that handles real wash-sale and tax decisions. The visual ask is for an **Apple-dark aesthetic with subtle cyber undertones** — Apple Stocks / Vision Pro energy on a financial workbench. We also concluded that two component-level designs (the home-page wash-sale ribbon, and the allocation treemap) were carrying the wrong information weight and should be redesigned outright.

Nothing in this spec changes routes, business logic, the ORM, or the public Python API. It changes templates, CSS, one chart library, and two route handlers (one to switch a partial, one for new aggregations).

## 2. Scope

### In scope
- New color tokens + Tailwind config for an Apple-dark theme (dark-only, no light mode).
- Typography stack switch: Inter for UI, JetBrains Mono / SF Mono fallback for numerics. Fira Code / Fira Sans removed.
- Replace hand-rolled SVG charts with ApexCharts (vendored to `/static/`).
- Component restyling: topbar, navigation, segmented controls, KPI cards, panels, status chips, ticker icons in tables.
- Combined hero KPI cards: `Realized P/L` and `Unrealized P/L` each carry both YTD and Lifetime, side-by-side, in one card.
- Replace the allocation treemap with a **donut + leaderboard chips** module on a curated 10-color palette.
- Replace the calendar dot ribbon on the home page with a **Wash-sale watch · last 30 days** panel listing recent loss closes with a countdown to "safe to repurchase." (The full year calendar still lives at `/calendar`.)
- One small new pure helper in `portfolio/` for "recent loss closes" aggregation.

### Out of scope
- Light mode. (Dark only. Requested explicitly.)
- New pages or routes.
- Business logic changes — wash-sale engine, pricing, ORM, parsers all unchanged.
- Mobile. The app keeps `<meta name="viewport" content="width=1024">` (existing). Responsive polish is non-goal.
- Backend changes for tables that still render the same data.
- Replacing htmx or Alpine.

## 3. Design tokens

### 3.1 Color

```
/* Canvas */
--bg          #000000   /* page background, OLED-black */
--surface     #1C1C1E   /* cards, panels */
--surface-2   #2C2C2E   /* elevated/hover, segment-button active */
--surface-3   #3A3A3C   /* highest elevation, ticker icon background */

/* Hairlines */
--hairline           rgba(255,255,255,0.08)   /* default 0.5px borders */
--hairline-strong    rgba(255,255,255,0.14)   /* hovered borders */

/* Text */
--text       #FFFFFF
--label-1    rgba(235,235,245,0.92)
--label-2    rgba(235,235,245,0.60)
--label-3    rgba(235,235,245,0.35)

/* Brand / cyber accent (lead KPI halo, brand mark, "+ unrealized today" markers) */
--indigo     #5E5CE6   /* Apple systemIndigo */
--violet     #BF5AF2   /* Apple systemPurple */

/* Semantic — P/L */
--pos        #30D158   /* Apple systemGreen */
--neg        #FF453A   /* Apple systemRed */

/* Semantic — status (wash-sale confidence + warnings) */
--warn       #FF9F0A   /* Apple systemOrange — "probable" */
--info       #64D2FF   /* Apple systemTeal — "unclear" */
/* "confirmed" reuses --neg */

/* Allocation rank palette — categorical, slot-bound */
--rank-1   #0A84FF   /* systemBlue */
--rank-2   #FFD60A   /* systemYellow */
--rank-3   #30D158   /* systemGreen — categorical, see §3.1.1 */
--rank-4   #FF375F   /* systemPink */
--rank-5   #5E5CE6   /* systemIndigo */
--rank-6   #64D2FF   /* systemTeal */
--rank-7   #5AC8FA   /* systemCyan (dim tier) */
--rank-8   #BF5AF2   /* systemPurple (dim tier) */
--rank-9   rgba(181,181,255,0.65)    /* lavender (dim tier) */
--rank-10  rgba(255,255,255,0.40)    /* neutral (dim tier) */
--rank-rest rgba(255,255,255,0.14)   /* "+N more" segment + ghost chip */
```

#### 3.1.1 Color zoning rule

The same hue can appear in different roles. To prevent miscueing, **role is determined by visual context**, not by color alone:

| Zone | Hue | Where it appears |
|---|---|---|
| Brand / cyber moment | indigo → violet gradient + glow | Brand mark, lead-KPI radial halo, equity-curve "+ unrealized today" dot/line |
| P/L semantic | systemGreen / systemRed | KPI numerals, table cells with `+`/`−` deltas, equity-curve line |
| Status semantic | red / amber / cyan | Wash-sale confidence chips, wash-watch dot, partial-data warning |
| Allocation categorical | 10-slot rank palette | Donut segments, leaderboard chip dots — only inside the `Allocation` panel |

`systemGreen` is shared between "P/L gain" and "rank 3 categorical." Acceptable because the chip context (`● MSFT $42.0k 8.7%`) and the P/L cell context (`+$3,108`) are visually distinct. If this overlap proves confusing in practice, swap rank-3 to a slightly limier `#5BD379` and keep `systemGreen` exclusive to P/L. (Documented; not implemented now.)

### 3.2 Typography

Replace the current Fira Sans / Fira Code stack.

```
font-family-sans:  -apple-system, "SF Pro Display", "Inter", system-ui, sans-serif
font-family-mono:  "SF Mono", "JetBrains Mono", ui-monospace, Menlo, monospace
font-feature-settings (sans):  "ss01", "cv11"
font-feature-settings (mono):  "tnum", "ss01"
font-variant-numeric (numbers): tabular-nums
```

`Inter` and `JetBrains Mono` are vendored as woff2 to `/static/fonts/` (no Google Fonts at runtime — keeps the privacy posture intact). Apple system fonts are listed first so Mac users get pixel-perfect SF without a font load.

**Type scale** (snug, between Bloomberg-compact and Apple-comfortable):

| Token | Size | Weight | Letter | Usage |
|---|---|---|---|---|
| display-1 | 28px | 700 | -0.025em | Page title (`Portfolio`) |
| heading-1 | 20px | 600 | -0.025em | Panel sub-titles inside cards |
| heading-2 | 14px | 600 | -0.015em | Panel headers (`Equity curve`, `Allocation`) |
| body | 13px | 400 | normal | Default body text |
| label-uc | 11px | 500 | 0.04em / uppercase | KPI head, panel meta |
| caption | 11px | 400 | normal | Footnotes, "as of" |
| micro | 10px | 500 | 0.04em / uppercase | Period sub-context (YTD / Lifetime inside hero KPI) |
| numeric-hero | 22px | 700 | -0.02em | KPI primary value |
| numeric-table | 12px | 400 | -0.01em | Table cells (mono, tabular) |

### 3.3 Spacing — "snug" density

```
--row-pad   8px    /* table row vertical padding */
--card-pad  16px   /* panel internal padding */
--gap       12px   /* default gap between panels */
--kpi-gap   10px   /* KPI grid gap */
```

Tightens current 12–14px row padding to 8px; trims card padding from 18px to 16px.

### 3.4 Radii, shadows, blur

```
--r-sm   6px    /* segmented buttons, swatches */
--r-md   8px    /* small inputs, calendar ribbon */
--r-lg   12px   /* panels, KPI cards */
--r-xl   16px   /* page-frame, modal */

/* No box-shadow on cards by default; depth comes from background lift + hairline border. */
/* Small accent glows (chip dots, wash-watch dot) use box-shadow:  0 0 5–6px currentColor. */
/* SVG-level glows (donut, brand mark) use the filter: drop-shadow(...) form. */

/* Topbar vibrancy */
backdrop-filter: saturate(180%) blur(20px)
background: rgba(0,0,0,0.6)

/* Lead KPI halo (Realized hero card only) */
background:
  radial-gradient(120% 90% at 0% 0%,    rgba(94,92,230,.16) 0%, transparent 55%),
  radial-gradient(140% 100% at 100% 100%, rgba(191,90,242,.10) 0%, transparent 55%),
  var(--surface);
border-color: rgba(94,92,230,0.22);
```

## 4. Components

### 4.1 Topbar

Sticky, vibrancy-blurred. Left: brand mark (22×22 indigo→violet gradient square with α monogram, soft outer glow) + nav links. Right: account pill + period pill (read-only summaries; the real period/account toggles live in the page toolbar below).

### 4.2 Page header + toolbar

```
[ Portfolio                  ]  [ Period seg ] [ Account seg ]
[ All accounts · YTD …       ]
```

Page title at `display-1`. Sub-line at `body` muted. Toolbar segments are pill-rounded (`--r-md`) with a sliding active background of `--surface-3`.

### 4.3 KPI grid (12-column)

| Card | Cols | Type |
|---|---|---|
| Realized P/L (combined) | 4 | hero, has indigo→violet halo |
| Unrealized P/L (combined) | 4 | hero (no halo) |
| Open Position $ | 2 | mini |
| Wash impact | 2 | mini |

**Combined hero card layout:**

```
Realized P/L                        ← label-uc
┌──────────── 1fr ────────────┐ │ ┌──────────── 1fr ────────────┐
  YTD             ← micro      │   Lifetime       ← micro
  +$48,120.63     ← numeric-h  │   +$182,506.40   ← numeric-h
  +8.4% on cost   ← caption    │   since 2021     ← caption
└──────────────────────────────┘ │ └──────────────────────────────┘
```

The 0.5px vertical hairline between YTD and Lifetime is `--hairline`. Both numbers receive equal type weight; YTD on the left because it's the user's primary working period.

### 4.4 Allocation panel

Replaces the current treemap. Components:

1. **Donut**: SVG (no JS lib needed for a donut), 11px stroke, 10 ranked segments + a "rest" segment, on a 5%-white-alpha track. Drop-shadow `0 0 18px rgba(10,132,255,0.14)` for a faint cyber glow.
2. **Center**: `Total` label, `$481.9k` value, `38 symbols` sub. (Numeric-hero size scaled down to 19–20px because of donut diameter.)
3. **Concentration stats** to the right of the donut: `Top holding · NVDA · 23.3%` / `Top 3 share` / `Top 5 share` / `Top 10 share`. 4 rows, hairline-separated.
4. **Chip list** below: top 10 holdings as wrapping pill chips. Each chip = colored dot + ticker + $ amount (muted) + percent (bold). Top-6 dots have a `0 0 5px currentColor` glow; ranks 7–10 don't. The `+N more` tail is a borderless ghost chip at the end of the wrap.

**Color binding rule:** rank slot determines color. As positions reshuffle, the color follows the slot, not the ticker. (NVDA is blue while it's #1; if META overtakes it, META becomes blue.) This is documented in the panel meta tooltip.

### 4.5 Wash-sale watch panel (replaces home calendar ribbon)

**Title:** `Wash-sale watch`
**Subtitle:** `Loss closes in the last 30 days · don't buy back · {N} symbols`

One row per loss-closed symbol (sells with negative realized P/L) within `today − 30d`. Each row:

```
[●] TSLA   −$612.40   closed 8d ago   ███░░░░░░░░░    22d to safe
              loss      meta-line       progress       countdown
```

- Dot left of ticker is `--neg` with a `0 0 6px` glow.
- Loss amount is mono, in `--neg`.
- Progress fill is a green-amber-red gradient (`pos` 100% → `warn` 70% → `neg` 0%); width = `(days_since_close / 30) * 100%`.
- Countdown numeral colored by urgency:
  - `--neg` if `days_to_safe ≥ 21` (just closed — danger zone)
  - `--warn` if `7 ≤ days_to_safe < 21`
  - `--pos` if `days_to_safe < 7` (almost clear)
- Sort: most-recently-closed first (= largest `days_to_safe` first = top).
- Empty state: panel still renders, body says `All clear · no loss closes in the last 30 days.`

The full annual ribbon is still available at `/calendar`. The home page's job is "what should I avoid right now?", which this panel answers directly.

**Backend addition:** new pure helper in `portfolio/wash_watch.py`:

```python
def recent_loss_closes(
    today: date,
    window_days: int = 30,
    account: str | None = None,
) -> list[LossCloseRow]:
    """Sells with realized P/L < 0 whose close_date is in the closed interval
    [today - window_days, today], grouped by symbol (one row per symbol; if a
    symbol has multiple loss closes in window, take the most recent date and
    sum the losses across those closes).

    `today` is the server-side `date.today()` at request time — no caching of
    "today" across HTMX swaps. `days_to_safe = window_days - days_since`,
    clamped to ≥ 0.

    Returns rows sorted by close_date desc."""
```

`LossCloseRow` Pydantic model: `{symbol, account, close_date, days_since, days_to_safe, loss_amount}`.

**Route:** `routes/portfolio.py` gets a new fragment endpoint `GET /portfolio/wash-watch?account=...` returning `_portfolio_wash_watch.html` (HTMX-loaded, like the other lazy fragments).

### 4.6 Positions table (full 9-column, restyled)

Columns unchanged from current spec:

| Column | Tooltip / source |
|---|---|
| Symbol | underlying, with 20×20 ticker icon (gradient block, ticker letter) |
| Accounts | distinct accounts; `+N more` if >3 |
| Qty | sum of remaining quantity |
| Mkt $ | qty × latest price |
| Open Cost | sum adjusted basis on open lots |
| Avg Basis | open cost ÷ qty |
| Cash Sunk/sh | per-share cash exposure |
| {Period} Realized | period-scoped realized P/L |
| Unrealized | mkt − open cost |

Restyling:
- 0.5px hairline between rows; no zebra.
- Hover: `rgba(255,255,255,.02)` row tint.
- Header row: `label-uc` style, 11px.
- Body: 12px, mono on every numeric column.
- 8px row padding (snug).
- No `Status` column. Wash-sale confidence does not live on the positions table — that information has its own surfaces (the home-page wash-sale watch panel and the `/calendar` page). The earlier mockup that showed a status column was over-reach; the user's "keep current columns" instruction is the canonical answer.

### 4.7 Equity curve panel (ApexCharts area)

The hand-rolled SVG comes out. ApexCharts area chart, themed for dark:

- `theme: { mode: 'dark' }`
- `chart.background: 'transparent'`
- Series 1: realized cumulative — `--pos` line, area gradient `--pos` 30% → 0%
- Series 2 (last point only, marker): `+ unrealized today` — `--violet` marker with a dashed connector to the realized line at `today`
- X-axis: time, snake-case month labels, `--label-3`
- Y-axis: USD, formatter `"+$" + k-rounded`, `--label-3`
- Grid: 0.5px `--hairline`, dashed
- Tooltip: dark theme, mono numerics, "Realized: $X · Unrealized: $Y · Total: $Z" composite for the present-day point
- Animations: 800ms easing, only on initial load (no jitter on filter changes)

### 4.8 Calendar / Imports / Sim / Detail pages

Same routes, same data, restyled to use the new tokens. No structural changes specified here — they inherit from the design system. The `/calendar` page keeps the dual-ribbon layout from `2026-04-26-ui-ux-redesign-design.md` but recolored:

- Monthly P/L bars: `--pos` for net-gain months, `--neg` for net-loss months, `--surface-2` (3px, neutral) for zero months.
- Wash-sale dots: `--neg` (confirmed), `--warn` (probable), `--info` (unclear) with `0 0 12px currentColor` glow.

## 5. ApexCharts integration

### 5.1 Vendoring

- Install via `npm` once into a build directory, copy `dist/apexcharts.min.js` and `apexcharts.min.css` into `src/net_alpha/web/static/vendor/apexcharts/`. **Do not** add npm to runtime — this is a build-time fetch only, mirroring how htmx and Alpine were vendored.
- `Makefile` gets a `vendor-apex` target. CI runs it once and commits the vendored files.
- `base.html` adds the script + link tags to load from `/static/vendor/apexcharts/`.
- Disclaimer footer remains unchanged. ApexCharts is not a network call at runtime.

### 5.2 Theming

Single shared theme object `src/net_alpha/web/static/charts.js`:

```js
window.netAlphaChartTheme = {
  colors: { pos: '#30D158', neg: '#FF453A', indigo: '#5E5CE6', violet: '#BF5AF2',
            label2: 'rgba(235,235,245,0.6)', label3: 'rgba(235,235,245,0.35)',
            hairline: 'rgba(255,255,255,0.08)' },
  defaults: { /* common ApexCharts options for dark area/donut/bar */ }
};
```

Each chart imports `defaults` and overrides only what differs (data, axes labels). Keeps charts visually consistent with no per-chart re-theming.

### 5.3 What stays SVG

The donut, the calendar dot ribbon, the wash-watch progress bars, and the brand-mark monogram remain pure SVG/CSS. They're simple enough that ApexCharts would be overkill, and they need exact pixel control we'd lose with a generic library.

## 6. Migration & phasing

This is a one-shot visual cutover, not a phased rollout. There's no "two themes side by side" period. We ship the new theme, the old theme dies.

**Phase A — Tokens + topbar/nav + KPI cards.** ~half day.
- New `tailwind.config.js` palette + `app.src.css` updated with new tokens, fonts, base layer.
- `vendor-apex` target run, font files committed.
- `base.html` updated for new fonts, vendored ApexCharts script include.
- Topbar restyled.
- KPI partial `_portfolio_kpis.html` rewritten to render the 12-col grid with combined hero cards.
- Build CSS, smoke-test the home page.

**Phase B — Allocation + Wash-watch + Equity curve.** ~half day.
- New partial `_portfolio_allocation.html` (donut + chips), retire `_portfolio_treemap.html`.
- New partial `_portfolio_wash_watch.html`, retire the calendar-ribbon include from `portfolio.html`.
- New helper `portfolio/wash_watch.py` + tests.
- Equity curve partial rewritten to use ApexCharts.
- Update `routes/portfolio.py`: replace `/portfolio/treemap` with `/portfolio/allocation`; add `/portfolio/wash-watch`; existing `/portfolio/equity-curve` returns the ApexCharts container instead of the inline SVG.

**Phase C — Tables + Calendar + remaining pages.** ~half day.
- Positions table restyle (drop status-as-column, add chip-in-symbol-cell, snug padding).
- Status chips restyle.
- `/calendar` dual ribbon recolored.
- `/imports`, `/sim`, `/detail` restyled to inherit.
- Visual regression: open every page, verify nothing broke.

## 7. Testing

Existing route + render tests should keep passing. New surface area:

- `portfolio/wash_watch.py` — full unit coverage. Cases: empty, single loss close, multiple loss closes for same symbol (collapse to most recent), account filter, day-30 boundary (inclusive of `today − 30d`, exclusive of `today − 31d`), gain closes excluded.
- Golden-file test for `_portfolio_wash_watch.html` against a fixture row set including the urgent / mid / almost-safe color tiers.
- Golden-file test for `_portfolio_allocation.html` (donut + chips) — verify chip ordering and color slots.
- Smoke test: `apexcharts.min.js` is present at `/static/vendor/apexcharts/` (file existence, no network).
- The `web/static/charts.js` theme module is loaded on every page that uses ApexCharts.

Visual regression isn't automated — manual sweep of all five pages on the developer's machine before merge, screenshots posted in the PR description.

## 8. Privacy & disclaimers

No change. The "informational only" disclaimer line in the footer stays. The Yahoo Finance disclosure (when prices are remote-fetched) stays. ApexCharts loads from `/static/`, no network call.

## 9. Open questions

1. **Brand-mark monogram glyph.** Currently `α` (alpha). Considered alternatives (`λ`, `∆`, `n/α`). Default stays `α` unless the user wants otherwise.
2. **Animation on KPI value updates.** ApexCharts animations cover the equity curve. Should KPI numerals also count up on first paint (250ms ease)? Default no — value churn on filter swaps would feel busy. Add later if requested.
3. **Wash-watch ETF substitution.** Today's spec triggers wash-watch only on the same ticker. The wash-sale engine itself does substitute-ETF matching (SPY/VOO/IVV/SPLG, etc.). Should the home-page wash-watch panel surface the substitute group too? Default no — keeps the home-page module focused. Substitute matches still appear in the full `/calendar`.
4. **Rank-3 categorical color overlap with P/L green.** Documented in §3.1.1. If feedback says it confuses, swap to `#5BD379` and update §3.1.

## 10. Acceptance

The redesign is done when:
- All five web pages render in the new theme without layout breakage.
- Hand-rolled equity curve is replaced by ApexCharts; donut + chips replaces treemap.
- Home-page wash-watch panel shows recent loss closes with countdown.
- Existing tests pass, new tests pass, ruff check passes.
- A side-by-side screenshot pair (old vs new) for the home page reads as a clear quality jump.
- The user reviews a working build, accepts.
