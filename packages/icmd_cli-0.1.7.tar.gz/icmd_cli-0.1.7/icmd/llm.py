import os
import subprocess
from huggingface_hub import hf_hub_download

MODEL_REPO = "MSDeepak718/qwen-icmd"
MODEL_FILE = "qwen-icmd-q4.gguf"

CACHE_DIR = os.path.expanduser("~/.icmd_model")
MODEL_PATH = os.path.join(CACHE_DIR, MODEL_FILE)

# Path to bundled llama binary
LLAMA_BIN = os.path.join(os.path.dirname(__file__), "bin/llama-cli")


def ensure_model():
    os.makedirs(CACHE_DIR, exist_ok=True)

    if not os.path.exists(MODEL_PATH):
        print("⬇️ Downloading iCMD model (~400MB)...")

        hf_hub_download(
            repo_id=MODEL_REPO,
            filename=MODEL_FILE,
            local_dir=CACHE_DIR
        )


def llm(user_input, OS):
    ensure_model()

    prompt = f"""You are an expert terminal command generator.

Convert the user query into a SAFE and VALID {OS} command.

Rules:
- Output ONLY the command
- No explanation
- No dangerous commands

Query: {user_input}
"""

    result = subprocess.run(
        [
            LLAMA_BIN,
            "-m", MODEL_PATH,
            "-p", prompt,
            "-n", "100",
            "--temp", "0.2"
        ],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return "Error running model"

    # Clean output (important)
    output = result.stdout.strip()
    return output.split("\n")[-1]