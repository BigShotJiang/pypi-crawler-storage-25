"""Decorator-based tracing for Ciphyrs."""

from __future__ import annotations

import functools
from typing import Any, Callable, Optional, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def trace(
    name: Optional[str] = None,
    metadata: Optional[dict] = None,
    project: Optional[str] = None,
    client: Optional[Any] = None,
) -> Callable[[F], F]:
    """Decorator that wraps a function in a Ciphyrs trace.

    Usage:
        @ciphyrs.trace(name="research_pipeline")
        def run_pipeline(query):
            return researcher.run(query)

    Or with an explicit client:
        @trace(name="pipeline", client=my_client)
        def run(query):
            ...

    The function's first argument is captured as trigger_input,
    and the return value as final_output.
    """

    def decorator(fn: F) -> F:
        trace_name = name or fn.__name__

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            from ciphyrs import get_client

            c = client or get_client()
            with c.trace(name=trace_name, metadata=metadata, project=project) as ctx:
                # Capture trigger input
                if args:
                    ctx.trigger_input = str(args[0])
                elif kwargs:
                    first_val = next(iter(kwargs.values()))
                    ctx.trigger_input = str(first_val)

                result = fn(*args, **kwargs)
                ctx.final_output = str(result) if result is not None else None
                return result

        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            from ciphyrs import get_client

            c = client or get_client()
            with c.trace(name=trace_name, metadata=metadata, project=project) as ctx:
                if args:
                    ctx.trigger_input = str(args[0])
                elif kwargs:
                    first_val = next(iter(kwargs.values()))
                    ctx.trigger_input = str(first_val)

                result = await fn(*args, **kwargs)
                ctx.final_output = str(result) if result is not None else None
                return result

        import asyncio

        if asyncio.iscoroutinefunction(fn):
            return async_wrapper  # type: ignore
        return sync_wrapper  # type: ignore

    return decorator


def span(
    agent_name: Optional[str] = None,
    kind: str = "agent",
    operation_name: Optional[str] = None,
    model_name: Optional[str] = None,
    client: Optional[Any] = None,
) -> Callable[[F], F]:
    """Decorator that wraps a function in a Ciphyrs span.

    Must be used within an active trace context.

    Usage:
        @ciphyrs.span(agent_name="Researcher", kind="llm_call")
        def research(query):
            return llm.complete(query)

    The function arguments are captured as input, return value as output.
    Errors are automatically recorded.
    """

    def decorator(fn: F) -> F:
        resolved_agent = agent_name or fn.__name__

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            from ciphyrs import get_client

            c = client or get_client()
            with c.span(
                agent_name=resolved_agent,
                kind=kind,
                operation_name=operation_name or fn.__name__,
                model_name=model_name,
            ) as s:
                # Capture input
                if args:
                    s.set_input(args[0])
                elif kwargs:
                    s.set_input(next(iter(kwargs.values())))

                result = fn(*args, **kwargs)
                s.set_output(result)
                return result

        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            from ciphyrs import get_client

            c = client or get_client()
            with c.span(
                agent_name=resolved_agent,
                kind=kind,
                operation_name=operation_name or fn.__name__,
                model_name=model_name,
            ) as s:
                if args:
                    s.set_input(args[0])
                elif kwargs:
                    s.set_input(next(iter(kwargs.values())))

                result = await fn(*args, **kwargs)
                s.set_output(result)
                return result

        import asyncio

        if asyncio.iscoroutinefunction(fn):
            return async_wrapper  # type: ignore
        return sync_wrapper  # type: ignore

    return decorator
