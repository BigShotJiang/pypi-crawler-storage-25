"""Governance utilities — approval gateway and policy checks."""
import time
from contextlib import contextmanager
from typing import Optional, Dict, Any


class GovernanceClient:
    """Interact with the Ciphyrs governance layer.

    Provides human-in-the-loop approval workflows and policy evaluation
    for controlling agent actions at runtime.
    """

    def __init__(self, client):
        self.client = client
        self.base_url = client.base_url
        self.session = client._session

    def request_approval(self, action: str, context: Optional[Dict] = None,
                          risk_level: str = "medium", timeout: int = 900) -> dict:
        """Request human approval for an action. Blocks until approved/rejected/expired.

        Args:
            action: Description of the action requiring approval
            context: Additional context (agent_id, trace_id, details)
            risk_level: 'critical', 'high', 'medium', 'low'
            timeout: Max seconds to wait for approval (default 15 min)

        Returns:
            dict with: id, status ('approved'|'auto_approved'), resolved_by, resolution_note

        Raises:
            PermissionError: If request is rejected
            TimeoutError: If approval expires or is not received in time
        """
        resp = self.session.post(f"{self.base_url}/v1/governance/approve", json={
            "action": action,
            "context": context or {},
            "risk_level": risk_level,
        })
        resp.raise_for_status()
        request_id = resp.json()["id"]

        # Poll until resolved
        deadline = time.time() + timeout
        interval = 1.0
        while time.time() < deadline:
            poll = self.session.get(
                f"{self.base_url}/v1/governance/approve/{request_id}/poll"
            )
            poll.raise_for_status()
            data = poll.json()

            if data["status"] in ("approved", "auto_approved"):
                return data
            elif data["status"] == "rejected":
                raise PermissionError(
                    f"Approval rejected: {data.get('resolution_note', 'No reason given')}"
                )
            elif data["status"] == "expired":
                raise TimeoutError("Approval request expired")

            time.sleep(min(interval, max(0.1, deadline - time.time())))
            interval = min(interval * 1.5, 5)

        raise TimeoutError(f"Approval not received within {timeout}s")

    @contextmanager
    def require_approval(self, action: str, context: Optional[Dict] = None,
                          risk_level: str = "medium", timeout: int = 900):
        """Context manager that blocks until approval is granted.

        Usage:
            with ciphyrs.governance.require_approval("delete-customer-data"):
                database.delete(customer_id)

        Args:
            action: Description of the action requiring approval
            context: Additional context (agent_id, trace_id, details)
            risk_level: 'critical', 'high', 'medium', 'low'
            timeout: Max seconds to wait for approval (default 15 min)

        Raises:
            PermissionError: If request is rejected
            TimeoutError: If approval expires or is not received in time
        """
        self.request_approval(action, context, risk_level, timeout)
        yield

    def check_policy(self, action: str, agent_id: Optional[str] = None,
                      context: Optional[Dict] = None) -> dict:
        """Check if an action is allowed by governance policies.

        Args:
            action: The action identifier to evaluate (e.g., 'send-email', 'delete-data')
            agent_id: Optional agent ID for agent-specific policies
            context: Additional context for policy evaluation

        Returns:
            dict with: allowed (bool), matching_policies[], required_action
        """
        resp = self.session.post(f"{self.base_url}/v1/governance/evaluate", json={
            "action": action,
            "agent_id": agent_id,
            "context": context or {},
        })
        resp.raise_for_status()
        return resp.json()

    def list_policies(self) -> list:
        """List all governance policies.

        Returns:
            List of policy dicts with id, name, rules, etc.
        """
        resp = self.session.get(f"{self.base_url}/v1/governance/policies")
        resp.raise_for_status()
        return resp.json()
