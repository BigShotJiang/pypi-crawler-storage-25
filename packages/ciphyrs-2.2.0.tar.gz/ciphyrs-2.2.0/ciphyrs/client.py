"""Core Ciphyrs client for trace ingestion."""

from __future__ import annotations

import atexit
import contextvars
import logging
import os
import random
import socket
import sys
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ciphyrs.errors import BudgetExceededError, RateLimitError, AuthError, IngestError

logger = logging.getLogger("ciphyrs")


def _infer_agent_name() -> Optional[str]:
    """Zero-config agent name inference. Explicit option wins; this is the
    fallback chain for users who just do `CiphyrsClient(api_key=...)`.

    Order: CIPHYRS_AGENT_NAME env → Python module name (`sys.argv[0]`
    basename without .py) → hostname. First non-empty wins.
    """
    v = os.environ.get("CIPHYRS_AGENT_NAME", "").strip()
    if v:
        return v
    # sys.argv[0] is the script path the user ran
    try:
        if sys.argv and sys.argv[0]:
            base = os.path.basename(sys.argv[0])
            if base.endswith(".py"):
                base = base[:-3]
            base = base.strip()
            if base and base not in ("-c", "-m"):
                return base
    except Exception:
        pass
    try:
        h = socket.gethostname().strip()
        if h:
            return h
    except Exception:
        pass
    return None


def _infer_environment() -> Optional[str]:
    v = os.environ.get("CIPHYRS_ENVIRONMENT", "").strip()
    if v:
        return v
    v = os.environ.get("PYTHON_ENV", "").strip()
    if v == "production":
        return "prod"
    return v or None


class _SpanContext:
    """Captures data for a single span within a trace."""

    def __init__(
        self,
        trace_id: str,
        agent_name: str,
        kind: str = "agent",
        operation_name: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        model_name: Optional[str] = None,
    ):
        self.span_id = str(uuid.uuid4())
        self.trace_id = trace_id
        self.parent_span_id = parent_span_id
        self.agent_name = agent_name
        self.kind = kind
        self.operation_name = operation_name
        self.model_name = model_name
        self.status = "ok"
        self.input: Optional[str] = None
        self.output: Optional[str] = None
        self.error_message: Optional[str] = None
        self.started_at: Optional[str] = None
        self.ended_at: Optional[str] = None
        self.duration_ms: Optional[int] = None
        self.token_count: Optional[int] = None
        self.prompt_tokens: Optional[int] = None
        self.completion_tokens: Optional[int] = None
        self.cost_usd: Optional[float] = None
        self.attributes: Dict[str, Any] = {}
        self.session_id: Optional[str] = None

    def set_input(self, value: Any) -> "_SpanContext":
        self.input = str(value) if value is not None else None
        return self

    def set_output(self, value: Any) -> "_SpanContext":
        self.output = str(value) if value is not None else None
        return self

    def set_error(self, error: BaseException) -> "_SpanContext":
        self.status = "error"
        self.error_message = f"{type(error).__name__}: {error}"
        return self

    def set_tokens(
        self,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        total: Optional[int] = None,
    ) -> "_SpanContext":
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.token_count = total or ((prompt_tokens or 0) + (completion_tokens or 0)) or None
        return self

    def set_model(self, model_name: str) -> "_SpanContext":
        self.model_name = model_name
        return self

    def set_cost(self, cost_usd: float) -> "_SpanContext":
        self.cost_usd = cost_usd
        return self

    def set_attribute(self, key: str, value: Any) -> "_SpanContext":
        self.attributes[key] = value
        return self

    def to_dict(self) -> Dict[str, Any]:
        return {
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "agent_name": self.agent_name,
            "kind": self.kind,
            "operation_name": self.operation_name,
            "status": self.status,
            "input": self.input,
            "output": self.output,
            "error_message": self.error_message,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "duration_ms": self.duration_ms,
            "token_count": self.token_count,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "cost_usd": self.cost_usd,
            "model_name": self.model_name,
            "session_id": self.session_id,
            "attributes": self.attributes,
        }


class _TraceContext:
    """Accumulates spans for a single trace."""

    def __init__(self, name: Optional[str] = None, metadata: Optional[Dict] = None):
        self.trace_id = str(uuid.uuid4())
        self.name = name
        self.status = "running"
        self.metadata = metadata or {}
        self.trigger_input: Optional[str] = None
        self.final_output: Optional[str] = None
        self.duration_ms: Optional[int] = None
        self.spans: List[_SpanContext] = []
        self._start_time: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "name": self.name,
            "status": self.status,
            "trigger_input": self.trigger_input,
            "final_output": self.final_output,
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
        }


# Context variables for trace/span propagation (works with both threading and asyncio)
_current_trace: contextvars.ContextVar[Optional[_TraceContext]] = contextvars.ContextVar(
    "_current_trace", default=None
)
_current_span: contextvars.ContextVar[Optional[_SpanContext]] = contextvars.ContextVar(
    "_current_span", default=None
)

# Maximum number of payloads that can be buffered before oldest are dropped
MAX_BUFFER_SIZE = 10000


def _get_active_trace() -> Optional[_TraceContext]:
    return _current_trace.get()


def _get_active_span() -> Optional[_SpanContext]:
    return _current_span.get()


class CiphyrsClient:
    """Main Ciphyrs SDK client for trace ingestion.

    Example:
        client = CiphyrsClient(api_key="ck_...", project="my-project")

        with client.trace("my-pipeline") as t:
            with client.span("Researcher", kind="llm_call") as s:
                s.set_input("What is AI?")
                result = llm.complete("What is AI?")
                s.set_output(result)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.ciphyrs.com",
        project: Optional[str] = None,
        project_description: Optional[str] = None,
        framework: Optional[str] = None,
        max_buffer_size: int = 10,
        flush_interval: float = 30.0,
        agent_name: Optional[str] = None,
        environment: Optional[str] = None,
        auto_health: bool = True,
        health_interval_seconds: float = 60.0,
        health_probe: Optional[Callable[[], Dict[str, Any]]] = None,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.project = project or "default"
        self.project_description = project_description
        self.framework = framework
        self.max_buffer_size = max_buffer_size
        self.flush_interval = flush_interval
        # Zero-config agent + env. Explicit arg wins, then env vars, then
        # inference from script name / hostname.
        self.agent_name = agent_name or _infer_agent_name()
        self.environment = environment or _infer_environment()

        # HTTP session with retry logic
        # Note: 429 is NOT in status_forcelist — budget-exceeded 429s must not
        # be silently retried. Regular rate-limit 429s are handled explicitly.
        self._session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            backoff_jitter=0.3,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["POST"],
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        self._session.headers.update({
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "ciphyrs-python/0.1.0",
        })

        # Buffer for batch sending
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_lock = threading.Lock()

        # Background flush timer
        self._flush_timer: Optional[threading.Timer] = None
        self._start_flush_timer()

        # Health monitor state — daemon thread so it never blocks exit.
        self._health_thread: Optional[threading.Thread] = None
        self._health_stop = threading.Event()
        self._health_interval = float(health_interval_seconds)
        self._health_probe = health_probe

        # Flush on exit
        atexit.register(self.flush)
        atexit.register(self.stop_health_monitor)

        # Auto-start heartbeat so `CiphyrsClient(api_key=...)` alone is
        # enough for the dashboard to show live status. Opt out with
        # `auto_health=False`.
        if auto_health and self.agent_name:
            try:
                self.start_health_monitor(
                    agent_name=self.agent_name,
                    interval_seconds=self._health_interval,
                    probe=self._health_probe,
                    environment=self.environment,
                )
            except Exception as e:  # never break the host app
                logger.warning("[ciphyrs] auto-health disabled: %s", e)
        elif auto_health and not self.agent_name:
            logger.warning(
                "[ciphyrs] auto-health skipped: no agent_name could be inferred. "
                "Set CIPHYRS_AGENT_NAME env var or pass agent_name=... to the client."
            )

    def _start_flush_timer(self) -> None:
        if self.flush_interval > 0:
            self._flush_timer = threading.Timer(self.flush_interval, self._auto_flush)
            self._flush_timer.daemon = True
            self._flush_timer.start()

    def _auto_flush(self) -> None:
        try:
            self.flush()
        except Exception:
            logger.exception("Auto-flush failed")
        finally:
            self._start_flush_timer()

    @contextmanager
    def trace(
        self,
        name: Optional[str] = None,
        metadata: Optional[Dict] = None,
        project: Optional[str] = None,
        budget_limit: Optional[float] = None,
    ):
        """Context manager that creates a trace and sends it on exit.

        Args:
            name: Trace name (e.g., "research_pipeline").
            metadata: Arbitrary metadata dict.
            project: Override default project name.
            budget_limit: Optional client-side budget limit in USD. If the
                cumulative cost of spans within this trace exceeds this value,
                a BudgetExceededError is raised when the trace completes.

        Yields:
            _TraceContext that can be used to set trigger_input/final_output.
        """
        ctx = _TraceContext(name=name, metadata=metadata)
        ctx._start_time = time.monotonic()
        ctx._budget_limit = budget_limit

        token = _current_trace.set(ctx)

        try:
            yield ctx
            ctx.status = "completed"
        except Exception as exc:
            ctx.status = "failed"
            ctx.metadata["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            elapsed = time.monotonic() - ctx._start_time
            ctx.duration_ms = int(elapsed * 1000)
            _current_trace.reset(token)

            # Client-side budget check before sending
            if budget_limit is not None and ctx.spans:
                total_cost = sum(s.cost_usd or 0.0 for s in ctx.spans)
                if total_cost > budget_limit:
                    raise BudgetExceededError(
                        budget_limit=budget_limit,
                        current_spend=total_cost,
                    )

            # Send the trace
            payload = {
                "project": {
                    "name": project or self.project,
                    "description": self.project_description,
                    "framework": self.framework,
                },
                "trace": ctx.to_dict(),
                "spans": [s.to_dict() for s in ctx.spans],
            }

            if len(ctx.spans) > 0:
                self._enqueue(payload)

    @contextmanager
    def span(
        self,
        agent_name: str,
        kind: str = "agent",
        operation_name: Optional[str] = None,
        model_name: Optional[str] = None,
    ):
        """Context manager for a span within the active trace.

        Args:
            agent_name: Name of the agent (e.g., "Researcher").
            kind: Span type — "agent", "llm_call", "tool_call", "retrieval".
            operation_name: Optional operation identifier.
            model_name: LLM model name if applicable.

        Yields:
            _SpanContext for setting input/output/tokens/errors.
        """
        active_trace = _get_active_trace()
        if active_trace is None:
            raise RuntimeError("span() must be used inside a trace() context")

        parent = _get_active_span()
        span_ctx = _SpanContext(
            trace_id=active_trace.trace_id,
            agent_name=agent_name,
            kind=kind,
            operation_name=operation_name,
            parent_span_id=parent.span_id if parent else None,
            model_name=model_name,
        )
        span_ctx.started_at = datetime.now(timezone.utc).isoformat()

        token = _current_span.set(span_ctx)

        start = time.monotonic()
        try:
            yield span_ctx
        except Exception as exc:
            span_ctx.set_error(exc)
            raise
        finally:
            elapsed = time.monotonic() - start
            span_ctx.duration_ms = int(elapsed * 1000)
            span_ctx.ended_at = datetime.now(timezone.utc).isoformat()
            _current_span.reset(token)
            active_trace.spans.append(span_ctx)

    def _check_response(self, resp: requests.Response) -> None:
        """Check response for budget-exceeded 429 or other errors.

        Raises:
            BudgetExceededError: If 429 with budget_exceeded flag.
            RateLimitError: If 429 without budget_exceeded (rate limit).
            AuthError: If 401 or 403.
            IngestError: For other non-2xx responses.
        """
        if resp.ok:
            return

        if resp.status_code == 429:
            try:
                body = resp.json()
            except Exception:
                body = {}

            if body.get("budget_exceeded"):
                raise BudgetExceededError(
                    budget_limit=body.get("budget_limit", 0),
                    current_spend=body.get("current_spend", 0),
                    retry_after=body.get("retry_after"),
                    budget_id=body.get("budget_id"),
                    budget_type=body.get("budget_type"),
                )
            else:
                retry_after = resp.headers.get("Retry-After")
                raise RateLimitError(
                    retry_after=int(retry_after) if retry_after else None,
                )

        if resp.status_code in (401, 403):
            raise AuthError(resp.text)

        # For other errors, raise with details
        raise IngestError(resp.status_code, resp.text)

    def ingest(
        self,
        project: Dict[str, Any],
        trace: Dict[str, Any],
        spans: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Directly ingest a trace with spans via POST /v1/trace/ingest.

        Args:
            project: {"name": "...", "description": "...", "framework": "..."}
            trace: {"trace_id": "...", "name": "...", "status": "...", ...}
            spans: List of span dicts matching the API schema.

        Returns:
            API response dict.

        Raises:
            BudgetExceededError: If the agent/project budget is exceeded.
        """
        url = f"{self.base_url}/v1/trace/ingest"
        payload = {"project": project, "trace": trace, "spans": spans}
        resp = self._session.post(url, json=payload, timeout=30)
        self._check_response(resp)
        return resp.json()

    def ingest_batch(self, traces: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Ingest multiple traces via POST /v1/trace/ingest/batch.

        Args:
            traces: List of {project, trace, spans} dicts. Max 50.

        Returns:
            API response dict.

        Raises:
            BudgetExceededError: If any trace's agent/project budget is exceeded.
        """
        url = f"{self.base_url}/v1/trace/ingest/batch"
        resp = self._session.post(url, json={"traces": traces}, timeout=60)
        self._check_response(resp)
        return resp.json()

    @property
    def test(self):
        """Lazy-loaded TestRunner for security scans and performance benchmarks."""
        if not hasattr(self, '_test_runner'):
            from ciphyrs.testing import TestRunner
            self._test_runner = TestRunner(self)
        return self._test_runner

    @property
    def governance(self):
        """Lazy-loaded GovernanceClient for approval workflows and policy checks."""
        if not hasattr(self, '_governance'):
            from ciphyrs.governance import GovernanceClient
            self._governance = GovernanceClient(self)
        return self._governance

    def _enqueue(self, payload: Dict[str, Any]) -> None:
        """Add a trace payload to the buffer, flushing if full."""
        with self._buffer_lock:
            self._buffer.append(payload)

            # Drop oldest payloads if buffer exceeds absolute max
            if len(self._buffer) > MAX_BUFFER_SIZE:
                dropped = len(self._buffer) - MAX_BUFFER_SIZE
                self._buffer = self._buffer[dropped:]
                logger.warning(
                    "Buffer overflow: dropped %d oldest payload(s). "
                    "Consider increasing flush frequency.",
                    dropped,
                )

            if len(self._buffer) >= self.max_buffer_size:
                self._flush_buffer()

    def _flush_buffer(self) -> None:
        """Send all buffered traces. Must be called with _buffer_lock held."""
        if not self._buffer:
            return

        to_send = self._buffer[:]
        self._buffer.clear()

        try:
            if len(to_send) == 1:
                payload = to_send[0]
                url = f"{self.base_url}/v1/trace/ingest"
                resp = self._session.post(url, json=payload, timeout=30)
                self._check_response(resp)
                logger.debug("Ingested trace %s", payload["trace"]["trace_id"])
            else:
                url = f"{self.base_url}/v1/trace/ingest/batch"
                resp = self._session.post(url, json={"traces": to_send}, timeout=60)
                self._check_response(resp)
                logger.debug("Batch ingested %d traces", len(to_send))
        except BudgetExceededError:
            # Don't re-buffer budget-exceeded traces — they will keep failing
            logger.warning("Budget exceeded — dropped %d trace(s)", len(to_send))
            raise
        except Exception:
            logger.exception("Failed to send %d trace(s)", len(to_send))
            # Re-buffer on failure (up to 2x max to avoid infinite growth)
            if len(self._buffer) + len(to_send) <= self.max_buffer_size * 2:
                self._buffer.extend(to_send)

    def flush(self) -> None:
        """Send all buffered traces immediately."""
        with self._buffer_lock:
            self._flush_buffer()

    def shutdown(self) -> None:
        """Flush and clean up resources."""
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None
        self.stop_health_monitor()
        self.flush()
        self._session.close()

    # ── Health heartbeat (V39) ────────────────────────────────────────────
    def report_heartbeat(
        self,
        *,
        agent_name: Optional[str] = None,
        agent_id: Optional[str] = None,
        status: str = "up",
        latency_ms: Optional[int] = None,
        error_message: Optional[str] = None,
        environment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Report a single health check to Ciphyrs.

        Fire-and-forget — network failures are swallowed with a warning so a
        flaky link can't crash the host app. Accepts either `agent_id` or
        `agent_name` (defaults to the client's configured name).
        """
        name = agent_name or self.agent_name
        if not name and not agent_id:
            raise ValueError("report_heartbeat requires agent_name or agent_id")
        body = {
            "agent_id": agent_id,
            "agent_name": name,
            "status": status,
            "latency_ms": latency_ms,
            "error_message": error_message,
            "environment": environment or self.environment,
            "metadata": metadata or {},
            "source": "sdk",
        }
        # Drop None values so the server defaults kick in
        body = {k: v for k, v in body.items() if v is not None}
        try:
            r = self._session.post(
                f"{self.base_url}/v1/trace/agents/heartbeat",
                json=body, timeout=10,
            )
            if not r.ok:
                logger.warning(
                    "[ciphyrs] heartbeat failed (%s): %s",
                    r.status_code, (r.text or "")[:200],
                )
                return {"ok": False, "status": r.status_code}
            return {"ok": True, **(r.json() if r.content else {})}
        except Exception as e:
            logger.warning("[ciphyrs] heartbeat network error: %s", e)
            return {"ok": False, "error": str(e)}

    def start_health_monitor(
        self,
        *,
        agent_name: Optional[str] = None,
        agent_id: Optional[str] = None,
        interval_seconds: float = 60.0,
        probe: Optional[Callable[[], Dict[str, Any]]] = None,
        environment: Optional[str] = None,
    ) -> None:
        """Start a recurring heartbeat every ``interval_seconds`` (default 60).

        Runs ``probe()`` each tick if provided — exceptions mark the beat
        'down' with the error message; return ``{"status": "...", ...}``
        to override. Runs on a daemon thread so it never blocks exit.
        Safe to call multiple times — previous monitor is stopped first.
        """
        name = agent_name or self.agent_name
        if not name and not agent_id:
            raise ValueError("start_health_monitor requires agent_name or agent_id")

        self.stop_health_monitor()
        self._health_stop = threading.Event()

        def _tick_once() -> None:
            status = "up"
            latency_ms: Optional[int] = None
            error_message: Optional[str] = None
            if probe is not None:
                t0 = time.time()
                try:
                    r = probe()
                    latency_ms = int((time.time() - t0) * 1000)
                    if isinstance(r, dict):
                        status = str(r.get("status", status))
                        latency_ms = int(r.get("latency_ms", latency_ms))
                        error_message = r.get("error_message")
                except Exception as e:
                    status = "down"
                    latency_ms = int((time.time() - t0) * 1000)
                    error_message = str(e)
            self.report_heartbeat(
                agent_name=name, agent_id=agent_id,
                status=status, latency_ms=latency_ms,
                error_message=error_message, environment=environment,
            )

        def _run() -> None:
            # Fire once immediately so the dashboard reflects liveness on boot.
            try:
                _tick_once()
            except Exception:
                logger.exception("health tick failed")
            while not self._health_stop.wait(interval_seconds):
                try:
                    _tick_once()
                except Exception:
                    logger.exception("health tick failed")

        self._health_thread = threading.Thread(
            target=_run, name="ciphyrs-health", daemon=True,
        )
        self._health_thread.start()

    def stop_health_monitor(self) -> None:
        """Stop the recurring heartbeat, if running."""
        if self._health_stop is not None:
            self._health_stop.set()
        self._health_thread = None
