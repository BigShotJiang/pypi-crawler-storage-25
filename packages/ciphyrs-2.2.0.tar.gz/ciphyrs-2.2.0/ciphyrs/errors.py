"""Ciphyrs SDK error types."""

from __future__ import annotations

from typing import Optional


class CiphyrsError(Exception):
    """Base exception for all Ciphyrs SDK errors."""

    pass


class BudgetExceededError(CiphyrsError):
    """Raised when an agent or project has exceeded its configured budget.

    The server returns HTTP 429 with budget details when enforcement is enabled.
    Can also be raised client-side when a local budget_limit is set on a trace.

    Attributes:
        budget_limit: The maximum budget in USD.
        current_spend: The current cumulative spend in USD.
        retry_after: Seconds until the budget period resets (from server).
        budget_id: Server-side budget ID if available.
        budget_type: 'daily', 'weekly', or 'monthly'.
    """

    def __init__(
        self,
        budget_limit: float,
        current_spend: float,
        retry_after: Optional[int] = None,
        budget_id: Optional[str] = None,
        budget_type: Optional[str] = None,
    ):
        self.budget_limit = budget_limit
        self.current_spend = current_spend
        self.retry_after = retry_after
        self.budget_id = budget_id
        self.budget_type = budget_type
        super().__init__(
            f"Budget exceeded: ${current_spend:.4f}/${budget_limit:.4f} USD"
            + (f" (resets in {retry_after}s)" if retry_after else "")
        )


class RateLimitError(CiphyrsError):
    """Raised when the API returns HTTP 429 for rate limiting (non-budget)."""

    def __init__(self, retry_after: Optional[int] = None):
        self.retry_after = retry_after
        msg = "Rate limited"
        if retry_after:
            msg += f" (retry after {retry_after}s)"
        super().__init__(msg)


class AuthError(CiphyrsError):
    """Raised when the API returns HTTP 401 or 403."""

    pass


class IngestError(CiphyrsError):
    """Raised when trace ingestion fails with a non-retryable error."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"Ingest failed (HTTP {status_code}): {message}")
