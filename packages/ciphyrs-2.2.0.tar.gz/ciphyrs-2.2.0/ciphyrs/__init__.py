"""Ciphyrs SDK — Agent tracing, observability, PII detection, testing, and governance."""
from __future__ import annotations

from typing import Optional

from ciphyrs.client import CiphyrsClient
from ciphyrs.decorators import trace, span
from ciphyrs.errors import (
    CiphyrsError,
    BudgetExceededError,
    RateLimitError,
    AuthError,
    IngestError,
)
from ciphyrs.testing import TestRunner
from ciphyrs.governance import GovernanceClient

__version__ = "2.2.0"
__all__ = [
    "CiphyrsClient",
    "trace",
    "span",
    "TestRunner",
    "GovernanceClient",
    "CiphyrsError",
    "BudgetExceededError",
    "RateLimitError",
    "AuthError",
    "IngestError",
]

# Module-level default client (set via init())
_default_client: Optional[CiphyrsClient] = None


def init(api_key: str, base_url: str = "https://api.ciphyrs.com", project: Optional[str] = None) -> CiphyrsClient:
    """Initialize the default Ciphyrs client.

    Args:
        api_key: Your Ciphyrs API key.
        base_url: API base URL (default: https://api.ciphyrs.com).
        project: Default project name for all traces.

    Returns:
        The configured CiphyrsClient instance.
    """
    global _default_client
    _default_client = CiphyrsClient(api_key=api_key, base_url=base_url, project=project)
    return _default_client


def get_client() -> "CiphyrsClient":
    """Get the default client. Raises if init() has not been called."""
    if _default_client is None:
        raise RuntimeError("Ciphyrs SDK not initialized. Call ciphyrs.init(api_key=...) first.")
    return _default_client
