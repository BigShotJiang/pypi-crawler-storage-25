"""OpenAI auto-tracing integration for Ciphyrs.

Monkey-patches the OpenAI client to automatically capture all
chat.completions.create calls as Ciphyrs spans.

Usage:
    import ciphyrs
    from ciphyrs.integrations.openai import patch_openai

    ciphyrs.init(api_key="ck_...")
    patch_openai()  # patches the global openai module

    # Now all OpenAI calls within a trace are auto-captured:
    with ciphyrs.get_client().trace("my-pipeline"):
        response = openai_client.chat.completions.create(
            model="gpt-4", messages=[{"role": "user", "content": "Hello"}]
        )
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Optional

logger = logging.getLogger("ciphyrs.openai")

_patched = False
_original_create = None
_original_acreate = None


def patch_openai(client: Optional[Any] = None) -> None:
    """Patch OpenAI's chat.completions.create to auto-trace calls.

    Args:
        client: Optional CiphyrsClient. Uses default if not provided.
    """
    global _patched, _original_create, _original_acreate
    if _patched:
        return

    try:
        import openai
        from openai.resources.chat.completions import Completions
    except ImportError:
        raise ImportError(
            "OpenAI SDK is required for this integration. "
            "Install it with: pip install ciphyrs[openai]"
        )

    original_create = Completions.create
    _original_create = original_create

    @functools.wraps(original_create)
    def traced_create(self_completions: Any, *args: Any, **kwargs: Any) -> Any:
        from ciphyrs.client import _get_active_trace

        active_trace = _get_active_trace()
        if active_trace is None:
            # No active trace, call original without tracing
            return original_create(self_completions, *args, **kwargs)

        # Resolve client
        ciphyrs_client = client
        if ciphyrs_client is None:
            from ciphyrs import get_client
            try:
                ciphyrs_client = get_client()
            except RuntimeError:
                return original_create(self_completions, *args, **kwargs)

        model = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        input_text = _format_messages(messages)

        with ciphyrs_client.span(
            agent_name=f"openai/{model}",
            kind="llm_call",
            operation_name="chat.completions.create",
            model_name=model,
        ) as span:
            span.set_input(input_text)

            try:
                response = original_create(self_completions, *args, **kwargs)
            except Exception as exc:
                span.set_error(exc)
                raise

            # Extract response data
            try:
                if hasattr(response, "choices") and response.choices:
                    content = response.choices[0].message.content or ""
                    span.set_output(content)

                if hasattr(response, "usage") and response.usage:
                    span.set_tokens(
                        prompt_tokens=response.usage.prompt_tokens,
                        completion_tokens=response.usage.completion_tokens,
                        total=response.usage.total_tokens,
                    )

                if hasattr(response, "model"):
                    span.set_model(response.model)
            except Exception:
                logger.debug("Failed to extract OpenAI response metadata", exc_info=True)

            return response

    Completions.create = traced_create  # type: ignore

    # Also patch async if available
    try:
        from openai.resources.chat.completions import AsyncCompletions

        original_acreate = AsyncCompletions.create
        _original_acreate = original_acreate

        @functools.wraps(original_acreate)
        async def traced_acreate(self_completions: Any, *args: Any, **kwargs: Any) -> Any:
            from ciphyrs.client import _get_active_trace

            active_trace = _get_active_trace()
            if active_trace is None:
                return await original_acreate(self_completions, *args, **kwargs)

            ciphyrs_client_inner = client
            if ciphyrs_client_inner is None:
                from ciphyrs import get_client
                try:
                    ciphyrs_client_inner = get_client()
                except RuntimeError:
                    return await original_acreate(self_completions, *args, **kwargs)

            model = kwargs.get("model", "unknown")
            messages = kwargs.get("messages", [])
            input_text = _format_messages(messages)

            with ciphyrs_client_inner.span(
                agent_name=f"openai/{model}",
                kind="llm_call",
                operation_name="chat.completions.create",
                model_name=model,
            ) as span:
                span.set_input(input_text)

                try:
                    response = await original_acreate(self_completions, *args, **kwargs)
                except Exception as exc:
                    span.set_error(exc)
                    raise

                try:
                    if hasattr(response, "choices") and response.choices:
                        content = response.choices[0].message.content or ""
                        span.set_output(content)

                    if hasattr(response, "usage") and response.usage:
                        span.set_tokens(
                            prompt_tokens=response.usage.prompt_tokens,
                            completion_tokens=response.usage.completion_tokens,
                            total=response.usage.total_tokens,
                        )

                    if hasattr(response, "model"):
                        span.set_model(response.model)
                except Exception:
                    logger.debug("Failed to extract async OpenAI response metadata", exc_info=True)

                return response

        AsyncCompletions.create = traced_acreate  # type: ignore
    except (ImportError, AttributeError):
        pass  # Async not available

    _patched = True
    logger.info("OpenAI SDK patched for Ciphyrs tracing")


def unpatch_openai() -> None:
    """Remove the Ciphyrs monkey-patch from OpenAI and restore original methods."""
    global _patched, _original_create, _original_acreate

    if not _patched:
        return

    try:
        from openai.resources.chat.completions import Completions

        if _original_create is not None:
            Completions.create = _original_create  # type: ignore

        try:
            from openai.resources.chat.completions import AsyncCompletions

            if _original_acreate is not None:
                AsyncCompletions.create = _original_acreate  # type: ignore
        except (ImportError, AttributeError):
            pass
    except ImportError:
        pass

    _patched = False
    _original_create = None
    _original_acreate = None
    logger.info("OpenAI SDK unpatched — original methods restored")


def _format_messages(messages: list) -> str:
    """Format OpenAI messages list into a readable string."""
    parts = []
    for msg in messages:
        if isinstance(msg, dict):
            role = msg.get("role", "?")
            content = msg.get("content", "")
            if isinstance(content, list):
                # Multi-modal messages
                text_parts = [p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text"]
                content = " ".join(text_parts)
            parts.append(f"[{role}] {content}")
        else:
            parts.append(str(msg))
    return "\n".join(parts)[:10000]
