"""LangChain callback handler for automatic Ciphyrs tracing.

Usage:
    from ciphyrs.integrations.langchain import CiphyrsCallbackHandler

    handler = CiphyrsCallbackHandler(client=ciphyrs_client)
    chain.invoke({"input": "hello"}, config={"callbacks": [handler]})
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Union

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError:
    try:
        from langchain.callbacks.base import BaseCallbackHandler
        from langchain.schema import LLMResult
    except ImportError:
        raise ImportError(
            "LangChain is required for this integration. "
            "Install it with: pip install ciphyrs[langchain]"
        )


class CiphyrsCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that sends traces to Ciphyrs.

    Automatically captures:
    - LLM calls with model name, tokens, and input/output
    - Chain runs with input/output
    - Tool invocations with tool name and results
    - Errors in any component
    """

    def __init__(
        self,
        client: Any = None,
        project: Optional[str] = None,
        trace_name: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        super().__init__()
        if client is None:
            from ciphyrs import get_client
            client = get_client()

        self._client = client
        self._project = project or client.project
        self._trace_name = trace_name or "langchain_trace"
        self._session_id = session_id

        self._trace_id = str(uuid.uuid4())
        self._spans: Dict[str, Dict[str, Any]] = {}
        self._span_order: List[str] = []
        self._parent_stack: List[str] = []
        self._trace_start = time.monotonic()
        self._trigger_input: Optional[str] = None
        self._final_output: Optional[str] = None

    def _new_span(
        self,
        run_id: str,
        agent_name: str,
        kind: str,
        operation_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        span = {
            "span_id": str(run_id),
            "parent_span_id": self._parent_stack[-1] if self._parent_stack else None,
            "agent_name": agent_name,
            "kind": kind,
            "operation_name": operation_name,
            "status": "ok",
            "input": None,
            "output": None,
            "error_message": None,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "ended_at": None,
            "duration_ms": None,
            "token_count": None,
            "prompt_tokens": None,
            "completion_tokens": None,
            "model_name": None,
            "session_id": self._session_id,
            "attributes": {},
            "_start_mono": time.monotonic(),
        }
        self._spans[str(run_id)] = span
        self._span_order.append(str(run_id))
        return span

    def _finish_span(self, run_id: str, output: Optional[str] = None, error: Optional[str] = None) -> None:
        key = str(run_id)
        span = self._spans.get(key)
        if not span:
            return
        elapsed = time.monotonic() - span.pop("_start_mono", time.monotonic())
        span["duration_ms"] = int(elapsed * 1000)
        span["ended_at"] = datetime.now(timezone.utc).isoformat()
        if output is not None:
            span["output"] = str(output)[:10000]
        if error:
            span["status"] = "error"
            span["error_message"] = str(error)[:2000]

    # ── LLM callbacks ────────────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
        span = self._new_span(run_id, agent_name=name, kind="llm_call", operation_name="llm.generate")
        span["input"] = "\n---\n".join(prompts)[:10000]

        model = kwargs.get("invocation_params", {}).get("model_name") or kwargs.get("invocation_params", {}).get("model")
        if model:
            span["model_name"] = model

        self._parent_stack.append(str(run_id))

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        output_text = ""
        if response.generations:
            texts = [g.text for gen_list in response.generations for g in gen_list if hasattr(g, "text")]
            output_text = "\n".join(texts)

        span = self._spans.get(str(run_id))
        if span and response.llm_output:
            usage = response.llm_output.get("token_usage", {})
            span["prompt_tokens"] = usage.get("prompt_tokens")
            span["completion_tokens"] = usage.get("completion_tokens")
            span["token_count"] = usage.get("total_tokens")
            if "model_name" in response.llm_output:
                span["model_name"] = response.llm_output["model_name"]

        self._finish_span(run_id, output=output_text)
        self._final_output = output_text[:2000]
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    def on_llm_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        self._finish_span(run_id, error=str(error))
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    # ── Chain callbacks ──────────────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
        span = self._new_span(run_id, agent_name=name, kind="agent", operation_name="chain.run")
        input_str = str(inputs)[:10000]
        span["input"] = input_str
        if self._trigger_input is None:
            self._trigger_input = input_str[:2000]
        self._parent_stack.append(str(run_id))

    def on_chain_end(self, outputs: Dict[str, Any], *, run_id: Any, **kwargs: Any) -> None:
        output_str = str(outputs)[:10000]
        self._finish_span(run_id, output=output_str)
        self._final_output = output_str[:2000]
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    def on_chain_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        self._finish_span(run_id, error=str(error))
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    # ── Tool callbacks ───────────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        name = serialized.get("name", "tool")
        span = self._new_span(run_id, agent_name=name, kind="tool_call", operation_name=f"tool.{name}")
        span["input"] = str(input_str)[:10000]
        self._parent_stack.append(str(run_id))

    def on_tool_end(self, output: str, *, run_id: Any, **kwargs: Any) -> None:
        self._finish_span(run_id, output=str(output))
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    def on_tool_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        self._finish_span(run_id, error=str(error))
        if str(run_id) in self._parent_stack:
            self._parent_stack.remove(str(run_id))

    # ── Text / Retriever (minimal) ───────────────────────────────────────

    def on_text(self, text: str, **kwargs: Any) -> None:
        pass  # Not traced separately

    # ── Flush on completion ──────────────────────────────────────────────

    def flush(self) -> None:
        """Send the accumulated trace to Ciphyrs."""
        duration_ms = int((time.monotonic() - self._trace_start) * 1000)

        has_errors = any(s.get("status") == "error" for s in self._spans.values())

        trace_payload = {
            "trace_id": self._trace_id,
            "name": self._trace_name,
            "status": "failed" if has_errors else "completed",
            "trigger_input": self._trigger_input,
            "final_output": self._final_output,
            "duration_ms": duration_ms,
            "metadata": {},
        }

        ordered_spans = [self._spans[sid] for sid in self._span_order if sid in self._spans]

        self._client.ingest(
            project={"name": self._project},
            trace=trace_payload,
            spans=ordered_spans,
        )

    def __del__(self) -> None:
        try:
            if self._spans:
                self.flush()
        except Exception:
            pass
