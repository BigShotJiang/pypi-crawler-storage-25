"""Agent testing utilities — security scans and performance benchmarks."""
import time
import requests
from typing import List, Optional, Dict, Any


class TestRunner:
    """Runs security and performance tests against agent endpoints."""

    def __init__(self, client):
        self.client = client
        self.base_url = client.base_url
        self.session = client._session  # reuse session with auth

    def security_scan(self, agent_endpoint: str, categories: Optional[List[str]] = None,
                      timeout: int = 30) -> dict:
        """Run a quick security scan against an agent endpoint.

        Args:
            agent_endpoint: URL of the agent to test
            categories: List of attack categories (default: all)
                Options: prompt_injection, pii_leakage, jailbreak, secret_extraction, tool_abuse
            timeout: Timeout per test case in seconds

        Returns:
            dict with: run_id, status, score, total, passed, failed, results[]
        """
        resp = self.session.post(f"{self.base_url}/v1/tests/quick/security", json={
            "agent_endpoint": agent_endpoint,
            "categories": categories or [
                "prompt_injection", "pii_leakage", "jailbreak",
                "secret_extraction", "tool_abuse",
            ],
            "timeout": timeout,
        })
        resp.raise_for_status()
        run = resp.json()

        # Poll until complete
        return self._poll_run(run["run_id"], timeout=timeout * 50)

    def performance_benchmark(self, agent_endpoint: str, test_inputs: List[str],
                               concurrency: int = 5, duration_seconds: int = 60) -> dict:
        """Run a performance benchmark against an agent endpoint.

        Args:
            agent_endpoint: URL of the agent to test
            test_inputs: List of test prompts to send
            concurrency: Number of concurrent requests
            duration_seconds: How long to run the benchmark

        Returns:
            dict with: run_id, p50_ms, p95_ms, p99_ms, avg_cost, total_tokens, throughput_rps
        """
        resp = self.session.post(f"{self.base_url}/v1/tests/quick/performance", json={
            "agent_endpoint": agent_endpoint,
            "test_inputs": test_inputs,
            "concurrency": concurrency,
            "duration_seconds": duration_seconds,
        })
        resp.raise_for_status()
        run = resp.json()

        return self._poll_run(run["run_id"], timeout=duration_seconds + 30)

    def list_suites(self, suite_type: Optional[str] = None) -> list:
        """List test suites.

        Args:
            suite_type: Optional filter — 'security', 'performance', 'functional'

        Returns:
            List of test suite dicts.
        """
        params = {}
        if suite_type:
            params["suite_type"] = suite_type
        resp = self.session.get(f"{self.base_url}/v1/tests/suites", params=params)
        resp.raise_for_status()
        return resp.json()

    def get_run(self, run_id: str) -> dict:
        """Get test run details with results.

        Args:
            run_id: The test run identifier.

        Returns:
            dict with run status, score, and individual test results.
        """
        resp = self.session.get(f"{self.base_url}/v1/tests/runs/{run_id}")
        resp.raise_for_status()
        return resp.json()

    def list_attacks(self, category: Optional[str] = None) -> list:
        """List available attack templates.

        Args:
            category: Optional filter — 'prompt_injection', 'pii_leakage', etc.

        Returns:
            List of attack template dicts.
        """
        url = f"{self.base_url}/v1/tests/attacks"
        if category:
            url = f"{url}/{category}"
        resp = self.session.get(url)
        resp.raise_for_status()
        return resp.json()

    def _poll_run(self, run_id: str, timeout: int = 300, interval: float = 2.0) -> dict:
        """Poll a test run until completion.

        Args:
            run_id: The test run identifier.
            timeout: Max seconds to wait.
            interval: Initial polling interval in seconds (grows with backoff).

        Returns:
            Completed test run dict.

        Raises:
            TimeoutError: If the run does not complete within the timeout.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            run = self.get_run(run_id)
            if run.get("status") in ("completed", "failed", "cancelled"):
                return run
            time.sleep(min(interval, max(0.1, deadline - time.time())))
            interval = min(interval * 1.2, 10)  # gradual backoff
        raise TimeoutError(f"Test run {run_id} did not complete within {timeout}s")
