"""Basic tests for CiphyrsClient (Python SDK).

Run with: python -m pytest tests/test_client.py -v
"""

import threading
import unittest
from unittest.mock import MagicMock, patch

from ciphyrs.client import (
    MAX_BUFFER_SIZE,
    CiphyrsClient,
    _SpanContext,
    _TraceContext,
    _current_span,
    _current_trace,
    _get_active_span,
    _get_active_trace,
)


class TestCiphyrsClientInit(unittest.TestCase):
    """Test client initialization."""

    @patch("ciphyrs.client.requests.Session")
    def test_default_project(self, mock_session_cls):
        client = CiphyrsClient(api_key="ck_test_12345678")
        self.assertEqual(client.project, "default")
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_custom_project(self, mock_session_cls):
        client = CiphyrsClient(api_key="ck_test_12345678", project="my-proj")
        self.assertEqual(client.project, "my-proj")
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_base_url_trailing_slash(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            base_url="https://api.example.com///",
        )
        self.assertEqual(client.base_url, "https://api.example.com")
        client.shutdown()


class TestSpanContext(unittest.TestCase):
    """Test _SpanContext data class."""

    def test_set_input_output(self):
        span = _SpanContext(trace_id="t1", agent_name="agent")
        span.set_input("hello").set_output("world")
        d = span.to_dict()
        self.assertEqual(d["input"], "hello")
        self.assertEqual(d["output"], "world")

    def test_set_tokens(self):
        span = _SpanContext(trace_id="t1", agent_name="agent")
        span.set_tokens(prompt_tokens=10, completion_tokens=20)
        d = span.to_dict()
        self.assertEqual(d["prompt_tokens"], 10)
        self.assertEqual(d["completion_tokens"], 20)
        self.assertEqual(d["token_count"], 30)

    def test_set_error(self):
        span = _SpanContext(trace_id="t1", agent_name="agent")
        span.set_error(ValueError("oops"))
        d = span.to_dict()
        self.assertEqual(d["status"], "error")
        self.assertIn("ValueError", d["error_message"])

    def test_set_model_and_cost(self):
        span = _SpanContext(trace_id="t1", agent_name="agent")
        span.set_model("gpt-4").set_cost(0.05)
        d = span.to_dict()
        self.assertEqual(d["model_name"], "gpt-4")
        self.assertEqual(d["cost_usd"], 0.05)


class TestBuffering(unittest.TestCase):
    """Test span buffering and flush."""

    @patch("ciphyrs.client.requests.Session")
    def test_enqueue_adds_to_buffer(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            max_buffer_size=100,
            flush_interval=0,
        )
        payload = {"trace": {"trace_id": "t1"}, "spans": []}
        client._enqueue(payload)
        self.assertEqual(len(client._buffer), 1)
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_flush_clears_buffer(self, mock_session_cls):
        mock_session = MagicMock()
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {"ok": True}
        mock_session.post.return_value = mock_response
        mock_session_cls.return_value = mock_session

        client = CiphyrsClient(
            api_key="ck_test_12345678",
            max_buffer_size=100,
            flush_interval=0,
        )
        client._session = mock_session
        client._enqueue({"trace": {"trace_id": "t1"}, "spans": []})
        client._enqueue({"trace": {"trace_id": "t2"}, "spans": []})
        client.flush()
        self.assertEqual(len(client._buffer), 0)
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_buffer_overflow_drops_oldest(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            max_buffer_size=MAX_BUFFER_SIZE + 100,  # prevent auto-flush
            flush_interval=0,
        )
        # Fill buffer beyond MAX_BUFFER_SIZE
        for i in range(MAX_BUFFER_SIZE + 5):
            client._buffer.append({"trace": {"trace_id": str(i)}, "spans": []})

        # Enqueue one more
        client._enqueue({"trace": {"trace_id": "overflow"}, "spans": []})
        self.assertLessEqual(len(client._buffer), MAX_BUFFER_SIZE)
        # The last item should be the overflow one
        self.assertEqual(client._buffer[-1]["trace"]["trace_id"], "overflow")
        client.shutdown()


class TestTraceSpanContextManager(unittest.TestCase):
    """Test trace/span context managers."""

    @patch("ciphyrs.client.requests.Session")
    def test_trace_creates_context(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            flush_interval=0,
        )
        with client.trace("test-trace") as ctx:
            self.assertIsNotNone(ctx)
            self.assertEqual(ctx.name, "test-trace")
            self.assertEqual(_get_active_trace(), ctx)

        # After exiting, trace should be cleared
        self.assertIsNone(_get_active_trace())
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_span_within_trace(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            flush_interval=0,
        )
        with client.trace("test-trace") as trace_ctx:
            with client.span("my-agent", kind="llm_call") as span_ctx:
                span_ctx.set_input("question")
                span_ctx.set_output("answer")
                self.assertEqual(_get_active_span(), span_ctx)

            # Span should be recorded on the trace
            self.assertEqual(len(trace_ctx.spans), 1)
            self.assertEqual(trace_ctx.spans[0].agent_name, "my-agent")

        self.assertIsNone(_get_active_span())
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_span_outside_trace_raises(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            flush_interval=0,
        )
        with self.assertRaises(RuntimeError):
            with client.span("agent", kind="agent"):
                pass
        client.shutdown()

    @patch("ciphyrs.client.requests.Session")
    def test_trace_captures_error(self, mock_session_cls):
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            flush_interval=0,
        )
        with self.assertRaises(ValueError):
            with client.trace("fail-trace") as ctx:
                raise ValueError("boom")

        self.assertEqual(ctx.status, "failed")
        self.assertIn("ValueError", ctx.metadata.get("error", ""))
        client.shutdown()


class TestContextVars(unittest.TestCase):
    """Test that context variables work across threads."""

    @patch("ciphyrs.client.requests.Session")
    def test_contextvars_isolation(self, mock_session_cls):
        """Verify that traces in different threads are isolated."""
        client = CiphyrsClient(
            api_key="ck_test_12345678",
            flush_interval=0,
        )
        results = {}

        def thread_fn(name):
            with client.trace(name) as ctx:
                results[name] = ctx.trace_id
                active = _get_active_trace()
                results[f"{name}_active"] = active.trace_id if active else None

        t1 = threading.Thread(target=thread_fn, args=("thread-1",))
        t2 = threading.Thread(target=thread_fn, args=("thread-2",))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        # Each thread should have seen its own trace
        self.assertEqual(results["thread-1"], results["thread-1_active"])
        self.assertEqual(results["thread-2"], results["thread-2_active"])
        self.assertNotEqual(results["thread-1"], results["thread-2"])
        client.shutdown()


if __name__ == "__main__":
    unittest.main()
