from setuptools import setup, find_packages

setup(
    name="ciphyrs",
    version="2.2.0",
    description="Official Ciphyrs SDK for Python — agent tracing, observability, and PII detection",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Ciphyrs",
    author_email="sdk@ciphyrs.com",
    url="https://github.com/ciphyrs/ciphyrs-python",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "langchain": ["langchain>=0.1.0"],
        "openai": ["openai>=1.0.0"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
    ],
)
