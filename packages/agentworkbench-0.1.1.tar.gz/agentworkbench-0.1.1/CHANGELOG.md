# Changelog

## Unreleased

- Added an eval-driven agent optimization workflow for repo-native agents.
- Added local-first security suite generation and optional Promptfoo interoperability.
- Added benchmark signatures, promotion gates, weighted metrics, and behavior-surface telemetry across prompts, tools, skills, plugins, and MCPs.
- Added experiment normalization for older artifact bundles so status, history, and leaderboard stay usable across schema drift.
- Added cost and token telemetry to experiment reports, compare output, diagnosis, proposals, and optional promotion gates.
- Added repo-local `env_files` loading for command agents, plus a live Groq/Cerebras provider demo for smoke-checking real external models.
- Added `awb check` loop-readiness reports and promotion gates for code structure, agent topology, eval contracts, deterministic fallbacks, and loop hygiene.
- Added compatibility aliases for `awb ablate --limit` and top-level `awb run-workflow`.
- Added downstream Codex agent and release/laptop setup documentation.
- Cleaned the release quality gates so `ruff check .`, `mypy`, and `pytest -q` pass.
- Removed the Docker wrapper and trimmed the CLI back to the core optimization loop around status, compare, diagnose, propose, patch-template, and promote.
