# Agent Workbench Instructions

1. Run `awb learn` before creating a behavior brief or editing the target agent.
2. Use `awb brief start --agent-id <id>` and the generated packet to interview the user and capture approved behavior in `.agent-workbench/briefs/*.yaml`.
3. Only generate evals from an approved brief, then review the draft suite and run `awb evals approve --eval-id <id>` before starting experiments.
4. Use `awb run`, `awb check`, `awb compare --best`, `awb diagnose`, `awb status`, and `awb promote` to evaluate changes instead of ad hoc scripts.
5. Use `awb propose` when you want a bounded mutation plan, then `awb patch-template` when you want an editable implementation checklist with grouped file/path edits and validation steps.
6. Keep benchmark drift visible. If briefs, evals, or scorers change, call that out explicitly.
7. Treat prompts, tools, skills, plugins, and MCPs as first-class optimization levers. Check whether newly available surfaces are actually used before keeping them.
8. Run `awb check --agent-id <id> --eval-id <id> --subset full` or `awb check --experiment <id>` before promotion; treat critical loop-readiness findings as blockers.
9. Do not rely on smoke runs for live optimization or promotion decisions. Use `full` runs for meaningful evaluation; smoke subsets are only for fast local debugging.
