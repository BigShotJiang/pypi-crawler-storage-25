# OrbitDesk Team Directory

- Account Security owns SSO exception reviews and prior exception follow-ups.
- Frontline Billing handles invoice typos and simple billing corrections.
- Product Support handles repeated export failures and workflow bugs.
