# OrbitDesk Support Style

- Use exact policy phrases when they exist in the local context.
- Keep replies to one or two sentences.
- State the decision first and end with the next action.
