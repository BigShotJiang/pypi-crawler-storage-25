# OrbitDesk Refund Policy

- Support uses a 14-day refund window from the latest renewal.
- If usage is 25 credits or fewer inside the 14-day refund window, support can approve directly.
- If usage is above 25 credits inside the 14-day refund window, manager approval is required.
- After the 14-day refund window, the account is not eligible for a refund.
- If the billing email changed in the last 7 days, pause the refund and verify identity first.
