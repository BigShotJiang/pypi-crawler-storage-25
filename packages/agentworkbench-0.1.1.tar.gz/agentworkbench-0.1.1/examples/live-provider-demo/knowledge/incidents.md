# OrbitDesk Incident Playbook

- If export jobs are stuck for more than 15 minutes across multiple teams, open Sev2 and post to the status page.
- If payment failures affect multiple workspaces, open Sev1 and page the incident commander.
- If a single customer sees a local login issue, use normal troubleshooting and do not open an incident.
