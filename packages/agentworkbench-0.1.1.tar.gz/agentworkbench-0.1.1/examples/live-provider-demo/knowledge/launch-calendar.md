# OrbitDesk Launch Calendar

- Month-end freeze runs from the 28th to the 30th; risky changes do not ship in that window.
- Low-risk UI-only changes can ship in the current window.
