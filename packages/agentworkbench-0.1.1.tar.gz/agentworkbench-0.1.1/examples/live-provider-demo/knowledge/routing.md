# OrbitDesk Routing Policy

- SSO exception requests for enterprise accounts route to Account Security.
- Minor invoice typos and simple billing corrections route to Frontline Billing.
- Repeated export failures for high-priority customers route to Product Support.
