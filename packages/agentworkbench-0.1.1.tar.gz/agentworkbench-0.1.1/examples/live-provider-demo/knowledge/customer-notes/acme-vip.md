# Customer History: ACME VIP

- ACME is a VIP customer with priority handling.
- The previous workaround failed for the export bug.
- If the export bug returns, apologize, say the workaround failed, and escalate to product as P1.
- Last month ACME received a courtesy extension, not a refund.
