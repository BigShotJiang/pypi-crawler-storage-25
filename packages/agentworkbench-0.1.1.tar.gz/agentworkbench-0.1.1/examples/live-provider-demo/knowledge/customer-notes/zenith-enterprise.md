# Customer History: Zenith Enterprise

- Zenith Enterprise had a prior SSO exception denied last quarter.
- Route follow-up exception requests back to Account Security with that history.
