# OrbitDesk Release Checklist

- If a release includes a backward incompatible database migration, delay the release until a rollback plan is approved.
- If finance exports are touched during month-end freeze, delay the release and notify finance operations.
- If a release only changes UI copy with no backend risk, ship in the current window.
