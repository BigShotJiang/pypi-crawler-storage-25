from __future__ import annotations

from pathlib import Path
from typing import Any


def _query_terms(query: str) -> list[str]:
    sanitized = query.lower()
    for marker in ["?", ",", ".", ":", ";", "!", "(", ")", "'"]:
        sanitized = sanitized.replace(marker, " ")
    return [term for term in sanitized.split() if len(term) > 3]


def _history_line_bonus(query: str, line: str) -> int:
    lowered_query = query.lower()
    lowered_line = line.lower()
    bonus = 0
    if any(marker in lowered_query for marker in ("again", "another", "repeat", "repeated", "follow-up", "follow up")):
        if any(marker in lowered_line for marker in ("prior", "previous", "last", "denied", "approved", "failed", "workaround", "extension")):
            bonus += 4
    if any(marker in lowered_query for marker in ("refund", "credits", "renewed")):
        if any(marker in lowered_line for marker in ("refund", "extension", "manager", "courtesy")):
            bonus += 3
    if any(marker in lowered_query for marker in ("exception", "review", "reviewed")):
        if any(marker in lowered_line for marker in ("denied", "approved", "exception")):
            bonus += 3
    if any(marker in lowered_query for marker in ("bug", "incident", "export")):
        if any(marker in lowered_line for marker in ("failed", "workaround", "p1", "escalate")):
            bonus += 3
    return bonus


def recall_customer_history_hits(project_root: Path, customer_id: str, query: str = "", limit: int = 2) -> list[dict[str, Any]]:
    """Return the most relevant customer-history lines for the current support question."""
    path = project_root / "knowledge" / "customer-notes" / f"{customer_id}.md"
    if not path.exists():
        return []
    relative_path = str(path.relative_to(project_root))
    text = path.read_text(encoding="utf-8").strip()
    terms = _query_terms(query)
    lines = [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]
    if not terms:
        return [
            {
                "id": f"{relative_path}#L{index + 1}",
                "path": relative_path,
                "line": index + 1,
                "score": 0,
                "snippet": line,
            }
            for index, line in enumerate(lines[:limit])
        ]
    ranked: list[tuple[int, int, str]] = []
    for index, line in enumerate(lines):
        haystack = line.lower()
        score = sum(1 for term in terms if term in haystack) + _history_line_bonus(query, line)
        if score <= 0:
            continue
        ranked.append((score, index, line))
    if not ranked:
        return [
            {
                "id": f"{relative_path}#L{index + 1}",
                "path": relative_path,
                "line": index + 1,
                "score": 0,
                "snippet": line,
            }
            for index, line in enumerate(lines[:limit])
        ]
    ranked.sort(key=lambda item: (-item[0], item[1]))
    top_score = ranked[0][0]
    score_floor = max(1, top_score - 1)
    selected: list[tuple[int, str]] = []
    selected_scores: dict[str, int] = {}
    seen: set[str] = set()
    for score, index, line in ranked:
        if selected and score < score_floor:
            break
        if line in seen:
            continue
        seen.add(line)
        selected.append((index, line))
        selected_scores[line] = score
        if len(selected) >= limit:
            break
    selected.sort(key=lambda item: item[0])
    return [
        {
            "id": f"{relative_path}#L{index + 1}",
            "path": relative_path,
            "line": index + 1,
            "score": selected_scores.get(line, 0),
            "snippet": line,
        }
        for index, line in selected
    ]


def recall_customer_history(project_root: Path, customer_id: str, query: str = "", limit: int = 2) -> str:
    hits = recall_customer_history_hits(project_root, customer_id, query=query, limit=limit)
    return "\n".join(str(item.get("snippet") or "").strip() for item in hits if str(item.get("snippet") or "").strip())
