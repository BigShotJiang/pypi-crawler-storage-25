from __future__ import annotations

import re
from pathlib import Path


def _query_terms(query: str) -> list[str]:
    return [term for term in re.findall(r"[a-z0-9]+", query.lower()) if len(term) > 1]


def _refund_signals(query: str) -> dict[str, int | bool]:
    lowered = query.lower()
    signals: dict[str, int | bool] = {}
    days_match = re.search(r"(\d+)\s+days?\s+ago", lowered)
    credits_match = re.search(r"used\s+(\d+)\s+credits?", lowered)
    if days_match:
        signals["days_since_renewal"] = int(days_match.group(1))
    elif "yesterday" in lowered:
        signals["days_since_renewal"] = 1
    if credits_match:
        signals["credits_used"] = int(credits_match.group(1))
    if "billing email changed" in lowered:
        signals["billing_email_changed"] = True
    return signals


def _refund_line_bonus(line: str, signals: dict[str, int | bool]) -> int:
    lowered = line.lower()
    bonus = 0
    days_since = signals.get("days_since_renewal")
    credits_used = signals.get("credits_used")
    threshold_match = re.search(r"(\d+)[-\s]?day", lowered)
    credit_threshold_match = re.search(r"(\d+)\s+credits", lowered)
    if isinstance(days_since, int) and threshold_match:
        threshold = int(threshold_match.group(1))
        if days_since <= threshold and any(marker in lowered for marker in ("inside", "within", "last")):
            bonus += 4
        if days_since > threshold and any(marker in lowered for marker in ("after", "outside")):
            bonus += 4
        if days_since <= threshold and any(marker in lowered for marker in ("after", "outside")):
            bonus -= 2
        if days_since > threshold and any(marker in lowered for marker in ("inside", "within", "last")):
            bonus -= 2
    if isinstance(credits_used, int) and credit_threshold_match:
        threshold = int(credit_threshold_match.group(1))
        if credits_used <= threshold and "or fewer" in lowered:
            bonus += 4
        if credits_used > threshold and any(marker in lowered for marker in ("above", "over", "more than")):
            bonus += 4
        if credits_used <= threshold and any(marker in lowered for marker in ("above", "over", "more than")):
            bonus -= 2
        if credits_used > threshold and "or fewer" in lowered:
            bonus -= 2
    if signals.get("billing_email_changed") and "billing email changed" in lowered:
        bonus += 5
    return bonus


def _release_signals(query: str) -> dict[str, bool]:
    lowered = query.lower()
    return {
        "db_migration": "database migration" in lowered or "backward incompatible" in lowered,
        "finance_exports": "finance export" in lowered and not any(
            phrase in lowered
            for phrase in ["no finance export", "no finance exports", "without finance export", "without finance exports"]
        ),
        "no_finance_exports": any(
            phrase in lowered
            for phrase in ["no finance export", "no finance exports", "without finance export", "without finance exports"]
        ),
        "month_end_freeze": "month-end freeze" in lowered and not any(
            phrase in lowered
            for phrase in ["not in month-end freeze", "outside month-end freeze", "not during month-end freeze"]
        ),
        "not_month_end_freeze": any(
            phrase in lowered
            for phrase in ["not in month-end freeze", "outside month-end freeze", "not during month-end freeze"]
        ),
        "ui_only": any(phrase in lowered for phrase in ["ui copy", "ui-only", "ui only"]) and "no backend risk" in lowered,
    }


def _release_line_bonus(line: str, signals: dict[str, bool]) -> int:
    lowered = line.lower()
    bonus = 0
    if signals.get("db_migration"):
        if "database migration" in lowered or "backward incompatible" in lowered:
            bonus += 12
        if any(marker in lowered for marker in ("ui copy", "ui-only", "current window")):
            bonus -= 8
    if signals.get("finance_exports"):
        if "finance exports" in lowered:
            bonus += 6
    if signals.get("no_finance_exports") and "finance exports" in lowered:
        bonus -= 6
    if signals.get("month_end_freeze"):
        if "month-end freeze" in lowered:
            bonus += 6
    if signals.get("not_month_end_freeze") and "month-end freeze" in lowered:
        bonus -= 10
    if signals.get("ui_only"):
        if "ui copy" in lowered or "current window" in lowered:
            bonus += 6
        if "database migration" in lowered:
            bonus -= 4
    return bonus


def _search_files(project_root: Path, relative_paths: list[str], query: str, limit: int = 2, *, allow_fallback: bool = True) -> list[dict[str, str]]:
    terms = _query_terms(query)
    refund_signals = _refund_signals(query)
    release_signals = _release_signals(query)
    ranked: list[tuple[int, str, int, str]] = []
    for relative_path in relative_paths:
        path = project_root / relative_path
        if not path.exists():
            continue
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            snippet = line.strip()
            if not snippet or snippet.startswith("#"):
                continue
            haystack = snippet.lower()
            score = sum(1 for term in terms if term in haystack)
            if relative_path.endswith("refunds.md"):
                score += _refund_line_bonus(snippet, refund_signals)
            if relative_path.endswith(("release-checklist.md", "launch-calendar.md")):
                score += _release_line_bonus(snippet, release_signals)
            if terms and score <= 0:
                continue
            ranked.append((score, relative_path, index, snippet))
    if ranked:
        ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
        matches = []
        seen = set()
        top_score = ranked[0][0]
        score_floor = max(1, top_score - 2)
        for score, relative_path, index, snippet in ranked:
            if matches and score < score_floor:
                break
            key = (relative_path, snippet)
            if key in seen:
                continue
            seen.add(key)
            matches.append(
                {
                    "id": f"{relative_path}#L{index + 1}",
                    "path": relative_path,
                    "line": index + 1,
                    "score": score,
                    "snippet": snippet,
                }
            )
            if len(matches) >= limit:
                break
        return matches
    if not allow_fallback:
        return []
    fallback = []
    for relative_path in relative_paths[:limit]:
        path = project_root / relative_path
        if path.exists():
            content_lines = [
                line.strip()
                for line in path.read_text(encoding="utf-8").splitlines()
                if line.strip() and not line.lstrip().startswith("#")
            ]
            fallback.append(
                {
                    "id": relative_path,
                    "path": relative_path,
                    "line": 1,
                    "score": 0,
                    "snippet": "\n".join(content_lines[:3]).strip(),
                }
            )
    return fallback


def policy_search(query: str, project_root: Path) -> list[dict[str, str]]:
    """Return the decisive refund-policy lines for a support-policy question."""
    return _search_files(
        project_root,
        ["knowledge/refunds.md"],
        query,
        limit=2,
        allow_fallback=False,
    )


def incident_lookup(query: str, project_root: Path) -> list[dict[str, str]]:
    """Find the incident playbook line that best matches the current support incident question."""
    return _search_files(project_root, ["knowledge/incidents.md"], query, limit=1, allow_fallback=False)


def release_checklist_search(query: str, project_root: Path) -> list[dict[str, str]]:
    """Retrieve the strongest release-checklist lines that should drive a launch recommendation."""
    return _search_files(project_root, ["knowledge/release-checklist.md"], query, limit=2, allow_fallback=False)


def launch_calendar_lookup(query: str, project_root: Path) -> list[dict[str, str]]:
    """Retrieve launch-calendar timing constraints that can block or permit a release."""
    return _search_files(project_root, ["knowledge/launch-calendar.md"], query, limit=1, allow_fallback=False)


def routing_policy_search(query: str, project_root: Path) -> list[dict[str, str]]:
    """Retrieve the routing rule snippet that should determine the escalation target."""
    return _search_files(project_root, ["knowledge/routing.md"], query, limit=1, allow_fallback=False)


def team_directory_lookup(query: str, project_root: Path) -> list[dict[str, str]]:
    """Retrieve the team-directory snippet that maps a workflow to an owning team."""
    return _search_files(project_root, ["knowledge/team-directory.md"], query, limit=1, allow_fallback=False)


def response_planner(query: str) -> str:
    """Draft a simple response plan without adding new external evidence."""
    return f"Plan: gather local context, answer with the decision first, then the next action. Query: {query}"
