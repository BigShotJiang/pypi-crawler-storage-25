from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from agentworkbench.demo_helpers import read_prompt_file, runtime_event
from agentworkbench.evidence import snippet_supported_by_output
from target_agent.memory import recall_customer_history_hits
from target_agent.tools import (
    incident_lookup,
    launch_calendar_lookup,
    policy_search,
    release_checklist_search,
    routing_policy_search,
    team_directory_lookup,
)

_PROVIDERS = {
    "groq": {
        "api_key_env": "GROQ_API_KEY",
        "base_url": "https://api.groq.com/openai/v1/chat/completions",
    },
    "cerebras": {
        "api_key_env": "CEREBRAS_API_KEY",
        "base_url": "https://api.cerebras.ai/v1/chat/completions",
    },
}

def _enabled_names(items: list[dict[str, Any]]) -> list[str]:
    names = []
    for item in items:
        if item.get("enabled", True):
            name = item.get("name") or item.get("id")
            if name:
                names.append(str(name))
    return sorted(dict.fromkeys(names))


def _provider_response(model: dict[str, Any], messages: list[dict[str, str]]) -> tuple[str, dict[str, int]]:
    provider_name = str(model.get("provider") or "")
    provider = _PROVIDERS[provider_name]
    api_key = os.environ.get(provider["api_key_env"], "")
    payload = {
        "model": str(model.get("model_id") or model.get("name") or ""),
        "messages": messages,
        "temperature": float(model.get("temperature", 0)),
        "max_tokens": int(model.get("max_tokens", 120)),
    }
    request = urllib.request.Request(
        provider["base_url"],
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "agent-workbench-live-provider-demo",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30, context=ssl.create_default_context()) as response:
        body = json.loads(response.read().decode("utf-8"))
    content = body["choices"][0]["message"]["content"].strip()
    usage = body.get("usage") or {}
    return content, {
        "input": int(usage.get("prompt_tokens", 0) or 0),
        "output": int(usage.get("completion_tokens", 0) or 0),
        "total": int(usage.get("total_tokens", 0) or 0),
    }


def _facts_text(metadata: dict[str, Any]) -> str:
    facts = metadata.get("facts") or {}
    if not facts:
        return "(none)"
    return "\n".join(f"- {key}: {value}" for key, value in facts.items())


def _hits_text(hits: list[dict[str, Any]], *, include_reference: bool = False) -> str:
    lines: list[str] = []
    for item in hits:
        snippet = str(item.get("snippet") or "").strip()
        if not snippet:
            continue
        reference = str(item.get("id") or item.get("path") or "").strip()
        if include_reference and reference:
            lines.append(f"- {reference}: {snippet}")
        else:
            lines.append(f"- {snippet}")
    return "\n".join(lines)


def _answer_contract(*, customer_history_present: bool) -> str:
    rules = [
        "Answer in exactly two sentences.",
        "Sentence 1 must start with the decision or destination team.",
        "Sentence 1 must preserve the decisive local rule phrase verbatim instead of paraphrasing it.",
        "Sentence 2 must start exactly with 'Next action:' and give the follow-up action.",
    ]
    if customer_history_present:
        rules.append("When customer history changes the outcome, preserve the decisive history line verbatim instead of paraphrasing it.")
        rules.append("If both rule context and customer history apply, include one exact phrase from each source.")
    return "\n".join(f"- {rule}" for rule in rules)


def _skipped_surface_event(kind: str, name: str, *, mcp: str = "", reason: str = "", **data: Any) -> dict[str, Any]:
    return runtime_event(kind, name, status="skipped", mcp=mcp, reason=reason, **data)


def _evidence_record(
    *,
    kind: str,
    name: str,
    query: str,
    status: str,
    hits: list[dict[str, Any]],
    mcp: str = "",
) -> dict[str, Any]:
    selected_hits = []
    for item in hits:
        hit = dict(item)
        hit["selected"] = bool(hit.get("selected"))
        selected_hits.append(hit)
    record = {
        "kind": kind,
        "name": name,
        "query": query,
        "status": status,
        "hit_count": len(selected_hits),
        "selected_count": sum(1 for item in selected_hits if bool(item.get("selected"))),
        "hits": selected_hits,
    }
    if mcp:
        record["mcp"] = mcp
    return record


def _selected_evidence_snippets(
    evidence_records: list[dict[str, Any]],
    *,
    kind: str,
    name: str,
) -> list[str]:
    snippets: list[str] = []
    for record in evidence_records:
        if str(record.get("kind") or "") != kind or str(record.get("name") or "") != name:
            continue
        for hit in record.get("hits") or []:
            if not bool((hit or {}).get("selected")):
                continue
            snippet = str((hit or {}).get("snippet") or "").strip()
            if snippet:
                snippets.append(snippet.lstrip("- ").strip())
    return list(dict.fromkeys(snippets))


def _split_next_action(output: str) -> tuple[str, str]:
    text = str(output or "").strip()
    marker = "Next action:"
    index = text.find(marker)
    if index < 0:
        return text, ""
    return text[:index].strip(), text[index:].strip()


def _preserve_customer_history_phrase(
    final_output: str,
    evidence_records: list[dict[str, Any]],
    events: list[dict[str, Any]],
) -> tuple[str, bool]:
    text = str(final_output or "").strip()
    if not text:
        return text, False
    selected_history = _selected_evidence_snippets(
        evidence_records,
        kind="memory_lookup",
        name="customer_memory",
    )
    missing_history = [
        snippet
        for snippet in selected_history
        if not snippet_supported_by_output(snippet, text)
    ]
    if not missing_history:
        return text, False
    first_sentence, next_action = _split_next_action(text)
    if not first_sentence:
        return text, False
    phrase = missing_history[0].rstrip(" .")
    rewritten_first = first_sentence.rstrip()
    rewritten_first = rewritten_first.rstrip(".!? ").rstrip()
    rewritten_first = f'{rewritten_first} because "{phrase}".'
    rebuilt = rewritten_first if not next_action else f"{rewritten_first} {next_action}"
    events.append(
        runtime_event(
            "decision",
            "customer_history_phrase_injected",
            source="memory_lookup:customer_memory",
        )
    )
    return rebuilt, True


def _run_filesystem_lookup(
    *,
    required: bool,
    tool_name: str,
    query: str,
    project_root: Path,
    enabled_tools: set[str],
    enabled_mcps: set[str],
    workflow_trace: list[str],
    tool_calls: list[dict[str, Any]],
    events: list[dict[str, Any]],
    evidence_records: list[dict[str, Any]],
    lookup_fn: Any,
    use_context: bool,
) -> str:
    if not required:
        return ""
    if tool_name not in enabled_tools:
        events.append(_skipped_surface_event("retrieval", tool_name, mcp="filesystem", reason="tool_disabled"))
        return ""
    if "filesystem" not in enabled_mcps:
        events.append(_skipped_surface_event("retrieval", tool_name, mcp="filesystem", reason="mcp_disabled"))
        return ""
    hits = lookup_fn(query, project_root)
    context = _hits_text(hits) if use_context else ""
    workflow_trace.extend([f"tool:{tool_name}", "mcp:filesystem"])
    status = "success" if context else "empty"
    selected_hits = [{**item, "selected": bool(use_context)} for item in hits]
    tool_calls.append({"name": tool_name, "hits": len(hits), "selected": bool(context), "status": status, "mcp": "filesystem"})
    events.append(runtime_event("retrieval", tool_name, hits=len(hits), selected=bool(context), status=status, mcp="filesystem"))
    evidence_records.append(
        _evidence_record(
            kind="retrieval",
            name=tool_name,
            query=query,
            status=status,
            hits=selected_hits,
            mcp="filesystem",
        )
    )
    return context


def _run_customer_memory_lookup(
    *,
    customer_id: str | None,
    query: str,
    project_root: Path,
    enabled_tools: set[str],
    enabled_mcps: set[str],
    memory_skill_enabled: bool,
    workflow_trace: list[str],
    tool_calls: list[dict[str, Any]],
    events: list[dict[str, Any]],
    evidence_records: list[dict[str, Any]],
) -> str:
    if not customer_id:
        return ""
    if "customer_memory" not in enabled_tools:
        events.append(_skipped_surface_event("memory_lookup", "customer_memory", customer_id=customer_id, mcp="memory", reason="tool_disabled"))
        return ""
    if not memory_skill_enabled:
        events.append(_skipped_surface_event("memory_lookup", "customer_memory", customer_id=customer_id, mcp="memory", reason="skill_disabled"))
        return ""
    if "memory" not in enabled_mcps:
        events.append(_skipped_surface_event("memory_lookup", "customer_memory", customer_id=customer_id, mcp="memory", reason="mcp_disabled"))
        return ""
    history_hits = [{**item, "selected": True} for item in recall_customer_history_hits(project_root, customer_id, query)]
    customer_history = "\n".join(str(item.get("snippet") or "").strip() for item in history_hits if str(item.get("snippet") or "").strip())
    workflow_trace.extend(["tool:customer_memory", "mcp:memory"])
    status = "success" if customer_history else "empty"
    tool_calls.append({"name": "customer_memory", "customer_id": customer_id, "loaded": bool(customer_history), "status": status, "mcp": "memory"})
    evidence_records.append(
        _evidence_record(
            kind="memory_lookup",
            name="customer_memory",
            query=query,
            status=status,
            hits=history_hits,
            mcp="memory",
        )
    )
    events.append(
        runtime_event(
            "memory_lookup",
            "customer_memory",
            customer_id=customer_id,
            loaded=bool(customer_history),
            status=status,
            mcp="memory",
        )
    )
    return customer_history


def run_case(case: dict[str, Any], context: dict[str, Any], project_root: Path) -> dict[str, Any]:
    prompts = context.get("agent", {}).get("prompts", {}) or {}
    model = context.get("agent", {}).get("model", {}) or {}
    provider_name = str(model.get("provider") or "unknown")
    metadata = case.get("metadata") or {}
    enabled_tools = set(_enabled_names(context.get("agent", {}).get("tools", []) or []))
    enabled_skills = set(_enabled_names(context.get("agent", {}).get("skills", []) or []))
    enabled_plugins = set(_enabled_names(context.get("agent", {}).get("plugins", []) or []))
    enabled_mcps = set(_enabled_names(context.get("agent", {}).get("mcps", []) or []))
    system_prompt = read_prompt_file(project_root, prompts.get("system"))
    reviewer_prompt = read_prompt_file(project_root, prompts.get("reviewer"))
    customer_history_required = bool(metadata.get("requires_customer_memory"))
    memory_skill_enabled = any(name in enabled_skills for name in ("memory_recall", "history_recall"))

    workflow_trace = ["startup:prompt_load", "prompt:system"]
    events: list[dict[str, Any]] = [runtime_event("prompt_load", "system", loaded=bool(system_prompt))]
    if reviewer_prompt:
        workflow_trace.append("prompt:reviewer")
        events.append(runtime_event("prompt_load", "reviewer", loaded=True))
    if customer_history_required:
        events.append(runtime_event("decision", "customer_memory_required"))
    if memory_skill_enabled:
        events.append(runtime_event("decision", "memory_skill_enabled"))
    tool_calls: list[dict[str, Any]] = []
    evidence_records: list[dict[str, Any]] = []
    policy_context = ""
    incident_context = ""
    release_context = ""
    calendar_context = ""
    routing_context = ""
    team_context = ""
    customer_history = ""
    routing_history_required = bool(metadata.get("requires_routing_policy_search")) or bool(metadata.get("requires_team_directory_lookup"))

    query = str(case.get("input") or "")
    policy_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_policy_search")),
        tool_name="policy_search",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=policy_search,
        use_context=True,
    )
    incident_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_incident_lookup")),
        tool_name="incident_lookup",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=incident_lookup,
        use_context=True,
    )
    release_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_release_checklist_search")),
        tool_name="release_checklist_search",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=release_checklist_search,
        use_context="risk_review" in enabled_skills,
    )
    calendar_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_launch_calendar_lookup")),
        tool_name="launch_calendar_lookup",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=launch_calendar_lookup,
        use_context="launch_window_check" in enabled_skills,
    )
    routing_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_routing_policy_search")),
        tool_name="routing_policy_search",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=routing_policy_search,
        use_context="route_selection" in enabled_skills,
    )
    team_context = _run_filesystem_lookup(
        required=bool(metadata.get("requires_team_directory_lookup")),
        tool_name="team_directory_lookup",
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
        lookup_fn=team_directory_lookup,
        use_context="team_matching" in enabled_skills,
    )
    customer_history = _run_customer_memory_lookup(
        customer_id=str(metadata.get("customer_id") or "") or None,
        query=query,
        project_root=project_root,
        enabled_tools=enabled_tools,
        enabled_mcps=enabled_mcps,
        memory_skill_enabled=memory_skill_enabled,
        workflow_trace=workflow_trace,
        tool_calls=tool_calls,
        events=events,
        evidence_records=evidence_records,
    )

    if customer_history_required and not customer_history:
        events.append(runtime_event("decision", "customer_history_missing"))
        events.append(runtime_event("provider_request", "skipped", provider=provider_name, reason="missing_customer_history"))
        return {
            "final_output": "I need customer history.",
            "events": events,
            "evidence_records": evidence_records,
            "workflow_trace": workflow_trace,
            "tool_calls": tool_calls,
            "skills_used": [],
            "plugins_used": ["knowledge_base"] if tool_calls else [],
            "mcp_servers_used": sorted({str(call.get("mcp") or "") for call in tool_calls if str(call.get("mcp") or "").strip()}),
            "prompt_keys_used": ["system"] + (["reviewer"] if reviewer_prompt else []),
            "step_count": 1 + len(tool_calls) + (1 if reviewer_prompt else 0),
            "token_usage": {},
            "cost_estimate": 0.0,
            "errors": [],
            "metadata": {
                "provider": model.get("provider"),
                "model_name": model.get("name"),
                "customer_history_loaded": False,
                "live_call_skipped": True,
            },
        }

    context_sections = [f"Question:\n{case.get('input', '')}", f"Case facts:\n{_facts_text(metadata)}"]
    if customer_history_required or customer_history:
        history_heading = "Required customer-specific history" if customer_history_required and routing_history_required else "Selected customer-specific history"
        context_sections.append(f"{history_heading}:\n{customer_history or '(missing)'}")
    selected_contexts = [
        ("Selected policy context", policy_context),
        ("Selected incident context", incident_context),
        ("Selected release context", release_context),
        ("Selected launch calendar context", calendar_context),
        ("Selected routing context", routing_context),
        ("Selected team directory context", team_context),
    ]
    for heading, content in selected_contexts:
        if content:
            context_sections.append(f"{heading}:\n{content}")
    answer_contract = _answer_contract(customer_history_present=bool(customer_history_required or customer_history))
    history_guidance = ""
    if customer_history_required and routing_history_required:
        history_guidance = "When customer-specific history is required for the case, quote that exact history line after 'because' before the follow-up action. "
    messages = [{"role": "system", "content": system_prompt}]
    if reviewer_prompt:
        messages.append({"role": "system", "content": reviewer_prompt})
    messages.append(
        {
            "role": "user",
            "content": (
                "\n\n".join(context_sections)
                + "\n\n"
                + "Answer contract:\n"
                + answer_contract
                + "\n\n"
                + "Use only the supplied selected context. "
                + "When a selected source includes the decision phrase or required follow-up action, keep that exact phrase in the answer instead of paraphrasing it. "
                + "Do not collapse the next action into sentence 1. "
                + "Do not mention missing sections or unavailable tools. "
                + "If selected customer history is present, include one exact history phrase that explains or constrains the decision. "
                + history_guidance
                + "If both rule context and customer history apply, include one exact phrase from each source."
            ),
        }
    )

    events.append(
        runtime_event(
            "provider_request",
            "chat_completion",
            provider=provider_name,
            reviewer=bool(reviewer_prompt),
            message_count=len(messages),
        )
    )
    try:
        final_output, token_usage = _provider_response(model, messages)
        errors: list[str] = []
        events.append(
            runtime_event(
                "provider_response",
                "success",
                provider=provider_name,
                total_tokens=int(token_usage.get("total", 0) or 0),
            )
        )
    except (KeyError, urllib.error.HTTPError, urllib.error.URLError, TimeoutError, ValueError) as exc:
        final_output = ""
        token_usage = {}
        errors = [str(exc)]
        events.append(runtime_event("provider_response", "error", provider=provider_name))
    customer_history_phrase_injected = False
    if final_output and customer_history:
        final_output, customer_history_phrase_injected = _preserve_customer_history_phrase(
            final_output,
            evidence_records,
            events,
        )

    skills_used = []
    launch_calendar_checked = any(str(call.get("name") or "") == "launch_calendar_lookup" for call in tool_calls)
    if customer_history and "history_recall" in enabled_skills:
        skills_used.append("history_recall")
        workflow_trace.append("skill:history_recall")
    if customer_history and "memory_recall" in enabled_skills:
        skills_used.append("memory_recall")
        workflow_trace.append("skill:memory_recall")
    if policy_context and "policy_grounding" in enabled_skills:
        skills_used.append("policy_grounding")
        workflow_trace.append("skill:policy_grounding")
    if release_context and "risk_review" in enabled_skills:
        skills_used.append("risk_review")
        workflow_trace.append("skill:risk_review")
    if launch_calendar_checked and "launch_window_check" in enabled_skills:
        skills_used.append("launch_window_check")
        workflow_trace.append("skill:launch_window_check")
    if incident_context and "incident_triage" in enabled_skills:
        skills_used.append("incident_triage")
        workflow_trace.append("skill:incident_triage")
    if routing_context and "route_selection" in enabled_skills:
        skills_used.append("route_selection")
        workflow_trace.append("skill:route_selection")
    if team_context and "team_matching" in enabled_skills:
        skills_used.append("team_matching")
        workflow_trace.append("skill:team_matching")
    if reviewer_prompt and "response_review" in enabled_skills:
        skills_used.append("response_review")
        workflow_trace.append("skill:response_review")

    plugins_used = []
    if (policy_context or incident_context) and "knowledge_base" in enabled_plugins:
        plugins_used.append("knowledge_base")
        workflow_trace.append("plugin:knowledge_base")
    if (release_context or calendar_context) and "runbook_index" in enabled_plugins:
        plugins_used.append("runbook_index")
        workflow_trace.append("plugin:runbook_index")
    if (routing_context or team_context) and "directory_index" in enabled_plugins:
        plugins_used.append("directory_index")
        workflow_trace.append("plugin:directory_index")
    if incident_context and "incident_board" in enabled_plugins:
        plugins_used.append("incident_board")
        workflow_trace.append("plugin:incident_board")
    if customer_history and "workflow_memory" in enabled_plugins:
        plugins_used.append("workflow_memory")
        workflow_trace.append("plugin:workflow_memory")

    mcp_servers_used = []
    for call in tool_calls:
        mcp_name = str(call.get("mcp") or "").strip()
        if mcp_name:
            mcp_servers_used.append(mcp_name)
    mcp_servers_used = sorted(dict.fromkeys(mcp_servers_used))

    prompt_keys_used = ["system"]
    if reviewer_prompt:
        prompt_keys_used.append("reviewer")
        events.append(runtime_event("decision", "reviewer_enabled"))
    if customer_history:
        events.append(runtime_event("decision", "customer_history_loaded"))
    step_count = 1 + len(tool_calls) + (1 if reviewer_prompt else 0)
    if step_count > 3:
        events.append(runtime_event("budget", "step_heavy", step_count=step_count))
    if final_output:
        events.append(runtime_event("decision", "response_ready"))

    return {
        "final_output": final_output,
        "events": events,
        "evidence_records": evidence_records,
        "workflow_trace": workflow_trace,
        "tool_calls": tool_calls,
        "skills_used": skills_used,
        "plugins_used": plugins_used,
        "mcp_servers_used": mcp_servers_used,
        "prompt_keys_used": prompt_keys_used,
        "step_count": step_count,
        "token_usage": token_usage,
        "cost_estimate": 0.0,
        "errors": errors,
        "metadata": {
            "provider": model.get("provider"),
            "model_name": model.get("name"),
            "policy_context_loaded": bool(policy_context),
            "incident_context_loaded": bool(incident_context),
            "release_context_loaded": bool(release_context),
            "calendar_context_loaded": bool(calendar_context),
            "routing_context_loaded": bool(routing_context),
            "team_context_loaded": bool(team_context),
            "customer_history_loaded": bool(customer_history),
            "customer_history_phrase_injected": customer_history_phrase_injected,
        },
    }
