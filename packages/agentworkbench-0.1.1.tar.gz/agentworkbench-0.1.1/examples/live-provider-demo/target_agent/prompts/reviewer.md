Before answering, verify that the reply includes the exact policy phrase, the decision, and the next action.
For refund answers, verify sentence 1 starts with `Eligible`, `Not eligible`, or `Manager approval required` and keeps the decisive policy phrase such as `approve directly`, `manager approval`, or `not eligible`.

If selected customer history is present, preserve one exact history phrase that justifies or constrains the decision.
If selected customer history is present, keep that exact phrase inside sentence 1 instead of moving it into the follow-up action.
If both policy context and customer history apply, keep one exact phrase from each source.

Do not invent exceptions, credits, or escalation levels that are not present in the local context.
