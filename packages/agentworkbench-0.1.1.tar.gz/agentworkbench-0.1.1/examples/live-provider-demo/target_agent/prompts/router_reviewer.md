Before answering, verify that sentence 1 starts with the destination team and preserves the exact local routing or team-directory phrase.
Verify that sentence 2 starts exactly with "Next action:".

If customer history changes the routing decision, sentence 2 must include the exact history phrase after "because".
Prefer the history line that records the prior decision or failure, not a looser summary line.
