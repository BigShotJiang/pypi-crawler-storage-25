Before answering, verify that the reply includes the exact local release phrase, the decision, and a second sentence that starts with `Next action:`.
If a selected line says `ship in the current window`, `delay the release`, `rollback plan is approved`, or `notify finance operations`, require that exact phrase to appear in the final answer.
Reject drafts that say `ship now`, `cannot ship`, `reschedule`, or other paraphrases when the local evidence provides a more exact phrase.

Do not mention missing sections or invent launch policies that are not in the local context.
