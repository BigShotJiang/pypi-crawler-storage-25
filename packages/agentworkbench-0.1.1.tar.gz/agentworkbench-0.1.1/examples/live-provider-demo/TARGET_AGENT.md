# Live Provider Target Agent

This demo wraps a real provider-backed support agent for a fictional SaaS product called OrbitDesk.

- `target_agent/cli.py` loads the harness case and context.
- `target_agent/runtime.py` uses local tools and memory to build grounded context, then calls Groq or Cerebras through OpenAI-compatible chat completions.
- `target_agent/tools.py` searches refund and incident docs plus exposes an intentionally removable planner surface.
- `target_agent/memory.py` loads customer history for repeat-customer and VIP cases.
- `target_agent/prompts/system.md` keeps answers grounded and concise.
- `target_agent/prompts/reviewer.md` enforces exact policy phrases and the next action.
- `knowledge/*.md` and `knowledge/customer-notes/*.md` are the local source of truth for the agent.
