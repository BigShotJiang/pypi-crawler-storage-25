# Live Provider Demo

This demo uses real Groq and Cerebras chat completions to run a small support agent for a fictional SaaS product called OrbitDesk.

It is configured to load keys from the repo-local `.env.providers.local` file through `.agent-workbench/workbench.yaml`.

## Agent Variants

- `groq-support-baseline`: grounded in refund and incident docs, but has no customer-memory surface.
- `groq-support-grounded`: adds customer memory plus a reviewer prompt.
- `groq-release-no-risk-review` -> `groq-release-workflow`: a release gate pair where adding `risk_review` changes both the workflow trace and the final recommendation.
- `groq-router-no-history` -> `groq-router-workflow`: a routing pair where adding `history_recall` restores `customer_memory`, the `memory` MCP path, and the workflow steps needed for enterprise follow-ups.
- `cerebras-support-bloated`: keeps the same quality but carries an unused planner tool.
- `cerebras-support-pruned`: removes the unused planner tool after diagnosis.

## Run The Demo

```bash
cd examples/live-provider-demo
awb learn

# Baseline -> grounded improvement
awb run --agent-id groq-support-baseline --eval-id support-ops-agent --subset full
awb run --agent-id groq-support-grounded --eval-id support-ops-agent --subset full
awb compare --baseline <baseline-experiment-id> --candidate <grounded-experiment-id>
awb diagnose --experiment <grounded-experiment-id>
awb iterate --experiment <grounded-experiment-id>
awb run --agent-id groq-support-grounded --eval-id support-ops-agent --subset full --tag workflow
awb diagnose --experiment <grounded-experiment-id> --tag workflow --focus-limit 2
awb factorial --experiment <grounded-experiment-id> --factor prompts:reviewer --factor tools:customer_memory --factor mcps:memory --tag workflow
awb matrix --agent-id groq-support-grounded --agent-id cerebras-support-pruned --eval-id support-ops-agent --subset full

# Skill and workflow regression checks
awb run --agent-id groq-release-no-risk-review --eval-id release-gate-agent --subset full
awb run --agent-id groq-release-workflow --eval-id release-gate-agent --subset full
awb compare --baseline <release-bad-experiment-id> --candidate <release-good-experiment-id>
awb diagnose --experiment <release-bad-experiment-id>
awb iterate --experiment <release-bad-experiment-id>

awb run --agent-id groq-router-no-history --eval-id escalation-router-agent --subset full
awb run --agent-id groq-router-workflow --eval-id escalation-router-agent --subset full
awb compare --baseline <router-bad-experiment-id> --candidate <router-good-experiment-id>
awb diagnose --experiment <router-bad-experiment-id>
awb iterate --experiment <router-bad-experiment-id>

# Bloated variant -> diagnose -> prune
awb run --agent-id cerebras-support-bloated --eval-id support-ops-agent --subset full
awb compare --candidate <bloated-experiment-id> --best
awb diagnose --experiment <bloated-experiment-id>
awb iterate --experiment <bloated-experiment-id>
awb propose --experiment <bloated-experiment-id>
awb run --agent-id cerebras-support-pruned --eval-id support-ops-agent --subset full
awb compare --baseline <bloated-experiment-id> --candidate <pruned-experiment-id>
awb ablate --experiment <bloated-experiment-id>
```

Use `full` for live-provider optimization. Smoke runs are only for fast local debugging and are not useful for judging progress, promotion, or surface-level regressions.

Repeated live runs are supported with `awb run --repeat N`, and promotion can require stability summaries via the workbench gates, but that is intentionally expensive. Use it sparingly on high-confidence candidates or on narrower filtered slices before you spend on repeated full-suite runs.

The provider runtime emits explicit `events` for retrieval, memory lookup, provider request/response, reviewer enablement, and early skips. That gives the harness a stable decision trace even when providers or wrappers emit uneven raw telemetry.

## What This Shows

- a real external LLM can be wrapped by the command adapter and run against repo-local tools, prompts, and memory
- the harness can distinguish missing memory from grounded customer-history answers
- the harness can track tool, skill, plugin, MCP, prompt, explicit event, workflow-trace, token, and model changes across live iterations
- the harness can rank live variants on a Pareto frontier and show availability-vs-usage audits for the declared surfaces
- the harness can audit tool and MCP outcomes, not just availability or invocation counts
- the harness can run cross-provider matrices and small prompt/tool/MCP factorials on the same live suite
- the harness can slice live runs and diagnosis by case id, tag, or text match so provider debugging stays cheap
- the harness can require repeated-run stability before promotion when you are ready to spend on that confidence
- `awb status` will surface the newest matching stability series, matrix, and factorial artifacts for the filtered live stream so you can review the lane in one command, along with the latest tool and MCP recommendations for that benchmark stream
- the harness can catch score-neutral bloat and turn it into a pruning proposal
- the harness can ablate live prompt/tool/skill/plugin/MCP surfaces one at a time to see which ones are actually carrying the score
- the harness can turn diagnosis into measured iteration lanes with explicit tool, skill, plugin, MCP, workflow, prompt, token, and latency checks
