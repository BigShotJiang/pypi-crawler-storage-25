from __future__ import annotations

from agentworkbench.scorer_utils import score_output_quality, score_process_alignment


def score_cases(run_artifact: dict, case: dict) -> list[dict]:
    return [score_output_quality(run_artifact, case), score_process_alignment(run_artifact, case)]
