# Repo Brief: live-provider-demo

- Root: `/home/jamiemac/code_projects/agent-workbench/examples/live-provider-demo`
- File count: 23
- Languages: markdown, python
- Likely entrypoints: target_agent/cli.py
- Existing agent assets: target_agent/prompts/release_reviewer.md, target_agent/prompts/release_system.md, target_agent/prompts/reviewer.md, target_agent/prompts/router_reviewer.md, target_agent/prompts/router_system.md, target_agent/prompts/system.md
- Existing evaluation assets: none
- Provider hints: openai
- Likely env keys: CEREBRAS_API_KEY, GROQ_API_KEY

## Target Agent Candidates

- Prompt files: target_agent/prompts/release_reviewer.md, target_agent/prompts/release_system.md, target_agent/prompts/reviewer.md, target_agent/prompts/router_reviewer.md, target_agent/prompts/router_system.md, target_agent/prompts/system.md
- Tool files: target_agent/tools.py
- Memory or MCP files: target_agent/memory.py
- Test or eval files: none
- Confirmed owned files: .agent-workbench/evals/escalation-router-agent.jsonl, .agent-workbench/evals/release-gate-agent.jsonl, .agent-workbench/evals/support-ops-agent.jsonl, .agent-workbench/scorers/escalation-router-agent_default.py, .agent-workbench/scorers/release-gate-agent_default.py, .agent-workbench/scorers/support-ops-agent_default.py, knowledge/customer-notes/acme-vip.md, knowledge/customer-notes/zenith-enterprise.md, knowledge/incidents.md, knowledge/launch-calendar.md, knowledge/refunds.md, knowledge/release-checklist.md, knowledge/routing.md, knowledge/team-directory.md, target_agent/cli.py, target_agent/memory.py, target_agent/prompts/release_reviewer.md, target_agent/prompts/release_system.md, target_agent/prompts/reviewer.md, target_agent/prompts/router_reviewer.md, target_agent/prompts/router_system.md, target_agent/prompts/system.md, target_agent/runtime.py, target_agent/tools.py
- Unclaimed candidate files: none

## Suggested Questions

- What end-user tasks should the target agent handle reliably?
- Which failure modes are unacceptable for this target agent?
- What does a strong answer or workflow look like on the hardest user requests?
- Which prompts, tools, memory, plugins, or MCP integrations should the target agent rely on or avoid?
- Which files in the repo actually define the target agent behavior today?
- What latency, cost, or step-budget limits matter for this agent?

## Suggested Commands


## Optimization Start

- Learn the repo, confirm the target agent files, and capture expected behavior before editing code.
- Write down expected outputs, tool calls, skills, plugins, MCPs, prompt variants, and runtime guardrails in the approved brief.
- Prefer full eval runs for real optimization and promotion decisions. Use smoke subsets only for fast local debugging.
