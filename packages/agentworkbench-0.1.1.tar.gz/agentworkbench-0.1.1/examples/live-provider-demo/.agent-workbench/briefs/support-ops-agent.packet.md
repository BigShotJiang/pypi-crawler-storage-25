# Brief Packet: support-ops-agent

- Agent: `groq-support-grounded`
- Goal: Improve a live provider-backed support agent that answers refund, identity, incident, and repeat-customer questions from local policy docs.

## Learn The Repo First

- Read `.agent-workbench/discovery/repo-brief.md` before drafting evals.
- Confirm which local files and commands actually define the target agent behavior before editing anything.
- Inspect the confirmed owned files and surface paths before proposing any benchmark or code changes.

## Target Agent Files

- Confirmed owned files: .agent-workbench/evals/support-ops-agent.jsonl, .agent-workbench/scorers/support-ops-agent_default.py, knowledge/customer-notes/acme-vip.md, knowledge/incidents.md, knowledge/refunds.md, target_agent/cli.py, target_agent/memory.py, target_agent/prompts/reviewer.md, target_agent/prompts/system.md, target_agent/runtime.py, target_agent/tools.py
- Surface files: {'prompts': ['target_agent/prompts/system.md', 'target_agent/prompts/reviewer.md'], 'tools': ['target_agent/tools.py'], 'memory': ['target_agent/memory.py'], 'runtime': ['target_agent/cli.py', 'target_agent/runtime.py'], 'tests': ['knowledge/refunds.md', 'knowledge/incidents.md', 'knowledge/customer-notes/acme-vip.md', '.agent-workbench/evals/support-ops-agent.jsonl', '.agent-workbench/scorers/support-ops-agent_default.py']}
- Unclaimed candidate files: none
- Provider hints: openai
- Likely env keys: CEREBRAS_API_KEY, GROQ_API_KEY

## Interview The User

- Ask the user for the target job, failure modes, approval criteria, and runtime constraints.
- Collect representative end-user requests, workflows, and expected tool or memory usage before drafting evals.
- Confirm which required environment variables must be present to run the target agent locally.

## Likely Questions

- Can this customer get a refund?
- What should support do during an export incident?
- How should support respond to a VIP repeat issue?
- What end-user tasks should the target agent handle reliably?
- Which failure modes are unacceptable for this target agent?
- What does a strong answer or workflow look like on the hardest user requests?
- Which prompts, tools, memory, plugins, or MCP integrations should the target agent rely on or avoid?
- Which files in the repo actually define the target agent behavior today?
- What latency, cost, or step-budget limits matter for this agent?

## Likely Commands

- A customer renewed 10 days ago and wants a refund. What do I say?
- Multiple teams report export jobs stuck for 20 minutes. What should support do?
- A VIP customer hit the export bug again after yesterday's workaround. How should we respond?

## Rough Answer Outlines

- Question: A customer renewed 10 days ago and wants a refund. What do I say?
- Outline: State eligibility from the refund window, mention any approval threshold, and give the next action.

## Workflow Scenarios

- `refund-grounding`: Use policy search before answering refund or identity questions.
- `vip-memory`: Use customer memory before answering VIP repeat-contact questions.

## Optimization Surface

- Prompt variants: system, reviewer
- Preferred tools: policy_search, incident_lookup, customer_memory
- Preferred skills: policy_grounding, incident_triage, memory_recall
- Preferred plugins: knowledge_base, workflow_memory
- Preferred MCPs: filesystem, memory

## Definition Of Better

- Better: Answers use exact local policy phrases such as `verify identity`, `manager approval`, `Sev2`, and `P1`.
- Better: The agent uses customer memory on repeat-customer cases instead of guessing.
- Worse: The agent answers without local grounding.
- Worse: The agent adds unused surface that does not improve outcomes.
- Accept: Answers are grounded, concise, and include the right next action.
