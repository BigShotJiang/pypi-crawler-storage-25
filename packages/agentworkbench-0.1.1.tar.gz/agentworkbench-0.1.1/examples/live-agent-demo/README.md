# Live Agent Demo

This is the primary `agentworkbench` demo for the live-agent-first workflow.

It models the intended setup:

- a real local target agent lives in repo code under `target_agent/`
- `awb` wraps that target agent with thin agent specs in `.agent-workbench/agents/`
- baseline and candidate variants run through the same local entrypoint
- the benchmark, compare, diagnose, propose, and patch-template loop works against a real local runtime

The runtime is deterministic and does not require API keys. To adapt it to a real provider-backed agent, replace the stub logic in `target_agent/runtime.py`, set `required_env` in the agent spec, and update either the `entrypoints.command` wrapper or the in-process `entrypoints.python` callable if needed.

The demo runtime now emits explicit `events` in addition to tool, skill, plugin, MCP, and prompt usage so compares can explain the decision path, not just the surface counts.

The checked-in specs include both command-adapter and python-adapter variants so the telemetry and optimization contract can be exercised across multiple runtime integration styles.

## Run The Demo

```bash
cd examples/live-agent-demo
awb learn
awb brief packet --brief-id live-support-agent --agent-id live-support-candidate
awb run --agent-id live-support-baseline --eval-id live-support-agent --subset full
awb run --agent-id live-support-candidate --eval-id live-support-agent --subset full
awb compare --baseline <baseline-experiment-id> --candidate <candidate-experiment-id>
awb diagnose --experiment <candidate-experiment-id>
awb propose --experiment <candidate-experiment-id>
awb ablate --experiment <candidate-experiment-id>
awb patch-template --experiment <candidate-experiment-id>
```

## Files That Define The Target Agent

- `target_agent/cli.py`
- `target_agent/runtime.py`
- `target_agent/tools.py`
- `target_agent/memory.py`
- `target_agent/prompts/system.md`
- `target_agent/prompts/reviewer.md`

## Swap In A Real Provider

1. Replace the behavior tables in `target_agent/runtime.py` with your real provider-backed agent logic.
2. Add required keys such as `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` to `required_env` in the relevant `.agent-workbench/agents/*.yaml`.
3. Update `entrypoints.command` if your runtime should use a different module, script, or working directory.
4. Keep `owned_paths` and `surface_paths` pointed at the real prompt, tool, memory, runtime, and test files so `awb propose` and `awb patch-template` can target the right code.
5. Preserve or improve explicit `events`, `workflow_trace`, and surface-usage telemetry when swapping in a real agent so optimization runs stay interpretable.
6. Make the runtime actually respect enabled prompts, tools, skills, plugins, and MCPs so `awb ablate` can measure whether those surfaces matter.
