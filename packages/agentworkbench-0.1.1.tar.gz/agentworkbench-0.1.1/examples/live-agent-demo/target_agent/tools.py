from __future__ import annotations


def repo_search(query: str) -> str:
    return f"repo_search:{query}"


def task_planner(task: str) -> str:
    return f"task_planner:{task}"
