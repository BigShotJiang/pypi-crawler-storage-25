from __future__ import annotations


def recall_regression_note() -> str:
    return "workflow memory"
