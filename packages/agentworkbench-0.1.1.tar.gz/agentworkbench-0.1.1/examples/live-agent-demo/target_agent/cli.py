from __future__ import annotations

import json
import os
from pathlib import Path

from target_agent.runtime import run_case


def main() -> None:
    case_path = Path(os.environ["AWB_CASE_PATH"])
    context_path = Path(os.environ["AWB_CONTEXT_PATH"])
    output_path = Path(os.environ["AWB_OUTPUT_PATH"])
    case = json.loads(case_path.read_text(encoding="utf-8"))
    context = json.loads(context_path.read_text(encoding="utf-8"))
    project_root = Path(os.environ["AWB_PROJECT_ROOT"])
    variant = os.environ.get("DEMO_AGENT_VARIANT", "baseline")
    payload = run_case(case, context, variant, project_root)
    output_path.write_text(json.dumps(payload), encoding="utf-8")


if __name__ == "__main__":
    main()
