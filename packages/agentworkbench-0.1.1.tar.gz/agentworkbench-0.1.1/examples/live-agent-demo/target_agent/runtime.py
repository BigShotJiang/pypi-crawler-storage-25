from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.demo_helpers import read_prompt_file, runtime_event
from target_agent.memory import recall_regression_note
from target_agent.tools import repo_search, task_planner


def _base_events(
    *,
    strategy: str,
    tool_calls: list[dict[str, Any]],
    skills_used: list[str],
    mcp_servers_used: list[str],
    prompt_keys_used: list[str],
    step_count: int,
    metadata: dict[str, Any],
) -> list[dict[str, Any]]:
    events = [
        runtime_event("prompt_load", "system", loaded=bool(metadata.get("system_prompt_loaded"))),
        runtime_event("decision", strategy, variant=str(metadata.get("variant") or "unknown"), step_count=step_count),
    ]
    if bool(metadata.get("reviewer_prompt_loaded")):
        events.append(runtime_event("prompt_load", "reviewer", loaded=True))
    if "reviewer" in prompt_keys_used:
        events.append(runtime_event("decision", "reviewer_enabled"))
    if "memory" in mcp_servers_used or "memory_recall" in skills_used:
        events.append(runtime_event("decision", "memory_consulted"))
    if not tool_calls:
        events.append(runtime_event("decision", "clarify_first"))
    for call in tool_calls:
        name = str(call.get("name") or call.get("tool") or call.get("id") or "").strip()
        if not name:
            continue
        kind = "retrieval" if "search" in name else ("planning" if "planner" in name else "tool_use")
        extras = {
            key: value
            for key, value in call.items()
            if key not in {"name", "tool", "id"} and isinstance(value, (bool, float, int, str))
        }
        events.append(runtime_event(kind, name, **extras))
    if step_count > 2:
        events.append(runtime_event("budget", "step_heavy", step_count=step_count))
    return events


def _enabled_names(items: list[dict[str, Any]]) -> set[str]:
    names: set[str] = set()
    for item in items:
        if not item.get("enabled", True):
            continue
        name = item.get("name") or item.get("id")
        if name:
            names.add(str(name))
    return names


def _loaded_prompt_keys(prompts: dict[str, Any], project_root: Path) -> set[str]:
    keys: set[str] = set()
    for key, relative_path in prompts.items():
        if read_prompt_file(project_root, str(relative_path) if relative_path is not None else None):
            keys.add(str(key))
    return keys


def _tool_entry(name: str, key: str, value: str, enabled_tools: set[str]) -> list[dict[str, Any]]:
    if name not in enabled_tools:
        return []
    return [{"name": name, key: value}]


def _used_prompt_keys(*keys: str, available: set[str]) -> list[str]:
    return [key for key in keys if key in available]


def _base_payload(
    *,
    final_output: str,
    tool_calls: list[dict[str, Any]],
    skills_used: list[str],
    plugins_used: list[str],
    mcp_servers_used: list[str],
    prompt_keys_used: list[str],
    step_count: int,
    metadata: dict[str, Any],
    strategy: str,
) -> dict[str, Any]:
    return {
        "final_output": final_output,
        "events": _base_events(
            strategy=strategy,
            tool_calls=tool_calls,
            skills_used=skills_used,
            mcp_servers_used=mcp_servers_used,
            prompt_keys_used=prompt_keys_used,
            step_count=step_count,
            metadata=metadata,
        ),
        "tool_calls": tool_calls,
        "skills_used": skills_used,
        "plugins_used": plugins_used,
        "mcp_servers_used": mcp_servers_used,
        "prompt_keys_used": prompt_keys_used,
        "step_count": step_count,
        "token_usage": {"input": 120, "output": 80},
        "cost_estimate": 0.0,
        "metadata": metadata,
    }


def run_case(case: dict[str, Any], context: dict[str, Any], variant: str, project_root: Path) -> dict[str, Any]:
    case_id = str(case.get("id") or "")
    prompts = context.get("agent", {}).get("prompts", {}) or {}
    enabled_tools = _enabled_names(context.get("agent", {}).get("tools", []) or [])
    enabled_skills = _enabled_names(context.get("agent", {}).get("skills", []) or [])
    enabled_plugins = _enabled_names(context.get("agent", {}).get("plugins", []) or [])
    enabled_mcps = _enabled_names(context.get("agent", {}).get("mcps", []) or [])
    if not enabled_tools:
        enabled_tools = {"repo_search", "task_planner"}
    if not enabled_skills:
        enabled_skills = {"repo_grounding", "review_loop", "memory_recall"}
    if not enabled_plugins:
        enabled_plugins = {"repo_index", "workflow_memory"}
    if not enabled_mcps:
        enabled_mcps = {"filesystem", "memory"}
    loaded_prompt_keys = _loaded_prompt_keys(prompts, project_root)
    system_prompt = read_prompt_file(project_root, prompts.get("system"))
    reviewer_prompt = read_prompt_file(project_root, prompts.get("reviewer"))
    shared_metadata = {
        "variant": variant,
        "system_prompt_loaded": bool(system_prompt),
        "reviewer_prompt_loaded": bool(reviewer_prompt),
        "owned_paths": context.get("agent", {}).get("owned_paths", []),
    }

    if case_id == "live-support-output-1":
        if variant == "baseline" or "reviewer" not in loaded_prompt_keys:
            return _base_payload(
                final_output="The target agent uses a local runtime and repo search.",
                tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
                skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
                plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
                mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
                prompt_keys_used=_used_prompt_keys("system", available=loaded_prompt_keys),
                step_count=1,
                metadata=shared_metadata,
                strategy="repo_search_only",
            )
        return _base_payload(
            final_output="The target agent uses the local runtime, prompt files, and repo search.",
            tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
            skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
            plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
            mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
            prompt_keys_used=_used_prompt_keys("system", "reviewer", available=loaded_prompt_keys),
            step_count=2,
            metadata=shared_metadata,
            strategy="review_before_answer",
        )

    if case_id == "live-support-output-2":
        if variant == "baseline" or not ({"reviewer", "review_loop"} <= (loaded_prompt_keys | enabled_skills)):
            return _base_payload(
                final_output="Rerun the benchmark after checking the logs.",
                tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
                skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
                plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
                mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
                prompt_keys_used=_used_prompt_keys("system", available=loaded_prompt_keys),
                step_count=1,
                metadata=shared_metadata,
                strategy="rerun_first",
            )
        return _base_payload(
            final_output="Diagnose before rerun, then compare against the clean baseline.",
            tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
            skills_used=[name for name in ["repo_grounding", "review_loop"] if name in enabled_skills],
            plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
            mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
            prompt_keys_used=_used_prompt_keys("system", "reviewer", available=loaded_prompt_keys),
            step_count=2,
            metadata=shared_metadata,
            strategy="diagnose_then_rerun",
        )

    if case_id == "live-support-workflow-1":
        if variant == "baseline" or "task_planner" not in enabled_tools:
            return _base_payload(
                final_output="Use repo search, then explain the prompt files from the runtime path.",
                tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
                skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
                plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
                mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
                prompt_keys_used=_used_prompt_keys("system", available=loaded_prompt_keys),
                step_count=2,
                metadata=shared_metadata,
                strategy="repo_search_required",
            )
        return _base_payload(
            final_output="Read the runtime directly and answer from the system configuration.",
            tool_calls=_tool_entry("task_planner", "task", task_planner(case["input"]), enabled_tools),
            skills_used=[name for name in ["repo_grounding", "review_loop"] if name in enabled_skills],
            plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
            mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
            prompt_keys_used=_used_prompt_keys("system", "reviewer", available=loaded_prompt_keys),
            step_count=2,
            metadata=shared_metadata,
            strategy="planner_substitution",
        )

    if case_id == "live-support-workflow-2":
        memory_ready = {
            "task_planner",
            "memory_recall",
            "workflow_memory",
            "memory",
            "reviewer",
        } <= (enabled_tools | enabled_skills | enabled_plugins | enabled_mcps | loaded_prompt_keys)
        if variant == "baseline" or not memory_ready:
            return _base_payload(
                final_output="Workflow memory may help explain prior regressions.",
                tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
                skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
                plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
                mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
                prompt_keys_used=_used_prompt_keys("system", available=loaded_prompt_keys),
                step_count=2,
                metadata=shared_metadata,
                strategy="memory_suggested_not_used",
            )
        tool_calls = []
        tool_calls.extend(_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools))
        tool_calls.extend(_tool_entry("task_planner", "task", task_planner(case["input"]), enabled_tools))
        return _base_payload(
            final_output=f"{recall_regression_note()} can explain the prior regression and guide the next fix.",
            tool_calls=tool_calls,
            skills_used=[name for name in ["repo_grounding", "memory_recall", "review_loop"] if name in enabled_skills],
            plugins_used=[name for name in ["repo_index", "workflow_memory"] if name in enabled_plugins],
            mcp_servers_used=[name for name in ["filesystem", "memory"] if name in enabled_mcps],
            prompt_keys_used=_used_prompt_keys("system", "reviewer", available=loaded_prompt_keys),
            step_count=3,
            metadata=shared_metadata,
            strategy="memory_guided_answer",
        )

    if case_id == "live-support-step-budget":
        expanded_budget_ready = {"task_planner", "review_loop", "workflow_memory", "memory", "reviewer"} <= (
            enabled_tools | enabled_skills | enabled_plugins | enabled_mcps | loaded_prompt_keys
        )
        if variant == "baseline" or not expanded_budget_ready:
            return _base_payload(
                final_output="Here is the concise action plan: diagnose, patch, rerun.",
                tool_calls=_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools),
                skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
                plugins_used=["repo_index"] if "repo_index" in enabled_plugins else [],
                mcp_servers_used=["filesystem"] if "filesystem" in enabled_mcps else [],
                prompt_keys_used=_used_prompt_keys("system", available=loaded_prompt_keys),
                step_count=2,
                metadata=shared_metadata,
                strategy="concise_plan",
            )
        tool_calls = []
        tool_calls.extend(_tool_entry("repo_search", "query", repo_search(case["input"]), enabled_tools))
        tool_calls.extend(_tool_entry("task_planner", "task", task_planner(case["input"]), enabled_tools))
        return _base_payload(
            final_output="Start by expanding the plan with extra review steps before touching the benchmark.",
            tool_calls=tool_calls,
            skills_used=[name for name in ["repo_grounding", "review_loop"] if name in enabled_skills],
            plugins_used=[name for name in ["repo_index", "workflow_memory"] if name in enabled_plugins],
            mcp_servers_used=[name for name in ["filesystem", "memory"] if name in enabled_mcps],
            prompt_keys_used=_used_prompt_keys("system", "reviewer", available=loaded_prompt_keys),
            step_count=4,
            metadata=shared_metadata,
            strategy="step_budget_expanded",
        )

    return _base_payload(
        final_output="I need a clarifying question before changing anything.",
        tool_calls=[],
        skills_used=["repo_grounding"] if "repo_grounding" in enabled_skills else [],
        plugins_used=[name for name in (["repo_index"] if variant == "baseline" else ["repo_index", "workflow_memory"]) if name in enabled_plugins],
        mcp_servers_used=[name for name in (["filesystem"] if variant == "baseline" else ["filesystem", "memory"]) if name in enabled_mcps],
        prompt_keys_used=_used_prompt_keys(*(["system"] if variant == "baseline" else ["system", "reviewer"]), available=loaded_prompt_keys),
        step_count=1,
        metadata=shared_metadata,
        strategy="clarify_before_change",
    )


def run_case_python(case: dict[str, Any], context: dict[str, Any], project_root: Path, **_: Any) -> dict[str, Any]:
    runtime_env = (((context.get("agent") or {}).get("runtime") or {}).get("env") or {})
    variant = str(runtime_env.get("DEMO_AGENT_VARIANT") or "baseline")
    return run_case(case, context, variant, project_root)
