from __future__ import annotations

from agentworkbench.scorers.workflow import score_conversation_turns


def _surface_names(run_artifact: dict, key: str) -> list[str]:
    if key == "tools_used":
        tool_calls = run_artifact.get("tool_calls") or []
        names = []
        for item in tool_calls:
            name = item.get("name") or item.get("tool") or item.get("id")
            if name:
                names.append(str(name))
        return sorted(set(names))
    return sorted(set(str(item) for item in (run_artifact.get(key) or [])))


def _output_score(run_artifact: dict, case: dict) -> dict:
    final_output = (run_artifact.get("final_output") or "").strip()
    expected = (case.get("expected") or "").strip()
    if expected:
        passed = expected.lower() in final_output.lower()
        reason = "expected text present" if passed else "expected text missing"
        value = 1.0 if passed else 0.0
    else:
        passed = bool(final_output)
        reason = "non-empty output" if passed else "empty output"
        value = 1.0 if passed else 0.0
    return {
        "name": "output_quality",
        "value": value,
        "passed": passed,
        "reason": reason,
    }


def _process_score(run_artifact: dict, case: dict) -> dict:
    metadata = case.get("metadata") or {}
    expectations = metadata.get("process_expectations") or {}
    hints = metadata.get("process_hints") or {}
    used = {
        "required_tools": _surface_names(run_artifact, "tools_used"),
        "required_skills": _surface_names(run_artifact, "skills_used"),
        "required_plugins": _surface_names(run_artifact, "plugins_used"),
        "required_mcps": _surface_names(run_artifact, "mcp_servers_used"),
        "required_prompt_keys": _surface_names(run_artifact, "prompt_keys_used"),
    }
    failures = []
    for expectation_key, used_values in used.items():
        expected_values = [str(item) for item in expectations.get(expectation_key, [])]
        if expected_values and not set(expected_values) & set(used_values):
            failures.append(f"missing {expectation_key}: {', '.join(expected_values)}")
    forbidden_mapping = {
        "forbidden_tools": used["required_tools"],
        "forbidden_skills": used["required_skills"],
        "forbidden_plugins": used["required_plugins"],
        "forbidden_mcps": used["required_mcps"],
        "forbidden_prompt_keys": used["required_prompt_keys"],
    }
    for expectation_key, used_values in forbidden_mapping.items():
        forbidden_values = [str(item) for item in expectations.get(expectation_key, [])]
        matched = sorted(set(forbidden_values) & set(used_values))
        if matched:
            failures.append(f"forbidden {expectation_key}: {', '.join(matched)}")
    max_step_count = expectations.get("max_step_count")
    step_count = int(run_artifact.get("step_count") or 0)
    if max_step_count is not None and step_count > int(max_step_count):
        failures.append(f"step_count {step_count} exceeds max_step_count {int(max_step_count)}")
    if failures:
        return {
            "name": "process_alignment",
            "value": 0.0,
            "passed": False,
            "reason": "; ".join(failures),
        }
    hint_mapping = {
        "preferred_tools": used["required_tools"],
        "preferred_skills": used["required_skills"],
        "preferred_plugins": used["required_plugins"],
        "preferred_mcps": used["required_mcps"],
        "preferred_prompt_keys": used["required_prompt_keys"],
    }
    matched_hints = []
    available_hints = []
    for hint_key, used_values in hint_mapping.items():
        hint_values = [str(item) for item in hints.get(hint_key, [])]
        if hint_values:
            available_hints.append(hint_key)
            if set(hint_values) & set(used_values):
                matched_hints.append(hint_key)
    if available_hints and matched_hints:
        return {
            "name": "process_alignment",
            "value": 1.0,
            "passed": True,
            "reason": f"matched preferred surfaces: {', '.join(matched_hints)}",
        }
    if available_hints:
        return {
            "name": "process_alignment",
            "value": 0.5,
            "passed": True,
            "reason": "no preferred surfaces were observed in telemetry",
        }
    return {
        "name": "process_alignment",
        "value": 1.0,
        "passed": True,
        "reason": "no explicit process constraints",
    }


def score_cases(run_artifact: dict, case: dict) -> list[dict]:
    scores = [_output_score(run_artifact, case), _process_score(run_artifact, case)]
    turn_scores = score_conversation_turns(run_artifact, case)
    scores.extend(turn_scores)
    return scores
