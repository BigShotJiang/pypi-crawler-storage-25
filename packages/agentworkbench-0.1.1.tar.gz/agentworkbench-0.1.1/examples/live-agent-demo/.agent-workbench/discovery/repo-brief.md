# Repo Brief: live-agent-demo

- Root: `/home/jamiemac/code_projects/agent-workbench/examples/live-agent-demo`
- File count: 10
- Languages: python, markdown
- Likely entrypoints: target_agent/cli.py
- Existing agent assets: target_agent/prompts/reviewer.md, target_agent/prompts/system.md
- Existing evaluation assets: none
- Provider hints: none
- Likely env keys: ANTHROPIC_API_KEY, OPENAI_API_KEY

## Target Agent Candidates

- Prompt files: target_agent/prompts/reviewer.md, target_agent/prompts/system.md
- Tool files: target_agent/tools.py
- Memory or MCP files: target_agent/memory.py
- Test or eval files: none
- Confirmed owned files: .agent-workbench/evals/live-support-agent.jsonl, .agent-workbench/scorers/live-support-agent_default.py, target_agent/cli.py, target_agent/memory.py, target_agent/prompts/reviewer.md, target_agent/prompts/system.md, target_agent/runtime.py, target_agent/tools.py
- Unclaimed candidate files: none

## Suggested Questions

- What end-user tasks should the target agent handle reliably?
- Which failure modes are unacceptable for this target agent?
- What does a strong answer or workflow look like on the hardest user requests?
- Which prompts, tools, memory, plugins, or MCP integrations should the target agent rely on or avoid?
- Which files in the repo actually define the target agent behavior today?
- What latency, cost, or step-budget limits matter for this agent?

## Suggested Commands


## Optimization Start

- Learn the repo, confirm the target agent files, and capture expected behavior before editing code.
- Write down expected outputs, tool calls, skills, plugins, MCPs, prompt variants, and runtime guardrails in the approved brief.
- Prefer full eval runs for real optimization and promotion decisions. Use smoke subsets only for fast local debugging.
