# Target Agent

This demo target agent is a local support agent that explains how the repo is wired and recommends the next action after evaluation failures.

The target agent deliberately has two variants:

- `live-support-baseline`
- `live-support-candidate`

Both variants invoke the same local runtime in `target_agent/cli.py`. The thin `AgentSpec` wrapper changes the available prompts, tools, plugins, MCPs, and runtime env so the benchmark can compare behavior changes without pretending that the agent spec is the implementation itself.
