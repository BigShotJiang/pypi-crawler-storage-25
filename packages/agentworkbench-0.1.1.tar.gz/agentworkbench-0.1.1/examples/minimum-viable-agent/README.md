# Minimum Viable Agent (MVA) Template

This example demonstrates the recommended structure for building agents with Agent Workbench. It uses the `command` adapter to bridge the harness with your agent code.

## Structure

- **`target_agent/`**: Your agent logic.
    - `cli.py`: The entrypoint CLI that reads AWB environment variables.
    - `runtime.py`: Your agent's core decision loop and provider integration.
    - `tools.py`: Modular tools available to your agent.
- **`.agent-workbench/`**: AWB configuration.
    - `agents/mva-agent.yaml`: Agent specification (adapter, model, prompts, tools).
    - `evals/mva-eval.jsonl`: Evaluation cases (inputs, expected outputs, rubrics).
    - `workbench.yaml`: Project-wide settings (env files, gates).

## Getting Started

1. **Install Dependencies**:
   ```bash
   pip install agent-workbench langchain-openai
   ```

2. **Set Environment Variables**:
   Create a `.env` file or export your keys:
   ```bash
   export OPENAI_API_KEY="your-key"
   ```

3. **Run a Benchmark**:
   ```bash
   awb run --agent-id mva-agent --eval-id mva-eval
   ```

4. **Diagnose Results**:
   ```bash
   awb diagnose --agent-id mva-agent --eval-id mva-eval
   ```

## Why this structure?
- **Decoupling**: The AWB CLI (`awb`) handles orchestration, while your agent code remains isolated in `target_agent/`.
- **Observability**: By emitting artifacts like `events` and `evidence_records`, you get high-fidelity traces for every run.
- **Portability**: This structure makes it easy to move between different LLM providers (e.g., OpenAI, Anthropic, Cerebras) without changing your harness configuration.
