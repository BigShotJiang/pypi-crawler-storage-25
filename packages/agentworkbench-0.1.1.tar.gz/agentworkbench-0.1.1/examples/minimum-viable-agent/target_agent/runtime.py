from __future__ import annotations

import time
from pathlib import Path
from typing import Any


def run_case(
    case: dict[str, Any],
    context: dict[str, Any],
    project_root: Path,
) -> dict[str, Any]:
    """Execute one eval case and return an AWB run-artifact payload."""
    user_input = str(case.get("input", ""))
    
    # 1. Simulate some "thought" process
    events = [
        {"kind": "startup", "label": "initializing", "timestamp_ms": int(time.time() * 1000)},
        {"kind": "decision", "label": "thinking", "timestamp_ms": int(time.time() * 1000)},
    ]
    
    # 2. Dummy response logic (normally you'd call an LLM here)
    if "2+2" in user_input:
        final_output = "2+2 is 4."
    elif "France" in user_input:
        final_output = "The capital of France is Paris."
    else:
        final_output = f"I received your input: {user_input}"

    # 3. Return a structure that AWB understands
    return {
        "final_output": final_output,
        "events": events,
        "evidence_records": [],
        "workflow_trace": ["startup", "thinking", "response"],
        "tool_calls": [],
        "latency_ms": 100,
        "errors": [],
    }
