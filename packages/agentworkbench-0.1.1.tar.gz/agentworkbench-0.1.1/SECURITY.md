# Security Policy

## Supported Versions
We support the latest minor release on the `main` branch. Security fixes are
released as patch versions when needed.

## Reporting a Vulnerability
Please report security issues privately.

Preferred options:
1. Open a GitHub Security Advisory for this repository.
2. Email the maintainers at `security@agentworkbench.dev`.

If neither option is available, contact the maintainers through the project
channels listed in the README and ask for a secure reporting path.

We will acknowledge receipt within 72 hours and provide a timeline for
investigation and remediation.
