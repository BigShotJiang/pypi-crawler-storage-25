# Agent Workbench CLI - Bash Completion
#
# Install: source this file or add to ~/.bashrc
#   source /path/to/awb_completion.bash
#
# Or copy to /etc/bash_completion.d/awb

_awb_completions() {
    local cur="${COMP_WORDS[COMP_CWORD]}"
    local prev="${COMP_WORDS[COMP_CWORD-1]}"
    local commands="init learn brief evals run run-chain run-workflow compare check status next diagnose propose iterate optimize ablate matrix factorial patch-template promote release adapters benchmarks redteam human-review artifacts scorer-audit migrate doctor traces"
    local brief_commands="start draft finalize packet"
    local evals_commands="generate expand review approve export import"
    local benchmarks_commands="register list show check diff install"
    local redteam_commands="generate report"
    local human_review_commands="queues answers answer apply"
    local artifacts_commands="show export review"
    local show_commands="experiment case compare"
    local run_commands="chain workflow replay"
    local traces_commands="validate explain"

    COMPREPLY=()

    if [[ ${COMP_CWORD} -eq 1 ]]; then
        COMPREPLY=($(compgen -W "${commands}" -- "${cur}"))
        return 0
    fi

    local cmd="${COMP_WORDS[1]}"

    case "${cmd}" in
        brief)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${brief_commands}" -- "${cur}"))
            fi
            ;;
        evals)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${evals_commands}" -- "${cur}"))
            fi
            ;;
        run)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${run_commands}" -- "${cur}"))
            fi
            ;;
        benchmarks)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${benchmarks_commands}" -- "${cur}"))
            fi
            ;;
        redteam)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${redteam_commands}" -- "${cur}"))
            fi
            ;;
        human-review)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${human_review_commands}" -- "${cur}"))
            fi
            ;;
        artifacts)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${artifacts_commands}" -- "${cur}"))
                return 0
            fi
            if [[ ${COMP_CWORD} -eq 3 && "${COMP_WORDS[2]}" == "show" ]]; then
                COMPREPLY=($(compgen -W "${show_commands}" -- "${cur}"))
            fi
            ;;
        traces)
            if [[ ${COMP_CWORD} -eq 2 ]]; then
                COMPREPLY=($(compgen -W "${traces_commands}" -- "${cur}"))
            fi
            ;;
        compare|check|status|next|diagnose|propose|iterate|optimize|ablate|matrix|factorial|patch-template|promote|release|adapters|scorer-audit|migrate|doctor|run-chain|run-workflow)
            # Common arguments
            local args="--help --format"
            COMPREPLY=($(compgen -W "${args}" -- "${cur}"))
            ;;
    esac

    return 0
}

complete -F _awb_completions awb
