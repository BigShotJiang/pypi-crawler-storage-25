# Contributing to Agent Workbench

## Development Setup

Create a virtual environment and install the development extras:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -U pip
python -m pip install -e ".[dev]"
```

## Common Commands

```bash
make test
make lint
make build
```

## Quality Standards

- **CLI Stability**: Keep the CLI stable and additive. Prefer new subcommands or flags over breaking existing artifact contracts.
- **File-First Workflow**: Reports and machine-readable payloads should remain easy for coding agents to inspect directly from the repo.
- **Telemetry Hygiene**: Preserve the stable telemetry and provenance tracking contracts. Any change to event shapes must be backward compatible.
- **Modularity**: Keep `runner.py` under the 1800-line target. Decompose complex logic into sub-modules (e.g., `runner_compare.py`, `report_html.py`).
- **Public Surface**: Always update `__init__.py`'s `__all__` when adding new stable functionality to the SDK surface.

## Extension & Plugin Development

When adding a new extension point:
1. Define the abstract base class in `agentworkbench.extensions.base`.
2. Add the discovery logic to `agentworkbench.extensions.loader`.
3. Provide a reference implementation if applicable.
4. Update the `README.md` "Extension SDK" section.

## Expectations

- Add or update tests with any behavior change, especially around artifact layout, compare semantics, or CLI output.
- Use `JudgedScore` for all model-based or complex heuristic evaluation metrics to ensure auditability.
- Maintain the local-first, low-dependency philosophy. Avoid adding heavy new dependencies unless absolutely necessary.
- Documentation should be code-grounded and kept in sync with implementation changes.
