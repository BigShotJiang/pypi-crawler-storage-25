# Codex Agent Guide

This guide is written for a downstream Codex agent using Agent Workbench (`awb`) to design, evaluate, and optimize another repo-local agent. Treat `awb` as the source of truth for briefs, evals, runs, comparisons, loop-readiness checks, proposals, patch plans, and promotion gates.

## Operating Principles

- Start from repo facts. Run `awb learn` before drafting a behavior brief or editing target-agent surfaces.
- Do not optimize against an unapproved benchmark. Briefs and eval suites must be approved before experiments drive changes.
- Use `full` runs for optimization and promotion decisions. Use `smoke` only for fast debugging.
- Keep benchmark drift explicit. If a brief, eval, scorer, or split changes, call it out before comparing results.
- Treat prompts, tools, skills, plugins, MCPs, workflows, and runtime entrypoints as first-class surfaces.
- Do not add deterministic fallbacks, case-id maps, exact expected-output shortcuts, or silent canned answers.
- Run `awb check` before promotion and whenever topology, eval contracts, or target runtime code changes.

## First-Time Setup In A Target Repo

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -e /path/to/agent-workbench

awb init
awb learn
awb status
```

`awb init` creates `.agent-workbench/`. The important subdirectories are:

- `.agent-workbench/agents/`: target-agent specs.
- `.agent-workbench/briefs/`: approved behavior contracts.
- `.agent-workbench/evals/`: eval cases, suite metadata, and splits.
- `.agent-workbench/scorers/`: scorer code.
- `.agent-workbench/runs/`: experiment artifacts.
- `.agent-workbench/reports/`: human-readable and JSON reports.

## Canonical Optimization Loop

Use this sequence unless the user explicitly asks for a narrower operation:

```bash
awb learn
awb brief start --agent-id <agent-id>
awb brief packet --brief-id <brief-id> --agent-id <agent-id>
awb brief finalize --brief-id <brief-id>
awb evals generate --brief-id <brief-id> --eval-id <eval-id>
awb evals review --eval-id <eval-id>
awb evals approve --eval-id <eval-id>
awb run --agent-id <agent-id> --eval-id <eval-id> --subset full
awb check --agent-id <agent-id> --eval-id <eval-id> --subset full
awb compare --candidate <experiment-id> --best
awb diagnose --experiment <experiment-id>
awb propose --experiment <experiment-id>
awb patch-template --proposal-id <proposal-id>
```

After implementing a patch, rerun:

```bash
awb run --agent-id <agent-id> --eval-id <eval-id> --subset full
awb check --experiment <new-experiment-id>
awb compare --candidate <new-experiment-id> --best
awb diagnose --experiment <new-experiment-id>
```

Promote only when the comparison gates and loop-readiness gate pass:

```bash
awb promote --experiment <new-experiment-id>
```

## Loop-Readiness Checks

`awb check` is the guardrail for long-running Codex optimization loops. It writes:

- `.agent-workbench/reports/check-<target>.json`
- `.agent-workbench/reports/check-<target>.md`
- `.agent-workbench/reports/check-latest.json`
- `.agent-workbench/reports/check-latest.md`

Common forms:

```bash
awb check
awb check --agent-id <agent-id> --eval-id <eval-id> --subset full
awb check --experiment <experiment-id>
awb check --workflow-file <workflow-file> --eval-id <eval-id> --subset full
awb check --chain-agent-id <agent-a> --chain-agent-id <agent-b> --eval-id <eval-id> --subset full
awb check --format text --fail-on none
```

Severity behavior:

- Default `--fail-on critical`.
- `critical` findings block default check exit and promotion when `loop_checks.block_promotion_on_critical` is true.
- `high`, `medium`, `warning`, and `info` findings are actionable hints unless the caller raises `--fail-on`.

Check categories:

| Category | Purpose |
| --- | --- |
| `code_structure` | Finds monolithic target files, long functions/classes, and undeclared/smeared target surfaces. |
| `agent_topology` | Flags over-delegation, missing routing/handoff structure, workflow loops, dead ends, duplicate visits, and unmatched routes. |
| `eval_contract` | Checks process expectations, tool/MCP declarations, and rationale for required/forbidden process behavior. |
| `deterministic_fallback` | Flags case-id shortcuts, exact expected-output strings in target runtime code, and canned final-output fallbacks. |
| `loop_hygiene` | Surfaces draft evals, benchmark drift, smoke-only decisions, missing promoted baselines, review items, gate failures, and scorer-audit issues. |

## Eval Contract Metadata

When a case expects process behavior, include the reason. Missing rationale is allowed for backward compatibility but will be flagged.

```json
{
  "metadata": {
    "process_expectations": {
      "required_tools": ["repo_search"],
      "required_mcps": ["filesystem"],
      "rationale": "The case asks for repo-grounded facts that cannot be verified from the prompt alone.",
      "rationales": {
        "required_tools.repo_search": "Needed to inspect local implementation references.",
        "required_mcps.filesystem": "Needed to read local files rather than answer from memory."
      }
    }
  }
}
```

Use specific rationales when an expectation is not obvious from the brief, case input, expected behavior, or workflow scenario.

## Agent Spec Checklist

A useful agent spec names every surface the benchmark can expect:

```yaml
id: repo-agent
adapter: command
instructions:
  - Answer from repo evidence before making implementation claims.
prompts:
  system: target_agent/prompts/system.md
tools:
  - name: repo_search
    enabled: true
mcps:
  - name: filesystem
    enabled: true
owned_paths:
  - target_agent/runtime.py
surface_paths:
  prompts:
    - target_agent/prompts/system.md
  runtime:
    - target_agent/runtime.py
entrypoints:
  command:
    argv:
      - python3
      - -m
      - target_agent
    cwd: .
```

Use `owned_paths`, `owned_globs`, and `surface_paths` so `awb check` can inspect the target agent rather than the whole repo.

## Runtime Telemetry Contract

Command and Python adapters should write a JSON payload that includes enough telemetry to explain behavior:

```json
{
  "final_output": "answer returned to the user",
  "events": ["prompt:system", "tool:repo_search"],
  "workflow_trace": ["startup:prompt_load", "tool:repo_search"],
  "tool_calls": [{"name": "repo_search"}],
  "mcp_servers_used": ["filesystem"],
  "prompt_keys_used": ["system"],
  "evidence_records": [
    {"source": "repo_search", "path": "agent.py", "snippet": "relevant fact"}
  ],
  "step_count": 2
}
```

Do not fabricate telemetry. If a tool was not actually called, do not report it as used.

## Multi-Agent And Workflow Use

Prefer one agent when the eval cases are single-step and do not require routing, handoffs, specialist tools, or workflow sequencing.

Use a chain when sequential specialization is part of the task:

```bash
awb run chain \
  --agent-id planner \
  --agent-id implementer \
  --agent-id reviewer \
  --eval-id <eval-id> \
  --subset full
```

Use a workflow when route selection matters:

```bash
awb run workflow \
  --workflow-file support-router \
  --eval-id <eval-id> \
  --subset full
```

`awb run-workflow` is kept as a compatibility alias for `awb run workflow`.

## Mutation Workflow

Use proposals and patch templates to keep edits bounded:

```bash
awb diagnose --experiment <experiment-id>
awb propose --experiment <experiment-id>
awb patch-template --proposal-id <proposal-id>
```

Proposal categories include:

- `retrieval_quality`
- `prompt_grounding`
- `surface_contract`
- `tool_routing`
- `benchmark_hygiene`
- `stability_validation`
- `code_structure`
- `agent_topology`
- `eval_contract`
- `deterministic_fallback`

Patch templates include target files, target paths, expected effects, acceptance checks, validation commands, and risks. Follow the template unless the user explicitly redirects.

## Promotion Rules

Before promotion:

```bash
awb check --experiment <experiment-id>
awb compare --candidate <experiment-id> --best
awb status --eval-id <eval-id> --subset full
```

Promotion should fail if:

- The benchmark is dirty and clean benchmark gates are required.
- The candidate regresses beyond configured gates.
- `loop_readiness` has critical findings.
- The decision is based only on smoke results.

## Fast Command Reference

| Goal | Command |
| --- | --- |
| Discover repo surfaces | `awb learn` |
| Create behavior contract | `awb brief start --agent-id <id>` |
| Show agent interview packet | `awb brief packet --brief-id <id> --agent-id <id>` |
| Generate evals | `awb evals generate --brief-id <id> --eval-id <id>` |
| Approve evals | `awb evals approve --eval-id <id>` |
| Run agent | `awb run --agent-id <id> --eval-id <id> --subset full` |
| Run chain | `awb run chain --agent-id <a> --agent-id <b> --eval-id <id> --subset full` |
| Run workflow | `awb run workflow --workflow-file <file> --eval-id <id> --subset full` |
| Check loop readiness | `awb check --agent-id <id> --eval-id <id> --subset full` |
| Compare to best | `awb compare --candidate <experiment-id> --best` |
| Diagnose | `awb diagnose --experiment <experiment-id>` |
| Propose mutation | `awb propose --experiment <experiment-id>` |
| Create patch checklist | `awb patch-template --proposal-id <proposal-id>` |
| Promote | `awb promote --experiment <experiment-id>` |
| Release summary | `awb release` |

