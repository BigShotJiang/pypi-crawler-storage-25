# Release And Laptop Setup

This document explains how to validate, build, release, and install Agent Workbench on another machine.

## Local Release Gates

Run these from the repo root before cutting a release:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"

ruff check .
mypy
pytest -q
python -m build
python -m twine check dist/*
```

On Debian/Ubuntu, `python3 -m venv` requires the `python3-venv` package. If that is not available but `uv` is installed, use:

```bash
uv venv .venv
. .venv/bin/activate
uv pip install -e ".[dev]"
```

The short Make targets are:

```bash
make install-dev
make lint
make typecheck
make test
make build
```

`make quality` also runs `vulture` and coverage. Use it when you want the stricter project hygiene pass.

## Version And Changelog

Before publishing:

1. Update `agentworkbench/__init__.py` `__version__`.
2. Move `CHANGELOG.md` entries from `Unreleased` into a dated version section.
3. Rebuild the package after the version change.
4. Install the built wheel in a fresh virtualenv and run `awb --version`.

Example:

```bash
python -m build
python -m pip install --force-reinstall dist/agentworkbench-<version>-py3-none-any.whl
awb --version
```

## Test A Built Wheel

Use a clean temporary environment:

```bash
tmpdir="$(mktemp -d)"
python3 -m venv "$tmpdir/venv"
. "$tmpdir/venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install dist/agentworkbench-<version>-py3-none-any.whl
awb --help
python -m agentworkbench --help
```

Run a tiny smoke project:

```bash
workdir="$(mktemp -d)"
cd "$workdir"
awb init
awb learn
awb status
awb check --format text --fail-on none
```

## Publish To PyPI

For TestPyPI:

```bash
python -m build
python -m twine check dist/*
python -m twine upload --repository testpypi dist/*
```

For PyPI:

```bash
python -m twine upload dist/*
```

After publishing:

```bash
python3 -m venv /tmp/awb-release-check
. /tmp/awb-release-check/bin/activate
python -m pip install --upgrade pip
python -m pip install agentworkbench==<version>
awb --version
awb --help
```

## Install On A Work Laptop

Choose one of these paths.

### Option A: Install From A Wheel

Build the wheel on a machine with the repo:

```bash
python -m build
```

Move `dist/agentworkbench-<version>-py3-none-any.whl` to the laptop, then:

```bash
python3 -m venv ~/.venvs/agentworkbench
. ~/.venvs/agentworkbench/bin/activate
python -m pip install --upgrade pip
python -m pip install /path/to/agentworkbench-<version>-py3-none-any.whl
awb --help
```

If the laptop blocks global Python installs or lacks `python3-venv`, use `uv` instead:

```bash
uv venv ~/.venvs/agentworkbench
. ~/.venvs/agentworkbench/bin/activate
uv pip install /path/to/agentworkbench-<version>-py3-none-any.whl
awb --help
```

### Option B: Install From A Git Checkout

```bash
git clone <repo-url> ~/code/agent-workbench
cd ~/code/agent-workbench
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
awb --help
```

Use editable install when you want to iterate on the package itself.

### Option C: Install With pipx

This is convenient if the laptop already has `pipx`:

```bash
pipx install /path/to/agentworkbench-<version>-py3-none-any.whl
awb --help
```

For a Git source:

```bash
pipx install "git+ssh://git@github.com/<org>/<repo>.git"
```

## Shell Completion

Bash:

```bash
source /path/to/agent-workbench/completions/awb.bash
```

Zsh:

```bash
fpath=(/path/to/agent-workbench/completions $fpath)
autoload -Uz compinit && compinit
```

## Use It On A Target Repo

After installing `awb`, go to the repo that contains the agent you want to optimize:

```bash
cd /path/to/target-agent-repo
awb init
awb learn
```

Create or edit `.agent-workbench/agents/<agent-id>.yaml` so it points at the real target agent. Then run the approved-loop workflow:

```bash
awb brief start --agent-id <agent-id>
awb brief packet --brief-id <brief-id> --agent-id <agent-id>
awb brief finalize --brief-id <brief-id>
awb evals generate --brief-id <brief-id> --eval-id <eval-id>
awb evals review --eval-id <eval-id>
awb evals approve --eval-id <eval-id>
awb run --agent-id <agent-id> --eval-id <eval-id> --subset full
awb check --agent-id <agent-id> --eval-id <eval-id> --subset full
awb compare --candidate <experiment-id> --best
awb diagnose --experiment <experiment-id>
```

## Provider Keys

Provider agents use normal environment variables. Keep secrets out of committed workbench files.

```bash
export OPENAI_API_KEY=...
export GROQ_API_KEY=...
export CEREBRAS_API_KEY=...
```

For local-only convenience, add uncommitted env files and reference them from `.agent-workbench/workbench.yaml`:

```yaml
env_files:
  - .env.providers.local
```

## Release Checklist

- `ruff check .` passes.
- `mypy` passes.
- `pytest -q` passes.
- `python -m build` succeeds.
- `python -m twine check dist/*` passes.
- `README.md`, `docs/codex_agent_guide.md`, and this file match the shipped CLI.
- Changelog and version are updated.
- The built wheel installs in a clean virtualenv.
- `awb check --format text --fail-on none` works in a newly initialized target repo.
