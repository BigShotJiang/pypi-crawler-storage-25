# Agent Workbench - Multi-Turn and Chain Features

This document describes the multi-turn conversation and multi-agent chain features in Agent Workbench.

## Multi-Turn Conversations

### Overview

Agent Workbench supports multi-turn conversations in eval cases, where the agent engages in a back-and-forth dialogue with the user rather than a single request-response interaction.

### Defining Multi-Turn Eval Cases

Add a `turns` array to your eval case:

```json
{
  "id": "support-multiturn-refund",
  "input": "What refund amount should we offer?",
  "expected": "full refund",
  "turns": [
    {"role": "user", "content": "A customer wants a refund. Their subscription renewed 5 days ago."},
    {"role": "assistant", "content": "I found the customer's account. They are eligible for a full refund."}
  ],
  "metadata": {
    "expected_turns": [
      {"step": 0, "expected_tools": ["policy_search"], "expected_skills": ["policy_grounding"]},
      {"step": 1, "expected_tools": ["customer_memory"], "expected_skills": ["memory_recall"]}
    ]
  }
}
```

### Turn-Level Scoring

The `expected_turns` metadata enables turn-level scoring. Each turn is evaluated for:

- **Expected tools** — Did the agent use the required tools at each step?
- **Expected skills** — Did the agent use the required skills?

The scorer outputs:
- `turn_0_alignment` — Score for turn 0
- `turn_1_alignment` — Score for turn 1

### Conversation Metrics

The behavior summary includes conversation metrics:

| Metric | Description |
|--------|-------------|
| `average_turn_count` | Average number of turns per case |
| `escalation_rate` | Percentage of cases where escalation was detected |
| `average_re_ask_count` | Average number of times agent asked for clarification |
| `average_turn_latency_ms` | Average latency per turn |
| `cases_with_turns` | Number of cases with multi-turn conversations |

### Adapter Support

- **Provider adapter**: Turns are converted to chat messages
- **Command adapter**: Turns passed via `AWB_TURNS_JSON` env var
- **Python adapter**: Turns passed via `AWB_TURNS_JSON` env var

---

## Multi-Agent Chains

### Overview

Multi-agent chains run eval cases through multiple agents sequentially, with each agent's output feeding into the next.

### Running Chains

```bash
awb run chain \
  --agent-id groq-support-baseline \
  --agent-id groq-router-workflow \
  --eval-id support-ops-agent \
  --subset chain
```

### Chain Configuration

You can customize each step with `--step-config`:

```bash
awb run chain \
  --agent-id agent-a \
  --agent-id agent-b \
  --eval-id my-eval \
  --step-config '{"agent_id": "agent-b", "branch_condition": "prior_score >= 0.5"}'
```

#### Step Config Options

| Option | Description |
|--------|-------------|
| `agent_id` | Agent spec ID for this step |
| `handoff_template` | Template for passing output to next step |
| `step_expectations` | Process expectations for this step |
| `branch_condition` | Python expression; if False, skip this step |

### Structured Handoffs

The `handoff_template` supports these variables:

| Variable | Description |
|----------|-------------|
| `{prior_output}` | Previous agent's final output |
| `{prior_structured_output}` | Previous agent's structured output as JSON |
| `{prior_tool_calls}` | Previous agent's tool calls as JSON |
| `{prior_evidence}` | Previous agent's evidence records as JSON |
| `{prior_trace}` | Previous agent's trace events as JSON |
| `{original_input}` | Original case input |
| `{case_id}` | Case ID |
| `{step}` | Current step index |
| `{chain_context}` | Full accumulated context as JSON |

### Per-Step Scoring

Every chain step is scored against the original eval case. The step scores are stored in the experiment artifact:

```json
{
  "chain_steps": [
    {
      "agent_id": "groq-support-baseline",
      "step": 0,
      "step_score": {
        "scores": [...],
        "passed": false,
        "score": 0.3
      }
    },
    {
      "agent_id": "groq-router-workflow", 
      "step": 1,
      "step_score": {
        "scores": [...],
        "passed": false,
        "score": 0.5
      }
    }
  ]
}
```

### Chain Aggregate Metrics

| Metric | Description |
|--------|-------------|
| `step_pass_rate` | Percentage of steps that passed |
| `step_scores` | Score per agent ID |
| `degrading_steps` | Agent IDs where score dropped from prior step |
| `total_chain_latency_ms` | Total latency across all steps |
| `branch_skips` | Steps skipped due to branch conditions |

### Dynamic Branching

Use `branch_condition` to conditionally skip steps:

```json
{
  "agent_id": "router-agent",
  "branch_condition": "prior_score >= 0.5"
}
```

If the prior step's score is below 0.5, the router step is skipped.

### Turn Preservation

With `--preserve-turns` (default behavior), steps receive accumulated conversation turns:

```
Step 0: turns = [original_turns]
Step 1: turns = [original_turns, assistant_response, handoff_input]
```

---

## Chain Diagnosis

### Overview

The `diagnose` command analyzes chain experiments to identify which step/agent is responsible for failures.

### Output

```json
{
  "chain_diagnosis": {
    "is_chain_run": true,
    "weakest_step": 0,
    "weakest_agent": "groq-support-baseline",
    "step_failure_counts": {
      "0": {"groq-support-baseline": 2},
      "1": {"groq-router-workflow": 2}
    },
    "first_failing_steps": {
      "case-1": {"step": 0, "agent_id": "groq-support-baseline", "score": 0.1}
    }
  }
}
```

### Key Metrics

| Metric | Description |
|--------|-------------|
| `weakest_step` | Step index with most failures |
| `weakest_agent` | Agent ID at weakest step |
| `step_failure_counts` | Failure count per step per agent |
| `first_failing_steps` | First step that failed for each case |

---

## Adapter Chain Context

### Overview

Adapters can receive chain context to make informed decisions.

### Environment Variables

- `AWB_CHAIN_CONTEXT_JSON` — Full chain context as JSON
- `AWB_TURNS_JSON` — Accumulated conversation turns

### Provider Adapter

Chain context is appended to the system message:

```
System: You are a helpful assistant.

Chain context:
{
  "steps": [...],
  "original_input": "...",
  "accumulated_output": "..."
}
```

---

## Multi-Turn Case Generation from Briefs

### Overview

Generate multi-turn eval cases from behavior briefs with `workflow_scenarios`.

### Brief Format

```yaml
workflow_scenarios:
  - name: support-escalation
    turns:
      - role: user
        content: "My order hasn't arrived"
      - role: assistant
        content: "Let me look up your order"
      - role: user
        content: "Order #12345"
    expected_turns:
      - step: 0
        expected_tools: ["order_lookup"]
      - step: 1
        expected_tools: ["shipping_status"]
    expected: "Resolved with shipping info"
```

---

## CLI Reference

### run Command

```bash
awb run --agent-id <id> --eval-id <id> --subset <subset>
```

Supports multi-turn eval cases automatically.

### run chain Command

```bash
awb run chain \
  --agent-id <id> \
  --agent-id <id> \
  [--chain-handoff-template <template>] \
  [--step-config <json>]
```

### diagnose Command

```bash
awb diagnose --eval-id <id> --subset <subset>
```

Outputs chain diagnosis for chain experiments.

---

## Examples

See `examples/live-provider-demo/` for a complete example with:

- Multi-turn eval cases in `.agent-workbench/evals/support-ops-agent.jsonl`
- Chain eval cases with `turns` and `expected_turns`
- Scorer configured for turn-level scoring in `.agent-workbench/scorers/support-ops-agent_default.py`

Run the example:

```bash
cd examples/live-provider-demo

# Run multi-turn tests
awb run --agent-id groq-support-baseline --eval-id support-ops-agent --subset multiturn

# Run chain tests  
awb run chain --agent-id groq-support-baseline --agent-id groq-router-workflow --eval-id support-ops-agent --subset chain

# Diagnose chain failures
awb diagnose --eval-id support-ops-agent --subset chain
```
