from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.proposals import build_mutation_proposal_payload, write_mutation_proposal_payload
from agentworkbench.report_next import render_next_report
from agentworkbench.reports import write_report
from agentworkbench.runner_compare import status_summary
from agentworkbench.runner_diagnosis import diagnose_experiment
from agentworkbench.utils import ensure_dir, write_json


def _status_command(payload: dict[str, Any]) -> str:
    parts = ["awb", "status"]
    if payload.get("agent_id"):
        parts.extend(["--agent-id", str(payload["agent_id"])])
    if payload.get("eval_id"):
        parts.extend(["--eval-id", str(payload["eval_id"])])
    if payload.get("subset"):
        parts.extend(["--subset", str(payload["subset"])])
    if payload.get("benchmark_signature"):
        parts.extend(["--benchmark-signature", str(payload["benchmark_signature"])])
    return " ".join(parts)


def _why_now(diagnosis: dict[str, Any], proposals: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    failed_gates = [
        str(key)
        for key, value in (diagnosis.get("gate_results") or {}).items()
        if key != "overall_passed" and isinstance(value, dict) and not bool(value.get("passed", True))
    ]
    if failed_gates:
        reasons.append(f"Failed gates: {', '.join(failed_gates[:4])}.")
    for item in (diagnosis.get("focus_cases") or [])[:2]:
        case_id = str(item.get("case_id") or "unknown")
        reason = str(item.get("reason") or "changed behavior")
        reasons.append(f"Focus case `{case_id}` needs attention: {reason}.")
    top = ((proposals.get("proposals") or []) or [{}])[0]
    if top.get("proposal_id"):
        reasons.append(
            f"Top proposal `{top.get('proposal_id')}` targets `{top.get('category', 'mutation')}` with priority `{top.get('priority', 'medium')}`."
        )
    for item in (diagnosis.get("surface_recommendations") or [])[:2]:
        surface = str(item.get("surface") or "").strip()
        recommendation = str(item.get("recommendation") or "").strip()
        if surface and recommendation:
            reasons.append(f"Surface `{surface}` is marked `{recommendation}`.")
    return reasons


def _next_commands(diagnosis: dict[str, Any], proposals: dict[str, Any]) -> list[dict[str, str]]:
    commands: list[dict[str, str]] = []
    experiment_id = str(diagnosis.get("experiment_id") or "").strip()
    baseline_id = str(diagnosis.get("baseline_id") or "").strip()
    focus_cases = diagnosis.get("focus_cases") or []
    if diagnosis.get("recommended_action") == "promote" and experiment_id:
        command = f"awb promote --experiment {experiment_id}"
        if baseline_id:
            command += f" --baseline {baseline_id}"
        commands.append(
            {
                "step": "promote",
                "command": command,
                "reason": "The current candidate clears the comparison gates and is the next baseline candidate.",
            }
        )
    if experiment_id and focus_cases:
        commands.append(
            {
                "step": "eval_expand",
                "command": (
                    f"awb evals expand --eval-id {diagnosis.get('eval_id')} --experiment {experiment_id} "
                    f"--focus-limit {max(1, min(len(focus_cases), 4))}"
                ),
                "reason": "Capture the current failure slice as draft benchmark coverage before the next mutation round.",
            }
        )
    top = ((proposals.get("proposals") or []) or [{}])[0]
    proposal_id = str(top.get("proposal_id") or "").strip()
    if experiment_id and proposal_id:
        commands.append(
            {
                "step": "patch_template",
                "command": f"awb patch-template --experiment {experiment_id} --proposal-id {proposal_id}",
                "reason": str(top.get("rationale") or "Turn the top proposal into an editable implementation checklist."),
            }
        )
    stability_command = str(((diagnosis.get("stability_slice") or {}).get("command")) or "").strip()
    if stability_command:
        commands.append(
            {
                "step": "stability",
                "command": stability_command,
                "reason": "Measure repeat-run stability before making a promotion decision.",
            }
        )
    if experiment_id:
        commands.append(
            {
                "step": "iterate",
                "command": f"awb iterate --experiment {experiment_id} --limit {max(1, len(proposals.get('proposals', [])))}",
                "reason": "Convert the current diagnosis into measured lanes if you want multiple bounded follow-up paths.",
            }
        )
    commands.append(
        {
            "step": "status",
            "command": _status_command(
                {
                    "agent_id": diagnosis.get("agent_id"),
                    "eval_id": diagnosis.get("eval_id"),
                    "subset": diagnosis.get("subset"),
                    "benchmark_signature": diagnosis.get("benchmark_signature"),
                }
            ),
            "reason": "Refresh the stream summary after the next edit or validation run.",
        }
    )
    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in commands:
        command = str(item.get("command") or "").strip()
        if not command or command in seen:
            continue
        seen.add(command)
        deduped.append(item)
    return deduped


def build_next_steps_summary(
    project_root: Path,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    baseline_id: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    cluster_ids: list[str] | None = None,
    focus_limit: int = 5,
    limit: int = 3,
) -> dict[str, Any]:
    diagnosis = diagnose_experiment(
        project_root,
        experiment_id=experiment_id,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        baseline_id=baseline_id,
        case_ids=case_ids,
        tags=tags,
        match=match,
        cluster_ids=cluster_ids,
        focus_limit=focus_limit,
    )
    status = status_summary(
        project_root,
        agent_id=str(diagnosis.get("agent_id") or "") or agent_id,
        eval_id=str(diagnosis.get("eval_id") or "") or eval_id,
        subset=str(diagnosis.get("subset") or "") or subset,
        benchmark_signature=str(diagnosis.get("benchmark_signature") or "") or benchmark_signature,
        limit=5,
    )
    proposals = write_mutation_proposal_payload(
        project_root,
        build_mutation_proposal_payload(project_root, diagnosis, limit=limit),
    )
    top_proposal = ((proposals.get("proposals") or []) or [None])[0]
    payload = {
        "project_root": str(project_root),
        "experiment_id": diagnosis.get("experiment_id"),
        "agent_id": diagnosis.get("agent_id"),
        "eval_id": diagnosis.get("eval_id"),
        "subset": diagnosis.get("subset"),
        "benchmark_signature": diagnosis.get("benchmark_signature"),
        "baseline_id": diagnosis.get("baseline_id"),
        "recommended_action": diagnosis.get("recommended_action"),
        "summary": diagnosis.get("summary"),
        "why_now": _why_now(diagnosis, proposals),
        "status": {
            "latest_experiment": status.get("latest_experiment"),
            "latest_compare": status.get("latest_compare"),
            "latest_baseline_ladder": status.get("latest_baseline_ladder"),
            "latest_stability": status.get("latest_stability"),
            "latest_matrix": status.get("latest_matrix"),
            "latest_factorial": status.get("latest_factorial"),
            "streams": status.get("streams"),
        },
        "diagnosis": {
            "focus_cases": diagnosis.get("focus_cases"),
            "failure_clusters": diagnosis.get("failure_clusters"),
            "surface_recommendations": diagnosis.get("surface_recommendations"),
            "suggested_mutations": diagnosis.get("suggested_mutations"),
            "gate_results": diagnosis.get("gate_results"),
            "metric_deltas": diagnosis.get("metric_deltas"),
            "behavior_deltas": diagnosis.get("behavior_deltas"),
            "stability_slice": diagnosis.get("stability_slice"),
            "suggested_commands": diagnosis.get("suggested_commands"),
        },
        "proposals": proposals,
        "top_proposal": top_proposal,
        "next_commands": _next_commands(diagnosis, proposals),
    }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / f"next-{diagnosis['experiment_id']}.json", payload)
    write_json(reports_dir / "next-latest.json", payload)
    write_report(reports_dir / f"next-{diagnosis['experiment_id']}.md", render_next_report(payload))
    write_report(reports_dir / "next-latest.md", render_next_report(payload))
    return payload
