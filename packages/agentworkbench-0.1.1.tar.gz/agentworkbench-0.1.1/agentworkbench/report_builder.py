from __future__ import annotations

from collections.abc import Iterable
from typing import Any


class ReportBuilder:
    def __init__(self, title: str) -> None:
        self._lines: list[str] = [f"# {title}", ""]

    @staticmethod
    def _normalize_heading(heading: str) -> str:
        text = str(heading or "").strip()
        if text.startswith("## "):
            return text[3:]
        if text.startswith("# "):
            return text[2:]
        return text

    def lines(self) -> list[str]:
        return list(self._lines)

    def text(self) -> str:
        return "\n".join(self._lines).strip() + "\n"

    def blank(self) -> ReportBuilder:
        if self._lines and self._lines[-1] != "":
            self._lines.append("")
        return self

    def section(self, title: str) -> ReportBuilder:
        self._lines.extend(["", f"## {title}", ""])
        return self

    def bullet(self, text: str) -> ReportBuilder:
        self._lines.append(f"- {text}")
        return self

    def bullets(self, items: Iterable[str], *, empty_text: str = "none") -> ReportBuilder:
        added = False
        for item in items:
            self._lines.append(f"- {item}")
            added = True
        if not added:
            self._lines.append(f"- {empty_text}")
        return self

    def kv(self, key: str, value: Any, *, code_key: bool = True) -> ReportBuilder:
        label = f"`{key}`" if code_key else key
        self._lines.append(f"- {label}: {value}")
        return self

    def kv_list(self, key: str, values: list[str], *, empty_text: str = "none") -> ReportBuilder:
        joined = ", ".join(values) if values else empty_text
        return self.kv(key, joined)

    def kv_map(self, mapping: dict[str, Any], *, skip_keys: set[str] | None = None) -> ReportBuilder:
        skip = skip_keys or set()
        for key, value in mapping.items():
            if key in skip:
                continue
            if isinstance(value, list):
                self.kv(key, ", ".join(value) or "none")
            else:
                self.kv(key, value)
        return self

    def repo_change_summary(self, summary: dict[str, Any]) -> ReportBuilder:
        if not summary:
            self._lines.append("- none")
            return self
        self._lines.append(f"- Changed file count: {summary.get('changed_file_count', 0)}")
        self._lines.append(
            f"- Surface areas changed: {', '.join(summary.get('surface_areas_changed', [])) or 'none'}"
        )
        self._lines.append(f"- Agent spec files: {', '.join(summary.get('agent_spec_files', [])) or 'none'}")
        self._lines.append(f"- Benchmark files: {', '.join(summary.get('benchmark_files', [])) or 'none'}")
        self._lines.append(f"- Owned files: {', '.join(summary.get('owned_files', [])) or 'none'}")
        self._lines.append(f"- Unowned files: {', '.join(summary.get('unowned_files', [])) or 'none'}")
        for key, value in (summary.get("surface_files") or {}).items():
            self._lines.append(f"- `{key}` files: {', '.join(value) or 'none'}")
        return self

    def human_checkpoints(
        self, checkpoints: list[dict[str, Any]], *, heading: str = "Human Checkpoints"
    ) -> ReportBuilder:
        self.section(self._normalize_heading(heading))
        if not checkpoints:
            self._lines.append("- none")
            return self
        for item in checkpoints:
            self._lines.append(
                f"- `{item.get('priority', 'medium')}` `{item.get('checkpoint_id', 'checkpoint')}`: {item.get('title') or 'Human checkpoint'}"
            )
            self._lines.append(
                f"- queue: {item.get('queue') or 'none'}, review_type: {item.get('review_type') or 'none'}, "
                f"question_type: {item.get('question_type') or 'none'}, response_mode: {item.get('response_mode') or 'none'}"
            )
            self._lines.append(f"- ask: {item.get('question') or 'none'}")
            self._lines.append(
                f"- suggested_prompt: {item.get('suggested_prompt') or item.get('question') or 'none'}"
            )
            self._lines.append(f"- reason: {item.get('reason') or 'none'}")
            self._lines.append(
                f"- related_cases: {', '.join(item.get('related_case_ids', [])) or 'none'}"
            )
        return self

    def review_queue(
        self, queue: dict[str, Any], *, heading: str = "Human Review Queue"
    ) -> ReportBuilder:
        self.section(self._normalize_heading(heading))
        if not queue:
            self._lines.append("- none")
            return self
        self._lines.append(
            f"- queue_id={queue.get('queue_id') or 'queue'}, stage={queue.get('stage') or 'unknown'}, "
            f"subject={queue.get('subject') or 'unknown'}, items={queue.get('item_count', 0)}, blocking={queue.get('blocking_count', 0)}"
        )
        self._lines.append(f"- queues={', '.join(queue.get('queues', [])) or 'none'}")
        self._lines.append(
            f"- pending={queue.get('pending_count', 0)}, resolved={queue.get('resolved_count', 0)}, all_resolved={queue.get('all_resolved', False)}"
        )
        for item in queue.get("items", [])[:8]:
            self._lines.append(
                f"- `{item.get('checkpoint_id', 'checkpoint')}`: status={item.get('status') or 'pending'}, queue={item.get('queue') or 'none'}, "
                f"review_type={item.get('review_type') or 'none'}, question_type={item.get('question_type') or 'none'}, "
                f"response_mode={item.get('response_mode') or 'none'}"
            )
            self._lines.append(f"- prompt: {item.get('suggested_prompt') or item.get('question') or 'none'}")
            resolution = item.get("resolution") or {}
            if resolution:
                self._lines.append(
                    f"- resolution: decision={resolution.get('decision') or 'none'}, guidance={resolution.get('guidance') or 'none'}, "
                    f"reviewer={resolution.get('reviewer') or 'human'}, resolved_at={resolution.get('resolved_at') or 'unknown'}"
                )
        return self
