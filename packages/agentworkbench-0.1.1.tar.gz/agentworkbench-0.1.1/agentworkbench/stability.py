from __future__ import annotations

import statistics
from pathlib import Path
from typing import Any, cast

from agentworkbench.config import control_dir
from agentworkbench.models import ExperimentRecord
from agentworkbench.utils import created_at_utc, ensure_dir, read_json

_SERIES_METRICS = (
    "average_score",
    "passed_cases",
    "average_latency_ms",
    "average_step_count",
    "average_cost_estimate",
)


def _metric_value(record: ExperimentRecord, name: str) -> float:
    if name in {"average_score", "passed_cases"}:
        return float(record.scores.get(name, 0.0))
    return float(record.behavior_summary.get(name, 0.0))


def _metric_summary(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"mean": 0.0, "stddev": 0.0, "min": 0.0, "max": 0.0, "cv": None, "ci95_half_width": 0.0}
    mean = statistics.fmean(values)
    stddev = statistics.stdev(values) if len(values) > 1 else 0.0
    ci95_half_width = 1.96 * stddev / (len(values) ** 0.5) if len(values) > 1 else 0.0
    cv = (stddev / mean) if abs(mean) > 1e-9 else None
    return {
        "mean": round(mean, 6),
        "stddev": round(stddev, 6),
        "min": round(min(values), 6),
        "max": round(max(values), 6),
        "cv": round(cv, 6) if cv is not None else None,
        "ci95_half_width": round(ci95_half_width, 6),
    }


def build_stability_summary(
    *,
    series_id: str,
    records: list[ExperimentRecord],
    label: str | None = None,
    selection: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not records:
        raise ValueError("Cannot summarize an empty experiment series.")
    latest = sorted(records, key=lambda item: (item.created_at or "", item.experiment_id))[-1]
    comparable_signatures = sorted({record.benchmark_signature for record in records if record.benchmark_signature})
    selected_case_ids = latest.selected_case_ids or []
    metrics = {name: _metric_summary([_metric_value(record, name) for record in records]) for name in _SERIES_METRICS}
    return {
        "series_id": series_id,
        "created_at": created_at_utc(),
        "label": label or series_id,
        "repeat_count": len(records),
        "representative_experiment_id": latest.experiment_id,
        "experiment_ids": [record.experiment_id for record in records],
        "agent_id": latest.agent_id,
        "eval_id": latest.eval_id,
        "subset": latest.subset,
        "benchmark_signatures": comparable_signatures,
        "selection_fingerprint": latest.selection_fingerprint,
        "selected_case_ids": selected_case_ids,
        "selection": selection or {},
        "metrics": metrics,
        "series_mean_score": metrics["average_score"]["mean"],
        "series_score_stddev": metrics["average_score"]["stddev"],
        "series_latency_cv": metrics["average_latency_ms"]["cv"],
        "series_cost_cv": metrics["average_cost_estimate"]["cv"],
        "case_pass_rates": {},
    }


def stability_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "stability")


def _load_stability_summary(project_root: Path, series_id: str | None) -> dict[str, Any] | None:
    if not series_id:
        return None
    path = stability_dir(project_root) / f"{series_id}.json"
    if not path.exists():
        return None
    return cast(dict[str, Any], read_json(path))


def _stability_summary_for_record(project_root: Path, record: ExperimentRecord | None) -> dict[str, Any] | None:
    if record is None:
        return None
    return _load_stability_summary(project_root, record.series_id)
