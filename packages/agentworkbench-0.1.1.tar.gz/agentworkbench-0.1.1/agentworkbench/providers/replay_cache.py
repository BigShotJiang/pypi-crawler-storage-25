"""Provider response replay/cache management."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.utils import read_json, write_json


def _provider_cache_dir(project_root: Path) -> Path:
    return control_dir(project_root) / "cache" / "provider"


def cache_path(project_root: Path, cache_key: str) -> Path:
    """Return the filesystem path for a given cache key."""
    return _provider_cache_dir(project_root) / f"{cache_key}.json"


def load_cache(path: Path) -> tuple[dict[str, Any] | None, list[str]]:
    """Load a cached provider response.

    Returns ``(response_dict, errors)``. On success the first element is the
    cached response payload and ``errors`` is empty. On failure the first
    element is ``None`` and ``errors`` describes what went wrong.
    """
    if not path.exists():
        return None, []
    try:
        payload = read_json(path)
    except (OSError, json.JSONDecodeError) as exc:
        return None, [f"Provider cache entry was not valid JSON: {exc}"]
    if not isinstance(payload, dict):
        return None, ["Provider cache entry must contain a JSON object"]
    response = payload.get("response")
    if not isinstance(response, dict):
        return None, ["Provider cache entry is missing a valid `response` payload"]
    return response, []


def write_cache(path: Path, *, request: dict[str, Any], response: dict[str, Any]) -> None:
    """Persist a provider response to the cache.

    The cached payload is human-inspectable and secrets are not stored
    (the request body is recorded, but API keys are never part of it).
    """
    write_json(
        path,
        {
            "cache_schema_version": "awb.provider_cache.v1",
            "request": request,
            "response": response,
        },
    )


__all__ = [
    "cache_path",
    "load_cache",
    "write_cache",
]
