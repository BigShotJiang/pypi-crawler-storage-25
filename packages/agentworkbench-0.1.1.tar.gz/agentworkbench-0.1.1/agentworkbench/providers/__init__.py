"""Modular provider transport layer.

This package contains the shared transport core for OpenAI-compatible
providers, replay/cache management, and pricing resolution.
"""

from __future__ import annotations

from agentworkbench.providers.base import (
    BUILTIN_PROVIDER_ENDPOINTS,
    ProviderCapabilities,
    ProviderConfig,
    ProviderResponse,
    RetryClassification,
    classify_error,
)
from agentworkbench.providers.openai_compatible import (
    build_messages,
    build_request_body,
    http_request,
    parse_response,
    provider_tools,
    request_fingerprint,
    request_headers,
)
from agentworkbench.providers.pricing_resolver import (
    estimate_token_cost,
    resolve_pricing,
)
from agentworkbench.providers.replay_cache import (
    load_cache,
    write_cache,
)

__all__ = [
    "BUILTIN_PROVIDER_ENDPOINTS",
    "ProviderCapabilities",
    "ProviderConfig",
    "ProviderResponse",
    "RetryClassification",
    "build_messages",
    "build_request_body",
    "classify_error",
    "estimate_token_cost",
    "http_request",
    "load_cache",
    "parse_response",
    "provider_tools",
    "request_fingerprint",
    "request_headers",
    "resolve_pricing",
    "write_cache",
]
