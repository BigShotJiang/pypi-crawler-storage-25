"""Shared OpenAI-compatible transport: message building, HTTP, response parsing."""

from __future__ import annotations

import hashlib
import json
import re
import ssl
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, cast

from agentworkbench.models import AgentSpec, EvalCase, ProviderEntrypoint
from agentworkbench.providers.base import ProviderResponse, classify_error
from agentworkbench.tool_interfaces import compact_tool_description, compact_tool_schema

_MODEL_REQUEST_KEYS = {
    "frequency_penalty",
    "max_completion_tokens",
    "max_output_tokens",
    "max_tokens",
    "parallel_tool_calls",
    "presence_penalty",
    "reasoning_effort",
    "response_format",
    "seed",
    "stop",
    "temperature",
    "tool_choice",
    "top_p",
}

_FAILED_GENERATION_FUNCTION_RE = re.compile(
    r"<function=(?P<name>[^>\s]+)>\s*(?P<arguments>.*?)(?=(?:<function=)|$)",
    re.DOTALL,
)


# ---------------------------------------------------------------------------
# Prompt resolution
# ---------------------------------------------------------------------------


def _resolve_prompt_value(project_root: Path, value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    candidate = project_root / text
    if candidate.exists() and candidate.is_file():
        return candidate.read_text(encoding="utf-8").strip()
    return text


def _resolved_prompts(project_root: Path, prompts: dict[str, Any]) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for key, value in prompts.items():
        prompt_text = _resolve_prompt_value(project_root, value)
        if prompt_text:
            resolved[str(key)] = prompt_text
    return resolved


def _ordered_prompt_keys(config: ProviderEntrypoint, prompts: dict[str, str]) -> list[str]:
    if config.prompt_keys:
        return [str(key) for key in config.prompt_keys if str(key) in prompts and prompts[str(key)].strip()]
    keys = [str(key) for key, value in prompts.items() if str(value).strip()]
    system_key = str(config.system_prompt_key or "").strip()
    ordered: list[str] = []
    if system_key and system_key in keys:
        ordered.append(system_key)
    ordered.extend(key for key in sorted(keys) if key not in ordered)
    return ordered


def _message_content(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                if item.strip():
                    parts.append(item.strip())
                continue
            if not isinstance(item, dict):
                continue
            if str(item.get("type") or "") == "text":
                text = str(item.get("text") or "").strip()
                if text:
                    parts.append(text)
                continue
            text = str(item.get("content") or item.get("text") or "").strip()
            if text:
                parts.append(text)
        return "\n".join(parts).strip()
    return str(value or "").strip()


def _text_preview(value: Any, *, limit: int = 240) -> str:
    text = _message_content(value)
    if len(text) <= limit:
        return text
    clipped = text[: max(0, limit - 3)].rstrip()
    return f"{clipped}..."


def _compact_tool_call_names(tool_calls: Any, *, limit: int = 6) -> list[str]:
    names: list[str] = []
    for item in tool_calls or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or (item.get("function") or {}).get("name") or "").strip()
        if name:
            names.append(name)
        if len(names) >= limit:
            break
    return names


def _compact_trace_markers(trace_events: Any, *, limit: int = 8) -> list[str]:
    markers: list[str] = []
    for item in trace_events or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "").strip()
        name = str(item.get("name") or "").strip()
        marker = f"{kind}:{name}".strip(":")
        if marker:
            markers.append(marker)
        if len(markers) >= limit:
            break
    return markers


def _compact_evidence_markers(evidence_records: Any, *, limit: int = 6) -> list[str]:
    markers: list[str] = []
    for item in evidence_records or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "").strip()
        name = str(item.get("name") or "").strip()
        marker = f"{kind}:{name}".strip(":")
        if marker:
            markers.append(marker)
        if len(markers) >= limit:
            break
    return markers


def _compact_chain_step(step: Any) -> dict[str, Any]:
    if not isinstance(step, dict):
        return {}
    artifact = step.get("artifact_summary") or {}
    output_preview = step.get("final_output_preview") or artifact.get("final_output") or ""
    payload: dict[str, Any] = {}
    for key in ("step", "node_id", "agent_id", "from_node", "route"):
        value = step.get(key)
        if value not in (None, "", [], {}):
            payload[key] = value
    selected_edges = step.get("selected_edges")
    if isinstance(selected_edges, list) and selected_edges:
        payload["selected_edges"] = [
            {
                "to": item.get("to"),
                "label": item.get("label"),
                "default": item.get("default", False),
            }
            for item in selected_edges[:4]
            if isinstance(item, dict)
        ]
    elif isinstance(step.get("selected_edge"), dict):
        edge = step.get("selected_edge") or {}
        payload["selected_edges"] = [{"to": edge.get("to"), "label": edge.get("label"), "default": edge.get("default", False)}]
    tool_names = step.get("tool_call_names") or _compact_tool_call_names(artifact.get("tool_calls"))
    if tool_names:
        payload["tool_calls"] = tool_names[:6]
    evidence_markers = _compact_evidence_markers(artifact.get("evidence_records"))
    if evidence_markers:
        payload["evidence"] = evidence_markers
    trace_markers = _compact_trace_markers(artifact.get("trace_events"))
    if trace_markers:
        payload["trace"] = trace_markers
    errors = [str(item) for item in (step.get("errors") or artifact.get("errors") or []) if str(item).strip()]
    if errors:
        payload["errors"] = errors[:4]
    if output_preview:
        payload["output_preview"] = _text_preview(output_preview, limit=140)
    return payload


def _compact_shared_context(shared_context: Any) -> dict[str, Any]:
    if not isinstance(shared_context, dict):
        return {}
    compact: dict[str, Any] = {}
    for key, value in sorted(shared_context.items()):
        if isinstance(value, str):
            compact[key] = _text_preview(value, limit=120)
            continue
        if isinstance(value, list):
            compact[key] = [
                _text_preview(item, limit=80) if isinstance(item, str) else item
                for item in value[:6]
            ]
            continue
        if isinstance(value, dict):
            compact[key] = {
                str(nested_key): (
                    _text_preview(nested_value, limit=80) if isinstance(nested_value, str) else nested_value
                )
                for nested_key, nested_value in list(value.items())[:6]
            }
            continue
        compact[key] = value
    return compact


def _chain_context_blob(chain_context: Any, mode: str) -> str:
    if not chain_context:
        return ""
    normalized_mode = str(mode or "compact").strip().lower()
    if normalized_mode == "off":
        return ""
    if normalized_mode == "full":
        return json.dumps(chain_context, indent=2)
    if not isinstance(chain_context, dict):
        return _text_preview(chain_context, limit=600)
    compact: dict[str, Any] = {
        "case_id": str(chain_context.get("case_id") or "").strip(),
        "original_input": _text_preview(chain_context.get("original_input") or "", limit=180),
        "accumulated_output": _text_preview(chain_context.get("accumulated_output") or "", limit=220),
        "step_count": len(chain_context.get("steps") or []),
        "steps": [
            payload
            for payload in (_compact_chain_step(step) for step in (chain_context.get("steps") or [])[-4:])
            if payload
        ],
        "aggregated_tool_calls": _compact_tool_call_names(chain_context.get("aggregated_tool_calls")),
        "aggregated_evidence": _compact_evidence_markers(chain_context.get("aggregated_evidence")),
        "aggregated_trace": _compact_trace_markers(chain_context.get("aggregated_trace_events")),
    }
    shared_context = _compact_shared_context(chain_context.get("shared_context"))
    if shared_context:
        compact["shared_context"] = shared_context
    return json.dumps({key: value for key, value in compact.items() if value not in ("", [], {}, None)}, indent=2)


# ---------------------------------------------------------------------------
# Message building
# ---------------------------------------------------------------------------


def build_messages(
    project_root: Path,
    spec: AgentSpec,
    case: EvalCase,
    config: ProviderEntrypoint,
) -> tuple[list[dict[str, str]], list[str]]:
    """Build the chat messages list and return prompt keys used."""
    resolved_prompts = _resolved_prompts(project_root, spec.prompts)
    prompt_keys = _ordered_prompt_keys(config, resolved_prompts)
    sections: list[str] = []
    if config.include_instructions and spec.instructions:
        sections.append("Instructions:\n" + "\n".join(f"- {item}" for item in spec.instructions if str(item).strip()))
    for key in prompt_keys:
        prompt_text = resolved_prompts.get(key, "").strip()
        if not prompt_text:
            continue
        if key == str(config.system_prompt_key or "").strip():
            sections.append(prompt_text)
        else:
            sections.append(f"{key} prompt:\n{prompt_text}")
    try:
        user_content = str(config.user_prompt_template).format(input=case.input, case_id=case.id)
    except KeyError as exc:
        raise ValueError(
            f"Provider user_prompt_template referenced unknown field `{exc.args[0]}`. Supported fields: input, case_id."
        ) from exc
    system_blob = "\n\n".join(section for section in sections if section.strip()).strip()

    chain_context = case.metadata.get("chain_context")
    if chain_context:
        context_blob = _chain_context_blob(chain_context, str(config.chain_context_mode))
        if context_blob:
            system_blob = (
                f"{system_blob}\n\nChain context:\n{context_blob}" if system_blob else f"Chain context:\n{context_blob}"
            )

    turns = [t for t in (case.turns or []) if isinstance(t, dict)]
    if turns:
        messages: list[dict[str, str]] = []
        if system_blob:
            messages.append({"role": "system", "content": system_blob})
        allowed_roles = {"system", "user", "assistant", "tool"}
        for item in turns:
            role = str(item.get("role") or "user").strip().lower()
            if role not in allowed_roles:
                role = "user"
            content = str(item.get("content") or "")
            messages.append({"role": role, "content": content})
        if user_content.strip():
            messages.append({"role": "user", "content": user_content})
        return messages, prompt_keys

    messages = []
    if system_blob:
        messages.append({"role": "system", "content": system_blob})
    messages.append({"role": "user", "content": user_content})
    return messages, prompt_keys


# ---------------------------------------------------------------------------
# Tool payload
# ---------------------------------------------------------------------------


def provider_tools(spec: AgentSpec, *, tool_format: str = "full") -> list[dict[str, Any]]:
    """Build the tool definitions payload for the request body."""
    payload: list[dict[str, Any]] = []
    compact_mode = str(tool_format or "full").strip().lower() == "compact"
    for tool in spec.tools:
        if not isinstance(tool, dict) or not bool(tool.get("enabled", True)):
            continue
        if isinstance(tool.get("function"), dict):
            function_payload = dict(tool.get("function") or {})
            name = str(function_payload.get("name") or tool.get("name") or "").strip()
            if not name:
                continue
            function_payload["name"] = name
            if compact_mode:
                function_payload["description"] = compact_tool_description(function_payload.get("description") or "")
                parameters = function_payload.get("parameters")
                if isinstance(parameters, dict):
                    function_payload["parameters"] = compact_tool_schema(parameters)
            payload.append({"type": str(tool.get("type") or "function"), "function": function_payload})
            continue
        schema = tool.get("parameters") or tool.get("input_schema") or tool.get("schema")
        if not isinstance(schema, dict):
            continue
        name = str(tool.get("name") or "").strip()
        if not name:
            continue
        payload.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": compact_tool_description(tool.get("description") or "")
                    if compact_mode
                    else str(tool.get("description") or "").strip(),
                    "parameters": compact_tool_schema(schema) if compact_mode else schema,
                },
            }
        )
    return payload


# ---------------------------------------------------------------------------
# Request body
# ---------------------------------------------------------------------------


def build_request_body(spec: AgentSpec, messages: list[dict[str, str]], config: ProviderEntrypoint) -> dict[str, Any]:
    """Build the JSON request body for the provider API."""
    model_name = str(spec.model.get("model_id") or spec.model.get("name") or "").strip()
    payload: dict[str, Any] = {"model": model_name, "messages": messages}
    for key in _MODEL_REQUEST_KEYS:
        if key in spec.model and spec.model.get(key) is not None:
            payload[key] = spec.model.get(key)
    tools = provider_tools(spec, tool_format=str(config.tool_format))
    if tools:
        payload["tools"] = tools
    payload.update(dict(config.extra_body or {}))
    return payload


# ---------------------------------------------------------------------------
# Fingerprint / headers
# ---------------------------------------------------------------------------


def request_fingerprint(payload: dict[str, Any]) -> str:
    """Compute a cache key for a provider request."""
    serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def request_headers(config: ProviderEntrypoint, api_key: str) -> dict[str, str]:
    """Build HTTP headers for a provider request."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "agent-workbench-provider-adapter",
    }
    for key, value in (config.headers or {}).items():
        headers[str(key)] = str(value)
    return headers


# ---------------------------------------------------------------------------
# HTTP transport
# ---------------------------------------------------------------------------


class TransportError(Exception):
    """Raised when an HTTP request to a provider fails."""

    def __init__(self, message: str, *, http_code: int | None = None, body: str = ""):
        super().__init__(message)
        self.http_code = http_code
        self.body = body
        self.classification = classify_error(message, http_code)


def http_request(
    url: str,
    body: dict[str, Any],
    headers: dict[str, str],
    timeout_seconds: int,
) -> dict[str, Any]:
    """Send a POST request and return the parsed JSON response.

    Raises ``TransportError`` on failure.
    """
    request = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds, context=ssl.create_default_context()) as response:
            return cast(dict[str, Any], json.loads(response.read().decode("utf-8")))
    except urllib.error.HTTPError as exc:
        error_body = ""
        try:
            error_body = exc.read().decode("utf-8").strip()
        except OSError:
            pass
        raise TransportError(
            f"Provider request failed with HTTP {exc.code}",
            http_code=exc.code,
            body=error_body,
        ) from exc
    except urllib.error.URLError as exc:
        raise TransportError(f"Provider request failed: {exc.reason}") from exc
    except TimeoutError as exc:
        raise TransportError(
            f"Provider request timed out after {timeout_seconds} seconds",
        ) from exc
    except json.JSONDecodeError as exc:
        raise TransportError(f"Provider response was not valid JSON: {exc}") from exc
    except OSError as exc:
        raise TransportError(f"Provider request failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------


def parse_response(response_payload: dict[str, Any]) -> ProviderResponse:
    """Parse an OpenAI-compatible JSON response into a ``ProviderResponse``."""
    choices = response_payload.get("choices") or []
    if not choices or not isinstance(choices[0], dict):
        raise ValueError("Provider response is missing choices[0]")
    message = choices[0].get("message") or {}
    if not isinstance(message, dict):
        raise ValueError("Provider response choices[0].message must be an object")

    final_output = _message_content(message.get("content"))

    tool_calls: list[dict[str, Any]] = []
    for item in message.get("tool_calls") or []:
        if not isinstance(item, dict):
            continue
        function = item.get("function") or {}
        name = str(function.get("name") or item.get("name") or item.get("id") or "").strip()
        if not name:
            continue
        row: dict[str, Any] = {"name": name, "status": "requested"}
        if str(item.get("id") or "").strip():
            row["id"] = str(item.get("id"))
        arguments = str(function.get("arguments") or "").strip()
        if arguments:
            row["arguments"] = arguments
        tool_calls.append(row)

    usage = response_payload.get("usage") or {}
    token_usage = {
        "input": int(usage.get("prompt_tokens", 0) or 0),
        "output": int(usage.get("completion_tokens", 0) or 0),
        "total": int(usage.get("total_tokens", 0) or 0),
    }

    finish_reason = ""
    if choices and isinstance(choices[0], dict):
        finish_reason = str(choices[0].get("finish_reason") or "").strip()

    response_id = str(response_payload.get("id") or "").strip()

    return ProviderResponse(
        final_output=final_output,
        tool_calls=tool_calls,
        token_usage=token_usage,
        finish_reason=finish_reason,
        response_id=response_id,
        raw_payload=response_payload,
    )


def recover_tool_use_failed_response(error_body: str, *, response_id: str = "") -> dict[str, Any] | None:
    """Recover a synthetic tool-call response from provider `tool_use_failed` bodies.

    Some OpenAI-compatible providers reject malformed function-call output but still include
    a machine-readable `failed_generation` string like:
    `<function=route_refund>{"reason":"..."}`
    """
    text = str(error_body or "").strip()
    if not text:
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    error = payload.get("error") or {}
    if not isinstance(error, dict):
        return None
    code = str(error.get("code") or "").strip().lower()
    failed_generation = str(error.get("failed_generation") or "").strip()
    if code != "tool_use_failed" or not failed_generation:
        return None

    tool_calls: list[dict[str, Any]] = []
    for index, match in enumerate(_FAILED_GENERATION_FUNCTION_RE.finditer(failed_generation), start=1):
        name = str(match.group("name") or "").strip()
        if not name:
            continue
        arguments = str(match.group("arguments") or "").strip() or "{}"
        if arguments and arguments[0] not in "{[":
            arguments = json.dumps({"raw": arguments})
        try:
            json.loads(arguments)
        except json.JSONDecodeError:
            continue
        tool_calls.append(
            {
                "id": f"recovered_call_{index}",
                "type": "function",
                "function": {
                    "name": name,
                    "arguments": arguments,
                },
            }
        )
    if not tool_calls:
        return None

    return {
        "id": response_id or "recovered_tool_use_failed",
        "choices": [
            {
                "message": {
                    "content": "",
                    "tool_calls": tool_calls,
                },
                "finish_reason": "tool_calls",
            }
        ],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
        "awb_recovery": {
            "mode": "tool_use_failed",
            "error": {
                "message": str(error.get("message") or "").strip(),
                "type": str(error.get("type") or "").strip(),
                "code": str(error.get("code") or "").strip(),
                "failed_generation": failed_generation,
            },
        },
    }


__all__ = [
    "TransportError",
    "build_messages",
    "build_request_body",
    "http_request",
    "parse_response",
    "recover_tool_use_failed_response",
    "provider_tools",
    "request_fingerprint",
    "request_headers",
]
