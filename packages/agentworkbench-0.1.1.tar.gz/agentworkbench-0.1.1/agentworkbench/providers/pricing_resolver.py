"""Pricing resolution and token cost estimation.

Re-exports the public API from ``agentworkbench.pricing`` while adding
provider-aware helpers that complement the core pricing module.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.pricing import (
    estimate_token_cost,
    resolve_pricing,
)


def estimate_run_cost(
    project_root: Path,
    model: dict[str, Any],
    token_usage: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a cost estimate dict, or an empty dict when pricing is unavail."""
    result = estimate_token_cost(project_root, model, token_usage, metadata)
    if result is None:
        return {}
    return result


__all__ = [
    "estimate_run_cost",
    "estimate_token_cost",
    "resolve_pricing",
]
