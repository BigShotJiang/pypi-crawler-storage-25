"""Base provider definitions, config, capabilities, and retry classification."""

from __future__ import annotations

import enum
from typing import Any

# ---------------------------------------------------------------------------
# Built-in provider endpoint registry
# ---------------------------------------------------------------------------

OPENAI_COMPATIBLE_PROVIDER_ALIASES = {
    "openai-compatible": "openai-compatible",
    "openai_compatible": "openai-compatible",
}

BUILTIN_PROVIDER_ENDPOINTS: dict[str, dict[str, str]] = {
    "openai": {
        "api_key_env": "OPENAI_API_KEY",
        "base_url": "https://api.openai.com/v1/chat/completions",
    },
    "google": {
        "api_key_env": "GOOGLE_API_KEY",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    },
    "groq": {
        "api_key_env": "GROQ_API_KEY",
        "base_url": "https://api.groq.com/openai/v1/chat/completions",
    },
    "cerebras": {
        "api_key_env": "CEREBRAS_API_KEY",
        "base_url": "https://api.cerebras.ai/v1/chat/completions",
    },
}


# ---------------------------------------------------------------------------
# Retry classification
# ---------------------------------------------------------------------------

class RetryClassification(enum.Enum):
    """Classifies provider errors to inform retry / back-off behaviour."""

    AUTH = "auth"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    TRANSIENT = "transient"
    BAD_REQUEST = "bad_request"
    UNKNOWN = "unknown"


def classify_error(error: str, http_code: int | None = None) -> RetryClassification:
    """Return a classification for a provider error string."""
    error_lower = error.lower()

    if http_code == 401 or http_code == 403 or "unauthorized" in error_lower or "forbidden" in error_lower:
        return RetryClassification.AUTH
    if http_code == 429 or "rate limit" in error_lower or "too many requests" in error_lower:
        return RetryClassification.RATE_LIMIT
    if "timeout" in error_lower or "timed out" in error_lower:
        return RetryClassification.TIMEOUT
    if http_code == 400 or "bad request" in error_lower or "invalid" in error_lower:
        return RetryClassification.BAD_REQUEST
    if http_code is not None and http_code >= 500:
        return RetryClassification.TRANSIENT
    if "connection" in error_lower or "reset" in error_lower:
        return RetryClassification.TRANSIENT
    return RetryClassification.UNKNOWN


# ---------------------------------------------------------------------------
# Provider capability declarations
# ---------------------------------------------------------------------------

class ProviderCapabilities:
    """Declarative capability surface for a provider."""

    def __init__(
        self,
        *,
        text: bool = True,
        tool_calling: bool = False,
        json_mode: bool = False,
        reasoning_tokens: bool = False,
    ):
        self.text = text
        self.tool_calling = tool_calling
        self.json_mode = json_mode
        self.reasoning_tokens = reasoning_tokens

    def to_dict(self) -> dict[str, bool]:
        return {
            "text": self.text,
            "tool_calling": self.tool_calling,
            "json_mode": self.json_mode,
            "reasoning_tokens": self.reasoning_tokens,
        }


# Default capability declarations per known provider
PROVIDER_CAPABILITIES: dict[str, ProviderCapabilities] = {
    "openai": ProviderCapabilities(text=True, tool_calling=True, json_mode=True, reasoning_tokens=True),
    "openai-compatible": ProviderCapabilities(text=True, tool_calling=True, json_mode=True),
    "google": ProviderCapabilities(text=True, tool_calling=True, json_mode=True),
    "groq": ProviderCapabilities(text=True, tool_calling=True, json_mode=True),
    "cerebras": ProviderCapabilities(text=True, tool_calling=True),
}


def get_provider_capabilities(provider_name: str) -> ProviderCapabilities:
    """Return declared capabilities for a provider, defaulting to text-only."""
    normalized = OPENAI_COMPATIBLE_PROVIDER_ALIASES.get(provider_name.lower(), provider_name.lower())
    return PROVIDER_CAPABILITIES.get(normalized, ProviderCapabilities())


# ---------------------------------------------------------------------------
# Provider config (thin wrapper for provider metadata)
# ---------------------------------------------------------------------------

class ProviderConfig:
    """Runtime-resolved metadata for a specific provider invocation."""

    def __init__(
        self,
        *,
        provider: str,
        base_url: str,
        api_key_env: str,
        model_name: str,
        capabilities: ProviderCapabilities | None = None,
        max_concurrent: int = 4,
    ):
        self.provider = provider
        self.base_url = base_url
        self.api_key_env = api_key_env
        self.model_name = model_name
        self.capabilities = capabilities or get_provider_capabilities(provider)
        self.max_concurrent = max_concurrent

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "base_url": self.base_url,
            "api_key_env": self.api_key_env,
            "model_name": self.model_name,
            "capabilities": self.capabilities.to_dict(),
            "max_concurrent": self.max_concurrent,
        }


# ---------------------------------------------------------------------------
# Provider response container
# ---------------------------------------------------------------------------

class ProviderResponse:
    """Normalised response from any OpenAI-compatible provider."""

    def __init__(
        self,
        *,
        final_output: str,
        tool_calls: list[dict[str, Any]],
        token_usage: dict[str, int],
        finish_reason: str = "",
        response_id: str = "",
        raw_payload: dict[str, Any] | None = None,
    ):
        self.final_output = final_output
        self.tool_calls = tool_calls
        self.token_usage = token_usage
        self.finish_reason = finish_reason
        self.response_id = response_id
        self.raw_payload = raw_payload or {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "final_output": self.final_output,
            "tool_calls": self.tool_calls,
            "token_usage": self.token_usage,
            "finish_reason": self.finish_reason,
            "response_id": self.response_id,
        }


__all__ = [
    "BUILTIN_PROVIDER_ENDPOINTS",
    "OPENAI_COMPATIBLE_PROVIDER_ALIASES",
    "PROVIDER_CAPABILITIES",
    "ProviderCapabilities",
    "ProviderConfig",
    "ProviderResponse",
    "RetryClassification",
    "classify_error",
    "get_provider_capabilities",
]
