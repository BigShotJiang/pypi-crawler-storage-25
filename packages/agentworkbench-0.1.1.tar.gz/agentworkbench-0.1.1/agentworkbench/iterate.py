from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.briefs import brief_path
from agentworkbench.config import control_dir, load_model
from agentworkbench.evals import load_eval_suite, preferred_subset
from agentworkbench.models import BehaviorBrief, IterationLane, IterationPlan, MutationProposal
from agentworkbench.proposals import generate_mutation_proposals
from agentworkbench.reports import render_iteration_report, write_report
from agentworkbench.runner import diagnose_experiment
from agentworkbench.utils import ensure_dir, write_json


def iterations_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "iterations")


def _behavior_contract(project_root: Path, brief_id: str) -> dict[str, Any]:
    if not brief_id:
        return {}
    path = brief_path(project_root, brief_id)
    if not path.exists():
        return {}
    brief = load_model(path, BehaviorBrief)
    workflows = []
    for item in brief.workflow_scenarios[:6]:
        workflows.append(
            {
                "name": item.get("name") or item.get("trigger") or "unnamed-workflow",
                "trigger": item.get("trigger") or item.get("prompt") or "",
                "expected_tools": [str(value) for value in item.get("expected_tools", [])][:8],
                "expected_skills": [str(value) for value in item.get("expected_skills", [])][:8],
                "expected_plugins": [str(value) for value in item.get("expected_plugins", [])][:8],
                "expected_mcps": [str(value) for value in item.get("expected_mcps", [])][:8],
                "expected_prompt_keys": [str(value) for value in item.get("expected_prompt_keys", [])][:8],
                "expected_workflow_steps": [str(value) for value in item.get("expected_workflow_steps", [])][:12],
                "expected_workflow_sequence": [str(value) for value in item.get("expected_workflow_sequence", [])][:12],
                "max_steps": item.get("max_steps"),
            }
        )
    return {
        "goal": brief.goal,
        "approval_status": brief.approval_status,
        "desired_behaviors": brief.desired_behaviors[:8],
        "non_goals": brief.non_goals[:8],
        "acceptance_criteria": brief.acceptance_criteria[:8],
        "better_signals": brief.better_signals[:8],
        "worse_signals": brief.worse_signals[:8],
        "prompt_variants": brief.prompt_variants[:8],
        "preferred_tools": brief.preferred_tools[:8],
        "preferred_skills": brief.preferred_skills[:8],
        "preferred_plugins": brief.preferred_plugins[:8],
        "preferred_mcps": brief.preferred_mcps[:8],
        "likely_user_commands": brief.likely_user_commands[:6],
        "workflows": workflows,
    }


def _readiness_payload(project_root: Path, diagnosis: dict[str, Any], preferred_subset: str) -> dict[str, Any]:
    discovery_path = control_dir(project_root) / "discovery" / "repo-summary.json"
    suite = load_eval_suite(project_root, str(diagnosis.get("eval_id") or ""))
    brief_id = str(suite.brief_id or "")
    contract = _behavior_contract(project_root, brief_id)
    subset = str(diagnosis.get("subset") or "")
    notes = [
        "Capture expected outputs, tool calls, skills, plugins, MCPs, prompt variants, and runtime guardrails before mutating the agent.",
        "Keep benchmark drift explicit: if briefs, evals, or scorers change, treat that as benchmark work rather than agent optimization.",
    ]
    if preferred_subset != subset:
        notes.insert(
            0,
            f"Use `{preferred_subset}` for real optimization and promotion decisions. The current `{subset}` subset is only a fast local check.",
        )
    return {
        "discovery_summary_path": str(discovery_path.relative_to(project_root)) if discovery_path.exists() else None,
        "brief_id": brief_id or None,
        "eval_id": suite.id,
        "eval_approval_status": suite.approval_status,
        "score_weights": suite.score_weights,
        "behavior_contract": contract,
        "loop_checks": {
            "passed": (diagnosis.get("loop_checks") or {}).get("passed"),
            "summary": (diagnosis.get("loop_checks") or {}).get("summary") or {},
            "hints": (diagnosis.get("loop_checks") or {}).get("hints") or [],
            "findings": (diagnosis.get("loop_checks") or {}).get("findings") or [],
        },
        "notes": notes,
    }


def _measurement_focus(proposal: MutationProposal) -> tuple[list[str], list[str], list[str]]:
    category = proposal.category
    common_metrics = [
        "metric.output_quality",
        "metric.process_alignment",
        "avg_step_count_delta",
        "avg_latency_ms_delta",
        "avg_cost_estimate_delta",
        "selected_evidence_use_rate_delta",
        "tool_usage_count_deltas",
        "skill_usage_count_deltas",
        "plugin_usage_count_deltas",
        "mcp_usage_count_deltas",
        "prompt_usage_count_deltas",
        "workflow_step_count_deltas",
        "average_token_usage_deltas",
        "trace_event_label_deltas",
        "surface_audit_deltas",
        "tool_audit_deltas",
        "mcp_audit_deltas",
    ]
    mapping = {
        "code_structure": (
            [
                "Improve target-agent modularity without changing measured behavior.",
                "Watch score, process alignment, and surface usage to confirm the refactor stays behavior-preserving.",
            ],
            [*common_metrics, "loop_readiness"],
            [
                "Do not mix structural cleanup with prompt or scorer changes in the same iteration.",
            ],
        ),
        "agent_topology": (
            [
                "Align one-agent, chain, or workflow shape with the actual eval contract.",
                "Measure workflow trace, step count, route decisions, dead ends, and duplicate work after the topology edit.",
            ],
            [*common_metrics, "loop_readiness", "workflow_step_count_deltas"],
            [
                "Only add agents when the benchmark explicitly requires routing, handoff, specialization, or fan-out.",
            ],
        ),
        "eval_contract": (
            [
                "Make process expectations explain why a tool, MCP, prompt key, or workflow step is required.",
                "Keep benchmark-contract edits separate from target-agent behavior edits.",
            ],
            [*common_metrics, "loop_readiness", "benchmark_drift"],
            [
                "If evals, briefs, or scorers change, treat the next compare as benchmark work, not clean agent optimization.",
            ],
        ),
        "deterministic_fallback": (
            [
                "Remove benchmark-specific output paths from the target runtime.",
                "Confirm passing cases are supported by input handling, model output, tools, or evidence rather than exact fixtures.",
            ],
            [*common_metrics, "loop_readiness", "trace_event_label_deltas"],
            [
                "No critical deterministic fallback finding should remain before promotion.",
            ],
        ),
        "retrieval_quality": (
            [
                "Improve answer quality on failing cases while keeping the same retrieval surfaces active.",
                "Check whether tool calls, skill use, plugin use, and MCP use still cover the evidence path needed by the case.",
                "Watch token and step drift so retrieval fixes do not quietly add overhead.",
            ],
            common_metrics,
            [
                "Required tools, skills, plugins, MCPs, and prompt keys for the focus cases should not regress.",
                "Score gains should not come from widening the benchmark or changing scorer logic.",
            ],
        ),
        "prompt_grounding": (
            [
                "Improve answer wording and required term coverage without changing the retrieval path unless needed.",
                "Keep tool, skill, plugin, and MCP usage stable so prompt edits stay attributable.",
            ],
            common_metrics,
            [
                "Avoid overfitting to exact benchmark wording beyond the required local phrases.",
            ],
        ),
        "surface_contract": (
            [
                "Make the runtime obey the declared tool and MCP surfaces exactly.",
                "Measure process alignment, trace evidence, tool calls, MCP usage, and contract violations together.",
            ],
            [*common_metrics, "surface_contract_violation_count_delta", "surface_contract_violations_added", "surface_contract_violations_removed"],
            [
                "Do not hide contract drift by only changing reports; runtime behavior and emitted telemetry both need to match the spec.",
            ],
        ),
        "tool_routing": (
            [
                "Increase process alignment by routing the right tool, skill, plugin, MCP, and prompt surfaces on workflow cases.",
                "Measure both answer quality and workflow telemetry, not only the final text.",
            ],
            common_metrics,
            [
                "Do not add extra planner or reviewer hops unless they pay for themselves in score.",
            ],
        ),
        "step_budget": (
            [
                "Reduce steps and latency without lowering answer quality or process alignment.",
                "Check whether fewer tool calls or skill reads still preserve the required workflow.",
            ],
            common_metrics,
            [
                "Do not trade away required tool, skill, plugin, or MCP usage just to look cheaper.",
            ],
        ),
        "cost_budget": (
            [
                "Reduce token, model, tool, skill, plugin, and MCP overhead while holding score.",
                "Track surface usage separately so cost cuts are explainable rather than accidental.",
            ],
            common_metrics,
            [
                "Do not accept cheaper runs that hide regressions in process alignment or required terms.",
            ],
        ),
        "surface_pruning": (
            [
                "Reduce unused available surface while keeping measured behavior flat or better.",
                "Check tool, skill, plugin, MCP, and prompt coverage directly after pruning.",
            ],
            common_metrics,
            [
                "Pruning should not lower score or remove latent workflow coverage that the eval suite actually exercises.",
            ],
        ),
        "stability_validation": (
            [
                "Measure repeated-run variance separately from one-off score deltas.",
                "Keep score, latency, and cost stability visible before promotion.",
            ],
            [*common_metrics, "candidate_score_stddev", "candidate_latency_cv", "candidate_cost_cv"],
            [
                "Do not raise repeat counts so far that the live loop becomes impractical for the target provider budget.",
            ],
        ),
    }
    return mapping.get(
        category,
        (
            ["Measure output quality, process alignment, and surface usage separately so the next pass stays interpretable."],
            common_metrics,
            ["Keep the next mutation narrow enough that score movement is attributable."],
        ),
    )


def _compare_targets(diagnosis: dict[str, Any]) -> list[dict[str, Any]]:
    ladder = diagnosis.get("baseline_ladder") or {}
    targets: list[dict[str, Any]] = []
    seen: set[str] = set()
    for label in ["promoted_baseline", "same_model_best", "same_agent_best", "overall_best"]:
        value = ladder.get(label) or {}
        experiment_id = str(value.get("experiment_id") or "")
        if not experiment_id or experiment_id in seen:
            continue
        seen.add(experiment_id)
        targets.append(
            {
                "label": label,
                "experiment_id": experiment_id,
                "model_name": value.get("model_name"),
                "average_score": value.get("average_score"),
            }
        )
    baseline_id = str(diagnosis.get("baseline_id") or "")
    if baseline_id and baseline_id not in seen:
        seen.add(baseline_id)
        targets.insert(0, {"label": "selected_baseline", "experiment_id": baseline_id})
    return targets


def _validation_commands(
    diagnosis: dict[str, Any],
    preferred_subset: str,
    compare_targets: list[dict[str, Any]],
) -> list[str]:
    agent_id = str(diagnosis.get("agent_id") or "")
    eval_id = str(diagnosis.get("eval_id") or "")
    benchmark_signature = str(diagnosis.get("benchmark_signature") or "")
    commands = [f"awb run --agent-id {agent_id} --eval-id {eval_id} --subset {preferred_subset}"]
    for target in compare_targets[:3]:
        commands.append(f"awb compare --baseline {target['experiment_id']} --candidate <new-experiment-id>")
    commands.extend(
        [
            f"awb check --agent-id {agent_id} --eval-id {eval_id} --subset {preferred_subset}",
            "awb diagnose --experiment <new-experiment-id>",
            f"awb status --eval-id {eval_id} --subset {preferred_subset} --benchmark-signature {benchmark_signature}",
        ]
    )
    return commands


def _ablation_command(diagnosis: dict[str, Any], proposal: MutationProposal) -> str | None:
    if proposal.category not in {"prompt_grounding", "tool_routing", "surface_pruning"}:
        return None
    return f"awb ablate --experiment {diagnosis['experiment_id']}"


def build_iteration_plan(
    project_root: Path,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    baseline_id: str | None = None,
    limit: int = 3,
) -> dict[str, Any]:
    diagnosis = diagnose_experiment(
        project_root,
        experiment_id=experiment_id,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        baseline_id=baseline_id,
    )
    proposals_payload = generate_mutation_proposals(
        project_root,
        experiment_id=diagnosis.get("experiment_id"),
        baseline_id=baseline_id or diagnosis.get("baseline_id"),
        limit=limit,
    )
    preferred_run_subset = preferred_subset(
        project_root,
        str(diagnosis.get("eval_id") or ""),
        str(diagnosis.get("subset") or ""),
    )
    compare_targets = _compare_targets(diagnosis)
    lanes: list[IterationLane] = []
    for index, item in enumerate(proposals_payload.get("proposals", [])[:limit], start=1):
        proposal = MutationProposal.model_validate(item)
        measurement_focus, metrics_to_watch, guardrails = _measurement_focus(proposal)
        lanes.append(
            IterationLane(
                lane_id=f"{diagnosis['experiment_id']}-lane-{index:02d}-{proposal.category}",
                category=proposal.category,
                title=proposal.title,
                priority=proposal.priority,
                rationale=proposal.rationale,
                related_cases=proposal.related_cases,
                target_surfaces=proposal.target_surfaces,
                target_files=proposal.target_files,
                target_paths=proposal.target_paths,
                measurement_focus=measurement_focus,
                metrics_to_watch=metrics_to_watch,
                guardrails=[*guardrails, *proposal.acceptance_checks],
                compare_against=compare_targets,
                ablation_command=_ablation_command(diagnosis, proposal),
                validation_commands=_validation_commands(diagnosis, preferred_run_subset, compare_targets),
            )
        )
    notes = [
        "Measure score, required terms, tool calls, skill reads, plugin use, MCP use, prompt use, steps, latency, tokens, and cost separately.",
        "Prefer full runs for real optimization and promotion decisions. Use smoke subsets only for fast local debugging.",
    ]
    plan = IterationPlan(
        plan_id=f"{diagnosis['experiment_id']}-iterate",
        experiment_id=str(diagnosis.get("experiment_id") or ""),
        baseline_id=diagnosis.get("baseline_id"),
        benchmark_signature=str(diagnosis.get("benchmark_signature") or ""),
        recommended_action=str(diagnosis.get("recommended_action") or "review"),
        summary=str(diagnosis.get("summary") or ""),
        preferred_subset=preferred_run_subset,
        notes=notes,
        baseline_ladder=diagnosis.get("baseline_ladder") or {},
        readiness=_readiness_payload(project_root, diagnosis, preferred_run_subset),
        lanes=lanes,
        command_sequence=_validation_commands(diagnosis, preferred_run_subset, compare_targets),
    )
    payload = plan.model_dump(mode="json")
    root = iterations_dir(project_root)
    write_json(root / f"iterate-{diagnosis['experiment_id']}.json", payload)
    write_json(root / "latest.json", payload)
    write_report(root / f"iterate-{diagnosis['experiment_id']}.md", render_iteration_report(payload))
    write_report(root / "latest.md", render_iteration_report(payload))
    return payload
