from __future__ import annotations

from typing import Any

from agentworkbench.report_builder import ReportBuilder


def render_status_report(payload: dict[str, Any]) -> str:
    latest = payload.get("latest_experiment") or {}
    latest_baseline_ladder = payload.get("latest_baseline_ladder") or {}
    latest_compare = payload.get("latest_compare") or {}
    promotion_counts = payload.get("promotion_counts") or {}

    report = ReportBuilder("Workbench Status")
    report.bullet(f"Project root: `{payload.get('project_root') or '.'}`")
    report.bullet(f"Agent filter: `{payload.get('agent_id') or 'all'}`")
    report.bullet(f"Eval filter: `{payload.get('eval_id') or 'all'}`")
    report.bullet(f"Subset filter: `{payload.get('subset') or 'all'}`")
    report.bullet(f"Benchmark filter: `{payload.get('benchmark_signature') or 'all'}`")
    report.bullet(f"Promoted only: `{payload.get('promoted_only', False)}`")
    report.bullet(f"Total experiments: {payload.get('total_experiments', 0)}")
    report.bullet(f"Benchmark signatures: {', '.join(payload.get('benchmark_signatures', [])) or 'none'}")
    report.bullet(
        "Promotion counts: "
        f"candidate={promotion_counts.get('candidate', 0)}, "
        f"promoted={promotion_counts.get('promoted', 0)}, "
        f"rejected={promotion_counts.get('rejected', 0)}"
    )

    report.section("Gate Policy")
    report.kv_map(payload.get("gates") or {})

    report.section("Latest Experiment")
    if latest:
        report.bullet(
            f"`{latest.get('experiment_id')}`: score {float(latest.get('average_score', 0.0)):.3f}, "
            f"passed {latest.get('passed_cases', 0)}/{latest.get('total_cases', 0)}, "
            f"model=`{latest.get('model_name', 'unknown')}`, "
            f"subset=`{latest.get('subset') or 'unknown'}`, benchmark=`{latest.get('benchmark_signature', 'unknown')}`, "
            f"avg_trace_events={float(latest.get('average_trace_event_count', 0.0)):.2f}, "
            f"avg_evidence={float(latest.get('average_evidence_record_count', 0.0)):.2f}, "
            f"evidence_use_rate={latest.get('selected_evidence_use_rate', 'n/a')}, "
            f"avg_cost={float(latest.get('average_cost_estimate', 0.0)):.6f}, "
            f"promotion=`{latest.get('promotion_status') or 'candidate'}`"
        )
    else:
        report.bullet("none")

    report.section("Latest Baseline Ladder")
    if latest_baseline_ladder:
        for key, value in latest_baseline_ladder.items():
            if not value:
                report.bullet(f"`{key}`: none")
                continue
            report.bullet(
                f"`{key}`: `{value.get('experiment_id', 'unknown')}`, "
                f"score={float(value.get('average_score', 0.0)):.3f}, "
                f"passed={value.get('passed_cases', 0)}/{value.get('total_cases', 0)}, "
                f"model=`{value.get('model_name', 'unknown')}`"
            )
    else:
        report.bullet("none")

    report.section("Latest Compare")
    if latest_compare:
        report.bullet(
            f"`{latest_compare.get('baseline_id', 'unknown')}` -> `{latest_compare.get('candidate_id', 'unknown')}`: "
            f"mode=`{latest_compare.get('comparison_mode', 'unknown')}`, "
            f"recommended=`{latest_compare.get('recommended_action') or 'review'}`, "
            f"summary={latest_compare.get('summary') or 'none'}"
        )
    else:
        report.bullet("none")

    report.section("Pareto Frontier")
    pareto_frontier = payload.get("pareto_frontier") or []
    if pareto_frontier:
        for item in pareto_frontier[:5]:
            report.bullet(
                f"`{item.get('experiment_id', 'unknown')}`: "
                f"score={float(item.get('average_score', 0.0)):.3f}, "
                f"passed={item.get('passed_cases', 0)}/{item.get('total_cases', 0)}, "
                f"latency={float(item.get('average_latency_ms', 0.0)):.2f}ms, "
                f"cost={float(item.get('average_cost_estimate', 0.0)):.6f}, "
                f"model=`{item.get('model_name', 'unknown')}`"
            )
    else:
        report.bullet("none")

    report.section("Latest Stability")
    latest_stability = payload.get("latest_stability") or {}
    if latest_stability:
        metrics = latest_stability.get("metrics") or {}
        score_metrics = metrics.get("average_score") or {}
        latency_metrics = metrics.get("average_latency_ms") or {}
        cost_metrics = metrics.get("average_cost_estimate") or {}
        report.bullet(
            f"`{latest_stability.get('series_id', 'series')}`: "
            f"label=`{latest_stability.get('label') or latest_stability.get('series_id') or 'series'}`, "
            f"repeats={latest_stability.get('repeat_count', 0)}, "
            f"representative=`{latest_stability.get('representative_experiment_id', 'unknown')}`, "
            f"score_mean={score_metrics.get('mean', 'n/a')}, "
            f"score_stddev={score_metrics.get('stddev', 'n/a')}, "
            f"latency_cv={latency_metrics.get('cv', 'n/a')}, "
            f"cost_cv={cost_metrics.get('cv', 'n/a')}"
        )
        report.bullet(f"selection: {latest_stability.get('selection') or {}}")
    else:
        report.bullet("none")

    report.section("Latest Matrix")
    latest_matrix = payload.get("latest_matrix") or {}
    if latest_matrix:
        report.bullet(
            f"`{latest_matrix.get('matrix_id', 'matrix')}`: "
            f"experiments={latest_matrix.get('experiment_count', 0)}, "
            f"agents={', '.join(latest_matrix.get('agent_ids', [])) or 'none'}, "
            f"eval=`{latest_matrix.get('eval_id') or 'unknown'}`, "
            f"subset=`{latest_matrix.get('subset') or 'unknown'}`, "
            f"benchmark_signatures={', '.join(latest_matrix.get('benchmark_signatures', [])) or 'none'}"
        )
        best = latest_matrix.get("best_by_score") or {}
        cheapest = latest_matrix.get("cheapest") or {}
        fastest = latest_matrix.get("fastest") or {}
        report.bullet(
            f"best_by_score=`{best.get('experiment_id', 'none')}`, "
            f"cheapest=`{cheapest.get('experiment_id', 'none')}`, "
            f"fastest=`{fastest.get('experiment_id', 'none')}`"
        )
    else:
        report.bullet("none")

    report.section("Latest Factorial")
    latest_factorial = payload.get("latest_factorial") or {}
    if latest_factorial:
        report.bullet(
            f"`{latest_factorial.get('factorial_id', 'factorial')}`: "
            f"source=`{latest_factorial.get('source_experiment_id', 'unknown')}`, "
            f"control=`{latest_factorial.get('control_experiment_id', 'unknown')}`, "
            f"factors={', '.join(latest_factorial.get('selected_factors', [])) or 'none'}, "
            f"combinations={latest_factorial.get('combination_count', 0)}"
        )
        top_effect = (latest_factorial.get("factor_effects") or [{}])[0]
        if top_effect:
            report.bullet(
                f"top_effect: `{top_effect.get('factor') or 'unknown'}` "
                f"avg_score_delta={float(top_effect.get('average_score_effect', 0.0)):+.3f}, "
                f"avg_passed_delta={float(top_effect.get('passed_case_effect', 0.0)):+.3f}"
            )
    else:
        report.bullet("none")

    report.section("Latest Ablation")
    latest_ablation = payload.get("latest_ablation") or {}
    if latest_ablation:
        report.bullet(
            f"`{latest_ablation.get('ablation_id', 'ablation')}`: "
            f"source=`{latest_ablation.get('source_experiment_id', 'unknown')}`, "
            f"surfaces={', '.join(latest_ablation.get('surfaces', [])) or 'none'}"
        )
        top_result = (latest_ablation.get("results") or [{}])[0]
        if top_result:
            report.bullet(
                f"top_result: `{top_result.get('surface_kind') or 'surface'}:{top_result.get('surface_name') or 'unknown'}` "
                f"avg_score_delta={float(top_result.get('average_score_delta', 0.0)):+.3f}, "
                f"avg_passed_delta={float(top_result.get('passed_case_delta', 0.0)):+.3f}"
            )
    else:
        report.bullet("none")

    report.section("Tool And MCP Recommendations")
    surface_recommendations = payload.get("surface_recommendations") or []
    if surface_recommendations:
        for item in surface_recommendations:
            report.bullet(
                f"{item.get('surface') or 'surface'}: "
                f"{item.get('recommendation') or 'review'} "
                f"(priority={item.get('priority', 'n/a')})"
            )
    else:
        report.bullet("none")

    return report.text()
