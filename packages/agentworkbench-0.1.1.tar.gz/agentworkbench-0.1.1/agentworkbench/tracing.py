from __future__ import annotations

from typing import Any

TRACE_SCHEMA_VERSION = "awb.trace.v1"
TRACE_TAXONOMY = "awb.canonical.v1"
CANONICAL_TRACE_EVENT_KINDS = {
    "budget",
    "command",
    "decision",
    "event",
    "mcp",
    "memory_lookup",
    "planning",
    "plugin",
    "prompt",
    "prompt_load",
    "provider_request",
    "provider_response",
    "python",
    "retrieval",
    "runtime",
    "skill",
    "startup",
    "tool",
    "tool_call",
    "workflow",
}
_TRACE_KIND_ALIASES = {
    "llm_request": "provider_request",
    "llm_response": "provider_response",
    "mcp_server": "mcp",
    "memory": "memory_lookup",
    "plan": "planning",
    "prompt_key": "prompt",
    "tool_use": "tool",
}


def _compact_scalar_payload(payload: dict[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, (bool, float, int, str)):
            compact[str(key)] = value
    return compact


def _step_event(step: str, seq: int, source: str) -> dict[str, Any]:
    kind, separator, remainder = step.partition(":")
    normalized_kind = _canonical_kind(str(kind or "workflow"))
    name = str(remainder or step)
    return {
        "seq": seq,
        "kind": normalized_kind,
        "name": name,
        "label": f"{normalized_kind}:{name}",
        "source": source,
        "provenance": "raw",
    }


def _named_surface_events(kind: str, values: list[str], seen: set[str], start_seq: int, source: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    seq = start_seq
    for value in values:
        label = f"{kind}:{value}"
        if label in seen:
            continue
        seen.add(label)
        events.append(
            {
                "seq": seq,
                "kind": kind,
                "name": str(value),
                "label": label,
                "source": source,
                "provenance": "raw",
            }
        )
        seq += 1
    return events


def _tool_call_events(tool_calls: list[dict[str, Any]], seen: set[str], start_seq: int) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    seq = start_seq
    for call in tool_calls:
        name = str(call.get("name") or call.get("tool") or call.get("id") or "").strip()
        if not name:
            continue
        label = f"tool:{name}"
        compact = _compact_scalar_payload({key: value for key, value in call.items() if key not in {"name", "tool", "id"}})
        if label not in seen:
            seen.add(label)
            event = {
                "seq": seq,
                "kind": "tool",
                "name": name,
                "label": label,
                "source": "tool_calls",
                "provenance": "raw",
            }
            if compact:
                event["data"] = compact
            events.append(event)
            seq += 1
            continue
        if compact:
            events.append(
                {
                    "seq": seq,
                    "kind": "tool_call",
                    "name": name,
                    "label": f"tool_call:{name}",
                    "source": "tool_calls",
                    "provenance": "raw",
                    "data": compact,
                }
            )
            seq += 1
    return events


def _explicit_event(raw: Any, seq: int) -> dict[str, Any] | None:
    if isinstance(raw, str):
        return _step_event(raw, seq, "explicit")
    if not isinstance(raw, dict):
        return None
    kind = _canonical_kind(str(raw.get("kind") or raw.get("type") or raw.get("category") or "event"))
    name = str(raw.get("name") or raw.get("label") or raw.get("step") or kind)
    label = str(raw.get("label") or f"{kind}:{name}")
    event = {
        "seq": seq,
        "kind": kind,
        "name": name,
        "label": label,
        "source": "explicit",
        "provenance": str(raw.get("provenance") or "raw"),
    }
    compact = _compact_scalar_payload(
        {
            key: value
            for key, value in raw.items()
            if key not in {"seq", "kind", "type", "category", "name", "label", "step"}
        }
    )
    if compact:
        event["data"] = compact
    return event


def normalize_trace_events(structured_output: dict[str, Any]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    seen_labels: set[str] = set()
    seq = 1

    for raw in structured_output.get("events") or []:
        event = _explicit_event(raw, seq)
        if event is None:
            continue
        label = str(event.get("label") or "")
        if label:
            seen_labels.add(label)
        events.append(event)
        seq += 1

    for step in structured_output.get("workflow_trace") or []:
        event = _step_event(str(step), seq, "workflow_trace")
        label = str(event.get("label") or "")
        if label not in seen_labels:
            seen_labels.add(label)
            events.append(event)
            seq += 1

    tool_calls = [item for item in structured_output.get("tool_calls") or [] if isinstance(item, dict)]
    tool_events = _tool_call_events(tool_calls, seen_labels, seq)
    events.extend(tool_events)
    seq += len(tool_events)

    surface_sources = [
        ("prompt", [str(item) for item in structured_output.get("prompt_keys_used") or []], "prompt_keys_used"),
        ("skill", [str(item) for item in structured_output.get("skills_used") or []], "skills_used"),
        ("plugin", [str(item) for item in structured_output.get("plugins_used") or []], "plugins_used"),
        ("mcp", [str(item) for item in structured_output.get("mcp_servers_used") or []], "mcp_servers_used"),
    ]
    for kind, values, source in surface_sources:
        surface_events = _named_surface_events(kind, values, seen_labels, seq, source)
        events.extend(surface_events)
        seq += len(surface_events)

    return events


def trace_event_label(event: dict[str, Any]) -> str:
    label = event.get("label")
    if label:
        return str(label)
    kind = str(event.get("kind") or "event")
    name = str(event.get("name") or kind)
    return f"{kind}:{name}"


def _canonical_kind(kind: str) -> str:
    normalized = str(kind or "event").strip() or "event"
    return _TRACE_KIND_ALIASES.get(normalized, normalized)


def trace_schema_metadata() -> dict[str, Any]:
    return {
        "version": TRACE_SCHEMA_VERSION,
        "taxonomy": TRACE_TAXONOMY,
        "canonical_kinds": sorted(CANONICAL_TRACE_EVENT_KINDS),
    }
