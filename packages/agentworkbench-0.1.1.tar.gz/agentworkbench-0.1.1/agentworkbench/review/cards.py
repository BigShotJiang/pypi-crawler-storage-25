from __future__ import annotations

from html import escape
from typing import Any

from agentworkbench.review.common import html_json, html_list, html_metric


def render_case_card(
    row: dict[str, Any],
    baseline_row: dict[str, Any] | None = None,
    show_evidence: bool = False,
) -> str:
    case = row.get("case") or {}
    artifact = row.get("artifact") or {}
    scores = [dict(item) for item in row.get("scores", []) if isinstance(item, dict)]
    passed = bool(row.get("passed", False))
    score_value = float(row.get("score", 0.0) or 0.0)
    case_id = str(case.get("id") or "unknown")
    input_text = str(case.get("input") or "")
    expected_text = str(case.get("expected") or "")
    final_output = str(artifact.get("final_output") or "")
    search_blob = " ".join(
        [
            case_id,
            input_text,
            expected_text,
            final_output,
            " ".join(str(item.get("name") or "") for item in artifact.get("tool_calls", []) if isinstance(item, dict)),
            " ".join(str(item) for item in artifact.get("workflow_trace", [])),
            " ".join(str(item) for item in artifact.get("errors", [])),
        ]
    ).lower()
    status_class = "pass" if passed else "fail"
    compare_block = ""
    if baseline_row is not None:
        baseline_artifact = baseline_row.get("artifact") or {}
        baseline_output = str(baseline_artifact.get("final_output") or "")
        baseline_score = float(baseline_row.get("score", 0.0) or 0.0)
        delta = score_value - baseline_score
        delta_class = "pass" if delta >= 0 else "fail"
        compare_block = (
            '<div class="compare-grid">'
            f"<div><h4>Candidate Output</h4><pre>{escape(final_output)}</pre></div>"
            f"<div><h4>Baseline Output</h4><pre>{escape(baseline_output)}</pre></div>"
            "</div>"
            f'<p class="delta {delta_class}">score delta: {delta:+.3f}</p>'
        )
    else:
        compare_block = f"<pre>{escape(final_output)}</pre>"
    metrics_html = "".join(html_metric(score) for score in scores) or '<div class="muted">no scores</div>'
    sections = [
        f"<section><h4>Input</h4><pre>{escape(input_text)}</pre></section>",
        f"<section><h4>Expected</h4><pre>{escape(expected_text)}</pre></section>",
        f'<section class="span-two"><h4>Output</h4>{compare_block}</section>',
        f'<section class="span-two"><h4>Metrics</h4><div class="metrics">{metrics_html}</div></section>',
        f"<section><h4>Workflow</h4><ul>{html_list(list(artifact.get('workflow_trace') or []))}</ul></section>",
        f"<section><h4>Tools</h4><ul>{html_list([str((item or {}).get('name') or '') for item in artifact.get('tool_calls', []) if isinstance(item, dict)])}</ul></section>",
        f"<section><h4>Prompts</h4><ul>{html_list(list(artifact.get('prompt_keys_used') or []))}</ul></section>",
        f"<section><h4>MCPs</h4><ul>{html_list(list(artifact.get('mcp_servers_used') or []))}</ul></section>",
    ]
    if show_evidence:
        evidence_sections = _render_evidence_sections(artifact)
        sections.extend(evidence_sections)
    sections.extend(
        [
            f'<section class="span-two"><details><summary>Trace Events</summary><pre>{html_json(artifact.get("trace_events") or [])}</pre></details></section>',
            f'<section class="span-two"><details><summary>Metadata</summary><pre>{html_json(artifact.get("metadata") or {})}</pre></details></section>',
            f'<section class="span-two"><details><summary>Errors</summary><pre>{html_json(artifact.get("errors") or [])}</pre></details></section>',
        ]
    )
    return (
        f'<article class="case-card" data-search="{escape(search_blob)}" data-status="{status_class}">'
        f'<header><h3 id="{escape(case_id)}">{escape(case_id)}</h3><div class="case-meta">'
        f'<span class="badge {status_class}">{"pass" if passed else "fail"}</span>'
        f"<span>score {score_value:.3f}</span>"
        f"<span>latency {int(artifact.get('latency_ms', 0) or 0)}ms</span>"
        f"<span>steps {int(artifact.get('step_count', 0) or 0)}</span>"
        "</div></header>"
        '<div class="case-layout">' + "".join(sections) + "</div></article>"
    )


def _render_evidence_sections(artifact: dict[str, Any]) -> list[str]:
    evidence_records = artifact.get("evidence_records") or []
    if not evidence_records:
        return []
    sections = []
    for record in evidence_records:
        label = str(record.get("label") or "unknown")
        hits = record.get("hits") or []
        selected_hits = [h for h in hits if h.get("selected")]
        used_hits = [h for h in selected_hits if h.get("used_in_output")]
        if selected_hits:
            sections.append(
                f'<section class="span-two"><h4>Evidence: {escape(label)}</h4>'
                f'<p class="muted">{len(selected_hits)} selected, {len(used_hits)} used in output</p>'
                f"<ul>{html_list([str(h.get('snippet', '')[:100]) for h in selected_hits[:3]])}</ul></section>"
            )
    return sections


def rank_failures(rows: list[dict[str, Any]], top_n: int = 10) -> list[dict[str, Any]]:
    failures = []
    for row in rows:
        if not row.get("passed", True):
            scores = row.get("scores", [])
            reasons = [str(s.get("reason", "")) for s in scores if isinstance(s, dict)]
            failures.append(
                {
                    "case_id": str((row.get("case") or {}).get("id") or "unknown"),
                    "score": row.get("score", 0.0),
                    "reasons": reasons,
                }
            )
    return failures[:top_n]


__all__ = [
    "render_case_card",
    "rank_failures",
]
