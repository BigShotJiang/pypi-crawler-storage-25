from __future__ import annotations

from html import escape
from typing import Any


def render_summary_header(
    experiment: dict[str, Any],
    aggregate: dict[str, Any],
    spec_snapshot: dict[str, Any],
    behavior: dict[str, Any],
    baseline_experiment: dict[str, Any] | None = None,
) -> str:
    baseline_header = ""
    if baseline_experiment is not None:
        baseline_header = (
            f"<p>Baseline: <code>{escape(str(baseline_experiment.get('experiment_id') or 'unknown'))}</code> "
            f"agent=<code>{escape(str(baseline_experiment.get('agent_id') or 'unknown'))}</code></p>"
        )
    return f"""<section class="hero">
  <h1>Experiment Review</h1>
  <p><code>{escape(str(experiment.get("experiment_id") or "unknown"))}</code> agent=<code>{escape(str(experiment.get("agent_id") or "unknown"))}</code> eval=<code>{escape(str(experiment.get("eval_id") or "unknown"))}</code> subset=<code>{escape(str(experiment.get("subset") or ""))}</code></p>
  {baseline_header}
  <div class="summary-grid">
    <div><strong>Average score</strong><br>{float(aggregate.get("average_score", 0.0) or 0.0):.3f}</div>
    <div><strong>Passed</strong><br>{int(aggregate.get("passed_cases", 0) or 0)}/{int(aggregate.get("total_cases", 0) or 0)}</div>
    <div><strong>Model</strong><br>{escape(str(spec_snapshot.get("model_name") or "unknown"))}</div>
    <div><strong>Prompts used</strong><br>{escape(", ".join(behavior.get("prompt_keys_used", []) or []) or "none")}</div>
    <div><strong>Tools used</strong><br>{escape(", ".join(behavior.get("tools_used", []) or []) or "none")}</div>
    <div><strong>MCPs used</strong><br>{escape(", ".join(behavior.get("mcp_servers_used", []) or []) or "none")}</div>
  </div>
</section>"""


def render_toolbar(total_cases: int, filters: list[str] | None = None) -> str:
    filter_buttons = ""
    if filters:
        filter_buttons = "".join(f'<button class="filter-btn" data-filter="{f}">{f}</button>' for f in filters)
    return f"""<div class="toolbar">
  {filter_buttons}
  <input id="case-filter" type="search" placeholder="Filter cases by id, input, output, tool, trace, or error">
  <span class="muted">{total_cases} case cards</span>
</div>"""


__all__ = [
    "render_summary_header",
    "render_toolbar",
]
