from __future__ import annotations

import json
from html import escape
from typing import Any


def html_json(value: Any) -> str:
    return escape(json.dumps(value, indent=2, sort_keys=True))


def html_metric(score: dict[str, Any], *, include_judged_details: bool = False) -> str:
    name = escape(str(score.get("name") or "metric"))
    value = float(score.get("value", 0.0) or 0.0)
    passed = bool(score.get("passed", False))
    reason = escape(str(score.get("reason") or ""))
    badge_class = "pass" if passed else "fail"
    judge_badge = ""
    if include_judged_details:
        judged = score.get("judged") or {}
        if judged:
            fallback = escape(str(judged.get("fallback_path") or ""))
            ci = judged.get("confidence_interval")
            ci_text = ""
            if isinstance(ci, dict):
                ci_text = f" CI [{ci.get('lower', 0):.3f}, {ci.get('upper', 1):.3f}]"
            judge_badge = f'<span class="judge-badge {fallback}">{fallback}{ci_text}</span>'
    return (
        f'<div class="metric">'
        f'<span class="metric-name">{name}</span>'
        f'<span class="metric-value {badge_class}">{value:.3f}</span>'
        f'<span class="metric-reason">{reason}{judge_badge}</span>'
        f"</div>"
    )


def html_list(values: list[Any]) -> str:
    items = [escape(str(item)) for item in values if str(item).strip()]
    if not items:
        return '<span class="muted">none</span>'
    return "".join(f"<li>{item}</li>" for item in items)
