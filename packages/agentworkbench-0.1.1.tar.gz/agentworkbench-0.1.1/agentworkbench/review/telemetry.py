from __future__ import annotations

from html import escape
from typing import Any


def render_telemetry_view(artifact: dict[str, Any]) -> str:
    tool_calls = artifact.get("tool_calls") or []
    trace_events = artifact.get("trace_events") or []
    prompt_keys = artifact.get("prompt_keys_used") or []
    mcp_servers = artifact.get("mcp_servers_used") or []
    step_count = artifact.get("step_count", 0)
    latency_ms = artifact.get("latency_ms", 0)
    return f"""<section class="telemetry-view">
  <h3>Telemetry Summary</h3>
  <div class="telemetry-grid">
    <div><strong>Steps</strong><br>{step_count}</div>
    <div><strong>Latency</strong><br>{latency_ms}ms</div>
    <div><strong>Tools</strong><br>{len(tool_calls)} calls</div>
    <div><strong>Prompts</strong><br>{len(prompt_keys)} used</div>
    <div><strong>MCPs</strong><br>{len(mcp_servers)} used</div>
    <div><strong>Events</strong><br>{len(trace_events)} events</div>
  </div>
  <details><summary>Tool Calls Detail</summary>
    <pre>{escape(_format_tool_calls(tool_calls))}</pre>
  </details>
  <details><summary>Trace Events Detail</summary>
    <pre>{escape(_format_trace_events(trace_events))}</pre>
  </details>
</section>"""


def _format_tool_calls(tool_calls: list[Any]) -> str:
    if not tool_calls:
        return "none"
    lines = []
    for tc in tool_calls:
        name = tc.get("name") or tc.get("tool") or "unknown"
        args = tc.get("arguments") or {}
        lines.append(f"- {name}({args})")
    return "\n".join(lines)


def _format_trace_events(events: list[Any]) -> str:
    if not events:
        return "none"
    lines = []
    for e in events:
        label = e.get("label", "")
        ts = e.get("timestamp", "")
        lines.append(f"- {ts}: {label}")
    return "\n".join(lines)


def render_evidence_view(artifact: dict[str, Any]) -> str:
    evidence_records = artifact.get("evidence_records") or []
    if not evidence_records:
        return '<p class="muted">No evidence records available.</p>'
    sections = []
    for record in evidence_records:
        label = escape(str(record.get("label") or "unknown"))
        kind = escape(str(record.get("kind") or ""))
        hits = record.get("hits") or []
        selected = [h for h in hits if h.get("selected")]
        used = [h for h in selected if h.get("used_in_output")]
        hit_html = ""
        for h in selected[:5]:
            snippet = escape(str(h.get("snippet", ""))[:200])
            path = escape(str(h.get("path", "")))
            line = h.get("line", 0)
            used_class = " used" if h.get("used_in_output") else ""
            hit_html += f'<div class="evidence-hit{used_class}"><pre>{snippet}</pre><span class="muted">path: {path} line {line}</span></div>'
        sections.append(
            f'<div class="evidence-source">'
            f'<h4>{label} <span class="muted">({kind})</span></h4>'
            f"<p>{len(selected)} selected, {len(used)} used in output</p>"
            f"{hit_html}"
            f"</div>"
        )
    return f"""<section class="evidence-view">
  <h3>Evidence Provenance</h3>
  {"".join(sections)}
</section>"""


__all__ = [
    "render_telemetry_view",
    "render_evidence_view",
]
