from __future__ import annotations

from html import escape
from typing import Any


def render_compare_view(
    candidate_row: dict[str, Any],
    baseline_row: dict[str, Any],
) -> str:
    candidate_artifact = candidate_row.get("artifact") or {}
    baseline_artifact = baseline_row.get("artifact") or {}
    candidate_scores = candidate_row.get("scores", [])
    baseline_scores = baseline_row.get("scores", [])
    candidate_output = str(candidate_artifact.get("final_output") or "")
    baseline_output = str(baseline_artifact.get("final_output") or "")
    candidate_tools = [str(tc.get("name") or "") for tc in candidate_artifact.get("tool_calls", [])]
    baseline_tools = [str(tc.get("name") or "") for tc in baseline_artifact.get("tool_calls", [])]
    candidate_trace = list(candidate_artifact.get("workflow_trace") or [])
    baseline_trace = list(baseline_artifact.get("workflow_trace") or [])
    candidate_mcps = list(candidate_artifact.get("mcp_servers_used") or [])
    baseline_mcps = list(baseline_artifact.get("mcp_servers_used") or [])
    return f"""<section class="compare-view">
  <h3>Side-by-Side Comparison</h3>
  <div class="compare-output">
    <div><h4>Candidate Output</h4><pre>{escape(candidate_output)}</pre></div>
    <div><h4>Baseline Output</h4><pre>{escape(baseline_output)}</pre></div>
  </div>
  <div class="compare-metrics">
    <div><h4>Candidate Scores</h4>{_format_score_diffs(candidate_scores, baseline_scores)}</div>
  </div>
  <div class="compare-workflow">
    <div><h4>Candidate Workflow</h4><ul>{_format_list(candidate_trace)}</ul></div>
    <div><h4>Baseline Workflow</h4><ul>{_format_list(baseline_trace)}</ul></div>
  </div>
  <div class="compare-tools">
    <div><h4>Candidate Tools</h4><ul>{_format_list(candidate_tools)}</ul></div>
    <div><h4>Baseline Tools</h4><ul>{_format_list(baseline_tools)}</ul></div>
  </div>
  <div class="compare-mcps">
    <div><h4>Candidate MCPs</h4><ul>{_format_list(candidate_mcps)}</ul></div>
    <div><h4>Baseline MCPs</h4><ul>{_format_list(baseline_mcps)}</ul></div>
  </div>
</section>"""


def _format_score_diffs(candidate_scores: list[Any], baseline_scores: list[Any]) -> str:
    baseline_by_name = {str(s.get("name") or ""): s for s in baseline_scores if isinstance(s, dict)}
    lines = []
    for cs in candidate_scores:
        if not isinstance(cs, dict):
            continue
        name = str(cs.get("name") or "")
        cand_val = float(cs.get("value", 0.0))
        base = baseline_by_name.get(name, {})
        base_val = float(base.get("value", 0.0))
        delta = cand_val - base_val
        delta_str = f"{delta:+.3f}"
        delta_class = "pass" if delta >= 0 else "fail"
        lines.append(
            f'<div class="score-row">'
            f"<span>{escape(name)}</span>"
            f"<span>{cand_val:.3f}</span>"
            f'<span class="{delta_class}">{delta_str}</span>'
            f"</div>"
        )
    return "".join(lines) or '<span class="muted">no scores</span>'


def _format_list(items: list[str]) -> str:
    if not items:
        return '<li class="muted">none</li>'
    return "".join(f"<li>{escape(str(i))}</li>" for i in items)


__all__ = [
    "render_compare_view",
]
