from __future__ import annotations

from typing import Any


def render_terminal_review(
    bundle: dict[str, Any],
    baseline_bundle: dict[str, Any] | None = None,
    limit: int = 50,
) -> str:
    experiment = bundle.get("experiment") or {}
    aggregate = bundle.get("aggregate") or {}
    rows = list(bundle.get("rows") or bundle.get("partial_rows") or [])[:limit]
    lines = []
    lines.append("=" * 80)
    lines.append(f"EXPERIMENT REVIEW: {experiment.get('experiment_id', 'unknown')}")
    lines.append(f"Agent: {experiment.get('agent_id', 'unknown')} | Eval: {experiment.get('eval_id', 'unknown')}")
    lines.append(
        f"Score: {aggregate.get('average_score', 0.0):.3f} | Passed: {aggregate.get('passed_cases', 0)}/{aggregate.get('total_cases', 0)}"
    )
    lines.append("=" * 80)
    if baseline_bundle:
        baseline_exp = baseline_bundle.get("experiment") or {}
        lines.append(f"Baseline: {baseline_exp.get('experiment_id', 'unknown')}")
    lines.append("")
    lines.append("FAILED CASES:")
    lines.append("-" * 40)
    failed_count = 0
    for row in rows:
        if not row.get("passed", True):
            failed_count += 1
            case = row.get("case") or {}
            case_id = case.get("id", "unknown")
            score = row.get("score", 0.0)
            reasons = [s.get("reason", "") for s in row.get("scores", []) if not s.get("passed", True)]
            lines.append(f"  [{case_id}] score={score:.3f}")
            for reason in reasons[:2]:
                lines.append(f"    - {reason[:70]}")
    lines.append(f"\nTotal failed: {failed_count}/{len(rows)}")
    lines.append("")
    lines.append("TOP FAILURES (by score impact):")
    lines.append("-" * 40)
    failures = sorted([r for r in rows if not r.get("passed", True)], key=lambda r: r.get("score", 0.0))[:10]
    for i, row in enumerate(failures, 1):
        case = row.get("case") or {}
        lines.append(f"  {i}. {case.get('id', 'unknown')}: score={row.get('score', 0.0):.3f}")
    return "\n".join(lines)


def render_terminal_summary(
    bundle: dict[str, Any],
    baseline_bundle: dict[str, Any] | None = None,
) -> str:
    experiment = bundle.get("experiment") or {}
    aggregate = bundle.get("aggregate") or {}
    behavior = bundle.get("behavior") or {}
    spec = bundle.get("spec_snapshot") or {}
    lines = []
    lines.append("EXPERIMENT SUMMARY")
    lines.append("=" * 50)
    lines.append(f"ID:       {experiment.get('experiment_id', 'n/a')}")
    lines.append(f"Agent:    {experiment.get('agent_id', 'n/a')}")
    lines.append(f"Eval:     {experiment.get('eval_id', 'n/a')}")
    lines.append(f"Subset:   {experiment.get('subset', 'n/a')}")
    lines.append(f"Model:    {spec.get('model_name', 'unknown')}")
    lines.append("")
    lines.append("RESULTS")
    lines.append("-" * 50)
    lines.append(f"Score:      {aggregate.get('average_score', 0.0):.3f}")
    lines.append(f"Passed:     {aggregate.get('passed_cases', 0)}/{aggregate.get('total_cases', 0)}")
    lines.append(f"Pass Rate:  {aggregate.get('passed_cases', 0) / max(aggregate.get('total_cases', 1), 1) * 100:.1f}%")
    lines.append("")
    lines.append("BEHAVIOR")
    lines.append("-" * 50)
    lines.append(f"Avg Steps:     {behavior.get('average_step_count', 0):.1f}")
    lines.append(f"Avg Latency:   {behavior.get('average_latency_ms', 0):.0f}ms")
    lines.append(f"Avg Cost:      ${behavior.get('average_cost_estimate', 0):.4f}")
    tools = behavior.get("tools_used", [])
    lines.append(f"Tools:         {', '.join(tools[:5])}{'...' if len(tools) > 5 else ''}")
    prompts = behavior.get("prompt_keys_used", [])
    lines.append(f"Prompts:       {', '.join(prompts[:5])}{'...' if len(prompts) > 5 else ''}")
    if baseline_bundle:
        baseline_agg = baseline_bundle.get("aggregate") or {}
        delta = aggregate.get("average_score", 0.0) - baseline_agg.get("average_score", 0.0)
        lines.append("")
        lines.append("COMPARISON TO BASELINE")
        lines.append("-" * 50)
        lines.append(f"Baseline:     {baseline_bundle.get('experiment', {}).get('experiment_id', 'n/a')}")
        lines.append(f"Baseline Score: {baseline_agg.get('average_score', 0.0):.3f}")
        lines.append(f"Delta:          {delta:+.3f}")
    return "\n".join(lines)


__all__ = [
    "render_terminal_review",
    "render_terminal_summary",
]
