"""Bayesian Optimization for intelligent hyperparameter and surface search.

This module provides Bayesian optimization to replace exhaustive grid search
when the search space is large. It uses Gaussian Process surrogates and
Expected Improvement acquisition to intelligently explore.

Usage:
    from agentworkbench.bayesian import BayesianOptimizer, ParameterSpace

    # Define search space
    space = ParameterSpace({
        "temperature": (0.0, 1.0),        # Continuous
        "max_tokens": [256, 512, 1024, 2048],  # Discrete
        "use_tool_1": [True, False],           # Binary
    })

    optimizer = BayesianOptimizer(space, n_initial=4)

    # Try some initial random configs
    for _ in range(4):
        config = optimizer.suggest()
        score = run_experiment(config)  # Your experiment function
        optimizer.observe(config, score)

    # Bayesian optimization loop
    for _ in range(8):
        config = optimizer.suggest()
        score = run_experiment(config)
        optimizer.observe(config, score)

    best = optimizer.get_best()
"""

from __future__ import annotations

import importlib.util
import math
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, cast

import numpy as np
from numpy.typing import NDArray


@dataclass
class ParameterSpace:
    """Defines the search space for optimization.

    Args:
        dimensions: Dict mapping parameter names to their bounds/categories
                   - Continuous: (min, max) tuple
                   - Discrete: list of values
                   - Categorical: [True, False] for binary
    """

    dimensions: dict[str, tuple | list] = field(default_factory=dict)
    _discrete_map: dict[str, dict[int, Any]] = field(default_factory=dict, init=False)
    _value_to_index: dict[str, dict[Any, int]] = field(default_factory=dict, init=False)
    _bool_dims: set[str] = field(default_factory=set, init=False)

    def __post_init__(self):
        self._normalization_bounds: dict[str, tuple[float, float]] = {}
        for name, spec in self.dimensions.items():
            if isinstance(spec, tuple) and len(spec) == 2:
                # Continuous: normalize to [0, 1]
                self._normalization_bounds[name] = (spec[0], spec[1])
            elif isinstance(spec, list) and spec:
                categories = list(spec)
                if all(isinstance(item, bool) for item in categories):
                    self._bool_dims.add(name)
                    categories = [bool(item) for item in categories]
                self._discrete_map[name] = {i: value for i, value in enumerate(categories)}
                self._value_to_index[name] = {value: i for i, value in enumerate(categories)}

    def _normalize(self, params: dict[str, Any]) -> dict[str, float]:
        """Normalize params to [0, 1] space."""
        normalized = {}
        for name, value in params.items():
            spec = self.dimensions.get(name)
            if spec is None:
                continue
            if isinstance(spec, tuple):
                # Continuous: scale to [0, 1]
                min_val, max_val = spec
                normalized[name] = (value - min_val) / (max_val - min_val)
            elif isinstance(spec, list):
                categories = self._discrete_map.get(name, {})
                if not categories:
                    continue
                max_index = max(len(categories) - 1, 1)
                index: int | None
                if name in self._bool_dims:
                    index = 1 if bool(value) else 0
                else:
                    index = self._value_to_index.get(name, {}).get(value)
                    if index is None and isinstance(value, int) and value in categories:
                        index = value
                    if index is None:
                        index = 0
                normalized[name] = float(index) / float(max_index)
        return normalized

    def _denormalize(self, normalized: dict[str, float]) -> dict[str, Any]:
        """Convert normalized values back to original space."""
        denormalized = {}
        for name, value in normalized.items():
            spec = self.dimensions.get(name)
            if spec is None:
                continue
            if isinstance(spec, tuple):
                min_val, max_val = spec
                denormalized[name] = min_val + value * (max_val - min_val)
            elif isinstance(spec, list):
                categories = self._discrete_map.get(name, {})
                if not categories:
                    continue
                max_index = len(categories) - 1
                if max_index <= 0:
                    idx = 0
                else:
                    idx = int(round(value * max_index))
                    idx = max(0, min(idx, max_index))
                denormalized[name] = categories.get(idx)
        return denormalized

    def to_vector(self, params: dict[str, Any]) -> NDArray[np.float64]:
        """Convert params dict to numpy vector."""
        normalized = self._normalize(params)
        return np.array([normalized.get(k, 0.5) for k in self.dimensions.keys()])

    def from_vector(self, vector: NDArray[np.float64]) -> dict[str, Any]:
        """Convert numpy vector to params dict."""
        normalized = {k: vector[i] for i, k in enumerate(self.dimensions.keys())}
        return self._denormalize(normalized)

    @property
    def n_dims(self) -> int:
        """Number of dimensions."""
        return len(self.dimensions)


class GaussianProcessSurrogate:
    """Gaussian Process surrogate model for Bayesian optimization.

    Uses scikit-learn's GaussianProcessRegressor with automatic relevance
    determination (ARD) kernels for flexibility.
    """

    def __init__(self, n_dims: int, noise: float = 0.01):
        self.n_dims = n_dims
        self.noise = noise
        self.X_train: NDArray[np.float64] | None = None
        self.y_train: NDArray[np.float64] | None = None
        self._model: Any = None

    def _init_model(self):
        """Lazy import and initialize GP model."""
        try:
            from sklearn.gaussian_process import GaussianProcessRegressor  # type: ignore[import-not-found]
            from sklearn.gaussian_process.kernels import RBF, WhiteKernel  # type: ignore[import-not-found]
        except ImportError:
            self._model = None
            return

        kernel = RBF(length_scale=np.ones(self.n_dims), length_scale_bounds=(0.01, 10.0))
        kernel += WhiteKernel(noise_level=self.noise, noise_level_bounds=(1e-5, 1.0))

        self._model = GaussianProcessRegressor(
            kernel=kernel,
            n_restarts_optimizer=2,
            random_state=42,
            normalize_y=True,
        )

    def fit(self, X: NDArray[np.float64], y: NDArray[np.float64]) -> None:
        """Fit the GP to observed data."""
        if self._model is None:
            self._init_model()

        self.X_train = X
        self.y_train = y

        if self._model is not None and len(X) >= 2:
            self._model.fit(X, y)

    def predict(self, X: NDArray[np.float64]) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Predict mean and std for input points."""
        if self._model is None or self.X_train is None or len(self.X_train) < 2:
            # No model yet - return prior
            return np.full(len(X), 0.5), np.full(len(X), 1.0)

        mu, sigma = self._model.predict(X, return_std=True)
        return np.asarray(mu, dtype=np.float64), np.asarray(sigma, dtype=np.float64)

    def sample(self, X: NDArray[np.float64], n_samples: int = 1) -> NDArray[np.float64]:
        """Sample from the posterior distribution."""
        if self._model is None or self.X_train is None or len(self.X_train) < 2:
            return np.random.uniform(0, 1, (n_samples, self.n_dims))

        return np.asarray(self._model.sample_y(X, n_samples=n_samples), dtype=np.float64)


class ExpectedImprovement:
    """Expected Improvement acquisition function.

    Computes the expected improvement over the current best observation,
    balancing exploitation and exploration.
    """

    def __init__(self, xi: float = 0.01):
        self.xi = xi  # Exploration parameter

    def compute(self, mu: NDArray[np.float64], sigma: NDArray[np.float64], best: float) -> NDArray[np.float64]:
        """Compute EI for each point.

        Args:
            mu: Predicted means
            sigma: Predicted standard deviations
            best: Current best observation

        Returns:
            Expected improvement values
        """
        # Avoid division by zero
        sigma = np.maximum(sigma, 1e-10)

        # Standardized improvement
        z = (mu - best - self.xi) / sigma

        # EI formula
        ei = (mu - best - self.xi) * self._normal_cdf(z) + sigma * self._normal_pdf(z)

        # Set negative EI to 0 (no improvement)
        return np.maximum(ei, 0)

    @staticmethod
    def _normal_cdf(x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Standard normal CDF using scipy or approximation."""
        try:
            from scipy.stats import norm  # type: ignore[import-untyped]

            return np.asarray(norm.cdf(x), dtype=np.float64)
        except ImportError:
            # Approximation
            erf_values = np.vectorize(math.erf)(x / np.sqrt(2.0))
            return np.asarray(0.5 * (1 + erf_values), dtype=np.float64)

    @staticmethod
    def _normal_pdf(x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Standard normal PDF."""
        try:
            from scipy.stats import norm

            return np.asarray(norm.pdf(x), dtype=np.float64)
        except ImportError:
            return np.asarray(np.exp(-0.5 * x**2) / np.sqrt(2 * np.pi), dtype=np.float64)


class UpperConfidenceBound:
    """Upper Confidence Bound acquisition function.

    Balances mean prediction (exploitation) with uncertainty (exploration).
    """

    def __init__(self, kappa: float = 2.0):
        self.kappa = kappa  # Exploration weight

    def compute(self, mu: NDArray[np.float64], sigma: NDArray[np.float64], best: float) -> NDArray[np.float64]:
        """Compute UCB for each point."""
        return mu + self.kappa * sigma


@dataclass
class OptimizationResult:
    """Result of Bayesian optimization."""

    best_params: dict[str, Any]
    best_score: float
    all_observations: list[tuple[dict[str, Any], float]]
    n_iterations: int
    converged: bool


class BayesianOptimizer:
    """Bayesian optimizer for intelligent search.

    This replaces exhaustive grid/factorial search with intelligent
    probabilistic optimization.

    Usage:
        optimizer = BayesianOptimizer(
            space=ParameterSpace({"temp": (0.0, 1.0), "max_tokens": [512, 1024]}),
            n_initial=4,
            acquisition="ei",  # or "ucb"
        )

        for config in optimizer.suggest_initial():
            score = run_experiment(config)
            optimizer.observe(config, score)

        while optimizer.n_observations < total_budget:
            next_config = optimizer.suggest()
            score = run_experiment(next_config)
            optimizer.observe(next_config, score)

        result = optimizer.get_result()
    """

    def __init__(
        self,
        space: ParameterSpace,
        n_initial: int = 4,
        acquisition: str = "ei",
        minimize_noise: float = 0.01,
    ):
        self.space = space
        self.n_initial = n_initial
        self.minimize_noise = minimize_noise

        # Initialize components
        self._gp = GaussianProcessSurrogate(space.n_dims, noise=minimize_noise)

        self._acquisition: ExpectedImprovement | UpperConfidenceBound
        if acquisition == "ei":
            self._acquisition = ExpectedImprovement()
        elif acquisition == "ucb":
            self._acquisition = UpperConfidenceBound()
        else:
            raise ValueError(f"Unknown acquisition: {acquisition}")

        # Observations storage
        self._observations: list[tuple[dict[str, Any], float]] = []
        self._X_history: list[NDArray[np.float64]] = []
        self._y_history: list[float] = []

        # Best tracking
        self._best_score: float = float("-inf") if minimize_noise > 0 else float("-inf")
        self._best_params: dict[str, Any] | None = None

    def suggest_initial(self) -> list[dict[str, Any]]:
        """Generate initial random configurations.

        Returns:
            List of parameter configs to try initially
        """
        configs = []
        for _ in range(self.n_initial):
            config = self.space.from_vector(np.random.uniform(0, 1, self.space.n_dims))
            configs.append(config)
        return configs

    def suggest(self, n_candidates: int = 1) -> dict[str, Any] | list[dict[str, Any]]:
        """Suggest next configuration(s) to try.

        Uses the acquisition function to intelligently select
        the most promising next configuration.

        Args:
            n_candidates: Number of suggestions to return

        Returns:
            Single config (if n_candidates=1) or list of configs
        """
        n_obs = len(self._observations)

        if n_obs < self.n_initial:
            # Random sampling before we have enough data for GP
            pool = np.random.uniform(0, 1, (n_candidates * 2, self.space.n_dims))
            candidates = [self.space.from_vector(v) for v in pool[:n_candidates]]
            return candidates[0] if n_candidates == 1 else candidates

        # Try to use scipy optimization for better candidates
        try:
            has_scipy_optimize = importlib.util.find_spec("scipy.optimize") is not None
        except ModuleNotFoundError:
            has_scipy_optimize = False
        if has_scipy_optimize:
            best_candidates = self._optimize_acquisition_minimize(n_candidates)
            return best_candidates[0] if n_candidates == 1 else best_candidates

        # Generate candidate pool
        n_pool = max(100, n_candidates * 20)
        pool = np.random.uniform(0, 1, (n_pool, self.space.n_dims))

        # Get GP predictions
        mu, sigma = self._gp.predict(pool)

        # Compute acquisition values
        acq_values = self._acquisition.compute(mu, sigma, self._best_score)

        # Select top candidates
        top_indices = np.argsort(acq_values)[-n_candidates:][::-1]

        if n_candidates == 1:
            return self.space.from_vector(pool[top_indices[0]])

        return [self.space.from_vector(pool[i]) for i in top_indices]

    def _optimize_acquisition_minimize(self, n_candidates: int) -> list[dict[str, Any]]:
        """Optimize acquisition function using scipy.optimize."""
        from scipy.optimize import minimize  # type: ignore[import-untyped]

        candidates = []
        bounds = [(0, 1) for _ in range(self.space.n_dims)]

        for _ in range(n_candidates):
            # Multiple random starts
            best_acq = float("-inf")
            best_x = None

            for start in np.random.uniform(0, 1, (5, self.space.n_dims)):
                try:
                    result = minimize(
                        lambda x: -self._acquisition.compute(*self._gp.predict(x.reshape(1, -1)), self._best_score)[
                            0
                        ],
                        start,
                        method="L-BFGS-B",
                        bounds=bounds,
                    )
                    if -result.fun > best_acq:
                        best_acq = -result.fun
                        best_x = result.x
                except Exception:
                    continue

            if best_x is not None:
                candidates.append(self.space.from_vector(best_x))
            else:
                # Fallback
                candidates.append(self.space.from_vector(np.random.uniform(0, 1, self.space.n_dims)))

        return candidates

    def observe(self, params: dict[str, Any], score: float) -> None:
        """Record an observation.

        Args:
            params: The parameter configuration tried
            score: The objective score achieved
        """
        self._observations.append((params, score))

        # Convert to vector and store
        vector = self.space.to_vector(params)
        self._X_history.append(vector)
        self._y_history.append(score)

        # Update best
        if score > self._best_score:
            self._best_score = score
            self._best_params = params.copy()

        # Retrain GP if we have enough data
        if len(self._observations) >= 2:
            X = np.array(self._X_history)
            y = np.array(self._y_history)
            self._gp.fit(X, y)

    @property
    def n_observations(self) -> int:
        """Number of observations made."""
        return len(self._observations)

    @property
    def best_score(self) -> float:
        """Best score observed."""
        return self._best_score

    @property
    def best_params(self) -> dict[str, Any]:
        """Best parameters found."""
        return self._best_params.copy() if self._best_params else {}

    def get_result(self) -> OptimizationResult:
        """Get the final optimization result."""
        return OptimizationResult(
            best_params=self.best_params,
            best_score=self._best_score,
            all_observations=self._observations.copy(),
            n_iterations=self.n_observations,
            converged=self.n_observations >= self.n_initial + 8,
        )


class SurfaceBayesianOptimizer:
    """Specialized optimizer for surface (tool/skill/prompt) selection.

    This extends Bayesian optimization to handle the discrete
    binary on/off nature of surface selection.
    """

    def __init__(self, surfaces: list[str], n_initial: int = 4):
        self.surfaces = surfaces
        self.space = ParameterSpace({s: [True, False] for s in surfaces})
        self._optimizer = BayesianOptimizer(
            self.space,
            n_initial=n_initial,
            acquisition="ei",
        )

    def suggest_surface_combo(self) -> dict[str, bool]:
        """Suggest which surfaces to enable."""
        config = cast(dict[str, Any], self._optimizer.suggest())
        return {s: config.get(s, False) for s in self.surfaces}

    def observe_surface_combo(self, enabled: dict[str, bool], score: float) -> None:
        """Record observation."""
        self._optimizer.observe(enabled, score)

    @property
    def best_surface_combo(self) -> dict[str, bool]:
        """Best surface combination found."""
        return {s: self._optimizer.best_params.get(s, False) for s in self.surfaces}

    @property
    def best_score(self) -> float:
        """Best score observed."""
        return self._optimizer.best_score


def optimize_with_bayesian(
    objective_fn: Callable[[dict[str, Any]], float],
    space: ParameterSpace,
    budget: int = 12,
    n_initial: int = 4,
) -> OptimizationResult:
    """Run complete Bayesian optimization loop.

    This is a convenience function for running optimization
    with less boilerplate.

    Args:
        objective_fn: Function that takes params and returns score
        space: Parameter space to search
        budget: Total experiments to run
        n_initial: Random samples before Bayesian starts

    Returns:
        OptimizationResult with best found
    """
    optimizer = BayesianOptimizer(space, n_initial=n_initial)

    # Initial random samples
    for config in optimizer.suggest_initial():
        score = objective_fn(config)
        optimizer.observe(config, score)

    # Bayesian optimization
    while optimizer.n_observations < budget:
        config = cast(dict[str, Any], optimizer.suggest())
        score = objective_fn(config)
        optimizer.observe(config, score)

    return optimizer.get_result()


__all__ = [
    "ParameterSpace",
    "GaussianProcessSurrogate",
    "ExpectedImprovement",
    "UpperConfidenceBound",
    "BayesianOptimizer",
    "SurfaceBayesianOptimizer",
    "OptimizationResult",
    "optimize_with_bayesian",
]
