from __future__ import annotations

ARTIFACT_SCHEMA_VERSION = "awb.artifact.v1"
BENCHMARK_SCHEMA_VERSION = "awb.benchmark.v1"
BENCHMARK_INGESTION_SCHEMA_VERSION = "awb.benchmark.ingestion.v1"
PARTIAL_RUNS_FILENAME = "runs.partial.jsonl"
RUN_CONTEXT_FILENAME = "run_context.json"
