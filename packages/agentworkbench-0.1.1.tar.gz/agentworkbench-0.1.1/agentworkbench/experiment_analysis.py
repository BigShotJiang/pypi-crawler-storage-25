from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.analysis_helpers import (
    compact_grounding_provenance as _compact_grounding_provenance,
)
from agentworkbench.analysis_helpers import (
    compact_metadata as _compact_metadata,
)
from agentworkbench.analysis_helpers import (
    count_deltas as _count_deltas,
)
from agentworkbench.analysis_helpers import (
    float_dict_deltas as _float_dict_deltas,
)
from agentworkbench.analysis_helpers import (
    format_evidence_record as _format_evidence_record,
)
from agentworkbench.analysis_helpers import (
    format_tool_call as _format_tool_call,
)
from agentworkbench.analysis_helpers import (
    list_delta as _list_delta,
)
from agentworkbench.analysis_helpers import (
    preview_text as _preview_text,
)
from agentworkbench.analysis_helpers import (
    surface_audit_deltas as _surface_audit_deltas,
)
from agentworkbench.audits import (
    audit_deltas,
    run_surface_audits,
    run_surface_contract_audits,
)
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.evidence import artifact_evidence_summary
from agentworkbench.models import ComparisonRecord, ExperimentRecord
from agentworkbench.scorer_utils import grounding_provenance
from agentworkbench.surface_usage import tool_call_names
from agentworkbench.tracing import trace_event_label

_BENCHMARK_REPO_PATHS = tuple(f"{CONTROL_DIR_NAME}/{name}/" for name in ("briefs", "evals", "scorers"))


def case_expectations(case: dict[str, Any]) -> dict[str, Any]:
    metadata = case.get("metadata") or {}
    expectations = metadata.get("process_expectations") or {}
    hints = metadata.get("process_hints") or {}
    return {
        "required_terms": [str(item) for item in metadata.get("required_terms", [])][:8],
        "forbidden_terms": [str(item) for item in metadata.get("forbidden_terms", [])][:8],
        "required_tools": [str(item) for item in expectations.get("required_tools", [])][:8],
        "required_skills": [str(item) for item in expectations.get("required_skills", [])][:8],
        "required_plugins": [str(item) for item in expectations.get("required_plugins", [])][:8],
        "required_mcps": [str(item) for item in expectations.get("required_mcps", [])][:8],
        "required_prompt_keys": [str(item) for item in expectations.get("required_prompt_keys", [])][:8],
        "required_workflow_steps": [str(item) for item in expectations.get("required_workflow_steps", [])][:12],
        "workflow_sequence": [str(item) for item in expectations.get("workflow_sequence", [])][:12],
        "preferred_tools": [str(item) for item in hints.get("preferred_tools", [])][:8],
        "preferred_skills": [str(item) for item in hints.get("preferred_skills", [])][:8],
        "preferred_plugins": [str(item) for item in hints.get("preferred_plugins", [])][:8],
        "preferred_mcps": [str(item) for item in hints.get("preferred_mcps", [])][:8],
        "preferred_prompt_keys": [str(item) for item in hints.get("preferred_prompt_keys", [])][:8],
        "preferred_workflow_steps": [str(item) for item in hints.get("preferred_workflow_steps", [])][:12],
        "preferred_workflow_sequence": [str(item) for item in hints.get("preferred_workflow_sequence", [])][:12],
        "facts": _compact_metadata(metadata.get("facts") or {}),
        "human_review": _compact_metadata(metadata.get("human_review") or {}),
        "tags": [str(tag) for tag in case.get("tags", [])][:8],
        "rubric": [_preview_text(item, 100) for item in case.get("rubric", [])[:4]],
    }


def artifact_evidence(row: dict[str, Any], spec_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    artifact = row.get("artifact") or {}
    case = row.get("case") or {}
    trace_events = [
        trace_event_label(event)
        for event in artifact.get("trace_events", [])[:16]
        if isinstance(event, dict)
    ]
    audits = run_surface_audits(artifact)
    contract_audits = run_surface_contract_audits(artifact, spec_snapshot)
    evidence_records, evidence_summary = artifact_evidence_summary(artifact)
    score_list = row.get("scores", []) or []
    output_quality_score = next(
        (
            score
            for score in score_list
            if isinstance(score, dict) and str(score.get("name") or "") == "output_quality"
        ),
        {},
    )
    grounding = output_quality_score.get("grounding_provenance") if isinstance(output_quality_score, dict) else {}
    if not isinstance(grounding, dict) or not grounding:
        grounding = grounding_provenance(artifact, case)
    return {
        "input_preview": _preview_text(case.get("input", ""), 180),
        "expected_preview": _preview_text(case.get("expected", ""), 120),
        "final_output_preview": _preview_text(artifact.get("final_output", ""), 180),
        "workflow_trace": [str(item) for item in artifact.get("workflow_trace", [])][:16],
        "trace_events": trace_events,
        "tool_calls": [_format_tool_call(call) for call in artifact.get("tool_calls", [])[:8]],
        "skills_used": [str(item) for item in artifact.get("skills_used", [])][:8],
        "plugins_used": [str(item) for item in artifact.get("plugins_used", [])][:8],
        "mcp_servers_used": [str(item) for item in artifact.get("mcp_servers_used", [])][:8],
        "prompt_keys_used": [str(item) for item in artifact.get("prompt_keys_used", [])][:8],
        "step_count": int(artifact.get("step_count") or 0),
        "latency_ms": int(artifact.get("latency_ms") or 0),
        "token_usage": {str(key): int(value) for key, value in (artifact.get("token_usage") or {}).items()},
        "cost_estimate": float(artifact.get("cost_estimate") or 0.0),
        "pricing": (artifact.get("metadata") or {}).get("pricing") or {},
        "tool_audits": audits.get("tools") or {},
        "mcp_audits": audits.get("mcps") or {},
        "evidence_records": [_format_evidence_record(record) for record in evidence_records[:4]],
        "evidence_summary": evidence_summary,
        "grounding_provenance": _compact_grounding_provenance(grounding),
        "surface_contract_audits": contract_audits,
        "errors": [str(item) for item in artifact.get("errors", [])][:8],
        "metadata": _compact_metadata(artifact.get("metadata") or {}),
        "score_reasons": [
            f"{str(score.get('name') or 'metric')}: {str(score.get('reason') or 'n/a')}"
            for score in row.get("scores", [])[:8]
        ],
    }


def _relative_agent_spec_path(spec_snapshot: dict[str, Any]) -> str | None:
    path = spec_snapshot.get("spec_path")
    if path:
        return str(path)
    agent_id = str(spec_snapshot.get("agent_id") or "")
    if not agent_id:
        return None
    return str(Path(CONTROL_DIR_NAME) / "agents" / f"{agent_id}.yaml")


def _matches_owned_glob(relative_path: str, patterns: list[str]) -> bool:
    candidate = Path(relative_path)
    return any(candidate.match(pattern) for pattern in patterns)


def repo_change_summary(
    baseline_spec: dict[str, Any],
    candidate_spec: dict[str, Any],
    changed_files: list[str],
) -> dict[str, Any]:
    surface_paths: dict[str, set[str]] = {}
    for spec_snapshot in [baseline_spec, candidate_spec]:
        for key, values in (spec_snapshot.get("surface_paths") or {}).items():
            surface_paths.setdefault(str(key), set()).update(str(item) for item in values or [])
    owned_paths = {
        str(item)
        for spec_snapshot in [baseline_spec, candidate_spec]
        for item in spec_snapshot.get("owned_paths", []) or []
    }
    owned_globs = [
        str(item)
        for spec_snapshot in [baseline_spec, candidate_spec]
        for item in spec_snapshot.get("owned_globs", []) or []
    ]
    agent_spec_files = {
        path
        for path in [_relative_agent_spec_path(baseline_spec), _relative_agent_spec_path(candidate_spec)]
        if path
    }
    surface_file_hits: dict[str, set[str]] = {key: set() for key in sorted(surface_paths)}
    benchmark_files: set[str] = set()
    owned_files: set[str] = set()
    unowned_files: list[str] = []
    changed_agent_spec_files: set[str] = set()
    for relative_path in changed_files:
        matched = False
        if any(relative_path.startswith(prefix) for prefix in _BENCHMARK_REPO_PATHS):
            benchmark_files.add(relative_path)
            matched = True
        if relative_path in agent_spec_files:
            changed_agent_spec_files.add(relative_path)
            matched = True
        for surface, files in surface_paths.items():
            if relative_path in files:
                surface_file_hits.setdefault(surface, set()).add(relative_path)
                matched = True
        if relative_path in owned_paths or _matches_owned_glob(relative_path, owned_globs):
            owned_files.add(relative_path)
            matched = True
        if not matched:
            unowned_files.append(relative_path)
    surface_files = {
        key: sorted(value)
        for key, value in sorted(surface_file_hits.items())
        if value
    }
    return {
        "changed_file_count": len(changed_files),
        "surface_areas_changed": sorted(surface_files),
        "surface_files": surface_files,
        "agent_spec_files": sorted(changed_agent_spec_files),
        "benchmark_files": sorted(benchmark_files),
        "owned_files": sorted(owned_files),
        "unowned_files": sorted(unowned_files),
    }


def _prompt_snapshot_map(spec_snapshot: dict[str, Any]) -> dict[str, dict[str, Any]]:
    snapshots = spec_snapshot.get("prompt_snapshots") or []
    result: dict[str, dict[str, Any]] = {}
    for item in snapshots:
        if not isinstance(item, dict):
            continue
        key = str(item.get("key") or "").strip()
        if key:
            result[key] = item
    return result


def spec_changes(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    changes: dict[str, Any] = {
        "agent_id_changed": baseline.get("agent_id") != candidate.get("agent_id"),
        "instruction_changed": baseline.get("instructions") != candidate.get("instructions"),
        "prompt_fingerprint_changed": baseline.get("prompt_fingerprint") != candidate.get("prompt_fingerprint"),
    }
    for field, prefix in [
        ("prompt_keys", "prompt_keys"),
        ("tool_names", "tools"),
        ("skill_names", "skills"),
        ("plugin_names", "plugins"),
        ("mcp_names", "mcps"),
    ]:
        added, removed = _list_delta(baseline.get(field, []), candidate.get(field, []))
        changes[f"{prefix}_added"] = added
        changes[f"{prefix}_removed"] = removed
    baseline_prompts = _prompt_snapshot_map(baseline)
    candidate_prompts = _prompt_snapshot_map(candidate)
    prompt_source_changed_keys: list[str] = []
    prompt_content_changed_keys: list[str] = []
    prompt_content_drift: list[dict[str, Any]] = []
    for key in sorted(set(baseline_prompts) & set(candidate_prompts)):
        before = baseline_prompts[key]
        after = candidate_prompts[key]
        source_changed = (
            str(before.get("source_type") or "") != str(after.get("source_type") or "")
            or str(before.get("source") or "") != str(after.get("source") or "")
        )
        content_changed = str(before.get("content_hash") or "") != str(after.get("content_hash") or "")
        if source_changed:
            prompt_source_changed_keys.append(key)
        if content_changed:
            prompt_content_changed_keys.append(key)
        if not source_changed and not content_changed:
            continue
        prompt_content_drift.append(
            {
                "key": key,
                "source_changed": source_changed,
                "content_changed": content_changed,
                "baseline_source_type": str(before.get("source_type") or ""),
                "candidate_source_type": str(after.get("source_type") or ""),
                "baseline_source": str(before.get("source") or ""),
                "candidate_source": str(after.get("source") or ""),
                "baseline_content_hash": str(before.get("content_hash") or ""),
                "candidate_content_hash": str(after.get("content_hash") or ""),
                "baseline_preview": _preview_text(before.get("preview") or before.get("content") or "", 140),
                "candidate_preview": _preview_text(after.get("preview") or after.get("content") or "", 140),
            }
        )
    changes["prompt_source_changed_keys"] = prompt_source_changed_keys
    changes["prompt_content_changed_keys"] = prompt_content_changed_keys
    changes["prompt_content_drift"] = prompt_content_drift
    if baseline.get("model_name") != candidate.get("model_name"):
        changes["model_changed"] = f"{baseline.get('model_name', 'unknown')} -> {candidate.get('model_name', 'unknown')}"
    return changes


def behavior_deltas(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    list_delta_fields = [
        ("tools_used", "tools_used"),
        ("skills_used", "skills_used"),
        ("plugins_used", "plugins_used"),
        ("mcp_servers_used", "mcp_servers_used"),
        ("prompt_keys_used", "prompt_keys_used"),
        ("providers_used", "providers_used"),
        ("models_used", "models_used"),
        ("evidence_sources_used", "evidence_sources"),
        ("evidence_sources_with_unused_selected", "evidence_sources_with_unused_selected"),
        ("trace_events_used", "trace_events"),
        ("unused_available_tools", "unused_available_tools"),
        ("unused_available_skills", "unused_available_skills"),
        ("unused_available_plugins", "unused_available_plugins"),
        ("unused_available_mcps", "unused_available_mcps"),
        ("unused_available_prompt_keys", "unused_available_prompt_keys"),
        ("surface_contract_violations", "surface_contract_violations"),
        ("tool_used_not_enabled", "tool_used_not_enabled"),
        ("mcp_used_not_enabled", "mcp_used_not_enabled"),
        ("mcp_referenced_not_listed", "mcp_referenced_not_listed"),
        ("mcp_listed_not_referenced", "mcp_listed_not_referenced"),
    ]
    for field, prefix in list_delta_fields:
        added, removed = _list_delta(baseline.get(field, []), candidate.get(field, []))
        result[f"{prefix}_added"] = added
        result[f"{prefix}_removed"] = removed

    for output_key, field, precision in [
        ("avg_tool_calls_delta", "average_tool_calls", 3),
        ("avg_trace_event_count_delta", "average_trace_event_count", 3),
        ("avg_evidence_record_count_delta", "average_evidence_record_count", 3),
        ("avg_selected_evidence_count_delta", "average_selected_evidence_count", 3),
        ("avg_supported_evidence_count_delta", "average_supported_evidence_count", 3),
        ("avg_step_count_delta", "average_step_count", 3),
        ("avg_latency_ms_delta", "average_latency_ms", 3),
        ("avg_cost_estimate_delta", "average_cost_estimate", 6),
        ("total_cost_estimate_delta", "total_cost_estimate", 6),
        ("selected_evidence_use_rate_delta", "selected_evidence_use_rate", 3),
        ("tool_coverage_delta", "tool_coverage", 3),
        ("skill_coverage_delta", "skill_coverage", 3),
        ("plugin_coverage_delta", "plugin_coverage", 3),
        ("mcp_coverage_delta", "mcp_coverage", 3),
        ("prompt_coverage_delta", "prompt_coverage", 3),
    ]:
        result[output_key] = round(float(candidate.get(field) or 0.0) - float(baseline.get(field) or 0.0), precision)

    for output_key, field in [
        ("cases_with_selected_evidence_delta", "cases_with_selected_evidence"),
        ("cases_with_supported_evidence_delta", "cases_with_supported_evidence"),
        ("cases_with_unsupported_selected_evidence_delta", "cases_with_unsupported_selected_evidence"),
        ("surface_contract_violation_count_delta", "surface_contract_violation_count"),
    ]:
        result[output_key] = int(candidate.get(field, 0) or 0) - int(baseline.get(field, 0) or 0)

    for output_key, field in [
        ("evidence_source_count_deltas", "evidence_source_counts"),
        ("evidence_kind_deltas", "evidence_kind_counts"),
        ("tool_usage_count_deltas", "tool_usage_counts"),
        ("skill_usage_count_deltas", "skill_usage_counts"),
        ("plugin_usage_count_deltas", "plugin_usage_counts"),
        ("mcp_usage_count_deltas", "mcp_usage_counts"),
        ("prompt_usage_count_deltas", "prompt_usage_counts"),
        ("workflow_step_count_deltas", "workflow_step_counts"),
        ("trace_event_label_deltas", "trace_event_label_counts"),
        ("trace_event_kind_deltas", "trace_event_kind_counts"),
        ("total_token_usage_deltas", "total_token_usage"),
    ]:
        result[output_key] = _count_deltas(baseline.get(field, {}), candidate.get(field, {}))

    result["average_token_usage_deltas"] = _float_dict_deltas(
        baseline.get("average_token_usage", {}),
        candidate.get("average_token_usage", {}),
    )
    result["surface_audit_deltas"] = _surface_audit_deltas(
        baseline.get("surface_audits", {}) or {},
        candidate.get("surface_audits", {}) or {},
    )
    for output_key, field in [("tool_audit_deltas", "tool_audits"), ("mcp_audit_deltas", "mcp_audits")]:
        result[output_key] = audit_deltas(baseline.get(field, {}) or {}, candidate.get(field, {}) or {})
    return result


def changed_cases(
    baseline_rows: list[dict[str, Any]],
    candidate_rows: list[dict[str, Any]],
    *,
    baseline_spec_snapshot: dict[str, Any] | None = None,
    candidate_spec_snapshot: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    baseline_by_id = {row["case"]["id"]: row for row in baseline_rows}
    candidate_by_id = {row["case"]["id"]: row for row in candidate_rows}
    changed: list[dict[str, Any]] = []
    for case_id in sorted(set(baseline_by_id) & set(candidate_by_id)):
        base = baseline_by_id[case_id]
        cand = candidate_by_id[case_id]
        base_output = base["artifact"].get("final_output", "")
        cand_output = cand["artifact"].get("final_output", "")
        base_tools = sorted(set(tool_call_names(base.get("artifact") or {})))
        cand_tools = sorted(set(tool_call_names(cand.get("artifact") or {})))
        tools_added, tools_removed = _list_delta(base_tools, cand_tools)
        skills_added, skills_removed = _list_delta(base["artifact"].get("skills_used", []), cand["artifact"].get("skills_used", []))
        plugins_added, plugins_removed = _list_delta(base["artifact"].get("plugins_used", []), cand["artifact"].get("plugins_used", []))
        mcps_added, mcps_removed = _list_delta(base["artifact"].get("mcp_servers_used", []), cand["artifact"].get("mcp_servers_used", []))
        prompts_added, prompts_removed = _list_delta(base["artifact"].get("prompt_keys_used", []), cand["artifact"].get("prompt_keys_used", []))
        workflow_added, workflow_removed = _list_delta(base["artifact"].get("workflow_trace", []), cand["artifact"].get("workflow_trace", []))
        base_trace_events = [
            trace_event_label(event)
            for event in base["artifact"].get("trace_events", [])
            if isinstance(event, dict)
        ]
        cand_trace_events = [
            trace_event_label(event)
            for event in cand["artifact"].get("trace_events", [])
            if isinstance(event, dict)
        ]
        trace_events_added, trace_events_removed = _list_delta(base_trace_events, cand_trace_events)
        workflow_trace_changed = base["artifact"].get("workflow_trace", []) != cand["artifact"].get("workflow_trace", [])
        output_changed = base_output != cand_output
        score_delta = float(cand.get("score", 0.0)) - float(base.get("score", 0.0))
        if not (
            output_changed
            or tools_added
            or tools_removed
            or skills_added
            or skills_removed
            or plugins_added
            or plugins_removed
            or mcps_added
            or mcps_removed
            or prompts_added
            or prompts_removed
            or workflow_trace_changed
            or trace_events_added
            or trace_events_removed
            or score_delta
        ):
            continue
        changed.append(
            {
                "case_id": case_id,
                "tags": [str(t) for t in (cand.get("case") or {}).get("tags") or []],
                "score_delta": round(score_delta, 3),
                "output_changed": output_changed,
                "baseline_output_preview": base_output[:120],
                "candidate_output_preview": cand_output[:120],
                "expected_behavior": case_expectations(cand["case"]),
                "baseline_evidence": artifact_evidence(base, baseline_spec_snapshot),
                "candidate_evidence": artifact_evidence(cand, candidate_spec_snapshot),
                "tool_call_count_delta": len(cand["artifact"].get("tool_calls", [])) - len(base["artifact"].get("tool_calls", [])),
                "trace_event_count_delta": len(cand_trace_events) - len(base_trace_events),
                "step_count_delta": int(cand["artifact"].get("step_count") or 0) - int(base["artifact"].get("step_count") or 0),
                "workflow_trace_changed": workflow_trace_changed,
                "workflow_steps_added": workflow_added,
                "workflow_steps_removed": workflow_removed,
                "trace_events_added": trace_events_added,
                "trace_events_removed": trace_events_removed,
                "tools_added": tools_added,
                "tools_removed": tools_removed,
                "skills_added": skills_added,
                "skills_removed": skills_removed,
                "plugins_added": plugins_added,
                "plugins_removed": plugins_removed,
                "mcps_added": mcps_added,
                "mcps_removed": mcps_removed,
                "prompt_keys_added": prompts_added,
                "prompt_keys_removed": prompts_removed,
            }
        )
    return changed


def comparison_summary(
    metric_deltas: dict[str, float],
    changed_cases: list[dict[str, Any]],
    behavior_deltas: dict[str, Any],
    repo_change_summary: dict[str, Any],
) -> str:
    improved_cases = sum(1 for item in changed_cases if item.get("score_delta", 0.0) > 0)
    regressed_cases = sum(1 for item in changed_cases if item.get("score_delta", 0.0) < 0)
    score_delta = metric_deltas.get("average_score", 0.0)
    if score_delta > 0:
        verdict = "Candidate improves baseline"
    elif score_delta < 0:
        verdict = "Candidate regresses baseline"
    else:
        verdict = "Candidate is score-neutral versus baseline"
    mutated_surfaces = repo_change_summary.get("surface_areas_changed", []) or []
    if mutated_surfaces:
        verdict += f"; mutated files touched: {', '.join(mutated_surfaces)}"
    surface_changes = [
        name
        for name in [
            *behavior_deltas.get("tools_used_added", []),
            *behavior_deltas.get("skills_used_added", []),
            *behavior_deltas.get("plugins_used_added", []),
            *behavior_deltas.get("mcp_servers_used_added", []),
            *behavior_deltas.get("prompt_keys_used_added", []),
        ]
    ]
    if surface_changes:
        verdict += f"; new active surfaces: {', '.join(surface_changes)}"
    else:
        unused_surface_added = [
            name
            for name in [
                *behavior_deltas.get("unused_available_tools_added", []),
                *behavior_deltas.get("unused_available_skills_added", []),
                *behavior_deltas.get("unused_available_plugins_added", []),
                *behavior_deltas.get("unused_available_mcps_added", []),
                *behavior_deltas.get("unused_available_prompt_keys_added", []),
            ]
        ]
        if unused_surface_added:
            verdict += f"; unused available surfaces added: {', '.join(unused_surface_added)}"
    contract_violations_added = behavior_deltas.get("surface_contract_violations_added", []) or []
    if contract_violations_added:
        verdict += f"; new contract violations: {', '.join(contract_violations_added[:4])}"
    evidence_use_rate_delta = float(behavior_deltas.get("selected_evidence_use_rate_delta", 0.0) or 0.0)
    if evidence_use_rate_delta:
        direction = "improved" if evidence_use_rate_delta > 0 else "fell"
        verdict += f"; evidence use rate {direction} {evidence_use_rate_delta:+.3f}"
    return f"{verdict}; improved cases={improved_cases}, regressed cases={regressed_cases}"


def telemetry_summary(baseline: ExperimentRecord, candidate: ExperimentRecord) -> dict[str, Any]:
    baseline_behavior = baseline.behavior_summary or {}
    candidate_behavior = candidate.behavior_summary or {}
    baseline_versions = baseline_behavior.get("trace_schema_versions", []) or []
    candidate_versions = candidate_behavior.get("trace_schema_versions", []) or []
    baseline_taxonomies = baseline_behavior.get("trace_taxonomies", []) or []
    candidate_taxonomies = candidate_behavior.get("trace_taxonomies", []) or []
    return {
        "baseline_trace_schema_versions": baseline_versions,
        "candidate_trace_schema_versions": candidate_versions,
        "baseline_trace_taxonomies": baseline_taxonomies,
        "candidate_trace_taxonomies": candidate_taxonomies,
        "schema_changed": baseline_versions != candidate_versions or baseline_taxonomies != candidate_taxonomies,
        "noncanonical_trace_event_kinds_added": sorted(
            set(candidate_behavior.get("noncanonical_trace_event_kinds", []) or [])
            - set(baseline_behavior.get("noncanonical_trace_event_kinds", []) or [])
        ),
        "noncanonical_trace_event_kinds_removed": sorted(
            set(baseline_behavior.get("noncanonical_trace_event_kinds", []) or [])
            - set(candidate_behavior.get("noncanonical_trace_event_kinds", []) or [])
        ),
    }


def benchmark_drift_summary(
    baseline: ExperimentRecord,
    candidate: ExperimentRecord,
    comparison_mode: str,
    changed_paths: list[str],
) -> dict[str, Any]:
    sections: set[str] = set()
    for path in changed_paths:
        if f"{CONTROL_DIR_NAME}/briefs/" in path:
            sections.add("briefs")
        elif f"{CONTROL_DIR_NAME}/evals/" in path:
            sections.add("evals")
        elif f"{CONTROL_DIR_NAME}/scorers/" in path:
            sections.add("scorers")
        else:
            sections.add("other")
    baseline_manifest = baseline.benchmark_manifest or {}
    candidate_manifest = candidate.benchmark_manifest or {}
    return {
        "status": comparison_mode,
        "changed_path_count": len(changed_paths),
        "changed_paths": changed_paths,
        "changed_sections": sorted(sections),
        "baseline_fingerprint": baseline_manifest.get("fingerprint"),
        "candidate_fingerprint": candidate_manifest.get("fingerprint"),
        "fingerprint_changed": (baseline_manifest.get("fingerprint") or "") != (candidate_manifest.get("fingerprint") or ""),
    }


def _failure_cluster_category(reason: str, item: dict[str, Any], comparison: ComparisonRecord | None) -> str:
    text = reason.lower()
    candidate_evidence = item.get("candidate_evidence") or {}
    candidate_errors = [str(error).lower() for error in (candidate_evidence.get("errors") or [])]
    tool_audits = candidate_evidence.get("tool_audits") or {}
    mcp_audits = candidate_evidence.get("mcp_audits") or {}
    contract_audits = candidate_evidence.get("surface_contract_audits") or {}
    evidence_summary = candidate_evidence.get("evidence_summary") or {}
    if "execution failed" in text or "command exited" in text or "timed out" in text:
        return "execution_failure"
    if comparison and comparison.comparison_mode != "clean":
        return "benchmark_drift"
    if any("429" in error or "rate limit" in error or "too many requests" in error for error in candidate_errors):
        return "provider_rate_limit"
    if any(
        marker in error
        for error in candidate_errors
        for marker in ["401", "403", "unauthorized", "forbidden", "invalid api key", "authentication"]
    ):
        return "provider_auth_failure"
    if any("timeout" in error or "timed out" in error for error in candidate_errors):
        return "provider_timeout"
    if candidate_errors:
        return "provider_failure"
    if (contract_audits.get("violations") or []) and float(item.get("score_delta") or 0.0) <= 0.0:
        return "surface_contract_violation"
    if (
        int(evidence_summary.get("selected_count", 0) or 0) > 0
        and int(evidence_summary.get("used_count", 0) or 0) == 0
        and any(marker in text for marker in ["required terms", "expected text missing", "forbidden terms"])
    ):
        return "grounding_gap"
    if any(int(counts.get("error", 0)) > 0 for counts in tool_audits.values()):
        return "tool_failure"
    if any(int(counts.get("error", 0)) > 0 for counts in mcp_audits.values()):
        return "mcp_failure"
    if any(int(counts.get("empty", 0)) > 0 for counts in mcp_audits.values()) and item.get("expected_behavior", {}).get("required_mcps"):
        return "mcp_empty"
    if "missing customer history" in text or "customer history" in text or "memory" in text:
        return "memory_gap"
    if item.get("tool_call_count_delta", 0) > 0 and float(item.get("score_delta") or 0.0) <= 0.0:
        return "routing_regression"
    if item.get("workflow_trace_changed") and float(item.get("score_delta") or 0.0) <= 0.0:
        return "trace_regression"
    if item.get("step_count_delta", 0) > 0 and float(item.get("score_delta") or 0.0) <= 0.0:
        return "step_overhead"
    missing_required_terms: list[str] = []
    marker = "missing required terms:"
    if marker in text:
        tail = text.split(marker, 1)[1].split(";", 1)[0]
        missing_required_terms = [term.strip() for term in tail.split(",") if term.strip()]
    if missing_required_terms and all(term == "next action" for term in missing_required_terms):
        return "response_structure_gap"
    if any(marker in text for marker in ["preferred_tools", "required_tools", "required_mcps", "required_skills"]):
        return "retrieval_gap"
    if any(marker in text for marker in ["required terms", "forbidden terms", "expected text missing"]):
        return "prompt_regression"
    return "output_regression"


def failure_clusters(
    comparison: ComparisonRecord | None,
    focus_cases: list[dict[str, Any]],
    failed_case_map: dict[str, str],
) -> list[dict[str, Any]]:
    buckets: dict[str, dict[str, Any]] = {}
    for item in focus_cases:
        case_id = str(item.get("case_id") or "")
        explicit_reason = str(item.get("reason") or failed_case_map.get(case_id, "") or "").strip()
        score_delta = float(item.get("score_delta", 0.0) or 0.0)
        if not explicit_reason and score_delta > 0.0:
            continue
        reason = explicit_reason or "changed relative to baseline"
        if reason == "improved relative to baseline":
            continue
        category = _failure_cluster_category(reason, item, comparison)
        if not explicit_reason and score_delta >= 0.0 and category == "output_regression":
            continue
        bucket = buckets.setdefault(
            category,
            {
                "cluster_id": category,
                "category": category,
                "case_ids": [],
                "reasons": [],
                "trace_markers": set(),
                "surface_markers": set(),
            },
        )
        bucket["case_ids"].append(str(item.get("case_id") or "unknown"))
        bucket["reasons"].append(reason)
        for value in item.get("trace_events_added", []) or []:
            bucket["trace_markers"].add(str(value))
        for value in item.get("trace_events_removed", []) or []:
            bucket["trace_markers"].add(str(value))
        for key in [
            "tools_added",
            "tools_removed",
            "skills_added",
            "skills_removed",
            "plugins_added",
            "plugins_removed",
            "mcps_added",
            "mcps_removed",
            "prompt_keys_added",
            "prompt_keys_removed",
        ]:
            for value in item.get(key, []) or []:
                bucket["surface_markers"].add(str(value))
    clusters: list[dict[str, Any]] = []
    for category, bucket in buckets.items():
        case_ids = bucket["case_ids"]
        trace_markers = sorted(bucket["trace_markers"])
        surface_markers = sorted(bucket["surface_markers"])
        summary = f"{category.replace('_', ' ')} affecting {len(case_ids)} case(s)"
        if surface_markers:
            summary += f"; surfaces={', '.join(surface_markers[:6])}"
        elif trace_markers:
            summary += f"; trace={', '.join(trace_markers[:6])}"
        clusters.append(
            {
                "cluster_id": bucket["cluster_id"],
                "category": category,
                "count": len(case_ids),
                "case_ids": case_ids,
                "reasons": bucket["reasons"][:5],
                "trace_markers": trace_markers[:8],
                "surface_markers": surface_markers[:8],
                "summary": summary,
            }
        )
    return sorted(clusters, key=lambda item: (-int(item.get("count", 0)), str(item.get("cluster_id") or "")))
