from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.report_scorer_audit import render_scorer_audit_report
from agentworkbench.reports import write_report
from agentworkbench.runner import _latest_matching_record, _load_experiment, _load_run_rows
from agentworkbench.scorers.audit import score_audit_report, summarize_judge_audit
from agentworkbench.utils import ensure_dir, write_json


def _prompt_digest(value: str) -> str:
    if not value:
        return ""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]


def _judgment_origin(score: dict[str, Any]) -> str:
    judged = score.get("judged")
    if not isinstance(judged, dict):
        return "unknown"
    path = str(judged.get("fallback_path") or "").strip()
    return path or "unknown"


def _row_scores(row: dict[str, Any], metric_names: set[str] | None) -> list[dict[str, Any]]:
    scores = [dict(item) for item in row.get("scores") or [] if isinstance(item, dict)]
    if metric_names is None:
        return scores
    return [item for item in scores if str(item.get("name") or "") in metric_names]


def build_scorer_audit(
    project_root: Path,
    *,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    case_ids: list[str] | None = None,
    metric_names: list[str] | None = None,
    confidence_threshold: float = 0.7,
    ci_width_threshold: float = 0.25,
) -> dict[str, Any]:
    target_id = str(experiment_id or "").strip()
    if not target_id:
        record = _latest_matching_record(
            project_root,
            agent_id=agent_id,
            eval_id=eval_id,
            subset=subset,
            benchmark_signature=benchmark_signature,
        )
        if record is None:
            raise ValueError("No experiments matched the requested filters for scorer audit.")
        target_id = record.experiment_id

    record, _aggregate = _load_experiment(project_root, target_id)
    rows = _load_run_rows(project_root, target_id)
    selected_case_ids = {str(item) for item in (case_ids or []) if str(item).strip()}
    filtered_rows = [
        row
        for row in rows
        if not selected_case_ids or str((row.get("case") or {}).get("id") or "") in selected_case_ids
    ]
    selected_metrics = {str(item) for item in (metric_names or []) if str(item).strip()} or None

    metric_entries: dict[str, list[dict[str, Any]]] = {}
    flat_scores: list[dict[str, Any]] = []
    review_case_ids: set[str] = set()
    for row in filtered_rows:
        case_id = str((row.get("case") or {}).get("id") or "unknown")
        for score in _row_scores(row, selected_metrics):
            metric_name = str(score.get("name") or "unnamed_metric")
            metric_entries.setdefault(metric_name, []).append({"case_id": case_id, "score": score})
            flat_scores.append(score)

    metric_audits: dict[str, Any] = {}
    issues: list[str] = []
    for metric_name, entries in sorted(metric_entries.items()):
        scores = [item["score"] for item in entries]
        audit = score_audit_report(scores)
        fallback_paths: dict[str, int] = {}
        judge_models: set[str] = set()
        judge_prompt_digests: set[str] = set()
        low_confidence_cases: list[dict[str, Any]] = []
        wide_ci_cases: list[dict[str, Any]] = []
        unknown_cases: list[dict[str, Any]] = []
        for entry in entries:
            case_id = str(entry["case_id"])
            score = entry["score"]
            origin = _judgment_origin(score)
            fallback_paths[origin] = fallback_paths.get(origin, 0) + 1
            judged = score.get("judged")
            if not isinstance(judged, dict):
                unknown_cases.append({"case_id": case_id})
                review_case_ids.add(case_id)
                continue
            model = str(judged.get("model") or "").strip()
            if model:
                judge_models.add(model)
            prompt_digest = _prompt_digest(str(judged.get("prompt") or ""))
            if prompt_digest:
                judge_prompt_digests.add(prompt_digest)
            confidence = judged.get("confidence")
            if isinstance(confidence, (int, float)) and float(confidence) < float(confidence_threshold):
                low_confidence_cases.append({"case_id": case_id, "confidence": round(float(confidence), 3)})
                review_case_ids.add(case_id)
            ci = judged.get("confidence_interval")
            if isinstance(ci, dict):
                lower = ci.get("lower")
                upper = ci.get("upper")
                if isinstance(lower, (int, float)) and isinstance(upper, (int, float)):
                    width = round(float(upper) - float(lower), 3)
                    if width > float(ci_width_threshold):
                        wide_ci_cases.append({"case_id": case_id, "width": width})
                        review_case_ids.add(case_id)
        metric_audit = {
            **audit,
            "fallback_paths": dict(sorted(fallback_paths.items())),
            "judge_models": sorted(judge_models),
            "judge_model_count": len(judge_models),
            "judge_prompt_digests": sorted(judge_prompt_digests),
            "judge_prompt_variant_count": len(judge_prompt_digests),
            "low_confidence_cases": low_confidence_cases,
            "wide_confidence_interval_cases": wide_ci_cases,
            "unknown_judgment_cases": unknown_cases,
        }
        metric_audit["needs_review"] = bool(
            metric_audit["unknown_scores"]
            or low_confidence_cases
            or wide_ci_cases
            or len(judge_models) > 1
            or len(judge_prompt_digests) > 1
        )
        if metric_audit["unknown_scores"]:
            issues.append(f"Metric `{metric_name}` has scores without judgment metadata.")
        if len(judge_models) > 1:
            issues.append(f"Metric `{metric_name}` uses multiple judge models: {', '.join(sorted(judge_models))}.")
        if len(judge_prompt_digests) > 1:
            issues.append(f"Metric `{metric_name}` uses multiple judge prompt variants.")
        if low_confidence_cases:
            issues.append(
                f"Metric `{metric_name}` has low-confidence judgments on {len(low_confidence_cases)} case(s)."
            )
        if wide_ci_cases:
            issues.append(f"Metric `{metric_name}` has wide confidence intervals on {len(wide_ci_cases)} case(s).")
        metric_audits[metric_name] = metric_audit

    overall = score_audit_report(flat_scores)
    judge_summary = summarize_judge_audit({}, flat_scores)
    suggested_commands: list[str] = []
    if review_case_ids:
        command = f"awb run replay --experiment {target_id}"
        for case_id in sorted(review_case_ids)[:4]:
            command += f" --case-id {case_id}"
        suggested_commands.append(command)
    if issues:
        suggested_commands.append(f"awb artifacts show experiment --experiment {target_id}")

    payload = {
        "experiment_id": target_id,
        "agent_id": record.agent_id,
        "eval_id": record.eval_id,
        "subset": record.subset,
        "benchmark_signature": record.benchmark_signature,
        "selected_case_count": len(filtered_rows),
        "selected_metric_names": sorted(metric_audits) if metric_audits else sorted(selected_metrics or []),
        "overall": overall,
        "confidence_note": judge_summary.get("confidence_note") or "",
        "metric_audits": metric_audits,
        "review_case_ids": sorted(review_case_ids),
        "issues": issues,
        "suggested_commands": suggested_commands,
    }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / f"scorer-audit-{target_id}.json", payload)
    write_json(reports_dir / "scorer-audit-latest.json", payload)
    write_report(reports_dir / f"scorer-audit-{target_id}.md", render_scorer_audit_report(payload))
    write_report(reports_dir / "scorer-audit-latest.md", render_scorer_audit_report(payload))
    return payload


__all__ = ["build_scorer_audit"]
