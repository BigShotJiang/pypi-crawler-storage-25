from __future__ import annotations

from typing import Any

from agentworkbench.analysis_helpers import (
    declared_names as _declared_names,
)
from agentworkbench.analysis_helpers import (
    infer_from_events as _infer_from_events,
)
from agentworkbench.analysis_helpers import (
    infer_from_evidence as _infer_from_evidence,
)
from agentworkbench.analysis_helpers import (
    normalize_tool_call as _normalize_tool_call,
)
from agentworkbench.analysis_helpers import (
    ordered_union as _ordered_union,
)
from agentworkbench.analysis_helpers import (
    parse_step as _parse_step,
)
from agentworkbench.analysis_helpers import (
    surface_inference_from_trace as _surface_inference_from_trace,
)
from agentworkbench.instrumentation import summarize_provenance
from agentworkbench.tracing import normalize_trace_events


def enrich_run_artifact_payload(
    artifact: dict[str, Any], spec_snapshot: dict[str, Any] | None = None
) -> dict[str, Any]:
    spec_snapshot = spec_snapshot or {}
    declared_tools = _declared_names(spec_snapshot, "tool_names")
    declared_prompts = _declared_names(spec_snapshot, "prompt_keys")
    declared_mcps = _declared_names(spec_snapshot, "mcp_names")

    normalized = dict(artifact or {})
    raw_source_payload = normalized.get("structured_output")
    source_payload: dict[str, Any] = dict(raw_source_payload) if isinstance(raw_source_payload, dict) else {}
    tool_calls_declared = "tool_calls" in source_payload
    prompt_keys_declared = "prompt_keys_used" in source_payload
    skills_declared = "skills_used" in source_payload
    plugins_declared = "plugins_used" in source_payload
    mcps_declared = "mcp_servers_used" in source_payload
    normalized["metadata"] = dict(normalized.get("metadata") or {})
    normalized["events"] = [dict(item) for item in normalized.get("events", []) if isinstance(item, dict)]
    normalized["errors"] = [str(item) for item in normalized.get("errors", []) if str(item).strip()]
    normalized["evidence_records"] = [
        dict(item) for item in normalized.get("evidence_records", []) if isinstance(item, dict)
    ]
    normalized["tool_calls"] = [
        item for item in (_normalize_tool_call(call) for call in normalized.get("tool_calls", [])) if item is not None
    ]

    workflow_trace = [str(item) for item in normalized.get("workflow_trace", []) if str(item).strip()]
    prompt_keys_used = [str(item) for item in normalized.get("prompt_keys_used", []) if str(item).strip()]
    skills_used = [str(item) for item in normalized.get("skills_used", []) if str(item).strip()]
    plugins_used = [str(item) for item in normalized.get("plugins_used", []) if str(item).strip()]
    mcp_servers_used = [str(item) for item in normalized.get("mcp_servers_used", []) if str(item).strip()]

    raw_trace_events = [dict(item) for item in normalized.get("trace_events", []) if isinstance(item, dict)]
    if raw_trace_events:
        trace_events = raw_trace_events
    else:
        trace_events = normalize_trace_events(
            {
                "events": normalized["events"],
                "workflow_trace": workflow_trace,
                "tool_calls": normalized["tool_calls"],
                "prompt_keys_used": prompt_keys_used,
                "skills_used": skills_used,
                "plugins_used": plugins_used,
                "mcp_servers_used": mcp_servers_used,
            }
        )

    event_prompts, event_skills, event_plugins, event_mcps, event_workflow, event_tool_calls, inferred_metadata = (
        _infer_from_events(
            normalized["events"],
            declared_tools=declared_tools,
            declared_mcps=declared_mcps,
        )
    )
    evidence_mcps, evidence_tool_calls = _infer_from_evidence(
        normalized["evidence_records"],
        declared_tools=declared_tools,
    )
    trace_prompts, trace_skills, trace_plugins, trace_mcps, trace_workflow = _surface_inference_from_trace(trace_events)

    step_prompts = [
        name for kind, name in (_parse_step(step) or ("", "") for step in workflow_trace) if kind == "prompt"
    ]
    step_skills = [name for kind, name in (_parse_step(step) or ("", "") for step in workflow_trace) if kind == "skill"]
    step_plugins = [
        name for kind, name in (_parse_step(step) or ("", "") for step in workflow_trace) if kind == "plugin"
    ]
    step_mcps = [name for kind, name in (_parse_step(step) or ("", "") for step in workflow_trace) if kind == "mcp"]

    if (
        not prompt_keys_used
        and len(declared_prompts) == 1
        and any(event.get("kind") in {"prompt", "prompt_load"} for event in normalized["events"])
    ):
        prompt_keys_used = [next(iter(declared_prompts))]

    if not prompt_keys_declared:
        prompt_keys_used = _ordered_union(prompt_keys_used, [*step_prompts, *trace_prompts, *event_prompts])
    if not skills_declared:
        skills_used = _ordered_union(skills_used, [*step_skills, *trace_skills, *event_skills])
    if not plugins_declared:
        plugins_used = _ordered_union(plugins_used, [*step_plugins, *trace_plugins, *event_plugins])
    if not mcps_declared:
        mcp_servers_used = _ordered_union(mcp_servers_used, [*step_mcps, *trace_mcps, *event_mcps, *evidence_mcps])

    tool_call_by_name = {
        str(item.get("name") or ""): dict(item)
        for item in normalized["tool_calls"]
        if str(item.get("name") or "").strip()
    }
    for inferred in [*event_tool_calls, *evidence_tool_calls]:
        name = str(inferred.get("name") or "").strip()
        if not name:
            continue
        if declared_tools and name not in declared_tools:
            continue
        existing = tool_call_by_name.get(name)
        if existing is None:
            if tool_calls_declared:
                continue
            tool_call_by_name[name] = dict(inferred)
            continue
        for key, value in inferred.items():
            if key == "name":
                continue
            existing.setdefault(key, value)
    tool_calls = list(tool_call_by_name.values())

    inferred_workflow = [*trace_workflow, *event_workflow]
    for call in tool_calls:
        name = str(call.get("name") or "").strip()
        if name:
            inferred_workflow.append(f"tool:{name}")
    if prompt_keys_used:
        inferred_workflow = [*([f"prompt:{name}" for name in prompt_keys_used]), *inferred_workflow]
    if mcp_servers_used:
        inferred_workflow.extend(f"mcp:{name}" for name in mcp_servers_used)
    workflow_trace = _ordered_union(workflow_trace, inferred_workflow)

    trace_events = normalize_trace_events(
        {
            "events": normalized["events"],
            "workflow_trace": workflow_trace,
            "tool_calls": tool_calls,
            "prompt_keys_used": prompt_keys_used,
            "skills_used": skills_used,
            "plugins_used": plugins_used,
            "mcp_servers_used": mcp_servers_used,
        }
    )

    metadata = dict(normalized.get("metadata") or {})
    metadata.update(
        {key: value for key, value in inferred_metadata.items() if key not in metadata and str(value).strip()}
    )
    if "provider" not in metadata and str((spec_snapshot.get("metadata") or {}).get("provider") or "").strip():
        metadata["provider"] = str((spec_snapshot.get("metadata") or {}).get("provider"))
    if "model_name" not in metadata and str(spec_snapshot.get("model_name") or "").strip():
        metadata["model_name"] = str(spec_snapshot.get("model_name"))

    step_count = int(normalized.get("step_count") or 0)
    if step_count <= 0:
        candidates = [len(workflow_trace), len(tool_calls), len(trace_events)]
        if str(normalized.get("final_output") or "").strip():
            candidates.append(1)
        step_count = max(candidates or [0])

    normalized["workflow_trace"] = workflow_trace
    normalized["prompt_keys_used"] = [
        name for name in prompt_keys_used if not declared_prompts or name in declared_prompts
    ]
    normalized["skills_used"] = skills_used
    normalized["plugins_used"] = plugins_used
    normalized["mcp_servers_used"] = [name for name in mcp_servers_used if not declared_mcps or name in declared_mcps]
    normalized["tool_calls"] = tool_calls
    normalized["trace_events"] = trace_events
    normalized["step_count"] = step_count
    normalized["metadata"] = metadata

    telemetry_confidence = summarize_provenance(trace_events)
    normalized["telemetry_confidence"] = {
        "quality": telemetry_confidence["quality"],
        "confidence": telemetry_confidence["confidence"],
        "raw_count": telemetry_confidence["raw_count"],
        "inferred_count": telemetry_confidence["inferred_count"],
        "total_count": telemetry_confidence["total_count"],
    }

    return normalized


def enrich_run_row_payload(row: dict[str, Any], spec_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    normalized = dict(row or {})
    artifact = normalized.get("artifact") or {}
    if isinstance(artifact, dict):
        normalized["artifact"] = enrich_run_artifact_payload(artifact, spec_snapshot=spec_snapshot)
    return normalized
