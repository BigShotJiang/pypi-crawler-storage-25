from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from agentworkbench.compare_statistics import paired_comparison_statistics
from agentworkbench.config import control_dir, load_config
from agentworkbench.experiment_analysis import (
    behavior_deltas,
    benchmark_drift_summary,
    changed_cases,
    comparison_summary,
    failure_clusters,
    repo_change_summary,
    spec_changes,
    telemetry_summary,
)
from agentworkbench.models import ComparisonRecord, ExperimentRecord
from agentworkbench.report_compare import render_compare_report
from agentworkbench.report_status import render_status_report
from agentworkbench.reports import write_report
from agentworkbench.snapshot import compare_benchmark_hashes, compare_snapshot_states
from agentworkbench.stability_utils import _stability_summary_for_record
from agentworkbench.surface_details import compare_surface_snapshots
from agentworkbench.utils import ensure_dir, read_json, write_json


def _compare_artifact_stem(baseline_id: str, candidate_id: str, *, limit: int = 160) -> str:
    stem = f"compare-{baseline_id}-to-{candidate_id}"
    if len(stem) <= limit:
        return stem
    digest = hashlib.sha1(stem.encode("utf-8")).hexdigest()[:10]
    shortened = f"compare-{baseline_id[:48]}-to-{candidate_id[:48]}"
    shortened = shortened[: max(0, limit - 11)].rstrip("-")
    return f"{shortened}-{digest}"


def _gate_results(
    project_root: Path,
    comparison_mode: str,
    metric_deltas: dict[str, float],
    behavior_deltas: dict[str, Any],
    changed_cases: list[dict[str, Any]],
    candidate_scores: dict[str, Any],
    *,
    baseline_record: ExperimentRecord | None = None,
    candidate_record: ExperimentRecord | None = None,
) -> tuple[dict[str, Any], str]:
    config = load_config(project_root)
    gates = config.gates
    regressed_cases = sum(1 for item in changed_cases if float(item.get("score_delta", 0.0)) < 0.0)
    critical_tags = [str(t).strip() for t in (gates.governance_critical_tags or []) if str(t).strip()]
    critical_tag_set = set(critical_tags)
    regressed_governance_cases = 0
    if critical_tag_set:
        for item in changed_cases:
            if float(item.get("score_delta", 0.0)) >= 0.0:
                continue
            case_tags = {str(t) for t in (item.get("tags") or [])}
            if case_tags & critical_tag_set:
                regressed_governance_cases += 1
    results = {
        "benchmark_clean": {
            "passed": (comparison_mode == "clean") or (not gates.require_clean_benchmark),
            "actual": comparison_mode,
            "required": "clean" if gates.require_clean_benchmark else "any",
        },
        "average_score_delta": {
            "passed": float(metric_deltas.get("average_score", 0.0)) >= float(gates.min_average_score_delta),
            "actual": round(float(metric_deltas.get("average_score", 0.0)), 3),
            "required": gates.min_average_score_delta,
        },
        "passed_case_delta": {
            "passed": float(metric_deltas.get("passed_cases", 0.0)) >= float(gates.min_passed_case_delta),
            "actual": float(metric_deltas.get("passed_cases", 0.0)),
            "required": gates.min_passed_case_delta,
        },
        "regressed_cases": {
            "passed": regressed_cases <= int(gates.max_regressed_cases),
            "actual": regressed_cases,
            "required": gates.max_regressed_cases,
        },
    }
    if critical_tag_set:
        max_gov = (
            gates.max_regressed_governance_tag_cases
            if gates.max_regressed_governance_tag_cases is not None
            else int(gates.max_regressed_cases)
        )
        results["regressed_governance_tag_cases"] = {
            "passed": regressed_governance_cases <= int(max_gov),
            "actual": regressed_governance_cases,
            "required": max_gov,
            "tags": sorted(critical_tag_set),
        }
    if gates.min_average_score is not None:
        results["minimum_average_score"] = {
            "passed": float(candidate_scores.get("average_score", 0.0)) >= float(gates.min_average_score),
            "actual": round(float(candidate_scores.get("average_score", 0.0)), 3),
            "required": gates.min_average_score,
        }
    if gates.max_average_latency_ms_delta is not None:
        results["average_latency_delta"] = {
            "passed": float(behavior_deltas.get("avg_latency_ms_delta", 0.0))
            <= float(gates.max_average_latency_ms_delta),
            "actual": float(behavior_deltas.get("avg_latency_ms_delta", 0.0)),
            "required": gates.max_average_latency_ms_delta,
        }
    if gates.max_average_step_count_delta is not None:
        results["average_step_count_delta"] = {
            "passed": float(behavior_deltas.get("avg_step_count_delta", 0.0))
            <= float(gates.max_average_step_count_delta),
            "actual": float(behavior_deltas.get("avg_step_count_delta", 0.0)),
            "required": gates.max_average_step_count_delta,
        }
    if gates.max_average_cost_estimate_delta is not None:
        results["average_cost_estimate_delta"] = {
            "passed": float(behavior_deltas.get("avg_cost_estimate_delta", 0.0))
            <= float(gates.max_average_cost_estimate_delta),
            "actual": float(behavior_deltas.get("avg_cost_estimate_delta", 0.0)),
            "required": gates.max_average_cost_estimate_delta,
        }
    candidate_stability = _stability_summary_for_record(project_root, candidate_record)
    baseline_stability = _stability_summary_for_record(project_root, baseline_record)
    if (
        gates.min_stability_runs > 1
        or gates.max_average_score_stddev is not None
        or gates.max_average_latency_cv is not None
        or gates.max_average_cost_cv is not None
    ):
        results["candidate_stability_runs"] = {
            "passed": bool(candidate_stability)
            and int((candidate_stability or {}).get("repeat_count", 0)) >= int(gates.min_stability_runs),
            "actual": int((candidate_stability or {}).get("repeat_count", 0)),
            "required": gates.min_stability_runs,
        }
    if gates.require_baseline_stability:
        results["baseline_stability_runs"] = {
            "passed": bool(baseline_stability)
            and int((baseline_stability or {}).get("repeat_count", 0)) >= int(gates.min_stability_runs),
            "actual": int((baseline_stability or {}).get("repeat_count", 0)),
            "required": gates.min_stability_runs,
        }
    if gates.max_average_score_stddev is not None:
        actual_raw = (((candidate_stability or {}).get("metrics") or {}).get("average_score") or {}).get("stddev")
        actual = float(actual_raw) if actual_raw is not None else None
        results["candidate_score_stddev"] = {
            "passed": bool(candidate_stability)
            and actual is not None
            and actual <= float(gates.max_average_score_stddev),
            "actual": actual,
            "required": gates.max_average_score_stddev,
        }
    if gates.max_average_latency_cv is not None:
        actual = (((candidate_stability or {}).get("metrics") or {}).get("average_latency_ms") or {}).get("cv")
        actual_value = float(actual) if actual is not None else None
        results["candidate_latency_cv"] = {
            "passed": bool(candidate_stability)
            and actual_value is not None
            and actual_value <= float(gates.max_average_latency_cv),
            "actual": actual_value,
            "required": gates.max_average_latency_cv,
        }
    if gates.max_average_cost_cv is not None:
        actual = (((candidate_stability or {}).get("metrics") or {}).get("average_cost_estimate") or {}).get("cv")
        actual_value = float(actual) if actual is not None else None
        results["candidate_cost_cv"] = {
            "passed": bool(candidate_stability)
            and actual_value is not None
            and actual_value <= float(gates.max_average_cost_cv),
            "actual": actual_value,
            "required": gates.max_average_cost_cv,
        }
    average_token_usage_deltas = behavior_deltas.get("average_token_usage_deltas", {}) or {}
    average_total_token_delta = float(
        average_token_usage_deltas.get(
            "total",
            sum(float(value) for key, value in average_token_usage_deltas.items() if key != "total"),
        )
    )
    unused_surface_added = [
        *behavior_deltas.get("unused_available_tools_added", []),
        *behavior_deltas.get("unused_available_skills_added", []),
        *behavior_deltas.get("unused_available_plugins_added", []),
        *behavior_deltas.get("unused_available_mcps_added", []),
        *behavior_deltas.get("unused_available_prompt_keys_added", []),
    ]
    score_neutral = (
        abs(float(metric_deltas.get("average_score", 0.0))) < 1e-9
        and abs(float(metric_deltas.get("passed_cases", 0.0))) < 1e-9
        and regressed_cases == 0
    )
    if score_neutral:
        has_neutral_overhead = (
            float(behavior_deltas.get("avg_step_count_delta", 0.0)) > 0.0
            or float(behavior_deltas.get("avg_cost_estimate_delta", 0.0)) > 0.0
            or average_total_token_delta > 0.0
            or bool(unused_surface_added)
        )
        results["score_neutral_overhead"] = {
            "passed": not has_neutral_overhead,
            "actual": {
                "avg_step_count_delta": float(behavior_deltas.get("avg_step_count_delta", 0.0)),
                "avg_cost_estimate_delta": float(behavior_deltas.get("avg_cost_estimate_delta", 0.0)),
                "average_total_token_delta": average_total_token_delta,
                "unused_surface_added": unused_surface_added,
            },
            "required": "score gain or no added step, token, cost, or unused surface overhead",
        }
    if candidate_record is not None:
        from agentworkbench.loop_checks import loop_check_gate

        loop_gate = loop_check_gate(project_root, candidate_record)
        if loop_gate is not None:
            results["loop_readiness"] = loop_gate
    overall_passed = all(bool(item.get("passed", False)) for item in results.values() if isinstance(item, dict))
    results["overall_passed"] = overall_passed
    if overall_passed:
        action = "promote"
    elif comparison_mode != "clean" and gates.require_clean_benchmark:
        action = "review-benchmark-drift"
    elif regressed_cases > int(gates.max_regressed_cases) or float(metric_deltas.get("average_score", 0.0)) < 0.0:
        action = "reject"
    else:
        action = "review"
    return results, action


def _initial_promotion_gates(project_root: Path, candidate_record: ExperimentRecord) -> tuple[dict[str, Any], str]:
    config = load_config(project_root)
    gates = config.gates
    results: dict[str, Any] = {"baseline_required": False}
    average_score = float(candidate_record.scores.get("average_score", 0.0))
    if gates.min_average_score is not None:
        results["minimum_average_score"] = {
            "passed": average_score >= float(gates.min_average_score),
            "actual": round(average_score, 3),
            "required": gates.min_average_score,
        }
    candidate_stability = _stability_summary_for_record(project_root, candidate_record)
    if (
        gates.min_stability_runs > 1
        or gates.max_average_score_stddev is not None
        or gates.max_average_latency_cv is not None
        or gates.max_average_cost_cv is not None
    ):
        results["candidate_stability_runs"] = {
            "passed": bool(candidate_stability)
            and int((candidate_stability or {}).get("repeat_count", 0)) >= int(gates.min_stability_runs),
            "actual": int((candidate_stability or {}).get("repeat_count", 0)),
            "required": gates.min_stability_runs,
        }
    if gates.max_average_score_stddev is not None:
        actual_raw = (((candidate_stability or {}).get("metrics") or {}).get("average_score") or {}).get("stddev")
        actual = float(actual_raw) if actual_raw is not None else None
        results["candidate_score_stddev"] = {
            "passed": bool(candidate_stability)
            and actual is not None
            and actual <= float(gates.max_average_score_stddev),
            "actual": actual,
            "required": gates.max_average_score_stddev,
        }
    if gates.max_average_latency_cv is not None:
        actual = (((candidate_stability or {}).get("metrics") or {}).get("average_latency_ms") or {}).get("cv")
        actual_value = float(actual) if actual is not None else None
        results["candidate_latency_cv"] = {
            "passed": bool(candidate_stability)
            and actual_value is not None
            and actual_value <= float(gates.max_average_latency_cv),
            "actual": actual_value,
            "required": gates.max_average_latency_cv,
        }
    if gates.max_average_cost_cv is not None:
        actual = (((candidate_stability or {}).get("metrics") or {}).get("average_cost_estimate") or {}).get("cv")
        actual_value = float(actual) if actual is not None else None
        results["candidate_cost_cv"] = {
            "passed": bool(candidate_stability)
            and actual_value is not None
            and actual_value <= float(gates.max_average_cost_cv),
            "actual": actual_value,
            "required": gates.max_average_cost_cv,
        }
    from agentworkbench.loop_checks import loop_check_gate

    loop_gate = loop_check_gate(project_root, candidate_record)
    if loop_gate is not None:
        results["loop_readiness"] = loop_gate
    overall_passed = all(bool(item.get("passed", False)) for item in results.values() if isinstance(item, dict))
    results["overall_passed"] = overall_passed
    return results, ("promote" if overall_passed else "review")


__all__ = [
    "compare_experiments",
    "compare_against_best",
    "promote_experiment",
    "status_summary",
    "_gate_results",
    "_initial_promotion_gates",
]


def compare_experiments(project_root: Path, baseline_id: str, candidate_id: str) -> ComparisonRecord:
    from agentworkbench.runner import (
        _baseline_ladder,
        _load_experiment,
        _load_run_rows,
        _pareto_summary,
        _stability_summary_for_record,
    )

    baseline_record, baseline_scores = _load_experiment(project_root, baseline_id)
    candidate_record, candidate_scores = _load_experiment(project_root, candidate_id)
    baseline_rows = _load_run_rows(project_root, baseline_id)
    candidate_rows = _load_run_rows(project_root, candidate_id)
    repo_changes, repo_diff = compare_snapshot_states(baseline_record.repo_after, candidate_record.repo_before)
    repo_summary = repo_change_summary(
        baseline_record.spec_snapshot,
        candidate_record.spec_snapshot,
        repo_changes,
    )
    mode, benchmark_changes = compare_benchmark_hashes(
        baseline_record.benchmark_hashes, candidate_record.benchmark_hashes
    )
    metric_deltas = {
        "average_score": float(candidate_scores.get("average_score", 0.0))
        - float(baseline_scores.get("average_score", 0.0)),
        "passed_cases": float(candidate_scores.get("passed_cases", 0)) - float(baseline_scores.get("passed_cases", 0)),
    }
    baseline_metric_averages = baseline_scores.get("metric_averages", {}) or {}
    candidate_metric_averages = candidate_scores.get("metric_averages", {}) or {}
    for name in sorted(set(baseline_metric_averages) | set(candidate_metric_averages)):
        metric_deltas[f"metric.{name}"] = float(candidate_metric_averages.get(name, 0.0)) - float(
            baseline_metric_averages.get(name, 0.0)
        )
    behavior_delta_summary = behavior_deltas(baseline_record.behavior_summary, candidate_record.behavior_summary)
    spec_change_summary = spec_changes(baseline_record.spec_snapshot, candidate_record.spec_snapshot)
    changed_case_rows = changed_cases(
        baseline_rows,
        candidate_rows,
        baseline_spec_snapshot=baseline_record.spec_snapshot,
        candidate_spec_snapshot=candidate_record.spec_snapshot,
    )
    telemetry_detail = telemetry_summary(baseline_record, candidate_record)
    benchmark_drift = benchmark_drift_summary(baseline_record, candidate_record, mode, benchmark_changes)
    stability_summary = {
        "baseline": _stability_summary_for_record(project_root, baseline_record) or {},
        "candidate": _stability_summary_for_record(project_root, candidate_record) or {},
    }
    statistical_summary = paired_comparison_statistics(baseline_rows, candidate_rows)
    surface_detail_changes = compare_surface_snapshots(
        baseline_record.surface_snapshot or {},
        candidate_record.surface_snapshot or {},
    )
    pareto_summary = _pareto_summary(project_root, baseline_record, candidate_record)
    gate_results, recommended_action = _gate_results(
        project_root,
        mode,
        metric_deltas,
        behavior_delta_summary,
        changed_case_rows,
        candidate_scores,
        baseline_record=baseline_record,
        candidate_record=candidate_record,
    )
    comparison = ComparisonRecord(
        baseline_id=baseline_id,
        candidate_id=candidate_id,
        comparison_mode=mode,
        metric_deltas=metric_deltas,
        behavior_deltas=behavior_delta_summary,
        spec_changes=spec_change_summary,
        changed_cases=changed_case_rows,
        baseline_ladder=_baseline_ladder(project_root, candidate_record),
        benchmark_changes=benchmark_changes,
        repo_changes=repo_changes,
        repo_change_summary=repo_summary,
        surface_detail_changes=surface_detail_changes,
        baseline_runtime_changes=baseline_record.changed_files,
        candidate_runtime_changes=candidate_record.changed_files,
        telemetry_summary=telemetry_detail,
        benchmark_drift=benchmark_drift,
        stability_summary=stability_summary,
        statistical_summary=statistical_summary,
        pareto_summary=pareto_summary,
        failure_clusters=[],
        gate_results=gate_results,
        recommended_action=recommended_action,
        summary=comparison_summary(metric_deltas, changed_case_rows, behavior_delta_summary, repo_summary),
    )
    focus_cases = [
        item for item in changed_case_rows if float(item.get("score_delta", 0.0)) < 0.0
    ] or changed_case_rows[:5]
    comparison.failure_clusters = failure_clusters(comparison, focus_cases, {})
    compare_dir = ensure_dir(control_dir(project_root) / "reports")
    compare_stem = _compare_artifact_stem(baseline_id, candidate_id)
    write_json(compare_dir / f"{compare_stem}.json", comparison.model_dump(mode="json"))
    write_json(compare_dir / "latest-compare.json", comparison.model_dump(mode="json"))
    write_report(compare_dir / f"{compare_stem}.repo.diff", repo_diff or "")
    write_report(compare_dir / "latest-compare.repo.diff", repo_diff or "")
    write_report(compare_dir / f"{compare_stem}.md", render_compare_report(comparison))
    write_report(compare_dir / "latest-compare.md", render_compare_report(comparison))
    return comparison


def compare_against_best(project_root: Path, candidate_id: str) -> ComparisonRecord:
    from agentworkbench.runner import _best_comparable_baseline, _load_experiment

    candidate_record, _ = _load_experiment(project_root, candidate_id)
    baseline_record = _best_comparable_baseline(project_root, candidate_record)
    if baseline_record is None:
        raise ValueError(
            f"No comparable baseline found for {candidate_id}. Run a prior experiment on the same eval/subset/benchmark signature first."
        )
    return compare_experiments(project_root, baseline_record.experiment_id, candidate_id)


def promote_experiment(project_root: Path, experiment_id: str, baseline_id: str | None = None) -> dict[str, Any]:
    from agentworkbench.runner import (
        _best_comparable_baseline,
        _load_experiment,
        _record_benchmark_signature,
        _refresh_experiment_report,
        _write_experiment_record,
        list_experiment_records,
    )

    candidate_record, _ = _load_experiment(project_root, experiment_id)
    baseline_record = None
    comparison = None
    if baseline_id:
        baseline_record, _ = _load_experiment(project_root, baseline_id)
    else:
        baseline_record = _best_comparable_baseline(project_root, candidate_record)
    if baseline_record is None:
        gate_results, recommended_action = _initial_promotion_gates(project_root, candidate_record)
        candidate_record.promotion_status = "promoted" if bool(gate_results.get("overall_passed")) else "rejected"
        candidate_record.promotion_notes = {
            "reason": "initial comparable baseline"
            if bool(gate_results.get("overall_passed"))
            else "failed initial promotion gates",
            "baseline_id": None,
            "recommended_action": recommended_action,
            "gate_results": gate_results,
        }
        _write_experiment_record(project_root, candidate_record)
        _refresh_experiment_report(project_root, candidate_record.experiment_id, update_latest=True)
        result = {
            "experiment_id": experiment_id,
            "baseline_id": None,
            "promotion_status": candidate_record.promotion_status,
            "recommended_action": recommended_action,
            "gate_results": gate_results,
        }
    else:
        comparison = compare_experiments(project_root, baseline_record.experiment_id, experiment_id)
        if bool(comparison.gate_results.get("overall_passed")):
            candidate_record.promotion_status = "promoted"
            candidate_record.promotion_notes = {
                "reason": "passed promotion gates",
                "baseline_id": baseline_record.experiment_id,
                "recommended_action": comparison.recommended_action,
                "gate_results": comparison.gate_results,
            }
            comparable_records = [
                record
                for record in list_experiment_records(
                    project_root, eval_id=candidate_record.eval_id, subset=candidate_record.subset
                )
                if record.experiment_id != candidate_record.experiment_id
                and _record_benchmark_signature(record) == _record_benchmark_signature(candidate_record)
                and record.promotion_status == "promoted"
            ]
            for record in comparable_records:
                record.promotion_status = "candidate"
                record.promotion_notes = {
                    "reason": "superseded",
                    "superseded_by": candidate_record.experiment_id,
                }
                _write_experiment_record(project_root, record)
                _refresh_experiment_report(project_root, record.experiment_id)
        else:
            candidate_record.promotion_status = "rejected"
            candidate_record.promotion_notes = {
                "reason": "failed promotion gates",
                "baseline_id": baseline_record.experiment_id,
                "recommended_action": comparison.recommended_action,
                "gate_results": comparison.gate_results,
            }
        _write_experiment_record(project_root, candidate_record)
        _refresh_experiment_report(project_root, candidate_record.experiment_id, update_latest=True)
        result = {
            "experiment_id": experiment_id,
            "baseline_id": baseline_record.experiment_id,
            "promotion_status": candidate_record.promotion_status,
            "recommended_action": comparison.recommended_action,
            "gate_results": comparison.gate_results,
        }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / "promotion-latest.json", result)
    return result


def status_summary(
    project_root: Path,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    promoted_only: bool = False,
    limit: int = 10,
) -> dict[str, Any]:
    from agentworkbench.runner import (
        _best_comparable_baseline,
        _latest_matching_json_artifact,
        _pareto_frontier,
        _record_benchmark_signature,
        _record_created_key,
        _record_sort_key,
        _record_summary,
        list_experiment_records,
    )

    config = load_config(project_root)
    records = list_experiment_records(
        project_root,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        promoted_only=promoted_only,
    )
    benchmark_signatures = sorted({_record_benchmark_signature(record) for record in records})
    benchmark_signature_set = set(benchmark_signatures)

    def _matches_filtered_artifact(payload: dict[str, Any]) -> bool:
        if eval_id and str(payload.get("eval_id") or "") != str(eval_id):
            return False
        if subset and str(payload.get("subset") or "") != str(subset):
            return False
        payload_signatures = {
            str(item)
            for item in [
                payload.get("benchmark_signature"),
                *(payload.get("benchmark_signatures") or []),
            ]
            if str(item or "").strip()
        }
        if benchmark_signature:
            return str(benchmark_signature) in payload_signatures
        if benchmark_signature_set and payload_signatures:
            return bool(payload_signatures & benchmark_signature_set)
        return True

    promotion_counts = {
        "candidate": sum(1 for record in records if record.promotion_status == "candidate"),
        "promoted": sum(1 for record in records if record.promotion_status == "promoted"),
        "rejected": sum(1 for record in records if record.promotion_status == "rejected"),
    }
    ladder: dict[str, list[dict[str, Any]]] = {}
    for sig in benchmark_signatures:
        sig_records = sorted(
            [record for record in records if _record_benchmark_signature(record) == sig],
            key=_record_sort_key,
            reverse=True,
        )
        ladder[sig] = [_record_summary(record) for record in sig_records[:limit]]
    series_map: dict[str, list[ExperimentRecord]] = {}
    for record in records:
        if not record.series_id:
            continue
        if record.series_id not in series_map:
            series_map[record.series_id] = []
        series_map[record.series_id].append(record)
    for series_id in series_map:
        series_map[series_id] = sorted(series_map[series_id], key=_record_sort_key, reverse=True)
    series_summaries: list[dict[str, Any]] = []
    for series_id, series_records in series_map.items():
        if len(series_records) < 2:
            continue
        first_record = series_records[0]
        latest_record = series_records[-1]
        score_delta = float(latest_record.scores.get("average_score", 0.0)) - float(
            first_record.scores.get("average_score", 0.0)
        )
        passed_delta = int(latest_record.scores.get("passed_cases", 0)) - int(
            first_record.scores.get("passed_cases", 0)
        )
        series_summaries.append(
            {
                "series_id": series_id,
                "agent_id": first_record.agent_id,
                "eval_id": first_record.eval_id,
                "subset": first_record.subset,
                "run_count": len(series_records),
                "score_delta": round(score_delta, 3),
                "passed_delta": passed_delta,
                "current_score": float(latest_record.scores.get("average_score", 0.0)),
                "current_passed": int(latest_record.scores.get("passed_cases", 0)),
                "current_promotion_status": latest_record.promotion_status,
            }
        )
    series_summaries.sort(key=lambda x: x["run_count"], reverse=True)
    top_recommendations: list[dict[str, Any]] = []
    for record in sorted(records, key=_record_sort_key, reverse=True)[:5]:
        if record.promotion_status != "candidate":
            continue
        baseline = _best_comparable_baseline(project_root, record)
        if baseline is None:
            continue
        top_recommendations.append(
            {
                "experiment_id": record.experiment_id,
                "agent_id": record.agent_id,
                "eval_id": record.eval_id,
                "subset": record.subset,
                "score": float(record.scores.get("average_score", 0.0)),
                "passed": int(record.scores.get("passed_cases", 0)),
                "baseline_id": baseline.experiment_id,
                "baseline_score": float(baseline.scores.get("average_score", 0.0)),
            }
        )
    promoted_records = [record for record in records if record.promotion_status == "promoted"]
    pareto_frontier: list[dict[str, Any]] = []
    if promoted_records:
        from agentworkbench.runner import _pareto_frontier

        frontier = _pareto_frontier(promoted_records)
        pareto_frontier = [_record_summary(record) for record in frontier[:5]]

    latest_stability = _latest_matching_json_artifact(
        control_dir(project_root) / "stability",
        _matches_filtered_artifact,
    )
    latest_matrix = _latest_matching_json_artifact(
        control_dir(project_root) / "matrices",
        _matches_filtered_artifact,
    )
    latest_factorial = _latest_matching_json_artifact(
        control_dir(project_root) / "factorials",
        _matches_filtered_artifact,
    )

    latest_summary_record: ExperimentRecord | None = (
        sorted(records, key=_record_created_key, reverse=True)[0] if records else None
    )
    latest_experiment_summary = _record_summary(latest_summary_record) if latest_summary_record else None

    # Get surface recommendations for the latest experiment
    surface_recommendations = []
    if latest_factorial and latest_factorial.get("surface_recommendations"):
        surface_recommendations = list(latest_factorial.get("surface_recommendations") or [])
    elif latest_summary_record is not None:
        from agentworkbench.runner import _record_surface_recommendations

        surface_recommendations = _record_surface_recommendations(project_root, latest_summary_record)

    streams: list[dict[str, Any]] = []
    for sig in benchmark_signatures:
        sig_records = [r for r in records if _record_benchmark_signature(r) == sig]
        if not sig_records:
            continue
        latest_run = sorted(sig_records, key=_record_created_key, reverse=True)[0]
        best_run = sorted(sig_records, key=_record_sort_key, reverse=True)[0]
        baseline_records = [r for r in sig_records if r.promotion_status == "promoted"]
        promoted = sorted(baseline_records, key=_record_sort_key, reverse=True)[0] if baseline_records else None

        model_name = str((latest_run.spec_snapshot or {}).get("model_name") or "unknown")
        same_model_records = [
            r for r in sig_records if str((r.spec_snapshot or {}).get("model_name") or "unknown") == model_name
        ]
        best_same_model = (
            sorted(same_model_records, key=_record_sort_key, reverse=True)[0] if same_model_records else None
        )

        same_agent_records = [r for r in sig_records if r.agent_id == latest_run.agent_id]
        best_same_agent = (
            sorted(same_agent_records, key=_record_sort_key, reverse=True)[0] if same_agent_records else None
        )

        stream_pareto = _pareto_frontier(sig_records)[:5]
        candidate_records = [r for r in sig_records if r.promotion_status == "candidate"]
        latest_candidate = (
            sorted(candidate_records, key=_record_created_key, reverse=True)[0] if candidate_records else None
        )

        streams.append(
            {
                "eval_id": latest_run.eval_id,
                "subset": latest_run.subset,
                "benchmark_signature": sig,
                "experiment_count": len(sig_records),
                "promoted_baseline": _record_summary(promoted) if promoted else None,
                "best_run": _record_summary(best_run),
                "latest_run": _record_summary(latest_run),
                "latest_candidate": _record_summary(latest_candidate) if latest_candidate else None,
                "best_same_model_run": _record_summary(best_same_model) if best_same_model else None,
                "best_same_agent_run": _record_summary(best_same_agent) if best_same_agent else None,
                "latest_on_pareto_frontier": any(record.experiment_id == latest_run.experiment_id for record in stream_pareto),
                "pareto_frontier": [_record_summary(r) for r in stream_pareto],
            }
        )

    latest_compare_path = control_dir(project_root) / "reports" / "latest-compare.json"
    latest_compare = None
    if latest_compare_path.exists():
        try:
            candidate_compare = read_json(latest_compare_path)
            candidate_id = candidate_compare.get("candidate_id")
            # Only include latest_compare if it matches the latest experiment in the current view
            if latest_experiment_summary and candidate_id == latest_experiment_summary.get("experiment_id"):
                latest_compare = candidate_compare
        except Exception:
            pass

    latest_baseline_ladder = None
    if latest_experiment_summary and records:
        from agentworkbench.runner import _baseline_ladder, _load_experiment

        experiment_id = latest_experiment_summary.get("experiment_id")
        if experiment_id:
            try:
                record, _ = _load_experiment(project_root, experiment_id)
                latest_baseline_ladder = _baseline_ladder(project_root, record)
            except Exception:
                pass

    latest_pareto_frontier = pareto_frontier[0] if pareto_frontier else None

    payload = {
        "project_root": str(project_root),
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "benchmark_signature": benchmark_signature,
        "promoted_only": promoted_only,
        "config": {
            "artifacts_dir": config.artifacts_dir,
            "control_dir": str(control_dir(project_root)),
        },
        "total_experiments": len(records),
        "gates": config.gates.model_dump(mode="json"),
        "promotion_counts": promotion_counts,
        "benchmark_signatures": benchmark_signatures,
        "ladder": ladder,
        "series_summaries": series_summaries[:10],
        "top_recommendations": top_recommendations[:5],
        "pareto_frontier": pareto_frontier,
        "latest_pareto_frontier": latest_pareto_frontier,
        "latest_experiment": latest_experiment_summary,
        "latest_compare": latest_compare,
        "latest_baseline_ladder": latest_baseline_ladder,
        "latest_stability": latest_stability,
        "latest_matrix": latest_matrix,
        "latest_factorial": latest_factorial,
        "surface_recommendations": surface_recommendations,
        "streams": streams,
    }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / "status-latest.json", payload)
    write_report(reports_dir / "status-latest.md", render_status_report(payload))
    return payload
