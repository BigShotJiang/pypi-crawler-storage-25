"""Sequential multi-agent runs: each case passes the prior agent's output as input to the next.

Features:
- Per-step scoring (always on): every step is scored against the original eval case.
- Structured handoffs: template variables for prior_output, prior_structured_output,
  prior_tool_calls, prior_evidence, prior_trace, chain_context, original_input, case_id, step.
- Dynamic branching: step configs can include branch_condition expressions.
- Turn preservation: steps 1+ receive accumulated conversation turns.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentworkbench.adapters import get_adapter
from agentworkbench.aggregate_metrics import aggregate_chain_rows
from agentworkbench.case_selection import build_case_selection
from agentworkbench.config import control_dir, experiment_dir, load_config, load_model
from agentworkbench.constants import RUN_CONTEXT_FILENAME
from agentworkbench.evals import ScoringContext, load_eval_cases, load_scoring_context, score_run
from agentworkbench.models import (
    AgentSpec,
    ChainAggregate,
    ChainContext,
    ChainStepConfig,
    EvalCase,
    ExperimentRecord,
    StepScore,
)
from agentworkbench.report_experiment import render_experiment_report
from agentworkbench.reports import write_report
from agentworkbench.run_context import build_run_context, persist_run_artifacts
from agentworkbench.run_failures import failed_cases_for_experiment
from agentworkbench.run_finalize import finalize_run
from agentworkbench.run_helpers import _spec_snapshot
from agentworkbench.run_rows import execution_failure_score, weighted_score
from agentworkbench.safe_expressions import UnsafeExpressionError, evaluate_condition
from agentworkbench.snapshot import capture_snapshot, compute_benchmark_hashes
from agentworkbench.surface_details import capture_surface_snapshot
from agentworkbench.telemetry import enrich_run_artifact_payload
from agentworkbench.utils import created_at_utc, ensure_dir, utc_timestamp_slug, write_json, write_jsonl

HANDOFF_TEMPLATE_FIELDS = {
    "prior_output",
    "prior_structured_output",
    "prior_tool_calls",
    "prior_evidence",
    "prior_trace",
    "shared_context",
    "original_input",
    "input",
    "case_id",
    "step",
    "chain_context",
}


def _evaluate_branch_condition(condition: str | None, prior_step_score: dict[str, Any] | None) -> bool:
    if not condition:
        return True
    if prior_step_score is None:
        return True
    try:
        return evaluate_condition(
            condition,
            {
                "prior_score": prior_step_score.get("score", 0.0),
                "prior_passed": prior_step_score.get("passed", False),
            },
        )
    except UnsafeExpressionError:
        return True


def _build_chain_context(
    chain_steps: list[dict[str, Any]],
    original_input: str,
    case_id: str,
) -> ChainContext:
    accumulated_parts: list[str] = []
    all_tool_calls: list[dict[str, Any]] = []
    all_evidence: list[dict[str, Any]] = []
    all_trace_events: list[dict[str, Any]] = []

    for step_info in chain_steps:
        output_preview = step_info.get("final_output_preview", "")
        if output_preview:
            accumulated_parts.append(output_preview)
        artifact = step_info.get("artifact_summary") or {}
        all_tool_calls.extend(artifact.get("tool_calls", []))
        all_evidence.extend(artifact.get("evidence_records", []))
        all_trace_events.extend(artifact.get("trace_events", []))

    return ChainContext(
        steps=chain_steps,
        original_input=original_input,
        case_id=case_id,
        accumulated_output="\n---\n".join(accumulated_parts),
        aggregated_tool_calls=all_tool_calls,
        aggregated_evidence=all_evidence,
        aggregated_trace_events=all_trace_events,
    )


def _resolve_step_config(
    agent_ids: list[str],
    step_configs: list[dict[str, Any]] | None,
) -> list[ChainStepConfig]:
    if step_configs:
        return [ChainStepConfig(**cfg) for cfg in step_configs]
    return [ChainStepConfig(agent_id=aid) for aid in agent_ids]


def _build_handoff(
    template: str,
    prior_output: str,
    prior_artifact: dict[str, Any] | None,
    original_input: str,
    case_id: str,
    step_idx: int,
    chain_context: ChainContext | None,
    shared_context: dict[str, Any] | None = None,
) -> str:
    prior_artifact = prior_artifact or {}
    context_json = json.dumps(chain_context.model_dump(mode="json")) if chain_context else "{}"
    shared_context_json = json.dumps(shared_context or {})
    try:
        return template.format(
            prior_output=prior_output,
            prior_structured_output=json.dumps(prior_artifact.get("structured_output", {})),
            prior_tool_calls=json.dumps(prior_artifact.get("tool_calls", [])),
            prior_evidence=json.dumps(prior_artifact.get("evidence_records", [])),
            prior_trace=json.dumps(prior_artifact.get("trace_events", [])),
            shared_context=shared_context_json,
            original_input=original_input,
            input=original_input,
            case_id=case_id,
            step=step_idx,
            chain_context=context_json,
        )
    except KeyError as exc:
        raise ValueError(
            f"chain_handoff_template unknown field `{exc.args[0]}`. Use: {', '.join(sorted(HANDOFF_TEMPLATE_FIELDS))}."
        ) from exc


def _accumulate_turns(
    original_turns: list[dict[str, Any]],
    prior_output: str,
    handoff_input: str,
) -> list[dict[str, Any]]:
    if not original_turns:
        return [{"role": "user", "content": handoff_input}]
    turns = list(original_turns)
    if prior_output:
        turns.append({"role": "assistant", "content": prior_output})
    turns.append({"role": "user", "content": handoff_input})
    return turns


def _score_step(
    project_root: Path,
    eval_id: str,
    artifact: Any,
    case: EvalCase,
    scoring_context: ScoringContext,
    step_expectations: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], bool, float]:
    scored_case = case
    if step_expectations:
        enriched_metadata = dict(case.metadata or {})
        enriched_metadata["process_expectations"] = step_expectations.get(
            "process_expectations", case.metadata.get("process_expectations", {})
        )
        enriched_metadata.update(step_expectations)
        scored_case = case.model_copy(update={"metadata": enriched_metadata})

    scores = score_run(project_root, eval_id, artifact, scored_case, scoring_context=scoring_context)
    if artifact.errors:
        scores = [*scores, execution_failure_score(artifact.errors)]
    passed = not artifact.errors and all(bool(s.get("passed", False)) for s in scores)
    score = 0.0 if artifact.errors else weighted_score(scores)
    return scores, passed, score


def run_chain_experiment(
    project_root: Path,
    agent_ids: list[str],
    eval_id: str,
    subset: str,
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
    chain_handoff_template: str = "{prior_output}",
    step_configs: list[dict[str, Any]] | None = None,
) -> tuple[ExperimentRecord, dict[str, Any]]:
    """Run each eval case through ``agent_ids`` in order; each step's ``final_output`` feeds the next.

    Every step is scored against the original eval case. The final step's score is the case score.
    Steps support dynamic branching via ``branch_condition`` expressions.
    Conversation turns are preserved across steps.
    """
    if len(agent_ids) < 2:
        raise ValueError("Multi-agent chain requires at least two agent ids")

    config = load_config(project_root)
    chain_key = "+".join(agent_ids)
    experiment_id = f"{chain_key}-{eval_id}-{subset}-{utc_timestamp_slug()}"
    exp_dir = experiment_dir(project_root, experiment_id)
    cases = load_eval_cases(
        project_root,
        eval_id,
        subset,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    first_spec = load_model(control_dir(project_root) / "agents" / f"{agent_ids[0]}.yaml", AgentSpec)
    spec_snapshot = _spec_snapshot(first_spec, project_root)
    surface_snapshot = capture_surface_snapshot(project_root, first_spec)
    selection = build_case_selection(
        cases,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    before_snapshot = capture_snapshot(project_root, config.snapshot_mode)
    before_benchmarks = compute_benchmark_hashes(project_root)
    write_json(
        exp_dir / RUN_CONTEXT_FILENAME,
        build_run_context(
            agent_id=chain_key,
            eval_id=eval_id,
            subset=subset,
            selection=selection,
            spec_snapshot=spec_snapshot,
            surface_snapshot=surface_snapshot,
            repo_before=before_snapshot,
            benchmark_hashes_before=before_benchmarks,
            extra={
                "agent_ids": list(agent_ids),
                "run_kind": "chain",
            },
        ),
    )
    persist_run_artifacts(
        exp_dir,
        spec_snapshot=spec_snapshot,
        selection=selection,
        surface_snapshot=surface_snapshot,
    )

    scoring_ctx = load_scoring_context(project_root, eval_id)
    resolved_configs = _resolve_step_config(agent_ids, step_configs)
    rows: list[dict[str, Any]] = []

    for case in cases:
        prior_output = ""
        prior_artifact_summary: dict[str, Any] = {}
        prior_step_score: dict[str, Any] | None = None
        chain_steps: list[dict[str, Any]] = []
        step_scores: list[StepScore] = []
        final_artifact: Any = None
        last_spec: AgentSpec | None = None
        accumulated_turns = list(case.turns) if case.turns else []

        for step_idx, step_cfg in enumerate(resolved_configs):
            aid = step_cfg.agent_id

            if not _evaluate_branch_condition(step_cfg.branch_condition, prior_step_score):
                chain_steps.append(
                    {
                        "agent_id": aid,
                        "step": step_idx,
                        "skipped": True,
                        "branch_condition": step_cfg.branch_condition,
                        "prior_score": prior_step_score,
                    }
                )
                continue

            spec = load_model(control_dir(project_root) / "agents" / f"{aid}.yaml", AgentSpec)
            last_spec = spec

            if step_idx == 0:
                step_case = case
                if case.turns:
                    accumulated_turns = list(case.turns)
            else:
                chain_ctx = _build_chain_context(chain_steps, case.input, case.id)
                handoff = _build_handoff(
                    step_cfg.handoff_template or chain_handoff_template,
                    prior_output=prior_output,
                    prior_artifact=prior_artifact_summary,
                    original_input=case.input,
                    case_id=case.id,
                    step_idx=step_idx,
                    chain_context=chain_ctx,
                    shared_context={},
                )
                new_turns = _accumulate_turns(accumulated_turns, prior_output, handoff)
                step_case = case.model_copy(
                    update={
                        "input": handoff,
                        "turns": new_turns,
                        "metadata": {**(case.metadata or {}), "chain_context": chain_ctx.model_dump(mode="json")},
                    }
                )
                accumulated_turns = new_turns

            adapter = get_adapter(spec.adapter)
            case_dir = ensure_dir(exp_dir / case.id / f"chain-{step_idx}-{aid}")
            artifact = adapter.invoke(project_root, spec, step_case, case_dir)
            artifact = artifact.__class__.model_validate(
                enrich_run_artifact_payload(
                    artifact.model_dump(mode="json"), spec_snapshot=_spec_snapshot(spec, project_root)
                )
            )

            scores, passed, score = _score_step(
                project_root,
                eval_id,
                artifact,
                case,
                scoring_ctx,
                step_expectations=step_cfg.step_expectations or None,
            )

            prior_output = str(
                artifact.final_output
                or (artifact.structured_output or {}).get("final_output")
                or (artifact.structured_output or {}).get("output")
                or ""
            )

            artifact_summary = {
                "final_output": prior_output,
                "tool_calls": artifact.tool_calls or [],
                "evidence_records": artifact.evidence_records or [],
                "trace_events": artifact.trace_events or [],
                "latency_ms": artifact.latency_ms,
                "token_usage": artifact.token_usage or {},
                "cost_estimate": artifact.cost_estimate,
                "step_count": artifact.step_count,
                "errors": artifact.errors or [],
            }

            step_score = StepScore(
                agent_id=aid,
                step=step_idx,
                scores=scores,
                passed=passed,
                score=score,
                final_output_preview=prior_output[:200],
                latency_ms=artifact.latency_ms,
                errors=artifact.errors or [],
            )
            step_scores.append(step_score)
            prior_step_score = step_score.model_dump(mode="json")

            chain_steps.append(
                {
                    "agent_id": aid,
                    "step": step_idx,
                    "final_output_preview": prior_output[:200],
                    "latency_ms": artifact.latency_ms,
                    "errors": artifact.errors or [],
                    "step_score": prior_step_score,
                    "artifact_summary": artifact_summary,
                }
            )
            prior_artifact_summary = artifact_summary
            final_artifact = artifact

        assert final_artifact is not None and last_spec is not None

        final_step_score = step_scores[-1] if step_scores else None
        final_scores = final_step_score.scores if final_step_score else []
        final_passed = final_step_score.passed if final_step_score else False
        final_score = final_step_score.score if final_step_score else 0.0

        chain_agg = _compute_chain_aggregate(chain_steps, step_scores)

        meta = dict(final_artifact.metadata or {})
        meta["chain_steps"] = chain_steps
        meta["chain_agent_ids"] = list(agent_ids)
        meta["chain_aggregate"] = chain_agg.model_dump(mode="json")
        meta["step_scores"] = [s.model_dump(mode="json") for s in step_scores]
        final_artifact = final_artifact.model_copy(update={"metadata": meta})

        rows.append(
            {
                "case": case.model_dump(mode="json"),
                "artifact": final_artifact.model_dump(mode="json"),
                "scores": final_scores,
                "passed": final_passed,
                "score": final_score,
            }
        )

    finalized = finalize_run(
        project_root,
        rows=rows,
        spec_snapshot=spec_snapshot,
        before_snapshot=before_snapshot,
        before_benchmarks=before_benchmarks,
        snapshot_mode=config.snapshot_mode,
        selection_fingerprint=selection["selection_fingerprint"],
    )
    aggregate = finalized.aggregate
    behavior_summary = finalized.behavior_summary
    chain_aggregate = _aggregate_chain_metrics(rows)
    aggregate["chain_aggregate"] = chain_aggregate
    record = ExperimentRecord(
        experiment_id=experiment_id,
        parent_experiment_id=None,
        series_id=None,
        agent_id=chain_key,
        eval_id=eval_id,
        subset=subset,
        created_at=created_at_utc(),
        benchmark_signature=finalized.benchmark_signature,
        spec_snapshot={**spec_snapshot, "chain_agent_ids": list(agent_ids)},
        repo_before=before_snapshot,
        repo_after=finalized.after_snapshot,
        changed_files=finalized.changed_files,
        benchmark_hashes=finalized.after_benchmarks,
        benchmark_manifest=finalized.after_manifest,
        case_selection=selection,
        selection_fingerprint=selection["selection_fingerprint"],
        selected_case_ids=selection["selected_case_ids"],
        completed_case_ids=[c.id for c in cases],
        total_case_count=len(cases),
        surface_snapshot=surface_snapshot,
        scores=aggregate,
        behavior_summary=behavior_summary,
        status="completed",
        promotion_status="candidate",
    )
    write_json(exp_dir / "experiment.json", record.model_dump(mode="json"))
    write_json(exp_dir / "aggregate.json", aggregate)
    write_json(exp_dir / "behavior.json", behavior_summary)
    write_jsonl(exp_dir / "runs.jsonl", rows)

    failed_cases = failed_cases_for_experiment(project_root, experiment_id)
    write_report(exp_dir / "report.md", render_experiment_report(record, aggregate, failed_cases))
    write_report(exp_dir / "repo.diff", finalized.diff_text)
    return record, aggregate


def _compute_chain_aggregate(chain_steps: list[dict[str, Any]], step_scores: list[StepScore]) -> ChainAggregate:
    executed = [s for s in chain_steps if not s.get("skipped")]
    skipped = [s for s in chain_steps if s.get("skipped")]
    total_latency = sum(s.get("latency_ms", 0) for s in executed)
    step_score_map = {s.agent_id: s.score for s in step_scores}
    degrading = []
    for i in range(1, len(step_scores)):
        if step_scores[i].score < step_scores[i - 1].score:
            degrading.append(step_scores[i].agent_id)

    return ChainAggregate(
        step_pass_rate=round(sum(1 for s in step_scores if s.passed) / len(step_scores), 3) if step_scores else 0.0,
        step_scores=step_score_map,
        degrading_steps=degrading,
        total_chain_latency_ms=total_latency,
        branch_skips=[
            {"step": s["step"], "agent_id": s["agent_id"], "condition": s.get("branch_condition")} for s in skipped
        ],
    )


def _aggregate_chain_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary = aggregate_chain_rows(rows)
    return {
        "average_step_pass_rate": summary["average_step_pass_rate"],
        "average_chain_latency_ms": summary["average_latency_ms"],
        "average_step_scores": summary["average_step_scores"],
        "degrading_step_frequency": summary["degrading_step_frequency"],
        "total_cases": summary["case_count"] or len(rows),
    }


__all__ = ["run_chain_experiment"]
