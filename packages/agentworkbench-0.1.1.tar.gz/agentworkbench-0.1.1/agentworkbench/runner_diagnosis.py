from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.case_selection import case_matches, normalize_case_selection
from agentworkbench.config import control_dir, load_config
from agentworkbench.experiment_analysis import (
    artifact_evidence,
    case_expectations,
    failure_clusters,
)
from agentworkbench.human_review import build_review_queue, experiment_human_checkpoints
from agentworkbench.human_review_store import pending_review_items, resolve_review_queue
from agentworkbench.models import ExperimentRecord
from agentworkbench.report_diagnosis import render_diagnosis_report
from agentworkbench.reports import write_report
from agentworkbench.runner_compare import compare_experiments
from agentworkbench.utils import ensure_dir, write_json


def _chain_diagnosis(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Analyze which chain steps fail most often."""
    step_failures: dict[int, dict[str, int]] = {}
    first_failing_step: dict[str, dict[str, Any]] = {}

    for row in rows:
        case_id = row.get("case", {}).get("id", "unknown")
        meta = row.get("artifact", {}).get("metadata", {})
        chain_steps = meta.get("chain_steps", [])

        for step in chain_steps:
            if step.get("skipped"):
                continue
            agent_id = step.get("agent_id", "unknown")
            step_idx = step.get("step", 0)
            step_score = step.get("step_score", {})

            if not step_score.get("passed", True):
                if step_idx not in step_failures:
                    step_failures[step_idx] = {}
                step_failures[step_idx][agent_id] = step_failures[step_idx].get(agent_id, 0) + 1

            if not step_score.get("passed", True) and case_id not in first_failing_step:
                first_failing_step[case_id] = {
                    "step": step_idx,
                    "agent_id": agent_id,
                    "score": step_score.get("score", 0.0),
                }

    weakest_step = None
    weakest_agent = None
    max_failures = 0
    for step_idx, agents in step_failures.items():
        for agent_id, count in agents.items():
            if count > max_failures:
                max_failures = count
                weakest_step = step_idx
                weakest_agent = agent_id

    return {
        "is_chain_run": bool(chain_steps),
        "weakest_step": weakest_step,
        "weakest_agent": weakest_agent,
        "step_failure_counts": step_failures,
        "first_failing_steps": first_failing_step,
    }


def _workflow_diagnosis(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Analyze node-level failures and route patterns for workflow runs."""
    node_failures: dict[str, dict[str, int]] = {}
    first_failing_node: dict[str, dict[str, Any]] = {}
    path_counts: dict[str, int] = {}
    terminal_counts: dict[str, int] = {}
    route_counts: dict[str, int] = {}
    unmatched_routes: list[dict[str, Any]] = []
    provider_recovery_counts: dict[str, int] = {}
    provider_recoveries: list[dict[str, Any]] = []
    loop_cases: list[str] = []
    dead_end_cases: list[str] = []
    duplicate_work_cases: list[dict[str, Any]] = []
    over_delegation_cases: list[dict[str, Any]] = []
    fan_out_total = 0
    join_total = 0
    shared_context_keys: set[str] = set()
    has_workflow = False

    for row in rows:
        case_id = row.get("case", {}).get("id", "unknown")
        meta = row.get("artifact", {}).get("metadata", {})
        workflow_steps = meta.get("workflow_steps", [])
        workflow_agg = meta.get("workflow_aggregate") or {}
        if workflow_steps:
            has_workflow = True
        path_signature = str(workflow_agg.get("path_signature") or "").strip()
        if path_signature:
            path_counts[path_signature] = path_counts.get(path_signature, 0) + 1
        terminal_node = str(workflow_agg.get("terminal_node") or "").strip()
        if terminal_node:
            terminal_counts[terminal_node] = terminal_counts.get(terminal_node, 0) + 1
        if bool(workflow_agg.get("loop_detected")):
            loop_cases.append(case_id)
        if int(workflow_agg.get("dead_end_count", 0) or 0) > 0:
            dead_end_cases.append(case_id)
        fan_out_total += int(workflow_agg.get("fan_out_count", 0) or 0)
        join_total += int(workflow_agg.get("join_count", 0) or 0)
        for key in workflow_agg.get("shared_context_keys") or []:
            if str(key).strip():
                shared_context_keys.add(str(key))
        duplicate_nodes = [str(item) for item in workflow_agg.get("duplicate_node_visits") or [] if str(item).strip()]
        if duplicate_nodes:
            duplicate_work_cases.append({"case_id": case_id, "node_ids": duplicate_nodes})
        executed_nodes = [str(item) for item in workflow_agg.get("executed_nodes") or [] if str(item).strip()]
        if executed_nodes:
            unique_nodes = len(set(executed_nodes))
            if len(executed_nodes) >= max(4, unique_nodes + 2):
                over_delegation_cases.append(
                    {
                        "case_id": case_id,
                        "executed_node_count": len(executed_nodes),
                        "unique_node_count": unique_nodes,
                        "path_signature": workflow_agg.get("path_signature") or "",
                    }
                )

        for item in workflow_agg.get("route_decisions") or []:
            if not isinstance(item, dict):
                continue
            label = str(item.get("label") or f"{item.get('from', '?')}->{item.get('to', '?')}")
            route_counts[label] = route_counts.get(label, 0) + 1
        for item in workflow_agg.get("unmatched_routes") or []:
            if isinstance(item, dict):
                unmatched_routes.append({"case_id": case_id, **item})

        for step in workflow_steps:
            node_id = str(step.get("node_id") or "unknown")
            agent_id = str(step.get("agent_id") or "unknown")
            step_score = step.get("step_score", {})
            trace_events = ((step.get("artifact_summary") or {}).get("trace_events") or [])
            recovered = any(
                isinstance(event, dict)
                and str(event.get("kind") or "").strip() == "provider_response"
                and str(event.get("name") or "").strip() == "recovered"
                for event in trace_events
            )
            if recovered:
                provider_recovery_counts[node_id] = provider_recovery_counts.get(node_id, 0) + 1
                provider_recoveries.append(
                    {
                        "case_id": case_id,
                        "node_id": node_id,
                        "agent_id": agent_id,
                    }
                )
            if not step_score.get("passed", True):
                node_failures.setdefault(node_id, {})
                node_failures[node_id][agent_id] = node_failures[node_id].get(agent_id, 0) + 1
                if case_id not in first_failing_node:
                    first_failing_node[case_id] = {
                        "node_id": node_id,
                        "agent_id": agent_id,
                        "score": step_score.get("score", 0.0),
                    }

    weakest_node = None
    weakest_agent = None
    max_failures = 0
    for node_id, agents in node_failures.items():
        for agent_id, count in agents.items():
            if count > max_failures:
                max_failures = count
                weakest_node = node_id
                weakest_agent = agent_id

    return {
        "is_workflow_run": has_workflow,
        "weakest_node": weakest_node,
        "weakest_agent": weakest_agent,
        "node_failure_counts": node_failures,
        "first_failing_nodes": first_failing_node,
        "path_counts": path_counts,
        "terminal_node_counts": terminal_counts,
        "route_counts": route_counts,
        "unmatched_routes": unmatched_routes,
        "provider_recovery_counts": provider_recovery_counts,
        "provider_recoveries": provider_recoveries,
        "loop_cases": loop_cases,
        "dead_end_cases": dead_end_cases,
        "duplicate_work_cases": duplicate_work_cases,
        "over_delegation_cases": over_delegation_cases,
        "fan_out_total": fan_out_total,
        "join_total": join_total,
        "shared_context_keys": sorted(shared_context_keys),
    }


def diagnose_experiment(
    project_root: Path,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    baseline_id: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    cluster_ids: list[str] | None = None,
    focus_limit: int = 5,
) -> dict[str, Any]:
    from agentworkbench.runner import (
        _baseline_ladder,
        _best_comparable_baseline,
        _diagnosis_suggestions,
        _failed_case_map,
        _latest_matching_record,
        _load_experiment,
        _load_run_rows,
        _recommended_stability_slice,
        _record_benchmark_signature,
        _record_surface_recommendations,
        _surface_gaps,
    )

    target_record: ExperimentRecord
    if experiment_id:
        target_record, aggregate = _load_experiment(project_root, experiment_id)
    else:
        from agentworkbench.runner import _latest_matching_record

        latest_record = _latest_matching_record(
            project_root,
            agent_id=agent_id,
            eval_id=eval_id,
            subset=subset,
            benchmark_signature=benchmark_signature,
        )
        if latest_record is None:
            raise ValueError("No experiments matched the requested filters for diagnosis.")
        target_record = latest_record
        aggregate = target_record.scores

    failed_case_map = _failed_case_map(project_root, target_record.experiment_id)
    target_rows = {row["case"]["id"]: row for row in _load_run_rows(project_root, target_record.experiment_id)}
    baseline_record = None
    if baseline_id:
        baseline_record, _ = _load_experiment(project_root, baseline_id)
    else:
        baseline_record = _best_comparable_baseline(project_root, target_record)
    comparison = (
        compare_experiments(project_root, baseline_record.experiment_id, target_record.experiment_id)
        if baseline_record
        else None
    )
    baseline_rows = (
        {row["case"]["id"]: row for row in _load_run_rows(project_root, baseline_record.experiment_id)}
        if baseline_record
        else {}
    )
    focus_selection = normalize_case_selection(case_ids=case_ids, tags=tags, match=match, limit=focus_limit)
    allowed_case_ids: set[str] | None = None
    if comparison and cluster_ids:
        allowed_case_ids = set()
        for cluster in comparison.failure_clusters:
            if str(cluster.get("cluster_id") or "") in set(cluster_ids):
                allowed_case_ids.update(str(item) for item in cluster.get("case_ids", []))
    focus_cases: list[dict[str, Any]] = []
    if comparison:
        regressed = [item for item in comparison.changed_cases if float(item.get("score_delta", 0.0)) < 0.0]
        if regressed:
            focus_source = regressed
        elif failed_case_map:
            changed_case_map = {str(item.get("case_id") or ""): item for item in comparison.changed_cases}
            focus_source = [
                changed_case_map.get(case_id, {"case_id": case_id, "score_delta": 0.0}) for case_id in failed_case_map
            ]
        else:
            focus_source = comparison.changed_cases[: max(5, focus_limit)]
        for item in focus_source:
            case_id = str(item["case_id"])
            if allowed_case_ids is not None and case_id not in allowed_case_ids:
                continue
            case_payload = (target_rows.get(case_id) or {}).get("case") or {"id": case_id, "tags": []}
            if not case_matches(case_payload, focus_selection):
                continue
            focus_cases.append(
                {
                    "case_id": case_id,
                    "score_delta": item.get("score_delta", 0.0),
                    "reason": failed_case_map.get(case_id)
                    or (
                        "regressed relative to baseline"
                        if float(item.get("score_delta", 0.0)) < 0.0
                        else "improved relative to baseline"
                        if float(item.get("score_delta", 0.0)) > 0.0
                        else "changed relative to baseline"
                    ),
                    "tools_added": item.get("tools_added", []),
                    "tools_removed": item.get("tools_removed", []),
                    "skills_added": item.get("skills_added", []),
                    "skills_removed": item.get("skills_removed", []),
                    "plugins_added": item.get("plugins_added", []),
                    "plugins_removed": item.get("plugins_removed", []),
                    "mcps_added": item.get("mcps_added", []),
                    "mcps_removed": item.get("mcps_removed", []),
                    "prompt_keys_added": item.get("prompt_keys_added", []),
                    "prompt_keys_removed": item.get("prompt_keys_removed", []),
                    "expected_behavior": item.get("expected_behavior")
                    or case_expectations((target_rows.get(case_id) or {}).get("case") or {}),
                    "baseline_evidence": item.get("baseline_evidence")
                    or (
                        artifact_evidence(
                            baseline_rows[case_id], baseline_record.spec_snapshot if baseline_record else None
                        )
                        if case_id in baseline_rows
                        else {}
                    ),
                    "candidate_evidence": item.get("candidate_evidence")
                    or (
                        artifact_evidence(target_rows[case_id], target_record.spec_snapshot)
                        if case_id in target_rows
                        else {}
                    ),
                }
            )
            if len(focus_cases) >= int(focus_limit):
                break
    else:
        for case_id, reason in failed_case_map.items():
            if not case_matches(
                (target_rows.get(case_id) or {}).get("case") or {"id": case_id, "tags": []}, focus_selection
            ):
                continue
            focus_cases.append(
                {
                    "case_id": case_id,
                    "score_delta": None,
                    "reason": reason,
                    "expected_behavior": case_expectations((target_rows.get(case_id) or {}).get("case") or {}),
                    "candidate_evidence": artifact_evidence(target_rows[case_id], target_record.spec_snapshot)
                    if case_id in target_rows
                    else {},
                }
            )
            if len(focus_cases) >= int(focus_limit):
                break
    improved_cases = []
    if comparison:
        improved_cases = [item for item in comparison.changed_cases if float(item.get("score_delta", 0.0)) > 0.0][:5]
    recommended_action = (
        comparison.recommended_action
        if comparison
        else ("promote" if target_record.promotion_status == "promoted" else "establish-baseline")
    )
    summary = (
        comparison.summary
        if comparison
        else (
            f"Standalone diagnosis for {target_record.experiment_id}; "
            f"average_score={float(aggregate.get('average_score', 0.0)):.3f}, "
            f"passed={aggregate.get('passed_cases', 0)}/{aggregate.get('total_cases', 0)}"
        )
    )
    surface_recommendations = _record_surface_recommendations(project_root, target_record)
    suggestions = _diagnosis_suggestions(target_record, failed_case_map, comparison, surface_recommendations)
    config = load_config(project_root)
    stability_slice = _recommended_stability_slice(
        target_record,
        target_rows,
        focus_cases,
        min_repeat=max(2, min(int(config.gates.min_stability_runs or 1), 3)),
    )
    suggested_commands = [
        f"awb status --eval-id {target_record.eval_id} --subset {target_record.subset} --benchmark-signature {_record_benchmark_signature(target_record)}",
    ]
    if comparison:
        suggested_commands.insert(
            0, f"awb compare --baseline {comparison.baseline_id} --candidate {comparison.candidate_id}"
        )
        if comparison.failure_clusters:
            cluster_id = str(comparison.failure_clusters[0].get("cluster_id") or "").strip()
            if cluster_id:
                suggested_commands.append(
                    f"awb run replay --baseline {comparison.baseline_id} --candidate {comparison.candidate_id} --cluster {cluster_id}"
                )
    if recommended_action == "promote":
        if baseline_record:
            suggested_commands.insert(
                0, f"awb promote --experiment {target_record.experiment_id} --baseline {baseline_record.experiment_id}"
            )
        else:
            suggested_commands.insert(0, f"awb promote --experiment {target_record.experiment_id}")
    if focus_cases:
        replay_command = f"awb run replay --experiment {target_record.experiment_id}"
        for item in focus_cases[:4]:
            replay_command += f" --case-id {str(item.get('case_id') or 'unknown')}"
        suggested_commands.append(replay_command)
    if stability_slice.get("command"):
        suggested_commands.append(str(stability_slice["command"]))

    chain_diag = _chain_diagnosis(list(target_rows.values()))
    workflow_diag = _workflow_diagnosis(list(target_rows.values()))
    try:
        from agentworkbench.loop_checks import build_loop_check_report

        loop_checks = build_loop_check_report(
            project_root,
            experiment_id=target_record.experiment_id,
            fail_on="critical",
            write=True,
        )
    except Exception as exc:
        loop_checks = {
            "passed": False,
            "summary": {},
            "findings": [],
            "hints": [],
            "error": str(exc),
        }
    for finding in loop_checks.get("findings") or []:
        category = str(finding.get("category") or "")
        if category not in {"code_structure", "agent_topology", "eval_contract", "deterministic_fallback"}:
            continue
        if str(finding.get("severity") or "") not in {"critical", "high", "medium"}:
            continue
        if float(finding.get("confidence") or 0.0) < 0.7:
            continue
        if any(item.get("category") == category for item in suggestions):
            continue
        suggestions.append(
            {
                "category": category,
                "rationale": str(finding.get("message") or finding.get("title") or ""),
                "action": str(finding.get("hint") or "Resolve the loop-readiness finding before continuing optimization."),
            }
        )

    human_checkpoints = experiment_human_checkpoints(focus_cases)
    human_review_queue = build_review_queue(
        queue_id=f"diagnose-{target_record.experiment_id}",
        stage="answer_acceptance",
        subject=target_record.experiment_id,
        checkpoints=human_checkpoints,
    )
    human_review_queue = resolve_review_queue(project_root, human_review_queue)
    payload = {
        "experiment_id": target_record.experiment_id,
        "agent_id": target_record.agent_id,
        "eval_id": target_record.eval_id,
        "subset": target_record.subset,
        "benchmark_signature": _record_benchmark_signature(target_record),
        "promotion_status": target_record.promotion_status,
        "baseline_id": baseline_record.experiment_id if baseline_record else None,
        "comparison_mode": comparison.comparison_mode if comparison else "standalone",
        "focus_filter": {
            **focus_selection,
            "clusters": cluster_ids or [],
        },
        "recommended_action": recommended_action,
        "summary": summary,
        "baseline_ladder": _baseline_ladder(project_root, target_record),
        "aggregate": aggregate,
        "chain_diagnosis": chain_diag,
        "workflow_diagnosis": workflow_diag,
        "surface_gaps": _surface_gaps(target_record),
        "surface_recommendations": surface_recommendations,
        "loop_checks": loop_checks,
        "focus_cases": focus_cases,
        "human_checkpoints": pending_review_items(human_review_queue),
        "human_review_queue": human_review_queue,
        "improved_cases": improved_cases,
        "gate_results": comparison.gate_results if comparison else {},
        "metric_deltas": comparison.metric_deltas if comparison else {},
        "behavior_deltas": comparison.behavior_deltas if comparison else {},
        "spec_changes": comparison.spec_changes if comparison else {},
        "surface_detail_changes": comparison.surface_detail_changes if comparison else {},
        "telemetry_summary": comparison.telemetry_summary if comparison else {},
        "benchmark_drift": comparison.benchmark_drift if comparison else {},
        "stability_summary": comparison.stability_summary if comparison else {},
        "pareto_summary": comparison.pareto_summary if comparison else {},
        "failure_clusters": comparison.failure_clusters
        if comparison
        else failure_clusters(None, focus_cases, failed_case_map),
        "repo_changes": comparison.repo_changes if comparison else [],
        "repo_change_summary": comparison.repo_change_summary if comparison else {},
        "baseline_runtime_changes": comparison.baseline_runtime_changes if comparison else [],
        "candidate_runtime_changes": comparison.candidate_runtime_changes
        if comparison
        else target_record.changed_files,
        "stability_slice": stability_slice,
        "suggested_mutations": suggestions,
        "suggested_commands": suggested_commands,
    }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / f"diagnose-{target_record.experiment_id}.json", payload)
    write_json(reports_dir / "diagnose-latest.json", payload)
    write_json(reports_dir / f"diagnose-review-queue-{target_record.experiment_id}.json", human_review_queue)
    write_json(reports_dir / "diagnose-review-queue-latest.json", human_review_queue)
    write_report(reports_dir / f"diagnose-{target_record.experiment_id}.md", render_diagnosis_report(payload))
    write_report(reports_dir / "diagnose-latest.md", render_diagnosis_report(payload))
    return payload


__all__ = ["diagnose_experiment"]
