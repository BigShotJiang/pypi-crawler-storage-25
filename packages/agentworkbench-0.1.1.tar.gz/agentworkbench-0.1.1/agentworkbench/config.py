"""Configuration utilities for Agent Workbench.

This module provides functions for finding the project root, loading configuration,
and managing experiment directories.
"""

from __future__ import annotations

from pathlib import Path
from typing import TypeVar

from pydantic import BaseModel

from agentworkbench.models import WorkbenchConfig
from agentworkbench.utils import ensure_dir, read_yaml, write_yaml

CONTROL_DIR_NAME = ".agent-workbench"

T = TypeVar("T", bound=BaseModel)


def find_project_root(start: Path | None = None) -> Path:
    """Find the project root by searching for .agent-workbench/workbench.yaml."""
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if (candidate / CONTROL_DIR_NAME / "workbench.yaml").exists():
            return candidate
    return current


def control_dir(project_root: Path) -> Path:
    """Get the control directory path for the project."""
    return project_root / CONTROL_DIR_NAME


def load_model(path: Path, model_type: type[T]) -> T:
    """Load a Pydantic model from a YAML file."""
    payload = read_yaml(path)
    return model_type.model_validate(payload)


def dump_model(path: Path, model: BaseModel) -> Path:
    """Dump a Pydantic model to a YAML file."""
    return write_yaml(path, model.model_dump(mode="json"))


def config_path(project_root: Path) -> Path:
    """Get the workbench.yaml config file path."""
    return control_dir(project_root) / "workbench.yaml"


def load_config(project_root: Path | None = None) -> WorkbenchConfig:
    """Load the workbench configuration."""
    root = find_project_root(project_root)
    path = config_path(root)
    if not path.exists():
        raise FileNotFoundError(f"Missing workbench config: {path}")
    return load_model(path, WorkbenchConfig)


def experiments_root(project_root: Path) -> Path:
    """Get the experiments directory (where experiment artifacts are stored)."""
    config = load_config(project_root)
    return ensure_dir(project_root / config.artifacts_dir)


def experiment_dir(project_root: Path, experiment_id: str) -> Path:
    """Get the directory for a specific experiment."""
    return ensure_dir(experiments_root(project_root) / experiment_id)
