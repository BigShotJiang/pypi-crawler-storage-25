from __future__ import annotations

from typing import Any


def render_scorer_audit_report(payload: dict[str, Any]) -> str:
    lines = [
        f"# Scorer Audit {payload.get('experiment_id') or 'unknown'}",
        "",
        f"- Agent: `{payload.get('agent_id') or 'unknown'}`",
        f"- Eval: `{payload.get('eval_id') or 'unknown'}`",
        f"- Subset: `{payload.get('subset') or 'unknown'}`",
        f"- Selected cases: {payload.get('selected_case_count', 0)}",
        f"- Selected metrics: {', '.join(payload.get('selected_metric_names') or []) or 'all'}",
        "",
        "## Overall",
        "",
    ]
    overall = payload.get("overall") or {}
    for key in [
        "total_scores",
        "heuristic_scores",
        "model_judged_scores",
        "unknown_scores",
        "heuristic_percentage",
        "model_judged_percentage",
    ]:
        if key in overall:
            lines.append(f"- `{key}`: {overall.get(key)}")
    lines.append(f"- confidence_note: {payload.get('confidence_note') or 'none'}")
    lines.extend(["", "## Issues", ""])
    issues = payload.get("issues") or []
    if issues:
        lines.extend(f"- {item}" for item in issues)
    else:
        lines.append("- none")
    lines.extend(["", "## Metrics", ""])
    metric_audits = payload.get("metric_audits") or {}
    if not metric_audits:
        lines.append("- none")
    for metric_name, audit in metric_audits.items():
        lines.append(
            f"- `{metric_name}`: total={audit.get('total_scores', 0)}, model_judged={audit.get('model_judged_scores', 0)}, "
            f"heuristic={audit.get('heuristic_scores', 0)}, unknown={audit.get('unknown_scores', 0)}, "
            f"judge_models={', '.join(audit.get('judge_models', [])) or 'none'}, "
            f"prompt_variants={audit.get('judge_prompt_variant_count', 0)}, needs_review={audit.get('needs_review', False)}"
        )
        lines.append(
            f"- fallback_paths={audit.get('fallback_paths') or {}}, "
            f"low_confidence_cases={', '.join(item.get('case_id') for item in audit.get('low_confidence_cases', [])) or 'none'}, "
            f"wide_ci_cases={', '.join(item.get('case_id') for item in audit.get('wide_confidence_interval_cases', [])) or 'none'}, "
            f"unknown_cases={', '.join(item.get('case_id') for item in audit.get('unknown_judgment_cases', [])) or 'none'}"
        )
    lines.extend(["", "## Suggested Commands", ""])
    commands = payload.get("suggested_commands") or []
    if commands:
        lines.extend(f"- `{item}`" for item in commands)
    else:
        lines.append("- none")
    return "\n".join(lines)
