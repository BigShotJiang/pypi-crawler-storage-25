from __future__ import annotations

import json
from typing import Any

from agentworkbench.report_builder import ReportBuilder


def render_diagnosis_report(payload: dict[str, Any]) -> str:
    aggregate = payload.get("aggregate") or {}
    baseline_ladder = payload.get("baseline_ladder") or {}
    report = ReportBuilder(f"Diagnosis {payload['experiment_id']}")
    report.bullet(f"Agent: `{payload.get('agent_id') or 'unknown'}`")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`")
    report.bullet(f"Promotion status: `{payload.get('promotion_status') or 'candidate'}`")
    report.bullet(f"Baseline: `{payload.get('baseline_id') or 'none'}`")
    report.bullet(f"Comparison mode: `{payload.get('comparison_mode') or 'standalone'}`")
    report.bullet(f"Recommended action: `{payload.get('recommended_action') or 'review'}`")
    report.bullet(f"Summary: {payload.get('summary') or 'none'}")

    report.section("Baseline Ladder")
    if baseline_ladder:
        for key, value in baseline_ladder.items():
            if not value:
                report.bullet(f"`{key}`: none")
                continue
            report.bullet(
                f"`{key}`: `{value.get('experiment_id', 'unknown')}`, "
                f"score={float(value.get('average_score', 0.0)):.3f}, "
                f"passed={value.get('passed_cases', 0)}/{value.get('total_cases', 0)}, "
                f"model=`{value.get('model_name', 'unknown')}`"
            )
    else:
        report.bullet("none")

    report.section("Aggregate")
    report.bullet(f"Average score: {float(aggregate.get('average_score', 0.0)):.3f}")
    report.bullet(f"Passed: {aggregate.get('passed_cases', 0)}/{aggregate.get('total_cases', 0)}")

    metric_deltas = payload.get("metric_deltas") or {}
    report.section("Metric Deltas")
    if metric_deltas:
        for key, value in metric_deltas.items():
            report.bullet(f"`{key}`: {float(value):+.3f}")
    else:
        report.bullet("none")

    spec_changes = payload.get("spec_changes") or {}
    report.section("Spec Changes")
    if spec_changes:
        report.kv_map(spec_changes, skip_keys={"prompt_content_drift"})
    else:
        report.bullet("none")

    prompt_drift = spec_changes.get("prompt_content_drift", []) if spec_changes else []
    if prompt_drift:
        report.section("Prompt Drift")
        for item in prompt_drift:
            report.bullet(
                f"`{item.get('key', 'prompt')}`: source_changed={item.get('source_changed', False)}, "
                f"content_changed={item.get('content_changed', False)}, "
                f"baseline=`{item.get('baseline_source') or 'inline'}` ({item.get('baseline_content_hash') or 'none'}), "
                f"candidate=`{item.get('candidate_source') or 'inline'}` ({item.get('candidate_content_hash') or 'none'})"
            )
            report.bullet(
                f"baseline_preview={item.get('baseline_preview') or 'none'} | "
                f"candidate_preview={item.get('candidate_preview') or 'none'}"
            )

    behavior_deltas = payload.get("behavior_deltas") or {}
    report.section("Behavior Deltas")
    if behavior_deltas:
        report.kv_map(behavior_deltas)
    else:
        report.bullet("none")

    surface_gaps = payload.get("surface_gaps") or {}
    report.section("Surface Gaps")
    if surface_gaps:
        report.kv_map(surface_gaps)
    else:
        report.bullet("none")

    surface_recommendations = payload.get("surface_recommendations") or []
    report.section("Surface Recommendations")
    if surface_recommendations:
        for item in surface_recommendations:
            report.bullet(
                f"{item.get('surface') or 'surface'}: "
                f"{item.get('recommendation') or 'review'} "
                f"(priority={item.get('priority', 'n/a')})"
            )
    else:
        report.bullet("none")

    loop_checks = payload.get("loop_checks") or {}
    report.section("Loop Readiness")
    if loop_checks:
        report.bullet(f"passed={loop_checks.get('passed')}, readiness_score={loop_checks.get('readiness_score', 'n/a')}")
        summary = loop_checks.get("summary") or {}
        report.bullet(
            "findings="
            + ", ".join(f"{key}:{summary.get(key, 0)}" for key in ["critical", "high", "medium", "warning", "info"])
        )
        for item in (loop_checks.get("findings") or [])[:5]:
            report.bullet(
                f"`{item.get('severity', 'info')}` `{item.get('category', 'loop')}`: "
                f"{item.get('title', 'finding')} - {item.get('hint', 'review')}"
            )
    else:
        report.bullet("none")

    report.section("Suggested Mutations")
    suggested_mutations = payload.get("suggested_mutations") or []
    if suggested_mutations:
        for item in suggested_mutations:
            report.bullet(
                f"{item.get('category') or 'mutation'}: {item.get('action') or item.get('rationale') or 'review'}"
            )
    else:
        report.bullet("none")

    report.section("Suggested Commands")
    suggested_commands = payload.get("suggested_commands") or []
    if suggested_commands:
        for command in suggested_commands:
            report.bullet(str(command))
    else:
        report.bullet("none")

    report.section("Benchmark Drift")
    benchmark_drift = payload.get("benchmark_drift") or {}
    if benchmark_drift:
        report.kv_map(benchmark_drift)
    else:
        report.bullet("none")

    report.section("Telemetry")
    telemetry = payload.get("telemetry_summary") or {}
    if telemetry:
        report.kv_map(telemetry)
    else:
        report.bullet("none")

    def _render_diagnosis_section(title: str, data: dict[str, Any]) -> None:
        report.section(title)
        if not data:
            report.bullet("none")
            return
        for key, value in data.items():
            if isinstance(value, list):
                if not value:
                    report.bullet(f"`{key}`: none")
                elif all(isinstance(item, str) for item in value):
                    report.bullet(f"`{key}`: {', '.join(value)}")
                else:
                    report.bullet(f"`{key}`: {len(value)} item(s)")
            elif isinstance(value, dict):
                if not value:
                    report.bullet(f"`{key}`: none")
                else:
                    report.bullet(f"`{key}`: {json.dumps(value, sort_keys=True)}")
            else:
                report.bullet(f"`{key}`: {value}")

    _render_diagnosis_section("Chain Diagnosis", payload.get("chain_diagnosis") or {})
    _render_diagnosis_section("Workflow Diagnosis", payload.get("workflow_diagnosis") or {})

    report.section("Stability")
    stability = payload.get("stability_summary") or {}
    if stability:
        report.kv_map(stability)
    else:
        report.bullet("none")

    report.repo_change_summary(payload.get("repo_change_summary") or {})
    report.human_checkpoints(payload.get("human_checkpoints") or [], heading="Ask The Human")
    report.review_queue(payload.get("review_queue") or {})
    return report.text()
