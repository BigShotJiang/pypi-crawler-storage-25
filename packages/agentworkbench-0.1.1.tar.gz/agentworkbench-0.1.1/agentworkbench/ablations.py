from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.models import AgentSpec, ExperimentRecord
from agentworkbench.optimization_utils import short_variant_label, surface_targets, write_temp_agent_spec
from agentworkbench.reports import render_ablation_report, write_report
from agentworkbench.runner import compare_experiments, load_agent_spec, run_experiment
from agentworkbench.tool_interfaces import (
    alternate_provider_tool_format,
    find_tool,
    loose_tool_schema,
    set_provider_tool_format,
    set_tool_description,
    set_tool_schema,
    tool_schema,
)
from agentworkbench.utils import ensure_dir, write_json


def ablations_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "ablations")


def _ablated_spec(spec: AgentSpec, surface_kind: str, surface_name: str) -> AgentSpec:
    clone = spec.model_copy(deep=True)
    clone.id = f"{spec.id}-ablate-{short_variant_label(surface_kind, surface_name)}"
    clone.metadata = {
        **(clone.metadata or {}),
        "ablation": {
            "source_agent_id": spec.id,
            "surface_kind": surface_kind,
            "surface_name": surface_name,
        },
    }
    if surface_kind == "prompts":
        clone.prompts.pop(surface_name, None)
    elif surface_kind in {"tools", "skills", "plugins", "mcps"}:
        items = getattr(clone, surface_kind)
        for item in items:
            name = item.get("name") or item.get("id")
            if str(name) == surface_name:
                item["enabled"] = False
    elif surface_kind == "tool_docstrings":
        tool = find_tool(clone, surface_name)
        if tool is not None:
            set_tool_description(tool, "")
    elif surface_kind == "tool_schemas":
        tool = find_tool(clone, surface_name)
        if tool is not None:
            current_schema = tool_schema(tool)
            if current_schema:
                set_tool_schema(tool, loose_tool_schema(current_schema))
    elif surface_kind == "tool_formats":
        set_provider_tool_format(clone, alternate_provider_tool_format(surface_name))
    return clone


def _effect_label(comparison: dict[str, Any]) -> tuple[str, float]:
    score_delta = float((comparison.get("metric_deltas") or {}).get("average_score", 0.0))
    passed_case_delta = float((comparison.get("metric_deltas") or {}).get("passed_cases", 0.0))
    behavior_deltas = comparison.get("behavior_deltas") or {}
    efficiency_gain = (
        max(0.0, -float(behavior_deltas.get("avg_step_count_delta", 0.0)))
        + max(0.0, -float(behavior_deltas.get("avg_latency_ms_delta", 0.0)) / 1000.0)
        + max(0.0, -float(behavior_deltas.get("avg_cost_estimate_delta", 0.0)) * 100.0)
    )
    if score_delta > 0.0 or passed_case_delta > 0.0:
        return "harmful_surface", round(40.0 + score_delta * 10.0 + passed_case_delta * 2.0 + efficiency_gain, 3)
    if abs(score_delta) < 1e-9 and abs(passed_case_delta) < 1e-9 and efficiency_gain > 0.0:
        return "prune_candidate", round(30.0 + efficiency_gain, 3)
    if abs(score_delta) < 1e-9 and abs(passed_case_delta) < 1e-9:
        return "neutral_surface", 20.0
    return "valuable_surface", round(10.0 + score_delta * 10.0 + passed_case_delta * 2.0, 3)


def _surface_audit_delta(comparison: dict[str, Any], surface_kind: str, surface_name: str) -> dict[str, Any]:
    behavior_deltas = comparison.get("behavior_deltas") or {}
    if surface_kind == "tools":
        return (behavior_deltas.get("tool_audit_deltas") or {}).get(surface_name) or {}
    if surface_kind == "mcps":
        return (behavior_deltas.get("mcp_audit_deltas") or {}).get(surface_name) or {}
    return {}


def _optimization_signal(comparison: dict[str, Any], surface_kind: str, surface_name: str) -> tuple[str, dict[str, Any]]:
    audit_delta = _surface_audit_delta(comparison, surface_kind, surface_name)
    behavior_deltas = comparison.get("behavior_deltas") or {}
    score_delta = float((comparison.get("metric_deltas") or {}).get("average_score", 0.0))
    cost_delta = float(behavior_deltas.get("avg_cost_estimate_delta", 0.0))
    evidence_use_delta = float(audit_delta.get("selected_evidence_use_rate_delta", behavior_deltas.get("selected_evidence_use_rate_delta", 0.0)) or 0.0)
    supported_delta = int(audit_delta.get("supported_evidence_delta", 0) or 0)
    selected_delta = int(audit_delta.get("selected_evidence_delta", 0) or 0)
    unsupported_delta = int(audit_delta.get("cases_with_unsupported_selected_evidence_delta", 0) or 0)
    if surface_kind in {"tools", "mcps"}:
        if score_delta >= 0.0 and evidence_use_delta >= 0.0 and cost_delta <= 0.0:
            return "noise_or_overhead", audit_delta
        if score_delta < 0.0 or evidence_use_delta < 0.0 or supported_delta < 0 or selected_delta < 0:
            return "grounding_support", audit_delta
        if unsupported_delta < 0:
            return "retrieval_cleanup", audit_delta
    return "neutral", audit_delta


def run_surface_ablations(
    project_root: Path,
    *,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    case_limit: int | None = None,
    surfaces: list[str] | None = None,
    surface_limit: int | None = None,
    keep_specs: bool = False,
) -> dict[str, Any]:
    source_record: ExperimentRecord
    if experiment_id:
        from agentworkbench.runner import _load_experiment  # local import to avoid cycles at module import time

        source_record, _aggregate = _load_experiment(project_root, experiment_id)
        agent_id = source_record.agent_id
        eval_id = source_record.eval_id
        subset = source_record.subset
        if not case_ids:
            case_ids = list(source_record.selected_case_ids or [])
    else:
        if not agent_id or not eval_id:
            raise ValueError("Provide either --experiment or both --agent-id and --eval-id for ablations.")
        source_record, _aggregate = run_experiment(
            project_root,
            agent_id,
            eval_id,
            subset or "smoke",
            case_ids=case_ids,
            tags=tags,
            match=match,
            limit=case_limit,
        )
        experiment_id = source_record.experiment_id
    assert agent_id is not None
    assert eval_id is not None
    assert subset is not None
    base_spec = load_agent_spec(project_root, agent_id)
    targets = surface_targets(base_spec, surfaces or [])
    if surface_limit is not None and surface_limit > 0:
        targets = targets[:surface_limit]
    if not targets:
        raise ValueError(
            "No enabled prompts, tools, skills, plugins, MCPs, or tool-interface surfaces were available to ablate."
        )
    results: list[dict[str, Any]] = []
    temp_paths: list[Path] = []
    try:
        for surface_kind, surface_name in targets:
            ablated = _ablated_spec(base_spec, surface_kind, surface_name)
            temp_path = write_temp_agent_spec(project_root, ablated)
            temp_paths.append(temp_path)
            ablation_record, _aggregate = run_experiment(
                project_root,
                ablated.id,
                eval_id,
                subset,
                case_ids=case_ids,
                tags=tags,
                match=match,
                limit=case_limit,
            )
            comparison = compare_experiments(project_root, experiment_id, ablation_record.experiment_id).model_dump(mode="json")
            effect, marginal_value_score = _effect_label(comparison)
            optimization_signal, audit_delta = _optimization_signal(comparison, surface_kind, surface_name)
            results.append(
                {
                    "surface_kind": surface_kind,
                    "surface_name": surface_name,
                    "ablation_agent_id": ablated.id,
                    "experiment_id": ablation_record.experiment_id,
                    "effect": effect,
                    "marginal_value_score": marginal_value_score,
                    "average_score_delta": float((comparison.get("metric_deltas") or {}).get("average_score", 0.0)),
                    "passed_case_delta": float((comparison.get("metric_deltas") or {}).get("passed_cases", 0.0)),
                    "avg_step_count_delta": float((comparison.get("behavior_deltas") or {}).get("avg_step_count_delta", 0.0)),
                    "avg_latency_ms_delta": float((comparison.get("behavior_deltas") or {}).get("avg_latency_ms_delta", 0.0)),
                    "avg_cost_estimate_delta": float((comparison.get("behavior_deltas") or {}).get("avg_cost_estimate_delta", 0.0)),
                    "selected_evidence_use_rate_delta": float((comparison.get("behavior_deltas") or {}).get("selected_evidence_use_rate_delta", 0.0)),
                    "optimization_signal": optimization_signal,
                    "surface_audit_delta": audit_delta,
                    "trace_events_added": (comparison.get("behavior_deltas") or {}).get("trace_events_added", []),
                    "trace_events_removed": (comparison.get("behavior_deltas") or {}).get("trace_events_removed", []),
                    "pareto_summary": comparison.get("pareto_summary") or {},
                    "recommended_action": comparison.get("recommended_action") or "review",
                }
            )
    finally:
        if not keep_specs:
            for path in temp_paths:
                if path.exists():
                    path.unlink()
    ordered = sorted(results, key=lambda item: (-float(item.get("marginal_value_score", 0.0)), str(item.get("surface_kind")), str(item.get("surface_name"))))
    payload = {
        "source_experiment_id": experiment_id,
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "case_ids": case_ids or [],
        "tags": tags or [],
        "match": match or "",
        "case_limit": case_limit,
        "surface_filters": surfaces or ["prompts", "tools", "skills", "plugins", "mcps"],
        "ablation_count": len(ordered),
        "results": ordered,
        "temporary_spec_paths": [str(path.relative_to(project_root)) for path in temp_paths if path.exists()],
    }
    root = ablations_dir(project_root)
    write_json(root / f"ablate-{experiment_id}.json", payload)
    write_json(root / "latest.json", payload)
    write_report(root / f"ablate-{experiment_id}.md", render_ablation_report(payload))
    write_report(root / "latest.md", render_ablation_report(payload))
    return payload
