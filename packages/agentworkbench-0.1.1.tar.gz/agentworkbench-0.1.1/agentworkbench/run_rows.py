from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.adapters import get_adapter
from agentworkbench.evals import ScoringContext, score_run
from agentworkbench.models import AgentSpec, EvalCase
from agentworkbench.telemetry import enrich_run_artifact_payload
from agentworkbench.utils import ensure_dir


def weighted_score(scores: list[dict[str, Any]]) -> float:
    total = 0.0
    weight_sum = 0.0
    for score in scores:
        weight = float(score.get("weight", 1.0))
        total += float(score.get("value", 0.0)) * weight
        weight_sum += weight
    if weight_sum <= 0.0:
        return 0.0
    return total / weight_sum


def execution_failure_score(errors: list[str]) -> dict[str, Any]:
    return {
        "name": "execution_status",
        "value": 0.0,
        "weight": 0.0,
        "passed": False,
        "reason": "; ".join(errors[:3]) if errors else "Execution failed before scoring",
    }


def build_scored_run_row(
    project_root: Path,
    spec: AgentSpec,
    spec_snapshot: dict[str, Any],
    eval_id: str,
    case: EvalCase,
    case_dir: Path,
    *,
    scoring_context: ScoringContext | None = None,
) -> tuple[str, dict[str, Any]]:
    adapter = get_adapter(spec.adapter)
    artifact = adapter.invoke(project_root, spec, case, ensure_dir(case_dir))
    artifact = artifact.__class__.model_validate(
        enrich_run_artifact_payload(artifact.model_dump(mode="json"), spec_snapshot=spec_snapshot)
    )
    scores = score_run(project_root, eval_id, artifact, case, scoring_context=scoring_context)
    if artifact.errors:
        scores = [*scores, execution_failure_score(artifact.errors)]
    passed = not artifact.errors and all(bool(score.get("passed", False)) for score in scores)
    row = {
        "case": case.model_dump(mode="json"),
        "artifact": artifact.model_dump(mode="json"),
        "scores": scores,
        "passed": passed,
        "score": 0.0 if artifact.errors else weighted_score(scores),
    }
    return case.id, row
