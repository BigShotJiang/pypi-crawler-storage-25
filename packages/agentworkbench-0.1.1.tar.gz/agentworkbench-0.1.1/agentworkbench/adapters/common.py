from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any

from agentworkbench.adapters.shared import config_env
from agentworkbench.models import AgentSpec

Estimator = Callable[[Any, dict[str, Any], dict[str, Any], dict[str, Any]], dict[str, Any] | None]


def build_env(project_root, spec: AgentSpec) -> dict[str, str]:
    env = os.environ.copy()
    for key, value in config_env(project_root).items():
        env.setdefault(str(key), str(value))
    for key, value in (spec.runtime.get("env") or {}).items():
        env[str(key)] = str(value)
    return env


def required_env_names(spec: AgentSpec, extra: list[str] | None = None) -> list[str]:
    names = {str(item) for item in spec.required_env if str(item).strip()}
    for item in extra or []:
        if str(item).strip():
            names.add(str(item))
    return sorted(names)


def missing_env(env: dict[str, str], required: list[str]) -> list[str]:
    return [name for name in required if name and not str(env.get(name, "")).strip()]


def apply_cost_estimate(
    project_root,
    spec: AgentSpec,
    token_usage: dict[str, Any],
    metadata: dict[str, Any],
    cost_estimate: float,
    *,
    estimator: Estimator,
) -> float:
    if cost_estimate > 0.0:
        return cost_estimate
    estimated = estimator(project_root, spec.model, token_usage, metadata)
    if estimated is not None:
        metadata["pricing"] = estimated
        return float(estimated["cost_usd"])
    return cost_estimate
