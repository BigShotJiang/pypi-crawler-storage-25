from __future__ import annotations

from collections.abc import Callable
from importlib.metadata import entry_points
from typing import Any

from agentworkbench.adapters.command import CommandAdapter, summarize_command_entrypoint
from agentworkbench.adapters.provider import ProviderAdapter, summarize_provider_entrypoint
from agentworkbench.adapters.python import PythonAdapter, summarize_python_entrypoint
from agentworkbench.models import AgentSpec

AdapterFactory = Callable[[], Any]

_ADAPTER_FACTORIES: dict[str, tuple[AdapterFactory, str]] = {
    "command": (CommandAdapter, "builtin"),
    "python": (PythonAdapter, "builtin"),
    "provider": (ProviderAdapter, "builtin"),
}


def register_adapter(name: str, factory: AdapterFactory, *, source: str = "registered") -> None:
    adapter_name = str(name or "").strip()
    if not adapter_name:
        raise ValueError("Adapter name cannot be empty")
    _ADAPTER_FACTORIES[adapter_name] = (factory, source)


def _load_entrypoint_adapters() -> None:
    for item in entry_points(group="agentworkbench.adapters"):
        if item.name in _ADAPTER_FACTORIES:
            continue
        register_adapter(item.name, item.load(), source=f"entrypoint:{item.value}")


def available_adapters() -> list[dict[str, str]]:
    _load_entrypoint_adapters()
    payload: list[dict[str, str]] = []
    for name in sorted(_ADAPTER_FACTORIES):
        _factory, source = _ADAPTER_FACTORIES[name]
        payload.append({"name": name, "source": source})
    return payload


def get_adapter(name: str) -> Any:
    _load_entrypoint_adapters()
    adapter_name = str(name or "command")
    factory_entry = _ADAPTER_FACTORIES.get(adapter_name)
    if factory_entry is None:
        supported = ", ".join(f"`{item['name']}`" for item in available_adapters())
        raise ValueError(f"Unsupported adapter `{name}`. Supported adapters: {supported}.")
    factory, _source = factory_entry
    return factory()


def summarize_entrypoint(spec: AgentSpec) -> tuple[str, str]:
    if str(spec.adapter or "command") == "provider":
        return summarize_provider_entrypoint(spec)
    if str(spec.adapter or "command") == "python":
        return summarize_python_entrypoint(spec)
    return summarize_command_entrypoint(spec)
