from __future__ import annotations

import json
import shlex
import subprocess
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from agentworkbench.adapters.common import apply_cost_estimate, build_env, missing_env, required_env_names
from agentworkbench.adapters.shared import normalized_surface_paths, raw_runtime_events
from agentworkbench.evidence import normalize_evidence_records
from agentworkbench.models import AgentSpec, CommandEntrypoint, EvalCase, RunArtifact
from agentworkbench.pricing import estimate_token_cost
from agentworkbench.tracing import TRACE_SCHEMA_VERSION, TRACE_TAXONOMY, normalize_trace_events
from agentworkbench.utils import ensure_dir, write_json


def resolve_command_entrypoint(spec: AgentSpec) -> tuple[str | list[str], bool, str, int]:
    command = spec.entrypoints.get("command")
    if not command:
        raise ValueError(f"Agent `{spec.id}` is missing entrypoints.command for command adapter")
    if isinstance(command, str):
        return command, True, ".", 300
    if isinstance(command, list):
        return [str(item) for item in command], False, ".", 300
    if isinstance(command, Mapping):
        config = CommandEntrypoint.model_validate(dict(command))
        has_argv = bool(config.argv)
        has_shell = bool(config.shell)
        if has_argv == has_shell:
            raise ValueError(f"Agent `{spec.id}` entrypoints.command must define exactly one of `argv` or `shell`")
        if config.argv:
            return [str(item) for item in config.argv], False, str(config.cwd or "."), int(config.timeout_seconds)
        return str(config.shell or ""), True, str(config.cwd or "."), int(config.timeout_seconds)
    raise ValueError(f"Agent `{spec.id}` has unsupported entrypoints.command type `{type(command).__name__}`")


def summarize_command_entrypoint(spec: AgentSpec) -> tuple[str, str]:
    try:
        args, _shell, cwd, _timeout_seconds = resolve_command_entrypoint(spec)
    except ValueError:
        return "unknown", "."
    command_text = args if isinstance(args, str) else " ".join(str(item) for item in args)
    return command_text, cwd


def _command_event(
    *,
    command_text: str,
    cwd: str,
    stdout: str,
    stderr: str,
    returncode: int | None,
    output_path: Path | None,
    timeout_seconds: int | None,
) -> dict[str, Any]:
    return {
        "kind": "command",
        "name": "invoke",
        "label": "command:invoke",
        "command": command_text,
        "cwd": cwd,
        "stdout": stdout,
        "stderr": stderr,
        "returncode": returncode,
        "output_path": str(output_path) if output_path else None,
        "timeout_seconds": timeout_seconds,
    }


class CommandAdapter:
    def _error_artifact(
        self,
        spec: AgentSpec,
        case: EvalCase,
        *,
        command_text: str,
        cwd: str,
        latency_ms: int,
        errors: list[str],
        stdout: str = "",
        stderr: str = "",
        returncode: int | None = None,
        output_path: Path | None = None,
        timeout_seconds: int | None = None,
    ) -> RunArtifact:
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            final_output="",
            structured_output={},
            events=[
                _command_event(
                    command_text=command_text,
                    cwd=cwd,
                    stdout=stdout,
                    stderr=stderr,
                    returncode=returncode,
                    output_path=output_path,
                    timeout_seconds=timeout_seconds,
                )
            ],
            evidence_records=[],
            trace_events=[],
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            workflow_trace=[],
            tool_calls=[],
            skills_used=[],
            plugins_used=[],
            mcp_servers_used=[],
            prompt_keys_used=[],
            step_count=0,
            latency_ms=latency_ms,
            token_usage={},
            cost_estimate=0.0,
            errors=errors,
            metadata={},
        )

    def _load_structured_output(self, output_path: Path) -> tuple[dict[str, Any], list[str]]:
        structured_output: dict[str, Any] = {}
        errors: list[str] = []
        if output_path.exists():
            try:
                payload = json.loads(output_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                errors.append(f"AWB output file was not valid JSON: {exc}")
            else:
                if isinstance(payload, dict):
                    structured_output = payload
                else:
                    errors.append("AWB output file must contain a JSON object")
        else:
            errors.append("Command did not write AWB_OUTPUT_PATH")
        return structured_output, errors

    def invoke(self, project_root: Path, spec: AgentSpec, case: EvalCase, run_dir: Path) -> RunArtifact:
        ensure_dir(run_dir)
        case_path = run_dir / "case.json"
        output_path = run_dir / "output.json"
        context_path = run_dir / "context.json"
        write_json(case_path, case.model_dump(mode="json"))
        try:
            args, shell, cwd_value, timeout_seconds = resolve_command_entrypoint(spec)
        except ValueError as exc:
            return self._error_artifact(
                spec,
                case,
                command_text="invalid-command-entrypoint",
                cwd=str(project_root),
                latency_ms=0,
                errors=[str(exc)],
                output_path=output_path,
            )
        command_cwd = (
            (project_root / cwd_value).resolve() if not Path(cwd_value).is_absolute() else Path(cwd_value).resolve()
        )
        command_text = args if isinstance(args, str) else " ".join(shlex.quote(item) for item in args)
        if not command_cwd.exists() or not command_cwd.is_dir():
            return self._error_artifact(
                spec,
                case,
                command_text=command_text,
                cwd=str(command_cwd),
                latency_ms=0,
                errors=[f"Command working directory does not exist: {command_cwd}"],
                output_path=output_path,
                timeout_seconds=timeout_seconds,
            )
        enabled_tools = [tool for tool in spec.tools if isinstance(tool, dict) and tool.get("enabled", True)]
        enabled_skills = [skill for skill in spec.skills if isinstance(skill, dict) and skill.get("enabled", True)]
        enabled_plugins = [
            plugin for plugin in spec.plugins if isinstance(plugin, dict) and plugin.get("enabled", True)
        ]
        enabled_mcps = [mcp for mcp in spec.mcps if isinstance(mcp, dict) and mcp.get("enabled", True)]
        surface_paths = normalized_surface_paths(spec)
        context = {
            "agent": {
                "id": spec.id,
                "instructions": spec.instructions,
                "prompts": spec.prompts,
                "model": spec.model,
                "tools": enabled_tools,
                "skills": enabled_skills,
                "plugins": enabled_plugins,
                "mcps": enabled_mcps,
                "owned_paths": [str(path) for path in spec.owned_paths],
                "owned_globs": [str(path) for path in spec.owned_globs],
                "surface_paths": surface_paths,
                "required_env": [str(key) for key in spec.required_env],
                "runtime": spec.runtime,
                "metadata": spec.metadata,
            },
            "case": case.model_dump(mode="json"),
            "paths": {
                "project_root": str(project_root),
                "run_dir": str(run_dir),
                "case_path": str(case_path),
                "output_path": str(output_path),
                "command_cwd": str(command_cwd),
            },
        }
        write_json(context_path, context)
        env = build_env(project_root, spec)
        env["AWB_PROJECT_ROOT"] = str(project_root)
        env["AWB_AGENT_ID"] = spec.id
        env["AWB_CASE_PATH"] = str(case_path)
        env["AWB_OUTPUT_PATH"] = str(output_path)
        env["AWB_CONTEXT_PATH"] = str(context_path)
        env["AWB_INPUT"] = case.input
        env["AWB_TURNS_JSON"] = json.dumps(case.turns or [])
        env["AWB_CHAIN_CONTEXT_JSON"] = json.dumps(case.metadata.get("chain_context") or {})
        env["AWB_PROMPTS_JSON"] = json.dumps(spec.prompts)
        env["AWB_TOOLS_JSON"] = json.dumps(enabled_tools)
        env["AWB_SKILLS_JSON"] = json.dumps(enabled_skills)
        env["AWB_PLUGINS_JSON"] = json.dumps(enabled_plugins)
        env["AWB_MCPS_JSON"] = json.dumps(enabled_mcps)
        env["AWB_OWNED_PATHS_JSON"] = json.dumps(spec.owned_paths)
        env["AWB_OWNED_GLOBS_JSON"] = json.dumps(spec.owned_globs)
        env["AWB_SURFACE_PATHS_JSON"] = json.dumps(surface_paths)
        env["AWB_REQUIRED_ENV_JSON"] = json.dumps(spec.required_env)
        missing = missing_env(env, required_env_names(spec))
        if missing:
            return self._error_artifact(
                spec,
                case,
                command_text=command_text,
                cwd=str(command_cwd),
                latency_ms=0,
                errors=[f"Missing required environment variables: {', '.join(sorted(missing))}"],
                output_path=output_path,
                timeout_seconds=timeout_seconds,
            )
        started = time.time()
        completed_stdout = ""
        completed_stderr = ""
        returncode: int | None = None
        timed_out = False
        try:
            completed = subprocess.run(
                args,
                capture_output=True,
                text=True,
                cwd=command_cwd,
                env=env,
                shell=shell,
                timeout=timeout_seconds,
            )
        except OSError as exc:
            latency_ms = int((time.time() - started) * 1000)
            return self._error_artifact(
                spec,
                case,
                command_text=command_text,
                cwd=str(command_cwd),
                latency_ms=latency_ms,
                errors=[f"Failed to execute command: {exc}"],
                stderr=str(exc),
                output_path=output_path,
                timeout_seconds=timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            timed_out = True
            completed_stdout = str(exc.stdout or "")
            completed_stderr = str(exc.stderr or "")
        else:
            completed_stdout = completed.stdout
            completed_stderr = completed.stderr
            returncode = completed.returncode
        latency_ms = int((time.time() - started) * 1000)
        structured_output, errors = self._load_structured_output(output_path)
        workflow_trace = [str(item) for item in structured_output.get("workflow_trace") or []]
        tool_calls = structured_output.get("tool_calls") or []
        skills_used = [str(item) for item in structured_output.get("skills_used") or []]
        plugins_used = [str(item) for item in structured_output.get("plugins_used") or []]
        mcp_servers_used = [str(item) for item in structured_output.get("mcp_servers_used") or []]
        prompt_keys_used = [str(item) for item in structured_output.get("prompt_keys_used") or []]
        step_count = int(structured_output.get("step_count") or 0)
        final_output = str(
            structured_output.get("final_output") or structured_output.get("output") or completed_stdout.strip()
        )
        if timed_out:
            errors.append(f"Command timed out after {timeout_seconds} seconds")
        elif returncode != 0:
            errors.append(f"Command exited with {returncode}")
        if completed_stderr.strip():
            errors.append(completed_stderr.strip())
        raw_events = raw_runtime_events(structured_output)
        evidence_records = normalize_evidence_records(structured_output, final_output=final_output)
        trace_events = normalize_trace_events(structured_output)
        token_usage = {str(key): int(value) for key, value in (structured_output.get("token_usage") or {}).items()}
        metadata = dict(structured_output.get("metadata") or {})
        cost_estimate = float(structured_output.get("cost_estimate") or 0.0)
        cost_estimate = apply_cost_estimate(
            project_root,
            spec,
            token_usage,
            metadata,
            cost_estimate,
            estimator=estimate_token_cost,
        )
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            final_output=final_output,
            structured_output=structured_output,
            events=[
                *raw_events,
                _command_event(
                    command_text=command_text,
                    cwd=str(command_cwd),
                    stdout=completed_stdout,
                    stderr=completed_stderr,
                    returncode=returncode,
                    output_path=output_path,
                    timeout_seconds=timeout_seconds,
                ),
            ],
            evidence_records=evidence_records,
            trace_events=trace_events,
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            workflow_trace=workflow_trace,
            tool_calls=tool_calls,
            skills_used=skills_used,
            plugins_used=plugins_used,
            mcp_servers_used=mcp_servers_used,
            prompt_keys_used=prompt_keys_used,
            step_count=step_count or len(tool_calls),
            latency_ms=latency_ms,
            token_usage=token_usage,
            cost_estimate=cost_estimate,
            errors=errors,
            metadata=metadata,
        )
