from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import load_config
from agentworkbench.models import AgentSpec
from agentworkbench.utils import read_env_file


def raw_runtime_events(structured_output: dict[str, Any]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for item in structured_output.get("events") or []:
        if isinstance(item, dict):
            events.append(dict(item))
        elif isinstance(item, str):
            events.append({"kind": "event", "label": item})
    return events


def normalized_surface_paths(spec: AgentSpec) -> dict[str, list[str]]:
    return {str(key): [str(path) for path in value or []] for key, value in spec.surface_paths.items() if value}


def config_env(project_root: Path) -> dict[str, str]:
    config = load_config(project_root)
    values: dict[str, str] = {}
    for env_path in config.env_files:
        candidate = Path(env_path)
        if not candidate.is_absolute():
            candidate = project_root / candidate
        values.update(read_env_file(candidate))
    return values
