from __future__ import annotations

import importlib
import inspect
import json
import os
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

from agentworkbench.adapters.common import apply_cost_estimate, build_env, missing_env, required_env_names
from agentworkbench.adapters.shared import normalized_surface_paths, raw_runtime_events
from agentworkbench.evidence import normalize_evidence_records
from agentworkbench.models import AgentSpec, EvalCase, PythonEntrypoint, RunArtifact
from agentworkbench.pricing import estimate_token_cost
from agentworkbench.tracing import TRACE_SCHEMA_VERSION, TRACE_TAXONOMY, normalize_trace_events
from agentworkbench.utils import ensure_dir, write_json

_SUBPROCESS_BOOTSTRAP = (
    "from agentworkbench.adapters.python import _subprocess_main; raise SystemExit(_subprocess_main())"
)


def resolve_python_entrypoint(spec: AgentSpec) -> tuple[str, str, int]:
    entrypoint = spec.entrypoints.get("python")
    if not entrypoint:
        raise ValueError(f"Agent `{spec.id}` is missing entrypoints.python for python adapter")
    config = PythonEntrypoint.model_validate(dict(entrypoint))
    return str(config.callable), str(config.cwd or "."), int(config.timeout_seconds)


def summarize_python_entrypoint(spec: AgentSpec) -> tuple[str, str]:
    try:
        callable_path, cwd, _timeout_seconds = resolve_python_entrypoint(spec)
    except ValueError:
        return "unknown", "."
    return callable_path, cwd


def _python_event(*, callable_path: str, cwd: str, latency_ms: int, status: str) -> dict[str, Any]:
    return {
        "kind": "python",
        "name": "invoke",
        "label": "python:invoke",
        "callable": callable_path,
        "cwd": cwd,
        "latency_ms": latency_ms,
        "status": status,
    }


def _build_context(project_root: Path, spec: AgentSpec, case: EvalCase, run_dir: Path) -> tuple[Path, dict[str, Any]]:
    case_path = run_dir / "case.json"
    output_path = run_dir / "output.json"
    context_path = run_dir / "context.json"
    write_json(case_path, case.model_dump(mode="json"))
    context = {
        "agent": {
            "id": spec.id,
            "instructions": spec.instructions,
            "prompts": spec.prompts,
            "model": spec.model,
            "tools": [tool for tool in spec.tools if tool.get("enabled", True)],
            "skills": [skill for skill in spec.skills if skill.get("enabled", True)],
            "plugins": [plugin for plugin in spec.plugins if plugin.get("enabled", True)],
            "mcps": [mcp for mcp in spec.mcps if mcp.get("enabled", True)],
            "owned_paths": [str(path) for path in spec.owned_paths],
            "owned_globs": [str(path) for path in spec.owned_globs],
            "surface_paths": normalized_surface_paths(spec),
            "required_env": [str(key) for key in spec.required_env],
            "runtime": spec.runtime,
            "metadata": spec.metadata,
        },
        "case": case.model_dump(mode="json"),
        "paths": {
            "project_root": str(project_root),
            "run_dir": str(run_dir),
            "case_path": str(case_path),
            "output_path": str(output_path),
        },
    }
    write_json(context_path, context)
    return output_path, context


def _callable_from_path(callable_path: str, search_root: Path) -> Callable[..., Any]:
    importlib.invalidate_caches()
    module_name, separator, attr_name = callable_path.partition(":")
    if not separator or not module_name or not attr_name:
        raise ValueError(f"Invalid python entrypoint `{callable_path}`. Use `module.path:callable_name`.")
    added_paths: list[str] = []
    for candidate in [str(search_root), str(search_root.resolve())]:
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
            added_paths.append(candidate)
    try:
        module = importlib.import_module(module_name)
    finally:
        for candidate in reversed(added_paths):
            if candidate in sys.path:
                sys.path.remove(candidate)
    target = getattr(module, attr_name, None)
    if target is None or not callable(target):
        raise ValueError(f"Python entrypoint `{callable_path}` did not resolve to a callable.")
    return cast(Callable[..., Any], target)


def _invoke_callable(
    target: Callable[..., Any],
    *,
    case: dict[str, Any],
    context: dict[str, Any],
    project_root: Path,
    run_dir: Path,
    spec_payload: dict[str, Any],
) -> Any:
    signature = inspect.signature(target)
    available = {
        "case": case,
        "context": context,
        "project_root": project_root,
        "run_dir": run_dir,
        "spec": spec_payload,
    }
    if any(parameter.kind == inspect.Parameter.VAR_KEYWORD for parameter in signature.parameters.values()):
        return target(**available)
    kwargs = {name: value for name, value in available.items() if name in signature.parameters}
    return target(**kwargs)


def _bootstrap_pythonpath(env: dict[str, str]) -> None:
    package_root = str(Path(__file__).resolve().parents[2])
    current = env.get("PYTHONPATH", "").strip()
    paths = [package_root]
    if current:
        paths.append(current)
    env["PYTHONPATH"] = os.pathsep.join(paths)


def _write_subprocess_payload(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def _load_subprocess_payload(path: Path) -> tuple[dict[str, Any], list[str]]:
    if not path.exists():
        return {}, ["Python adapter subprocess did not write a result payload"]
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {}, [f"Python adapter subprocess payload was not valid JSON: {exc}"]
    if not isinstance(payload, dict):
        return {}, ["Python adapter subprocess payload must contain a JSON object"]
    return payload, []


def _subprocess_main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 5:
        print("Python adapter subprocess expected 5 arguments", file=sys.stderr)
        return 2
    callable_path, search_root_text, case_path_text, context_path_text, result_path_text = args
    search_root = Path(search_root_text)
    case_path = Path(case_path_text)
    context_path = Path(context_path_text)
    result_path = Path(result_path_text)
    try:
        case_payload = json.loads(case_path.read_text(encoding="utf-8"))
        context_payload = json.loads(context_path.read_text(encoding="utf-8"))
        project_root = Path(((context_payload.get("paths") or {}).get("project_root")) or search_root)
        run_dir = Path(((context_payload.get("paths") or {}).get("run_dir")) or search_root)
        spec_payload = dict(context_payload.get("agent") or {})
        target = _callable_from_path(callable_path, search_root)
        structured = _invoke_callable(
            target,
            case=case_payload,
            context=context_payload,
            project_root=project_root,
            run_dir=run_dir,
            spec_payload=spec_payload,
        )
        if isinstance(structured, RunArtifact):
            _write_subprocess_payload(
                result_path,
                {"status": "ok", "kind": "run_artifact", "payload": structured.model_dump(mode="json")},
            )
            return 0
        if isinstance(structured, str):
            _write_subprocess_payload(result_path, {"status": "ok", "kind": "string", "payload": structured})
            return 0
        if isinstance(structured, dict):
            _write_subprocess_payload(result_path, {"status": "ok", "kind": "structured", "payload": structured})
            return 0
        _write_subprocess_payload(
            result_path,
            {
                "status": "error",
                "errors": [f"Python adapter callable returned unsupported type `{type(structured).__name__}`"],
            },
        )
        return 1
    except Exception as exc:
        _write_subprocess_payload(
            result_path,
            {"status": "error", "errors": [f"Python adapter failed: {exc.__class__.__name__}: {exc}"]},
        )
        return 1


class PythonAdapter:
    def _error_artifact(
        self,
        spec: AgentSpec,
        case: EvalCase,
        *,
        callable_path: str,
        cwd: str,
        latency_ms: int,
        errors: list[str],
    ) -> RunArtifact:
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            events=[_python_event(callable_path=callable_path, cwd=cwd, latency_ms=latency_ms, status="error")],
            evidence_records=[],
            errors=errors,
        )

    def invoke(self, project_root: Path, spec: AgentSpec, case: EvalCase, run_dir: Path) -> RunArtifact:
        ensure_dir(run_dir)
        try:
            callable_path, cwd_value, timeout_seconds = resolve_python_entrypoint(spec)
        except ValueError as exc:
            return self._error_artifact(
                spec,
                case,
                callable_path="invalid-python-entrypoint",
                cwd=str(project_root),
                latency_ms=0,
                errors=[str(exc)],
            )
        python_cwd = (
            (project_root / cwd_value).resolve() if not Path(cwd_value).is_absolute() else Path(cwd_value).resolve()
        )
        if not python_cwd.exists() or not python_cwd.is_dir():
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=0,
                errors=[f"Python working directory does not exist: {python_cwd}"],
            )
        output_path, context = _build_context(project_root, spec, case, run_dir)
        env = build_env(project_root, spec)
        env["AWB_PROJECT_ROOT"] = str(project_root)
        env["AWB_AGENT_ID"] = spec.id
        env["AWB_INPUT"] = case.input
        env["AWB_TURNS_JSON"] = json.dumps(case.turns or [])
        env["AWB_CHAIN_CONTEXT_JSON"] = json.dumps(case.metadata.get("chain_context") or {})
        env["AWB_OUTPUT_PATH"] = str(output_path)
        env["AWB_CONTEXT_PATH"] = str(run_dir / "context.json")
        _bootstrap_pythonpath(env)
        missing = missing_env(env, required_env_names(spec))
        if missing:
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=0,
                errors=[f"Missing required environment variables: {', '.join(sorted(missing))}"],
            )
        result_path = run_dir / "python-result.json"
        started = time.time()
        completed_stderr = ""
        returncode: int | None = None
        timed_out = False
        try:
            completed = subprocess.run(
                [
                    sys.executable,
                    "-c",
                    _SUBPROCESS_BOOTSTRAP,
                    callable_path,
                    str(python_cwd),
                    str(run_dir / "case.json"),
                    str(run_dir / "context.json"),
                    str(result_path),
                ],
                capture_output=True,
                text=True,
                cwd=python_cwd,
                env=env,
                timeout=timeout_seconds,
            )
        except OSError as exc:
            latency_ms = int((time.time() - started) * 1000)
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=[f"Failed to execute Python adapter subprocess: {exc}"],
            )
        except subprocess.TimeoutExpired:
            timed_out = True
        else:
            completed_stderr = completed.stderr
            returncode = completed.returncode
        latency_ms = int((time.time() - started) * 1000)
        payload, payload_errors = _load_subprocess_payload(result_path)
        if timed_out:
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=[f"Python adapter timed out after {timeout_seconds} seconds"],
            )
        if payload_errors:
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=payload_errors,
            )
        if str(payload.get("status") or "").lower() != "ok":
            errors = [str(item) for item in payload.get("errors") or []]
            if returncode not in (None, 0) and not errors:
                errors.append(f"Python adapter subprocess exited with {returncode}")
            if completed_stderr.strip():
                errors.append(completed_stderr.strip())
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=errors or ["Python adapter subprocess failed"],
            )
        if returncode not in (None, 0):
            errors = [f"Python adapter subprocess exited with {returncode}"]
            if completed_stderr.strip():
                errors.append(completed_stderr.strip())
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=errors,
            )
        structured_output: dict[str, Any]
        result_kind = str(payload.get("kind") or "")
        if result_kind == "run_artifact":
            artifact = RunArtifact.model_validate(payload.get("payload") or {})
            artifact.case_id = case.id
            artifact.agent_id = spec.id
            artifact.trace_schema_version = artifact.trace_schema_version or TRACE_SCHEMA_VERSION
            artifact.trace_taxonomy = artifact.trace_taxonomy or TRACE_TAXONOMY
            if not artifact.evidence_records and artifact.structured_output:
                artifact.evidence_records = normalize_evidence_records(
                    artifact.structured_output, final_output=artifact.final_output
                )
            artifact.events.append(
                _python_event(callable_path=callable_path, cwd=str(python_cwd), latency_ms=latency_ms, status="ok")
            )
            artifact.latency_ms = artifact.latency_ms or latency_ms
            return artifact
        if result_kind == "string":
            structured_output = {"final_output": str(payload.get("payload") or "")}
        elif result_kind == "structured":
            structured_output = dict(payload.get("payload") or {})
        else:
            return self._error_artifact(
                spec,
                case,
                callable_path=callable_path,
                cwd=str(python_cwd),
                latency_ms=latency_ms,
                errors=[f"Python adapter subprocess returned unsupported result kind `{result_kind or 'unknown'}`"],
            )
        trace_events = normalize_trace_events(structured_output)
        evidence_records = normalize_evidence_records(
            structured_output,
            final_output=str(structured_output.get("final_output") or structured_output.get("output") or ""),
        )
        token_usage = {str(key): int(value) for key, value in (structured_output.get("token_usage") or {}).items()}
        metadata = dict(structured_output.get("metadata") or {})
        cost_estimate = float(structured_output.get("cost_estimate") or 0.0)
        cost_estimate = apply_cost_estimate(
            project_root,
            spec,
            token_usage,
            metadata,
            cost_estimate,
            estimator=estimate_token_cost,
        )
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            final_output=str(structured_output.get("final_output") or structured_output.get("output") or ""),
            structured_output=structured_output,
            events=[
                *raw_runtime_events(structured_output),
                _python_event(callable_path=callable_path, cwd=str(python_cwd), latency_ms=latency_ms, status="ok"),
            ],
            evidence_records=evidence_records,
            trace_events=trace_events,
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            workflow_trace=[str(item) for item in structured_output.get("workflow_trace") or []],
            tool_calls=[item for item in structured_output.get("tool_calls") or [] if isinstance(item, dict)],
            skills_used=[str(item) for item in structured_output.get("skills_used") or []],
            plugins_used=[str(item) for item in structured_output.get("plugins_used") or []],
            mcp_servers_used=[str(item) for item in structured_output.get("mcp_servers_used") or []],
            prompt_keys_used=[str(item) for item in structured_output.get("prompt_keys_used") or []],
            step_count=int(structured_output.get("step_count") or 0),
            latency_ms=latency_ms,
            token_usage=token_usage,
            cost_estimate=cost_estimate,
            errors=[str(item) for item in structured_output.get("errors") or []],
            metadata=metadata,
        )
