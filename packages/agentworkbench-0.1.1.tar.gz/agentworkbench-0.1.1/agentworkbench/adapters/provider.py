"""Provider adapter – delegates to the modular ``providers`` package.

This file is intentionally kept thin. All transport, caching, message
building, and response parsing live in ``agentworkbench.providers``.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from agentworkbench.adapters.common import apply_cost_estimate, build_env, missing_env, required_env_names
from agentworkbench.evidence import normalize_evidence_records
from agentworkbench.models import AgentSpec, EvalCase, ProviderEntrypoint, RunArtifact
from agentworkbench.providers.base import (
    BUILTIN_PROVIDER_ENDPOINTS,
    OPENAI_COMPATIBLE_PROVIDER_ALIASES,
)
from agentworkbench.providers.openai_compatible import (
    TransportError,
    build_messages,
    build_request_body,
    http_request,
    parse_response,
    recover_tool_use_failed_response,
    request_fingerprint,
    request_headers,
)
from agentworkbench.providers.pricing_resolver import estimate_token_cost
from agentworkbench.providers.replay_cache import cache_path, load_cache, write_cache
from agentworkbench.tracing import TRACE_SCHEMA_VERSION, TRACE_TAXONOMY, normalize_trace_events
from agentworkbench.utils import ensure_dir

# ---------------------------------------------------------------------------
# Entrypoint resolution
# ---------------------------------------------------------------------------

def resolve_provider_entrypoint(spec: AgentSpec) -> ProviderEntrypoint:
    entrypoint = spec.entrypoints.get("provider")
    if not entrypoint:
        raise ValueError(f"Agent `{spec.id}` is missing entrypoints.provider for provider adapter")
    config = ProviderEntrypoint.model_validate(dict(entrypoint))
    raw_provider_name = str(config.provider or spec.model.get("provider") or "").strip().lower()
    provider_name = OPENAI_COMPATIBLE_PROVIDER_ALIASES.get(raw_provider_name, raw_provider_name)
    if provider_name == "anthropic":
        raise ValueError(
            f"Agent `{spec.id}` provider adapter only supports OpenAI-compatible APIs. "
            "Anthropic's native Messages API is not OpenAI-compatible; use an OpenAI-compatible proxy/base_url "
            "with provider `openai-compatible` instead."
        )
    provider_defaults = BUILTIN_PROVIDER_ENDPOINTS.get(provider_name, {})
    config.provider = provider_name or None
    config.base_url = str(config.base_url or spec.model.get("base_url") or provider_defaults.get("base_url") or "").strip() or None
    config.api_key_env = (
        str(config.api_key_env or spec.model.get("api_key_env") or provider_defaults.get("api_key_env") or "").strip() or None
    )
    model_name = str(spec.model.get("model_id") or spec.model.get("name") or "").strip()
    if not model_name:
        raise ValueError(f"Agent `{spec.id}` provider adapter requires model.name or model.model_id")
    if not config.base_url:
        raise ValueError(
            f"Agent `{spec.id}` provider adapter requires entrypoints.provider.base_url or a builtin provider mapping"
        )
    if not config.api_key_env:
        raise ValueError(
            f"Agent `{spec.id}` provider adapter requires entrypoints.provider.api_key_env or a builtin provider mapping"
        )
    return config


def summarize_provider_entrypoint(spec: AgentSpec) -> tuple[str, str]:
    try:
        config = resolve_provider_entrypoint(spec)
    except ValueError:
        return "unknown", "."
    model_name = str(spec.model.get("model_id") or spec.model.get("name") or "unknown")
    provider_name = str(config.provider or spec.model.get("provider") or "provider")
    return f"{provider_name}:{model_name}", str(config.base_url or ".")


# ---------------------------------------------------------------------------
# Helper: provider event
# ---------------------------------------------------------------------------

def _provider_event(
    *,
    provider: str,
    model_name: str,
    base_url: str,
    status: str,
    cache_status: str,
    timeout_seconds: int,
) -> dict[str, Any]:
    return {
        "kind": "provider",
        "name": "invoke",
        "label": "provider:invoke",
        "provider": provider,
        "model_name": model_name,
        "base_url": base_url,
        "status": status,
        "cache_status": cache_status,
        "timeout_seconds": timeout_seconds,
    }


# ---------------------------------------------------------------------------
# Structured output helper
# ---------------------------------------------------------------------------

def _parsed_structured_output(final_output: str) -> dict[str, Any]:
    text = str(final_output or "").strip()
    if not text or text[0] not in "{[":
        return {}
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return {}
    if isinstance(payload, dict):
        return payload
    return {"response": payload}


# ---------------------------------------------------------------------------
# Provider adapter
# ---------------------------------------------------------------------------

class ProviderAdapter:

    def _error_artifact(
        self,
        spec: AgentSpec,
        case: EvalCase,
        *,
        config: ProviderEntrypoint,
        latency_ms: int,
        errors: list[str],
        cache_status: str,
        final_output: str = "",
        metadata: dict[str, Any] | None = None,
        error_classification: str | None = None,
    ) -> RunArtifact:
        provider_name = str(config.provider or spec.model.get("provider") or "provider")
        model_name = str(spec.model.get("model_id") or spec.model.get("name") or "unknown")
        meta = {
            "provider": provider_name,
            "model_name": model_name,
            "base_url": str(config.base_url or ""),
            "cache_mode": config.cache_mode,
            "cache_status": cache_status,
            **(metadata or {}),
        }
        if error_classification:
            meta["error_classification"] = error_classification
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            final_output=final_output,
            structured_output={},
            events=[
                _provider_event(
                    provider=provider_name,
                    model_name=model_name,
                    base_url=str(config.base_url or ""),
                    status="error",
                    cache_status=cache_status,
                    timeout_seconds=int(config.timeout_seconds),
                )
            ],
            evidence_records=[],
            trace_events=[],
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            workflow_trace=[],
            tool_calls=[],
            skills_used=[],
            plugins_used=[],
            mcp_servers_used=[],
            prompt_keys_used=[],
            step_count=0,
            latency_ms=latency_ms,
            token_usage={},
            cost_estimate=0.0,
            errors=errors,
            metadata=meta,
        )

    def invoke(self, project_root: Path, spec: AgentSpec, case: EvalCase, run_dir: Path) -> RunArtifact:
        ensure_dir(run_dir)
        try:
            config = resolve_provider_entrypoint(spec)
            messages, prompt_keys = build_messages(project_root, spec, case, config)
        except ValueError as exc:
            fallback_config = ProviderEntrypoint(base_url=None, api_key_env=None)
            return self._error_artifact(
                spec, case, config=fallback_config, latency_ms=0,
                errors=[str(exc)], cache_status="disabled",
            )

        # Resolve environment
        env = build_env(project_root, spec)
        required_env = required_env_names(spec, [str(config.api_key_env or "").strip()])
        missing = missing_env(env, required_env)
        if missing:
            return self._error_artifact(
                spec, case, config=config, latency_ms=0,
                errors=[f"Missing required environment variables: {', '.join(missing)}"],
                cache_status="disabled",
            )

        # Build request
        request_body = build_request_body(spec, messages, config)
        provider_name = str(config.provider or spec.model.get("provider") or "provider")
        model_name = str(spec.model.get("model_id") or spec.model.get("name") or "unknown")
        cache_descriptor = {
            "adapter": "provider",
            "provider": provider_name,
            "base_url": str(config.base_url or ""),
            "request": request_body,
        }
        cache_key = request_fingerprint(cache_descriptor)
        c_path = cache_path(project_root, cache_key)

        # Cache lookup
        response_payload: dict[str, Any] | None = None
        cache_status = "disabled" if config.cache_mode == "off" else "miss"
        recovered_from_error = False
        started = time.time()
        if config.cache_mode != "off":
            cached_response, cache_errors = load_cache(c_path)
            if cache_errors and config.cache_mode == "replay":
                return self._error_artifact(
                    spec, case, config=config, latency_ms=0,
                    errors=cache_errors, cache_status="invalid",
                    metadata={"cache_key": cache_key},
                )
            if cached_response is not None and config.cache_mode != "refresh":
                response_payload = cached_response
                cache_status = "replay" if config.cache_mode == "replay" else "hit"
        if response_payload is None:
            if config.cache_mode == "replay":
                return self._error_artifact(
                    spec, case, config=config, latency_ms=0,
                    errors=[f"Provider cache miss for replay mode: {cache_key}"],
                    cache_status="miss", metadata={"cache_key": cache_key},
                )
            api_key = str(env.get(str(config.api_key_env or ""), "")).strip()
            try:
                response_payload = http_request(
                    str(config.base_url),
                    request_body,
                    request_headers(config, api_key),
                    int(config.timeout_seconds),
                )
            except TransportError as exc:
                latency_ms = int((time.time() - started) * 1000)
                recovered_payload = recover_tool_use_failed_response(
                    exc.body,
                    response_id=f"recovered:{cache_key}",
                )
                if recovered_payload is not None:
                    response_payload = recovered_payload
                    recovered_from_error = True
                    cache_status = "recovered"
                    if config.cache_mode in {"auto", "refresh"}:
                        write_cache(c_path, request=cache_descriptor, response=response_payload)
                else:
                    errors = [str(exc)]
                    if exc.body:
                        errors.append(exc.body)
                    return self._error_artifact(
                        spec, case, config=config, latency_ms=latency_ms,
                        errors=errors, cache_status="miss",
                        metadata={"cache_key": cache_key},
                        error_classification=exc.classification.value,
                    )
            except ValueError as exc:
                latency_ms = int((time.time() - started) * 1000)
                return self._error_artifact(
                    spec, case, config=config, latency_ms=latency_ms,
                    errors=[f"Provider request failed: {exc}"],
                    cache_status="miss", metadata={"cache_key": cache_key},
                )
            if not recovered_from_error:
                cache_status = "stored" if config.cache_mode == "auto" else "refreshed"
            if config.cache_mode in {"auto", "refresh"} and response_payload is not None and not recovered_from_error:
                write_cache(c_path, request=cache_descriptor, response=response_payload)

        latency_ms = int((time.time() - started) * 1000)
        assert response_payload is not None

        # Parse response
        try:
            parsed = parse_response(response_payload)
        except ValueError as exc:
            return self._error_artifact(
                spec, case, config=config, latency_ms=latency_ms,
                errors=[str(exc)], cache_status=cache_status,
                metadata={"cache_key": cache_key},
            )
        recovery_meta = response_payload.get("awb_recovery") or {}
        is_recovered = isinstance(recovery_meta, dict) and bool(recovery_meta)
        response_status = "recovered" if is_recovered else "success"
        recovered_error = recovery_meta.get("error") if isinstance(recovery_meta, dict) else {}
        if not isinstance(recovered_error, dict):
            recovered_error = {}

        # Build structured output and artifact
        structured_output: dict[str, Any] = {
            "final_output": parsed.final_output,
            "events": [
                {
                    "kind": "provider_request", "name": "chat_completion",
                    "label": "provider_request:chat_completion",
                    "provider": provider_name, "model_name": model_name,
                    "message_count": len(messages), "cache_status": cache_status,
                },
                {
                    "kind": "provider_response", "name": response_status,
                    "label": f"provider_response:{response_status}",
                    "provider": provider_name, "model_name": model_name,
                    "finish_reason": parsed.finish_reason,
                    "tool_calls": len(parsed.tool_calls), "cache_status": cache_status,
                    **(
                        {
                            "recovery_mode": str(recovery_meta.get("mode") or "").strip(),
                            "recovered_error_code": str(recovered_error.get("code") or "").strip(),
                        }
                        if is_recovered
                        else {}
                    ),
                },
            ],
            "tool_calls": parsed.tool_calls,
            "prompt_keys_used": prompt_keys,
            "step_count": 1 + len(parsed.tool_calls),
            "token_usage": parsed.token_usage,
            "metadata": {
                "provider": provider_name, "model_name": model_name,
                "base_url": str(config.base_url or ""),
                "cache_mode": config.cache_mode, "cache_status": cache_status,
                "cache_key": cache_key,
                "finish_reason": parsed.finish_reason,
                "response_id": parsed.response_id,
                **(
                    {
                        "recovered_from_error": True,
                        "recovery_mode": str(recovery_meta.get("mode") or "").strip(),
                        "recovered_error_code": str(recovered_error.get("code") or "").strip(),
                        "recovered_error_message": str(recovered_error.get("message") or "").strip(),
                        "recovered_failed_generation": str(recovered_error.get("failed_generation") or "").strip(),
                    }
                    if is_recovered
                    else {}
                ),
            },
        }
        structured_output_payload = _parsed_structured_output(parsed.final_output)
        if structured_output_payload:
            structured_output["structured_output"] = structured_output_payload
        evidence_records = normalize_evidence_records(structured_output, final_output=parsed.final_output)
        trace_events = normalize_trace_events(structured_output)
        run_metadata = dict(structured_output.get("metadata") or {})
        cost_estimate = float(structured_output.get("cost_estimate") or 0.0)
        cost_estimate = apply_cost_estimate(
            project_root,
            spec,
            parsed.token_usage,
            run_metadata,
            cost_estimate,
            estimator=estimate_token_cost,
        )
        return RunArtifact(
            case_id=case.id,
            agent_id=spec.id,
            final_output=parsed.final_output,
            structured_output=structured_output,
            events=[
                *(structured_output.get("events") or []),
                _provider_event(
                    provider=provider_name, model_name=model_name,
                    base_url=str(config.base_url or ""),
                    status=response_status, cache_status=cache_status,
                    timeout_seconds=int(config.timeout_seconds),
                ),
            ],
            evidence_records=evidence_records,
            trace_events=trace_events,
            trace_schema_version=TRACE_SCHEMA_VERSION,
            trace_taxonomy=TRACE_TAXONOMY,
            workflow_trace=[str(item) for item in structured_output.get("workflow_trace") or []],
            tool_calls=parsed.tool_calls,
            skills_used=[],
            plugins_used=[],
            mcp_servers_used=[],
            prompt_keys_used=prompt_keys,
            step_count=int(structured_output.get("step_count") or 0),
            latency_ms=latency_ms,
            token_usage=parsed.token_usage,
            cost_estimate=cost_estimate,
            errors=[],
            metadata=run_metadata,
        )
