from __future__ import annotations

from typing import Any

from agentworkbench.models import AgentSpec
from agentworkbench.utils import enabled_item_names

_SCHEMA_METADATA_KEYS = {
    "$comment",
    "default",
    "deprecated",
    "description",
    "example",
    "examples",
    "title",
}
_SCHEMA_STRUCTURAL_KEYS = {
    "$defs",
    "$ref",
    "additionalProperties",
    "allOf",
    "anyOf",
    "const",
    "enum",
    "items",
    "maxItems",
    "maxLength",
    "maximum",
    "minItems",
    "minLength",
    "minimum",
    "oneOf",
    "pattern",
    "properties",
    "required",
    "type",
}
_PROVIDER_TOOL_FORMATS = {"full", "compact"}


def enabled_tool_names(spec: AgentSpec) -> list[str]:
    return enabled_item_names(spec.tools, sort=True)


def find_tool(spec: AgentSpec, tool_name: str) -> dict[str, Any] | None:
    wanted = str(tool_name).strip()
    for tool in spec.tools:
        name = str(tool.get("name") or tool.get("id") or "").strip()
        if name == wanted:
            return tool
    return None


def tool_description(tool: dict[str, Any]) -> str:
    function_payload = tool.get("function")
    if isinstance(function_payload, dict):
        return str(function_payload.get("description") or "").strip()
    return str(tool.get("description") or "").strip()


def set_tool_description(tool: dict[str, Any], value: str) -> None:
    function_payload = tool.get("function")
    if isinstance(function_payload, dict):
        function_payload["description"] = str(value)
        return
    tool["description"] = str(value)


def tool_schema(tool: dict[str, Any]) -> dict[str, Any] | None:
    function_payload = tool.get("function")
    if isinstance(function_payload, dict):
        schema = function_payload.get("parameters")
        return dict(schema) if isinstance(schema, dict) else None
    for key in ("parameters", "input_schema", "schema"):
        schema = tool.get(key)
        if isinstance(schema, dict):
            return dict(schema)
    return None


def set_tool_schema(tool: dict[str, Any], schema: dict[str, Any]) -> None:
    function_payload = tool.get("function")
    if isinstance(function_payload, dict):
        function_payload["parameters"] = dict(schema)
        return
    for key in ("parameters", "input_schema", "schema"):
        if isinstance(tool.get(key), dict):
            tool[key] = dict(schema)
            return
    tool["parameters"] = dict(schema)


def compact_tool_description(value: str, *, limit: int = 96) -> str:
    text = " ".join(str(value or "").split())
    if not text:
        return ""
    first_sentence = text.split(". ", 1)[0].strip()
    compact = first_sentence if first_sentence else text
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 3)].rstrip() + "..."


def compact_tool_schema(value: Any) -> Any:
    if isinstance(value, dict):
        compact: dict[str, Any] = {}
        for key, item in value.items():
            if key in _SCHEMA_METADATA_KEYS:
                continue
            if key not in _SCHEMA_STRUCTURAL_KEYS and not key.startswith("$"):
                continue
            if key == "properties" and isinstance(item, dict):
                compact["properties"] = {str(name): compact_tool_schema(child) for name, child in item.items()}
                continue
            if key == "items":
                compact["items"] = compact_tool_schema(item)
                continue
            if key in {"oneOf", "anyOf", "allOf"} and isinstance(item, list):
                compact[key] = [compact_tool_schema(child) for child in item if isinstance(child, dict)]
                continue
            if isinstance(item, dict):
                compact[key] = compact_tool_schema(item)
            elif isinstance(item, list):
                compact[key] = [compact_tool_schema(child) if isinstance(child, dict) else child for child in item]
            else:
                compact[key] = item
        return compact
    if isinstance(value, list):
        return [compact_tool_schema(item) for item in value]
    return value


def loose_tool_schema(schema: dict[str, Any]) -> dict[str, Any]:
    schema_type = str(schema.get("type") or "").strip()
    if schema_type == "object":
        properties = schema.get("properties") or {}
        simplified: dict[str, Any] = {"type": "object", "properties": {}}
        for key, value in properties.items():
            if not isinstance(value, dict):
                continue
            child_type = str(value.get("type") or "").strip()
            child: dict[str, Any] = {"type": child_type or "string"}
            if child_type == "array" and isinstance(value.get("items"), dict):
                child["items"] = {"type": str((value.get("items") or {}).get("type") or "string")}
            elif child_type == "object" and isinstance(value.get("properties"), dict):
                child["properties"] = {
                    str(name): {"type": str((child_value or {}).get("type") or "string")}
                    for name, child_value in (value.get("properties") or {}).items()
                    if isinstance(child_value, dict)
                }
            simplified["properties"][str(key)] = child
        simplified["additionalProperties"] = True
        return simplified
    if schema_type == "array":
        items = schema.get("items")
        return {
            "type": "array",
            "items": {"type": str((items or {}).get("type") or "string")} if isinstance(items, dict) else {"type": "string"},
        }
    return {"type": schema_type or "string"}


def provider_tool_format(spec: AgentSpec) -> str:
    entrypoint = spec.entrypoints.get("provider") or {}
    mode = str((entrypoint or {}).get("tool_format") or "full").strip().lower()
    return mode if mode in _PROVIDER_TOOL_FORMATS else "full"


def alternate_provider_tool_format(current: str) -> str:
    normalized = str(current or "full").strip().lower()
    return "compact" if normalized != "compact" else "full"


def set_provider_tool_format(spec: AgentSpec, mode: str) -> None:
    provider_entrypoint = dict(spec.entrypoints.get("provider") or {})
    provider_entrypoint["tool_format"] = str(mode)
    spec.entrypoints["provider"] = provider_entrypoint


def tool_docstring_targets(spec: AgentSpec) -> list[str]:
    targets = []
    for name in enabled_tool_names(spec):
        tool = find_tool(spec, name)
        if tool and tool_description(tool):
            targets.append(name)
    return sorted(dict.fromkeys(targets))


def tool_schema_targets(spec: AgentSpec) -> list[str]:
    targets = []
    for name in enabled_tool_names(spec):
        tool = find_tool(spec, name)
        if tool and tool_schema(tool):
            targets.append(name)
    return sorted(dict.fromkeys(targets))


__all__ = [
    "alternate_provider_tool_format",
    "compact_tool_description",
    "compact_tool_schema",
    "enabled_tool_names",
    "find_tool",
    "loose_tool_schema",
    "provider_tool_format",
    "set_provider_tool_format",
    "set_tool_description",
    "set_tool_schema",
    "tool_description",
    "tool_docstring_targets",
    "tool_schema",
    "tool_schema_targets",
]
