from __future__ import annotations

import ast
import configparser
import hashlib
import json
import tomllib
from pathlib import Path
from typing import Any

import yaml

from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.models import AgentSpec


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _preview(text: str, limit: int = 96) -> str:
    compact = " ".join(text.split())
    if len(compact) <= limit:
        return compact
    return f"{compact[: max(0, limit - 3)]}..."


def _relative_spec_path(spec: AgentSpec) -> str:
    return str(Path(CONTROL_DIR_NAME) / "agents" / f"{spec.id}.yaml")


def _candidate_surface_files(project_root: Path, spec: AgentSpec) -> list[str]:
    files: set[str] = {_relative_spec_path(spec)}
    files.update(str(item) for item in spec.owned_paths)
    for values in spec.surface_paths.values():
        files.update(str(item) for item in values or [])
    resolved: list[str] = []
    for relative_path in sorted(files):
        path = project_root / relative_path
        if path.exists() and path.is_file():
            resolved.append(relative_path)
    return resolved


def _docstring_entries(node: ast.AST, prefix: str = "") -> dict[str, dict[str, str]]:
    entries: dict[str, dict[str, str]] = {}
    for child in getattr(node, "body", []):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = f"{prefix}{child.name}"
            docstring = ast.get_docstring(child) or ""
            if docstring:
                label = ("class" if isinstance(child, ast.ClassDef) else "function") + f":{name}"
                entries[label] = {"hash": _hash_text(docstring), "preview": _preview(docstring)}
            if isinstance(child, ast.ClassDef):
                entries.update(_docstring_entries(child, prefix=f"{child.name}."))
    return entries


def _python_details(text: str) -> dict[str, Any]:
    try:
        module = ast.parse(text)
    except SyntaxError:
        return {}
    details: dict[str, Any] = {}
    module_docstring = ast.get_docstring(module) or ""
    if module_docstring:
        details["module"] = {"hash": _hash_text(module_docstring), "preview": _preview(module_docstring)}
    details.update(_docstring_entries(module))
    return details


def _flatten_key(prefix: str, key: str) -> str:
    return key if not prefix else f"{prefix}.{key}"


def _flatten_scalar_entries(value: Any, prefix: str = "") -> dict[str, dict[str, str]]:
    entries: dict[str, dict[str, str]] = {}
    if isinstance(value, dict):
        for key, item in value.items():
            entries.update(_flatten_scalar_entries(item, _flatten_key(prefix, str(key))))
        return entries
    if isinstance(value, list):
        for index, item in enumerate(value):
            if isinstance(item, dict) and (item.get("name") or item.get("id")):
                identifier = str(item.get("name") or item.get("id"))
                child_prefix = f"{prefix}[{identifier}]"
            else:
                child_prefix = f"{prefix}[{index}]"
            entries.update(_flatten_scalar_entries(item, child_prefix))
        return entries
    if value is None or not prefix:
        return entries
    rendered = str(value)
    entries[prefix] = {"hash": _hash_text(rendered), "preview": _preview(rendered)}
    return entries


def _config_details(path: Path, text: str) -> dict[str, Any]:
    suffix = path.suffix.lower()
    try:
        if suffix in {".yaml", ".yml"}:
            payload = yaml.safe_load(text)
        elif suffix == ".json":
            payload = json.loads(text)
        elif suffix == ".toml":
            payload = tomllib.loads(text)
        elif suffix in {".ini", ".cfg"}:
            parser = configparser.ConfigParser()
            parser.read_string(text)
            payload = {section: dict(parser.items(section)) for section in parser.sections()}
        else:
            return {}
    except Exception:
        return {}
    return _flatten_scalar_entries(payload)


def _prompt_sections(text: str) -> dict[str, dict[str, str]]:
    sections: dict[str, list[str]] = {"__root__": []}
    current = "__root__"
    for line in text.splitlines():
        if line.startswith("#"):
            current = line.lstrip("#").strip() or "__root__"
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    return {
        key: {"hash": _hash_text("\n".join(value).strip()), "preview": _preview("\n".join(value).strip())}
        for key, value in sections.items()
        if "\n".join(value).strip()
    }


def capture_surface_snapshot(project_root: Path, spec: AgentSpec) -> dict[str, Any]:
    snapshot: dict[str, Any] = {}
    for relative_path in _candidate_surface_files(project_root, spec):
        path = project_root / relative_path
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        details: dict[str, Any] = {
            "kind": path.suffix.lower().lstrip(".") or "text",
            "hash": _hash_text(text),
        }
        python_docstrings = _python_details(text) if path.suffix.lower() == ".py" else {}
        if python_docstrings:
            details["docstrings"] = python_docstrings
        config_entries = _config_details(path, text)
        if config_entries:
            details["config"] = config_entries
        if path.suffix.lower() in {".md", ".txt"}:
            sections = _prompt_sections(text)
            if sections:
                details["sections"] = sections
        snapshot[relative_path] = details
    return snapshot


def _named_delta(
    baseline: dict[str, dict[str, str]],
    candidate: dict[str, dict[str, str]],
    *,
    prefix: str,
    file_path: str,
) -> list[str]:
    changed: list[str] = []
    for name in sorted(set(baseline) | set(candidate)):
        before = (baseline.get(name) or {}).get("hash")
        after = (candidate.get(name) or {}).get("hash")
        if before != after:
            changed.append(f"{file_path}::{prefix}{name}")
    return changed


def compare_surface_snapshots(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    docstring_changes: list[str] = []
    config_changes: list[str] = []
    prompt_section_changes: list[str] = []
    changed_files: list[str] = []
    for file_path in sorted(set(baseline) | set(candidate)):
        before = baseline.get(file_path) or {}
        after = candidate.get(file_path) or {}
        if before.get("hash") != after.get("hash"):
            changed_files.append(file_path)
        docstring_changes.extend(
            _named_delta(before.get("docstrings", {}), after.get("docstrings", {}), prefix="", file_path=file_path)
        )
        config_changes.extend(
            _named_delta(before.get("config", {}), after.get("config", {}), prefix="", file_path=file_path)
        )
        prompt_section_changes.extend(
            _named_delta(before.get("sections", {}), after.get("sections", {}), prefix="section:", file_path=file_path)
        )
    tool_docstrings = [
        item
        for item in docstring_changes
        if "tool" in Path(str(item).split("::", 1)[0]).stem.lower()
    ]
    tool_docstrings.extend(
        item
        for item in config_changes
        if ("::tools[" in item or ".tools[" in item) and item.endswith(".description")
    )
    mcp_config = [item for item in config_changes if "::mcps[" in item or ".mcps[" in item]
    plugin_config = [item for item in config_changes if "::plugins[" in item or ".plugins[" in item]
    tool_config = [item for item in config_changes if "::tools[" in item or ".tools[" in item]
    tool_schema = [
        item
        for item in tool_config
        if any(marker in item for marker in [".parameters", ".input_schema", ".schema"])
    ]
    prompt_config = [item for item in config_changes if "::prompts." in item or ".prompts." in item]
    runtime_config = [item for item in config_changes if "::runtime." in item or ".runtime." in item or "::model." in item]
    tool_format_config = [item for item in config_changes if item.endswith("entrypoints.provider.tool_format")]
    return {
        "changed_files": changed_files,
        "docstring_changes": sorted(docstring_changes),
        "tool_docstring_changes": sorted(dict.fromkeys(tool_docstrings)),
        "config_changes": sorted(config_changes),
        "tool_config_changes": sorted(tool_config),
        "tool_schema_changes": sorted(tool_schema),
        "tool_format_changes": sorted(tool_format_config),
        "plugin_config_changes": sorted(plugin_config),
        "mcp_config_changes": sorted(mcp_config),
        "prompt_config_changes": sorted(prompt_config),
        "runtime_config_changes": sorted(runtime_config),
        "prompt_section_changes": sorted(prompt_section_changes),
    }
