from __future__ import annotations

from typing import Any

from agentworkbench.models import ExperimentRecord


def render_experiment_report(record: ExperimentRecord, aggregate: dict[str, Any], failed_cases: list[dict[str, Any]]) -> str:
    behavior = record.behavior_summary or {}
    spec = record.spec_snapshot or {}
    lines = [
        f"# Experiment {record.experiment_id}",
        "",
        f"- Agent: `{record.agent_id}`",
        f"- Eval: `{record.eval_id}`",
        f"- Subset: `{record.subset or 'unknown'}`",
        f"- Status: `{record.status}`",
        f"- Promotion status: `{record.promotion_status}`",
        f"- Series: `{record.series_id or 'none'}`",
        f"- Parent experiment: `{record.parent_experiment_id or 'none'}`",
        f"- Created: `{record.created_at or 'unknown'}`",
        f"- Benchmark signature: `{record.benchmark_signature or 'unknown'}`",
        f"- Benchmark fingerprint: `{(record.benchmark_manifest or {}).get('fingerprint', 'unknown')}`",
        f"- Case selection: mode=`{(record.case_selection or {}).get('selection_mode', 'subset')}`, "
        f"count={len(record.selected_case_ids or [])}, "
        f"fingerprint=`{record.selection_fingerprint or 'none'}`",
        f"- Average score: {aggregate.get('average_score', 0.0):.3f}",
        f"- Passed: {aggregate.get('passed_cases', 0)}/{aggregate.get('total_cases', 0)}",
        "",
        "## Score Breakdown",
        "",
    ]
    metric_averages = aggregate.get("metric_averages") or {}
    metric_weights = aggregate.get("metric_weights") or {}
    metric_pass_rates = aggregate.get("metric_pass_rates") or {}
    weighted_metric_contributions = aggregate.get("weighted_metric_contributions") or {}
    if metric_averages:
        for name in metric_averages:
            lines.append(
                f"- `{name}`: avg={float(metric_averages.get(name, 0.0)):.3f}, "
                f"pass_rate={float(metric_pass_rates.get(name, 0.0)):.3f}, "
                f"weight={float(metric_weights.get(name, 1.0)):.3f}, "
                f"contribution={float(weighted_metric_contributions.get(name, 0.0)):.3f}"
            )
    else:
        lines.append("- none")
    lines.extend([
        "",
        "## Agent Surface",
        "",
        f"- Model: `{spec.get('model_name', 'unknown')}`",
        f"- Runtime entrypoint: `{spec.get('command_entrypoint', 'unknown')}`",
        f"- Runtime cwd: `{spec.get('command_cwd', '.')}`",
        f"- Required env: {', '.join(spec.get('required_env', [])) or 'none'}",
        f"- Prompt keys: {', '.join(spec.get('prompt_keys', [])) or 'none'}",
        f"- Tools available: {', '.join(spec.get('tool_names', [])) or 'none'}",
        f"- Skills available: {', '.join(spec.get('skill_names', [])) or 'none'}",
        f"- Plugins available: {', '.join(spec.get('plugin_names', [])) or 'none'}",
        f"- MCP servers available: {', '.join(spec.get('mcp_names', [])) or 'none'}",
        f"- Owned files: {', '.join(spec.get('owned_paths', [])) or 'none'}",
        "",
        "## Surface Files",
        "",
    ])
    surface_paths = spec.get("surface_paths", {}) or {}
    if surface_paths:
        for key, value in surface_paths.items():
            lines.append(f"- `{key}`: {', '.join(value) or 'none'}")
    else:
        lines.append("- none")
    lines.extend([
        "",
        "## Behavior Summary",
        "",
        f"- Avg tool calls: {behavior.get('average_tool_calls', 0.0):.2f}",
        f"- Avg trace events: {behavior.get('average_trace_event_count', 0.0):.2f}",
        f"- Avg evidence records: {behavior.get('average_evidence_record_count', 0.0):.2f}",
        f"- Avg selected evidence: {behavior.get('average_selected_evidence_count', 0.0):.2f}",
        f"- Avg supported evidence: {behavior.get('average_supported_evidence_count', 0.0):.2f}",
        f"- Avg step count: {behavior.get('average_step_count', 0.0):.2f}",
        f"- Avg latency ms: {behavior.get('average_latency_ms', 0.0):.1f}",
        f"- Avg cost estimate: {float(behavior.get('average_cost_estimate', 0.0)):.6f}",
        f"- Total cost estimate: {float(behavior.get('total_cost_estimate', 0.0)):.6f}",
        f"- Providers used: {', '.join(behavior.get('providers_used', [])) or 'none'}",
        f"- Models used: {', '.join(behavior.get('models_used', [])) or 'none'}",
        f"- Pricing sources: {', '.join(behavior.get('pricing_sources', [])) or 'none'}",
        f"- Tools used: {', '.join(behavior.get('tools_used', [])) or 'none'}",
        f"- Skills used: {', '.join(behavior.get('skills_used', [])) or 'none'}",
        f"- Plugins used: {', '.join(behavior.get('plugins_used', [])) or 'none'}",
        f"- MCP servers used: {', '.join(behavior.get('mcp_servers_used', [])) or 'none'}",
        f"- Prompt keys used: {', '.join(behavior.get('prompt_keys_used', [])) or 'none'}",
        f"- Workflow steps used: {', '.join(behavior.get('workflow_steps_used', [])) or 'none'}",
        f"- Trace events used: {', '.join(behavior.get('trace_events_used', [])) or 'none'}",
        f"- Evidence sources used: {', '.join(behavior.get('evidence_sources_used', [])) or 'none'}",
        f"- Evidence sources with unused selected snippets: {', '.join(behavior.get('evidence_sources_with_unused_selected', [])) or 'none'}",
        f"- Selected evidence use rate: {behavior.get('selected_evidence_use_rate', 'n/a')}",
        f"- Trace schema versions: {', '.join(behavior.get('trace_schema_versions', [])) or 'none'}",
        f"- Trace taxonomies: {', '.join(behavior.get('trace_taxonomies', [])) or 'none'}",
        f"- Tool coverage: {behavior.get('tool_coverage', 'n/a')}",
        f"- Skill coverage: {behavior.get('skill_coverage', 'n/a')}",
        f"- Plugin coverage: {behavior.get('plugin_coverage', 'n/a')}",
        f"- MCP coverage: {behavior.get('mcp_coverage', 'n/a')}",
        f"- Prompt coverage: {behavior.get('prompt_coverage', 'n/a')}",
        "",
        "## Surface Counts",
        "",
        f"- Tool usage counts: {behavior.get('tool_usage_counts', {}) or 'none'}",
        f"- Skill usage counts: {behavior.get('skill_usage_counts', {}) or 'none'}",
        f"- Plugin usage counts: {behavior.get('plugin_usage_counts', {}) or 'none'}",
        f"- MCP usage counts: {behavior.get('mcp_usage_counts', {}) or 'none'}",
        f"- Prompt usage counts: {behavior.get('prompt_usage_counts', {}) or 'none'}",
        f"- Workflow step counts: {behavior.get('workflow_step_counts', {}) or 'none'}",
        f"- Trace event labels: {behavior.get('trace_event_label_counts', {}) or 'none'}",
        f"- Trace event kinds: {behavior.get('trace_event_kind_counts', {}) or 'none'}",
        f"- Evidence source counts: {behavior.get('evidence_source_counts', {}) or 'none'}",
        f"- Evidence kind counts: {behavior.get('evidence_kind_counts', {}) or 'none'}",
        f"- Total token usage: {behavior.get('total_token_usage', {}) or 'none'}",
        f"- Average token usage: {behavior.get('average_token_usage', {}) or 'none'}",
        "",
        "## Tool And MCP Audits",
        "",
        f"- Tool outcome totals: {behavior.get('tool_outcome_totals', {}) or 'none'}",
        f"- MCP outcome totals: {behavior.get('mcp_outcome_totals', {}) or 'none'}",
        f"- Tool evidence totals: {behavior.get('tool_evidence_totals', {}) or 'none'}",
        f"- MCP evidence totals: {behavior.get('mcp_evidence_totals', {}) or 'none'}",
        f"- Tools with errors: {', '.join(behavior.get('tools_with_errors', [])) or 'none'}",
        f"- MCPs with errors: {', '.join(behavior.get('mcps_with_errors', [])) or 'none'}",
        f"- Tools with empty results: {', '.join(behavior.get('tools_with_empty_results', [])) or 'none'}",
        f"- MCPs with empty results: {', '.join(behavior.get('mcps_with_empty_results', [])) or 'none'}",
        f"- Tools with unused selected evidence: {', '.join(behavior.get('tools_with_unused_selected_evidence', [])) or 'none'}",
        f"- MCPs with unused selected evidence: {', '.join(behavior.get('mcps_with_unused_selected_evidence', [])) or 'none'}",
        f"- Tools with low evidence use: {', '.join(behavior.get('tools_with_low_evidence_use', [])) or 'none'}",
        f"- MCPs with low evidence use: {', '.join(behavior.get('mcps_with_low_evidence_use', [])) or 'none'}",
        "",
        "## Surface Contracts",
        "",
        f"- Surface contract violation count: {behavior.get('surface_contract_violation_count', 0)}",
        f"- Tool used while disabled: {', '.join(behavior.get('tool_used_not_enabled', [])) or 'none'}",
        f"- MCP used while disabled: {', '.join(behavior.get('mcp_used_not_enabled', [])) or 'none'}",
        f"- MCP referenced but not listed: {', '.join(behavior.get('mcp_referenced_not_listed', [])) or 'none'}",
        f"- MCP listed but not referenced: {', '.join(behavior.get('mcp_listed_not_referenced', [])) or 'none'}",
        "",
        "## Unused Available Surface",
        "",
        f"- Tools: {', '.join(behavior.get('unused_available_tools', [])) or 'none'}",
        f"- Skills: {', '.join(behavior.get('unused_available_skills', [])) or 'none'}",
        f"- Plugins: {', '.join(behavior.get('unused_available_plugins', [])) or 'none'}",
        f"- MCP servers: {', '.join(behavior.get('unused_available_mcps', [])) or 'none'}",
        f"- Prompt keys: {', '.join(behavior.get('unused_available_prompt_keys', [])) or 'none'}",
        "",
        "## Availability Vs Usage",
        "",
    ])
    surface_audits = behavior.get("surface_audits") or {}
    if surface_audits:
        for key, value in surface_audits.items():
            lines.append(
                f"- `{key}`: available={', '.join(value.get('available', [])) or 'none'}, "
                f"used={', '.join(value.get('used', [])) or 'none'}, "
                f"unused={', '.join(value.get('unused', [])) or 'none'}, "
                f"used_not_declared={', '.join(value.get('used_not_declared', [])) or 'none'}, "
                f"coverage={value.get('coverage', 'n/a')}"
            )
    else:
        lines.append("- none")
    lines.extend(["", "## Per-Surface Outcomes", ""])
    if behavior.get("tool_audits") or behavior.get("mcp_audits"):
        for label, audits in [("tools", behavior.get("tool_audits") or {}), ("mcps", behavior.get("mcp_audits") or {})]:
            for name, counts in audits.items():
                lines.append(
                    f"- `{label}:{name}`: attempted={counts.get('attempted', 0)}, success={counts.get('success', 0)}, "
                    f"empty={counts.get('empty', 0)}, error={counts.get('error', 0)}, skipped={counts.get('skipped', 0)}, "
                    f"selected_evidence={counts.get('selected_evidence', 0)}, supported_evidence={counts.get('supported_evidence', 0)}, "
                    f"selected_evidence_use_rate={counts.get('selected_evidence_use_rate', 'n/a')}, "
                    f"success_rate={counts.get('success_rate', 'n/a')}"
                )
    else:
        lines.append("- none")
    if behavior.get("is_workflow_run"):
        lines.extend(
            [
                "",
                "## Workflow Summary",
                "",
                f"- Avg workflow step pass rate: {behavior.get('average_workflow_step_pass_rate', 0.0):.3f}",
                f"- Avg workflow latency ms: {behavior.get('average_workflow_latency_ms', 0.0):.1f}",
                f"- Avg workflow node scores: {behavior.get('average_workflow_node_scores', {}) or 'none'}",
                f"- Workflow path counts: {behavior.get('workflow_path_counts', {}) or 'none'}",
                f"- Workflow terminal node counts: {behavior.get('workflow_terminal_node_counts', {}) or 'none'}",
                f"- Workflow route counts: {behavior.get('workflow_route_counts', {}) or 'none'}",
            ]
        )
    lines.extend([
        "",
        "## Changed Files",
        "",
    ])
    if record.changed_files:
        lines.extend([f"- `{path}`" for path in record.changed_files[:20]])
    else:
        lines.append("- none")
    lines.extend(["", "## Failed Cases", ""])
    if failed_cases:
        for item in failed_cases[:10]:
            lines.append(f"- `{item['case_id']}`: {item['reason']}")
    else:
        lines.append("- none")
    return "\n".join(lines)
