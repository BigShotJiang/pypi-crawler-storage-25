from __future__ import annotations

import os
import re
import shutil
import tomllib
from collections import Counter
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, load_model
from agentworkbench.models import AgentSpec
from agentworkbench.reports import render_repo_brief, write_report
from agentworkbench.utils import ensure_dir, write_json

IGNORED_DIRS = {
    ".git",
    ".agent-workbench",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".tox",
    ".nox",
    "node_modules",
    ".venv",
    "venv",
    "dist",
    "build",
}

ENTRYPOINT_CANDIDATES = {
    "__main__.py",
    "app.py",
    "cli.py",
    "index.js",
    "index.ts",
    "main.py",
    "manage.py",
    "server.py",
}

ENTRYPOINT_IGNORED_PARTS = {
    "docs",
    "examples",
    "fixtures",
    "test",
    "tests",
}

LANGUAGE_MAP = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".md": "markdown",
    ".sh": "shell",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
}

TEXT_SUFFIXES = {
    ".env",
    ".example",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".mjs",
    ".py",
    ".sh",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}

PROMPT_HINTS = {"instruction", "instructions", "persona", "policy", "prompt", "prompts", "system"}
TOOL_HINTS = {"executor", "mcp", "mcp_server", "planner", "plugin", "plugins", "router", "skill", "skills", "tool", "tools"}
MEMORY_HINTS = {"memory", "rag", "retrieval", "session", "state", "vector"}
TEST_HINTS = {"benchmark", "eval", "fixture", "scorer", "test", "tests"}

PROVIDER_PATTERNS = {
    "openai": re.compile(r"\bopenai\b", re.IGNORECASE),
    "anthropic": re.compile(r"\banthropic\b", re.IGNORECASE),
    "azure-openai": re.compile(r"\bazure[\s_\-]*openai\b", re.IGNORECASE),
    "google-genai": re.compile(r"\bgoogle[\s_\-]*(genai|generativeai|gemini)\b", re.IGNORECASE),
    "litellm": re.compile(r"\blitellm\b", re.IGNORECASE),
    "langchain": re.compile(r"\blangchain\b", re.IGNORECASE),
}

ENV_KEY_PATTERN = re.compile(
    r"\b([A-Z][A-Z0-9_]*(?:API_KEY|BASE_URL|MODEL|ENDPOINT|ORG_ID|PROJECT_ID|DEPLOYMENT|TOKEN))\b"
)


def _is_ignored_path(path: Path) -> bool:
    return any(part in IGNORED_DIRS or part.endswith(".egg-info") for part in path.parts)


def _iter_repo_files(project_root: Path) -> list[Path]:
    files: list[Path] = []
    for path in project_root.rglob("*"):
        if _is_ignored_path(path.relative_to(project_root)):
            continue
        if path.is_file():
            files.append(path)
    return sorted(files)


def _safe_read_text(path: Path) -> str:
    if path.suffix.lower() not in TEXT_SUFFIXES and path.name.lower() not in {".env", ".env.example"}:
        return ""
    try:
        if path.stat().st_size > 200_000:
            return ""
    except OSError:
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def _guess_commands(project_root: Path) -> dict[str, str]:
    commands: dict[str, str] = {}
    python_executable = "python" if shutil.which("python") else ("python3" if shutil.which("python3") else "")
    if (project_root / "Makefile").exists():
        commands["test"] = "make test"
    elif (project_root / "pyproject.toml").exists() or (project_root / "requirements.txt").exists():
        commands["test"] = f"{python_executable} -m pytest" if python_executable else "pytest"
    if (project_root / "package.json").exists():
        commands.setdefault("test", "npm test")
        commands["install"] = "npm install"
    return commands


def _existing_eval_assets(files: list[Path], project_root: Path) -> list[str]:
    matches: list[str] = []
    for path in files:
        lowered = path.name.lower()
        if any(token in lowered for token in ["eval", "benchmark", "test"]):
            matches.append(str(path.relative_to(project_root)))
    return matches[:30]


def _existing_agent_assets(files: list[Path], project_root: Path) -> list[str]:
    matches: list[str] = []
    for path in files:
        relative = str(path.relative_to(project_root))
        lowered = relative.lower()
        if (
            path.name == "AGENTS.md"
            or lowered.startswith(".github/agents/")
            or lowered.startswith(".agent-workbench/agents/")
            or ".codex-plugin/" in lowered
            or any(token in lowered for token in ["prompt", "plugin", "mcp", "copilot", "codex"])
        ):
            matches.append(relative)
    return matches[:30]


def _candidate_files(files: list[Path], project_root: Path, hints: set[str], *, suffixes: set[str] | None = None) -> list[str]:
    matches: list[str] = []
    for path in files:
        relative = str(path.relative_to(project_root))
        lowered = relative.lower()
        name_tokens = set(token for token in re.split(r"[^a-z0-9]+", lowered) if token)
        if hints & name_tokens:
            if suffixes and path.suffix.lower() not in suffixes:
                continue
            matches.append(relative)
    return matches[:20]


def _provider_hints(files: list[Path]) -> tuple[list[str], list[str]]:
    providers: set[str] = set()
    env_keys: set[str] = set()
    for path in files:
        text = _safe_read_text(path)
        if not text:
            continue
        for name, pattern in PROVIDER_PATTERNS.items():
            if pattern.search(text):
                providers.add(name)
        for match in ENV_KEY_PATTERN.findall(text):
            env_keys.add(str(match))
    return sorted(providers), sorted(env_keys)


def _entrypoint_summary(spec: AgentSpec) -> str:
    command = spec.entrypoints.get("command")
    if isinstance(command, str):
        return command
    if isinstance(command, list):
        return " ".join(str(item) for item in command)
    if isinstance(command, dict):
        argv = command.get("argv")
        if argv:
            return " ".join(str(item) for item in argv)
        shell = command.get("shell")
        if shell:
            return str(shell)
    return ""


def _agent_ownership(project_root: Path) -> dict[str, Any]:
    agents_dir = control_dir(project_root) / "agents"
    if not agents_dir.exists():
        return {"agent_specs": {}, "confirmed_owned_files": [], "unclaimed_candidate_files": []}
    specs: dict[str, Any] = {}
    confirmed: set[str] = set()
    for path in sorted(agents_dir.glob("*.yaml")):
        try:
            spec = load_model(path, AgentSpec)
        except Exception:
            continue
        spec_paths = [str(item) for item in spec.owned_paths]
        surface_paths = {
            str(key): [str(item) for item in value or []]
            for key, value in spec.surface_paths.items()
            if value
        }
        for item in spec_paths:
            confirmed.add(item)
        for values in surface_paths.values():
            confirmed.update(values)
        specs[spec.id] = {
            "adapter": spec.adapter,
            "owned_paths": spec_paths,
            "owned_globs": [str(item) for item in spec.owned_globs],
            "surface_paths": surface_paths,
            "required_env": [str(item) for item in spec.required_env],
            "entrypoint": _entrypoint_summary(spec),
        }
    return {"agent_specs": specs, "confirmed_owned_files": sorted(confirmed)}


def _likely_entrypoints(files: list[Path], project_root: Path) -> list[str]:
    def sort_key(relative: str) -> tuple[int, int, str]:
        path = Path(relative)
        priority = 0
        if path.name == "cli.py":
            priority -= 2
        elif path.name == "__main__.py":
            priority -= 1
        return (priority, len(path.parts), relative)

    pyproject_targets: list[str] = []
    pyproject_path = project_root / "pyproject.toml"
    if pyproject_path.exists():
        try:
            payload = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            payload = {}
        scripts = ((payload.get("project") or {}).get("scripts") or {})
        for target in scripts.values():
            module_name = str(target).split(":", 1)[0].strip()
            if not module_name:
                continue
            module_path = project_root / Path(*module_name.split("."))
            file_path = module_path.with_suffix(".py")
            if file_path.exists():
                pyproject_targets.append(str(file_path.relative_to(project_root)))

    matches: list[str] = []
    for path in files:
        relative = path.relative_to(project_root)
        if any(part in ENTRYPOINT_IGNORED_PARTS for part in relative.parts):
            continue
        if path.name in ENTRYPOINT_CANDIDATES:
            matches.append(str(relative))
    ordered = list(dict.fromkeys([*pyproject_targets, *sorted(matches, key=sort_key)]))
    return ordered[:10]


def discover_repo(project_root: Path) -> dict[str, Any]:
    files = _iter_repo_files(project_root)
    languages = Counter(LANGUAGE_MAP.get(path.suffix, "other") for path in files)
    display_name = os.environ.get("AWB_HOST_PROJECT_NAME", project_root.name)
    display_root = os.environ.get("AWB_HOST_PROJECT_ROOT", str(project_root))
    likely_entrypoints = _likely_entrypoints(files, project_root)
    prompt_files = _candidate_files(files, project_root, PROMPT_HINTS, suffixes={".md", ".py", ".txt", ".yaml", ".yml"})
    tool_files = _candidate_files(files, project_root, TOOL_HINTS, suffixes={".js", ".py", ".ts", ".tsx", ".yaml", ".yml"})
    memory_files = _candidate_files(files, project_root, MEMORY_HINTS, suffixes={".js", ".json", ".py", ".ts", ".tsx", ".yaml", ".yml"})
    test_files = _candidate_files(files, project_root, TEST_HINTS)
    provider_hints, likely_env_keys = _provider_hints(files)
    ownership = _agent_ownership(project_root)
    candidate_agent_files = list(
        dict.fromkeys(
            [
                *likely_entrypoints,
                *prompt_files,
                *tool_files,
                *memory_files,
            ]
        )
    )
    confirmed_owned = set(ownership.get("confirmed_owned_files", []))
    summary = {
        "project_name": display_name,
        "project_root": display_root,
        "file_count": len(files),
        "languages": [language for language, _ in languages.most_common() if language != "other"],
        "likely_entrypoints": likely_entrypoints,
        "existing_agent_assets": _existing_agent_assets(files, project_root),
        "existing_evaluation_assets": _existing_eval_assets(files, project_root),
        "candidate_prompt_files": prompt_files,
        "candidate_tool_files": tool_files,
        "candidate_memory_files": memory_files,
        "candidate_test_files": test_files,
        "candidate_agent_files": candidate_agent_files[:30],
        "provider_hints": provider_hints,
        "likely_env_keys": likely_env_keys,
        "agent_specs": ownership.get("agent_specs", {}),
        "confirmed_owned_files": sorted(confirmed_owned),
        "unclaimed_candidate_files": [path for path in candidate_agent_files if path not in confirmed_owned][:30],
        "guessed_commands": _guess_commands(project_root),
        "top_files": [str(path.relative_to(project_root)) for path in files[:50]],
        "suggested_user_questions": [
            "What end-user tasks should the target agent handle reliably?",
            "Which failure modes are unacceptable for this target agent?",
            "What does a strong answer or workflow look like on the hardest user requests?",
            "Which prompts, tools, memory, plugins, or MCP integrations should the target agent rely on or avoid?",
            "Which files in the repo actually define the target agent behavior today?",
            "What latency, cost, or step-budget limits matter for this agent?",
        ],
    }
    discovery_dir = ensure_dir(control_dir(project_root) / "discovery")
    write_json(discovery_dir / "repo-summary.json", summary)
    write_report(discovery_dir / "repo-brief.md", render_repo_brief(summary))
    return summary
