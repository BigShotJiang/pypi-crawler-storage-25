from __future__ import annotations

import re
from typing import Any

_ALNUM_PATTERN = re.compile(r"[a-z0-9]+")


def normalized_alnum_text(value: Any) -> str:
    return " ".join(_ALNUM_PATTERN.findall(str(value or "").lower()))
