from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, dump_model, load_model
from agentworkbench.models import BehaviorBrief
from agentworkbench.utils import created_at_utc, read_json, read_jsonl, write_json, write_jsonl


def review_answers_path(project_root: Path) -> Path:
    return control_dir(project_root) / "human-review" / "answers.json"


def load_review_answers(project_root: Path) -> list[dict[str, Any]]:
    path = review_answers_path(project_root)
    if not path.exists():
        return []
    payload = read_json(path)
    answers = payload.get("answers") if isinstance(payload, dict) else payload
    if not isinstance(answers, list):
        return []
    return [dict(item) for item in answers if isinstance(item, dict)]


def save_review_answers(project_root: Path, answers: list[dict[str, Any]]) -> Path:
    payload = {"answers": answers}
    return write_json(review_answers_path(project_root), payload)


def _answer_key(answer: dict[str, Any]) -> tuple[str, str]:
    return (str(answer.get("queue_id") or ""), str(answer.get("checkpoint_id") or ""))


def _upsert_answer(answers: list[dict[str, Any]], answer_record: dict[str, Any]) -> list[dict[str, Any]]:
    updated = [dict(item) for item in answers]
    key = _answer_key(answer_record)
    for index, existing in enumerate(updated):
        if _answer_key(existing) == key:
            updated[index] = dict(answer_record)
            break
    else:
        updated.append(dict(answer_record))
    return updated


def _load_review_queue(project_root: Path, queue_id: str) -> dict[str, Any]:
    reports_dir = control_dir(project_root) / "reports"
    for path in sorted(reports_dir.glob("*review-queue*.json")):
        try:
            payload = read_json(path)
        except Exception:
            continue
        if str((payload or {}).get("queue_id") or "") == str(queue_id):
            return dict(payload)
    return {}


def _queue_item(queue: dict[str, Any], checkpoint_id: str) -> dict[str, Any]:
    for item in queue.get("items") or []:
        if str((item or {}).get("checkpoint_id") or "") == str(checkpoint_id):
            return dict(item)
    return {}


def _upsert_applied_entry(entries: list[dict[str, Any]], entry: dict[str, Any]) -> list[dict[str, Any]]:
    updated = [dict(item) for item in entries if isinstance(item, dict)]
    entry_key = (
        str(entry.get("queue_id") or ""),
        str(entry.get("checkpoint_id") or ""),
        tuple(sorted(str(case_id) for case_id in entry.get("related_case_ids") or [] if str(case_id).strip())),
    )
    for index, existing in enumerate(updated):
        existing_key = (
            str(existing.get("queue_id") or ""),
            str(existing.get("checkpoint_id") or ""),
            tuple(sorted(str(case_id) for case_id in existing.get("related_case_ids") or [] if str(case_id).strip())),
        )
        if existing_key == entry_key:
            updated[index] = dict(entry)
            break
    else:
        updated.append(dict(entry))
    return updated


def _applied_entry(
    answer: dict[str, Any], queue_item: dict[str, Any], *, related_case_ids: list[str]
) -> dict[str, Any]:
    return {
        "queue_id": str(answer.get("queue_id") or ""),
        "checkpoint_id": str(answer.get("checkpoint_id") or ""),
        "decision": str(answer.get("decision") or "").strip(),
        "guidance": str(answer.get("guidance") or "").strip(),
        "answer": str(answer.get("answer") or ""),
        "reviewer": str(answer.get("reviewer") or "human"),
        "resolved_at": str(answer.get("resolved_at") or ""),
        "review_type": str(queue_item.get("review_type") or ""),
        "question_type": str(queue_item.get("question_type") or ""),
        "response_mode": str(queue_item.get("response_mode") or ""),
        "related_case_ids": sorted({str(case_id) for case_id in related_case_ids if str(case_id).strip()}),
    }


def _review_payload(container: dict[str, Any]) -> dict[str, Any]:
    payload = dict(container.get("human_review") or {})
    applied_answers = payload.get("applied_answers")
    if not isinstance(applied_answers, list):
        payload["applied_answers"] = []
    return payload


def _apply_to_brief(
    project_root: Path, brief_id: str, answer: dict[str, Any], queue_item: dict[str, Any], *, dry_run: bool
) -> dict[str, Any]:
    path = control_dir(project_root) / "briefs" / f"{brief_id}.yaml"
    brief = load_model(path, BehaviorBrief)
    metadata = dict(brief.metadata or {})
    review_payload = _review_payload(metadata)
    entry = _applied_entry(answer, queue_item, related_case_ids=[])
    review_payload["applied_answers"] = _upsert_applied_entry(review_payload.get("applied_answers") or [], entry)
    review_payload["resolved_checkpoint_ids"] = sorted(
        {
            *[
                str(item.get("checkpoint_id") or "")
                for item in review_payload.get("applied_answers") or []
                if str(item.get("checkpoint_id") or "").strip()
            ],
            str(answer.get("checkpoint_id") or ""),
        }
    )
    metadata["human_review"] = review_payload
    if not dry_run:
        brief.metadata = metadata
        dump_model(path, brief)
    return {"artifact_kind": "brief", "artifact_id": brief_id, "updated_paths": [str(path)]}


def _apply_to_eval_suite(
    project_root: Path,
    eval_id: str,
    answer: dict[str, Any],
    queue_item: dict[str, Any],
    *,
    dry_run: bool,
) -> dict[str, Any]:
    from agentworkbench.evals import eval_path, load_eval_suite, suite_path

    suite = load_eval_suite(project_root, eval_id)
    suite_metadata = dict(suite.metadata or {})
    suite_review = _review_payload(suite_metadata)
    related_case_ids = answer.get("related_case_ids") or queue_item.get("related_case_ids") or []
    entry = _applied_entry(answer, queue_item, related_case_ids=related_case_ids)
    suite_review["applied_answers"] = _upsert_applied_entry(suite_review.get("applied_answers") or [], entry)
    suite_review["resolved_checkpoint_ids"] = sorted(
        {
            *[
                str(item.get("checkpoint_id") or "")
                for item in suite_review.get("applied_answers") or []
                if str(item.get("checkpoint_id") or "").strip()
            ],
            str(answer.get("checkpoint_id") or ""),
        }
    )
    suite_metadata["human_review"] = suite_review
    updated_paths = [str(suite_path(project_root, eval_id))]

    case_rows = [dict(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    case_ids = sorted({str(case_id) for case_id in related_case_ids if str(case_id).strip()})
    if case_ids:
        updated_paths.append(str(eval_path(project_root, eval_id)))
    for index, row in enumerate(case_rows):
        case_id = str(row.get("id") or "")
        if case_ids and case_id not in case_ids:
            continue
        metadata = dict(row.get("metadata") or {})
        case_review = _review_payload(metadata)
        case_entry = _applied_entry(answer, queue_item, related_case_ids=[case_id] if case_id else [])
        case_review["applied_answers"] = _upsert_applied_entry(case_review.get("applied_answers") or [], case_entry)
        case_review.update(
            {
                "required": False,
                "resolved": True,
                "decision": str(answer.get("decision") or "").strip(),
                "guidance": str(answer.get("guidance") or "").strip(),
                "review_type": str(queue_item.get("review_type") or case_review.get("review_type") or ""),
                "question_type": str(queue_item.get("question_type") or case_review.get("question_type") or ""),
                "response_mode": str(queue_item.get("response_mode") or case_review.get("response_mode") or ""),
                "source_queue_id": str(answer.get("queue_id") or ""),
                "resolved_at": str(answer.get("resolved_at") or ""),
            }
        )
        metadata["human_review"] = case_review
        case_rows[index] = {
            **row,
            "metadata": metadata,
        }

    if not dry_run:
        suite.metadata = suite_metadata
        dump_model(suite_path(project_root, eval_id), suite)
        if case_ids:
            write_jsonl(eval_path(project_root, eval_id), case_rows)
    return {"artifact_kind": "eval", "artifact_id": eval_id, "updated_paths": updated_paths, "case_ids": case_ids}


def _diagnose_eval_id(project_root: Path, experiment_id: str) -> str | None:
    try:
        from agentworkbench.config import experiment_dir
    except Exception:
        return None
    try:
        path = experiment_dir(project_root, experiment_id) / "experiment.json"
    except Exception:
        return None
    if not path.exists():
        return None
    payload = read_json(path)
    eval_id = str((payload or {}).get("eval_id") or "").strip()
    return eval_id or None


def apply_review_answers(
    project_root: Path,
    *,
    queue_id: str | None = None,
    checkpoint_id: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    answers = load_review_answers(project_root)
    filtered = [
        dict(answer)
        for answer in answers
        if (queue_id is None or str(answer.get("queue_id") or "") == str(queue_id))
        and (checkpoint_id is None or str(answer.get("checkpoint_id") or "") == str(checkpoint_id))
    ]
    applied: list[dict[str, Any]] = []
    touched_briefs: set[str] = set()
    touched_evals: set[str] = set()

    for answer in filtered:
        queue_name = str(answer.get("queue_id") or "")
        item_name = str(answer.get("checkpoint_id") or "")
        if not queue_name or not item_name:
            continue
        queue = _load_review_queue(project_root, queue_name)
        queue_item = _queue_item(queue, item_name)
        if queue_name.startswith("brief-"):
            brief_id = queue_name[len("brief-") :]
            if brief_id:
                applied.append(_apply_to_brief(project_root, brief_id, answer, queue_item, dry_run=dry_run))
                touched_briefs.add(brief_id)
        elif queue_name.startswith("eval-"):
            eval_id = queue_name[len("eval-") :]
            if eval_id:
                applied.append(_apply_to_eval_suite(project_root, eval_id, answer, queue_item, dry_run=dry_run))
                touched_evals.add(eval_id)
        elif queue_name.startswith("diagnose-"):
            experiment_id = queue_name[len("diagnose-") :]
            diagnose_eval_id = _diagnose_eval_id(project_root, experiment_id)
            if diagnose_eval_id:
                applied.append(_apply_to_eval_suite(project_root, diagnose_eval_id, answer, queue_item, dry_run=dry_run))
                touched_evals.add(diagnose_eval_id)

    if not dry_run:
        for brief_id in sorted(touched_briefs):
            try:
                from agentworkbench.briefs import build_brief_packet

                build_brief_packet(project_root, brief_id)
            except Exception:
                continue
        for eval_id in sorted(touched_evals):
            try:
                from agentworkbench.evals import review_eval_suite

                review_eval_suite(project_root, eval_id)
            except Exception:
                continue

    updated_paths = sorted({path for item in applied for path in item.get("updated_paths") or []})
    payload = {
        "applied_answer_count": len(filtered),
        "artifact_update_count": len(applied),
        "updated_paths": updated_paths,
        "artifacts": applied,
        "dry_run": dry_run,
    }
    return payload


def record_review_answer(
    project_root: Path,
    *,
    queue_id: str,
    checkpoint_id: str,
    answer: str = "",
    decision: str | None = None,
    guidance: str | None = None,
    related_case_ids: list[str] | None = None,
    reviewer: str = "human",
    apply_to_artifacts: bool = True,
) -> dict[str, Any]:
    answers = load_review_answers(project_root)
    answer_record: dict[str, Any] = {
        "queue_id": str(queue_id),
        "checkpoint_id": str(checkpoint_id),
        "answer": str(answer or ""),
        "decision": str(decision or "").strip(),
        "guidance": str(guidance or "").strip(),
        "related_case_ids": sorted({str(item) for item in (related_case_ids or []) if str(item).strip()}),
        "reviewer": str(reviewer or "human"),
        "resolved_at": created_at_utc(),
    }
    answers = _upsert_answer(answers, answer_record)
    save_review_answers(project_root, answers)
    apply_summary: dict[str, Any] = {
        "applied_answer_count": 0,
        "artifact_update_count": 0,
        "updated_paths": [],
        "artifacts": [],
    }
    if apply_to_artifacts:
        apply_summary = apply_review_answers(
            project_root,
            queue_id=queue_id,
            checkpoint_id=checkpoint_id,
            dry_run=False,
        )
        updated_paths = apply_summary.get("updated_paths")
        answer_record["applied_paths"] = list(updated_paths) if isinstance(updated_paths, list) else []
        artifact_update_count = apply_summary.get("artifact_update_count", 0)
        answer_record["artifact_update_count"] = int(artifact_update_count) if isinstance(artifact_update_count, int | float | str) else 0
        answers = _upsert_answer(answers, answer_record)
        save_review_answers(project_root, answers)
    answer_record["apply_summary"] = apply_summary
    return answer_record


def _answer_matches_item(answer: dict[str, Any], queue_id: str, item: dict[str, Any]) -> bool:
    if str(answer.get("queue_id") or "") != str(queue_id):
        return False
    if str(answer.get("checkpoint_id") or "") != str(item.get("checkpoint_id") or ""):
        return False
    answer_cases = {str(case_id) for case_id in answer.get("related_case_ids") or [] if str(case_id).strip()}
    item_cases = {str(case_id) for case_id in item.get("related_case_ids") or [] if str(case_id).strip()}
    if not answer_cases or not item_cases:
        return True
    return bool(answer_cases & item_cases)


def resolve_review_queue(project_root: Path, queue: dict[str, Any]) -> dict[str, Any]:
    resolved = dict(queue or {})
    items = [dict(item) for item in resolved.get("items") or [] if isinstance(item, dict)]
    answers = load_review_answers(project_root)
    queue_id = str(resolved.get("queue_id") or "")
    pending_count = 0
    resolved_count = 0
    for item in items:
        matching = next((answer for answer in answers if _answer_matches_item(answer, queue_id, item)), None)
        if matching:
            item["status"] = "resolved"
            item["resolution"] = {
                "answer": matching.get("answer"),
                "decision": matching.get("decision"),
                "guidance": matching.get("guidance"),
                "reviewer": matching.get("reviewer"),
                "resolved_at": matching.get("resolved_at"),
                "applied_paths": matching.get("applied_paths") or [],
            }
            resolved_count += 1
        else:
            item["status"] = "pending"
            pending_count += 1
    resolved["items"] = items
    resolved["pending_count"] = pending_count
    resolved["resolved_count"] = resolved_count
    resolved["all_resolved"] = bool(items) and pending_count == 0
    return resolved


def pending_review_items(queue: dict[str, Any]) -> list[dict[str, Any]]:
    return [dict(item) for item in queue.get("items") or [] if str(item.get("status") or "pending") != "resolved"]


def load_review_queue_payload(project_root: Path, queue_id: str) -> dict[str, Any]:
    queue = _load_review_queue(project_root, queue_id)
    if not queue:
        return {}
    return resolve_review_queue(project_root, queue)


def list_review_queues(project_root: Path, *, pending_only: bool = False) -> dict[str, Any]:
    reports_dir = control_dir(project_root) / "reports"
    queue_payloads: dict[str, dict[str, Any]] = {}
    for path in sorted(reports_dir.glob("*review-queue*.json")):
        try:
            payload = read_json(path)
        except Exception:
            continue
        if not isinstance(payload, dict) or not str(payload.get("queue_id") or "").strip():
            continue
        queue_payloads[str(payload["queue_id"])] = resolve_review_queue(project_root, payload)
    queues = list(queue_payloads.values())
    if pending_only:
        queues = [item for item in queues if int(item.get("pending_count", 0)) > 0]
    return {
        "queue_count": len(queues),
        "pending_queue_count": sum(1 for item in queues if int(item.get("pending_count", 0)) > 0),
        "queues": queues,
    }


__all__ = [
    "apply_review_answers",
    "load_review_queue_payload",
    "list_review_queues",
    "load_review_answers",
    "pending_review_items",
    "record_review_answer",
    "resolve_review_queue",
    "review_answers_path",
    "save_review_answers",
]
