"""Human-in-the-Loop Integration with Hints.

This module provides intelligent human integration that asks for small hints
rather than full answers, minimizing human effort while maximizing learning.

Philosophy:
- Instead of "What's wrong?" → Ask "Try higher temperature?"
- Instead of "What do you want?" → Ask "Is latency more important than cost?"
- Ask minimal questions to resolve uncertainty

Usage:
    from agentworkbench.human_integration import HumanHintSystem

    hint_system = HumanHintSystem(
        confidence_threshold=0.4,
        hint_kinds=["direction", "priority", "alternative"],
    )

    # Should we ask for hint?
    if hint_system.should_ask(experiment_result):
        hint = hint_system.generate_hint(experiment_result)
        print(f"Quick question: {hint.question}")

    # Record human hint response
    hint_system.record_hint(hint, human_response)

    # Use hints to improve optimization
    learned_direction = hint_system.get_learned_direction()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class HintKind(Enum):
    """Types of hints we can ask for."""

    DIRECTION = "direction"  # "try higher/lower X"
    PRIORITY = "priority"  # "X matters more than Y"
    ALTERNATIVE = "alternative"  # "consider X instead"
    CORRECTION = "correction"  # "you're close but X"


@dataclass
class Hint:
    """A single hint question."""

    kind: HintKind
    question: str
    options: list[str]
    context: dict[str, Any]
    answered: bool = False
    answer: str | None = None


@dataclass
class LearnedHint:
    """What we've learned from human hints."""

    direction_adjustments: dict[str, float] = field(default_factory=dict)
    priority_rankings: list[tuple[str, float]] = field(default_factory=list)
    alternatives: dict[str, str] = field(default_factory=dict)
    corrections: list[dict[str, Any]] = field(default_factory=list)


class HumanHintSystem:
    """System for intelligent hint-based human interaction.

    Goal: Ask minimal questions that have maximum impact.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.4,
        hint_kinds: list[str] | None = None,
        max_attempts: int = 3,
    ):
        self.confidence_threshold = confidence_threshold
        self.hint_kinds = hint_kinds or ["direction", "priority", "alternative"]
        self.max_attempts = max_attempts

        self._hints: list[Hint] = []
        self._learned = LearnedHint()
        self._attempt_count: dict[str, int] = {}

    def should_ask(
        self,
        experiment_result: dict[str, Any],
    ) -> bool:
        """Decide if we should ask for human input.

        Args:
            experiment_result: Result dict with confidence, scores, etc.

        Returns:
            True if we should ask a hint
        """
        # Check confidence
        confidence = experiment_result.get("confidence", 0.5)
        if confidence > self.confidence_threshold:
            return False

        # Check if we've asked too many times
        exp_id = experiment_result.get("experiment_id", "")
        if self._attempt_count.get(exp_id, 0) >= self.max_attempts:
            return False

        # Check if there's actionable uncertainty
        score_stddev = experiment_result.get("score_stddev", 0)
        if score_stddev < 0.1:
            return False

        return True

    def generate_hint(
        self,
        experiment_result: dict[str, Any],
    ) -> Hint | None:
        """Generate a hint question based on experiment state.

        Args:
            experiment_result: Current experiment result

        Returns:
            Hint question to ask human, or None if no appropriate hint
        """
        # Analyze what's uncertain
        uncertain_params = self._find_uncertain_params(experiment_result)

        if not uncertain_params:
            return None

        # Pick cheapest hint kind
        kind = self._select_hint_kind(uncertain_params)

        if kind == HintKind.DIRECTION:
            return self._generate_direction_hint(uncertain_params)
        elif kind == HintKind.PRIORITY:
            return self._generate_priority_hint(experiment_result)
        elif kind == HintKind.ALTERNATIVE:
            return self._generate_alternative_hint(uncertain_params)

        return None

    def _find_uncertain_params(
        self,
        result: dict[str, Any],
    ) -> dict[str, float]:
        """Find parameters with high uncertainty."""
        uncertain = {}

        # Temperature
        temp = result.get("temperature", 0.5)
        if temp < 0.3 or temp > 0.7:
            uncertain["temperature"] = abs(temp - 0.5) * 2

        # Max tokens
        tokens = result.get("max_tokens", 1024)
        if tokens < 512 or tokens > 2048:
            uncertain["max_tokens"] = 0.3

        # Tools enabled
        n_tools = result.get("tool_count", 0)
        if n_tools < 2:
            uncertain["tools"] = 0.4

        return uncertain

    def _select_hint_kind(
        self,
        uncertain_params: dict[str, float],
    ) -> HintKind:
        """Select most appropriate hint type."""
        # Simple priority
        if "temperature" in uncertain_params:
            return HintKind.DIRECTION
        if "tools" in uncertain_params:
            return HintKind.PRIORITY
        return HintKind.ALTERNATIVE

    def _generate_direction_hint(
        self,
        params: dict[str, float],
    ) -> Hint:
        """Generate direction hint (higher/lower)."""
        options = []
        question = "Quick hint: For this agent, should we "

        if "temperature" in params:
            current = params.get("temperature", 0.5)
            direction = "higher" if current < 0.5 else "lower"
            question += f"try {direction} temperature?"
            options = ["yes", "no", "doesn't matter"]

        if "max_tokens" in params:
            question += " try larger/smaller max_tokens?"
            options = ["larger", "smaller", "doesn't matter"]

        return Hint(
            kind=HintKind.DIRECTION,
            question=question,
            options=options,
            context=params,
        )

    def _generate_priority_hint(
        self,
        result: dict[str, Any],
    ) -> Hint:
        """Generate priority hint (what matters more?)."""
        # Compare metrics
        latency = result.get("average_latency_ms", 1000)
        cost = result.get("average_cost_estimate", 1.0)

        question = "Quick hint: For this use case, is "

        if latency > 1000 and cost > 0.5:
            question += "latency or cost more important?"
            options = ["latency", "cost", "neither"]
        else:
            question += "quality or speed more important?"
            options = ["quality", "speed", "neither"]

        return Hint(
            kind=HintKind.PRIORITY,
            question=question,
            options=options,
            context=result,
        )

    def _generate_alternative_hint(
        self,
        params: dict[str, float],
    ) -> Hint:
        """Generate alternative hint."""
        question = "Quick hint: Instead of current approach, consider:"
        options = ["different tool", "different prompt", "chain agents"]

        return Hint(
            kind=HintKind.ALTERNATIVE,
            question=question,
            options=options,
            context=params,
        )

    def record_hint(self, hint: Hint, answer: str) -> None:
        """Record human's hint answer.

        Args:
            hint: The hint that was asked
            answer: Human's response
        """
        hint.answered = True
        hint.answer = answer
        self._hints.append(hint)

        # Update learned model
        self._learn_from_hint(hint, answer)

    def _learn_from_hint(self, hint: Hint, answer: str) -> None:
        """Update learned model from hint."""
        if hint.kind == HintKind.DIRECTION:
            param = list(hint.context.keys())[0]
            if answer in ("yes", "higher", "larger"):
                self._learned.direction_adjustments[param] = 0.1
            elif answer in ("no", "lower", "smaller"):
                self._learned.direction_adjustments[param] = -0.1

        elif hint.kind == HintKind.PRIORITY:
            if answer:
                self._learned.priority_rankings.append((answer, 1.0))

        elif hint.kind == HintKind.ALTERNATIVE:
            if answer:
                self._learned.alternatives[hint.kind.value] = answer

    def get_learned_direction(self) -> dict[str, float]:
        """Get learned parameter adjustments."""
        return self._learned.direction_adjustments.copy()

    def get_priority_rankings(self) -> list[tuple[str, float]]:
        """Get learned priority rankings."""
        return self._learned.priority_rankings.copy()

    def get_alternatives(self) -> dict[str, str]:
        """Get learned alternatives."""
        return self._learned.alternatives.copy()


class HintIntegration:
    """Integrates hints into the optimization loop.

    This coordinates between active learning, human hints,
    and the optimization process.
    """

    def __init__(self):
        self._hint_system = HumanHintSystem()

    def should_request_hint(
        self,
        experiment_result: dict[str, Any],
    ) -> bool:
        """Check if we need human input."""
        return self._hint_system.should_ask(experiment_result)

    def get_hint_for_experiment(
        self,
        experiment_result: dict[str, Any],
    ) -> Hint | None:
        """Get hint for current experiment."""
        return self._hint_system.generate_hint(experiment_result)

    def apply_hint_to_suggestion(
        self,
        suggestion: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply learned hints to parameter suggestion."""
        learned = self._hint_system.get_learned_direction()

        # Adjust suggestion based on learned direction
        adjusted = suggestion.copy()

        for param, direction in learned.items():
            if param in adjusted:
                if isinstance(adjusted[param], (int, float)):
                    adjusted[param] += direction

        return adjusted

    def incorporate_feedback(
        self,
        hint: Hint,
        answer: str,
    ) -> None:
        """Incorporate hint answer into learning."""
        self._hint_system.record_hint(hint, answer)


def create_hint_system(
    confidence_threshold: float = 0.4,
    hint_kinds: list[str] | None = None,
) -> HumanHintSystem:
    """Create a configured hint system."""
    return HumanHintSystem(
        confidence_threshold=confidence_threshold,
        hint_kinds=hint_kinds,
    )


__all__ = [
    "HintKind",
    "Hint",
    "LearnedHint",
    "HumanHintSystem",
    "HintIntegration",
    "create_hint_system",
]
