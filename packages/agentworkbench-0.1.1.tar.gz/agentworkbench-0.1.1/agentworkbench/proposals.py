from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, load_model
from agentworkbench.evals import scorer_path, split_path, suite_path
from agentworkbench.models import AgentSpec, MutationProposal
from agentworkbench.reports import render_proposals_report, write_report
from agentworkbench.runner import diagnose_experiment
from agentworkbench.surface_recommendations import matching_surface_recommendations, retrieval_surface_focus
from agentworkbench.utils import ensure_dir, read_json, write_json


def proposals_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "proposals")


def _agent_spec_path(project_root: Path, agent_id: str) -> str:
    return str((control_dir(project_root) / "agents" / f"{agent_id}.yaml").relative_to(project_root))


def _brief_path(project_root: Path, brief_id: str) -> str:
    return str((control_dir(project_root) / "briefs" / f"{brief_id}.yaml").relative_to(project_root))


def _load_agent_spec(project_root: Path, agent_id: str) -> AgentSpec | None:
    if not agent_id:
        return None
    path = control_dir(project_root) / "agents" / f"{agent_id}.yaml"
    if not path.exists():
        return None
    return load_model(path, AgentSpec)


def _load_discovery_summary(project_root: Path) -> dict[str, Any]:
    path = control_dir(project_root) / "discovery" / "repo-summary.json"
    return read_json(path) if path.exists() else {}


def _resolved_owned_globs(project_root: Path, spec: AgentSpec | None) -> list[str]:
    if spec is None:
        return []
    matches: list[str] = []
    for pattern in spec.owned_globs:
        for path in sorted(project_root.glob(pattern)):
            if path.is_file():
                matches.append(str(path.relative_to(project_root)))
    return list(dict.fromkeys(matches))


def _discovery_files_for_surface(discovery: dict[str, Any], surface: str) -> list[str]:
    mapping = {
        "instructions": ["candidate_prompt_files", "candidate_agent_files"],
        "model": ["candidate_agent_files", "candidate_prompt_files"],
        "prompts": ["candidate_prompt_files"],
        "tools": ["candidate_tool_files"],
        "skills": ["candidate_tool_files"],
        "plugins": ["candidate_tool_files"],
        "mcps": ["candidate_memory_files", "candidate_tool_files"],
        "memory": ["candidate_memory_files"],
        "runtime": ["likely_entrypoints", "candidate_agent_files"],
        "tests": ["candidate_test_files"],
    }
    files: list[str] = []
    for key in mapping.get(surface, []):
        files.extend(str(item) for item in discovery.get(key, []) or [])
    return list(dict.fromkeys(files))


def _category_surface_keys(category: str) -> list[str]:
    mapping = {
        "code_structure": ["runtime", "prompts", "tools", "tests"],
        "agent_topology": ["runtime", "prompts", "tools", "tests"],
        "eval_contract": ["tests", "tools", "mcps", "prompts"],
        "deterministic_fallback": ["runtime", "prompts", "tools", "tests"],
        "retrieval_quality": ["tools", "mcps", "memory", "runtime", "prompts"],
        "prompt_grounding": ["instructions", "prompts"],
        "surface_contract": ["tools", "skills", "plugins", "mcps", "memory", "runtime", "prompts"],
        "tool_routing": ["tools", "skills", "plugins", "mcps", "memory", "runtime", "prompts"],
        "step_budget": ["runtime", "instructions", "prompts", "tests"],
        "cost_budget": ["runtime", "instructions", "prompts", "tools", "skills", "plugins", "mcps", "memory", "model", "tests"],
        "surface_pruning": ["prompts", "tools", "skills", "plugins", "mcps", "memory", "runtime"],
        "stability_validation": ["runtime", "model", "tests"],
    }
    return mapping.get(category, [])


def _loop_check_findings(diagnosis: dict[str, Any], category: str) -> list[dict[str, Any]]:
    return [
        dict(item)
        for item in (diagnosis.get("loop_checks") or {}).get("findings", []) or []
        if str((item or {}).get("category") or "") == category
    ]


def _owned_target_files(project_root: Path, spec: AgentSpec | None, category: str) -> list[str]:
    if spec is None:
        return []
    files: list[str] = []
    surface_keys = _category_surface_keys(category)
    for key in surface_keys:
        files.extend(str(path) for path in (spec.surface_paths.get(key) or []))
    if files:
        return list(dict.fromkeys(files))
    files.extend(str(path) for path in spec.owned_paths)
    files.extend(_resolved_owned_globs(project_root, spec))
    return list(dict.fromkeys(files))


def _changed_target_files(diagnosis: dict[str, Any], category: str) -> list[str]:
    summary = diagnosis.get("repo_change_summary") or {}
    detail_changes = diagnosis.get("surface_detail_changes") or {}
    surface_files = summary.get("surface_files") or {}
    files: list[str] = []
    for item in _loop_check_findings(diagnosis, category):
        files.extend(str(path) for path in item.get("target_files", []) or [])
    if category == "benchmark_hygiene":
        files.extend(str(path) for path in summary.get("benchmark_files", []) or [])
    detail_mapping = {
        "retrieval_quality": ["tool_docstring_changes", "tool_schema_changes", "tool_config_changes", "mcp_config_changes"],
        "prompt_grounding": ["prompt_section_changes", "prompt_config_changes"],
        "surface_contract": [
            "tool_docstring_changes",
            "tool_schema_changes",
            "tool_format_changes",
            "tool_config_changes",
            "plugin_config_changes",
            "mcp_config_changes",
            "runtime_config_changes",
        ],
        "tool_routing": [
            "tool_docstring_changes",
            "tool_schema_changes",
            "tool_format_changes",
            "tool_config_changes",
            "plugin_config_changes",
            "mcp_config_changes",
            "runtime_config_changes",
        ],
        "cost_budget": ["runtime_config_changes", "tool_format_changes", "mcp_config_changes", "tool_config_changes"],
        "stability_validation": ["runtime_config_changes"],
    }
    for key in detail_mapping.get(category, []):
        for item in detail_changes.get(key, []) or []:
            files.append(str(item).split("::", 1)[0])
    for surface in _category_surface_keys(category):
        files.extend(str(path) for path in surface_files.get(surface, []) or [])
    if category in {"prompt_grounding", "surface_contract", "tool_routing", "step_budget", "cost_budget", "surface_pruning", "stability_validation"}:
        files.extend(str(path) for path in summary.get("agent_spec_files", []) or [])
    return list(dict.fromkeys(files))


def _priority(category: str) -> str:
    if category in {
        "code_structure",
        "agent_topology",
        "eval_contract",
        "deterministic_fallback",
        "retrieval_quality",
        "prompt_grounding",
        "surface_contract",
        "tool_routing",
        "benchmark_hygiene",
        "stability_validation",
    }:
        return "high"
    if category in {"step_budget", "cost_budget", "surface_pruning"}:
        return "medium"
    return "low"


def _priority_rank(priority: str) -> int:
    return {"high": 3, "medium": 2, "low": 1}.get(priority, 0)


def _supporting_clusters(category: str, diagnosis: dict[str, Any]) -> list[str]:
    cluster_mapping = {
        "code_structure": set(),
        "agent_topology": {"routing_regression", "step_overhead"},
        "eval_contract": {"surface_contract_violation", "benchmark_drift"},
        "deterministic_fallback": {"benchmark_drift", "output_regression"},
        "benchmark_hygiene": {"benchmark_drift"},
        "retrieval_quality": {"retrieval_gap"},
        "prompt_grounding": {"prompt_regression", "output_regression", "response_structure_gap"},
        "surface_contract": {"surface_contract_violation"},
        "tool_routing": {"routing_regression", "trace_regression", "memory_gap", "tool_failure", "mcp_failure"},
        "step_budget": {"step_overhead"},
        "cost_budget": {"step_overhead", "surface_bloat"},
        "surface_pruning": {"surface_bloat"},
        "stability_validation": {"provider_auth_failure", "provider_failure", "provider_rate_limit", "provider_timeout"},
    }
    supported = cluster_mapping.get(category, set())
    clusters = []
    for item in diagnosis.get("failure_clusters", []) or []:
        cluster_id = str(item.get("cluster_id") or item.get("category") or "")
        if cluster_id in supported:
            clusters.append(cluster_id)
    return clusters


def _supporting_trace_events(category: str, diagnosis: dict[str, Any]) -> list[str]:
    behavior_deltas = diagnosis.get("behavior_deltas") or {}
    labels = list(
        dict.fromkeys(
            [
                *[str(item) for item in behavior_deltas.get("trace_events_added", []) or []],
                *[str(item) for item in behavior_deltas.get("trace_events_removed", []) or []],
            ]
        )
    )
    predicates = {
        "benchmark_hygiene": lambda label: False,
        "code_structure": lambda label: label.startswith(("prompt:", "tool:", "mcp:", "provider_request:", "budget:")),
        "agent_topology": lambda label: label.startswith(("decision:", "routing:", "workflow:", "planning:", "budget:")),
        "eval_contract": lambda label: label.startswith(("tool:", "mcp:", "prompt:", "decision:", "workflow:")),
        "deterministic_fallback": lambda label: label.startswith(("prompt:", "provider_response:", "budget:")),
        "retrieval_quality": lambda label: label.startswith("retrieval:") or label.startswith("memory_lookup:"),
        "prompt_grounding": lambda label: label.startswith("prompt:") or label.startswith("prompt_load:") or "reviewer" in label,
        "surface_contract": lambda label: label.startswith(("tool:", "mcp:", "tool_call:", "memory_lookup:", "retrieval:", "decision:")),
        "tool_routing": lambda label: label.startswith(("tool:", "planning:", "skill:", "plugin:", "mcp:", "decision:memory_")),
        "step_budget": lambda label: label.startswith("budget:"),
        "cost_budget": lambda label: label.startswith(("provider_request:", "provider_response:", "budget:", "planning:")),
        "surface_pruning": lambda label: label.startswith(("tool:", "plugin:", "mcp:", "prompt:")),
        "stability_validation": lambda label: label.startswith(("provider_request:", "provider_response:", "budget:", "decision:")),
    }
    predicate = predicates.get(category, lambda label: False)
    return [label for label in labels if predicate(label)][:6]


def _proposal_surface_recommendations(diagnosis: dict[str, Any], category: str) -> list[dict[str, Any]]:
    recommendations = diagnosis.get("surface_recommendations") or []
    category_recommendations = {
        "retrieval_quality": {"keep_enabled", "keep_enabled_fix_grounding", "improve_grounding", "exercise_surface_in_routing", "keep_with_interaction"},
        "tool_routing": {"keep_enabled", "exercise_surface_in_routing", "keep_with_interaction"},
        "surface_pruning": {"prune_or_disable", "replace_or_disable", "unused_available", "overhead_candidate", "fix_or_prune_empty"},
    }
    allowed = category_recommendations.get(category, set())
    return matching_surface_recommendations(
        recommendations,
        surfaces=retrieval_surface_focus(diagnosis.get("surface_gaps") or {}) if category == "retrieval_quality" else None,
        recommendations=allowed or None,
        limit=4,
    )


def _surface_recommendation_lines(items: list[dict[str, Any]]) -> list[str]:
    lines: list[str] = []
    for item in items:
        surface = str(item.get("surface") or "surface")
        recommendation = str(item.get("recommendation") or "review")
        reasons = " ".join(str(reason) for reason in (item.get("reasons") or [])[:2]).strip()
        line = f"{surface} => {recommendation}"
        if reasons:
            line = f"{line} ({reasons})"
        lines.append(line)
    return lines


def _stability_slice_command(diagnosis: dict[str, Any]) -> str:
    return str((diagnosis.get("stability_slice") or {}).get("command") or "").strip()


def _priority_score(category: str, diagnosis: dict[str, Any]) -> float:
    score = float(_priority_rank(_priority(category)) * 10)
    metric_deltas = diagnosis.get("metric_deltas") or {}
    score += float(len(_supporting_clusters(category, diagnosis)) * 5)
    score += float(len(_supporting_trace_events(category, diagnosis)))
    benchmark_drift = diagnosis.get("benchmark_drift") or {}
    if category == "benchmark_hygiene" and benchmark_drift.get("status") != "clean":
        score += 8.0
    if category == "surface_pruning":
        surface_gaps = diagnosis.get("surface_gaps") or {}
        unused_count = sum(len(surface_gaps.get(key, []) or []) for key in [
            "unused_available_tools",
            "unused_available_skills",
            "unused_available_plugins",
            "unused_available_mcps",
            "unused_available_prompt_keys",
        ])
        score += min(float(unused_count), 8.0)
    if (
        category == "retrieval_quality"
        and float(metric_deltas.get("metric.output_quality", 0.0)) < 0.0
        and float(metric_deltas.get("metric.process_alignment", 0.0)) >= 0.0
    ):
        score += 18.0
    if category == "retrieval_quality":
        score += min(float(len(retrieval_surface_focus(diagnosis.get("surface_gaps") or {})) * 2), 8.0)
    if (
        category == "prompt_grounding"
        and float(metric_deltas.get("metric.output_quality", 0.0)) < 0.0
        and float(metric_deltas.get("metric.process_alignment", 0.0)) >= 0.0
    ):
        score += 6.0
    if category == "surface_contract":
        score += float(len(diagnosis.get("surface_gaps", {}).get("surface_contract_violations", []) or []) * 4)
    loop_severity_bonus = {"critical": 24.0, "high": 14.0, "medium": 8.0, "warning": 2.0, "info": 1.0}
    for finding in _loop_check_findings(diagnosis, category):
        score += loop_severity_bonus.get(str(finding.get("severity") or "info"), 1.0) * float(
            finding.get("confidence") or 1.0
        )
    for index, item in enumerate(diagnosis.get("suggested_mutations", []) or []):
        if str(item.get("category") or "") == category:
            score += max(0.0, 20.0 - float(index))
            break
    return round(score, 3)


def _suggestion_index(diagnosis: dict[str, Any], category: str) -> int:
    for index, item in enumerate(diagnosis.get("suggested_mutations", []) or []):
        if str(item.get("category") or "") == category:
            return index
    return 999


def _target_files(project_root: Path, diagnosis: dict[str, Any], category: str) -> list[str]:
    files: list[str] = []
    agent_id = str(diagnosis.get("agent_id") or "")
    eval_id = str(diagnosis.get("eval_id") or "")
    spec = _load_agent_spec(project_root, agent_id)
    discovery = _load_discovery_summary(project_root)
    files.extend(_changed_target_files(diagnosis, category))
    files.extend(_owned_target_files(project_root, spec, category))
    if not files:
        for surface in _category_surface_keys(category):
            files.extend(_discovery_files_for_surface(discovery, surface))
    if not files and agent_id:
        files.append(_agent_spec_path(project_root, agent_id))
    if category == "benchmark_hygiene":
        suite = suite_path(project_root, eval_id)
        if suite.exists():
            files.append(str(suite.relative_to(project_root)))
        split = split_path(project_root, eval_id)
        if split.exists():
            files.append(str(split.relative_to(project_root)))
        scorer = scorer_path(project_root, eval_id)
        if scorer.exists():
            files.append(str(scorer.relative_to(project_root)))
        brief_id = str((diagnosis.get("suite") or {}).get("brief_id") or "")
        if brief_id:
            files.append(_brief_path(project_root, brief_id))
    return list(dict.fromkeys(files))


def _target_paths(project_root: Path, diagnosis: dict[str, Any], category: str) -> list[str]:
    agent_id = str(diagnosis.get("agent_id") or "")
    eval_id = str(diagnosis.get("eval_id") or "")
    spec_file = _agent_spec_path(project_root, agent_id) if agent_id else ""
    target_files = _target_files(project_root, diagnosis, category)
    paths: list[str] = []
    behavior_deltas = diagnosis.get("behavior_deltas") or {}
    spec_changes = diagnosis.get("spec_changes") or {}
    for target_file in target_files:
        if target_file != spec_file:
            paths.append(target_file)
    if category == "retrieval_quality":
        if spec_file:
            paths.extend(
                [
                    f"{spec_file}::tools",
                    f"{spec_file}::mcps",
                    f"{spec_file}::memory",
                    f"{spec_file}::runtime",
                    f"{spec_file}::prompts",
                ]
            )
            for marker in retrieval_surface_focus(diagnosis.get("surface_gaps") or {}):
                kind, _, name = marker.partition(":")
                if kind == "tools":
                    paths.append(f"{spec_file}::tools.{name}")
                elif kind == "mcps":
                    paths.append(f"{spec_file}::mcps.{name}")
    elif category == "prompt_grounding":
        if spec_file:
            paths.extend([f"{spec_file}::instructions", f"{spec_file}::prompts.system", f"{spec_file}::prompts.default"])
            if behavior_deltas.get("prompt_keys_used_removed") or spec_changes.get("prompt_keys_removed"):
                paths.append(f"{spec_file}::prompts.reviewer")
    elif category == "surface_contract":
        if spec_file:
            paths.extend(
                [
                    f"{spec_file}::tools",
                    f"{spec_file}::skills",
                    f"{spec_file}::plugins",
                    f"{spec_file}::mcps",
                    f"{spec_file}::runtime",
                    f"{spec_file}::prompts",
                ]
            )
    elif category == "tool_routing":
        if spec_file:
            paths.extend(
                [
                    f"{spec_file}::tools",
                    f"{spec_file}::skills",
                    f"{spec_file}::plugins",
                    f"{spec_file}::mcps",
                    f"{spec_file}::prompts",
                ]
            )
    elif category == "step_budget":
        if spec_file:
            paths.extend([f"{spec_file}::runtime", f"{spec_file}::instructions"])
    elif category == "cost_budget":
        if spec_file:
            paths.extend(
                [
                    f"{spec_file}::model",
                    f"{spec_file}::runtime",
                    f"{spec_file}::instructions",
                    f"{spec_file}::prompts",
                    f"{spec_file}::tools",
                    f"{spec_file}::skills",
                    f"{spec_file}::plugins",
                    f"{spec_file}::mcps",
                ]
            )
    elif category == "surface_pruning":
        if spec_file:
            paths.extend([f"{spec_file}::tools", f"{spec_file}::skills", f"{spec_file}::plugins", f"{spec_file}::mcps", f"{spec_file}::prompts"])
    elif category == "benchmark_hygiene":
        for candidate in [suite_path(project_root, eval_id), split_path(project_root, eval_id), scorer_path(project_root, eval_id)]:
            if candidate.exists():
                paths.append(f"{candidate.relative_to(project_root)}")
    elif category == "agent_topology":
        if spec_file:
            paths.extend(
                [
                    f"{spec_file}::instructions",
                    f"{spec_file}::entrypoints",
                    f"{spec_file}::tools",
                    f"{spec_file}::runtime",
                ]
            )
        loop_target = (diagnosis.get("loop_checks") or {}).get("target") or {}
        workflow_file = str(loop_target.get("workflow_file") or "")
        if workflow_file:
            paths.append(workflow_file)
    elif category in {"code_structure", "agent_topology", "eval_contract", "deterministic_fallback"}:
        for item in _loop_check_findings(diagnosis, category):
            paths.extend(str(path) for path in item.get("target_files", []) or [])
    return list(dict.fromkeys(paths))


def _target_surfaces(category: str, diagnosis: dict[str, Any]) -> list[str]:
    mapping = {
        "code_structure": ["runtime", "module_boundaries", "owned_paths", "surface_paths"],
        "agent_topology": ["agent_count", "workflow", "chain", "handoffs"],
        "eval_contract": ["brief", "eval_suite", "process_expectations", "tool_rationales"],
        "deterministic_fallback": ["runtime", "entrypoints", "fixtures", "fallbacks"],
        "retrieval_quality": ["retrieval", "tools", "memory", "mcps", "runtime", "prompts"],
        "prompt_grounding": ["instructions", "prompts", "reviewer_prompts"],
        "surface_contract": ["tools", "mcps", "runtime_contract", "trace_contract"],
        "tool_routing": ["tools", "skills", "plugins", "mcps", "memory", "prompt_routing"],
        "step_budget": ["planner", "runtime", "step_budget", "reviewer_overhead"],
        "cost_budget": ["model_selection", "tool_budget", "prompt_budget", "runtime_budget"],
        "surface_pruning": ["tools", "skills", "plugins", "mcps", "memory", "prompt_variants"],
        "benchmark_hygiene": ["brief", "eval_suite", "splits", "scorer"],
        "stability_validation": ["repeat_runs", "variance_gates", "promotion_gates"],
        "promote_candidate": ["promotion_state"],
        "inspect_failures": ["failing_cases"],
    }
    surfaces = list(mapping.get(category, ["agent_behavior"]))
    surfaces.extend(str(item.get("surface") or "") for item in _proposal_surface_recommendations(diagnosis, category))
    for item in _loop_check_findings(diagnosis, category):
        surfaces.extend(str(surface) for surface in item.get("target_surfaces", []) or [])
    return list(dict.fromkeys(surface for surface in surfaces if surface))


def _effect_lines(category: str, diagnosis: dict[str, Any]) -> list[str]:
    metric_deltas = diagnosis.get("metric_deltas") or {}
    retrieval_focus = retrieval_surface_focus(diagnosis.get("surface_gaps") or {})
    effects = {
        "code_structure": [
            "Make future Codex edits smaller, easier to review, and less likely to mix prompt, runtime, and tool changes.",
            "Preserve benchmark behavior while improving target-agent maintainability.",
        ],
        "agent_topology": [
            "Align the number of agents, workflow nodes, and handoff paths with the benchmark contract.",
            "Reduce over-delegation or add explicit workflow structure where the eval requires it.",
        ],
        "eval_contract": [
            "Make required tools, MCPs, prompt keys, and workflow steps defensible instead of arbitrary.",
            "Keep process-alignment failures interpretable during long optimization loops.",
        ],
        "deterministic_fallback": [
            "Remove benchmark-specific fixture behavior from the target agent runtime.",
            "Make score gains depend on general agent behavior rather than exact expected strings or case IDs.",
        ],
        "retrieval_quality": [
            "Increase `metric.output_quality` on grounded cases that already use the expected tools or memory.",
            "Improve evidence selection without widening the benchmark or surface area.",
            f"Raise `selected_evidence_use_rate` on the low-value retrieval surfaces: {', '.join(retrieval_focus) or 'none identified'}.",
        ],
        "prompt_grounding": [
            "Increase `metric.output_quality` on the current focus cases.",
            "Raise weighted `average_score` without changing the benchmark.",
        ],
        "surface_contract": [
            "Remove process-alignment regressions caused by disabled or misreported tools and MCPs.",
            "Make telemetry, tool calls, workflow trace, and MCP usage reflect the actual enabled surfaces.",
        ],
        "tool_routing": [
            "Improve `metric.process_alignment` on workflow and routed cases.",
            "Restore or increase usage of the right tools, skills, plugins, or MCPs.",
        ],
        "step_budget": [
            "Reduce unnecessary steps or reviewer overhead.",
            "Hold or improve score while lowering `avg_step_count_delta` and latency drift.",
        ],
        "cost_budget": [
            "Reduce unnecessary spend per case without lowering score.",
            "Hold or improve score while lowering `avg_cost_estimate_delta` and token overhead.",
        ],
        "surface_pruning": [
            "Reduce unused available surface and simplify the agent spec.",
            "Keep only surfaces that produce measurable gains.",
        ],
        "benchmark_hygiene": [
            "Return future comparisons to a clean benchmark state.",
            "Make score deltas easier to trust and promote.",
        ],
        "stability_validation": [
            "Make promotion decisions depend on repeatability rather than one lucky live run.",
            "Keep score, latency, and cost variance visible before promotion.",
        ],
        "promote_candidate": [
            "Turn the current candidate into the clean baseline for this benchmark signature.",
            f"Preserve the current gain of {float(metric_deltas.get('average_score', 0.0)):+.3f} average score.",
        ],
        "inspect_failures": [
            "Make the next mutation narrower and easier to validate.",
            "Convert failing cases into one bounded change class.",
        ],
    }
    return effects.get(category, ["Improve the current benchmark outcome."])


def _change_plan(category: str, diagnosis: dict[str, Any]) -> list[str]:
    focus_cases = diagnosis.get("focus_cases") or []
    example_case = focus_cases[0]["case_id"] if focus_cases else "the top failing case"
    behavior_deltas = diagnosis.get("behavior_deltas") or {}
    spec_changes = diagnosis.get("spec_changes") or {}
    recommendation_lines = _surface_recommendation_lines(_proposal_surface_recommendations(diagnosis, category))
    removed_surfaces = list(dict.fromkeys(
        [
            *behavior_deltas.get("tools_used_removed", []),
            *behavior_deltas.get("skills_used_removed", []),
            *behavior_deltas.get("plugins_used_removed", []),
            *behavior_deltas.get("mcp_servers_used_removed", []),
            *behavior_deltas.get("prompt_keys_used_removed", []),
            *spec_changes.get("tools_removed", []),
            *spec_changes.get("skills_removed", []),
            *spec_changes.get("plugins_removed", []),
            *spec_changes.get("mcps_removed", []),
            *spec_changes.get("prompt_keys_removed", []),
        ]
    ))
    added_surfaces = list(dict.fromkeys(
        [
            *behavior_deltas.get("tools_used_added", []),
            *behavior_deltas.get("skills_used_added", []),
            *behavior_deltas.get("plugins_used_added", []),
            *behavior_deltas.get("mcp_servers_used_added", []),
            *behavior_deltas.get("prompt_keys_used_added", []),
        ]
    ))
    surface_gaps = diagnosis.get("surface_gaps") or {}
    loop_findings = _loop_check_findings(diagnosis, category)
    loop_hint = str((loop_findings[0] if loop_findings else {}).get("hint") or "")
    loop_message = str((loop_findings[0] if loop_findings else {}).get("message") or "")
    if category == "code_structure":
        return [
            loop_message or "Inspect loop-readiness code-structure findings for the target agent files.",
            loop_hint or "Split large or monolithic target-agent code into clearer prompt, runtime, tool, and workflow files.",
            "Keep the mutation behavior-preserving; validate with the same eval before making behavior changes.",
        ]
    if category == "agent_topology":
        return [
            loop_message or "Inspect whether the current agent count matches the benchmark workflow needs.",
            loop_hint or "Use one agent for simple cases, and declare a workflow or chain only when routing or handoffs are required.",
            "Validate topology changes with workflow telemetry, step counts, and process-alignment scores.",
        ]
    if category == "eval_contract":
        return [
            loop_message or "Inspect process expectations that lack a rationale or point to missing surfaces.",
            loop_hint or "Add explicit rationales for required/forbidden tools, MCPs, prompt keys, and workflow steps.",
            "Do not change the target agent to satisfy an expectation until the eval contract says why that expectation is correct.",
        ]
    if category == "deterministic_fallback":
        return [
            loop_message or "Inspect deterministic fallback findings in the target runtime or entrypoint.",
            loop_hint or "Remove hard-coded benchmark answers, case-id branches, or fixture final outputs from the target agent.",
            "Re-run the same eval and confirm outputs still pass through general behavior, tools, model responses, or evidence.",
        ]
    if category == "retrieval_quality":
        retrieval_focus = retrieval_surface_focus(diagnosis.get("surface_gaps") or {})
        return [
            f"Inspect the retrieval path for `{example_case}` and identify which evidence was missed or ranked too low.",
            f"Pay particular attention to the low-value retrieval surfaces: {', '.join(retrieval_focus) or 'none identified'}.",
            (
                f"Use the current surface recommendations as the first mutation boundary: {' | '.join(recommendation_lines)}."
                if recommendation_lines
                else "Start with the tool and MCP surfaces that selected evidence but still failed to ground the answer."
            ),
            "Tighten search terms, snippet ranking, memory recall, or context assembly in the real target agent files before broad prompt edits.",
            "Keep the mutation bounded to retrieval and evidence packaging for this pass.",
        ]
    if category == "prompt_grounding":
        return [
            f"Read the failing case details for `{example_case}` and identify the missing required content or structure.",
            "Revise the main answer instructions or prompt sections so the expected content is explicitly required.",
            "If a reviewer prompt exists or was removed in the better baseline, restore or tighten that reviewer behavior before changing tools.",
            "Keep the mutation bounded to prompt/instruction edits for this pass.",
        ]
    if category == "surface_contract":
        contract_violations = diagnosis.get("surface_gaps", {}).get("surface_contract_violations", []) or []
        return [
            f"Inspect the tool and MCP contract violations for `{example_case}`: {', '.join(contract_violations) or 'none listed'}.",
            "Align runtime gating, emitted events, tool calls, workflow trace, and `mcp_servers_used` with the surfaces declared in the agent spec.",
            "Keep the mutation bounded to contract enforcement and telemetry consistency before broader prompt or retrieval edits.",
        ]
    if category == "tool_routing":
        surface_text = ", ".join(removed_surfaces or added_surfaces or ["the workflow surfaces"])
        return [
            f"Inspect the routed workflow failures and the changed surfaces: {surface_text}.",
            (
                f"Use the routing-sensitive surface recommendations to decide what must stay active: {' | '.join(recommendation_lines)}."
                if recommendation_lines
                else "Check whether the right tool, MCP, plugin, and prompt surfaces are present on the failing workflow cases."
            ),
            "Adjust the target agent files so the right tools, skills, memory, plugins, MCPs, or prompt keys are selected on the relevant workflow cases.",
            "Do not add unrelated new surface area in the same mutation.",
        ]
    if category == "step_budget":
        return [
            "Inspect where extra planner or reviewer steps were added.",
            "Lower step budget, tighten stop conditions, or simplify reviewer loops so the agent does less work per case.",
            "Keep the answer quality mutation separate from the step-budget mutation.",
        ]
    if category == "cost_budget":
        return [
            "Inspect where the candidate added cost without adding benchmark value.",
            "Reduce expensive prompt, model, tool, plugin, or MCP usage on the same cases before widening scope.",
            "Keep the cost-budget mutation separate from the answer-quality mutation so the next compare is easy to trust.",
        ]
    if category == "surface_pruning":
        unused = list(dict.fromkeys(
            [
                *surface_gaps.get("unused_available_tools", []),
                *surface_gaps.get("unused_available_skills", []),
                *surface_gaps.get("unused_available_plugins", []),
                *surface_gaps.get("unused_available_mcps", []),
                *surface_gaps.get("unused_available_prompt_keys", []),
                *surface_gaps.get("tools_with_low_evidence_use", []),
                *surface_gaps.get("mcps_with_low_evidence_use", []),
                *surface_gaps.get("tools_with_unused_selected_evidence", []),
                *surface_gaps.get("mcps_with_unused_selected_evidence", []),
            ]
        ))
        return [
            f"Audit the currently unused surface: {', '.join(unused) or 'none identified'}.",
            (
                f"Prefer the explicit prune candidates from the current surface recommendations: {' | '.join(recommendation_lines)}."
                if recommendation_lines
                else "Start with enabled surfaces that are unused or add cost without grounded-evidence gains."
            ),
            "Remove or disable surface in the real target agent files that is not contributing to better scores or grounded evidence use.",
            "Re-run the benchmark to confirm the simpler agent preserves the same outcomes.",
        ]
    if category == "benchmark_hygiene":
        return [
            "Review the suite, splits, scorer, and brief for unintended benchmark drift.",
            "Separate eval-authoring changes from agent-behavior changes before continuing optimization.",
            "Re-establish a clean baseline once the benchmark is stable.",
        ]
    if category == "stability_validation":
        return [
            "Decide which live streams are expensive enough that repeats should be required before promotion.",
            "Set repeat-count and variance thresholds in the workbench config, then validate them on the current provider-backed agent.",
            "Keep stability-gate edits separate from answer-quality edits so promotion outcomes stay interpretable.",
        ]
    if category == "promote_candidate":
        return [
            "Promote the candidate as the clean baseline for this benchmark signature.",
            "Freeze the benchmark inputs, then draft new eval cases around the improved behaviors before the next mutation.",
        ]
    return [
        "Review the focus cases and failing reasons.",
        "Choose one mutation class and change only that surface in the next iteration.",
    ]


def _acceptance_checks(category: str, diagnosis: dict[str, Any]) -> list[str]:
    checks = [
        "Run the same eval subset on the mutated agent.",
        "Compare against the best comparable clean baseline.",
        "Keep the benchmark signature unchanged unless you are intentionally editing the benchmark.",
    ]
    if category == "code_structure":
        checks.append("Loop-readiness code-structure findings should decrease without lowering `average_score`.")
    if category == "agent_topology":
        checks.append("Agent count and workflow traces should match the eval contract without added dead ends, loops, or over-delegation.")
    if category == "eval_contract":
        checks.append("Required process expectations should have explicit rationale or a clear brief/case link.")
    if category == "deterministic_fallback":
        checks.append("No critical deterministic fallback findings should remain on `awb check`.")
    if category == "retrieval_quality":
        checks.append("Focus cases should keep the right tool or memory usage while `metric.output_quality` improves.")
        checks.append("`selected_evidence_use_rate` should improve or at least not fall on the affected tools and MCPs.")
    if category == "prompt_grounding":
        checks.append("`metric.output_quality` should improve on the focus cases.")
    if category == "surface_contract":
        checks.append("No tool or MCP contract violations should remain on the mutated run.")
    if category == "tool_routing":
        checks.append("`metric.process_alignment` should improve or remain perfect on workflow cases.")
    if category == "step_budget":
        checks.append("Average step count and latency should not increase.")
    if category == "cost_budget":
        checks.append("Average cost estimate and token usage should not increase.")
    if category == "surface_pruning":
        checks.append("Unused available surface should decrease without lowering `average_score`.")
        checks.append("Low-value retrieval surfaces should either disappear or show better grounded-evidence use after the mutation.")
    if category == "benchmark_hygiene":
        checks.append("The next compare should return `comparison_mode=clean`.")
    if category == "stability_validation":
        checks.append("Repeated live runs should emit a stability summary and promotion should fail when configured stability gates are missing.")
    if category == "promote_candidate":
        checks.append("The current promotion gates should remain passing.")
    return checks


def _validation_commands(diagnosis: dict[str, Any], category: str) -> list[str]:
    agent_id = str(diagnosis.get("agent_id") or "")
    eval_id = str(diagnosis.get("eval_id") or "")
    subset = str(diagnosis.get("subset") or "smoke")
    benchmark_signature = str(diagnosis.get("benchmark_signature") or "")
    commands = [
        f"awb run --agent-id {agent_id} --eval-id {eval_id} --subset {subset}",
        "awb compare --candidate <new-experiment-id> --best",
        "awb diagnose --experiment <new-experiment-id>",
        f"awb status --eval-id {eval_id} --subset {subset} --benchmark-signature {benchmark_signature}",
    ]
    if category == "promote_candidate":
        if diagnosis.get("baseline_id"):
            commands.insert(0, f"awb promote --experiment <new-experiment-id> --baseline {diagnosis['baseline_id']}")
        else:
            commands.insert(0, "awb promote --experiment <new-experiment-id>")
    if category == "stability_validation":
        commands.insert(0, f"awb run --agent-id {agent_id} --eval-id {eval_id} --subset {subset} --repeat 3")
    if category in {"surface_pruning", "surface_contract", "tool_routing", "prompt_grounding"}:
        commands.append("awb ablate --experiment <new-experiment-id>")
    if category in {"code_structure", "agent_topology", "eval_contract", "deterministic_fallback"}:
        commands.insert(0, f"awb check --experiment {diagnosis.get('experiment_id')} --fail-on none")
        commands.append("awb check --experiment <new-experiment-id>")
    stability_command = _stability_slice_command(diagnosis)
    if stability_command and category in {"retrieval_quality", "prompt_grounding", "surface_contract", "tool_routing", "stability_validation"}:
        commands.append(stability_command)
    return commands


def _risks(category: str) -> list[str]:
    mapping = {
        "code_structure": ["May produce a clean refactor that accidentally changes runtime behavior if validation is skipped."],
        "agent_topology": ["May simplify too aggressively or add unnecessary handoffs if the eval contract is still ambiguous."],
        "eval_contract": ["May change the benchmark contract; call out benchmark drift explicitly before comparing agent behavior."],
        "deterministic_fallback": ["May expose real model/tool failures that fixture-like outputs were hiding."],
        "retrieval_quality": ["May overfit retrieval heuristics or narrow recall too aggressively on unseen cases."],
        "prompt_grounding": ["May overfit to benchmark wording or expected phrases."],
        "surface_contract": ["Strict contract enforcement can expose latent agent assumptions and cause short-term regressions until routing is fixed."],
        "tool_routing": ["May increase latency or step count by routing too aggressively."],
        "step_budget": ["May reduce answer quality if useful review steps are removed."],
        "cost_budget": ["May reduce answer quality if the cheaper path removes useful model or tool work."],
        "surface_pruning": ["May remove latent capability that matters on unseen cases."],
        "benchmark_hygiene": ["Can stall optimization progress if benchmark edits and agent edits stay entangled."],
        "stability_validation": ["Can increase live evaluation spend if repeat counts are set too aggressively."],
        "promote_candidate": ["Promoting too early can hide residual weaknesses in broader evals."],
        "inspect_failures": ["A vague next mutation can lead to another low-signal iteration."],
    }
    return mapping.get(category, ["Validate the mutation on the same benchmark before widening scope."])


def _proposal_title(category: str) -> str:
    titles = {
        "code_structure": "Improve Target Agent Structure",
        "agent_topology": "Align Agent Topology With Benchmark Need",
        "eval_contract": "Justify Eval Process Expectations",
        "deterministic_fallback": "Remove Deterministic Fallbacks",
        "retrieval_quality": "Improve Retrieval And Evidence Selection",
        "prompt_grounding": "Tighten Prompt Grounding",
        "surface_contract": "Fix Tool And MCP Contract Drift",
        "tool_routing": "Fix Tool And Surface Routing",
        "step_budget": "Reduce Step And Review Overhead",
        "cost_budget": "Reduce Cost And Token Overhead",
        "surface_pruning": "Prune Unused Surface",
        "benchmark_hygiene": "Stabilize Benchmark Inputs",
        "stability_validation": "Add Stability Gates",
        "promote_candidate": "Promote Candidate Baseline",
        "inspect_failures": "Inspect Failing Cases First",
    }
    return titles.get(category, "Mutation Proposal")


def generate_mutation_proposals(
    project_root: Path,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    baseline_id: str | None = None,
    limit: int = 3,
) -> dict[str, Any]:
    diagnosis = diagnose_experiment(
        project_root,
        experiment_id=experiment_id,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        baseline_id=baseline_id,
    )
    payload = build_mutation_proposal_payload(project_root, diagnosis, limit=limit)
    return write_mutation_proposal_payload(project_root, payload)


def build_mutation_proposal_payload(
    project_root: Path,
    diagnosis: dict[str, Any],
    *,
    limit: int = 3,
) -> dict[str, Any]:
    proposals: list[MutationProposal] = []
    for index, item in enumerate(diagnosis.get("suggested_mutations") or [], start=1):
        category = str(item.get("category") or "inspect_failures")
        priority_score = _priority_score(category, diagnosis)
        proposal = MutationProposal(
            proposal_id=f"{diagnosis['experiment_id']}-{index:02d}-{category}",
            experiment_id=diagnosis["experiment_id"],
            baseline_id=diagnosis.get("baseline_id"),
            benchmark_signature=str(diagnosis.get("benchmark_signature") or ""),
            category=category,
            title=_proposal_title(category),
            priority=_priority(category),
            priority_score=priority_score,
            target_files=_target_files(project_root, diagnosis, category),
            target_paths=_target_paths(project_root, diagnosis, category),
            target_surfaces=_target_surfaces(category, diagnosis),
            related_cases=[str(case.get("case_id")) for case in diagnosis.get("focus_cases", [])[:3] if case.get("case_id")],
            supporting_trace_events=_supporting_trace_events(category, diagnosis),
            supporting_clusters=_supporting_clusters(category, diagnosis),
            rationale=str(item.get("rationale") or ""),
            change_plan=_change_plan(category, diagnosis),
            expected_effects=_effect_lines(category, diagnosis),
            acceptance_checks=_acceptance_checks(category, diagnosis),
            validation_commands=_validation_commands(diagnosis, category),
            risks=_risks(category),
        )
        proposals.append(proposal)
    proposals = sorted(
        proposals,
        key=lambda item: (-float(item.priority_score), _suggestion_index(diagnosis, item.category), -_priority_rank(item.priority), item.proposal_id),
    )[:limit]
    payload = {
        "experiment_id": diagnosis["experiment_id"],
        "baseline_id": diagnosis.get("baseline_id"),
        "benchmark_signature": diagnosis.get("benchmark_signature"),
        "recommended_action": diagnosis.get("recommended_action"),
        "summary": diagnosis.get("summary"),
        "proposal_count": len(proposals),
        "surface_recommendations": diagnosis.get("surface_recommendations") or [],
        "proposals": [proposal.model_dump(mode="json") for proposal in proposals],
        "suggested_command_sequence": list(dict.fromkeys(
            command
            for proposal in proposals
            for command in proposal.validation_commands
        )),
    }
    return payload


def write_mutation_proposal_payload(project_root: Path, payload: dict[str, Any]) -> dict[str, Any]:
    root = proposals_dir(project_root)
    write_json(root / f"proposals-{payload['experiment_id']}.json", payload)
    write_json(root / "latest.json", payload)
    write_report(root / f"proposals-{payload['experiment_id']}.md", render_proposals_report(payload))
    write_report(root / "latest.md", render_proposals_report(payload))
    return payload
