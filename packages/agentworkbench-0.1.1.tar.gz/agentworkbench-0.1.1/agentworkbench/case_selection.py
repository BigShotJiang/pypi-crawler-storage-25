from __future__ import annotations

import hashlib
import json
from typing import Any

from agentworkbench.models import EvalCase


def normalize_case_selection(
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    normalized_limit = int(limit) if limit is not None and int(limit) > 0 else None
    return {
        "case_ids": sorted(dict.fromkeys(str(item) for item in (case_ids or []) if str(item).strip())),
        "tags": sorted(dict.fromkeys(str(item) for item in (tags or []) if str(item).strip())),
        "match": str(match or "").strip(),
        "limit": normalized_limit,
    }


def selection_is_default(selection: dict[str, Any]) -> bool:
    return not (
        selection.get("case_ids")
        or selection.get("tags")
        or selection.get("match")
        or selection.get("limit") is not None
    )


def case_search_text(case: EvalCase | dict[str, Any]) -> str:
    payload = case.model_dump(mode="json") if isinstance(case, EvalCase) else dict(case)
    metadata = payload.get("metadata") or {}
    parts = [
        str(payload.get("id") or ""),
        str(payload.get("input") or ""),
        str(payload.get("expected") or ""),
        " ".join(str(item) for item in (payload.get("tags") or [])),
        json.dumps(metadata, sort_keys=True, default=str),
    ]
    return "\n".join(parts).lower()


def case_matches(case: EvalCase | dict[str, Any], selection: dict[str, Any]) -> bool:
    payload = case.model_dump(mode="json") if isinstance(case, EvalCase) else dict(case)
    wanted_ids = set(str(item) for item in selection.get("case_ids") or [])
    wanted_tags = set(str(item) for item in selection.get("tags") or [])
    match = str(selection.get("match") or "").strip().lower()
    if wanted_ids and str(payload.get("id") or "") not in wanted_ids:
        return False
    if wanted_tags and not wanted_tags.intersection(str(tag) for tag in payload.get("tags") or []):
        return False
    if match and match not in case_search_text(payload):
        return False
    return True


def filter_eval_cases(cases: list[EvalCase], selection: dict[str, Any]) -> list[EvalCase]:
    filtered = [case for case in cases if case_matches(case, selection)]
    limit = selection.get("limit")
    if limit is not None:
        filtered = filtered[: int(limit)]
    return filtered


def select_eval_cases(
    cases: list[EvalCase],
    *,
    subset_ids: set[str] | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
) -> list[EvalCase]:
    selection = normalize_case_selection(case_ids=case_ids, tags=tags, match=match, limit=limit)
    filtered = [case for case in cases if subset_ids is None or case.id in subset_ids]
    return filter_eval_cases(filtered, selection)


def finalize_case_selection(selection: dict[str, Any], cases: list[EvalCase]) -> dict[str, Any]:
    selected_case_ids = [case.id for case in cases]
    payload = {
        **normalize_case_selection(
            case_ids=selection.get("case_ids"),
            tags=selection.get("tags"),
            match=selection.get("match"),
            limit=selection.get("limit"),
        ),
        "selected_case_ids": selected_case_ids,
        "selected_case_count": len(selected_case_ids),
    }
    payload["selection_fingerprint"] = hashlib.sha256(
        json.dumps(
            {
                "case_ids": payload["case_ids"],
                "tags": payload["tags"],
                "match": payload["match"],
                "limit": payload["limit"],
                "selected_case_ids": selected_case_ids,
            },
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()[:12]
    payload["selection_mode"] = "filtered" if not selection_is_default(payload) else "subset"
    return payload


def build_case_selection(
    cases: list[EvalCase],
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    selection = normalize_case_selection(case_ids=case_ids, tags=tags, match=match, limit=limit)
    return finalize_case_selection(selection, cases)
