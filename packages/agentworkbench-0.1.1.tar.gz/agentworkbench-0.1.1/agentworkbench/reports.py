from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.report_builder import ReportBuilder
from agentworkbench.report_compare import render_compare_report
from agentworkbench.report_diagnosis import render_diagnosis_report
from agentworkbench.report_experiment import render_experiment_report
from agentworkbench.report_next import render_next_report
from agentworkbench.report_status import render_status_report
from agentworkbench.utils import ensure_dir, write_text


def render_extension_reports(bundle: dict[str, Any]) -> dict[str, str]:
    """Discover and run all available ReporterPlugin extensions.
    
    Returns a mapping of reporter_name -> rendered_content.
    """
    try:
        from agentworkbench.extensions.base import ReporterPlugin
        from agentworkbench.extensions.loader import get_extension, list_extensions

        reports: dict[str, str] = {}
        for ext in list_extensions("reporters"):
            if ext.get("status") == "loaded":
                plugin = get_extension("reporters", ext["name"])
                if isinstance(plugin, ReporterPlugin):
                    try:
                        content = plugin.render(bundle)
                        if content:
                            reports[plugin.name] = content
                    except Exception:
                        continue
        return reports
    except (ImportError, Exception):
        return {}

__all__ = [
    "render_repo_brief",
    "render_experiment_report",
    "render_compare_report",
    "render_status_report",
    "render_next_report",
    "render_diagnosis_report",
    "render_iteration_report",
    "render_proposals_report",
    "render_patch_template_report",
    "render_matrix_report",
    "render_factorial_report",
    "render_optimize_report",
    "render_ablation_report",
    "render_release_report",
    "render_redteam_report",
    "render_brief_packet",
    "render_eval_suite_report",
    "render_extension_reports",
    "write_report",
]


def render_repo_brief(summary: dict[str, Any]) -> str:
    report = ReportBuilder(f"Repo Brief: {summary['project_name']}")
    report.bullet(f"Root: `{summary['project_root']}`")
    report.bullet(f"File count: {summary['file_count']}")
    report.bullet(f"Languages: {', '.join(summary['languages']) or 'unknown'}")
    report.bullet(f"Likely entrypoints: {', '.join(summary['likely_entrypoints']) or 'none'}")
    report.bullet(f"Existing agent assets: {', '.join(summary.get('existing_agent_assets', [])) or 'none'}")
    report.bullet(f"Existing evaluation assets: {', '.join(summary['existing_evaluation_assets']) or 'none'}")
    report.bullet(f"Provider hints: {', '.join(summary.get('provider_hints', [])) or 'none'}")
    report.bullet(f"Likely env keys: {', '.join(summary.get('likely_env_keys', [])) or 'none'}")

    report.section("Target Agent Candidates")
    report.bullet(f"Prompt files: {', '.join(summary.get('candidate_prompt_files', [])) or 'none'}")
    report.bullet(f"Tool files: {', '.join(summary.get('candidate_tool_files', [])) or 'none'}")
    report.bullet(f"Memory or MCP files: {', '.join(summary.get('candidate_memory_files', [])) or 'none'}")
    report.bullet(f"Test or eval files: {', '.join(summary.get('candidate_test_files', [])) or 'none'}")
    report.bullet(f"Confirmed owned files: {', '.join(summary.get('confirmed_owned_files', [])) or 'none'}")
    report.bullet(f"Unclaimed candidate files: {', '.join(summary.get('unclaimed_candidate_files', [])) or 'none'}")

    report.section("Suggested Questions")
    for question in summary["suggested_user_questions"]:
        report.bullet(question)

    report.section("Suggested Commands")
    for label, command in summary["guessed_commands"].items():
        report.bullet(f"`{label}`: `{command}`")

    report.section("Optimization Start")
    report.bullet("Learn the repo, confirm the target agent files, and capture expected behavior before editing code.")
    report.bullet(
        "Write down expected outputs, tool calls, skills, plugins, MCPs, prompt variants, and runtime guardrails in the approved brief."
    )
    report.bullet(
        "Prefer full eval runs for real optimization and promotion decisions. Use smoke subsets only for fast local debugging."
    )
    return report.text()


def render_iteration_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Iterate {payload['experiment_id']}")
    report.bullet(f"Baseline: `{payload.get('baseline_id') or 'none'}`")
    report.bullet(f"Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`")
    report.bullet(f"Recommended action: `{payload.get('recommended_action') or 'review'}`")
    report.bullet(f"Preferred subset: `{payload.get('preferred_subset') or 'unknown'}`")
    report.bullet(f"Summary: {payload.get('summary') or 'none'}")
    report.section("Notes")
    notes = payload.get("notes", [])
    if notes:
        for item in notes:
            report.bullet(item)
    else:
        report.bullet("none")

    report.section("Baseline Ladder")
    ladder = payload.get("baseline_ladder") or {}
    if ladder:
        for key, value in ladder.items():
            if not value:
                report.bullet(f"`{key}`: none")
                continue
            report.bullet(
                f"`{key}`: `{value.get('experiment_id', 'unknown')}`, "
                f"score={float(value.get('average_score', 0.0)):.3f}, "
                f"passed={value.get('passed_cases', 0)}/{value.get('total_cases', 0)}, "
                f"model=`{value.get('model_name', 'unknown')}`"
            )
    else:
        report.bullet("none")

    readiness = payload.get("readiness") or {}
    report.section("Readiness")
    for key in ["discovery_summary_path", "brief_id", "eval_id", "eval_approval_status"]:
        report.bullet(f"`{key}`: {readiness.get(key) or 'none'}")
    report.bullet(f"`score_weights`: {readiness.get('score_weights') or {}}")
    for item in readiness.get("notes", []):
        report.bullet(f"readiness_note: {item}")

    contract = readiness.get("behavior_contract") or {}
    if contract:
        report.section("Behavior Contract")
        for key in [
            "goal",
            "approval_status",
            "desired_behaviors",
            "non_goals",
            "acceptance_criteria",
            "better_signals",
            "worse_signals",
            "prompt_variants",
            "preferred_tools",
            "preferred_skills",
            "preferred_plugins",
            "preferred_mcps",
            "likely_user_commands",
        ]:
            value = contract.get(key)
            if isinstance(value, list):
                report.bullet(f"`{key}`: {', '.join(value) or 'none'}")
            else:
                report.bullet(f"`{key}`: {value or 'none'}")
        for workflow in contract.get("workflows", []):
            report.bullet(
                f"workflow=`{workflow.get('name', 'workflow')}`: "
                f"trigger={workflow.get('trigger') or 'none'}, "
                f"tools={', '.join(workflow.get('expected_tools', [])) or 'none'}, "
                f"skills={', '.join(workflow.get('expected_skills', [])) or 'none'}, "
                f"plugins={', '.join(workflow.get('expected_plugins', [])) or 'none'}, "
                f"mcps={', '.join(workflow.get('expected_mcps', [])) or 'none'}, "
                f"prompts={', '.join(workflow.get('expected_prompt_keys', [])) or 'none'}, "
                f"workflow_steps={', '.join(workflow.get('expected_workflow_steps', [])) or 'none'}, "
                f"workflow_sequence={' -> '.join(workflow.get('expected_workflow_sequence', [])) or 'none'}, "
                f"max_steps={workflow.get('max_steps', 'n/a')}"
            )

    report.section("Lanes")
    lanes = payload.get("lanes", [])
    if lanes:
        for lane in lanes:
            report.bullet(
                f"`{lane.get('lane_id', 'lane')}` [{lane.get('priority', 'medium')}]: "
                f"{lane.get('title', 'Lane')} ({lane.get('category', 'mutation')})"
            )
            report.bullet(f"rationale: {lane.get('rationale') or 'none'}")
            report.bullet(f"related_cases: {', '.join(lane.get('related_cases', [])) or 'none'}")
            report.bullet(f"target_surfaces: {', '.join(lane.get('target_surfaces', [])) or 'none'}")
            report.bullet(f"target_files: {', '.join(lane.get('target_files', [])) or 'none'}")
            report.bullet(f"measurement_focus: {' | '.join(lane.get('measurement_focus', [])) or 'none'}")
            report.bullet(f"metrics_to_watch: {' | '.join(lane.get('metrics_to_watch', [])) or 'none'}")
            report.bullet(f"guardrails: {' | '.join(lane.get('guardrails', [])) or 'none'}")
            compare_against = lane.get("compare_against", [])
            report.bullet(
                "compare_against: "
                + (
                    " | ".join(f"{item.get('label')}={item.get('experiment_id')}" for item in compare_against)
                    if compare_against
                    else "none"
                )
            )
            report.bullet(f"ablation_command: {lane.get('ablation_command') or 'none'}")
            report.bullet(f"validation_commands: {' | '.join(lane.get('validation_commands', [])) or 'none'}")
            report.blank()
    else:
        report.bullet("none")
        report.blank()

    report.section("Command Sequence")
    commands = payload.get("command_sequence", [])
    if commands:
        for command in commands:
            report.bullet(f"`{command}`")
    else:
        report.bullet("none")
    return report.text()


def render_proposals_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Proposals {payload['experiment_id']}")
    report.bullet(f"Baseline: `{payload.get('baseline_id') or 'none'}`")
    report.bullet(f"Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`")
    report.bullet(f"Recommended action: `{payload.get('recommended_action') or 'review'}`")
    report.bullet(f"Summary: {payload.get('summary') or 'none'}")
    report.bullet(f"Proposal count: {payload.get('proposal_count', 0)}")

    report.section("Surface Recommendations")
    surface_recs = payload.get("surface_recommendations", [])
    if surface_recs:
        for item in surface_recs[:8]:
            report.bullet(
                f"`{item.get('surface', 'surface')}`: recommendation=`{item.get('recommendation', 'review')}`, "
                f"score_effect={item.get('average_score_effect', 'n/a')}, "
                f"use_rate={item.get('selected_evidence_use_rate', 'n/a')}"
            )
            report.bullet(f"why: {' '.join(item.get('reasons', []) or ['none'])}")
    else:
        report.bullet("none")

    report.section("Mutation Proposals")
    proposals = payload.get("proposals", [])
    if proposals:
        for proposal in proposals:
            report.bullet(
                f"`{proposal.get('proposal_id', 'proposal')}` [{proposal.get('priority', 'medium')}]: "
                f"{proposal.get('title', 'Mutation Proposal')} ({proposal.get('category', 'mutation')})"
            )
            report.bullet(f"rationale: {proposal.get('rationale') or 'none'}")
            report.bullet(f"priority_score: {proposal.get('priority_score', 0.0)}")
            report.bullet(f"target_files: {', '.join(proposal.get('target_files', [])) or 'none'}")
            report.bullet(f"target_paths: {', '.join(proposal.get('target_paths', [])) or 'none'}")
            report.bullet(f"target_surfaces: {', '.join(proposal.get('target_surfaces', [])) or 'none'}")
            report.bullet(f"related_cases: {', '.join(proposal.get('related_cases', [])) or 'none'}")
            report.bullet(f"supporting_clusters: {', '.join(proposal.get('supporting_clusters', [])) or 'none'}")
            report.bullet(f"supporting_trace_events: {', '.join(proposal.get('supporting_trace_events', [])) or 'none'}")
            report.bullet(f"plan: {' | '.join(proposal.get('change_plan', [])) or 'none'}")
            report.bullet(f"expected_effects: {' | '.join(proposal.get('expected_effects', [])) or 'none'}")
            report.bullet(f"acceptance_checks: {' | '.join(proposal.get('acceptance_checks', [])) or 'none'}")
            report.bullet(f"validation_commands: {' | '.join(proposal.get('validation_commands', [])) or 'none'}")
            report.bullet(f"risks: {' | '.join(proposal.get('risks', [])) or 'none'}")
            report.blank()
    else:
        report.bullet("none")
        report.blank()

    report.section("Suggested Command Sequence")
    commands = payload.get("suggested_command_sequence", [])
    if commands:
        for command in commands:
            report.bullet(f"`{command}`")
    else:
        report.bullet("none")
    return report.text()


def render_patch_template_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Patch Template {payload['template_id']}")
    report.bullet(f"Proposal: `{payload.get('proposal_id') or 'unknown'}`")
    report.bullet(f"Experiment: `{payload.get('experiment_id') or 'unknown'}`")
    report.bullet(f"Baseline: `{payload.get('baseline_id') or 'none'}`")
    report.bullet(f"Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`")
    report.bullet(f"Category: `{payload.get('category') or 'mutation'}`")
    report.bullet(f"Status: `{payload.get('status') or 'draft'}`")
    report.bullet(f"Title: {payload.get('title') or 'Patch Template'}")
    report.bullet(f"Summary: {payload.get('summary') or 'none'}")

    report.section("Hypothesis")
    report.bullet(payload.get("hypothesis") or "Fill this in before editing.")
    report.blank()

    if payload.get("rationale"):
        report.section("Rationale")
        report.bullet(str(payload.get("rationale")))

    report.section("Target Files")
    for item in payload.get("target_files", []):
        report.bullet(f"`{item}`")
    if not payload.get("target_files"):
        report.bullet("none")

    report.section("Target Paths")
    for item in payload.get("target_paths", []):
        report.bullet(f"`{item}`")
    if not payload.get("target_paths"):
        report.bullet("none")

    report.section("Target Surfaces")
    for item in payload.get("target_surfaces", []):
        report.bullet(f"`{item}`")
    if not payload.get("target_surfaces"):
        report.bullet("none")

    report.section("Related Cases")
    for item in payload.get("related_cases", []):
        report.bullet(f"`{item}`")
    if not payload.get("related_cases"):
        report.bullet("none")

    report.section("Change Plan")
    for item in payload.get("change_plan", []):
        report.bullet(item)
    if not payload.get("change_plan"):
        report.bullet("none")

    report.section("Planned Edits")
    for item in payload.get("planned_edits", []):
        report.bullet(
            f"file=`{item.get('file', 'unknown')}`, status=`{item.get('status', 'pending')}`, "
            f"paths={', '.join(item.get('paths', [])) or 'none'}, objective={item.get('objective') or 'none'}"
        )
        report.bullet(f"planned_change: {item.get('planned_change') or 'Fill this in before implementing.'}")
    if not payload.get("planned_edits"):
        report.bullet("none")

    report.section("Expected Effects")
    for item in payload.get("expected_effects", []):
        report.bullet(item)
    if not payload.get("expected_effects"):
        report.bullet("none")

    report.section("Acceptance Checks")
    for item in payload.get("acceptance_checks", []):
        report.bullet(item)
    if not payload.get("acceptance_checks"):
        report.bullet("none")

    report.section("Validation Commands")
    for item in payload.get("validation_commands", []):
        report.bullet(f"`{item}`")
    if not payload.get("validation_commands"):
        report.bullet("none")

    report.section("Validation Results")
    for item in payload.get("validation_results", []):
        report.bullet(item)
    if not payload.get("validation_results"):
        report.bullet("none yet")

    report.section("Implementation Notes")
    for item in payload.get("implementation_notes", []):
        report.bullet(item)
    if not payload.get("implementation_notes"):
        report.bullet("none")

    report.section("Risks")
    for item in payload.get("risks", []):
        report.bullet(item)
    if not payload.get("risks"):
        report.bullet("none")
    return report.text()


def render_matrix_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Matrix {payload.get('matrix_id', 'matrix')}")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Agents: {', '.join(payload.get('agent_ids', [])) or 'none'}")
    report.bullet(
        f"Temperatures: {', '.join(str(item) for item in payload.get('temperatures', [])) or 'spec defaults'}"
    )
    report.bullet(f"Max tokens: {', '.join(str(item) for item in payload.get('max_tokens', [])) or 'spec defaults'}")
    report.bullet(f"Experiment count: {payload.get('experiment_count', 0)}")

    report.section("Best Variants")
    for label in ["best_by_score", "cheapest", "fastest"]:
        value = payload.get(label)
        if not value:
            report.bullet(f"`{label}`: none")
            continue
        report.bullet(
            f"`{label}`: `{value.get('experiment_id', 'unknown')}`, "
            f"score={float(value.get('average_score', 0.0)):.3f}, "
            f"passed={value.get('passed_cases', 0)}/{value.get('total_cases', 0)}, "
            f"cost={float(value.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(value.get('average_latency_ms', 0.0)):.1f}, "
            f"model=`{value.get('model_name', 'unknown')}`"
        )

    report.section("Pareto Frontier")
    for item in payload.get("pareto_frontier", []):
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: score={float(item.get('average_score', 0.0)):.3f}, "
            f"passed={item.get('passed_cases', 0)}/{item.get('total_cases', 0)}, "
            f"cost={float(item.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(item.get('average_latency_ms', 0.0)):.1f}, "
            f"steps={float(item.get('average_step_count', 0.0)):.2f}"
        )
    if not payload.get("pareto_frontier"):
        report.bullet("none")

    report.section("Experiments")
    for item in payload.get("experiments", []):
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: agent=`{item.get('agent_id', 'unknown')}`, "
            f"score={float(item.get('average_score', 0.0)):.3f}, "
            f"passed={item.get('passed_cases', 0)}/{item.get('total_cases', 0)}, "
            f"cost={float(item.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(item.get('average_latency_ms', 0.0)):.1f}, "
            f"model=`{item.get('model_name', 'unknown')}`"
        )
    if not payload.get("experiments"):
        report.bullet("none")
    return report.text()


def render_factorial_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Factorial {payload.get('factorial_id', 'factorial')}")
    report.bullet(f"Source experiment: `{payload.get('source_experiment_id') or 'unknown'}`")
    report.bullet(
        f"Control experiment: `{payload.get('control_experiment_id') or payload.get('source_experiment_id') or 'unknown'}`"
    )
    report.bullet(f"Agent: `{payload.get('agent_id') or 'unknown'}`")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Selection fingerprint: `{payload.get('selection_fingerprint') or 'unknown'}`")
    report.bullet(f"Selected cases: {payload.get('selected_case_count', 0)}")
    report.bullet(f"Selected factors: {', '.join(payload.get('selected_factors', [])) or 'none'}")
    report.bullet(f"Combination count: {payload.get('combination_count', 0)}")

    report.section("Factor Effects")
    for item in payload.get("factor_effects", []):
        report.bullet(
            f"`{item.get('factor', 'factor')}`: "
            f"score_effect={float(item.get('average_score_effect', 0.0)):+.3f}, "
            f"cost_effect={float(item.get('average_cost_effect', 0.0)):+.6f}, "
            f"evidence_use_effect={float(item.get('selected_evidence_use_rate_effect', 0.0)):+.3f}"
        )
    if not payload.get("factor_effects"):
        report.bullet("none")

    report.section("Surface Recommendations")
    for item in payload.get("surface_recommendations", [])[:8]:
        interaction = item.get("strongest_interaction") or {}
        report.bullet(
            f"`{item.get('surface', 'surface')}`: "
            f"recommendation=`{item.get('recommendation', 'review')}`, "
            f"use_rate={item.get('selected_evidence_use_rate', 'n/a')}, "
            f"score_effect={item.get('average_score_effect', 'n/a')}, "
            f"cost_effect={item.get('average_cost_effect', 'n/a')}, "
            f"interaction=`{interaction.get('pair', 'none')}`"
        )
        report.bullet(f"why: {' '.join(item.get('reasons', []) or ['none'])}")
    if not payload.get("surface_recommendations"):
        report.bullet("none")

    report.section("Pair Interactions")
    for item in payload.get("pair_interactions", []):
        report.bullet(
            f"`{item.get('pair', 'pair')}`: score_interaction={float(item.get('average_score_interaction', 0.0)):+.3f}"
        )
    if not payload.get("pair_interactions"):
        report.bullet("none")

    report.section("Pareto Frontier")
    for item in payload.get("pareto_frontier", []):
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: score={float(item.get('average_score', 0.0)):.3f}, "
            f"passed={item.get('passed_cases', 0)}/{item.get('total_cases', 0)}, "
            f"cost={float(item.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(item.get('average_latency_ms', 0.0)):.1f}"
        )
    if not payload.get("pareto_frontier"):
        report.bullet("none")

    report.section("Combinations")
    for item in payload.get("results", []):
        state = ", ".join(
            f"{label}={'on' if enabled else 'off'}"
            for label, enabled in sorted((item.get("state") or {}).items())
        )
        summary = item.get("summary") or {}
        deltas = item.get("deltas") or {}
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: {state or 'all on'}, "
            f"score={float(summary.get('average_score', 0.0)):.3f}, "
            f"passed={summary.get('passed_cases', 0)}/{summary.get('total_cases', 0)}, "
            f"cost={float(summary.get('average_cost_estimate', 0.0)):.6f}, "
            f"score_delta={float(deltas.get('average_score_delta', 0.0)):+.3f}, "
            f"passed_delta={float(deltas.get('passed_case_delta', 0.0)):+.3f}, "
            f"cost_delta={float(deltas.get('average_cost_delta', 0.0)):+.6f}"
        )
    if not payload.get("results"):
        report.bullet("none")
    return report.text()


def render_optimize_report(payload: dict[str, Any]) -> str:
    diagnosis = payload.get("diagnosis") or {}
    allocation = payload.get("allocation") or {}
    matrix = payload.get("matrix") or {}
    ablation = payload.get("ablation") or {}
    factorial = payload.get("factorial") or {}
    revalidation = payload.get("revalidation") or {}
    finalists = payload.get("finalists") or []
    recommended = payload.get("recommended_candidate") or {}
    recommended_summary = recommended.get("summary") or {}
    patch_handoff = payload.get("patch_handoff") or {}

    report = ReportBuilder(f"Optimize {payload.get('control_experiment_id') or 'unknown'}")
    report.bullet(f"Agent: `{payload.get('agent_id') or 'unknown'}`")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Preferred subset: `{payload.get('preferred_subset') or payload.get('subset') or 'unknown'}`")
    report.bullet(f"Control experiment: `{payload.get('control_experiment_id') or 'unknown'}`")
    report.bullet(
        f"Final control experiment: `{payload.get('final_control_experiment_id') or payload.get('control_experiment_id') or 'unknown'}`"
    )
    report.bullet(f"Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`")
    report.bullet(f"Search budget: {payload.get('search_budget', 0)}")
    report.bullet(f"Search experiments: {payload.get('search_experiment_count', 0)}")
    report.bullet(f"Source runs created: {payload.get('source_runs_created', 0)}")
    report.bullet(f"Unused budget: {payload.get('unused_budget', 0)}")

    report.section("Diagnosis")
    report.bullet(f"Recommended action: `{diagnosis.get('recommended_action') or 'review'}`")
    report.bullet(f"Summary: {diagnosis.get('summary') or 'none'}")
    baseline_id = diagnosis.get("baseline_id")
    if baseline_id:
        report.bullet(f"Baseline: `{baseline_id}`")
    focus_cases = diagnosis.get("focus_cases") or []
    if focus_cases:
        report.bullet(
            "Focus cases: " + ", ".join(str(item.get("case_id") or "unknown") for item in focus_cases[:5])
        )
    warnings = payload.get("warnings") or []
    if warnings:
        report.bullet(f"Warnings: {' | '.join(str(item) for item in warnings)}")

    report.section("Search Plan")
    report.bullet(
        f"Reserved revalidation budget: {int(allocation.get('reserved_revalidation_budget', 0) or 0)}"
    )
    report.bullet(f"Search-stage budget: {int(allocation.get('search_stage_budget', 0) or 0)}")
    report.bullet(
        f"Matrix stage requested: {bool(allocation.get('matrix_stage_requested', False))} "
        f"(budgeted experiments={int(allocation.get('matrix_experiment_budget', 0) or 0)})"
    )
    search_stage = allocation.get("search_stage_allocation") or {}
    report.bullet(
        f"Search-stage allocation: ablations={int(search_stage.get('ablation_limit', 0) or 0)}, "
        f"factorial_factors={int(search_stage.get('factorial_factor_target', 0) or 0)}, "
        f"factorial_search_spend={int(search_stage.get('factorial_experiment_budget', 0) or 0)}"
    )

    report.section("Model/Runtime Matrix")
    report.bullet(f"Requested: {bool(matrix.get('requested', False))}")
    report.bullet(f"Agent ids: {', '.join(matrix.get('agent_ids', [])) or 'none'}")
    report.bullet(f"Temperatures: {', '.join(str(item) for item in matrix.get('temperatures', [])) or 'none'}")
    report.bullet(f"Max tokens: {', '.join(str(item) for item in matrix.get('max_tokens', [])) or 'none'}")
    report.bullet(f"Experiment count: {int(matrix.get('experiment_count', 0) or 0)}")
    for item in (matrix.get("experiments") or [])[:4]:
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: "
            f"score={float(item.get('average_score', 0.0)):.3f}, "
            f"passed={item.get('passed_cases', 0)}/{item.get('total_cases', 0)}, "
            f"cost={float(item.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(item.get('average_latency_ms', 0.0)):.1f}"
        )
    if not matrix.get("experiments"):
        report.bullet("none")

    report.section("Ablation Stage")
    report.bullet(f"Ablation count: {ablation.get('ablation_count', 0)}")
    report.bullet(f"Surface filters: {', '.join(ablation.get('surface_filters', [])) or 'none'}")
    report.bullet(f"Shortlisted factors: {', '.join(ablation.get('shortlisted_factors', [])) or 'none'}")
    for item in (ablation.get("results") or [])[:6]:
        report.bullet(
            f"`{item.get('surface_kind', 'surface')}:{item.get('surface_name', 'unknown')}`: "
            f"effect={item.get('effect', 'unknown')}, "
            f"signal={item.get('optimization_signal', 'neutral')}, "
            f"score_delta={float(item.get('average_score_delta', 0.0)):+.3f}, "
            f"cost_delta={float(item.get('avg_cost_estimate_delta', 0.0)):+.6f}"
        )
    if not ablation.get("results"):
        report.bullet("none")

    report.section("Factorial Stage")
    report.bullet(f"Selected factors: {', '.join(factorial.get('selected_factors', [])) or 'none'}")
    report.bullet(f"Combination count: {factorial.get('combination_count', 0)}")
    for item in (factorial.get("results") or [])[:6]:
        state = ", ".join(
            f"{label}={'on' if enabled else 'off'}" for label, enabled in sorted((item.get("state") or {}).items())
        )
        summary = item.get("summary") or {}
        report.bullet(
            f"`{item.get('experiment_id', 'unknown')}`: {state or 'all on'}, "
            f"score={float(summary.get('average_score', 0.0)):.3f}, "
            f"passed={summary.get('passed_cases', 0)}/{summary.get('total_cases', 0)}, "
            f"cost={float(summary.get('average_cost_estimate', 0.0)):.6f}"
        )
    if not factorial.get("results"):
        report.bullet("none")

    report.section("Revalidation Stage")
    report.bullet(
        f"Preferred subset: `{revalidation.get('preferred_subset') or payload.get('preferred_subset') or 'unknown'}`"
    )
    report.bullet(f"Control revalidated: {bool(revalidation.get('control_revalidated', False))}")
    report.bullet(
        f"Revalidated finalist count: {int(revalidation.get('revalidated_finalist_count', 0) or 0)}"
    )
    for item in (revalidation.get("finalists") or [])[:4]:
        summary = item.get("summary") or {}
        report.bullet(
            f"`{summary.get('experiment_id', item.get('experiment_id', 'unknown'))}`: "
            f"source={item.get('source_experiment_id') or 'none'}, "
            f"score={float(summary.get('average_score', 0.0)):.3f}, "
            f"passed={summary.get('passed_cases', 0)}/{summary.get('total_cases', 0)}, "
            f"cost={float(summary.get('average_cost_estimate', 0.0)):.6f}"
        )
    if not revalidation.get("finalists"):
        report.bullet("none")

    report.section("Finalists")
    for item in finalists[:4]:
        summary = item.get("summary") or {}
        control_compare = item.get("control_compare") or {}
        baseline_compare = item.get("baseline_compare") or {}
        control_deltas = control_compare.get("metric_deltas") or {}
        baseline_deltas = baseline_compare.get("metric_deltas") or {}
        gate_failures = item.get("gate_failures") or []
        report.bullet(
            f"`{summary.get('experiment_id', item.get('experiment_id', 'unknown'))}` "
            f"({item.get('stage', 'candidate')}): action={item.get('recommended_action', 'review')}, "
            f"promotion_ready={bool(item.get('promotion_ready', False))}, "
            f"score={float(summary.get('average_score', 0.0)):.3f}, "
            f"passed={summary.get('passed_cases', 0)}/{summary.get('total_cases', 0)}, "
            f"cost={float(summary.get('average_cost_estimate', 0.0)):.6f}, "
            f"latency_ms={float(summary.get('average_latency_ms', 0.0)):.1f}"
        )
        report.bullet(
            f"baseline={item.get('baseline_id') or 'none'}, "
            f"control_score_delta={float(control_deltas.get('average_score', 0.0)):+.3f}, "
            f"baseline_score_delta={float(baseline_deltas.get('average_score', 0.0)):+.3f}, "
            f"gate_failures={', '.join(gate_failures) or 'none'}"
        )
    if not finalists:
        report.bullet("none")

    report.section("Recommended Candidate")
    report.bullet(
        f"`{recommended.get('experiment_id') or payload.get('control_experiment_id') or 'unknown'}` "
        f"({recommended.get('stage') or 'control'}): "
        f"score={float(recommended_summary.get('average_score', 0.0)):.3f}, "
        f"passed={recommended_summary.get('passed_cases', 0)}/{recommended_summary.get('total_cases', 0)}, "
        f"cost={float(recommended_summary.get('average_cost_estimate', 0.0)):.6f}, "
        f"latency_ms={float(recommended_summary.get('average_latency_ms', 0.0)):.1f}"
    )
    surface_changes = recommended.get("surface_changes") or []
    report.bullet(
        "Surface changes: "
        + (
            ", ".join(
                f"{item.get('factor')}={'on' if item.get('enabled', True) else 'off'}"
                for item in surface_changes
            )
            if surface_changes
            else "none"
        )
    )
    report.bullet(f"Why: {payload.get('recommendation_reason') or 'none'}")

    report.section("Patch Handoff")
    report.bullet(f"Proposal experiment: `{patch_handoff.get('proposal_experiment_id') or 'none'}`")
    report.bullet(f"Proposal id: `{patch_handoff.get('proposal_id') or 'none'}`")
    report.bullet(
        f"Recommended candidate experiment: `{patch_handoff.get('recommended_candidate_experiment_id') or 'none'}`"
    )
    template_paths = patch_handoff.get("template_paths") or {}
    for name, path in template_paths.items():
        report.bullet(f"{name}: `{path}`")
    if not template_paths:
        report.bullet("none")

    report.section("Proposals")
    for item in (payload.get("proposals") or {}).get("proposals", []):
        report.bullet(
            f"`{item.get('proposal_id', 'proposal')}` [{item.get('priority', 'medium')}]: "
            f"{item.get('title', 'Mutation Proposal')} ({item.get('category', 'mutation')})"
        )
    if not (payload.get("proposals") or {}).get("proposals"):
        report.bullet("none")

    report.section("Next Commands")
    for item in payload.get("next_commands", []):
        report.bullet(f"`{item.get('command', '')}`")
        report.bullet(f"why: {item.get('reason') or 'none'}")
    if not payload.get("next_commands"):
        report.bullet("none")
    return report.text()


def render_release_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder("Release Readiness")
    report.bullet(f"Project root: `{payload.get('project_root') or '.'}`")
    report.bullet(f"Overall ready: `{payload.get('overall_ready', False)}`")
    report.bullet(f"Streams: {payload.get('stream_count', 0)}")
    report.bullet(f"Ready streams: {payload.get('ready_stream_count', 0)}")
    report.bullet(f"Not ready streams: {payload.get('not_ready_stream_count', 0)}")

    report.section("Blocking Reasons")
    for item in payload.get("blocking_reasons", []):
        report.bullet(item)
    if not payload.get("blocking_reasons"):
        report.bullet("none")

    report.section("Streams")
    for item in payload.get("streams", []):
        promoted = item.get("promoted_baseline")
        latest_candidate = item.get("latest_candidate")
        latest_run = item.get("latest_run") or {}
        report.bullet(
            f"eval=`{item.get('eval_id') or 'unknown'}`, subset=`{item.get('subset') or 'unknown'}`, "
            f"benchmark=`{item.get('benchmark_signature') or 'unknown'}`, ready=`{item.get('ready', False)}`"
        )
        report.bullet(
            f"active_benchmark_signature={item.get('active_benchmark_signature') or 'unknown'}, "
            f"benchmark_signatures={', '.join(item.get('benchmark_signatures', [])) or 'none'}, "
            f"historical_stream_count={item.get('historical_stream_count', 0)}, "
            f"has_stale_promoted_baseline={item.get('has_stale_promoted_baseline', False)}"
        )
        report.bullet(f"reasons: {', '.join(item.get('reasons', [])) or 'none'}")
        report.bullet(f"promoted_baseline: {promoted.get('experiment_id') if promoted else 'none'}")
        stale_ids = [entry.get("experiment_id") for entry in item.get("stale_promoted_baselines", []) if entry]
        report.bullet(f"stale_promoted_baselines: {', '.join(stale_ids) or 'none'}")
        report.bullet(f"latest_run: {latest_run.get('experiment_id', 'none')}")
        report.bullet(f"latest_candidate: {latest_candidate.get('experiment_id') if latest_candidate else 'none'}")
        loop_readiness = item.get("loop_readiness") or {}
        if loop_readiness:
            report.bullet(
                f"loop_readiness: passed={loop_readiness.get('passed')}, "
                f"readiness_score={loop_readiness.get('readiness_score', 'n/a')}, "
                f"summary={loop_readiness.get('summary') or {}}"
            )
    if not payload.get("streams"):
        report.bullet("none")
    return report.text()


def render_redteam_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder("Red-Team Report")
    report.bullet(f"Experiment: `{payload.get('experiment_id') or 'unknown'}`")
    report.bullet(f"Baseline: `{payload.get('baseline_id') or 'none'}`")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Total red-team cases: {payload.get('total_redteam_cases', 0)}")
    report.bullet(f"Failed red-team cases: {payload.get('failed_redteam_cases', 0)}")
    report.bullet(f"Modes: {', '.join(payload.get('modes', [])) or 'none'}")
    report.bullet(f"Attack families: {', '.join(payload.get('attack_families', [])) or 'none'}")

    report.section("Mode Summary")
    for item in payload.get("mode_summary", []):
        report.bullet(
            f"`{item.get('mode') or 'unknown'}`: total={item.get('total', 0)}, "
            f"failure_rate={float(item.get('failure_rate', 0.0)):.3f}, "
            f"average_score={float(item.get('average_score', 0.0)):.3f}"
        )
    if not payload.get("mode_summary"):
        report.bullet("none")

    report.section("Family Summary")
    for item in payload.get("family_summary", []):
        report.bullet(
            f"`{item.get('family') or 'unknown'}`: total={item.get('total', 0)}, "
            f"failure_rate={float(item.get('failure_rate', 0.0)):.3f}, "
            f"attack_types={', '.join(item.get('attack_types', [])) or 'none'}"
        )
    if not payload.get("family_summary"):
        report.bullet("none")

    report.section("Attack Summary")
    for item in payload.get("attacks", []):
        report.bullet(
            f"`{item.get('attack_type', 'attack')}` [{item.get('mode') or 'unknown'} / {item.get('family') or 'unknown'}]: "
            f"passed={item.get('passed', 0)}/{item.get('total', 0)}, "
            f"average_score={item.get('average_score', 0.0)}, "
            f"baseline_average_score={item.get('baseline_average_score', 'n/a')}, "
            f"score_delta={item.get('score_delta', 'n/a')}"
        )
        report.bullet(f"cases: {', '.join(item.get('case_ids', [])) or 'none'}")
    if not payload.get("attacks"):
        report.bullet("none")

    report.section("Source Cases")
    for item in payload.get("source_case_summary", [])[:12]:
        report.bullet(
            f"`{item.get('source_case_id') or 'unknown'}`: total={item.get('total', 0)}, "
            f"failure_rate={float(item.get('failure_rate', 0.0)):.3f}, "
            f"attack_types={', '.join(item.get('attack_types', [])) or 'none'}"
        )
    if not payload.get("source_case_summary"):
        report.bullet("none")
    return report.text()


def render_ablation_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Ablations {payload.get('source_experiment_id', 'unknown')}")
    report.bullet(f"Agent: `{payload.get('agent_id') or 'unknown'}`")
    report.bullet(f"Eval: `{payload.get('eval_id') or 'unknown'}`")
    report.bullet(f"Subset: `{payload.get('subset') or 'unknown'}`")
    report.bullet(f"Surface filters: {', '.join(payload.get('surface_filters', [])) or 'none'}")
    report.bullet(f"Ablation count: {payload.get('ablation_count', 0)}")

    report.section("Results")
    for item in payload.get("results", []):
        pareto = item.get("pareto_summary") or {}
        report.bullet(
            f"`{item.get('surface_kind', 'surface')}:{item.get('surface_name', 'unknown')}`: "
            f"effect={item.get('effect', 'unknown')}, "
            f"signal={item.get('optimization_signal', 'neutral')}, "
            f"marginal_value_score={float(item.get('marginal_value_score', 0.0)):.3f}, "
            f"score_delta={float(item.get('average_score_delta', 0.0)):+.3f}, "
            f"passed_case_delta={float(item.get('passed_case_delta', 0.0)):+.1f}, "
            f"step_delta={float(item.get('avg_step_count_delta', 0.0)):+.3f}, "
            f"latency_delta={float(item.get('avg_latency_ms_delta', 0.0)):+.3f}, "
            f"cost_delta={float(item.get('avg_cost_estimate_delta', 0.0)):+.6f}, "
            f"evidence_use_delta={float(item.get('selected_evidence_use_rate_delta', 0.0)):+.3f}, "
            f"pareto_frontier={pareto.get('candidate_on_frontier', False)}"
        )
        report.bullet(
            f"trace_removed={', '.join(item.get('trace_events_removed', [])) or 'none'}, "
            f"trace_added={', '.join(item.get('trace_events_added', [])) or 'none'}"
        )
        report.bullet(f"surface_audit_delta={item.get('surface_audit_delta') or {}}")
    if not payload.get("results"):
        report.bullet("none")
    return report.text()


def render_brief_packet(packet: dict[str, Any]) -> str:
    report = ReportBuilder(f"Brief Packet: {packet['brief_id']}")
    report.bullet(f"Agent: `{packet.get('agent_id') or 'unspecified'}`")
    report.bullet(f"Goal: {packet.get('goal') or 'none'}")

    report.section("Learn The Repo First")
    for item in packet.get("repo_learning_prompts", []):
        report.bullet(item)

    report.section("Target Agent Files")
    report.bullet(f"Confirmed owned files: {', '.join(packet.get('confirmed_owned_files', [])) or 'none'}")
    report.bullet(f"Surface files: {packet.get('surface_paths') or 'none'}")
    report.bullet(
        f"Unclaimed candidate files: {', '.join(packet.get('unclaimed_candidate_files', [])) or 'none'}"
    )
    report.bullet(f"Provider hints: {', '.join(packet.get('provider_hints', [])) or 'none'}")
    report.bullet(f"Likely env keys: {', '.join(packet.get('likely_env_keys', [])) or 'none'}")

    report.section("Interview The User")
    for item in packet.get("interview_prompts", []):
        report.bullet(item)

    report.section("Likely Questions")
    for item in packet.get("likely_questions", []):
        report.bullet(item)
    if not packet.get("likely_questions"):
        report.bullet("none yet")

    report.section("Likely Commands")
    for item in packet.get("likely_commands", []):
        report.bullet(item)
    if not packet.get("likely_commands"):
        report.bullet("none yet")

    report.section("Rough Answer Outlines")
    for item in packet.get("rough_answer_outlines", []):
        report.bullet(f"Question: {item.get('question') or item.get('input') or 'unspecified'}")
        report.bullet(f"Outline: {item.get('outline') or item.get('expected') or 'unspecified'}")
    if not packet.get("rough_answer_outlines"):
        report.bullet("none yet")

    report.section("Workflow Scenarios")
    for item in packet.get("workflow_scenarios", []):
        name = item.get("name") or item.get("workflow") or item.get("trigger") or "unnamed-workflow"
        trigger = item.get("trigger") or item.get("prompt") or "unspecified"
        report.bullet(f"`{name}`: {trigger}")
        report.bullet(
            f"expected_tools={', '.join(item.get('expected_tools', [])) or 'none'}, "
            f"expected_skills={', '.join(item.get('expected_skills', [])) or 'none'}, "
            f"expected_plugins={', '.join(item.get('expected_plugins', [])) or 'none'}, "
            f"expected_mcps={', '.join(item.get('expected_mcps', [])) or 'none'}, "
            f"expected_prompts={', '.join(item.get('expected_prompt_keys', [])) or 'none'}, "
            f"expected_workflow_steps={', '.join(item.get('expected_workflow_steps', [])) or 'none'}, "
            f"expected_workflow_sequence={' -> '.join(item.get('expected_workflow_sequence', [])) or 'none'}, "
            f"max_steps={item.get('max_steps', 'n/a')}"
        )
    if not packet.get("workflow_scenarios"):
        report.bullet("none yet")

    report.section("Optimization Surface")
    for label, values in [
        ("Prompt variants", packet.get("prompt_variants", [])),
        ("Preferred tools", packet.get("preferred_tools", [])),
        ("Preferred skills", packet.get("preferred_skills", [])),
        ("Preferred plugins", packet.get("preferred_plugins", [])),
        ("Preferred MCPs", packet.get("preferred_mcps", [])),
    ]:
        report.bullet(f"{label}: {', '.join(values) or 'none'}")

    report.section("Definition Of Better")
    for item in packet.get("better_signals", []):
        report.bullet(f"Better: {item}")
    for item in packet.get("worse_signals", []):
        report.bullet(f"Worse: {item}")
    for item in packet.get("acceptance_criteria", []):
        report.bullet(f"Accept: {item}")

    report.human_checkpoints(packet.get("human_checkpoints", []))
    report.review_queue(packet.get("human_review_queue") or {})
    report.section("How To Test The Agent")
    report.bullet(
        "Capture expected output phrases, expected tool calls, expected skills, expected plugins, expected MCPs, and expected prompt variants in the approved brief and eval cases."
    )
    report.bullet("Use the workflow scenarios above as the starting contract for process alignment scoring.")
    report.bullet(
        "Prefer full eval runs for real optimization and promotion decisions. Use smoke subsets only for fast local debugging."
    )
    return report.text()


def render_eval_suite_report(payload: dict[str, Any]) -> str:
    report = ReportBuilder(f"Target Agent Eval Suite {payload['eval_id']}")
    report.bullet(f"Brief: `{payload.get('brief_id') or 'unknown'}`")
    report.bullet(f"Status: `{payload.get('approval_status') or 'draft'}`")
    report.bullet(f"Cases: {payload.get('generated_case_count', 0)}")
    report.bullet(f"Tags: {', '.join(payload.get('tags', [])) or 'none'}")

    report.section("Score Weights")
    for name, weight in (payload.get("score_weights") or {}).items():
        report.bullet(f"`{name}`: {float(weight):.3f}")
    if not payload.get("score_weights"):
        report.bullet("none")

    report.section("Splits")
    for name, count in (payload.get("split_sizes") or {}).items():
        report.bullet(f"`{name}`: {count}")
    if not payload.get("split_sizes"):
        report.bullet("none")

    expansion_summary = payload.get("expansion_summary") or {}
    if expansion_summary:
        report.section("Expansion Summary")
        report.bullet(f"Expanded cases: {expansion_summary.get('expanded_case_count', 0)}")
        source_counts = expansion_summary.get("source_counts") or {}
        report.bullet(
            "Sources: "
            + (", ".join(f"{name}={count}" for name, count in source_counts.items()) if source_counts else "none")
        )
        mode_counts = expansion_summary.get("mode_counts") or {}
        report.bullet(
            "Modes: "
            + (", ".join(f"{name}={count}" for name, count in mode_counts.items()) if mode_counts else "none")
        )
        expanded_split_sizes = expansion_summary.get("expanded_split_sizes") or {}
        report.bullet(
            "Expansion splits: "
            + (
                ", ".join(f"{name}={count}" for name, count in expanded_split_sizes.items())
                if expanded_split_sizes
                else "none"
            )
        )
        latest = expansion_summary.get("latest") or {}
        if latest:
            report.bullet(
                f"Latest expansion: {latest.get('timestamp') or 'unknown'}; "
                f"added={latest.get('added_case_count', 0)}, "
                f"previous_status=`{latest.get('previous_approval_status') or 'unknown'}`"
            )
            if latest.get("experiment_id"):
                report.bullet(f"Source experiment: `{latest.get('experiment_id')}`")
            warnings = [str(item) for item in latest.get("warnings", []) if str(item).strip()]
            if warnings:
                report.bullet(f"Warnings: {' | '.join(warnings)}")

    report.section("Notes")
    for item in payload.get("notes", []):
        report.bullet(item)
    if not payload.get("notes"):
        report.bullet("none")

    report.human_checkpoints(
        payload.get("human_checkpoints", []), heading="Human Checkpoints Before Approval"
    )
    report.review_queue(payload.get("human_review_queue") or {}, heading="Human Review Queue")
    report.section("Case Preview")
    for case in payload.get("cases", [])[:12]:
        metadata = case.get("metadata") or {}
        process = metadata.get("process_expectations") or {}
        expansion_source = metadata.get("expansion_source") or {}
        report.bullet(
            f"`{case.get('id', 'unknown')}` [{', '.join(case.get('tags', [])) or 'untagged'}]: "
            f"input={case.get('input', '')!r}, expected={case.get('expected', '')!r}"
        )
        if expansion_source:
            report.bullet(
                f"expansion: source={expansion_source.get('source') or 'unknown'}, "
                f"mode={expansion_source.get('mode') or 'unknown'}, "
                f"origin={expansion_source.get('source_case_id') or expansion_source.get('brief_id') or expansion_source.get('source_key') or 'n/a'}"
            )
        if process:
            report.bullet(
                f"process: required_tools={process.get('required_tools', [])}, required_skills={process.get('required_skills', [])}, "
                f"required_plugins={process.get('required_plugins', [])}, required_mcps={process.get('required_mcps', [])}, "
                f"required_prompt_keys={process.get('required_prompt_keys', [])}, "
                f"required_workflow_steps={process.get('required_workflow_steps', [])}, "
                f"workflow_sequence={process.get('workflow_sequence', [])}, "
                f"max_step_count={process.get('max_step_count')}"
            )
    if not payload.get("cases"):
        report.bullet("none")
    return report.text()


def write_report(path: Path, content: str) -> Path:
    ensure_dir(path.parent)
    return write_text(path, content)
