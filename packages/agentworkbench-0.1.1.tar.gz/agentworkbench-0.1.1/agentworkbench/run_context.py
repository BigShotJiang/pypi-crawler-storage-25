from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from agentworkbench.utils import write_json


def build_run_context(
    *,
    agent_id: str,
    eval_id: str,
    subset: str,
    selection: dict[str, Any],
    spec_snapshot: dict[str, Any],
    surface_snapshot: dict[str, Any],
    repo_before: dict[str, Any],
    benchmark_hashes_before: dict[str, str],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "selection": selection,
        "spec_snapshot": spec_snapshot,
        "surface_snapshot": surface_snapshot,
        "repo_before": repo_before,
        "benchmark_hashes_before": benchmark_hashes_before,
    }
    if extra:
        payload.update(extra)
    return payload


def persist_run_artifacts(
    exp_dir: Path,
    *,
    spec_snapshot: dict[str, Any],
    selection: dict[str, Any],
    surface_snapshot: dict[str, Any],
) -> None:
    write_json(exp_dir / "spec_snapshot.json", spec_snapshot)
    write_json(exp_dir / "case_selection.json", selection)
    write_json(exp_dir / "surface_snapshot.json", surface_snapshot)


def build_benchmark_signature(
    benchmark_hashes: dict[str, str],
    *,
    selection_fingerprint: str | None = None,
    extra: dict[str, Any] | None = None,
) -> str:
    payload = {str(key): str(value) for key, value in (benchmark_hashes or {}).items()}
    if selection_fingerprint:
        payload["case_selection"] = str(selection_fingerprint)
    if extra:
        for key, value in extra.items():
            if value is None:
                continue
            payload[str(key)] = str(value)
    encoded = json.dumps(payload, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()[:12]


__all__ = [
    "build_run_context",
    "persist_run_artifacts",
    "build_benchmark_signature",
]
