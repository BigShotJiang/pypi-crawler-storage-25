from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentworkbench.config import experiment_dir


def failed_cases_for_experiment(project_root: Path, experiment_id: str) -> list[dict[str, Any]]:
    failed_cases: list[dict[str, Any]] = []
    runs_path = experiment_dir(project_root, experiment_id) / "runs.jsonl"
    if not runs_path.exists():
        return failed_cases
    for row in runs_path.read_text(encoding="utf-8").splitlines():
        if not row.strip():
            continue
        payload = json.loads(row)
        if not payload.get("passed"):
            case_id = payload["case"]["id"]
            reason = "; ".join(item.get("reason", "") for item in payload.get("scores", []))
            failed_cases.append({"case_id": case_id, "reason": reason})
    return failed_cases


__all__ = ["failed_cases_for_experiment"]
