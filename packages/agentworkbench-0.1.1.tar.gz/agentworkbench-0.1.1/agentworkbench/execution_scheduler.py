from __future__ import annotations

import datetime as dt
import json
import random
import threading
import time as _time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from agentworkbench.evals import ScoringContext
from agentworkbench.models import AgentSpec, EvalCase
from agentworkbench.run_rows import build_scored_run_row
from agentworkbench.utils import ensure_dir, utc_timestamp_slug

# ---------------------------------------------------------------------------
# Retry policy
# ---------------------------------------------------------------------------


class RetryPolicy:
    def __init__(
        self,
        max_retries: int = 0,
        retry_on_errors: list[str] | None = None,
        backoff_multiplier: float = 1.0,
        max_backoff_seconds: float = 30.0,
        jitter: bool = True,
    ):
        self.max_retries: int = max_retries
        self.retry_on_errors: list[str] = retry_on_errors or []
        self.backoff_multiplier: float = backoff_multiplier
        self.max_backoff_seconds: float = max_backoff_seconds
        self.jitter: bool = jitter

    def should_retry(self, error: str) -> bool:
        if self.max_retries <= 0:
            return False
        if not self.retry_on_errors:
            return True
        error_lower = error.lower()
        return any(pattern.lower() in error_lower for pattern in self.retry_on_errors)

    def get_backoff(self, attempt: int) -> float:
        backoff = self.backoff_multiplier * (2 ** (attempt - 1))
        backoff = min(backoff, self.max_backoff_seconds)
        if self.jitter:
            backoff *= 0.5 + random.random() * 0.5
        return float(backoff)


DEFAULT_RETRY_POLICY = RetryPolicy(max_retries=0)


# ---------------------------------------------------------------------------
# Provider-aware concurrency buckets
# ---------------------------------------------------------------------------


class ConcurrencyBucket:
    """Provider-aware semaphore to prevent rate-limiting across models.

    Each provider name maps to a ``threading.Semaphore`` with its own
    concurrency ceiling. Callers acquire before making a provider request
    and release when done.
    """

    def __init__(self, limits: dict[str, int] | None = None, default_limit: int = 4):
        self._limits = {k.lower(): v for k, v in (limits or {}).items()}
        self._default_limit = default_limit
        self._semaphores: dict[str, threading.Semaphore] = {}
        self._lock = threading.Lock()

    def _get_semaphore(self, provider: str) -> threading.Semaphore:
        key = provider.lower()
        with self._lock:
            if key not in self._semaphores:
                limit = self._limits.get(key, self._default_limit)
                self._semaphores[key] = threading.Semaphore(limit)
            return self._semaphores[key]

    def acquire(self, provider: str) -> None:
        self._get_semaphore(provider).acquire()

    def release(self, provider: str) -> None:
        self._get_semaphore(provider).release()


# ---------------------------------------------------------------------------
# Heartbeat tracker
# ---------------------------------------------------------------------------


class HeartbeatTracker:
    """Incremental progress persistence for long-running executions.

    Periodically writes a heartbeat file that records which cases have been
    completed and their results, allowing mid-run restarts.
    """

    def __init__(self, heartbeat_path: Path | None = None, interval_seconds: float = 30.0):
        self._path = heartbeat_path
        self._interval = interval_seconds
        self._completed: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._last_flush = 0.0

    def record(self, case_id: str, row: dict[str, Any]) -> None:
        with self._lock:
            self._completed[case_id] = row
        now = _time.monotonic()
        if self._path and (now - self._last_flush) >= self._interval:
            self.flush()

    def flush(self) -> None:
        if not self._path:
            return
        with self._lock:
            snapshot = dict(self._completed)
        self._last_flush = _time.monotonic()
        ensure_dir(self._path.parent)
        self._path.write_text(
            json.dumps(
                {
                    "schema": "awb.heartbeat.v1",
                    "timestamp": utc_timestamp_slug(),
                    "completed_count": len(snapshot),
                    "case_ids": sorted(snapshot.keys()),
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def completed_case_ids(self) -> set[str]:
        with self._lock:
            return set(self._completed.keys())


# ---------------------------------------------------------------------------
# Execution backend
# ---------------------------------------------------------------------------


class ExecutionBackend:
    def __init__(
        self,
        max_concurrent: int = 1,
        retry_policy: RetryPolicy | None = None,
        concurrency_bucket: ConcurrencyBucket | None = None,
        heartbeat: HeartbeatTracker | None = None,
        on_case_complete: Callable[[str, dict[str, Any]], None] | None = None,
    ):
        self.max_concurrent = max_concurrent
        self.retry_policy = retry_policy or DEFAULT_RETRY_POLICY
        self.concurrency_bucket = concurrency_bucket
        self.heartbeat = heartbeat
        self.on_case_complete = on_case_complete

    def execute(
        self,
        project_root: Path,
        spec: AgentSpec,
        spec_snapshot: dict[str, Any],
        eval_id: str,
        cases: list[EvalCase],
        experiment_id: str,
        seed: int | None = None,
        case_ids_exclude: list[str] | None = None,
        *,
        scoring_context: ScoringContext | None = None,
        early_stop_consecutive_failures: int | None = None,
    ) -> dict[str, dict[str, Any]]:
        rows_by_case_id: dict[str, dict[str, Any]] = {}
        case_ids_exclude_set = set(case_ids_exclude or [])
        remaining_cases = [c for c in cases if c.id not in case_ids_exclude_set]
        if not remaining_cases:
            return rows_by_case_id

        total_remaining = len(remaining_cases)
        completed_in_this_run = 0


        rng = random.Random(seed) if seed is not None else None
        if rng is not None:
            rng.shuffle(remaining_cases)

        provider_name = str(spec.model.get("provider") or "").strip().lower()

        if self.max_concurrent == 1:
            streak = 0
            for case in remaining_cases:
                case_id, row = self._run_case_with_retry(
                    project_root,
                    spec,
                    spec_snapshot,
                    eval_id,
                    case,
                    experiment_id,
                    rng,
                    provider_name=provider_name,
                    scoring_context=scoring_context,
                )
                rows_by_case_id[case_id] = row
                completed_in_this_run += 1
                
                # Default status logging
                status = "✅" if row.get("passed") else "❌"
                latency = row.get("latency_ms", 0)
                print(f"[AWB] Progress: {completed_in_this_run}/{total_remaining} ({int(completed_in_this_run/total_remaining*100)}%) | {status} {case_id} | ⏱️ {latency}ms", flush=True)

                if self.heartbeat:
                    self.heartbeat.record(case_id, row)
                if self.on_case_complete:
                    self.on_case_complete(case_id, row)

                if early_stop_consecutive_failures:
                    if not row.get("passed"):
                        streak += 1
                        if streak >= early_stop_consecutive_failures:
                            break
                    else:
                        streak = 0
        else:
            with ThreadPoolExecutor(max_workers=min(self.max_concurrent, len(remaining_cases))) as executor:
                futures = {
                    executor.submit(
                        self._run_case_with_retry,
                        project_root,
                        spec,
                        spec_snapshot,
                        eval_id,
                        case,
                        experiment_id,
                        rng,
                        provider_name=provider_name,
                        scoring_context=scoring_context,
                    ): case.id
                    for case in remaining_cases
                }
                for future in as_completed(futures):
                    case_id, row = future.result()
                    rows_by_case_id[case_id] = row
                    completed_in_this_run += 1

                    # Default status logging
                    status = "✅" if row.get("passed") else "❌"
                    latency = row.get("latency_ms", 0)
                    print(f"[AWB] Progress: {completed_in_this_run}/{total_remaining} ({int(completed_in_this_run/total_remaining*100)}%) | {status} {case_id} | ⏱️ {latency}ms", flush=True)

                    if self.heartbeat:
                        self.heartbeat.record(case_id, row)
                    if self.on_case_complete:
                        self.on_case_complete(case_id, row)

        if self.heartbeat:
            self.heartbeat.flush()
        return rows_by_case_id

    def _run_case_with_retry(
        self,
        project_root: Path,
        spec: AgentSpec,
        spec_snapshot: dict[str, Any],
        eval_id: str,
        case: EvalCase,
        experiment_id: str,
        rng: random.Random | None,
        *,
        provider_name: str = "",
        scoring_context: ScoringContext | None = None,
    ) -> tuple[str, dict[str, Any]]:
        last_error: str = ""
        for attempt in range(self.retry_policy.max_retries + 1):
            if self.concurrency_bucket and provider_name:
                self.concurrency_bucket.acquire(provider_name)
            try:
                from agentworkbench.config import experiment_dir

                case_dir = ensure_dir(experiment_dir(project_root, experiment_id) / case.id)
                return build_scored_run_row(
                    project_root,
                    spec,
                    spec_snapshot,
                    eval_id,
                    case,
                    case_dir,
                    scoring_context=scoring_context,
                )
            except Exception as e:
                last_error = str(e)
                if attempt < self.retry_policy.max_retries and self.retry_policy.should_retry(last_error):
                    _time.sleep(self.retry_policy.get_backoff(attempt + 1))
                    continue
                raise
            finally:
                if self.concurrency_bucket and provider_name:
                    self.concurrency_bucket.release(provider_name)
        raise RuntimeError(f"Exhausted retries, last error: {last_error}")


# ---------------------------------------------------------------------------
# Resource accounting
# ---------------------------------------------------------------------------


class ResourceAccounting:
    def __init__(self):
        self.wall_clock_start: dt.datetime | None = None
        self.wall_clock_end: dt.datetime | None = None
        self.provider_time_ms: float = 0.0
        self.local_tool_time_ms: float = 0.0
        self.retry_count: int = 0

    def start(self) -> None:
        self.wall_clock_start = dt.datetime.now(dt.UTC)

    def end(self) -> None:
        self.wall_clock_end = dt.datetime.now(dt.UTC)

    def add_provider_time(self, ms: float) -> None:
        self.provider_time_ms += ms

    def add_local_tool_time(self, ms: float) -> None:
        self.local_tool_time_ms += ms

    def increment_retry(self) -> None:
        self.retry_count += 1

    def to_dict(self) -> dict[str, Any]:
        wall_clock_ms = 0.0
        if self.wall_clock_start and self.wall_clock_end:
            wall_clock_ms = (self.wall_clock_end - self.wall_clock_start).total_seconds() * 1000
        return {
            "wall_clock_ms": round(wall_clock_ms, 2),
            "provider_time_ms": round(self.provider_time_ms, 2),
            "local_tool_time_ms": round(self.local_tool_time_ms, 2),
            "retry_count": self.retry_count,
        }


# ---------------------------------------------------------------------------
# Factory helpers
# ---------------------------------------------------------------------------


def create_execution_backend(
    max_concurrent: int = 1,
    max_retries: int = 0,
    retry_on_errors: list[str] | None = None,
    backoff_multiplier: float = 1.0,
    max_backoff_seconds: float = 30.0,
    provider_concurrency_limits: dict[str, int] | None = None,
    heartbeat_path: Path | None = None,
    heartbeat_interval: float = 30.0,
    on_case_complete: Callable[[str, dict[str, Any]], None] | None = None,
) -> ExecutionBackend:
    retry_policy = RetryPolicy(
        max_retries=max_retries,
        retry_on_errors=retry_on_errors,
        backoff_multiplier=backoff_multiplier,
        max_backoff_seconds=max_backoff_seconds,
    )
    bucket = ConcurrencyBucket(limits=provider_concurrency_limits) if provider_concurrency_limits else None
    heartbeat = (
        HeartbeatTracker(heartbeat_path=heartbeat_path, interval_seconds=heartbeat_interval) if heartbeat_path else None
    )
    return ExecutionBackend(
        max_concurrent=max_concurrent,
        retry_policy=retry_policy,
        concurrency_bucket=bucket,
        heartbeat=heartbeat,
        on_case_complete=on_case_complete,
    )


def run_cases_parallel(
    project_root: Path,
    spec: AgentSpec,
    spec_snapshot: dict[str, Any],
    eval_id: str,
    cases: list[EvalCase],
    experiment_id: str,
    max_concurrent: int = 1,
    seed: int | None = None,
    *,
    scoring_context: ScoringContext | None = None,
    early_stop_consecutive_failures: int | None = None,
) -> dict[str, dict[str, Any]]:
    backend = create_execution_backend(max_concurrent=max_concurrent)
    return backend.execute(
        project_root,
        spec,
        spec_snapshot,
        eval_id,
        cases,
        experiment_id,
        seed=seed,
        scoring_context=scoring_context,
        early_stop_consecutive_failures=early_stop_consecutive_failures,
    )


__all__ = [
    "ConcurrencyBucket",
    "DEFAULT_RETRY_POLICY",
    "ExecutionBackend",
    "HeartbeatTracker",
    "ResourceAccounting",
    "RetryPolicy",
    "create_execution_backend",
    "run_cases_parallel",
]
