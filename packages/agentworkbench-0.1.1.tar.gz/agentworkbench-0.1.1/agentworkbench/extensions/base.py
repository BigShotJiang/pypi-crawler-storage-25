from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agentworkbench.models import AgentSpec, EvalCase, RunArtifact


class AdapterPlugin(ABC):
    """Stable interface for target-agent execution adapters."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this adapter (e.g. 'command', 'python')."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Semantic version of the plugin."""
        pass

    @property
    def capabilities(self) -> dict[str, bool]:
        """Declared capabilities for the runner to consider."""
        return {
            "tool_calling": False,
            "structured_output": False,
            "streaming": False,
        }

    @abstractmethod
    def invoke(
        self,
        project_root: Path,
        spec: AgentSpec,
        case: EvalCase,
        case_dir: Path,
    ) -> RunArtifact:
        """Execute the target agent for a single eval case.
        
        Must return a compliant RunArtifact.
        """
        pass


class ScorerPlugin(ABC):
    """Stable interface for custom evaluation scorers."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this scorer."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Version of this scorer plugin."""
        pass

    @property
    def supported_agent_types(self) -> list[str]:
        """Optionally restrict this scorer to specific agent types."""
        return ["general"]

    @abstractmethod
    def score_cases(
        self,
        run_artifact: dict[str, Any],
        case: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Calculate one or more scores for a single run-case row.
        
        Returns a list of dicts, each with:
        - name: str (metric name)
        - value: float (0.0 to 1.0)
        - passed: bool
        - reason: str (optional)
        """
        pass


class ReporterPlugin(ABC):
    """Stable interface for custom experiment visualization and reporting."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this reporter."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Version of this reporter plugin."""
        pass

    @abstractmethod
    def render(
        self,
        bundle: dict[str, Any],
        **options: Any,
    ) -> str:
        """Render a report (Markdown, HTML, etc.) from an experiment bundle."""
        pass


class ImporterPlugin(ABC):
    """Stable interface for importing external evaluation datasets."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this importer."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Version of this importer plugin."""
        pass

    @property
    def supported_formats(self) -> list[str]:
        """File extensions or format names supported (e.g. 'human_eval', 'gsm8k')."""
        return []

    @abstractmethod
    def import_dataset(
        self,
        source: Any,
        **options: Any,
    ) -> dict[str, Any]:
        """Import a dataset and return a compliant EvalSuite bundle."""
        pass


class TransportPlugin(ABC):
    """Stable interface for custom model communication transports."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this transport (e.g. 'openai', 'anthropic')."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Version of this transport plugin."""
        pass

    @property
    def supported_models(self) -> list[str]:
        """List of model prefixes or specific names supported."""
        return []

    @abstractmethod
    def complete(
        self,
        messages: list[dict[str, Any]],
        **options: Any,
    ) -> dict[str, Any]:
        """Send a completion/chat request and return a normalized dict."""
        pass


def validate_plugin_version(plugin: Any, min_version: str | None = None) -> dict[str, Any]:
    """Validate that a plugin meets the required interface and version."""
    issues: list[str] = []
    if not hasattr(plugin, "name") or not plugin.name:
        issues.append("Plugin must have a non-empty 'name' property")
    if not hasattr(plugin, "version") or not plugin.version:
        issues.append("Plugin must have a non-empty 'version' property")
    if min_version and hasattr(plugin, "version"):
        if str(plugin.version) < str(min_version):
            issues.append(f"Plugin version {plugin.version} is below minimum {min_version}")
    return {
        "valid": len(issues) == 0,
        "issues": issues,
    }


__all__ = [
    "AdapterPlugin",
    "ScorerPlugin",
    "ReporterPlugin",
    "ImporterPlugin",
    "TransportPlugin",
    "validate_plugin_version",
]
