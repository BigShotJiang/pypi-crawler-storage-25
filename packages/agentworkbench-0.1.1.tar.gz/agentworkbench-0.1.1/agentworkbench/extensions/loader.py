from __future__ import annotations

from importlib.metadata import EntryPoint, entry_points
from typing import Any

_EXTENSIONS: dict[str, dict[str, Any]] = {
    "adapters": {},
    "scorers": {},
    "reporters": {},
    "importers": {},
    "transports": {},
}

_GROUP_TO_CATEGORY = {
    "agentworkbench.adapters": "adapters",
    "agentworkbench.scorers": "scorers",
    "agentworkbench.reporters": "reporters",
    "agentworkbench.importers": "importers",
    "agentworkbench.transports": "transports",
}


def _entry_points_for_group(group: str) -> list[EntryPoint]:
    try:
        return list(entry_points(group=group))
    except TypeError:
        eps: Any = entry_points()
        if hasattr(eps, "select"):
            return list(eps.select(group=group))
        if isinstance(eps, dict):
            return list(eps.get(group, []))
        return []


def _discover_plugins(group: str) -> None:
    category = _GROUP_TO_CATEGORY.get(group)
    if category is None:
        return
    for ep in _entry_points_for_group(group):
        try:
            plugin = ep.load()
            _EXTENSIONS[category][ep.name] = {
                "plugin": plugin,
                "source": f"entrypoint:{ep.value}",
                "name": ep.name,
            }
        except Exception as e:
            _EXTENSIONS[category][ep.name] = {
                "error": str(e),
                "source": f"entrypoint:{ep.value}",
                "name": ep.name,
            }


def _discover_all() -> None:
    _discover_plugins("agentworkbench.adapters")
    _discover_plugins("agentworkbench.scorers")
    _discover_plugins("agentworkbench.reporters")
    _discover_plugins("agentworkbench.importers")
    _discover_plugins("agentworkbench.transports")


def register_plugin(
    category: str,
    name: str,
    plugin: Any,
    *,
    source: str = "registered",
) -> None:
    if category not in _EXTENSIONS:
        raise ValueError(f"Unknown extension category: {category}")
    _EXTENSIONS[category][name] = {
        "plugin": plugin,
        "source": source,
        "name": name,
    }


def list_extensions(category: str) -> list[dict[str, Any]]:
    if category not in _EXTENSIONS:
        raise ValueError(f"Unknown extension category: {category}")
    _discover_all()
    results = []
    for name, data in _EXTENSIONS[category].items():
        item: dict[str, Any] = {"name": name, "source": data.get("source", "unknown")}
        if "error" in data:
            item["error"] = data["error"]
            item["status"] = "error"
        else:
            item["status"] = "loaded"
            if hasattr(data["plugin"], "version"):
                item["version"] = data["plugin"].version
            if hasattr(data["plugin"], "capabilities"):
                item["capabilities"] = data["plugin"].capabilities
        results.append(item)
    return sorted(results, key=lambda x: x["name"])


def get_extension(category: str, name: str) -> Any:
    if category not in _EXTENSIONS:
        raise ValueError(f"Unknown extension category: {category}")
    _discover_all()
    data = _EXTENSIONS[category].get(name)
    if data is None:
        available = ", ".join(f"`{n}`" for n in _EXTENSIONS[category])
        raise ValueError(f"Unknown {category} `{name}`. Available: {available}.")
    if "error" in data:
        raise RuntimeError(f"Failed to load {category} `{name}`: {data['error']}")
    return data["plugin"]


def check_extension_health(category: str, name: str) -> dict[str, Any]:
    try:
        plugin = get_extension(category, name)
        from agentworkbench.extensions.base import validate_plugin_version

        validation = validate_plugin_version(plugin)
        return {
            "status": "healthy",
            "plugin": name,
            "category": category,
            "validation": validation,
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "plugin": name,
            "category": category,
            "error": str(e),
        }


__all__ = [
    "register_plugin",
    "list_extensions",
    "get_extension",
    "check_extension_health",
]
