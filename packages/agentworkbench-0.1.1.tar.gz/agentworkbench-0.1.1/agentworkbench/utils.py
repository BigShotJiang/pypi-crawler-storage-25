from __future__ import annotations

import datetime as dt
import json
import os
import re
import uuid
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import yaml


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def _atomic_write(path: Path, content: str) -> Path:
    ensure_dir(path.parent)
    temp_path = path.parent / f".{path.name}.{uuid.uuid4().hex}.tmp"
    temp_path.write_text(content, encoding="utf-8")
    os.replace(temp_path, path)
    return path


def write_text(path: Path, content: str) -> Path:
    return _atomic_write(path, content.rstrip() + "\n")


def write_json(path: Path, payload: Any) -> Path:
    return _atomic_write(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_jsonl(path: Path, rows: Iterable[Any]) -> Path:
    return _atomic_write(path, "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def read_jsonl(path: Path) -> list[Any]:
    rows: list[Any] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_yaml(path: Path, payload: Any) -> Path:
    return _atomic_write(path, yaml.safe_dump(payload, sort_keys=False))


def read_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key] = value
    return values


def utc_timestamp_slug() -> str:
    return dt.datetime.now(dt.UTC).strftime("%Y%m%d%H%M%S%f")


def created_at_utc() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def enabled_item_names(items: list[dict[str, object]], *, sort: bool = False) -> list[str]:
    names: list[str] = []
    for item in items:
        if not isinstance(item, dict) or not bool(item.get("enabled", True)):
            continue
        name = item.get("name") or item.get("id")
        text = str(name or "").strip()
        if text:
            names.append(text)
    unique = list(dict.fromkeys(names))
    return sorted(unique) if sort else unique


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "workbench"
