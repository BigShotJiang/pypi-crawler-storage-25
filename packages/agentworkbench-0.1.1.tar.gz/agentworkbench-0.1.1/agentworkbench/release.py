from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.reports import render_release_report, write_report
from agentworkbench.runner_compare import status_summary
from agentworkbench.utils import ensure_dir, write_json


def _stream_family_key(stream: dict[str, Any]) -> tuple[str, str]:
    return (str(stream.get("eval_id") or ""), str(stream.get("subset") or ""))

def release_readiness_summary(
    project_root: Path,
    *,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    promoted_only: bool = False,
    limit: int = 20,
) -> dict[str, Any]:
    status = status_summary(
        project_root,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        promoted_only=promoted_only,
        limit=limit,
    )
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for stream in status.get("streams", []):
        grouped.setdefault(_stream_family_key(stream), []).append(dict(stream))

    stream_rows: list[dict[str, Any]] = []
    blocking_reasons: list[str] = []
    for (family_eval_id, family_subset), family_streams in sorted(grouped.items()):
        family_streams = sorted(
            family_streams,
            key=lambda item: str((item.get("latest_run") or {}).get("created_at") or ""),
            reverse=True,
        )
        active_stream = family_streams[0]
        promoted_baseline = active_stream.get("promoted_baseline")
        latest_candidate = active_stream.get("latest_candidate")
        latest_run = active_stream.get("latest_run") or {}
        stale_promoted_baselines = [
            stream.get("promoted_baseline")
            for stream in family_streams[1:]
            if stream.get("promoted_baseline")
        ]
        reasons: list[str] = []
        ready = True
        if not promoted_baseline:
            ready = False
            if stale_promoted_baselines:
                reasons.append("promoted baseline exists only on stale benchmark signature")
            else:
                reasons.append("no promoted baseline")
        if latest_candidate and not promoted_baseline:
            reasons.append("candidate exists but has not passed promotion")
        if not latest_run:
            ready = False
            reasons.append("no experiments recorded")
        loop_readiness: dict[str, Any] = {}
        latest_run_id = str(latest_run.get("experiment_id") or "").strip()
        if latest_run_id:
            try:
                from agentworkbench.loop_checks import build_loop_check_report

                loop_payload = build_loop_check_report(
                    project_root,
                    experiment_id=latest_run_id,
                    fail_on="critical",
                    write=False,
                )
                loop_readiness = {
                    "passed": loop_payload.get("passed"),
                    "readiness_score": loop_payload.get("readiness_score"),
                    "summary": loop_payload.get("summary") or {},
                    "top_findings": (loop_payload.get("findings") or [])[:5],
                }
                if int((loop_payload.get("summary") or {}).get("critical", 0)) > 0:
                    ready = False
                    reasons.append("critical loop-readiness findings")
            except Exception as exc:
                loop_readiness = {"passed": False, "error": str(exc)}
        stream_row = {
            "eval_id": family_eval_id,
            "subset": family_subset,
            "benchmark_signature": active_stream.get("benchmark_signature"),
            "active_benchmark_signature": active_stream.get("benchmark_signature"),
            "benchmark_signatures": [stream.get("benchmark_signature") for stream in family_streams if stream.get("benchmark_signature")],
            "historical_stream_count": len(family_streams),
            "has_stale_promoted_baseline": bool(stale_promoted_baselines),
            "ready": ready,
            "reasons": reasons,
            "promoted_baseline": promoted_baseline,
            "latest_run": latest_run,
            "latest_candidate": latest_candidate,
            "stale_promoted_baselines": stale_promoted_baselines,
            "loop_readiness": loop_readiness,
        }
        stream_rows.append(stream_row)
        if not ready:
            label = f"{family_eval_id}:{family_subset}"
            blocking_reasons.append(f"{label}: {', '.join(reasons) or 'not ready'}")
    payload = {
        "project_root": str(project_root),
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "benchmark_signature": benchmark_signature,
        "promoted_only": promoted_only,
        "stream_count": len(stream_rows),
        "ready_stream_count": sum(1 for item in stream_rows if item.get("ready")),
        "not_ready_stream_count": sum(1 for item in stream_rows if not item.get("ready")),
        "overall_ready": bool(stream_rows) and all(bool(item.get("ready")) for item in stream_rows),
        "blocking_reasons": blocking_reasons,
        "streams": stream_rows,
        "status_summary": {
            "promotion_counts": status.get("promotion_counts") or {},
            "benchmark_signatures": status.get("benchmark_signatures") or [],
        },
    }
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    write_json(reports_dir / "release-latest.json", payload)
    write_report(reports_dir / "release-latest.md", render_release_report(payload))
    return payload


__all__ = ["release_readiness_summary"]
