"""Learned Scoring Models - Learn from human feedback and experiments.

This module provides learned scoring that improves over time by learning
from human feedback, promotion decisions, and experiment outcomes.

Usage:
    from agentworkbench.learned_scorer import LearnedScorer, fit_from_experiments

    # Initialize from prior experiments
    scorer = LearnedScorer(
        features=["score", "latency_ms", "cost_estimate", "tool_count", "evidence_use"]
    )

    # Fit to historical data
    scorer.fit(experiments=experiment_records, feedback=human_decisions)

    # Predict score for new outputs
    predicted_score = scorer.predict(output_features)

    # Update online as new data comes in
    scorer.update(output_features, actual_score)
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

FEATURE_EXTRACTORS: dict[str, Callable[..., Any]] = {}


def register_feature_extractor(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to register a feature extractor."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        FEATURE_EXTRACTORS[name] = func
        return func

    return decorator


@dataclass
class ScorerWeights:
    """Learned weights for scoring."""

    score_weight: float
    latency_weight: float
    cost_weight: float
    evidence_weight: float

    def predict(self, features: dict[str, float]) -> float:
        """Compute weighted prediction."""
        total = 0.0
        total += self.score_weight * features.get("score", 0)
        total += self.latency_weight * (1.0 - features.get("normalized_latency", 0.5))
        total += self.cost_weight * (1.0 - features.get("normalized_cost", 0.5))
        total += self.evidence_weight * features.get("evidence_use", 0)
        return total / (self.score_weight + self.latency_weight + self.cost_weight + self.evidence_weight + 1e-10)


class LinearScorer:
    """Simple linear model for scoring.

    Uses online learning to adapt to human preferences.
    """

    def __init__(self, features: list[str]):
        self.features = features
        self.weights = np.ones(len(features))
        self._feature_means: np.ndarray = np.ones(len(features))
        self._feature_stds: np.ndarray = np.ones(len(features))
        self._n_samples: int = 0

    def fit(
        self,
        X: list[dict[str, float]],
        y: list[float],
        alpha: float = 0.01,
    ) -> LinearScorer:
        """Fit linear model with L2 regularization.

        Args:
            X: List of feature dicts
            y: List of target scores
            alpha: L2 regularization strength
        """
        # Convert to matrix
        n_samples = len(X)
        n_features = len(self.features)

        X_mat = np.zeros((n_samples, n_features))
        for i, feats in enumerate(X):
            X_mat[i] = [feats.get(f, 0.0) for f in self.features]

        y_vec = np.array(y)

        # Compute mean/std for normalization
        self._feature_means = X_mat.mean(axis=0)
        self._feature_stds = X_mat.std(axis=0) + 1e-10

        # Normalize
        X_norm = (X_mat - self._feature_means) / self._feature_stds

        # Solve regularized least squares
        reg = alpha * np.eye(n_features)
        self.weights = np.linalg.lstsq(X_norm.T @ X_norm + reg, X_norm.T @ y_vec, rcond=None)[0]

        self._n_samples = n_samples
        return self

    def predict(self, features: dict[str, float]) -> float:
        """Predict score for features."""
        if self._n_samples < 2:
            # Default to simple average
            return sum(features.values()) / len(features) if features else 0.5

        X = np.array([features.get(f, 0.0) for f in self.features])
        X_norm = (X - self._feature_means) / self._feature_stds

        return float(np.clip(np.dot(X_norm, self.weights), 0.0, 1.0))

    def update(self, features: dict[str, float], target: float, learning_rate: float = 0.1) -> None:
        """Online update with new observation."""
        if self._n_samples < 2:
            # Can't update until we have initial model
            return

        # Simple incremental update
        X = np.array([features.get(f, 0.0) for f in self.features])
        X_norm = (X - self._feature_means) / self._feature_stds

        prediction = float(np.dot(X_norm, self.weights))
        error = target - prediction

        # Update weights
        self.weights += learning_rate * error * X_norm

        self._n_samples += 1


class PreferenceModel:
    """Learns human preferences from decisions.

    This extracts patterns from which experiments humans promote/reject
    to understand what matters to them.
    """

    def __init__(self):
        self._promoted_features: list[dict[str, float]] = []
        self._rejected_features: list[dict[str, float]] = []

    def fit(
        self,
        experiments: list[Any],
        promotion_decisions: list[bool],
    ) -> PreferenceModel:
        """Fit to promotion decisions.

        Args:
            experiments: List of ExperimentRecord
            promotion_decisions: True if promoted, False if rejected
        """
        # Extract features
        for exp, promoted in zip(experiments, promotion_decisions, strict=True):
            features = {
                "score": exp.scores.get("average_score", 0),
                "latency": exp.behavior_summary.get("average_latency_ms", 0),
                "cost": exp.behavior_summary.get("average_cost_estimate", 0),
                "passed_rate": exp.scores.get("passed_cases", 0),
                "stability": exp.scores.get("series_score_stddev", 1.0),
            }
            if promoted:
                self._promoted_features.append(features)
            else:
                self._rejected_features.append(features)

        return self

    def preference_score(self, features: dict[str, float]) -> float:
        """Compute how much this matches human preferences.

        Args:
            features: Feature dict for an experiment

        Returns:
            Score from 0 (rejected pattern) to 1 (promoted pattern)
        """
        if not self._promoted_features or not self._rejected_features:
            return 0.5

        # Simple comparison: closer to promoted mean, further from rejected mean
        promoted_mean = self._compute_mean(self._promoted_features)
        rejected_mean = self._compute_mean(self._rejected_features)

        distance_to_promoted = self._distance(features, promoted_mean)
        distance_to_rejected = self._distance(features, rejected_mean)

        # Prefer closer to promoted, farther from rejected
        total = distance_to_promoted + distance_to_rejected
        if total < 1e-10:
            return 0.5

        return distance_to_rejected / total

    def _compute_mean(self, features_list: list[dict[str, float]]) -> dict[str, float]:
        """Compute mean of feature dicts."""
        if not features_list:
            return {}

        all_keys: set[str] = set()
        for f in features_list:
            all_keys.update(f.keys())

        return {k: float(np.mean([f.get(k, 0) for f in features_list])) for k in all_keys}

    def _distance(self, a: dict[str, float], b: dict[str, float]) -> float:
        """Compute Euclidean distance."""
        keys = set(a.keys()) | set(b.keys())
        return float(sum((a.get(k, 0) - b.get(k, 0)) ** 2 for k in keys) ** 0.5)


@dataclass
class LearnedScorer:
    """Learned scoring that combines all signals.

    Combines:
    - Linear model for objective features
    - Preference model for human alignment
    - Online updates for continuous learning
    """

    features: list[str] = field(
        default_factory=lambda: ["score", "latency_ms", "cost_estimate", "evidence_use", "passed_cases"]
    )

    _linear: LinearScorer | None = field(default=None, init=False)
    _preference: PreferenceModel | None = field(default=None, init=False)

    def fit(
        self,
        experiments: list[Any] | None = None,
        feedback: list[dict[str, Any]] | None = None,
    ) -> LearnedScorer:
        """Fit to experiments and human feedback.

        Args:
            experiments: Optional list of ExperimentRecord
            feedback: Optional list of feedback dicts (with 'experiment_id', 'decision')
        """
        # Fit linear model from experiments
        if experiments:
            X = []
            y = []
            for exp in experiments:
                features = {
                    "score": exp.scores.get("average_score", 0),
                    "latency_ms": exp.behavior_summary.get("average_latency_ms", 0),
                    "cost_estimate": exp.behavior_summary.get("average_cost_estimate", 0),
                    "evidence_use": exp.behavior_summary.get("evidence_use_rate", 0),
                    "passed_cases": exp.scores.get("passed_cases", 0),
                }
                X.append(features)
                y.append(exp.scores.get("average_score", 0))

            self._linear = LinearScorer(self.features)
            self._linear.fit(X, y)

        # Fit preference model from feedback
        if feedback and experiments:
            exp_map = {e.experiment_id: e for e in experiments}

            exp_list = []
            decisions = []
            for fb in feedback:
                exp_id = fb.get("experiment_id")
                decision = fb.get("decision")  # "promote", "reject", "baseline", "candidate"

                if exp_id in exp_map and decision:
                    exp_list.append(exp_map[exp_id])
                    decisions.append(decision in ("promote", "baseline"))

            if exp_list:
                self._preference = PreferenceModel()
                self._preference.fit(exp_list, decisions)

        return self

    def predict(self, features: dict[str, float]) -> float:
        """Predict score combining all models.

        Args:
            features: Feature dict for prediction

        Returns:
            Combined score prediction
        """
        score = 0.5
        weights = [0.5, 0.3, 0.2]  # linear, preference, default

        if self._linear is not None:
            score += weights[0] * self._linear.predict(features)
        else:
            weights[0] = 0
            weights[2] = 0.7

        if self._preference is not None:
            score += weights[1] * self._preference.preference_score(features)
        else:
            weights[1] = 0

        return score / sum(weights)

    def update(self, features: dict[str, float], actual_score: float) -> None:
        """Online update with new observation."""
        if self._linear is not None:
            self._linear.update(features, actual_score)

    def feature_importance(self) -> dict[str, float]:
        """Get feature importance from learned model."""
        if self._linear is None:
            return {f: 1.0 / len(self.features) for f in self.features}

        return {f: abs(w) for f, w in zip(self.features, self._linear.weights, strict=True)}


def fit_from_experiments(
    experiments: list[Any],
    feedback: list[dict[str, Any]] | None = None,
) -> LearnedScorer:
    """Convenience function to fit a learned scorer.

    Args:
        experiments: List of ExperimentRecord
        feedback: Optional list of feedback dicts

    Returns:
        Fitted LearnedScorer
    """
    scorer = LearnedScorer()
    scorer.fit(experiments=experiments, feedback=feedback)
    return scorer


def save_learned_scorer(scorer: LearnedScorer, path: Path) -> None:
    """Save learned scorer to disk.

    Args:
        scorer: The LearnedScorer to save
        path: Path to save to (JSON/YAML)
    """
    import json

    data = {
        "features": scorer.features,
        "weights": scorer._linear.weights.tolist() if scorer._linear else None,
        "feature_means": scorer._linear._feature_means.tolist() if scorer._linear else None,
        "feature_stds": scorer._linear._feature_stds.tolist() if scorer._linear else None,
        "n_samples": scorer._linear._n_samples if scorer._linear else 0,
    }

    # Save preference model data
    if scorer._preference:
        data["preference_model"] = {
            "promoted_features": scorer._preference._promoted_features,
            "rejected_features": scorer._preference._rejected_features,
        }

    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_learned_scorer(path: Path) -> LearnedScorer:
    """Load learned scorer from disk.

    Args:
        path: Path to load from

    Returns:
        Loaded LearnedScorer
    """
    import json

    data = json.loads(path.read_text(encoding="utf-8"))

    features = data.get("features", ["score", "latency", "cost"])
    scorer = LearnedScorer(features=features)

    # Restore linear model
    if data.get("weights"):
        scorer._linear = LinearScorer(features)
        scorer._linear.weights = np.array(data["weights"])
        scorer._linear._feature_means = np.array(data.get("feature_means", [0.5] * len(features)))
        scorer._linear._feature_stds = np.array(data.get("feature_stds", [1.0] * len(features)))
        scorer._linear._n_samples = data.get("n_samples", 0)

    # Restore preference model
    if data.get("preference_model"):
        pm = PreferenceModel()
        pm._promoted_features = data["preference_model"].get("promoted_features", [])
        pm._rejected_features = data["preference_model"].get("rejected_features", [])
        scorer._preference = pm

    return scorer


__all__ = [
    "LearnedScorer",
    "LinearScorer",
    "PreferenceModel",
    "fit_from_experiments",
    "save_learned_scorer",
    "load_learned_scorer",
    "register_feature_extractor",
]
