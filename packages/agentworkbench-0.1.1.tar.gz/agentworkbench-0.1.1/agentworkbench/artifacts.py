from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, experiment_dir, experiments_root
from agentworkbench.constants import (
    ARTIFACT_SCHEMA_VERSION,
    PARTIAL_RUNS_FILENAME,
    RUN_CONTEXT_FILENAME,
)
from agentworkbench.human_review_store import load_review_queue_payload
from agentworkbench.models import ComparisonRecord
from agentworkbench.review_html import render_experiment_review_html
from agentworkbench.runner import _load_experiment, _load_run_rows
from agentworkbench.utils import (
    read_json,
    read_jsonl,
    write_json,
    write_text,
)


def load_experiment_bundle(project_root: Path, experiment_id: str) -> dict[str, Any]:
    record, aggregate = _load_experiment(project_root, experiment_id)
    exp_dir = experiment_dir(project_root, experiment_id)
    return {
        "artifact_schema_version": ARTIFACT_SCHEMA_VERSION,
        "experiment": record.model_dump(mode="json"),
        "aggregate": aggregate,
        "behavior": read_json(exp_dir / "behavior.json") if (exp_dir / "behavior.json").exists() else {},
        "spec_snapshot": read_json(exp_dir / "spec_snapshot.json") if (exp_dir / "spec_snapshot.json").exists() else {},
        "case_selection": read_json(exp_dir / "case_selection.json")
        if (exp_dir / "case_selection.json").exists()
        else {},
        "surface_snapshot": read_json(exp_dir / "surface_snapshot.json")
        if (exp_dir / "surface_snapshot.json").exists()
        else {},
        "run_context": read_json(exp_dir / RUN_CONTEXT_FILENAME) if (exp_dir / RUN_CONTEXT_FILENAME).exists() else {},
        "rows": _load_run_rows(project_root, experiment_id) if (exp_dir / "runs.jsonl").exists() else [],
        "partial_rows": read_jsonl(exp_dir / PARTIAL_RUNS_FILENAME),
    }


def load_case_bundle(project_root: Path, experiment_id: str, case_id: str) -> dict[str, Any]:
    bundle = load_experiment_bundle(project_root, experiment_id)
    for row in bundle.get("rows") or bundle.get("partial_rows") or []:
        case = row.get("case") or {}
        if str(case.get("id") or "") == str(case_id):
            return {
                "artifact_schema_version": ARTIFACT_SCHEMA_VERSION,
                "experiment_id": experiment_id,
                "case_id": case_id,
                "experiment": bundle.get("experiment") or {},
                "row": row,
            }
    raise ValueError(f"Case `{case_id}` was not found in experiment `{experiment_id}`.")


def load_compare_payload(
    project_root: Path,
    *,
    baseline_id: str | None = None,
    candidate_id: str | None = None,
    latest: bool = False,
) -> dict[str, Any]:
    reports_dir = control_dir(project_root) / "reports"
    if latest:
        path = reports_dir / "latest-compare.json"
    else:
        if not baseline_id or not candidate_id:
            raise ValueError("Provide both baseline_id and candidate_id, or use latest=True.")
        path = reports_dir / f"compare-{baseline_id}-to-{candidate_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Missing compare artifact: {path}")
    payload = ComparisonRecord.model_validate(read_json(path))
    return payload.model_dump(mode="json")


def export_experiment_bundle(project_root: Path, experiment_id: str, output_path: Path | None = None) -> dict[str, Any]:
    payload = load_experiment_bundle(project_root, experiment_id)
    if output_path is not None:
        write_json(output_path, payload)
    return payload


def export_review_html(
    project_root: Path,
    experiment_id: str,
    *,
    output_path: Path | None = None,
    baseline_id: str | None = None,
    queue_id: str | None = None,
) -> dict[str, Any]:
    payload = load_experiment_bundle(project_root, experiment_id)
    baseline_payload = load_experiment_bundle(project_root, baseline_id) if baseline_id else None
    resolved_queue_id = str(queue_id or f"diagnose-{experiment_id}")
    review_queue = load_review_queue_payload(project_root, resolved_queue_id)
    reports_dir = control_dir(project_root) / "reports"
    target_path = output_path or reports_dir / (
        f"review-{baseline_id}-to-{experiment_id}.html" if baseline_id else f"review-{experiment_id}.html"
    )
    write_text(target_path, render_experiment_review_html(payload, baseline_payload, review_queue=review_queue))
    return {
        "artifact_schema_version": ARTIFACT_SCHEMA_VERSION,
        "experiment_id": experiment_id,
        "baseline_id": baseline_id,
        "queue_id": resolved_queue_id if review_queue else None,
        "output_path": str(target_path),
    }


def migrate_artifacts(project_root: Path, *, check_only: bool = False) -> dict[str, Any]:
    experiments_migrated = 0
    compare_payloads_migrated = 0
    reports_dir = control_dir(project_root) / "reports"
    experiment_ids = [path.parent.name for path in sorted(experiments_root(project_root).glob("*/experiment.json"))]
    for experiment_id in experiment_ids:
        record, _aggregate = _load_experiment(project_root, experiment_id)
        exp_dir = experiment_dir(project_root, experiment_id)
        if not check_only:
            write_json(exp_dir / "experiment.json", record.model_dump(mode="json"))
        experiments_migrated += 1
    compare_paths = list(sorted(reports_dir.glob("compare-*-to-*.json")))
    if (reports_dir / "latest-compare.json").exists():
        compare_paths.append(reports_dir / "latest-compare.json")
    for path in compare_paths:
        payload = ComparisonRecord.model_validate(read_json(path))
        if not check_only:
            write_json(path, payload.model_dump(mode="json"))
        compare_payloads_migrated += 1
    return {
        "artifact_schema_version": ARTIFACT_SCHEMA_VERSION,
        "check_only": check_only,
        "experiments_migrated": experiments_migrated,
        "compare_payloads_migrated": compare_payloads_migrated,
    }


__all__ = [
    "load_experiment_bundle",
    "load_case_bundle",
    "load_compare_payload",
    "export_experiment_bundle",
    "export_review_html",
    "migrate_artifacts",
]
