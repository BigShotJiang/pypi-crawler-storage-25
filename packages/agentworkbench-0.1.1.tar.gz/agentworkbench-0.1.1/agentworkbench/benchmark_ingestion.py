from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
from collections import Counter
from collections.abc import Iterable, Iterator
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from agentworkbench.benchmarks import (
    _benchmark_metadata_from_suite,
    _bundle_manifest,
    _entry_version,
    _load_registry,
    _sorted_registry_entries,
    _string_list,
    _write_registry,
    benchmark_bundle_path,
    benchmark_integrity_report,
    benchmark_registry_path,
    benchmark_root,
)
from agentworkbench.config import control_dir
from agentworkbench.constants import BENCHMARK_INGESTION_SCHEMA_VERSION, BENCHMARK_SCHEMA_VERSION
from agentworkbench.evals import default_score_weights
from agentworkbench.models import EvalCase, EvalSuiteSpec
from agentworkbench.utils import (
    created_at_utc,
    ensure_dir,
    read_json,
    read_jsonl,
    read_yaml,
    slugify,
    utc_timestamp_slug,
    write_json,
    write_jsonl,
    write_text,
    write_yaml,
)

INGEST_STAGES = ["ingested", "normalized", "deduped", "validated", "reviewed", "published"]
DEFAULT_SHARD_SIZE = 5000


def ingested_benchmark_dir(project_root: Path, benchmark_id: str, version: int) -> Path:
    return benchmark_root(project_root) / "ingested" / slugify(benchmark_id) / f"v{int(version)}"


def manifest_path(project_root: Path, benchmark_id: str, version: int) -> Path:
    return ingested_benchmark_dir(project_root, benchmark_id, version) / "manifest.yaml"


def jobs_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "jobs")


def _job_path(project_root: Path, job_id: str) -> Path:
    return jobs_dir(project_root) / f"{job_id}.json"


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _hash_json(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def _manifest_fingerprint(manifest: dict[str, Any]) -> str:
    fingerprint_source = {
        key: value
        for key, value in manifest.items()
        if key not in {"fingerprint", "updated_at", "jobs", "stage_history"}
    }
    return _hash_json(fingerprint_source)[:16]


def _load_manifest(project_root: Path, benchmark_id: str, version: int) -> dict[str, Any]:
    path = manifest_path(project_root, benchmark_id, version)
    if not path.exists():
        raise FileNotFoundError(f"Benchmark ingestion manifest not found: {path}")
    payload = read_yaml(path) or {}
    if not isinstance(payload, dict):
        raise ValueError(f"Benchmark ingestion manifest must be a mapping: {path}")
    return payload


def _write_manifest(project_root: Path, manifest: dict[str, Any]) -> Path:
    benchmark_id = str(manifest["benchmark_id"])
    version = int(manifest["version"])
    root = ingested_benchmark_dir(project_root, benchmark_id, version)
    ensure_dir(root)
    manifest["updated_at"] = created_at_utc()
    manifest["fingerprint"] = _manifest_fingerprint(manifest)
    path = write_yaml(root / "manifest.yaml", manifest)
    history = ensure_dir(root / "manifest-history")
    history_index = len(list(history.glob("*.yaml"))) + 1
    write_yaml(history / f"{history_index:04d}-{slugify(str(manifest.get('stage') or 'unknown'))}.yaml", manifest)
    return path


def _next_ingestion_version(project_root: Path, benchmark_id: str) -> int:
    root = benchmark_root(project_root) / "ingested" / slugify(benchmark_id)
    staged_versions = []
    if root.exists():
        for path in root.glob("v*"):
            try:
                staged_versions.append(int(path.name[1:]))
            except ValueError:
                continue
    registry_versions = [
        _entry_version(entry)
        for entry in (_load_registry(project_root).get("benchmarks") or [])
        if str(entry.get("benchmark_id") or "") == str(benchmark_id)
    ]
    return max([0, *staged_versions, *registry_versions]) + 1


@contextmanager
def _benchmark_lock(project_root: Path, benchmark_id: str, version: int, stage: str) -> Iterator[Path]:
    root = ensure_dir(ingested_benchmark_dir(project_root, benchmark_id, version))
    path = root / ".lock"
    payload = {
        "benchmark_id": benchmark_id,
        "version": version,
        "stage": stage,
        "created_at": created_at_utc(),
        "pid": os.getpid(),
    }
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise RuntimeError(f"Benchmark `{benchmark_id}` v{version} is locked by {path}") from exc
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        yield path
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _start_job(
    project_root: Path,
    *,
    stage: str,
    benchmark_id: str,
    version: int,
    workers: int,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    job_id = f"benchmark-{slugify(stage)}-{slugify(benchmark_id)}-v{int(version)}-{utc_timestamp_slug()}"
    payload = {
        "job_id": job_id,
        "kind": "benchmark_ingestion",
        "stage": stage,
        "benchmark_id": benchmark_id,
        "version": int(version),
        "workers": max(1, int(workers or 1)),
        "status": "running",
        "started_at": created_at_utc(),
        "finished_at": "",
        "params": params or {},
        "result": {},
        "error": "",
    }
    write_json(_job_path(project_root, job_id), payload)
    return payload


def _finish_job(project_root: Path, job: dict[str, Any], *, result: dict[str, Any], error: str = "") -> dict[str, Any]:
    job = dict(job)
    job["finished_at"] = created_at_utc()
    job["status"] = "failed" if error else "completed"
    job["result"] = result
    job["error"] = error
    write_json(_job_path(project_root, str(job["job_id"])), job)
    return job


def _append_job(manifest: dict[str, Any], job: dict[str, Any]) -> None:
    jobs = [dict(item) for item in manifest.get("jobs") or [] if isinstance(item, dict)]
    jobs.append(
        {
            "job_id": job.get("job_id"),
            "stage": job.get("stage"),
            "status": job.get("status"),
            "started_at": job.get("started_at"),
            "finished_at": job.get("finished_at"),
            "workers": job.get("workers"),
        }
    )
    manifest["jobs"] = jobs


def _set_stage(manifest: dict[str, Any], stage: str) -> None:
    previous = str(manifest.get("stage") or "")
    manifest["stage"] = stage
    history = [dict(item) for item in manifest.get("stage_history") or [] if isinstance(item, dict)]
    history.append({"from": previous, "to": stage, "at": created_at_utc()})
    manifest["stage_history"] = history


def _read_source_rows(path: Path) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".jsonl":
        return [dict(item) for item in read_jsonl(path) if isinstance(item, dict)]
    if suffix == ".json":
        payload = read_json(path)
        if isinstance(payload, list):
            return [dict(item) for item in payload if isinstance(item, dict)]
        if isinstance(payload, dict):
            for key in ["cases", "rows", "data", "examples"]:
                if isinstance(payload.get(key), list):
                    return [dict(item) for item in payload[key] if isinstance(item, dict)]
            return [payload]
        raise ValueError("JSON source must contain an object, list, or a dict with cases/rows/data/examples.")
    if suffix == ".csv":
        with path.open("r", encoding="utf-8", newline="") as handle:
            return [dict(row) for row in csv.DictReader(handle)]
    raise ValueError("Supported benchmark ingestion sources are .jsonl, .json, and .csv files.")


def _iter_source_rows(path: Path) -> Iterable[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".jsonl":
        with path.open("r", encoding="utf-8") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                payload = json.loads(line)
                if not isinstance(payload, dict):
                    raise ValueError(f"{path}:{line_number}: JSONL benchmark rows must be objects.")
                yield payload
        return
    if suffix == ".csv":
        with path.open("r", encoding="utf-8", newline="") as handle:
            yield from (dict(row) for row in csv.DictReader(handle))
        return
    yield from _read_source_rows(path)


def _chunked(rows: list[dict[str, Any]], size: int) -> Iterable[tuple[int, list[dict[str, Any]]]]:
    chunk_size = max(1, int(size or DEFAULT_SHARD_SIZE))
    for index in range(0, len(rows), chunk_size):
        yield index // chunk_size + 1, rows[index : index + chunk_size]


class _StageShardWriter:
    def __init__(self, root: Path, *, stage: str, prefix: str, shard_size: int) -> None:
        self.root = root
        self.stage_dir = ensure_dir(root / stage)
        self.prefix = prefix
        self.shard_size = max(1, int(shard_size or DEFAULT_SHARD_SIZE))
        self.buffer: list[dict[str, Any]] = []
        self.shards: list[dict[str, Any]] = []
        self.row_count = 0
        for old_path in self.stage_dir.glob(f"{prefix}-*.jsonl"):
            old_path.unlink()

    def add(self, row: dict[str, Any]) -> None:
        self.buffer.append(row)
        self.row_count += 1
        if len(self.buffer) >= self.shard_size:
            self._flush()

    def add_many(self, rows: Iterable[dict[str, Any]]) -> None:
        for row in rows:
            self.add(row)

    def close(self) -> list[dict[str, Any]]:
        self._flush()
        return self.shards

    def _flush(self) -> None:
        if not self.buffer:
            return
        path = self.stage_dir / f"{self.prefix}-{len(self.shards) + 1:05d}.jsonl"
        write_jsonl(path, self.buffer)
        self.shards.append(
            {
                "path": str(path.relative_to(self.root)),
                "row_count": len(self.buffer),
                "case_count": len(self.buffer),
                "hash": _sha256_file(path),
            }
        )
        self.buffer = []


def _write_stage_shards(
    root: Path,
    *,
    stage: str,
    prefix: str,
    rows: list[dict[str, Any]],
    shard_size: int,
) -> list[dict[str, Any]]:
    writer = _StageShardWriter(root, stage=stage, prefix=prefix, shard_size=shard_size)
    writer.add_many(rows)
    return writer.close()


def _read_manifest_shards(root: Path, manifest: dict[str, Any], stage: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for shard in (manifest.get("shards") or {}).get(stage, []) or []:
        path = root / str(shard.get("path") or "")
        rows.extend(dict(item) for item in read_jsonl(path) if isinstance(item, dict))
    return rows


def _list_field(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if isinstance(value, tuple):
        return [str(item) for item in value if str(item).strip()]
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return []
        if stripped.startswith("["):
            try:
                payload = json.loads(stripped)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, list):
                return [str(item) for item in payload if str(item).strip()]
        return [item.strip() for item in stripped.split(",") if item.strip()]
    return [str(value)]


def _infer_answer_types(row: dict[str, Any], expected: str, rubric: list[str], explicit: list[str] | None) -> list[str]:
    if explicit:
        return list(dict.fromkeys(str(item) for item in explicit if str(item).strip()))
    raw = row.get("answer_type") or row.get("answer_types")
    values = _list_field(raw)
    if values:
        return values
    inferred: list[str] = []
    if expected:
        inferred.append("exact_or_reference")
    if rubric:
        inferred.append("rubric")
    metadata = dict(row.get("metadata") or {}) if isinstance(row.get("metadata"), dict) else {}
    expectations = metadata.get("process_expectations") or row.get("process_expectations")
    if expectations:
        inferred.append("process_expectations")
    return inferred or ["synthetic_unverified"]


def _default_scorer_content() -> str:
    return """from __future__ import annotations

from agentworkbench.scorer_utils import default_score_bundle


def score_cases(run_artifact: dict, case: dict) -> list[dict]:
    return default_score_bundle(run_artifact, case)
"""


def _source_metadata(source_path: Path, source_name: str | None, dataset_revision: str | None, license_name: str) -> dict[str, Any]:
    return {
        "name": str(source_name or source_path.stem),
        "path": str(source_path),
        "filename": source_path.name,
        "source_hash": _sha256_file(source_path),
        "dataset_revision": str(dataset_revision or ""),
        "license": str(license_name or ""),
    }


def ingest_benchmark_source(
    project_root: Path,
    *,
    source_path: Path,
    benchmark_id: str,
    version: int | None = None,
    source_name: str | None = None,
    dataset_revision: str | None = None,
    license_name: str = "",
    scorer_path: Path | None = None,
    scorer_version: str = "",
    shard_size: int = DEFAULT_SHARD_SIZE,
    workers: int = 1,
) -> dict[str, Any]:
    source_path = source_path.resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Benchmark source not found: {source_path}")
    resolved_version = int(version or _next_ingestion_version(project_root, benchmark_id))
    with _benchmark_lock(project_root, benchmark_id, resolved_version, "ingest"):
        job = _start_job(
            project_root,
            stage="ingest",
            benchmark_id=benchmark_id,
            version=resolved_version,
            workers=workers,
            params={"source_path": str(source_path), "shard_size": shard_size},
        )
        try:
            root = ingested_benchmark_dir(project_root, benchmark_id, resolved_version)
            ensure_dir(root / "raw")
            raw_snapshot = root / "raw" / source_path.name
            shutil.copyfile(source_path, raw_snapshot)
            source = _source_metadata(source_path, source_name, dataset_revision, license_name)
            raw_writer = _StageShardWriter(root, stage="raw", prefix="raw", shard_size=shard_size)
            raw_row_count = 0
            for index, row in enumerate(_iter_source_rows(source_path), start=1):
                raw_row_count = index
                raw_writer.add(
                    {
                        "raw_index": index,
                        "source_row_id": str(row.get("id") or row.get("case_id") or index),
                        "source": source,
                        "source_row": row,
                    }
                )
            shards = raw_writer.close()
            scorer: dict[str, Any] = {
                "filename": "",
                "version": scorer_version,
                "hash": "",
                "content": "",
            }
            if scorer_path:
                scorer_path = scorer_path.resolve()
                scorer_content = scorer_path.read_text(encoding="utf-8")
                scorer_target = ensure_dir(root / "scorers") / scorer_path.name
                write_text(scorer_target, scorer_content)
                scorer.update(
                    {
                        "filename": scorer_path.name,
                        "version": scorer_version,
                        "hash": _sha256_bytes(scorer_content.encode("utf-8")),
                        "path": str(scorer_target.relative_to(root)),
                        "content": scorer_content,
                    }
                )
            manifest = {
                "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
                "ingestion_schema_version": BENCHMARK_INGESTION_SCHEMA_VERSION,
                "benchmark_id": benchmark_id,
                "version": resolved_version,
                "stage": "ingested",
                "created_at": created_at_utc(),
                "updated_at": "",
                "source": source,
                "raw_snapshot": str(raw_snapshot.relative_to(root)),
                "case_count": 0,
                "raw_row_count": raw_row_count,
                "shard_size": int(shard_size),
                "shards": {"raw": shards, "normalized": [], "deduped": []},
                "transforms": [],
                "scorer": scorer,
                "splits": {},
                "validation": {},
                "governance": {"approval_status": "unreviewed", "review_queue_id": ""},
                "jobs": [],
                "stage_history": [],
            }
            finished = _finish_job(project_root, job, result={"raw_row_count": raw_row_count, "shard_count": len(shards)})
            _append_job(manifest, finished)
            _write_manifest(project_root, manifest)
            return {
                "benchmark_id": benchmark_id,
                "version": resolved_version,
                "stage": "ingested",
                "raw_row_count": raw_row_count,
                "shard_count": len(shards),
                "manifest_path": str(manifest_path(project_root, benchmark_id, resolved_version)),
                "job": finished,
            }
        except Exception as exc:
            _finish_job(project_root, job, result={}, error=str(exc))
            raise


def _normalize_raw_shard(
    root: Path,
    shard: dict[str, Any],
    *,
    benchmark_id: str,
    source: dict[str, Any],
    transform_hash: str,
    id_field: str,
    input_field: str,
    expected_field: str,
    rubric_field: str,
    tags_field: str,
    metadata_field: str,
    answer_types: list[str] | None,
    answer_source: str,
) -> list[dict[str, Any]]:
    path = root / str(shard.get("path") or "")
    output: list[dict[str, Any]] = []
    for raw in read_jsonl(path):
        source_row = dict((raw or {}).get("source_row") or {})
        raw_index = int((raw or {}).get("raw_index") or (len(output) + 1))
        case_id = str(
            source_row.get(id_field)
            or source_row.get("id")
            or source_row.get("case_id")
            or f"{slugify(benchmark_id)}-{raw_index:08d}"
        )
        input_text = str(source_row.get(input_field) or source_row.get("input") or source_row.get("prompt") or "")
        expected = str(source_row.get(expected_field) or source_row.get("expected") or source_row.get("answer") or "")
        rubric = _list_field(source_row.get(rubric_field) or source_row.get("rubric"))
        tags = _list_field(source_row.get(tags_field) or source_row.get("tags"))
        raw_metadata = source_row.get(metadata_field) or source_row.get("metadata") or {}
        metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
        case_answer_types = _infer_answer_types(source_row, expected, rubric, answer_types)
        provenance = {
            "source_name": source.get("name", ""),
            "source_path": source.get("path", ""),
            "source_row_id": str((raw or {}).get("source_row_id") or case_id),
            "source_revision": source.get("dataset_revision", ""),
            "source_hash": source.get("source_hash", ""),
            "license": source.get("license", ""),
            "raw_shard": shard.get("path", ""),
            "raw_index": raw_index,
            "transform_hash": transform_hash,
            "answer_type": case_answer_types,
            "answer_source": answer_source,
        }
        metadata["benchmark_provenance"] = provenance
        metadata["answer_type"] = case_answer_types
        metadata.setdefault("source", "benchmark_ingestion")
        case = {
            "id": case_id,
            "input": input_text,
            "expected": expected,
            "rubric": rubric,
            "tags": tags,
            "metadata": metadata,
            "turns": source_row.get("turns") if isinstance(source_row.get("turns"), list) else [],
        }
        output.append(EvalCase.model_validate(case).model_dump(mode="json"))
    return output


def normalize_ingested_benchmark(
    project_root: Path,
    *,
    benchmark_id: str,
    version: int,
    id_field: str = "id",
    input_field: str = "input",
    expected_field: str = "expected",
    rubric_field: str = "rubric",
    tags_field: str = "tags",
    metadata_field: str = "metadata",
    answer_types: list[str] | None = None,
    answer_source: str = "source_dataset",
    shard_size: int | None = None,
    workers: int = 1,
) -> dict[str, Any]:
    with _benchmark_lock(project_root, benchmark_id, version, "normalize"):
        manifest = _load_manifest(project_root, benchmark_id, version)
        root = ingested_benchmark_dir(project_root, benchmark_id, version)
        raw_shards = list((manifest.get("shards") or {}).get("raw") or [])
        if not raw_shards:
            raise ValueError(f"Benchmark `{benchmark_id}` v{version} has no raw shards to normalize.")
        params = {
            "id_field": id_field,
            "input_field": input_field,
            "expected_field": expected_field,
            "rubric_field": rubric_field,
            "tags_field": tags_field,
            "metadata_field": metadata_field,
            "answer_types": answer_types or [],
            "answer_source": answer_source,
        }
        transform_hash = _hash_json({"stage": "normalize", **params})[:16]
        job = _start_job(
            project_root,
            stage="normalize",
            benchmark_id=benchmark_id,
            version=version,
            workers=workers,
            params={**params, "transform_hash": transform_hash},
        )
        try:
            worker_count = max(1, int(workers or 1))
            normalized_writer = _StageShardWriter(
                root,
                stage="normalized",
                prefix="cases",
                shard_size=shard_size or int(manifest.get("shard_size") or DEFAULT_SHARD_SIZE),
            )
            provenance_path = ensure_dir(root / "provenance") / "sources.jsonl"
            case_count = 0
            with ThreadPoolExecutor(max_workers=worker_count) as executor:
                with provenance_path.open("w", encoding="utf-8") as provenance_handle:
                    for chunk in executor.map(
                        lambda shard: _normalize_raw_shard(
                            root,
                            shard,
                            benchmark_id=benchmark_id,
                            source=dict(manifest.get("source") or {}),
                            transform_hash=transform_hash,
                            id_field=id_field,
                            input_field=input_field,
                            expected_field=expected_field,
                            rubric_field=rubric_field,
                            tags_field=tags_field,
                            metadata_field=metadata_field,
                            answer_types=answer_types,
                            answer_source=answer_source,
                        ),
                        raw_shards,
                    ):
                        normalized_writer.add_many(chunk)
                        case_count += len(chunk)
                        for case in chunk:
                            provenance_handle.write(
                                json.dumps(
                                    {
                                        "case_id": case["id"],
                                        **dict((case.get("metadata") or {}).get("benchmark_provenance") or {}),
                                    },
                                    sort_keys=True,
                                )
                                + "\n"
                            )
            shards = normalized_writer.close()
            transform_record = {
                "stage": "normalize",
                "transform_hash": transform_hash,
                "params": params,
                "case_count": case_count,
                "created_at": created_at_utc(),
            }
            write_jsonl(root / "provenance" / "transforms.jsonl", [*read_jsonl(root / "provenance" / "transforms.jsonl"), transform_record])
            manifest.setdefault("shards", {})["normalized"] = shards
            manifest["case_count"] = case_count
            manifest["transforms"] = [*list(manifest.get("transforms") or []), transform_record]
            manifest["splits"] = {"full": {"case_count": case_count}, "smoke": {"case_count": min(3, case_count)}}
            _set_stage(manifest, "normalized")
            finished = _finish_job(project_root, job, result={"case_count": case_count, "shard_count": len(shards)})
            _append_job(manifest, finished)
            _write_manifest(project_root, manifest)
            return {
                "benchmark_id": benchmark_id,
                "version": version,
                "stage": "normalized",
                "case_count": case_count,
                "shard_count": len(shards),
                "transform_hash": transform_hash,
                "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
                "job": finished,
            }
        except Exception as exc:
            _finish_job(project_root, job, result={}, error=str(exc))
            raise


def _case_signature(case: dict[str, Any], strategy: str) -> str:
    if strategy == "exact_case":
        payload = {
            "input": " ".join(str(case.get("input") or "").lower().split()),
            "expected": " ".join(str(case.get("expected") or "").lower().split()),
            "rubric": [str(item).lower() for item in case.get("rubric") or []],
        }
    else:
        payload = {"input": " ".join(str(case.get("input") or "").lower().split())}
    return _hash_json(payload)


def dedupe_ingested_benchmark(
    project_root: Path,
    *,
    benchmark_id: str,
    version: int,
    strategy: str = "exact_input",
    shard_size: int | None = None,
    workers: int = 1,
) -> dict[str, Any]:
    del workers
    if strategy not in {"exact_input", "exact_case", "none"}:
        raise ValueError("Dedupe strategy must be one of: exact_input, exact_case, none.")
    with _benchmark_lock(project_root, benchmark_id, version, "dedupe"):
        manifest = _load_manifest(project_root, benchmark_id, version)
        root = ingested_benchmark_dir(project_root, benchmark_id, version)
        normalized_shards = list((manifest.get("shards") or {}).get("normalized") or [])
        if not normalized_shards:
            raise ValueError(f"Benchmark `{benchmark_id}` v{version} has no normalized cases to dedupe.")
        job = _start_job(
            project_root,
            stage="dedupe",
            benchmark_id=benchmark_id,
            version=version,
            workers=1,
            params={"strategy": strategy},
        )
        try:
            deduped_writer = _StageShardWriter(
                root,
                stage="deduped",
                prefix="cases",
                shard_size=shard_size or int(manifest.get("shard_size") or DEFAULT_SHARD_SIZE),
            )
            duplicates: list[dict[str, Any]] = []
            seen: dict[str, str] = {}
            input_case_count = 0
            for shard in normalized_shards:
                for case in read_jsonl(root / str(shard.get("path") or "")):
                    if not isinstance(case, dict):
                        continue
                    input_case_count += 1
                    signature = _case_signature(case, strategy)
                    if strategy != "none" and signature in seen:
                        duplicates.append(
                            {
                                "case_id": case.get("id"),
                                "duplicate_of": seen[signature],
                                "signature": signature,
                            }
                        )
                        continue
                    seen[signature] = str(case.get("id") or "")
                    deduped_writer.add(case)
            shards = deduped_writer.close()
            write_json(
                root / "provenance" / "dedupe.json",
                {
                    "strategy": strategy,
                    "input_case_count": input_case_count,
                    "case_count": deduped_writer.row_count,
                    "duplicate_count": len(duplicates),
                    "duplicates": duplicates,
                },
            )
            transform_record = {
                "stage": "dedupe",
                "transform_hash": _hash_json({"stage": "dedupe", "strategy": strategy})[:16],
                "params": {"strategy": strategy},
                "input_case_count": input_case_count,
                "case_count": deduped_writer.row_count,
                "duplicate_count": len(duplicates),
                "created_at": created_at_utc(),
            }
            write_jsonl(root / "provenance" / "transforms.jsonl", [*read_jsonl(root / "provenance" / "transforms.jsonl"), transform_record])
            manifest.setdefault("shards", {})["deduped"] = shards
            manifest["case_count"] = deduped_writer.row_count
            manifest["duplicate_count"] = len(duplicates)
            manifest["transforms"] = [*list(manifest.get("transforms") or []), transform_record]
            manifest["splits"] = {
                "full": {"case_count": deduped_writer.row_count},
                "smoke": {"case_count": min(3, deduped_writer.row_count)},
            }
            _set_stage(manifest, "deduped")
            finished = _finish_job(
                project_root,
                job,
                result={
                    "case_count": deduped_writer.row_count,
                    "duplicate_count": len(duplicates),
                    "shard_count": len(shards),
                },
            )
            _append_job(manifest, finished)
            _write_manifest(project_root, manifest)
            return {
                "benchmark_id": benchmark_id,
                "version": version,
                "stage": "deduped",
                "case_count": deduped_writer.row_count,
                "duplicate_count": len(duplicates),
                "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
                "job": finished,
            }
        except Exception as exc:
            _finish_job(project_root, job, result={}, error=str(exc))
            raise


def _final_case_stage(manifest: dict[str, Any]) -> str:
    shards = manifest.get("shards") or {}
    if shards.get("deduped"):
        return "deduped"
    if shards.get("normalized"):
        return "normalized"
    return ""


def validate_ingested_benchmark(
    project_root: Path,
    *,
    benchmark_id: str,
    version: int,
    workers: int = 1,
) -> dict[str, Any]:
    with _benchmark_lock(project_root, benchmark_id, version, "validate"):
        manifest = _load_manifest(project_root, benchmark_id, version)
        root = ingested_benchmark_dir(project_root, benchmark_id, version)
        stage = _final_case_stage(manifest)
        if not stage:
            raise ValueError(f"Benchmark `{benchmark_id}` v{version} has no normalized or deduped cases to validate.")
        shards = list((manifest.get("shards") or {}).get(stage) or [])
        job = _start_job(
            project_root,
            stage="validate",
            benchmark_id=benchmark_id,
            version=version,
            workers=workers,
            params={"case_stage": stage},
        )
        try:
            def _validate_shard(shard: dict[str, Any]) -> dict[str, Any]:
                path = root / str(shard.get("path") or "")
                rows = read_jsonl(path)
                issues: list[str] = []
                warnings: list[str] = []
                cases: list[dict[str, Any]] = []
                for index, row in enumerate(rows, start=1):
                    try:
                        case = EvalCase.model_validate(row).model_dump(mode="json")
                    except Exception as exc:
                        issues.append(f"{path.name}:{index}: invalid eval case: {exc}")
                        continue
                    provenance = dict((case.get("metadata") or {}).get("benchmark_provenance") or {})
                    if not provenance:
                        warnings.append(f"{case['id']}: missing benchmark provenance")
                    if not str(provenance.get("license") or "").strip():
                        warnings.append(f"{case['id']}: missing source license")
                    if not _list_field((case.get("metadata") or {}).get("answer_type") or provenance.get("answer_type")):
                        warnings.append(f"{case['id']}: missing answer type")
                    cases.append(case)
                return {"path": str(path.relative_to(root)), "issues": issues, "warnings": warnings, "cases": cases}

            with ThreadPoolExecutor(max_workers=max(1, int(workers or 1))) as executor:
                shard_results = list(executor.map(_validate_shard, shards))
            issues = [issue for item in shard_results for issue in item["issues"]]
            warnings = [warning for item in shard_results for warning in item["warnings"]]
            cases = [case for item in shard_results for case in item["cases"]]
            ids = [str(case.get("id") or "") for case in cases]
            id_counts = Counter(ids)
            duplicate_ids = sorted(case_id for case_id, count in id_counts.items() if case_id and count > 1)
            if duplicate_ids:
                issues.append(f"Duplicate case ids: {', '.join(duplicate_ids[:20])}")
            if not cases:
                issues.append("Benchmark contains no valid cases.")
            bundle = _legacy_bundle_from_cases(project_root, manifest, cases, eval_id=str(manifest["benchmark_id"]))
            integrity = benchmark_integrity_report(bundle)
            issues.extend(str(item) for item in integrity.get("issues") or [])
            warnings.extend(str(item) for item in integrity.get("warnings") or [])
            answer_type_counts: Counter[str] = Counter()
            for case in cases:
                for answer_type in _list_field((case.get("metadata") or {}).get("answer_type")):
                    answer_type_counts[answer_type] += 1
            validation = {
                "healthy": not issues,
                "case_stage": stage,
                "case_count": len(cases),
                "shard_count": len(shards),
                "issues": issues,
                "warnings": sorted(dict.fromkeys(warnings)),
                "answer_type_counts": dict(sorted(answer_type_counts.items())),
                "integrity": integrity,
                "validated_at": created_at_utc(),
            }
            write_json(root / "validation" / "latest.json", validation)
            write_text(
                root / "validation" / "latest.md",
                "\n".join(
                    [
                        f"# Benchmark Validation: {benchmark_id} v{version}",
                        "",
                        f"Healthy: {validation['healthy']}",
                        f"Case count: {validation['case_count']}",
                        f"Shard count: {validation['shard_count']}",
                        "",
                        "## Issues",
                        *(f"- {item}" for item in issues),
                        "",
                        "## Warnings",
                        *(f"- {item}" for item in sorted(dict.fromkeys(warnings)) if str(item).strip()),
                    ]
                ),
            )
            manifest["validation"] = validation
            _set_stage(manifest, "validated" if validation["healthy"] else "validation_failed")
            finished = _finish_job(project_root, job, result=validation)
            _append_job(manifest, finished)
            _write_manifest(project_root, manifest)
            return {
                "benchmark_id": benchmark_id,
                "version": version,
                "stage": manifest["stage"],
                "validation": validation,
                "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
                "job": finished,
            }
        except Exception as exc:
            _finish_job(project_root, job, result={}, error=str(exc))
            raise


def review_ingested_benchmark(
    project_root: Path,
    *,
    benchmark_id: str,
    version: int,
    approve: bool = False,
    reviewer: str = "human",
    guidance: str = "",
) -> dict[str, Any]:
    with _benchmark_lock(project_root, benchmark_id, version, "review"):
        manifest = _load_manifest(project_root, benchmark_id, version)
        validation = dict(manifest.get("validation") or {})
        queue_id = f"benchmark-{slugify(benchmark_id)}-v{int(version)}"
        checkpoints: list[dict[str, Any]] = []
        if not validation.get("healthy"):
            checkpoints.append(
                {
                    "checkpoint_id": "benchmark-validation",
                    "title": "Resolve validation issues",
                    "priority": "high",
                    "question": "Are all schema, split, provenance, and scorer issues resolved?",
                    "reason": "; ".join(str(item) for item in validation.get("issues") or []) or "Validation has not passed.",
                    "review_type": "governance",
                    "question_type": "approval",
                }
            )
        answer_counts = validation.get("answer_type_counts") or {}
        synthetic_count = int(answer_counts.get("synthetic_unverified", 0) or 0)
        if synthetic_count:
            checkpoints.append(
                {
                    "checkpoint_id": "synthetic-unverified",
                    "title": "Review synthetic or unverified answers",
                    "priority": "high",
                    "question": "Are synthetic/unverified cases reviewed or intentionally excluded from promotion gates?",
                    "reason": f"{synthetic_count} cases are tagged synthetic_unverified.",
                    "review_type": "governance",
                    "question_type": "approval",
                }
            )
        if not str((manifest.get("source") or {}).get("license") or "").strip():
            checkpoints.append(
                {
                    "checkpoint_id": "source-license",
                    "title": "Confirm source license",
                    "priority": "high",
                    "question": "Is the source license and usage permission documented?",
                    "reason": "The ingestion manifest does not include a license.",
                    "review_type": "governance",
                    "question_type": "approval",
                }
            )
        if not checkpoints:
            checkpoints.append(
                {
                    "checkpoint_id": "publish-approval",
                    "title": "Approve benchmark publication",
                    "priority": "medium",
                    "question": "Is this benchmark version ready to publish as an immutable registry artifact?",
                    "reason": "Validation passed and no high-risk provenance gaps were detected.",
                    "review_type": "governance",
                    "question_type": "approval",
                }
            )
        approval_status = "approved" if approve else "review"
        queue = {
            "queue_id": queue_id,
            "stage": "benchmark_review",
            "subject": f"{benchmark_id} v{version}",
            "items": checkpoints,
            "pending_count": 0 if approve else len(checkpoints),
            "resolved_count": len(checkpoints) if approve else 0,
            "all_resolved": approve,
            "created_at": created_at_utc(),
        }
        write_json(control_dir(project_root) / "reports" / f"benchmark-review-queue-{slugify(benchmark_id)}-v{int(version)}.json", queue)
        governance = {
            "approval_status": approval_status,
            "review_queue_id": queue_id,
            "reviewer": reviewer if approve else "",
            "reviewed_at": created_at_utc() if approve else "",
            "guidance": guidance,
            "checkpoint_count": len(checkpoints),
        }
        manifest["governance"] = governance
        _set_stage(manifest, "reviewed" if approve else "review")
        _write_manifest(project_root, manifest)
        return {
            "benchmark_id": benchmark_id,
            "version": version,
            "stage": manifest["stage"],
            "governance": governance,
            "review_queue": queue,
            "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
        }


def _legacy_bundle_from_cases(
    project_root: Path,
    manifest: dict[str, Any],
    cases: list[dict[str, Any]],
    *,
    eval_id: str,
) -> dict[str, Any]:
    del project_root
    eval_cases = [EvalCase.model_validate(case) for case in cases]
    suite = EvalSuiteSpec(
        id=eval_id,
        brief_id="",
        approval_status="approved",
        score_weights=default_score_weights(),
        notes=[
            f"Installed from sharded benchmark `{manifest['benchmark_id']}` v{manifest['version']}.",
            "Source provenance, transform hashes, answer types, and license metadata are preserved in case metadata.",
        ],
        generated_case_count=len(eval_cases),
        tags=sorted({tag for case in eval_cases for tag in case.tags}),
        metadata={
            "benchmark": {
                "origin_repo": str((manifest.get("source") or {}).get("name") or ""),
                "author": "benchmark-ingestion",
                "version": str((manifest.get("source") or {}).get("dataset_revision") or f"v{manifest['version']}"),
                "license": str((manifest.get("source") or {}).get("license") or ""),
                "intended_agent_type": "",
                "required_capabilities": [],
                "description": f"Sharded benchmark imported from {(manifest.get('source') or {}).get('name') or 'source dataset'}.",
            },
            "ingestion_manifest": {
                "benchmark_id": manifest["benchmark_id"],
                "version": manifest["version"],
                "fingerprint": manifest.get("fingerprint", ""),
                "source": manifest.get("source") or {},
                "transforms": manifest.get("transforms") or [],
                "governance": manifest.get("governance") or {},
            },
        },
    )
    full_ids = [case.id for case in eval_cases]
    splits = {"smoke": full_ids[: min(3, len(full_ids))], "full": full_ids}
    scorer = dict(manifest.get("scorer") or {})
    scorer_content = str(scorer.get("content") or "") or _default_scorer_content()
    bundle = {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": str(manifest["benchmark_id"]),
        "source_eval_id": eval_id,
        "exported_at": created_at_utc(),
        "suite": suite.model_dump(mode="json"),
        "benchmark_metadata": _benchmark_metadata_from_suite(suite),
        "cases": [case.model_dump(mode="json") for case in eval_cases],
        "splits": splits,
        "scorer": {
            "filename": str(scorer.get("filename") or f"{eval_id}_default.py"),
            "version": str(scorer.get("version") or ""),
            "hash": str(scorer.get("hash") or _sha256_bytes(scorer_content.encode("utf-8"))),
            "content": scorer_content,
        },
        "sharded_manifest": manifest,
    }
    bundle["manifest"] = _bundle_manifest(bundle)
    return bundle


def publish_ingested_benchmark(
    project_root: Path,
    *,
    benchmark_id: str,
    version: int,
    eval_id: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    with _benchmark_lock(project_root, benchmark_id, version, "publish"):
        manifest = _load_manifest(project_root, benchmark_id, version)
        root = ingested_benchmark_dir(project_root, benchmark_id, version)
        validation = dict(manifest.get("validation") or {})
        governance = dict(manifest.get("governance") or {})
        if not force and not validation.get("healthy"):
            raise ValueError("Benchmark must pass validation before publish. Re-run with --force to override.")
        if not force and governance.get("approval_status") != "approved":
            raise ValueError("Benchmark must be governance-approved before publish. Re-run with --force to override.")
        stage = _final_case_stage(manifest)
        if not stage:
            raise ValueError(f"Benchmark `{benchmark_id}` v{version} has no normalized or deduped cases to publish.")
        cases = _read_manifest_shards(root, manifest, stage)
        registry = _load_registry(project_root)
        entries = _sorted_registry_entries([dict(item) for item in registry.get("benchmarks", []) if isinstance(item, dict)])
        existing = [
            entry
            for entry in entries
            if str(entry.get("benchmark_id") or "") == benchmark_id and _entry_version(entry) == int(version)
        ]
        if existing and not force:
            raise ValueError(f"Benchmark `{benchmark_id}` v{version} is already published. Re-run with --force to replace it.")
        bundle = _legacy_bundle_from_cases(project_root, manifest, cases, eval_id=str(eval_id or benchmark_id))
        destination = benchmark_bundle_path(project_root, benchmark_id, version)
        write_json(destination, bundle)
        entries = [
            entry
            for entry in entries
            if not (str(entry.get("benchmark_id") or "") == benchmark_id and _entry_version(entry) == int(version))
        ]
        for entry in entries:
            if str(entry.get("benchmark_id") or "") == benchmark_id:
                entry["active"] = False
        bundle_manifest = dict(bundle.get("manifest") or {})
        metadata = dict(bundle_manifest.get("benchmark_metadata") or {})
        entry = {
            "benchmark_id": benchmark_id,
            "version": int(version),
            "version_label": str(metadata.get("version") or f"v{int(version)}"),
            "active": True,
            "source_eval_id": str(eval_id or benchmark_id),
            "bundle_path": str(destination.relative_to(project_root)),
            "fingerprint": str(bundle_manifest.get("fingerprint") or ""),
            "case_count": int(bundle_manifest.get("case_count") or len(cases)),
            "approval_status": "approved",
            "tags": [str(item) for item in bundle_manifest.get("tags", []) if str(item).strip()],
            "split_names": [str(item) for item in bundle_manifest.get("split_names", []) if str(item).strip()],
            "origin_repo": str(metadata.get("origin_repo") or ""),
            "author": str(metadata.get("author") or "benchmark-ingestion"),
            "license": str(metadata.get("license") or ""),
            "intended_agent_type": str(metadata.get("intended_agent_type") or ""),
            "required_capabilities": _string_list(metadata.get("required_capabilities")),
            "description": str(metadata.get("description") or ""),
            "registered_at": created_at_utc(),
            "sharded": True,
            "ingestion_manifest_path": str(manifest_path(project_root, benchmark_id, version).relative_to(project_root)),
            "ingestion_fingerprint": str(manifest.get("fingerprint") or ""),
            "source_name": str((manifest.get("source") or {}).get("name") or ""),
            "source_revision": str((manifest.get("source") or {}).get("dataset_revision") or ""),
            "source_hash": str((manifest.get("source") or {}).get("source_hash") or ""),
        }
        entries.append(entry)
        registry["benchmarks"] = _sorted_registry_entries(entries)
        _write_registry(project_root, registry)
        manifest["published_bundle_path"] = str(destination.relative_to(project_root))
        manifest["published_registry_path"] = str(benchmark_registry_path(project_root).relative_to(project_root))
        _set_stage(manifest, "published")
        _write_manifest(project_root, manifest)
        return {
            "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
            "benchmark_id": benchmark_id,
            "version": int(version),
            "stage": "published",
            "case_count": len(cases),
            "bundle_path": str(destination),
            "registry_path": str(benchmark_registry_path(project_root)),
            "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
            "fingerprint": entry["fingerprint"],
            "registry_entry": entry,
        }


def show_ingested_benchmark(project_root: Path, *, benchmark_id: str, version: int) -> dict[str, Any]:
    manifest = _load_manifest(project_root, benchmark_id, version)
    return {
        "benchmark_id": benchmark_id,
        "version": version,
        "manifest": manifest,
        "manifest_path": str(manifest_path(project_root, benchmark_id, version)),
    }


def list_ingested_benchmarks(project_root: Path, *, benchmark_id: str | None = None) -> dict[str, Any]:
    root = benchmark_root(project_root) / "ingested"
    rows: list[dict[str, Any]] = []
    if root.exists():
        for manifest_file in sorted(root.glob("*/v*/manifest.yaml")):
            payload = read_yaml(manifest_file) or {}
            if benchmark_id and str(payload.get("benchmark_id") or "") != benchmark_id:
                continue
            rows.append(
                {
                    "benchmark_id": payload.get("benchmark_id"),
                    "version": payload.get("version"),
                    "stage": payload.get("stage"),
                    "case_count": payload.get("case_count", 0),
                    "raw_row_count": payload.get("raw_row_count", 0),
                    "fingerprint": payload.get("fingerprint", ""),
                    "manifest_path": str(manifest_file),
                }
            )
    return {
        "ingested_benchmark_count": len(rows),
        "benchmarks": rows,
    }


def list_ingestion_jobs(project_root: Path, *, limit: int = 20) -> dict[str, Any]:
    paths = sorted(jobs_dir(project_root).glob("benchmark-*.json"), key=lambda path: path.stat().st_mtime_ns, reverse=True)
    jobs = [read_json(path) for path in paths[: max(1, int(limit))]]
    return {"job_count": len(jobs), "jobs": jobs}


def show_ingestion_job(project_root: Path, *, job_id: str) -> dict[str, Any]:
    path = _job_path(project_root, job_id)
    if not path.exists():
        raise FileNotFoundError(f"Benchmark ingestion job not found: {job_id}")
    payload = read_json(path)
    return dict(payload) if isinstance(payload, dict) else {}
