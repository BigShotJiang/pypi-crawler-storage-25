from __future__ import annotations

from typing import Any, cast

from agentworkbench.aggregate_metrics import aggregate_chain_rows, aggregate_workflow_rows
from agentworkbench.audits import aggregate_surface_audits, aggregate_surface_contract_audits
from agentworkbench.evidence import artifact_evidence_summary
from agentworkbench.surface_usage import tool_call_names
from agentworkbench.tracing import (
    CANONICAL_TRACE_EVENT_KINDS,
    TRACE_SCHEMA_VERSION,
    TRACE_TAXONOMY,
    trace_event_label,
)

BEHAVIOR_SUMMARY_VERSION = "awb.behavior.v3"


def _sorted_counts(items: list[str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return dict(sorted(counts.items()))


def _row_artifact(item: dict[str, Any]) -> dict[str, Any]:
    artifact = item.get("artifact")
    if isinstance(artifact, dict):
        return cast(dict[str, Any], artifact)
    return {}


def _token_usage_summary(rows: list[dict[str, Any]]) -> tuple[dict[str, int], dict[str, float]]:
    totals: dict[str, int] = {}
    total_cases = len(rows)
    for item in rows:
        for key, value in (_row_artifact(item).get("token_usage") or {}).items():
            totals[str(key)] = totals.get(str(key), 0) + int(value)
    averages = {key: round(total / total_cases, 3) for key, total in sorted(totals.items()) if total_cases > 0}
    return dict(sorted(totals.items())), averages


def _usage_counts(rows: list[dict[str, Any]], artifact_key: str) -> dict[str, int]:
    values: list[str] = []
    for item in rows:
        art = _row_artifact(item)
        if artifact_key == "tool_calls":
            values.extend(tool_call_names(art))
        elif artifact_key == "trace_events":
            for event in art.get("trace_events", []):
                if isinstance(event, dict):
                    values.append(trace_event_label(event))
        elif artifact_key == "trace_event_kinds":
            for event in art.get("trace_events", []):
                if isinstance(event, dict) and event.get("kind"):
                    values.append(str(event["kind"]))
        else:
            values.extend(str(name) for name in art.get(artifact_key, []))
    return _sorted_counts(values)


def _coverage(available: list[str], used_counts: dict[str, int]) -> dict[str, Any]:
    used = sorted(name for name, count in used_counts.items() if count > 0)
    unused = sorted(name for name in available if name not in used_counts)
    coverage = round(len(used) / len(available), 3) if available else None
    return {"used": used, "unused": unused, "coverage": coverage}


def _surface_audit(available: list[str], used_counts: dict[str, int]) -> dict[str, Any]:
    coverage = _coverage(available, used_counts)
    declared = set(str(item) for item in available)
    used = coverage["used"]
    return {
        "available": [str(item) for item in available],
        "used": used,
        "unused": coverage["unused"],
        "used_not_declared": sorted(name for name in used_counts if name not in declared),
        "coverage": coverage["coverage"],
        "available_count": len(available),
        "used_count": len(used),
        "unused_count": len(coverage["unused"]),
    }


def _surface_audits(spec_snapshot: dict[str, Any], usage_counts: dict[str, dict[str, int]]) -> dict[str, Any]:
    return {
        "tools": _surface_audit(spec_snapshot.get("tool_names", []), usage_counts.get("tools", {})),
        "skills": _surface_audit(spec_snapshot.get("skill_names", []), usage_counts.get("skills", {})),
        "plugins": _surface_audit(spec_snapshot.get("plugin_names", []), usage_counts.get("plugins", {})),
        "mcps": _surface_audit(spec_snapshot.get("mcp_names", []), usage_counts.get("mcps", {})),
        "prompts": _surface_audit(spec_snapshot.get("prompt_keys", []), usage_counts.get("prompts", {})),
    }


def _aggregate_evidence(rows: list[dict[str, Any]]) -> dict[str, Any]:
    total_cases = len(rows) or 1
    total_records = 0
    total_selected = 0
    total_used = 0
    source_counts: dict[str, int] = {}
    kind_counts: dict[str, int] = {}
    source_summaries: dict[str, dict[str, Any]] = {}
    cases_with_selected = 0
    cases_with_supported = 0
    cases_with_unsupported = 0
    for row in rows:
        _records, summary = artifact_evidence_summary(row.get("artifact") or {})
        total_records += int(summary.get("record_count", 0))
        total_selected += int(summary.get("selected_count", 0))
        total_used += int(summary.get("used_count", 0))
        if int(summary.get("selected_count", 0)) > 0:
            cases_with_selected += 1
        if int(summary.get("used_count", 0)) > 0:
            cases_with_supported += 1
        if int(summary.get("selected_count", 0)) > 0 and int(summary.get("used_count", 0)) == 0:
            cases_with_unsupported += 1
        for label, count in (summary.get("source_counts") or {}).items():
            source_counts[str(label)] = source_counts.get(str(label), 0) + int(count)
        for label, count in (summary.get("kind_counts") or {}).items():
            kind_counts[str(label)] = kind_counts.get(str(label), 0) + int(count)
        for label, item in (summary.get("source_summaries") or {}).items():
            bucket = source_summaries.setdefault(
                str(label),
                {
                    "records": 0,
                    "hits": 0,
                    "selected": 0,
                    "used": 0,
                    "mcps": set(),
                    "statuses": set(),
                    "paths": set(),
                },
            )
            bucket["records"] += int(item.get("records", 0))
            bucket["hits"] += int(item.get("hits", 0))
            bucket["selected"] += int(item.get("selected", 0))
            bucket["used"] += int(item.get("used", 0))
            bucket["mcps"].update(str(value) for value in item.get("mcps", []) or [])
            bucket["statuses"].update(str(value) for value in item.get("statuses", []) or [])
            bucket["paths"].update(str(value) for value in item.get("paths", []) or [])
    finalized_sources: dict[str, Any] = {}
    for label, item in sorted(source_summaries.items()):
        selected = int(item.get("selected", 0))
        used = int(item.get("used", 0))
        finalized_sources[label] = {
            "records": int(item.get("records", 0)),
            "hits": int(item.get("hits", 0)),
            "selected": selected,
            "used": used,
            "use_rate": round(used / selected, 3) if selected else None,
            "mcps": sorted(str(value) for value in item.get("mcps", set()) if str(value).strip()),
            "statuses": sorted(str(value) for value in item.get("statuses", set()) if str(value).strip()),
            "paths": sorted(str(value) for value in item.get("paths", set()) if str(value).strip()),
        }
    return {
        "average_evidence_record_count": total_records / total_cases,
        "average_selected_evidence_count": total_selected / total_cases,
        "average_supported_evidence_count": total_used / total_cases,
        "selected_evidence_use_rate": round(total_used / total_selected, 3) if total_selected else None,
        "cases_with_selected_evidence": cases_with_selected,
        "cases_with_supported_evidence": cases_with_supported,
        "cases_with_unsupported_selected_evidence": cases_with_unsupported,
        "evidence_sources_used": sorted(source_counts),
        "evidence_source_counts": dict(sorted(source_counts.items())),
        "evidence_kind_counts": dict(sorted(kind_counts.items())),
        "evidence_sources_with_unused_selected": sorted(
            label
            for label, item in finalized_sources.items()
            if int(item.get("selected", 0)) > int(item.get("used", 0))
        ),
        "evidence_source_summaries": finalized_sources,
    }


def _artifact_metadata_values(rows: list[dict[str, Any]], value_getter: Any) -> list[str]:
    return sorted({value for item in rows if (value := str(value_getter(_row_artifact(item)) or "").strip())})


def aggregate_behavior_summary(rows: list[dict[str, Any]], spec_snapshot: dict[str, Any]) -> dict[str, Any]:
    total_cases = len(rows) or 1
    total_tool_calls = sum(len(_row_artifact(item).get("tool_calls", [])) for item in rows)
    total_trace_events = sum(len(_row_artifact(item).get("trace_events", [])) for item in rows)
    total_steps = sum(int(_row_artifact(item).get("step_count") or 0) for item in rows)
    total_latency = sum(int(_row_artifact(item).get("latency_ms") or 0) for item in rows)
    total_output_length = sum(len(_row_artifact(item).get("final_output") or "") for item in rows)
    total_cost_estimate = sum(float(_row_artifact(item).get("cost_estimate") or 0.0) for item in rows)
    total_token_usage, average_token_usage = _token_usage_summary(rows)
    tool_usage_counts = _usage_counts(rows, "tool_calls")
    skill_usage_counts = _usage_counts(rows, "skills_used")
    plugin_usage_counts = _usage_counts(rows, "plugins_used")
    mcp_usage_counts = _usage_counts(rows, "mcp_servers_used")
    prompt_usage_counts = _usage_counts(rows, "prompt_keys_used")
    workflow_step_counts = _usage_counts(rows, "workflow_trace")
    trace_event_label_counts = _usage_counts(rows, "trace_events")
    trace_event_kind_counts = _usage_counts(rows, "trace_event_kinds")
    tool_coverage = _coverage(spec_snapshot.get("tool_names", []), tool_usage_counts)
    skill_coverage = _coverage(spec_snapshot.get("skill_names", []), skill_usage_counts)
    plugin_coverage = _coverage(spec_snapshot.get("plugin_names", []), plugin_usage_counts)
    mcp_coverage = _coverage(spec_snapshot.get("mcp_names", []), mcp_usage_counts)
    prompt_coverage = _coverage(spec_snapshot.get("prompt_keys", []), prompt_usage_counts)
    surface_audits = _surface_audits(
        spec_snapshot,
        {
            "tools": tool_usage_counts,
            "skills": skill_usage_counts,
            "plugins": plugin_usage_counts,
            "mcps": mcp_usage_counts,
            "prompts": prompt_usage_counts,
        },
    )
    audit_summary = aggregate_surface_audits(rows)
    contract_summary = aggregate_surface_contract_audits(rows, spec_snapshot)
    evidence_summary = _aggregate_evidence(rows)
    chain_summary = _aggregate_chain_summary(rows)
    workflow_summary = _aggregate_workflow_summary(rows)
    return {
        "behavior_summary_version": BEHAVIOR_SUMMARY_VERSION,
        "average_tool_calls": total_tool_calls / total_cases,
        "average_trace_event_count": total_trace_events / total_cases,
        "average_step_count": total_steps / total_cases,
        "average_latency_ms": total_latency / total_cases,
        "average_output_length": total_output_length / total_cases,
        "total_cost_estimate": round(total_cost_estimate, 6),
        "average_cost_estimate": round(total_cost_estimate / total_cases, 6),
        "total_token_usage": total_token_usage,
        "average_token_usage": average_token_usage,
        "tools_used": tool_coverage["used"],
        "skills_used": skill_coverage["used"],
        "plugins_used": plugin_coverage["used"],
        "mcp_servers_used": mcp_coverage["used"],
        "prompt_keys_used": prompt_coverage["used"],
        "workflow_steps_used": sorted(workflow_step_counts),
        "trace_events_used": sorted(trace_event_label_counts),
        "tool_usage_counts": tool_usage_counts,
        "skill_usage_counts": skill_usage_counts,
        "plugin_usage_counts": plugin_usage_counts,
        "mcp_usage_counts": mcp_usage_counts,
        "prompt_usage_counts": prompt_usage_counts,
        "workflow_step_counts": workflow_step_counts,
        "trace_event_label_counts": trace_event_label_counts,
        "trace_event_kind_counts": trace_event_kind_counts,
        "trace_schema_versions": _artifact_metadata_values(
            rows, lambda artifact: artifact.get("trace_schema_version") or TRACE_SCHEMA_VERSION
        ),
        "trace_taxonomies": _artifact_metadata_values(
            rows, lambda artifact: artifact.get("trace_taxonomy") or TRACE_TAXONOMY
        ),
        "noncanonical_trace_event_kinds": sorted(
            kind for kind in trace_event_kind_counts if kind not in CANONICAL_TRACE_EVENT_KINDS
        ),
        "providers_used": _artifact_metadata_values(
            rows, lambda artifact: (artifact.get("metadata") or {}).get("provider")
        ),
        "models_used": _artifact_metadata_values(
            rows,
            lambda artifact: (artifact.get("metadata") or {}).get("model_name") or spec_snapshot.get("model_name"),
        ),
        "pricing_sources": _artifact_metadata_values(
            rows,
            lambda artifact: ((artifact.get("metadata") or {}).get("pricing") or {}).get("source_url"),
        ),
        "unused_available_tools": tool_coverage["unused"],
        "unused_available_skills": skill_coverage["unused"],
        "unused_available_plugins": plugin_coverage["unused"],
        "unused_available_mcps": mcp_coverage["unused"],
        "unused_available_prompt_keys": prompt_coverage["unused"],
        "tool_coverage": tool_coverage["coverage"],
        "skill_coverage": skill_coverage["coverage"],
        "plugin_coverage": plugin_coverage["coverage"],
        "mcp_coverage": mcp_coverage["coverage"],
        "prompt_coverage": prompt_coverage["coverage"],
        "surface_audits": surface_audits,
        **audit_summary,
        **contract_summary,
        **evidence_summary,
        **chain_summary,
        **workflow_summary,
        **_aggregate_conversation_metrics(rows),
    }


def _aggregate_chain_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary = aggregate_chain_rows(rows)
    if not summary["case_count"]:
        return {}
    return {
        "is_chain_run": True,
        "average_chain_step_pass_rate": summary["average_step_pass_rate"],
        "average_chain_latency_ms": summary["average_latency_ms"],
        "average_chain_step_scores": summary["average_step_scores"],
        "chain_degrading_step_frequency": summary["degrading_step_frequency"],
        "total_chain_executed_steps": summary["total_executed_steps"],
        "total_chain_skipped_steps": summary["total_skipped_steps"],
    }


def _aggregate_workflow_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary = aggregate_workflow_rows(rows)
    if not summary["case_count"]:
        return {}
    return {
        "is_workflow_run": True,
        "average_workflow_step_pass_rate": summary["average_step_pass_rate"],
        "average_workflow_latency_ms": summary["average_latency_ms"],
        "average_workflow_node_scores": summary["average_node_scores"],
        "workflow_path_counts": summary["path_counts"],
        "workflow_terminal_node_counts": summary["terminal_node_counts"],
        "workflow_route_counts": summary["route_counts"],
    }


def _conversation_metrics(row: dict[str, Any]) -> dict[str, Any]:
    """Extract conversation metrics from a run row."""
    case = row.get("case", {})
    artifact = row.get("artifact", {})

    turns = case.get("turns", [])
    if not turns:
        return {}

    tool_calls = artifact.get("tool_calls", [])

    final_output = str(artifact.get("final_output", "")).lower()
    escalation_keywords = ["escalate", "manager", "senior", "director", "lead", "tier 3", "tier 2"]
    escalation_detected = any(kw in final_output for kw in escalation_keywords)

    re_ask_count = 0
    for turn in turns:
        if turn.get("role") == "assistant":
            content = turn.get("content", "").lower()
            if any(q in content for q in ["?", "could you", "please clarify", "would you", "help me understand"]):
                re_ask_count += 1

    expected = case.get("expected", "").lower()
    resolution_turn = None
    if "resolved" in expected or "answer" in expected or "eligible" in expected or "not eligible" in expected:
        resolution_turn = len(turns) - 1

    latency_ms = artifact.get("latency_ms", 0)
    avg_turn_latency = latency_ms / len(turns) if turns else 0

    return {
        "turn_count": len(turns),
        "tool_call_count": len(tool_calls),
        "evidence_retrieval_count": len(artifact.get("evidence_records", [])),
        "escalation_detected": escalation_detected,
        "resolution_turn": resolution_turn,
        "re_ask_count": re_ask_count,
        "avg_turn_latency_ms": round(avg_turn_latency, 1),
    }


def _aggregate_conversation_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate conversation metrics across all rows with turns."""
    metrics_list = [_conversation_metrics(row) for row in rows if _conversation_metrics(row)]
    if not metrics_list:
        return {}
    total_cases_with_turns = len(metrics_list)
    avg_turn_count = sum(m.get("turn_count", 0) for m in metrics_list) / total_cases_with_turns
    avg_tool_calls = sum(m.get("tool_call_count", 0) for m in metrics_list) / total_cases_with_turns
    avg_evidence = sum(m.get("evidence_retrieval_count", 0) for m in metrics_list) / total_cases_with_turns
    escalation_rate = sum(1 for m in metrics_list if m.get("escalation_detected")) / total_cases_with_turns
    avg_re_ask = sum(m.get("re_ask_count", 0) for m in metrics_list) / total_cases_with_turns
    avg_turn_latency = sum(m.get("avg_turn_latency_ms", 0) for m in metrics_list) / total_cases_with_turns

    return {
        "average_turn_count": round(avg_turn_count, 2),
        "average_tool_call_per_turn": round(avg_tool_calls / max(avg_turn_count, 1), 2),
        "average_evidence_per_turn": round(avg_evidence / max(avg_turn_count, 1), 2),
        "escalation_rate": round(escalation_rate, 3),
        "average_re_ask_count": round(avg_re_ask, 2),
        "average_turn_latency_ms": round(avg_turn_latency, 1),
        "cases_with_turns": total_cases_with_turns,
    }
