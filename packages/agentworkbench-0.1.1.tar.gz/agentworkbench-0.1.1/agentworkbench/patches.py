from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, dump_model
from agentworkbench.models import MutationProposal, PatchPlanItem, PatchTemplate
from agentworkbench.proposals import proposals_dir
from agentworkbench.reports import render_patch_template_report, write_report
from agentworkbench.utils import read_json, write_json


def patches_dir(project_root: Path) -> Path:
    root = control_dir(project_root) / "patches"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _proposal_payload_path(project_root: Path, experiment_id: str | None = None) -> Path:
    root = proposals_dir(project_root)
    if experiment_id:
        return root / f"proposals-{experiment_id}.json"
    return root / "latest.json"


def _load_proposal_payload(project_root: Path, experiment_id: str | None = None) -> dict[str, Any]:
    path = _proposal_payload_path(project_root, experiment_id)
    if not path.exists():
        if experiment_id:
            raise ValueError(f"No proposal bundle found for experiment `{experiment_id}`. Run `awb propose --experiment {experiment_id}` first.")
        raise ValueError("No proposal bundle found yet. Run `awb propose` first.")
    payload = read_json(path)
    return dict(payload) if isinstance(payload, dict) else {}


def resolve_proposal(project_root: Path, proposal_id: str | None = None, experiment_id: str | None = None) -> tuple[dict[str, Any], MutationProposal]:
    payload = _load_proposal_payload(project_root, experiment_id)
    proposals = [MutationProposal.model_validate(item) for item in payload.get("proposals", [])]
    if not proposals:
        raise ValueError("The selected proposal bundle is empty. Run `awb propose` again after diagnosis.")
    if proposal_id:
        for proposal in proposals:
            if proposal.proposal_id == proposal_id:
                return payload, proposal
        raise ValueError(f"Proposal `{proposal_id}` was not found in the selected bundle.")
    return payload, proposals[0]


def patch_template_path(project_root: Path, template_id: str) -> Path:
    return patches_dir(project_root) / f"{template_id}.yaml"


def patch_template_report_path(project_root: Path, template_id: str) -> Path:
    return patches_dir(project_root) / f"{template_id}.md"


def patch_template_json_path(project_root: Path, template_id: str) -> Path:
    return patches_dir(project_root) / f"{template_id}.json"


def _group_target_paths(target_files: list[str], target_paths: list[str], change_plan: list[str]) -> list[PatchPlanItem]:
    grouped: dict[str, list[str]] = {file: [] for file in target_files}
    for item in target_paths:
        file_name, _, path_name = item.partition("::")
        grouped.setdefault(file_name, [])
        if path_name:
            grouped[file_name].append(path_name)
    edits: list[PatchPlanItem] = []
    for index, file in enumerate(target_files or sorted(grouped), start=1):
        paths = grouped.get(file, [])
        objective = change_plan[min(index - 1, len(change_plan) - 1)] if change_plan else "Implement the proposal in this file."
        edits.append(
            PatchPlanItem(
                file=file,
                paths=paths,
                objective=objective,
                planned_change="",
                status="pending",
            )
        )
    if not edits:
        edits.append(PatchPlanItem(file="unknown", paths=[], objective="Implement the proposal.", planned_change="", status="pending"))
    return edits


def build_patch_template(project_root: Path, proposal_id: str | None = None, experiment_id: str | None = None) -> dict[str, Path]:
    payload, proposal = resolve_proposal(project_root, proposal_id=proposal_id, experiment_id=experiment_id)
    template = PatchTemplate(
        template_id=f"{proposal.proposal_id}-patch",
        proposal_id=proposal.proposal_id,
        experiment_id=proposal.experiment_id,
        baseline_id=proposal.baseline_id,
        benchmark_signature=proposal.benchmark_signature,
        category=proposal.category,
        title=proposal.title,
        status="draft",
        summary=str(payload.get("summary") or ""),
        rationale=proposal.rationale,
        hypothesis="",
        target_files=proposal.target_files,
        target_paths=proposal.target_paths,
        target_surfaces=proposal.target_surfaces,
        related_cases=proposal.related_cases,
        planned_edits=_group_target_paths(proposal.target_files, proposal.target_paths, proposal.change_plan),
        change_plan=proposal.change_plan,
        expected_effects=proposal.expected_effects,
        acceptance_checks=proposal.acceptance_checks,
        validation_commands=proposal.validation_commands,
        validation_results=[],
        risks=proposal.risks,
        implementation_notes=[
            "Fill in `hypothesis` before editing.",
            "Update `planned_change` for each file before implementing.",
            "Record validation output after rerunning the eval subset.",
        ],
    )
    template_payload = template.model_dump(mode="json")
    yaml_path = dump_model(patch_template_path(project_root, template.template_id), template)
    report_path = write_report(
        patch_template_report_path(project_root, template.template_id),
        render_patch_template_report(template_payload),
    )
    json_path = write_json(
        patch_template_json_path(project_root, template.template_id),
        {
            **template_payload,
            "yaml_path": str(yaml_path.relative_to(project_root)),
            "report_path": str(report_path.relative_to(project_root)),
        },
    )
    latest_yaml = dump_model(patches_dir(project_root) / "latest.yaml", template)
    latest_report = write_report(patches_dir(project_root) / "latest.md", render_patch_template_report(template_payload))
    latest_json = write_json(
        patches_dir(project_root) / "latest.json",
        {
            **template_payload,
            "yaml_path": str(yaml_path.relative_to(project_root)),
            "report_path": str(report_path.relative_to(project_root)),
            "json_path": str(json_path.relative_to(project_root)),
        },
    )
    return {
        "template_yaml": yaml_path,
        "template_report": report_path,
        "template_json": json_path,
        "latest_yaml": latest_yaml,
        "latest_report": latest_report,
        "latest_json": latest_json,
    }
