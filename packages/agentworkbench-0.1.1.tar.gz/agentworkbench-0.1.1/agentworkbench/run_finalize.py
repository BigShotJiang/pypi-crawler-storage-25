from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from agentworkbench.behavior_summary import aggregate_behavior_summary
from agentworkbench.run_context import build_benchmark_signature
from agentworkbench.run_helpers import _aggregate_results
from agentworkbench.snapshot import (
    capture_snapshot,
    compare_benchmark_hashes,
    compare_snapshots,
    compute_benchmark_hashes,
    compute_benchmark_manifest,
)


@dataclass(frozen=True)
class RunFinalizeResult:
    after_snapshot: dict[str, Any]
    after_benchmarks: dict[str, str]
    after_manifest: dict[str, Any]
    changed_files: list[str]
    diff_text: str
    aggregate: dict[str, Any]
    behavior_summary: dict[str, Any]
    benchmark_signature: str


def finalize_run(
    project_root: Path,
    *,
    rows: list[dict[str, Any]],
    spec_snapshot: dict[str, Any],
    before_snapshot: dict[str, Any],
    before_benchmarks: dict[str, str],
    snapshot_mode: str | None,
    selection_fingerprint: str | None,
    signature_extra: dict[str, Any] | None = None,
) -> RunFinalizeResult:
    after_snapshot = capture_snapshot(project_root, snapshot_mode or "auto")
    after_benchmarks = compute_benchmark_hashes(project_root)
    after_manifest = compute_benchmark_manifest(project_root)
    changed_files, diff_text = compare_snapshots(project_root, before_snapshot, after_snapshot)
    aggregate = _aggregate_results(rows)
    behavior_summary = aggregate_behavior_summary(rows, spec_snapshot)
    aggregate["benchmark_mode"], aggregate["benchmark_changes"] = compare_benchmark_hashes(
        before_benchmarks, after_benchmarks
    )
    benchmark_signature = build_benchmark_signature(
        after_benchmarks,
        selection_fingerprint=selection_fingerprint,
        extra=signature_extra,
    )
    return RunFinalizeResult(
        after_snapshot=after_snapshot,
        after_benchmarks=after_benchmarks,
        after_manifest=after_manifest,
        changed_files=changed_files,
        diff_text=diff_text or "",
        aggregate=aggregate,
        behavior_summary=behavior_summary,
        benchmark_signature=benchmark_signature,
    )


__all__ = ["RunFinalizeResult", "finalize_run"]
