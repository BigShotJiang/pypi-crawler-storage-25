from __future__ import annotations

import hashlib
import subprocess
from difflib import unified_diff
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir

IGNORED_PATH_PARTS = {".git", "__pycache__", ".pytest_cache", "node_modules", ".venv", "venv"}


def _should_ignore(path: Path) -> bool:
    return any(part in IGNORED_PATH_PARTS for part in path.parts) or ".agent-workbench/runs" in str(path) or ".agent-workbench/reports" in str(path)


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError:
        return b""


def _hash_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _text_or_none(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None


def git_available(project_root: Path) -> bool:
    git_dir = project_root / ".git"
    if not git_dir.exists():
        return False
    result = subprocess.run(["git", "-C", str(project_root), "rev-parse", "--show-toplevel"], capture_output=True, text=True)
    return result.returncode == 0


def detect_mode(project_root: Path, preferred: str = "auto") -> str:
    if preferred == "git" and git_available(project_root):
        return "git"
    if preferred == "filesystem":
        return "filesystem"
    return "git" if git_available(project_root) else "filesystem"


def _tracked_files(project_root: Path) -> list[Path]:
    files: list[Path] = []
    for path in project_root.rglob("*"):
        if path.is_file() and not _should_ignore(path.relative_to(project_root)):
            files.append(path)
    return sorted(files)


def _git_metadata(project_root: Path) -> dict[str, Any]:
    head = subprocess.run(["git", "-C", str(project_root), "rev-parse", "HEAD"], capture_output=True, text=True)
    status = subprocess.run(["git", "-C", str(project_root), "status", "--short"], capture_output=True, text=True)
    return {
        "head": head.stdout.strip() if head.returncode == 0 else "",
        "status": status.stdout.splitlines(),
    }


def capture_snapshot(project_root: Path, preferred: str = "auto") -> dict[str, Any]:
    mode = detect_mode(project_root, preferred)
    files = _tracked_files(project_root)
    hashed_files = {str(path.relative_to(project_root)): _hash_bytes(_read_bytes(path)) for path in files}
    text_files = {
        str(path.relative_to(project_root)): text
        for path in files
        if (text := _text_or_none(path)) is not None
    }
    snapshot = {
        "mode": mode,
        "files": hashed_files,
        "texts": text_files,
        "file_count": len(hashed_files),
    }
    if mode == "git":
        snapshot["git"] = _git_metadata(project_root)
    return snapshot


def compute_benchmark_hashes(project_root: Path) -> dict[str, str]:
    benchmark_root = control_dir(project_root)
    if not benchmark_root.exists():
        return {}
    targets = [
        benchmark_root / "briefs",
        benchmark_root / "evals",
        benchmark_root / "scorers",
    ]
    hashes: dict[str, str] = {}
    for target in targets:
        if target.is_file():
            hashes[str(target.relative_to(project_root))] = _hash_bytes(_read_bytes(target))
        elif target.is_dir():
            for path in sorted(target.rglob("*")):
                if (
                    path.is_file()
                    and path.suffix != ".md"
                    and not path.name.endswith(".packet.md")
                    and not _should_ignore(path.relative_to(project_root))
                ):
                    hashes[str(path.relative_to(project_root))] = _hash_bytes(_read_bytes(path))
    return hashes


def compute_benchmark_manifest(project_root: Path) -> dict[str, Any]:
    hashes = compute_benchmark_hashes(project_root)
    sections: dict[str, list[str]] = {"briefs": [], "evals": [], "scorers": [], "other": []}
    for path in sorted(hashes):
        if f"{control_dir(project_root).name}/briefs/" in path:
            sections["briefs"].append(path)
        elif f"{control_dir(project_root).name}/evals/" in path:
            sections["evals"].append(path)
        elif f"{control_dir(project_root).name}/scorers/" in path:
            sections["scorers"].append(path)
        else:
            sections["other"].append(path)
    fingerprint = _hash_bytes("\n".join(f"{path}:{hashes[path]}" for path in sorted(hashes)).encode("utf-8"))[:12]
    return {
        "fingerprint": fingerprint,
        "hash_count": len(hashes),
        "paths": hashes,
        "sections": {key: value for key, value in sections.items() if value},
    }


def compare_snapshot_states(before: dict[str, Any], after: dict[str, Any]) -> tuple[list[str], str]:
    before_files: dict[str, str] = before.get("files", {})
    after_files: dict[str, str] = after.get("files", {})
    before_texts: dict[str, str] = before.get("texts", {})
    after_texts: dict[str, str] = after.get("texts", {})
    changed = sorted(path for path in set(before_files) | set(after_files) if before_files.get(path) != after_files.get(path))
    diff_chunks: list[str] = []
    for relative in changed[:50]:
        before_text = before_texts.get(relative)
        after_text = after_texts.get(relative)
        if (relative in before_files and before_text is None) or (relative in after_files and after_text is None):
            diff_chunks.append(f"Binary or unreadable change: {relative}")
            continue
        previous = before_text.splitlines(keepends=True) if relative in before_files and before_text is not None else []
        current = after_text.splitlines(keepends=True) if relative in after_files and after_text is not None else []
        diff_chunks.extend(
            unified_diff(previous, current, fromfile=f"a/{relative}", tofile=f"b/{relative}", n=3)
        )
    return changed, "".join(diff_chunks)


def compare_snapshots(project_root: Path, before: dict[str, Any], after: dict[str, Any]) -> tuple[list[str], str]:
    _ = project_root
    return compare_snapshot_states(before, after)


def compare_benchmark_hashes(before: dict[str, str], after: dict[str, str]) -> tuple[str, list[str]]:
    changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
    return ("clean" if not changed else "benchmark-changed"), changed
