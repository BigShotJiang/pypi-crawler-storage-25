from __future__ import annotations

import difflib
import shlex
from html import escape
from typing import Any

from agentworkbench.review.common import html_json, html_list, html_metric


def _informative_failure_score(row: dict[str, Any]) -> float:
    if bool(row.get("passed", False)):
        return -1.0
    scores = row.get("scores") or []
    artifact = row.get("artifact") or {}
    num_scores = len(scores)
    num_tools = len(artifact.get("tool_calls") or [])
    num_errors = len(artifact.get("errors") or [])
    cost = float(artifact.get("cost_estimate") or 0.0)
    partial = sum(1 for s in scores if float(s.get("value", 0.0) or 0.0) > 0.0)
    return num_scores * 2.0 + num_tools * 1.5 + partial * 3.0 + cost * 10.0 + (1.0 if num_errors else 0.0)


def _output_diff(candidate_output: str, baseline_output: str) -> str:
    lines = list(
        difflib.unified_diff(
            baseline_output.splitlines(),
            candidate_output.splitlines(),
            fromfile="baseline",
            tofile="candidate",
            lineterm="",
        )
    )
    if not lines:
        return "No output diff."
    return "\n".join(lines)


def _shell_command(*parts: str) -> str:
    return " ".join(shlex.quote(str(part)) for part in parts if str(part).strip())


def _prompt_snapshot_section(spec_snapshot: dict[str, Any], baseline_spec_snapshot: dict[str, Any] | None = None) -> str:
    prompt_snapshots = [dict(item) for item in spec_snapshot.get("prompt_snapshots") or [] if isinstance(item, dict)]
    if not prompt_snapshots:
        return ""
    baseline_lookup = {
        str(item.get("key") or ""): dict(item)
        for item in (baseline_spec_snapshot or {}).get("prompt_snapshots", []) or []
        if isinstance(item, dict)
    }
    prompt_cards = []
    for item in prompt_snapshots:
        key = str(item.get("key") or "prompt")
        source = str(item.get("source") or "")
        source_type = str(item.get("source_type") or "inline")
        content_hash = str(item.get("content_hash") or "")
        preview = str(item.get("preview") or "")
        content = str(item.get("content") or "")
        baseline_item = baseline_lookup.get(key)
        change_label = "new"
        change_class = "warn"
        if baseline_item is not None:
            if str(baseline_item.get("content_hash") or "") == content_hash:
                change_label = "same as baseline"
                change_class = "pass"
            else:
                change_label = "changed from baseline"
                change_class = "fail"
        prompt_cards.append(
            '<article class="prompt-card">'
            f"<header><h3>{escape(key)}</h3>"
            f'<div class="case-meta"><span>{escape(source_type)}</span><span>{escape(source)}</span>'
            f'<span class="badge {change_class}">{escape(change_label)}</span>'
            f"<span>hash {escape(content_hash)}</span></div></header>"
            f"<pre>{escape(preview)}</pre>"
            f'<details><summary>Full Prompt</summary><pre>{escape(content)}</pre></details>'
            "</article>"
        )
    prompt_fingerprint = escape(str(spec_snapshot.get("prompt_fingerprint") or ""))
    return (
        '<section class="hero">'
        '<h2>Prompt Snapshots</h2>'
        '<p class="muted">Saved prompt versions from the experiment snapshot so you can diff prompt edits against case outcomes.</p>'
        f'<p><strong>Prompt fingerprint</strong>: <code>{prompt_fingerprint or "none"}</code></p>'
        f'<div class="prompt-grid">{"".join(prompt_cards)}</div>'
        "</section>"
    )


def _review_queue_section(review_queue: dict[str, Any]) -> str:
    items = [dict(item) for item in review_queue.get("items") or [] if isinstance(item, dict)]
    pending = [item for item in items if str(item.get("status") or "pending") != "resolved"]
    if not pending:
        return ""
    queue_id = str(review_queue.get("queue_id") or "")
    cards: list[str] = []
    for item in pending:
        checkpoint_id = str(item.get("checkpoint_id") or "")
        case_links = "".join(
            f'<a class="case-link" href="#case-{escape(str(case_id))}">{escape(str(case_id))}</a>'
            for case_id in item.get("related_case_ids") or []
            if str(case_id).strip()
        ) or '<span class="muted">No related cases</span>'
        cards.append(
            f'<article class="queue-card" data-queue-id="{escape(queue_id)}"'
            f' data-checkpoint-id="{escape(checkpoint_id)}"'
            f' data-case-ids="{escape(",".join(str(case_id) for case_id in item.get("related_case_ids") or [] if str(case_id).strip()))}">'
            f"<header><h3>{escape(str(item.get('title') or checkpoint_id or 'checkpoint'))}</h3>"
            f'<div class="case-meta"><span>{escape(str(item.get("priority") or "medium"))}</span>'
            f'<span>{escape(str(item.get("review_type") or ""))}</span>'
            f'<span>{escape(str(item.get("question_type") or ""))}</span></div></header>'
            f'<p>{escape(str(item.get("question") or ""))}</p>'
            f'<p class="muted">{escape(str(item.get("reason") or ""))}</p>'
            f'<div class="queue-cases">{case_links}</div>'
            '<div class="queue-builder">'
            '<label>Decision<select class="decision-select">'
            '<option value="candidate">candidate</option>'
            '<option value="baseline">baseline</option>'
            '<option value="neither">neither</option>'
            '<option value="accept">accept</option>'
            '<option value="reject">reject</option>'
            '</select></label>'
            '<label>Guidance<input class="guidance-input" type="text" placeholder="Optional short guidance"></label>'
            '<label>Answer<input class="answer-input" type="text" placeholder="Optional answer note"></label>'
            '<div class="queue-actions"><button class="copy-review-command">Copy awb human-review answer</button></div>'
            '<pre class="command-preview"></pre>'
            '</div>'
            '</article>'
        )
    return (
        '<section class="hero">'
        '<h2>Pairwise Review Queue</h2>'
        '<p class="muted">These pending review checkpoints can be answered directly from the HTML artifact. Use the copy button to emit a complete CLI command.</p>'
        f'<p><strong>Queue</strong>: <code>{escape(queue_id)}</code> '
        f'<span class="badge warn">{len(pending)} pending</span></p>'
        f'{"".join(cards)}'
        "</section>"
    )


def _review_case_card(
    row: dict[str, Any],
    experiment_id: str,
    agent_id: str,
    baseline_row: dict[str, Any] | None = None,
    *,
    baseline_experiment_id: str | None = None,
    baseline_agent_id: str | None = None,
    rank: int | None = None,
) -> str:
    case = row.get("case") or {}
    artifact = row.get("artifact") or {}
    scores = [dict(item) for item in row.get("scores", []) if isinstance(item, dict)]
    passed = bool(row.get("passed", False))
    score_value = float(row.get("score", 0.0) or 0.0)
    case_id = str(case.get("id") or "unknown")
    input_text = str(case.get("input") or "")
    expected_text = str(case.get("expected") or "")
    final_output = str(artifact.get("final_output") or "")
    cost = float(artifact.get("cost_estimate") or 0.0)
    latency = int(artifact.get("latency_ms", 0) or 0)
    informative_rank = int(rank or 0)
    search_blob = " ".join(
        [
            case_id,
            input_text,
            expected_text,
            final_output,
            " ".join(str(item.get("name") or "") for item in artifact.get("tool_calls", []) if isinstance(item, dict)),
            " ".join(str(item) for item in artifact.get("workflow_trace", [])),
            " ".join(str(item) for item in artifact.get("errors", [])),
        ]
    ).lower()
    status_class = "pass" if passed else "fail"
    delta_value = 0.0
    is_regression = False
    baseline_output = ""
    compare_block = f"<pre>{escape(final_output)}</pre>"
    diff_block = ""
    if baseline_row is not None:
        baseline_artifact = baseline_row.get("artifact") or {}
        baseline_output = str(baseline_artifact.get("final_output") or "")
        baseline_score = float(baseline_row.get("score", 0.0) or 0.0)
        delta_value = score_value - baseline_score
        is_regression = delta_value < -0.01
        delta_class = "pass" if delta_value >= 0 else "fail"
        compare_block = (
            '<div class="view-toolbar">'
            '<button class="view-btn active" data-view="split">Split</button>'
            '<button class="view-btn" data-view="diff">Diff</button>'
            "</div>"
            '<div class="output-view" data-view="split">'
            '<div class="compare-grid">'
            f'<div><h4>Candidate Output</h4><pre>{escape(final_output)}</pre></div>'
            f'<div><h4>Baseline Output</h4><pre>{escape(baseline_output)}</pre></div>'
            "</div>"
            f'<p class="delta {delta_class}">score delta: {delta_value:+.3f}</p>'
            "</div>"
        )
        diff_block = (
            f'<div class="output-view" data-view="diff" hidden>'
            f"<pre>{escape(_output_diff(final_output, baseline_output))}</pre>"
            "</div>"
        )
    rank_badge = f'<span class="rank-badge">#{rank}</span>' if rank is not None else ""
    metrics_html = "".join(html_metric(score, include_judged_details=True) for score in scores) or '<div class="muted">no scores</div>'
    replay_commands = [
        _shell_command("awb", "run", "replay", "--experiment", experiment_id, "--case-id", case_id),
        _shell_command("awb", "run", "replay", "--experiment", experiment_id, "--case-id", case_id, "--agent-id", agent_id),
        _shell_command("awb", "artifacts", "show", "case", "--experiment", experiment_id, "--case-id", case_id),
    ]
    if baseline_experiment_id:
        replay_commands.append(
            _shell_command("awb", "artifacts", "show", "case", "--experiment", baseline_experiment_id, "--case-id", case_id)
        )
    if baseline_experiment_id and baseline_agent_id:
        replay_commands.append(
            _shell_command(
                "awb",
                "run",
                "replay",
                "--experiment",
                baseline_experiment_id,
                "--case-id",
                case_id,
                "--agent-id",
                baseline_agent_id,
            )
        )
    return (
        f'<article id="case-{escape(case_id)}" class="case-card" data-case-id="{escape(case_id)}"'
        f' data-search="{escape(search_blob)}"'
        f' data-status="{"pass" if passed else "fail"}"'
        f' data-score="{score_value:.4f}"'
        f' data-latency="{latency}"'
        f' data-cost="{cost:.4f}"'
        f' data-rank="{informative_rank}"'
        f' data-regression="{"yes" if is_regression else "no"}"'
        f' data-delta="{delta_value:.4f}">'
        f'<header><h3>{rank_badge}{escape(case_id)}</h3><div class="case-meta">'
        f'<span class="badge {status_class}">{"pass" if passed else "fail"}</span>'
        f"<span>score {score_value:.3f}</span>"
        f"<span>latency {latency}ms</span>"
        f"<span>steps {int(artifact.get('step_count', 0) or 0)}</span>"
        f"<span>cost ${cost:.4f}</span>"
        "</div></header>"
        '<div class="case-layout">'
        f'<section><h4>Input</h4><pre>{escape(input_text)}</pre></section>'
        f'<section><h4>Expected</h4><pre>{escape(expected_text)}</pre></section>'
        f'<section class="span-two"><h4>Output</h4>{compare_block}{diff_block}</section>'
        f'<section class="span-two"><h4>Metrics</h4><div class="metrics">{metrics_html}</div></section>'
        f'<section><h4>Workflow</h4><ul>{html_list(list(artifact.get("workflow_trace") or []))}</ul></section>'
        f'<section><h4>Tools</h4><ul>{html_list([str((item or {}).get("name") or "") for item in artifact.get("tool_calls", []) if isinstance(item, dict)])}</ul></section>'
        f'<section><h4>Prompts</h4><ul>{html_list(list(artifact.get("prompt_keys_used") or []))}</ul></section>'
        f'<section><h4>MCPs</h4><ul>{html_list(list(artifact.get("mcp_servers_used") or []))}</ul></section>'
        f'<section class="span-two"><details><summary>Trace Events</summary><pre>{html_json(artifact.get("trace_events") or [])}</pre></details></section>'
        f'<section class="span-two"><details><summary>Metadata</summary><pre>{html_json(artifact.get("metadata") or {})}</pre></details></section>'
        f'<section class="span-two"><details><summary>Errors</summary><pre>{html_json(artifact.get("errors") or [])}</pre></details></section>'
        f'<section class="span-two"><details><summary>Playground</summary><pre>{escape(chr(10).join(replay_commands))}</pre></details></section>'
        "</div></article>"
    )


def render_experiment_review_html(
    bundle: dict[str, Any],
    baseline_bundle: dict[str, Any] | None = None,
    *,
    review_queue: dict[str, Any] | None = None,
) -> str:
    experiment = bundle.get("experiment") or {}
    baseline_experiment = (baseline_bundle or {}).get("experiment") or {}
    aggregate = bundle.get("aggregate") or {}
    behavior = bundle.get("behavior") or {}
    spec_snapshot = bundle.get("spec_snapshot") or {}
    baseline_spec_snapshot = (baseline_bundle or {}).get("spec_snapshot") or {}
    rows = list(bundle.get("rows") or bundle.get("partial_rows") or [])
    baseline_lookup = {
        str((row.get("case") or {}).get("id") or ""): row
        for row in (baseline_bundle or {}).get("rows", []) or []
    }

    failures = [r for r in rows if not r.get("passed", False)]
    ranked_failures = sorted(failures, key=_informative_failure_score, reverse=True)[:10]
    rank_map = {str((r.get("case") or {}).get("id") or ""): i + 1 for i, r in enumerate(ranked_failures)}

    total_cost = sum(float((r.get("artifact") or {}).get("cost_estimate") or 0.0) for r in rows)
    avg_latency = (
        sum(int((r.get("artifact") or {}).get("latency_ms") or 0) for r in rows) / len(rows) if rows else 0
    )
    regressions = sum(
        1
        for r in rows
        if baseline_lookup
        and float(r.get("score", 0)) - float(baseline_lookup.get(str((r.get("case") or {}).get("id") or ""), {}).get("score", 0))
        < -0.01
    )

    ranked_cards_html = ""
    if ranked_failures:
        ranked_cards = "".join(
            _review_case_card(
                row,
                str(experiment.get("experiment_id") or ""),
                str(experiment.get("agent_id") or ""),
                baseline_lookup.get(str((row.get("case") or {}).get("id") or "")) if baseline_lookup else None,
                baseline_experiment_id=str(baseline_experiment.get("experiment_id") or "") or None,
                baseline_agent_id=str(baseline_experiment.get("agent_id") or "") or None,
                rank=rank_map.get(str((row.get("case") or {}).get("id") or "")),
            )
            for row in ranked_failures
        )
        ranked_cards_html = (
            '<section class="failure-ranking">'
            '<h2>Top Informative Failures</h2>'
            '<p class="muted">Ranked by tool usage, partial scores, cost, and error signals.</p>'
            f"{ranked_cards}"
            "</section>"
        )

    case_cards = "".join(
        _review_case_card(
            row,
            str(experiment.get("experiment_id") or ""),
            str(experiment.get("agent_id") or ""),
            baseline_lookup.get(str((row.get("case") or {}).get("id") or "")) if baseline_lookup else None,
            baseline_experiment_id=str(baseline_experiment.get("experiment_id") or "") or None,
            baseline_agent_id=str(baseline_experiment.get("agent_id") or "") or None,
        )
        for row in rows
    )
    baseline_header = ""
    if baseline_bundle is not None:
        baseline_header = (
            f"<p>Baseline: <code>{escape(str(baseline_experiment.get('experiment_id') or 'unknown'))}</code> "
            f"agent=<code>{escape(str(baseline_experiment.get('agent_id') or 'unknown'))}</code></p>"
        )
    prompt_section = _prompt_snapshot_section(spec_snapshot, baseline_spec_snapshot if baseline_bundle else None)
    queue_section = _review_queue_section(review_queue or {})
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AWB Review {escape(str(experiment.get("experiment_id") or "unknown"))}</title>
  <style>
    :root {{
      --bg: #f7f4ec;
      --panel: #fffdf8;
      --ink: #1e1d1a;
      --muted: #6f6a5f;
      --border: #d8cfbf;
      --accent: #0f766e;
      --danger: #b42318;
      --warn: #b45309;
      --shadow: 0 12px 30px rgba(45, 33, 10, 0.08);
    }}
    body {{ margin: 0; background: linear-gradient(180deg, #efe7d7 0%, var(--bg) 35%, #f9f7f1 100%); color: var(--ink); font-family: "Iowan Old Style", "Palatino Linotype", serif; }}
    main {{ max-width: 1260px; margin: 0 auto; padding: 32px 20px 64px; }}
    .hero, .case-card, .queue-card, .prompt-card {{ background: var(--panel); border: 1px solid var(--border); box-shadow: var(--shadow); border-radius: 18px; }}
    .hero {{ padding: 24px; margin-bottom: 24px; }}
    h1, h2, h3, h4 {{ margin: 0 0 8px; font-family: Georgia, serif; }}
    .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-top: 18px; }}
    .summary-grid div {{ padding: 12px; border: 1px solid var(--border); border-radius: 12px; background: #fffaf1; }}
    .toolbar {{ display: flex; gap: 12px; align-items: center; margin: 18px 0 24px; flex-wrap: wrap; }}
    .toolbar input, .toolbar select, .queue-builder input, .queue-builder select {{ min-width: 200px; padding: 12px 14px; border-radius: 999px; border: 1px solid var(--border); background: #fffdf8; }}
    .filter-buttons {{ display: flex; gap: 8px; flex-wrap: wrap; }}
    .filter-btn, .view-btn, .copy-review-command {{ padding: 6px 14px; border-radius: 999px; border: 1px solid var(--border); background: var(--panel); cursor: pointer; font-size: 0.85rem; font-family: inherit; transition: all 0.15s; }}
    .filter-btn:hover, .view-btn:hover, .copy-review-command:hover {{ border-color: var(--accent); }}
    .filter-btn.active, .view-btn.active, .copy-review-command {{ background: var(--accent); color: #fff; border-color: var(--accent); }}
    .muted {{ color: var(--muted); }}
    .badge, .delta {{ display: inline-flex; align-items: center; border-radius: 999px; padding: 4px 10px; font-size: 0.9rem; }}
    .pass {{ background: rgba(15, 118, 110, 0.12); color: var(--accent); }}
    .fail {{ background: rgba(180, 35, 24, 0.12); color: var(--danger); }}
    .warn {{ background: rgba(180, 83, 9, 0.12); color: var(--warn); }}
    .rank-badge {{ display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 50%; background: var(--warn); color: #fff; font-size: 0.75rem; font-weight: 700; margin-right: 8px; }}
    .judge-badge {{ display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; margin-left: 6px; }}
    .judge-badge.heuristic {{ background: rgba(15, 118, 110, 0.1); color: var(--accent); }}
    .judge-badge.model_judged {{ background: rgba(147, 51, 234, 0.1); color: #7c3aed; }}
    .case-card, .queue-card, .prompt-card {{ padding: 18px; margin-bottom: 18px; }}
    .case-card header, .queue-card header, .prompt-card header {{ display: flex; justify-content: space-between; gap: 12px; align-items: baseline; flex-wrap: wrap; }}
    .case-meta, .queue-cases {{ display: flex; gap: 10px; flex-wrap: wrap; color: var(--muted); }}
    .case-layout {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; margin-top: 14px; }}
    .span-two {{ grid-column: 1 / -1; }}
    .prompt-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 14px; margin-top: 14px; }}
    pre {{ margin: 0; white-space: pre-wrap; word-break: break-word; background: #fbf7ef; border: 1px solid var(--border); border-radius: 12px; padding: 12px; font-family: "SFMono-Regular", Consolas, monospace; font-size: 0.9rem; }}
    ul {{ margin: 0; padding-left: 18px; }}
    .metrics {{ display: grid; gap: 8px; }}
    .metric {{ display: grid; grid-template-columns: 180px 90px 1fr; gap: 10px; align-items: start; padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: #fffaf1; }}
    .metric-name {{ font-weight: 700; }}
    .compare-grid {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }}
    .failure-ranking {{ margin-bottom: 32px; }}
    .failure-ranking h2 {{ color: var(--danger); }}
    details summary {{ cursor: pointer; color: var(--muted); }}
    .view-toolbar {{ display: flex; gap: 8px; margin-bottom: 10px; }}
    .queue-builder {{ display: grid; gap: 10px; margin-top: 14px; }}
    .queue-builder label {{ display: grid; gap: 6px; font-weight: 700; }}
    .queue-actions {{ display: flex; gap: 10px; flex-wrap: wrap; }}
    .case-link {{ display: inline-flex; align-items: center; border: 1px solid var(--border); border-radius: 999px; padding: 4px 10px; text-decoration: none; color: inherit; }}
    @media (max-width: 820px) {{
      .case-layout, .compare-grid, .metric {{ grid-template-columns: 1fr; }}
      .span-two {{ grid-column: auto; }}
    }}
  </style>
</head>
<body>
  <main>
    <section class="hero">
      <h1>Experiment Review</h1>
      <p><code>{escape(str(experiment.get("experiment_id") or "unknown"))}</code> agent=<code>{escape(str(experiment.get("agent_id") or "unknown"))}</code> eval=<code>{escape(str(experiment.get("eval_id") or "unknown"))}</code> subset=<code>{escape(str(experiment.get("subset") or ""))}</code></p>
      {baseline_header}
      <div class="summary-grid">
        <div><strong>Average score</strong><br>{float(aggregate.get("average_score", 0.0) or 0.0):.3f}</div>
        <div><strong>Passed</strong><br>{int(aggregate.get("passed_cases", 0) or 0)}/{int(aggregate.get("total_cases", 0) or 0)}</div>
        <div><strong>Failures</strong><br>{len(failures)}</div>
        <div><strong>Regressions</strong><br>{regressions}</div>
        <div><strong>Total cost</strong><br>${total_cost:.4f}</div>
        <div><strong>Avg latency</strong><br>{int(avg_latency)}ms</div>
        <div><strong>Model</strong><br>{escape(str(spec_snapshot.get("model_name") or "unknown"))}</div>
        <div><strong>Prompts used</strong><br>{escape(", ".join(behavior.get("prompt_keys_used", []) or []) or "none")}</div>
      </div>
    </section>
    {prompt_section}
    {queue_section}
    {ranked_cards_html}
    <div class="toolbar">
      <input id="case-filter" type="search" placeholder="Filter cases by id, input, output, tool, trace, or error">
      <select id="case-sort">
        <option value="informative">Sort: informative failures first</option>
        <option value="score-desc">Sort: highest score</option>
        <option value="score-asc">Sort: lowest score</option>
        <option value="latency-desc">Sort: highest latency</option>
        <option value="cost-desc">Sort: highest cost</option>
        <option value="regression">Sort: regressions first</option>
      </select>
      <div class="filter-buttons">
        <button class="filter-btn active" data-filter="all">Show All ({len(rows)})</button>
        <button class="filter-btn" data-filter="fail">Failures ({len(failures)})</button>
        <button class="filter-btn" data-filter="regression">Regressions ({regressions})</button>
        <button class="filter-btn" data-filter="high-cost">High Cost</button>
      </div>
    </div>
    <section id="cases">{case_cards or '<p class="muted">No run rows available.</p>'}</section>
  </main>
  <script>
    const filterInput = document.getElementById('case-filter');
    const sortSelect = document.getElementById('case-sort');
    const casesContainer = document.getElementById('cases');
    const cards = Array.from(document.querySelectorAll('#cases .case-card'));
    const filterBtns = Array.from(document.querySelectorAll('.filter-btn'));
    let activeFilter = 'all';

    function numeric(card, key) {{
      return parseFloat(card.dataset[key] || '0');
    }}

    function applyFilters() {{
      const query = filterInput.value.trim().toLowerCase();
      const costs = cards.map(c => parseFloat(c.dataset.cost || '0')).sort((a, b) => b - a);
      const costThreshold = costs.length > 0
        ? costs[Math.max(0, Math.floor(costs.length * 0.25))]
        : 0;
      for (const card of cards) {{
        const haystack = card.dataset.search || '';
        let show = !query || haystack.includes(query);
        if (show && activeFilter === 'fail') show = card.dataset.status === 'fail';
        if (show && activeFilter === 'regression') show = card.dataset.regression === 'yes';
        if (show && activeFilter === 'high-cost') show = parseFloat(card.dataset.cost || '0') >= costThreshold;
        card.hidden = !show;
      }}
    }}

    function sortCards() {{
      const mode = sortSelect.value;
      const sorted = cards.slice().sort((left, right) => {{
        if (mode === 'score-desc') return numeric(right, 'score') - numeric(left, 'score');
        if (mode === 'score-asc') return numeric(left, 'score') - numeric(right, 'score');
        if (mode === 'latency-desc') return numeric(right, 'latency') - numeric(left, 'latency');
        if (mode === 'cost-desc') return numeric(right, 'cost') - numeric(left, 'cost');
        if (mode === 'regression') {{
          const leftRegression = left.dataset.regression === 'yes' ? 1 : 0;
          const rightRegression = right.dataset.regression === 'yes' ? 1 : 0;
          if (leftRegression !== rightRegression) return rightRegression - leftRegression;
          return numeric(left, 'score') - numeric(right, 'score');
        }}
        return numeric(left, 'rank') - numeric(right, 'rank');
      }});
      for (const card of sorted) {{
        casesContainer.appendChild(card);
      }}
    }}

    filterInput.addEventListener('input', applyFilters);
    sortSelect.addEventListener('change', sortCards);
    for (const btn of filterBtns) {{
      btn.addEventListener('click', () => {{
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeFilter = btn.dataset.filter;
        applyFilters();
      }});
    }}

    for (const card of cards) {{
      const buttons = Array.from(card.querySelectorAll('.view-btn'));
      const views = Array.from(card.querySelectorAll('.output-view'));
      for (const button of buttons) {{
        button.addEventListener('click', () => {{
          buttons.forEach(item => item.classList.remove('active'));
          button.classList.add('active');
          const activeView = button.dataset.view;
          for (const view of views) {{
            view.hidden = view.dataset.view !== activeView;
          }}
        }});
      }}
    }}

    function quoteArg(value) {{
      return '"' + String(value || '').replace(/(["\\\\$`])/g, '\\\\$1') + '"';
    }}

    for (const card of Array.from(document.querySelectorAll('.queue-card'))) {{
      const decision = card.querySelector('.decision-select');
      const guidance = card.querySelector('.guidance-input');
      const answer = card.querySelector('.answer-input');
      const preview = card.querySelector('.command-preview');
      const copyBtn = card.querySelector('.copy-review-command');
      const queueId = card.dataset.queueId || '';
      const checkpointId = card.dataset.checkpointId || '';
      const caseIds = (card.dataset.caseIds || '').split(',').filter(Boolean);
      function buildCommand() {{
        const parts = [
          'awb',
          'human-review',
          'answer',
          '--queue-id',
          quoteArg(queueId),
          '--checkpoint-id',
          quoteArg(checkpointId),
          '--decision',
          quoteArg(decision.value || 'candidate'),
        ];
        if ((guidance.value || '').trim()) {{
          parts.push('--guidance', quoteArg(guidance.value.trim()));
        }}
        if ((answer.value || '').trim()) {{
          parts.push('--answer', quoteArg(answer.value.trim()));
        }}
        for (const caseId of caseIds) {{
          parts.push('--case-id', quoteArg(caseId));
        }}
        return parts.join(' ');
      }}
      function refreshPreview() {{
        preview.textContent = buildCommand();
      }}
      refreshPreview();
      for (const input of [decision, guidance, answer]) {{
        input.addEventListener('input', refreshPreview);
        input.addEventListener('change', refreshPreview);
      }}
      copyBtn.addEventListener('click', async () => {{
        const command = buildCommand();
        if (navigator.clipboard && navigator.clipboard.writeText) {{
          await navigator.clipboard.writeText(command);
        }}
        preview.textContent = command;
      }});
    }}

    applyFilters();
    sortCards();
  </script>
</body>
</html>"""


__all__ = ["render_experiment_review_html"]
