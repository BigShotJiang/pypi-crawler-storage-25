from __future__ import annotations

import math
import re
from typing import Any

from agentworkbench.text_utils import normalized_alnum_text

_EVIDENCE_EVENT_KINDS = {"retrieval", "memory_lookup", "tool_result"}
_TEXT_KEYS = ("snippet", "text", "content", "value", "line")
_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "if",
    "in",
    "into",
    "is",
    "it",
    "of",
    "on",
    "or",
    "that",
    "the",
    "then",
    "this",
    "to",
    "when",
    "with",
}


def _clip_text(value: Any, limit: int = 240) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    return f"{text[: limit - 3].rstrip()}..."


def _text_tokens(value: Any, *, min_length: int = 3) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9]+", str(value or "").lower()) if len(token) >= min_length]


def _token_windows(tokens: list[str], *, min_size: int, max_size: int) -> list[str]:
    if len(tokens) < min_size:
        return []
    windows: list[str] = []
    upper = min(max_size, len(tokens))
    for size in range(upper, min_size - 1, -1):
        for start in range(0, len(tokens) - size + 1):
            windows.append(" ".join(tokens[start : start + size]))
    return windows


def _int_value(value: Any, default: int = 0) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str) and value.strip():
        try:
            return int(float(value))
        except ValueError:
            return default
    return default


def _float_value(value: Any) -> float | None:
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (float, int)):
        return float(value)
    if isinstance(value, str) and value.strip():
        try:
            return float(value)
        except ValueError:
            return None
    return None


def _status_from_payload(payload: dict[str, Any]) -> str:
    explicit = str(payload.get("status") or "").strip().lower()
    if explicit:
        return explicit
    if payload.get("error") not in (None, "", False):
        return "error"
    if payload.get("loaded") not in (None, ""):
        return "success" if bool(payload.get("loaded")) else "empty"
    if payload.get("selected") not in (None, ""):
        return "success" if bool(payload.get("selected")) else "empty"
    if payload.get("hit_count") not in (None, ""):
        return "success" if _int_value(payload.get("hit_count")) > 0 else "empty"
    if payload.get("hits") not in (None, ""):
        if isinstance(payload.get("hits"), list):
            return "success" if payload.get("hits") else "empty"
        return "success" if _int_value(payload.get("hits")) > 0 else "empty"
    return "success"


def snippet_supported_by_output(snippet: str, output: str) -> bool:
    snippet_text = normalized_alnum_text(snippet)
    output_text = normalized_alnum_text(output)
    if not snippet_text or not output_text:
        return False
    if snippet_text in output_text:
        return True
    snippet_tokens = _text_tokens(snippet, min_length=1)
    if any(window and window in output_text for window in _token_windows(snippet_tokens, min_size=4, max_size=6)):
        return True
    meaningful_tokens = sorted({token for token in _text_tokens(snippet) if token not in _STOPWORDS})
    if len(meaningful_tokens) < 4:
        meaningful_tokens = sorted(set(_text_tokens(snippet)))
    if len(meaningful_tokens) < 4:
        return False
    output_tokens = {token for token in _text_tokens(output) if token not in _STOPWORDS}
    if not output_tokens:
        output_tokens = set(_text_tokens(output))
    overlap = sum(1 for token in meaningful_tokens if token in output_tokens)
    needed = max(3, math.ceil(len(meaningful_tokens) * 0.6))
    return overlap >= needed


def evidence_record_label(record: dict[str, Any]) -> str:
    label = str(record.get("label") or "").strip()
    if label:
        return label
    kind = str(record.get("kind") or "evidence").strip() or "evidence"
    name = str(record.get("name") or kind).strip() or kind
    return f"{kind}:{name}"


def _hit_identifier(path: str, line: int, index: int, label: str) -> str:
    if path and line > 0:
        return f"{path}#L{line}"
    if path:
        return path
    return f"{label}#{index}"


def _normalize_hit(
    raw_hit: Any,
    *,
    label: str,
    index: int,
    output: str,
    default_selected: bool = False,
) -> dict[str, Any] | None:
    if isinstance(raw_hit, str):
        hit = {"snippet": raw_hit}
    elif isinstance(raw_hit, dict):
        hit = dict(raw_hit)
    else:
        return None
    snippet = ""
    for key in _TEXT_KEYS:
        value = hit.get(key)
        if str(value or "").strip():
            snippet = str(value).strip()
            break
    path = str(hit.get("path") or hit.get("source_path") or "").strip()
    line = _int_value(hit.get("line") or hit.get("line_number"), 0)
    selected = bool(hit.get("selected")) if "selected" in hit else default_selected
    heuristic_supported = selected and snippet_supported_by_output(snippet, output)
    used_in_output = (
        bool(hit.get("used_in_output")) or heuristic_supported
        if "used_in_output" in hit
        else heuristic_supported
    )
    normalized = {
        "id": str(hit.get("id") or _hit_identifier(path, line, index, label)),
        "path": path,
        "line": line,
        "snippet": _clip_text(snippet, 240),
        "selected": selected,
        "used_in_output": used_in_output,
    }
    score = _float_value(hit.get("score"))
    if score is not None:
        normalized["score"] = round(score, 3)
    return normalized


def _iter_raw_evidence_records(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    explicit = artifact.get("evidence_records")
    if explicit is None:
        explicit = artifact.get("evidence")
    records: list[dict[str, Any]] = []
    for item in explicit or []:
        if isinstance(item, dict):
            records.append(dict(item))
    if records:
        return records

    fallback: list[dict[str, Any]] = []
    for item in artifact.get("events") or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "").strip()
        if kind not in _EVIDENCE_EVENT_KINDS:
            continue
        fallback.append(
            {
                "kind": kind,
                "name": item.get("tool") or item.get("name"),
                "mcp": item.get("mcp"),
                "status": item.get("status"),
                "hit_count": item.get("hits"),
                "selected_count": 1 if bool(item.get("selected") or item.get("loaded")) else 0,
                "used_count": 0,
            }
        )
    if fallback:
        return fallback

    for item in artifact.get("tool_calls") or []:
        if not isinstance(item, dict):
            continue
        fallback.append(
            {
                "kind": "retrieval",
                "name": item.get("name") or item.get("tool") or item.get("id"),
                "mcp": item.get("mcp"),
                "status": item.get("status"),
                "hit_count": item.get("hits"),
                "selected_count": 1 if bool(item.get("selected") or item.get("loaded")) else 0,
                "used_count": 0,
            }
        )
    return fallback


def normalize_evidence_records(artifact: dict[str, Any], final_output: str | None = None) -> list[dict[str, Any]]:
    output = str(final_output if final_output is not None else artifact.get("final_output") or "")
    records: list[dict[str, Any]] = []
    for raw in _iter_raw_evidence_records(artifact):
        kind = str(raw.get("kind") or raw.get("type") or raw.get("category") or "evidence").strip() or "evidence"
        name = str(raw.get("name") or raw.get("tool") or raw.get("source") or kind).strip() or kind
        label = str(raw.get("label") or f"{kind}:{name}")
        hits: list[dict[str, Any]] = []
        raw_hits = raw.get("hits") if isinstance(raw.get("hits"), list) else raw.get("items")
        if isinstance(raw_hits, list):
            for hit_index, hit in enumerate(raw_hits, start=1):
                normalized_hit = _normalize_hit(hit, label=label, index=hit_index, output=output)
                if normalized_hit:
                    hits.append(normalized_hit)
        elif any(str(raw.get(key) or "").strip() for key in ("path", *_TEXT_KEYS)):
            normalized_hit = _normalize_hit(raw, label=label, index=1, output=output, default_selected=bool(raw.get("selected") or raw.get("loaded")))
            if normalized_hit:
                hits.append(normalized_hit)
        selected_count = _int_value(raw.get("selected_count"), -1)
        if selected_count < 0:
            selected_count = sum(1 for hit in hits if bool(hit.get("selected")))
        if selected_count <= 0 and raw.get("selected") not in (None, ""):
            selected_count = 1 if bool(raw.get("selected")) else 0
        if selected_count <= 0 and raw.get("loaded") not in (None, ""):
            selected_count = 1 if bool(raw.get("loaded")) else 0
        hit_count = _int_value(raw.get("hit_count"), -1)
        if hit_count < 0:
            hits_value = raw.get("hits")
            if isinstance(hits_value, int):
                hit_count = hits_value
            elif isinstance(hits_value, list):
                hit_count = len(hits_value)
            else:
                hit_count = len(hits)
        computed_used_count = sum(1 for hit in hits if bool(hit.get("used_in_output")))
        used_count = _int_value(raw.get("used_count"), -1)
        if used_count < 0:
            used_count = computed_used_count
        else:
            used_count = max(used_count, computed_used_count)
        used_in_output = (
            bool(raw.get("used_in_output")) or bool(used_count)
            if "used_in_output" in raw
            else bool(used_count)
        )
        normalized = {
            "kind": kind,
            "name": name,
            "label": label,
            "status": _status_from_payload(
                {
                    **raw,
                    "hit_count": hit_count,
                    "selected": selected_count > 0,
                }
            ),
            "query": _clip_text(raw.get("query"), 240),
            "hit_count": max(0, hit_count),
            "selected_count": max(0, selected_count),
            "used_count": max(0, used_count),
            "used_in_output": used_in_output,
            "hits": hits[:5],
        }
        mcp = str(raw.get("mcp") or "").strip()
        if mcp:
            normalized["mcp"] = mcp
        records.append(normalized)
    return records


def summarize_evidence_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    source_counts: dict[str, int] = {}
    kind_counts: dict[str, int] = {}
    source_summaries: dict[str, dict[str, Any]] = {}
    total_hits = 0
    total_selected = 0
    total_used = 0
    for record in records:
        label = evidence_record_label(record)
        kind = str(record.get("kind") or "evidence")
        source_counts[label] = source_counts.get(label, 0) + 1
        kind_counts[kind] = kind_counts.get(kind, 0) + 1
        hit_count = _int_value(record.get("hit_count"), 0)
        selected_count = _int_value(record.get("selected_count"), 0)
        used_count = _int_value(record.get("used_count"), 0)
        total_hits += hit_count
        total_selected += selected_count
        total_used += used_count
        summary = source_summaries.setdefault(
            label,
            {
                "records": 0,
                "hits": 0,
                "selected": 0,
                "used": 0,
                "mcps": set(),
                "statuses": set(),
                "paths": set(),
            },
        )
        summary["records"] += 1
        summary["hits"] += hit_count
        summary["selected"] += selected_count
        summary["used"] += used_count
        if record.get("mcp"):
            summary["mcps"].add(str(record["mcp"]))
        if record.get("status"):
            summary["statuses"].add(str(record["status"]))
        for hit in record.get("hits") or []:
            path = str((hit or {}).get("path") or "").strip()
            if path:
                summary["paths"].add(path)
    finalized_sources: dict[str, Any] = {}
    for label, summary in sorted(source_summaries.items()):
        selected = int(summary["selected"])
        used = int(summary["used"])
        finalized_sources[label] = {
            "records": int(summary["records"]),
            "hits": int(summary["hits"]),
            "selected": selected,
            "used": used,
            "use_rate": round(used / selected, 3) if selected else None,
            "mcps": sorted(summary["mcps"]),
            "statuses": sorted(summary["statuses"]),
            "paths": sorted(summary["paths"]),
        }
    return {
        "record_count": len(records),
        "hit_count": total_hits,
        "selected_count": total_selected,
        "used_count": total_used,
        "use_rate": round(total_used / total_selected, 3) if total_selected else None,
        "source_labels": sorted(source_counts),
        "source_counts": dict(sorted(source_counts.items())),
        "kind_counts": dict(sorted(kind_counts.items())),
        "sources_with_unused_selected": sorted(
            label
            for label, summary in finalized_sources.items()
            if int(summary.get("selected", 0)) > int(summary.get("used", 0))
        ),
        "source_summaries": finalized_sources,
    }


def artifact_evidence_summary(artifact: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    records = normalize_evidence_records(artifact, final_output=str(artifact.get("final_output") or ""))
    return records, summarize_evidence_records(records)
