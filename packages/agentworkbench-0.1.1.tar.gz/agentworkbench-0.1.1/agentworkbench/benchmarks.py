from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, dump_model
from agentworkbench.constants import BENCHMARK_SCHEMA_VERSION
from agentworkbench.evals import eval_path, load_eval_suite, scorer_path, split_path, suite_path
from agentworkbench.models import EvalCase, EvalSuiteSpec
from agentworkbench.utils import (
    created_at_utc,
    ensure_dir,
    read_json,
    read_jsonl,
    read_yaml,
    write_json,
    write_jsonl,
    write_text,
    write_yaml,
)


def benchmark_root(project_root: Path) -> Path:
    return control_dir(project_root) / "benchmarks"


def benchmark_registry_path(project_root: Path) -> Path:
    return benchmark_root(project_root) / "registry.json"


def benchmark_bundle_path(project_root: Path, benchmark_id: str, version: int | None = None) -> Path:
    suffix = f"-v{int(version)}" if version is not None else ""
    return benchmark_root(project_root) / f"{benchmark_id}{suffix}.json"


def _utc_now() -> str:
    return created_at_utc()


def _bundle_manifest(bundle: dict[str, Any]) -> dict[str, Any]:
    suite = EvalSuiteSpec.model_validate(bundle.get("suite") or {})
    cases = [EvalCase.model_validate(item) for item in bundle.get("cases") or []]
    splits = dict(bundle.get("splits") or {})
    scorer = dict(bundle.get("scorer") or {})
    benchmark_metadata = _benchmark_metadata_from_suite(suite)
    fingerprint_source = {
        "suite": suite.model_dump(mode="json"),
        "cases": [case.model_dump(mode="json") for case in cases],
        "splits": splits,
        "scorer": str(scorer.get("content") or ""),
    }
    fingerprint = hashlib.sha256(json.dumps(fingerprint_source, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    return {
        "fingerprint": fingerprint,
        "case_count": len(cases),
        "approval_status": suite.approval_status,
        "tags": list(suite.tags),
        "split_names": sorted(str(name) for name in splits),
        "split_sizes": {str(name): len(value or []) for name, value in sorted(splits.items())},
        "benchmark_metadata": benchmark_metadata,
    }


def _normalized_suite_metadata(suite: EvalSuiteSpec, cases: list[EvalCase]) -> EvalSuiteSpec:
    suite.generated_case_count = len(cases)
    suite.tags = sorted({str(tag) for case in cases for tag in case.tags if str(tag).strip()})
    return suite


def _string_list(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    return [str(item) for item in values if str(item).strip()]


def _benchmark_metadata_from_suite(suite: EvalSuiteSpec) -> dict[str, Any]:
    raw_metadata = dict(suite.metadata or {})
    benchmark_metadata = raw_metadata.get("benchmark") or {}
    if not isinstance(benchmark_metadata, dict):
        benchmark_metadata = {}
    metadata: dict[str, Any] = {}
    for field in BENCHMARK_METADATA_FIELDS:
        value = benchmark_metadata.get(field, raw_metadata.get(field))
        if field == "required_capabilities":
            metadata[field] = _string_list(value)
        else:
            metadata[field] = str(value or "").strip()
    return metadata


def build_eval_suite_bundle(
    project_root: Path,
    eval_id: str,
    *,
    benchmark_id: str | None = None,
) -> dict[str, Any]:
    cases = [EvalCase.model_validate(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    suite = _normalized_suite_metadata(load_eval_suite(project_root, eval_id), cases)
    splits = read_yaml(split_path(project_root, eval_id)) or {}
    scorer_file = scorer_path(project_root, eval_id)
    scorer_content = scorer_file.read_text(encoding="utf-8") if scorer_file.exists() else ""
    bundle = {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": str(benchmark_id or eval_id),
        "source_eval_id": eval_id,
        "exported_at": _utc_now(),
        "suite": suite.model_dump(mode="json"),
        "benchmark_metadata": _benchmark_metadata_from_suite(suite),
        "cases": [case.model_dump(mode="json") for case in cases],
        "splits": splits,
        "scorer": {
            "filename": scorer_file.name,
            "content": scorer_content,
        },
    }
    bundle["manifest"] = _bundle_manifest(bundle)
    return bundle


def export_eval_suite_bundle(
    project_root: Path,
    eval_id: str,
    *,
    output_path: Path | None = None,
    benchmark_id: str | None = None,
) -> dict[str, Any]:
    bundle = build_eval_suite_bundle(project_root, eval_id, benchmark_id=benchmark_id)
    destination = output_path or (control_dir(project_root) / "exports" / f"eval-{eval_id}.json")
    write_json(destination, bundle)
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": bundle["benchmark_id"],
        "source_eval_id": eval_id,
        "fingerprint": (bundle.get("manifest") or {}).get("fingerprint"),
        "output_path": str(destination),
    }


def _target_eval_paths(project_root: Path, eval_id: str) -> dict[str, Path]:
    return {
        "eval_file": eval_path(project_root, eval_id),
        "suite_file": suite_path(project_root, eval_id),
        "split_file": split_path(project_root, eval_id),
        "scorer_file": scorer_path(project_root, eval_id),
    }


def _validate_bundle(payload: dict[str, Any]) -> tuple[EvalSuiteSpec, list[EvalCase], dict[str, Any], dict[str, Any]]:
    """Validate a benchmark bundle, checking schema version, structure, and fingerprint integrity."""
    schema_version = str(payload.get("benchmark_schema_version") or "").strip()
    if schema_version not in {"", BENCHMARK_SCHEMA_VERSION}:
        raise ValueError(f"Unsupported benchmark bundle schema `{schema_version}`")
    for required_field in ("suite", "cases"):
        if required_field not in payload:
            raise ValueError(f"Benchmark bundle is missing required field: `{required_field}`")
    suite = EvalSuiteSpec.model_validate(payload.get("suite") or {})
    cases = [EvalCase.model_validate(item) for item in payload.get("cases") or []]
    splits = dict(payload.get("splits") or {})
    scorer = dict(payload.get("scorer") or {})
    if not cases:
        raise ValueError("Benchmark bundle must contain at least one eval case")
    if not splits:
        raise ValueError("Benchmark bundle must define at least one split")
    # Verify fingerprint integrity if a manifest is present
    bundled_manifest = payload.get("manifest") or {}
    if bundled_manifest.get("fingerprint"):
        recalculated = _bundle_manifest(payload)
        if recalculated["fingerprint"] != bundled_manifest["fingerprint"]:
            raise ValueError(
                f"Bundle fingerprint mismatch: expected {bundled_manifest['fingerprint']}, "
                f"got {recalculated['fingerprint']}. The bundle may have been tampered with or corrupted."
            )
    return suite, cases, splits, scorer


def import_eval_suite_bundle(
    project_root: Path,
    bundle_path: Path,
    *,
    eval_id: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    if not bundle_path.exists():
        raise FileNotFoundError(f"Benchmark bundle not found: {bundle_path}")
    payload = read_json(bundle_path)
    if not isinstance(payload, dict):
        raise ValueError("Benchmark bundle must contain a JSON object")
    suite, cases, splits, scorer = _validate_bundle(payload)
    target_eval_id = str(eval_id or payload.get("source_eval_id") or suite.id or "").strip()
    if not target_eval_id:
        raise ValueError("Benchmark bundle is missing a target eval id")
    paths = _target_eval_paths(project_root, target_eval_id)
    existing = [path for path in paths.values() if path.exists()]
    if existing and not overwrite:
        raise ValueError(
            f"Eval suite `{target_eval_id}` already exists. Re-run with `--force` to overwrite the existing files."
        )
    suite = _normalized_suite_metadata(suite, cases)
    suite.id = target_eval_id
    dump_model(paths["suite_file"], suite)
    write_jsonl(paths["eval_file"], [case.model_dump(mode="json") for case in cases])
    write_yaml(paths["split_file"], splits)
    scorer_content = str(scorer.get("content") or "")
    if scorer_content.strip():
        write_text(paths["scorer_file"], scorer_content)
    elif paths["scorer_file"].exists() and overwrite:
        paths["scorer_file"].unlink()
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": str(payload.get("benchmark_id") or ""),
        "source_eval_id": str(payload.get("source_eval_id") or suite.id),
        "eval_id": target_eval_id,
        "fingerprint": ((payload.get("manifest") or {}).get("fingerprint") or ""),
        "paths": {key: str(value) for key, value in paths.items()},
    }


def _load_registry(project_root: Path) -> dict[str, Any]:
    path = benchmark_registry_path(project_root)
    if not path.exists():
        return {
            "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
            "benchmarks": [],
        }
    payload = read_json(path)
    if not isinstance(payload, dict):
        raise ValueError("Benchmark registry must contain a JSON object")
    payload.setdefault("benchmark_schema_version", BENCHMARK_SCHEMA_VERSION)
    payload["benchmarks"] = [dict(item) for item in payload.get("benchmarks", []) if isinstance(item, dict)]
    return payload


def _write_registry(project_root: Path, payload: dict[str, Any]) -> Path:
    return write_json(benchmark_registry_path(project_root), payload)


def _entry_version(entry: dict[str, Any]) -> int:
    return int(entry.get("version", 1) or 1)


def _sorted_registry_entries(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        [dict(item) for item in entries if isinstance(item, dict)],
        key=lambda item: (str(item.get("benchmark_id") or ""), _entry_version(item), str(item.get("fingerprint") or "")),
    )


def _latest_registry_entries(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for entry in _sorted_registry_entries(entries):
        benchmark_id = str(entry.get("benchmark_id") or "")
        if not benchmark_id:
            continue
        current = latest.get(benchmark_id)
        if current is None or _entry_version(entry) >= _entry_version(current):
            latest[benchmark_id] = entry
    return sorted(latest.values(), key=lambda item: str(item.get("benchmark_id") or ""))


def _entry_matches_filters(
    entry: dict[str, Any],
    *,
    tags: list[str] | None = None,
    match: str | None = None,
    capability: str | None = None,
    agent_type: str | None = None,
    approval_status: str | None = None,
) -> bool:
    entry_tags = {str(item) for item in entry.get("tags", []) if str(item).strip()}
    if tags and not {str(item) for item in tags if str(item).strip()} <= entry_tags:
        return False
    if capability:
        capabilities = {str(item) for item in entry.get("required_capabilities", []) if str(item).strip()}
        if str(capability) not in capabilities:
            return False
    if agent_type and str(entry.get("intended_agent_type") or "").strip() != str(agent_type):
        return False
    if approval_status and str(entry.get("approval_status") or "").strip() != str(approval_status):
        return False
    if match:
        haystack = " ".join(
            [
                str(entry.get("benchmark_id") or ""),
                str(entry.get("source_eval_id") or ""),
                str(entry.get("origin_repo") or ""),
                str(entry.get("author") or ""),
                str(entry.get("version_label") or ""),
                str(entry.get("license") or ""),
                str(entry.get("intended_agent_type") or ""),
                str(entry.get("description") or ""),
                " ".join(str(item) for item in entry.get("tags", []) if str(item).strip()),
                " ".join(str(item) for item in entry.get("required_capabilities", []) if str(item).strip()),
            ]
        ).lower()
        if str(match).lower() not in haystack:
            return False
    return True


def _load_registered_entry(
    project_root: Path,
    benchmark_id: str,
    *,
    version: int | None = None,
) -> dict[str, Any]:
    registry = _load_registry(project_root)
    entries = [
        dict(item)
        for item in registry.get("benchmarks", [])
        if str(item.get("benchmark_id") or "") == str(benchmark_id)
    ]
    if not entries:
        raise ValueError(f"Benchmark `{benchmark_id}` is not registered")
    if version is not None:
        entry = next((item for item in entries if _entry_version(item) == int(version)), None)
        if entry is None:
            raise ValueError(f"Benchmark `{benchmark_id}` does not have version {version}")
        return entry
    return _latest_registry_entries(entries)[-1]


def load_registered_benchmark_bundle(
    project_root: Path,
    benchmark_id: str,
    *,
    version: int | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    entry = _load_registered_entry(project_root, benchmark_id, version=version)
    bundle_path = Path(str(entry.get("bundle_path") or ""))
    if not bundle_path.is_absolute():
        bundle_path = project_root / bundle_path
    payload = read_json(bundle_path)
    if not isinstance(payload, dict):
        raise ValueError(f"Benchmark bundle `{bundle_path}` is not a JSON object")
    return entry, payload


def _normalized_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def benchmark_integrity_report(bundle: dict[str, Any]) -> dict[str, Any]:
    suite = EvalSuiteSpec.model_validate(bundle.get("suite") or {})
    cases = [EvalCase.model_validate(item) for item in bundle.get("cases") or []]
    scorer_content = str((bundle.get("scorer") or {}).get("content") or "").lower()
    duplicate_case_ids: list[str] = []
    duplicate_inputs: dict[str, list[str]] = {}
    duplicate_expecteds: dict[str, list[str]] = {}
    echoed_expected_case_ids: list[str] = []
    scorer_mentions_case_ids: list[str] = []
    scorer_mentions_expecteds: list[str] = []
    missing_metadata_fields = [
        field for field, value in _benchmark_metadata_from_suite(suite).items() if field != "required_capabilities" and not str(value).strip()
    ]

    seen_ids: set[str] = set()
    input_groups: dict[str, list[str]] = {}
    expected_groups: dict[str, list[str]] = {}
    for case in cases:
        if case.id in seen_ids:
            duplicate_case_ids.append(case.id)
        seen_ids.add(case.id)
        normalized_input = _normalized_text(case.input)
        normalized_expected = _normalized_text(case.expected)
        if normalized_input:
            input_groups.setdefault(normalized_input, []).append(case.id)
        if normalized_expected:
            expected_groups.setdefault(normalized_expected, []).append(case.id)
        if normalized_expected and len(normalized_expected) >= 12 and normalized_expected in normalized_input:
            echoed_expected_case_ids.append(case.id)
        if case.id.lower() in scorer_content:
            scorer_mentions_case_ids.append(case.id)
        if normalized_expected and len(normalized_expected) >= 18 and normalized_expected in scorer_content:
            scorer_mentions_expecteds.append(case.id)

    duplicate_inputs = {
        normalized: ids for normalized, ids in input_groups.items() if len(ids) > 1
    }
    duplicate_expecteds = {
        normalized: ids for normalized, ids in expected_groups.items() if len(ids) > 1
    }
    warnings: list[str] = []
    if missing_metadata_fields:
        warnings.append(
            "Benchmark metadata is incomplete: " + ", ".join(missing_metadata_fields)
        )
    if duplicate_inputs:
        warnings.append("Duplicate normalized inputs detected across cases.")
    if duplicate_expecteds:
        warnings.append("Duplicate normalized expected outputs detected across cases.")
    if echoed_expected_case_ids:
        warnings.append("Some cases echo the expected output inside the input, which weakens benchmark quality.")
    if scorer_mentions_case_ids or scorer_mentions_expecteds:
        warnings.append("Scorer contains case-specific identifiers or expected outputs; review for overfitting risk.")
    issues = []
    if duplicate_case_ids:
        issues.append("Duplicate case ids detected in benchmark bundle.")
    return {
        "healthy": not issues,
        "issues": issues,
        "warnings": warnings,
        "duplicate_case_ids": sorted(duplicate_case_ids),
        "duplicate_input_groups": duplicate_inputs,
        "duplicate_expected_groups": duplicate_expecteds,
        "echoed_expected_case_ids": sorted(echoed_expected_case_ids),
        "scorer_mentions_case_ids": sorted(scorer_mentions_case_ids),
        "scorer_mentions_expected_case_ids": sorted(scorer_mentions_expecteds),
        "missing_metadata_fields": missing_metadata_fields,
    }


def register_benchmark(
    project_root: Path,
    eval_id: str,
    *,
    benchmark_id: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    bundle = build_eval_suite_bundle(project_root, eval_id, benchmark_id=benchmark_id)
    bench_id = str(bundle["benchmark_id"])
    registry = _load_registry(project_root)
    entries = _sorted_registry_entries([dict(item) for item in registry.get("benchmarks", []) if isinstance(item, dict)])
    manifest = dict(bundle.get("manifest") or {})
    matching_entries = [entry for entry in entries if str(entry.get("benchmark_id") or "") == bench_id]
    duplicate_entry = next(
        (entry for entry in matching_entries if str(entry.get("fingerprint") or "") == str(manifest.get("fingerprint") or "")),
        None,
    )
    if duplicate_entry is not None and not overwrite:
        return {
            "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
            "benchmark_id": bench_id,
            "source_eval_id": eval_id,
            "fingerprint": str(manifest.get("fingerprint") or ""),
            "version": _entry_version(duplicate_entry),
            "version_label": str(duplicate_entry.get("version_label") or f"v{_entry_version(duplicate_entry)}"),
            "bundle_path": str(project_root / str(duplicate_entry.get("bundle_path") or "")),
            "registry_path": str(benchmark_registry_path(project_root)),
            "created_new_version": False,
            "duplicate_fingerprint": True,
        }

    next_version = max((_entry_version(entry) for entry in matching_entries), default=0) + 1
    destination = benchmark_bundle_path(project_root, bench_id, next_version)
    ensure_dir(destination.parent)
    write_json(destination, bundle)
    metadata = dict(manifest.get("benchmark_metadata") or {})
    for entry in entries:
        if str(entry.get("benchmark_id") or "") == bench_id:
            entry["active"] = False
    entries.append(
        {
            "benchmark_id": bench_id,
            "version": next_version,
            "version_label": str(metadata.get("version") or f"v{next_version}"),
            "active": True,
            "source_eval_id": eval_id,
            "bundle_path": str(destination.relative_to(project_root)),
            "fingerprint": str(manifest.get("fingerprint") or ""),
            "case_count": int(manifest.get("case_count") or 0),
            "approval_status": str(manifest.get("approval_status") or ""),
            "tags": [str(item) for item in manifest.get("tags", []) if str(item).strip()],
            "split_names": [str(item) for item in manifest.get("split_names", []) if str(item).strip()],
            "origin_repo": str(metadata.get("origin_repo") or ""),
            "author": str(metadata.get("author") or ""),
            "license": str(metadata.get("license") or ""),
            "intended_agent_type": str(metadata.get("intended_agent_type") or ""),
            "required_capabilities": _string_list(metadata.get("required_capabilities")),
            "description": str(metadata.get("description") or ""),
            "registered_at": _utc_now(),
        }
    )
    registry["benchmarks"] = _sorted_registry_entries(entries)
    _write_registry(project_root, registry)
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": bench_id,
        "source_eval_id": eval_id,
        "fingerprint": str(manifest.get("fingerprint") or ""),
        "version": next_version,
        "version_label": str(metadata.get("version") or f"v{next_version}"),
        "bundle_path": str(destination),
        "registry_path": str(benchmark_registry_path(project_root)),
        "created_new_version": True,
        "duplicate_fingerprint": False,
    }


def list_registered_benchmarks(
    project_root: Path,
    *,
    include_history: bool = False,
    tags: list[str] | None = None,
    match: str | None = None,
    capability: str | None = None,
    agent_type: str | None = None,
    approval_status: str | None = None,
) -> dict[str, Any]:
    registry = _load_registry(project_root)
    all_entries = _sorted_registry_entries([dict(item) for item in registry.get("benchmarks", []) if isinstance(item, dict)])
    selected = all_entries if include_history else _latest_registry_entries(all_entries)
    selected = [
        entry
        for entry in selected
        if _entry_matches_filters(
            entry,
            tags=tags,
            match=match,
            capability=capability,
            agent_type=agent_type,
            approval_status=approval_status,
        )
    ]
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_count": len(selected),
        "total_registered_versions": len(all_entries),
        "include_history": include_history,
        "benchmarks": selected,
    }


def show_registered_benchmark(project_root: Path, benchmark_id: str, *, version: int | None = None) -> dict[str, Any]:
    entry, bundle = load_registered_benchmark_bundle(project_root, benchmark_id, version=version)
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "entry": entry,
        "manifest": dict(bundle.get("manifest") or {}),
        "benchmark_metadata": dict(bundle.get("benchmark_metadata") or {}),
        "compatibility": check_benchmark_compatibility(project_root, bundle),
        "integrity": benchmark_integrity_report(bundle),
    }


def check_registered_benchmark(project_root: Path, benchmark_id: str, *, version: int | None = None) -> dict[str, Any]:
    entry, bundle = load_registered_benchmark_bundle(project_root, benchmark_id, version=version)
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": benchmark_id,
        "version": _entry_version(entry),
        "compatibility": check_benchmark_compatibility(project_root, bundle),
        "integrity": benchmark_integrity_report(bundle),
    }


def diff_registered_benchmark_versions(
    project_root: Path,
    benchmark_id: str,
    *,
    version_a: int | None = None,
    version_b: int | None = None,
) -> dict[str, Any]:
    registry = _load_registry(project_root)
    matching_entries = [
        dict(item)
        for item in registry.get("benchmarks", [])
        if str(item.get("benchmark_id") or "") == str(benchmark_id)
    ]
    if len(matching_entries) < 2:
        raise ValueError(f"Benchmark `{benchmark_id}` does not have enough versions to diff")
    ordered_versions = sorted({_entry_version(entry) for entry in matching_entries})
    resolved_version_b = version_b if version_b is not None else ordered_versions[-1]
    resolved_version_a = version_a if version_a is not None else ordered_versions[-2]
    entry_a, bundle_a = load_registered_benchmark_bundle(project_root, benchmark_id, version=resolved_version_a)
    entry_b, bundle_b = load_registered_benchmark_bundle(project_root, benchmark_id, version=resolved_version_b)
    return {
        "benchmark_schema_version": BENCHMARK_SCHEMA_VERSION,
        "benchmark_id": benchmark_id,
        "version_a": _entry_version(entry_a),
        "version_b": _entry_version(entry_b),
        "entry_a": entry_a,
        "entry_b": entry_b,
        "diff": diff_benchmarks(bundle_a, bundle_b),
    }


def install_registered_benchmark(
    project_root: Path,
    benchmark_id: str,
    *,
    version: int | None = None,
    eval_id: str | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    entry = _load_registered_entry(project_root, benchmark_id, version=version)
    bundle_path = Path(str(entry.get("bundle_path") or ""))
    if not bundle_path.is_absolute():
        bundle_path = project_root / bundle_path
    result = import_eval_suite_bundle(project_root, bundle_path, eval_id=eval_id, overwrite=overwrite)
    result["benchmark_id"] = benchmark_id
    result["version"] = _entry_version(entry)
    result["registered_bundle_path"] = str(bundle_path)
    return result


__all__ = [
    "benchmark_integrity_report",
    "benchmark_root",
    "benchmark_registry_path",
    "benchmark_bundle_path",
    "build_eval_suite_bundle",
    "export_eval_suite_bundle",
    "import_eval_suite_bundle",
    "load_registered_benchmark_bundle",
    "register_benchmark",
    "list_registered_benchmarks",
    "show_registered_benchmark",
    "check_registered_benchmark",
    "diff_registered_benchmark_versions",
    "install_registered_benchmark",
    "benchmark_lock_path",
    "load_benchmark_lock",
    "save_benchmark_lock",
    "check_benchmark_compatibility",
    "diff_benchmarks",
]


BENCHMARK_METADATA_FIELDS = [
    "origin_repo",
    "author",
    "version",
    "license",
    "intended_agent_type",
    "required_capabilities",
    "description",
]


def benchmark_lock_path(project_root: Path) -> Path:
    return benchmark_root(project_root) / "lock.json"


def load_benchmark_lock(project_root: Path) -> dict[str, Any]:
    path = benchmark_lock_path(project_root)
    if not path.exists():
        return {"locked_benchmarks": {}}
    payload = read_json(path)
    return dict(payload) if isinstance(payload, dict) else {"locked_benchmarks": {}}


def save_benchmark_lock(project_root: Path, lock_data: dict[str, Any]) -> Path:
    return write_json(benchmark_lock_path(project_root), lock_data)


def check_benchmark_compatibility(
    project_root: Path,
    bundle: dict[str, Any],
) -> dict[str, Any]:
    issues: list[str] = []
    warnings: list[str] = []
    suite = bundle.get("suite") or {}
    scorer = bundle.get("scorer") or {}
    benchmark_metadata = bundle.get("benchmark_metadata") or {}
    required_terms = suite.get("required_terms", [])
    if required_terms:
        warnings.append(f"Benchmark expects required_terms: {required_terms}")
    has_scorer = bool(scorer.get("content", "").strip())
    if not has_scorer:
        warnings.append("Benchmark has no custom scorer - will use default")
    missing_metadata = [
        field
        for field in BENCHMARK_METADATA_FIELDS
        if field != "required_capabilities" and not str(benchmark_metadata.get(field) or "").strip()
    ]
    if missing_metadata:
        warnings.append("Benchmark metadata is incomplete: " + ", ".join(missing_metadata))
    del project_root
    return {
        "compatible": len(issues) == 0,
        "issues": issues,
        "warnings": warnings,
    }


def diff_benchmarks(
    bundle_a: dict[str, Any],
    bundle_b: dict[str, Any],
) -> dict[str, Any]:
    manifest_a = bundle_a.get("manifest") or {}
    manifest_b = bundle_b.get("manifest") or {}
    cases_a = bundle_a.get("cases") or []
    cases_b = bundle_b.get("cases") or []
    metadata_a = dict(manifest_a.get("benchmark_metadata") or {})
    metadata_b = dict(manifest_b.get("benchmark_metadata") or {})
    return {
        "fingerprint_a": manifest_a.get("fingerprint", ""),
        "fingerprint_b": manifest_b.get("fingerprint", ""),
        "fingerprint_changed": manifest_a.get("fingerprint") != manifest_b.get("fingerprint"),
        "case_count_a": len(cases_a),
        "case_count_b": len(cases_b),
        "case_count_delta": len(cases_a) - len(cases_b),
        "tags_a": sorted({str(item) for item in manifest_a.get("tags", []) if str(item).strip()}),
        "tags_b": sorted({str(item) for item in manifest_b.get("tags", []) if str(item).strip()}),
        "tags_added": sorted(
            {str(item) for item in manifest_b.get("tags", []) if str(item).strip()}
            - {str(item) for item in manifest_a.get("tags", []) if str(item).strip()}
        ),
        "tags_removed": sorted(
            {str(item) for item in manifest_a.get("tags", []) if str(item).strip()}
            - {str(item) for item in manifest_b.get("tags", []) if str(item).strip()}
        ),
        "required_capabilities_added": sorted(
            {str(item) for item in metadata_b.get("required_capabilities", []) if str(item).strip()}
            - {str(item) for item in metadata_a.get("required_capabilities", []) if str(item).strip()}
        ),
        "required_capabilities_removed": sorted(
            {str(item) for item in metadata_a.get("required_capabilities", []) if str(item).strip()}
            - {str(item) for item in metadata_b.get("required_capabilities", []) if str(item).strip()}
        ),
        "version_label_a": str(metadata_a.get("version") or ""),
        "version_label_b": str(metadata_b.get("version") or ""),
    }


BENCHMARK_PACK_TEMPLATES = {
    "support": {
        "name": "Support Agent Pack",
        "description": "Eval suite for customer support agents",
        "suggested_tags": ["support", "qa", "troubleshooting"],
        "suggested_metrics": ["output_quality", "grounding_support", "process_alignment"],
    },
    "coding": {
        "name": "Coding Agent Pack",
        "description": "Eval suite for code generation and refactoring agents",
        "suggested_tags": ["coding", "debugging", "refactoring"],
        "suggested_metrics": ["output_quality", "json_schema_adherence", "process_alignment"],
    },
    "retrieval": {
        "name": "Retrieval Agent Pack",
        "description": "Eval suite for information retrieval agents",
        "suggested_tags": ["retrieval", "search", "qa"],
        "suggested_metrics": ["output_quality", "grounding_support"],
    },
    "workflow": {
        "name": "Workflow Agent Pack",
        "description": "Eval suite for multi-step workflow agents",
        "suggested_tags": ["workflow", "orchestration", "planning"],
        "suggested_metrics": ["process_alignment", "output_quality"],
    },
}


def get_benchmark_pack_template(pack_type: str) -> dict[str, Any] | None:
    return BENCHMARK_PACK_TEMPLATES.get(pack_type)
