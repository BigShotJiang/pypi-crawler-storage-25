"""Paired per-case comparison statistics (case-id aligned, not list-position aligned)."""

from __future__ import annotations

import random
from typing import Any


def bootstrap_metric_summary(values: list[float], *, samples: int = 2000, seed: int = 0) -> dict[str, Any]:
    if not values:
        return {"count": 0, "mean": 0.0, "ci_low": 0.0, "ci_high": 0.0, "probability_positive": None}
    mean = sum(values) / len(values)
    if len(values) == 1:
        probability_positive = 1.0 if mean > 0 else (0.0 if mean < 0 else 0.5)
        return {
            "count": 1,
            "mean": round(mean, 3),
            "ci_low": round(mean, 3),
            "ci_high": round(mean, 3),
            "probability_positive": probability_positive,
        }
    rng = random.Random(seed)
    sample_means: list[float] = []
    count = len(values)
    for _ in range(samples):
        total = 0.0
        for _index in range(count):
            total += values[rng.randrange(count)]
        sample_means.append(total / count)
    sample_means.sort()
    low_index = int((samples - 1) * 0.025)
    high_index = int((samples - 1) * 0.975)
    probability_positive = sum(1 for value in sample_means if value > 0.0) / len(sample_means)
    return {
        "count": count,
        "mean": round(mean, 3),
        "ci_low": round(sample_means[low_index], 3),
        "ci_high": round(sample_means[high_index], 3),
        "probability_positive": round(probability_positive, 3),
    }


def paired_comparison_statistics(baseline_rows: list[dict[str, Any]], candidate_rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Align rows by case id; bootstrap score deltas and per-case pass indicators."""
    baseline_by_id = {str((row.get("case") or {}).get("id") or ""): row for row in baseline_rows}
    candidate_by_id = {str((row.get("case") or {}).get("id") or ""): row for row in candidate_rows}
    shared_case_ids = sorted(case_id for case_id in set(baseline_by_id) & set(candidate_by_id) if case_id)
    score_deltas = [
        float(candidate_by_id[case_id].get("score", 0.0)) - float(baseline_by_id[case_id].get("score", 0.0))
        for case_id in shared_case_ids
    ]
    pass_deltas = [
        float(bool(candidate_by_id[case_id].get("passed"))) - float(bool(baseline_by_id[case_id].get("passed")))
        for case_id in shared_case_ids
    ]
    return {
        "shared_case_count": len(shared_case_ids),
        "average_score_delta": bootstrap_metric_summary(score_deltas, seed=11),
        "pass_rate_delta": bootstrap_metric_summary(pass_deltas, seed=29),
    }


__all__ = ["bootstrap_metric_summary", "paired_comparison_statistics"]
