from __future__ import annotations

from agentworkbench.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
