from __future__ import annotations

from typing import Any


def render_next_report(payload: dict[str, Any]) -> str:
    status = payload.get("status") or {}
    diagnosis = payload.get("diagnosis") or {}
    proposals = payload.get("proposals") or {}
    top_proposal = payload.get("top_proposal") or {}
    lines = [
        f"# Next Steps {payload.get('experiment_id') or 'unknown'}",
        "",
        f"- Agent: `{payload.get('agent_id') or 'unknown'}`",
        f"- Eval: `{payload.get('eval_id') or 'unknown'}`",
        f"- Subset: `{payload.get('subset') or 'unknown'}`",
        f"- Benchmark signature: `{payload.get('benchmark_signature') or 'unknown'}`",
        f"- Baseline: `{payload.get('baseline_id') or 'none'}`",
        f"- Recommended action: `{payload.get('recommended_action') or 'review'}`",
        f"- Summary: {payload.get('summary') or 'none'}",
        "",
        "## Why Now",
        "",
    ]
    for item in payload.get("why_now", []):
        lines.append(f"- {item}")
    if not payload.get("why_now"):
        lines.append("- none")
    lines.extend(["", "## Status Snapshot", ""])
    latest = status.get("latest_experiment") or {}
    if latest:
        lines.append(
            f"- latest_experiment=`{latest.get('experiment_id', 'unknown')}`, "
            f"score={float(latest.get('average_score', 0.0)):.3f}, "
            f"passed={latest.get('passed_cases', 0)}/{latest.get('total_cases', 0)}, "
            f"promotion=`{latest.get('promotion_status', 'candidate')}`"
        )
    else:
        lines.append("- latest_experiment: none")
    latest_compare = status.get("latest_compare") or {}
    if latest_compare:
        lines.append(
            f"- latest_compare=`{latest_compare.get('baseline_id', 'unknown')}` -> "
            f"`{latest_compare.get('candidate_id', 'unknown')}`, "
            f"mode=`{latest_compare.get('comparison_mode', 'unknown')}`, "
            f"recommended=`{latest_compare.get('recommended_action', 'review')}`"
        )
    else:
        lines.append("- latest_compare: none")
    latest_stability = status.get("latest_stability") or {}
    if latest_stability:
        lines.append(
            f"- latest_stability=`{latest_stability.get('series_id', 'unknown')}`, "
            f"repeats={latest_stability.get('repeat_count', 0)}"
        )
    else:
        lines.append("- latest_stability: none")
    lines.extend(["", "## Focus Cases", ""])
    for item in diagnosis.get("focus_cases", [])[:5]:
        lines.append(
            f"- `{item.get('case_id', 'unknown')}`: "
            f"reason={item.get('reason') or 'none'}, "
            f"score_delta={item.get('score_delta', 'n/a')}"
        )
    if not diagnosis.get("focus_cases"):
        lines.append("- none")
    lines.extend(["", "## Top Proposal", ""])
    if top_proposal:
        lines.append(
            f"- `{top_proposal.get('proposal_id', 'proposal')}` [{top_proposal.get('priority', 'medium')}]: "
            f"{top_proposal.get('title', 'Mutation Proposal')}"
        )
        lines.append(f"- category: `{top_proposal.get('category', 'mutation')}`")
        lines.append(f"- rationale: {top_proposal.get('rationale') or 'none'}")
        lines.append(f"- target_files: {', '.join(top_proposal.get('target_files', [])) or 'none'}")
        lines.append(f"- target_surfaces: {', '.join(top_proposal.get('target_surfaces', [])) or 'none'}")
        lines.append(f"- plan: {' | '.join(top_proposal.get('change_plan', [])) or 'none'}")
    else:
        lines.append("- none")
    lines.extend(["", "## Additional Proposals", ""])
    for item in proposals.get("proposals", [])[1:5]:
        lines.append(
            f"- `{item.get('proposal_id', 'proposal')}` [{item.get('priority', 'medium')}]: "
            f"{item.get('title', 'Mutation Proposal')} ({item.get('category', 'mutation')})"
        )
    if len(proposals.get("proposals", [])) <= 1:
        lines.append("- none")
    lines.extend(["", "## Next Commands", ""])
    for item in payload.get("next_commands", []):
        lines.append(
            f"- `{item.get('command', '')}`"
        )
        lines.append(f"- why: {item.get('reason') or 'none'}")
    if not payload.get("next_commands"):
        lines.append("- none")
    return "\n".join(lines)
