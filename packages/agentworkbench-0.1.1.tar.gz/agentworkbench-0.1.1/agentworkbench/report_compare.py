from __future__ import annotations

from agentworkbench.models import ComparisonRecord
from agentworkbench.report_builder import ReportBuilder


def render_compare_report(comparison: ComparisonRecord) -> str:
    improved_cases = [item for item in comparison.changed_cases if float(item.get("score_delta", 0.0)) > 0]
    regressed_cases = [item for item in comparison.changed_cases if float(item.get("score_delta", 0.0)) < 0]
    report = ReportBuilder(f"Compare {comparison.baseline_id} -> {comparison.candidate_id}")
    report.bullet(f"Comparison mode: `{comparison.comparison_mode}`")
    report.bullet(f"Summary: {comparison.summary}")
    report.bullet(f"Recommended action: `{comparison.recommended_action or 'review'}`")
    report.bullet(f"Improved cases: {len(improved_cases)}")
    report.bullet(f"Regressed cases: {len(regressed_cases)}")

    report.section("Spec Changes")
    if comparison.spec_changes:
        report.kv_map(comparison.spec_changes, skip_keys={"prompt_content_drift"})
    else:
        report.bullet("none")

    prompt_drift = comparison.spec_changes.get("prompt_content_drift", []) if comparison.spec_changes else []
    if prompt_drift:
        report.section("Prompt Drift")
        for item in prompt_drift:
            report.bullet(
                f"`{item.get('key', 'prompt')}`: source_changed={item.get('source_changed', False)}, "
                f"content_changed={item.get('content_changed', False)}, "
                f"baseline=`{item.get('baseline_source') or 'inline'}` ({item.get('baseline_content_hash') or 'none'}), "
                f"candidate=`{item.get('candidate_source') or 'inline'}` ({item.get('candidate_content_hash') or 'none'})"
            )
            report.bullet(
                f"baseline_preview={item.get('baseline_preview') or 'none'} | "
                f"candidate_preview={item.get('candidate_preview') or 'none'}"
            )

    report.section("Metric Deltas")
    if comparison.metric_deltas:
        for key, value in comparison.metric_deltas.items():
            report.bullet(f"`{key}`: {value:+.3f}")
    else:
        report.bullet("none")

    report.section("Statistics")
    statistics = comparison.statistical_summary or {}
    if statistics:
        report.bullet(f"Shared case count: {statistics.get('shared_case_count', 0)}")
        for key in ["average_score_delta", "pass_rate_delta"]:
            stat_value = statistics.get(key)
            if not isinstance(stat_value, dict) or not stat_value:
                report.bullet(f"`{key}`: none")
                continue
            report.bullet(
                f"`{key}`: mean={stat_value.get('mean', 0.0)}, "
                f"ci=[{stat_value.get('ci_low', 0.0)}, {stat_value.get('ci_high', 0.0)}], "
                f"probability_positive={stat_value.get('probability_positive')}"
            )
    else:
        report.bullet("none")

    report.section("Behavior Deltas")
    if comparison.behavior_deltas:
        report.kv_map(comparison.behavior_deltas)
    else:
        report.bullet("none")

    report.section("Promotion Gates")
    if comparison.gate_results:
        for key, value in comparison.gate_results.items():
            if isinstance(value, dict):
                report.bullet(
                    f"`{key}`: passed={value.get('passed')}, "
                    f"actual={value.get('actual')}, required={value.get('required')}"
                )
            else:
                report.bullet(f"`{key}`: {value}")
    else:
        report.bullet("none")

    report.section("Telemetry")
    telemetry = comparison.telemetry_summary or {}
    if telemetry:
        report.kv_map(telemetry)
    else:
        report.bullet("none")

    report.section("Benchmark Drift")
    drift = comparison.benchmark_drift or {}
    if drift:
        report.kv_map(drift)
    else:
        report.bullet("none")

    report.section("Stability")
    stability = comparison.stability_summary or {}
    if stability:
        for label in ["baseline", "candidate"]:
            stability_value = stability.get(label)
            if not isinstance(stability_value, dict) or not stability_value:
                report.bullet(f"`{label}`: none")
                continue
            metrics = stability_value.get("metrics") or {}
            score_metrics = metrics.get("average_score") or {}
            latency_metrics = metrics.get("average_latency_ms") or {}
            cost_metrics = metrics.get("average_cost_estimate") or {}
            report.bullet(
                f"`{label}`: repeats={stability_value.get('repeat_count', 0)}, "
                f"score_mean={score_metrics.get('mean', 'n/a')}, "
                f"score_stddev={score_metrics.get('stddev', 'n/a')}, "
                f"latency_cv={latency_metrics.get('cv', 'n/a')}, "
                f"cost_cv={cost_metrics.get('cv', 'n/a')}"
            )
    else:
        report.bullet("none")

    report.section("Between-Run Repo Changes")
    report.repo_change_summary(comparison.repo_change_summary or {})
    return report.text()
