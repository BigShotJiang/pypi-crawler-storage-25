from __future__ import annotations

import hashlib
from pathlib import Path

from agentworkbench.config import control_dir
from agentworkbench.models import AgentSpec
from agentworkbench.tool_interfaces import (
    enabled_tool_names,
    provider_tool_format,
    tool_docstring_targets,
    tool_schema_targets,
)
from agentworkbench.utils import enabled_item_names, slugify, write_yaml


def short_variant_label(*parts: str, limit: int = 48) -> str:
    raw = "-".join(slugify(str(part)) for part in parts if str(part).strip())
    if len(raw) <= limit:
        return raw
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:8]
    return f"{raw[: max(0, limit - 9)].rstrip('-')}-{digest}"


def temp_agent_spec_path(project_root: Path, spec: AgentSpec) -> Path:
    return control_dir(project_root) / "agents" / f"{spec.id}.yaml"


def write_temp_agent_spec(project_root: Path, spec: AgentSpec) -> Path:
    path = temp_agent_spec_path(project_root, spec)
    write_yaml(path, spec.model_dump(mode="json"))
    return path


def normalize_surface_groups(groups: list[str] | None) -> list[str]:
    normalized: list[str] = []
    for group in groups or []:
        normalized.extend(part.strip() for part in str(group).split(",") if part.strip())
    return normalized


def surface_targets(spec: AgentSpec, groups: list[str] | None) -> list[tuple[str, str]]:
    selected = set(normalize_surface_groups(groups) or ["prompts", "tools", "skills", "plugins", "mcps"])
    targets: list[tuple[str, str]] = []
    if "prompts" in selected:
        targets.extend(("prompts", str(key)) for key in sorted(spec.prompts))
    if "tools" in selected:
        targets.extend(("tools", name) for name in enabled_tool_names(spec))
    if "skills" in selected:
        targets.extend(("skills", name) for name in enabled_item_names(spec.skills))
    if "plugins" in selected:
        targets.extend(("plugins", name) for name in enabled_item_names(spec.plugins))
    if "mcps" in selected:
        targets.extend(("mcps", name) for name in enabled_item_names(spec.mcps))
    if "tool_docstrings" in selected:
        targets.extend(("tool_docstrings", name) for name in tool_docstring_targets(spec))
    if "tool_schemas" in selected:
        targets.extend(("tool_schemas", name) for name in tool_schema_targets(spec))
    if "tool_formats" in selected and spec.adapter == "provider" and enabled_tool_names(spec):
        targets.append(("tool_formats", provider_tool_format(spec)))
    return targets
