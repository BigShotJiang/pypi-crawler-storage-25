from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from agentworkbench.ablations import run_surface_ablations
from agentworkbench.bayesian import BayesianOptimizer, ParameterSpace
from agentworkbench.config import control_dir
from agentworkbench.evals import preferred_subset as resolve_preferred_subset
from agentworkbench.factorial import run_factorial_experiments
from agentworkbench.matrix import run_experiment_matrix
from agentworkbench.optimization_utils import short_variant_label, write_temp_agent_spec
from agentworkbench.patches import build_patch_template
from agentworkbench.proposals import build_mutation_proposal_payload, write_mutation_proposal_payload
from agentworkbench.reports import render_optimize_report, write_report
from agentworkbench.runner_compare import _initial_promotion_gates, compare_experiments
from agentworkbench.runner_diagnosis import diagnose_experiment
from agentworkbench.utils import created_at_utc, ensure_dir, utc_timestamp_slug, write_json


def optimizations_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "optimizations")


def _explicit_selection(
    case_ids: list[str] | None,
    tags: list[str] | None,
    match: str | None,
    case_limit: int | None,
) -> bool:
    return bool(case_ids or tags or str(match or "").strip() or case_limit is not None)


def _selection_kwargs(
    *,
    case_ids: list[str] | None,
    tags: list[str] | None,
    match: str | None,
    case_limit: int | None,
    explicit_only: bool,
) -> dict[str, Any]:
    if explicit_only and not _explicit_selection(case_ids, tags, match, case_limit):
        return {
            "case_ids": None,
            "tags": None,
            "match": None,
            "limit": None,
        }
    return {
        "case_ids": case_ids,
        "tags": tags,
        "match": match,
        "limit": case_limit,
    }


def _reserved_revalidation_budget(total_budget: int, current_subset: str, preferred_subset: str) -> int:
    if not preferred_subset or preferred_subset == current_subset:
        return 0
    if total_budget >= 8:
        return 3
    if total_budget >= 5:
        return 2
    return 0


def _search_budget_allocation(search_budget: int) -> dict[str, int]:
    if search_budget >= 10:
        return {
            "ablation_limit": 3,
            "factorial_factor_target": 3,
            "factorial_experiment_budget": 7,
        }
    if search_budget >= 7:
        return {
            "ablation_limit": 3,
            "factorial_factor_target": 2,
            "factorial_experiment_budget": 3,
        }
    if search_budget >= 5:
        return {
            "ablation_limit": 2,
            "factorial_factor_target": 2,
            "factorial_experiment_budget": 3,
        }
    return {
        "ablation_limit": min(4, max(0, search_budget)),
        "factorial_factor_target": 0,
        "factorial_experiment_budget": 0,
    }


def _resolve_control_experiment(
    project_root: Path,
    *,
    experiment_id: str | None,
    agent_id: str | None,
    eval_id: str | None,
    subset: str | None,
    case_ids: list[str] | None,
    tags: list[str] | None,
    match: str | None,
    case_limit: int | None,
) -> tuple[Any, int]:
    from agentworkbench.runner import _load_experiment, run_experiment

    explicit_selection = _explicit_selection(case_ids, tags, match, case_limit)
    if experiment_id:
        source_record, _aggregate = _load_experiment(project_root, experiment_id)
        if not explicit_selection:
            return source_record, 0
        control_record, _aggregate = run_experiment(
            project_root,
            source_record.agent_id,
            source_record.eval_id,
            source_record.subset,
            case_ids=case_ids,
            tags=tags,
            match=match,
            limit=case_limit,
        )
        return control_record, 1
    if not agent_id or not eval_id:
        raise ValueError("Provide either --experiment or both --agent-id and --eval-id for optimize.")
    control_record, _aggregate = run_experiment(
        project_root,
        agent_id,
        eval_id,
        subset or "full",
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=case_limit,
    )
    return control_record, 1


_EFFECT_PRIORITY = {
    "harmful_surface": 0,
    "prune_candidate": 1,
    "neutral_surface": 2,
    "valuable_surface": 3,
}


def _factor_candidate_score(item: dict[str, Any]) -> tuple[int, float, float, float, str, str]:
    effect = str(item.get("effect") or "valuable_surface")
    optimization_signal = str(item.get("optimization_signal") or "neutral")
    score_delta = float(item.get("average_score_delta", 0.0) or 0.0)
    passed_delta = float(item.get("passed_case_delta", 0.0) or 0.0)
    efficiency_gain = (
        max(0.0, -float(item.get("avg_step_count_delta", 0.0) or 0.0))
        + max(0.0, -float(item.get("avg_latency_ms_delta", 0.0) or 0.0) / 1000.0)
        + max(0.0, -float(item.get("avg_cost_estimate_delta", 0.0) or 0.0) * 100.0)
    )
    signal_bonus = 1.0 if optimization_signal == "noise_or_overhead" else 0.0
    return (
        _EFFECT_PRIORITY.get(effect, 9),
        -(score_delta + signal_bonus),
        -(efficiency_gain + max(0.0, passed_delta)),
        -float(item.get("marginal_value_score", 0.0) or 0.0),
        str(item.get("surface_kind") or ""),
        str(item.get("surface_name") or ""),
    )


def _shortlist_factor_candidates(ablation_payload: dict[str, Any], limit: int) -> list[str]:
    candidates = sorted(ablation_payload.get("results", []), key=_factor_candidate_score)
    factors: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        factor = f"{item.get('surface_kind')}:{item.get('surface_name')}"
        if factor in seen:
            continue
        seen.add(factor)
        factors.append(factor)
        if len(factors) >= limit:
            break
    return factors


def _matrix_stage_requested(
    matrix_agent_ids: list[str] | None,
    temperatures: list[float] | None,
    max_tokens: list[int] | None,
) -> bool:
    return bool(matrix_agent_ids or temperatures or max_tokens)


def _matrix_stage_config(
    *,
    control_agent_id: str,
    matrix_agent_ids: list[str] | None,
    temperatures: list[float] | None,
    max_tokens: list[int] | None,
) -> dict[str, Any]:
    agent_ids = list(dict.fromkeys(str(item) for item in (matrix_agent_ids or []) if str(item).strip()))
    if not agent_ids and (temperatures or max_tokens):
        agent_ids = [control_agent_id]
    return {
        "agent_ids": agent_ids,
        "temperatures": [float(item) for item in (temperatures or [])],
        "max_tokens": [int(item) for item in (max_tokens or [])],
    }


def _matrix_experiment_count(config: dict[str, Any]) -> int:
    agent_ids = list(config.get("agent_ids") or [])
    if not agent_ids:
        return 0
    temperature_axis = list(config.get("temperatures") or []) or [None]
    max_token_axis = list(config.get("max_tokens") or []) or [None]
    return len(agent_ids) * len(temperature_axis) * len(max_token_axis)


def run_bayesian_optimization(
    project_root: Path,
    *,
    agent_id: str,
    eval_id: str,
    subset: str = "smoke",
    temperatures: list[float] | None = None,
    max_tokens: list[int] | None = None,
    budget: int = 8,
) -> dict[str, Any]:
    """Run hyperparameter optimization using Bayesian optimization.

    Args:
        project_root: Project root path
        agent_id: Agent to optimize
        eval_id: Eval suite ID
        subset: Eval subset
        temperatures: Temperature values to try
        max_tokens: Max tokens values to try
        budget: Total experiments to run

    Returns:
        Optimization result with best hyperparameters
    """
    from agentworkbench.runner import load_agent_spec, run_experiment

    # Build parameter space
    param_space: dict[str, tuple[Any, ...] | list[Any]] = {}
    if temperatures:
        param_space["temperature"] = temperatures
    if max_tokens:
        param_space["max_tokens"] = max_tokens

    if not param_space:
        # Default search space
        param_space = {
            "temperature": [0.1, 0.3, 0.5, 0.7, 0.9],
            "max_tokens": [512, 1024, 2048],
        }

    space = ParameterSpace(param_space)
    optimizer = BayesianOptimizer(space, n_initial=max(2, budget // 4))

    results = []
    best_result = None
    best_score = float("-inf")
    base_spec = load_agent_spec(project_root, agent_id)
    temp_paths: list[Path] = []

    try:
        for i in range(budget):
            config = cast(dict[str, Any], optimizer.suggest())
            variant = base_spec.model_copy(deep=True)
            variant.model = dict(variant.model or {})
            if "temperature" in config:
                variant.model["temperature"] = float(config["temperature"])
            if "max_tokens" in config:
                variant.model["max_tokens"] = int(config["max_tokens"])
            variant.id = (
                f"{base_spec.id}-bayes-{i + 1:02d}-"
                f"{short_variant_label(str(config.get('temperature', 'na')), str(config.get('max_tokens', 'na')))}"
            )
            temp_paths.append(write_temp_agent_spec(project_root, variant))

            record, aggregate = run_experiment(
                project_root,
                agent_id=variant.id,
                eval_id=eval_id,
                subset=subset,
            )

            score = float(aggregate.get("average_score", 0.0) or 0.0)
            optimizer.observe(config, score)
            results.append(
                {
                    "experiment_id": record.experiment_id,
                    "agent_id": variant.id,
                    "config": config,
                    "score": score,
                    "average_latency_ms": float(record.behavior_summary.get("average_latency_ms", 0.0) or 0.0),
                    "average_cost_estimate": float(
                        record.behavior_summary.get("average_cost_estimate", 0.0) or 0.0
                    ),
                }
            )

            if score > best_score:
                best_score = score
                best_result = dict(config)
    finally:
        for path in temp_paths:
            if path.exists():
                path.unlink()

    return {
        "optimization_type": "bayesian",
        "best_params": best_result or {},
        "best_score": best_score,
        "all_results": results,
        "n_iterations": budget,
    }


def _summary_rank(summary: dict[str, Any]) -> tuple[float, float, float, float, float, str]:
    return (
        float(summary.get("average_score", 0.0) or 0.0),
        float(summary.get("passed_cases", 0.0) or 0.0),
        -float(summary.get("average_cost_estimate", 0.0) or 0.0),
        -float(summary.get("average_latency_ms", 0.0) or 0.0),
        -float(summary.get("average_step_count", 0.0) or 0.0),
        str(summary.get("experiment_id") or ""),
    )


def _load_search_candidates(
    project_root: Path,
    *,
    control_record: Any,
    ablation_payload: dict[str, Any] | None,
    factorial_payload: dict[str, Any] | None,
    matrix_payload: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    from agentworkbench.runner import _load_experiment, _record_summary

    candidates: list[dict[str, Any]] = [
        {
            "stage": "control",
            "experiment_id": control_record.experiment_id,
            "summary": _record_summary(control_record),
            "surface_changes": [],
        }
    ]
    seen = {control_record.experiment_id}
    for item in (ablation_payload or {}).get("results", []):
        experiment_id = str(item.get("experiment_id") or "")
        if not experiment_id or experiment_id in seen:
            continue
        record, _aggregate = _load_experiment(project_root, experiment_id)
        candidates.append(
            {
                "stage": "ablation",
                "experiment_id": experiment_id,
                "summary": _record_summary(record),
                "surface_changes": [
                    {
                        "factor": f"{item.get('surface_kind')}:{item.get('surface_name')}",
                        "enabled": False,
                        "effect": item.get("effect"),
                        "optimization_signal": item.get("optimization_signal"),
                    }
                ],
            }
        )
        seen.add(experiment_id)
    for item in (factorial_payload or {}).get("results", []):
        experiment_id = str(item.get("experiment_id") or "")
        if not experiment_id or experiment_id in seen:
            continue
        state = {str(key): bool(value) for key, value in (item.get("state") or {}).items()}
        candidates.append(
            {
                "stage": "factorial",
                "experiment_id": experiment_id,
                "summary": dict(item.get("summary") or {}),
                "surface_changes": [
                    {"factor": factor, "enabled": enabled} for factor, enabled in sorted(state.items()) if not enabled
                ],
                "deltas": dict(item.get("deltas") or {}),
            }
        )
        seen.add(experiment_id)
    for item in (matrix_payload or {}).get("experiments", []):
        experiment_id = str(item.get("experiment_id") or "")
        if not experiment_id or experiment_id in seen:
            continue
        candidates.append(
            {
                "stage": "matrix",
                "experiment_id": experiment_id,
                "summary": dict(item),
                "surface_changes": [],
            }
        )
        seen.add(experiment_id)
    candidates.sort(key=lambda item: _summary_rank(item.get("summary") or {}), reverse=True)
    return candidates


def _temporary_spec_paths(project_root: Path, *payloads: dict[str, Any] | None) -> list[Path]:
    paths: list[Path] = []
    for payload in payloads:
        for item in (payload or {}).get("temporary_spec_paths", []) or []:
            path = project_root / str(item)
            if path not in paths:
                paths.append(path)
    return paths


def _cleanup_temp_specs(paths: list[Path]) -> None:
    for path in paths:
        if path.exists():
            path.unlink()


def _top_search_candidates(search_candidates: list[dict[str, Any]], limit: int = 2) -> list[dict[str, Any]]:
    candidates = [item for item in search_candidates if str(item.get("stage") or "") != "control"]
    candidates.sort(key=lambda item: _summary_rank(item.get("summary") or {}), reverse=True)
    return candidates[:limit]


def _compact_comparison(payload: dict[str, Any]) -> dict[str, Any]:
    metric_deltas = payload.get("metric_deltas") or {}
    return {
        "baseline_id": payload.get("baseline_id"),
        "candidate_id": payload.get("candidate_id"),
        "comparison_mode": payload.get("comparison_mode"),
        "recommended_action": payload.get("recommended_action"),
        "summary": payload.get("summary"),
        "metric_deltas": {
            "average_score": float(metric_deltas.get("average_score", 0.0) or 0.0),
            "passed_cases": float(metric_deltas.get("passed_cases", 0.0) or 0.0),
            "metric.output_quality": float(metric_deltas.get("metric.output_quality", 0.0) or 0.0),
            "metric.process_alignment": float(metric_deltas.get("metric.process_alignment", 0.0) or 0.0),
        },
        "gate_results": dict(payload.get("gate_results") or {}),
        "gate_failures": [
            str(key)
            for key, value in (payload.get("gate_results") or {}).items()
            if key != "overall_passed" and isinstance(value, dict) and not bool(value.get("passed", True))
        ],
        "stability_summary": dict((payload.get("stability_summary") or {}).get("candidate") or {}),
        "benchmark_drift_status": str((payload.get("benchmark_drift") or {}).get("status") or ""),
        "changed_case_count": len(payload.get("changed_cases") or []),
    }


def _stability_rank_value(item: dict[str, Any]) -> tuple[float, float, float]:
    stability = dict((item.get("baseline_compare") or item.get("control_compare") or {}).get("stability_summary") or {})
    metrics = dict(stability.get("metrics") or {})
    score_stddev = float(((metrics.get("average_score") or {}).get("stddev")) or 0.0)
    latency_cv = float(((metrics.get("average_latency_ms") or {}).get("cv")) or 0.0)
    cost_cv = float(((metrics.get("average_cost_estimate") or {}).get("cv")) or 0.0)
    return (-score_stddev, -latency_cv, -cost_cv)


_ACTION_RANK = {"promote": 3, "review": 2, "review-benchmark-drift": 1, "reject": 0}


def _finalist_rank(item: dict[str, Any]) -> tuple[int, int, float, float, float, float, float, float, float, int, str]:
    summary = item.get("summary") or {}
    gate_results = item.get("gate_results") or {}
    control_metric_deltas = (item.get("control_compare") or {}).get("metric_deltas") or {}
    baseline_metric_deltas = (item.get("baseline_compare") or {}).get("metric_deltas") or {}
    stability_rank = _stability_rank_value(item)
    return (
        1 if bool(gate_results.get("overall_passed")) else 0,
        _ACTION_RANK.get(str(item.get("recommended_action") or "review"), -1),
        float(control_metric_deltas.get("average_score", 0.0) or 0.0),
        float(baseline_metric_deltas.get("average_score", 0.0) or 0.0),
        stability_rank[0],
        stability_rank[1],
        stability_rank[2],
        float(summary.get("average_score", 0.0) or 0.0),
        float(summary.get("passed_cases", 0.0) or 0.0),
        -len(item.get("gate_failures", []) or []),
        str(summary.get("experiment_id") or ""),
    )


def _assess_finalists(
    project_root: Path,
    *,
    final_control_record: Any,
    finalists: list[dict[str, Any]],
    explicit_baseline_id: str | None,
) -> list[dict[str, Any]]:
    from agentworkbench.runner import _best_comparable_baseline, _load_experiment

    assessed: list[dict[str, Any]] = []
    for finalist in finalists:
        experiment_id = str((finalist.get("summary") or {}).get("experiment_id") or finalist.get("experiment_id") or "")
        if not experiment_id:
            continue
        control_compare_payload = None
        if experiment_id != final_control_record.experiment_id:
            control_compare_payload = compare_experiments(
                project_root, final_control_record.experiment_id, experiment_id
            ).model_dump(mode="json")
        candidate_record, _aggregate = _load_experiment(project_root, experiment_id)
        baseline_record = None
        if explicit_baseline_id:
            baseline_record, _ = _load_experiment(project_root, explicit_baseline_id)
        else:
            baseline_record = _best_comparable_baseline(project_root, candidate_record)
        baseline_compare_payload = None
        gate_results: dict[str, Any]
        recommended_action: str
        if baseline_record is not None:
            if control_compare_payload and baseline_record.experiment_id == final_control_record.experiment_id:
                baseline_compare_payload = control_compare_payload
            else:
                baseline_compare_payload = compare_experiments(
                    project_root, baseline_record.experiment_id, experiment_id
                ).model_dump(mode="json")
            gate_results = dict((baseline_compare_payload or {}).get("gate_results") or {})
            recommended_action = str((baseline_compare_payload or {}).get("recommended_action") or "review")
        else:
            gate_results, recommended_action = _initial_promotion_gates(project_root, candidate_record)
        gate_failures = [
            str(key)
            for key, value in gate_results.items()
            if key != "overall_passed" and isinstance(value, dict) and not bool(value.get("passed", True))
        ]
        assessed.append(
            {
                **finalist,
                "baseline_id": baseline_record.experiment_id if baseline_record else None,
                "control_compare": _compact_comparison(control_compare_payload or {})
                if control_compare_payload
                else {},
                "baseline_compare": _compact_comparison(baseline_compare_payload or {})
                if baseline_compare_payload
                else {},
                "gate_results": gate_results,
                "gate_failures": gate_failures,
                "promotion_ready": bool(gate_results.get("overall_passed")),
                "recommended_action": recommended_action,
            }
        )
    return sorted(assessed, key=_finalist_rank, reverse=True)


def _revalidation_stage(
    project_root: Path,
    *,
    control_record: Any,
    search_candidates: list[dict[str, Any]],
    preferred_subset: str,
    revalidation_budget: int,
    case_ids: list[str] | None,
    tags: list[str] | None,
    match: str | None,
    case_limit: int | None,
) -> tuple[Any, list[dict[str, Any]], dict[str, Any], int, list[str]]:
    from agentworkbench.runner import _record_summary, run_experiment

    warnings: list[str] = []
    finalists = _top_search_candidates(search_candidates, limit=2)
    payload = {
        "preferred_subset": preferred_subset,
        "control_experiment_id": control_record.experiment_id,
        "control_revalidated": False,
        "revalidated_finalist_count": 0,
        "finalists": [],
    }
    if preferred_subset == control_record.subset:
        payload["finalists"] = finalists
        return control_record, finalists, payload, 0, warnings
    if revalidation_budget < 2:
        warnings.append(
            "Insufficient reserved budget for full-subset revalidation; finalist ranking stayed on the search subset."
        )
        payload["finalists"] = finalists[:1]
        return control_record, finalists[:1], payload, 0, warnings
    selection_kwargs = _selection_kwargs(
        case_ids=case_ids,
        tags=tags,
        match=match,
        case_limit=case_limit,
        explicit_only=True,
    )
    final_control_record, _aggregate = run_experiment(
        project_root,
        control_record.agent_id,
        control_record.eval_id,
        preferred_subset,
        case_ids=selection_kwargs["case_ids"],
        tags=selection_kwargs["tags"],
        match=selection_kwargs["match"],
        limit=selection_kwargs["limit"],
    )
    spent = 1
    revalidated: list[dict[str, Any]] = []
    finalist_limit = min(2, max(0, revalidation_budget - spent), len(finalists))
    for finalist in finalists[:finalist_limit]:
        summary = finalist.get("summary") or {}
        candidate_agent_id = str(summary.get("agent_id") or "").strip()
        if not candidate_agent_id:
            continue
        revalidated_record, _aggregate = run_experiment(
            project_root,
            candidate_agent_id,
            control_record.eval_id,
            preferred_subset,
            case_ids=selection_kwargs["case_ids"],
            tags=selection_kwargs["tags"],
            match=selection_kwargs["match"],
            limit=selection_kwargs["limit"],
        )
        revalidated.append(
            {
                **finalist,
                "source_experiment_id": finalist.get("experiment_id"),
                "experiment_id": revalidated_record.experiment_id,
                "summary": _record_summary(revalidated_record),
            }
        )
        spent += 1
    if not revalidated:
        warnings.append("No finalist candidates were revalidated on the preferred full subset.")
    payload.update(
        {
            "control_experiment_id": final_control_record.experiment_id,
            "control_revalidated": True,
            "revalidated_finalist_count": len(revalidated),
            "finalists": revalidated,
        }
    )
    return final_control_record, revalidated, payload, spent, warnings


def _patch_handoff(
    project_root: Path,
    *,
    proposals_payload: dict[str, Any],
    recommended_candidate: dict[str, Any],
) -> dict[str, Any]:
    top_proposal = ((proposals_payload.get("proposals") or []) or [{}])[0]
    proposal_id = str(top_proposal.get("proposal_id") or "").strip()
    if not proposal_id:
        return {}
    template_paths = build_patch_template(
        project_root,
        proposal_id=proposal_id,
        experiment_id=str(proposals_payload.get("experiment_id") or ""),
    )
    return {
        "proposal_experiment_id": str(proposals_payload.get("experiment_id") or ""),
        "proposal_id": proposal_id,
        "recommended_candidate_experiment_id": str(
            (recommended_candidate.get("summary") or {}).get("experiment_id")
            or recommended_candidate.get("experiment_id")
            or ""
        ),
        "recommended_surface_changes": list(recommended_candidate.get("surface_changes") or []),
        "template_paths": {key: str(value.relative_to(project_root)) for key, value in template_paths.items()},
    }


def _recommendation_reason(
    *,
    control_summary: dict[str, Any],
    recommended_candidate: dict[str, Any],
) -> str:
    recommended_summary = dict(recommended_candidate.get("summary") or {})
    gate_results = dict(recommended_candidate.get("gate_results") or {})
    if gate_results and bool(gate_results.get("overall_passed")):
        return (
            f"Top finalist `{recommended_summary.get('experiment_id', 'unknown')}` cleared the current promotion-style gates "
            f"and outranked the other finalists on score, stability, cost, and latency."
        )
    control_compare = dict(recommended_candidate.get("control_compare") or {})
    control_metric_deltas = dict(control_compare.get("metric_deltas") or {})
    control_score_delta = float(control_metric_deltas.get("average_score", 0.0) or 0.0)
    control_pass_delta = float(control_metric_deltas.get("passed_cases", 0.0) or 0.0)
    if control_score_delta > 0.0 or control_pass_delta > 0.0:
        return (
            f"Best finalist improved score by {control_score_delta:+.3f} and passed cases by {control_pass_delta:+.1f} "
            f"relative to the control experiment."
        )
    control_cost = float(control_summary.get("average_cost_estimate", 0.0) or 0.0)
    recommended_cost = float(recommended_summary.get("average_cost_estimate", 0.0) or 0.0)
    control_latency = float(control_summary.get("average_latency_ms", 0.0) or 0.0)
    recommended_latency = float(recommended_summary.get("average_latency_ms", 0.0) or 0.0)
    if recommended_cost < control_cost or recommended_latency < control_latency:
        return (
            f"No finalist cleared the current gates, but the best measured frontier candidate reduced cost from "
            f"{control_cost:.6f} to {recommended_cost:.6f} and latency from {control_latency:.1f}ms to {recommended_latency:.1f}ms."
        )
    return "The bounded search did not surface a finalist that clearly beats the control experiment under the current gates."


def _next_commands(
    *,
    control_experiment_id: str,
    final_control_experiment_id: str,
    preferred_subset: str,
    recommended_candidate: dict[str, Any],
    diagnosis: dict[str, Any],
    proposals_payload: dict[str, Any],
    patch_handoff: dict[str, Any],
) -> list[dict[str, str]]:
    commands: list[dict[str, str]] = []
    recommended_summary = dict(recommended_candidate.get("summary") or {})
    recommended_experiment_id = str(
        recommended_summary.get("experiment_id") or recommended_candidate.get("experiment_id") or ""
    ).strip()
    if recommended_experiment_id and recommended_experiment_id != final_control_experiment_id:
        commands.append(
            {
                "step": "compare",
                "command": f"awb compare --baseline {final_control_experiment_id} --candidate {recommended_experiment_id}",
                "reason": "Review the best finalist against the final control on the preferred comparison subset.",
            }
        )
        commands.append(
            {
                "step": "diagnose",
                "command": f"awb diagnose --experiment {recommended_experiment_id}",
                "reason": "Inspect why the winning finalist moved score, stability, cost, or latency.",
            }
        )
    commands.append(
        {
            "step": "propose",
            "command": f"awb propose --experiment {control_experiment_id} --limit {max(1, len(proposals_payload.get('proposals', [])))}",
            "reason": "Refresh the bounded implementation proposals for the real agent files.",
        }
    )
    if patch_handoff:
        commands.append(
            {
                "step": "patch_template",
                "command": (
                    f"awb patch-template --experiment {patch_handoff['proposal_experiment_id']} "
                    f"--proposal-id {patch_handoff['proposal_id']}"
                ),
                "reason": "Regenerate or update the top patch template after reviewing the measured winner.",
            }
        )
    commands.append(
        {
            "step": "iterate",
            "command": f"awb iterate --experiment {control_experiment_id} --limit {max(1, len(proposals_payload.get('proposals', [])))}",
            "reason": "Convert the optimize result into measured implementation lanes for the next code change.",
        }
    )
    commands.append(
        {
            "step": "status",
            "command": (
                f"awb status --eval-id {diagnosis.get('eval_id')} --subset {preferred_subset} "
                f"--benchmark-signature {diagnosis.get('benchmark_signature')}"
            ),
            "reason": "Refresh the stream after applying the chosen patch plan or benchmark change.",
        }
    )
    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in commands:
        command = str(item.get("command") or "").strip()
        if not command or command in seen:
            continue
        seen.add(command)
        deduped.append(item)
    return deduped


def run_bounded_optimization(
    project_root: Path,
    *,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    baseline_id: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    case_limit: int | None = None,
    surfaces: list[str] | None = None,
    budget: int = 6,
    proposal_limit: int = 3,
    matrix_agent_ids: list[str] | None = None,
    temperatures: list[float] | None = None,
    max_tokens: list[int] | None = None,
) -> dict[str, Any]:
    if int(budget) < 1:
        raise ValueError("Optimize budget must be at least 1 search experiment.")
    budget = int(budget)
    proposal_limit = max(1, int(proposal_limit))
    control_record, source_runs_created = _resolve_control_experiment(
        project_root,
        experiment_id=experiment_id,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        case_ids=case_ids,
        tags=tags,
        match=match,
        case_limit=case_limit,
    )
    optimize_id = f"optimize-{control_record.experiment_id}-{utc_timestamp_slug()}"
    diagnosis = diagnose_experiment(
        project_root,
        experiment_id=control_record.experiment_id,
        baseline_id=baseline_id,
    )
    preferred_subset = resolve_preferred_subset(project_root, control_record.eval_id, control_record.subset)
    revalidation_budget = _reserved_revalidation_budget(budget, control_record.subset, preferred_subset)
    matrix_config = _matrix_stage_config(
        control_agent_id=control_record.agent_id,
        matrix_agent_ids=matrix_agent_ids,
        temperatures=temperatures,
        max_tokens=max_tokens,
    )
    available_search_budget = max(0, budget - revalidation_budget)
    warnings: list[str] = []
    matrix_payload: dict[str, Any] | None = None
    temp_spec_paths: list[Path] = []
    try:
        matrix_experiment_count = _matrix_experiment_count(matrix_config)
        remaining_search_budget = available_search_budget
        if _matrix_stage_requested(matrix_agent_ids, temperatures, max_tokens):
            if not matrix_config.get("agent_ids"):
                warnings.append("Matrix/model axis was requested without any usable agent or runtime values; skipping.")
            elif matrix_experiment_count > remaining_search_budget:
                warnings.append(
                    f"Skipped model/runtime matrix stage because it would spend {matrix_experiment_count} experiments "
                    f"with only {remaining_search_budget} search slots available."
                )
            else:
                matrix_payload = run_experiment_matrix(
                    project_root,
                    agent_ids=list(matrix_config.get("agent_ids") or []),
                    eval_id=control_record.eval_id,
                    subset=control_record.subset,
                    temperatures=list(matrix_config.get("temperatures") or []) or None,
                    max_tokens=list(matrix_config.get("max_tokens") or []) or None,
                    case_ids=case_ids,
                    tags=tags,
                    match=match,
                    limit=case_limit,
                    keep_specs=True,
                )
                remaining_search_budget -= int((matrix_payload or {}).get("experiment_count", 0) or 0)
                temp_spec_paths.extend(_temporary_spec_paths(project_root, matrix_payload))

        allocation = _search_budget_allocation(remaining_search_budget)

        ablation_payload: dict[str, Any] | None = None
        if allocation["ablation_limit"] > 0:
            try:
                ablation_payload = run_surface_ablations(
                    project_root,
                    experiment_id=control_record.experiment_id,
                    surfaces=surfaces or ["prompts", "tools", "skills", "plugins", "mcps"],
                    surface_limit=allocation["ablation_limit"],
                    keep_specs=True,
                )
                temp_spec_paths.extend(_temporary_spec_paths(project_root, ablation_payload))
            except ValueError as exc:
                warnings.append(str(exc))

        shortlisted_factors = (
            _shortlist_factor_candidates(ablation_payload, allocation["factorial_factor_target"])
            if ablation_payload and allocation["factorial_factor_target"] > 0
            else []
        )
        factorial_payload: dict[str, Any] | None = None
        if len(shortlisted_factors) >= 2:
            try:
                factorial_payload = run_factorial_experiments(
                    project_root,
                    experiment_id=control_record.experiment_id,
                    factors=shortlisted_factors,
                    keep_specs=True,
                )
                temp_spec_paths.extend(_temporary_spec_paths(project_root, factorial_payload))
            except ValueError as exc:
                warnings.append(str(exc))
        elif allocation["factorial_factor_target"] > 0:
            warnings.append("Not enough ablation-backed factors were available to run the bounded factorial stage.")

        search_candidates = _load_search_candidates(
            project_root,
            control_record=control_record,
            ablation_payload=ablation_payload,
            factorial_payload=factorial_payload,
            matrix_payload=matrix_payload,
        )
        control_candidate = next(
            item for item in search_candidates if item["experiment_id"] == control_record.experiment_id
        )

        final_control_record, finalists, revalidation_payload, revalidation_spend, revalidation_warnings = (
            _revalidation_stage(
                project_root,
                control_record=control_record,
                search_candidates=search_candidates,
                preferred_subset=preferred_subset,
                revalidation_budget=revalidation_budget,
                case_ids=case_ids,
                tags=tags,
                match=match,
                case_limit=case_limit,
            )
        )
        warnings.extend(revalidation_warnings)
        finalist_assessments = _assess_finalists(
            project_root,
            final_control_record=final_control_record,
            finalists=finalists,
            explicit_baseline_id=baseline_id,
        )

        recommendation_source = (
            finalist_assessments[0]
            if finalist_assessments
            else max(
                search_candidates,
                key=lambda item: _summary_rank(item.get("summary") or {}),
            )
        )
        recommendation_reason = _recommendation_reason(
            control_summary=dict(control_candidate.get("summary") or {}),
            recommended_candidate=recommendation_source,
        )

        proposals_payload = build_mutation_proposal_payload(project_root, diagnosis, limit=proposal_limit)
        proposals_payload["optimize_context"] = {
            "optimize_id": optimize_id,
            "recommended_candidate_experiment_id": str(
                (recommendation_source.get("summary") or {}).get("experiment_id")
                or recommendation_source.get("experiment_id")
                or ""
            ),
            "recommended_candidate_stage": str(recommendation_source.get("stage") or ""),
            "recommended_surface_changes": list(recommendation_source.get("surface_changes") or []),
            "final_control_experiment_id": final_control_record.experiment_id,
            "preferred_subset": preferred_subset,
        }
        proposals_payload = write_mutation_proposal_payload(project_root, proposals_payload)
        patch_handoff = _patch_handoff(
            project_root,
            proposals_payload=proposals_payload,
            recommended_candidate=recommendation_source,
        )

        ablation_spend = int((ablation_payload or {}).get("ablation_count", 0) or 0)
        factorial_spend = max(0, int((factorial_payload or {}).get("combination_count", 0) or 0) - 1)
        matrix_spend = int((matrix_payload or {}).get("experiment_count", 0) or 0)
        search_experiment_count = matrix_spend + ablation_spend + factorial_spend + revalidation_spend

        payload = {
            "optimize_id": optimize_id,
            "created_at": created_at_utc(),
            "project_root": str(project_root),
            "control_experiment_id": control_record.experiment_id,
            "final_control_experiment_id": final_control_record.experiment_id,
            "agent_id": control_record.agent_id,
            "eval_id": control_record.eval_id,
            "subset": control_record.subset,
            "preferred_subset": preferred_subset,
            "benchmark_signature": control_record.benchmark_signature,
            "selection_fingerprint": control_record.selection_fingerprint,
            "selected_case_count": len(control_record.selected_case_ids or []),
            "selected_case_ids": list(control_record.selected_case_ids or []),
            "source_runs_created": source_runs_created,
            "search_budget": budget,
            "search_experiment_count": search_experiment_count,
            "unused_budget": max(0, budget - search_experiment_count),
            "allocation": {
                "reserved_revalidation_budget": revalidation_budget,
                "matrix_stage_requested": _matrix_stage_requested(matrix_agent_ids, temperatures, max_tokens),
                "matrix_experiment_budget": matrix_experiment_count,
                "search_stage_budget": available_search_budget,
                "search_stage_allocation": allocation,
            },
            "warnings": warnings,
            "diagnosis": {
                "recommended_action": diagnosis.get("recommended_action"),
                "summary": diagnosis.get("summary"),
                "baseline_id": diagnosis.get("baseline_id"),
                "focus_cases": diagnosis.get("focus_cases"),
                "failure_clusters": diagnosis.get("failure_clusters"),
                "surface_recommendations": diagnosis.get("surface_recommendations"),
            },
            "proposals": {
                "proposal_count": proposals_payload.get("proposal_count", 0),
                "proposals": (proposals_payload.get("proposals") or [])[:proposal_limit],
            },
            "patch_handoff": patch_handoff,
            "matrix": {
                "requested": _matrix_stage_requested(matrix_agent_ids, temperatures, max_tokens),
                "agent_ids": list(matrix_config.get("agent_ids") or []),
                "temperatures": list(matrix_config.get("temperatures") or []),
                "max_tokens": list(matrix_config.get("max_tokens") or []),
                "experiment_count": int((matrix_payload or {}).get("experiment_count", 0) or 0),
                "experiments": (matrix_payload or {}).get("experiments") or [],
                "pareto_frontier": (matrix_payload or {}).get("pareto_frontier") or [],
                "best_by_score": (matrix_payload or {}).get("best_by_score"),
                "cheapest": (matrix_payload or {}).get("cheapest"),
                "fastest": (matrix_payload or {}).get("fastest"),
            },
            "ablation": {
                "ablation_count": int((ablation_payload or {}).get("ablation_count", 0) or 0),
                "surface_filters": list((ablation_payload or {}).get("surface_filters") or []),
                "results": (ablation_payload or {}).get("results") or [],
                "shortlisted_factors": shortlisted_factors,
            },
            "factorial": {
                "selected_factors": list((factorial_payload or {}).get("selected_factors") or []),
                "combination_count": int((factorial_payload or {}).get("combination_count", 0) or 0),
                "results": (factorial_payload or {}).get("results") or [],
                "factor_effects": (factorial_payload or {}).get("factor_effects") or [],
                "pair_interactions": (factorial_payload or {}).get("pair_interactions") or [],
                "surface_recommendations": (factorial_payload or {}).get("surface_recommendations") or [],
                "pareto_frontier": (factorial_payload or {}).get("pareto_frontier") or [],
            },
            "revalidation": revalidation_payload,
            "search_candidates": search_candidates,
            "finalists": finalist_assessments,
            "pareto_frontier": finalist_assessments[:5] if finalist_assessments else search_candidates[:5],
            "recommended_candidate": recommendation_source,
            "recommendation_reason": recommendation_reason,
            "next_commands": _next_commands(
                control_experiment_id=control_record.experiment_id,
                final_control_experiment_id=final_control_record.experiment_id,
                preferred_subset=preferred_subset,
                recommended_candidate=recommendation_source,
                diagnosis=diagnosis,
                proposals_payload=proposals_payload,
                patch_handoff=patch_handoff,
            ),
        }
        root = optimizations_dir(project_root)
        write_json(root / f"{optimize_id}.json", payload)
        write_json(root / "latest.json", payload)
        write_report(root / f"{optimize_id}.md", render_optimize_report(payload))
        write_report(root / "latest.md", render_optimize_report(payload))
        return payload
    finally:
        _cleanup_temp_specs(temp_spec_paths)
