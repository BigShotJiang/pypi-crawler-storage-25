from __future__ import annotations

from typing import Any


def aggregate_chain_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    chain_aggs: list[dict[str, Any]] = []
    step_scores_by_agent: dict[str, list[float]] = {}
    degrading_counts: dict[str, int] = {}
    total_executed = 0
    total_skipped = 0
    for row in rows:
        artifact = row.get("artifact", {})
        meta = artifact.get("metadata", {})
        chain_agg = meta.get("chain_aggregate") or {}
        if chain_agg:
            chain_aggs.append(chain_agg)
            total_executed += int(chain_agg.get("executed_steps", 0) or 0)
            total_skipped += int(chain_agg.get("skipped_steps", 0) or 0)
            for item in chain_agg.get("degrading_steps", []) or []:
                label = str(item)
                degrading_counts[label] = degrading_counts.get(label, 0) + 1
        for score in meta.get("step_scores", []) or []:
            agent_id = str(score.get("agent_id") or "unknown")
            step_scores_by_agent.setdefault(agent_id, []).append(float(score.get("score", 0.0)))
    case_count = len(chain_aggs)
    return {
        "case_count": case_count,
        "average_step_pass_rate": (
            round(sum(float(item.get("step_pass_rate", 0.0)) for item in chain_aggs) / case_count, 3)
            if case_count
            else 0.0
        ),
        "average_latency_ms": (
            round(sum(int(item.get("total_chain_latency_ms", 0) or 0) for item in chain_aggs) / case_count, 1)
            if case_count
            else 0.0
        ),
        "average_step_scores": {
            agent_id: round(sum(scores) / len(scores), 3)
            for agent_id, scores in sorted(step_scores_by_agent.items())
            if scores
        },
        "degrading_step_frequency": {
            agent_id: round(count / case_count, 3)
            for agent_id, count in sorted(degrading_counts.items())
            if case_count
        },
        "total_executed_steps": total_executed,
        "total_skipped_steps": total_skipped,
    }


def aggregate_workflow_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    workflow_aggs: list[dict[str, Any]] = []
    node_scores: dict[str, list[float]] = {}
    path_counts: dict[str, int] = {}
    terminal_counts: dict[str, int] = {}
    route_counts: dict[str, int] = {}
    duplicate_nodes: dict[str, int] = {}
    shared_context_keys: set[str] = set()
    unmatched_route_count = 0
    fan_out_count = 0
    join_count = 0
    dead_end_count = 0
    loop_case_count = 0
    for row in rows:
        artifact = row.get("artifact", {})
        meta = artifact.get("metadata", {})
        workflow_agg = meta.get("workflow_aggregate") or {}
        if not workflow_agg:
            continue
        workflow_aggs.append(workflow_agg)
        path_signature = str(workflow_agg.get("path_signature") or "").strip()
        if path_signature:
            path_counts[path_signature] = path_counts.get(path_signature, 0) + 1
        terminal_node = str(workflow_agg.get("terminal_node") or "").strip()
        if terminal_node:
            terminal_counts[terminal_node] = terminal_counts.get(terminal_node, 0) + 1
        for route in workflow_agg.get("route_decisions") or []:
            if not isinstance(route, dict):
                continue
            label = str(route.get("label") or f"{route.get('from', '?')}->{route.get('to', '?')}")
            route_counts[label] = route_counts.get(label, 0) + 1
        unmatched_route_count += len(workflow_agg.get("unmatched_routes") or [])
        fan_out_count += int(workflow_agg.get("fan_out_count", 0) or 0)
        join_count += int(workflow_agg.get("join_count", 0) or 0)
        dead_end_count += int(workflow_agg.get("dead_end_count", 0) or 0)
        if bool(workflow_agg.get("loop_detected")):
            loop_case_count += 1
        for node_id in workflow_agg.get("duplicate_node_visits") or []:
            label = str(node_id)
            duplicate_nodes[label] = duplicate_nodes.get(label, 0) + 1
        for key in workflow_agg.get("shared_context_keys") or []:
            label = str(key).strip()
            if label:
                shared_context_keys.add(label)
        for score in meta.get("step_scores", []) or []:
            node_id = str(score.get("node_id") or score.get("agent_id") or "unknown")
            node_scores.setdefault(node_id, []).append(float(score.get("score", 0.0)))
    case_count = len(workflow_aggs)
    return {
        "case_count": case_count,
        "average_step_pass_rate": (
            round(sum(float(item.get("step_pass_rate", 0.0)) for item in workflow_aggs) / case_count, 3)
            if case_count
            else 0.0
        ),
        "average_latency_ms": (
            round(sum(int(item.get("total_workflow_latency_ms", 0) or 0) for item in workflow_aggs) / case_count, 1)
            if case_count
            else 0.0
        ),
        "average_node_scores": {
            node_id: round(sum(scores) / len(scores), 3)
            for node_id, scores in sorted(node_scores.items())
            if scores
        },
        "path_counts": path_counts,
        "terminal_node_counts": terminal_counts,
        "route_counts": route_counts,
        "unmatched_route_count": unmatched_route_count,
        "fan_out_count": fan_out_count,
        "join_count": join_count,
        "dead_end_count": dead_end_count,
        "loop_case_count": loop_case_count,
        "duplicate_node_counts": duplicate_nodes,
        "shared_context_keys": sorted(shared_context_keys),
    }
