from __future__ import annotations

from pathlib import Path
from typing import Any


def runtime_event(kind: str, name: str, **data: Any) -> dict[str, Any]:
    event: dict[str, Any] = {"kind": kind, "name": name}
    for key, value in data.items():
        if isinstance(value, (bool, float, int, str)):
            event[key] = value
    return event


def read_prompt_file(project_root: Path, relative_path: str | None) -> str:
    if not relative_path:
        return ""
    path = project_root / relative_path
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8").strip()
