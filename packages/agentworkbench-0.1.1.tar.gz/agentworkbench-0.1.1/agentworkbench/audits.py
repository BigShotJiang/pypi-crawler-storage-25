from __future__ import annotations

from typing import Any

from agentworkbench.evidence import normalize_evidence_records
from agentworkbench.surface_usage import USAGE_EVENT_KINDS, referenced_mcp_names, referenced_tool_names

_OUTCOME_KEYS = ("attempted", "success", "empty", "error", "skipped")
_EVIDENCE_KEYS = (
    "evidence_records",
    "evidence_hits",
    "selected_evidence",
    "supported_evidence",
    "cases_with_selected_evidence",
    "cases_with_supported_evidence",
    "cases_with_unsupported_selected_evidence",
)

def _blank_audit() -> dict[str, int]:
    return {key: 0 for key in (*_OUTCOME_KEYS, *_EVIDENCE_KEYS)}


def _increment(audits: dict[str, dict[str, int]], name: str, outcome: str) -> None:
    if not name:
        return
    normalized = outcome if outcome in _OUTCOME_KEYS else "success"
    bucket = audits.setdefault(name, _blank_audit())
    bucket["attempted"] += 1
    if normalized != "attempted":
        bucket[normalized] += 1


def _increment_evidence(
    audits: dict[str, dict[str, int]],
    name: str,
    *,
    hit_count: int,
    selected_count: int,
    used_count: int,
) -> None:
    if not name:
        return
    bucket = audits.setdefault(name, _blank_audit())
    bucket["evidence_records"] += 1
    bucket["evidence_hits"] += max(0, int(hit_count))
    bucket["selected_evidence"] += max(0, int(selected_count))
    bucket["supported_evidence"] += max(0, int(used_count))


def _event_status(event: dict[str, Any]) -> str:
    explicit = str(event.get("status") or "").strip().lower()
    if explicit in _OUTCOME_KEYS:
        return explicit
    name = str(event.get("name") or "").strip().lower()
    if name == "skipped":
        return "skipped"
    if name == "error" or event.get("error") not in (None, "", False):
        return "error"
    if "loaded" in event:
        return "success" if bool(event.get("loaded")) else "empty"
    if "selected" in event:
        return "success" if bool(event.get("selected")) else "empty"
    if "hits" in event:
        return "success" if int(event.get("hits") or 0) > 0 else "empty"
    return "success"


def _call_status(call: dict[str, Any]) -> str:
    explicit = str(call.get("status") or "").strip().lower()
    if explicit in _OUTCOME_KEYS:
        return explicit
    if call.get("error") not in (None, "", False):
        return "error"
    if "loaded" in call:
        return "success" if bool(call.get("loaded")) else "empty"
    if "selected" in call:
        return "success" if bool(call.get("selected")) else "empty"
    if "hits" in call:
        return "success" if int(call.get("hits") or 0) > 0 else "empty"
    return "success"


def run_surface_audits(artifact: dict[str, Any]) -> dict[str, dict[str, dict[str, int]]]:
    tool_audits: dict[str, dict[str, int]] = {}
    mcp_audits: dict[str, dict[str, int]] = {}
    observed_tools: set[str] = set()
    for item in artifact.get("events") or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "")
        if kind not in USAGE_EVENT_KINDS:
            continue
        tool_name = str(item.get("tool") or item.get("name") or "").strip()
        if not tool_name:
            continue
        observed_tools.add(tool_name)
        outcome = _event_status(item)
        _increment(tool_audits, tool_name, outcome)
        mcp_name = str(item.get("mcp") or "").strip()
        if mcp_name:
            _increment(mcp_audits, mcp_name, outcome)
    for item in artifact.get("tool_calls") or []:
        if not isinstance(item, dict):
            continue
        tool_name = str(item.get("name") or item.get("tool") or item.get("id") or "").strip()
        if not tool_name or tool_name in observed_tools:
            continue
        outcome = _call_status(item)
        _increment(tool_audits, tool_name, outcome)
        mcp_name = str(item.get("mcp") or "").strip()
        if mcp_name:
            _increment(mcp_audits, mcp_name, outcome)
    tool_selected_cases: set[str] = set()
    tool_supported_cases: set[str] = set()
    mcp_selected_cases: set[str] = set()
    mcp_supported_cases: set[str] = set()
    evidence_tool_counts: dict[str, int] = {}
    evidence_mcp_counts: dict[str, int] = {}
    for record in normalize_evidence_records(artifact):
        status = str(record.get("status") or "success")
        selected_count = int(record.get("selected_count", 0) or 0)
        used_count = int(record.get("used_count", 0) or 0)
        hit_count = int(record.get("hit_count", 0) or 0)
        tool_name = str(record.get("name") or "").strip()
        if tool_name:
            evidence_tool_counts[tool_name] = evidence_tool_counts.get(tool_name, 0) + 1
            while int((tool_audits.get(tool_name) or {}).get("attempted", 0)) < evidence_tool_counts[tool_name]:
                _increment(tool_audits, tool_name, status)
            _increment_evidence(
                tool_audits,
                tool_name,
                hit_count=hit_count,
                selected_count=selected_count,
                used_count=used_count,
            )
            if selected_count > 0:
                tool_selected_cases.add(tool_name)
            if used_count > 0:
                tool_supported_cases.add(tool_name)
        mcp_name = str(record.get("mcp") or "").strip()
        if mcp_name:
            evidence_mcp_counts[mcp_name] = evidence_mcp_counts.get(mcp_name, 0) + 1
            while int((mcp_audits.get(mcp_name) or {}).get("attempted", 0)) < evidence_mcp_counts[mcp_name]:
                _increment(mcp_audits, mcp_name, status)
            _increment_evidence(
                mcp_audits,
                mcp_name,
                hit_count=hit_count,
                selected_count=selected_count,
                used_count=used_count,
            )
            if selected_count > 0:
                mcp_selected_cases.add(mcp_name)
            if used_count > 0:
                mcp_supported_cases.add(mcp_name)
    for name in tool_selected_cases:
        bucket = tool_audits.setdefault(name, _blank_audit())
        bucket["cases_with_selected_evidence"] += 1
        if name in tool_supported_cases:
            bucket["cases_with_supported_evidence"] += 1
        else:
            bucket["cases_with_unsupported_selected_evidence"] += 1
    for name in mcp_selected_cases:
        bucket = mcp_audits.setdefault(name, _blank_audit())
        bucket["cases_with_selected_evidence"] += 1
        if name in mcp_supported_cases:
            bucket["cases_with_supported_evidence"] += 1
        else:
            bucket["cases_with_unsupported_selected_evidence"] += 1
    return {"tools": tool_audits, "mcps": mcp_audits}


def run_surface_contract_audits(
    artifact: dict[str, Any],
    spec_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    enabled_tools = {str(item) for item in (spec_snapshot or {}).get("tool_names", []) or [] if str(item).strip()}
    enabled_mcps = {str(item) for item in (spec_snapshot or {}).get("mcp_names", []) or [] if str(item).strip()}
    referenced_tools = referenced_tool_names(artifact)
    referenced_mcps = referenced_mcp_names(artifact)
    listed_mcps = {str(item) for item in artifact.get("mcp_servers_used") or [] if str(item).strip()}

    tool_used_not_enabled = sorted(referenced_tools - enabled_tools) if spec_snapshot is not None else []
    mcp_used_not_enabled = sorted(referenced_mcps - enabled_mcps) if spec_snapshot is not None else []
    mcp_referenced_not_listed = sorted(referenced_mcps - listed_mcps)
    mcp_listed_not_referenced = sorted(listed_mcps - referenced_mcps)

    violations: list[str] = []
    violations.extend(f"tool:{name}:used_not_enabled" for name in tool_used_not_enabled)
    violations.extend(f"mcp:{name}:used_not_enabled" for name in mcp_used_not_enabled)
    violations.extend(f"mcp:{name}:referenced_not_listed" for name in mcp_referenced_not_listed)
    violations.extend(f"mcp:{name}:listed_not_referenced" for name in mcp_listed_not_referenced)
    violations = sorted(dict.fromkeys(violations))

    return {
        "tool_used_not_enabled": tool_used_not_enabled,
        "mcp_used_not_enabled": mcp_used_not_enabled,
        "mcp_referenced_not_listed": mcp_referenced_not_listed,
        "mcp_listed_not_referenced": mcp_listed_not_referenced,
        "violations": violations,
        "violation_counts": {name: 1 for name in violations},
        "violation_count": len(violations),
    }


def _finalize_audits(audits: dict[str, dict[str, int]]) -> dict[str, dict[str, Any]]:
    finalized: dict[str, dict[str, Any]] = {}
    for name, counts in sorted(audits.items()):
        attempted = int(counts.get("attempted", 0))
        selected_evidence = int(counts.get("selected_evidence", 0))
        supported_evidence = int(counts.get("supported_evidence", 0))
        finalized[name] = {
            **{key: int(counts.get(key, 0)) for key in (*_OUTCOME_KEYS, *_EVIDENCE_KEYS)},
            "success_rate": round(int(counts.get("success", 0)) / attempted, 3) if attempted else None,
            "empty_rate": round(int(counts.get("empty", 0)) / attempted, 3) if attempted else None,
            "error_rate": round(int(counts.get("error", 0)) / attempted, 3) if attempted else None,
            "selected_evidence_use_rate": round(supported_evidence / selected_evidence, 3) if selected_evidence else None,
            "avg_selected_evidence_per_attempt": round(selected_evidence / attempted, 3) if attempted else None,
            "avg_supported_evidence_per_attempt": round(supported_evidence / attempted, 3) if attempted else None,
        }
    return finalized


def aggregate_surface_audits(rows: list[dict[str, Any]]) -> dict[str, Any]:
    tool_totals: dict[str, dict[str, int]] = {}
    mcp_totals: dict[str, dict[str, int]] = {}
    for row in rows:
        run_audits = run_surface_audits(row.get("artifact") or {})
        for name, counts in run_audits["tools"].items():
            bucket = tool_totals.setdefault(name, _blank_audit())
            for key in (*_OUTCOME_KEYS, *_EVIDENCE_KEYS):
                bucket[key] += int(counts.get(key, 0))
        for name, counts in run_audits["mcps"].items():
            bucket = mcp_totals.setdefault(name, _blank_audit())
            for key in (*_OUTCOME_KEYS, *_EVIDENCE_KEYS):
                bucket[key] += int(counts.get(key, 0))
    tool_audits = _finalize_audits(tool_totals)
    mcp_audits = _finalize_audits(mcp_totals)
    return {
        "tool_audits": tool_audits,
        "mcp_audits": mcp_audits,
        "tool_outcome_totals": {
            key: sum(int(item.get(key, 0)) for item in tool_audits.values()) for key in _OUTCOME_KEYS
        },
        "mcp_outcome_totals": {
            key: sum(int(item.get(key, 0)) for item in mcp_audits.values()) for key in _OUTCOME_KEYS
        },
        "tool_evidence_totals": {
            key: sum(int(item.get(key, 0)) for item in tool_audits.values()) for key in _EVIDENCE_KEYS
        },
        "mcp_evidence_totals": {
            key: sum(int(item.get(key, 0)) for item in mcp_audits.values()) for key in _EVIDENCE_KEYS
        },
        "tools_with_errors": sorted(name for name, counts in tool_audits.items() if int(counts.get("error", 0)) > 0),
        "mcps_with_errors": sorted(name for name, counts in mcp_audits.items() if int(counts.get("error", 0)) > 0),
        "tools_with_empty_results": sorted(name for name, counts in tool_audits.items() if int(counts.get("empty", 0)) > 0),
        "mcps_with_empty_results": sorted(name for name, counts in mcp_audits.items() if int(counts.get("empty", 0)) > 0),
        "tools_with_unused_selected_evidence": sorted(
            name for name, counts in tool_audits.items() if int(counts.get("cases_with_unsupported_selected_evidence", 0)) > 0
        ),
        "mcps_with_unused_selected_evidence": sorted(
            name for name, counts in mcp_audits.items() if int(counts.get("cases_with_unsupported_selected_evidence", 0)) > 0
        ),
        "tools_with_low_evidence_use": sorted(
            name
            for name, counts in tool_audits.items()
            if int(counts.get("selected_evidence", 0)) > 0 and float(counts.get("selected_evidence_use_rate") or 0.0) < 0.5
        ),
        "mcps_with_low_evidence_use": sorted(
            name
            for name, counts in mcp_audits.items()
            if int(counts.get("selected_evidence", 0)) > 0 and float(counts.get("selected_evidence_use_rate") or 0.0) < 0.5
        ),
    }


def aggregate_surface_contract_audits(
    rows: list[dict[str, Any]],
    spec_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    tool_used_not_enabled: set[str] = set()
    mcp_used_not_enabled: set[str] = set()
    mcp_referenced_not_listed: set[str] = set()
    mcp_listed_not_referenced: set[str] = set()
    violation_counts: dict[str, int] = {}
    for row in rows:
        audit = run_surface_contract_audits(row.get("artifact") or {}, spec_snapshot)
        tool_used_not_enabled.update(str(item) for item in audit.get("tool_used_not_enabled", []) or [])
        mcp_used_not_enabled.update(str(item) for item in audit.get("mcp_used_not_enabled", []) or [])
        mcp_referenced_not_listed.update(str(item) for item in audit.get("mcp_referenced_not_listed", []) or [])
        mcp_listed_not_referenced.update(str(item) for item in audit.get("mcp_listed_not_referenced", []) or [])
        for name in audit.get("violations", []) or []:
            key = str(name)
            violation_counts[key] = violation_counts.get(key, 0) + 1
    violations = sorted(violation_counts)
    return {
        "tool_used_not_enabled": sorted(tool_used_not_enabled),
        "mcp_used_not_enabled": sorted(mcp_used_not_enabled),
        "mcp_referenced_not_listed": sorted(mcp_referenced_not_listed),
        "mcp_listed_not_referenced": sorted(mcp_listed_not_referenced),
        "surface_contract_violations": violations,
        "surface_contract_violation_case_counts": dict(sorted(violation_counts.items())),
        "surface_contract_violation_count": sum(violation_counts.values()),
        "surface_contract_unique_violation_count": len(violations),
    }


def audit_deltas(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    deltas: dict[str, dict[str, Any]] = {}
    for name in sorted(set(baseline) | set(candidate)):
        before = baseline.get(name) or {}
        after = candidate.get(name) or {}
        deltas[name] = {
            "attempted_delta": int(after.get("attempted", 0)) - int(before.get("attempted", 0)),
            "success_delta": int(after.get("success", 0)) - int(before.get("success", 0)),
            "empty_delta": int(after.get("empty", 0)) - int(before.get("empty", 0)),
            "error_delta": int(after.get("error", 0)) - int(before.get("error", 0)),
            "skipped_delta": int(after.get("skipped", 0)) - int(before.get("skipped", 0)),
            "evidence_records_delta": int(after.get("evidence_records", 0)) - int(before.get("evidence_records", 0)),
            "evidence_hits_delta": int(after.get("evidence_hits", 0)) - int(before.get("evidence_hits", 0)),
            "selected_evidence_delta": int(after.get("selected_evidence", 0)) - int(before.get("selected_evidence", 0)),
            "supported_evidence_delta": int(after.get("supported_evidence", 0)) - int(before.get("supported_evidence", 0)),
            "cases_with_selected_evidence_delta": int(after.get("cases_with_selected_evidence", 0)) - int(before.get("cases_with_selected_evidence", 0)),
            "cases_with_supported_evidence_delta": int(after.get("cases_with_supported_evidence", 0)) - int(before.get("cases_with_supported_evidence", 0)),
            "cases_with_unsupported_selected_evidence_delta": int(after.get("cases_with_unsupported_selected_evidence", 0))
            - int(before.get("cases_with_unsupported_selected_evidence", 0)),
            "success_rate_delta": round(float(after.get("success_rate") or 0.0) - float(before.get("success_rate") or 0.0), 3),
            "empty_rate_delta": round(float(after.get("empty_rate") or 0.0) - float(before.get("empty_rate") or 0.0), 3),
            "error_rate_delta": round(float(after.get("error_rate") or 0.0) - float(before.get("error_rate") or 0.0), 3),
            "selected_evidence_use_rate_delta": round(
                float(after.get("selected_evidence_use_rate") or 0.0) - float(before.get("selected_evidence_use_rate") or 0.0),
                3,
            ),
            "avg_selected_evidence_per_attempt_delta": round(
                float(after.get("avg_selected_evidence_per_attempt") or 0.0) - float(before.get("avg_selected_evidence_per_attempt") or 0.0),
                3,
            ),
            "avg_supported_evidence_per_attempt_delta": round(
                float(after.get("avg_supported_evidence_per_attempt") or 0.0) - float(before.get("avg_supported_evidence_per_attempt") or 0.0),
                3,
            ),
        }
    return deltas
