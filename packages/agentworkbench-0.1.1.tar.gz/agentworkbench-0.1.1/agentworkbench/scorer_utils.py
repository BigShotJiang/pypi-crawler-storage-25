"""Scorer utilities — thin re-export shim.

All scoring logic now lives in ``agentworkbench.scorers``. This module
re-exports the public surface so that existing callers (tests, evals,
experiment analysis) continue to work without changes.
"""

from __future__ import annotations

# Re-export every public scoring symbol.  The canonical implementations
# live inside ``agentworkbench/scorers/`` — edit there, not here.
from agentworkbench.scorers.grounding import (  # noqa: F401
    grounding_provenance,
    grounding_summary,
    score_grounding_support,
)
from agentworkbench.scorers.json_schema import score_json_schema_adherence  # noqa: F401
from agentworkbench.scorers.output_quality import score_output_quality  # noqa: F401
from agentworkbench.scorers.presets import default_score_bundle  # noqa: F401
from agentworkbench.scorers.process_alignment import score_process_alignment  # noqa: F401
from agentworkbench.scorers.safety import check_forbidden_terms  # noqa: F401
from agentworkbench.scorers.workflow import (  # noqa: F401
    contains_sequence,
    surface_names,
    workflow_trace,
)

__all__ = [
    "check_forbidden_terms",
    "contains_sequence",
    "default_score_bundle",
    "grounding_provenance",
    "grounding_summary",
    "score_grounding_support",
    "score_json_schema_adherence",
    "score_output_quality",
    "score_process_alignment",
    "surface_names",
    "workflow_trace",
]
