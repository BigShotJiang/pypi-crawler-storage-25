from __future__ import annotations

import hashlib
import importlib.util
import json
import warnings
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from agentworkbench.benchmark_quality import compute_benchmark_quality
from agentworkbench.briefs import brief_path
from agentworkbench.case_selection import select_eval_cases
from agentworkbench.config import control_dir, dump_model, load_model
from agentworkbench.human_review import build_review_queue, eval_human_checkpoints
from agentworkbench.human_review_store import pending_review_items, resolve_review_queue
from agentworkbench.learned_scorer import LearnedScorer, load_learned_scorer
from agentworkbench.models import BehaviorBrief, EvalCase, EvalSuiteSpec, RunArtifact
from agentworkbench.reports import render_eval_suite_report, write_report
from agentworkbench.utils import created_at_utc, read_jsonl, read_yaml, write_json, write_jsonl, write_text, write_yaml

_EXPANSION_ONLY_TAGS = {"expanded", "brief-derived", "failure-driven", "regression"}


def _load_extension_scorers() -> list[Callable[[dict[str, Any], dict[str, Any]], list[dict[str, Any]]]]:
    """Discover and return scorers from ScorerPlugin extensions."""
    try:
        from agentworkbench.extensions.base import ScorerPlugin
        from agentworkbench.extensions.loader import get_extension, list_extensions

        scorers: list[Callable[[dict[str, Any], dict[str, Any]], list[dict[str, Any]]]] = []
        for ext in list_extensions("scorers"):
            if ext.get("status") == "error":
                warnings.warn(
                    f"Scorer extension `{ext.get('name', '?')}` failed to load: {ext.get('error', 'unknown')}",
                    stacklevel=2,
                )
                continue
            if ext.get("status") != "loaded":
                continue
            plugin = get_extension("scorers", ext["name"])
            if isinstance(plugin, ScorerPlugin):
                scorers.append(plugin.score_cases)
        return scorers
    except ImportError:
        return []
    except Exception as exc:
        warnings.warn(f"Scorer extension discovery failed: {exc}", stacklevel=2)
        return []


def eval_path(project_root: Path, eval_id: str) -> Path:
    return control_dir(project_root) / "evals" / f"{eval_id}.jsonl"


def suite_path(project_root: Path, eval_id: str) -> Path:
    return control_dir(project_root) / "evals" / f"{eval_id}.suite.yaml"


def split_path(project_root: Path, eval_id: str) -> Path:
    return control_dir(project_root) / "evals" / f"{eval_id}.splits.yaml"


def scorer_path(project_root: Path, eval_id: str) -> Path:
    return control_dir(project_root) / "scorers" / f"{eval_id}_default.py"


def eval_review_path(project_root: Path, eval_id: str) -> Path:
    return control_dir(project_root) / "reports" / f"eval-review-{eval_id}.md"


def default_score_weights() -> dict[str, float]:
    return {"output_quality": 0.7, "process_alignment": 0.3}


def preferred_subset(project_root: Path, eval_id: str, current_subset: str) -> str:
    splits_file = split_path(project_root, eval_id)
    if not splits_file.exists():
        return current_subset or "full"
    splits = read_yaml(splits_file) or {}
    full_cases = splits.get("full") or []
    if full_cases:
        return "full"
    return current_subset or next(iter(splits), "full")


def load_eval_suite(project_root: Path, eval_id: str) -> EvalSuiteSpec:
    path = suite_path(project_root, eval_id)
    if not path.exists():
        raise ValueError(
            f"Eval suite `{eval_id}` is missing `{path.name}`. "
            f"Generate and approve the suite before running experiments."
        )
    return load_model(path, EvalSuiteSpec)


def _suite_score_weights(suite: EvalSuiteSpec) -> dict[str, float]:
    return {
        str(name): float(weight) for name, weight in suite.score_weights.items() if float(weight) > 0.0
    } or default_score_weights()


def _normalize_score_weights(score_weights: dict[str, float]) -> dict[str, float]:
    weights = {str(name): float(weight) for name, weight in score_weights.items() if float(weight) > 0.0}
    return weights or default_score_weights()


def _fingerprint(payload: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:12]


def _brief_surface_metadata(brief: BehaviorBrief) -> dict[str, Any]:
    return {
        "preferred_tools": brief.preferred_tools,
        "preferred_skills": brief.preferred_skills,
        "preferred_plugins": brief.preferred_plugins,
        "preferred_mcps": brief.preferred_mcps,
        "prompt_variants": brief.prompt_variants,
        "better_signals": brief.better_signals,
        "worse_signals": brief.worse_signals,
        "score_weights": default_score_weights(),
        "brief_human_review": dict((brief.metadata or {}).get("human_review") or {}),
    }


def _surface_hints(brief: BehaviorBrief) -> dict[str, list[str]]:
    return {
        "preferred_tools": list(brief.preferred_tools),
        "preferred_skills": list(brief.preferred_skills),
        "preferred_plugins": list(brief.preferred_plugins),
        "preferred_mcps": list(brief.preferred_mcps),
        "preferred_prompt_keys": list(brief.prompt_variants),
    }


def _workflow_expectations(workflow: dict[str, Any]) -> dict[str, Any]:
    expectations = {
        "required_tools": [str(item) for item in workflow.get("expected_tools", [])],
        "required_skills": [str(item) for item in workflow.get("expected_skills", [])],
        "required_plugins": [str(item) for item in workflow.get("expected_plugins", [])],
        "required_mcps": [str(item) for item in workflow.get("expected_mcps", [])],
        "required_prompt_keys": [str(item) for item in workflow.get("expected_prompt_keys", [])],
        "required_workflow_steps": [str(item) for item in workflow.get("expected_workflow_steps", [])],
        "workflow_sequence": [str(item) for item in workflow.get("expected_workflow_sequence", [])],
        "forbidden_tools": [str(item) for item in workflow.get("forbidden_tools", [])],
        "forbidden_skills": [str(item) for item in workflow.get("forbidden_skills", [])],
        "forbidden_plugins": [str(item) for item in workflow.get("forbidden_plugins", [])],
        "forbidden_mcps": [str(item) for item in workflow.get("forbidden_mcps", [])],
        "forbidden_prompt_keys": [str(item) for item in workflow.get("forbidden_prompt_keys", [])],
        "forbidden_workflow_steps": [str(item) for item in workflow.get("forbidden_workflow_steps", [])],
        "max_step_count": workflow.get("max_steps"),
    }
    return {key: value for key, value in expectations.items() if value not in (None, [], "")}


def _default_cases(brief: BehaviorBrief, eval_id: str) -> list[EvalCase]:
    cases: list[EvalCase] = []
    surface_hints = _surface_hints(brief)
    surface_metadata = _brief_surface_metadata(brief)
    if brief.examples:
        for index, example in enumerate(brief.examples, start=1):
            cases.append(
                EvalCase(
                    id=f"{eval_id}-example-{index}",
                    input=str(example.get("question") or example.get("input") or f"Example {index}"),
                    expected=str(example.get("expected") or ""),
                    rubric=brief.acceptance_criteria,
                    tags=["example"],
                    metadata={"source": "behavior_brief", "process_hints": surface_hints, **surface_metadata},
                )
            )
    if brief.rough_answer_outlines:
        for index, outline in enumerate(brief.rough_answer_outlines, start=1):
            cases.append(
                EvalCase(
                    id=f"{eval_id}-outline-{index}",
                    input=str(outline.get("question") or outline.get("input") or f"Outline {index}"),
                    expected=str(outline.get("outline") or outline.get("expected") or ""),
                    rubric=brief.acceptance_criteria,
                    tags=["outline"],
                    metadata={"source": "behavior_brief", "process_hints": surface_hints, **surface_metadata},
                )
            )
    if brief.target_questions:
        for index, question in enumerate(brief.target_questions, start=1):
            cases.append(
                EvalCase(
                    id=f"{eval_id}-question-{index}",
                    input=question,
                    expected="",
                    rubric=brief.acceptance_criteria,
                    tags=["target-question"],
                    metadata={"source": "behavior_brief", "process_hints": surface_hints, **surface_metadata},
                )
            )
    if brief.likely_user_commands:
        for index, command in enumerate(brief.likely_user_commands, start=1):
            cases.append(
                EvalCase(
                    id=f"{eval_id}-command-{index}",
                    input=command,
                    expected="",
                    rubric=brief.acceptance_criteria,
                    tags=["command"],
                    metadata={"source": "behavior_brief", "process_hints": surface_hints, **surface_metadata},
                )
            )
    if brief.workflow_scenarios:
        for index, workflow in enumerate(brief.workflow_scenarios, start=1):
            process_expectations = _workflow_expectations(workflow)
            workflow_metadata = {
                "source": "behavior_brief",
                "process_hints": surface_hints,
                "process_expectations": process_expectations,
                **surface_metadata,
                "workflow_name": workflow.get("name") or f"workflow-{index}",
            }

            if workflow.get("turns"):
                workflow_metadata["turns"] = workflow.get("turns")
                workflow_metadata["expected_turns"] = workflow.get("expected_turns", [])
                workflow_metadata["max_turns"] = workflow.get("max_turns", len(workflow.get("turns", [])))

            cases.append(
                EvalCase(
                    id=f"{eval_id}-workflow-{index}",
                    input=str(
                        workflow.get("trigger") or workflow.get("prompt") or workflow.get("name") or f"Workflow {index}"
                    ),
                    expected=str(workflow.get("expected") or ""),
                    rubric=brief.acceptance_criteria,
                    tags=["workflow"] + (["multiturn"] if workflow.get("turns") else []),
                    metadata=workflow_metadata,
                )
            )
    if not cases:
        cases.append(
            EvalCase(
                id=f"{eval_id}-goal-1",
                input=brief.goal,
                expected="",
                rubric=brief.acceptance_criteria,
                tags=["goal"],
                metadata={"source": "behavior_brief", "process_hints": surface_hints, **surface_metadata},
            )
        )
    return cases


def _default_scorer_template() -> str:
    return """from __future__ import annotations

from agentworkbench.scorer_utils import default_score_bundle


def score_cases(run_artifact: dict, case: dict) -> list[dict]:
    return default_score_bundle(run_artifact, case)
"""


def generate_eval_suite(project_root: Path, brief_id: str, eval_id: str) -> dict[str, Path]:
    brief = load_model(brief_path(project_root, brief_id), BehaviorBrief)
    if brief.approval_status != "approved":
        raise ValueError("Behavior brief must be approved before generating evals")
    cases = _default_cases(brief, eval_id)
    eval_file = eval_path(project_root, eval_id)
    suite_file = suite_path(project_root, eval_id)
    split_file = split_path(project_root, eval_id)
    scorer_file = scorer_path(project_root, eval_id)
    suite = EvalSuiteSpec(
        id=eval_id,
        brief_id=brief_id,
        approval_status="draft",
        score_weights=default_score_weights(),
        notes=[
            "Review the generated target-agent cases with the user before approval.",
            "Use rough outlines and workflows to encode what better means for the local target agent before optimization starts.",
        ],
        generated_case_count=len(cases),
        tags=sorted({tag for case in cases for tag in case.tags}),
    )
    write_jsonl(eval_file, [case.model_dump(mode="json") for case in cases])
    smoke = [case.id for case in cases[: min(3, len(cases))]]
    full = [case.id for case in cases]
    write_yaml(split_file, {"smoke": smoke, "full": full})
    dump_model(suite_file, suite)
    if not scorer_file.exists():
        write_text(scorer_file, _default_scorer_template())
    review_report = review_eval_suite(project_root, eval_id)
    return {
        "eval_file": eval_file,
        "suite_file": suite_file,
        "split_file": split_file,
        "scorer_file": scorer_file,
        "review_report": review_report,
    }


def _expansion_fingerprint(case: EvalCase) -> str:
    return str(((case.metadata or {}).get("expansion_source") or {}).get("fingerprint") or "").strip()


def _case_semantic_signature(case: EvalCase) -> str:
    metadata = dict(case.metadata or {})
    metadata.pop("source", None)
    metadata.pop("expansion_source", None)
    metadata.pop("regression_target", None)
    return json.dumps(
        {
            "input": " ".join(case.input.split()),
            "expected": " ".join(case.expected.split()),
            "rubric": [" ".join(str(item).split()) for item in case.rubric],
            "tags": sorted(str(tag) for tag in case.tags if str(tag) not in _EXPANSION_ONLY_TAGS),
            "metadata": metadata,
            "turns": case.turns,
        },
        sort_keys=True,
        default=str,
    )


def _load_expansion_brief(
    project_root: Path,
    eval_id: str,
    suite: EvalSuiteSpec,
    brief_id: str | None,
) -> BehaviorBrief | None:
    resolved_brief_id = str(brief_id or suite.brief_id or "").strip()
    if not resolved_brief_id:
        return None
    path = brief_path(project_root, resolved_brief_id)
    if not path.exists():
        raise ValueError(f"Behavior brief `{resolved_brief_id}` linked to eval `{eval_id}` is missing.")
    brief = load_model(path, BehaviorBrief)
    if brief.approval_status != "approved":
        raise ValueError(f"Behavior brief `{resolved_brief_id}` must be approved before expanding evals.")
    return brief


def _brief_seed_cases(brief: BehaviorBrief) -> list[EvalCase]:
    priority = {
        "workflow": 0,
        "multiturn": 0,
        "outline": 1,
        "target-question": 2,
        "command": 3,
        "example": 4,
        "goal": 5,
    }
    seed_cases = _default_cases(brief, f"{brief.id}-expand")
    return sorted(
        seed_cases,
        key=lambda case: min(priority.get(str(tag), 10) for tag in (case.tags or ["goal"])),
    )


def _brief_expansion_candidates(brief: BehaviorBrief) -> list[EvalCase]:
    candidates: list[EvalCase] = []
    surface_hints = _surface_hints(brief)
    surface_metadata = _brief_surface_metadata(brief)
    for index, edge_case in enumerate(brief.edge_cases, start=1):
        prompt = str(edge_case or "").strip()
        if not prompt:
            continue
        expansion_source = {
            "source": "brief",
            "mode": "edge_case",
            "brief_id": brief.id,
            "source_key": f"edge_case:{index}",
            "fingerprint": _fingerprint(
                {
                    "source": "brief",
                    "mode": "edge_case",
                    "brief_id": brief.id,
                    "input": prompt,
                    "acceptance_criteria": brief.acceptance_criteria,
                }
            ),
        }
        candidates.append(
            EvalCase(
                id="",
                input=prompt,
                expected="",
                rubric=list(brief.acceptance_criteria),
                tags=["edge-case", "expanded", "brief-derived"],
                metadata={
                    "source": "behavior_brief_expand",
                    "process_hints": surface_hints,
                    **surface_metadata,
                    "expansion_source": expansion_source,
                },
            )
        )
    for seed_case in _brief_seed_cases(brief):
        seed_mode = next((str(tag) for tag in seed_case.tags if str(tag) != "multiturn"), "goal")
        expansion_source = {
            "source": "brief",
            "mode": seed_mode.replace("-", "_"),
            "brief_id": brief.id,
            "source_key": seed_case.id,
            "fingerprint": _fingerprint(
                {
                    "source": "brief",
                    "mode": seed_mode,
                    "brief_id": brief.id,
                    "input": seed_case.input,
                    "expected": seed_case.expected,
                    "tags": sorted(seed_case.tags),
                    "turns": seed_case.turns,
                }
            ),
        }
        candidates.append(
            seed_case.model_copy(
                update={
                    "id": "",
                    "tags": sorted({*seed_case.tags, "expanded", "brief-derived"}),
                    "metadata": {
                        **dict(seed_case.metadata or {}),
                        "source": "behavior_brief_expand",
                        "expansion_source": expansion_source,
                    },
                }
            )
        )
    return candidates


def _clusters_for_case(diagnosis: dict[str, Any], case_id: str) -> list[str]:
    cluster_ids: list[str] = []
    for cluster in diagnosis.get("failure_clusters", []) or []:
        cluster_case_ids = {str(item) for item in cluster.get("case_ids", [])}
        if case_id in cluster_case_ids:
            cluster_ids.append(str(cluster.get("cluster_id") or cluster.get("category") or "failure_cluster"))
    return sorted(dict.fromkeys(cluster_ids))


def _merge_expected_behavior(metadata: dict[str, Any], expected_behavior: dict[str, Any]) -> dict[str, Any]:
    merged = dict(metadata)
    if expected_behavior.get("required_terms"):
        merged["required_terms"] = sorted(
            {
                *[str(item) for item in merged.get("required_terms", []) if str(item).strip()],
                *[str(item) for item in expected_behavior.get("required_terms", []) if str(item).strip()],
            }
        )
    if expected_behavior.get("forbidden_terms"):
        merged["forbidden_terms"] = sorted(
            {
                *[str(item) for item in merged.get("forbidden_terms", []) if str(item).strip()],
                *[str(item) for item in expected_behavior.get("forbidden_terms", []) if str(item).strip()],
            }
        )
    process_expectations = dict(merged.get("process_expectations") or {})
    for key in [
        "required_tools",
        "required_skills",
        "required_plugins",
        "required_mcps",
        "required_prompt_keys",
        "required_workflow_steps",
        "workflow_sequence",
    ]:
        values = [str(item) for item in expected_behavior.get(key, []) if str(item).strip()]
        if values:
            process_expectations[key] = sorted({*process_expectations.get(key, []), *values})
    max_step_count = expected_behavior.get("max_step_count")
    if max_step_count is not None:
        process_expectations["max_step_count"] = max_step_count
    if process_expectations:
        merged["process_expectations"] = process_expectations
    return merged


def _failure_expansion_candidates(
    diagnosis: dict[str, Any],
    target_rows: dict[str, dict[str, Any]],
) -> list[EvalCase]:
    candidates: list[EvalCase] = []
    experiment_id = str(diagnosis.get("experiment_id") or "").strip()
    baseline_id = str(diagnosis.get("baseline_id") or "").strip()
    for focus_case in diagnosis.get("focus_cases", []) or []:
        case_id = str(focus_case.get("case_id") or "").strip()
        if not case_id or case_id not in target_rows:
            continue
        original_case = EvalCase.model_validate((target_rows[case_id] or {}).get("case") or {})
        expected_behavior = dict(focus_case.get("expected_behavior") or {})
        reason = str(focus_case.get("reason") or "failed in a recent experiment").strip()
        cluster_ids = _clusters_for_case(diagnosis, case_id)
        candidate_evidence = dict(focus_case.get("candidate_evidence") or {})
        expansion_source = {
            "source": "failures",
            "mode": "focus_case",
            "experiment_id": experiment_id,
            "baseline_id": baseline_id,
            "source_case_id": case_id,
            "reason": reason,
            "score_delta": focus_case.get("score_delta"),
            "cluster_ids": cluster_ids,
            "fingerprint": _fingerprint(
                {
                    "source": "failures",
                    "experiment_id": experiment_id,
                    "source_case_id": case_id,
                    "reason": reason,
                    "cluster_ids": cluster_ids,
                }
            ),
        }
        metadata = _merge_expected_behavior(dict(original_case.metadata or {}), expected_behavior)
        metadata.update(
            {
                "source": "experiment_failure_expand",
                "expansion_source": expansion_source,
                "regression_target": {
                    "reason": reason,
                    "score_delta": focus_case.get("score_delta"),
                    "cluster_ids": cluster_ids,
                    "tool_calls": [str(item) for item in candidate_evidence.get("tool_calls", [])[:6]],
                    "trace_events": [str(item) for item in candidate_evidence.get("trace_events", [])[:6]],
                },
            }
        )
        rubric = list(original_case.rubric)
        regression_note = f"Regression target: {reason}."
        if regression_note not in rubric:
            rubric.append(regression_note)
        candidates.append(
            original_case.model_copy(
                update={
                    "id": "",
                    "rubric": rubric,
                    "tags": sorted({*original_case.tags, "expanded", "failure-driven", "regression", *cluster_ids}),
                    "metadata": metadata,
                }
            )
        )
    return candidates


def _expansion_summary(
    suite: EvalSuiteSpec,
    cases: list[EvalCase],
    splits: dict[str, Any],
) -> dict[str, Any]:
    history = list((suite.metadata or {}).get("expansion_history") or [])
    expanded_cases = [case for case in cases if _expansion_fingerprint(case)]
    if not history and not expanded_cases:
        return {}
    source_counts: dict[str, int] = {}
    mode_counts: dict[str, int] = {}
    for case in expanded_cases:
        expansion_source = (case.metadata or {}).get("expansion_source") or {}
        source = str(expansion_source.get("source") or "unknown")
        mode = str(expansion_source.get("mode") or "unknown")
        source_counts[source] = source_counts.get(source, 0) + 1
        mode_counts[mode] = mode_counts.get(mode, 0) + 1
    return {
        "expanded_case_count": len(expanded_cases),
        "source_counts": source_counts,
        "mode_counts": mode_counts,
        "expanded_split_sizes": {
            str(name): len(value or []) for name, value in (splits or {}).items() if str(name).startswith("expanded")
        },
        "latest": history[-1] if history else {},
        "history": history[-5:],
    }


def expand_eval_suite(
    project_root: Path,
    eval_id: str,
    *,
    brief_id: str | None = None,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    cluster_ids: list[str] | None = None,
    focus_limit: int = 4,
    brief_limit: int = 6,
    sources: list[str] | None = None,
) -> dict[str, Any]:
    suite = load_eval_suite(project_root, eval_id)
    existing_cases = [EvalCase.model_validate(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    existing_splits = read_yaml(split_path(project_root, eval_id)) if split_path(project_root, eval_id).exists() else {}
    selected_sources = list(dict.fromkeys(sources or ["brief", "failures"]))
    focus_limit = max(0, int(focus_limit))
    brief_limit = max(0, int(brief_limit))

    existing_signatures = {_case_semantic_signature(case) for case in existing_cases}
    existing_fingerprints = {fingerprint for case in existing_cases if (fingerprint := _expansion_fingerprint(case))}
    warnings: list[str] = []
    brief: BehaviorBrief | None = None
    diagnosis: dict[str, Any] | None = None
    accepted_entries: list[tuple[str, EvalCase]] = []

    if "brief" in selected_sources and brief_limit > 0:
        brief = _load_expansion_brief(project_root, eval_id, suite, brief_id)
        if brief is None:
            warnings.append(f"Eval `{eval_id}` has no linked approved brief for brief-driven expansion.")
        else:
            added = 0
            for candidate in _brief_expansion_candidates(brief):
                fingerprint = _expansion_fingerprint(candidate)
                signature = _case_semantic_signature(candidate)
                if fingerprint in existing_fingerprints or signature in existing_signatures:
                    continue
                existing_fingerprints.add(fingerprint)
                existing_signatures.add(signature)
                accepted_entries.append(("brief", candidate))
                added += 1
                if added >= brief_limit:
                    break

    if "failures" in selected_sources and focus_limit > 0:
        try:
            from agentworkbench.runner import _load_run_rows
            from agentworkbench.runner_diagnosis import diagnose_experiment

            diagnosis = diagnose_experiment(
                project_root,
                experiment_id=experiment_id,
                agent_id=agent_id,
                eval_id=eval_id,
                subset=subset,
                benchmark_signature=benchmark_signature,
                case_ids=case_ids,
                tags=tags,
                match=match,
                cluster_ids=cluster_ids,
                focus_limit=focus_limit,
            )
            target_rows = {
                str((row.get("case") or {}).get("id") or ""): row
                for row in _load_run_rows(project_root, str(diagnosis.get("experiment_id") or ""))
                if (row.get("case") or {}).get("id")
            }
            for candidate in _failure_expansion_candidates(diagnosis, target_rows):
                fingerprint = _expansion_fingerprint(candidate)
                if fingerprint in existing_fingerprints:
                    continue
                existing_fingerprints.add(fingerprint)
                accepted_entries.append(("failures", candidate))
        except ValueError as exc:
            warnings.append(str(exc))

    if not accepted_entries:
        detail = " ".join(warnings) if warnings else "All synthesized cases were already present."
        raise ValueError(f"No new eval cases were synthesized for `{eval_id}`. {detail}")

    added_case_ids_by_source: dict[str, list[str]] = {"brief": [], "failures": []}
    added_cases: list[EvalCase] = []
    for index, (source_name, candidate) in enumerate(accepted_entries, start=len(existing_cases) + 1):
        new_case = candidate.model_copy(update={"id": f"{eval_id}-expand-{index}"})
        added_cases.append(new_case)
        added_case_ids_by_source.setdefault(source_name, []).append(new_case.id)

    all_cases = [*existing_cases, *added_cases]
    all_case_ids = [case.id for case in all_cases]
    all_case_id_set = set(all_case_ids)

    split_payload: dict[str, list[str]] = {}
    for name, values in (existing_splits or {}).items():
        if str(name).startswith("expanded"):
            continue
        cleaned = [str(item) for item in values or [] if str(item) in all_case_id_set]
        if str(name) == "full":
            split_payload[str(name)] = all_case_ids
        elif str(name) == "smoke":
            split_payload[str(name)] = cleaned or all_case_ids[: min(3, len(all_case_ids))]
        else:
            split_payload[str(name)] = cleaned
    if "smoke" not in split_payload:
        split_payload["smoke"] = all_case_ids[: min(3, len(all_case_ids))]
    split_payload["full"] = all_case_ids

    expanded_case_ids = [case.id for case in all_cases if _expansion_fingerprint(case)]
    if expanded_case_ids:
        split_payload["expanded"] = expanded_case_ids
    if brief_case_ids := [
        case.id
        for case in all_cases
        if str(((case.metadata or {}).get("expansion_source") or {}).get("source") or "") == "brief"
    ]:
        split_payload["expanded-brief"] = brief_case_ids
    if failure_case_ids := [
        case.id
        for case in all_cases
        if str(((case.metadata or {}).get("expansion_source") or {}).get("source") or "") == "failures"
    ]:
        split_payload["expanded-failures"] = failure_case_ids

    previous_approval_status = suite.approval_status
    suite.brief_id = str((brief.id if brief else suite.brief_id) or "")
    suite.generated_case_count = len(all_cases)
    suite.tags = sorted({str(tag) for case in all_cases for tag in case.tags})
    suite.approval_status = "draft"
    source_counts = {
        source_name: len(case_ids_for_source)
        for source_name, case_ids_for_source in added_case_ids_by_source.items()
        if case_ids_for_source
    }
    expansion_event = {
        "timestamp": created_at_utc(),
        "selected_sources": selected_sources,
        "source_counts": source_counts,
        "added_case_count": len(added_cases),
        "added_case_ids": [case.id for case in added_cases],
        "brief_id": suite.brief_id,
        "experiment_id": str((diagnosis or {}).get("experiment_id") or ""),
        "baseline_id": str((diagnosis or {}).get("baseline_id") or ""),
        "previous_approval_status": previous_approval_status,
        "warnings": warnings,
    }
    metadata = dict(suite.metadata or {})
    history = list(metadata.get("expansion_history") or [])
    history.append(expansion_event)
    metadata["expansion_history"] = history
    metadata["latest_expansion"] = expansion_event
    suite.metadata = metadata
    suite.notes = [
        *(suite.notes or []),
        (
            f"Expanded on {expansion_event['timestamp']}: added {len(added_cases)} cases "
            f"(brief={source_counts.get('brief', 0)}, failures={source_counts.get('failures', 0)}); "
            f"approval reset from `{previous_approval_status}` to `draft` pending review."
        ),
    ]

    write_jsonl(eval_path(project_root, eval_id), [case.model_dump(mode="json") for case in all_cases])
    dump_model(suite_path(project_root, eval_id), suite)
    write_yaml(split_path(project_root, eval_id), split_payload)
    review_report = review_eval_suite(project_root, eval_id)
    return {
        "eval_id": eval_id,
        "brief_id": suite.brief_id,
        "experiment_id": expansion_event["experiment_id"],
        "approval_status": suite.approval_status,
        "added_case_count": len(added_cases),
        "generated_case_count": len(all_cases),
        "selected_sources": selected_sources,
        "source_counts": source_counts,
        "new_case_ids": [case.id for case in added_cases],
        "split_sizes": {name: len(value or []) for name, value in split_payload.items()},
        "warnings": warnings,
        "review_report": str(review_report),
    }


def review_eval_suite(project_root: Path, eval_id: str) -> Path:
    suite = load_eval_suite(project_root, eval_id)
    cases = [EvalCase.model_validate(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    splits = read_yaml(split_path(project_root, eval_id))
    human_checkpoints = eval_human_checkpoints(cases, suite)
    review_queue = build_review_queue(
        queue_id=f"eval-{eval_id}",
        stage="eval_review",
        subject=eval_id,
        checkpoints=human_checkpoints,
    )
    review_queue = resolve_review_queue(project_root, review_queue)
    payload = {
        "eval_id": eval_id,
        "brief_id": suite.brief_id,
        "approval_status": suite.approval_status,
        "generated_case_count": len(cases),
        "score_weights": _suite_score_weights(suite),
        "notes": suite.notes,
        "tags": suite.tags or sorted({tag for case in cases for tag in case.tags}),
        "split_sizes": {name: len(value or []) for name, value in (splits or {}).items()},
        "expansion_summary": _expansion_summary(suite, cases, splits),
        "cases": [case.model_dump(mode="json") for case in cases],
        "human_checkpoints": pending_review_items(review_queue),
        "human_review_queue": review_queue,
    }
    write_json(control_dir(project_root) / "reports" / f"eval-review-queue-{eval_id}.json", review_queue)
    path = eval_review_path(project_root, eval_id)
    return write_report(path, render_eval_suite_report(payload))


def approve_eval_suite(project_root: Path, eval_id: str, min_quality: float = 0.3) -> Path:
    suite = load_eval_suite(project_root, eval_id)
    cases = [EvalCase.model_validate(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    if not cases:
        raise ValueError("Eval suite must contain at least one case")
    if not split_path(project_root, eval_id).exists():
        raise ValueError("Eval suite must define splits before approval")
    if not scorer_path(project_root, eval_id).exists():
        raise ValueError("Eval suite must define a scorer before approval")
    weights = _normalize_score_weights(_suite_score_weights(suite))
    if sum(weights.values()) <= 0.0:
        raise ValueError("Eval suite score weights must sum to more than zero")

    brief = None
    brief_behaviors: list[dict] = []
    if suite.brief_id:
        try:
            brief = load_model(brief_path(project_root, suite.brief_id), BehaviorBrief)
            brief_behaviors = [
                {"category": "goal", "tags": ["goal"]},
                {
                    "category": "workflow",
                    "tags": ["workflow", *(["multiturn"] if any(item.get("turns") for item in brief.workflow_scenarios or []) else [])],
                },
                {"category": "edge_case", "tags": ["edge-case"] if brief.edge_cases else []},
            ]
        except Exception:
            pass

    quality = compute_benchmark_quality(
        benchmark_cases=[case.model_dump(mode="json") for case in cases],
        brief_behaviors=brief_behaviors,
        experiments=None,
    )

    if quality.overall_score < min_quality:
        raise ValueError(
            f"Benchmark quality {quality.overall_score:.2f} is below minimum {min_quality}. "
            f"Recommendation: {quality.recommendation}. Warnings: {quality.warnings}"
        )

    suite.score_weights = weights
    suite.generated_case_count = len(cases)
    suite.tags = sorted({tag for case in cases for tag in case.tags})
    suite.approval_status = "approved"
    dump_model(suite_path(project_root, eval_id), suite)
    return review_eval_suite(project_root, eval_id)


def load_eval_cases(
    project_root: Path,
    eval_id: str,
    subset: str,
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
) -> list[EvalCase]:
    suite = load_eval_suite(project_root, eval_id)
    if suite.approval_status != "approved":
        raise ValueError(f"Eval suite `{eval_id}` must be approved before running experiments")
    rows = [EvalCase.model_validate(item) for item in read_jsonl(eval_path(project_root, eval_id))]
    splits = read_yaml(split_path(project_root, eval_id))
    wanted = set(splits.get(subset, []))
    if not wanted:
        raise ValueError(f"Unknown or empty subset `{subset}` for eval `{eval_id}`")
    selected = select_eval_cases(
        rows,
        subset_ids=wanted,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    if not selected:
        raise ValueError(f"No eval cases matched subset `{subset}` with the requested case selection filters.")
    return selected


@dataclass(frozen=True)
class ScoringContext:
    """Loaded once per experiment to avoid re-reading suite and scorer modules per case."""

    suite: EvalSuiteSpec
    score_weights: dict[str, float]
    scorers: list[Callable[[dict[str, Any], dict[str, Any]], Any]]
    learned_scorer: LearnedScorer | None = None


def load_scoring_context(
    project_root: Path,
    eval_id: str,
    *,
    learned_scorer_path: Path | None = None,
) -> ScoringContext:
    suite = load_eval_suite(project_root, eval_id)
    learned_scorer: LearnedScorer | None = None
    if learned_scorer_path and learned_scorer_path.exists():
        learned_scorer = load_learned_scorer(learned_scorer_path)
    return ScoringContext(
        suite=suite,
        score_weights=_suite_score_weights(suite),
        scorers=load_scorers(project_root, eval_id),
        learned_scorer=learned_scorer,
    )


def load_scorers(project_root: Path, eval_id: str) -> list[Callable[[dict[str, Any], dict[str, Any]], Any]]:
    """Load both project-specific and extension-provided scorers."""
    # 1. Project-specific scorers
    project_scorers = []
    path = scorer_path(project_root, eval_id)
    if path.exists():
        module_name = f"awb_scorer_{eval_id.replace('-', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is not None and spec.loader is not None:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, "score_case"):
                project_scorers.append(module.score_case)
            if hasattr(module, "score_cases"):
                project_scorers.append(module.score_cases)

    # 2. Extension scorers
    extension_scorers = _load_extension_scorers()

    return project_scorers + extension_scorers


def score_run(
    project_root: Path,
    eval_id: str,
    artifact: RunArtifact,
    case: EvalCase,
    *,
    scoring_context: ScoringContext | None = None,
) -> list[dict[str, Any]]:
    ctx = scoring_context or load_scoring_context(project_root, eval_id)
    scorers = ctx.scorers
    if not scorers:
        return [
            {
                "name": "no_scorer",
                "value": 1.0 if artifact.final_output else 0.0,
                "passed": bool(artifact.final_output),
                "reason": "fallback scorer",
            }
        ]
    results = []
    weights = ctx.score_weights
    artifact_payload = artifact.model_dump(mode="json")
    case_payload = case.model_dump(mode="json")
    for scorer in scorers:
        output = scorer(artifact_payload, case_payload)
        if isinstance(output, list):
            results.extend(output)
        else:
            results.append(output)
    if ctx.learned_scorer is not None:
        learned_features = _extract_learned_features(artifact)
        if learned_features:
            learned_score = ctx.learned_scorer.predict(learned_features)
            results.append(
                {
                    "name": "learned",
                    "value": learned_score,
                    "passed": learned_score >= 0.5,
                    "reason": "learned scorer prediction",
                }
            )
    normalized: list[dict[str, Any]] = []
    for item in results:
        payload = dict(item)
        name = str(payload.get("name") or "unnamed_metric")
        payload["name"] = name
        payload["weight"] = float(payload.get("weight", weights.get(name, 1.0)))
        normalized.append(payload)
    return normalized


def _extract_learned_features(artifact: RunArtifact) -> dict[str, float]:
    """Extract features from artifact for learned scorer."""
    scores = artifact.metadata.get("scores", {})
    return {
        "score": sum(scores.values()) / len(scores) if scores else 0.5,
        "latency_ms": float(artifact.latency_ms or 0),
        "cost_estimate": float(artifact.cost_estimate or 0.0),
        "tool_count": float(len(artifact.tool_calls or [])),
        "step_count": float(artifact.step_count or 0),
        "has_output": 1.0 if artifact.final_output else 0.0,
        "has_errors": 1.0 if artifact.errors else 0.0,
    }
