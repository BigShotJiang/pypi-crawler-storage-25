from __future__ import annotations

from typing import Any

from agentworkbench.scorers.grounding import grounding_provenance


def score_output_quality(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any]:
    final_output = (run_artifact.get("final_output") or "").strip()
    final_output_lower = final_output.lower()
    metadata = case.get("metadata") or {}
    required_terms = [str(item).lower() for item in metadata.get("required_terms", []) if str(item).strip()]
    forbidden_terms = [str(item).lower() for item in metadata.get("forbidden_terms", []) if str(item).strip()]
    missing = [term for term in required_terms if term not in final_output_lower]
    forbidden = [term for term in forbidden_terms if term in final_output_lower]
    if forbidden:
        return {
            "name": "output_quality",
            "value": 0.0,
            "passed": False,
            "reason": f"forbidden terms present: {', '.join(forbidden)}",
        }
    if required_terms:
        matched = len(required_terms) - len(missing)
        value = matched / len(required_terms)
        passed = not missing
        reasons = ["all required terms present" if not missing else f"missing required terms: {', '.join(missing)}"]
    else:
        expected = (case.get("expected") or "").strip().lower()
        passed = bool(expected and expected in final_output_lower)
        value = 1.0 if passed else 0.0
        reasons = ["expected text present" if passed else "expected text missing"]
    grounding = grounding_provenance(run_artifact, case)
    if grounding["enabled"]:
        grounding_terms = grounding["grounding_terms"]
        grounded_terms = grounding["grounded_terms"]
        unsupported_terms = grounding["unsupported_terms"]
        if grounding_terms:
            value = min(value, len(grounded_terms) / len(grounding_terms))
        if grounding["require_selected_evidence"] and int(grounding["selected_evidence_count"]) <= 0:
            passed = False
            value = 0.0
            reasons.append("no selected evidence was recorded")
        elif unsupported_terms:
            passed = False
            unsupported_details = []
            for item in grounding.get("term_matches", []):
                term = str(item.get("term") or "")
                if term not in unsupported_terms:
                    continue
                sources = ", ".join(item.get("supporting_source_labels", []) or [])
                if sources:
                    unsupported_details.append(f"{term} [{sources}]")
                else:
                    unsupported_details.append(term)
            reasons.append(f"ungrounded required terms: {', '.join(unsupported_details or unsupported_terms)}")
        elif grounding_terms:
            grounded_details = []
            for item in grounding.get("term_matches", []):
                term = str(item.get("term") or "")
                if term not in grounded_terms:
                    continue
                sources = ", ".join(
                    item.get("used_source_labels", []) or item.get("supporting_source_labels", []) or []
                )
                grounded_details.append(f"{term} [{sources}]" if sources else term)
            reasons.append(f"grounded terms: {', '.join(grounded_details or grounded_terms)}")
    return {
        "name": "output_quality",
        "value": round(value, 3),
        "passed": passed,
        "reason": "; ".join(reasons),
        "grounding_provenance": grounding,
    }


__all__ = ["score_output_quality"]
