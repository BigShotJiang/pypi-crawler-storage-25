from __future__ import annotations

from typing import Any


def score_audit_report(
    scores: list[dict[str, Any]],
) -> dict[str, Any]:
    heuristic_scores = []
    model_judged_scores = []
    unknown_scores = []

    for score in scores:
        judged = score.get("judged")
        if judged is None:
            unknown_scores.append(score)
        elif judged.get("fallback_path") == "heuristic":
            heuristic_scores.append(score)
        else:
            model_judged_scores.append(score)

    total = len(scores)
    heuristic_count = len(heuristic_scores)
    model_count = len(model_judged_scores)
    unknown_count = len(unknown_scores)

    return {
        "total_scores": total,
        "heuristic_scores": heuristic_count,
        "model_judged_scores": model_count,
        "unknown_scores": unknown_count,
        "heuristic_percentage": round(heuristic_count / total * 100, 1) if total > 0 else 0.0,
        "model_judged_percentage": round(model_count / total * 100, 1) if total > 0 else 0.0,
        "is_fully_heuristic": heuristic_count == total and total > 0,
        "is_fully_model_judged": model_count == total and total > 0,
        "is_mixed": heuristic_count > 0 and model_count > 0,
    }


def summarize_judge_audit(
    _run_audit: dict[str, Any],
    aggregate_scores: list[dict[str, Any]],
) -> dict[str, Any]:
    case_level = score_audit_report(aggregate_scores)
    return {
        "case_level_audit": case_level,
        "run_has_judged_scores": any(
            any(score.get("judged") is not None for score in case_scores) for case_scores in [aggregate_scores]
        ),
        "confidence_note": _get_confidence_note(case_level),
    }


def _get_confidence_note(audit: dict[str, Any]) -> str:
    if audit["is_fully_heuristic"]:
        return "Scores are deterministic heuristics - high confidence in reproducibility"
    if audit["is_fully_model_judged"]:
        return "Scores are from model-based judgments - confidence varies by model quality"
    if audit["is_mixed"]:
        return "Mixed scoring approach - some scores deterministic, others model-judged"
    if audit["unknown_scores"] > 0:
        return "Some scores have unknown judgment origin"
    return "No judgment metadata available"


__all__ = [
    "score_audit_report",
    "summarize_judge_audit",
]
