from __future__ import annotations

from typing import Any

from agentworkbench.scorers.workflow import contains_sequence, surface_names, workflow_trace


def score_process_alignment(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any]:
    metadata = case.get("metadata") or {}
    expectations = metadata.get("process_expectations") or {}
    hints = metadata.get("process_hints") or {}
    trace = workflow_trace(run_artifact)
    used = {
        "required_tools": surface_names(run_artifact, "tools_used"),
        "required_skills": surface_names(run_artifact, "skills_used"),
        "required_plugins": surface_names(run_artifact, "plugins_used"),
        "required_mcps": surface_names(run_artifact, "mcp_servers_used"),
        "required_prompt_keys": surface_names(run_artifact, "prompt_keys_used"),
    }
    failures: list[str] = []
    for expectation_key, used_values in used.items():
        expected_values = [str(item) for item in expectations.get(expectation_key, [])]
        missing = [item for item in expected_values if item not in used_values]
        if missing:
            failures.append(f"missing {expectation_key}: {', '.join(missing)}")
    forbidden_mapping = {
        "forbidden_tools": used["required_tools"],
        "forbidden_skills": used["required_skills"],
        "forbidden_plugins": used["required_plugins"],
        "forbidden_mcps": used["required_mcps"],
        "forbidden_prompt_keys": used["required_prompt_keys"],
    }
    for forbidden_key, used_values in forbidden_mapping.items():
        forbidden_values = [str(item) for item in expectations.get(forbidden_key, [])]
        present = [item for item in forbidden_values if item in used_values]
        if present:
            failures.append(f"forbidden {forbidden_key}: {', '.join(present)}")
    required_workflow_steps = [str(item) for item in expectations.get("required_workflow_steps", [])]
    missing_workflow_steps = [item for item in required_workflow_steps if item not in trace]
    if missing_workflow_steps:
        failures.append(f"missing required_workflow_steps: {', '.join(missing_workflow_steps)}")
    forbidden_workflow_steps = [str(item) for item in expectations.get("forbidden_workflow_steps", [])]
    present_forbidden_steps = [item for item in forbidden_workflow_steps if item in trace]
    if present_forbidden_steps:
        failures.append(f"forbidden forbidden_workflow_steps: {', '.join(present_forbidden_steps)}")
    workflow_sequence = [str(item) for item in expectations.get("workflow_sequence", [])]
    if workflow_sequence and not contains_sequence(trace, workflow_sequence):
        failures.append(f"workflow_sequence mismatch: expected {' -> '.join(workflow_sequence)}")
    max_step_count = expectations.get("max_step_count")
    step_count = int(run_artifact.get("step_count") or 0)
    if max_step_count is not None and step_count > int(max_step_count):
        failures.append(f"step_count {step_count} exceeds max_step_count {int(max_step_count)}")
    if failures:
        return {
            "name": "process_alignment",
            "value": 0.0,
            "passed": False,
            "reason": "; ".join(failures),
        }
    hint_mapping = {
        "preferred_tools": used["required_tools"],
        "preferred_skills": used["required_skills"],
        "preferred_plugins": used["required_plugins"],
        "preferred_mcps": used["required_mcps"],
        "preferred_prompt_keys": used["required_prompt_keys"],
    }
    available_hints: list[str] = []
    matched_hints: list[str] = []
    for hint_key, used_values in hint_mapping.items():
        hint_values = [str(item) for item in hints.get(hint_key, [])]
        if hint_values:
            available_hints.append(hint_key)
            if set(hint_values) & set(used_values):
                matched_hints.append(hint_key)
    preferred_workflow_sequence = [str(item) for item in hints.get("preferred_workflow_sequence", [])]
    if preferred_workflow_sequence:
        available_hints.append("preferred_workflow_sequence")
        if contains_sequence(trace, preferred_workflow_sequence):
            matched_hints.append("preferred_workflow_sequence")
    if available_hints and matched_hints:
        return {
            "name": "process_alignment",
            "value": 1.0,
            "passed": True,
            "reason": f"matched preferred surfaces: {', '.join(matched_hints)}",
        }
    if available_hints:
        return {
            "name": "process_alignment",
            "value": 0.5,
            "passed": True,
            "reason": "no preferred surfaces were observed in telemetry",
        }
    return {
        "name": "process_alignment",
        "value": 1.0,
        "passed": True,
        "reason": "no explicit process constraints",
    }


__all__ = ["score_process_alignment"]
