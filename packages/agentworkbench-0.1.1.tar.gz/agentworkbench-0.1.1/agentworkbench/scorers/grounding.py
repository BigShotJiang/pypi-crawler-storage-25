from __future__ import annotations

from typing import Any

from agentworkbench.evidence import evidence_record_label, normalize_evidence_records
from agentworkbench.scorers.workflow import _contains_text


def _grounding_terms(metadata: dict[str, Any], required_terms: list[str]) -> list[str]:
    configured = metadata.get("grounding_required_terms")
    if configured is None:
        return required_terms if bool(metadata.get("require_grounding")) else []
    if isinstance(configured, str) and configured.strip().lower() == "required_terms":
        return required_terms
    return [str(item) for item in configured or [] if str(item).strip()]


def _selected_evidence_snippets(run_artifact: dict[str, Any]) -> list[str]:
    snippets: list[str] = []
    records = normalize_evidence_records(run_artifact, final_output=str(run_artifact.get("final_output") or ""))
    for record in records:
        for hit in record.get("hits") or []:
            if bool((hit or {}).get("selected")):
                snippet = str((hit or {}).get("snippet") or "").strip()
                if snippet:
                    snippets.append(snippet)
    return snippets


def _selected_evidence_hits(run_artifact: dict[str, Any]) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    records = normalize_evidence_records(run_artifact, final_output=str(run_artifact.get("final_output") or ""))
    for record in records:
        label = evidence_record_label(record)
        for hit in record.get("hits") or []:
            if not bool((hit or {}).get("selected")):
                continue
            hits.append(
                {
                    "label": label,
                    "kind": str(record.get("kind") or ""),
                    "name": str(record.get("name") or ""),
                    "mcp": str(record.get("mcp") or ""),
                    "id": str((hit or {}).get("id") or ""),
                    "path": str((hit or {}).get("path") or ""),
                    "line": int((hit or {}).get("line") or 0),
                    "snippet": str((hit or {}).get("snippet") or "").strip(),
                    "used_in_output": bool((hit or {}).get("used_in_output")),
                }
            )
    return hits


def grounding_provenance(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any]:
    metadata = case.get("metadata") or {}
    required_terms = [str(item) for item in metadata.get("required_terms", []) if str(item).strip()]
    grounding_terms = _grounding_terms(metadata, required_terms)
    final_output = str(run_artifact.get("final_output") or "")
    selected_hits = _selected_evidence_hits(run_artifact)
    selected_snippets = [
        str(item.get("snippet") or "") for item in selected_hits if str(item.get("snippet") or "").strip()
    ]
    grounded = [term for term in grounding_terms if any(_contains_text(snippet, term) for snippet in selected_snippets)]
    unsupported = [term for term in grounding_terms if term not in grounded]
    term_matches: list[dict[str, Any]] = []
    grounded_sources: set[str] = set()
    ungrounded_output_terms: list[str] = []
    missing_output_terms: list[str] = []
    for term in grounding_terms:
        output_present = _contains_text(final_output, term)
        supporting_hits = [
            {
                "label": str(hit.get("label") or ""),
                "id": str(hit.get("id") or ""),
                "path": str(hit.get("path") or ""),
                "line": int(hit.get("line") or 0),
                "used_in_output": bool(hit.get("used_in_output")),
                "snippet": str(hit.get("snippet") or ""),
            }
            for hit in selected_hits
            if _contains_text(hit.get("snippet"), term)
        ]
        if output_present and not supporting_hits:
            ungrounded_output_terms.append(term)
        if not output_present:
            missing_output_terms.append(term)
        if output_present and supporting_hits:
            grounded_sources.update(str(hit.get("label") or "") for hit in supporting_hits)
        term_matches.append(
            {
                "term": term,
                "output_present": output_present,
                "supported_by_selected_evidence": bool(supporting_hits),
                "supporting_hits": supporting_hits,
                "supporting_source_labels": sorted(
                    {str(hit.get("label") or "") for hit in supporting_hits if str(hit.get("label") or "").strip()}
                ),
                "used_source_labels": sorted(
                    {str(hit.get("label") or "") for hit in supporting_hits if bool(hit.get("used_in_output"))}
                ),
            }
        )
    return {
        "enabled": bool(grounding_terms or metadata.get("require_selected_evidence")),
        "require_selected_evidence": bool(metadata.get("require_selected_evidence")),
        "selected_evidence_count": len(selected_hits),
        "grounding_terms": grounding_terms,
        "grounded_terms": grounded,
        "unsupported_terms": unsupported,
        "ungrounded_output_terms": ungrounded_output_terms,
        "missing_output_terms": missing_output_terms,
        "grounded_source_labels": sorted(source for source in grounded_sources if source),
        "selected_source_labels": sorted(
            {str(hit.get("label") or "") for hit in selected_hits if str(hit.get("label") or "").strip()}
        ),
        "used_source_labels": sorted(
            {
                str(hit.get("label") or "")
                for hit in selected_hits
                if bool(hit.get("used_in_output")) and str(hit.get("label") or "").strip()
            }
        ),
        "term_matches": term_matches,
    }


def grounding_summary(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any]:
    provenance = grounding_provenance(run_artifact, case)
    return {
        "enabled": bool(provenance.get("enabled")),
        "require_selected_evidence": bool(provenance.get("require_selected_evidence")),
        "selected_evidence_count": int(provenance.get("selected_evidence_count", 0) or 0),
        "grounding_terms": list(provenance.get("grounding_terms") or []),
        "grounded_terms": list(provenance.get("grounded_terms") or []),
        "unsupported_terms": list(provenance.get("unsupported_terms") or []),
        "grounding_provenance": provenance,
    }


def score_grounding_support(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any] | None:
    provenance = grounding_provenance(run_artifact, case)
    if not bool(provenance.get("enabled")):
        return None
    selected_evidence_count = int(provenance.get("selected_evidence_count", 0) or 0)
    grounding_terms = [str(item) for item in provenance.get("grounding_terms") or []]
    grounded_terms = [str(item) for item in provenance.get("grounded_terms") or []]
    unsupported_terms = [str(item) for item in provenance.get("unsupported_terms") or []]
    require_selected_evidence = bool(provenance.get("require_selected_evidence"))
    if grounding_terms:
        value = len(grounded_terms) / len(grounding_terms)
    else:
        value = 1.0 if selected_evidence_count > 0 or not require_selected_evidence else 0.0
    passed = not unsupported_terms and (selected_evidence_count > 0 or not require_selected_evidence)
    if require_selected_evidence and selected_evidence_count <= 0:
        reason = "no selected evidence was recorded"
    elif unsupported_terms:
        reason = f"unsupported grounding terms: {', '.join(unsupported_terms)}"
    elif grounding_terms:
        reason = f"grounded terms supported: {', '.join(grounded_terms)}"
    else:
        reason = "selected evidence was recorded"
    return {
        "name": "grounding_support",
        "value": round(value, 3),
        "passed": passed,
        "reason": reason,
        "weight": 0.0,
        "grounding_provenance": provenance,
    }


__all__ = [
    "grounding_provenance",
    "grounding_summary",
    "score_grounding_support",
]
