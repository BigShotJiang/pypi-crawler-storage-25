from __future__ import annotations

import random
from typing import Any, NamedTuple


class ConfidenceInterval(NamedTuple):
    """Bootstrap confidence interval for a score value."""

    lower: float
    upper: float
    n_bootstrap: int
    alpha: float


def bootstrap_confidence_interval(
    values: list[float],
    *,
    n_bootstrap: int = 1000,
    alpha: float = 0.05,
    seed: int | None = None,
) -> ConfidenceInterval | None:
    """Compute a bootstrap confidence interval for a list of score values.

    Returns ``None`` when ``values`` is empty or has only one element.
    """
    if len(values) < 2:
        return None
    rng = random.Random(seed)
    means: list[float] = []
    for _ in range(n_bootstrap):
        sample = rng.choices(values, k=len(values))
        means.append(sum(sample) / len(sample))
    means.sort()
    lower_index = int(alpha / 2 * n_bootstrap)
    upper_index = int((1 - alpha / 2) * n_bootstrap) - 1
    return ConfidenceInterval(
        lower=round(means[max(0, lower_index)], 4),
        upper=round(means[min(len(means) - 1, upper_index)], 4),
        n_bootstrap=n_bootstrap,
        alpha=alpha,
    )


class JudgedScore:
    def __init__(
        self,
        *,
        prompt: str,
        model: str,
        evidence: list[str],
        fallback_path: str,
        confidence: float | None = None,
        confidence_interval: ConfidenceInterval | None = None,
    ):
        self.prompt = prompt
        self.model = model
        self.evidence = evidence
        self.fallback_path = fallback_path
        self.confidence = confidence
        self.confidence_interval = confidence_interval

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "prompt": self.prompt,
            "model": self.model,
            "evidence": self.evidence,
            "fallback_path": self.fallback_path,
            "confidence": self.confidence,
        }
        if self.confidence_interval is not None:
            payload["confidence_interval"] = {
                "lower": self.confidence_interval.lower,
                "upper": self.confidence_interval.upper,
                "n_bootstrap": self.confidence_interval.n_bootstrap,
                "alpha": self.confidence_interval.alpha,
            }
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JudgedScore:
        ci_data = data.get("confidence_interval")
        ci = None
        if isinstance(ci_data, dict):
            ci = ConfidenceInterval(
                lower=float(ci_data.get("lower", 0.0)),
                upper=float(ci_data.get("upper", 1.0)),
                n_bootstrap=int(ci_data.get("n_bootstrap", 1000)),
                alpha=float(ci_data.get("alpha", 0.05)),
            )
        return cls(
            prompt=str(data.get("prompt", "")),
            model=str(data.get("model", "")),
            evidence=list(data.get("evidence", [])),
            fallback_path=str(data.get("fallback_path", "heuristic")),
            confidence=data.get("confidence"),
            confidence_interval=ci,
        )


def heuristic_score() -> JudgedScore:
    """Create a JudgedScore representing a simple heuristic evaluation."""
    return JudgedScore(
        prompt="",
        model="",
        evidence=[],
        fallback_path="heuristic",
        confidence=1.0,
    )


def model_judged_score(
    *,
    prompt: str,
    model: str,
    evidence: list[str],
    confidence: float | None = None,
    confidence_interval: ConfidenceInterval | None = None,
) -> JudgedScore:
    """Create a JudgedScore representing a model-based evaluation."""
    return JudgedScore(
        prompt=prompt,
        model=model,
        evidence=evidence,
        fallback_path="model_judged",
        confidence=confidence,
        confidence_interval=confidence_interval,
    )


def enrich_score_with_judgment(
    score: dict[str, Any],
    judged: JudgedScore | None = None,
) -> dict[str, Any]:
    result = dict(score)
    if judged is not None:
        result["judged"] = judged.to_dict()
    return result


def report_judgment_disagreement(
    scores: list[dict[str, Any]],
) -> dict[str, Any]:
    judged_scores = [s for s in scores if s.get("judged") is not None]
    if len(judged_scores) < 2:
        return {"has_disagreement": False, "disagreement_count": 0}
    judgments = [str(s.get("judged", {}).get("fallback_path", "")) for s in judged_scores]
    unique = set(judgments)
    return {
        "has_disagreement": len(unique) > 1,
        "disagreement_count": len(unique) - 1 if len(unique) > 1 else 0,
        "judgment_types": sorted(unique),
    }


__all__ = [
    "ConfidenceInterval",
    "JudgedScore",
    "bootstrap_confidence_interval",
    "heuristic_score",
    "model_judged_score",
    "enrich_score_with_judgment",
    "report_judgment_disagreement",
]


