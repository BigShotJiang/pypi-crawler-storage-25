from __future__ import annotations

from collections.abc import Callable
from typing import Any

ScoreResult = dict[str, Any] | list[dict[str, Any]] | None
ScoreFn = Callable[[dict[str, Any], dict[str, Any]], ScoreResult]


def _score_output_quality(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.output_quality import score_output_quality

    return score_output_quality(run_artifact, case)


def _score_process_alignment(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.process_alignment import score_process_alignment

    return score_process_alignment(run_artifact, case)


def _score_grounding_support(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.grounding import score_grounding_support

    return score_grounding_support(run_artifact, case)


def _score_json_schema_adherence(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.json_schema import score_json_schema_adherence

    return score_json_schema_adherence(run_artifact, case)


def _score_safety_forbidden_terms(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.safety import check_forbidden_terms

    return check_forbidden_terms(run_artifact, case)


def _score_conversation_turns(run_artifact: dict[str, Any], case: dict[str, Any]) -> ScoreResult:
    from agentworkbench.scorers.workflow import score_conversation_turns

    return score_conversation_turns(run_artifact, case)


_SCORERS: dict[str, ScoreFn] = {
    "output_quality": _score_output_quality,
    "process_alignment": _score_process_alignment,
    "grounding_support": _score_grounding_support,
    "json_schema_adherence": _score_json_schema_adherence,
    "safety_forbidden_terms": _score_safety_forbidden_terms,
    "conversation_turns": _score_conversation_turns,
}


def _score_list(result: ScoreResult) -> list[dict[str, Any]]:
    if result is None:
        return []
    if isinstance(result, list):
        return [dict(item) for item in result if isinstance(item, dict)]
    return [dict(result)]


def _apply_weights(scores: list[dict[str, Any]], weights: dict[str, float] | None) -> list[dict[str, Any]]:
    if not weights:
        return scores
    for score in scores:
        name = str(score.get("name") or "")
        if name in weights:
            score["weight"] = float(weights[name])
    return scores


def _bundle(
    run_artifact: dict[str, Any],
    case: dict[str, Any],
    *,
    scorer_names: list[str],
    weights: dict[str, float] | None = None,
) -> list[dict[str, Any]]:
    scores: list[dict[str, Any]] = []
    for scorer_name in scorer_names:
        scorer = _SCORERS[scorer_name]
        scores.extend(_score_list(scorer(run_artifact, case)))
    return _apply_weights(scores, weights)


def default_score_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
            "grounding_support",
            "json_schema_adherence",
            "conversation_turns",
        ],
    )


def support_agent_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
            "grounding_support",
            "json_schema_adherence",
            "safety_forbidden_terms",
        ],
        weights={
            "output_quality": 0.6,
            "process_alignment": 0.2,
            "grounding_support": 0.1,
            "json_schema_adherence": 0.05,
            "safety_forbidden_terms": 0.05,
        },
    )


def coding_agent_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
            "json_schema_adherence",
            "safety_forbidden_terms",
        ],
        weights={
            "output_quality": 0.5,
            "process_alignment": 0.3,
            "json_schema_adherence": 0.15,
            "safety_forbidden_terms": 0.05,
        },
    )


def retrieval_agent_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
            "grounding_support",
        ],
        weights={
            "output_quality": 0.5,
            "process_alignment": 0.2,
            "grounding_support": 0.3,
        },
    )


def router_agent_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
        ],
        weights={
            "output_quality": 0.4,
            "process_alignment": 0.6,
        },
    )


def release_gate_bundle(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    return _bundle(
        run_artifact,
        case,
        scorer_names=[
            "output_quality",
            "process_alignment",
            "grounding_support",
            "json_schema_adherence",
            "safety_forbidden_terms",
        ],
        weights={
            "output_quality": 0.3,
            "process_alignment": 0.3,
            "grounding_support": 0.15,
            "json_schema_adherence": 0.15,
            "safety_forbidden_terms": 0.1,
        },
    )


BUNDLE_REGISTRY: dict[str, Any] = {
    "default": default_score_bundle,
    "support_agent": support_agent_bundle,
    "coding_agent": coding_agent_bundle,
    "retrieval_agent": retrieval_agent_bundle,
    "router_agent": router_agent_bundle,
    "release_gate": release_gate_bundle,
}


def get_scorer_bundle(name: str) -> Any:
    return BUNDLE_REGISTRY.get(name, default_score_bundle)


def register_scorer_bundle(name: str, bundle: Any) -> None:
    BUNDLE_REGISTRY[name] = bundle


def list_scorer_bundles() -> list[str]:
    return sorted(BUNDLE_REGISTRY.keys())


__all__ = [
    "default_score_bundle",
    "support_agent_bundle",
    "coding_agent_bundle",
    "retrieval_agent_bundle",
    "router_agent_bundle",
    "release_gate_bundle",
    "get_scorer_bundle",
    "register_scorer_bundle",
    "list_scorer_bundles",
    "BUNDLE_REGISTRY",
]
