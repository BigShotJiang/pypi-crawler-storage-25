from __future__ import annotations

from typing import Any

from agentworkbench.text_utils import normalized_alnum_text


def _contains_text(haystack: Any, needle: Any) -> bool:
    normalized_haystack = normalized_alnum_text(haystack)
    normalized_needle = normalized_alnum_text(needle)
    return bool(normalized_haystack and normalized_needle and normalized_needle in normalized_haystack)


def surface_names(run_artifact: dict[str, Any], key: str) -> list[str]:
    if key == "tools_used":
        names = []
        for item in run_artifact.get("tool_calls") or []:
            if not isinstance(item, dict):
                continue
            name = item.get("name") or item.get("tool") or item.get("id")
            if name:
                names.append(str(name))
        return sorted(set(names))
    return sorted(set(str(item) for item in (run_artifact.get(key) or [])))


def workflow_trace(run_artifact: dict[str, Any]) -> list[str]:
    trace = [str(item) for item in (run_artifact.get("workflow_trace") or [])]
    if trace:
        return trace
    labels: list[str] = []
    for item in run_artifact.get("trace_events") or []:
        if isinstance(item, dict):
            label = item.get("label")
            if label:
                labels.append(str(label))
    return labels


def contains_sequence(trace: list[str], expected: list[str]) -> bool:
    if not expected:
        return True
    index = 0
    for step in trace:
        if index < len(expected) and step == expected[index]:
            index += 1
            if index == len(expected):
                return True
    return index == len(expected)


def _trace_at_step(event: dict[str, Any], step: int) -> bool:
    return event.get("step_index") == step or event.get("step") == step


def score_conversation_turns(run_artifact: dict[str, Any], case: dict[str, Any]) -> list[dict[str, Any]]:
    """Score each turn in a multi-turn conversation."""
    turns = case.get("turns", [])
    if not turns:
        return []

    expected_turns = case.get("metadata", {}).get("expected_turns", [])
    if not expected_turns:
        return []

    results = []

    for idx, expected in enumerate(expected_turns):
        step_index = int(expected.get("step", idx))

        expected_tools = [str(t) for t in expected.get("expected_tools", [])]
        expected_skills = [str(t) for t in expected.get("expected_skills", [])]

        used_tools = set(surface_names(run_artifact, "tools_used"))
        used_skills = set(run_artifact.get("skills_used", []))

        passed = True
        failures = []

        for tool in expected_tools:
            if tool not in used_tools:
                passed = False
                failures.append(f"missing tool at step {step_index}: {tool}")

        for skill in expected_skills:
            if skill not in used_skills:
                passed = False
                failures.append(f"missing skill at step {step_index}: {skill}")

        results.append(
            {
                "name": f"turn_{idx}_alignment",
                "value": 0.0 if failures else 1.0,
                "passed": passed,
                "reason": "; ".join(failures) if failures else f"turn {idx} aligned",
                "turn_index": idx,
                "turn_role": turns[idx].get("role") if idx < len(turns) else None,
            }
        )

    return results


__all__ = [
    "_contains_text",
    "surface_names",
    "workflow_trace",
    "contains_sequence",
    "score_conversation_turns",
]
