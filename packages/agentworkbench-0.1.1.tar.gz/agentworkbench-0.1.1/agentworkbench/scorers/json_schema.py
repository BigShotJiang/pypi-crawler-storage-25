from __future__ import annotations

import json
from typing import Any


def _structured_output_candidate(run_artifact: dict[str, Any]) -> tuple[Any, str]:
    structured_output = run_artifact.get("structured_output")
    if isinstance(structured_output, dict) and structured_output:
        nested_output = structured_output.get("structured_output")
        if isinstance(nested_output, (dict, list)):
            return nested_output, "structured_output.structured_output"
        return structured_output, "structured_output"
    final_output = str(run_artifact.get("final_output") or "").strip()
    if not final_output or final_output[0] not in "{[":
        return None, "none"
    try:
        return json.loads(final_output), "final_output"
    except json.JSONDecodeError:
        return None, "none"


def _json_type_name(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return type(value).__name__


def _validate_json_schema(value: Any, schema: dict[str, Any], path: str = "$") -> list[str]:
    errors: list[str] = []
    expected_type = str(schema.get("type") or "").strip()
    if expected_type:
        matches_type = {
            "object": isinstance(value, dict),
            "array": isinstance(value, list),
            "string": isinstance(value, str),
            "number": isinstance(value, (int, float)) and not isinstance(value, bool),
            "integer": isinstance(value, int) and not isinstance(value, bool),
            "boolean": isinstance(value, bool),
            "null": value is None,
        }.get(expected_type, True)
        if not matches_type:
            return [f"{path}: expected {expected_type}, got {_json_type_name(value)}"]
    enum_values = schema.get("enum")
    if isinstance(enum_values, list) and enum_values and value not in enum_values:
        errors.append(f"{path}: value {value!r} not in enum {enum_values!r}")
    if isinstance(value, dict):
        required = [str(item) for item in schema.get("required", []) if str(item).strip()]
        for key in required:
            if key not in value:
                errors.append(f"{path}: missing required property `{key}`")
        properties = schema.get("properties") or {}
        if isinstance(properties, dict):
            for key, child_schema in properties.items():
                if key not in value or not isinstance(child_schema, dict):
                    continue
                errors.extend(_validate_json_schema(value[key], child_schema, f"{path}.{key}"))
    if isinstance(value, list):
        min_items = schema.get("minItems")
        max_items = schema.get("maxItems")
        if min_items is not None and len(value) < int(min_items):
            errors.append(f"{path}: expected at least {int(min_items)} items, got {len(value)}")
        if max_items is not None and len(value) > int(max_items):
            errors.append(f"{path}: expected at most {int(max_items)} items, got {len(value)}")
        items_schema = schema.get("items")
        if isinstance(items_schema, dict):
            for index, item in enumerate(value):
                errors.extend(_validate_json_schema(item, items_schema, f"{path}[{index}]"))
    return errors


def score_json_schema_adherence(run_artifact: dict[str, Any], case: dict[str, Any]) -> dict[str, Any] | None:
    metadata = case.get("metadata") or {}
    schema = metadata.get("structured_output_schema")
    if schema is None:
        schema = metadata.get("json_schema")
    if not isinstance(schema, dict):
        return None
    candidate, source = _structured_output_candidate(run_artifact)
    if source == "none":
        return {
            "name": "json_schema_adherence",
            "value": 0.0,
            "passed": False,
            "reason": "no structured output was available for schema validation",
            "weight": 0.0,
            "validation_errors": ["$: no structured output was available for schema validation"],
        }
    validation_errors = _validate_json_schema(candidate, schema)
    passed = not validation_errors
    return {
        "name": "json_schema_adherence",
        "value": 1.0 if passed else 0.0,
        "passed": passed,
        "reason": f"{source} matched the configured schema" if passed else "; ".join(validation_errors[:4]),
        "weight": 0.0,
        "validation_errors": validation_errors,
        "structured_output_source": source,
    }


__all__ = [
    "score_json_schema_adherence",
    "_validate_json_schema",
]
