"""Centralized threshold configuration for Agent Workbench.

This module provides a single source of truth for all threshold values,
preventing magic numbers scattered throughout the codebase.

Thresholds can be loaded from:
1. Environment variables (prefixed with AWB_THRESHOLD_)
2. workbench.yaml configuration
3. Sensible defaults (these constants)

Usage:
    from agentworkbench.thresholds import load_thresholds, get_threshold

    # Load all thresholds for a project
    thresholds = load_thresholds(project_root)
    score_weights = thresholds.scoring.default_weights

    # Get specific threshold
    confidence_high = get_threshold("confidence_high", project_root)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agentworkbench.config import find_project_root


@dataclass
class ScoringWeights:
    """Scoring weight configuration."""

    output_quality: float = 0.7
    process_alignment: float = 0.3


@dataclass
class ConfidenceThresholds:
    """Confidence thresholds for trace quality and scoring."""

    high: float = 0.8
    high_confidence: float = 0.95
    medium: float = 0.5
    medium_confidence: float = 0.7
    scorer_audit_default: float = 0.7
    ci_width_default: float = 0.25


@dataclass
class EvidenceThresholds:
    """Evidence matching thresholds."""

    overlap: float = 0.6  # 60% token overlap required
    min_tokens: int = 3
    use_rate_low: float = 0.5  # 50% - below this is "low usage"
    use_rate_good: float = 0.75  # 75% - above this is "good"


@dataclass
class Timeouts:
    """Timeout configuration in seconds."""

    command: int = 300  # Command-line agents
    python: int = 300  # Python function agents
    provider: int = 60  # API provider agents
    default: int = 300


@dataclass
class WorkflowLimits:
    """Workflow configuration."""

    max_steps_per_case: int = 8
    brief_max_steps: int = 6


@dataclass
class StatisticalConstants:
    """Statistical constants."""

    ci_95_zscore: float = 1.96
    near_zero_threshold: float = 1e-9


@dataclass
class PriorityScores:
    """Priority scores for surface recommendations."""

    error_fix: int = 100
    keep_enabled_grounding: int = 90
    strong_interaction: int = 60
    healthy_current_surface: int = 55


@dataclass
class CLIDefaults:
    """CLI default values."""

    focus_limit: int = 5
    jobs: int = 1
    repeat: int = 1
    limit_status: int = 10
    limit_next: int = 3
    limit_propose: int = 3
    limit_iterate: int = 3
    limit_release: int = 20
    brief_limit: int = 6
    failure_limit: int = 4
    search_budget: int = 6
    proposal_followup: int = 3


@dataclass
class AblationConfig:
    """Ablation search configuration."""

    min_experiments: int = 4
    max_ablation_per_surface: int = 2
    require_improvement: float = 0.01


@dataclass
class BayesianConfig:
    """Bayesian optimization configuration."""

    n_initial: int = 4  # Random samples before Bayesian starts
    n_iterations: int = 8
    acq_function: str = "ei"  # Expected Improvement
    surrogate: str = "gp"  # Gaussian Process
    minimize_noise: float = 0.01


@dataclass
class ActiveLearningConfig:
    """Active learning configuration."""

    uncertainty_threshold: float = 0.3
    diversity_weight: float = 0.2
    coverage_weight: float = 0.3
    max_queries_per_round: int = 3


@dataclass
class HumanHintConfig:
    """Human-in-the-loop hint configuration."""

    # When to ask for hints vs. full answers
    hint_on_uncertainty: bool = True
    hint_confidence_threshold: float = 0.4  # Ask if confidence below this
    hint_max_attempts: int = 3
    hint_requester: str = "auto"  # auto, always, never

    # What kinds of hints to request
    hint_kinds: list[str] = field(
        default_factory=lambda: [
            "direction",  # "try higher temperature"
            "priority",  # "this matters more"
            "alternative",  # "consider X instead"
            "correction",  # "you're close but X"
        ]
    )


@dataclass
class Thresholds:
    """All thresholds - use load_thresholds() to create."""

    scoring: ScoringWeights = field(default_factory=ScoringWeights)
    confidence: ConfidenceThresholds = field(default_factory=ConfidenceThresholds)
    evidence: EvidenceThresholds = field(default_factory=EvidenceThresholds)
    timeouts: Timeouts = field(default_factory=Timeouts)
    workflow: WorkflowLimits = field(default_factory=WorkflowLimits)
    stats: StatisticalConstants = field(default_factory=StatisticalConstants)
    priority: PriorityScores = field(default_factory=PriorityScores)
    cli: CLIDefaults = field(default_factory=CLIDefaults)
    ablation: AblationConfig = field(default_factory=AblationConfig)
    bayesian: BayesianConfig = field(default_factory=BayesianConfig)
    active_learning: ActiveLearningConfig = field(default_factory=ActiveLearningConfig)
    human_hint: HumanHintConfig = field(default_factory=HumanHintConfig)


def _get_env_overrides() -> dict[str, Any]:
    """Get threshold overrides from environment variables."""
    overrides: dict[str, float | int | str] = {}
    prefix = "AWB_THRESHOLD_"

    for key, value in os.environ.items():
        if key.startswith(prefix):
            threshold_name = key[len(prefix) :].lower()
            # Try to parse as number
            try:
                if "." in value:
                    overrides[threshold_name] = float(value)
                else:
                    overrides[threshold_name] = int(value)
            except ValueError:
                overrides[threshold_name] = value

    return overrides


def get_threshold(name: str, project_root: Path | None = None) -> float | int | str:
    """Get a specific threshold by name.

    Args:
        name: Threshold name (e.g., "confidence_high", "timeout_command")
        project_root: Optional project root for config loading

    Returns:
        The threshold value
    """
    thresholds = load_thresholds(project_root)

    # Navigate the nested structure
    parts = name.split("_")
    obj: Any = thresholds
    for part in parts:
        if hasattr(obj, part):
            obj = getattr(obj, part)
        else:
            raise ValueError(f"Unknown threshold: {name}")

    if isinstance(obj, (float, int, str)):
        return obj
    raise ValueError(f"Threshold `{name}` does not resolve to a scalar value.")


def load_thresholds(project_root: Path | None = None) -> Thresholds:
    """Load thresholds with environment overrides and workbench.yaml config.

    Priority order:
    1. Environment variable (AWB_THRESHOLD_*)
    2. workbench.yaml configuration
    3. Sensible defaults (these constants)

    Args:
        project_root: Optional project root for config loading

    Returns:
        Thresholds dataclass with all configured values
    """
    root = find_project_root(project_root)
    env_overrides = _get_env_overrides()

    # Start with defaults
    thresholds = Thresholds()

    # Apply environment overrides to CLI defaults
    if "cli_focus_limit" in env_overrides:
        thresholds.cli.focus_limit = env_overrides["cli_focus_limit"]
    if "cli_jobs" in env_overrides:
        thresholds.cli.jobs = env_overrides["cli_jobs"]
    if "cli_limit_status" in env_overrides:
        thresholds.cli.limit_status = env_overrides["cli_limit_status"]
    if "confidence_high" in env_overrides:
        thresholds.confidence.high = env_overrides["confidence_high"]
    if "confidence_medium" in env_overrides:
        thresholds.confidence.medium = env_overrides["confidence_medium"]
    if "evidence_overlap" in env_overrides:
        thresholds.evidence.overlap = env_overrides["evidence_overlap"]
    if "timeout_command" in env_overrides:
        thresholds.timeouts.command = env_overrides["timeout_command"]
    if "timeout_provider" in env_overrides:
        thresholds.timeouts.provider = env_overrides["timeout_provider"]

    # Try to load from workbench.yaml config
    try:
        from agentworkbench.config import load_config

        config = load_config(root)
        if hasattr(config, "thresholds") and config.thresholds:
            config_thresholds = config.thresholds
            # Apply config overrides
            if hasattr(config_thresholds, "scoring_weights"):
                thresholds.scoring = config_thresholds.scoring_weights
            if hasattr(config_thresholds, "confidence"):
                thresholds.confidence = config_thresholds.confidence
            if hasattr(config_thresholds, "evidence"):
                thresholds.evidence = config_thresholds.evidence
            if hasattr(config_thresholds, "timeouts"):
                thresholds.timeouts = config_thresholds.timeouts
            if hasattr(config_thresholds, "cli"):
                thresholds.cli = config_thresholds.cli
    except Exception:
        pass  # Config loading is optional

    return thresholds


# Convenience accessors for common thresholds
def scoring_weights() -> ScoringWeights:
    """Get default scoring weights."""
    return ScoringWeights()


def confidence_thresholds() -> ConfidenceThresholds:
    """Get default confidence thresholds."""
    return ConfidenceThresholds()


def evidence_thresholds() -> EvidenceThresholds:
    """Get default evidence thresholds."""
    return EvidenceThresholds()


def timeouts() -> Timeouts:
    """Get default timeouts."""
    return Timeouts()


def cli_defaults() -> CLIDefaults:
    """Get default CLI values."""
    return CLIDefaults()


def bayesian_config() -> BayesianConfig:
    """Get Bayesian optimization configuration."""
    return BayesianConfig()


def active_learning_config() -> ActiveLearningConfig:
    """Get active learning configuration."""
    return ActiveLearningConfig()


def human_hint_config() -> HumanHintConfig:
    """Get human hint configuration."""
    return HumanHintConfig()


__all__ = [
    "Thresholds",
    "ScoringWeights",
    "ConfidenceThresholds",
    "EvidenceThresholds",
    "Timeouts",
    "WorkflowLimits",
    "StatisticalConstants",
    "PriorityScores",
    "CLIDefaults",
    "AblationConfig",
    "BayesianConfig",
    "ActiveLearningConfig",
    "HumanHintConfig",
    "load_thresholds",
    "get_threshold",
    "scoring_weights",
    "confidence_thresholds",
    "evidence_thresholds",
    "timeouts",
    "cli_defaults",
    "bayesian_config",
    "active_learning_config",
    "human_hint_config",
]
