from __future__ import annotations

import itertools
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.models import AgentSpec, ExperimentRecord
from agentworkbench.optimization_utils import write_temp_agent_spec
from agentworkbench.reports import render_matrix_report, write_report
from agentworkbench.runner import _pareto_frontier, _record_summary, load_agent_spec, run_experiment
from agentworkbench.utils import created_at_utc, ensure_dir, slugify, write_json


def matrix_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "matrices")


def _variant_spec(
    base_spec: AgentSpec,
    *,
    matrix_id: str,
    temperature: float | None,
    max_tokens: int | None,
) -> AgentSpec:
    clone = base_spec.model_copy(deep=True)
    if temperature is not None:
        clone.model["temperature"] = float(temperature)
    if max_tokens is not None:
        clone.model["max_tokens"] = int(max_tokens)
    variant_suffix = []
    if temperature is not None:
        variant_suffix.append(f"temp-{slugify(str(temperature))}")
    if max_tokens is not None:
        variant_suffix.append(f"max-{slugify(str(max_tokens))}")
    if variant_suffix:
        clone.id = f"{base_spec.id}-matrix-{'-'.join(variant_suffix)}"
    clone.metadata = {
        **(clone.metadata or {}),
        "matrix": {
            "matrix_id": matrix_id,
            "source_agent_id": base_spec.id,
            "temperature": clone.model.get("temperature"),
            "max_tokens": clone.model.get("max_tokens"),
        },
    }
    return clone
def run_experiment_matrix(
    project_root: Path,
    *,
    agent_ids: list[str],
    eval_id: str,
    subset: str,
    temperatures: list[float] | None = None,
    max_tokens: list[int] | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
    keep_specs: bool = False,
) -> dict[str, Any]:
    if not agent_ids:
        raise ValueError("Provide at least one --agent-id for the matrix run.")
    matrix_id = f"matrix-{slugify(eval_id)}-{slugify(subset)}"
    temperature_axis: list[float | None] = list(temperatures) if temperatures else [None]
    max_tokens_axis: list[int | None] = list(max_tokens) if max_tokens else [None]
    records: list[ExperimentRecord] = []
    temp_paths: list[Path] = []
    try:
        for agent_id in agent_ids:
            base_spec = load_agent_spec(project_root, agent_id)
            for temperature, max_token_value in itertools.product(temperature_axis, max_tokens_axis):
                variant = _variant_spec(
                    base_spec,
                    matrix_id=matrix_id,
                    temperature=temperature,
                    max_tokens=max_token_value,
                )
                if variant.id != agent_id:
                    temp_paths.append(write_temp_agent_spec(project_root, variant))
                record, _aggregate = run_experiment(
                    project_root,
                    variant.id,
                    eval_id,
                    subset,
                    case_ids=case_ids,
                    tags=tags,
                    match=match,
                    limit=limit,
                )
                records.append(record)
    finally:
        if not keep_specs:
            for path in temp_paths:
                if path.exists():
                    path.unlink()
    ordered = sorted(records, key=lambda item: (float(item.scores.get("average_score", 0.0)), item.created_at, item.experiment_id), reverse=True)
    frontier = _pareto_frontier(records)
    payload = {
        "matrix_id": matrix_id,
        "created_at": created_at_utc(),
        "agent_ids": agent_ids,
        "eval_id": eval_id,
        "subset": subset,
        "benchmark_signatures": sorted({record.benchmark_signature for record in records if record.benchmark_signature}),
        "temperatures": [value for value in temperature_axis if value is not None],
        "max_tokens": [value for value in max_tokens_axis if value is not None],
        "case_ids": case_ids or [],
        "tags": tags or [],
        "match": match or "",
        "limit": limit,
        "experiment_count": len(records),
        "experiments": [_record_summary(record) for record in ordered],
        "pareto_frontier": [_record_summary(record) for record in frontier],
        "best_by_score": _record_summary(ordered[0]) if ordered else None,
        "cheapest": _record_summary(sorted(records, key=lambda item: float(item.behavior_summary.get("average_cost_estimate", 0.0)))[0]) if records else None,
        "fastest": _record_summary(sorted(records, key=lambda item: float(item.behavior_summary.get("average_latency_ms", 0.0)))[0]) if records else None,
        "temporary_spec_paths": [str(path.relative_to(project_root)) for path in temp_paths if path.exists()],
    }
    root = matrix_dir(project_root)
    write_json(root / f"{matrix_id}.json", payload)
    write_json(root / "latest.json", payload)
    write_report(root / f"{matrix_id}.md", render_matrix_report(payload))
    write_report(root / "latest.md", render_matrix_report(payload))
    return payload
