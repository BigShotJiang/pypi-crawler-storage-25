"""Active Learning for intelligent case selection.

This module selects the most informative cases to evaluate, reducing
the number of cases needed to understand agent performance.

Usage:
    from agentworkbench.active_learning import ActiveLearningSelector

    selector = ActiveLearningSelector(
        similarity_fn=compute_case_similarity,
        uncertainty_fn=estimate_case_difficulty,
    )

    # Prioritize cases for evaluation
    prioritized = selector.prioritize(
        cases=eval_cases,
        run_history=prior_runs,
        max_select=10,
    )

    # After getting results, update uncertainty estimates
    selector.update(case_id, passed=True)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CaseFeatures:
    """Extracted features for a case."""

    id: str
    difficulty_estimate: float = 0.5  # How hard is this case?
    uncertainty: float = 0.5  # How confident is our prediction?
    diversity_score: float = 0.0  # How different from others?
    coverage_score: float = 0.0  # How much does it cover?
    priority: float = 0.5  # Final priority


class ActiveLearningSelector:
    """Selects informative cases using active learning.

    Uses uncertainty sampling, diversity, and coverage to select
    cases that will teach the most about agent performance.
    """

    def __init__(
        self,
        uncertainty_weight: float = 0.3,
        diversity_weight: float = 0.2,
        coverage_weight: float = 0.3,
        difficulty_weight: float = 0.2,
    ):
        self.uncertainty_weight = uncertainty_weight
        self.diversity_weight = diversity_weight
        self.coverage_weight = coverage_weight
        self.difficulty_weight = difficulty_weight

        self._case_features: dict[str, CaseFeatures] = {}
        self._case_embeddings: dict[str, list[float]] = {}
        self._run_results: dict[str, bool] = {}  # case_id -> passed

    def compute_features(
        self,
        cases: list[dict],
        run_history: list[dict] | None = None,
    ) -> dict[str, CaseFeatures]:
        """Extract features for all cases.

        Args:
            cases: List of eval case dicts
            run_history: Optional historical runs
        """
        # Compute difficulty from history
        difficulty = self._compute_difficulty(cases, run_history)

        # Extract IDs
        case_ids = [c.get("id", str(i)) for i, c in enumerate(cases)]

        for cid in case_ids:
            self._case_features[cid] = CaseFeatures(
                id=cid,
                difficulty_estimate=difficulty.get(cid, 0.5),
                uncertainty=0.5 if run_history is None else 0.3,
            )

        # Compute embeddings for diversity
        self._compute_embeddings(cases)

        # Compute diversity scores
        self._update_diversity_scores(case_ids)

        # Compute coverage
        self._update_coverage_scores(cases, case_ids)

        return self._case_features

    def _compute_difficulty(
        self,
        cases: list[dict],
        history: list[dict] | None,
    ) -> dict[str, float]:
        """Estimate case difficulty from history."""
        if not history:
            return {}

        # Count failures per case
        failures: dict[str, int] = {}
        total: dict[str, int] = {}

        for run in history:
            case_id = run.get("case", {}).get("id")
            passed = run.get("passed", False)

            if case_id:
                total[case_id] = total.get(case_id, 0) + 1
                if not passed:
                    failures[case_id] = failures.get(case_id, 0) + 1

        # Difficulty = failure rate
        return {
            cid: failures.get(cid, 0) / max(1, total.get(cid, 1))
            for cid in [c.get("id", str(i)) for i, c in enumerate(cases)]
        }

    def _compute_embeddings(self, cases: list[dict]) -> None:
        """Compute simple embeddings for diversity calculation."""
        for i, case in enumerate(cases):
            case_id = case.get("id", str(i))

            # Simple hash-based embedding for demonstration
            # In practice, use actual embeddings from model
            text = str(case.get("input") or case.get("prompt") or "") + str(case.get("id", ""))

            # Simple bag of words as embedding
            words = set(text.lower().split())
            embedding = [1.0 if w in words else 0.0 for w in self._get_vocab(cases)]

            # Normalize
            norm = sum(e**2 for e in embedding) ** 0.5
            if norm > 0:
                embedding = [e / norm for e in embedding]

            self._case_embeddings[case_id] = embedding

    def _get_vocab(self, cases: list[dict]) -> set[str]:
        """Build vocabulary from all cases."""
        vocab = set()
        for case in cases:
            text = str(case.get("input") or case.get("prompt") or "") + str(case.get("id", ""))
            vocab.update(text.lower().split())
        return vocab

    def _update_diversity_scores(self, case_ids: list[str]) -> None:
        """Update diversity scores based on embeddings."""
        if len(case_ids) < 2:
            return

        # Compute average pairwise distances
        for cid in case_ids:
            emb = self._case_embeddings.get(cid, [0])

            if not emb:
                continue

            distances = []
            for other_id in case_ids:
                if other_id == cid:
                    continue

                other_emb = self._case_embeddings.get(other_id, [0])
                if other_emb:
                    dist = sum((a - b) ** 2 for a, b in zip(emb, other_emb, strict=True)) ** 0.5
                    distances.append(dist)

            if distances:
                avg_dist = sum(distances) / len(distances)
                if cid in self._case_features:
                    self._case_features[cid].diversity_score = avg_dist

    def _update_coverage_scores(self, cases: list[dict], case_ids: list[str]) -> None:
        """Update coverage - how much skill surface is tested."""
        # Map case tags to surfaces
        surface_cases: dict[str, list[str]] = {}

        for case in cases:
            case_id = case.get("id", "")
            tags = case.get("tags", [])

            for tag in tags:
                if tag not in surface_cases:
                    surface_cases[tag] = []
                surface_cases[tag].append(case_id)

        # Score = how many different skills does this case test?
        for cid in case_ids:
            if cid not in self._case_features:
                continue

            surfaces_tested = set()
            for case in cases:
                if case.get("id", "") == cid:
                    surfaces_tested.update(case.get("tags", []))

            coverage = len(surfaces_tested) / max(1, len(surface_cases))
            self._case_features[cid].coverage_score = coverage

    def prioritize(
        self,
        cases: list[dict],
        run_history: list[dict] | None = None,
        max_select: int = 10,
    ) -> list[str]:
        """Select most informative cases.

        Args:
            cases: List of eval cases
            run_history: Optional prior runs
            max_select: Maximum cases to select

        Returns:
            Prioritized list of case IDs
        """
        # Compute features
        self.compute_features(cases, run_history)

        # Compute priority scores
        for feats in self._case_features.values():
            priority = (
                self.uncertainty_weight * feats.uncertainty
                + self.diversity_weight * feats.diversity_score
                + self.coverage_weight * feats.coverage_score
                + self.difficulty_weight * feats.difficulty_estimate
            )
            feats.priority = priority

        # Sort by priority
        sorted_cases = sorted(
            self._case_features.values(),
            key=lambda x: x.priority,
            reverse=True,
        )

        return [c.id for c in sorted_cases[:max_select]]

    def update(self, case_id: str, passed: bool) -> None:
        """Update uncertainty after getting result.

        Args:
            case_id: The case that was run
            passed: Whether it passed
        """
        self._run_results[case_id] = passed

        # Reduce uncertainty for similar cases
        if case_id not in self._case_embeddings:
            return

        case_emb = self._case_embeddings[case_id]

        for cid, emb in self._case_embeddings.items():
            if cid == case_id:
                continue

            # Update uncertainty for similar cases
            similarity = sum(a * b for a, b in zip(case_emb, emb, strict=True))

            if similarity > 0.8 and cid in self._case_features:
                # Similar case - reduce uncertainty
                old_u = self._case_features[cid].uncertainty
                self._case_features[cid].uncertainty = max(0.1, old_u - 0.1)


class UncertaintySampler:
    """Selects cases with highest uncertainty.

    Simple uncertainty sampling - prioritize cases where
    we're least confident in predictions.
    """

    def __init__(self, threshold: float = 0.3):
        self.threshold = threshold
        self._uncertainty: dict[str, float] = {}

    def set_uncertainty(self, case_id: str, uncertainty: float) -> None:
        """Set uncertainty for a case."""
        self._uncertainty[case_id] = uncertainty

    def sample(
        self,
        cases: list[dict],
        n: int = 5,
    ) -> list[str]:
        """Sample uncertain cases."""
        # Get uncertainty values
        uncertainties = []
        for i, c in enumerate(cases):
            case_id = c.get("id", str(i))
            unc = self._uncertainty.get(case_id, 0.5)
            uncertainties.append((case_id, unc))

        # Sort by uncertainty descending
        uncertainties.sort(key=lambda x: x[1], reverse=True)

        # Return top n
        return [c[0] for c in uncertainties[:n]]


class DiversitySampler:
    """Selects diverse cases.

    Maximizes diversity to cover different scenarios.
    """

    def sample(
        self,
        cases: list[dict],
        n: int = 5,
    ) -> list[str]:
        """Sample diverse cases."""
        # Simple: pick from different tag categories
        by_tag: dict[str, list[str]] = {}

        for case in cases:
            case_id = case.get("id", "")
            for tag in case.get("tags", []):
                if tag not in by_tag:
                    by_tag[tag] = []
                by_tag[tag].append(case_id)

        # Pick from each tag
        selected = []
        for case_ids in by_tag.values():
            if case_ids:
                selected.append(case_ids[0])
                if len(selected) >= n:
                    break

        # Fill remaining with random
        all_ids = [c.get("id", "") for c in cases]
        while len(selected) < n and all_ids:
            import random

            idx = random.randint(0, len(all_ids) - 1)
            if all_ids[idx] not in selected:
                selected.append(all_ids[idx])
            all_ids = [i for i in all_ids if i != all_ids[idx]]

        return selected[:n]


@dataclass
class ActiveLearningConfig:
    """Configuration for active learning."""

    uncertainty_weight: float = 0.3
    diversity_weight: float = 0.2
    coverage_weight: float = 0.3
    difficulty_weight: float = 0.2
    max_queries_per_round: int = 3
    uncertainty_threshold: float = 0.3


__all__ = [
    "ActiveLearningSelector",
    "UncertaintySampler",
    "DiversitySampler",
    "CaseFeatures",
    "ActiveLearningConfig",
]
