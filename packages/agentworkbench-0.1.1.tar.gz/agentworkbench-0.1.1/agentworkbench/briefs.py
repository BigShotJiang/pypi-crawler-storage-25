from __future__ import annotations

import copy
from pathlib import Path, PurePosixPath

from agentworkbench.config import control_dir, dump_model, load_model
from agentworkbench.human_review import brief_human_checkpoints, build_review_queue
from agentworkbench.human_review_store import pending_review_items, resolve_review_queue
from agentworkbench.models import AgentSpec, BehaviorBrief, EvalSuiteSpec
from agentworkbench.reports import render_brief_packet, write_report
from agentworkbench.utils import enabled_item_names, ensure_dir, read_json, read_jsonl, write_json


def brief_path(project_root: Path, brief_id: str) -> Path:
    return control_dir(project_root) / "briefs" / f"{brief_id}.yaml"


def brief_packet_path(project_root: Path, brief_id: str) -> Path:
    return control_dir(project_root) / "briefs" / f"{brief_id}.packet.md"


def _default_brief(brief_id: str, goal: str = "") -> BehaviorBrief:
    default_questions = [
        "What end-user tasks should the target agent handle reliably?",
        "Which failure modes are unacceptable for this target agent?",
        "What tone, structure, and grounding constraints matter in good answers?",
        "Which prompts, tools, memory systems, plugins, or MCP servers should the agent rely on or avoid?",
        "What latency, cost, or step-budget constraints matter during optimization?",
    ]
    return BehaviorBrief(
        id=brief_id,
        goal=goal,
        target_questions=default_questions,
        desired_behaviors=["Ground answers in the repo context and the target agent's implemented behavior before answering."],
        non_goals=["Do not invent capabilities that the repo does not support."],
        preferred_tools=[],
        preferred_skills=[],
        preferred_plugins=[],
        preferred_mcps=[],
        prompt_variants=["system"],
        likely_user_commands=[
            "Add the most common end-user request the target agent should handle here.",
        ],
        rough_answer_outlines=[
            {
                "question": "Add a representative end-user request here",
                "outline": "Describe the rough shape of a strong target-agent answer without writing the full answer.",
            }
        ],
        workflow_scenarios=[
            {
                "name": "default-workflow",
                "trigger": "The end user asks the target agent to inspect local context and answer a task-oriented question.",
                "expected": "List the rough steps the target agent should take before answering, including any tools, memory, or MCP calls that matter.",
                "expected_tools": [],
                "expected_skills": [],
                "expected_plugins": [],
                "expected_mcps": [],
                "expected_prompt_keys": [],
                "max_steps": 6,
            }
        ],
        better_signals=["Answers are more grounded in the repo and use the right prompts, tools, memory, and MCP surfaces when needed."],
        worse_signals=["Answers add steps, tools, or integrations without improving the user-facing result."],
        examples=[{"question": "Add a representative end-user request here", "expected": "Describe the expected target-agent behavior"}],
        edge_cases=["Handle incomplete or ambiguous user questions explicitly without pretending missing context exists."],
        acceptance_criteria=["Answers should be accurate, grounded, actionable, and within the expected runtime budget."],
        approval_status="draft",
    )


def start_brief(project_root: Path, brief_id: str, goal: str = "") -> Path:
    brief = _default_brief(brief_id, goal=goal)
    path = brief_path(project_root, brief_id)
    ensure_dir(path.parent)
    return dump_model(path, brief)


def _related_eval_ids(spec: AgentSpec) -> list[str]:
    eval_ids: list[str] = []
    for item in (spec.surface_paths or {}).get("tests", []) or []:
        path = PurePosixPath(str(item))
        if path.parent.name != "evals" or path.suffix != ".jsonl":
            continue
        eval_ids.append(path.stem)
    return list(dict.fromkeys(eval_ids))


def _load_related_template_brief(project_root: Path, spec: AgentSpec) -> tuple[BehaviorBrief | None, str | None]:
    for eval_id in _related_eval_ids(spec):
        suite_file = control_dir(project_root) / "evals" / f"{eval_id}.suite.yaml"
        if not suite_file.exists():
            continue
        suite = load_model(suite_file, EvalSuiteSpec)
        linked_brief_id = str(suite.brief_id or "").strip()
        if not linked_brief_id:
            continue
        linked_path = brief_path(project_root, linked_brief_id)
        if not linked_path.exists():
            continue
        return load_model(linked_path, BehaviorBrief), linked_brief_id
    return None, None


def _load_related_eval_cases(project_root: Path, spec: AgentSpec) -> list[dict[str, object]]:
    cases: list[dict[str, object]] = []
    seen_ids: set[str] = set()
    for eval_id in _related_eval_ids(spec):
        eval_file = control_dir(project_root) / "evals" / f"{eval_id}.jsonl"
        if not eval_file.exists():
            continue
        for item in read_jsonl(eval_file):
            case_id = str(item.get("id") or "").strip()
            if not case_id or case_id in seen_ids:
                continue
            seen_ids.add(case_id)
            cases.append(item)
    return cases


def _goal_from_spec(spec: AgentSpec) -> str:
    purpose = str((spec.metadata or {}).get("purpose") or "").strip()
    if purpose:
        return f"Improve the `{spec.id}` agent for `{purpose}` tasks."
    source_demo = str((spec.metadata or {}).get("source_demo") or "").strip()
    if source_demo:
        return f"Improve the `{spec.id}` agent defined in `{source_demo}`."
    return f"Improve the `{spec.id}` agent."


def _workflow_scenarios_from_cases(cases: list[dict[str, object]], prompt_variants: list[str]) -> list[dict[str, object]]:
    scenarios: list[dict[str, object]] = []
    for case in cases:
        raw_tags = case.get("tags", [])
        tags = [str(item) for item in raw_tags if str(item).strip()] if isinstance(raw_tags, list) else []
        raw_metadata = case.get("metadata")
        metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
        raw_process_expectations = metadata.get("process_expectations")
        process_expectations = dict(raw_process_expectations) if isinstance(raw_process_expectations, dict) else {}
        if "workflow" not in tags and not process_expectations:
            continue
        scenario = {
            "name": str(case.get("id") or f"workflow-{len(scenarios) + 1}"),
            "trigger": str(case.get("input") or "").strip(),
            "expected": str(case.get("expected") or "").strip(),
            "expected_tools": [str(item) for item in process_expectations.get("required_tools", []) if str(item).strip()],
            "expected_skills": [str(item) for item in process_expectations.get("required_skills", []) if str(item).strip()],
            "expected_plugins": [str(item) for item in process_expectations.get("required_plugins", []) if str(item).strip()],
            "expected_mcps": [str(item) for item in process_expectations.get("required_mcps", []) if str(item).strip()],
            "expected_prompt_keys": [
                str(item) for item in process_expectations.get("required_prompt_keys", []) if str(item).strip()
            ] or list(prompt_variants),
            "max_steps": process_expectations.get("max_step_count", 6),
        }
        scenarios.append({key: value for key, value in scenario.items() if value not in (None, [], "")})
        if len(scenarios) >= 3:
            break
    return scenarios


def draft_brief(project_root: Path, brief_id: str, agent_id: str, goal: str = "") -> Path:
    spec_path = control_dir(project_root) / "agents" / f"{agent_id}.yaml"
    if not spec_path.exists():
        raise ValueError(f"Agent spec `{agent_id}` not found.")
    spec = load_model(spec_path, AgentSpec)
    template_brief, linked_brief_id = _load_related_template_brief(project_root, spec)
    if template_brief is not None:
        brief = template_brief.model_copy(deep=True)
        brief.id = brief_id
        brief.approval_status = "draft"
        if goal.strip():
            brief.goal = goal.strip()
        metadata = copy.deepcopy(dict(brief.metadata or {}))
        metadata["draft_source"] = {
            "mode": "linked_brief",
            "agent_id": agent_id,
            "linked_brief_id": linked_brief_id,
            "linked_eval_ids": _related_eval_ids(spec),
        }
        brief.metadata = metadata
    else:
        related_cases = _load_related_eval_cases(project_root, spec)
        prompt_variants = list(spec.prompts.keys()) or ["system"]
        brief = _default_brief(brief_id, goal=goal.strip() or _goal_from_spec(spec))
        brief.desired_behaviors = list(
            dict.fromkeys(
                [
                    "Ground answers in the repo context and the target agent's implemented behavior before answering.",
                    "Use the configured prompts, tools, skills, plugins, and MCPs deliberately instead of adding unused surface.",
                    *(["Respect the declared runtime constraints and required environment."] if spec.required_env else []),
                ]
            )
        )
        brief.non_goals = list(
            dict.fromkeys(
                [
                    "Do not invent capabilities that the repo does not support.",
                    "Do not keep extra tools, prompts, skills, plugins, or MCPs that do not improve benchmark behavior.",
                ]
            )
        )
        brief.preferred_tools = enabled_item_names(spec.tools)
        brief.preferred_skills = enabled_item_names(spec.skills)
        brief.preferred_plugins = enabled_item_names(spec.plugins)
        brief.preferred_mcps = enabled_item_names(spec.mcps)
        brief.prompt_variants = prompt_variants
        likely_user_commands = [
            str(item.get("input") or "").strip() for item in related_cases if str(item.get("input") or "").strip()
        ][:3]
        if likely_user_commands:
            brief.likely_user_commands = likely_user_commands
        rough_answer_outlines = [
            {
                "question": str(item.get("input") or "").strip(),
                "outline": str(item.get("expected") or "").strip(),
            }
            for item in related_cases
            if str(item.get("input") or "").strip() and str(item.get("expected") or "").strip()
        ][:3]
        if rough_answer_outlines:
            brief.rough_answer_outlines = rough_answer_outlines
        workflow_scenarios = _workflow_scenarios_from_cases(related_cases, prompt_variants)
        if workflow_scenarios:
            brief.workflow_scenarios = workflow_scenarios
        brief.better_signals = list(
            dict.fromkeys(
                [
                    "Answers are more grounded in the repo and use the right configured surfaces when needed.",
                    *(["The preferred tools are used only when they improve the result."] if brief.preferred_tools else []),
                    *(["The preferred MCPs are used when retrieval or memory is necessary."] if brief.preferred_mcps else []),
                ]
            )
        )
        brief.worse_signals = list(
            dict.fromkeys(
                [
                    "Answers add steps, tools, or integrations without improving the user-facing result.",
                    "The agent ignores configured prompts, tools, skills, plugins, or MCPs that should matter for benchmark cases.",
                ]
            )
        )
        brief.metadata = {
            **copy.deepcopy(dict(brief.metadata or {})),
            "draft_source": {
                "mode": "agent_spec",
                "agent_id": agent_id,
                "linked_eval_ids": _related_eval_ids(spec),
                "owned_paths": [str(item) for item in spec.owned_paths],
                "surface_paths": {
                    str(key): [str(item) for item in value or []] for key, value in (spec.surface_paths or {}).items() if value
                },
            },
        }
    path = brief_path(project_root, brief_id)
    ensure_dir(path.parent)
    return dump_model(path, brief)


def finalize_brief(project_root: Path, brief_id: str) -> Path:
    path = brief_path(project_root, brief_id)
    brief = load_model(path, BehaviorBrief)
    if not brief.goal.strip():
        raise ValueError("Behavior brief goal cannot be empty")
    if not brief.desired_behaviors:
        raise ValueError("Behavior brief must define at least one desired behavior")
    if not brief.acceptance_criteria:
        raise ValueError("Behavior brief must define at least one acceptance criterion")
    if not brief.better_signals:
        raise ValueError("Behavior brief must define at least one better signal")
    if not brief.worse_signals:
        raise ValueError("Behavior brief must define at least one worse signal")
    brief.approval_status = "approved"
    return dump_model(path, brief)


def build_brief_packet(project_root: Path, brief_id: str, agent_id: str | None = None) -> Path:
    brief = load_model(brief_path(project_root, brief_id), BehaviorBrief)
    discovery_path = control_dir(project_root) / "discovery" / "repo-summary.json"
    discovery = read_json(discovery_path) if discovery_path.exists() else {}
    agent_spec: AgentSpec | None = None
    repo_learning_prompts = [
        "Read `.agent-workbench/discovery/repo-brief.md` before drafting evals.",
        "Confirm which local files and commands actually define the target agent behavior before editing anything.",
    ]
    interview_prompts = [
        "Ask the user for the target job, failure modes, approval criteria, and runtime constraints.",
        "Collect representative end-user requests, workflows, and expected tool or memory usage before drafting evals.",
    ]
    confirmed_owned_files = list(discovery.get("confirmed_owned_files", []))
    unclaimed_candidate_files = list(discovery.get("unclaimed_candidate_files", []))
    surface_paths: dict[str, list[str]] = {}
    provider_hints = list(discovery.get("provider_hints", []))
    likely_env_keys = list(discovery.get("likely_env_keys", []))
    if agent_id:
        spec_path = control_dir(project_root) / "agents" / f"{agent_id}.yaml"
        if spec_path.exists():
            agent_spec = load_model(spec_path, AgentSpec)
            confirmed_owned_files = list(
                dict.fromkeys([*confirmed_owned_files, *[str(path) for path in agent_spec.owned_paths]])
            )
            surface_paths = {
                str(key): [str(path) for path in value or []]
                for key, value in agent_spec.surface_paths.items()
                if value
            }
            repo_learning_prompts = [
                "Read `.agent-workbench/discovery/repo-brief.md` before drafting evals.",
                "Confirm which local files and commands actually define the target agent behavior before editing anything.",
                "Inspect the confirmed owned files and surface paths before proposing any benchmark or code changes.",
            ]
            interview_prompts = [
                "Ask the user for the target job, failure modes, approval criteria, and runtime constraints.",
                "Collect representative end-user requests, workflows, and expected tool or memory usage before drafting evals.",
            ]
            if agent_spec.required_env:
                interview_prompts.append(
                    "Confirm which required environment variables must be present to run the target agent locally."
                )
    likely_commands = list(brief.likely_user_commands)
    likely_commands.extend(discovery.get("guessed_commands", {}).values())
    likely_questions = list(brief.target_questions)
    likely_questions.extend(discovery.get("suggested_user_questions", []))
    human_checkpoints = brief_human_checkpoints(brief, discovery, agent_spec)
    review_queue = build_review_queue(
        queue_id=f"brief-{brief_id}",
        stage="brief",
        subject=brief_id,
        checkpoints=human_checkpoints,
    )
    review_queue = resolve_review_queue(project_root, review_queue)
    packet = {
        "brief_id": brief_id,
        "agent_id": agent_id,
        "goal": brief.goal,
        "repo_learning_prompts": repo_learning_prompts,
        "interview_prompts": interview_prompts,
        "confirmed_owned_files": confirmed_owned_files,
        "surface_paths": surface_paths,
        "unclaimed_candidate_files": unclaimed_candidate_files,
        "provider_hints": provider_hints,
        "likely_env_keys": likely_env_keys,
        "likely_questions": list(dict.fromkeys(str(item) for item in likely_questions if str(item).strip())),
        "likely_commands": list(dict.fromkeys(str(item) for item in likely_commands if str(item).strip())),
        "rough_answer_outlines": brief.rough_answer_outlines,
        "workflow_scenarios": brief.workflow_scenarios,
        "prompt_variants": brief.prompt_variants,
        "preferred_tools": brief.preferred_tools,
        "preferred_skills": brief.preferred_skills,
        "preferred_plugins": brief.preferred_plugins,
        "preferred_mcps": brief.preferred_mcps,
        "better_signals": brief.better_signals,
        "worse_signals": brief.worse_signals,
        "acceptance_criteria": brief.acceptance_criteria,
        "human_checkpoints": pending_review_items(review_queue),
        "human_review_queue": review_queue,
    }
    write_json(control_dir(project_root) / "reports" / f"brief-review-queue-{brief_id}.json", review_queue)
    return write_report(brief_packet_path(project_root, brief_id), render_brief_packet(packet))
