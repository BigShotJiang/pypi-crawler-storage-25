from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from agentworkbench.constants import ARTIFACT_SCHEMA_VERSION


class CommandEntrypoint(BaseModel):
    argv: list[str] | None = None
    shell: str | None = None
    cwd: str = "."
    timeout_seconds: int = 300


class PythonEntrypoint(BaseModel):
    callable: str
    cwd: str = "."
    timeout_seconds: int = 300


class ProviderEntrypoint(BaseModel):
    provider: str | None = None
    base_url: str | None = None
    api_key_env: str | None = None
    timeout_seconds: int = 60
    cache_mode: Literal["auto", "off", "replay", "refresh"] = "auto"
    tool_format: Literal["full", "compact"] = "full"
    system_prompt_key: str | None = "system"
    prompt_keys: list[str] = Field(default_factory=list)
    user_prompt_template: str = "{input}"
    include_instructions: bool = True
    chain_context_mode: Literal["full", "compact", "off"] = "compact"
    headers: dict[str, str] = Field(default_factory=dict)
    extra_body: dict[str, Any] = Field(default_factory=dict)


class AcceptanceGates(BaseModel):
    min_average_score_delta: float = 0.0
    min_average_score: float | None = None
    min_passed_case_delta: int = 0
    require_clean_benchmark: bool = True
    max_average_latency_ms_delta: float | None = None
    max_average_step_count_delta: float | None = None
    max_average_cost_estimate_delta: float | None = None
    max_regressed_cases: int = 0
    governance_critical_tags: list[str] = Field(
        default_factory=list,
        description="Eval case tags (e.g. security, red-team) for a separate regression budget.",
    )
    max_regressed_governance_tag_cases: int | None = Field(
        default=None,
        description="Max regressions among cases with any governance_critical_tags; None uses max_regressed_cases.",
    )
    min_stability_runs: int = 1
    max_average_score_stddev: float | None = None
    max_average_latency_cv: float | None = None
    max_average_cost_cv: float | None = None
    require_baseline_stability: bool = False


class LoopCheckConfig(BaseModel):
    enabled: bool = True
    fail_on_severity: Literal["none", "critical", "high", "medium", "warning"] = "critical"
    block_promotion_on_critical: bool = True
    large_file_line_threshold: int = 500
    large_function_line_threshold: int = 80
    min_rationale_chars: int = 12
    expected_string_match_min_chars: int = 8
    ignored_paths: list[str] = Field(
        default_factory=lambda: [
            "tests/**",
            ".agent-workbench/evals/**",
            ".agent-workbench/scorers/**",
            ".agent-workbench/runs/**",
            ".agent-workbench/runs-live/**",
            ".agent-workbench/reports/**",
            ".agent-workbench/cache/**",
        ],
    )


class WorkbenchConfig(BaseModel):
    snapshot_mode: Literal["auto", "git", "filesystem"] = "auto"
    artifacts_dir: str = ".agent-workbench/runs"
    env_files: list[str] = Field(default_factory=list)
    gates: AcceptanceGates = Field(default_factory=AcceptanceGates)
    loop_checks: LoopCheckConfig = Field(default_factory=LoopCheckConfig)
    docker_compose_file: str | None = None
    service_name: str | None = None
    early_stop_consecutive_failures: int | None = Field(
        default=None,
        description="Abort sequential runs after N consecutive case failures. Ignored when case parallelism > 1.",
    )
    provider_concurrency_limits: dict[str, int] = Field(
        default_factory=dict,
        description="Per-provider concurrency ceilings (lowercase provider name -> max in-flight calls).",
    )


class AgentSpec(BaseModel):
    id: str
    adapter: str = "command"
    instructions: list[str] = Field(default_factory=list)
    prompts: dict[str, Any] = Field(default_factory=dict)
    model: dict[str, Any] = Field(default_factory=dict)
    tools: list[dict[str, Any]] = Field(default_factory=list)
    skills: list[dict[str, Any]] = Field(default_factory=list)
    plugins: list[dict[str, Any]] = Field(default_factory=list)
    mcps: list[dict[str, Any]] = Field(default_factory=list)
    owned_paths: list[str] = Field(default_factory=list)
    owned_globs: list[str] = Field(default_factory=list)
    surface_paths: dict[str, list[str]] = Field(default_factory=dict)
    required_env: list[str] = Field(default_factory=list)
    runtime: dict[str, Any] = Field(default_factory=dict)
    entrypoints: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class BehaviorBrief(BaseModel):
    id: str
    goal: str = ""
    target_questions: list[str] = Field(default_factory=list)
    desired_behaviors: list[str] = Field(default_factory=list)
    non_goals: list[str] = Field(default_factory=list)
    preferred_tools: list[str] = Field(default_factory=list)
    preferred_skills: list[str] = Field(default_factory=list)
    preferred_plugins: list[str] = Field(default_factory=list)
    preferred_mcps: list[str] = Field(default_factory=list)
    prompt_variants: list[str] = Field(default_factory=list)
    likely_user_commands: list[str] = Field(default_factory=list)
    rough_answer_outlines: list[dict[str, Any]] = Field(default_factory=list)
    workflow_scenarios: list[dict[str, Any]] = Field(default_factory=list)
    better_signals: list[str] = Field(default_factory=list)
    worse_signals: list[str] = Field(default_factory=list)
    examples: list[dict[str, Any]] = Field(default_factory=list)
    edge_cases: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    approval_status: Literal["draft", "approved"] = "draft"


class EvalSuiteSpec(BaseModel):
    id: str
    brief_id: str = ""
    approval_status: Literal["draft", "approved"] = "draft"
    score_weights: dict[str, float] = Field(default_factory=lambda: {"output_quality": 0.7, "process_alignment": 0.3})
    notes: list[str] = Field(default_factory=list)
    generated_case_count: int = 0
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChainStepConfig(BaseModel):
    """Configuration for a single step in a multi-agent chain."""

    agent_id: str
    handoff_template: str | None = None
    step_expectations: dict[str, Any] = Field(default_factory=dict)
    branch_condition: str | None = Field(
        default=None,
        description="Python expression evaluated against prior step_score; if False, skip this step.",
    )


class ChainContext(BaseModel):
    """Accumulated context passed between chain steps."""

    steps: list[dict[str, Any]] = Field(default_factory=list)
    original_input: str = ""
    case_id: str = ""
    accumulated_output: str = ""
    shared_context: dict[str, Any] = Field(default_factory=dict)
    aggregated_tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    aggregated_evidence: list[dict[str, Any]] = Field(default_factory=list)
    aggregated_trace_events: list[dict[str, Any]] = Field(default_factory=list)


class StepScore(BaseModel):
    """Score for a single step in a multi-agent chain."""

    agent_id: str
    step: int
    scores: list[dict[str, Any]] = Field(default_factory=list)
    passed: bool = False
    score: float = 0.0
    final_output_preview: str = ""
    latency_ms: int = 0
    errors: list[str] = Field(default_factory=list)


class ChainAggregate(BaseModel):
    """Aggregate metrics for a multi-agent chain run."""

    step_pass_rate: float = 0.0
    step_scores: dict[str, float] = Field(default_factory=dict)
    degrading_steps: list[str] = Field(default_factory=list)
    total_chain_latency_ms: int = 0
    total_chain_tokens: int = 0
    total_chain_cost: float = 0.0
    branch_skips: list[dict[str, Any]] = Field(default_factory=list)


class WorkflowNodeConfig(BaseModel):
    """Configuration for a node in a routed multi-agent workflow."""

    id: str
    agent_id: str = ""
    node_type: Literal["agent", "chain"] = "agent"
    chain_agent_ids: list[str] = Field(default_factory=list)
    chain_handoff_template: str | None = None
    handoff_template: str | None = None
    step_expectations: dict[str, Any] = Field(default_factory=dict)
    routing_mode: Literal["first", "all"] = "first"
    join_mode: Literal["none", "all", "any"] = "none"
    max_visits: int | None = None


class WorkflowEdgeConfig(BaseModel):
    """Directed transition between workflow nodes."""

    model_config = ConfigDict(populate_by_name=True)

    from_node: str = Field(alias="from")
    to_node: str = Field(alias="to")
    when: str | None = None
    label: str | None = None
    default: bool = False


class WorkflowSpec(BaseModel):
    """Declarative router-style workflow definition."""

    id: str
    start_at: str
    nodes: list[WorkflowNodeConfig] = Field(default_factory=list)
    edges: list[WorkflowEdgeConfig] = Field(default_factory=list)
    max_steps_per_case: int = 8


class WorkflowAggregate(BaseModel):
    """Aggregate metrics for a routed workflow run."""

    step_pass_rate: float = 0.0
    node_scores: dict[str, float] = Field(default_factory=dict)
    degrading_nodes: list[str] = Field(default_factory=list)
    total_workflow_latency_ms: int = 0
    executed_nodes: list[str] = Field(default_factory=list)
    terminal_node: str | None = None
    path_signature: str = ""
    route_decisions: list[dict[str, Any]] = Field(default_factory=list)
    unmatched_routes: list[dict[str, Any]] = Field(default_factory=list)
    fan_out_count: int = 0
    join_count: int = 0
    dead_end_count: int = 0
    loop_detected: bool = False
    duplicate_node_visits: list[str] = Field(default_factory=list)
    shared_context_keys: list[str] = Field(default_factory=list)


class ConversationMetrics(BaseModel):
    """Metrics for multi-turn conversations."""

    turn_count: int = 0
    tool_call_count: int = 0
    evidence_retrieval_count: int = 0
    escalation_detected: bool = False
    resolution_turn: int | None = None
    re_ask_count: int = 0
    avg_turn_latency_ms: float = 0.0


class EvalCase(BaseModel):
    id: str
    input: str
    expected: str = ""
    rubric: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    turns: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Multi-turn messages {role, content} for provider adapter; command adapter receives AWB_TURNS_JSON.",
    )


class RunArtifact(BaseModel):
    case_id: str
    agent_id: str
    final_output: str = ""
    structured_output: dict[str, Any] = Field(default_factory=dict)
    events: list[dict[str, Any]] = Field(default_factory=list)
    evidence_records: list[dict[str, Any]] = Field(default_factory=list)
    trace_events: list[dict[str, Any]] = Field(default_factory=list)
    trace_schema_version: str = "awb.trace.v1"
    trace_taxonomy: str = "awb.canonical.v1"
    workflow_trace: list[str] = Field(default_factory=list)
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    skills_used: list[str] = Field(default_factory=list)
    plugins_used: list[str] = Field(default_factory=list)
    mcp_servers_used: list[str] = Field(default_factory=list)
    prompt_keys_used: list[str] = Field(default_factory=list)
    step_count: int = 0
    latency_ms: int = 0
    token_usage: dict[str, int] = Field(default_factory=dict)
    cost_estimate: float = 0.0
    errors: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExperimentRecord(BaseModel):
    artifact_schema_version: str = ARTIFACT_SCHEMA_VERSION
    experiment_id: str
    parent_experiment_id: str | None = None
    series_id: str | None = None
    agent_id: str
    eval_id: str
    subset: str = ""
    created_at: str = ""
    benchmark_signature: str = ""
    spec_snapshot: dict[str, Any] = Field(default_factory=dict)
    repo_before: dict[str, Any]
    repo_after: dict[str, Any]
    changed_files: list[str] = Field(default_factory=list)
    benchmark_hashes: dict[str, str] = Field(default_factory=dict)
    benchmark_manifest: dict[str, Any] = Field(default_factory=dict)
    case_selection: dict[str, Any] = Field(default_factory=dict)
    selection_fingerprint: str = ""
    selected_case_ids: list[str] = Field(default_factory=list)
    completed_case_ids: list[str] = Field(default_factory=list)
    total_case_count: int = 0
    surface_snapshot: dict[str, Any] = Field(default_factory=dict)
    scores: dict[str, Any] = Field(default_factory=dict)
    behavior_summary: dict[str, Any] = Field(default_factory=dict)
    status: str = "completed"
    promotion_status: Literal["candidate", "promoted", "rejected"] = "candidate"
    promotion_notes: dict[str, Any] = Field(default_factory=dict)


class ComparisonRecord(BaseModel):
    artifact_schema_version: str = ARTIFACT_SCHEMA_VERSION
    baseline_id: str
    candidate_id: str
    comparison_mode: Literal["clean", "benchmark-changed"]
    metric_deltas: dict[str, float] = Field(default_factory=dict)
    behavior_deltas: dict[str, Any] = Field(default_factory=dict)
    spec_changes: dict[str, Any] = Field(default_factory=dict)
    changed_cases: list[dict[str, Any]] = Field(default_factory=list)
    baseline_ladder: dict[str, Any] = Field(default_factory=dict)
    benchmark_changes: list[str] = Field(default_factory=list)
    repo_changes: list[str] = Field(default_factory=list)
    repo_change_summary: dict[str, Any] = Field(default_factory=dict)
    surface_detail_changes: dict[str, Any] = Field(default_factory=dict)
    baseline_runtime_changes: list[str] = Field(default_factory=list)
    candidate_runtime_changes: list[str] = Field(default_factory=list)
    telemetry_summary: dict[str, Any] = Field(default_factory=dict)
    benchmark_drift: dict[str, Any] = Field(default_factory=dict)
    stability_summary: dict[str, Any] = Field(default_factory=dict)
    statistical_summary: dict[str, Any] = Field(default_factory=dict)
    pareto_summary: dict[str, Any] = Field(default_factory=dict)
    failure_clusters: list[dict[str, Any]] = Field(default_factory=list)
    gate_results: dict[str, Any] = Field(default_factory=dict)
    recommended_action: str = ""
    summary: str = ""


class MutationProposal(BaseModel):
    proposal_id: str
    experiment_id: str
    baseline_id: str | None = None
    benchmark_signature: str = ""
    category: str
    title: str
    priority: Literal["high", "medium", "low"] = "medium"
    priority_score: float = 0.0
    target_files: list[str] = Field(default_factory=list)
    target_paths: list[str] = Field(default_factory=list)
    target_surfaces: list[str] = Field(default_factory=list)
    related_cases: list[str] = Field(default_factory=list)
    supporting_trace_events: list[str] = Field(default_factory=list)
    supporting_clusters: list[str] = Field(default_factory=list)
    rationale: str = ""
    change_plan: list[str] = Field(default_factory=list)
    expected_effects: list[str] = Field(default_factory=list)
    acceptance_checks: list[str] = Field(default_factory=list)
    validation_commands: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class PatchPlanItem(BaseModel):
    file: str
    paths: list[str] = Field(default_factory=list)
    objective: str = ""
    planned_change: str = ""
    status: Literal["pending", "in_progress", "done"] = "pending"


class PatchTemplate(BaseModel):
    template_id: str
    proposal_id: str
    experiment_id: str
    baseline_id: str | None = None
    benchmark_signature: str = ""
    category: str
    title: str
    status: Literal["draft", "ready", "implemented", "validated"] = "draft"
    summary: str = ""
    rationale: str = ""
    hypothesis: str = ""
    target_files: list[str] = Field(default_factory=list)
    target_paths: list[str] = Field(default_factory=list)
    target_surfaces: list[str] = Field(default_factory=list)
    related_cases: list[str] = Field(default_factory=list)
    planned_edits: list[PatchPlanItem] = Field(default_factory=list)
    change_plan: list[str] = Field(default_factory=list)
    expected_effects: list[str] = Field(default_factory=list)
    acceptance_checks: list[str] = Field(default_factory=list)
    validation_commands: list[str] = Field(default_factory=list)
    validation_results: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    implementation_notes: list[str] = Field(default_factory=list)


class IterationLane(BaseModel):
    lane_id: str
    category: str
    title: str
    priority: Literal["high", "medium", "low"] = "medium"
    rationale: str = ""
    related_cases: list[str] = Field(default_factory=list)
    target_surfaces: list[str] = Field(default_factory=list)
    target_files: list[str] = Field(default_factory=list)
    target_paths: list[str] = Field(default_factory=list)
    measurement_focus: list[str] = Field(default_factory=list)
    metrics_to_watch: list[str] = Field(default_factory=list)
    guardrails: list[str] = Field(default_factory=list)
    compare_against: list[dict[str, Any]] = Field(default_factory=list)
    ablation_command: str | None = None
    validation_commands: list[str] = Field(default_factory=list)


class IterationPlan(BaseModel):
    plan_id: str
    experiment_id: str
    baseline_id: str | None = None
    benchmark_signature: str = ""
    recommended_action: str = ""
    summary: str = ""
    preferred_subset: str = ""
    notes: list[str] = Field(default_factory=list)
    baseline_ladder: dict[str, Any] = Field(default_factory=dict)
    readiness: dict[str, Any] = Field(default_factory=dict)
    lanes: list[IterationLane] = Field(default_factory=list)
    command_sequence: list[str] = Field(default_factory=list)


__all__ = [
    "CommandEntrypoint",
    "PythonEntrypoint",
    "ProviderEntrypoint",
    "AcceptanceGates",
    "WorkbenchConfig",
    "AgentSpec",
    "BehaviorBrief",
    "EvalSuiteSpec",
    "EvalCase",
    "RunArtifact",
    "ExperimentRecord",
    "ComparisonRecord",
    "MutationProposal",
    "PatchPlanItem",
    "PatchTemplate",
    "IterationLane",
    "IterationPlan",
    "ChainStepConfig",
    "ChainContext",
    "StepScore",
    "ChainAggregate",
    "WorkflowNodeConfig",
    "WorkflowEdgeConfig",
    "WorkflowSpec",
    "WorkflowAggregate",
    "ConversationMetrics",
]
