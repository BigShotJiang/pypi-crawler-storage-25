from __future__ import annotations

import ast
import fnmatch
import re
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir, load_config, load_model
from agentworkbench.models import AgentSpec, BehaviorBrief, EvalCase, EvalSuiteSpec, ExperimentRecord
from agentworkbench.reports import write_report
from agentworkbench.utils import enabled_item_names, ensure_dir, read_json, read_jsonl, read_yaml, slugify, write_json

_SEVERITY_RANK = {"info": 0, "warning": 1, "medium": 2, "high": 3, "critical": 4}
_SEVERITIES = ("critical", "high", "medium", "warning", "info")
_FAIL_CHOICES = ("none", "critical", "high", "medium", "warning")
_TARGET_SUFFIXES = {".py", ".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs", ".sh", ".md", ".txt", ".yaml", ".yml", ".json", ".toml"}

_EXPECTATION_KEYS = (
    "required_tools",
    "forbidden_tools",
    "required_skills",
    "forbidden_skills",
    "required_plugins",
    "forbidden_plugins",
    "required_mcps",
    "forbidden_mcps",
    "required_prompt_keys",
    "forbidden_prompt_keys",
    "required_workflow_steps",
    "forbidden_workflow_steps",
    "workflow_sequence",
)

_SURFACE_BY_EXPECTATION = {
    "required_tools": "tools",
    "forbidden_tools": "tools",
    "required_skills": "skills",
    "forbidden_skills": "skills",
    "required_plugins": "plugins",
    "forbidden_plugins": "plugins",
    "required_mcps": "mcps",
    "forbidden_mcps": "mcps",
    "required_prompt_keys": "prompts",
    "forbidden_prompt_keys": "prompts",
    "required_workflow_steps": "workflow",
    "forbidden_workflow_steps": "workflow",
    "workflow_sequence": "workflow",
}


def _normalize_list(value: Any) -> list[str]:
    if value in (None, "", False):
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value).strip()] if str(value).strip() else []


def _relative(project_root: Path, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(project_root.resolve()))
    except ValueError:
        return str(path)


def _finding(
    *,
    category: str,
    severity: str,
    title: str,
    message: str,
    hint: str,
    target_files: list[str] | None = None,
    target_surfaces: list[str] | None = None,
    evidence: dict[str, Any] | None = None,
    confidence: float = 0.8,
    suffix: str = "",
) -> dict[str, Any]:
    identifier = ".".join(part for part in [category, slugify(title).replace("-", "_"), suffix] if part)
    return {
        "id": identifier,
        "category": category,
        "severity": severity,
        "title": title,
        "message": message,
        "confidence": round(float(confidence), 3),
        "target_files": list(dict.fromkeys(target_files or [])),
        "target_surfaces": list(dict.fromkeys(target_surfaces or [])),
        "evidence": evidence or {},
        "hint": hint,
        "gate_blocking": False,
    }


def _load_agent_spec(project_root: Path, agent_id: str) -> AgentSpec | None:
    if not agent_id:
        return None
    path = control_dir(project_root) / "agents" / f"{agent_id}.yaml"
    if not path.exists():
        return None
    return load_model(path, AgentSpec)


def _load_experiment_record(project_root: Path, experiment_id: str) -> ExperimentRecord | None:
    config = load_config(project_root)
    path = project_root / config.artifacts_dir / experiment_id / "experiment.json"
    if not path.exists():
        return None
    return ExperimentRecord.model_validate(read_json(path))


def _load_run_rows(project_root: Path, experiment_id: str) -> list[dict[str, Any]]:
    config = load_config(project_root)
    path = project_root / config.artifacts_dir / experiment_id / "runs.jsonl"
    return [dict(item) for item in read_jsonl(path)] if path.exists() else []


def _latest_experiment_record(project_root: Path) -> ExperimentRecord | None:
    config = load_config(project_root)
    records = []
    for path in sorted((project_root / config.artifacts_dir).glob("*/experiment.json")):
        try:
            record = ExperimentRecord.model_validate(read_json(path))
        except Exception:
            continue
        records.append(record)
    records.sort(key=lambda item: (item.created_at or "", item.experiment_id), reverse=True)
    return records[0] if records else None


def _load_eval_context(
    project_root: Path,
    eval_id: str | None,
    subset: str | None,
) -> tuple[EvalSuiteSpec | None, list[EvalCase], BehaviorBrief | None]:
    if not eval_id:
        return None, [], None
    evals_root = control_dir(project_root) / "evals"
    suite = None
    suite_path = evals_root / f"{eval_id}.suite.yaml"
    if suite_path.exists():
        suite = load_model(suite_path, EvalSuiteSpec)
    cases_path = evals_root / f"{eval_id}.jsonl"
    cases = [EvalCase.model_validate(item) for item in read_jsonl(cases_path)] if cases_path.exists() else []
    splits_path = evals_root / f"{eval_id}.splits.yaml"
    if subset and splits_path.exists():
        splits = read_yaml(splits_path) or {}
        wanted = {str(item) for item in splits.get(subset, []) or []}
        if wanted:
            cases = [case for case in cases if case.id in wanted]
    brief = None
    if suite and suite.brief_id:
        brief_path = control_dir(project_root) / "briefs" / f"{suite.brief_id}.yaml"
        if brief_path.exists():
            brief = load_model(brief_path, BehaviorBrief)
    return suite, cases, brief


def _load_workflow_agent_ids(project_root: Path, workflow_file: str | None) -> tuple[list[str], str | None]:
    if not workflow_file:
        return [], None
    from agentworkbench.workflow import _load_workflow_spec

    workflow, workflow_path = _load_workflow_spec(project_root, workflow_file)
    agent_ids: list[str] = []
    for node in workflow.nodes:
        if node.node_type == "chain":
            agent_ids.extend(str(item) for item in node.chain_agent_ids if str(item).strip())
        elif node.agent_id:
            agent_ids.append(str(node.agent_id))
    return list(dict.fromkeys(agent_ids)), workflow_path


def _entrypoint_file_candidates(spec: AgentSpec) -> list[str]:
    paths: list[str] = []
    entrypoint = spec.entrypoints.get("command")
    argv: list[str] = []
    if isinstance(entrypoint, list):
        argv = [str(item) for item in entrypoint]
    elif isinstance(entrypoint, dict):
        argv = [str(item) for item in (entrypoint.get("argv") or [])]
    for item in argv:
        text = item.strip()
        if not text or text.startswith("-"):
            continue
        suffix = Path(text).suffix.lower()
        if suffix in _TARGET_SUFFIXES:
            paths.append(text)
    return paths


def _resolve_owned_globs(project_root: Path, spec: AgentSpec) -> list[str]:
    matches: list[str] = []
    for pattern in spec.owned_globs:
        for path in sorted(project_root.glob(pattern)):
            if path.is_file():
                matches.append(_relative(project_root, path))
    return matches


def _target_files_for_specs(project_root: Path, specs: list[AgentSpec]) -> list[str]:
    files: list[str] = []
    for spec in specs:
        files.extend(str(item) for item in spec.owned_paths)
        files.extend(_resolve_owned_globs(project_root, spec))
        files.extend(path for values in (spec.surface_paths or {}).values() for path in (values or []))
        for value in spec.prompts.values():
            source = str(value or "").strip()
            if source and (project_root / source).is_file():
                files.append(source)
        files.extend(_entrypoint_file_candidates(spec))
    resolved = []
    for raw in files:
        path = project_root / raw
        if path.is_file():
            resolved.append(_relative(project_root, path))
    return list(dict.fromkeys(resolved))


def _ignored_path(relative_path: str, patterns: list[str]) -> bool:
    normalized = relative_path.replace("\\", "/")
    for pattern in patterns:
        prefix = pattern[:-3] if pattern.endswith("/**") else pattern
        if fnmatch.fnmatch(normalized, pattern) or normalized.startswith(prefix):
            return True
    return False


def _read_text(project_root: Path, relative_path: str) -> str:
    try:
        return (project_root / relative_path).read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def _function_spans(text: str) -> list[dict[str, Any]]:
    try:
        module = ast.parse(text)
    except SyntaxError:
        return []
    spans: list[dict[str, Any]] = []
    for node in ast.walk(module):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        start = int(getattr(node, "lineno", 0) or 0)
        end = int(getattr(node, "end_lineno", start) or start)
        spans.append({"name": getattr(node, "name", "unknown"), "kind": type(node).__name__, "lines": max(0, end - start + 1)})
    return spans


def _quality_commands(project_root: Path) -> list[str]:
    commands: list[str] = []
    makefile = project_root / "Makefile"
    if makefile.exists():
        text = makefile.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"^quality:", text, re.M):
            commands.append("make quality")
        if re.search(r"^lint:", text, re.M):
            commands.append("make lint")
        if re.search(r"^test:", text, re.M):
            commands.append("make test")
    pyproject = project_root / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8", errors="ignore")
        if "[tool.ruff" in text and not any(command == "make lint" for command in commands):
            commands.append("ruff check .")
        if "[tool.mypy]" in text:
            commands.append("mypy")
        if "[tool.pytest" in text and not any(command == "make test" for command in commands):
            commands.append("pytest")
    return list(dict.fromkeys(commands))


def _check_code_structure(project_root: Path, specs: list[AgentSpec], target_files: list[str]) -> list[dict[str, Any]]:
    config = load_config(project_root).loop_checks
    findings: list[dict[str, Any]] = []
    scannable = [path for path in target_files if not _ignored_path(path, config.ignored_paths)]
    for relative_path in scannable:
        text = _read_text(project_root, relative_path)
        if not text:
            continue
        line_count = len(text.splitlines())
        if line_count > config.large_file_line_threshold:
            findings.append(
                _finding(
                    category="code_structure",
                    severity="warning",
                    title="Large target file",
                    message=f"`{relative_path}` has {line_count} lines, above the configured target of {config.large_file_line_threshold}.",
                    hint="Split agent runtime, tool, prompt, or orchestration code into smaller files before continuing long optimization loops.",
                    target_files=[relative_path],
                    evidence={"line_count": line_count, "threshold": config.large_file_line_threshold},
                    confidence=0.93,
                    suffix=slugify(relative_path),
                )
            )
        if Path(relative_path).suffix == ".py":
            long_spans = [span for span in _function_spans(text) if int(span["lines"]) > config.large_function_line_threshold]
            if long_spans:
                findings.append(
                    _finding(
                        category="code_structure",
                        severity="warning",
                        title="Long function or class",
                        message=f"`{relative_path}` contains {len(long_spans)} long function/class block(s).",
                        hint="Extract the long block into smaller functions so future agent edits stay bounded and reviewable.",
                        target_files=[relative_path],
                        evidence={"spans": long_spans[:5], "threshold": config.large_function_line_threshold},
                        confidence=0.88,
                        suffix=slugify(relative_path),
                    )
                )
    for spec in specs:
        if len(scannable) == 1 and (spec.tools or spec.skills or spec.plugins or spec.mcps or spec.prompts):
            findings.append(
                _finding(
                    category="code_structure",
                    severity="warning",
                    title="Agent surface concentrated in one file",
                    message=f"`{spec.id}` declares behavior surfaces but only one target file is available for inspection.",
                    hint="Declare prompt, tool, runtime, and workflow files separately in owned_paths or surface_paths so Codex can mutate one surface at a time.",
                    target_files=scannable,
                    target_surfaces=["owned_paths", "surface_paths"],
                    evidence={"agent_id": spec.id, "target_file_count": len(scannable)},
                    confidence=0.76,
                    suffix=slugify(spec.id),
                )
            )
        file_prompt_count = sum(1 for value in spec.prompts.values() if (project_root / str(value or "")).is_file())
        if spec.prompts and file_prompt_count == 0:
            findings.append(
                _finding(
                    category="code_structure",
                    severity="info",
                    title="Prompt surface is inline",
                    message=f"`{spec.id}` declares prompts, but none resolve to standalone prompt files.",
                    hint="Move non-trivial prompts into files and list them under surface_paths.prompts for easier prompt-only optimization passes.",
                    target_files=[str(Path(".agent-workbench") / "agents" / f"{spec.id}.yaml")],
                    target_surfaces=["prompts"],
                    evidence={"prompt_keys": sorted(spec.prompts)},
                    confidence=0.7,
                    suffix=slugify(spec.id),
                )
            )
    return findings


def _case_has_process_need(case: EvalCase) -> bool:
    metadata = case.metadata or {}
    process = metadata.get("process_expectations") or {}
    return bool(
        "workflow" in case.tags
        or metadata.get("expected_route")
        or metadata.get("expected_terminal_node")
        or any(process.get(key) for key in _EXPECTATION_KEYS)
    )


def _brief_has_workflow_need(brief: BehaviorBrief | None) -> bool:
    if brief is None:
        return False
    if brief.workflow_scenarios:
        return True
    return bool(brief.preferred_tools or brief.preferred_mcps or brief.preferred_skills or brief.preferred_plugins)


def _check_agent_topology(
    *,
    agent_count: int,
    cases: list[EvalCase],
    brief: BehaviorBrief | None,
    rows: list[dict[str, Any]],
    target_files: list[str],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    process_cases = [case.id for case in cases if _case_has_process_need(case)]
    needs_workflow = bool(process_cases or _brief_has_workflow_need(brief))
    if agent_count > 1 and not needs_workflow:
        findings.append(
            _finding(
                category="agent_topology",
                severity="warning",
                title="Multi-agent topology lacks benchmark justification",
                message=f"{agent_count} agents are declared, but selected eval cases do not express routing, handoff, or process expectations.",
                hint="Use one agent for this benchmark or add explicit workflow/process expectations that justify the additional agents.",
                target_files=target_files[:6],
                evidence={"agent_count": agent_count, "selected_case_count": len(cases)},
                confidence=0.82,
            )
        )
    if agent_count <= 1 and needs_workflow:
        findings.append(
            _finding(
                category="agent_topology",
                severity="medium",
                title="Single-agent topology may be underspecified for workflow cases",
                message="The selected benchmark expresses routing, workflow, or process expectations but only one agent is declared for the check target.",
                hint="Keep one agent only if it can satisfy the workflow contract directly; otherwise declare a workflow or chain and evaluate the handoff path.",
                target_files=target_files[:6],
                evidence={"process_case_ids": process_cases[:8], "brief_has_workflows": bool(brief and brief.workflow_scenarios)},
                confidence=0.77,
            )
        )
    for row in rows:
        case_id = str((row.get("case") or {}).get("id") or "unknown")
        workflow_agg = (((row.get("artifact") or {}).get("metadata") or {}).get("workflow_aggregate") or {})
        if bool(workflow_agg.get("loop_detected")):
            findings.append(
                _finding(
                    category="agent_topology",
                    severity="high",
                    title="Workflow loop detected",
                    message=f"Workflow execution looped on case `{case_id}`.",
                    hint="Tighten workflow edge conditions or max_visits before continuing optimization.",
                    evidence={"case_id": case_id},
                    confidence=0.93,
                    suffix=slugify(case_id),
                )
            )
        if int(workflow_agg.get("dead_end_count", 0) or 0) > 0:
            findings.append(
                _finding(
                    category="agent_topology",
                    severity="high",
                    title="Workflow dead end detected",
                    message=f"Workflow reached a dead end on case `{case_id}`.",
                    hint="Add a default route or adjust route conditions so every expected path reaches a terminal node.",
                    evidence={"case_id": case_id, "dead_end_count": workflow_agg.get("dead_end_count")},
                    confidence=0.93,
                    suffix=slugify(case_id),
                )
            )
        unmatched = workflow_agg.get("unmatched_routes") or []
        if unmatched:
            findings.append(
                _finding(
                    category="agent_topology",
                    severity="medium",
                    title="Workflow unmatched routes",
                    message=f"Workflow emitted unmatched route decisions on case `{case_id}`.",
                    hint="Align router output labels with workflow edge labels and conditions.",
                    evidence={"case_id": case_id, "unmatched_routes": unmatched[:4]},
                    confidence=0.86,
                    suffix=slugify(case_id),
                )
            )
    return findings


def _brief_expectation_links(brief: BehaviorBrief | None) -> dict[str, set[str]]:
    links: dict[str, set[str]] = {key: set() for key in _EXPECTATION_KEYS}
    if brief is None:
        return links
    links["required_tools"].update(brief.preferred_tools)
    links["required_skills"].update(brief.preferred_skills)
    links["required_plugins"].update(brief.preferred_plugins)
    links["required_mcps"].update(brief.preferred_mcps)
    links["required_prompt_keys"].update(brief.prompt_variants)
    for workflow in brief.workflow_scenarios:
        mapping = {
            "required_tools": "expected_tools",
            "required_skills": "expected_skills",
            "required_plugins": "expected_plugins",
            "required_mcps": "expected_mcps",
            "required_prompt_keys": "expected_prompt_keys",
            "required_workflow_steps": "expected_workflow_steps",
            "workflow_sequence": "expected_workflow_sequence",
        }
        for target_key, source_key in mapping.items():
            links[target_key].update(_normalize_list(workflow.get(source_key)))
    return {key: {str(item) for item in value if str(item).strip()} for key, value in links.items()}


def _specific_rationale(process: dict[str, Any], key: str, name: str, min_chars: int) -> str:
    general = str(process.get("rationale") or process.get("why") or "").strip()
    if len(general) >= min_chars:
        return general
    rationales = process.get("rationales") or {}
    if not isinstance(rationales, dict):
        return ""
    candidates = [
        rationales.get(f"{key}.{name}"),
        rationales.get(f"{key}:{name}"),
        rationales.get(name),
    ]
    nested = rationales.get(key)
    if isinstance(nested, dict):
        candidates.append(nested.get(name))
    elif isinstance(nested, str):
        candidates.append(nested)
    for candidate in candidates:
        text = str(candidate or "").strip()
        if len(text) >= min_chars:
            return text
    return ""


def _expectation_has_context(case: EvalCase, brief_links: dict[str, set[str]], key: str, name: str) -> bool:
    if name in brief_links.get(key, set()):
        return True
    text = " ".join([case.input, case.expected, " ".join(case.rubric), " ".join(case.tags)]).lower()
    if name.lower() and name.lower() in text:
        return True
    metadata = case.metadata or {}
    for marker in ("evidence_path", "evidence_paths", "source", "sources", "reference", "references"):
        if metadata.get(marker):
            return True
    return False


def _check_eval_contract(
    *,
    project_root: Path,
    specs: list[AgentSpec],
    eval_id: str | None,
    cases: list[EvalCase],
    brief: BehaviorBrief | None,
) -> list[dict[str, Any]]:
    if not eval_id:
        return []
    config = load_config(project_root).loop_checks
    findings: list[dict[str, Any]] = []
    brief_links = _brief_expectation_links(brief)
    available = {
        "required_tools": {name for spec in specs for name in enabled_item_names(spec.tools)},
        "required_mcps": {name for spec in specs for name in enabled_item_names(spec.mcps)},
    }
    eval_file = str(Path(".agent-workbench") / "evals" / f"{eval_id}.jsonl")
    for case in cases:
        process = dict((case.metadata or {}).get("process_expectations") or {})
        for key in _EXPECTATION_KEYS:
            names = _normalize_list(process.get(key))
            if not names:
                continue
            surface = _SURFACE_BY_EXPECTATION.get(key, "process")
            for name in names:
                if key in available and name not in available[key]:
                    findings.append(
                        _finding(
                            category="eval_contract",
                            severity="high",
                            title="Required surface is not declared",
                            message=f"Case `{case.id}` requires `{key}.{name}`, but the checked agent spec does not declare it as enabled.",
                            hint="Either declare the surface on the target agent or remove the requirement from the eval contract.",
                            target_files=[eval_file],
                            target_surfaces=[f"{surface}:{name}"],
                            evidence={"case_ids": [case.id], "expectation": key, "available": sorted(available[key])},
                            confidence=0.94,
                            suffix=slugify(f"{case.id}-{key}-{name}"),
                        )
                    )
                if not _specific_rationale(process, key, name, config.min_rationale_chars) and not _expectation_has_context(case, brief_links, key, name):
                    findings.append(
                        _finding(
                            category="eval_contract",
                            severity="medium",
                            title="Required process expectation lacks rationale",
                            message=f"Case `{case.id}` expects `{key}.{name}` without a rationale or clear brief/case link.",
                            hint=f"Add `metadata.process_expectations.rationales.{key}.{name}` explaining why this expectation is correct.",
                            target_files=[eval_file],
                            target_surfaces=[f"{surface}:{name}"],
                            evidence={"case_ids": [case.id], "expectation": key},
                            confidence=0.84,
                            suffix=slugify(f"{case.id}-{key}-{name}"),
                        )
                    )
    if brief:
        brief_file = str(Path(".agent-workbench") / "briefs" / f"{brief.id}.yaml")
        for workflow in brief.workflow_scenarios:
            rationale = str(workflow.get("rationale") or workflow.get("why") or "").strip()
            if len(rationale) >= config.min_rationale_chars:
                continue
            expected = []
            for key in ("expected_tools", "expected_mcps", "expected_prompt_keys", "expected_workflow_steps", "expected_workflow_sequence"):
                expected.extend(_normalize_list(workflow.get(key)))
            if expected:
                findings.append(
                    _finding(
                        category="eval_contract",
                        severity="info",
                        title="Workflow scenario lacks rationale",
                        message=f"Workflow scenario `{workflow.get('name') or workflow.get('trigger') or 'workflow'}` lists process expectations without a rationale.",
                        hint="Add a short workflow rationale to the brief so generated evals can distinguish required process from optional implementation detail.",
                        target_files=[brief_file],
                        target_surfaces=[f"workflow:{item}" for item in expected[:6]],
                        evidence={"workflow": workflow.get("name") or workflow.get("trigger") or "workflow"},
                        confidence=0.68,
                        suffix=slugify(str(workflow.get("name") or workflow.get("trigger") or "workflow")),
                    )
                )
    return findings


def _fixed_final_output(text: str) -> bool:
    return bool(
        re.search(r"['\"]final_output['\"]\s*:\s*['\"][^'\"]{1,240}['\"]", text)
        or re.search(r"final_output\s*=\s*['\"][^'\"]{1,240}['\"]", text)
    )


def _scan_inline_entrypoints(specs: list[AgentSpec]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for spec in specs:
        entrypoint = spec.entrypoints.get("command")
        chunks: list[str] = []
        if isinstance(entrypoint, list):
            chunks = [str(item) for item in entrypoint]
        elif isinstance(entrypoint, dict):
            chunks.extend(str(item) for item in (entrypoint.get("argv") or []))
            if entrypoint.get("shell"):
                chunks.append(str(entrypoint.get("shell")))
        text = "\n".join(chunks)
        if text and _fixed_final_output(text):
            spec_file = str(Path(".agent-workbench") / "agents" / f"{spec.id}.yaml")
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="high",
                    title="Command entrypoint emits fixed final output",
                    message=f"`{spec.id}` has an inline command entrypoint that writes a fixed `final_output`.",
                    hint="Move fixture-like runtime behavior into tests, and make the target agent produce outputs from the case input, tools, model, or retrieved evidence.",
                    target_files=[spec_file],
                    target_surfaces=["entrypoints.command"],
                    evidence={"agent_id": spec.id},
                    confidence=0.82,
                    suffix=slugify(spec.id),
                )
            )
    return findings


def _check_deterministic_fallback(
    *,
    project_root: Path,
    specs: list[AgentSpec],
    target_files: list[str],
    cases: list[EvalCase],
    rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    config = load_config(project_root).loop_checks
    findings = _scan_inline_entrypoints(specs)
    case_ids = [case.id for case in cases if len(case.id) >= 4]
    expected_values = [
        case.expected.strip()
        for case in cases
        if len(case.expected.strip()) >= int(config.expected_string_match_min_chars)
    ]
    for relative_path in target_files:
        if _ignored_path(relative_path, config.ignored_paths):
            continue
        text = _read_text(project_root, relative_path)
        if not text:
            continue
        matched_case_ids = [case_id for case_id in case_ids if case_id in text]
        if matched_case_ids:
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="critical",
                    title="Target code contains eval case ids",
                    message=f"`{relative_path}` references eval case id(s), which can let the agent branch on the benchmark.",
                    hint="Remove case-id branching from the target agent; encode behavior through prompts, tools, retrieval, or runtime logic that generalizes beyond eval IDs.",
                    target_files=[relative_path],
                    evidence={"case_ids": matched_case_ids[:8]},
                    confidence=0.97,
                    suffix=slugify(relative_path),
                )
            )
        matched_expected = [value for value in expected_values if value and value in text]
        if matched_expected:
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="critical",
                    title="Target code contains exact expected outputs",
                    message=f"`{relative_path}` contains exact expected benchmark output text.",
                    hint="Remove exact benchmark answers from target code; keep expected strings only in evals, scorers, or tests.",
                    target_files=[relative_path],
                    evidence={"expected_matches": matched_expected[:4]},
                    confidence=0.96,
                    suffix=slugify(relative_path),
                )
            )
        if ("AWB_INPUT" in text or "AWB_CASE_ID" in text) and "final_output" in text and re.search(r"\{[^{}]*['\"][^'\"]+['\"]\s*:\s*['\"]", text, re.S):
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="critical",
                    title="Target code maps benchmark input to canned output",
                    message=f"`{relative_path}` appears to map AWB input/case identity to fixed outputs.",
                    hint="Replace case-map behavior with real model/tool/runtime behavior that can handle unseen inputs.",
                    target_files=[relative_path],
                    evidence={"markers": ["AWB_INPUT/AWB_CASE_ID", "final_output", "literal_map"]},
                    confidence=0.91,
                    suffix=slugify(relative_path),
                )
            )
        if _fixed_final_output(text):
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="high",
                    title="Target file emits fixed final output",
                    message=f"`{relative_path}` writes a fixed `final_output` value.",
                    hint="Make final output depend on the user input, model response, tool result, or retrieved evidence instead of a literal fixture string.",
                    target_files=[relative_path],
                    target_surfaces=["runtime"],
                    evidence={"marker": "final_output"},
                    confidence=0.87,
                    suffix=slugify(relative_path),
                )
            )
        lowered = text.lower()
        if "final_output" in text and any(marker in lowered for marker in ("fallback", "fixture", "canned")):
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="high",
                    title="Fallback wording appears in target output path",
                    message=f"`{relative_path}` mixes fallback/fixture wording with the final output path.",
                    hint="Keep deterministic fixture fallbacks in tests and expose runtime failures explicitly in agent artifacts.",
                    target_files=[relative_path],
                    evidence={"markers": ["fallback_or_fixture", "final_output"]},
                    confidence=0.78,
                    suffix=slugify(relative_path),
                )
            )
        if "except" in text and "final_output" in text:
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="high",
                    title="Error path may return canned final output",
                    message=f"`{relative_path}` handles exceptions near a final output path.",
                    hint="Emit errors in the run artifact instead of silently returning a successful canned answer after exceptions.",
                    target_files=[relative_path],
                    evidence={"markers": ["except", "final_output"]},
                    confidence=0.7,
                    suffix=slugify(relative_path),
                )
            )
    varied_inputs = {str((row.get("case") or {}).get("input") or "") for row in rows if (row.get("case") or {}).get("input")}
    outputs = [str((row.get("artifact") or {}).get("final_output") or "").strip() for row in rows]
    nonempty_outputs = [output for output in outputs if output]
    if len(varied_inputs) > 1 and len(set(nonempty_outputs)) == 1 and len(nonempty_outputs) > 1:
        has_support = any(
            (row.get("artifact") or {}).get("tool_calls")
            or (row.get("artifact") or {}).get("trace_events")
            or (row.get("artifact") or {}).get("evidence_records")
            for row in rows
        )
        if not has_support:
            findings.append(
                _finding(
                    category="deterministic_fallback",
                    severity="high",
                    title="Experiment outputs are identical without support telemetry",
                    message="Multiple varied cases produced the same final output with no tool, trace, or evidence support.",
                    hint="Inspect the runtime for canned outputs or missing telemetry before trusting the run as a behavioral signal.",
                    evidence={"output": nonempty_outputs[0][:240], "case_count": len(nonempty_outputs)},
                    confidence=0.74,
                )
            )
    return findings


def _latest_compare_for_candidate(project_root: Path, experiment_id: str | None) -> dict[str, Any] | None:
    if not experiment_id:
        return None
    reports_root = control_dir(project_root) / "reports"
    candidates: list[tuple[int, dict[str, Any]]] = []
    for path in reports_root.glob("compare-*-to-*.json"):
        try:
            payload = read_json(path)
        except Exception:
            continue
        if str(payload.get("candidate_id") or "") == experiment_id:
            candidates.append((path.stat().st_mtime_ns, payload))
    latest = reports_root / "latest-compare.json"
    if latest.exists():
        try:
            payload = read_json(latest)
            if str(payload.get("candidate_id") or "") == experiment_id:
                candidates.append((latest.stat().st_mtime_ns, payload))
        except Exception:
            pass
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _has_promoted_baseline(project_root: Path, record: ExperimentRecord | None) -> bool:
    if record is None:
        return False
    config = load_config(project_root)
    root = project_root / config.artifacts_dir
    for path in sorted(root.glob("*/experiment.json")):
        try:
            candidate = ExperimentRecord.model_validate(read_json(path))
        except Exception:
            continue
        if candidate.experiment_id == record.experiment_id:
            continue
        if candidate.eval_id != record.eval_id or candidate.subset != record.subset:
            continue
        if candidate.benchmark_signature != record.benchmark_signature:
            continue
        if candidate.promotion_status == "promoted":
            return True
    return False


def _pending_high_review_count(project_root: Path, *, eval_id: str | None, experiment_id: str | None) -> int:
    reports_root = control_dir(project_root) / "reports"
    wanted_queue_ids = {f"eval-{eval_id}" if eval_id else "", f"diagnose-{experiment_id}" if experiment_id else ""}
    wanted_queue_ids.discard("")
    count = 0
    for path in reports_root.glob("*review-queue*.json"):
        try:
            payload = read_json(path)
        except Exception:
            continue
        if wanted_queue_ids and str(payload.get("queue_id") or "") not in wanted_queue_ids:
            continue
        for item in payload.get("items") or []:
            if str((item or {}).get("status") or "pending") == "resolved":
                continue
            if str((item or {}).get("priority") or "").lower() == "high":
                count += 1
    return count


def _check_loop_hygiene(
    *,
    project_root: Path,
    suite: EvalSuiteSpec | None,
    record: ExperimentRecord | None,
    experiment_id: str | None,
    eval_id: str | None,
    subset: str | None,
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if suite and suite.approval_status != "approved":
        findings.append(
            _finding(
                category="loop_hygiene",
                severity="high",
                title="Eval suite is not approved",
                message=f"Eval `{suite.id}` is `{suite.approval_status}`, so long-loop optimization would be running against an unstable benchmark.",
                hint=f"Review and approve the eval suite with `awb evals approve --eval-id {suite.id}` before treating runs as promotion evidence.",
                target_files=[str(Path(".agent-workbench") / "evals" / f"{suite.id}.suite.yaml")],
                evidence={"approval_status": suite.approval_status},
                confidence=0.95,
            )
        )
    if subset == "smoke":
        findings.append(
            _finding(
                category="loop_hygiene",
                severity="warning",
                title="Smoke subset is not promotion evidence",
                message="The selected target uses the `smoke` subset.",
                hint="Use `full` runs for optimization and promotion decisions; keep smoke only for fast local debugging.",
                evidence={"subset": subset},
                confidence=0.9,
            )
        )
    if record and not _has_promoted_baseline(project_root, record):
        findings.append(
            _finding(
                category="loop_hygiene",
                severity="medium",
                title="No promoted comparable baseline",
                message="No promoted baseline exists for this eval/subset/benchmark signature.",
                hint="Promote a clean baseline before asking Codex to loop for many optimization rounds.",
                evidence={"experiment_id": record.experiment_id, "benchmark_signature": record.benchmark_signature},
                confidence=0.76,
            )
        )
    compare = _latest_compare_for_candidate(project_root, experiment_id)
    failed_gates = [
        key
        for key, value in ((compare or {}).get("gate_results") or {}).items()
        if key != "overall_passed" and isinstance(value, dict) and not bool(value.get("passed", True))
    ]
    if failed_gates:
        findings.append(
            _finding(
                category="loop_hygiene",
                severity="high",
                title="Latest comparison has failing gates",
                message=f"The latest comparison for `{experiment_id}` has failing gates: {', '.join(failed_gates[:5])}.",
                hint="Resolve promotion gate failures before asking Codex to continue broad optimization.",
                evidence={"failed_gates": failed_gates},
                confidence=0.91,
            )
        )
    pending_reviews = _pending_high_review_count(project_root, eval_id=eval_id, experiment_id=experiment_id)
    if pending_reviews:
        findings.append(
            _finding(
                category="loop_hygiene",
                severity="high",
                title="High-priority human review is pending",
                message=f"{pending_reviews} high-priority human review item(s) are unresolved for this target.",
                hint="Resolve the review queue before treating benchmark or acceptance decisions as stable.",
                evidence={"pending_high_priority_items": pending_reviews},
                confidence=0.88,
            )
        )
    scorer_audit = control_dir(project_root) / "reports" / "scorer-audit-latest.json"
    if scorer_audit.exists():
        try:
            payload = read_json(scorer_audit)
        except Exception:
            payload = {}
        if not experiment_id or str(payload.get("experiment_id") or "") == experiment_id:
            issues = [str(item) for item in payload.get("issues") or []]
            if issues:
                findings.append(
                    _finding(
                        category="loop_hygiene",
                        severity="medium",
                        title="Scorer audit has unresolved issues",
                        message=f"The latest scorer audit reports {len(issues)} issue(s).",
                        hint="Review scorer confidence and judgment metadata before using the metric for long-loop promotion decisions.",
                        evidence={"issues": issues[:5]},
                        confidence=0.84,
                    )
                )
    return findings


def _summarize_findings(findings: list[dict[str, Any]]) -> dict[str, int]:
    return {severity: sum(1 for finding in findings if finding.get("severity") == severity) for severity in _SEVERITIES}


def _apply_gate_flags(findings: list[dict[str, Any]], fail_on: str) -> bool:
    if fail_on == "none":
        return True
    threshold = _SEVERITY_RANK[fail_on]
    passed = True
    for finding in findings:
        blocking = _SEVERITY_RANK.get(str(finding.get("severity") or "info"), 0) >= threshold
        finding["gate_blocking"] = blocking
        if blocking:
            passed = False
    return passed


def _readiness_score(findings: list[dict[str, Any]]) -> float:
    penalty = 0.0
    weights = {"critical": 0.35, "high": 0.18, "medium": 0.08, "warning": 0.03, "info": 0.01}
    for finding in findings:
        penalty += weights.get(str(finding.get("severity") or "info"), 0.01) * float(finding.get("confidence") or 1.0)
    return round(max(0.0, 1.0 - penalty), 3)


def _target_slug(target: dict[str, Any]) -> str:
    for key in ("experiment_id", "workflow_file", "agent_id", "eval_id"):
        value = str(target.get(key) or "").strip()
        if value:
            return str(slugify(value))
    chain_ids = target.get("chain_agent_ids") or []
    if chain_ids:
        return str(slugify("-".join(str(item) for item in chain_ids)))
    return "project"


def render_loop_check_report(payload: dict[str, Any]) -> str:
    lines = [
        f"# Agent Loop Readiness Check {payload.get('target_slug') or 'project'}",
        "",
        f"- Passed: `{payload.get('passed', False)}`",
        f"- Fail on: `{payload.get('fail_on') or 'critical'}`",
        f"- Readiness score: {payload.get('readiness_score', 0.0)}",
        "",
        "## Summary",
        "",
    ]
    summary = payload.get("summary") or {}
    for severity in _SEVERITIES:
        lines.append(f"- `{severity}`: {summary.get(severity, 0)}")
    lines.extend(["", "## Findings", ""])
    findings = payload.get("findings") or []
    if not findings:
        lines.append("- none")
    for finding in findings:
        files = ", ".join(finding.get("target_files") or []) or "none"
        lines.append(
            f"- `{finding.get('severity')}` `{finding.get('category')}`: {finding.get('title')} "
            f"(confidence={finding.get('confidence')}, files={files})"
        )
        lines.append(f"  - {finding.get('message')}")
        lines.append(f"  - hint: {finding.get('hint')}")
    lines.extend(["", "## Suggested Commands", ""])
    commands = payload.get("suggested_commands") or []
    if commands:
        lines.extend(f"- `{command}`" for command in commands)
    else:
        lines.append("- none")
    return "\n".join(lines)


def _write_check_reports(project_root: Path, payload: dict[str, Any]) -> dict[str, Any]:
    reports_dir = ensure_dir(control_dir(project_root) / "reports")
    target_slug = str(payload.get("target_slug") or "project")
    json_path = write_json(reports_dir / f"check-{target_slug}.json", payload)
    md_path = write_report(reports_dir / f"check-{target_slug}.md", render_loop_check_report(payload))
    latest_json = write_json(reports_dir / "check-latest.json", payload)
    latest_md = write_report(reports_dir / "check-latest.md", render_loop_check_report(payload))
    payload["report_paths"] = {
        "json": _relative(project_root, json_path),
        "markdown": _relative(project_root, md_path),
        "latest_json": _relative(project_root, latest_json),
        "latest_markdown": _relative(project_root, latest_md),
    }
    write_json(json_path, payload)
    write_json(latest_json, payload)
    return payload


def build_loop_check_report(
    project_root: Path,
    *,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    experiment_id: str | None = None,
    workflow_file: str | None = None,
    chain_agent_ids: list[str] | None = None,
    fail_on: str | None = None,
    write: bool = True,
) -> dict[str, Any]:
    config = load_config(project_root)
    loop_config = config.loop_checks
    configured_fail_on = fail_on or loop_config.fail_on_severity
    if configured_fail_on not in _FAIL_CHOICES:
        raise ValueError(f"`fail_on` must be one of: {', '.join(_FAIL_CHOICES)}")
    record = _load_experiment_record(project_root, experiment_id) if experiment_id else None
    rows = _load_run_rows(project_root, experiment_id) if experiment_id else []
    if experiment_id and record is None:
        raise ValueError(f"Experiment `{experiment_id}` was not found.")
    if not any([agent_id, eval_id, experiment_id, workflow_file, chain_agent_ids]):
        record = _latest_experiment_record(project_root)
        if record:
            experiment_id = record.experiment_id
            rows = _load_run_rows(project_root, experiment_id)
    if record:
        agent_id = agent_id or record.agent_id
        eval_id = eval_id or record.eval_id
        subset = subset or record.subset
    subset = subset or "full"

    workflow_agent_ids, resolved_workflow_file = _load_workflow_agent_ids(project_root, workflow_file)
    checked_agent_ids = list(dict.fromkeys([*(chain_agent_ids or []), *workflow_agent_ids, *([agent_id] if agent_id else [])]))
    specs = [spec for spec in (_load_agent_spec(project_root, item) for item in checked_agent_ids) if spec is not None]
    suite, cases, brief = _load_eval_context(project_root, eval_id, subset)
    target_files = _target_files_for_specs(project_root, specs)
    agent_count = len(set(checked_agent_ids)) if checked_agent_ids else (1 if agent_id else 0)

    target = {
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "experiment_id": experiment_id,
        "workflow_file": resolved_workflow_file or workflow_file,
        "chain_agent_ids": chain_agent_ids or [],
    }

    findings: list[dict[str, Any]] = []
    payload: dict[str, Any]
    if not loop_config.enabled:
        payload = {
            "project_root": str(project_root),
            "target": target,
            "target_slug": _target_slug(target),
            "passed": True,
            "fail_on": configured_fail_on,
            "readiness_score": 1.0,
            "summary": _summarize_findings([]),
            "findings": [],
            "hints": [],
            "suggested_commands": [],
            "disabled": True,
        }
        return _write_check_reports(project_root, payload) if write else payload

    findings.extend(_check_code_structure(project_root, specs, target_files))
    findings.extend(_check_agent_topology(agent_count=agent_count, cases=cases, brief=brief, rows=rows, target_files=target_files))
    findings.extend(_check_eval_contract(project_root=project_root, specs=specs, eval_id=eval_id, cases=cases, brief=brief))
    findings.extend(_check_deterministic_fallback(project_root=project_root, specs=specs, target_files=target_files, cases=cases, rows=rows))
    findings.extend(_check_loop_hygiene(project_root=project_root, suite=suite, record=record, experiment_id=experiment_id, eval_id=eval_id, subset=subset))
    findings.sort(key=lambda item: (-_SEVERITY_RANK.get(str(item.get("severity") or "info"), 0), str(item.get("category") or ""), str(item.get("id") or "")))
    passed = _apply_gate_flags(findings, configured_fail_on)
    hints = list(dict.fromkeys(str(item.get("hint") or "") for item in findings if str(item.get("hint") or "").strip()))
    commands: list[str] = []
    if agent_id and eval_id:
        commands.append(f"awb run --agent-id {agent_id} --eval-id {eval_id} --subset {subset}")
    if experiment_id:
        commands.extend([f"awb diagnose --experiment {experiment_id}", f"awb propose --experiment {experiment_id}"])
    if agent_id and eval_id:
        commands.append("awb compare --candidate <new-experiment-id> --best")
    commands.extend(_quality_commands(project_root))
    payload = {
        "project_root": str(project_root),
        "target": target,
        "target_slug": _target_slug(target),
        "passed": passed,
        "fail_on": configured_fail_on,
        "readiness_score": _readiness_score(findings),
        "summary": _summarize_findings(findings),
        "findings": findings,
        "hints": hints[:12],
        "suggested_commands": list(dict.fromkeys(commands)),
    }
    return _write_check_reports(project_root, payload) if write else payload


def loop_check_gate(project_root: Path, candidate_record: ExperimentRecord | None) -> dict[str, Any] | None:
    if candidate_record is None:
        return None
    config = load_config(project_root).loop_checks
    if not config.enabled or not config.block_promotion_on_critical:
        return None
    payload = build_loop_check_report(
        project_root,
        experiment_id=candidate_record.experiment_id,
        fail_on="critical",
        write=True,
    )
    critical = int((payload.get("summary") or {}).get("critical", 0))
    return {
        "passed": critical == 0,
        "actual": {
            "critical_findings": critical,
            "readiness_score": payload.get("readiness_score"),
            "target_slug": payload.get("target_slug"),
        },
        "required": "zero critical loop-readiness findings",
    }


__all__ = ["build_loop_check_report", "loop_check_gate", "render_loop_check_report"]
