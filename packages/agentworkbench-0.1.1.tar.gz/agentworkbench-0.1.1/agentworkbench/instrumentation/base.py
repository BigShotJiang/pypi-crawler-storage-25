"""Instrumentation base types and provenance tracking."""

from __future__ import annotations

from enum import StrEnum
from typing import Any


class ProvenanceLevel(StrEnum):
    RAW = "raw"
    INFERRED = "inferred"
    MERGED = "merged"


class ProvenanceSource(StrEnum):
    WORKFLOW_TRACE = "workflow_trace"
    TOOL_CALL = "tool_call"
    PROMPT_USAGE = "prompt_usage"
    SKILL_LOAD = "skill_load"
    PLUGIN_USE = "plugin_use"
    MCP_ROUTING = "mcp_routing"
    PROVIDER_REQUEST = "provider_request"
    PROVIDER_RESPONSE = "provider_response"
    RETRIEVAL = "retrieval"
    RUNTIME = "runtime"
    HEURISTIC = "heuristic"
    MODEL_JUDGED = "model_judged"


class ProvenanceRecord:
    def __init__(
        self,
        field_name: str,
        value: Any,
        provenance: ProvenanceLevel,
        source: ProvenanceSource,
        confidence: float = 1.0,
        notes: str | None = None,
    ):
        self.field_name = field_name
        self.value = value
        self.provenance = provenance
        self.source = source
        self.confidence = confidence
        self.notes = notes

    def to_dict(self) -> dict[str, Any]:
        return {
            "field_name": self.field_name,
            "value": self.value,
            "provenance": self.provenance.value,
            "source": self.source.value,
            "confidence": self.confidence,
            "notes": self.notes,
        }


class ProvenanceTracker:
    def __init__(self):
        self.records: list[ProvenanceRecord] = []

    def add_raw(self, field_name: str, value: Any, source: ProvenanceSource) -> None:
        self.records.append(ProvenanceRecord(field_name, value, ProvenanceLevel.RAW, source))

    def add_inferred(self, field_name: str, value: Any, source: ProvenanceSource, confidence: float = 0.8) -> None:
        self.records.append(ProvenanceRecord(field_name, value, ProvenanceLevel.INFERRED, source, confidence))

    def add_merged(self, field_name: str, value: Any, sources: list[ProvenanceSource]) -> None:
        confidence = 1.0 / len(sources) if sources else 0.5
        self.records.append(
            ProvenanceRecord(field_name, value, ProvenanceLevel.MERGED, ProvenanceSource.HEURISTIC, confidence)
        )

    def get_provenance(self, field_name: str) -> list[ProvenanceRecord]:
        return [r for r in self.records if r.field_name == field_name]

    def to_dict(self) -> dict[str, Any]:
        return {
            "records": [r.to_dict() for r in self.records],
            "field_count": len(set(r.field_name for r in self.records)),
            "raw_count": sum(1 for r in self.records if r.provenance == ProvenanceLevel.RAW),
            "inferred_count": sum(1 for r in self.records if r.provenance == ProvenanceLevel.INFERRED),
            "merged_count": sum(1 for r in self.records if r.provenance == ProvenanceLevel.MERGED),
        }


__all__ = [
    "ProvenanceLevel",
    "ProvenanceSource",
    "ProvenanceRecord",
    "ProvenanceTracker",
]
