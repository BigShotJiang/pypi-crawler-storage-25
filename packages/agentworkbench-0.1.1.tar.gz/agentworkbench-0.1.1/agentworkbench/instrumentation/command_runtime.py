"""Instrumentation for command-runtime target agents (subprocess-based)."""

from __future__ import annotations

from typing import Any

from agentworkbench.instrumentation.base import ProvenanceLevel, ProvenanceSource
from agentworkbench.instrumentation.common import normalize_runtime_events


def normalize_command_runtime_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Normalize events emitted by command-runtime agents.

    Command-runtime agents emit events via stdout/stderr capture.
    Each event is tagged with provenance=raw and source=runtime.
    """
    return normalize_runtime_events(events, source="command_runtime")


def extract_command_runtime_signals(
    stdout: str,
    stderr: str,
    exit_code: int,
) -> list[dict[str, Any]]:
    """Extract instrumentation signals from command-runtime output.

    Returns inferred events when explicit events are not present.
    """
    signals = []
    if stdout:
        signals.append(
            {
                "kind": "stdout",
                "provenance": ProvenanceLevel.RAW.value,
                "source": ProvenanceSource.RUNTIME.value,
                "data": {"length": len(stdout)},
            }
        )
    if stderr:
        signals.append(
            {
                "kind": "stderr",
                "provenance": ProvenanceLevel.RAW.value,
                "source": ProvenanceSource.RUNTIME.value,
                "data": {"length": len(stderr)},
            }
        )
    signals.append(
        {
            "kind": "exit_code",
            "provenance": ProvenanceLevel.RAW.value,
            "source": ProvenanceSource.RUNTIME.value,
            "data": {"code": exit_code},
        }
    )
    return signals


__all__ = [
    "normalize_command_runtime_events",
    "extract_command_runtime_signals",
]
