"""Instrumentation for provider-backed target agents."""

from __future__ import annotations

from typing import Any

from agentworkbench.instrumentation.base import ProvenanceLevel, ProvenanceSource


def normalize_provider_runtime_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Normalize events emitted by provider-backed agents.

    Provider agents emit events via API request/response capture.
    Events are tagged with provenance=raw and source=provider_request/provider_response.
    """
    normalized = []
    for event in events:
        kind = event.get("kind", "unknown")
        source = (
            ProvenanceSource.PROVIDER_REQUEST.value
            if "request" in kind.lower()
            else ProvenanceSource.PROVIDER_RESPONSE.value
        )
        normalized_event = {
            "seq": event.get("seq", 0),
            "kind": kind,
            "name": event.get("name", ""),
            "label": event.get("label", ""),
            "source": source,
            "provenance": event.get("provenance", ProvenanceLevel.RAW.value),
            "data": event.get("data", {}),
        }
        normalized.append(normalized_event)
    return normalized


def extract_provider_signals(
    model: str,
    request: dict[str, Any],
    response: dict[str, Any],
    latency_ms: float,
) -> list[dict[str, Any]]:
    """Extract instrumentation signals from provider API interactions.

    Returns raw events for model requests and responses.
    """
    signals = []
    signals.append(
        {
            "kind": "provider_request",
            "provenance": ProvenanceLevel.RAW.value,
            "source": ProvenanceSource.PROVIDER_REQUEST.value,
            "data": {
                "model": model,
                "messages_count": len(request.get("messages", [])),
                "tools_count": len(request.get("tools", [])),
                "temperature": request.get("temperature"),
                "max_tokens": request.get("max_tokens"),
            },
        }
    )
    signals.append(
        {
            "kind": "provider_response",
            "provenance": ProvenanceLevel.RAW.value,
            "source": ProvenanceSource.PROVIDER_RESPONSE.value,
            "data": {
                "model": response.get("model", model),
                "finish_reason": response.get("choices", [{}])[0].get("finish_reason")
                if response.get("choices")
                else None,
                "latency_ms": latency_ms,
                "usage": response.get("usage", {}),
            },
        }
    )
    return signals


__all__ = [
    "normalize_provider_runtime_events",
    "extract_provider_signals",
]
