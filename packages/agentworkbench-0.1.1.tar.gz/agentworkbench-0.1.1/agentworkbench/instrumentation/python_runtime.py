"""Instrumentation for in-process Python runtime target agents."""

from __future__ import annotations

from typing import Any

from agentworkbench.instrumentation.base import ProvenanceLevel, ProvenanceSource
from agentworkbench.instrumentation.common import normalize_runtime_events


def normalize_python_runtime_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Normalize events emitted by in-process Python runtime agents.

    Python runtime agents emit events directly as Python dicts.
    Events are tagged with provenance=raw and source=runtime.
    """
    return normalize_runtime_events(events, source="python_runtime")


def extract_python_runtime_signals(
    function_calls: list[dict[str, Any]],
    variable_accesses: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Extract instrumentation signals from Python runtime execution.

    Returns inferred events for function calls and variable accesses.
    """
    signals = []
    for call in function_calls:
        signals.append(
            {
                "kind": "function_call",
                "provenance": ProvenanceLevel.RAW.value,
                "source": ProvenanceSource.RUNTIME.value,
                "data": {
                    "function": call.get("function", ""),
                    "args_count": len(call.get("args", [])),
                },
            }
        )
    for access in variable_accesses:
        signals.append(
            {
                "kind": "variable_access",
                "provenance": ProvenanceLevel.INFERRED.value,
                "source": ProvenanceSource.RUNTIME.value,
                "data": {
                    "variable": access.get("variable", ""),
                    "operation": access.get("operation", "read"),
                },
            }
        )
    return signals


__all__ = [
    "normalize_python_runtime_events",
    "extract_python_runtime_signals",
]
