"""Instrumentation package for Agent Workbench telemetry provenance tracking.

This package provides:
- Provenance levels: raw, inferred, merged
- Provenance sources: workflow_trace, tool_call, prompt_usage, etc.
- Provenance tracking and summarization
- Runtime-specific event normalization (command, python, provider)

Instrumentation Strategy:
    Every telemetry field is tagged with its provenance level:
    - raw: directly observed from agent output
    - inferred: derived from heuristics or partial signals
    - merged: combined from multiple sources

    Confidence scores reflect the reliability of each field:
    - raw fields: 1.0 confidence
    - inferred fields: 0.8 confidence (configurable)
    - merged fields: 1/N confidence where N is the number of sources
"""

from __future__ import annotations

from typing import Any

from agentworkbench.instrumentation.base import (
    ProvenanceLevel,
    ProvenanceRecord,
    ProvenanceSource,
    ProvenanceTracker,
)
from agentworkbench.instrumentation.command_runtime import (
    extract_command_runtime_signals,
    normalize_command_runtime_events,
)
from agentworkbench.instrumentation.provider_runtime import (
    extract_provider_signals,
    normalize_provider_runtime_events,
)
from agentworkbench.instrumentation.python_runtime import (
    extract_python_runtime_signals,
    normalize_python_runtime_events,
)


def summarize_provenance(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize provenance records into a quality/confidence report.

    Args:
        records: List of provenance record dicts with 'provenance' field.

    Returns:
        Dict with quality, confidence, counts, and issues.
    """
    if not records:
        return {
            "quality": "empty",
            "confidence": 0.0,
            "raw_count": 0,
            "inferred_count": 0,
            "total_count": 0,
            "issues": ["No trace records found"],
        }

    raw_count = sum(1 for r in records if r.get("provenance") == "raw")
    inferred_count = sum(1 for r in records if r.get("provenance") == "inferred")
    total = len(records)

    if total == 0:
        quality = "empty"
        confidence = 0.0
    elif raw_count / total >= 0.8:
        quality = "high"
        confidence = 0.95
    elif raw_count / total >= 0.5:
        quality = "medium"
        confidence = 0.7
    else:
        quality = "low"
        confidence = 0.4

    issues = []
    if raw_count == 0 and inferred_count == 0:
        issues.append("No raw or inferred telemetry found")
    if all(r.get("provenance") == "inferred" for r in records):
        issues.append("All fields are inferred - may not match actual agent behavior")

    return {
        "quality": quality,
        "confidence": confidence,
        "raw_count": raw_count,
        "inferred_count": inferred_count,
        "total_count": total,
        "issues": issues,
    }


__all__ = [
    "ProvenanceLevel",
    "ProvenanceSource",
    "ProvenanceRecord",
    "ProvenanceTracker",
    "summarize_provenance",
    "normalize_command_runtime_events",
    "extract_command_runtime_signals",
    "normalize_python_runtime_events",
    "extract_python_runtime_signals",
    "normalize_provider_runtime_events",
    "extract_provider_signals",
]
