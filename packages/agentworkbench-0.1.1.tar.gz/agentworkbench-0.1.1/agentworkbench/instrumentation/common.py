"""Shared helpers for runtime instrumentation."""

from __future__ import annotations

from typing import Any

from agentworkbench.instrumentation.base import ProvenanceLevel


def normalize_runtime_events(events: list[dict[str, Any]], *, source: str) -> list[dict[str, Any]]:
    normalized = []
    for event in events:
        normalized_event = {
            "seq": event.get("seq", 0),
            "kind": event.get("kind", "unknown"),
            "name": event.get("name", ""),
            "label": event.get("label", ""),
            "source": source,
            "provenance": event.get("provenance", ProvenanceLevel.RAW.value),
            "data": event.get("data", {}),
        }
        normalized.append(normalized_event)
    return normalized
