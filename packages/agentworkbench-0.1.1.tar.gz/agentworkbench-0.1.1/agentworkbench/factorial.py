from __future__ import annotations

import itertools
from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.models import AgentSpec, ExperimentRecord
from agentworkbench.optimization_utils import short_variant_label, surface_targets, write_temp_agent_spec
from agentworkbench.reports import render_factorial_report, write_report
from agentworkbench.runner import (
    _load_experiment,
    _pareto_frontier,
    _record_summary,
    load_agent_spec,
    run_experiment,
)
from agentworkbench.surface_recommendations import build_surface_recommendations
from agentworkbench.tool_interfaces import (
    alternate_provider_tool_format,
    find_tool,
    loose_tool_schema,
    set_provider_tool_format,
    set_tool_description,
    set_tool_schema,
    tool_schema,
)
from agentworkbench.utils import created_at_utc, ensure_dir, slugify, write_json


def factorial_dir(project_root: Path) -> Path:
    return ensure_dir(control_dir(project_root) / "factorials")


def _candidate_factors(spec: AgentSpec, groups: list[str], source_record: ExperimentRecord | None) -> list[tuple[str, str]]:
    usage = source_record.behavior_summary if source_record else {}
    usage_counts = {
        "prompts": usage.get("prompt_usage_counts", {}) or {},
        "tools": usage.get("tool_usage_counts", {}) or {},
        "skills": usage.get("skill_usage_counts", {}) or {},
        "plugins": usage.get("plugin_usage_counts", {}) or {},
        "mcps": usage.get("mcp_usage_counts", {}) or {},
    }
    candidates: list[tuple[int, str, str]] = []
    tool_counts = usage_counts["tools"]
    for kind, name in surface_targets(spec, groups or ["prompts", "tools", "mcps"]):
        if kind == "tool_formats":
            count = max(sum(int(value) for value in tool_counts.values()), 1)
        elif kind in {"tool_docstrings", "tool_schemas"}:
            count = int(tool_counts.get(name, 0))
        else:
            count = int((usage_counts.get(kind) or {}).get(name, 0))
        candidates.append((count, kind, name))
    candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [(kind, name) for _count, kind, name in candidates]


def _apply_factor_state(spec: AgentSpec, kind: str, name: str, enabled: bool) -> None:
    if kind == "prompts":
        if not enabled:
            spec.prompts.pop(name, None)
        return
    if kind == "tool_docstrings":
        if not enabled:
            tool = find_tool(spec, name)
            if tool is not None:
                set_tool_description(tool, "")
        return
    if kind == "tool_schemas":
        if not enabled:
            tool = find_tool(spec, name)
            if tool is not None:
                current_schema = tool_schema(tool)
                if current_schema:
                    set_tool_schema(tool, loose_tool_schema(current_schema))
        return
    if kind == "tool_formats":
        if not enabled:
            set_provider_tool_format(spec, alternate_provider_tool_format(name))
        return
    items = getattr(spec, kind)
    for item in items:
        item_name = item.get("name") or item.get("id")
        if str(item_name) == name:
            item["enabled"] = bool(enabled)


def _factorial_spec(base_spec: AgentSpec, factorial_id: str, state: dict[tuple[str, str], bool]) -> AgentSpec:
    clone = base_spec.model_copy(deep=True)
    disabled = []
    for factor, enabled in state.items():
        kind, name = factor
        _apply_factor_state(clone, kind, name, enabled)
        if not enabled:
            disabled.append(f"{kind}-{slugify(name)}")
    suffix = "all-on" if not disabled else "off-" + short_variant_label(*disabled, limit=56)
    clone.id = f"{base_spec.id}-factorial-{suffix}"
    clone.metadata = {
        **(clone.metadata or {}),
        "factorial": {
            "factorial_id": factorial_id,
            "source_agent_id": base_spec.id,
            "state": {f"{kind}:{name}": enabled for (kind, name), enabled in state.items()},
        },
    }
    return clone


def _combo_delta(record: ExperimentRecord, baseline: ExperimentRecord) -> dict[str, float]:
    return {
        "average_score_delta": round(float(record.scores.get("average_score", 0.0)) - float(baseline.scores.get("average_score", 0.0)), 3),
        "passed_case_delta": round(float(record.scores.get("passed_cases", 0.0)) - float(baseline.scores.get("passed_cases", 0.0)), 3),
        "average_cost_delta": round(
            float(record.behavior_summary.get("average_cost_estimate", 0.0)) - float(baseline.behavior_summary.get("average_cost_estimate", 0.0)),
            6,
        ),
    }


def _factor_effects(factors: list[tuple[str, str]], combinations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    effects: list[dict[str, Any]] = []
    for factor in factors:
        on = [item for item in combinations if item["state_map"][factor]]
        off = [item for item in combinations if not item["state_map"][factor]]
        if not on or not off:
            continue
        on_score = sum(float(item["summary"]["average_score"]) for item in on) / len(on)
        off_score = sum(float(item["summary"]["average_score"]) for item in off) / len(off)
        on_cost = sum(float(item["summary"]["average_cost_estimate"]) for item in on) / len(on)
        off_cost = sum(float(item["summary"]["average_cost_estimate"]) for item in off) / len(off)
        on_evidence_use = sum(float(item["summary"].get("selected_evidence_use_rate") or 0.0) for item in on) / len(on)
        off_evidence_use = sum(float(item["summary"].get("selected_evidence_use_rate") or 0.0) for item in off) / len(off)
        effects.append(
            {
                "factor": f"{factor[0]}:{factor[1]}",
                "average_score_effect": round(on_score - off_score, 3),
                "average_cost_effect": round(on_cost - off_cost, 6),
                "selected_evidence_use_rate_effect": round(on_evidence_use - off_evidence_use, 3),
            }
        )
    return sorted(effects, key=lambda item: (-abs(float(item["average_score_effect"])), item["factor"]))


def _pair_interactions(factors: list[tuple[str, str]], combinations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    interactions: list[dict[str, Any]] = []
    for left_index, left in enumerate(factors):
        for right in factors[left_index + 1:]:
            combinations_for_pair = {}
            for left_state, right_state in itertools.product([False, True], repeat=2):
                matching = [
                    item
                    for item in combinations
                    if item["state_map"].get(left) == left_state and item["state_map"].get(right) == right_state
                ]
                if matching:
                    combinations_for_pair[(left_state, right_state)] = sum(
                        float(item["summary"]["average_score"]) for item in matching
                    ) / len(matching)
            if len(combinations_for_pair) < 4:
                continue
            interaction = (
                float(combinations_for_pair[(True, True)])
                - float(combinations_for_pair[(True, False)])
                - float(combinations_for_pair[(False, True)])
                + float(combinations_for_pair[(False, False)])
            )
            interactions.append(
                {
                    "pair": f"{left[0]}:{left[1]} x {right[0]}:{right[1]}",
                    "average_score_interaction": round(interaction, 3),
                }
            )
    return sorted(interactions, key=lambda item: (-abs(float(item["average_score_interaction"])), item["pair"]))


def run_factorial_experiments(
    project_root: Path,
    *,
    experiment_id: str | None = None,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    case_limit: int | None = None,
    groups: list[str] | None = None,
    factors: list[str] | None = None,
    factor_limit: int | None = None,
    keep_specs: bool = False,
) -> dict[str, Any]:
    source_record: ExperimentRecord
    control_record: ExperimentRecord
    explicit_selection = bool(case_ids or tags or match or case_limit is not None)
    if experiment_id:
        source_record, _aggregate = _load_experiment(project_root, experiment_id)
        agent_id = source_record.agent_id
        eval_id = source_record.eval_id
        subset = source_record.subset
        if not explicit_selection and not case_ids:
            case_ids = list(source_record.selected_case_ids or [])
        if explicit_selection:
            control_record, _aggregate = run_experiment(
                project_root,
                agent_id,
                eval_id,
                subset,
                case_ids=case_ids,
                tags=tags,
                match=match,
                limit=case_limit,
            )
        else:
            control_record = source_record
    else:
        if not agent_id or not eval_id:
            raise ValueError("Provide either --experiment or both --agent-id and --eval-id for factorial runs.")
        source_record, _aggregate = run_experiment(
            project_root,
            agent_id,
            eval_id,
            subset or "smoke",
            case_ids=case_ids,
            tags=tags,
            match=match,
            limit=case_limit,
        )
        experiment_id = source_record.experiment_id
        subset = subset or "smoke"
        control_record = source_record
    assert agent_id is not None
    assert eval_id is not None
    assert subset is not None
    base_spec = load_agent_spec(project_root, agent_id)
    selected_factors: list[tuple[str, str]]
    if factors:
        selected_factors = []
        for item in factors:
            kind, _, name = str(item).partition(":")
            if not kind or not name:
                raise ValueError("Factor entries must use `kind:name` format.")
            selected_factors.append((kind, name))
    else:
        selected_factors = _candidate_factors(base_spec, groups or ["prompts", "tools", "mcps"], control_record)
        if factor_limit is not None and factor_limit > 0:
            selected_factors = selected_factors[:factor_limit]
    if not selected_factors:
        raise ValueError("No prompt, tool, MCP, or tool-interface factors were available for factorial experiments.")
    factorial_id = f"factorial-{control_record.experiment_id}"
    combinations: list[dict[str, Any]] = []
    temp_paths: list[Path] = []
    records: list[ExperimentRecord] = [control_record]
    try:
        for enabled_values in itertools.product([False, True], repeat=len(selected_factors)):
            state = dict(zip(selected_factors, enabled_values, strict=True))
            if all(enabled_values):
                combinations.append(
                    {
                        "state": {f"{kind}:{name}": enabled for (kind, name), enabled in state.items()},
                        "state_map": state,
                        "experiment_id": control_record.experiment_id,
                        "summary": _record_summary(control_record),
                        "deltas": {"average_score_delta": 0.0, "passed_case_delta": 0.0, "average_cost_delta": 0.0},
                    }
                )
                continue
            variant = _factorial_spec(base_spec, factorial_id, state)
            temp_paths.append(write_temp_agent_spec(project_root, variant))
            record, _aggregate = run_experiment(
                project_root,
                variant.id,
                eval_id,
                subset,
                case_ids=case_ids,
                tags=tags,
                match=match,
                limit=case_limit,
            )
            records.append(record)
            combinations.append(
                {
                    "state": {f"{kind}:{name}": enabled for (kind, name), enabled in state.items()},
                    "state_map": state,
                    "experiment_id": record.experiment_id,
                    "summary": _record_summary(record),
                    "deltas": _combo_delta(record, control_record),
                }
            )
    finally:
        if not keep_specs:
            for path in temp_paths:
                if path.exists():
                    path.unlink()
    frontier = _pareto_frontier(records)
    factor_effects = _factor_effects(selected_factors, combinations)
    pair_interactions = _pair_interactions(selected_factors, combinations)
    payload = {
        "factorial_id": factorial_id,
        "created_at": created_at_utc(),
        "source_experiment_id": source_record.experiment_id,
        "control_experiment_id": control_record.experiment_id,
        "agent_id": agent_id,
        "eval_id": eval_id,
        "subset": subset,
        "benchmark_signature": control_record.benchmark_signature,
        "selection_fingerprint": control_record.selection_fingerprint,
        "selected_case_count": len(control_record.selected_case_ids or []),
        "selected_case_ids": control_record.selected_case_ids,
        "selected_factors": [f"{kind}:{name}" for kind, name in selected_factors],
        "combination_count": len(combinations),
        "results": [{key: value for key, value in item.items() if key != "state_map"} for item in combinations],
        "factor_effects": factor_effects,
        "pair_interactions": pair_interactions,
        "surface_recommendations": build_surface_recommendations(
            control_record.behavior_summary or {},
            factor_effects=factor_effects,
            pair_interactions=pair_interactions,
        ),
        "pareto_frontier": [_record_summary(record) for record in frontier],
        "temporary_spec_paths": [str(path.relative_to(project_root)) for path in temp_paths if path.exists()],
    }
    root = factorial_dir(project_root)
    write_json(root / f"{factorial_id}.json", payload)
    write_json(root / "latest.json", payload)
    write_report(root / f"{factorial_id}.md", render_factorial_report(payload))
    write_report(root / "latest.md", render_factorial_report(payload))
    return payload
