from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from agentworkbench.adapters import summarize_entrypoint
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.models import AgentSpec
from agentworkbench.utils import enabled_item_names


def _prompt_snapshots(project_root: Path | None, spec: AgentSpec) -> tuple[list[dict[str, Any]], str]:
    snapshots: list[dict[str, Any]] = []
    fingerprint_rows: list[dict[str, str]] = []
    for key, raw_value in sorted(spec.prompts.items()):
        prompt_key = str(key).strip()
        source = str(raw_value or "").strip()
        if not prompt_key or not source:
            continue
        source_type = "inline"
        source_path = ""
        content = source
        if project_root is not None:
            candidate = project_root / source
            if candidate.exists() and candidate.is_file():
                source_type = "file"
                source_path = (
                    str(candidate.relative_to(project_root)) if candidate.is_relative_to(project_root) else str(candidate)
                )
                content = candidate.read_text(encoding="utf-8", errors="ignore").strip()
        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
        fingerprint_rows.append({"key": prompt_key, "content_hash": content_hash})
        snapshots.append(
            {
                "key": prompt_key,
                "source_type": source_type,
                "source": source_path or source,
                "content_hash": content_hash,
                "preview": content[:240],
                "content": content,
            }
        )
    fingerprint = ""
    if fingerprint_rows:
        fingerprint = hashlib.sha256(json.dumps(fingerprint_rows, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    return snapshots, fingerprint


def _spec_snapshot(spec: AgentSpec, project_root: Path | None = None) -> dict[str, Any]:
    command_entrypoint, command_cwd = summarize_entrypoint(spec)
    prompt_snapshots, prompt_fingerprint = _prompt_snapshots(project_root, spec)
    return {
        "agent_id": spec.id,
        "spec_path": str(Path(CONTROL_DIR_NAME) / "agents" / f"{spec.id}.yaml"),
        "adapter": spec.adapter,
        "instruction_count": len(spec.instructions),
        "instructions": spec.instructions,
        "prompt_keys": sorted(spec.prompts.keys()),
        "prompt_fingerprint": prompt_fingerprint,
        "prompt_snapshots": prompt_snapshots,
        "model_name": str(spec.model.get("name") or spec.model.get("model_name") or "unknown"),
        "model_config": spec.model,
        "tool_names": enabled_item_names(spec.tools, sort=True),
        "skill_names": enabled_item_names(spec.skills, sort=True),
        "plugin_names": enabled_item_names(spec.plugins, sort=True),
        "mcp_names": enabled_item_names(spec.mcps, sort=True),
        "owned_paths": [str(item) for item in spec.owned_paths],
        "owned_globs": [str(item) for item in spec.owned_globs],
        "surface_paths": {
            str(key): [str(item) for item in value or []] for key, value in spec.surface_paths.items() if value
        },
        "required_env": [str(item) for item in spec.required_env],
        "command_entrypoint": command_entrypoint,
        "command_cwd": command_cwd,
        "runtime": spec.runtime,
        "metadata": spec.metadata,
    }


def _aggregate_results(results: list[dict[str, Any]]) -> dict[str, Any]:
    total_cases = len(results)
    passed_cases = sum(1 for item in results if item["passed"])
    average_score = sum(item["score"] for item in results) / total_cases if total_cases else 0.0
    metric_totals: dict[str, float] = {}
    metric_weights: dict[str, float] = {}
    metric_pass_counts: dict[str, int] = {}
    metric_case_counts: dict[str, int] = {}
    for item in results:
        for score in item.get("scores", []):
            name = str(score.get("name") or "unnamed_metric")
            metric_totals[name] = metric_totals.get(name, 0.0) + float(score.get("value", 0.0))
            metric_weights[name] = float(score.get("weight", metric_weights.get(name, 1.0)))
            metric_case_counts[name] = metric_case_counts.get(name, 0) + 1
            if bool(score.get("passed", False)):
                metric_pass_counts[name] = metric_pass_counts.get(name, 0) + 1
    metric_averages = {
        name: (metric_totals[name] / metric_case_counts[name]) if metric_case_counts[name] else 0.0
        for name in sorted(metric_totals)
    }
    metric_pass_rates = {
        name: (metric_pass_counts.get(name, 0) / metric_case_counts[name]) if metric_case_counts[name] else 0.0
        for name in sorted(metric_case_counts)
    }
    weighted_metric_contributions = {
        name: round(metric_averages[name] * float(metric_weights.get(name, 1.0)), 3) for name in sorted(metric_averages)
    }
    return {
        "total_cases": total_cases,
        "passed_cases": passed_cases,
        "average_score": average_score,
        "metric_averages": metric_averages,
        "metric_pass_rates": metric_pass_rates,
        "metric_weights": {name: metric_weights[name] for name in sorted(metric_weights)},
        "weighted_metric_contributions": weighted_metric_contributions,
    }


__all__ = [
    "_spec_snapshot",
    "_aggregate_results",
]
