from __future__ import annotations

from typing import Any

USAGE_EVENT_KINDS = {"retrieval", "memory_lookup", "tool", "tool_result"}


def workflow_surface_names(artifact: dict[str, Any], prefix: str) -> set[str]:
    names: set[str] = set()
    marker = f"{prefix}:"
    for item in artifact.get("workflow_trace") or []:
        label = str(item or "").strip()
        if label.startswith(marker):
            names.add(label.split(":", 1)[1].strip())
    return {name for name in names if name}


def tool_call_names(artifact: dict[str, Any]) -> list[str]:
    names: list[str] = []
    for item in artifact.get("tool_calls") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or item.get("tool") or item.get("id") or "").strip()
        if name:
            names.append(name)
    return names


def referenced_tool_names(artifact: dict[str, Any], *, include_skipped: bool = False) -> set[str]:
    names = workflow_surface_names(artifact, "tool")
    for item in artifact.get("events") or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "")
        if kind not in USAGE_EVENT_KINDS:
            continue
        if not include_skipped and str(item.get("status") or "").strip().lower() == "skipped":
            continue
        name = str(item.get("tool") or item.get("name") or "").strip()
        if name:
            names.add(name)
    for name in tool_call_names(artifact):
        names.add(name)
    return names


def referenced_mcp_names(artifact: dict[str, Any], *, include_skipped: bool = False) -> set[str]:
    names = workflow_surface_names(artifact, "mcp")
    for item in artifact.get("events") or []:
        if not isinstance(item, dict):
            continue
        if not include_skipped and str(item.get("status") or "").strip().lower() == "skipped":
            continue
        name = str(item.get("mcp") or "").strip()
        if name:
            names.add(name)
    for item in artifact.get("tool_calls") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("mcp") or "").strip()
        if name:
            names.add(name)
    return names
