"""Benchmark Quality Metrics - Validate and measure benchmark quality.

This module provides metrics to assess benchmark quality, ensuring
that benchmarks are discriminative, reliable, and representative.

Usage:
    from agentworkbench.benchmark_quality import BenchmarkQuality, compute_benchmark_quality

    quality = compute_benchmark_quality(
        benchmark=benchmark_bundle,
        brief=behavior_brief,
        experiments=experiment_records,
    )

    print(f"Coverage: {quality.coverage:.1%}")
    print(f"Discrimination: {quality.discrimination:.1%}")
    print(f"Recommendation: {quality.recommendation}")
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class BenchmarkQuality:
    """Quality metrics for a benchmark."""

    coverage: float = 0.0  # % of brief behaviors tested
    discrimination: float = 0.0  # Pass/fail spread (not 0% or 100%)
    reliability: float = 0.0  # Test-retest correlation
    agreement: float = 0.0  # vs. human scoring
    diversity: float = 0.0  # Case similarity analysis

    overall_score: float = 0.0
    recommendation: str = "unknown"
    warnings: list[str] = field(default_factory=list)

    def is_acceptable(self, min_quality: float = 0.5) -> bool:
        """Check if benchmark passes quality threshold."""
        return self.overall_score >= min_quality


@dataclass
class CaseQuality:
    """Quality metrics for individual cases."""

    difficulty: float = 0.0
    is_reliable: bool = True
    is_discriminative: bool = True


def compute_coverage(
    benchmark_cases: list[dict],
    brief_behaviors: list[dict],
) -> float:
    """Compute what % of brief behaviors are tested.

    Args:
        benchmark_cases: List of eval cases
        brief_behaviors: List of desired behavior specs from brief

    Returns:
        Coverage score 0-1
    """
    if not brief_behaviors:
        return 0.5  # Default if no brief

    # Map behavior categories
    behavior_tags: set[str] = set()
    for bh in brief_behaviors:
        behavior_tags.update(bh.get("tags", []))
        behavior_tags.add(bh.get("category", ""))

    if not behavior_tags:
        return 0.5

    # Count cases covering each behavior
    coverage_per_behavior: dict[str, int] = {b: 0 for b in behavior_tags}

    for case in benchmark_cases:
        case_tags = set(case.get("tags", []))
        for b in behavior_tags:
            if b in case_tags:
                coverage_per_behavior[b] += 1

    # What % of behaviors have at least 1 case?
    covered = sum(1 for v in coverage_per_behavior.values() if v > 0)
    return covered / len(coverage_per_behavior)


def compute_discrimination(
    experiment_results: list[dict],
    baseline_results: list[dict] | None = None,
) -> float:
    """Compute discrimination - spread of pass/fail rates.

    A good benchmark should not give everyone 0% or 100%.

    Args:
        experimental_results: Results from candidate experiments
        baseline_results: Optional baseline for comparison

    Returns:
        Discrimination score (0-1, higher is better)
    """
    if not experiment_results:
        return 0.5

    # Collect pass rates
    pass_rates: list[float] = []

    for result in experiment_results:
        passed = result.get("passed_cases", 0)
        total = result.get("total_cases", 1)
        rate = float(passed) / max(1.0, float(total))
        pass_rates.append(rate)

    if baseline_results:
        for result in baseline_results:
            passed = result.get("passed_cases", 0)
            total = result.get("total_cases", 1)
            pass_rates.append(float(passed) / max(1.0, float(total)))

    if not pass_rates:
        return 0.0

    # Good discrimination = not all 0 or all 1
    # Ideal: mean around 0.5 with spread
    mean_rate = sum(pass_rates) / len(pass_rates)

    # Spread (standard deviation)
    spread = (sum((r - mean_rate) ** 2 for r in pass_rates) / len(pass_rates)) ** 0.5

    # Score: want mean around 0.5 with high spread
    # Penalize if mean is near 0 or 1
    mean_score = 1 - abs(mean_rate - 0.5) * 2  # Max at 0.5
    spread_score = min(spread * 2, 1.0)  # Max spread = 0.5

    return float((mean_score + spread_score) / 2)


def compute_reliability(
    experiment_results: list[dict],
    stability_data: list[dict] | None = None,
) -> float:
    """Compute test-retest reliability.

    Runs same agent on same cases multiple times -
    how consistent are results?

    Args:
        experiment_results: Single experiment or list
        stability_data: Optional stability series data

    Returns:
        Reliability correlation 0-1
    """
    if not stability_data:
        # Try to get from experiment results
        stability_data = []
        for r in experiment_results:
            if "stability_series" in r:
                stability_data.extend(r["stability_series"])

    if len(stability_data) < 2:
        return 0.5  # Can't compute

    # Compute correlation between runs
    scores = [s.get("score", 0) for s in stability_data]

    if len(scores) < 2:
        return 0.5

    mean = sum(scores) / len(scores)
    variance = sum((s - mean) ** 2 for s in scores) / len(scores)

    if variance < 1e-10:
        return 0.5

    # Coefficient of variation
    cv = variance**0.5 / mean if mean > 0 else 1.0

    # Reliability = 1 - CV (lower variation = higher reliability)
    return max(0, min(1, 1 - cv))


def compute_diversity(
    cases: list[dict],
) -> float:
    """Compute case diversity - how different are cases?

    Args:
        cases: List of eval cases

    Returns:
        Diversity score 0-1
    """
    if len(cases) < 2:
        return 0.0

    # Compute pairwise similarity
    # Simplify: use prompt length variance
    lengths = [len(str(c.get("input") or c.get("prompt") or "")) for c in cases]

    if not lengths:
        return 0.0

    # High variance = high diversity
    mean_len = sum(lengths) / len(lengths)
    variance = sum((length - mean_len) ** 2 for length in lengths) / len(lengths)
    stddev = variance**0.5

    # Normalize by mean (coefficient of variation)
    if mean_len < 1:
        return 0.0

    cv = stddev / mean_len

    # Good diversity: CV around 0.3-0.5
    return float(min(cv * 2, 1.0))


def compute_agreement(
    scorer_predictions: list[bool],
    human_judgments: list[bool],
) -> float:
    """Compute agreement between scorer and human.

    Args:
        scorer_predictions: What scorer predicted
        human_judgments: What human judged

    Returns:
        Agreement score 0-1
    """
    if len(scorer_predictions) != len(human_judgments):
        return 0.5

    if not scorer_predictions:
        return 0.5

    agreements = sum(1 for s, h in zip(scorer_predictions, human_judgments, strict=True) if s == h)

    return agreements / len(scorer_predictions)


def compute_benchmark_quality(
    benchmark_cases: list[dict],
    brief_behaviors: list[dict] | None = None,
    experiments: list[dict] | None = None,
    stability_data: list[dict] | None = None,
    human_judgments: list[bool] | None = None,
) -> BenchmarkQuality:
    """Compute comprehensive benchmark quality.

    Args:
        benchmark_cases: List of cases in benchmark
        brief_behaviors: Optional behaviors to test
        experiments: Optional experiment results
        stability_data: Optional stability series
        human_judgments: Optional human validation

    Returns:
        BenchmarkQuality with all metrics
    """
    quality = BenchmarkQuality()
    warnings = []

    # Compute individual metrics
    quality.coverage = compute_coverage(benchmark_cases, brief_behaviors or [])
    quality.discrimination = compute_discrimination(experiments or [])
    quality.reliability = compute_reliability(experiments or [], stability_data)
    quality.diversity = compute_diversity(benchmark_cases)

    if human_judgments and experiments:
        scorer_preds = []
        for exp in experiments:
            passed = exp.get("passed_cases", 0)
            total = exp.get("total_cases", 1)
            # Convert to boolean predictions (pass if > 50%)
            scorer_preds.append(passed / max(1, total) >= 0.5)
        quality.agreement = compute_agreement(scorer_preds, human_judgments)
    else:
        quality.agreement = 0.5  # Default when no human data

    # Overall score (weighted)
    quality.overall_score = (
        quality.coverage * 0.25
        + quality.discrimination * 0.30
        + quality.reliability * 0.20
        + quality.diversity * 0.15
        + quality.agreement * 0.10
    )

    # Warnings for issues
    if quality.coverage < 0.5:
        warnings.append(f"Low coverage: only {quality.coverage:.0%} of behaviors tested")

    if quality.discrimination < 0.3:
        warnings.append("Poor discrimination: all cases too easy or too hard")

    if quality.reliability < 0.5:
        warnings.append("Low reliability: inconsistent results")

    if quality.diversity < 0.2:
        warnings.append("Low diversity: cases too similar")

    quality.warnings = warnings

    # Recommendation
    if quality.overall_score >= 0.7:
        quality.recommendation = "excellent"
    elif quality.overall_score >= 0.5:
        quality.recommendation = "acceptable"
    elif quality.overall_score >= 0.3:
        quality.recommendation = "needs_improvement"
    else:
        quality.recommendation = "poor"

    return quality


def check_benchmark_quality(
    benchmark_cases: list[dict],
    min_quality: float = 0.5,
    **kwargs,
) -> tuple[bool, BenchmarkQuality]:
    """Check if benchmark meets quality bar.

    Returns:
        (passes, quality_metrics)
    """
    quality = compute_benchmark_quality(benchmark_cases, **kwargs)
    return quality.is_acceptable(min_quality), quality


__all__ = [
    "BenchmarkQuality",
    "CaseQuality",
    "compute_benchmark_quality",
    "compute_coverage",
    "compute_discrimination",
    "compute_reliability",
    "compute_diversity",
    "compute_agreement",
    "check_benchmark_quality",
]
