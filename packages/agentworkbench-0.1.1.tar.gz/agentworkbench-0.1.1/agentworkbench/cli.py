"""Command-line interface for Agent Workbench."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from agentworkbench import __version__
from agentworkbench.thresholds import load_thresholds

_FORMAT_CHOICES = ("json", "text")


def _json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if hasattr(value, "model_dump"):
        return _json_safe(value.model_dump(mode="json"))
    if is_dataclass(value) and not isinstance(value, type):
        return _json_safe(asdict(value))
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _print_json(payload: Any) -> None:
    print(json.dumps(_json_safe(payload), indent=2))


def _print_text(message: str) -> None:
    print(message)


def _existing_project_root(project_root: Path) -> Path:
    from agentworkbench.config import find_project_root

    return find_project_root(project_root.resolve())


def _path_arg(value: str | None) -> Path | None:
    if not value:
        return None
    return Path(value)


def _parse_json_objects(raw_values: list[str] | None, *, flag: str) -> list[dict[str, Any]] | None:
    if not raw_values:
        return None
    parsed: list[dict[str, Any]] = []
    for item in raw_values:
        try:
            payload = json.loads(item)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON for `{flag}`: {exc.msg}") from exc
        if not isinstance(payload, dict):
            raise ValueError(f"`{flag}` entries must decode to JSON objects.")
        parsed.append(payload)
    return parsed


def _require(value: str | None, message: str) -> str:
    if not value or not str(value).strip():
        raise ValueError(message)
    return str(value)


def _add_case_selection_args(
    parser: argparse.ArgumentParser,
    *,
    limit_flags: tuple[str, ...] = ("--case-limit",),
    limit_dest: str = "case_limit",
) -> None:
    parser.add_argument("--case-id", action="append", dest="case_ids")
    parser.add_argument("--tag", action="append", dest="tags")
    parser.add_argument("--match")
    if limit_flags:
        parser.add_argument(*limit_flags, dest=limit_dest, type=int)


def _doctor_payload(project_root: Path) -> dict[str, Any]:
    from agentworkbench.config import control_dir

    root = _existing_project_root(project_root)
    control = control_dir(root)
    issues: list[str] = []
    checks = {
        "install": True,
        "control_dir": control.exists(),
        "workbench_yaml": (control / "workbench.yaml").exists(),
    }
    if not checks["control_dir"]:
        issues.append(f"Control directory not found: {control}")
    if not checks["workbench_yaml"]:
        issues.append(f"workbench.yaml not found: {control / 'workbench.yaml'}")
    checks["install"] = all(bool(value) for value in checks.values())
    return {
        "project_root": str(root),
        "healthy": not issues,
        "issues": issues,
        "checks": checks,
    }


def _doctor_text(payload: dict[str, Any]) -> str:
    lines = [
        "Doctor",
        f"Project Root: {payload.get('project_root', '')}",
        f"Healthy: {'yes' if payload.get('healthy') else 'no'}",
    ]
    checks = payload.get("checks") or {}
    for name, passed in checks.items():
        lines.append(f"{name}: {'ok' if passed else 'missing'}")
    for issue in payload.get("issues") or []:
        lines.append(f"Issue: {issue}")
    return "\n".join(lines)


def _trace_validate_payload(project_root: Path, experiment_id: str) -> dict[str, Any]:
    from agentworkbench.instrumentation import summarize_provenance
    from agentworkbench.runner import _load_experiment, _load_run_rows

    record, aggregate = _load_experiment(project_root, experiment_id)
    rows = _load_run_rows(project_root, experiment_id)
    trace_events = [
        dict(event)
        for row in rows
        for event in ((row.get("artifact") or {}).get("trace_events") or [])
        if isinstance(event, dict)
    ]
    return {
        "experiment_id": experiment_id,
        "agent_id": record.agent_id,
        "eval_id": record.eval_id,
        "subset": record.subset,
        "row_count": len(rows),
        "trace_event_count": len(trace_events),
        "aggregate": aggregate,
        "provenance_summary": summarize_provenance(trace_events),
    }


def _field_sources(trace_events: list[dict[str, Any]], prefixes: list[str]) -> list[dict[str, Any]]:
    matches: list[dict[str, Any]] = []
    for event in trace_events:
        kind = str(event.get("kind") or "")
        name = str(event.get("name") or "")
        label = f"{kind}:{name}" if name else kind
        if any(label.startswith(prefix) or name == prefix.split(":", 1)[-1] for prefix in prefixes):
            matches.append(
                {
                    "kind": kind,
                    "name": name,
                    "source": str(event.get("source") or ""),
                    "provenance": str(event.get("provenance") or ""),
                }
            )
    return matches


def _trace_explain_payload(project_root: Path, experiment_id: str, case_id: str | None = None) -> dict[str, Any]:
    from agentworkbench.instrumentation import summarize_provenance
    from agentworkbench.runner import _load_experiment, _load_run_rows

    record, _aggregate = _load_experiment(project_root, experiment_id)
    rows = _load_run_rows(project_root, experiment_id)
    if case_id:
        row = next((item for item in rows if str((item.get("case") or {}).get("id") or "") == str(case_id)), None)
        if row is None:
            raise ValueError(f"Case `{case_id}` was not found in experiment `{experiment_id}`.")
    else:
        row = rows[0] if rows else None
    if row is None:
        raise ValueError(f"Experiment `{experiment_id}` has no recorded run rows.")
    artifact = dict(row.get("artifact") or {})
    trace_events = [dict(event) for event in artifact.get("trace_events", []) if isinstance(event, dict)]
    resolved_case_id = str((row.get("case") or {}).get("id") or "")
    field_provenance = {
        "workflow_trace": {
            "value": artifact.get("workflow_trace") or [],
            "sources": _field_sources(trace_events, ["tool:", "prompt:", "skill:", "plugin:", "mcp:"]),
        },
        "tool_calls": {
            "value": artifact.get("tool_calls") or [],
            "sources": _field_sources(trace_events, ["tool:"]),
        },
        "prompt_keys_used": {
            "value": artifact.get("prompt_keys_used") or [],
            "sources": _field_sources(trace_events, ["prompt:"]),
        },
        "skills_used": {
            "value": artifact.get("skills_used") or [],
            "sources": _field_sources(trace_events, ["skill:"]),
        },
        "plugins_used": {
            "value": artifact.get("plugins_used") or [],
            "sources": _field_sources(trace_events, ["plugin:"]),
        },
        "mcp_servers_used": {
            "value": artifact.get("mcp_servers_used") or [],
            "sources": _field_sources(trace_events, ["mcp:"]),
        },
        "trace_events": {
            "count": len(trace_events),
            "summary": summarize_provenance(trace_events),
        },
    }
    return {
        "experiment_id": experiment_id,
        "agent_id": record.agent_id,
        "eval_id": record.eval_id,
        "subset": record.subset,
        "case_id": resolved_case_id,
        "field_provenance": field_provenance,
    }


def _trace_text(payload: dict[str, Any]) -> str:
    lines = [
        f"Experiment: {payload.get('experiment_id', '')}",
        f"Eval: {payload.get('eval_id', '')}",
        f"Subset: {payload.get('subset', '')}",
    ]
    if payload.get("case_id"):
        lines.append(f"Case: {payload['case_id']}")
    if "provenance_summary" in payload:
        summary = payload["provenance_summary"]
        lines.append(
            f"Trace provenance: {summary.get('quality', 'unknown')} confidence={summary.get('confidence', 0.0)}"
        )
    return "\n".join(lines)


def _dispatch_replay(project_root: Path, args: argparse.Namespace) -> int:
    from agentworkbench.artifacts import load_compare_payload
    from agentworkbench.runner import _load_experiment, run_experiment

    source_record = None
    case_ids = [str(item) for item in (args.case_ids or []) if str(item).strip()]
    replay_source: dict[str, Any]
    if args.experiment:
        source_record, _aggregate = _load_experiment(project_root, args.experiment)
        selected_case_ids = case_ids or list(source_record.selected_case_ids or [])
        replay_source = {
            "selection_mode": "case_ids" if case_ids else "source_experiment_defaults",
            "source_experiment_id": source_record.experiment_id,
            "selected_case_ids": selected_case_ids,
        }
    else:
        baseline_id = _require(args.baseline, "Replay from clusters requires `--baseline`.")
        candidate_id = _require(args.candidate, "Replay from clusters requires `--candidate`.")
        cluster_ids = [str(item) for item in (args.cluster_ids or []) if str(item).strip()]
        if not cluster_ids:
            raise ValueError("Replay from a comparison requires at least one `--cluster`.")
        compare_payload = load_compare_payload(
            project_root,
            baseline_id=baseline_id,
            candidate_id=candidate_id,
        )
        selected_case_ids = list(case_ids)
        for cluster in compare_payload.get("failure_clusters", []) or []:
            cluster_id = str(cluster.get("cluster_id") or cluster.get("category") or "")
            if cluster_id in cluster_ids:
                selected_case_ids.extend(str(item) for item in cluster.get("case_ids", []) if str(item).strip())
        selected_case_ids = list(dict.fromkeys(selected_case_ids))
        if not selected_case_ids:
            raise ValueError("No cases matched the requested replay cluster selection.")
        source_record, _aggregate = _load_experiment(project_root, candidate_id)
        replay_source = {
            "selection_mode": "clusters",
            "comparison": {
                "baseline_id": baseline_id,
                "candidate_id": candidate_id,
                "cluster_ids": cluster_ids,
            },
            "selected_case_ids": selected_case_ids,
        }
    record, aggregate = run_experiment(
        project_root,
        source_record.agent_id,
        source_record.eval_id,
        source_record.subset,
        case_ids=selected_case_ids,
    )
    _print_json(
        {
            "experiment": record,
            "aggregate": aggregate,
            "replay_source": replay_source,
        }
    )
    return 0


def _dispatch_show(project_root: Path, args: argparse.Namespace) -> int:
    from agentworkbench.artifacts import (
        load_case_bundle,
        load_compare_payload,
        load_experiment_bundle,
    )

    if args.show_command == "experiment":
        _print_json(load_experiment_bundle(project_root, args.experiment))
        return 0
    if args.show_command == "case":
        _print_json(load_case_bundle(project_root, args.experiment, args.case_id))
        return 0
    if args.show_command == "compare":
        _print_json(
            load_compare_payload(
                project_root,
                baseline_id=args.baseline,
                candidate_id=args.candidate,
                latest=args.latest,
            )
        )
        return 0
    raise ValueError(f"Unknown show command `{args.show_command}`.")


def _dispatch_artifacts(project_root: Path, args: argparse.Namespace) -> int:
    from agentworkbench.artifacts import (
        export_experiment_bundle,
        export_review_html,
        load_case_bundle,
        load_compare_payload,
        load_experiment_bundle,
        migrate_artifacts,
    )

    command = args.artifacts_command
    if command == "show":
        _print_json(load_experiment_bundle(project_root, args.experiment))
        return 0
    if command == "case":
        _print_json(load_case_bundle(project_root, args.experiment, args.case_id))
        return 0
    if command == "compare":
        _print_json(
            load_compare_payload(
                project_root,
                baseline_id=args.baseline,
                candidate_id=args.candidate,
                latest=args.latest,
            )
        )
        return 0
    if command == "export":
        _print_json(export_experiment_bundle(project_root, args.experiment, output_path=_path_arg(args.output)))
        return 0
    if command == "review":
        _print_json(
            export_review_html(
                project_root,
                args.experiment,
                output_path=_path_arg(args.output),
                baseline_id=args.baseline,
                queue_id=args.queue_id,
            )
        )
        return 0
    if command == "migrate":
        _print_json(migrate_artifacts(project_root, check_only=args.check))
        return 0
    raise ValueError(f"Unknown artifacts command `{command}`.")


def build_parser() -> argparse.ArgumentParser:
    thresholds = load_thresholds()
    parser = argparse.ArgumentParser(
        prog="awb",
        description="Agent Workbench CLI for learning, evaluating, and optimizing repo-native agents.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--project-root", default=Path.cwd(), type=Path, help="Project root directory.")
    subparsers = parser.add_subparsers(dest="command", required=True, title="commands")

    subparsers.add_parser("init", help="Initialize Agent Workbench in the current repository.")
    subparsers.add_parser("learn", help="Discover repository structure and generate repo-learning artifacts.")

    brief = subparsers.add_parser("brief", help="Create and manage behavior briefs.")
    brief_sub = brief.add_subparsers(dest="brief_command", required=True)
    brief_start = brief_sub.add_parser("start", help="Start a new behavior brief.")
    brief_start.add_argument("--brief-id", required=True)
    brief_start.add_argument("--goal", required=True)
    brief_start.add_argument("--agent-id")
    brief_draft = brief_sub.add_parser("draft", help="Draft a behavior brief from an agent spec.")
    brief_draft.add_argument("--brief-id", required=True)
    brief_draft.add_argument("--agent-id", required=True)
    brief_draft.add_argument("--goal", default="")
    brief_finalize = brief_sub.add_parser("finalize", help="Approve a behavior brief after review.")
    brief_finalize.add_argument("--brief-id", required=True)
    brief_packet = brief_sub.add_parser("packet", help="Generate the brief interview packet.")
    brief_packet.add_argument("--brief-id", required=True)
    brief_packet.add_argument("--agent-id")

    evals = subparsers.add_parser("evals", help="Generate, review, expand, and approve eval suites.")
    evals_sub = evals.add_subparsers(dest="evals_command", required=True)
    evals_generate = evals_sub.add_parser("generate", help="Generate an eval suite from an approved brief.")
    evals_generate.add_argument("--brief-id", required=True)
    evals_generate.add_argument("--eval-id", required=True)
    evals_review = evals_sub.add_parser("review", help="Write the human-readable eval review report.")
    evals_review.add_argument("--eval-id", required=True)
    evals_approve = evals_sub.add_parser("approve", help="Approve an eval suite for execution.")
    evals_approve.add_argument("--eval-id", required=True)
    evals_approve.add_argument("--min-quality", type=float, default=0.3)
    evals_expand = evals_sub.add_parser("expand", help="Expand an eval suite from brief and failure signals.")
    evals_expand.add_argument("--eval-id", required=True)
    evals_expand.add_argument("--brief-id")
    evals_expand.add_argument("--experiment")
    evals_expand.add_argument("--agent-id")
    evals_expand.add_argument("--subset")
    evals_expand.add_argument("--benchmark-signature")
    _add_case_selection_args(evals_expand, limit_flags=())
    evals_expand.add_argument("--cluster-id", action="append", dest="cluster_ids")
    evals_expand.add_argument("--focus-limit", type=int, default=4)
    evals_expand.add_argument("--brief-limit", type=int, default=6)
    evals_expand.add_argument("--source", action="append", dest="sources")
    evals_export = evals_sub.add_parser("export", help="Export an eval suite bundle.")
    evals_export.add_argument("--eval-id", required=True)
    evals_export.add_argument("--output")
    evals_export.add_argument("--benchmark-id")
    evals_import = evals_sub.add_parser("import", help="Import an eval suite bundle.")
    evals_import.add_argument("--input", required=True)
    evals_import.add_argument("--eval-id")
    evals_import.add_argument("--force", action="store_true")

    run = subparsers.add_parser("run", help="Run an agent against an approved eval suite.")
    run.add_argument("--agent-id")
    run.add_argument("--eval-id")
    run.add_argument("--subset", default="smoke")
    _add_case_selection_args(run, limit_flags=("--limit", "--case-limit"), limit_dest="limit")
    run.add_argument("--active-learning", action="store_true")
    run.add_argument("--learned-scorer")
    run.add_argument("--repeat", type=int, default=1)
    run.add_argument("--series-label")
    run.add_argument("--jobs", type=int, default=1)
    run.add_argument("--resume-experiment")
    run_sub = run.add_subparsers(dest="run_command")
    run_chain = run_sub.add_parser("chain", help="Run a multi-agent chain.")
    run_chain.add_argument("--agent-id", action="append", dest="chain_agent_ids", required=True)
    run_chain.add_argument("--eval-id", required=True)
    run_chain.add_argument("--subset", default="smoke")
    _add_case_selection_args(run_chain, limit_flags=("--limit", "--case-limit"), limit_dest="limit")
    run_chain.add_argument("--chain-handoff-template", default="{prior_output}")
    run_chain.add_argument("--step-config", action="append", dest="step_configs")
    run_workflow = run_sub.add_parser("workflow", help="Run a workflow spec.")
    run_workflow.add_argument("--workflow-file", required=True)
    run_workflow.add_argument("--eval-id", required=True)
    run_workflow.add_argument("--subset", default="smoke")
    _add_case_selection_args(run_workflow, limit_flags=("--limit", "--case-limit"), limit_dest="limit")
    run_workflow.add_argument("--workflow-handoff-template", default="{prior_output}")
    run_workflow_alias = subparsers.add_parser("run-workflow", help="Compatibility alias for `awb run workflow`.")
    run_workflow_alias.add_argument("--workflow-file", required=True)
    run_workflow_alias.add_argument("--eval-id", required=True)
    run_workflow_alias.add_argument("--subset", default="smoke")
    _add_case_selection_args(run_workflow_alias, limit_flags=("--limit", "--case-limit"), limit_dest="limit")
    run_workflow_alias.add_argument("--workflow-handoff-template", default="{prior_output}")
    run_replay = run_sub.add_parser("replay", help="Replay cases from a prior experiment or failure cluster.")
    run_replay.add_argument("--experiment")
    run_replay.add_argument("--baseline")
    run_replay.add_argument("--candidate")
    run_replay.add_argument("--case-id", action="append", dest="case_ids")
    run_replay.add_argument("--cluster", action="append", dest="cluster_ids")

    optimize = subparsers.add_parser("optimize", help="Run bounded optimization over agent surfaces.")
    optimize.add_argument("--experiment")
    optimize.add_argument("--agent-id")
    optimize.add_argument("--eval-id")
    optimize.add_argument("--subset")
    optimize.add_argument("--benchmark-signature")
    optimize.add_argument("--baseline")
    _add_case_selection_args(optimize)
    optimize.add_argument("--surface", action="append", dest="surfaces")
    optimize.add_argument("--budget", type=int, default=6)
    optimize.add_argument("--proposal-limit", type=int, default=3)
    optimize.add_argument("--matrix-agent-id", action="append", dest="matrix_agent_ids")
    optimize.add_argument("--temperature", action="append", dest="temperatures", type=float)
    optimize.add_argument("--max-tokens", action="append", dest="max_tokens", type=int)
    optimize.add_argument("--bayesian", action="store_true")

    compare = subparsers.add_parser("compare", help="Compare two experiments.")
    compare.add_argument("--candidate", required=True)
    compare.add_argument("--baseline")
    compare.add_argument("--best", action="store_true")

    check = subparsers.add_parser("check", help="Run Codex loop-readiness checks.")
    check.add_argument("--agent-id")
    check.add_argument("--eval-id")
    check.add_argument("--subset", default="full")
    check.add_argument("--experiment")
    check.add_argument("--workflow-file")
    check.add_argument("--chain-agent-id", action="append", dest="chain_agent_ids")
    check.add_argument("--format", choices=_FORMAT_CHOICES, default="json")
    check.add_argument("--fail-on", choices=["none", "critical", "high", "medium", "warning"])

    status = subparsers.add_parser("status", help="Show stream, baseline, and optimization status.")
    status.add_argument("--agent-id")
    status.add_argument("--eval-id")
    status.add_argument("--subset")
    status.add_argument("--benchmark-signature")
    status.add_argument("--promoted-only", action="store_true")
    status.add_argument("--limit", type=int, default=thresholds.cli.limit_status)

    diagnose = subparsers.add_parser("diagnose", help="Diagnose experiment failures and bottlenecks.")
    diagnose.add_argument("--experiment")
    diagnose.add_argument("--agent-id")
    diagnose.add_argument("--eval-id")
    diagnose.add_argument("--subset")
    diagnose.add_argument("--benchmark-signature")
    diagnose.add_argument("--baseline")
    _add_case_selection_args(diagnose, limit_flags=())
    diagnose.add_argument("--cluster-id", action="append", dest="cluster_ids")
    diagnose.add_argument("--focus-limit", type=int, default=5)

    next_cmd = subparsers.add_parser("next", help="Generate recommended next steps from the current evidence.")
    next_cmd.add_argument("--experiment")
    next_cmd.add_argument("--agent-id")
    next_cmd.add_argument("--eval-id")
    next_cmd.add_argument("--subset")
    next_cmd.add_argument("--benchmark-signature")
    next_cmd.add_argument("--baseline")
    _add_case_selection_args(next_cmd, limit_flags=())
    next_cmd.add_argument("--cluster-id", action="append", dest="cluster_ids")
    next_cmd.add_argument("--focus-limit", type=int, default=5)
    next_cmd.add_argument("--limit", type=int, default=3)

    propose = subparsers.add_parser("propose", help="Generate bounded mutation proposals.")
    propose.add_argument("--experiment")
    propose.add_argument("--agent-id")
    propose.add_argument("--eval-id")
    propose.add_argument("--subset")
    propose.add_argument("--benchmark-signature")
    propose.add_argument("--baseline")
    propose.add_argument("--limit", type=int, default=3)

    patch = subparsers.add_parser("patch-template", help="Generate an editable implementation checklist.")
    patch.add_argument("--experiment")
    patch.add_argument("--proposal-id")

    matrix = subparsers.add_parser("matrix", help="Run a model/runtime experiment matrix.")
    matrix.add_argument("--agent-id", action="append", dest="agent_ids", required=True)
    matrix.add_argument("--eval-id", required=True)
    matrix.add_argument("--subset", default="smoke")
    _add_case_selection_args(matrix, limit_flags=("--limit", "--case-limit"), limit_dest="limit")
    matrix.add_argument("--temperature", action="append", dest="temperatures", type=float)
    matrix.add_argument("--max-tokens", action="append", dest="max_tokens", type=int)
    matrix.add_argument("--keep-specs", action="store_true")

    factorial = subparsers.add_parser("factorial", help="Run bounded factorial experiments.")
    factorial.add_argument("--experiment")
    factorial.add_argument("--agent-id")
    factorial.add_argument("--eval-id")
    factorial.add_argument("--subset")
    _add_case_selection_args(factorial)
    factorial.add_argument("--group", action="append", dest="groups")
    factorial.add_argument("--factor", action="append", dest="factors")
    factorial.add_argument("--factor-limit", type=int)
    factorial.add_argument("--keep-specs", action="store_true")

    promote = subparsers.add_parser("promote", help="Promote an experiment to the current baseline.")
    promote.add_argument("--experiment", required=True)
    promote.add_argument("--baseline")

    release = subparsers.add_parser("release", help="Summarize release readiness across streams.")
    release.add_argument("--agent-id")
    release.add_argument("--eval-id")
    release.add_argument("--subset")
    release.add_argument("--benchmark-signature")
    release.add_argument("--promoted-only", action="store_true")
    release.add_argument("--limit", type=int, default=20)

    adapters = subparsers.add_parser("adapters", help="List available adapters.")
    adapters.add_argument("--format", choices=_FORMAT_CHOICES, default="text")

    benchmarks = subparsers.add_parser("benchmarks", help="Manage registered benchmark bundles.")
    bench_sub = benchmarks.add_subparsers(dest="benchmarks_command", required=True)
    bench_register = bench_sub.add_parser("register", help="Register an eval suite as a benchmark bundle.")
    bench_register.add_argument("--eval-id", required=True)
    bench_register.add_argument("--benchmark-id")
    bench_register.add_argument("--force", action="store_true")
    bench_ingest = bench_sub.add_parser("ingest", help="Ingest a large benchmark source into raw sharded storage.")
    bench_ingest.add_argument("--source", required=True)
    bench_ingest.add_argument("--benchmark-id", required=True)
    bench_ingest.add_argument("--version", type=int)
    bench_ingest.add_argument("--source-name")
    bench_ingest.add_argument("--dataset-revision")
    bench_ingest.add_argument("--license", dest="license_name", default="")
    bench_ingest.add_argument("--scorer")
    bench_ingest.add_argument("--scorer-version", default="")
    bench_ingest.add_argument("--shard-size", type=int, default=5000)
    bench_ingest.add_argument("--workers", type=int, default=1)
    bench_normalize = bench_sub.add_parser("normalize", help="Normalize raw benchmark shards into AWB eval cases.")
    bench_normalize.add_argument("--benchmark-id", required=True)
    bench_normalize.add_argument("--version", type=int, required=True)
    bench_normalize.add_argument("--id-field", default="id")
    bench_normalize.add_argument("--input-field", default="input")
    bench_normalize.add_argument("--expected-field", default="expected")
    bench_normalize.add_argument("--rubric-field", default="rubric")
    bench_normalize.add_argument("--tags-field", default="tags")
    bench_normalize.add_argument("--metadata-field", default="metadata")
    bench_normalize.add_argument("--answer-type", action="append", dest="answer_types")
    bench_normalize.add_argument("--answer-source", default="source_dataset")
    bench_normalize.add_argument("--shard-size", type=int)
    bench_normalize.add_argument("--workers", type=int, default=1)
    bench_dedupe = bench_sub.add_parser("dedupe", help="Dedupe normalized benchmark cases into final shards.")
    bench_dedupe.add_argument("--benchmark-id", required=True)
    bench_dedupe.add_argument("--version", type=int, required=True)
    bench_dedupe.add_argument("--strategy", choices=["exact_input", "exact_case", "none"], default="exact_input")
    bench_dedupe.add_argument("--shard-size", type=int)
    bench_dedupe.add_argument("--workers", type=int, default=1)
    bench_validate = bench_sub.add_parser("validate", help="Validate a sharded benchmark ingestion artifact.")
    bench_validate.add_argument("--benchmark-id", required=True)
    bench_validate.add_argument("--version", type=int, required=True)
    bench_validate.add_argument("--workers", type=int, default=1)
    bench_review = bench_sub.add_parser("review", help="Create or approve the benchmark governance review queue.")
    bench_review.add_argument("--benchmark-id", required=True)
    bench_review.add_argument("--version", type=int, required=True)
    bench_review.add_argument("--approve", action="store_true")
    bench_review.add_argument("--reviewer", default="human")
    bench_review.add_argument("--guidance", default="")
    bench_publish = bench_sub.add_parser("publish", help="Publish a validated/reviewed sharded benchmark to the registry.")
    bench_publish.add_argument("--benchmark-id", required=True)
    bench_publish.add_argument("--version", type=int, required=True)
    bench_publish.add_argument("--eval-id")
    bench_publish.add_argument("--force", action="store_true")
    bench_ingested = bench_sub.add_parser("ingested", help="List or show sharded benchmark ingestion manifests.")
    bench_ingested.add_argument("--benchmark-id")
    bench_ingested.add_argument("--version", type=int)
    bench_jobs = bench_sub.add_parser("jobs", help="List or show benchmark ingestion jobs.")
    bench_jobs.add_argument("--job-id")
    bench_jobs.add_argument("--limit", type=int, default=20)
    bench_list = bench_sub.add_parser("list", help="List registered benchmarks.")
    bench_list.add_argument("--all-versions", action="store_true")
    bench_list.add_argument("--tags", action="append")
    bench_list.add_argument("--match")
    bench_list.add_argument("--capability")
    bench_list.add_argument("--agent-type")
    bench_list.add_argument("--approval-status")
    bench_list.add_argument("--format", choices=_FORMAT_CHOICES, default="json")
    bench_show = bench_sub.add_parser("show", help="Show benchmark details.")
    bench_show.add_argument("--benchmark-id", required=True)
    bench_show.add_argument("--version", type=int)
    bench_check = bench_sub.add_parser("check", help="Validate a benchmark bundle.")
    bench_check.add_argument("--benchmark-id", required=True)
    bench_check.add_argument("--version", type=int)
    bench_diff = bench_sub.add_parser("diff", help="Diff two benchmark versions.")
    bench_diff.add_argument("--benchmark-id", required=True)
    bench_diff.add_argument("--version-a", type=int)
    bench_diff.add_argument("--version-b", type=int)
    bench_install = bench_sub.add_parser("install", help="Install a registered benchmark as an eval suite.")
    bench_install.add_argument("--benchmark-id", required=True)
    bench_install.add_argument("--version", type=int)
    bench_install.add_argument("--eval-id", required=True)
    bench_install.add_argument("--force", action="store_true")

    redteam = subparsers.add_parser("redteam", help="Generate and review red-team eval suites.")
    redteam_sub = redteam.add_subparsers(dest="redteam_command", required=True)
    redteam_generate = redteam_sub.add_parser("generate", help="Generate a red-team suite from an existing eval.")
    redteam_generate.add_argument("--source-eval-id", required=True)
    redteam_generate.add_argument("--output-eval-id", required=True)
    redteam_generate.add_argument("--mode", action="append", dest="modes")
    redteam_report = redteam_sub.add_parser("report", help="Summarize a red-team experiment.")
    redteam_report.add_argument("--experiment", required=True)
    redteam_report.add_argument("--baseline")

    human_review = subparsers.add_parser("human-review", help="Inspect and answer human review queues.")
    human_review_sub = human_review.add_subparsers(dest="hr_command", required=True)
    hr_queues = human_review_sub.add_parser("queues", help="List human review queues.")
    hr_queues.add_argument("--pending-only", action="store_true")
    hr_answers = human_review_sub.add_parser("answers", help="List recorded human review answers.")
    hr_answers.add_argument("--queue-id")
    hr_answer = human_review_sub.add_parser("answer", help="Record and apply a human review answer.")
    hr_answer.add_argument("--queue-id", required=True)
    hr_answer.add_argument("--checkpoint-id", required=True)
    hr_answer.add_argument("--answer", default="")
    hr_answer.add_argument("--decision")
    hr_answer.add_argument("--guidance")
    hr_answer.add_argument("--case-id", action="append", dest="case_ids")
    hr_answer.add_argument("--reviewer", default="human")
    hr_apply = human_review_sub.add_parser("apply", help="Re-apply recorded human review answers to artifacts.")
    hr_apply.add_argument("--queue-id")
    hr_apply.add_argument("--checkpoint-id")
    hr_apply.add_argument("--dry-run", action="store_true")

    show = subparsers.add_parser("show", help="Inspect stored experiment and compare artifacts.")
    show_sub = show.add_subparsers(dest="show_command", required=True)
    show_experiment = show_sub.add_parser("experiment", help="Show an experiment bundle.")
    show_experiment.add_argument("--experiment", required=True)
    show_case = show_sub.add_parser("case", help="Show a single case bundle from an experiment.")
    show_case.add_argument("--experiment", required=True)
    show_case.add_argument("--case-id", required=True)
    show_compare = show_sub.add_parser("compare", help="Show a compare artifact.")
    show_compare.add_argument("--baseline")
    show_compare.add_argument("--candidate")
    show_compare.add_argument("--latest", action="store_true")

    export = subparsers.add_parser("export", help="Export a complete experiment bundle.")
    export.add_argument("--experiment", required=True)
    export.add_argument("--output")

    review = subparsers.add_parser("review", help="Export an HTML review artifact.")
    review.add_argument("--experiment", required=True)
    review.add_argument("--baseline")
    review.add_argument("--queue-id")
    review.add_argument("--output")

    artifacts = subparsers.add_parser("artifacts", help="Artifact inspection and export helpers.")
    artifacts_sub = artifacts.add_subparsers(dest="artifacts_command", required=True)
    artifacts_show = artifacts_sub.add_parser("show", help="Show an experiment bundle.")
    artifacts_show.add_argument("--experiment", required=True)
    artifacts_case = artifacts_sub.add_parser("case", help="Show a case bundle.")
    artifacts_case.add_argument("--experiment", required=True)
    artifacts_case.add_argument("--case-id", required=True)
    artifacts_compare = artifacts_sub.add_parser("compare", help="Show a compare artifact.")
    artifacts_compare.add_argument("--baseline")
    artifacts_compare.add_argument("--candidate")
    artifacts_compare.add_argument("--latest", action="store_true")
    artifacts_export = artifacts_sub.add_parser("export", help="Export a full experiment bundle.")
    artifacts_export.add_argument("--experiment", required=True)
    artifacts_export.add_argument("--output")
    artifacts_review = artifacts_sub.add_parser("review", help="Write an HTML review artifact.")
    artifacts_review.add_argument("--experiment", required=True)
    artifacts_review.add_argument("--baseline")
    artifacts_review.add_argument("--queue-id")
    artifacts_review.add_argument("--output")
    artifacts_migrate = artifacts_sub.add_parser("migrate", help="Migrate artifact schema files.")
    artifacts_migrate.add_argument("--check", action="store_true")

    scorer_audit = subparsers.add_parser("scorer-audit", help="Audit scorer quality for an experiment.")
    scorer_audit.add_argument("--experiment", required=True)

    migrate = subparsers.add_parser("migrate", help="Migrate experiment and compare artifact payloads.")
    migrate.add_argument("--check", action="store_true")

    doctor = subparsers.add_parser("doctor", help="Check local Agent Workbench health.")
    doctor.add_argument("--format", choices=_FORMAT_CHOICES, default="json")

    traces = subparsers.add_parser("traces", help="Validate and explain recorded trace telemetry.")
    traces_sub = traces.add_subparsers(dest="traces_command", required=True)
    traces_validate = traces_sub.add_parser("validate", help="Validate trace telemetry for an experiment.")
    traces_validate.add_argument("--experiment", required=True)
    traces_validate.add_argument("--format", choices=_FORMAT_CHOICES, default="json")
    traces_explain = traces_sub.add_parser("explain", help="Explain trace provenance for an experiment.")
    traces_explain.add_argument("--experiment", required=True)
    traces_explain.add_argument("--case-id")
    traces_explain.add_argument("--format", choices=_FORMAT_CHOICES, default="json")

    iterate = subparsers.add_parser("iterate", help="Turn a diagnosis into iteration lanes.")
    iterate.add_argument("--experiment")
    iterate.add_argument("--agent-id")
    iterate.add_argument("--eval-id")
    iterate.add_argument("--subset")
    iterate.add_argument("--benchmark-signature")
    iterate.add_argument("--baseline")
    iterate.add_argument("--limit", type=int, default=3)

    ablate = subparsers.add_parser("ablate", help="Run prompt/tool/skill/plugin/MCP ablations.")
    ablate.add_argument("--experiment")
    ablate.add_argument("--agent-id")
    ablate.add_argument("--eval-id")
    ablate.add_argument("--subset")
    _add_case_selection_args(ablate)
    ablate.add_argument("--surfaces", action="append")
    ablate.add_argument("--surface-limit", "--limit", dest="surface_limit", type=int)
    ablate.add_argument("--keep-specs", action="store_true")

    return parser


def dispatch(args: argparse.Namespace) -> int:
    init_like = args.command == "init"
    project_root = args.project_root.resolve() if init_like else _existing_project_root(args.project_root)

    if args.command == "init":
        from agentworkbench.scaffold import init_workbench

        init_workbench(project_root)
        _print_text(f"Initialized Agent Workbench in {project_root / '.agent-workbench'}")
        return 0

    if args.command == "learn":
        from agentworkbench.discovery import discover_repo

        summary = discover_repo(project_root)
        _print_text(
            f"Learned repository surface for {summary.get('project_name', project_root.name)}. "
            f"Wrote discovery artifacts to {project_root / '.agent-workbench' / 'discovery'}"
        )
        return 0

    if args.command == "brief":
        from agentworkbench.briefs import build_brief_packet, draft_brief, finalize_brief, start_brief

        if args.brief_command == "start":
            brief_path = start_brief(project_root, args.brief_id, args.goal)
            payload: dict[str, Any] = {"brief_path": brief_path}
            if args.agent_id:
                payload["packet_path"] = build_brief_packet(project_root, args.brief_id, agent_id=args.agent_id)
            _print_json(payload)
            return 0
        if args.brief_command == "draft":
            brief_path = draft_brief(project_root, args.brief_id, args.agent_id, args.goal)
            _print_json(
                {
                    "brief_path": brief_path,
                    "packet_path": build_brief_packet(project_root, args.brief_id, agent_id=args.agent_id),
                }
            )
            return 0
        if args.brief_command == "finalize":
            _print_json({"brief_path": finalize_brief(project_root, args.brief_id)})
            return 0
        if args.brief_command == "packet":
            _print_json({"packet_path": build_brief_packet(project_root, args.brief_id, agent_id=args.agent_id)})
            return 0
        raise ValueError(f"Unknown brief command `{args.brief_command}`.")

    if args.command == "evals":
        from agentworkbench.benchmarks import export_eval_suite_bundle, import_eval_suite_bundle
        from agentworkbench.evals import approve_eval_suite, expand_eval_suite, generate_eval_suite, review_eval_suite

        if args.evals_command == "generate":
            _print_json(generate_eval_suite(project_root, args.brief_id, args.eval_id))
            return 0
        if args.evals_command == "review":
            _print_json({"review_report": review_eval_suite(project_root, args.eval_id)})
            return 0
        if args.evals_command == "approve":
            _print_json({"review_report": approve_eval_suite(project_root, args.eval_id, args.min_quality)})
            return 0
        if args.evals_command == "expand":
            _print_json(
                expand_eval_suite(
                    project_root,
                    args.eval_id,
                    brief_id=args.brief_id,
                    experiment_id=args.experiment,
                    agent_id=args.agent_id,
                    subset=args.subset,
                    benchmark_signature=args.benchmark_signature,
                    case_ids=args.case_ids,
                    tags=args.tags,
                    match=args.match,
                    cluster_ids=args.cluster_ids,
                    focus_limit=args.focus_limit,
                    brief_limit=args.brief_limit,
                    sources=args.sources,
                )
            )
            return 0
        if args.evals_command == "export":
            _print_json(
                export_eval_suite_bundle(
                    project_root,
                    args.eval_id,
                    output_path=_path_arg(args.output),
                    benchmark_id=args.benchmark_id,
                )
            )
            return 0
        if args.evals_command == "import":
            _print_json(
                import_eval_suite_bundle(
                    project_root,
                    Path(args.input),
                    eval_id=args.eval_id,
                    overwrite=args.force,
                )
            )
            return 0
        raise ValueError(f"Unknown evals command `{args.evals_command}`.")

    if args.command == "run":
        if args.run_command == "replay":
            return _dispatch_replay(project_root, args)
        if args.run_command == "chain":
            from agentworkbench.chain import run_chain_experiment

            record, aggregate = run_chain_experiment(
                project_root,
                args.chain_agent_ids,
                args.eval_id,
                args.subset,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                limit=args.limit,
                chain_handoff_template=args.chain_handoff_template,
                step_configs=_parse_json_objects(args.step_configs, flag="--step-config"),
            )
            _print_json({"experiment": record, "aggregate": aggregate})
            return 0
        if args.run_command == "workflow":
            from agentworkbench.workflow import run_workflow_experiment

            record, aggregate = run_workflow_experiment(
                project_root,
                args.workflow_file,
                args.eval_id,
                args.subset,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                limit=args.limit,
                workflow_handoff_template=args.workflow_handoff_template,
            )
            _print_json({"experiment": record, "aggregate": aggregate})
            return 0

        from agentworkbench.runner import run_experiment, run_experiment_series

        agent_id = _require(args.agent_id, "`run` requires `--agent-id`.")
        eval_id = _require(args.eval_id, "`run` requires `--eval-id`.")
        learned_scorer_path = _path_arg(args.learned_scorer)
        if args.repeat > 1:
            _print_json(
                run_experiment_series(
                    project_root,
                    agent_id,
                    eval_id,
                    args.subset,
                    repeat=args.repeat,
                    case_ids=args.case_ids,
                    tags=args.tags,
                    match=args.match,
                    limit=args.limit,
                    label=args.series_label,
                    jobs=args.jobs,
                    learned_scorer_path=learned_scorer_path,
                )
            )
            return 0
        record, aggregate = run_experiment(
            project_root,
            agent_id,
            eval_id,
            args.subset,
            case_ids=args.case_ids,
            tags=args.tags,
            match=args.match,
            limit=args.limit,
            jobs=args.jobs,
            resume_experiment=args.resume_experiment,
            learned_scorer_path=learned_scorer_path,
            active_learning=args.active_learning,
        )
        _print_json({"experiment": record, "aggregate": aggregate})
        return 0

    if args.command == "run-workflow":
        from agentworkbench.workflow import run_workflow_experiment

        record, aggregate = run_workflow_experiment(
            project_root,
            args.workflow_file,
            args.eval_id,
            args.subset,
            case_ids=args.case_ids,
            tags=args.tags,
            match=args.match,
            limit=args.limit,
            workflow_handoff_template=args.workflow_handoff_template,
        )
        _print_json({"experiment": record, "aggregate": aggregate})
        return 0

    if args.command == "optimize":
        from agentworkbench.optimize import run_bayesian_optimization, run_bounded_optimization

        if args.bayesian:
            agent_id = args.agent_id
            eval_id = args.eval_id
            subset = args.subset or "smoke"
            if args.experiment and (not agent_id or not eval_id):
                from agentworkbench.runner import _load_experiment

                source_record, _aggregate = _load_experiment(project_root, args.experiment)
                agent_id = source_record.agent_id
                eval_id = source_record.eval_id
                subset = source_record.subset
            _print_json(
                run_bayesian_optimization(
                    project_root,
                    agent_id=_require(agent_id, "Bayesian optimization requires `--agent-id` or `--experiment`."),
                    eval_id=_require(eval_id, "Bayesian optimization requires `--eval-id` or `--experiment`."),
                    subset=subset,
                    temperatures=args.temperatures,
                    max_tokens=args.max_tokens,
                    budget=args.budget,
                )
            )
            return 0
        _print_json(
            run_bounded_optimization(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                baseline_id=args.baseline,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                case_limit=args.case_limit,
                surfaces=args.surfaces,
                budget=args.budget,
                proposal_limit=args.proposal_limit,
                matrix_agent_ids=args.matrix_agent_ids,
                temperatures=args.temperatures,
                max_tokens=args.max_tokens,
            )
        )
        return 0

    if args.command == "compare":
        from agentworkbench.runner_compare import compare_against_best, compare_experiments

        if args.best:
            _print_json(compare_against_best(project_root, args.candidate))
            return 0
        baseline_id = _require(args.baseline, "`compare` requires `--baseline` unless `--best` is used.")
        _print_json(compare_experiments(project_root, baseline_id, args.candidate))
        return 0

    if args.command == "check":
        from agentworkbench.loop_checks import build_loop_check_report, render_loop_check_report

        payload = build_loop_check_report(
            project_root,
            agent_id=args.agent_id,
            eval_id=args.eval_id,
            subset=args.subset,
            experiment_id=args.experiment,
            workflow_file=args.workflow_file,
            chain_agent_ids=args.chain_agent_ids,
            fail_on=args.fail_on,
        )
        if args.format == "json":
            _print_json(payload)
        else:
            _print_text(render_loop_check_report(payload))
        return 0 if bool(payload.get("passed", True)) else 1

    if args.command == "status":
        from agentworkbench.runner_compare import status_summary

        _print_json(
            status_summary(
                project_root,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                promoted_only=args.promoted_only,
                limit=args.limit,
            )
        )
        return 0

    if args.command == "diagnose":
        from agentworkbench.runner_diagnosis import diagnose_experiment

        _print_json(
            diagnose_experiment(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                baseline_id=args.baseline,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                cluster_ids=args.cluster_ids,
                focus_limit=args.focus_limit,
            )
        )
        return 0

    if args.command == "next":
        from agentworkbench.next_steps import build_next_steps_summary

        _print_json(
            build_next_steps_summary(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                baseline_id=args.baseline,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                cluster_ids=args.cluster_ids,
                focus_limit=args.focus_limit,
                limit=args.limit,
            )
        )
        return 0

    if args.command == "propose":
        from agentworkbench.proposals import generate_mutation_proposals

        _print_json(
            generate_mutation_proposals(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                baseline_id=args.baseline,
                limit=args.limit,
            )
        )
        return 0

    if args.command == "patch-template":
        from agentworkbench.patches import build_patch_template

        _print_json(
            build_patch_template(
                project_root,
                proposal_id=args.proposal_id,
                experiment_id=args.experiment,
            )
        )
        return 0

    if args.command == "matrix":
        from agentworkbench.matrix import run_experiment_matrix

        _print_json(
            run_experiment_matrix(
                project_root,
                agent_ids=args.agent_ids,
                eval_id=args.eval_id,
                subset=args.subset,
                temperatures=args.temperatures,
                max_tokens=args.max_tokens,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                limit=args.limit,
                keep_specs=args.keep_specs,
            )
        )
        return 0

    if args.command == "factorial":
        from agentworkbench.factorial import run_factorial_experiments

        _print_json(
            run_factorial_experiments(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                case_limit=args.case_limit,
                groups=args.groups,
                factors=args.factors,
                factor_limit=args.factor_limit,
                keep_specs=args.keep_specs,
            )
        )
        return 0

    if args.command == "promote":
        from agentworkbench.runner_compare import promote_experiment

        _print_json(promote_experiment(project_root, args.experiment, args.baseline))
        return 0

    if args.command == "release":
        from agentworkbench.release import release_readiness_summary

        _print_json(
            release_readiness_summary(
                project_root,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                promoted_only=args.promoted_only,
                limit=args.limit,
            )
        )
        return 0

    if args.command == "adapters":
        from agentworkbench.adapters import available_adapters

        payload = {"adapters": available_adapters()}
        if args.format == "json":
            _print_json(payload)
        else:
            for adapter in payload["adapters"]:
                print(f"{adapter['name']}: {adapter['source']}")
        return 0

    if args.command == "benchmarks":
        from agentworkbench.benchmark_ingestion import (
            dedupe_ingested_benchmark,
            ingest_benchmark_source,
            list_ingested_benchmarks,
            list_ingestion_jobs,
            normalize_ingested_benchmark,
            publish_ingested_benchmark,
            review_ingested_benchmark,
            show_ingested_benchmark,
            show_ingestion_job,
            validate_ingested_benchmark,
        )
        from agentworkbench.benchmarks import (
            check_registered_benchmark,
            diff_registered_benchmark_versions,
            install_registered_benchmark,
            list_registered_benchmarks,
            register_benchmark,
            show_registered_benchmark,
        )

        if args.benchmarks_command == "register":
            _print_json(
                register_benchmark(
                    project_root,
                    args.eval_id,
                    benchmark_id=args.benchmark_id,
                    overwrite=args.force,
                )
            )
            return 0
        if args.benchmarks_command == "ingest":
            _print_json(
                ingest_benchmark_source(
                    project_root,
                    source_path=Path(args.source),
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    source_name=args.source_name,
                    dataset_revision=args.dataset_revision,
                    license_name=args.license_name,
                    scorer_path=_path_arg(args.scorer),
                    scorer_version=args.scorer_version,
                    shard_size=args.shard_size,
                    workers=args.workers,
                )
            )
            return 0
        if args.benchmarks_command == "normalize":
            _print_json(
                normalize_ingested_benchmark(
                    project_root,
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    id_field=args.id_field,
                    input_field=args.input_field,
                    expected_field=args.expected_field,
                    rubric_field=args.rubric_field,
                    tags_field=args.tags_field,
                    metadata_field=args.metadata_field,
                    answer_types=args.answer_types,
                    answer_source=args.answer_source,
                    shard_size=args.shard_size,
                    workers=args.workers,
                )
            )
            return 0
        if args.benchmarks_command == "dedupe":
            _print_json(
                dedupe_ingested_benchmark(
                    project_root,
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    strategy=args.strategy,
                    shard_size=args.shard_size,
                    workers=args.workers,
                )
            )
            return 0
        if args.benchmarks_command == "validate":
            _print_json(
                validate_ingested_benchmark(
                    project_root,
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    workers=args.workers,
                )
            )
            return 0
        if args.benchmarks_command == "review":
            _print_json(
                review_ingested_benchmark(
                    project_root,
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    approve=args.approve,
                    reviewer=args.reviewer,
                    guidance=args.guidance,
                )
            )
            return 0
        if args.benchmarks_command == "publish":
            _print_json(
                publish_ingested_benchmark(
                    project_root,
                    benchmark_id=args.benchmark_id,
                    version=args.version,
                    eval_id=args.eval_id,
                    force=args.force,
                )
            )
            return 0
        if args.benchmarks_command == "ingested":
            if args.version is not None:
                _print_json(show_ingested_benchmark(project_root, benchmark_id=args.benchmark_id, version=args.version))
            else:
                _print_json(list_ingested_benchmarks(project_root, benchmark_id=args.benchmark_id))
            return 0
        if args.benchmarks_command == "jobs":
            if args.job_id:
                _print_json(show_ingestion_job(project_root, job_id=args.job_id))
            else:
                _print_json(list_ingestion_jobs(project_root, limit=args.limit))
            return 0
        if args.benchmarks_command == "list":
            payload = list_registered_benchmarks(
                project_root,
                include_history=args.all_versions,
                tags=args.tags,
                match=args.match,
                capability=args.capability,
                agent_type=args.agent_type,
                approval_status=args.approval_status,
            )
            if args.format == "json":
                _print_json(payload)
            else:
                for entry in payload.get("benchmarks", []):
                    print(f"{entry['benchmark_id']} v{entry['version']}: {entry.get('description', '')}")
            return 0
        if args.benchmarks_command == "show":
            _print_json(show_registered_benchmark(project_root, args.benchmark_id, version=args.version))
            return 0
        if args.benchmarks_command == "check":
            _print_json(check_registered_benchmark(project_root, args.benchmark_id, version=args.version))
            return 0
        if args.benchmarks_command == "diff":
            _print_json(
                diff_registered_benchmark_versions(
                    project_root,
                    args.benchmark_id,
                    version_a=args.version_a,
                    version_b=args.version_b,
                )
            )
            return 0
        if args.benchmarks_command == "install":
            _print_json(
                install_registered_benchmark(
                    project_root,
                    args.benchmark_id,
                    version=args.version,
                    eval_id=args.eval_id,
                    overwrite=args.force,
                )
            )
            return 0
        raise ValueError(f"Unknown benchmarks command `{args.benchmarks_command}`.")

    if args.command == "redteam":
        from agentworkbench.redteam import generate_redteam_suite, redteam_report

        if args.redteam_command == "generate":
            _print_json(
                generate_redteam_suite(
                    project_root,
                    args.source_eval_id,
                    args.output_eval_id,
                    modes=args.modes,
                )
            )
            return 0
        if args.redteam_command == "report":
            _print_json(redteam_report(project_root, args.experiment, baseline_id=args.baseline))
            return 0
        raise ValueError(f"Unknown redteam command `{args.redteam_command}`.")

    if args.command == "human-review":
        from agentworkbench.human_review_store import (
            apply_review_answers,
            list_review_queues,
            load_review_answers,
            record_review_answer,
        )

        if args.hr_command == "queues":
            _print_json(list_review_queues(project_root, pending_only=args.pending_only))
            return 0
        if args.hr_command == "answers":
            answers = load_review_answers(project_root)
            if args.queue_id:
                answers = [item for item in answers if str(item.get("queue_id") or "") == str(args.queue_id)]
            _print_json({"answer_count": len(answers), "answers": answers})
            return 0
        if args.hr_command == "answer":
            _print_json(
                record_review_answer(
                    project_root,
                    queue_id=args.queue_id,
                    checkpoint_id=args.checkpoint_id,
                    answer=args.answer,
                    decision=args.decision,
                    guidance=args.guidance,
                    related_case_ids=args.case_ids,
                    reviewer=args.reviewer,
                    apply_to_artifacts=True,
                )
            )
            return 0
        if args.hr_command == "apply":
            _print_json(
                apply_review_answers(
                    project_root,
                    queue_id=args.queue_id,
                    checkpoint_id=args.checkpoint_id,
                    dry_run=args.dry_run,
                )
            )
            return 0
        raise ValueError(f"Unknown human-review command `{args.hr_command}`.")

    if args.command == "show":
        return _dispatch_show(project_root, args)

    if args.command == "export":
        from agentworkbench.artifacts import export_experiment_bundle

        _print_json(export_experiment_bundle(project_root, args.experiment, output_path=_path_arg(args.output)))
        return 0

    if args.command == "review":
        from agentworkbench.artifacts import export_review_html

        _print_json(
            export_review_html(
                project_root,
                args.experiment,
                output_path=_path_arg(args.output),
                baseline_id=args.baseline,
                queue_id=args.queue_id,
            )
        )
        return 0

    if args.command == "artifacts":
        return _dispatch_artifacts(project_root, args)

    if args.command == "scorer-audit":
        from agentworkbench.scorer_audit import build_scorer_audit

        _print_json(build_scorer_audit(project_root, experiment_id=args.experiment))
        return 0

    if args.command == "migrate":
        from agentworkbench.artifacts import migrate_artifacts

        _print_json(migrate_artifacts(project_root, check_only=args.check))
        return 0

    if args.command == "doctor":
        payload = _doctor_payload(project_root)
        if args.format == "json":
            _print_json(payload)
        else:
            _print_text(_doctor_text(payload))
        return 0 if payload.get("healthy") else 1

    if args.command == "traces":
        if args.traces_command == "validate":
            payload = _trace_validate_payload(project_root, args.experiment)
        elif args.traces_command == "explain":
            payload = _trace_explain_payload(project_root, args.experiment, case_id=args.case_id)
        else:
            raise ValueError(f"Unknown traces command `{args.traces_command}`.")
        if args.format == "json":
            _print_json(payload)
        else:
            _print_text(_trace_text(payload))
        return 0

    if args.command == "iterate":
        from agentworkbench.iterate import build_iteration_plan

        _print_json(
            build_iteration_plan(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                benchmark_signature=args.benchmark_signature,
                baseline_id=args.baseline,
                limit=args.limit,
            )
        )
        return 0

    if args.command == "ablate":
        from agentworkbench.ablations import run_surface_ablations

        _print_json(
            run_surface_ablations(
                project_root,
                experiment_id=args.experiment,
                agent_id=args.agent_id,
                eval_id=args.eval_id,
                subset=args.subset,
                case_ids=args.case_ids,
                tags=args.tags,
                match=args.match,
                case_limit=args.case_limit,
                surfaces=args.surfaces,
                surface_limit=args.surface_limit,
                keep_specs=args.keep_specs,
            )
        )
        return 0

    raise ValueError(f"Unknown command `{args.command}`.")


def main(argv: list[str] | None = None) -> int:
    try:
        parser = build_parser()
        try:
            args = parser.parse_args(argv)
        except SystemExit as exc:
            return 0 if exc.code in (None, 0) else 1
        return int(dispatch(args) or 0)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
