from __future__ import annotations

from pathlib import Path
from typing import Any

from agentworkbench.config import control_dir
from agentworkbench.utils import read_yaml

_BUILTIN_PRICING = [
    {
        "provider": "groq",
        "names": ["groq/llama-3.1-8b-instant", "llama-3.1-8b-instant", "llama 3.1 8b"],
        "input_per_million_tokens": 0.05,
        "output_per_million_tokens": 0.08,
        "currency": "USD",
        "source_url": "https://console.groq.com/docs/models",
        "source_label": "Groq models page",
    },
    {
        "provider": "cerebras",
        "names": ["cerebras/llama3.1-8b", "llama3.1-8b", "llama 3.1 8b", "meta/llama3.1-8b"],
        "input_per_million_tokens": 0.10,
        "output_per_million_tokens": 0.10,
        "currency": "USD",
        "source_url": "https://www.cerebras.ai/pricing",
        "source_label": "Cerebras pricing page",
    },
]


def _normalize_pricing_entry(payload: dict[str, Any], fallback_provider: str = "") -> dict[str, Any] | None:
    input_rate = payload.get("input_per_million_tokens", payload.get("input_per_million"))
    output_rate = payload.get("output_per_million_tokens", payload.get("output_per_million"))
    if input_rate is None or output_rate is None:
        return None
    names = payload.get("names") or []
    single_name = payload.get("name")
    if single_name:
        names = [*names, single_name]
    return {
        "provider": str(payload.get("provider") or fallback_provider or "").lower(),
        "names": sorted(dict.fromkeys(str(item).strip().lower() for item in names if str(item).strip())),
        "input_per_million_tokens": float(input_rate),
        "output_per_million_tokens": float(output_rate),
        "currency": str(payload.get("currency") or "USD"),
        "source_url": str(payload.get("source_url") or ""),
        "source_label": str(payload.get("source_label") or "pricing override"),
    }


def _load_pricing_overrides(project_root: Path) -> list[dict[str, Any]]:
    path = control_dir(project_root) / "pricing.yaml"
    if not path.exists():
        return []
    payload = read_yaml(path) or {}
    entries = payload.get("models") if isinstance(payload, dict) else []
    normalized: list[dict[str, Any]] = []
    for item in entries or []:
        if not isinstance(item, dict):
            continue
        entry = _normalize_pricing_entry(item)
        if entry is not None:
            normalized.append(entry)
    return normalized


def _match_pricing_entry(entries: list[dict[str, Any]], provider: str, candidates: list[str]) -> dict[str, Any] | None:
    normalized_candidates = [str(item).strip().lower() for item in candidates if str(item).strip()]
    normalized_provider = str(provider or "").strip().lower()
    for entry in entries:
        entry_provider = str(entry.get("provider") or "").lower()
        if normalized_provider and entry_provider and normalized_provider != entry_provider:
            continue
        names = set(str(item).lower() for item in entry.get("names", []))
        if names.intersection(normalized_candidates):
            return entry
    return None


def _usage_value(token_usage: dict[str, Any], *keys: str) -> int:
    for key in keys:
        if key in token_usage and token_usage[key] is not None:
            return int(token_usage[key])
    return 0


def resolve_pricing(
    project_root: Path,
    model: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    metadata = metadata or {}
    pricing_payload = metadata.get("pricing") or model.get("pricing")
    if isinstance(pricing_payload, dict):
        entry = _normalize_pricing_entry(pricing_payload, fallback_provider=str(model.get("provider") or metadata.get("provider") or ""))
        if entry is not None:
            return entry
    provider = str(metadata.get("provider") or model.get("provider") or "").strip().lower()
    model_candidates = [
        str(metadata.get("model_name") or ""),
        str(metadata.get("model") or ""),
        str(model.get("name") or ""),
        str(model.get("model_id") or ""),
    ]
    entries = [*_load_pricing_overrides(project_root), *_BUILTIN_PRICING]
    return _match_pricing_entry(entries, provider, model_candidates)


def estimate_token_cost(
    project_root: Path,
    model: dict[str, Any],
    token_usage: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    pricing = resolve_pricing(project_root, model, metadata)
    if pricing is None:
        return None
    input_tokens = _usage_value(token_usage, "input", "prompt", "prompt_tokens")
    output_tokens = _usage_value(token_usage, "output", "completion", "completion_tokens")
    if input_tokens <= 0 and output_tokens <= 0:
        total_tokens = _usage_value(token_usage, "total", "total_tokens")
        if total_tokens <= 0:
            return None
        input_tokens = total_tokens
    cost_usd = (
        (input_tokens * float(pricing["input_per_million_tokens"])) / 1_000_000.0
        + (output_tokens * float(pricing["output_per_million_tokens"])) / 1_000_000.0
    )
    return {
        **pricing,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cost_usd": round(cost_usd, 6),
    }
