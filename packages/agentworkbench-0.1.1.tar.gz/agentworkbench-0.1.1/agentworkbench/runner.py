from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Any

from agentworkbench.active_learning import ActiveLearningSelector
from agentworkbench.behavior_summary import BEHAVIOR_SUMMARY_VERSION, aggregate_behavior_summary
from agentworkbench.case_selection import build_case_selection
from agentworkbench.config import control_dir, experiment_dir, experiments_root, load_config, load_model
from agentworkbench.constants import PARTIAL_RUNS_FILENAME, RUN_CONTEXT_FILENAME
from agentworkbench.evals import load_eval_cases, load_scoring_context
from agentworkbench.execution_scheduler import create_execution_backend
from agentworkbench.experiment_analysis import failure_clusters
from agentworkbench.models import AgentSpec, ComparisonRecord, EvalCase, ExperimentRecord
from agentworkbench.reports import (
    render_experiment_report,
    render_extension_reports,
    write_report,
)
from agentworkbench.run_context import build_benchmark_signature, build_run_context, persist_run_artifacts
from agentworkbench.run_failures import failed_cases_for_experiment
from agentworkbench.run_finalize import finalize_run
from agentworkbench.run_helpers import _spec_snapshot
from agentworkbench.runner_compare import (
    compare_against_best,
    compare_experiments,
    promote_experiment,
    status_summary,
)
from agentworkbench.runner_diagnosis import diagnose_experiment
from agentworkbench.snapshot import capture_snapshot, compute_benchmark_hashes
from agentworkbench.stability import build_stability_summary
from agentworkbench.stability_utils import _stability_summary_for_record, stability_dir
from agentworkbench.surface_details import capture_surface_snapshot
from agentworkbench.surface_recommendations import (
    build_surface_recommendations,
    matching_surface_recommendations,
    retrieval_surface_focus,
    surface_recommendation_text,
)
from agentworkbench.telemetry import enrich_run_row_payload
from agentworkbench.utils import (
    created_at_utc,
    ensure_dir,
    read_json,
    read_jsonl,
    utc_timestamp_slug,
    write_json,
    write_jsonl,
)

_EXPERIMENT_ID_TIMESTAMP_PATTERN = re.compile(r"-(\d{20})$")


def load_agent_spec(project_root: Path, agent_id: str) -> AgentSpec:
    return load_model(control_dir(project_root) / "agents" / f"{agent_id}.yaml", AgentSpec)


def _record_sort_key(record: ExperimentRecord) -> tuple[float, float, str, str]:
    return (
        float(record.scores.get("average_score", 0.0)),
        float(record.scores.get("passed_cases", 0)),
        record.created_at,
        record.experiment_id,
    )


def _record_benchmark_signature(record: ExperimentRecord) -> str:
    if record.benchmark_signature:
        return record.benchmark_signature
    return build_benchmark_signature(
        record.benchmark_hashes or {},
        selection_fingerprint=record.selection_fingerprint or None,
    )


def _record_created_key(record: ExperimentRecord) -> tuple[str, str]:
    return (record.created_at or "", record.experiment_id)


def _experiment_timestamp(experiment_id: str) -> dt.datetime | None:
    match = _EXPERIMENT_ID_TIMESTAMP_PATTERN.search(experiment_id)
    if not match:
        return None
    try:
        timestamp = dt.datetime.strptime(match.group(1), "%Y%m%d%H%M%S%f")
    except ValueError:
        return None
    return timestamp.replace(tzinfo=dt.UTC)


def _infer_subset(record: ExperimentRecord) -> str:
    if record.subset:
        return record.subset
    timestamp_match = _EXPERIMENT_ID_TIMESTAMP_PATTERN.search(record.experiment_id)
    prefix = f"{record.agent_id}-{record.eval_id}-"
    if not timestamp_match or not record.experiment_id.startswith(prefix):
        return record.subset
    subset = record.experiment_id[len(prefix) : -len(timestamp_match.group(0))]
    return subset or record.subset


def _normalize_record(record: ExperimentRecord) -> ExperimentRecord:
    normalized = record.model_copy(deep=True)
    normalized.subset = _infer_subset(record)
    if not normalized.created_at:
        timestamp = _experiment_timestamp(normalized.experiment_id)
        if timestamp is not None:
            normalized.created_at = timestamp.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    if not normalized.benchmark_signature and normalized.benchmark_hashes:
        normalized.benchmark_signature = build_benchmark_signature(normalized.benchmark_hashes)
    return normalized


def _behavior_summary_needs_refresh(record: ExperimentRecord) -> bool:
    return str((record.behavior_summary or {}).get("behavior_summary_version") or "") != BEHAVIOR_SUMMARY_VERSION


def _refresh_record_behavior_summary(project_root: Path, record: ExperimentRecord) -> ExperimentRecord:
    runs_path = experiment_dir(project_root, record.experiment_id) / "runs.jsonl"
    if not runs_path.exists():
        return record
    refreshed = record.model_copy(deep=True)
    refreshed.behavior_summary = aggregate_behavior_summary(
        _load_run_rows(project_root, refreshed.experiment_id), refreshed.spec_snapshot or {}
    )
    write_json(
        experiment_dir(project_root, refreshed.experiment_id) / "experiment.json", refreshed.model_dump(mode="json")
    )
    return refreshed


def _record_summary(record: ExperimentRecord) -> dict[str, Any]:
    record = _normalize_record(record)
    spec = record.spec_snapshot or {}
    return {
        "experiment_id": record.experiment_id,
        "series_id": record.series_id,
        "created_at": record.created_at,
        "agent_id": record.agent_id,
        "eval_id": record.eval_id,
        "subset": record.subset,
        "benchmark_signature": _record_benchmark_signature(record),
        "model_name": spec.get("model_name", "unknown"),
        "average_score": record.scores.get("average_score", 0.0),
        "passed_cases": record.scores.get("passed_cases", 0),
        "total_cases": record.scores.get("total_cases", 0),
        "average_trace_event_count": record.behavior_summary.get("average_trace_event_count", 0.0),
        "average_evidence_record_count": record.behavior_summary.get("average_evidence_record_count", 0.0),
        "selected_evidence_use_rate": record.behavior_summary.get("selected_evidence_use_rate"),
        "average_step_count": record.behavior_summary.get("average_step_count", 0.0),
        "average_latency_ms": record.behavior_summary.get("average_latency_ms", 0.0),
        "average_cost_estimate": record.behavior_summary.get("average_cost_estimate", 0.0),
        "promotion_status": record.promotion_status,
        "selection_fingerprint": record.selection_fingerprint,
        "selected_case_count": len(record.selected_case_ids or []),
        "tools_used": record.behavior_summary.get("tools_used", []),
        "skills_used": record.behavior_summary.get("skills_used", []),
        "plugins_used": record.behavior_summary.get("plugins_used", []),
        "mcp_servers_used": record.behavior_summary.get("mcp_servers_used", []),
        "prompt_keys_used": record.behavior_summary.get("prompt_keys_used", []),
    }


def _latest_matching_json_artifact(root: Path, predicate: Any) -> dict[str, Any] | None:
    if not root.exists():
        return None
    candidates: list[tuple[str, int, dict[str, Any]]] = []
    for path in root.glob("*.json"):
        if path.name == "latest.json":
            continue
        try:
            payload = read_json(path)
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        if not predicate(payload):
            continue
        candidates.append((str(payload.get("created_at") or ""), int(path.stat().st_mtime_ns), dict(payload)))
    if candidates:
        candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return candidates[0][2]
    latest_path = root / "latest.json"
    if latest_path.exists():
        payload = read_json(latest_path)
        if isinstance(payload, dict) and predicate(payload):
            return dict(payload)
    return None


def _record_surface_recommendations(project_root: Path, record: ExperimentRecord | None) -> list[dict[str, Any]]:
    if record is None:
        return []
    latest_factorial = _latest_matching_json_artifact(
        control_dir(project_root) / "factorials",
        lambda payload: (
            str(payload.get("agent_id") or "") == str(record.agent_id)
            and str(payload.get("eval_id") or "") == str(record.eval_id)
            and str(payload.get("subset") or "") == str(record.subset)
            and str(payload.get("benchmark_signature") or "") == _record_benchmark_signature(record)
        ),
    )
    factor_effects: list[dict[str, Any]] = []
    pair_interactions: list[dict[str, Any]] = []
    recommendations: list[dict[str, Any]] = []
    if latest_factorial:
        factor_effects = list(latest_factorial.get("factor_effects") or [])
        pair_interactions = list(latest_factorial.get("pair_interactions") or [])
        recommendations = list(latest_factorial.get("surface_recommendations") or [])
    if not recommendations:
        recommendations = build_surface_recommendations(
            record.behavior_summary or {},
            factor_effects=factor_effects,
            pair_interactions=pair_interactions,
        )
    return recommendations


def _latest_matching_compare(
    project_root: Path,
    allowed_experiment_ids: set[str],
    record_lookup: dict[str, ExperimentRecord],
    preferred_benchmark_signature: str | None = None,
) -> dict[str, Any] | None:
    reports_root = control_dir(project_root) / "reports"
    if not reports_root.exists():
        return None
    candidates: list[tuple[str, int, dict[str, Any]]] = []
    for path in reports_root.glob("compare-*-to-*.json"):
        try:
            payload = read_json(path)
        except (OSError, json.JSONDecodeError):
            continue
        candidate_id = str(payload.get("candidate_id") or "")
        baseline_id = str(payload.get("baseline_id") or "")
        if (
            allowed_experiment_ids
            and candidate_id not in allowed_experiment_ids
            and baseline_id not in allowed_experiment_ids
        ):
            continue
        candidate_record = record_lookup.get(candidate_id)
        baseline_record = record_lookup.get(baseline_id)
        record_for_signature = candidate_record or baseline_record
        if preferred_benchmark_signature and record_for_signature is not None:
            if _record_benchmark_signature(record_for_signature) != preferred_benchmark_signature:
                continue
        candidate_timestamp = _experiment_timestamp(candidate_id)
        candidates.append(
            (
                candidate_timestamp.replace(microsecond=0).isoformat().replace("+00:00", "Z")
                if candidate_timestamp
                else "",
                int(path.stat().st_mtime_ns),
                payload,
            )
        )
    if not candidates:
        return None
    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return candidates[0][2]


def _comparable_records(
    project_root: Path,
    candidate_record: ExperimentRecord,
    *,
    include_self: bool,
) -> list[ExperimentRecord]:
    return [
        record
        for record in list_experiment_records(
            project_root, eval_id=candidate_record.eval_id, subset=candidate_record.subset
        )
        if (include_self or record.experiment_id != candidate_record.experiment_id)
        and _record_benchmark_signature(record) == _record_benchmark_signature(candidate_record)
    ]


def _best_summary(records: list[ExperimentRecord]) -> dict[str, Any] | None:
    if not records:
        return None
    return _record_summary(sorted(records, key=_record_sort_key, reverse=True)[0])


def _baseline_ladder(
    project_root: Path,
    candidate_record: ExperimentRecord,
    *,
    include_self: bool = False,
) -> dict[str, Any]:
    records = _comparable_records(project_root, candidate_record, include_self=include_self)
    model_name = str((candidate_record.spec_snapshot or {}).get("model_name") or "unknown")
    return {
        "promoted_baseline": _best_summary([record for record in records if record.promotion_status == "promoted"]),
        "same_model_best": _best_summary(
            [
                record
                for record in records
                if str((record.spec_snapshot or {}).get("model_name") or "unknown") == model_name
            ]
        ),
        "same_agent_best": _best_summary(
            [record for record in records if record.agent_id == candidate_record.agent_id]
        ),
        "overall_best": _best_summary(records),
    }


def _write_experiment_record(project_root: Path, record: ExperimentRecord) -> ExperimentRecord:
    write_json(experiment_dir(project_root, record.experiment_id) / "experiment.json", record.model_dump(mode="json"))
    return record


def _partial_runs_path(project_root: Path, experiment_id: str) -> Path:
    return experiment_dir(project_root, experiment_id) / PARTIAL_RUNS_FILENAME


def _run_context_path(project_root: Path, experiment_id: str) -> Path:
    return experiment_dir(project_root, experiment_id) / RUN_CONTEXT_FILENAME


def _ordered_rows_for_cases(cases: list[EvalCase], rows_by_case_id: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    return [rows_by_case_id[case.id] for case in cases if case.id in rows_by_case_id]


def _persist_partial_rows(
    project_root: Path,
    experiment_id: str,
    cases: list[EvalCase],
    rows_by_case_id: dict[str, dict[str, Any]],
) -> None:
    write_jsonl(_partial_runs_path(project_root, experiment_id), _ordered_rows_for_cases(cases, rows_by_case_id))


def _validate_resume_context(
    experiment_id: str,
    expected_context: dict[str, Any],
    existing_context: dict[str, Any],
) -> None:
    mismatches: list[str] = []
    for key in ["agent_id", "eval_id", "subset"]:
        if str(existing_context.get(key) or "") != str(expected_context.get(key) or ""):
            mismatches.append(key)
    expected_selection = expected_context.get("selection") or {}
    existing_selection = existing_context.get("selection") or {}
    if str(existing_selection.get("selection_fingerprint") or "") != str(
        expected_selection.get("selection_fingerprint") or ""
    ):
        mismatches.append("selection_fingerprint")
    if dict(existing_context.get("spec_snapshot") or {}) != dict(expected_context.get("spec_snapshot") or {}):
        mismatches.append("spec_snapshot")
    if mismatches:
        raise ValueError(
            f"Resume experiment `{experiment_id}` does not match the requested run context: {', '.join(sorted(mismatches))}"
        )


def _stability_path(project_root: Path, series_id: str) -> Path:
    return stability_dir(project_root) / f"{series_id}.json"


def _write_stability_summary(project_root: Path, payload: dict[str, Any]) -> dict[str, Any]:
    root = stability_dir(project_root)
    write_json(root / f"{payload['series_id']}.json", payload)
    write_json(root / "latest.json", payload)
    return payload


def _failed_case_map(project_root: Path, experiment_id: str) -> dict[str, str]:
    return {item["case_id"]: item["reason"] for item in failed_cases_for_experiment(project_root, experiment_id)}


def _refresh_experiment_report(project_root: Path, experiment_id: str, update_latest: bool = False) -> None:
    exp_dir = experiment_dir(project_root, experiment_id)
    aggregate_path = exp_dir / "aggregate.json"
    if not aggregate_path.exists():
        return
    record, aggregate = _load_experiment(project_root, experiment_id)
    failed_cases = failed_cases_for_experiment(project_root, experiment_id)
    write_report(exp_dir / "report.md", render_experiment_report(record, aggregate, failed_cases))

    # 2. Extension reports
    bundle = record.model_dump(mode="json")
    bundle["aggregate"] = aggregate
    bundle["failed_cases"] = failed_cases
    ext_reports = render_extension_reports(bundle)
    for name, content in ext_reports.items():
        write_report(exp_dir / f"report-{name}.md", content)

    if update_latest:
        latest = ensure_dir(control_dir(project_root) / "reports")
        write_report(latest / "latest-experiment.md", render_experiment_report(record, aggregate, failed_cases))
        for name, content in ext_reports.items():
            write_report(latest / f"latest-report-{name}.md", content)


def list_experiment_records(
    project_root: Path,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    promoted_only: bool = False,
) -> list[ExperimentRecord]:
    records: list[ExperimentRecord] = []
    for path in sorted(experiments_root(project_root).glob("*/experiment.json")):
        record = _normalize_record(ExperimentRecord.model_validate(read_json(path)))
        if _behavior_summary_needs_refresh(record):
            record = _refresh_record_behavior_summary(project_root, record)
        if agent_id and record.agent_id != agent_id:
            continue
        if eval_id and record.eval_id != eval_id:
            continue
        if subset and record.subset != subset:
            continue
        if benchmark_signature and _record_benchmark_signature(record) != benchmark_signature:
            continue
        if promoted_only and record.promotion_status != "promoted":
            continue
        records.append(record)
    return sorted(records, key=_record_created_key)


def _best_comparable_baseline(project_root: Path, candidate_record: ExperimentRecord) -> ExperimentRecord | None:
    records = [
        record
        for record in list_experiment_records(
            project_root, eval_id=candidate_record.eval_id, subset=candidate_record.subset
        )
        if record.experiment_id != candidate_record.experiment_id
        and _record_benchmark_signature(record) == _record_benchmark_signature(candidate_record)
    ]
    if not records:
        return None
    promoted = [record for record in records if record.promotion_status == "promoted"]
    comparable = promoted or records
    return sorted(comparable, key=_record_sort_key, reverse=True)[0]


def _latest_matching_record(
    project_root: Path,
    agent_id: str | None = None,
    eval_id: str | None = None,
    subset: str | None = None,
    benchmark_signature: str | None = None,
    promoted_only: bool = False,
) -> ExperimentRecord | None:
    """Find the most recent experiment record matching the given filters."""
    records = list_experiment_records(
        project_root,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        benchmark_signature=benchmark_signature,
        promoted_only=promoted_only,
    )
    if not records:
        return None
    return sorted(records, key=_record_created_key, reverse=True)[0]


def run_experiment(
    project_root: Path,
    agent_id: str,
    eval_id: str,
    subset: str,
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
    series_id: str | None = None,
    jobs: int = 1,
    resume_experiment: str | None = None,
    max_concurrent: int = 1,
    seed: int | None = None,
    max_retries: int = 0,
    retry_on_errors: list[str] | None = None,
    backoff_multiplier: float = 1.0,
    max_backoff_seconds: float = 30.0,
    learned_scorer_path: Path | None = None,
    active_learning: bool = False,
) -> tuple[ExperimentRecord, dict[str, Any]]:
    """Run an agent specification against an eval suite and return results."""
    if jobs < 1:
        raise ValueError("Job count must be at least 1.")
    config = load_config(project_root)
    spec = load_agent_spec(project_root, agent_id)
    experiment_id = resume_experiment or f"{agent_id}-{eval_id}-{subset}-{utc_timestamp_slug()}"
    exp_dir = experiment_dir(project_root, experiment_id)
    cases = load_eval_cases(
        project_root,
        eval_id,
        subset,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    prior_records = [
        record
        for record in list_experiment_records(project_root, agent_id=agent_id, eval_id=eval_id, subset=subset)
        if record.experiment_id != experiment_id
    ]

    if active_learning:
        selector = ActiveLearningSelector()
        case_dicts = [{"id": c.id, "input": c.input, "metadata": c.metadata} for c in cases]
        prior_run_history: list[dict[str, Any]] = []
        for prior_record in prior_records:
            for row in _load_run_rows(project_root, prior_record.experiment_id):
                case = dict(row.get("case") or {})
                case_id = str(case.get("id") or "")
                if not case_id:
                    continue
                prior_run_history.append(
                    {
                        "case": {"id": case_id},
                        "passed": bool(row.get("passed")),
                    }
                )
        prioritized_ids = selector.prioritize(case_dicts, prior_run_history, max_select=len(cases))
        case_by_id = {case.id: case for case in cases}
        cases = [case_by_id[case_id] for case_id in prioritized_ids if case_id in case_by_id]

    spec_snapshot = _spec_snapshot(spec, project_root)
    surface_snapshot = capture_surface_snapshot(project_root, spec)
    selection = build_case_selection(
        cases,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    rows_by_case_id: dict[str, dict[str, Any]] = {}
    context_path = _run_context_path(project_root, experiment_id)
    if resume_experiment:
        if not context_path.exists():
            raise FileNotFoundError(f"Missing run context for resume experiment: {context_path}")
        existing_context = read_json(context_path)
        expected_context = build_run_context(
            agent_id=agent_id,
            eval_id=eval_id,
            subset=subset,
            selection=selection,
            spec_snapshot=spec_snapshot,
            surface_snapshot=surface_snapshot,
            repo_before={},
            benchmark_hashes_before={},
        )
        _validate_resume_context(experiment_id, expected_context, existing_context)
        before_snapshot = dict(existing_context.get("repo_before") or {})
        before_benchmarks = {
            str(key): str(value) for key, value in (existing_context.get("benchmark_hashes_before") or {}).items()
        }
        spec_snapshot = dict(existing_context.get("spec_snapshot") or spec_snapshot)
        surface_snapshot = dict(existing_context.get("surface_snapshot") or surface_snapshot)
        for row in read_jsonl(_partial_runs_path(project_root, experiment_id)):
            case_id = str((row.get("case") or {}).get("id") or "")
            if case_id:
                rows_by_case_id[case_id] = row
    else:
        before_snapshot = capture_snapshot(project_root, config.snapshot_mode)
        before_benchmarks = compute_benchmark_hashes(project_root)
        write_json(
            context_path,
            build_run_context(
                agent_id=agent_id,
                eval_id=eval_id,
                subset=subset,
                selection=selection,
                spec_snapshot=spec_snapshot,
                surface_snapshot=surface_snapshot,
                repo_before=before_snapshot,
                benchmark_hashes_before=before_benchmarks,
            ),
        )
        persist_run_artifacts(
            exp_dir,
            spec_snapshot=spec_snapshot,
            selection=selection,
            surface_snapshot=surface_snapshot,
        )
    remaining_cases = [case for case in cases if case.id not in rows_by_case_id]
    if remaining_cases:
        effective_concurrent = max(int(jobs), int(max_concurrent))
        provider_limits = dict(config.provider_concurrency_limits or {})
        scoring_ctx = load_scoring_context(project_root, eval_id, learned_scorer_path=learned_scorer_path)
        early_stop = config.early_stop_consecutive_failures
        backend = create_execution_backend(
            max_concurrent=effective_concurrent,
            max_retries=max_retries,
            retry_on_errors=retry_on_errors,
            backoff_multiplier=backoff_multiplier,
            max_backoff_seconds=max_backoff_seconds,
            provider_concurrency_limits=provider_limits or None,
        )
        rows_merged = dict(rows_by_case_id)
        rows_merged.update(
            backend.execute(
                project_root,
                spec,
                spec_snapshot,
                eval_id,
                remaining_cases,
                experiment_id,
                seed=seed,
                scoring_context=scoring_ctx,
                early_stop_consecutive_failures=early_stop if effective_concurrent == 1 else None,
            )
        )
        rows_by_case_id = rows_merged
        _persist_partial_rows(project_root, experiment_id, cases, rows_by_case_id)
    rows = _ordered_rows_for_cases(cases, rows_by_case_id)
    finalized = finalize_run(
        project_root,
        rows=rows,
        spec_snapshot=spec_snapshot,
        before_snapshot=before_snapshot,
        before_benchmarks=before_benchmarks,
        snapshot_mode=config.snapshot_mode,
        selection_fingerprint=selection["selection_fingerprint"],
    )
    aggregate = finalized.aggregate
    behavior_summary = finalized.behavior_summary
    record = ExperimentRecord(
        experiment_id=experiment_id,
        parent_experiment_id=prior_records[-1].experiment_id if prior_records else None,
        series_id=series_id,
        agent_id=agent_id,
        eval_id=eval_id,
        subset=subset,
        created_at=created_at_utc(),
        benchmark_signature=finalized.benchmark_signature,
        spec_snapshot=spec_snapshot,
        repo_before=before_snapshot,
        repo_after=finalized.after_snapshot,
        changed_files=finalized.changed_files,
        benchmark_hashes=finalized.after_benchmarks,
        benchmark_manifest=finalized.after_manifest,
        case_selection=selection,
        selection_fingerprint=selection["selection_fingerprint"],
        selected_case_ids=selection["selected_case_ids"],
        completed_case_ids=[case.id for case in cases if case.id in rows_by_case_id],
        total_case_count=len(cases),
        surface_snapshot=surface_snapshot,
        scores=aggregate,
        behavior_summary=behavior_summary,
        status="completed",
        promotion_status="candidate",
    )
    _write_experiment_record(project_root, record)
    write_json(exp_dir / "aggregate.json", aggregate)
    write_json(exp_dir / "behavior.json", behavior_summary)
    persist_run_artifacts(
        exp_dir,
        spec_snapshot=spec_snapshot,
        selection=selection,
        surface_snapshot=surface_snapshot,
    )
    write_jsonl(exp_dir / "runs.jsonl", rows)
    partial_path = _partial_runs_path(project_root, experiment_id)
    if partial_path.exists():
        partial_path.unlink()
    write_report(exp_dir / "repo.diff", finalized.diff_text)
    _refresh_experiment_report(project_root, experiment_id, update_latest=True)
    return record, aggregate


def run_experiment_series(
    project_root: Path,
    agent_id: str,
    eval_id: str,
    subset: str,
    *,
    repeat: int,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
    label: str | None = None,
    jobs: int = 1,
    learned_scorer_path: Path | None = None,
) -> dict[str, Any]:
    if repeat < 2:
        raise ValueError("Repeat count must be at least 2 to build a stability series.")
    series_id = f"{agent_id}-{eval_id}-{subset}-series-{utc_timestamp_slug()}"
    records: list[ExperimentRecord] = []
    for _index in range(repeat):
        record, _aggregate = run_experiment(
            project_root,
            agent_id,
            eval_id,
            subset,
            case_ids=case_ids,
            tags=tags,
            match=match,
            limit=limit,
            series_id=series_id,
            jobs=jobs,
            learned_scorer_path=learned_scorer_path,
        )
        records.append(record)
    payload = build_stability_summary(
        series_id=series_id,
        records=records,
        label=label,
        selection={
            "case_ids": case_ids or [],
            "tags": tags or [],
            "match": match or "",
            "case_limit": limit,
        },
    )
    return _write_stability_summary(project_root, payload)


def _load_experiment(project_root: Path, experiment_id: str) -> tuple[ExperimentRecord, dict[str, Any]]:
    exp_dir = experiment_dir(project_root, experiment_id)
    record = _normalize_record(ExperimentRecord.model_validate(read_json(exp_dir / "experiment.json")))
    if _behavior_summary_needs_refresh(record):
        record = _refresh_record_behavior_summary(project_root, record)
    aggregate = read_json(exp_dir / "aggregate.json")
    return record, aggregate


def _load_run_rows(project_root: Path, experiment_id: str) -> list[dict[str, Any]]:
    spec_snapshot: dict[str, Any] = {}
    experiment_path = experiment_dir(project_root, experiment_id) / "experiment.json"
    if experiment_path.exists():
        try:
            spec_snapshot = dict((read_json(experiment_path) or {}).get("spec_snapshot") or {})
        except (OSError, json.JSONDecodeError):
            spec_snapshot = {}
    final_path = experiment_dir(project_root, experiment_id) / "runs.jsonl"
    if final_path.exists():
        return [enrich_run_row_payload(row, spec_snapshot=spec_snapshot) for row in read_jsonl(final_path)]
    partial_path = _partial_runs_path(project_root, experiment_id)
    if partial_path.exists():
        return [enrich_run_row_payload(row, spec_snapshot=spec_snapshot) for row in read_jsonl(partial_path)]
    return []


def _stability_comparison_summary(
    project_root: Path,
    baseline: ExperimentRecord,
    candidate: ExperimentRecord,
) -> dict[str, Any]:
    return {
        "baseline": _stability_summary_for_record(project_root, baseline) or {},
        "candidate": _stability_summary_for_record(project_root, candidate) or {},
    }


def _failure_clusters(
    comparison: ComparisonRecord | None,
    focus_cases: list[dict[str, Any]],
    failed_case_map: dict[str, str],
) -> list[dict[str, Any]]:
    return failure_clusters(comparison, focus_cases, failed_case_map)


_PARETO_MAXIMIZE_KEYS = {"average_score", "passed_cases"}
_PARETO_MINIMIZE_KEYS = {"average_latency_ms", "average_step_count", "average_cost_estimate"}
_PARETO_KEYS = sorted(_PARETO_MAXIMIZE_KEYS | _PARETO_MINIMIZE_KEYS)


def _pareto_vector(record: ExperimentRecord) -> dict[str, float]:
    summary = _record_summary(record)
    return {
        "average_score": float(summary.get("average_score", 0.0)),
        "passed_cases": float(summary.get("passed_cases", 0.0)),
        "average_latency_ms": float(summary.get("average_latency_ms", 0.0)),
        "average_step_count": float(summary.get("average_step_count", 0.0)),
        "average_cost_estimate": float(summary.get("average_cost_estimate", 0.0)),
    }


def _dominates(left: ExperimentRecord, right: ExperimentRecord) -> bool:
    left_vector = _pareto_vector(left)
    right_vector = _pareto_vector(right)
    better = False
    for key in _PARETO_KEYS:
        left_value = left_vector[key]
        right_value = right_vector[key]
        if key in _PARETO_MAXIMIZE_KEYS:
            if left_value < right_value:
                return False
            if left_value > right_value:
                better = True
        else:
            if left_value > right_value:
                return False
            if left_value < right_value:
                better = True
    return better


def _pareto_frontier(records: list[ExperimentRecord]) -> list[ExperimentRecord]:
    frontier: list[ExperimentRecord] = []
    for record in records:
        if any(other.experiment_id != record.experiment_id and _dominates(other, record) for other in records):
            continue
        frontier.append(record)
    return sorted(frontier, key=_record_sort_key, reverse=True)


def _pareto_tradeoffs(left: ExperimentRecord, right: ExperimentRecord) -> dict[str, list[str]]:
    left_vector = _pareto_vector(left)
    right_vector = _pareto_vector(right)
    better: list[str] = []
    worse: list[str] = []
    equal: list[str] = []
    for key in _PARETO_KEYS:
        left_value = left_vector[key]
        right_value = right_vector[key]
        if abs(left_value - right_value) < 1e-9:
            equal.append(key)
        elif (key in _PARETO_MAXIMIZE_KEYS and left_value > right_value) or (
            key in _PARETO_MINIMIZE_KEYS and left_value < right_value
        ):
            better.append(key)
        else:
            worse.append(key)
    return {"better": better, "worse": worse, "equal": equal}


def _pareto_summary(project_root: Path, baseline: ExperimentRecord, candidate: ExperimentRecord) -> dict[str, Any]:
    comparable = _comparable_records(project_root, candidate, include_self=True)
    frontier = _pareto_frontier(comparable)
    return {
        "objective_directions": {
            "average_score": "maximize",
            "passed_cases": "maximize",
            "average_latency_ms": "minimize",
            "average_step_count": "minimize",
            "average_cost_estimate": "minimize",
        },
        "comparable_count": len(comparable),
        "frontier_experiment_ids": [record.experiment_id for record in frontier],
        "candidate_on_frontier": any(record.experiment_id == candidate.experiment_id for record in frontier),
        "baseline_on_frontier": any(record.experiment_id == baseline.experiment_id for record in frontier),
        "candidate_dominates_baseline": _dominates(candidate, baseline),
        "baseline_dominates_candidate": _dominates(baseline, candidate),
        "candidate_tradeoffs": _pareto_tradeoffs(candidate, baseline),
        "frontier": [_record_summary(record) for record in frontier[:5]],
    }


__all__ = [
    "run_experiment",
    "run_experiment_series",
    "compare_experiments",
    "compare_against_best",
    "promote_experiment",
    "status_summary",
    "diagnose_experiment",
    "list_experiment_records",
    "experiments_root",
    "experiment_dir",
    "load_agent_spec",
]


def _surface_gaps(record: ExperimentRecord) -> dict[str, Any]:
    behavior = record.behavior_summary or {}
    return {
        "unused_available_tools": behavior.get("unused_available_tools", []),
        "unused_available_skills": behavior.get("unused_available_skills", []),
        "unused_available_plugins": behavior.get("unused_available_plugins", []),
        "unused_available_mcps": behavior.get("unused_available_mcps", []),
        "unused_available_prompt_keys": behavior.get("unused_available_prompt_keys", []),
        "tool_coverage": behavior.get("tool_coverage"),
        "skill_coverage": behavior.get("skill_coverage"),
        "plugin_coverage": behavior.get("plugin_coverage"),
        "mcp_coverage": behavior.get("mcp_coverage"),
        "prompt_coverage": behavior.get("prompt_coverage"),
        "surface_audits": behavior.get("surface_audits", {}) or {},
        "tool_used_not_enabled": behavior.get("tool_used_not_enabled", []) or [],
        "mcp_used_not_enabled": behavior.get("mcp_used_not_enabled", []) or [],
        "mcp_referenced_not_listed": behavior.get("mcp_referenced_not_listed", []) or [],
        "mcp_listed_not_referenced": behavior.get("mcp_listed_not_referenced", []) or [],
        "surface_contract_violations": behavior.get("surface_contract_violations", []) or [],
        "surface_contract_violation_count": behavior.get("surface_contract_violation_count", 0),
        "evidence_sources_with_unused_selected": behavior.get("evidence_sources_with_unused_selected", []) or [],
        "selected_evidence_use_rate": behavior.get("selected_evidence_use_rate"),
        "cases_with_unsupported_selected_evidence": behavior.get("cases_with_unsupported_selected_evidence", 0),
        "tools_with_unused_selected_evidence": behavior.get("tools_with_unused_selected_evidence", []) or [],
        "mcps_with_unused_selected_evidence": behavior.get("mcps_with_unused_selected_evidence", []) or [],
        "tools_with_low_evidence_use": behavior.get("tools_with_low_evidence_use", []) or [],
        "mcps_with_low_evidence_use": behavior.get("mcps_with_low_evidence_use", []) or [],
    }


def _recommended_stability_slice(
    record: ExperimentRecord,
    target_rows: dict[str, Any],
    focus_cases: list[dict[str, Any]],
    *,
    min_repeat: int,
) -> dict[str, Any]:
    preferred_case_ids = [
        str(item.get("case_id") or "") for item in focus_cases if str(item.get("case_id") or "").strip()
    ]
    preferred_case_ids = list(dict.fromkeys(preferred_case_ids))[:4]
    case_payloads = [
        (target_rows.get(case_id) or {}).get("case") or {"id": case_id, "tags": []} for case_id in preferred_case_ids
    ]
    common_tags: set[str] = set(str(tag) for tag in (case_payloads[0].get("tags") or [])) if case_payloads else set()
    for case in case_payloads[1:]:
        common_tags &= {str(tag) for tag in (case.get("tags") or [])}

    selection = {
        "subset": record.subset,
        "repeat": min_repeat,
        "case_ids": [],
        "tags": [],
    }
    command = ""
    reason = ""
    if common_tags:
        chosen_tag = sorted(tag for tag in common_tags if tag)[0]
        selection["tags"] = [chosen_tag]
        command = (
            f"awb run --agent-id {record.agent_id} --eval-id {record.eval_id} --subset {record.subset} "
            f"--tag {chosen_tag} --repeat {min_repeat} --series-label {chosen_tag}-stability"
        )
        reason = "Use the shared focus-case tag for cheaper repeat runs before wider live promotion checks."
    elif preferred_case_ids:
        selection["case_ids"] = preferred_case_ids
        case_flags = " ".join(f"--case-id {case_id}" for case_id in preferred_case_ids)
        command = (
            f"awb run --agent-id {record.agent_id} --eval-id {record.eval_id} --subset {record.subset} "
            f"{case_flags} --repeat {min_repeat} --series-label focused-stability"
        )
        reason = "Repeat the current focus cases first so stability checks stay affordable."
    return {
        "selection": selection,
        "reason": reason,
        "command": command,
    }


def _append_suggestion(suggestions: list[dict[str, str]], category: str, rationale: str, action: str) -> None:
    if any(item.get("category") == category for item in suggestions):
        return
    suggestions.append({"category": category, "rationale": rationale, "action": action})


def _diagnosis_suggestions(
    record: ExperimentRecord,
    failed_case_map: dict[str, str],
    comparison: ComparisonRecord | None,
    surface_recommendations: list[dict[str, Any]] | None = None,
) -> list[dict[str, str]]:
    suggestions: list[dict[str, str]] = []
    surface_recommendations = surface_recommendations or []
    score_deltas = comparison.metric_deltas if comparison else {}
    behavior_deltas = comparison.behavior_deltas if comparison else {}
    average_score_delta = float(score_deltas.get("average_score", 0.0)) if comparison else 0.0
    output_delta = float(score_deltas.get("metric.output_quality", 0.0)) if comparison else 0.0
    process_delta = float(score_deltas.get("metric.process_alignment", 0.0)) if comparison else 0.0
    average_token_usage_deltas = behavior_deltas.get("average_token_usage_deltas", {}) or {}
    average_total_token_delta = float(
        average_token_usage_deltas.get(
            "total",
            sum(float(value) for key, value in average_token_usage_deltas.items() if key != "total"),
        )
    )
    cluster_categories = [
        str(item.get("category") or "") for item in (comparison.failure_clusters if comparison else [])
    ]
    cluster_to_mutation = {
        "benchmark_drift": "benchmark_hygiene",
        "grounding_gap": "prompt_grounding",
        "memory_gap": "tool_routing",
        "mcp_empty": "retrieval_quality",
        "mcp_failure": "tool_routing",
        "prompt_regression": "prompt_grounding",
        "provider_auth_failure": "stability_validation",
        "provider_failure": "stability_validation",
        "provider_rate_limit": "stability_validation",
        "provider_timeout": "stability_validation",
        "response_structure_gap": "prompt_grounding",
        "retrieval_gap": "retrieval_quality",
        "routing_regression": "tool_routing",
        "step_overhead": "step_budget",
        "surface_contract_violation": "surface_contract",
        "trace_regression": "tool_routing",
        "tool_failure": "tool_routing",
        "output_regression": "prompt_grounding",
    }
    for cluster in cluster_categories[:3]:
        category = cluster_to_mutation.get(cluster)
        if category == "benchmark_hygiene":
            _append_suggestion(
                suggestions,
                "benchmark_hygiene",
                "Failure clusters point to benchmark drift rather than a clean agent-only regression.",
                "Freeze the benchmark inputs before interpreting the next score delta.",
            )
        elif category == "tool_routing":
            _append_suggestion(
                suggestions,
                "tool_routing",
                "Failure clusters point to routing, memory, or workflow-telemetry regressions.",
                "Restore the expected tool, skill, plugin, MCP, or prompt path before changing broader prompts.",
            )
        elif category == "surface_contract":
            _append_suggestion(
                suggestions,
                "surface_contract",
                "Failure clusters show the runtime is violating the declared tool or MCP contract.",
                "Make the agent obey enabled tools and MCPs strictly, and keep emitted usage lists consistent with the actual route taken.",
            )
        elif category == "prompt_grounding":
            _append_suggestion(
                suggestions,
                "prompt_grounding",
                "Failure clusters point to missing answer structure or prompt-grounding drift.",
                "Tighten the instructions or reviewer prompt around the failing cases.",
            )
        elif category == "retrieval_quality":
            _append_suggestion(
                suggestions,
                "retrieval_quality",
                "Failure clusters point to missing or weak evidence selection.",
                "Tighten retrieval, ranking, or context assembly before adding new surfaces.",
            )
        elif category == "step_budget":
            _append_suggestion(
                suggestions,
                "step_budget",
                "Failure clusters show extra workflow overhead without a corresponding gain.",
                "Reduce unnecessary planner or reviewer hops before widening the mutation.",
            )
        elif category == "stability_validation":
            _append_suggestion(
                suggestions,
                "stability_validation",
                "Failure clusters point to live provider instability rather than a clean behavioral regression.",
                "Rerun the affected slice with backoff or lower concurrency before judging the mutation.",
            )
    failed_reasons = " ".join(failed_case_map.values())
    output_failure_markers = [
        "expected text missing",
        "empty output",
        "missing required terms",
        "forbidden terms present",
    ]
    process_failure_markers = [
        "missing required_tools",
        "missing required_skills",
        "missing required_plugins",
        "missing required_mcps",
        "missing required_prompt_keys",
        "forbidden forbidden_tools",
        "forbidden forbidden_skills",
        "forbidden forbidden_plugins",
        "forbidden forbidden_mcps",
        "forbidden forbidden_prompt_keys",
        "max_step_count",
        "exceeds max_step_count",
        "no preferred surfaces were observed in telemetry",
    ]
    matched_retrieval_markers = ["preferred_tools", "preferred_skills", "preferred_plugins", "preferred_mcps"]
    has_output_failures = any(marker in failed_reasons for marker in output_failure_markers)
    output_issue = output_delta < 0.0 or has_output_failures
    process_issue = process_delta < 0.0 or any(marker in failed_reasons for marker in process_failure_markers)
    retrieval_issue = (
        output_issue and any(marker in failed_reasons for marker in matched_retrieval_markers) and not process_issue
    )
    if comparison and comparison.comparison_mode != "clean":
        _append_suggestion(
            suggestions,
            "benchmark_hygiene",
            "The benchmark changed between baseline and candidate, so quality deltas are harder to trust.",
            "Stabilize briefs, evals, and scorers before accepting or rejecting the mutation.",
        )
    if comparison and any(
        not bool((comparison.gate_results.get(key) or {}).get("passed", True))
        for key in [
            "candidate_stability_runs",
            "baseline_stability_runs",
            "candidate_score_stddev",
            "candidate_latency_cv",
            "candidate_cost_cv",
        ]
        if key in comparison.gate_results
    ):
        _append_suggestion(
            suggestions,
            "stability_validation",
            "Promotion confidence is limited because the available live repeats are missing or too noisy.",
            "Repeat the live run before promotion and check score, latency, and cost variance separately.",
        )
    gaps = _surface_gaps(record)
    retrieval_recommendations = matching_surface_recommendations(
        surface_recommendations,
        surfaces=retrieval_surface_focus(gaps),
        recommendations={"keep_enabled_fix_grounding", "improve_grounding", "exercise_surface_in_routing"},
    )
    pruning_recommendations = matching_surface_recommendations(
        surface_recommendations,
        recommendations={
            "prune_or_disable",
            "replace_or_disable",
            "unused_available",
            "overhead_candidate",
            "fix_or_prune_empty",
        },
    )
    routing_recommendations = matching_surface_recommendations(
        surface_recommendations,
        recommendations={"exercise_surface_in_routing", "keep_with_interaction"},
    )
    if retrieval_issue:
        _append_suggestion(
            suggestions,
            "retrieval_quality",
            "The agent exercised the expected retrieval surfaces but still missed required evidence on failing cases.",
            (
                "Keep the helpful retrieval surfaces enabled and fix their evidence packaging first: "
                f"{surface_recommendation_text(retrieval_recommendations)}."
                if retrieval_recommendations
                else "Tighten query construction, snippet ranking, memory recall, or context packaging before broad prompt rewrites."
            ),
        )
    if any(cluster == "grounding_gap" for cluster in cluster_categories):
        _append_suggestion(
            suggestions,
            "prompt_grounding",
            "The run selected local evidence but the final answer did not preserve that evidence.",
            (
                "Make the answer or reviewer prompt preserve the decisive phrase from the affected retrieval surfaces: "
                f"{surface_recommendation_text(retrieval_recommendations)}."
                if retrieval_recommendations
                else "Make the answer or reviewer prompt carry the decisive retrieved phrase through instead of paraphrasing it away."
            ),
        )
    if any(cluster == "response_structure_gap" for cluster in cluster_categories):
        _append_suggestion(
            suggestions,
            "prompt_grounding",
            "The run exercised the right surfaces but still missed required response structure such as an explicit next action.",
            "Make the answer contract force a distinct `Next action:` sentence instead of folding the follow-up into the decision line.",
        )
    if output_issue:
        _append_suggestion(
            suggestions,
            "prompt_grounding",
            (
                "Output quality regressed or failing cases are missing expected content."
                if output_delta < 0.0
                else "The current failing cases are still missing expected content."
            ),
            "Tighten answer prompts, grounding instructions, or reviewer prompts around the failing cases.",
        )
    if process_issue:
        _append_suggestion(
            suggestions,
            "tool_routing",
            "Process alignment slipped or the agent is missing required surfaces on workflow cases.",
            (
                "Adjust routing so the recommended workflow surfaces are actually exercised: "
                f"{surface_recommendation_text(routing_recommendations)}."
                if routing_recommendations
                else "Adjust tool, skill, plugin, MCP, or prompt routing so required workflow steps are actually exercised."
            ),
        )
    if (
        int(record.behavior_summary.get("surface_contract_violation_count", 0) or 0) > 0
        or int(behavior_deltas.get("surface_contract_violation_count_delta", 0) or 0) > 0
    ):
        _append_suggestion(
            suggestions,
            "surface_contract",
            "The run shows tool or MCP contract drift between the declared spec and the emitted telemetry.",
            "Align runtime behavior, trace events, tool calls, and `mcp_servers_used` with the enabled surfaces before optimizing prompts on top of that drift.",
        )
    if float(behavior_deltas.get("avg_step_count_delta", 0.0)) > 0.0 and average_score_delta <= 0.0:
        _append_suggestion(
            suggestions,
            "step_budget",
            "The agent is taking more steps without a compensating score gain.",
            "Reduce planner/reviewer overhead or tighten max-step guidance before adding more surface area.",
        )
    if (
        float(behavior_deltas.get("avg_cost_estimate_delta", 0.0)) > 0.0 or average_total_token_delta > 0.0
    ) and average_score_delta <= 0.0:
        _append_suggestion(
            suggestions,
            "cost_budget",
            "The candidate uses more token or cost budget per case without a compensating score gain.",
            "Reduce unnecessary model, tool, or prompt overhead before widening the surface area.",
        )
    low_value_retrieval_surfaces = [
        *gaps.get("tools_with_unused_selected_evidence", []),
        *gaps.get("mcps_with_unused_selected_evidence", []),
    ]
    if low_value_retrieval_surfaces:
        _append_suggestion(
            suggestions,
            "retrieval_quality",
            "Some tools or MCPs are returning selected evidence that still is not making it into final answers consistently.",
            (
                "Keep and fix grounding on the affected retrieval surfaces before adding more: "
                f"{surface_recommendation_text(retrieval_recommendations)}."
                if retrieval_recommendations
                else "Tighten ranking, context assembly, and answer-grounding for the affected retrieval surfaces before adding more."
            ),
        )
    unused_surface = [
        *gaps.get("unused_available_tools", []),
        *gaps.get("unused_available_skills", []),
        *gaps.get("unused_available_plugins", []),
        *gaps.get("unused_available_mcps", []),
        *gaps.get("unused_available_prompt_keys", []),
    ]
    if unused_surface and average_score_delta <= 0.0:
        _append_suggestion(
            suggestions,
            "surface_pruning",
            "The agent has available surfaces that are not being used and current changes are not clearly helping.",
            (
                "Prune or justify the low-value enabled surfaces first: "
                f"{surface_recommendation_text(pruning_recommendations)}."
                if pruning_recommendations
                else "Remove, disable, or justify unused prompts, tools, skills, plugins, or MCPs before adding more."
            ),
        )
    if comparison and comparison.recommended_action == "promote":
        _append_suggestion(
            suggestions,
            "promote_candidate",
            "The candidate passed the current clean-benchmark gates.",
            "Promote this run, then expand the eval suite around the cases and workflows that improved.",
        )
    if not suggestions:
        _append_suggestion(
            suggestions,
            "inspect_failures",
            "No single dominant failure mode was detected from the current metrics.",
            "Review the top failing cases and mutate one surface at a time so the next compare is easier to interpret.",
        )
    return suggestions
