"""Agent Workbench - local-first Python package and CLI for evaluating and optimizing repo-native target agents."""

from __future__ import annotations

__all__ = [
    "__version__",
    "__title__",
    # --- Models ---
    "AgentSpec",
    "EvalCase",
    "ExperimentRecord",
    "ComparisonRecord",
    # --- Runner ---
    "run_experiment",
    "run_experiment_series",
    "compare_experiments",
    "compare_against_best",
    "promote_experiment",
    "status_summary",
    "diagnose_experiment",
    "release_readiness_summary",
    "run_bounded_optimization",
    "generate_redteam_suite",
    "redteam_report",
    "apply_review_answers",
    # --- Benchmarks ---
    "export_eval_suite_bundle",
    "import_eval_suite_bundle",
    "register_benchmark",
    "list_registered_benchmarks",
    "install_registered_benchmark",
    # --- Artifacts ---
    "export_experiment_bundle",
    "load_experiment_bundle",
    "load_case_bundle",
    # --- Scoring ---
    "JudgedScore",
    "heuristic_score",
    "model_judged_score",
    # --- Instrumentation ---
    "ProvenanceLevel",
    "ProvenanceTracker",
    "summarize_provenance",
    # --- Extensions ---
    "list_extensions",
    "get_extension",
    "register_plugin",
    # --- Provider Types ---
    "ProviderConfig",
    "ProviderCapabilities",
]

__title__ = "agentworkbench"
__version__ = "0.1.1"


from agentworkbench.artifacts import (
    export_experiment_bundle,
    load_case_bundle,
    load_experiment_bundle,
)
from agentworkbench.benchmarks import (
    export_eval_suite_bundle,
    import_eval_suite_bundle,
    install_registered_benchmark,
    list_registered_benchmarks,
    register_benchmark,
)
from agentworkbench.extensions.loader import (
    get_extension,
    list_extensions,
    register_plugin,
)
from agentworkbench.human_review_store import apply_review_answers
from agentworkbench.instrumentation import (
    ProvenanceLevel,
    ProvenanceTracker,
    summarize_provenance,
)
from agentworkbench.models import AgentSpec, ComparisonRecord, EvalCase, ExperimentRecord
from agentworkbench.optimize import run_bounded_optimization
from agentworkbench.providers.base import (
    ProviderCapabilities,
    ProviderConfig,
)
from agentworkbench.redteam import generate_redteam_suite, redteam_report
from agentworkbench.release import release_readiness_summary
from agentworkbench.runner import (
    compare_against_best,
    compare_experiments,
    diagnose_experiment,
    promote_experiment,
    run_experiment,
    run_experiment_series,
    status_summary,
)
from agentworkbench.scorers.judge import (
    JudgedScore,
    heuristic_score,
    model_judged_score,
)
