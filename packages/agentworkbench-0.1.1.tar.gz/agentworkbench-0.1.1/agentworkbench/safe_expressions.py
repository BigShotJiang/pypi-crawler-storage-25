from __future__ import annotations

import ast
from typing import Any


class UnsafeExpressionError(ValueError):
    """Raised when a condition expression uses an unsupported construct."""


def evaluate_condition(expression: str, variables: dict[str, Any] | None = None) -> bool:
    """Evaluate a small boolean expression against the provided variables."""
    try:
        parsed = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise UnsafeExpressionError(f"Invalid condition expression: {expression}") from exc
    return bool(_evaluate_node(parsed.body, variables or {}))


def _evaluate_node(node: ast.AST, variables: dict[str, Any]) -> Any:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id not in variables:
            raise UnsafeExpressionError(f"Unknown variable in condition: {node.id}")
        return variables[node.id]
    if isinstance(node, ast.Tuple):
        return tuple(_evaluate_node(element, variables) for element in node.elts)
    if isinstance(node, ast.List):
        return [_evaluate_node(element, variables) for element in node.elts]
    if isinstance(node, ast.Set):
        return {_evaluate_node(element, variables) for element in node.elts}
    if isinstance(node, ast.BoolOp):
        values = [_evaluate_node(value, variables) for value in node.values]
        if isinstance(node.op, ast.And):
            return all(values)
        if isinstance(node.op, ast.Or):
            return any(values)
        raise UnsafeExpressionError(f"Unsupported boolean operator: {type(node.op).__name__}")
    if isinstance(node, ast.UnaryOp):
        operand = _evaluate_node(node.operand, variables)
        if isinstance(node.op, ast.Not):
            return not operand
        raise UnsafeExpressionError(f"Unsupported unary operator: {type(node.op).__name__}")
    if isinstance(node, ast.Compare):
        return _evaluate_comparison(node, variables)
    raise UnsafeExpressionError(f"Unsupported expression node: {type(node).__name__}")


def _evaluate_comparison(node: ast.Compare, variables: dict[str, Any]) -> bool:
    left = _evaluate_node(node.left, variables)
    for operator_node, comparator in zip(node.ops, node.comparators, strict=True):
        right = _evaluate_node(comparator, variables)
        if isinstance(operator_node, ast.Eq):
            passed = left == right
        elif isinstance(operator_node, ast.NotEq):
            passed = left != right
        elif isinstance(operator_node, ast.Lt):
            passed = left < right
        elif isinstance(operator_node, ast.LtE):
            passed = left <= right
        elif isinstance(operator_node, ast.Gt):
            passed = left > right
        elif isinstance(operator_node, ast.GtE):
            passed = left >= right
        elif isinstance(operator_node, ast.In):
            passed = left in right
        elif isinstance(operator_node, ast.NotIn):
            passed = left not in right
        elif isinstance(operator_node, ast.Is):
            passed = left is right
        elif isinstance(operator_node, ast.IsNot):
            passed = left is not right
        else:
            raise UnsafeExpressionError(f"Unsupported comparison operator: {type(operator_node).__name__}")
        if not passed:
            return False
        left = right
    return True


__all__ = ["UnsafeExpressionError", "evaluate_condition"]
