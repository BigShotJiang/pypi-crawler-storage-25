from __future__ import annotations

from typing import Any

from agentworkbench.models import AgentSpec, BehaviorBrief, EvalCase

_SUBJECTIVE_MARKERS = {
    "brand",
    "clarity",
    "concise",
    "elegant",
    "feel",
    "formal",
    "friendly",
    "polished",
    "preference",
    "style",
    "subjective",
    "taste",
    "tone",
    "verbose",
    "verbosity",
    "voice",
    "warm",
}

_FACTUAL_UNCERTAINTY_MARKERS = {
    "ambiguous",
    "assume",
    "clarify",
    "confirm",
    "missing",
    "unknown",
    "unspecified",
    "uncertain",
}

_WORKFLOW_CONTRACT_FIELDS = (
    "expected_tools",
    "expected_skills",
    "expected_plugins",
    "expected_mcps",
    "expected_prompt_keys",
    "expected_workflow_steps",
    "expected_workflow_sequence",
)


def _flatten_text(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        items: list[str] = []
        for nested in value.values():
            items.extend(_flatten_text(nested))
        return items
    if isinstance(value, list):
        items = []
        for nested in value:
            items.extend(_flatten_text(nested))
        return items
    if value in (None, False):
        return []
    return [str(value)]


def _contains_subjective_signal(*values: Any) -> bool:
    text = " ".join(part.lower() for value in values for part in _flatten_text(value))
    return any(marker in text for marker in _SUBJECTIVE_MARKERS)


def _contains_factual_uncertainty_signal(*values: Any) -> bool:
    text = " ".join(part.lower() for value in values for part in _flatten_text(value))
    return any(marker in text for marker in _FACTUAL_UNCERTAINTY_MARKERS)


def _checkpoint(
    *,
    checkpoint_id: str,
    title: str,
    priority: str,
    question: str,
    reason: str,
    review_type: str,
    question_type: str,
    queue: str,
    response_mode: str,
    suggested_prompt: str | None = None,
    related_case_ids: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "checkpoint_id": checkpoint_id,
        "title": title,
        "priority": priority,
        "question": question,
        "reason": reason,
        "review_type": review_type,
        "question_type": question_type,
        "queue": queue,
        "response_mode": response_mode,
        "suggested_prompt": suggested_prompt or question,
        "related_case_ids": list(dict.fromkeys(related_case_ids or [])),
    }


def _case_process_expectations(case: EvalCase) -> dict[str, Any]:
    return dict((case.metadata or {}).get("process_expectations") or {})


def _case_required_terms(case: EvalCase) -> list[str]:
    metadata = case.metadata or {}
    return [str(item) for item in metadata.get("required_terms", []) if str(item).strip()]


def _case_forbidden_terms(case: EvalCase) -> list[str]:
    metadata = case.metadata or {}
    return [str(item) for item in metadata.get("forbidden_terms", []) if str(item).strip()]


def _case_has_objective_contract(case: EvalCase) -> bool:
    process = _case_process_expectations(case)
    return any(
        [
            str(case.expected).strip(),
            _case_required_terms(case),
            _case_forbidden_terms(case),
            process.get("required_tools"),
            process.get("required_skills"),
            process.get("required_plugins"),
            process.get("required_mcps"),
            process.get("required_prompt_keys"),
            process.get("required_workflow_steps"),
            process.get("workflow_sequence"),
        ]
    )


def _expected_has_objective_contract(expected: dict[str, Any]) -> bool:
    return any(
        [
            expected.get("required_terms"),
            expected.get("forbidden_terms"),
            expected.get("required_tools"),
            expected.get("required_skills"),
            expected.get("required_plugins"),
            expected.get("required_mcps"),
            expected.get("required_prompt_keys"),
            expected.get("required_workflow_steps"),
            expected.get("workflow_sequence"),
        ]
    )


def _explicit_review_config(payload: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    review = payload.get("human_review") or payload.get("review_queue") or {}
    return dict(review) if isinstance(review, dict) else {}


def _review_resolved(payload: dict[str, Any] | None) -> bool:
    review = _explicit_review_config(payload)
    if bool(review.get("resolved")):
        return True
    applied_answers = review.get("applied_answers") or []
    return bool(applied_answers)


def _brief_checkpoint_resolved(brief: BehaviorBrief, checkpoint_id: str) -> bool:
    review = _explicit_review_config(brief.metadata or {})
    resolved_ids = {str(item) for item in review.get("resolved_checkpoint_ids") or [] if str(item).strip()}
    if checkpoint_id in resolved_ids:
        return True
    for item in review.get("applied_answers") or []:
        if str((item or {}).get("checkpoint_id") or "") == checkpoint_id:
            return True
    return False


def build_review_queue(
    *,
    queue_id: str,
    stage: str,
    subject: str,
    checkpoints: list[dict[str, Any]],
) -> dict[str, Any]:
    items = [
        {
            "checkpoint_id": item.get("checkpoint_id"),
            "title": item.get("title"),
            "priority": item.get("priority"),
            "review_type": item.get("review_type"),
            "question_type": item.get("question_type"),
            "queue": item.get("queue"),
            "response_mode": item.get("response_mode"),
            "question": item.get("question"),
            "suggested_prompt": item.get("suggested_prompt") or item.get("question"),
            "reason": item.get("reason"),
            "related_case_ids": item.get("related_case_ids") or [],
        }
        for item in checkpoints
    ]
    return {
        "queue_id": queue_id,
        "stage": stage,
        "subject": subject,
        "item_count": len(items),
        "blocking_count": sum(1 for item in items if str(item.get("priority") or "").strip().lower() == "high"),
        "queues": sorted({str(item.get("queue") or "").strip() for item in items if str(item.get("queue") or "").strip()}),
        "items": items,
    }


def brief_human_checkpoints(
    brief: BehaviorBrief,
    discovery: dict[str, Any],
    agent_spec: AgentSpec | None = None,
) -> list[dict[str, Any]]:
    confirmed_owned_files = list(discovery.get("confirmed_owned_files", []))
    if agent_spec:
        confirmed_owned_files.extend(str(path) for path in agent_spec.owned_paths)
    checkpoints: list[dict[str, Any]] = []

    if not list(dict.fromkeys(item for item in confirmed_owned_files if str(item).strip())) and not _brief_checkpoint_resolved(
        brief, "brief-surface-confirmation"
    ):
        checkpoints.append(
            _checkpoint(
                checkpoint_id="brief-surface-confirmation",
                title="Confirm the target agent surface",
                priority="high",
                question="Which files, prompts, tools, MCPs, and plugins are actually in scope for this target agent before the benchmark is approved?",
                reason="The repo summary does not yet confirm owned target-agent files, so the benchmark could drift onto the wrong surface.",
                review_type="benchmark_authoring",
                question_type="surface_confirmation",
                queue="benchmark_authoring",
                response_mode="confirm_scope",
            )
        )

    exemplar_count = len(brief.examples) + len(brief.rough_answer_outlines) + len(brief.likely_user_commands)
    if exemplar_count < 3 and not _brief_checkpoint_resolved(brief, "brief-representative-examples"):
        checkpoints.append(
            _checkpoint(
                checkpoint_id="brief-representative-examples",
                title="Add representative benchmark examples",
                priority="high",
                question="Which 3-5 real user requests best represent the jobs this agent must handle before eval generation starts?",
                reason="The brief does not yet contain enough concrete examples to anchor the benchmark around real usage.",
                review_type="benchmark_authoring",
                question_type="representative_examples",
                queue="benchmark_authoring",
                response_mode="provide_examples",
            )
        )

    workflow_gaps: list[str] = []
    for workflow in brief.workflow_scenarios:
        has_contract = any(workflow.get(field) for field in _WORKFLOW_CONTRACT_FIELDS)
        if not has_contract:
            workflow_gaps.append(str(workflow.get("name") or workflow.get("trigger") or "workflow"))
    if workflow_gaps and not _brief_checkpoint_resolved(brief, "brief-workflow-contract"):
        checkpoints.append(
            _checkpoint(
                checkpoint_id="brief-workflow-contract",
                title="Clarify workflow expectations before drafting evals",
                priority="medium",
                question="For the listed workflows, which tool calls, memory lookups, MCPs, and handoff steps are actually required versus optional?",
                reason="Some workflow scenarios are still narrative-only and do not specify the concrete process contract the benchmark should score.",
                review_type="benchmark_authoring",
                question_type="workflow_contract",
                queue="benchmark_authoring",
                response_mode="provide_guidance",
                related_case_ids=workflow_gaps[:6],
            )
        )

    if (
        _contains_subjective_signal(
        brief.goal,
        brief.target_questions,
        brief.better_signals,
        brief.worse_signals,
        brief.acceptance_criteria,
        brief.rough_answer_outlines,
        )
        and not _brief_checkpoint_resolved(brief, "brief-subjective-rubric")
    ):
        checkpoints.append(
            _checkpoint(
                checkpoint_id="brief-subjective-rubric",
                title="Define how a human should choose between subjective outputs",
                priority="medium",
                question="When output quality depends on taste or tone, should the human choose baseline, candidate, or neither, and what short guidance should the model follow next time?",
                reason="The brief includes subjective quality signals, so the package should ask the human to resolve taste-based decisions instead of pretending they are fully objective.",
                review_type="subjective_review",
                question_type="pairwise_acceptance",
                queue="benchmark_authoring",
                response_mode="choose_or_guide",
                suggested_prompt="Choose baseline, candidate, or neither for subjective cases, then add one short guidance note for the model if needed.",
            )
        )

    return checkpoints


def eval_human_checkpoints(
    cases: list[EvalCase],
    suite: Any | None = None,
) -> list[dict[str, Any]]:
    del suite
    checkpoints: list[dict[str, Any]] = []
    subjective_cases: list[str] = []
    ambiguous_cases: list[str] = []
    workflow_cases: list[str] = []

    for case in cases:
        metadata = case.metadata or {}
        review_config = _explicit_review_config(metadata)
        process = _case_process_expectations(case)
        subjective = bool(metadata.get("human_review_required") or review_config.get("required")) or _contains_subjective_signal(
            case.tags,
            case.rubric,
            case.expected,
            metadata,
        )
        if _review_resolved(metadata):
            continue
        if subjective and not _case_has_objective_contract(case):
            subjective_cases.append(case.id)
        elif case.rubric and not _case_has_objective_contract(case):
            ambiguous_cases.append(case.id)
        if "workflow" in case.tags and not process:
            workflow_cases.append(case.id)

    if subjective_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="eval-subjective-cases",
                title="Mark subjective cases for human pairwise review",
                priority="high",
                question="For the subjective cases below, should the human choose baseline, candidate, or neither when multiple outputs look plausible, and what short guidance should the model follow?",
                reason="These cases rely on taste or tone but do not yet have an objective acceptance contract.",
                review_type="subjective_review",
                question_type="pairwise_acceptance",
                queue="benchmark_authoring",
                response_mode="choose_or_guide",
                suggested_prompt="Choose baseline, candidate, or neither, then add at most one short guidance note for the model if needed.",
                related_case_ids=subjective_cases[:8],
            )
        )
    if ambiguous_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="eval-acceptance-thresholds",
                title="Tighten guidance for rubric-only cases",
                priority="medium",
                question="Which short constraints, required terms, or disqualifying failure signals should the model follow so these cases can be accepted without guesswork?",
                reason="Several cases rely only on free-form rubric text, which makes regression decisions harder to defend.",
                review_type="benchmark_authoring",
                question_type="acceptance_contract",
                queue="benchmark_authoring",
                response_mode="provide_guidance",
                related_case_ids=ambiguous_cases[:8],
            )
        )
    if workflow_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="eval-workflow-contract",
                title="Confirm workflow process contracts",
                priority="medium",
                question="Which workflow cases should require explicit tool, memory, MCP, or handoff traces before the suite is approved?",
                reason="Some workflow cases do not yet encode the concrete process expectations needed for tool-use or coordination scoring.",
                review_type="benchmark_authoring",
                question_type="workflow_contract",
                queue="benchmark_authoring",
                response_mode="provide_guidance",
                related_case_ids=workflow_cases[:8],
            )
        )
    if _contains_factual_uncertainty_signal(cases):
        checkpoints.append(
            _checkpoint(
                checkpoint_id="eval-factual-clarification",
                title="Clarify factual ambiguity before approval",
                priority="medium",
                question="Which missing facts should be supplied, or which assumptions should the model be told not to make, before this suite is treated as authoritative?",
                reason="Some cases still read as if they rely on unstated facts or assumptions, which makes human review about factual clarification rather than taste.",
                review_type="factual_clarification",
                question_type="missing_fact",
                queue="benchmark_authoring",
                response_mode="provide_guidance",
            )
        )
    return checkpoints


def experiment_human_checkpoints(focus_cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
    checkpoints: list[dict[str, Any]] = []
    pairwise_cases: list[str] = []
    benchmark_gap_cases: list[str] = []
    tool_contract_cases: list[str] = []

    for item in focus_cases:
        case_id = str(item.get("case_id") or "unknown")
        expected = item.get("expected_behavior") or {}
        candidate = item.get("candidate_evidence") or {}
        baseline = item.get("baseline_evidence") or {}
        if _review_resolved({"human_review": expected.get("human_review") or {}}):
            continue
        subjective = _contains_subjective_signal(
            expected.get("tags", []),
            expected.get("rubric", []),
            item.get("reason"),
            candidate.get("final_output_preview"),
            baseline.get("final_output_preview"),
        )
        weak_contract = not _expected_has_objective_contract(expected)
        if subjective and weak_contract and candidate.get("final_output_preview") and baseline.get("final_output_preview"):
            pairwise_cases.append(case_id)
        elif weak_contract and (expected.get("rubric") or expected.get("tags")):
            benchmark_gap_cases.append(case_id)
        if not expected.get("required_tools") and (item.get("tools_added") or item.get("tools_removed")):
            tool_contract_cases.append(case_id)

    if pairwise_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="diagnosis-pairwise-review",
                title="Ask the human for pairwise acceptance on subjective regressions",
                priority="high",
                question="For the cases below, should the human choose baseline, candidate, or neither, and what short guidance should the model follow next time?",
                reason="The baseline and candidate differ on cases whose acceptance still depends on human taste or preference.",
                review_type="subjective_review",
                question_type="pairwise_acceptance",
                queue="answer_acceptance",
                response_mode="choose_or_guide",
                suggested_prompt="Choose baseline, candidate, or neither, then add one short guidance note for the model if needed.",
                related_case_ids=pairwise_cases[:8],
            )
        )
    if benchmark_gap_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="diagnosis-benchmark-gap",
                title="Close benchmark gaps before trusting the regression verdict",
                priority="medium",
                question="Which short constraints, failure signals, or workflow expectations should the model follow for these cases before promotion decisions rely on them?",
                reason="These cases are currently under-specified, so the run can show change without the benchmark clearly saying what should count as correct.",
                review_type="benchmark_authoring",
                question_type="acceptance_contract",
                queue="benchmark_authoring",
                response_mode="provide_guidance",
                related_case_ids=benchmark_gap_cases[:8],
            )
        )
    if tool_contract_cases:
        checkpoints.append(
            _checkpoint(
                checkpoint_id="diagnosis-tool-contract",
                title="Decide whether tool usage should be benchmarked explicitly",
                priority="medium",
                question="For the cases below, should the benchmark require or forbid specific tools, or is tool choice intentionally left open?",
                reason="Behavior changed at the tool-routing level, but the case contract does not yet say whether that change should count as good, bad, or irrelevant.",
                review_type="tool_contract_review",
                question_type="tool_contract",
                queue="answer_acceptance",
                response_mode="provide_guidance",
                related_case_ids=tool_contract_cases[:8],
            )
        )
    return checkpoints


__all__ = [
    "build_review_queue",
    "brief_human_checkpoints",
    "eval_human_checkpoints",
    "experiment_human_checkpoints",
]
