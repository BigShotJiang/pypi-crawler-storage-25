from __future__ import annotations

from typing import Any

_SUPPORTED_KINDS = {"tools", "mcps", "tool_docstrings", "tool_schemas", "tool_formats"}


def normalize_surface_label(surface: str) -> str:
    if surface.startswith("tool:"):
        return f"tools:{surface.split(':', 1)[1]}"
    if surface.startswith("mcp:"):
        return f"mcps:{surface.split(':', 1)[1]}"
    return surface


def retrieval_surface_focus(surface_gaps: dict[str, Any]) -> list[str]:
    return list(
        dict.fromkeys(
            [
                *[f"tools:{item}" for item in surface_gaps.get("tools_with_low_evidence_use", []) or []],
                *[f"tools:{item}" for item in surface_gaps.get("tools_with_unused_selected_evidence", []) or []],
                *[f"mcps:{item}" for item in surface_gaps.get("mcps_with_low_evidence_use", []) or []],
                *[f"mcps:{item}" for item in surface_gaps.get("mcps_with_unused_selected_evidence", []) or []],
            ]
        )
    )


def matching_surface_recommendations(
    surface_recommendations: list[dict[str, Any]],
    *,
    surfaces: list[str] | None = None,
    recommendations: set[str] | None = None,
    limit: int = 3,
) -> list[dict[str, Any]]:
    allowed_surfaces = {normalize_surface_label(str(item)) for item in (surfaces or []) if str(item).strip()}
    matched: list[dict[str, Any]] = []
    for item in surface_recommendations or []:
        surface = str(item.get("surface") or "")
        recommendation = str(item.get("recommendation") or "")
        if allowed_surfaces and surface not in allowed_surfaces:
            continue
        if recommendations and recommendation not in recommendations:
            continue
        matched.append(item)
    return matched[:limit]


def surface_recommendation_text(items: list[dict[str, Any]]) -> str:
    labels: list[str] = []
    for item in items:
        surface = str(item.get("surface") or "surface")
        recommendation = str(item.get("recommendation") or "review")
        labels.append(f"{surface} => {recommendation}")
    return ", ".join(labels) or "none"


def _as_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    return float(value)


def _as_int(value: Any) -> int:
    if value in (None, ""):
        return 0
    return int(value)


def _factor_effect_lookup(items: list[dict[str, Any]]) -> dict[tuple[str, str], dict[str, Any]]:
    lookup: dict[tuple[str, str], dict[str, Any]] = {}
    for item in items or []:
        factor = str(item.get("factor") or "")
        kind, _, name = factor.partition(":")
        if kind not in _SUPPORTED_KINDS or not name:
            continue
        lookup[(kind, name)] = item
    return lookup


def _interaction_lookup(items: list[dict[str, Any]]) -> dict[tuple[str, str], dict[str, Any]]:
    lookup: dict[tuple[str, str], dict[str, Any]] = {}
    for item in items or []:
        pair = str(item.get("pair") or "")
        left, _, right = pair.partition(" x ")
        if not left or not right:
            continue
        score = float(item.get("average_score_interaction", 0.0) or 0.0)
        for label, partner in [(left, right), (right, left)]:
            kind, _, name = label.partition(":")
            if kind not in _SUPPORTED_KINDS or not name:
                continue
            current = lookup.get((kind, name))
            if current is None or abs(score) > abs(float(current.get("average_score_interaction", 0.0) or 0.0)):
                lookup[(kind, name)] = {
                    "pair": pair,
                    "paired_with": partner,
                    "average_score_interaction": round(score, 3),
                }
    return lookup


def _available_surface_names(behavior: dict[str, Any], kind: str) -> list[str]:
    surface_audits = (behavior.get("surface_audits") or {}).get(kind) or {}
    available = [str(item) for item in surface_audits.get("available") or [] if str(item).strip()]
    audit_key = "tool_audits" if kind == "tools" else "mcp_audits"
    available.extend(str(item) for item in ((behavior.get(audit_key) or {}).keys()) if str(item).strip())
    return sorted(dict.fromkeys(available))


def _generic_factor_recommendation(
    *,
    kind: str,
    name: str,
    factor_effect: dict[str, Any],
    interaction: dict[str, Any] | None,
) -> dict[str, Any] | None:
    score_effect = _as_float(factor_effect.get("average_score_effect"))
    cost_effect = _as_float(factor_effect.get("average_cost_effect"))
    evidence_effect = _as_float(factor_effect.get("selected_evidence_use_rate_effect"))
    if score_effect is None:
        return None
    reasons: list[str] = []
    recommendation = "review"
    priority = 40
    if score_effect > 0.05:
        reasons.append("Factorial evidence says keeping this interface surface helps score.")
        recommendation = "keep_enabled"
        priority = 62
        if interaction and abs(float(interaction.get("average_score_interaction", 0.0) or 0.0)) >= 0.1:
            reasons.append(f"Strong interaction detected with `{interaction.get('paired_with')}`.")
            recommendation = "keep_with_interaction"
            priority = 66
    elif score_effect < -0.05:
        reasons.append("Factorial evidence says the alternate interface version works better than the current one.")
        recommendation = "prefer_alternate_interface"
        priority = 70
    elif (cost_effect or 0.0) > 0.0:
        reasons.append("The current interface version adds cost without a meaningful score gain.")
        recommendation = "overhead_candidate"
        priority = 58
    else:
        reasons.append("The current and alternate interface versions are close enough that this surface is low priority.")
        recommendation = "neutral_interface"
        priority = 35
    return {
        "surface": f"{kind}:{name}",
        "surface_kind": kind,
        "surface_name": name,
        "recommendation": recommendation,
        "priority": priority,
        "attempted": None,
        "success": None,
        "empty": None,
        "error": None,
        "selected_evidence": None,
        "supported_evidence": None,
        "selected_evidence_use_rate": None,
        "cases_with_unsupported_selected_evidence": None,
        "average_score_effect": round(score_effect, 3),
        "average_cost_effect": round(cost_effect, 6) if cost_effect is not None else None,
        "selected_evidence_use_rate_effect": round(evidence_effect, 3) if evidence_effect is not None else None,
        "strongest_interaction": interaction or {},
        "reasons": reasons,
    }


def _surface_recommendation(
    *,
    kind: str,
    name: str,
    audit: dict[str, Any],
    factor_effect: dict[str, Any] | None,
    interaction: dict[str, Any] | None,
    unused_available: set[str],
) -> dict[str, Any] | None:
    use_rate = _as_float(audit.get("selected_evidence_use_rate"))
    attempted = _as_int(audit.get("attempted"))
    success = _as_int(audit.get("success"))
    empty = _as_int(audit.get("empty"))
    errors = _as_int(audit.get("error"))
    selected = _as_int(audit.get("selected_evidence"))
    supported = _as_int(audit.get("supported_evidence"))
    unsupported_cases = _as_int(audit.get("cases_with_unsupported_selected_evidence"))
    score_effect = _as_float((factor_effect or {}).get("average_score_effect"))
    cost_effect = _as_float((factor_effect or {}).get("average_cost_effect"))
    evidence_effect = _as_float((factor_effect or {}).get("selected_evidence_use_rate_effect"))
    label = f"{kind}:{name}"
    reasons: list[str] = []

    if errors > 0:
        reasons.append(f"{errors} error events were recorded for this surface.")
        recommendation = "fix_errors"
        priority = 100
    elif unsupported_cases > 0 or (selected > 0 and use_rate is not None and use_rate < 0.5):
        if score_effect is not None and score_effect > 0.05:
            reasons.append("Factorial evidence says this surface helps score when enabled.")
            recommendation = "keep_enabled_fix_grounding"
            priority = 90
        elif score_effect is not None and score_effect < -0.05:
            reasons.append("Factorial evidence says this surface hurts score when enabled.")
            recommendation = "replace_or_disable"
            priority = 88
        else:
            reasons.append("Selected evidence is not consistently making it into final answers.")
            recommendation = "improve_grounding"
            priority = 85
    elif score_effect is not None and score_effect < -0.05:
        reasons.append("Factorial evidence says enabling this surface lowers score.")
        recommendation = "prune_or_disable"
        priority = 80
    elif attempted > 0 and success == 0 and empty > 0 and selected == 0:
        reasons.append("This surface is being invoked but only returning empty results.")
        recommendation = "fix_or_prune_empty"
        priority = 75
    elif name in unused_available:
        if score_effect is not None and score_effect > 0.05:
            reasons.append("Factorial evidence says this surface helps, but it was unused in the latest run.")
            recommendation = "exercise_surface_in_routing"
            priority = 72
        else:
            reasons.append("The surface is enabled but unused in the latest run.")
            recommendation = "unused_available"
            priority = 68
    elif score_effect is not None and abs(score_effect) < 0.03 and (cost_effect or 0.0) > 0.0:
        reasons.append("This surface adds measurable cost without a meaningful score gain.")
        recommendation = "overhead_candidate"
        priority = 64
    elif score_effect is not None and score_effect > 0.05:
        if interaction and abs(float(interaction.get("average_score_interaction", 0.0) or 0.0)) >= 0.1:
            reasons.append(f"Strong interaction detected with `{interaction.get('paired_with')}`.")
            recommendation = "keep_with_interaction"
            priority = 60
        elif (cost_effect or 0.0) > 0.0 and score_effect < 0.1:
            reasons.append("This surface helps, but the gain is modest relative to the added cost.")
            recommendation = "keep_but_watch_cost"
            priority = 58
        else:
            reasons.append("Factorial evidence says this surface improves score when enabled.")
            recommendation = "keep_enabled"
            priority = 55
    elif selected > 0 and use_rate is not None and use_rate >= 0.75 and supported > 0:
        reasons.append("The latest run shows good selected-evidence support for this surface.")
        recommendation = "healthy_current_surface"
        priority = 50
    else:
        return None

    if use_rate is not None and recommendation not in {"keep_enabled_fix_grounding", "improve_grounding"}:
        reasons.append(f"Latest selected-evidence use rate is {use_rate:.3f}.")
    return {
        "surface": label,
        "surface_kind": kind,
        "surface_name": name,
        "recommendation": recommendation,
        "priority": priority,
        "attempted": attempted,
        "success": success,
        "empty": empty,
        "error": errors,
        "selected_evidence": selected,
        "supported_evidence": supported,
        "selected_evidence_use_rate": round(use_rate, 3) if use_rate is not None else None,
        "cases_with_unsupported_selected_evidence": unsupported_cases,
        "average_score_effect": round(score_effect, 3) if score_effect is not None else None,
        "average_cost_effect": round(cost_effect, 6) if cost_effect is not None else None,
        "selected_evidence_use_rate_effect": round(evidence_effect, 3) if evidence_effect is not None else None,
        "strongest_interaction": interaction or {},
        "reasons": reasons,
    }


def build_surface_recommendations(
    behavior_summary: dict[str, Any],
    *,
    factor_effects: list[dict[str, Any]] | None = None,
    pair_interactions: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    factor_lookup = _factor_effect_lookup(factor_effects or [])
    interaction_lookup = _interaction_lookup(pair_interactions or [])
    recommendations: list[dict[str, Any]] = []
    for kind, audit_key, unused_key in [
        ("tools", "tool_audits", "unused_available_tools"),
        ("mcps", "mcp_audits", "unused_available_mcps"),
    ]:
        audits = behavior_summary.get(audit_key) or {}
        unused_available = {str(item) for item in behavior_summary.get(unused_key, []) or [] if str(item).strip()}
        for name in _available_surface_names(behavior_summary, kind):
            recommendation = _surface_recommendation(
                kind=kind,
                name=name,
                audit=audits.get(name) or {},
                factor_effect=factor_lookup.get((kind, name)),
                interaction=interaction_lookup.get((kind, name)),
                unused_available=unused_available,
            )
            if recommendation is not None:
                recommendations.append(recommendation)
    seen = {(str(item.get("surface_kind")), str(item.get("surface_name"))) for item in recommendations}
    for (kind, name), factor_effect in factor_lookup.items():
        if (kind, name) in seen or kind in {"tools", "mcps"}:
            continue
        recommendation = _generic_factor_recommendation(
            kind=kind,
            name=name,
            factor_effect=factor_effect,
            interaction=interaction_lookup.get((kind, name)),
        )
        if recommendation is not None:
            recommendations.append(recommendation)
    return sorted(
        recommendations,
        key=lambda item: (-int(item.get("priority", 0)), str(item.get("surface_kind")), str(item.get("surface_name"))),
    )
