from __future__ import annotations

from pathlib import Path

from agentworkbench.config import control_dir, dump_model
from agentworkbench.models import AgentSpec, WorkbenchConfig
from agentworkbench.utils import ensure_dir, write_text

AGENTS_TEMPLATE = """# Agent Workbench Instructions

1. Run `awb learn` before creating a behavior brief or editing the target agent files.
2. Use `awb brief start --agent-id <id>` and the generated packet to interview the user and capture approved behavior in `.agent-workbench/briefs/*.yaml`.
3. Only generate evals from an approved brief, then review the draft suite and approve it before running experiments.
4. Use `awb run`, `awb compare --best`, `awb diagnose`, `awb ablate`, `awb status`, and `awb promote` instead of ad hoc scripts.
5. Use `awb propose` after diagnosis when you want a bounded mutation plan, then `awb patch-template` to turn that proposal into an editable implementation checklist for the real repo files that define the target agent.
6. Keep benchmark drift visible. If briefs, evals, or scorers change, call that out explicitly.
7. Treat prompts, tools, skills, plugins, MCPs, memory integrations, and runtime configs as first-class optimization levers. Check whether newly added surfaces are actually used before keeping them.
8. Preserve agent telemetry. Prefer emitting `workflow_trace`, `events`, `tool_calls`, and related surface usage so comparisons can explain why behavior changed.
"""


COPILOT_TEMPLATE = """---
name: optimizer
description: Repo-native optimizer that learns the repo, drafts a behavior brief for a target agent implemented in local repo code, generates evals, and compares iterations.
tools: ["codebase", "terminal", "search", "edit"]
---

Use `awb` commands rather than ad hoc helpers. Learn the repo first, inspect which local files actually define the target agent, then run `awb brief start --agent-id <id>` and use the generated packet while interviewing the user about the target agent. Draft and approve the behavior brief before eval generation, then generate a draft eval suite, review it, and approve it before running experiments. Use `awb status` to inspect the current gates and promoted baselines, `awb compare --best` to compare a new candidate against the best comparable run, `awb diagnose` to turn regressions into concrete next mutations, `awb ablate` to test whether prompts, tools, skills, plugins, or MCPs are actually carrying the result, `awb propose` to convert those mutations into a bounded edit plan, and `awb patch-template` to turn the chosen proposal into an editable implementation checklist that points at prompts, tools, runtime config, memory, and MCP integration files when possible.

Keep target-agent telemetry intact when possible. Emit `workflow_trace`, `events`, `tool_calls`, `skills_used`, `plugins_used`, `mcp_servers_used`, and `prompt_keys_used` so the harness can attribute behavior changes to concrete workflow decisions.
"""


GENERATED_GITIGNORE_ENTRIES = [
    ".agent-workbench/runs/",
    ".agent-workbench/reports/",
    ".agent-workbench/proposals/",
    ".agent-workbench/patches/",
    ".agent-workbench/ablations/",
    ".agent-workbench/matrices/",
    ".agent-workbench/factorials/",
    ".agent-workbench/iterations/",
    ".agent-workbench/stability/",
    ".agent-workbench/exports/",
    "__pycache__/",
    ".pytest_cache/",
]


def _write_text_if_missing(path: Path, content: str) -> Path:
    if not path.exists():
        write_text(path, content)
    return path


def _dump_model_if_missing(path: Path, model: WorkbenchConfig | AgentSpec) -> Path:
    if not path.exists():
        dump_model(path, model)
    return path


def _ensure_gitignore_entries(path: Path, entries: list[str]) -> Path:
    existing_lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    existing = set(existing_lines)
    missing = [entry for entry in entries if entry not in existing]
    if not missing and path.exists():
        return path
    lines = list(existing_lines)
    if lines and lines[-1].strip():
        lines.append("")
    lines.extend(missing or entries)
    return write_text(path, "\n".join(lines))


def init_workbench(project_root: Path) -> dict[str, Path]:
    control = control_dir(project_root)
    for relative in [
        "agents",
        "briefs",
        "evals",
        "scorers",
        "adapters",
        "discovery",
        "runs",
        "reports",
        "exports",
        "benchmarks",
        "proposals",
        "patches",
        "ablations",
        "matrices",
        "factorials",
        "iterations",
        "stability",
        "cache",
        "cache/provider",
    ]:
        ensure_dir(control / relative)
    ensure_dir(project_root / ".github" / "agents")
    config = WorkbenchConfig()
    agent_spec = AgentSpec(
        id="sample-agent",
        adapter="command",
        instructions=[
            "Treat this file as a thin harness around the real local target agent.",
            "Replace the placeholder command entrypoint with your actual repo-local agent invocation.",
        ],
        prompts={"system": "Answer the user using grounded repo context and the local agent implementation."},
        model={"name": "replace-me"},
        tools=[{"name": "repo_search", "enabled": True}],
        skills=[{"name": "repo_reading", "enabled": True}],
        plugins=[{"name": "repo_index", "enabled": True}],
        mcps=[{"name": "filesystem", "enabled": True}],
        owned_paths=[],
        owned_globs=[],
        surface_paths={
            "instructions": [],
            "prompts": [],
            "tools": [],
            "runtime": [],
            "tests": [],
        },
        required_env=[],
        runtime={"env": {}},
        entrypoints={
            "command": {
                "argv": [
                    "python3",
                    "-c",
                    (
                        "import json, os; "
                        "payload = {"
                        "'final_output': os.environ.get('AWB_INPUT', ''), "
                        "'events': ['prompt:system', 'tool:repo_search', 'skill:repo_reading'], "
                        "'workflow_trace': ['startup:prompt_load', 'tool:repo_search', 'skill:repo_reading'], "
                        "'tool_calls': [{'name': 'repo_search'}], "
                        "'skills_used': ['repo_reading'], "
                        "'plugins_used': ['repo_index'], "
                        "'mcp_servers_used': ['filesystem'], "
                        "'prompt_keys_used': ['system'], "
                        "'step_count': 1"
                        "}; "
                        "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))"
                    ),
                ],
                "cwd": ".",
                "timeout_seconds": 300,
            }
        },
        metadata={"owner": "agentworkbench"},
    )
    improved_agent_spec = AgentSpec(
        id="sample-agent-improved",
        adapter="command",
        instructions=[
            "Treat this file as a thin harness around a more grounded local target agent variant.",
            "Replace the placeholder command entrypoint with your actual repo-local agent invocation.",
        ],
        prompts={
            "system": "Answer the user using the repo context.",
            "reviewer": "Check whether the answer is grounded before returning it.",
        },
        model={"name": "replace-me"},
        tools=[{"name": "repo_search", "enabled": True}, {"name": "answer_reviewer", "enabled": True}],
        skills=[{"name": "repo_reading", "enabled": True}, {"name": "critic", "enabled": True}],
        plugins=[{"name": "repo_index", "enabled": True}, {"name": "workflow_memory", "enabled": True}],
        mcps=[{"name": "filesystem", "enabled": True}, {"name": "memory", "enabled": True}],
        owned_paths=[],
        owned_globs=[],
        surface_paths={
            "instructions": [],
            "prompts": [],
            "tools": [],
            "memory": [],
            "runtime": [],
            "tests": [],
        },
        required_env=[],
        runtime={"env": {}},
        entrypoints={
            "command": {
                "argv": [
                    "python3",
                    "-c",
                    (
                        "import json, os; "
                        "payload = {"
                        "'final_output': 'Describe the expected behavior\\n' + os.environ.get('AWB_INPUT', ''), "
                        "'events': ['prompt:system', 'prompt:reviewer', 'tool:repo_search', 'skill:repo_reading', 'skill:critic'], "
                        "'workflow_trace': ['startup:prompt_load', 'tool:repo_search', 'skill:repo_reading', 'skill:critic'], "
                        "'tool_calls': [{'name': 'repo_search'}, {'name': 'answer_reviewer'}], "
                        "'skills_used': ['repo_reading', 'critic'], "
                        "'plugins_used': ['repo_index', 'workflow_memory'], "
                        "'mcp_servers_used': ['filesystem', 'memory'], "
                        "'prompt_keys_used': ['system', 'reviewer'], "
                        "'step_count': 2"
                        "}; "
                        "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))"
                    ),
                ],
                "cwd": ".",
                "timeout_seconds": 300,
            }
        },
        metadata={"owner": "agentworkbench"},
    )
    _dump_model_if_missing(control / "workbench.yaml", config)
    _dump_model_if_missing(control / "agents" / "sample-agent.yaml", agent_spec)
    _dump_model_if_missing(control / "agents" / "sample-agent-improved.yaml", improved_agent_spec)
    _write_text_if_missing(project_root / "AGENTS.md", AGENTS_TEMPLATE)
    _write_text_if_missing(project_root / ".github" / "agents" / "optimizer.agent.md", COPILOT_TEMPLATE)
    _ensure_gitignore_entries(project_root / ".gitignore", GENERATED_GITIGNORE_ENTRIES)
    return {
        "config": control / "workbench.yaml",
        "agent_spec": control / "agents" / "sample-agent.yaml",
        "improved_agent_spec": control / "agents" / "sample-agent-improved.yaml",
        "agents_md": project_root / "AGENTS.md",
    }
