"""Conditional multi-agent workflows with routed transitions between nodes."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agentworkbench.adapters import get_adapter
from agentworkbench.aggregate_metrics import aggregate_workflow_rows
from agentworkbench.case_selection import build_case_selection
from agentworkbench.chain import (
    _accumulate_turns,
    _build_chain_context,
    _build_handoff,
    _score_step,
)
from agentworkbench.config import control_dir, experiment_dir, load_config, load_model
from agentworkbench.constants import RUN_CONTEXT_FILENAME
from agentworkbench.evals import load_eval_cases, load_scoring_context
from agentworkbench.models import (
    AgentSpec,
    ExperimentRecord,
    RunArtifact,
    StepScore,
    WorkflowAggregate,
    WorkflowEdgeConfig,
    WorkflowSpec,
)
from agentworkbench.report_experiment import render_experiment_report
from agentworkbench.reports import write_report
from agentworkbench.run_context import build_run_context, persist_run_artifacts
from agentworkbench.run_failures import failed_cases_for_experiment
from agentworkbench.run_finalize import finalize_run
from agentworkbench.run_helpers import _spec_snapshot
from agentworkbench.safe_expressions import UnsafeExpressionError, evaluate_condition
from agentworkbench.snapshot import capture_snapshot, compute_benchmark_hashes
from agentworkbench.surface_details import capture_surface_snapshot
from agentworkbench.surface_usage import tool_call_names
from agentworkbench.telemetry import enrich_run_artifact_payload
from agentworkbench.utils import (
    created_at_utc,
    ensure_dir,
    read_json,
    read_yaml,
    utc_timestamp_slug,
    write_json,
    write_jsonl,
)


def _workflow_file_path(project_root: Path, workflow_file: str | Path) -> Path:
    candidate = Path(workflow_file)
    if candidate.is_absolute():
        return candidate
    direct = project_root / candidate
    if direct.exists():
        return direct
    workflow_dir = control_dir(project_root) / "workflows"
    from_control = workflow_dir / candidate
    if from_control.exists():
        return from_control
    if candidate.suffix:
        return from_control
    for suffix in (".yaml", ".yml", ".json"):
        alt = workflow_dir / f"{candidate}{suffix}"
        if alt.exists():
            return alt
    return from_control


def _load_workflow_spec(project_root: Path, workflow_file: str | Path) -> tuple[WorkflowSpec, str]:
    path = _workflow_file_path(project_root, workflow_file)
    if not path.exists():
        raise FileNotFoundError(f"Workflow file not found: {path}")
    if path.suffix.lower() == ".json":
        payload = read_json(path)
    else:
        payload = read_yaml(path)
    spec = WorkflowSpec.model_validate(payload or {})
    node_ids = [node.id for node in spec.nodes]
    if not node_ids:
        raise ValueError("Workflow must define at least one node.")
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("Workflow node ids must be unique.")
    if spec.start_at not in set(node_ids):
        raise ValueError(f"Workflow start_at `{spec.start_at}` is not declared in nodes.")
    valid_nodes = set(node_ids)
    for node in spec.nodes:
        if node.node_type == "agent" and not str(node.agent_id or "").strip():
            raise ValueError(f"Workflow node `{node.id}` requires `agent_id` when node_type=agent.")
        if node.node_type == "chain" and not [item for item in node.chain_agent_ids if str(item).strip()]:
            raise ValueError(f"Workflow node `{node.id}` requires `chain_agent_ids` when node_type=chain.")
    for edge in spec.edges:
        if edge.from_node not in valid_nodes:
            raise ValueError(f"Workflow edge references unknown from node `{edge.from_node}`.")
        if edge.to_node not in valid_nodes:
            raise ValueError(f"Workflow edge references unknown to node `{edge.to_node}`.")
    relative_path = str(path.relative_to(project_root)) if path.is_relative_to(project_root) else str(path)
    return spec, relative_path


def _enabled_rows(names: set[str]) -> list[dict[str, Any]]:
    return [{"name": name, "enabled": True} for name in sorted(name for name in names if name)]


def _node_agent_ids(node: Any) -> list[str]:
    if str(getattr(node, "node_type", "agent") or "agent").strip().lower() == "chain":
        return [str(item) for item in getattr(node, "chain_agent_ids", []) or [] if str(item).strip()]
    agent_id = str(getattr(node, "agent_id", "") or "").strip()
    return [agent_id] if agent_id else []


def _node_runtime_label(node: Any) -> str:
    agent_id = str(getattr(node, "agent_id", "") or "").strip()
    if agent_id:
        return agent_id
    chain_ids = _node_agent_ids(node)
    return " -> ".join(chain_ids) if chain_ids else str(getattr(node, "id", "node") or "node")


def _load_node_specs(project_root: Path, node: Any) -> list[AgentSpec]:
    return [
        load_model(control_dir(project_root) / "agents" / f"{agent_id}.yaml", AgentSpec)
        for agent_id in _node_agent_ids(node)
    ]


def _merge_surface_paths(specs: list[AgentSpec]) -> dict[str, list[str]]:
    merged: dict[str, set[str]] = {}
    for spec in specs:
        for key, values in (spec.surface_paths or {}).items():
            merged.setdefault(str(key), set()).update(str(item) for item in values or [])
    return {key: sorted(values) for key, values in sorted(merged.items()) if values}


def _workflow_surface_spec(workflow: WorkflowSpec, specs: list[AgentSpec], workflow_file: str) -> AgentSpec:
    tools = {str(item.get("name") or "").strip() for spec in specs for item in spec.tools if isinstance(item, dict)}
    skills = {str(item.get("name") or "").strip() for spec in specs for item in spec.skills if isinstance(item, dict)}
    plugins = {str(item.get("name") or "").strip() for spec in specs for item in spec.plugins if isinstance(item, dict)}
    mcps = {str(item.get("name") or "").strip() for spec in specs for item in spec.mcps if isinstance(item, dict)}
    owned_paths = {str(path) for spec in specs for path in spec.owned_paths}
    owned_globs = {str(path) for spec in specs for path in spec.owned_globs}
    required_env = {str(name) for spec in specs for name in spec.required_env}
    prompt_keys = {str(key) for spec in specs for key in (spec.prompts or {}).keys()}
    return AgentSpec(
        id=workflow.id,
        adapter="command",
        instructions=[
            (
                f"Workflow node {node.id} uses agent {node.agent_id}."
                if str(node.node_type) == "agent"
                else f"Workflow node {node.id} runs chain {' -> '.join(_node_agent_ids(node))}."
            )
            for node in workflow.nodes
        ],
        prompts={key: "" for key in sorted(prompt_keys)},
        model={"name": "workflow"},
        tools=_enabled_rows(tools),
        skills=_enabled_rows(skills),
        plugins=_enabled_rows(plugins),
        mcps=_enabled_rows(mcps),
        owned_paths=sorted(owned_paths),
        owned_globs=sorted(owned_globs),
        surface_paths=_merge_surface_paths(specs),
        required_env=sorted(required_env),
        runtime={"workflow_file": workflow_file},
        metadata={
            "workflow_id": workflow.id,
            "workflow_nodes": [
                {
                    "id": node.id,
                    "node_type": node.node_type,
                    "agent_id": node.agent_id,
                    "chain_agent_ids": _node_agent_ids(node),
                }
                for node in workflow.nodes
            ],
        },
    )


def _workflow_spec_snapshot(
    project_root: Path, workflow: WorkflowSpec, specs: list[AgentSpec], workflow_file: str
) -> dict[str, Any]:
    synthetic_spec = _workflow_surface_spec(workflow, specs, workflow_file)
    snapshot = _spec_snapshot(synthetic_spec, project_root)
    model_names = sorted({str(spec.model.get("name") or spec.model.get("model_id") or "unknown") for spec in specs})
    snapshot.update(
        {
            "adapter": "workflow",
            "spec_path": workflow_file,
            "workflow_id": workflow.id,
            "workflow_file": workflow_file,
            "workflow_nodes": [
                {
                    "id": node.id,
                    "node_type": node.node_type,
                    "agent_id": node.agent_id,
                    "chain_agent_ids": _node_agent_ids(node),
                }
                for node in workflow.nodes
            ],
            "workflow_edges": [
                {
                    "from": edge.from_node,
                    "to": edge.to_node,
                    "when": edge.when,
                    "label": edge.label,
                    "default": edge.default,
                }
                for edge in workflow.edges
            ],
            "workflow_agent_ids": [agent_id for node in workflow.nodes for agent_id in _node_agent_ids(node)],
            "model_name": ", ".join(model_names) if model_names else "workflow",
            "model_names": model_names,
            "command_entrypoint": f"workflow:{workflow_file}",
            "command_cwd": ".",
        }
    )
    return snapshot


def _structured_payload(artifact: Any) -> dict[str, Any]:
    payload = (artifact.structured_output or {}).get("structured_output")
    if isinstance(payload, dict):
        return payload
    payload = artifact.structured_output or {}
    if isinstance(payload, dict) and any(
        key in payload for key in ("route", "next", "next_node", "destination", "decision")
    ):
        return payload
    return {}


def _derive_route(final_output: str, artifact: Any) -> str:
    structured = _structured_payload(artifact)
    for key in ("route", "next", "next_node", "destination", "decision"):
        value = structured.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    names = tool_call_names(artifact.model_dump(mode="json") if hasattr(artifact, "model_dump") else artifact)
    if len(names) == 1:
        return names[0]
    text = str(final_output or "").strip()
    if not text:
        return ""
    if text[0] in "{[":
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            for key in ("route", "next", "next_node", "destination", "decision"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
    return text.splitlines()[0].strip()


def _evaluate_workflow_edge(condition: str | None, context: dict[str, Any]) -> bool:
    if not condition:
        return True
    try:
        return evaluate_condition(condition, context)
    except UnsafeExpressionError:
        return False


def _select_next_edge(
    outgoing: list[WorkflowEdgeConfig],
    *,
    route_context: dict[str, Any],
) -> tuple[WorkflowEdgeConfig | None, list[WorkflowEdgeConfig]]:
    matched: list[WorkflowEdgeConfig] = []
    default_edge: WorkflowEdgeConfig | None = None
    for edge in outgoing:
        if edge.default and default_edge is None:
            default_edge = edge
        if edge.when is None and not edge.default:
            matched.append(edge)
            continue
        if edge.when and _evaluate_workflow_edge(edge.when, route_context):
            matched.append(edge)
    if matched:
        return matched[0], matched
    return default_edge, matched


def _edge_summary(edge: WorkflowEdgeConfig | None) -> dict[str, Any] | None:
    if edge is None:
        return None
    return {
        "from": edge.from_node,
        "to": edge.to_node,
        "label": edge.label,
        "when": edge.when,
        "default": edge.default,
    }


def _selected_edges_for_node(
    node: Any,
    selected_edge: WorkflowEdgeConfig | None,
    matched_edges: list[WorkflowEdgeConfig],
) -> list[WorkflowEdgeConfig]:
    routing_mode = str(getattr(node, "routing_mode", "first") or "first").strip().lower()
    if routing_mode == "all" and matched_edges:
        return matched_edges
    return [selected_edge] if selected_edge is not None else []


def _incoming_nodes_by_target(workflow: WorkflowSpec) -> dict[str, set[str]]:
    incoming: dict[str, set[str]] = {node.id: set() for node in workflow.nodes}
    for edge in workflow.edges:
        incoming.setdefault(edge.to_node, set()).add(edge.from_node)
    return incoming


def _merge_turns(arrivals: list[dict[str, Any]], fallback_turns: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if len(arrivals) == 1:
        turns = arrivals[0].get("turns")
        if isinstance(turns, list):
            return list(turns)
    for arrival in arrivals:
        turns = arrival.get("turns")
        if isinstance(turns, list) and turns:
            return list(turns)
    return list(fallback_turns)


def _merge_arrival_outputs(arrivals: list[dict[str, Any]]) -> str:
    if not arrivals:
        return ""
    if len(arrivals) == 1:
        return str(arrivals[0].get("prior_output") or "")
    chunks: list[str] = []
    for arrival in arrivals:
        label = str(arrival.get("from_node") or "start")
        output = str(arrival.get("prior_output") or "").strip()
        if output:
            chunks.append(f"[{label}] {output}")
    return "\n\n".join(chunks)


def _merge_artifact_summaries(arrivals: list[dict[str, Any]]) -> dict[str, Any]:
    if not arrivals:
        return {}
    if len(arrivals) == 1:
        return dict(arrivals[0].get("prior_artifact_summary") or {})
    merged: dict[str, Any] = {
        "final_output": _merge_arrival_outputs(arrivals),
        "tool_calls": [],
        "evidence_records": [],
        "trace_events": [],
        "latency_ms": 0,
        "token_usage": {},
        "cost_estimate": 0.0,
        "step_count": 0,
        "errors": [],
        "incoming_edges": [],
    }
    token_usage: dict[str, int] = {}
    for arrival in arrivals:
        summary = dict(arrival.get("prior_artifact_summary") or {})
        merged["tool_calls"].extend(summary.get("tool_calls") or [])
        merged["evidence_records"].extend(summary.get("evidence_records") or [])
        merged["trace_events"].extend(summary.get("trace_events") or [])
        merged["latency_ms"] += int(summary.get("latency_ms", 0) or 0)
        merged["cost_estimate"] += float(summary.get("cost_estimate", 0.0) or 0.0)
        merged["step_count"] += int(summary.get("step_count", 0) or 0)
        merged["errors"].extend(summary.get("errors") or [])
        incoming_edge = arrival.get("incoming_edge")
        if incoming_edge:
            merged["incoming_edges"].append(incoming_edge)
        for key, value in (summary.get("token_usage") or {}).items():
            token_usage[str(key)] = token_usage.get(str(key), 0) + int(value or 0)
    if token_usage:
        merged["token_usage"] = token_usage
    return merged


def _shared_context_updates(artifact: Any) -> dict[str, Any]:
    structured_output = artifact.structured_output or {}
    updates = structured_output.get("shared_context_updates")
    if isinstance(updates, dict):
        return dict(updates)
    nested = structured_output.get("structured_output")
    if isinstance(nested, dict):
        updates = nested.get("shared_context_updates")
        if isinstance(updates, dict):
            return dict(updates)
    metadata = artifact.metadata or {}
    updates = metadata.get("shared_context_updates")
    if isinstance(updates, dict):
        return dict(updates)
    return {}


def _merge_shared_context(shared_context: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    if not updates:
        return dict(shared_context)
    merged = dict(shared_context)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = {**dict(merged.get(key) or {}), **value}
        elif isinstance(value, list) and isinstance(merged.get(key), list):
            merged[key] = [*list(merged.get(key) or []), *value]
        else:
            merged[key] = value
    return merged


def _sum_token_usage(existing: dict[str, int], updates: dict[str, Any]) -> dict[str, int]:
    merged = dict(existing)
    for key, value in (updates or {}).items():
        merged[str(key)] = merged.get(str(key), 0) + int(value or 0)
    return merged


def _invoke_agent_artifact(project_root: Path, spec: AgentSpec, step_case: Any, case_dir: Path) -> RunArtifact:
    adapter = get_adapter(spec.adapter)
    artifact = adapter.invoke(project_root, spec, step_case, case_dir)
    enriched = enrich_run_artifact_payload(
        artifact.model_dump(mode="json"), spec_snapshot=_spec_snapshot(spec, project_root)
    )
    return RunArtifact.model_validate(enriched)


def _artifact_output(artifact: RunArtifact) -> str:
    return str(
        artifact.final_output
        or (artifact.structured_output or {}).get("final_output")
        or (artifact.structured_output or {}).get("output")
        or ""
    )


def _artifact_summary(artifact: RunArtifact) -> dict[str, Any]:
    return {
        "final_output": _artifact_output(artifact),
        "structured_output": _structured_payload(artifact),
        "tool_calls": artifact.tool_calls or [],
        "evidence_records": artifact.evidence_records or [],
        "trace_events": artifact.trace_events or [],
        "latency_ms": artifact.latency_ms,
        "token_usage": artifact.token_usage or {},
        "cost_estimate": artifact.cost_estimate,
        "step_count": artifact.step_count,
        "errors": artifact.errors or [],
        "route": _derive_route(_artifact_output(artifact), artifact),
        "shared_context_updates": _shared_context_updates(artifact),
    }


def _invoke_chain_node(
    project_root: Path,
    node: Any,
    step_case: Any,
    case_dir: Path,
    *,
    shared_context: dict[str, Any],
) -> tuple[RunArtifact, AgentSpec]:
    chain_agent_ids = _node_agent_ids(node)
    local_shared_context = dict(shared_context)
    chain_steps: list[dict[str, Any]] = []
    accumulated_turns = list(step_case.turns) if step_case.turns else []
    prior_output = ""
    prior_artifact_summary: dict[str, Any] = {}
    final_artifact: RunArtifact | None = None
    final_spec: AgentSpec | None = None
    aggregate_tool_calls: list[dict[str, Any]] = []
    aggregate_evidence_records: list[dict[str, Any]] = []
    aggregate_trace_events: list[dict[str, Any]] = []
    aggregate_errors: list[str] = []
    aggregate_prompt_keys: set[str] = set()
    aggregate_skills: set[str] = set()
    aggregate_plugins: set[str] = set()
    aggregate_mcps: set[str] = set()
    aggregate_token_usage: dict[str, int] = {}
    aggregate_cost = 0.0
    aggregate_latency_ms = 0
    aggregate_step_count = 0
    aggregate_updates: dict[str, Any] = {}

    for index, agent_id in enumerate(chain_agent_ids):
        spec = load_model(control_dir(project_root) / "agents" / f"{agent_id}.yaml", AgentSpec)
        final_spec = spec
        if index == 0:
            nested_case = step_case
        else:
            chain_context = _build_chain_context(chain_steps, step_case.input, step_case.id).model_copy(
                update={"shared_context": dict(local_shared_context)}
            )
            handoff = _build_handoff(
                node.chain_handoff_template or "{prior_output}",
                prior_output=prior_output,
                prior_artifact=prior_artifact_summary,
                original_input=step_case.input,
                case_id=step_case.id,
                step_idx=index,
                chain_context=chain_context,
                shared_context=local_shared_context,
            )
            accumulated_turns = _accumulate_turns(accumulated_turns, prior_output, handoff)
            nested_case = step_case.model_copy(
                update={
                    "input": handoff,
                    "turns": accumulated_turns,
                    "metadata": {
                        **(step_case.metadata or {}),
                        "chain_context": chain_context.model_dump(mode="json"),
                        "shared_context": dict(local_shared_context),
                    },
                }
            )
        nested_dir = ensure_dir(case_dir / f"chain-{index}-{agent_id}")
        artifact = _invoke_agent_artifact(project_root, spec, nested_case, nested_dir)
        final_artifact = artifact
        prior_output = _artifact_output(artifact)
        prior_artifact_summary = _artifact_summary(artifact)
        chain_steps.append(
            {
                "step": index,
                "agent_id": agent_id,
                "final_output_preview": prior_output[:200],
                "latency_ms": artifact.latency_ms,
                "errors": artifact.errors or [],
                "artifact_summary": prior_artifact_summary,
            }
        )
        local_shared_context = _merge_shared_context(local_shared_context, _shared_context_updates(artifact))
        aggregate_updates = _merge_shared_context(aggregate_updates, _shared_context_updates(artifact))
        aggregate_tool_calls.extend(artifact.tool_calls or [])
        aggregate_evidence_records.extend(artifact.evidence_records or [])
        aggregate_trace_events.extend(artifact.trace_events or [])
        aggregate_errors.extend(artifact.errors or [])
        aggregate_prompt_keys.update(str(item) for item in artifact.prompt_keys_used or [])
        aggregate_skills.update(str(item) for item in artifact.skills_used or [])
        aggregate_plugins.update(str(item) for item in artifact.plugins_used or [])
        aggregate_mcps.update(str(item) for item in artifact.mcp_servers_used or [])
        aggregate_token_usage = _sum_token_usage(aggregate_token_usage, artifact.token_usage or {})
        aggregate_cost += float(artifact.cost_estimate or 0.0)
        aggregate_latency_ms += int(artifact.latency_ms or 0)
        aggregate_step_count += int(artifact.step_count or 0)

    assert final_artifact is not None and final_spec is not None

    structured_output = dict(final_artifact.structured_output or {})
    if aggregate_updates:
        structured_output["shared_context_updates"] = aggregate_updates
    metadata = dict(final_artifact.metadata or {})
    metadata["nested_chain"] = {
        "node_id": str(getattr(node, "id", "") or ""),
        "agent_ids": chain_agent_ids,
        "step_count": len(chain_steps),
        "shared_context_after": dict(local_shared_context),
        "steps": chain_steps,
    }
    workflow_trace = [f"chain_agent:{agent_id}" for agent_id in chain_agent_ids]
    workflow_trace.extend(str(item) for item in final_artifact.workflow_trace or [])
    return (
        final_artifact.model_copy(
            update={
                "structured_output": structured_output,
                "metadata": metadata,
                "tool_calls": aggregate_tool_calls,
                "evidence_records": aggregate_evidence_records,
                "trace_events": aggregate_trace_events,
                "workflow_trace": workflow_trace,
                "skills_used": sorted(aggregate_skills),
                "plugins_used": sorted(aggregate_plugins),
                "mcp_servers_used": sorted(aggregate_mcps),
                "prompt_keys_used": sorted(aggregate_prompt_keys),
                "step_count": aggregate_step_count,
                "latency_ms": aggregate_latency_ms,
                "token_usage": aggregate_token_usage,
                "cost_estimate": round(aggregate_cost, 6),
                "errors": aggregate_errors,
            }
        ),
        final_spec,
    )


def _compute_workflow_aggregate(
    workflow_steps: list[dict[str, Any]],
    step_scores: list[StepScore],
) -> WorkflowAggregate:
    total_latency = sum(int(step.get("latency_ms", 0) or 0) for step in workflow_steps)
    degrading: list[str] = []
    for index in range(1, len(step_scores)):
        if step_scores[index].score < step_scores[index - 1].score:
            degrading.append(str(workflow_steps[index].get("node_id") or step_scores[index].agent_id))
    route_decisions: list[dict[str, Any]] = []
    fan_out_count = 0
    join_count = 0
    dead_end_count = 0
    visit_counts: dict[str, int] = {}
    shared_context_keys: set[str] = set()
    for step in workflow_steps:
        selected_edges = step.get("selected_edges") or []
        if selected_edges:
            route_decisions.extend(item for item in selected_edges if item)
        else:
            selected_edge = step.get("selected_edge")
            if isinstance(selected_edge, dict):
                route_decisions.append(selected_edge)
        if len(selected_edges) > 1:
            fan_out_count += 1
        if int(step.get("join_arrival_count", 1) or 1) > 1:
            join_count += 1
        if step.get("route_unmatched"):
            dead_end_count += 1
        node_id = str(step.get("node_id") or "")
        if node_id:
            visit_counts[node_id] = visit_counts.get(node_id, 0) + 1
        for key in step.get("shared_context_after_keys") or []:
            if str(key).strip():
                shared_context_keys.add(str(key))
    unmatched_routes = [
        {
            "step": step.get("step"),
            "node_id": step.get("node_id"),
            "route": step.get("route"),
            "matched_edges": step.get("matched_edges", []),
        }
        for step in workflow_steps
        if step.get("route_unmatched")
    ]
    executed_nodes = [str(step.get("node_id") or "") for step in workflow_steps]
    return WorkflowAggregate(
        step_pass_rate=round(sum(1 for score in step_scores if score.passed) / len(step_scores), 3)
        if step_scores
        else 0.0,
        node_scores={
            str(step.get("node_id") or score.agent_id): score.score
            for step, score in zip(workflow_steps, step_scores, strict=False)
        },
        degrading_nodes=degrading,
        total_workflow_latency_ms=total_latency,
        executed_nodes=executed_nodes,
        terminal_node=executed_nodes[-1] if executed_nodes else None,
        path_signature=" -> ".join(executed_nodes),
        route_decisions=[item for item in route_decisions if item],
        unmatched_routes=unmatched_routes,
        fan_out_count=fan_out_count,
        join_count=join_count,
        dead_end_count=dead_end_count,
        loop_detected=any(count > 1 for count in visit_counts.values()),
        duplicate_node_visits=sorted(node_id for node_id, count in visit_counts.items() if count > 1),
        shared_context_keys=sorted(shared_context_keys),
    )


def _aggregate_workflow_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary = aggregate_workflow_rows(rows)
    return {
        "average_workflow_step_pass_rate": summary["average_step_pass_rate"],
        "average_workflow_latency_ms": summary["average_latency_ms"],
        "average_workflow_node_scores": summary["average_node_scores"],
        "workflow_path_counts": summary["path_counts"],
        "workflow_terminal_node_counts": summary["terminal_node_counts"],
        "workflow_route_counts": summary["route_counts"],
        "workflow_unmatched_route_count": summary["unmatched_route_count"],
        "workflow_fan_out_count": summary["fan_out_count"],
        "workflow_join_count": summary["join_count"],
        "workflow_dead_end_count": summary["dead_end_count"],
        "workflow_loop_case_count": summary["loop_case_count"],
        "workflow_duplicate_node_counts": summary["duplicate_node_counts"],
        "workflow_shared_context_keys": summary["shared_context_keys"],
        "total_cases": summary["case_count"] or len(rows),
    }


def run_workflow_experiment(
    project_root: Path,
    workflow_file: str | Path,
    eval_id: str,
    subset: str,
    *,
    case_ids: list[str] | None = None,
    tags: list[str] | None = None,
    match: str | None = None,
    limit: int | None = None,
    workflow_handoff_template: str = "{prior_output}",
) -> tuple[ExperimentRecord, dict[str, Any]]:
    workflow, workflow_path = _load_workflow_spec(project_root, workflow_file)
    if len(workflow.nodes) < 2:
        raise ValueError("Workflow requires at least two nodes.")

    config = load_config(project_root)
    experiment_id = f"{workflow.id}-{eval_id}-{subset}-{utc_timestamp_slug()}"
    exp_dir = experiment_dir(project_root, experiment_id)
    cases = load_eval_cases(
        project_root,
        eval_id,
        subset,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    node_spec_sets = {node.id: _load_node_specs(project_root, node) for node in workflow.nodes}
    flattened_specs = [spec for specs in node_spec_sets.values() for spec in specs]
    workflow_spec = _workflow_surface_spec(workflow, flattened_specs, workflow_path)
    spec_snapshot = _workflow_spec_snapshot(project_root, workflow, flattened_specs, workflow_path)
    surface_snapshot = capture_surface_snapshot(project_root, workflow_spec)
    selection = build_case_selection(
        cases,
        case_ids=case_ids,
        tags=tags,
        match=match,
        limit=limit,
    )
    before_snapshot = capture_snapshot(project_root, config.snapshot_mode)
    before_benchmarks = compute_benchmark_hashes(project_root)
    write_json(
        exp_dir / RUN_CONTEXT_FILENAME,
        build_run_context(
            agent_id=workflow.id,
            eval_id=eval_id,
            subset=subset,
            selection=selection,
            spec_snapshot=spec_snapshot,
            surface_snapshot=surface_snapshot,
            repo_before=before_snapshot,
            benchmark_hashes_before=before_benchmarks,
            extra={
                "workflow_id": workflow.id,
                "workflow_file": workflow_path,
                "workflow_nodes": [
                    {
                        "id": node.id,
                        "node_type": node.node_type,
                        "agent_id": node.agent_id,
                        "chain_agent_ids": _node_agent_ids(node),
                    }
                    for node in workflow.nodes
                ],
                "run_kind": "workflow",
            },
        ),
    )
    persist_run_artifacts(
        exp_dir,
        spec_snapshot=spec_snapshot,
        selection=selection,
        surface_snapshot=surface_snapshot,
    )

    scoring_ctx = load_scoring_context(project_root, eval_id)
    nodes_by_id = {node.id: node for node in workflow.nodes}
    edges_by_from: dict[str, list[WorkflowEdgeConfig]] = {}
    for edge in workflow.edges:
        edges_by_from.setdefault(edge.from_node, []).append(edge)
    incoming_nodes = _incoming_nodes_by_target(workflow)

    rows: list[dict[str, Any]] = []

    for case in cases:
        workflow_steps: list[dict[str, Any]] = []
        step_scores: list[StepScore] = []
        terminal_artifacts: list[dict[str, Any]] = []
        final_artifact: Any = None
        final_spec: AgentSpec | None = None
        shared_context: dict[str, Any] = {}
        pending: list[dict[str, Any]] = [
            {
                "node_id": workflow.start_at,
                "from_node": None,
                "incoming_edge": None,
                "prior_output": "",
                "prior_artifact_summary": {},
                "turns": list(case.turns) if case.turns else [],
                "path_nodes": [],
            }
        ]
        pending_joins: dict[str, list[dict[str, Any]]] = {}
        visit_counts: dict[str, int] = {}
        exceeded_max_steps = False

        while pending and len(workflow_steps) < int(workflow.max_steps_per_case):
            arrival = pending.pop(0)
            node = nodes_by_id[str(arrival.get("node_id") or workflow.start_at)]
            queued_arrivals = [arrival]
            if node.join_mode != "none" and incoming_nodes.get(node.id):
                bucket = pending_joins.setdefault(node.id, [])
                bucket.append(arrival)
                if node.join_mode == "all":
                    required_sources = {str(item) for item in incoming_nodes.get(node.id, set()) if str(item).strip()}
                    arrived_sources = {
                        str(item.get("from_node") or "") for item in bucket if str(item.get("from_node") or "").strip()
                    }
                    if required_sources and not required_sources.issubset(arrived_sources):
                        continue
                    queued_arrivals = list(bucket)
                    pending_joins[node.id] = []
                else:
                    queued_arrivals = [bucket.pop(0)]

            node_label = _node_runtime_label(node)
            visit_counts[node.id] = visit_counts.get(node.id, 0) + 1
            if node.max_visits is not None and visit_counts[node.id] > int(node.max_visits):
                workflow_steps.append(
                    {
                        "node_id": node.id,
                        "agent_id": node_label,
                        "node_type": node.node_type,
                        "step": len(workflow_steps),
                        "from_node": queued_arrivals[0].get("from_node"),
                        "incoming_edge": queued_arrivals[0].get("incoming_edge"),
                        "errors": [f"node `{node.id}` exceeded max_visits={node.max_visits}"],
                        "route_unmatched": True,
                        "matched_edges": [],
                        "selected_edge": None,
                        "selected_edges": [],
                        "route": "",
                        "join_arrival_count": len(queued_arrivals),
                        "shared_context_before_keys": sorted(shared_context),
                        "shared_context_after_keys": sorted(shared_context),
                        "visit_index": visit_counts[node.id],
                    }
                )
                break

            merged_prior_output = _merge_arrival_outputs(queued_arrivals)
            merged_prior_artifact_summary = _merge_artifact_summaries(queued_arrivals)
            base_turns = _merge_turns(queued_arrivals, list(case.turns) if case.turns else [])
            current_step = len(workflow_steps)

            if (
                current_step == 0
                and node.id == workflow.start_at
                and not str(queued_arrivals[0].get("from_node") or "").strip()
                and not merged_prior_output
            ):
                step_case = case
            else:
                workflow_ctx = _build_chain_context(workflow_steps, case.input, case.id).model_copy(
                    update={"shared_context": dict(shared_context)}
                )
                handoff = _build_handoff(
                    node.handoff_template or workflow_handoff_template,
                    prior_output=merged_prior_output,
                    prior_artifact=merged_prior_artifact_summary,
                    original_input=case.input,
                    case_id=case.id,
                    step_idx=current_step,
                    chain_context=workflow_ctx,
                    shared_context=shared_context,
                )
                new_turns = _accumulate_turns(base_turns, merged_prior_output, handoff)
                step_case = case.model_copy(
                    update={
                        "input": handoff,
                        "turns": new_turns,
                        "metadata": {
                            **(case.metadata or {}),
                            "chain_context": workflow_ctx.model_dump(mode="json"),
                            "workflow_context": workflow_ctx.model_dump(mode="json"),
                            "shared_context": dict(shared_context),
                        },
                    }
                )

            case_dir = ensure_dir(exp_dir / case.id / f"workflow-{current_step}-{node.id}")
            if str(node.node_type) == "chain":
                artifact, final_spec = _invoke_chain_node(
                    project_root,
                    node,
                    step_case,
                    case_dir,
                    shared_context=shared_context,
                )
            else:
                spec = node_spec_sets[node.id][-1]
                artifact = _invoke_agent_artifact(project_root, spec, step_case, case_dir)
                final_spec = spec
            scores, passed, score = _score_step(
                project_root,
                eval_id,
                artifact,
                case,
                scoring_ctx,
                step_expectations=node.step_expectations or None,
            )
            final_output = _artifact_output(artifact)
            route = _derive_route(final_output, artifact)
            structured_output = _structured_payload(artifact)
            artifact_payload: dict[str, Any] = (
                artifact.model_dump(mode="json") if hasattr(artifact, "model_dump") else dict(artifact)
            )
            tool_call_list = tool_call_names(artifact_payload)
            route_context = {
                "route": route,
                "final_output": final_output,
                "structured_output": structured_output,
                "tool_call_names": tool_call_list,
                "score": score,
                "passed": passed,
                "errors": artifact.errors or [],
                "metadata": artifact.metadata or {},
            }
            selected_edge, matched_edges = _select_next_edge(
                edges_by_from.get(node.id, []), route_context=route_context
            )
            selected_edges = _selected_edges_for_node(node, selected_edge, matched_edges)
            shared_context_before = dict(shared_context)
            shared_context = _merge_shared_context(shared_context, _shared_context_updates(artifact))

            artifact_summary = _artifact_summary(artifact)
            step_score = StepScore(
                agent_id=node_label,
                step=current_step,
                scores=scores,
                passed=passed,
                score=score,
                final_output_preview=final_output[:200],
                latency_ms=artifact.latency_ms,
                errors=artifact.errors or [],
            )
            step_score_payload = step_score.model_dump(mode="json")
            step_score_payload["node_id"] = node.id
            step_scores.append(step_score)

            workflow_steps.append(
                {
                    "node_id": node.id,
                    "agent_id": node_label,
                    "node_type": node.node_type,
                    "step": current_step,
                    "from_node": queued_arrivals[0].get("from_node"),
                    "incoming_edge": queued_arrivals[0].get("incoming_edge"),
                    "final_output_preview": final_output[:200],
                    "latency_ms": artifact.latency_ms,
                    "errors": artifact.errors or [],
                    "route": route,
                    "tool_call_names": tool_call_list,
                    "step_score": step_score_payload,
                    "artifact_summary": artifact_summary,
                    "matched_edges": [_edge_summary(edge) for edge in matched_edges],
                    "selected_edge": _edge_summary(selected_edges[0]) if selected_edges else None,
                    "selected_edges": [_edge_summary(edge) for edge in selected_edges],
                    "route_unmatched": bool(edges_by_from.get(node.id)) and not selected_edges,
                    "join_arrival_count": len(queued_arrivals),
                    "shared_context_before_keys": sorted(shared_context_before),
                    "shared_context_after_keys": sorted(shared_context),
                    "visit_index": visit_counts[node.id],
                }
            )
            final_artifact = artifact

            child_turns = list(step_case.turns) if step_case.turns else base_turns
            child_path = [*list(queued_arrivals[0].get("path_nodes") or []), node.id]
            if selected_edges:
                for edge in selected_edges:
                    pending.append(
                        {
                            "node_id": edge.to_node,
                            "from_node": node.id,
                            "incoming_edge": _edge_summary(edge),
                            "prior_output": final_output,
                            "prior_artifact_summary": artifact_summary,
                            "turns": child_turns,
                            "path_nodes": child_path,
                        }
                    )
            else:
                terminal_artifacts.append(
                    {
                        "node_id": node.id,
                        "artifact": artifact,
                        "scores": scores,
                        "passed": passed,
                        "score": score,
                    }
                )
        else:
            if pending:
                exceeded_max_steps = True

        if exceeded_max_steps:
            blocked_node = nodes_by_id[str((pending[0] if pending else {}).get("node_id") or workflow.start_at)]
            workflow_steps.append(
                {
                    "node_id": str((pending[0] if pending else {}).get("node_id") or workflow.start_at),
                    "agent_id": _node_runtime_label(blocked_node),
                    "node_type": blocked_node.node_type,
                    "step": int(workflow.max_steps_per_case),
                    "errors": [f"workflow exceeded max_steps_per_case={workflow.max_steps_per_case}"],
                    "route_unmatched": True,
                    "matched_edges": [],
                    "selected_edge": None,
                    "selected_edges": [],
                    "route": "",
                    "join_arrival_count": 1,
                    "shared_context_before_keys": sorted(shared_context),
                    "shared_context_after_keys": sorted(shared_context),
                }
            )
        if pending_joins and not pending and not exceeded_max_steps:
            for node_id, bucket in sorted(pending_joins.items()):
                if not bucket:
                    continue
                workflow_steps.append(
                    {
                        "node_id": node_id,
                        "agent_id": _node_runtime_label(nodes_by_id[node_id]),
                        "node_type": nodes_by_id[node_id].node_type,
                        "step": len(workflow_steps),
                        "from_node": bucket[0].get("from_node"),
                        "incoming_edge": bucket[0].get("incoming_edge"),
                        "errors": [f"join node `{node_id}` did not receive all required inputs"],
                        "route_unmatched": True,
                        "matched_edges": [],
                        "selected_edge": None,
                        "selected_edges": [],
                        "route": "",
                        "join_arrival_count": len(bucket),
                        "shared_context_before_keys": sorted(shared_context),
                        "shared_context_after_keys": sorted(shared_context),
                    }
                )

        assert final_artifact is not None and final_spec is not None

        if len(terminal_artifacts) > 1:
            branch_payload = [
                {
                    "node_id": item.get("node_id"),
                    "final_output": str(item["artifact"].final_output or ""),
                }
                for item in terminal_artifacts
                if isinstance(item.get("artifact"), RunArtifact)
            ]
            combined_output = "\n\n".join(
                f"[{item.get('node_id')}] {str(item.get('final_output') or '').strip()}"
                for item in branch_payload
                if str(item.get("final_output") or "").strip()
            )
            final_artifact = terminal_artifacts[-1]["artifact"].model_copy(
                update={
                    "final_output": combined_output or final_artifact.final_output,
                    "structured_output": {
                        **dict(final_artifact.structured_output or {}),
                        "branch_terminal_outputs": branch_payload,
                    },
                }
            )
            final_scores, final_passed, final_score = _score_step(
                project_root,
                eval_id,
                final_artifact,
                case,
                scoring_ctx,
            )
        else:
            final_step_score = step_scores[-1] if step_scores else None
            final_scores = final_step_score.scores if final_step_score else []
            final_passed = final_step_score.passed if final_step_score else False
            final_score = final_step_score.score if final_step_score else 0.0

        workflow_agg = _compute_workflow_aggregate(workflow_steps, step_scores)
        meta = dict(final_artifact.metadata or {})
        meta["workflow_id"] = workflow.id
        meta["workflow_file"] = workflow_path
        meta["workflow_steps"] = workflow_steps
        meta["workflow_nodes"] = [
            {
                "id": node.id,
                "node_type": node.node_type,
                "agent_id": node.agent_id,
                "chain_agent_ids": _node_agent_ids(node),
            }
            for node in workflow.nodes
        ]
        meta["workflow_edges"] = [_edge_summary(edge) for edge in workflow.edges]
        meta["workflow_aggregate"] = workflow_agg.model_dump(mode="json")
        meta["workflow_shared_context"] = dict(shared_context)
        meta["step_scores"] = [
            {
                **score.model_dump(mode="json"),
                "node_id": workflow_steps[index]["node_id"],
            }
            for index, score in enumerate(step_scores)
        ]
        if terminal_artifacts:
            meta["workflow_terminal_outputs"] = [
                {
                    "node_id": item.get("node_id"),
                    "final_output_preview": str(item["artifact"].final_output or "")[:200],
                }
                for item in terminal_artifacts
                if isinstance(item.get("artifact"), RunArtifact)
            ]
        workflow_trace = [f"workflow_node:{step['node_id']}" for step in workflow_steps if step.get("node_id")]
        workflow_trace.extend(str(item) for item in final_artifact.workflow_trace or [])
        final_artifact = final_artifact.model_copy(update={"metadata": meta, "workflow_trace": workflow_trace})

        rows.append(
            {
                "case": case.model_dump(mode="json"),
                "artifact": final_artifact.model_dump(mode="json"),
                "scores": final_scores,
                "passed": final_passed,
                "score": final_score,
            }
        )

    finalized = finalize_run(
        project_root,
        rows=rows,
        spec_snapshot=spec_snapshot,
        before_snapshot=before_snapshot,
        before_benchmarks=before_benchmarks,
        snapshot_mode=config.snapshot_mode,
        selection_fingerprint=selection["selection_fingerprint"],
        signature_extra={"workflow": workflow.id},
    )
    aggregate = finalized.aggregate
    behavior_summary = finalized.behavior_summary
    aggregate["workflow_aggregate"] = _aggregate_workflow_metrics(rows)
    record = ExperimentRecord(
        experiment_id=experiment_id,
        parent_experiment_id=None,
        series_id=None,
        agent_id=workflow.id,
        eval_id=eval_id,
        subset=subset,
        created_at=created_at_utc(),
        benchmark_signature=finalized.benchmark_signature,
        spec_snapshot=spec_snapshot,
        repo_before=before_snapshot,
        repo_after=finalized.after_snapshot,
        changed_files=finalized.changed_files,
        benchmark_hashes=finalized.after_benchmarks,
        benchmark_manifest=finalized.after_manifest,
        case_selection=selection,
        selection_fingerprint=selection["selection_fingerprint"],
        selected_case_ids=selection["selected_case_ids"],
        completed_case_ids=[case.id for case in cases],
        total_case_count=len(cases),
        surface_snapshot=surface_snapshot,
        scores=aggregate,
        behavior_summary=behavior_summary,
        status="completed",
        promotion_status="candidate",
    )
    write_json(exp_dir / "experiment.json", record.model_dump(mode="json"))
    write_json(exp_dir / "aggregate.json", aggregate)
    write_json(exp_dir / "behavior.json", behavior_summary)
    write_jsonl(exp_dir / "runs.jsonl", rows)

    failed_cases = failed_cases_for_experiment(project_root, experiment_id)
    write_report(exp_dir / "report.md", render_experiment_report(record, aggregate, failed_cases))
    write_report(exp_dir / "repo.diff", finalized.diff_text)
    return record, aggregate


__all__ = ["run_workflow_experiment"]
