from __future__ import annotations

from typing import Any

from agentworkbench.evidence import evidence_record_label
from agentworkbench.tracing import trace_event_label

_WORKFLOW_TRACE_KINDS = {
    "decision",
    "mcp",
    "memory_lookup",
    "planning",
    "plugin",
    "prompt",
    "prompt_load",
    "provider_request",
    "provider_response",
    "runtime",
    "skill",
    "startup",
    "tool",
    "tool_call",
}


def preview_text(value: Any, limit: int = 160) -> str:
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    return f"{text[: max(0, limit - 3)]}..."


def format_tool_call(call: dict[str, Any]) -> str:
    name = str(call.get("name") or call.get("tool") or call.get("id") or "unknown")
    extras = []
    for key, value in sorted(call.items()):
        if key in {"name", "tool", "id"}:
            continue
        if isinstance(value, (bool, float, int, str)):
            extras.append(f"{key}={value}")
    if not extras:
        return name
    return f"{name}({', '.join(extras)})"


def format_evidence_record(record: dict[str, Any]) -> str:
    label = evidence_record_label(record)
    hits = int(record.get("hit_count", 0) or 0)
    selected = int(record.get("selected_count", 0) or 0)
    used = int(record.get("used_count", 0) or 0)
    status = str(record.get("status") or "unknown")
    parts = [f"hits={hits}", f"selected={selected}", f"used={used}", f"status={status}"]
    if record.get("mcp"):
        parts.append(f"mcp={record['mcp']}")
    hit_summaries = [
        preview_text((hit or {}).get("snippet") or "", 80)
        for hit in record.get("hits", [])[:2]
        if str((hit or {}).get("snippet") or "").strip()
    ]
    if hit_summaries:
        parts.append(f"snippets={' | '.join(hit_summaries)}")
    return f"{label}({', '.join(parts)})"


def compact_metadata(value: dict[str, Any]) -> dict[str, Any]:
    compact: dict[str, Any] = {}
    for key, item in value.items():
        if isinstance(item, (bool, float, int, str)):
            compact[str(key)] = item
            continue
        if isinstance(item, list):
            compact[str(key)] = [preview_text(entry, 60) for entry in item[:5]]
            continue
        if isinstance(item, dict):
            nested = {
                str(nested_key): nested_value
                for nested_key, nested_value in item.items()
                if isinstance(nested_value, (bool, float, int, str))
            }
            if nested:
                compact[str(key)] = nested
    return compact


def compact_grounding_provenance(value: dict[str, Any]) -> dict[str, Any]:
    if not value:
        return {}
    return {
        "enabled": bool(value.get("enabled")),
        "require_selected_evidence": bool(value.get("require_selected_evidence")),
        "selected_evidence_count": int(value.get("selected_evidence_count", 0) or 0),
        "grounding_terms": [str(item) for item in value.get("grounding_terms", [])[:8]],
        "grounded_terms": [str(item) for item in value.get("grounded_terms", [])[:8]],
        "unsupported_terms": [str(item) for item in value.get("unsupported_terms", [])[:8]],
        "missing_output_terms": [str(item) for item in value.get("missing_output_terms", [])[:8]],
        "ungrounded_output_terms": [str(item) for item in value.get("ungrounded_output_terms", [])[:8]],
        "selected_source_labels": [str(item) for item in value.get("selected_source_labels", [])[:8]],
        "grounded_source_labels": [str(item) for item in value.get("grounded_source_labels", [])[:8]],
        "used_source_labels": [str(item) for item in value.get("used_source_labels", [])[:8]],
        "term_matches": [
            {
                "term": str(item.get("term") or ""),
                "output_present": bool(item.get("output_present")),
                "supported_by_selected_evidence": bool(item.get("supported_by_selected_evidence")),
                "supporting_source_labels": [str(label) for label in (item.get("supporting_source_labels") or [])[:6]],
                "used_source_labels": [str(label) for label in (item.get("used_source_labels") or [])[:6]],
            }
            for item in value.get("term_matches", [])[:8]
        ],
    }


def list_delta(baseline: list[str], candidate: list[str]) -> tuple[list[str], list[str]]:
    before = set(baseline)
    after = set(candidate)
    return sorted(after - before), sorted(before - after)


def count_deltas(baseline: dict[str, int], candidate: dict[str, int]) -> dict[str, int]:
    keys = sorted(set(baseline) | set(candidate))
    deltas: dict[str, int] = {}
    for key in keys:
        delta = int(candidate.get(key, 0)) - int(baseline.get(key, 0))
        if delta:
            deltas[key] = delta
    return deltas


def float_dict_deltas(baseline: dict[str, float], candidate: dict[str, float]) -> dict[str, float]:
    keys = sorted(set(baseline) | set(candidate))
    deltas: dict[str, float] = {}
    for key in keys:
        delta = round(float(candidate.get(key, 0.0)) - float(baseline.get(key, 0.0)), 3)
        if delta:
            deltas[key] = delta
    return deltas


def surface_audit_deltas(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    keys = sorted(set(baseline) | set(candidate))
    deltas: dict[str, Any] = {}
    for key in keys:
        before = baseline.get(key) or {}
        after = candidate.get(key) or {}
        deltas[key] = {
            "coverage_delta": round(float(after.get("coverage") or 0.0) - float(before.get("coverage") or 0.0), 3),
            "unused_added": sorted(set(after.get("unused") or []) - set(before.get("unused") or [])),
            "unused_removed": sorted(set(before.get("unused") or []) - set(after.get("unused") or [])),
            "used_not_declared_added": sorted(
                set(after.get("used_not_declared") or []) - set(before.get("used_not_declared") or [])
            ),
            "used_not_declared_removed": sorted(
                set(before.get("used_not_declared") or []) - set(after.get("used_not_declared") or [])
            ),
        }
    return deltas


def ordered_unique(values: list[str]) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        ordered.append(text)
    return ordered


def ordered_union(existing: list[str], inferred: list[str]) -> list[str]:
    return ordered_unique([*existing, *inferred])


def declared_names(spec_snapshot: dict[str, Any], key: str) -> set[str]:
    return {str(item) for item in spec_snapshot.get(key, []) if str(item).strip()}


def parse_step(step: Any) -> tuple[str, str] | None:
    text = str(step or "").strip()
    if not text or ":" not in text:
        return None
    kind, name = text.split(":", 1)
    kind = kind.strip()
    name = name.strip()
    if not kind or not name:
        return None
    return kind, name


def normalize_tool_call(call: Any) -> dict[str, Any] | None:
    if not isinstance(call, dict):
        return None
    name = str(call.get("name") or call.get("tool") or call.get("id") or "").strip()
    if not name:
        return None
    normalized: dict[str, Any] = {"name": name}
    for key, value in call.items():
        if key in {"name", "tool"}:
            continue
        if isinstance(value, (bool, float, int, str)):
            normalized[str(key)] = value
    return normalized


def infer_from_events(
    events: list[Any],
    *,
    declared_tools: set[str],
    declared_mcps: set[str],
) -> tuple[list[str], list[str], list[str], list[str], list[str], list[dict[str, Any]], dict[str, Any]]:
    prompts: list[str] = []
    skills: list[str] = []
    plugins: list[str] = []
    mcps: list[str] = []
    workflow: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    metadata: dict[str, Any] = {}
    saw_prompt_event = False
    for raw in events:
        if not isinstance(raw, dict):
            continue
        kind = str(raw.get("kind") or raw.get("type") or raw.get("category") or "").strip()
        name = str(raw.get("name") or raw.get("label") or raw.get("step") or "").strip()
        mcp_name = str(raw.get("mcp") or "").strip()
        status = str(raw.get("status") or "").strip().lower()
        is_skipped = status == "skipped"
        if kind in {"prompt", "prompt_load"} and name:
            prompts.append(name)
            saw_prompt_event = True
        if kind == "skill" and name:
            skills.append(name)
        if kind == "plugin" and name:
            plugins.append(name)
        if not is_skipped and kind in {"mcp", "memory_lookup"} and name and name in declared_mcps:
            mcps.append(name)
        if mcp_name and not is_skipped:
            mcps.append(mcp_name)
        if not is_skipped and kind in {"retrieval", "tool", "tool_call"} and name:
            if declared_tools and name not in declared_tools:
                pass
            else:
                inferred = normalize_tool_call(raw)
                if inferred is not None:
                    if "status" not in inferred:
                        inferred["status"] = "inferred"
                    tool_calls.append(inferred)
        if kind in {"provider_request", "provider_response"}:
            provider_name = str(raw.get("provider") or "").strip()
            model_name = str(raw.get("model_name") or "").strip()
            if provider_name and "provider" not in metadata:
                metadata["provider"] = provider_name
            if model_name and "model_name" not in metadata:
                metadata["model_name"] = model_name
        if kind in _WORKFLOW_TRACE_KINDS and not (
            is_skipped and kind in {"mcp", "memory_lookup", "tool", "tool_call"}
        ):
            if kind == "tool_call" and name:
                workflow.append(f"tool:{name}")
            elif name and ":" not in name:
                workflow.append(f"{kind}:{name}")
            elif name:
                workflow.append(name)
    if saw_prompt_event and not prompts:
        prompts.append("system")
    if declared_mcps:
        mcps = [m for m in mcps if m in declared_mcps]
    return prompts, skills, plugins, mcps, workflow, tool_calls, metadata


def infer_from_evidence(
    evidence_records: list[Any],
    *,
    declared_tools: set[str],
) -> tuple[list[str], list[dict[str, Any]]]:
    mcps: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    for record in evidence_records:
        if not isinstance(record, dict):
            continue
        status = str(record.get("status") or "").strip().lower()
        if status == "skipped":
            continue
        mcp_name = str(record.get("mcp") or "").strip()
        if mcp_name:
            mcps.append(mcp_name)
        kind = str(record.get("kind") or "").strip()
        name = str(record.get("name") or "").strip()
        if not name:
            continue
        if declared_tools and name not in declared_tools and kind not in {"retrieval", "tool"}:
            continue
        if kind in {"retrieval", "tool"} or name in declared_tools:
            tool_calls.append(
                {
                    "name": name,
                    "status": str(record.get("status") or "inferred"),
                    "hits": int(record.get("hit_count", 0) or 0),
                    "selected": bool(int(record.get("selected_count", 0) or 0) > 0),
                }
            )
    return mcps, tool_calls


def surface_inference_from_trace(
    trace_events: list[Any],
) -> tuple[list[str], list[str], list[str], list[str], list[str]]:
    prompts: list[str] = []
    skills: list[str] = []
    plugins: list[str] = []
    mcps: list[str] = []
    workflow: list[str] = []
    for event in trace_events:
        if not isinstance(event, dict):
            continue
        kind = str(event.get("kind") or "").strip()
        name = str(event.get("name") or "").strip()
        status = str((event.get("data") or {}).get("status") or "").strip().lower()
        is_skipped = status == "skipped"
        if kind == "prompt" and name:
            prompts.append(name)
        elif kind == "skill" and name:
            skills.append(name)
        elif kind == "plugin" and name:
            plugins.append(name)
        elif kind == "mcp" and name and not is_skipped:
            mcps.append(name)
        if kind in _WORKFLOW_TRACE_KINDS and not (
            is_skipped and kind in {"mcp", "memory_lookup", "tool", "tool_call"}
        ):
            label = trace_event_label(event)
            if label:
                if kind == "tool_call" and name:
                    workflow.append(f"tool:{name}")
                else:
                    workflow.append(label)
    return prompts, skills, plugins, mcps, workflow


__all__ = [
    "preview_text",
    "format_tool_call",
    "format_evidence_record",
    "compact_metadata",
    "compact_grounding_provenance",
    "list_delta",
    "count_deltas",
    "float_dict_deltas",
    "surface_audit_deltas",
    "ordered_unique",
    "ordered_union",
    "declared_names",
    "parse_step",
    "normalize_tool_call",
    "infer_from_events",
    "infer_from_evidence",
    "surface_inference_from_trace",
]
