from __future__ import annotations

from agentworkbench.audits import (
    aggregate_surface_audits,
    aggregate_surface_contract_audits,
    run_surface_contract_audits,
)


def test_surface_contract_audits_ignore_skipped_disabled_events() -> None:
    artifact = {
        "events": [
            {"kind": "retrieval", "name": "lookup", "status": "skipped", "mcp": "memory", "reason": "tool_disabled"},
            {"kind": "memory_lookup", "name": "customer_memory", "status": "skipped", "mcp": "memory", "reason": "mcp_disabled"},
        ],
        "tool_calls": [],
        "workflow_trace": [],
        "mcp_servers_used": [],
    }
    audit = run_surface_contract_audits(
        artifact,
        {
            "tool_names": [],
            "mcp_names": [],
        },
    )
    assert audit["tool_used_not_enabled"] == []
    assert audit["mcp_used_not_enabled"] == []
    assert audit["mcp_referenced_not_listed"] == []
    assert audit["mcp_listed_not_referenced"] == []
    assert audit["violation_count"] == 0


def test_surface_contract_audits_flag_disabled_and_unlisted_usage() -> None:
    artifact = {
        "events": [
            {"kind": "retrieval", "name": "lookup", "hits": 1, "selected": True, "status": "success", "mcp": "memory"},
        ],
        "tool_calls": [
            {"name": "lookup", "hits": 1, "selected": True, "status": "success", "mcp": "memory"},
        ],
        "workflow_trace": ["tool:lookup", "mcp:memory"],
        "mcp_servers_used": [],
    }
    audit = run_surface_contract_audits(
        artifact,
        {
            "tool_names": [],
            "mcp_names": [],
        },
    )
    assert audit["tool_used_not_enabled"] == ["lookup"]
    assert audit["mcp_used_not_enabled"] == ["memory"]
    assert audit["mcp_referenced_not_listed"] == ["memory"]
    assert audit["mcp_listed_not_referenced"] == []
    assert audit["violations"] == [
        "mcp:memory:referenced_not_listed",
        "mcp:memory:used_not_enabled",
        "tool:lookup:used_not_enabled",
    ]
    assert audit["violation_count"] == 3


def test_aggregate_surface_contract_audits_tracks_case_counts() -> None:
    rows = [
        {
            "artifact": {
                "workflow_trace": ["tool:lookup", "mcp:memory"],
                "tool_calls": [{"name": "lookup", "status": "success", "mcp": "memory"}],
                "mcp_servers_used": [],
            }
        },
        {
            "artifact": {
                "workflow_trace": ["tool:lookup", "mcp:memory"],
                "tool_calls": [{"name": "lookup", "status": "success", "mcp": "memory"}],
                "mcp_servers_used": [],
            }
        },
    ]
    summary = aggregate_surface_contract_audits(
        rows,
        {
            "tool_names": [],
            "mcp_names": [],
        },
    )
    assert summary["surface_contract_violations"] == [
        "mcp:memory:referenced_not_listed",
        "mcp:memory:used_not_enabled",
        "tool:lookup:used_not_enabled",
    ]
    assert summary["surface_contract_violation_case_counts"] == {
        "mcp:memory:referenced_not_listed": 2,
        "mcp:memory:used_not_enabled": 2,
        "tool:lookup:used_not_enabled": 2,
    }
    assert summary["surface_contract_violation_count"] == 6
    assert summary["surface_contract_unique_violation_count"] == 3


def test_aggregate_surface_audits_tracks_evidence_helpfulness() -> None:
    rows = [
        {
            "artifact": {
                "final_output": "Ship in the current window. Next action: proceed with deployment.",
                "tool_calls": [{"name": "lookup", "status": "success", "mcp": "filesystem"}],
                "evidence_records": [
                    {
                        "kind": "retrieval",
                        "name": "lookup",
                        "mcp": "filesystem",
                        "hits": [
                            {
                                "snippet": "If a release only changes UI copy with no backend risk, ship in the current window.",
                                "selected": True,
                            }
                        ],
                    }
                ],
            }
        },
        {
            "artifact": {
                "final_output": "Delay the release.",
                "tool_calls": [{"name": "lookup", "status": "success", "mcp": "filesystem"}],
                "evidence_records": [
                    {
                        "kind": "retrieval",
                        "name": "lookup",
                        "mcp": "filesystem",
                        "hits": [
                            {
                                "snippet": "notify finance operations before releasing",
                                "selected": True,
                            }
                        ],
                    }
                ],
            }
        },
    ]
    summary = aggregate_surface_audits(rows)
    tool_audit = summary["tool_audits"]["lookup"]
    mcp_audit = summary["mcp_audits"]["filesystem"]
    assert tool_audit["attempted"] == 2
    assert tool_audit["selected_evidence"] == 2
    assert tool_audit["supported_evidence"] == 1
    assert tool_audit["cases_with_selected_evidence"] == 2
    assert tool_audit["cases_with_supported_evidence"] == 1
    assert tool_audit["cases_with_unsupported_selected_evidence"] == 1
    assert tool_audit["selected_evidence_use_rate"] == 0.5
    assert mcp_audit["cases_with_unsupported_selected_evidence"] == 1
    assert summary["tool_evidence_totals"]["selected_evidence"] == 2
    assert summary["tools_with_unused_selected_evidence"] == ["lookup"]
    assert summary["mcps_with_unused_selected_evidence"] == ["filesystem"]
