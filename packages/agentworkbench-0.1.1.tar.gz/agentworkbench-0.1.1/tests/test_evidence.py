from __future__ import annotations

from agentworkbench.evidence import artifact_evidence_summary, normalize_evidence_records, snippet_supported_by_output


def test_snippet_supported_by_output_accepts_exact_phrase_and_high_overlap() -> None:
    assert snippet_supported_by_output("delay the release until a rollback plan is approved", "Decision: delay the release until a rollback plan is approved.")
    assert snippet_supported_by_output(
        "customer had a prior sso exception denied last quarter",
        "Customer history says Zenith had a prior SSO exception denied last quarter.",
    )
    assert snippet_supported_by_output(
        "If a release only changes UI copy with no backend risk, ship in the current window.",
        "Ship in the current window. Next action: proceed with deployment.",
    )


def test_normalize_evidence_records_marks_selected_hits_used_in_output() -> None:
    records = normalize_evidence_records(
        {
            "final_output": "Delay the release until a rollback plan is approved. Next action: notify finance operations.",
            "evidence_records": [
                {
                    "kind": "retrieval",
                    "name": "release_checklist_search",
                    "mcp": "filesystem",
                    "query": "Should we ship?",
                    "hits": [
                        {
                            "path": "knowledge/release-checklist.md",
                            "line": 3,
                            "snippet": "delay the release until a rollback plan is approved",
                            "selected": True,
                        },
                        {
                            "path": "knowledge/release-checklist.md",
                            "line": 4,
                            "snippet": "notify finance operations",
                            "selected": True,
                        },
                    ],
                }
            ],
        }
    )
    assert len(records) == 1
    assert records[0]["used_count"] == 2
    assert records[0]["used_in_output"] is True
    assert records[0]["hits"][0]["used_in_output"] is True


def test_normalize_evidence_records_recomputes_stale_false_usage_flags() -> None:
    records = normalize_evidence_records(
        {
            "final_output": "Ship in the current window. Next action: proceed with deployment.",
            "evidence_records": [
                {
                    "kind": "retrieval",
                    "name": "release_checklist_search",
                    "used_in_output": False,
                    "used_count": 0,
                    "hits": [
                        {
                            "snippet": "If a release only changes UI copy with no backend risk, ship in the current window.",
                            "selected": True,
                            "used_in_output": False,
                        }
                    ],
                }
            ],
        }
    )
    assert records[0]["used_count"] == 1
    assert records[0]["used_in_output"] is True
    assert records[0]["hits"][0]["used_in_output"] is True


def test_artifact_evidence_summary_falls_back_to_retrieval_events() -> None:
    records, summary = artifact_evidence_summary(
        {
            "final_output": "approved",
            "events": [
                {"kind": "retrieval", "name": "lookup", "hits": 1, "selected": True, "status": "success", "mcp": "filesystem"},
                {"kind": "memory_lookup", "name": "customer_memory", "loaded": True, "status": "success", "mcp": "memory"},
            ],
        }
    )
    assert [item["label"] for item in records] == ["retrieval:lookup", "memory_lookup:customer_memory"]
    assert summary["record_count"] == 2
    assert summary["selected_count"] == 2
    assert summary["used_count"] == 0
    assert "memory_lookup:customer_memory" in summary["sources_with_unused_selected"]
