from __future__ import annotations

from agentworkbench.human_review import (
    brief_human_checkpoints,
    build_review_queue,
    eval_human_checkpoints,
    experiment_human_checkpoints,
)
from agentworkbench.human_review_store import (
    pending_review_items,
    record_review_answer,
    resolve_review_queue,
)
from agentworkbench.models import BehaviorBrief, EvalCase
from agentworkbench.report_diagnosis import render_diagnosis_report
from agentworkbench.reports import render_brief_packet, render_eval_suite_report


def test_brief_human_checkpoints_flag_surface_examples_and_subjective_quality() -> None:
    brief = BehaviorBrief(
        id="assistant",
        goal="Answer with the best tone and style for the user",
        acceptance_criteria=["Use polished language that feels warm and concise."],
        workflow_scenarios=[{"name": "default", "trigger": "User asks for help"}],
    )

    checkpoints = brief_human_checkpoints(brief, {"confirmed_owned_files": []})
    ids = {item["checkpoint_id"] for item in checkpoints}

    assert "brief-surface-confirmation" in ids
    assert "brief-representative-examples" in ids
    assert "brief-workflow-contract" in ids
    assert "brief-subjective-rubric" in ids
    assert all(item.get("queue") for item in checkpoints)
    assert any(item.get("review_type") == "subjective_review" for item in checkpoints)
    subjective = next(item for item in checkpoints if item["checkpoint_id"] == "brief-subjective-rubric")
    assert subjective["response_mode"] == "choose_or_guide"
    assert "ideal answer" not in subjective["question"].lower()
    assert "guidance" in subjective["question"].lower()


def test_eval_human_checkpoints_flag_subjective_and_workflow_cases() -> None:
    cases = [
        EvalCase(
            id="style-1",
            input="Write a response",
            rubric=["Prefer the warmer and more polished answer."],
            tags=["style"],
        ),
        EvalCase(
            id="workflow-1",
            input="Escalate the customer issue",
            expected="",
            rubric=["Use the right workflow."],
            tags=["workflow"],
        ),
    ]

    checkpoints = eval_human_checkpoints(cases)
    ids = {item["checkpoint_id"] for item in checkpoints}
    related = {case_id for item in checkpoints for case_id in item["related_case_ids"]}

    assert "eval-subjective-cases" in ids
    assert "eval-workflow-contract" in ids
    assert {"style-1", "workflow-1"} <= related


def test_eval_human_checkpoints_skip_cases_with_applied_human_review() -> None:
    cases = [
        EvalCase(
            id="style-1",
            input="Write a response",
            rubric=["Prefer the warmer and more polished answer."],
            tags=["style"],
            metadata={
                "human_review": {
                    "resolved": True,
                    "guidance": "Prefer the warmer answer.",
                    "applied_answers": [{"checkpoint_id": "eval-subjective-cases"}],
                }
            },
        )
    ]

    checkpoints = eval_human_checkpoints(cases)

    assert checkpoints == []


def test_experiment_human_checkpoints_flag_pairwise_review_and_tool_contract() -> None:
    checkpoints = experiment_human_checkpoints(
        [
            {
                "case_id": "style-1",
                "reason": "regressed relative to baseline",
                "tools_added": ["policy_search"],
                "tools_removed": [],
                "expected_behavior": {
                    "tags": ["style"],
                    "rubric": ["Prefer the answer with better tone and taste."],
                    "required_terms": [],
                    "required_tools": [],
                    "required_skills": [],
                    "required_plugins": [],
                    "required_mcps": [],
                    "required_prompt_keys": [],
                    "required_workflow_steps": [],
                    "workflow_sequence": [],
                },
                "baseline_evidence": {"final_output_preview": "Warm and direct answer."},
                "candidate_evidence": {"final_output_preview": "Formal but colder answer."},
            }
        ]
    )
    ids = {item["checkpoint_id"] for item in checkpoints}

    assert "diagnosis-pairwise-review" in ids
    assert "diagnosis-tool-contract" in ids


def test_reports_render_human_checkpoint_sections() -> None:
    checkpoints = [
        {
            "checkpoint_id": "example",
            "title": "Example checkpoint",
            "priority": "high",
            "question": "What should the human decide?",
            "reason": "The package found an ambiguous case.",
            "related_case_ids": ["case-1"],
        }
    ]
    queue = build_review_queue(queue_id="brief-assistant", stage="brief", subject="assistant", checkpoints=checkpoints)

    brief_report = render_brief_packet(
        {
            "brief_id": "assistant",
            "agent_id": "sample-agent",
            "goal": "Answer accurately",
            "repo_learning_prompts": [],
            "confirmed_owned_files": [],
            "surface_paths": {},
            "unclaimed_candidate_files": [],
            "provider_hints": [],
            "likely_env_keys": [],
            "interview_prompts": [],
            "likely_questions": [],
            "likely_commands": [],
            "rough_answer_outlines": [],
            "workflow_scenarios": [],
            "prompt_variants": [],
            "preferred_tools": [],
            "preferred_skills": [],
            "preferred_plugins": [],
            "preferred_mcps": [],
            "better_signals": [],
            "worse_signals": [],
            "acceptance_criteria": [],
            "human_checkpoints": checkpoints,
            "human_review_queue": queue,
        }
    )
    eval_report = render_eval_suite_report(
        {
            "eval_id": "assistant-eval",
            "brief_id": "assistant",
            "approval_status": "draft",
            "generated_case_count": 1,
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "tags": [],
            "split_sizes": {"smoke": 1},
            "cases": [],
            "human_checkpoints": checkpoints,
            "human_review_queue": queue,
        }
    )
    diagnosis_report = render_diagnosis_report(
        {
            "experiment_id": "exp-1",
            "agent_id": "sample-agent",
            "eval_id": "assistant-eval",
            "subset": "full",
            "benchmark_signature": "sig",
            "promotion_status": "candidate",
            "baseline_id": None,
            "comparison_mode": "standalone",
            "recommended_action": "review",
            "summary": "summary",
            "baseline_ladder": {},
            "aggregate": {},
            "surface_recommendations": [],
            "repo_changes": [],
            "repo_change_summary": {},
            "baseline_runtime_changes": [],
            "candidate_runtime_changes": [],
            "focus_cases": [],
            "failure_clusters": [],
            "surface_gaps": {},
            "suggested_mutations": [],
            "suggested_commands": [],
            "human_checkpoints": checkpoints,
            "human_review_queue": queue,
        }
    )

    assert "## Human Checkpoints" in brief_report
    assert "## Human Review Queue" in brief_report
    assert "## Human Checkpoints Before Approval" in eval_report
    assert "## Ask The Human" in diagnosis_report
    assert "What should the human decide?" in diagnosis_report


def test_recorded_human_answer_resolves_queue_item_without_requiring_answer_text(tmp_path) -> None:
    checkpoints = [
        {
            "checkpoint_id": "pairwise-1",
            "title": "Choose the better answer",
            "priority": "high",
            "question": "Which answer should win?",
            "reason": "Taste-based case.",
            "review_type": "subjective_review",
            "question_type": "pairwise_acceptance",
            "queue": "answer_acceptance",
            "response_mode": "choose_or_guide",
            "suggested_prompt": "Pick the better answer.",
            "related_case_ids": ["case-1"],
        }
    ]
    queue = build_review_queue(queue_id="diagnose-exp-1", stage="answer_acceptance", subject="exp-1", checkpoints=checkpoints)
    queue = resolve_review_queue(tmp_path, queue)

    assert queue["pending_count"] == 1
    assert len(pending_review_items(queue)) == 1

    record_review_answer(
        tmp_path,
        queue_id="diagnose-exp-1",
        checkpoint_id="pairwise-1",
        decision="candidate",
        guidance="Prefer the clearer answer while keeping the warmer tone.",
        related_case_ids=["case-1"],
    )
    resolved_queue = resolve_review_queue(tmp_path, queue)

    assert resolved_queue["pending_count"] == 0
    assert resolved_queue["resolved_count"] == 1
    assert pending_review_items(resolved_queue) == []
    resolution = resolved_queue["items"][0]["resolution"]
    assert resolution["decision"] == "candidate"
    assert resolution["guidance"] == "Prefer the clearer answer while keeping the warmer tone."
