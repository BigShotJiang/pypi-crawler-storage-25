from __future__ import annotations

import json
import runpy
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

from agentworkbench import __version__
from agentworkbench.briefs import finalize_brief, start_brief
from agentworkbench.cli import build_parser
from agentworkbench.evals import generate_eval_suite
from agentworkbench.scaffold import init_workbench


def _subparser(name: str) -> Any:
    parser = build_parser()
    subparsers = getattr(parser, "_subparsers", None)
    if subparsers is None:
        raise AssertionError("Parser is missing subparsers")
    for action in getattr(subparsers, "_group_actions", []):
        choices = getattr(action, "choices", None)
        if isinstance(choices, dict) and name in choices:
            return choices[name]
    raise AssertionError(f"Missing subparser {name}")


def test_cli_help_lists_core_commands() -> None:
    help_text = build_parser().format_help()
    assert "patch-template" in help_text
    assert "next" in help_text
    assert "diagnose" in help_text
    assert "status" in help_text
    assert "iterate" in help_text
    assert "optimize" in help_text
    brief_parser = _subparser("brief")
    assert "draft" in brief_parser.format_help()
    evals_parser = _subparser("evals")
    assert "expand" in evals_parser.format_help()


def test_python_module_entrypoint_reports_version() -> None:
    project_root = Path(__file__).resolve().parents[1]
    completed = subprocess.run(
        [sys.executable, "-m", "agentworkbench", "--version"],
        cwd=project_root,
        check=True,
        capture_output=True,
        text=True,
    )
    assert completed.stdout.strip() == f"awb {__version__}"


def test_python_module_main_invokes_cli(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("agentworkbench.cli.main", lambda: 7)

    with pytest.raises(SystemExit, match="7"):
        runpy.run_module("agentworkbench", run_name="__main__")


def test_python_module_entrypoint_reports_user_errors_without_traceback(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    start_brief(tmp_path, "assistant", "Answer repo questions accurately")
    finalize_brief(tmp_path, "assistant")
    generate_eval_suite(tmp_path, "assistant", "assistant-eval")

    completed = subprocess.run(
        [sys.executable, "-m", "agentworkbench", "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 1
    assert "must be approved" in completed.stderr
    assert "Traceback" not in completed.stderr


def test_python_module_run_outputs_json_payload(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    start_brief(tmp_path, "assistant", "Answer repo questions accurately")
    finalize_brief(tmp_path, "assistant")
    generate_eval_suite(tmp_path, "assistant", "assistant-eval")
    completed = subprocess.run(
        [sys.executable, "-m", "agentworkbench", "evals", "approve", "--eval-id", "assistant-eval"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=True,
    )
    assert completed.returncode == 0

    completed = subprocess.run(
        [sys.executable, "-m", "agentworkbench", "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(completed.stdout)

    assert payload["experiment"]["agent_id"] == "sample-agent"
    assert payload["experiment"]["eval_id"] == "assistant-eval"
    assert payload["aggregate"]["total_cases"] >= 1
