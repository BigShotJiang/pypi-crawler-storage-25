from __future__ import annotations

from pathlib import Path

import pytest

from agentworkbench.chain import _build_chain_context, _build_handoff
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.scaffold import init_workbench
from agentworkbench.utils import write_yaml
from agentworkbench.workflow import _load_workflow_spec, _workflow_file_path


def test_build_chain_context_aggregates_step_artifacts() -> None:
    context = _build_chain_context(
        [
            {
                "final_output_preview": "Route to refunds",
                "artifact_summary": {
                    "tool_calls": [{"name": "lookup_policy"}],
                    "evidence_records": [{"kind": "retrieval", "name": "refund-policy"}],
                    "trace_events": [{"kind": "provider_response", "name": "ok"}],
                },
            },
            {
                "final_output_preview": "Issue refund",
                "artifact_summary": {
                    "tool_calls": [{"name": "issue_refund"}],
                    "evidence_records": [{"kind": "note", "name": "csr-handoff"}],
                    "trace_events": [{"kind": "tool_result", "name": "issue_refund"}],
                },
            },
        ],
        original_input="Handle the refund request.",
        case_id="case-1",
    )

    assert context.case_id == "case-1"
    assert context.original_input == "Handle the refund request."
    assert context.accumulated_output == "Route to refunds\n---\nIssue refund"
    assert context.aggregated_tool_calls == [{"name": "lookup_policy"}, {"name": "issue_refund"}]
    assert context.aggregated_evidence[0]["name"] == "refund-policy"
    assert context.aggregated_trace_events[1]["kind"] == "tool_result"


def test_build_handoff_renders_known_fields_and_rejects_unknown_fields() -> None:
    chain_context = _build_chain_context(
        [{"final_output_preview": "Refund approved", "artifact_summary": {"tool_calls": [{"name": "lookup_policy"}]}}],
        original_input="Approve the refund.",
        case_id="case-2",
    )

    handoff = _build_handoff(
        template="{prior_output}|{prior_tool_calls}|{shared_context}|{case_id}|{step}|{chain_context}",
        prior_output="Refund approved",
        prior_artifact={"tool_calls": [{"name": "lookup_policy"}], "structured_output": {"route": "refund"}},
        original_input="Approve the refund.",
        case_id="case-2",
        step_idx=2,
        chain_context=chain_context,
        shared_context={"priority": "p1"},
    )

    assert "Refund approved" in handoff
    assert '"lookup_policy"' in handoff
    assert '"priority": "p1"' in handoff
    assert "case-2" in handoff
    assert '"aggregated_tool_calls"' in handoff

    with pytest.raises(ValueError, match="unknown field `missing`"):
        _build_handoff(
            template="{missing}",
            prior_output="",
            prior_artifact=None,
            original_input="",
            case_id="case-2",
            step_idx=0,
            chain_context=None,
        )


def _workflow_dir(project_root: Path) -> Path:
    workflow_dir = project_root / CONTROL_DIR_NAME / "workflows"
    workflow_dir.mkdir(parents=True, exist_ok=True)
    return workflow_dir


def _base_workflow_payload() -> dict[str, object]:
    return {
        "id": "router-workflow",
        "start_at": "router",
        "nodes": [
            {"id": "router", "agent_id": "sample-agent"},
            {"id": "refund", "agent_id": "sample-agent-improved"},
        ],
        "edges": [
            {"from": "router", "to": "refund", "when": "route == 'refund'"},
        ],
    }


def test_workflow_file_path_and_load_spec_resolve_control_directory(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    workflow_path = _workflow_dir(tmp_path) / "router.yaml"
    write_yaml(workflow_path, _base_workflow_payload())

    resolved = _workflow_file_path(tmp_path, "router")
    spec, relative_path = _load_workflow_spec(tmp_path, "router")

    assert resolved == workflow_path
    assert spec.id == "router-workflow"
    assert relative_path == f"{CONTROL_DIR_NAME}/workflows/router.yaml"


def test_load_workflow_spec_rejects_missing_and_invalid_specs(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    workflow_path = _workflow_dir(tmp_path) / "router.yaml"

    with pytest.raises(FileNotFoundError, match="Workflow file not found"):
        _load_workflow_spec(tmp_path, "missing")

    duplicate_nodes = _base_workflow_payload()
    duplicate_nodes["nodes"] = [
        {"id": "router", "agent_id": "sample-agent"},
        {"id": "router", "agent_id": "sample-agent-improved"},
    ]
    write_yaml(workflow_path, duplicate_nodes)
    with pytest.raises(ValueError, match="must be unique"):
        _load_workflow_spec(tmp_path, "router")

    unknown_start = _base_workflow_payload()
    unknown_start["start_at"] = "missing"
    write_yaml(workflow_path, unknown_start)
    with pytest.raises(ValueError, match="start_at `missing`"):
        _load_workflow_spec(tmp_path, "router")

    missing_agent = _base_workflow_payload()
    missing_agent["nodes"] = [{"id": "router", "node_type": "agent"}]
    write_yaml(workflow_path, missing_agent)
    with pytest.raises(ValueError, match="requires `agent_id`"):
        _load_workflow_spec(tmp_path, "router")

    missing_chain_members = _base_workflow_payload()
    missing_chain_members["nodes"] = [{"id": "router", "node_type": "chain"}]
    write_yaml(workflow_path, missing_chain_members)
    with pytest.raises(ValueError, match="requires `chain_agent_ids`"):
        _load_workflow_spec(tmp_path, "router")

    unknown_edge_target = _base_workflow_payload()
    unknown_edge_target["edges"] = [{"from": "router", "to": "missing"}]
    write_yaml(workflow_path, unknown_edge_target)
    with pytest.raises(ValueError, match="unknown to node"):
        _load_workflow_spec(tmp_path, "router")
