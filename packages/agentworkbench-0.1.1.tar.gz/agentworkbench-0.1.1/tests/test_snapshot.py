from __future__ import annotations

from pathlib import Path

from agentworkbench.snapshot import (
    capture_snapshot,
    compare_benchmark_hashes,
    compare_snapshots,
    compute_benchmark_hashes,
)


def test_filesystem_snapshot_detects_changes(tmp_path: Path) -> None:
    target = tmp_path / "file.txt"
    target.write_text("hello\n", encoding="utf-8")
    before = capture_snapshot(tmp_path, "filesystem")
    target.write_text("hello world\n", encoding="utf-8")
    after = capture_snapshot(tmp_path, "filesystem")
    changed, diff_text = compare_snapshots(tmp_path, before, after)
    assert "file.txt" in changed
    assert "hello world" in diff_text


def test_benchmark_hashes_and_compare(tmp_path: Path) -> None:
    control = tmp_path / ".agent-workbench"
    (control / "briefs").mkdir(parents=True)
    (control / "scorers").mkdir(parents=True)
    (control / "briefs" / "brief.yaml").write_text("id: brief\n", encoding="utf-8")
    (control / "scorers" / "brief_default.py").write_text("def score(*_args, **_kwargs):\n    return []\n", encoding="utf-8")
    before = compute_benchmark_hashes(tmp_path)
    (control / "briefs" / "brief.yaml").write_text("id: brief\ngoal: updated\n", encoding="utf-8")
    (control / "scorers" / "brief_default.py").write_text("def score(*_args, **_kwargs):\n    return [{'name': 'x', 'score': 1.0}]\n", encoding="utf-8")
    after = compute_benchmark_hashes(tmp_path)
    mode, changes = compare_benchmark_hashes(before, after)
    assert mode == "benchmark-changed"
    assert ".agent-workbench/briefs/brief.yaml" in changes
    assert ".agent-workbench/scorers/brief_default.py" in changes


def test_benchmark_hashes_ignore_packets_and_workbench_config(tmp_path: Path) -> None:
    control = tmp_path / ".agent-workbench"
    (control / "briefs").mkdir(parents=True)
    (control / "evals").mkdir(parents=True)
    (control / "scorers").mkdir(parents=True)
    (control / "workbench.yaml").write_text("snapshot_mode: auto\n", encoding="utf-8")
    (control / "briefs" / "brief.yaml").write_text("id: brief\n", encoding="utf-8")
    (control / "briefs" / "brief.packet.md").write_text("# packet\n", encoding="utf-8")
    (control / "evals" / "suite.yaml").write_text("id: suite\n", encoding="utf-8")
    before = compute_benchmark_hashes(tmp_path)
    (control / "workbench.yaml").write_text("snapshot_mode: filesystem\n", encoding="utf-8")
    (control / "briefs" / "brief.packet.md").write_text("# updated packet\n", encoding="utf-8")
    after = compute_benchmark_hashes(tmp_path)
    mode, changes = compare_benchmark_hashes(before, after)
    assert mode == "clean"
    assert changes == []
