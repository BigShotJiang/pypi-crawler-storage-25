"""Tests for instrumentation drift benchmarks."""

from __future__ import annotations

from agentworkbench.instrumentation import summarize_provenance


def _make_trace_events(model: str, tools: list[str], steps: int) -> list[dict]:
    """Create synthetic trace events for drift testing."""
    events = []
    events.append(
        {
            "seq": 0,
            "kind": "startup",
            "name": "agent_start",
            "provenance": "raw",
            "source": "runtime",
        }
    )
    for i in range(steps):
        events.append(
            {
                "seq": i + 1,
                "kind": "tool_call",
                "name": tools[i % len(tools)],
                "provenance": "raw",
                "source": "workflow_trace",
            }
        )
    events.append(
        {
            "seq": steps + 1,
            "kind": "provider_request",
            "provenance": "raw",
            "source": "provider_request",
            "data": {"model": model},
        }
    )
    events.append(
        {
            "seq": steps + 2,
            "kind": "provider_response",
            "provenance": "raw",
            "source": "provider_response",
            "data": {"model": model},
        }
    )
    return events


class TestInstrumentationDrift:
    """Benchmark tests for instrumentation drift detection."""

    def test_no_drift_between_identical_experiments(self):
        events_a = _make_trace_events("gpt-4", ["read_file", "grep"], 5)
        events_b = _make_trace_events("gpt-4", ["read_file", "grep"], 5)

        summary_a = summarize_provenance(events_a)
        summary_b = summarize_provenance(events_b)

        assert summary_a["quality"] == summary_b["quality"]
        assert summary_a["confidence"] == summary_b["confidence"]

    def test_drift_from_model_change(self):
        events_a = _make_trace_events("gpt-4", ["read_file"], 3)
        events_b = _make_trace_events("claude-3", ["read_file"], 3)

        models_a = {e["data"]["model"] for e in events_a if e.get("data", {}).get("model")}
        models_b = {e["data"]["model"] for e in events_b if e.get("data", {}).get("model")}

        assert models_a != models_b

    def test_drift_from_tool_change(self):
        events_a = _make_trace_events("gpt-4", ["read_file"], 3)
        events_b = _make_trace_events("gpt-4", ["read_file", "search", "grep"], 3)

        tools_a = {e["name"] for e in events_a if e["kind"] == "tool_call"}
        tools_b = {e["name"] for e in events_b if e["kind"] == "tool_call"}

        assert tools_a != tools_b

    def test_drift_from_telemetry_quality_change(self):
        raw_events = _make_trace_events("gpt-4", ["read_file"], 3)
        inferred_events = [{**e, "provenance": "inferred", "source": "heuristic"} for e in raw_events]

        summary_raw = summarize_provenance(raw_events)
        summary_inferred = summarize_provenance(inferred_events)

        assert summary_raw["quality"] == "high"
        assert summary_inferred["quality"] == "low"
        assert summary_raw["confidence"] > summary_inferred["confidence"]

    def test_drift_from_step_count_change(self):
        events_a = _make_trace_events("gpt-4", ["read_file"], 3)
        events_b = _make_trace_events("gpt-4", ["read_file"], 10)

        assert len(events_a) != len(events_b)

        summary_a = summarize_provenance(events_a)
        summary_b = summarize_provenance(events_b)

        assert summary_a["total_count"] != summary_b["total_count"]

    def test_empty_telemetry_drift(self):
        events_a = _make_trace_events("gpt-4", ["read_file"], 3)
        events_b: list[dict[str, object]] = []

        summary_a = summarize_provenance(events_a)
        summary_b = summarize_provenance(events_b)

        assert summary_a["quality"] != summary_b["quality"]
        assert summary_b["quality"] == "empty"
        assert summary_b["confidence"] == 0.0

    def test_mixed_provenance_drift(self):
        events = [
            {"seq": 1, "kind": "tool_call", "name": "read", "provenance": "raw", "source": "workflow_trace"},
            {"seq": 2, "kind": "tool_call", "name": "grep", "provenance": "inferred", "source": "heuristic"},
            {"seq": 3, "kind": "prompt", "provenance": "raw", "source": "workflow_trace"},
            {"seq": 4, "kind": "provider_request", "provenance": "raw", "source": "provider_request"},
            {"seq": 5, "kind": "provider_response", "provenance": "inferred", "source": "heuristic"},
        ]

        summary = summarize_provenance(events)

        assert summary["raw_count"] == 3
        assert summary["inferred_count"] == 2
        assert summary["total_count"] == 5
        assert summary["quality"] == "medium"
        assert 0.5 < summary["confidence"] < 0.9
