from __future__ import annotations

from pathlib import Path

from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.discovery import discover_repo
from agentworkbench.scaffold import init_workbench


def test_discover_python_fixture(tmp_path: Path) -> None:
    fixture = Path(__file__).parent / "fixtures" / "sample_python_repo"
    for source in fixture.rglob("*"):
        if source.is_file():
            target = tmp_path / source.relative_to(fixture)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    init_workbench(tmp_path)
    summary = discover_repo(tmp_path)
    assert "python" in summary["languages"]
    assert any("main.py" in entry for entry in summary["likely_entrypoints"])


def test_discover_notes_fixture(tmp_path: Path) -> None:
    fixture = Path(__file__).parent / "fixtures" / "sample_notes_repo"
    for source in fixture.rglob("*"):
        if source.is_file():
            target = tmp_path / source.relative_to(fixture)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    init_workbench(tmp_path)
    summary = discover_repo(tmp_path)
    assert "markdown" in summary["languages"]
    assert summary["file_count"] >= 1


def test_discover_repo_ignores_artifacts_and_finds_cli_entrypoints(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "toolpkg"',
                'version = "0.1.0"',
                "[project.scripts]",
                'toolpkg = "toolpkg.cli:main"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / "Makefile").write_text("test:\n\tpytest\n", encoding="utf-8")
    (tmp_path / "toolpkg").mkdir()
    (tmp_path / "toolpkg" / "cli.py").write_text("def main():\n    return 0\n", encoding="utf-8")
    (tmp_path / "toolpkg" / "__main__.py").write_text("from toolpkg.cli import main\n", encoding="utf-8")
    (tmp_path / "tests" / "fixtures").mkdir(parents=True)
    (tmp_path / "tests" / "fixtures" / "main.py").write_text("print('fixture')\n", encoding="utf-8")
    (tmp_path / ".ruff_cache").mkdir()
    (tmp_path / ".ruff_cache" / "cache").write_text("ignored\n", encoding="utf-8")
    (tmp_path / "dist").mkdir()
    (tmp_path / "dist" / "toolpkg.whl").write_text("ignored\n", encoding="utf-8")
    (tmp_path / "toolpkg.egg-info").mkdir()
    (tmp_path / "toolpkg.egg-info" / "PKG-INFO").write_text("ignored\n", encoding="utf-8")

    summary = discover_repo(tmp_path)

    assert summary["guessed_commands"]["test"] == "make test"
    assert "toolpkg/cli.py" in summary["likely_entrypoints"]
    assert "toolpkg/__main__.py" in summary["likely_entrypoints"]
    assert "tests/fixtures/main.py" not in summary["likely_entrypoints"]
    assert all(not path.startswith(".ruff_cache/") for path in summary["top_files"])
    assert all(not path.startswith("dist/") for path in summary["top_files"])
    assert all(".egg-info/" not in path for path in summary["top_files"])


def test_discover_repo_surfaces_owned_files_and_provider_hints(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    (tmp_path / "agent").mkdir()
    (tmp_path / "agent" / "cli.py").write_text("def main():\n    return 0\n", encoding="utf-8")
    (tmp_path / "agent" / "tools.py").write_text("def repo_search():\n    return 'ok'\n", encoding="utf-8")
    (tmp_path / "agent" / "memory.py").write_text("def recall():\n    return 'memory'\n", encoding="utf-8")
    (tmp_path / "agent" / "prompts").mkdir()
    (tmp_path / "agent" / "prompts" / "system.md").write_text("system prompt\n", encoding="utf-8")
    (tmp_path / "agent" / "provider.py").write_text(
        "import openai\nAPI_KEY = 'OPENAI_API_KEY'\n",
        encoding="utf-8",
    )
    (tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml").write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: agent/prompts/system.md}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "owned_paths:",
                "  - agent/cli.py",
                "  - agent/prompts/system.md",
                "surface_paths:",
                "  prompts:",
                "    - agent/prompts/system.md",
                "  runtime:",
                "    - agent/cli.py",
                "required_env:",
                "  - OPENAI_API_KEY",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv: [python3, -m, agent.cli]",
                "    cwd: .",
                "    timeout_seconds: 30",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    summary = discover_repo(tmp_path)

    assert "agent/prompts/system.md" in summary["candidate_prompt_files"]
    assert "agent/tools.py" in summary["candidate_tool_files"]
    assert "agent/memory.py" in summary["candidate_memory_files"]
    assert "openai" in summary["provider_hints"]
    assert "OPENAI_API_KEY" in summary["likely_env_keys"]
    assert "agent/cli.py" in summary["confirmed_owned_files"]
    assert "agent/prompts/system.md" in summary["confirmed_owned_files"]
