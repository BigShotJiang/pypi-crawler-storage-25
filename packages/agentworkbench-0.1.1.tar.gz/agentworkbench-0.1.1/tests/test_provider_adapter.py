from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from agentworkbench.adapters import provider as provider_adapter
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.models import AgentSpec, EvalCase, ProviderEntrypoint
from agentworkbench.providers import openai_compatible as provider_transport
from agentworkbench.providers.openai_compatible import TransportError
from agentworkbench.runner import run_experiment
from agentworkbench.scaffold import init_workbench
from agentworkbench.utils import read_jsonl, write_jsonl, write_text, write_yaml


class _FakeHTTPResponse:

    def __init__(self, payload: dict):
        self._payload = payload

    def __enter__(self) -> _FakeHTTPResponse:
        return self

    def __exit__(self, _exc_type: object, exc: object, _tb: object) -> Literal[False]:
        return False

    def read(self) -> bytes:
        return json.dumps(self._payload).encode("utf-8")


def _prepare_provider_eval(tmp_path: Path, eval_id: str = "provider-eval") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": f"{eval_id}-1",
            "input": "Return the approved support answer.",
            "expected": "approved from provider",
            "tags": ["provider"],
            "metadata": {},
        }
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": len(cases),
            "tags": ["provider"],
        },
    )
    write_yaml(
        control / "evals" / f"{eval_id}.splits.yaml",
        {
            "smoke": [cases[0]["id"]],
            "full": [cases[0]["id"]],
        },
    )
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    final_output = str(run_artifact.get('final_output') or '').lower()",
                "    expected = str(case.get('expected') or '').lower()",
                "    passed = expected in final_output",
                "    return {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if passed else 0.0,",
                "        'passed': passed,",
                "        'reason': 'match' if passed else 'miss',",
                "    }",
            ]
        ),
    )


def _write_provider_agent(tmp_path: Path, *, cache_mode: str) -> None:
    write_text(tmp_path / "prompts" / "system.md", "Answer concisely and stay grounded in the request.\n")
    spec = {
        "id": "provider-agent",
        "adapter": "provider",
        "instructions": ["Keep the answer concise."],
        "prompts": {
            "system": "prompts/system.md",
            "reviewer": "Preserve the decisive policy phrase verbatim when possible.",
        },
        "model": {
            "provider": "groq",
            "name": "groq/llama-3.1-8b-instant",
            "model_id": "llama-3.1-8b-instant",
            "temperature": 0,
            "max_tokens": 32,
        },
        "tools": [
            {
                "name": "lookup_policy",
                "enabled": True,
                "description": "Fetch the decisive support policy clause.",
                "parameters": {
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                },
            }
        ],
        "skills": [],
        "plugins": [],
        "mcps": [],
        "required_env": ["GROQ_API_KEY"],
        "runtime": {"env": {}},
        "entrypoints": {
            "provider": {
                "timeout_seconds": 5,
                "cache_mode": cache_mode,
            }
        },
        "metadata": {},
    }
    write_yaml(tmp_path / CONTROL_DIR_NAME / "agents" / "provider-agent.yaml", spec)


def _run_rows(tmp_path: Path, experiment_id: str) -> list[dict]:
    return read_jsonl(tmp_path / CONTROL_DIR_NAME / "runs" / experiment_id / "runs.jsonl")


def _prepare_tool_route_eval(tmp_path: Path, eval_id: str = "provider-route-eval") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": f"{eval_id}-1",
            "input": "Route this refund request.",
            "expected": "",
            "tags": ["provider", "tools"],
            "metadata": {"expected_tool": "lookup_policy"},
        }
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": len(cases),
            "tags": ["provider", "tools"],
        },
    )
    write_yaml(
        control / "evals" / f"{eval_id}.splits.yaml",
        {
            "smoke": [cases[0]["id"]],
            "full": [cases[0]["id"]],
        },
    )
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    tool_calls = [item for item in (run_artifact.get('tool_calls') or []) if isinstance(item, dict)]",
                "    chosen_tool = str((tool_calls[0] if tool_calls else {}).get('name') or '').strip()",
                "    expected_tool = str((case.get('metadata') or {}).get('expected_tool') or '').strip()",
                "    passed = bool(expected_tool and chosen_tool == expected_tool)",
                "    return {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if passed else 0.0,",
                "        'passed': passed,",
                "        'reason': 'matched expected tool' if passed else f'expected {expected_tool or \"none\"}, got {chosen_tool or \"none\"}',",
                "    }",
            ]
        ),
    )


def test_build_messages_compacts_chain_context_by_default(tmp_path: Path) -> None:
    spec = AgentSpec(
        id="provider-agent",
        adapter="provider",
        instructions=["Use the workflow context."],
        prompts={"system": "Follow the handoff."},
        model={"provider": "groq", "name": "llama"},
        tools=[],
    )
    chain_context = {
        "case_id": "case-1",
        "original_input": "Route the incident and preserve the important evidence.",
        "accumulated_output": "Router selected incident-specialist after retrieval.",
        "shared_context": {"customer_tier": "enterprise", "risk_flags": ["sla", "billing"]},
        "steps": [
            {
                "step": 0,
                "node_id": "router",
                "agent_id": "router-agent",
                "route": "incident",
                "artifact_summary": {
                    "final_output": "{\"route\":\"incident\"}",
                    "tool_calls": [{"name": "route_incident"}],
                    "evidence_records": [{"kind": "retrieval", "name": "policy_lookup"}],
                    "trace_events": [{"kind": "provider_response", "name": "recovered"}],
                },
            }
        ],
        "aggregated_tool_calls": [{"name": "route_incident"}],
        "aggregated_evidence": [{"kind": "retrieval", "name": "policy_lookup"}],
        "aggregated_trace_events": [{"kind": "provider_response", "name": "recovered"}],
    }
    case = EvalCase(id="case-1", input="Handle the incident.", metadata={"chain_context": chain_context})

    messages, _ = provider_transport.build_messages(tmp_path, spec, case, ProviderEntrypoint())
    system_content = messages[0]["content"]

    assert "Chain context:" in system_content
    assert '"step_count": 1' in system_content
    assert '"shared_context"' in system_content
    assert "aggregated_trace_events" not in system_content

    full_messages, _ = provider_transport.build_messages(
        tmp_path,
        spec,
        case,
        ProviderEntrypoint(chain_context_mode="full"),
    )
    assert "aggregated_trace_events" in full_messages[0]["content"]

    off_messages, _ = provider_transport.build_messages(
        tmp_path,
        spec,
        case,
        ProviderEntrypoint(chain_context_mode="off"),
    )
    assert "Chain context:" not in off_messages[0]["content"]


def test_provider_adapter_caches_and_reuses_openai_compatible_responses(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_provider_eval(tmp_path)
    _write_provider_agent(tmp_path, cache_mode="auto")
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    captured_requests: list[dict] = []

    def _fake_urlopen(request: object, timeout: int = 0, context: object | None = None) -> _FakeHTTPResponse:
        assert hasattr(request, "full_url")
        assert hasattr(request, "headers")
        assert hasattr(request, "data")
        captured_requests.append(
            {
                "url": request.full_url,
                "headers": dict(request.headers),
                "body": json.loads(request.data.decode("utf-8")),
                "timeout": timeout,
            }
        )
        return _FakeHTTPResponse(
            {
                "id": "resp_1",
                "choices": [
                    {
                        "message": {
                            "content": "approved from provider",
                            "tool_calls": [
                                {
                                    "id": "call_1",
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_policy",
                                        "arguments": "{\"query\":\"refund\"}",
                                    },
                                }
                            ],
                        },
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "prompt_tokens": 11,
                    "completion_tokens": 7,
                    "total_tokens": 18,
                },
            }
        )

    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _fake_urlopen)

    record, aggregate = run_experiment(tmp_path, "provider-agent", "provider-eval", "smoke")
    row = _run_rows(tmp_path, record.experiment_id)[0]

    assert aggregate["passed_cases"] == 1
    assert len(captured_requests) == 1
    assert captured_requests[0]["url"] == "https://api.groq.com/openai/v1/chat/completions"
    assert captured_requests[0]["body"]["model"] == "llama-3.1-8b-instant"
    assert captured_requests[0]["body"]["tools"][0]["function"]["name"] == "lookup_policy"
    assert row["artifact"]["final_output"] == "approved from provider"
    assert row["artifact"]["metadata"]["cache_status"] == "stored"
    assert row["artifact"]["tool_calls"][0]["name"] == "lookup_policy"
    assert row["artifact"]["cost_estimate"] > 0.0

    def _should_not_hit_network(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("provider cache should satisfy the second run")

    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _should_not_hit_network)

    cached_record, cached_aggregate = run_experiment(tmp_path, "provider-agent", "provider-eval", "smoke")
    cached_row = _run_rows(tmp_path, cached_record.experiment_id)[0]

    assert cached_aggregate["passed_cases"] == 1
    assert cached_row["artifact"]["metadata"]["cache_status"] == "hit"
    assert cached_row["artifact"]["final_output"] == "approved from provider"


def test_provider_adapter_replay_mode_reuses_cached_response_without_network(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_provider_eval(tmp_path)
    _write_provider_agent(tmp_path, cache_mode="auto")
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    monkeypatch.setattr(
        provider_transport.urllib.request,
        "urlopen",
        lambda *_args, **_kwargs: _FakeHTTPResponse(
            {
                "id": "resp_2",
                "choices": [{"message": {"content": "approved from provider"}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 9, "completion_tokens": 6, "total_tokens": 15},
            }
        ),
    )

    run_experiment(tmp_path, "provider-agent", "provider-eval", "smoke")
    _write_provider_agent(tmp_path, cache_mode="replay")

    def _should_not_hit_network(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("provider replay mode should not call the network")

    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _should_not_hit_network)

    record, aggregate = run_experiment(tmp_path, "provider-agent", "provider-eval", "smoke")
    row = _run_rows(tmp_path, record.experiment_id)[0]

    assert aggregate["passed_cases"] == 1
    assert row["artifact"]["metadata"]["cache_status"] == "replay"
    assert row["artifact"]["final_output"] == "approved from provider"


def test_provider_adapter_replay_mode_reports_cache_miss(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_provider_eval(tmp_path)
    _write_provider_agent(tmp_path, cache_mode="replay")
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    def _should_not_hit_network(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("provider replay mode should fail before making a network request")

    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _should_not_hit_network)

    record, aggregate = run_experiment(tmp_path, "provider-agent", "provider-eval", "smoke")
    row = _run_rows(tmp_path, record.experiment_id)[0]

    assert aggregate["passed_cases"] == 0
    assert row["artifact"]["errors"][0].startswith("Provider cache miss for replay mode:")


def test_provider_adapter_recovers_tool_use_failed_generation(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_tool_route_eval(tmp_path)
    _write_provider_agent(tmp_path, cache_mode="auto")
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    def _tool_use_failed(*_args: object, **_kwargs: object) -> None:
        raise TransportError(
            "Provider request failed with HTTP 400",
            http_code=400,
            body=json.dumps(
                {
                    "error": {
                        "message": "Failed to call a function. Please adjust your prompt.",
                        "type": "invalid_request_error",
                        "code": "tool_use_failed",
                        "failed_generation": '<function=lookup_policy>{"query":"refund"}',
                    }
                }
            ),
        )

    monkeypatch.setattr(provider_adapter, "http_request", _tool_use_failed)

    record, aggregate = run_experiment(tmp_path, "provider-agent", "provider-route-eval", "smoke")
    row = _run_rows(tmp_path, record.experiment_id)[0]

    assert aggregate["passed_cases"] == 1
    assert row["artifact"]["errors"] == []
    assert row["artifact"]["tool_calls"][0]["name"] == "lookup_policy"
    assert row["artifact"]["metadata"]["recovered_from_error"] is True
    assert row["artifact"]["metadata"]["recovery_mode"] == "tool_use_failed"
    assert row["artifact"]["metadata"]["recovered_error_code"] == "tool_use_failed"
    labels = [event.get("label") for event in row["artifact"]["trace_events"]]
    assert "provider_response:recovered" in labels
    assert row["artifact"]["metadata"]["cache_status"] == "recovered"


def test_resolve_provider_entrypoint_supports_openai_compatible_alias() -> None:
    spec = AgentSpec(
        id="provider-agent",
        adapter="provider",
        model={"provider": "openai_compatible", "name": "gpt-4.1-mini"},
        entrypoints={
            "provider": {
                "provider": "openai-compatible",
                "base_url": "https://example.test/v1/chat/completions",
                "api_key_env": "EXAMPLE_API_KEY",
            }
        },
    )

    config = provider_adapter.resolve_provider_entrypoint(spec)

    assert config.provider == "openai-compatible"
    assert config.base_url == "https://example.test/v1/chat/completions"
    assert config.api_key_env == "EXAMPLE_API_KEY"


def test_resolve_provider_entrypoint_rejects_anthropic_native_messages_api() -> None:
    spec = AgentSpec(
        id="provider-agent",
        adapter="provider",
        model={"provider": "anthropic", "name": "claude-opus"},
        entrypoints={"provider": {"timeout_seconds": 5}},
    )

    try:
        provider_adapter.resolve_provider_entrypoint(spec)
    except ValueError as exc:
        assert "OpenAI-compatible" in str(exc)
    else:
        raise AssertionError("Expected Anthropic native provider resolution to fail")
