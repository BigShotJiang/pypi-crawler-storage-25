from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

from agentworkbench.ablations import run_surface_ablations
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.factorial import run_factorial_experiments
from agentworkbench.providers import openai_compatible as provider_transport
from agentworkbench.runner import compare_experiments, run_experiment
from agentworkbench.scaffold import init_workbench
from agentworkbench.utils import read_jsonl, write_jsonl, write_text, write_yaml


class _FakeHTTPResponse:

    def __init__(self, payload: dict):
        self._payload = payload

    def __enter__(self) -> _FakeHTTPResponse:
        return self

    def __exit__(self, _exc_type: object, exc: object, _tb: object) -> Literal[False]:
        return False

    def read(self) -> bytes:
        return json.dumps(self._payload).encode("utf-8")


def _prepare_tool_interface_eval(tmp_path: Path, eval_id: str = "provider-tool-interface") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": "tool-refund",
            "input": "A Pro customer renewed 10 days ago and wants a refund. Call the single best tool.",
            "expected": "refund_policy_lookup",
            "tags": ["tools", "refund"],
            "metadata": {
                "required_tool": "refund_policy_lookup",
                "required_argument_keys": ["query"],
                "forbidden_tools": ["incident_playbook_lookup", "customer_history_lookup"],
                "process_expectations": {"required_tools": ["refund_policy_lookup"]},
            },
        },
        {
            "id": "tool-history",
            "input": "VIP customer ACME hit the export bug again. Call the single best tool before answering.",
            "expected": "customer_history_lookup",
            "tags": ["tools", "history"],
            "metadata": {
                "required_tool": "customer_history_lookup",
                "required_argument_keys": ["customer_id", "query"],
                "forbidden_tools": ["refund_policy_lookup", "incident_playbook_lookup"],
                "process_expectations": {"required_tools": ["customer_history_lookup"]},
            },
        },
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "provider-tool-interface",
            "approval_status": "approved",
            "score_weights": {"output_quality": 0.7, "process_alignment": 0.3},
            "notes": ["Provider-adapter benchmark for tool-interface experiments."],
            "generated_case_count": len(cases),
            "tags": ["tools", "provider"],
        },
    )
    write_yaml(control / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["tool-refund"], "full": [case["id"] for case in cases]})
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "import json",
                "",
                "def score_cases(run_artifact: dict, case: dict) -> list[dict]:",
                "    metadata = case.get('metadata') or {}",
                "    tool_calls = [item for item in (run_artifact.get('tool_calls') or []) if isinstance(item, dict)]",
                "    first = tool_calls[0] if tool_calls else {}",
                "    required_tool = str(metadata.get('required_tool') or '')",
                "    required_argument_keys = [str(item) for item in metadata.get('required_argument_keys', []) if str(item).strip()]",
                "    forbidden_tools = {str(item) for item in metadata.get('forbidden_tools', []) if str(item).strip()}",
                "    chosen_tool = str(first.get('name') or '')",
                "    arguments = {}",
                "    raw_arguments = str(first.get('arguments') or '').strip()",
                "    if raw_arguments:",
                "        try:",
                "            parsed = json.loads(raw_arguments)",
                "            if isinstance(parsed, dict):",
                "                arguments = parsed",
                "        except json.JSONDecodeError:",
                "            arguments = {}",
                "    missing_keys = [key for key in required_argument_keys if key not in arguments or arguments.get(key) in ('', None)]",
                "    tool_match = chosen_tool == required_tool and chosen_tool not in forbidden_tools",
                "    args_match = tool_match and not missing_keys",
                "    return [",
                "        {",
                "            'name': 'output_quality',",
                "            'value': 1.0 if tool_match else 0.0,",
                "            'passed': tool_match,",
                "            'reason': 'matched required tool' if tool_match else f'required {required_tool}, got {chosen_tool or \"none\"}',",
                "        },",
                "        {",
                "            'name': 'process_alignment',",
                "            'value': 1.0 if args_match else 0.0,",
                "            'passed': args_match,",
                "            'reason': 'arguments matched schema contract' if args_match else ('missing argument keys: ' + ', '.join(missing_keys) if missing_keys else 'tool selection failed'),",
                "        },",
                "    ]",
                "",
            ]
        ),
    )


def _write_provider_tool_agent(tmp_path: Path, *, agent_id: str, provider: str, model_name: str, model_id: str, tool_format: str = "full") -> None:
    prompt_dir = tmp_path / "prompts"
    prompt_dir.mkdir(exist_ok=True)
    write_text(
        prompt_dir / "system.md",
        "\n".join(
            [
                "Select exactly one function tool.",
                "Do not write any natural-language answer.",
                "Pick the tool whose purpose best matches the user request and provide the needed arguments.",
            ]
        )
        + "\n",
    )
    spec = {
        "id": agent_id,
        "adapter": "provider",
        "instructions": ["Return only the single best tool call."],
        "prompts": {"system": "prompts/system.md"},
        "model": {
            "provider": provider,
            "name": model_name,
            "model_id": model_id,
            "temperature": 0,
            "max_tokens": 64,
            "tool_choice": "required",
            "parallel_tool_calls": False,
        },
        "tools": [
            {
                "name": "refund_policy_lookup",
                "enabled": True,
                "description": "Use for account lookups. Choose this when the user asks about refund eligibility or billing policy.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Refund or billing-policy search query.",
                        }
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
            },
            {
                "name": "incident_playbook_lookup",
                "enabled": True,
                "description": "Use for account lookups. Choose this when the user asks about outages or incident response.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Incident or outage search query.",
                        }
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
            },
            {
                "name": "customer_history_lookup",
                "enabled": True,
                "description": "Use for account lookups. Choose this when the user asks about VIP history or repeat-customer context.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "Stable customer identifier such as acme-vip.",
                        },
                        "query": {
                            "type": "string",
                            "description": "Question about prior history or repeat-contact context.",
                        },
                    },
                    "required": ["customer_id", "query"],
                    "additionalProperties": False,
                },
            },
        ],
        "skills": [],
        "plugins": [],
        "mcps": [],
        "required_env": [f"{provider.upper()}_API_KEY"],
        "runtime": {"env": {}},
        "entrypoints": {"provider": {"timeout_seconds": 5, "cache_mode": "off", "tool_format": tool_format}},
        "metadata": {"owner": "tests"},
    }
    write_yaml(tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml", spec)


def _fake_provider_urlopen(request: Any, timeout: int = 0, context: object = None) -> _FakeHTTPResponse:
    del timeout, context
    body = json.loads(request.data.decode("utf-8"))
    messages = body.get("messages") or []
    user_content = str(messages[-1].get("content") or "").lower() if messages else ""
    tools = {item["function"]["name"]: item["function"] for item in body.get("tools") or [] if isinstance(item, dict)}

    def _description(name: str) -> str:
        return str((tools.get(name) or {}).get("description") or "").lower()

    def _schema(name: str) -> dict:
        schema = (tools.get(name) or {}).get("parameters") or {}
        return schema if isinstance(schema, dict) else {}

    tool_name = "refund_policy_lookup"
    arguments: dict[str, str] = {"query": "refund eligibility"}
    if "refund" in user_content:
        if "refund eligibility" not in _description("refund_policy_lookup"):
            tool_name = "incident_playbook_lookup"
            arguments = {"query": "refund question"}
    elif "vip customer acme" in user_content:
        history_description = _description("customer_history_lookup")
        history_schema = _schema("customer_history_lookup")
        required = [str(item) for item in history_schema.get("required", [])]
        properties = {str(key) for key in (history_schema.get("properties") or {}).keys()}
        if "repeat-customer context" in history_description and "customer_id" in required and "customer_id" in properties:
            tool_name = "customer_history_lookup"
            arguments = {"customer_id": "acme-vip", "query": "repeat export bug"}
        elif "customer_id" in properties:
            tool_name = "customer_history_lookup"
            arguments = {"query": "repeat export bug"}
        else:
            tool_name = "refund_policy_lookup"
            arguments = {"query": "vip history"}
    return _FakeHTTPResponse(
        {
            "id": "tool_iface_resp",
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "call_1",
                                "type": "function",
                                "function": {
                                    "name": tool_name,
                                    "arguments": json.dumps(arguments),
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 25, "completion_tokens": 8, "total_tokens": 33},
        }
    )


def test_provider_tool_interface_surfaces_support_ablations_and_factorials(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_tool_interface_eval(tmp_path)
    _write_provider_tool_agent(
        tmp_path,
        agent_id="provider-interface-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _fake_provider_urlopen)

    baseline_record, aggregate = run_experiment(tmp_path, "provider-interface-agent", "provider-tool-interface", "full")
    assert aggregate["passed_cases"] == 2

    ablations = run_surface_ablations(
        tmp_path,
        experiment_id=baseline_record.experiment_id,
        surfaces=["tool_docstrings", "tool_schemas", "tool_formats"],
    )
    assert {item["surface_kind"] for item in ablations["results"]} >= {"tool_docstrings", "tool_schemas", "tool_formats"}
    refund_docstrings = next(
        item for item in ablations["results"] if item["surface_kind"] == "tool_docstrings" and item["surface_name"] == "refund_policy_lookup"
    )
    history_schema = next(
        item for item in ablations["results"] if item["surface_kind"] == "tool_schemas" and item["surface_name"] == "customer_history_lookup"
    )
    tool_format = next(item for item in ablations["results"] if item["surface_kind"] == "tool_formats")
    assert refund_docstrings["average_score_delta"] < 0.0
    assert history_schema["average_score_delta"] < 0.0
    assert tool_format["average_score_delta"] < 0.0

    factorial = run_factorial_experiments(
        tmp_path,
        experiment_id=baseline_record.experiment_id,
        factors=[
            "tool_docstrings:refund_policy_lookup",
            "tool_schemas:customer_history_lookup",
            "tool_formats:full",
        ],
    )
    assert factorial["selected_factors"] == [
        "tool_docstrings:refund_policy_lookup",
        "tool_schemas:customer_history_lookup",
        "tool_formats:full",
    ]
    assert {item["factor"] for item in factorial["factor_effects"]} == {
        "tool_docstrings:refund_policy_lookup",
        "tool_schemas:customer_history_lookup",
        "tool_formats:full",
    }
    assert {item["surface"] for item in factorial["surface_recommendations"]} >= {
        "tool_docstrings:refund_policy_lookup",
        "tool_schemas:customer_history_lookup",
        "tool_formats:full",
    }


def test_compare_reports_tool_interface_detail_changes(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_tool_interface_eval(tmp_path)
    _write_provider_tool_agent(
        tmp_path,
        agent_id="provider-interface-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    _write_provider_tool_agent(
        tmp_path,
        agent_id="provider-interface-agent-compact",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        tool_format="compact",
    )
    compact_spec = tmp_path / CONTROL_DIR_NAME / "agents" / "provider-interface-agent-compact.yaml"
    compact_spec.write_text(
        compact_spec.read_text(encoding="utf-8").replace(
            "Choose this when the user asks about refund eligibility or billing policy.",
            "Choose this when the user asks about refund eligibility, billing policy, or refund exceptions.",
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.setattr(provider_transport.urllib.request, "urlopen", _fake_provider_urlopen)

    baseline_record, _aggregate = run_experiment(tmp_path, "provider-interface-agent", "provider-tool-interface", "full")
    candidate_record, _aggregate = run_experiment(tmp_path, "provider-interface-agent-compact", "provider-tool-interface", "full")
    comparison = compare_experiments(tmp_path, baseline_record.experiment_id, candidate_record.experiment_id)

    assert any(".description" in item for item in comparison.surface_detail_changes["tool_docstring_changes"])
    assert comparison.surface_detail_changes["tool_schema_changes"]
    assert comparison.surface_detail_changes["tool_format_changes"]
    rows = read_jsonl(tmp_path / CONTROL_DIR_NAME / "runs" / candidate_record.experiment_id / "runs.jsonl")
    assert rows[0]["artifact"]["tool_calls"][0]["name"]
