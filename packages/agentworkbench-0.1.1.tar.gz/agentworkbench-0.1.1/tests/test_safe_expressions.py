from __future__ import annotations

import ast
from typing import cast

import pytest

from agentworkbench.chain import _evaluate_branch_condition
from agentworkbench.safe_expressions import (
    UnsafeExpressionError,
    _evaluate_comparison,
    _evaluate_node,
    evaluate_condition,
)
from agentworkbench.workflow import _evaluate_workflow_edge


def test_evaluate_condition_supports_safe_boolean_expressions() -> None:
    assert evaluate_condition("prior_score >= 0.5 and prior_passed", {"prior_score": 0.8, "prior_passed": True}) is True
    assert evaluate_condition("route in ('refund', 'both')", {"route": "both"}) is True
    assert evaluate_condition("not prior_passed", {"prior_passed": False}) is True


def test_evaluate_condition_supports_collection_identity_and_falsey_paths() -> None:
    marker = object()

    assert evaluate_condition("route in ['refund', 'both']", {"route": "refund"}) is True
    assert evaluate_condition("route not in {'cancel'}", {"route": "refund"}) is True
    assert evaluate_condition("current is marker", {"current": marker, "marker": marker}) is True
    assert evaluate_condition("current is not marker", {"current": object(), "marker": marker}) is True
    assert evaluate_condition("3 < 2", {}) is False
    assert evaluate_condition("1 < 2 <= 2", {}) is True


def test_evaluate_condition_reports_syntax_and_unknown_variable_errors() -> None:
    with pytest.raises(UnsafeExpressionError, match="Invalid condition expression"):
        evaluate_condition("route ==", {"route": "refund"})

    with pytest.raises(UnsafeExpressionError, match="Unknown variable"):
        evaluate_condition("missing == 1", {})


def test_evaluate_condition_rejects_calls_and_attributes() -> None:
    with pytest.raises(UnsafeExpressionError):
        evaluate_condition("__import__('os').system('echo nope')", {})

    with pytest.raises(UnsafeExpressionError):
        evaluate_condition("context.value == 1", {"context": {"value": 1}})


def test_safe_expression_helpers_reject_unsupported_ast_nodes() -> None:
    invalid_bool = ast.BoolOp(op=ast.And(), values=[ast.Constant(value=True), ast.Constant(value=False)])
    invalid_bool.op = cast(ast.boolop, ast.BitAnd())
    with pytest.raises(UnsafeExpressionError, match="Unsupported boolean operator"):
        _evaluate_node(invalid_bool, {})

    invalid_unary = ast.UnaryOp(op=ast.USub(), operand=ast.Constant(value=1))
    with pytest.raises(UnsafeExpressionError, match="Unsupported unary operator"):
        _evaluate_node(invalid_unary, {})

    invalid_compare = ast.Compare(
        left=ast.Constant(value=1),
        ops=[cast(ast.cmpop, ast.Add())],
        comparators=[ast.Constant(value=2)],
    )
    with pytest.raises(UnsafeExpressionError, match="Unsupported comparison operator"):
        _evaluate_comparison(invalid_compare, {})

    with pytest.raises(UnsafeExpressionError, match="Unsupported expression node"):
        _evaluate_node(ast.BinOp(left=ast.Constant(value=1), op=ast.Add(), right=ast.Constant(value=2)), {})


def test_chain_branch_conditions_fail_open_on_invalid_expression() -> None:
    assert _evaluate_branch_condition(None, {"score": 0.7, "passed": True}) is True
    assert _evaluate_branch_condition("prior_score >= 0.5", None) is True
    assert _evaluate_branch_condition("prior_score >= 0.5", {"score": 0.7, "passed": True}) is True
    assert _evaluate_branch_condition("__import__('os').system('echo nope')", {"score": 0.1, "passed": False}) is True


def test_workflow_edges_fail_closed_on_invalid_expression() -> None:
    assert _evaluate_workflow_edge(None, {"route": "refund"}) is True
    assert _evaluate_workflow_edge("route == 'refund'", {"route": "refund"}) is True
    assert _evaluate_workflow_edge("__import__('os').system('echo nope')", {"route": "refund"}) is False
