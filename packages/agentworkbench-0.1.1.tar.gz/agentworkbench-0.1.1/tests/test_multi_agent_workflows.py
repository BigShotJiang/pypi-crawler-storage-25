from __future__ import annotations

import io
import json
import os
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from typing import Any

from agentworkbench.adapters import provider as provider_adapter
from agentworkbench.cli import main
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.providers.openai_compatible import TransportError
from agentworkbench.runner_diagnosis import diagnose_experiment
from agentworkbench.scaffold import init_workbench
from agentworkbench.utils import read_json, read_jsonl, write_jsonl, write_text, write_yaml
from agentworkbench.workflow import run_workflow_experiment


def _run_capture(tmp_path: Path, *args: str) -> tuple[int, str, str]:
    cwd = os.getcwd()
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    os.chdir(tmp_path)
    try:
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            code = main(list(args))
    finally:
        os.chdir(cwd)
    return code, stdout_buffer.getvalue(), stderr_buffer.getvalue()


def _write_command_agent(tmp_path: Path, agent_id: str, script: str) -> None:
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml",
        {
            "id": agent_id,
            "adapter": "command",
            "instructions": [],
            "prompts": {"system": "Use the workflow contract."},
            "model": {"name": "fixture-model"},
            "tools": [],
            "skills": [],
            "plugins": [],
            "mcps": [],
            "runtime": {"env": {}},
            "entrypoints": {
                "command": {
                    "argv": ["python3", "-c", script],
                    "cwd": ".",
                    "timeout_seconds": 10,
                }
            },
            "metadata": {"owner": "tests"},
        },
    )


def _prepare_workflow_fixture(tmp_path: Path, eval_id: str = "workflow-routing") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": "route-refund",
            "input": "A customer renewed yesterday and wants a refund.",
            "expected": "refund lane approved",
            "metadata": {"expected_route": "refund", "expected_terminal_node": "refund-specialist"},
            "tags": ["workflow", "refund"],
        },
        {
            "id": "route-incident",
            "input": "Export jobs are stuck and this looks like an incident.",
            "expected": "incident lane approved",
            "metadata": {"expected_route": "incident", "expected_terminal_node": "incident-specialist"},
            "tags": ["workflow", "incident"],
        },
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "workflow-routing",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": ["Workflow routing regression fixture."],
            "generated_case_count": len(cases),
            "tags": ["workflow"],
        },
    )
    write_yaml(control / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["route-refund"], "full": [case["id"] for case in cases]})
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "import json",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    metadata = case.get('metadata') or {}",
                "    mode = str(metadata.get('scoring_mode') or '').strip().lower()",
                "    final_output = str(run_artifact.get('final_output') or '').strip()",
                "    if mode == 'route':",
                "        route = ''",
                "        try:",
                "            payload = json.loads(final_output)",
                "            if isinstance(payload, dict):",
                "                route = str(payload.get('route') or '').strip()",
                "        except json.JSONDecodeError:",
                "            route = ''",
                "        expected_route = str(metadata.get('expected_route') or '').strip()",
                "        passed = route == expected_route and bool(route)",
                "        return {",
                "            'name': 'output_quality',",
                "            'value': 1.0 if passed else 0.0,",
                "            'passed': passed,",
                "            'reason': 'matched expected route' if passed else f'expected route {expected_route}, got {route or \"none\"}',",
                "        }",
                "    expected = str(case.get('expected') or '').strip().lower()",
                "    passed = expected in final_output.lower()",
                "    return {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if passed else 0.0,",
                "        'passed': passed,",
                "        'reason': 'expected text present' if passed else 'expected text missing',",
                "    }",
                "",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "router-agent",
        "\n".join(
            [
                "import json, os",
                "text = os.environ.get('AWB_INPUT', '').lower()",
                "route = 'incident' if 'incident' in text or 'stuck' in text else 'refund'",
                "payload = {'final_output': json.dumps({'route': route}), 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "refund-agent",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': 'refund lane approved', 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "incident-agent",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': 'incident lane approved', 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    write_yaml(
        control / "workflows" / "router-workflow.yaml",
        {
            "id": "router-workflow",
            "start_at": "router",
            "max_steps_per_case": 3,
            "nodes": [
                {"id": "router", "agent_id": "router-agent", "step_expectations": {"scoring_mode": "route"}},
                {"id": "refund-specialist", "agent_id": "refund-agent"},
                {"id": "incident-specialist", "agent_id": "incident-agent"},
            ],
            "edges": [
                {"from": "router", "to": "refund-specialist", "when": "route == 'refund'", "label": "refund-route"},
                {"from": "router", "to": "incident-specialist", "when": "route == 'incident'", "label": "incident-route"},
            ],
        },
    )


def _write_provider_router_agent(tmp_path: Path, agent_id: str = "router-agent") -> None:
    write_text(tmp_path / "prompts" / "provider-router-system.md", "Select exactly one route tool and no prose.\n")
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml",
        {
            "id": agent_id,
            "adapter": "provider",
            "instructions": ["Return exactly one route tool call and no prose."],
            "prompts": {"system": "prompts/provider-router-system.md"},
            "model": {
                "provider": "groq",
                "name": "groq/llama-3.1-8b-instant",
                "model_id": "llama-3.1-8b-instant",
                "temperature": 0,
                "max_tokens": 64,
                "tool_choice": "required",
                "parallel_tool_calls": False,
            },
            "tools": [
                {
                    "name": "refund",
                    "enabled": True,
                    "description": "Choose this for refund requests.",
                    "parameters": {"type": "object", "properties": {"reason": {"type": "string"}}},
                },
                {
                    "name": "incident",
                    "enabled": True,
                    "description": "Choose this for incidents.",
                    "parameters": {"type": "object", "properties": {"reason": {"type": "string"}}},
                },
            ],
            "skills": [],
            "plugins": [],
            "mcps": [],
            "required_env": ["GROQ_API_KEY"],
            "runtime": {"env": {}},
            "entrypoints": {
                "provider": {
                    "timeout_seconds": 5,
                    "cache_mode": "off",
                }
            },
            "metadata": {"owner": "tests"},
        },
    )


def _prepare_graph_workflow_fixture(tmp_path: Path, eval_id: str = "workflow-graph") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": "graph-case-1",
            "input": "Triage this issue using both refund and risk lanes.",
            "expected": "refund facts risk facts",
            "metadata": {},
            "tags": ["workflow", "graph"],
        }
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "workflow-graph",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": ["Graph workflow regression fixture."],
            "generated_case_count": len(cases),
            "tags": ["workflow", "graph"],
        },
    )
    write_yaml(control / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["graph-case-1"], "full": ["graph-case-1"]})
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "import json",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    metadata = case.get('metadata') or {}",
                "    mode = str(metadata.get('scoring_mode') or '').strip().lower()",
                "    final_output = str(run_artifact.get('final_output') or '').lower()",
                "    if mode == 'route':",
                "        route = ''",
                "        try:",
                "            payload = json.loads(str(run_artifact.get('final_output') or '{}'))",
                "            if isinstance(payload, dict):",
                "                route = str(payload.get('route') or '').strip()",
                "        except json.JSONDecodeError:",
                "            route = ''",
                "        expected_route = str(metadata.get('expected_route') or '').strip()",
                "        passed = route == expected_route and bool(route)",
                "        return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'matched expected route' if passed else f'expected route {expected_route}, got {route or \"none\"}'}",
                "    passed = 'refund facts' in final_output and 'risk facts' in final_output",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'combined branch outputs present' if passed else 'missing combined branch outputs'}",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "graph-router",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': json.dumps({'route': 'both'}), 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "refund-worker",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': 'refund facts', 'step_count': 1, 'structured_output': {'shared_context_updates': {'refund_status': 'ready'}}}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "risk-worker",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': 'risk facts', 'step_count': 1, 'structured_output': {'shared_context_updates': {'risk_status': 'ready'}}}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "synth-agent",
        "\n".join(
            [
                "import json, os",
                "text = os.environ.get('AWB_INPUT', '')",
                "payload = {'final_output': text, 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    write_yaml(
        control / "workflows" / "graph-workflow.yaml",
        {
            "id": "graph-workflow",
            "start_at": "router",
            "max_steps_per_case": 6,
            "nodes": [
                {
                    "id": "router",
                    "agent_id": "graph-router",
                    "routing_mode": "all",
                    "step_expectations": {"scoring_mode": "route", "expected_route": "both"},
                },
                {"id": "refund-worker", "agent_id": "refund-worker"},
                {"id": "risk-worker", "agent_id": "risk-worker"},
                {"id": "synth", "agent_id": "synth-agent", "join_mode": "all", "handoff_template": "Shared:{shared_context}\n{prior_output}"},
            ],
            "edges": [
                {"from": "router", "to": "refund-worker", "when": "route in ('refund', 'both')", "label": "refund-path"},
                {"from": "router", "to": "risk-worker", "when": "route in ('risk', 'both')", "label": "risk-path"},
                {"from": "refund-worker", "to": "synth", "label": "merge-refund"},
                {"from": "risk-worker", "to": "synth", "label": "merge-risk"},
            ],
        },
    )


def _prepare_nested_chain_workflow_fixture(tmp_path: Path, eval_id: str = "workflow-nested-chain") -> None:
    control = tmp_path / CONTROL_DIR_NAME
    cases = [
        {
            "id": "nested-refund",
            "input": "A customer needs a refund workflow.",
            "expected": "refund draft reviewed",
            "metadata": {"expected_route": "refund"},
            "tags": ["workflow", "nested"],
        }
    ]
    write_jsonl(control / "evals" / f"{eval_id}.jsonl", cases)
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "workflow-nested",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": ["Nested chain workflow regression fixture."],
            "generated_case_count": len(cases),
            "tags": ["workflow", "nested"],
        },
    )
    write_yaml(control / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["nested-refund"], "full": ["nested-refund"]})
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    final_output = str(run_artifact.get('final_output') or '').lower()",
                "    passed = 'refund draft reviewed' in final_output",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'nested chain output present' if passed else 'nested chain output missing'}",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "nested-router",
        "\n".join(
            [
                "import json",
                "payload = {'final_output': json.dumps({'route': 'refund'}), 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(__import__('os').environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "refund-drafter",
        "\n".join(
            [
                "import json",
                "payload = {'final_output': 'refund draft', 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(__import__('os').environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    _write_command_agent(
        tmp_path,
        "refund-reviewer",
        "\n".join(
            [
                "import json, os",
                "payload = {'final_output': f\"{os.environ.get('AWB_INPUT', '').strip()} reviewed\", 'step_count': 1, 'prompt_keys_used': ['system']}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    write_yaml(
        control / "workflows" / "nested-chain-workflow.yaml",
        {
            "id": "nested-chain-workflow",
            "start_at": "router",
            "max_steps_per_case": 4,
            "nodes": [
                {"id": "router", "agent_id": "nested-router"},
                {
                    "id": "refund-chain",
                    "node_type": "chain",
                    "chain_agent_ids": ["refund-drafter", "refund-reviewer"],
                    "chain_handoff_template": "{prior_output}",
                },
            ],
            "edges": [
                {"from": "router", "to": "refund-chain", "when": "route == 'refund'", "label": "refund-route"},
            ],
        },
    )


def test_run_workflow_routes_cases_and_diagnoses_paths(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _prepare_workflow_fixture(tmp_path)

    record, aggregate = run_workflow_experiment(tmp_path, "router-workflow", "workflow-routing", "full")

    assert aggregate["average_score"] == 1.0
    workflow_aggregate = aggregate["workflow_aggregate"]
    assert workflow_aggregate["average_workflow_step_pass_rate"] == 1.0
    assert workflow_aggregate["workflow_path_counts"] == {
        "router -> refund-specialist": 1,
        "router -> incident-specialist": 1,
    }
    assert workflow_aggregate["workflow_route_counts"] == {"incident-route": 1, "refund-route": 1}

    diagnosis = diagnose_experiment(tmp_path, experiment_id=record.experiment_id)
    assert diagnosis["workflow_diagnosis"]["is_workflow_run"] is True
    assert diagnosis["workflow_diagnosis"]["path_counts"] == {
        "router -> refund-specialist": 1,
        "router -> incident-specialist": 1,
    }
    assert diagnosis["workflow_diagnosis"]["route_counts"] == {"incident-route": 1, "refund-route": 1}

    report_text = (
        tmp_path / CONTROL_DIR_NAME / "reports" / f"diagnose-{record.experiment_id}.md"
    ).read_text(encoding="utf-8")
    assert "## Workflow Diagnosis" in report_text
    experiment_payload = read_json(tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "experiment.json")
    assert experiment_payload["spec_snapshot"]["workflow_file"] == ".agent-workbench/workflows/router-workflow.yaml"


def test_run_workflow_supports_fan_out_join_and_shared_context(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _prepare_graph_workflow_fixture(tmp_path)

    record, aggregate = run_workflow_experiment(tmp_path, "graph-workflow", "workflow-graph", "full")

    assert aggregate["average_score"] == 1.0
    workflow_aggregate = aggregate["workflow_aggregate"]
    assert workflow_aggregate["workflow_fan_out_count"] == 1
    assert workflow_aggregate["workflow_join_count"] == 1
    assert {"refund_status", "risk_status"} <= set(workflow_aggregate["workflow_shared_context_keys"])

    diagnosis = diagnose_experiment(tmp_path, experiment_id=record.experiment_id)

    assert diagnosis["workflow_diagnosis"]["fan_out_total"] == 1
    assert diagnosis["workflow_diagnosis"]["join_total"] == 1
    assert {"refund_status", "risk_status"} <= set(diagnosis["workflow_diagnosis"]["shared_context_keys"])
    assert diagnosis["workflow_diagnosis"]["dead_end_cases"] == []


def test_run_workflow_supports_nested_chain_nodes(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _prepare_nested_chain_workflow_fixture(tmp_path)

    record, aggregate = run_workflow_experiment(tmp_path, "nested-chain-workflow", "workflow-nested-chain", "full")

    assert aggregate["average_score"] == 1.0
    rows = read_jsonl(tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl")
    artifact = rows[0]["artifact"]
    assert artifact["final_output"] == "refund draft reviewed"
    assert artifact["metadata"]["nested_chain"]["agent_ids"] == ["refund-drafter", "refund-reviewer"]
    workflow_steps = artifact["metadata"]["workflow_steps"]
    assert workflow_steps[1]["node_type"] == "chain"
    assert workflow_steps[1]["agent_id"] == "refund-drafter -> refund-reviewer"


def test_cli_run_workflow_accepts_workflow_id(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _prepare_workflow_fixture(tmp_path)

    code, stdout, stderr = _run_capture(
        tmp_path,
        "run-workflow",
        "--workflow-file",
        "router-workflow",
        "--eval-id",
        "workflow-routing",
        "--subset",
        "full",
    )

    assert code == 0, stderr
    payload = json.loads(stdout)
    assert payload["experiment"]["agent_id"] == "router-workflow"
    assert payload["experiment"]["subset"] == "full"


def test_workflow_recovers_tool_use_failed_router_step(tmp_path: Path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_workflow_fixture(tmp_path)
    _write_provider_router_agent(tmp_path)
    monkeypatch.setenv("GROQ_API_KEY", "test-key")

    def _fake_http_request(_url: str, body: dict[str, Any], _headers: dict[str, str], _timeout: int) -> dict[str, Any]:
        messages = body.get("messages") or []
        text = "\n".join(str(item.get("content") or "") for item in messages if isinstance(item, dict)).lower()
        if "refund" in text:
            raise TransportError(
                "Provider request failed with HTTP 400",
                http_code=400,
                body=json.dumps(
                    {
                        "error": {
                            "message": "Failed to call a function. Please adjust your prompt.",
                            "type": "invalid_request_error",
                            "code": "tool_use_failed",
                            "failed_generation": '<function=refund>{"reason":"refund request"}',
                        }
                    }
                ),
            )
        return {
            "id": "resp_incident",
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "call_1",
                                "type": "function",
                                "function": {
                                    "name": "incident",
                                    "arguments": '{"reason":"incident request"}',
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 12, "completion_tokens": 4, "total_tokens": 16},
        }

    monkeypatch.setattr(provider_adapter, "http_request", _fake_http_request)

    record, aggregate = run_workflow_experiment(tmp_path, "router-workflow", "workflow-routing", "full")

    assert aggregate["average_score"] == 1.0
    workflow_aggregate = aggregate["workflow_aggregate"]
    assert workflow_aggregate["workflow_route_counts"] == {
        "incident-route": 1,
        "refund-route": 1,
    }
    assert workflow_aggregate["workflow_unmatched_route_count"] == 0

    diagnosis = diagnose_experiment(tmp_path, experiment_id=record.experiment_id)
    assert diagnosis["workflow_diagnosis"]["provider_recovery_counts"] == {"router": 1}
    assert diagnosis["workflow_diagnosis"]["provider_recoveries"] == [
        {"case_id": "route-refund", "node_id": "router", "agent_id": "router-agent"}
    ]
