from __future__ import annotations

import io
import json
import os
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from agentworkbench.cli import main
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.loop_checks import build_loop_check_report
from agentworkbench.runner import run_experiment
from agentworkbench.runner_compare import promote_experiment
from agentworkbench.scaffold import init_workbench
from agentworkbench.utils import read_yaml, write_jsonl, write_text, write_yaml


def _run_capture(tmp_path: Path, *args: str) -> tuple[int, str, str]:
    cwd = os.getcwd()
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    os.chdir(tmp_path)
    try:
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            code = main(list(args))
    finally:
        os.chdir(cwd)
    return code, stdout_buffer.getvalue(), stderr_buffer.getvalue()


def _write_eval(tmp_path: Path, *, eval_id: str = "loop-eval", process: dict | None = None, expected: str = "general answer", tags: list[str] | None = None) -> None:
    control = tmp_path / CONTROL_DIR_NAME
    write_jsonl(
        control / "evals" / f"{eval_id}.jsonl",
        [
            {
                "id": "case-1",
                "input": "Handle the request",
                "expected": expected,
                "rubric": [],
                "tags": tags or ["full"],
                "metadata": {"process_expectations": process or {}},
            }
        ],
    )
    write_yaml(
        control / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "generated_case_count": 1,
            "tags": tags or ["full"],
        },
    )
    write_yaml(control / "evals" / f"{eval_id}.splits.yaml", {"full": ["case-1"], "smoke": ["case-1"]})
    write_text(
        control / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "def score_case(run_artifact, case):",
                "    passed = str(case.get('expected') or '') in str(run_artifact.get('final_output') or '')",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'ok' if passed else 'missing'}",
            ]
        ),
    )


def _write_agent(tmp_path: Path, *, agent_id: str = "loop-agent", runtime_text: str = "print('agent')\n", tools: list[dict] | None = None) -> None:
    runtime = tmp_path / "target_agent" / "runtime.py"
    runtime.parent.mkdir(parents=True, exist_ok=True)
    write_text(runtime, runtime_text)
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml",
        {
            "id": agent_id,
            "adapter": "command",
            "instructions": [],
            "prompts": {"system": "target_agent/system.md"},
            "model": {"name": "fixture"},
            "tools": tools or [],
            "skills": [],
            "plugins": [],
            "mcps": [],
            "owned_paths": ["target_agent/runtime.py"],
            "surface_paths": {"runtime": ["target_agent/runtime.py"]},
            "runtime": {"env": {}},
            "entrypoints": {"command": {"argv": ["python3", "target_agent/runtime.py"], "cwd": ".", "timeout_seconds": 10}},
            "metadata": {},
        },
    )


def _categories(payload: dict) -> set[str]:
    return {item["category"] for item in payload["findings"]}


def test_check_flags_large_target_file(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    config_path = tmp_path / CONTROL_DIR_NAME / "workbench.yaml"
    config = read_yaml(config_path)
    config["loop_checks"] = {"large_file_line_threshold": 5}
    write_yaml(config_path, config)
    _write_agent(tmp_path, runtime_text="\n".join(f"print({i})" for i in range(12)))

    payload = build_loop_check_report(tmp_path, agent_id="loop-agent", fail_on="none")

    assert "code_structure" in _categories(payload)
    assert any(item["id"].startswith("code_structure.large_target_file") for item in payload["findings"])


def test_eval_contract_requires_rationale_and_declared_tool(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_agent(tmp_path, tools=[{"name": "repo_search", "enabled": True}])
    _write_eval(tmp_path, process={"required_tools": ["repo_search"]})

    payload = build_loop_check_report(tmp_path, agent_id="loop-agent", eval_id="loop-eval", subset="full", fail_on="none")
    assert any(item["category"] == "eval_contract" and item["severity"] == "medium" for item in payload["findings"])

    _write_eval(
        tmp_path,
        process={"required_tools": ["repo_search"], "rationales": {"required_tools": {"repo_search": "The case requires repository lookup evidence."}}},
    )
    payload = build_loop_check_report(tmp_path, agent_id="loop-agent", eval_id="loop-eval", subset="full", fail_on="none")
    assert not any(item["category"] == "eval_contract" and item["severity"] == "medium" for item in payload["findings"])


def test_eval_contract_flags_required_tool_missing_from_agent(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_agent(tmp_path)
    _write_eval(
        tmp_path,
        process={"required_tools": ["repo_search"], "rationale": "The answer must use repository evidence."},
    )

    payload = build_loop_check_report(tmp_path, agent_id="loop-agent", eval_id="loop-eval", subset="full", fail_on="none")

    assert any(item["category"] == "eval_contract" and item["severity"] == "high" for item in payload["findings"])


def test_deterministic_fallback_flags_expected_string_but_ignores_eval_files(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_eval(tmp_path, expected="secret benchmark answer")
    _write_agent(
        tmp_path,
        runtime_text="import json, os\npayload = {'final_output': 'secret benchmark answer'}\nopen(os.environ['AWB_OUTPUT_PATH'], 'w').write(json.dumps(payload))\n",
    )

    code, stdout, stderr = _run_capture(
        tmp_path,
        "check",
        "--agent-id",
        "loop-agent",
        "--eval-id",
        "loop-eval",
        "--subset",
        "full",
        "--format",
        "json",
    )

    assert code == 1, stderr
    payload = json.loads(stdout)
    assert any(item["category"] == "deterministic_fallback" and item["severity"] == "critical" for item in payload["findings"])


def test_topology_checks_cover_over_and_under_delegation(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_agent(tmp_path, agent_id="agent-a")
    _write_agent(tmp_path, agent_id="agent-b")
    _write_eval(tmp_path)

    payload = build_loop_check_report(
        tmp_path,
        chain_agent_ids=["agent-a", "agent-b"],
        eval_id="loop-eval",
        subset="full",
        fail_on="none",
    )
    assert any(item["category"] == "agent_topology" and item["severity"] == "warning" for item in payload["findings"])

    _write_eval(tmp_path, tags=["workflow"], process={"required_workflow_steps": ["route"], "rationale": "The case must route to the right specialist."})
    payload = build_loop_check_report(tmp_path, agent_id="agent-a", eval_id="loop-eval", subset="full", fail_on="none")
    assert any(item["category"] == "agent_topology" and item["severity"] == "medium" for item in payload["findings"])


def test_promotion_blocks_critical_loop_readiness_findings(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_eval(tmp_path, expected="exact promoted answer")
    _write_agent(
        tmp_path,
        runtime_text="import json, os\npayload = {'final_output': 'exact promoted answer'}\nopen(os.environ['AWB_OUTPUT_PATH'], 'w').write(json.dumps(payload))\n",
    )

    record, _aggregate = run_experiment(tmp_path, "loop-agent", "loop-eval", "full")
    result = promote_experiment(tmp_path, record.experiment_id)

    assert result["promotion_status"] == "rejected"
    assert result["gate_results"]["loop_readiness"]["passed"] is False


def test_check_text_output_and_run_workflow_alias_help(tmp_path: Path) -> None:
    init_workbench(tmp_path)
    _write_agent(tmp_path)
    code, stdout, stderr = _run_capture(tmp_path, "check", "--agent-id", "loop-agent", "--format", "text", "--fail-on", "none")

    assert code == 0, stderr
    assert "Agent Loop Readiness Check" in stdout

    help_text = main(["run-workflow", "--help"])
    assert help_text == 0
