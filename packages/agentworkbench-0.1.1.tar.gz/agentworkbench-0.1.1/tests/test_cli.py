from __future__ import annotations

import io
import json
import os
import time
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest.mock import patch

from agentworkbench.cli import main
from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.utils import read_yaml, write_json, write_yaml


def _run(tmp_path: Path, *args: str) -> int:
    cwd = os.getcwd()
    os.chdir(tmp_path)
    try:
        return main(list(args))
    finally:
        os.chdir(cwd)


def _run_capture(tmp_path: Path, *args: str) -> tuple[int, str, str]:
    cwd = os.getcwd()
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    os.chdir(tmp_path)
    try:
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            code = main(list(args))
    finally:
        os.chdir(cwd)
    return code, stdout_buffer.getvalue(), stderr_buffer.getvalue()


def _prepare_proposal_bundle(tmp_path: Path) -> tuple[str, str]:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "propose", "--experiment", experiment_id, "--limit", "1") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8"))
    assert payload["proposal_count"] >= 1
    proposal_id = payload["proposals"][0]["proposal_id"]
    return experiment_id, proposal_id


def _write_eval_fixture(tmp_path: Path, eval_id: str) -> None:
    evals_dir = tmp_path / CONTROL_DIR_NAME / "evals"
    scorer_dir = tmp_path / CONTROL_DIR_NAME / "scorers"
    cases = [
        {
            "id": f"{eval_id}-workflow-a",
            "input": "helpful workflow question",
            "expected": "approved",
            "tags": ["workflow"],
        },
        {
            "id": f"{eval_id}-workflow-b",
            "input": "another helpful workflow question",
            "expected": "approved",
            "tags": ["workflow"],
        },
        {"id": f"{eval_id}-output-a", "input": "plain output question", "expected": "fallback", "tags": ["output"]},
    ]
    (evals_dir / f"{eval_id}.jsonl").write_text("".join(json.dumps(item) + "\n" for item in cases), encoding="utf-8")
    write_yaml(
        evals_dir / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": len(cases),
            "tags": ["workflow", "output"],
        },
    )
    write_yaml(
        evals_dir / f"{eval_id}.splits.yaml",
        {
            "smoke": [cases[0]["id"]],
            "full": [item["id"] for item in cases],
        },
    )
    (scorer_dir / f"{eval_id}_default.py").write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    final_output = str(run_artifact.get('final_output') or '').lower()",
                "    expected = str(case.get('expected') or '').lower()",
                "    passed = expected in final_output",
                "    return {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if passed else 0.0,",
                "        'passed': passed,",
                "        'reason': 'expected text present' if passed else 'expected text missing',",
                "    }",
                "",
            ]
        ),
        encoding="utf-8",
    )


def _write_surface_agent_files(tmp_path: Path) -> None:
    (tmp_path / "target_agent").mkdir(exist_ok=True)
    (tmp_path / "target_agent" / "agent_tools.py").write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def lookup(query: str) -> str:",
                '    """Return the grounded support snippet for the current workflow question."""',
                "    return query",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / "target_agent" / "system.md").write_text("# System\nUse grounded responses.\n", encoding="utf-8")
    (tmp_path / "target_agent" / "reviewer.md").write_text("# Reviewer\nCheck grounded answers.\n", encoding="utf-8")


def _write_constant_agent(tmp_path: Path, agent_id: str, output_text: str = "approved") -> None:
    spec = {
        "id": agent_id,
        "adapter": "command",
        "instructions": ["Return the deterministic fixture output."],
        "prompts": {"system": "Use the fixture output."},
        "model": {"name": "fixture-model"},
        "tools": [],
        "skills": [],
        "plugins": [],
        "mcps": [],
        "runtime": {"env": {}},
        "entrypoints": {
            "command": {
                "argv": [
                    "python3",
                    "-c",
                    "\n".join(
                        [
                            "import json, os",
                            f"payload = {{'final_output': {output_text!r}, 'step_count': 1, 'prompt_keys_used': ['system']}}",
                            "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                        ]
                    ),
                ],
                "cwd": ".",
                "timeout_seconds": 10,
            }
        },
    }
    write_yaml(tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml", spec)


def _write_surface_agent_spec(
    tmp_path: Path,
    *,
    agent_id: str,
    provider: str,
    model_name: str,
    model_id: str,
    reviewer_enabled: bool = True,
    lookup_enabled: bool = True,
    memory_enabled: bool = True,
    emit_skipped_for_disabled: bool = False,
    force_contract_violation: bool = False,
    omit_mcp_servers_used: bool = False,
) -> None:
    spec = {
        "id": agent_id,
        "adapter": "command",
        "instructions": ["Exercise prompts, tools, and MCPs deterministically."],
        "prompts": {
            "system": "target_agent/system.md",
            **({"reviewer": "target_agent/reviewer.md"} if reviewer_enabled else {}),
        },
        "model": {
            "provider": provider,
            "name": model_name,
            "model_id": model_id,
            "temperature": 0,
            "max_tokens": 120,
        },
        "tools": [{"name": "lookup", "enabled": lookup_enabled}],
        "mcps": [{"name": "memory", "enabled": memory_enabled}],
        "owned_paths": [
            "target_agent/agent_tools.py",
            "target_agent/system.md",
            "target_agent/reviewer.md",
        ],
        "surface_paths": {
            "tools": ["target_agent/agent_tools.py"],
            "prompts": ["target_agent/system.md", "target_agent/reviewer.md"],
            "runtime": [],
        },
        "entrypoints": {
            "command": {
                "argv": [
                    "python3",
                    "-c",
                    "\n".join(
                        [
                            "import json, os",
                            "prompts = json.loads(os.environ.get('AWB_PROMPTS_JSON', '{}'))",
                            "tools = {item.get('name') for item in json.loads(os.environ.get('AWB_TOOLS_JSON', '[]'))}",
                            "mcps = {item.get('name') for item in json.loads(os.environ.get('AWB_MCPS_JSON', '[]'))}",
                            "status = 'success' if 'lookup' in tools else 'skipped'",
                            "events = []",
                            "tool_calls = []",
                            "evidence_records = []",
                            "workflow_trace = ['prompt:system'] + (['prompt:reviewer'] if 'reviewer' in prompts else [])",
                            "if 'lookup' in tools:",
                            "    selected = 'helpful' in os.environ.get('AWB_INPUT', '')",
                            "    hit = {'id': 'knowledge/support.md#L1', 'path': 'knowledge/support.md', 'line': 1, 'snippet': 'approved' if selected and 'memory' in mcps and 'reviewer' in prompts else 'fallback evidence', 'selected': selected}",
                            "    events.append({'kind': 'retrieval', 'name': 'lookup', 'hits': 1 if selected else 0, 'selected': selected, 'status': 'success' if selected else 'empty', 'mcp': 'memory' if 'memory' in mcps else ''})",
                            "    tool_calls.append({'name': 'lookup', 'hits': 1 if selected else 0, 'selected': selected, 'status': 'success' if selected else 'empty', 'mcp': 'memory' if 'memory' in mcps else ''})",
                            "    evidence_records.append({'kind': 'retrieval', 'name': 'lookup', 'query': os.environ.get('AWB_INPUT', ''), 'status': 'success' if selected else 'empty', 'mcp': 'memory' if 'memory' in mcps else '', 'hits': [hit]})",
                            "    workflow_trace.append('tool:lookup')",
                            "    if 'memory' in mcps:",
                            "        workflow_trace.append('mcp:memory')",
                            f"elif {emit_skipped_for_disabled!r}:",
                            "    events.append({'kind': 'retrieval', 'name': 'lookup', 'status': 'skipped', 'mcp': 'memory', 'reason': 'tool_disabled'})",
                            "if 'memory' in mcps:",
                            "    events.append({'kind': 'memory_lookup', 'name': 'customer_memory', 'loaded': True, 'status': 'success', 'mcp': 'memory'})",
                            "    evidence_records.append({'kind': 'memory_lookup', 'name': 'customer_memory', 'query': os.environ.get('AWB_INPUT', ''), 'status': 'success', 'mcp': 'memory', 'hits': [{'id': 'knowledge/customer.md#L1', 'path': 'knowledge/customer.md', 'line': 1, 'snippet': 'approved', 'selected': True}]})",
                            f"elif {emit_skipped_for_disabled!r}:",
                            "    events.append({'kind': 'memory_lookup', 'name': 'customer_memory', 'status': 'skipped', 'mcp': 'memory', 'reason': 'mcp_disabled'})",
                            f"if {force_contract_violation!r}:",
                            "    workflow_trace.extend(['tool:lookup', 'mcp:memory'])",
                            "    events.append({'kind': 'retrieval', 'name': 'lookup', 'hits': 1, 'selected': True, 'status': 'success', 'mcp': 'memory'})",
                            "    tool_calls.append({'name': 'lookup', 'hits': 1, 'selected': True, 'status': 'success', 'mcp': 'memory'})",
                            "    evidence_records.append({'kind': 'retrieval', 'name': 'lookup', 'query': os.environ.get('AWB_INPUT', ''), 'status': 'success', 'mcp': 'memory', 'hits': [{'id': 'knowledge/support.md#L2', 'path': 'knowledge/support.md', 'line': 2, 'snippet': 'approved', 'selected': True}]})",
                            "approved = 'reviewer' in prompts and 'lookup' in tools and 'memory' in mcps",
                            "payload = {",
                            "    'final_output': 'approved' if approved else 'fallback',",
                            "    'events': events,",
                            "    'evidence_records': evidence_records,",
                            "    'workflow_trace': workflow_trace,",
                            "    'tool_calls': tool_calls,",
                            f"    'mcp_servers_used': [] if {omit_mcp_servers_used!r} else sorted(mcps),",
                            "    'prompt_keys_used': sorted(prompts),",
                            "    'step_count': 1 + len(tool_calls) + (1 if 'reviewer' in prompts else 0),",
                            "    'token_usage': {'input': 100, 'output': 50, 'total': 150},",
                            "    'metadata': {'provider': '" + provider + "', 'model_name': '" + model_name + "'},",
                            "}",
                            "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                        ]
                    ),
                ],
                "cwd": ".",
                "timeout_seconds": 30,
            }
        },
    }
    write_yaml(tmp_path / CONTROL_DIR_NAME / "agents" / f"{agent_id}.yaml", spec)


def test_init_and_learn(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (tmp_path / CONTROL_DIR_NAME / "workbench.yaml").exists()


def test_release_command_summarizes_multi_stream_readiness(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent")
    _write_eval_fixture(tmp_path, "release-a")
    _write_eval_fixture(tmp_path, "release-b")

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "release-a", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    exp_a = sorted(path.name for path in runs_root.iterdir() if path.name.startswith("approved-agent-release-a-smoke-"))[-1]
    assert _run(tmp_path, "promote", "--experiment", exp_a) == 0

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "release-b", "--subset", "smoke") == 0
    exp_b = sorted(path.name for path in runs_root.iterdir() if path.name.startswith("approved-agent-release-b-smoke-"))[-1]

    code, stdout, _ = _run_capture(tmp_path, "release")
    assert code == 0
    payload = json.loads(stdout)
    assert payload["overall_ready"] is False
    assert any("release-b" in reason for reason in payload["blocking_reasons"])

    assert _run(tmp_path, "promote", "--experiment", exp_b) == 0
    code, stdout, _ = _run_capture(tmp_path, "release")
    assert code == 0
    payload = json.loads(stdout)
    assert payload["overall_ready"] is True


def test_release_command_groups_benchmark_history_into_one_stream_family(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent")
    _write_eval_fixture(tmp_path, "release-a")

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "release-a", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    exp_a = sorted(path.name for path in runs_root.iterdir() if path.name.startswith("approved-agent-release-a-smoke-"))[-1]
    assert _run(tmp_path, "promote", "--experiment", exp_a) == 0

    eval_path = tmp_path / CONTROL_DIR_NAME / "evals" / "release-a.jsonl"
    cases = [json.loads(line) for line in eval_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    cases[0]["expected"] = "approved-v2"
    eval_path.write_text("".join(json.dumps(item) + "\n" for item in cases), encoding="utf-8")

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "release-a", "--subset", "smoke") == 0
    code, stdout, _ = _run_capture(tmp_path, "release")
    assert code == 0
    payload = json.loads(stdout)
    assert payload["stream_count"] == 1
    stream = payload["streams"][0]
    assert stream["eval_id"] == "release-a"
    assert stream["historical_stream_count"] == 2
    assert len(stream["benchmark_signatures"]) == 2
    assert stream["ready"] is False
    assert stream["has_stale_promoted_baseline"] is True
    assert stream["stale_promoted_baselines"]
    assert any("stale benchmark signature" in reason for reason in stream["reasons"])


def test_redteam_generate_and_report(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent")
    _write_eval_fixture(tmp_path, "base-eval")

    code, stdout, _ = _run_capture(
        tmp_path,
        "redteam",
        "generate",
        "--source-eval-id",
        "base-eval",
        "--output-eval-id",
        "base-eval-red",
        "--mode",
        "adversarial",
        "--mode",
        "robustness",
        "--mode",
        "stress",
    )
    assert code == 0
    payload = json.loads(stdout)
    assert payload["generated_case_count"] > 0
    assert "prompt_injection" in payload["attack_types"]
    assert "partial_tool_outage" in payload["attack_types"]
    assert "stress" in payload["modes"]
    assert payload["split_sizes"]["stress"] > 0

    assert _run(tmp_path, "evals", "approve", "--eval-id", "base-eval-red") == 0
    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "base-eval-red", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(
        path.name for path in runs_root.iterdir() if path.name.startswith("approved-agent-base-eval-red-smoke-")
    )[-1]

    code, stdout, _ = _run_capture(tmp_path, "redteam", "report", "--experiment", experiment_id)
    assert code == 0
    report_payload = json.loads(stdout)
    assert report_payload["total_redteam_cases"] > 0
    assert "prompt_injection" in report_payload["attack_types"]
    assert "stress" in report_payload["modes"]
    assert "tool_failure" in report_payload["attack_families"]
    assert report_payload["mode_summary"]
    assert report_payload["source_case_summary"]


def test_human_review_answer_command_resolves_queue_items(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer with warm tone") == 0
    assert _run(tmp_path, "brief", "packet", "--brief-id", "assistant") == 0

    code, stdout, _ = _run_capture(tmp_path, "human-review", "queues", "--pending-only")
    assert code == 0
    payload = json.loads(stdout)
    assert payload["pending_queue_count"] >= 1
    assert payload["queues"][0]["queue_id"] == "brief-assistant"
    assert payload["queues"][0]["pending_count"] >= 1

    code, stdout, _ = _run_capture(
        tmp_path,
        "human-review",
        "answer",
        "--queue-id",
        "brief-assistant",
        "--checkpoint-id",
        "brief-surface-confirmation",
        "--decision",
        "confirmed",
        "--guidance",
        "Keep the benchmark scope limited to target_agent/ and its prompts/tools.",
    )
    assert code == 0
    answer_payload = json.loads(stdout)
    assert answer_payload["checkpoint_id"] == "brief-surface-confirmation"
    assert answer_payload["answer"] == ""
    assert answer_payload["guidance"] == "Keep the benchmark scope limited to target_agent/ and its prompts/tools."
    assert any(path.endswith("/briefs/assistant.yaml") for path in answer_payload["apply_summary"]["updated_paths"])

    assert _run(tmp_path, "brief", "packet", "--brief-id", "assistant") == 0
    code, stdout, _ = _run_capture(tmp_path, "human-review", "queues")
    assert code == 0
    payload = json.loads(stdout)
    brief_queue = next(item for item in payload["queues"] if item["queue_id"] == "brief-assistant")
    assert all(item["checkpoint_id"] != "brief-surface-confirmation" for item in brief_queue["items"])
    brief_payload = read_yaml(tmp_path / CONTROL_DIR_NAME / "briefs" / "assistant.yaml")
    assert brief_payload["metadata"]["human_review"]["resolved_checkpoint_ids"] == ["brief-surface-confirmation"]
    assert (tmp_path / CONTROL_DIR_NAME / "benchmarks").is_dir()
    assert (tmp_path / CONTROL_DIR_NAME / "exports").is_dir()
    assert (tmp_path / CONTROL_DIR_NAME / "cache" / "provider").is_dir()
    assert _run(tmp_path, "learn") == 0
    summary = json.loads((tmp_path / CONTROL_DIR_NAME / "discovery" / "repo-summary.json").read_text(encoding="utf-8"))
    assert summary["project_name"] == tmp_path.name
    assert "existing_agent_assets" in summary


def test_human_review_answer_applies_guidance_into_eval_cases(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    evals_dir = tmp_path / CONTROL_DIR_NAME / "evals"
    write_json(
        evals_dir / "style-eval-review-queue-seed.json",
        {"note": "seed"},
    )
    (evals_dir / "style-eval.jsonl").write_text(
        json.dumps(
            {
                "id": "style-1",
                "input": "Write a support reply",
                "expected": "",
                "rubric": ["Prefer the warmer and more polished answer."],
                "tags": ["style"],
                "metadata": {},
            }
        )
        + "\n",
        encoding="utf-8",
    )
    write_yaml(
        evals_dir / "style-eval.suite.yaml",
        {
            "id": "style-eval",
            "brief_id": "style-brief",
            "approval_status": "draft",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": 1,
            "tags": ["style"],
        },
    )
    write_yaml(evals_dir / "style-eval.splits.yaml", {"smoke": ["style-1"], "full": ["style-1"]})
    (tmp_path / CONTROL_DIR_NAME / "scorers" / "style-eval_default.py").write_text(
        "from __future__ import annotations\n\n"
        "def score_case(run_artifact: dict, case: dict) -> dict:\n"
        "    return {'name': 'output_quality', 'value': 1.0, 'passed': True, 'reason': 'fixture'}\n",
        encoding="utf-8",
    )

    assert _run(tmp_path, "evals", "review", "--eval-id", "style-eval") == 0
    code, stdout, _ = _run_capture(
        tmp_path,
        "human-review",
        "answer",
        "--queue-id",
        "eval-style-eval",
        "--checkpoint-id",
        "eval-subjective-cases",
        "--case-id",
        "style-1",
        "--decision",
        "candidate",
        "--guidance",
        "Prefer the warmer reply when both answers are acceptable.",
    )
    assert code == 0
    payload = json.loads(stdout)
    assert any(path.endswith("/evals/style-eval.jsonl") for path in payload["apply_summary"]["updated_paths"])

    case_payload = json.loads((evals_dir / "style-eval.jsonl").read_text(encoding="utf-8").splitlines()[0])
    human_review = case_payload["metadata"]["human_review"]
    assert human_review["resolved"] is True
    assert human_review["guidance"] == "Prefer the warmer reply when both answers are acceptable."
    assert human_review["decision"] == "candidate"


def test_adapters_command_lists_builtin_adapters(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    code, stdout, stderr = _run_capture(tmp_path, "adapters", "--format", "json")
    payload = json.loads(stdout)
    assert code == 0
    assert stderr == ""
    assert {item["name"] for item in payload["adapters"]} >= {"command", "provider", "python"}


def test_atomic_writes_replace_read_only_report_files(tmp_path: Path) -> None:
    path = tmp_path / "report.json"
    path.write_text('{"old": true}\n', encoding="utf-8")
    path.chmod(0o444)
    write_json(path, {"fresh": True})
    assert json.loads(path.read_text(encoding="utf-8")) == {"fresh": True}


def test_brief_packet_guides_optimizer_flow(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert _run(tmp_path, "learn") == 0
    assert (
        _run(
            tmp_path,
            "brief",
            "start",
            "--brief-id",
            "assistant",
            "--goal",
            "Answer repo questions accurately",
            "--agent-id",
            "sample-agent",
        )
        == 0
    )
    packet = (tmp_path / CONTROL_DIR_NAME / "briefs" / "assistant.packet.md").read_text(encoding="utf-8")
    assert "Learn The Repo First" in packet
    assert "Interview The User" in packet
    assert "Likely Commands" in packet
    assert "Definition Of Better" in packet
    assert "How To Test The Agent" in packet


def test_brief_draft_seeds_from_linked_brief_and_resets_approval(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "briefs" / "support-brief.yaml",
        {
            "id": "support-brief",
            "goal": "Handle support requests correctly",
            "target_questions": ["Which request should the agent answer?"],
            "desired_behaviors": ["Ground answers in policy."],
            "non_goals": ["Do not invent policy exceptions."],
            "preferred_tools": ["policy_lookup"],
            "preferred_skills": ["policy_grounding"],
            "preferred_plugins": ["knowledge_base"],
            "preferred_mcps": ["filesystem"],
            "prompt_variants": ["system", "reviewer"],
            "likely_user_commands": ["Can this customer get a refund?"],
            "rough_answer_outlines": [
                {"question": "Can this customer get a refund?", "outline": "State the policy result."}
            ],
            "workflow_scenarios": [{"name": "refund", "trigger": "Check policy first.", "expected_tools": ["policy_lookup"]}],
            "better_signals": ["The agent uses the policy file."],
            "worse_signals": ["The agent guesses."],
            "acceptance_criteria": ["Answer is grounded."],
            "approval_status": "approved",
        },
    )
    (tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.jsonl").write_text(
        json.dumps({"id": "support-1", "input": "Can this customer get a refund?", "expected": "State the policy result."}) + "\n",
        encoding="utf-8",
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.suite.yaml",
        {
            "id": "support-eval",
            "brief_id": "support-brief",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": 1,
            "tags": ["support"],
        },
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.splits.yaml",
        {"smoke": ["support-1"], "full": ["support-1"]},
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "agents" / "demo-agent.yaml",
        {
            "id": "demo-agent",
            "adapter": "command",
            "prompts": {"system": "system.md"},
            "tools": [{"name": "policy_lookup", "enabled": True}],
            "skills": [{"name": "policy_grounding", "enabled": True}],
            "plugins": [{"name": "knowledge_base", "enabled": True}],
            "mcps": [{"name": "filesystem", "enabled": True}],
            "surface_paths": {"tests": [".agent-workbench/evals/support-eval.jsonl"]},
            "runtime": {"env": {}},
            "entrypoints": {"command": ["python3", "-c", "print('ok')"]},
        },
    )

    assert (
        _run(
            tmp_path,
            "brief",
            "draft",
            "--brief-id",
            "drafted-brief",
            "--agent-id",
            "demo-agent",
            "--goal",
            "Override drafted goal",
        )
        == 0
    )

    drafted = read_yaml(tmp_path / CONTROL_DIR_NAME / "briefs" / "drafted-brief.yaml")
    assert drafted["goal"] == "Override drafted goal"
    assert drafted["approval_status"] == "draft"
    assert drafted["likely_user_commands"] == ["Can this customer get a refund?"]
    assert drafted["preferred_tools"] == ["policy_lookup"]
    assert drafted["metadata"]["draft_source"]["mode"] == "linked_brief"
    packet = (tmp_path / CONTROL_DIR_NAME / "briefs" / "drafted-brief.packet.md").read_text(encoding="utf-8")
    assert "Likely Commands" in packet
    assert "Can this customer get a refund?" in packet


def test_brief_draft_falls_back_to_agent_spec_and_eval_cases(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    (tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.jsonl").write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "id": "assistant-workflow-1",
                        "input": "Use the repo search tool before answering.",
                        "expected": "Answer from the indexed repo context.",
                        "tags": ["workflow"],
                        "metadata": {"process_expectations": {"required_tools": ["repo_search"], "max_step_count": 4}},
                    }
                ),
                json.dumps(
                    {
                        "id": "assistant-output-1",
                        "input": "Summarize the repo architecture.",
                        "expected": "Give a grounded architecture summary.",
                        "tags": ["output"],
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.suite.yaml",
        {
            "id": "assistant-eval",
            "brief_id": "",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": 2,
            "tags": ["workflow", "output"],
        },
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.splits.yaml",
        {"smoke": ["assistant-workflow-1"], "full": ["assistant-workflow-1", "assistant-output-1"]},
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "agents" / "draft-agent.yaml",
        {
            "id": "draft-agent",
            "adapter": "command",
            "prompts": {"system": "system.md", "reviewer": "reviewer.md"},
            "tools": [{"name": "repo_search", "enabled": True}],
            "skills": [{"name": "repo_reading", "enabled": True}],
            "plugins": [{"name": "repo_index", "enabled": True}],
            "mcps": [{"name": "filesystem", "enabled": True}],
            "owned_paths": ["target_agent/runtime.py"],
            "surface_paths": {"tests": [".agent-workbench/evals/assistant-eval.jsonl"]},
            "runtime": {"env": {}},
            "entrypoints": {"command": ["python3", "-c", "print('ok')"]},
            "metadata": {"purpose": "repo question answering"},
        },
    )

    assert _run(tmp_path, "brief", "draft", "--brief-id", "assistant", "--agent-id", "draft-agent") == 0

    drafted = read_yaml(tmp_path / CONTROL_DIR_NAME / "briefs" / "assistant.yaml")
    assert drafted["goal"] == "Improve the `draft-agent` agent for `repo question answering` tasks."
    assert drafted["preferred_tools"] == ["repo_search"]
    assert drafted["preferred_skills"] == ["repo_reading"]
    assert drafted["preferred_plugins"] == ["repo_index"]
    assert drafted["preferred_mcps"] == ["filesystem"]
    assert drafted["prompt_variants"] == ["system", "reviewer"]
    assert drafted["likely_user_commands"][0] == "Use the repo search tool before answering."
    assert drafted["rough_answer_outlines"][0]["outline"] == "Answer from the indexed repo context."
    assert drafted["workflow_scenarios"][0]["expected_tools"] == ["repo_search"]
    assert drafted["metadata"]["draft_source"]["mode"] == "agent_spec"


def test_evals_expand_adds_brief_and_failure_cases_and_resets_approval(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent", output_text="approved")
    _write_eval_fixture(tmp_path, "support-eval")

    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "briefs" / "support-brief.yaml",
        {
            "id": "support-brief",
            "goal": "Handle support requests accurately.",
            "target_questions": ["Which policy applies here?"],
            "desired_behaviors": ["Ground every answer in the documented policy."],
            "non_goals": ["Do not invent policy exceptions."],
            "preferred_tools": ["lookup"],
            "prompt_variants": ["system"],
            "likely_user_commands": ["Check whether this customer qualifies for an exception."],
            "rough_answer_outlines": [
                {
                    "question": "How should the agent handle a damaged-item exception?",
                    "outline": "State the documented exception path or say it does not exist.",
                }
            ],
            "workflow_scenarios": [
                {
                    "name": "policy-escalation",
                    "trigger": "The normal policy fails and the user asks for an exception.",
                    "expected": "Explain the documented exception path or say none exists.",
                    "expected_tools": ["lookup"],
                    "expected_workflow_steps": ["inspect_policy", "decide_exception"],
                }
            ],
            "better_signals": ["The agent cites the policy path."],
            "worse_signals": ["The agent guesses the answer."],
            "edge_cases": ["The customer asks for a partial refund after a damaged-item report with conflicting dates."],
            "acceptance_criteria": ["Answer stays within documented policy."],
            "approval_status": "approved",
        },
    )
    suite_file = tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.suite.yaml"
    suite_payload = read_yaml(suite_file)
    suite_payload["brief_id"] = "support-brief"
    write_yaml(suite_file, suite_payload)

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "support-eval", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.name.startswith("approved-agent-support-eval-full-"))[-1]

    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "expand",
        "--eval-id",
        "support-eval",
        "--experiment",
        experiment_id,
        "--focus-limit",
        "2",
        "--brief-limit",
        "4",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["added_case_count"] >= 2
    assert payload["source_counts"]["brief"] >= 1
    assert payload["source_counts"]["failures"] >= 1
    assert payload["approval_status"] == "draft"

    updated_suite = read_yaml(suite_file)
    assert updated_suite["approval_status"] == "draft"
    assert updated_suite["generated_case_count"] == 3 + payload["added_case_count"]
    expansion_history = updated_suite["metadata"]["expansion_history"]
    assert expansion_history[-1]["experiment_id"] == experiment_id
    assert expansion_history[-1]["source_counts"]["brief"] >= 1
    assert expansion_history[-1]["source_counts"]["failures"] >= 1

    split_payload = read_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.splits.yaml")
    assert split_payload["smoke"] == ["support-eval-workflow-a"]
    assert len(split_payload["expanded"]) == payload["added_case_count"]
    assert split_payload["expanded-brief"]
    assert split_payload["expanded-failures"]

    case_rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    new_case_ids = set(payload["new_case_ids"])
    expanded_sources = {
        row["metadata"]["expansion_source"]["source"]
        for row in case_rows
        if row["id"] in new_case_ids
    }
    assert expanded_sources == {"brief", "failures"}
    failure_case = next(row for row in case_rows if row["id"] in set(split_payload["expanded-failures"]))
    assert "regression" in failure_case["tags"]
    assert failure_case["metadata"]["regression_target"]["reason"]

    review_report = (tmp_path / CONTROL_DIR_NAME / "reports" / "eval-review-support-eval.md").read_text(
        encoding="utf-8"
    )
    assert "Expansion Summary" in review_report
    assert "Source experiment" in review_report


def test_evals_expand_uses_latest_matching_experiment_and_skips_duplicate_failure_cases(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent", output_text="approved")
    _write_eval_fixture(tmp_path, "support-eval")
    split_file = tmp_path / CONTROL_DIR_NAME / "evals" / "support-eval.splits.yaml"
    split_payload = read_yaml(split_file)
    split_payload["workflow-only"] = ["support-eval-workflow-a", "support-eval-workflow-b"]
    write_yaml(split_file, split_payload)

    assert _run(tmp_path, "run", "--agent-id", "approved-agent", "--eval-id", "support-eval", "--subset", "full") == 0

    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "expand",
        "--eval-id",
        "support-eval",
        "--source",
        "failures",
        "--agent-id",
        "approved-agent",
        "--subset",
        "full",
        "--focus-limit",
        "1",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["source_counts"] == {"failures": 1}
    updated_splits = read_yaml(split_file)
    assert updated_splits["workflow-only"] == ["support-eval-workflow-a", "support-eval-workflow-b"]
    assert updated_splits["expanded-failures"]

    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "expand",
        "--eval-id",
        "support-eval",
        "--source",
        "failures",
        "--agent-id",
        "approved-agent",
        "--subset",
        "full",
        "--focus-limit",
        "1",
    )
    assert code == 1
    assert stdout == ""
    assert "No new eval cases were synthesized for `support-eval`." in stderr


def test_eval_suite_requires_approval_before_run(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 1


def test_brief_eval_run_compare_flow(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert _run(tmp_path, "learn") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    brief_file = tmp_path / CONTROL_DIR_NAME / "briefs" / "assistant.yaml"
    contents = brief_file.read_text(encoding="utf-8").replace(
        "goal: Answer repo questions accurately", "goal: Answer repo questions accurately"
    )
    brief_file.write_text(contents, encoding="utf-8")
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    suite_file = tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.suite.yaml"
    assert "approval_status: draft" in suite_file.read_text(encoding="utf-8")
    assert _run(tmp_path, "evals", "review", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiments = sorted(path.name for path in runs_root.iterdir() if path.is_dir())
    assert experiments
    first = experiments[-1]
    sample_agent = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    updated = sample_agent.read_text(encoding="utf-8").replace(
        "'final_output': os.environ.get('AWB_INPUT', '')",
        "'final_output': 'improved ' + os.environ.get('AWB_INPUT', '')",
    )
    sample_agent.write_text(updated, encoding="utf-8")
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    experiments = sorted(path.name for path in runs_root.iterdir() if path.is_dir())
    second = experiments[-1]
    assert _run(tmp_path, "compare", "--baseline", first, "--candidate", second) == 0
    compare_report = tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{first}-to-{second}.md"
    assert compare_report.exists()


def test_weighted_metrics_appear_in_aggregate_and_report(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    suite_file = tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.suite.yaml"
    suite_text = (
        suite_file.read_text(encoding="utf-8")
        .replace("output_quality: 0.7", "output_quality: 0.8")
        .replace("process_alignment: 0.3", "process_alignment: 0.2")
    )
    suite_file.write_text(suite_text, encoding="utf-8")
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    aggregate = json.loads((runs_root / experiment_id / "aggregate.json").read_text(encoding="utf-8"))
    assert aggregate["metric_weights"]["output_quality"] == 0.8
    assert aggregate["metric_weights"]["process_alignment"] == 0.2
    assert "metric_averages" in aggregate
    report = (runs_root / experiment_id / "report.md").read_text(encoding="utf-8")
    assert "Score Breakdown" in report
    assert "output_quality" in report


def test_compare_tracks_tool_skill_mcp_and_prompt_changes_without_passing_gates(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(
            tmp_path,
            "brief",
            "start",
            "--brief-id",
            "behavior",
            "--goal",
            "Track behavior changes across agent variants",
        )
        == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "behavior") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "behavior", "--eval-id", "behavior-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "behavior-eval") == 0
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions:",
                "- Use the baseline prompt stack.",
                "prompts:",
                "  default: baseline prompt",
                "model:",
                "  name: baseline-model",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills:",
                "  - name: planner",
                "    enabled: true",
                "plugins:",
                "  - name: repo_index",
                "    enabled: true",
                "mcps:",
                "  - name: filesystem",
                "    enabled: true",
                "runtime:",
                "  env: {}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'baseline answer',",
                "          'workflow_trace': ['startup:prompt_load', 'tool:repo_search', 'skill:planner'],",
                "          'tool_calls': [{'name': 'repo_search'}],",
                "          'skills_used': ['planner'],",
                "          'plugins_used': ['repo_index'],",
                "          'mcp_servers_used': ['filesystem'],",
                "          'prompt_keys_used': ['default'],",
                "          'step_count': 1,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata:",
                "  owner: tests",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "behavior-eval", "--subset", "smoke") == 0
    baseline = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions:",
                "- Use the revised prompt stack.",
                "prompts:",
                "  default: revised prompt",
                "  reviewer: review prompt",
                "model:",
                "  name: candidate-model",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "  - name: calculator",
                "    enabled: true",
                "skills:",
                "  - name: planner",
                "    enabled: true",
                "  - name: critic",
                "    enabled: true",
                "plugins:",
                "  - name: repo_index",
                "    enabled: true",
                "  - name: workflow_memory",
                "    enabled: true",
                "mcps:",
                "  - name: filesystem",
                "    enabled: true",
                "  - name: memory",
                "    enabled: true",
                "runtime:",
                "  env: {}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'candidate answer',",
                "          'workflow_trace': ['startup:prompt_load', 'tool:repo_search', 'skill:planner', 'tool:calculator', 'skill:critic'],",
                "          'tool_calls': [{'name': 'repo_search'}, {'name': 'calculator'}],",
                "          'skills_used': ['planner', 'critic'],",
                "          'plugins_used': ['repo_index', 'workflow_memory'],",
                "          'mcp_servers_used': ['filesystem', 'memory'],",
                "          'prompt_keys_used': ['default', 'reviewer'],",
                "          'step_count': 2,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata:",
                "  owner: tests",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "behavior-eval", "--subset", "smoke") == 0
    candidate = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert "calculator" in compare_json["behavior_deltas"]["tools_used_added"]
    assert "critic" in compare_json["behavior_deltas"]["skills_used_added"]
    assert "workflow_memory" in compare_json["behavior_deltas"]["plugins_used_added"]
    assert "memory" in compare_json["behavior_deltas"]["mcp_servers_used_added"]
    assert "reviewer" in compare_json["spec_changes"]["prompt_keys_added"]
    assert "workflow_memory" in compare_json["spec_changes"]["plugins_added"]
    assert compare_json["baseline_ladder"]["same_agent_best"]["experiment_id"] == baseline
    assert compare_json["changed_cases"]
    assert compare_json["changed_cases"][0]["candidate_evidence"]["tool_calls"]
    assert compare_json["changed_cases"][0]["candidate_evidence"]["workflow_trace"]
    assert "skill:critic" in compare_json["behavior_deltas"]["workflow_step_count_deltas"]
    assert compare_json["telemetry_summary"]["baseline_trace_schema_versions"] == ["awb.trace.v1"]
    assert "candidate_on_frontier" in compare_json["pareto_summary"]
    assert compare_json["failure_clusters"]
    assert compare_json["gate_results"]["overall_passed"] is False
    assert compare_json["gate_results"]["score_neutral_overhead"]["passed"] is False
    assert compare_json["recommended_action"] == "review"


def test_compare_tracks_prompt_content_drift(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "prompt-drift-eval")
    _write_surface_agent_files(tmp_path)
    _write_constant_agent(tmp_path, "prompt-agent", output_text="approved")
    agent_path = tmp_path / CONTROL_DIR_NAME / "agents" / "prompt-agent.yaml"
    spec = read_yaml(agent_path)
    spec["prompts"] = {"system": "target_agent/system.md"}
    write_yaml(agent_path, spec)

    assert _run(tmp_path, "run", "--agent-id", "prompt-agent", "--eval-id", "prompt-drift-eval", "--subset", "smoke") == 0
    baseline = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]

    (tmp_path / "target_agent" / "system.md").write_text("# System\nUse stricter grounded responses.\n", encoding="utf-8")
    assert _run(tmp_path, "run", "--agent-id", "prompt-agent", "--eval-id", "prompt-drift-eval", "--subset", "smoke") == 0
    candidate = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]

    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    compare_report = (
        tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.md"
    ).read_text(encoding="utf-8")

    assert compare_json["spec_changes"]["prompt_fingerprint_changed"] is True
    assert compare_json["spec_changes"]["prompt_content_changed_keys"] == ["system"]
    assert compare_json["spec_changes"]["prompt_content_drift"][0]["key"] == "system"
    assert "## Prompt Drift" in compare_report


def test_patch_template_builds_from_latest_proposal_bundle(tmp_path: Path) -> None:
    experiment_id, proposal_id = _prepare_proposal_bundle(tmp_path)
    assert _run(tmp_path, "patch-template") == 0
    latest_json = json.loads((tmp_path / CONTROL_DIR_NAME / "patches" / "latest.json").read_text(encoding="utf-8"))
    latest_yaml = read_yaml(tmp_path / CONTROL_DIR_NAME / "patches" / "latest.yaml")
    latest_report = (tmp_path / CONTROL_DIR_NAME / "patches" / "latest.md").read_text(encoding="utf-8")
    assert latest_json["proposal_id"] == proposal_id
    assert latest_json["experiment_id"] == experiment_id
    assert latest_yaml["proposal_id"] == proposal_id
    assert latest_yaml["planned_edits"]
    assert "Validation Commands" in latest_report
    assert "Planned Edits" in latest_report


def test_patch_template_can_select_specific_proposal(tmp_path: Path) -> None:
    _, proposal_id = _prepare_proposal_bundle(tmp_path)
    assert _run(tmp_path, "patch-template", "--proposal-id", proposal_id) == 0
    template_yaml = read_yaml(tmp_path / CONTROL_DIR_NAME / "patches" / f"{proposal_id}-patch.yaml")
    template_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "patches" / f"{proposal_id}-patch.json").read_text(encoding="utf-8")
    )
    template_report = (tmp_path / CONTROL_DIR_NAME / "patches" / f"{proposal_id}-patch.md").read_text(encoding="utf-8")
    assert template_yaml["template_id"] == f"{proposal_id}-patch"
    assert template_yaml["target_paths"]
    assert template_json["yaml_path"].endswith(f"{proposal_id}-patch.yaml")
    assert template_json["report_path"].endswith(f"{proposal_id}-patch.md")
    assert "Expected Effects" in template_report
    assert "Implementation Notes" in template_report


def test_generated_process_scorer_uses_workflow_expectations(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(
            tmp_path, "brief", "start", "--brief-id", "workflow", "--goal", "Handle workflow cases with expected tools"
        )
        == 0
    )
    brief_file = tmp_path / CONTROL_DIR_NAME / "briefs" / "workflow.yaml"
    content = brief_file.read_text(encoding="utf-8")
    content = content.replace("expected_tools: []", "expected_tools:\n  - repo_search", 1)
    content = content.replace("max_steps: 6", "max_steps: 1", 1)
    brief_file.write_text(content, encoding="utf-8")
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "workflow") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "workflow", "--eval-id", "workflow-eval") == 0
    eval_file = tmp_path / CONTROL_DIR_NAME / "evals" / "workflow-eval.jsonl"
    rows = [json.loads(line) for line in eval_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    for row in rows:
        if "-workflow-" not in row["id"]:
            continue
        metadata = row.setdefault("metadata", {})
        expectations = metadata.setdefault("process_expectations", {})
        expectations["workflow_sequence"] = ["startup:prompt_load", "tool:repo_search", "skill:planner"]
    eval_file.write_text("\n".join(json.dumps(row) for row in rows) + "\n", encoding="utf-8")
    assert _run(tmp_path, "evals", "approve", "--eval-id", "workflow-eval") == 0
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts:",
                "  default: baseline prompt",
                "model:",
                "  name: baseline-model",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime:",
                "  env: {}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'List the rough steps the agent should take before answering.',",
                "          'workflow_trace': ['startup:prompt_load', 'skill:critic'],",
                "          'tool_calls': [],",
                "          'step_count': 2,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "workflow-eval", "--subset", "full") == 0
    experiment_id = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / experiment_id / "runs.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    ]
    workflow_row = next(row for row in rows if "-workflow-" in row["case"]["id"])
    reasons = " ".join(item["reason"] for item in workflow_row["scores"])
    assert "missing required_tools" in reasons
    assert "exceeds max_step_count" in reasons
    assert "workflow_sequence mismatch" in reasons


def test_promote_rejects_score_neutral_candidate_with_added_overhead(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiments = sorted(path.name for path in runs_root.iterdir() if path.is_dir())
    baseline = [item for item in experiments if item.startswith("sample-agent-assistant-eval")][-1]
    candidate = [item for item in experiments if item.startswith("sample-agent-improved-assistant-eval")][-1]
    assert _run(tmp_path, "promote", "--experiment", candidate, "--baseline", baseline) == 0
    candidate_record = json.loads((runs_root / candidate / "experiment.json").read_text(encoding="utf-8"))
    assert candidate_record["promotion_status"] == "rejected"
    promotion_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "promotion-latest.json").read_text(encoding="utf-8")
    )
    assert promotion_payload["recommended_action"] == "review"
    assert promotion_payload["gate_results"]["overall_passed"] is False
    assert promotion_payload["gate_results"]["score_neutral_overhead"]["passed"] is False


def test_compare_best_reviews_score_neutral_candidate_with_added_overhead(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--candidate", candidate, "--best") == 0
    latest_compare = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "latest-compare.json").read_text(encoding="utf-8")
    )
    assert latest_compare["baseline_id"] == baseline
    assert latest_compare["candidate_id"] == candidate
    assert latest_compare["recommended_action"] == "review"
    assert latest_compare["gate_results"]["score_neutral_overhead"]["passed"] is False


def test_status_reports_stream_baseline_and_latest_candidate(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--candidate", candidate, "--best") == 0
    assert _run(tmp_path, "status", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "status-latest.json").read_text(encoding="utf-8"))
    assert payload["promotion_counts"]["promoted"] == 1
    assert payload["latest_experiment"]["experiment_id"] == candidate
    assert payload["latest_compare"]["candidate_id"] == candidate
    assert payload["latest_baseline_ladder"]["promoted_baseline"]["experiment_id"] == baseline
    assert payload["latest_pareto_frontier"]
    assert payload["streams"][0]["promoted_baseline"]["experiment_id"] == baseline
    assert payload["streams"][0]["latest_candidate"]["experiment_id"] == candidate
    assert payload["streams"][0]["best_same_model_run"]["experiment_id"] == candidate
    assert payload["streams"][0]["best_same_agent_run"]["experiment_id"] == candidate
    assert "pareto_frontier" in payload["streams"][0]
    status_report = (tmp_path / CONTROL_DIR_NAME / "reports" / "status-latest.md").read_text(encoding="utf-8")
    assert "Workbench Status" in status_report
    assert "Pareto Frontier" in status_report
    assert baseline in status_report
    assert candidate in status_report


def test_status_hides_latest_compare_when_only_older_benchmark_compare_exists(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0

    scorer_path = tmp_path / CONTROL_DIR_NAME / "scorers" / "assistant-eval_default.py"
    scorer_path.write_text(
        scorer_path.read_text(encoding="utf-8") + "\n# benchmark drift for status selection\n", encoding="utf-8"
    )
    time.sleep(1.1)
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0

    assert _run(tmp_path, "status", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "status-latest.json").read_text(encoding="utf-8"))
    assert len(payload["streams"]) >= 2
    assert payload["latest_compare"] is None


def test_diagnose_uses_best_comparable_baseline_and_suggests_actions(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-improved-assistant-eval")
    )[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    candidate = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]
    assert _run(tmp_path, "diagnose", "--experiment", candidate) == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.json").read_text(encoding="utf-8"))
    assert payload["baseline_id"] == baseline
    assert payload["recommended_action"] in {"promote", "reject", "review"}
    assert payload["focus_cases"]
    assert payload["baseline_ladder"]["promoted_baseline"]["experiment_id"] == baseline
    assert payload["focus_cases"][0]["candidate_evidence"]["tool_calls"]
    categories = {item["category"] for item in payload["suggested_mutations"]}
    assert "prompt_grounding" in categories or "inspect_failures" in categories
    report = (tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.md").read_text(encoding="utf-8")
    assert "Suggested Mutations" in report
    assert candidate in report


def test_next_collapses_status_diagnose_and_proposals(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-improved-assistant-eval")
    )[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    candidate = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]

    assert _run(tmp_path, "next", "--experiment", candidate, "--limit", "2") == 0

    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "next-latest.json").read_text(encoding="utf-8"))
    assert payload["experiment_id"] == candidate
    assert payload["baseline_id"] == baseline
    assert payload["recommended_action"] in {"promote", "reject", "review"}
    assert payload["status"]["latest_experiment"]["experiment_id"] == candidate
    assert payload["diagnosis"]["focus_cases"]
    assert payload["proposals"]["proposal_count"] >= 1
    assert payload["top_proposal"]["proposal_id"] == payload["proposals"]["proposals"][0]["proposal_id"]
    assert any("evals expand" in item["command"] for item in payload["next_commands"])
    assert any("patch-template" in item["command"] for item in payload["next_commands"])

    proposals_payload = json.loads((tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8"))
    assert proposals_payload["experiment_id"] == candidate

    report = (tmp_path / CONTROL_DIR_NAME / "reports" / "next-latest.md").read_text(encoding="utf-8")
    assert "Next Steps" in report
    assert candidate in report


def test_iterate_builds_measured_lanes_and_prefers_full_subset(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-improved-assistant-eval")
    )[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    candidate = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]
    assert _run(tmp_path, "iterate", "--experiment", candidate, "--limit", "2") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "iterations" / "latest.json").read_text(encoding="utf-8"))
    assert payload["experiment_id"] == candidate
    assert payload["preferred_subset"] == "full"
    assert payload["baseline_ladder"]["promoted_baseline"]["experiment_id"] == baseline
    assert payload["lanes"]
    assert "tool_usage_count_deltas" in payload["lanes"][0]["metrics_to_watch"]
    assert "mcp_usage_count_deltas" in payload["lanes"][0]["metrics_to_watch"]
    report = (tmp_path / CONTROL_DIR_NAME / "iterations" / "latest.md").read_text(encoding="utf-8")
    assert "Behavior Contract" in report
    assert "Lanes" in report


def test_diagnose_can_select_latest_experiment_from_filters(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    latest = sorted(
        path.name
        for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]
    assert (
        _run(tmp_path, "diagnose", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.json").read_text(encoding="utf-8"))
    assert payload["experiment_id"] == latest
    assert payload["recommended_action"] in {"establish-baseline", "review", "promote"}
    assert payload["suggested_commands"]


def test_optimize_runs_bounded_search_and_persists_artifact(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "optimize-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="optimize-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    code, stdout, stderr = _run_capture(
        tmp_path,
        "optimize",
        "--agent-id",
        "optimize-agent",
        "--eval-id",
        "optimize-eval",
        "--subset",
        "full",
        "--tag",
        "workflow",
        "--budget",
        "6",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["search_budget"] == 6
    assert payload["source_runs_created"] == 1
    assert payload["selected_case_count"] == 2
    assert payload["search_experiment_count"] <= 6
    assert payload["ablation"]["ablation_count"] >= 2
    assert len(payload["ablation"]["shortlisted_factors"]) == 2
    assert payload["factorial"]["combination_count"] == 4
    assert payload["recommended_candidate"]["experiment_id"]
    assert payload["patch_handoff"]["proposal_id"]
    assert payload["patch_handoff"]["template_paths"]
    assert any("propose" in item["command"] for item in payload["next_commands"])

    optimize_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "optimizations" / "latest.json").read_text(encoding="utf-8")
    )
    assert optimize_payload["optimize_id"] == payload["optimize_id"]
    report = (tmp_path / CONTROL_DIR_NAME / "optimizations" / "latest.md").read_text(encoding="utf-8")
    assert "Optimize" in report
    assert "Recommended Candidate" in report
    assert "Patch Handoff" in report


def test_optimize_respects_small_budget_and_skips_factorial(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_constant_agent(tmp_path, "approved-agent")
    _write_eval_fixture(tmp_path, "optimize-lite")

    code, stdout, stderr = _run_capture(
        tmp_path,
        "optimize",
        "--agent-id",
        "approved-agent",
        "--eval-id",
        "optimize-lite",
        "--subset",
        "smoke",
        "--budget",
        "2",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["search_budget"] == 2
    assert payload["search_experiment_count"] <= 2
    assert payload["ablation"]["ablation_count"] >= 1
    assert payload["factorial"]["combination_count"] == 0
    assert payload["ablation"]["shortlisted_factors"] == []
    assert payload["unused_budget"] >= 0


def test_optimize_revalidates_finalists_and_builds_patch_handoff(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "optimize-revalidate")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="optimize-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    assert _run(tmp_path, "run", "--agent-id", "optimize-agent", "--eval-id", "optimize-revalidate", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("optimize-agent-optimize-revalidate-full-")
    )[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0

    code, stdout, stderr = _run_capture(
        tmp_path,
        "optimize",
        "--agent-id",
        "optimize-agent",
        "--eval-id",
        "optimize-revalidate",
        "--subset",
        "smoke",
        "--budget",
        "5",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["allocation"]["reserved_revalidation_budget"] == 2
    assert payload["revalidation"]["control_revalidated"] is True
    assert payload["revalidation"]["revalidated_finalist_count"] == 1
    assert payload["final_control_experiment_id"] != payload["control_experiment_id"]
    assert payload["finalists"]
    finalist = payload["finalists"][0]
    assert finalist["baseline_id"] == baseline
    assert finalist["recommended_action"] in {"promote", "review", "review-benchmark-drift", "reject"}
    assert "overall_passed" in finalist["gate_results"]
    patch_handoff = payload["patch_handoff"]
    assert patch_handoff["proposal_id"]
    assert patch_handoff["recommended_candidate_experiment_id"] == payload["recommended_candidate"]["experiment_id"]
    assert patch_handoff["template_paths"]
    for relative_path in patch_handoff["template_paths"].values():
        assert (tmp_path / relative_path).exists()
    assert any(item["step"] == "patch_template" for item in payload["next_commands"])

    report = (tmp_path / CONTROL_DIR_NAME / "optimizations" / "latest.md").read_text(encoding="utf-8")
    assert "Revalidation Stage" in report
    assert "Finalists" in report
    assert "Patch Handoff" in report


def test_optimize_can_search_model_runtime_axis(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "optimize-matrix")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="optimize-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    code, stdout, stderr = _run_capture(
        tmp_path,
        "optimize",
        "--agent-id",
        "optimize-agent",
        "--eval-id",
        "optimize-matrix",
        "--subset",
        "full",
        "--budget",
        "6",
        "--temperature",
        "0",
        "--temperature",
        "0.3",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["matrix"]["requested"] is True
    assert payload["matrix"]["agent_ids"] == ["optimize-agent"]
    assert payload["matrix"]["temperatures"] == [0.0, 0.3]
    assert payload["matrix"]["experiment_count"] == 2
    assert any(item["stage"] == "matrix" for item in payload["search_candidates"])
    assert not list((tmp_path / CONTROL_DIR_NAME / "agents").glob("optimize-agent-matrix-*.yaml"))

    report = (tmp_path / CONTROL_DIR_NAME / "optimizations" / "latest.md").read_text(encoding="utf-8")
    assert "Model/Runtime Matrix" in report


def test_propose_builds_bounded_mutation_plan(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-improved-assistant-eval")
    )[-1]
    assert _run(tmp_path, "promote", "--experiment", baseline) == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    candidate = sorted(
        path.name
        for path in runs_root.iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]
    assert _run(tmp_path, "propose", "--experiment", candidate, "--limit", "2") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8"))
    assert payload["experiment_id"] == candidate
    assert payload["baseline_id"] == baseline
    assert 1 <= payload["proposal_count"] <= 2
    first = payload["proposals"][0]
    assert first["target_files"]
    assert first["target_paths"]
    assert first["target_surfaces"]
    assert first["change_plan"]
    assert first["acceptance_checks"]
    assert first["validation_commands"]
    assert any("<new-experiment-id>" in command for command in first["validation_commands"])
    report = (tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.md").read_text(encoding="utf-8")
    assert "Mutation Proposals" in report
    assert first["proposal_id"] in report


def test_propose_can_use_latest_matching_filters(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    latest = sorted(
        path.name
        for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir()
        if path.is_dir() and path.name.startswith("sample-agent-assistant-eval")
    )[-1]
    assert (
        _run(tmp_path, "propose", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    )
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8"))
    assert payload["experiment_id"] == latest
    assert payload["proposal_count"] >= 1


def test_compare_marks_benchmark_changed(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer questions safely") == 0
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    scorer = tmp_path / CONTROL_DIR_NAME / "scorers" / "assistant-eval_default.py"
    scorer.write_text(scorer.read_text(encoding="utf-8") + "\n# benchmark drift\n", encoding="utf-8")
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    report = (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.md").read_text(
        encoding="utf-8"
    )
    assert "benchmark-changed" in report
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert compare_json["benchmark_drift"]["changed_sections"] == ["scorers"]
    assert compare_json["gate_results"]["overall_passed"] is False


def test_python_adapter_and_ablation_flow(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    runtime_module = tmp_path / "sample_runtime.py"
    runtime_module.write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def run_case(case, context, project_root):",
                "    tools = {item.get('name') for item in (context.get('agent', {}).get('tools', []) or []) if item.get('enabled', True)}",
                "    planner = 'task_planner' in tools",
                "    return {",
                "        'final_output': 'Describe the expected behavior\\n' + case.get('input', ''),",
                "        'events': [",
                "            {'kind': 'decision', 'name': 'planner_available' if planner else 'planner_removed'},",
                "            {'kind': 'prompt_load', 'name': 'system', 'loaded': True},",
                "        ],",
                "        'tool_calls': [{'name': 'repo_search'}],",
                "        'prompt_keys_used': ['system'],",
                "        'step_count': 1,",
                "        'token_usage': {'input': 120 if planner else 90, 'output': 20},",
                "    }",
                "",
            ]
        ),
        encoding="utf-8",
    )
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: python",
                "instructions: []",
                "prompts:",
                "  system: prompts/system.md",
                "model:",
                "  name: python-model",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "  - name: task_planner",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime:",
                "  env: {}",
                "entrypoints:",
                "  python:",
                "    callable: sample_runtime:run_case",
                "    cwd: .",
                "    timeout_seconds: 30",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    record = json.loads((runs_root / experiment_id / "experiment.json").read_text(encoding="utf-8"))
    assert record["spec_snapshot"]["adapter"] == "python"
    assert record["behavior_summary"]["trace_schema_versions"] == ["awb.trace.v1"]
    assert record["benchmark_manifest"]["fingerprint"]
    assert _run(tmp_path, "ablate", "--experiment", experiment_id, "--surfaces", "tools") == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "ablations" / "latest.json").read_text(encoding="utf-8"))
    assert payload["source_experiment_id"] == experiment_id
    task_planner = next(item for item in payload["results"] if item["surface_name"] == "task_planner")
    assert task_planner["effect"] in {"neutral_surface", "prune_candidate"}
    assert "selected_evidence_use_rate_delta" in task_planner
    assert task_planner["optimization_signal"] in {
        "neutral",
        "noise_or_overhead",
        "grounding_support",
        "retrieval_cleanup",
    }
    assert "candidate_on_frontier" in task_planner["pareto_summary"]
    report = (tmp_path / CONTROL_DIR_NAME / "ablations" / "latest.md").read_text(encoding="utf-8")
    assert "Ablations" in report


def test_compare_reviews_score_neutral_candidate_with_added_unused_surface(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer questions safely") == 0
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    baseline_spec = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    baseline_spec.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'steady answer',",
                "          'tool_calls': [{'name': 'repo_search'}],",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 100, 'output': 20},",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    candidate_spec = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent-improved.yaml"
    candidate_spec.write_text(
        "\n".join(
            [
                "id: sample-agent-improved",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "  - name: task_planner",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'steady answer',",
                "          'tool_calls': [{'name': 'repo_search'}],",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 120, 'output': 20},",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert compare_json["recommended_action"] == "review"
    assert compare_json["gate_results"]["overall_passed"] is False
    assert compare_json["gate_results"]["score_neutral_overhead"]["passed"] is False
    assert compare_json["gate_results"]["score_neutral_overhead"]["actual"]["unused_surface_added"] == ["task_planner"]


def test_compare_can_enforce_minimum_average_score(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    workbench = tmp_path / CONTROL_DIR_NAME / "workbench.yaml"
    workbench.write_text(
        "\n".join(
            [
                "snapshot_mode: auto",
                "artifacts_dir: .agent-workbench/runs",
                "gates:",
                "  min_average_score_delta: 0.0",
                "  min_average_score: 0.8",
                "  min_passed_case_delta: 0",
                "  require_clean_benchmark: true",
                "  max_average_latency_ms_delta: null",
                "  max_average_step_count_delta: null",
                "  max_average_cost_estimate_delta: null",
                "  max_regressed_cases: 0",
                "",
            ]
        ),
        encoding="utf-8",
    )
    assert _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer questions safely") == 0
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    sample_agent = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent-improved.yaml"
    sample_agent.write_text(
        (tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml")
        .read_text(encoding="utf-8")
        .replace("id: sample-agent", "id: sample-agent-improved"),
        encoding="utf-8",
    )
    assert (
        _run(tmp_path, "run", "--agent-id", "sample-agent-improved", "--eval-id", "assistant-eval", "--subset", "smoke")
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert compare_json["recommended_action"] == "review"
    assert compare_json["gate_results"]["minimum_average_score"]["passed"] is False


def test_run_can_filter_cases_and_emit_stability_series(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "slice-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="slice-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "slice-agent",
            "--eval-id",
            "slice-eval",
            "--subset",
            "full",
            "--tag",
            "workflow",
            "--repeat",
            "2",
            "--series-label",
            "workflow-stability",
        )
        == 0
    )
    stability_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "stability" / "latest.json").read_text(encoding="utf-8")
    )
    assert stability_payload["repeat_count"] == 2
    assert stability_payload["label"] == "workflow-stability"
    assert stability_payload["selected_case_ids"] == ["slice-eval-workflow-a", "slice-eval-workflow-b"]
    assert stability_payload["selection"]["tags"] == ["workflow"]
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_ids = sorted(path.name for path in runs_root.iterdir() if path.is_dir())
    assert len(experiment_ids) == 2
    record = json.loads((runs_root / experiment_ids[-1] / "experiment.json").read_text(encoding="utf-8"))
    assert record["series_id"] == stability_payload["series_id"]
    assert record["selected_case_ids"] == ["slice-eval-workflow-a", "slice-eval-workflow-b"]


def test_matrix_and_factorial_commands_capture_costs_and_frontiers(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "matrix-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="matrix-groq",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    _write_surface_agent_spec(
        tmp_path,
        agent_id="matrix-cerebras",
        provider="cerebras",
        model_name="cerebras/llama3.1-8b",
        model_id="llama3.1-8b",
    )

    assert (
        _run(
            tmp_path,
            "matrix",
            "--agent-id",
            "matrix-groq",
            "--agent-id",
            "matrix-cerebras",
            "--eval-id",
            "matrix-eval",
            "--subset",
            "full",
            "--tag",
            "workflow",
        )
        == 0
    )
    matrix_payload = json.loads((tmp_path / CONTROL_DIR_NAME / "matrices" / "latest.json").read_text(encoding="utf-8"))
    assert matrix_payload["experiment_count"] == 2
    assert matrix_payload["pareto_frontier"]
    assert all(float(item["average_cost_estimate"]) > 0.0 for item in matrix_payload["experiments"])

    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(
        path.name for path in runs_root.iterdir() if path.is_dir() and path.name.startswith("matrix-groq")
    )[-1]
    assert (
        _run(
            tmp_path,
            "factorial",
            "--experiment",
            experiment_id,
            "--factor",
            "prompts:reviewer",
            "--factor",
            "tools:lookup",
            "--factor",
            "mcps:memory",
        )
        == 0
    )
    factorial_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "factorials" / "latest.json").read_text(encoding="utf-8")
    )
    assert factorial_payload["combination_count"] == 8
    assert {item["factor"] for item in factorial_payload["factor_effects"]} == {
        "prompts:reviewer",
        "tools:lookup",
        "mcps:memory",
    }
    assert factorial_payload["created_at"]
    assert factorial_payload["benchmark_signature"]
    assert all("selected_evidence_use_rate_effect" in item for item in factorial_payload["factor_effects"])
    assert factorial_payload["surface_recommendations"]
    assert {item["surface"] for item in factorial_payload["surface_recommendations"]} >= {"tools:lookup", "mcps:memory"}
    assert factorial_payload["pareto_frontier"]
    assert matrix_payload["created_at"]
    assert matrix_payload["benchmark_signatures"]


def test_status_surfaces_latest_matrix_factorial_and_stability_artifacts(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "status-artifacts-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="status-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    _write_surface_agent_spec(
        tmp_path,
        agent_id="status-agent-alt",
        provider="cerebras",
        model_name="cerebras/llama3.1-8b",
        model_id="llama3.1-8b",
    )

    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "status-agent",
            "--eval-id",
            "status-artifacts-eval",
            "--subset",
            "full",
            "--tag",
            "workflow",
            "--repeat",
            "2",
            "--series-label",
            "workflow-stability",
        )
        == 0
    )
    assert (
        _run(
            tmp_path,
            "matrix",
            "--agent-id",
            "status-agent",
            "--agent-id",
            "status-agent-alt",
            "--eval-id",
            "status-artifacts-eval",
            "--subset",
            "full",
            "--tag",
            "workflow",
        )
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(
        path.name for path in runs_root.iterdir() if path.is_dir() and path.name.startswith("status-agent")
    )[-1]
    assert (
        _run(
            tmp_path,
            "factorial",
            "--experiment",
            experiment_id,
            "--tag",
            "workflow",
            "--factor",
            "prompts:reviewer",
            "--factor",
            "tools:lookup",
            "--factor",
            "mcps:memory",
        )
        == 0
    )

    assert (
        _run(
            tmp_path,
            "status",
            "--eval-id",
            "status-artifacts-eval",
            "--subset",
            "full",
        )
        == 0
    )
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "status-latest.json").read_text(encoding="utf-8"))
    assert payload["latest_stability"]["label"] == "workflow-stability"
    assert payload["latest_stability"]["selection"]["tags"] == ["workflow"]
    assert payload["latest_matrix"]["eval_id"] == "status-artifacts-eval"
    assert payload["latest_matrix"]["experiment_count"] == 2
    assert payload["latest_factorial"]["eval_id"] == "status-artifacts-eval"
    assert set(payload["latest_factorial"]["selected_factors"]) == {
        "prompts:reviewer",
        "tools:lookup",
        "mcps:memory",
    }
    assert payload["surface_recommendations"]
    assert {item["surface"] for item in payload["surface_recommendations"]} >= {"tools:lookup", "mcps:memory"}

    status_report = (tmp_path / CONTROL_DIR_NAME / "reports" / "status-latest.md").read_text(encoding="utf-8")
    assert "## Latest Stability" in status_report
    assert "## Latest Matrix" in status_report
    assert "## Latest Factorial" in status_report
    assert "## Tool And MCP Recommendations" in status_report


def test_diagnose_and_propose_include_surface_recommendations(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "surface-recommendation-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="surface-recommendation-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "surface-recommendation-agent",
            "--eval-id",
            "surface-recommendation-eval",
            "--subset",
            "full",
        )
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    source_experiment = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert (
        _run(
            tmp_path,
            "factorial",
            "--experiment",
            source_experiment,
            "--factor",
            "prompts:reviewer",
            "--factor",
            "tools:lookup",
            "--factor",
            "mcps:memory",
        )
        == 0
    )

    _write_surface_agent_spec(
        tmp_path,
        agent_id="surface-recommendation-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        memory_enabled=False,
    )
    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "surface-recommendation-agent",
            "--eval-id",
            "surface-recommendation-eval",
            "--subset",
            "full",
        )
        == 0
    )
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    assert _run(tmp_path, "diagnose", "--experiment", candidate) == 0
    diagnose_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.json").read_text(encoding="utf-8")
    )
    assert diagnose_payload["surface_recommendations"]
    assert {item["surface"] for item in diagnose_payload["surface_recommendations"]} >= {"tools:lookup", "mcps:memory"}
    diagnose_report = (tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.md").read_text(encoding="utf-8")
    assert "## Surface Recommendations" in diagnose_report

    assert _run(tmp_path, "propose", "--experiment", candidate, "--limit", "3") == 0
    proposals_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8")
    )
    assert proposals_payload["surface_recommendations"]
    assert {item["surface"] for item in proposals_payload["surface_recommendations"]} >= {"tools:lookup", "mcps:memory"}
    assert any(
        {"tools:lookup", "mcps:memory"} & set(proposal["target_surfaces"])
        for proposal in proposals_payload["proposals"]
    )
    proposals_report = (tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.md").read_text(encoding="utf-8")
    assert "## Surface Recommendations" in proposals_report


def test_factorial_can_rerun_control_for_filtered_case_selection(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "factorial-slice-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="factorial-slice-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )

    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "factorial-slice-agent",
            "--eval-id",
            "factorial-slice-eval",
            "--subset",
            "full",
        )
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    assert (
        _run(
            tmp_path,
            "factorial",
            "--experiment",
            experiment_id,
            "--tag",
            "workflow",
            "--factor",
            "prompts:reviewer",
            "--factor",
            "tools:lookup",
            "--factor",
            "mcps:memory",
        )
        == 0
    )
    factorial_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "factorials" / "latest.json").read_text(encoding="utf-8")
    )
    assert factorial_payload["source_experiment_id"] == experiment_id
    assert factorial_payload["control_experiment_id"] != experiment_id
    assert factorial_payload["selected_case_ids"] == [
        "factorial-slice-eval-workflow-a",
        "factorial-slice-eval-workflow-b",
    ]
    all_on = next(item for item in factorial_payload["results"] if all(item["state"].values()))
    assert all_on["experiment_id"] == factorial_payload["control_experiment_id"]
    assert all_on["summary"]["selected_case_count"] == 2


def test_compare_tracks_surface_detail_changes_and_tool_mcp_audits(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "detail-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="detail-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        memory_enabled=False,
    )
    assert _run(tmp_path, "run", "--agent-id", "detail-agent", "--eval-id", "detail-eval", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    tools_path = tmp_path / "target_agent" / "agent_tools.py"
    tools_path.write_text(
        tools_path.read_text(encoding="utf-8").replace(
            "Return the grounded support snippet for the current workflow question.",
            "Return the revised grounded support snippet for the current workflow question.",
        ),
        encoding="utf-8",
    )
    _write_surface_agent_spec(
        tmp_path,
        agent_id="detail-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        memory_enabled=True,
    )
    assert _run(tmp_path, "run", "--agent-id", "detail-agent", "--eval-id", "detail-eval", "--subset", "full") == 0
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert (
        "target_agent/agent_tools.py::function:lookup"
        in compare_payload["surface_detail_changes"]["tool_docstring_changes"]
    )
    assert any(
        "mcps[memory].enabled" in item for item in compare_payload["surface_detail_changes"]["mcp_config_changes"]
    )
    assert compare_payload["behavior_deltas"]["mcp_audit_deltas"]["memory"]["success_delta"] > 0
    assert compare_payload["behavior_deltas"]["mcp_audit_deltas"]["memory"]["selected_evidence_delta"] > 0
    assert compare_payload["behavior_deltas"]["tool_audit_deltas"]["lookup"]["attempted_delta"] == 0
    assert compare_payload["behavior_deltas"]["avg_evidence_record_count_delta"] > 0
    assert "memory_lookup:customer_memory" in compare_payload["behavior_deltas"]["evidence_sources_added"]
    assert compare_payload["changed_cases"][0]["candidate_evidence"]["evidence_summary"]["selected_count"] >= 1
    assert (
        compare_payload["changed_cases"][0]["candidate_evidence"]["tool_audits"]["customer_memory"]["selected_evidence"]
        >= 1
    )


def test_run_keeps_skipped_disabled_surfaces_out_of_contract_violations(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "contract-clean-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="contract-clean-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        lookup_enabled=False,
        memory_enabled=False,
        emit_skipped_for_disabled=True,
    )
    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "contract-clean-agent",
            "--eval-id",
            "contract-clean-eval",
            "--subset",
            "full",
        )
        == 0
    )
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    experiment_id = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    record = json.loads((runs_root / experiment_id / "experiment.json").read_text(encoding="utf-8"))
    behavior = record["behavior_summary"]
    assert behavior["surface_contract_violation_count"] == 0
    assert behavior["tool_used_not_enabled"] == []
    assert behavior["mcp_used_not_enabled"] == []
    assert behavior["mcp_referenced_not_listed"] == []
    assert behavior["tool_audits"]["lookup"]["skipped"] > 0
    assert behavior["mcp_audits"]["memory"]["skipped"] > 0


def test_diagnose_includes_evidence_provenance_in_focus_cases(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "evidence-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="evidence-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        memory_enabled=False,
    )
    assert _run(tmp_path, "run", "--agent-id", "evidence-agent", "--eval-id", "evidence-eval", "--subset", "full") == 0
    _write_surface_agent_spec(
        tmp_path,
        agent_id="evidence-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        memory_enabled=True,
    )
    assert _run(tmp_path, "run", "--agent-id", "evidence-agent", "--eval-id", "evidence-eval", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    assert _run(tmp_path, "diagnose", "--experiment", candidate) == 0
    payload = json.loads((tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.json").read_text(encoding="utf-8"))
    assert payload["focus_cases"][0]["candidate_evidence"]["evidence_records"]
    assert payload["focus_cases"][0]["candidate_evidence"]["evidence_summary"]["selected_count"] >= 1
    assert payload["focus_cases"][0]["candidate_evidence"]["tool_audits"]["customer_memory"]["selected_evidence"] >= 1
    assert payload["stability_slice"]["command"]
    assert "--repeat 2" in payload["stability_slice"]["command"]


def test_surface_contract_violations_flow_into_compare_diagnose_and_propose(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "contract-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="contract-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    assert _run(tmp_path, "run", "--agent-id", "contract-agent", "--eval-id", "contract-eval", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    baseline = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    _write_surface_agent_spec(
        tmp_path,
        agent_id="contract-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
        lookup_enabled=False,
        memory_enabled=False,
        force_contract_violation=True,
        omit_mcp_servers_used=True,
    )
    assert _run(tmp_path, "run", "--agent-id", "contract-agent", "--eval-id", "contract-eval", "--subset", "full") == 0
    candidate = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]

    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    assert compare_payload["behavior_deltas"]["surface_contract_violation_count_delta"] > 0
    assert compare_payload["behavior_deltas"]["tool_used_not_enabled_added"] == ["lookup"]
    assert compare_payload["behavior_deltas"]["mcp_used_not_enabled_added"] == ["memory"]
    assert compare_payload["behavior_deltas"]["mcp_referenced_not_listed_added"] == ["memory"]
    assert any(item["category"] == "surface_contract_violation" for item in compare_payload["failure_clusters"])
    assert compare_payload["changed_cases"][0]["candidate_evidence"]["surface_contract_audits"]["violations"]

    assert _run(tmp_path, "diagnose", "--experiment", candidate) == 0
    diagnose_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "diagnose-latest.json").read_text(encoding="utf-8")
    )
    assert "surface_contract" in {item["category"] for item in diagnose_payload["suggested_mutations"]}
    assert diagnose_payload["focus_cases"][0]["candidate_evidence"]["surface_contract_audits"]["violations"]

    assert _run(tmp_path, "propose", "--experiment", candidate, "--limit", "5") == 0
    proposals_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "proposals" / "latest.json").read_text(encoding="utf-8")
    )
    assert any(item["category"] == "surface_contract" for item in proposals_payload["proposals"])


def test_promote_can_require_stability_runs(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    workbench = tmp_path / CONTROL_DIR_NAME / "workbench.yaml"
    workbench.write_text(
        "\n".join(
            [
                "snapshot_mode: auto",
                "artifacts_dir: .agent-workbench/runs",
                "gates:",
                "  min_average_score_delta: 0.0",
                "  min_average_score: 0.0",
                "  min_passed_case_delta: 0",
                "  require_clean_benchmark: true",
                "  max_average_latency_ms_delta: null",
                "  max_average_step_count_delta: null",
                "  max_average_cost_estimate_delta: null",
                "  max_regressed_cases: 0",
                "  min_stability_runs: 2",
                "  max_average_score_stddev: 0.01",
                "",
            ]
        ),
        encoding="utf-8",
    )
    _write_eval_fixture(tmp_path, "stable-eval")
    _write_surface_agent_files(tmp_path)
    _write_surface_agent_spec(
        tmp_path,
        agent_id="stable-agent",
        provider="groq",
        model_name="groq/llama-3.1-8b-instant",
        model_id="llama-3.1-8b-instant",
    )
    assert _run(tmp_path, "run", "--agent-id", "stable-agent", "--eval-id", "stable-eval", "--subset", "full") == 0
    runs_root = tmp_path / CONTROL_DIR_NAME / "runs"
    single_experiment = sorted(path.name for path in runs_root.iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "promote", "--experiment", single_experiment) == 0
    promotion_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "promotion-latest.json").read_text(encoding="utf-8")
    )
    assert promotion_payload["promotion_status"] == "rejected"
    assert promotion_payload["gate_results"]["candidate_stability_runs"]["passed"] is False
    assert promotion_payload["gate_results"]["candidate_score_stddev"]["actual"] is None

    assert (
        _run(
            tmp_path,
            "run",
            "--agent-id",
            "stable-agent",
            "--eval-id",
            "stable-eval",
            "--subset",
            "full",
            "--repeat",
            "2",
        )
        == 0
    )
    stability_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "stability" / "latest.json").read_text(encoding="utf-8")
    )
    assert _run(tmp_path, "promote", "--experiment", stability_payload["representative_experiment_id"]) == 0
    promotion_payload = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / "promotion-latest.json").read_text(encoding="utf-8")
    )
    assert promotion_payload["promotion_status"] == "promoted"
    assert promotion_payload["gate_results"]["candidate_stability_runs"]["passed"] is True


def test_show_export_and_migrate_commands_work_on_experiment_artifacts(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0

    code, stdout, _stderr = _run_capture(
        tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke"
    )
    experiment_id = json.loads(stdout)["experiment"]["experiment_id"]
    assert code == 0

    code, stdout, _stderr = _run_capture(tmp_path, "show", "experiment", "--experiment", experiment_id)
    show_payload = json.loads(stdout)
    assert code == 0
    assert show_payload["experiment"]["experiment_id"] == experiment_id
    assert show_payload["rows"]

    first_case_id = show_payload["rows"][0]["case"]["id"]
    code, stdout, _stderr = _run_capture(
        tmp_path, "show", "case", "--experiment", experiment_id, "--case-id", first_case_id
    )
    case_payload = json.loads(stdout)
    assert code == 0
    assert case_payload["case_id"] == first_case_id

    export_path = tmp_path / "bundle.json"
    code, stdout, _stderr = _run_capture(
        tmp_path, "export", "--experiment", experiment_id, "--output", str(export_path)
    )
    export_payload = json.loads(stdout)
    assert code == 0
    assert export_payload["experiment"]["experiment_id"] == experiment_id
    assert json.loads(export_path.read_text(encoding="utf-8"))["experiment"]["experiment_id"] == experiment_id

    experiment_json = tmp_path / CONTROL_DIR_NAME / "runs" / experiment_id / "experiment.json"
    payload = json.loads(experiment_json.read_text(encoding="utf-8"))
    payload.pop("artifact_schema_version", None)
    experiment_json.write_text(json.dumps(payload), encoding="utf-8")

    code, stdout, _stderr = _run_capture(tmp_path, "migrate")
    migrate_payload = json.loads(stdout)
    assert code == 0
    assert migrate_payload["experiments_migrated"] >= 1
    assert json.loads(experiment_json.read_text(encoding="utf-8"))["artifact_schema_version"] == "awb.artifact.v1"


def test_evals_export_and_import_round_trip(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "portable-eval")

    bundle_path = tmp_path / "portable-benchmark.json"
    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "export",
        "--eval-id",
        "portable-eval",
        "--output",
        str(bundle_path),
        "--benchmark-id",
        "portable-benchmark",
    )
    assert code == 0
    assert stderr == ""
    export_payload = json.loads(stdout)
    assert export_payload["benchmark_id"] == "portable-benchmark"
    assert bundle_path.exists()

    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "import",
        "--input",
        str(bundle_path),
        "--eval-id",
        "portable-copy",
    )
    assert code == 0
    assert stderr == ""
    import_payload = json.loads(stdout)
    assert import_payload["eval_id"] == "portable-copy"
    imported_suite = read_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "portable-copy.suite.yaml")
    imported_cases = (tmp_path / CONTROL_DIR_NAME / "evals" / "portable-copy.jsonl").read_text(encoding="utf-8")
    imported_scorer = (tmp_path / CONTROL_DIR_NAME / "scorers" / "portable-copy_default.py").read_text(encoding="utf-8")
    assert imported_suite["id"] == "portable-copy"
    assert "portable-eval-workflow-a" in imported_cases
    assert "def score_case" in imported_scorer


def test_evals_import_requires_force_to_replace_existing_suite(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "portable-eval")
    bundle_path = tmp_path / "portable-benchmark.json"
    assert _run(tmp_path, "evals", "export", "--eval-id", "portable-eval", "--output", str(bundle_path)) == 0

    existing_suite = tmp_path / CONTROL_DIR_NAME / "evals" / "portable-copy.suite.yaml"
    existing_suite.write_text("id: portable-copy\napproval_status: draft\n", encoding="utf-8")

    code, _stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "import",
        "--input",
        str(bundle_path),
        "--eval-id",
        "portable-copy",
    )
    assert code == 1
    assert "already exists" in stderr

    code, stdout, stderr = _run_capture(
        tmp_path,
        "evals",
        "import",
        "--input",
        str(bundle_path),
        "--eval-id",
        "portable-copy",
        "--force",
    )
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    assert payload["eval_id"] == "portable-copy"
    suite = read_yaml(existing_suite)
    assert suite["id"] == "portable-copy"
    assert suite["generated_case_count"] == 3
    assert sorted(suite["tags"]) == ["output", "workflow"]


def test_benchmarks_register_list_and_install(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "registry-eval")

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "register",
        "--eval-id",
        "registry-eval",
        "--benchmark-id",
        "workflow-pack",
    )
    assert code == 0
    assert stderr == ""
    register_payload = json.loads(stdout)
    assert register_payload["benchmark_id"] == "workflow-pack"
    assert register_payload["version"] == 1

    code, stdout, stderr = _run_capture(tmp_path, "benchmarks", "list")
    assert code == 0
    assert stderr == ""
    list_payload = json.loads(stdout)
    assert list_payload["benchmarks"][0]["benchmark_id"] == "workflow-pack"
    assert list_payload["benchmarks"][0]["version"] == 1
    assert list_payload["benchmarks"][0]["fingerprint"]

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "install",
        "--benchmark-id",
        "workflow-pack",
        "--eval-id",
        "workflow-pack-copy",
    )
    assert code == 0
    assert stderr == ""
    install_payload = json.loads(stdout)
    assert install_payload["eval_id"] == "workflow-pack-copy"
    assert install_payload["version"] == 1
    installed_suite = read_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "workflow-pack-copy.suite.yaml")
    assert installed_suite["id"] == "workflow-pack-copy"


def test_benchmarks_support_versions_filters_checks_and_diffs(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "registry-eval")

    suite_path = tmp_path / CONTROL_DIR_NAME / "evals" / "registry-eval.suite.yaml"
    suite = read_yaml(suite_path)
    suite["metadata"] = {
        "benchmark": {
            "origin_repo": "github.com/example/coding-agents",
            "author": "awb-team",
            "version": "2026.04",
            "license": "MIT",
            "intended_agent_type": "coding",
            "required_capabilities": ["tools", "patching"],
            "description": "Coding regression pack",
        }
    }
    write_yaml(suite_path, suite)

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "register",
        "--eval-id",
        "registry-eval",
        "--benchmark-id",
        "workflow-pack",
    )
    assert code == 0
    assert stderr == ""
    version_one = json.loads(stdout)
    assert version_one["version"] == 1
    assert version_one["created_new_version"] is True

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "register",
        "--eval-id",
        "registry-eval",
        "--benchmark-id",
        "workflow-pack",
    )
    assert code == 0
    assert stderr == ""
    duplicate_payload = json.loads(stdout)
    assert duplicate_payload["version"] == 1
    assert duplicate_payload["created_new_version"] is False
    assert duplicate_payload["duplicate_fingerprint"] is True

    suite = read_yaml(suite_path)
    suite["notes"] = ["expanded benchmark coverage"]
    write_yaml(suite_path, suite)

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "register",
        "--eval-id",
        "registry-eval",
        "--benchmark-id",
        "workflow-pack",
    )
    assert code == 0
    assert stderr == ""
    version_two = json.loads(stdout)
    assert version_two["version"] == 2
    assert version_two["created_new_version"] is True

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "list",
        "--all-versions",
        "--capability",
        "tools",
        "--agent-type",
        "coding",
        "--match",
        "regression",
    )
    assert code == 0
    assert stderr == ""
    filtered_payload = json.loads(stdout)
    assert filtered_payload["benchmark_count"] == 2
    assert {item["version"] for item in filtered_payload["benchmarks"]} == {1, 2}

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "show",
        "--benchmark-id",
        "workflow-pack",
        "--version",
        "1",
    )
    assert code == 0
    assert stderr == ""
    show_payload = json.loads(stdout)
    assert show_payload["entry"]["version"] == 1
    assert show_payload["benchmark_metadata"]["intended_agent_type"] == "coding"

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "check",
        "--benchmark-id",
        "workflow-pack",
        "--version",
        "1",
    )
    assert code == 0
    assert stderr == ""
    check_payload = json.loads(stdout)
    assert check_payload["version"] == 1
    assert check_payload["integrity"]["healthy"] is True
    assert check_payload["integrity"]["missing_metadata_fields"] == []

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "diff",
        "--benchmark-id",
        "workflow-pack",
        "--version-a",
        "1",
        "--version-b",
        "2",
    )
    assert code == 0
    assert stderr == ""
    diff_payload = json.loads(stdout)
    assert diff_payload["version_a"] == 1
    assert diff_payload["version_b"] == 2
    assert diff_payload["diff"]["fingerprint_changed"] is True

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "install",
        "--benchmark-id",
        "workflow-pack",
        "--version",
        "1",
        "--eval-id",
        "workflow-pack-v1-copy",
    )
    assert code == 0
    assert stderr == ""
    install_payload = json.loads(stdout)
    assert install_payload["version"] == 1
    installed_suite = read_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "workflow-pack-v1-copy.suite.yaml")
    assert installed_suite["id"] == "workflow-pack-v1-copy"


def test_benchmarks_check_flags_duplicate_inputs_and_case_specific_scorers(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "registry-eval")

    cases_path = tmp_path / CONTROL_DIR_NAME / "evals" / "registry-eval.jsonl"
    cases = [json.loads(line) for line in cases_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    cases[1]["input"] = cases[0]["input"]
    cases[0]["expected"] = "approved answer text"
    cases_path.write_text("".join(json.dumps(item) + "\n" for item in cases), encoding="utf-8")

    scorer_path = tmp_path / CONTROL_DIR_NAME / "scorers" / "registry-eval_default.py"
    scorer_path.write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact: dict, case: dict) -> dict:",
                "    if case.get('id') == 'registry-eval-workflow-a':",
                "        passed = 'approved answer text' in str(run_artifact.get('final_output') or '')",
                "    else:",
                "        passed = False",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'custom'}",
            ]
        ),
        encoding="utf-8",
    )

    assert _run(tmp_path, "benchmarks", "register", "--eval-id", "registry-eval", "--benchmark-id", "workflow-pack") == 0

    code, stdout, stderr = _run_capture(tmp_path, "benchmarks", "check", "--benchmark-id", "workflow-pack")
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    warnings = payload["integrity"]["warnings"]
    assert any("Duplicate normalized inputs" in item for item in warnings)
    assert any("Scorer contains case-specific identifiers" in item for item in warnings)


def test_benchmark_ingestion_pipeline_publishes_sharded_bundle(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    source_path = tmp_path / "support-source.jsonl"
    source_rows = [
        {
            "id": "ticket-1",
            "input": "Can this customer get a refund?",
            "expected": "Quote the refund policy.",
            "rubric": ["Must cite policy.", "Must not invent exceptions."],
            "tags": ["support", "refund"],
        },
        {
            "id": "ticket-2",
            "input": "Can this customer get a refund?",
            "expected": "Quote the refund policy.",
            "rubric": ["Must cite policy."],
            "tags": ["support", "duplicate"],
        },
        {
            "id": "ticket-3",
            "input": "How should damaged items be handled?",
            "expected": "Use the damaged-item workflow.",
            "rubric": ["Mention evidence requirements."],
            "tags": ["support", "workflow"],
        },
        {
            "id": "ticket-4",
            "input": "Escalate a policy exception request.",
            "expected": "Escalate only when policy allows it.",
            "rubric": ["Preserve escalation constraints."],
            "tags": ["support", "escalation"],
        },
    ]
    source_path.write_text("".join(json.dumps(row) + "\n" for row in source_rows), encoding="utf-8")

    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "ingest",
        "--source",
        str(source_path),
        "--benchmark-id",
        "support-large",
        "--version",
        "1",
        "--source-name",
        "support-export",
        "--dataset-revision",
        "rev-2026-04",
        "--license",
        "CC-BY-4.0",
        "--shard-size",
        "2",
        "--workers",
        "2",
    )
    assert code == 0
    assert stderr == ""
    ingest_payload = json.loads(stdout)
    assert ingest_payload["stage"] == "ingested"
    assert ingest_payload["raw_row_count"] == 4
    assert ingest_payload["shard_count"] == 2

    assert (
        _run(
            tmp_path,
            "benchmarks",
            "normalize",
            "--benchmark-id",
            "support-large",
            "--version",
            "1",
            "--answer-type",
            "rubric",
            "--answer-type",
            "human_reviewed",
            "--workers",
            "2",
        )
        == 0
    )
    assert (
        _run(
            tmp_path,
            "benchmarks",
            "dedupe",
            "--benchmark-id",
            "support-large",
            "--version",
            "1",
            "--strategy",
            "exact_input",
        )
        == 0
    )
    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "validate",
        "--benchmark-id",
        "support-large",
        "--version",
        "1",
        "--workers",
        "2",
    )
    assert code == 0
    assert stderr == ""
    validation_payload = json.loads(stdout)
    assert validation_payload["validation"]["healthy"] is True
    assert validation_payload["validation"]["case_count"] == 3
    assert validation_payload["validation"]["answer_type_counts"]["human_reviewed"] == 3

    assert (
        _run(
            tmp_path,
            "benchmarks",
            "review",
            "--benchmark-id",
            "support-large",
            "--version",
            "1",
            "--approve",
            "--guidance",
            "Source labels were reviewed by the support policy owner.",
        )
        == 0
    )
    code, stdout, stderr = _run_capture(
        tmp_path,
        "benchmarks",
        "publish",
        "--benchmark-id",
        "support-large",
        "--version",
        "1",
        "--eval-id",
        "support-large-installed",
    )
    assert code == 0
    assert stderr == ""
    publish_payload = json.loads(stdout)
    assert publish_payload["stage"] == "published"
    assert publish_payload["registry_entry"]["sharded"] is True
    assert publish_payload["case_count"] == 3

    assert (
        _run(
            tmp_path,
            "benchmarks",
            "install",
            "--benchmark-id",
            "support-large",
            "--version",
            "1",
            "--eval-id",
            "support-copy",
        )
        == 0
    )
    installed_cases = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "evals" / "support-copy.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(installed_cases) == 3
    provenance = installed_cases[0]["metadata"]["benchmark_provenance"]
    assert provenance["source_name"] == "support-export"
    assert provenance["source_revision"] == "rev-2026-04"
    assert provenance["license"] == "CC-BY-4.0"
    assert provenance["answer_type"] == ["rubric", "human_reviewed"]

    manifest = read_yaml(tmp_path / CONTROL_DIR_NAME / "benchmarks" / "ingested" / "support-large" / "v1" / "manifest.yaml")
    assert manifest["stage"] == "published"
    assert manifest["duplicate_count"] == 1
    assert manifest["shards"]["deduped"][0]["hash"]

    code, stdout, stderr = _run_capture(tmp_path, "benchmarks", "jobs", "--limit", "10")
    assert code == 0
    assert stderr == ""
    jobs_payload = json.loads(stdout)
    assert jobs_payload["job_count"] >= 3
    assert {job["stage"] for job in jobs_payload["jobs"]} >= {"ingest", "normalize", "dedupe", "validate"}


def test_review_command_writes_html_artifact(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0

    code, stdout, _stderr = _run_capture(
        tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke"
    )
    experiment_id = json.loads(stdout)["experiment"]["experiment_id"]
    assert code == 0
    case_id = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.jsonl").read_text(encoding="utf-8").splitlines()[0]
    )["id"]

    queue_path = tmp_path / CONTROL_DIR_NAME / "reports" / f"diagnose-review-queue-{experiment_id}.json"
    write_json(
        queue_path,
        {
            "queue_id": f"diagnose-{experiment_id}",
            "items": [
                {
                    "checkpoint_id": "pairwise-1",
                    "title": "Choose the better answer",
                    "priority": "high",
                    "question": "Which answer should win?",
                    "reason": "Subjective tone difference.",
                    "review_type": "subjective_review",
                    "question_type": "pairwise_acceptance",
                    "related_case_ids": [case_id],
                }
            ],
        },
    )

    review_path = tmp_path / "review.html"
    code, stdout, _stderr = _run_capture(
        tmp_path,
        "review",
        "--experiment",
        experiment_id,
        "--baseline",
        experiment_id,
        "--queue-id",
        f"diagnose-{experiment_id}",
        "--output",
        str(review_path),
    )
    payload = json.loads(stdout)
    html = review_path.read_text(encoding="utf-8")

    assert code == 0
    assert payload["experiment_id"] == experiment_id
    assert payload["queue_id"] == f"diagnose-{experiment_id}"
    assert payload["output_path"] == str(review_path.resolve())
    assert "Experiment Review" in html
    assert experiment_id in html
    assert "case-card" in html
    assert "Prompt Snapshots" in html
    assert "Pairwise Review Queue" in html
    assert "Copy awb human-review answer" in html
    assert "awb run replay --experiment" in html
    assert "Diff" in html


def test_replay_command_uses_source_experiment_defaults(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    assert (
        _run(tmp_path, "brief", "start", "--brief-id", "assistant", "--goal", "Answer repo questions accurately") == 0
    )
    assert _run(tmp_path, "brief", "finalize", "--brief-id", "assistant") == 0
    assert _run(tmp_path, "evals", "generate", "--brief-id", "assistant", "--eval-id", "assistant-eval") == 0
    assert _run(tmp_path, "evals", "approve", "--eval-id", "assistant-eval") == 0

    code, stdout, _stderr = _run_capture(
        tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "assistant-eval", "--subset", "smoke"
    )
    assert code == 0
    experiment_id = json.loads(stdout)["experiment"]["experiment_id"]
    case_id = str(read_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "assistant-eval.splits.yaml")["smoke"][0])

    code, stdout, stderr = _run_capture(
        tmp_path,
        "run",
        "replay",
        "--experiment",
        experiment_id,
        "--case-id",
        case_id,
    )
    assert code == 0
    assert stderr == ""
    replay_payload = json.loads(stdout)
    assert replay_payload["experiment"]["agent_id"] == "sample-agent"
    assert replay_payload["experiment"]["eval_id"] == "assistant-eval"
    assert replay_payload["aggregate"]["total_cases"] == 1


def test_replay_command_can_replay_failure_cluster_cases(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "cluster-replay-eval")
    _write_constant_agent(tmp_path, "baseline-agent", output_text="fallback")
    _write_constant_agent(tmp_path, "candidate-agent", output_text="approved")

    assert _run(tmp_path, "run", "--agent-id", "baseline-agent", "--eval-id", "cluster-replay-eval", "--subset", "full") == 0
    baseline = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]
    assert _run(tmp_path, "run", "--agent-id", "candidate-agent", "--eval-id", "cluster-replay-eval", "--subset", "full") == 0
    candidate = sorted(path.name for path in (tmp_path / CONTROL_DIR_NAME / "runs").iterdir() if path.is_dir())[-1]

    assert _run(tmp_path, "compare", "--baseline", baseline, "--candidate", candidate) == 0
    compare_json = json.loads(
        (tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(
            encoding="utf-8"
        )
    )
    cluster_id = str(compare_json["failure_clusters"][0]["cluster_id"])
    expected_case_count = len(compare_json["failure_clusters"][0]["case_ids"])

    code, stdout, stderr = _run_capture(
        tmp_path,
        "run",
        "replay",
        "--baseline",
        baseline,
        "--candidate",
        candidate,
        "--cluster",
        cluster_id,
    )
    assert code == 0
    assert stderr == ""
    replay_payload = json.loads(stdout)
    assert replay_payload["aggregate"]["total_cases"] == expected_case_count
    assert replay_payload["replay_source"]["selection_mode"] == "clusters"
    assert replay_payload["replay_source"]["comparison"]["cluster_ids"] == [cluster_id]


def test_scorer_audit_reports_low_confidence_and_unknown_scores(tmp_path: Path) -> None:
    assert _run(tmp_path, "init") == 0
    _write_eval_fixture(tmp_path, "judge-audit-eval")
    _write_constant_agent(tmp_path, "judge-audit-agent", output_text="approved")
    scorer_path = tmp_path / CONTROL_DIR_NAME / "scorers" / "judge-audit-eval_default.py"
    scorer_path.write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "from agentworkbench.scorers import ConfidenceInterval, enrich_score_with_judgment, model_judged_score",
                "",
                "def score_cases(run_artifact: dict, case: dict) -> list[dict]:",
                "    base = {",
                "        'name': 'output_quality',",
                "        'value': 1.0,",
                "        'passed': True,",
                "        'reason': 'fixture',",
                "    }",
                "    judged = model_judged_score(",
                "        prompt='Judge correctness',",
                "        model='judge-a' if case.get('id', '').endswith('a') else 'judge-b',",
                "        evidence=['fixture'],",
                "        confidence=0.55 if case.get('id', '').endswith('a') else 0.92,",
                "        confidence_interval=ConfidenceInterval(0.2, 0.6, 200, 0.05) if case.get('id', '').endswith('a') else ConfidenceInterval(0.85, 0.95, 200, 0.05),",
                "    )",
                "    output_quality = enrich_score_with_judgment(base, judged)",
                "    process_alignment = {",
                "        'name': 'process_alignment',",
                "        'value': 1.0,",
                "        'passed': True,",
                "        'reason': 'fixture',",
                "    }",
                "    return [output_quality, process_alignment]",
            ]
        ),
        encoding="utf-8",
    )

    code, stdout, _stderr = _run_capture(
        tmp_path,
        "run",
        "--agent-id",
        "judge-audit-agent",
        "--eval-id",
        "judge-audit-eval",
        "--subset",
        "full",
    )
    assert code == 0
    experiment_id = json.loads(stdout)["experiment"]["experiment_id"]

    code, stdout, stderr = _run_capture(tmp_path, "scorer-audit", "--experiment", experiment_id)
    assert code == 0
    assert stderr == ""
    payload = json.loads(stdout)
    report_path = tmp_path / CONTROL_DIR_NAME / "reports" / f"scorer-audit-{experiment_id}.md"
    report_text = report_path.read_text(encoding="utf-8")

    assert "Metric `output_quality` uses multiple judge models: judge-a, judge-b." in payload["issues"]
    assert "Metric `process_alignment` has scores without judgment metadata." in payload["issues"]
    assert payload["metric_audits"]["output_quality"]["low_confidence_cases"]
    assert payload["metric_audits"]["output_quality"]["wide_confidence_interval_cases"]
    assert payload["metric_audits"]["process_alignment"]["unknown_scores"] > 0
    assert payload["suggested_commands"][0].startswith(f"awb run replay --experiment {experiment_id}")
    assert "## Metrics" in report_text


# ---------------------------------------------------------------------------
# CLI Contract Tests (Script 2)
# ---------------------------------------------------------------------------


class TestExitCodeTaxonomy:
    """Every user-facing command has deterministic exit behavior."""

    def test_unknown_command_returns_1(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "nonexistent")
        assert code == 1
        assert "nonexistent" in stderr

    def test_missing_required_arg_returns_1(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "run")
        assert code == 1

    def test_keyboard_interrupt_returns_130(self, tmp_path):
        with patch("agentworkbench.cli.build_parser", side_effect=KeyboardInterrupt):
            code = main([])
            assert code == 130

    def test_file_not_found_returns_1(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "show", "experiment", "--experiment", "nonexistent")
        assert code == 1

    def test_value_error_returns_1(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "brief", "bogus")
        assert code == 1


class TestStdoutShape:
    """Stdout shape consistency across commands."""

    def test_init_emits_text_not_json(self, tmp_path):
        code, stdout, stderr = _run_capture(tmp_path, "init")
        assert code == 0
        assert "Initialized" in stdout
        assert stderr == ""

    def test_learn_emits_text(self, tmp_path):
        _run(tmp_path, "init")
        code, stdout, stderr = _run_capture(tmp_path, "learn")
        assert code == 0
        assert stderr == ""


class TestStderrShape:
    """Stderr is empty on success, contains human-readable messages on error."""

    def test_successful_command_has_no_stderr(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "init")
        assert code == 0
        assert stderr == ""

    def test_error_message_on_stderr(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "show", "experiment", "--experiment", "does-not-exist")
        assert code == 1
        assert len(stderr.strip()) > 0

    def test_no_raw_traceback_on_user_error(self, tmp_path):
        code, _stdout, stderr = _run_capture(tmp_path, "brief", "invalid-command")
        assert code == 1
        assert "Traceback" not in stderr
        assert "invalid-command" in stderr


class TestJsonOutputMode:
    """Read-only inspection commands support --format json."""

    def test_adapters_format_json(self, tmp_path):
        code, stdout, _stderr = _run_capture(tmp_path, "adapters", "--format", "json")
        assert code == 0
        parsed = json.loads(stdout)
        assert "adapters" in parsed

    def test_adapters_format_text(self, tmp_path):
        code, stdout, _stderr = _run_capture(tmp_path, "adapters", "--format", "text")
        assert code == 0
        assert not stdout.startswith("{")

    def test_doctor_format_json(self, tmp_path):
        _run(tmp_path, "init")
        code, stdout, _stderr = _run_capture(tmp_path, "doctor", "--format", "json")
        assert code in (0, 1)
        parsed = json.loads(stdout)
        assert "healthy" in parsed
        assert "checks" in parsed
        assert "issues" in parsed

    def test_doctor_format_text(self, tmp_path):
        _run(tmp_path, "init")
        code, stdout, _stderr = _run_capture(tmp_path, "doctor", "--format", "text")
        assert code in (0, 1)
        assert "Doctor" in stdout

    def test_traces_validate_format_json(self, tmp_path):
        _run(tmp_path, "init")
        _run(tmp_path, "brief", "start", "--brief-id", "test", "--goal", "test")
        _run(tmp_path, "brief", "finalize", "--brief-id", "test")
        _run(tmp_path, "evals", "generate", "--brief-id", "test", "--eval-id", "test-eval")
        _run(tmp_path, "evals", "approve", "--eval-id", "test-eval")
        code, stdout, _stderr = _run_capture(
            tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "test-eval", "--subset", "smoke"
        )
        experiment_id = json.loads(stdout)["experiment"]["experiment_id"]
        code, stdout, _stderr = _run_capture(
            tmp_path, "traces", "validate", "--experiment", experiment_id, "--format", "json"
        )
        assert code == 0
        parsed = json.loads(stdout)
        assert "provenance_summary" in parsed

    def test_traces_explain_format_json(self, tmp_path):
        _run(tmp_path, "init")
        _run(tmp_path, "brief", "start", "--brief-id", "test", "--goal", "test")
        _run(tmp_path, "brief", "finalize", "--brief-id", "test")
        _run(tmp_path, "evals", "generate", "--brief-id", "test", "--eval-id", "test-eval")
        _run(tmp_path, "evals", "approve", "--eval-id", "test-eval")
        code, stdout, _stderr = _run_capture(
            tmp_path, "run", "--agent-id", "sample-agent", "--eval-id", "test-eval", "--subset", "smoke"
        )
        experiment_id = json.loads(stdout)["experiment"]["experiment_id"]
        code, stdout, _stderr = _run_capture(
            tmp_path, "traces", "explain", "--experiment", experiment_id, "--format", "json"
        )
        assert code == 0
        parsed = json.loads(stdout)
        assert "field_provenance" in parsed

    def test_benchmarks_list_format_json(self, tmp_path):
        _run(tmp_path, "init")
        code, stdout, _stderr = _run_capture(tmp_path, "benchmarks", "list", "--format", "json")
        assert code == 0
        parsed = json.loads(stdout)
        assert isinstance(parsed, dict)


class TestUnexpectedExceptionHandling:
    """Unexpected exceptions never emit raw tracebacks to users."""

    def test_unexpected_exception_catch_all(self, tmp_path):
        from unittest.mock import patch

        with patch("agentworkbench.cli.dispatch", side_effect=RuntimeError("internal failure")):
            code, _stdout, stderr = _run_capture(tmp_path, "init")
            assert code == 1
            assert "Traceback" not in stderr
            assert "internal failure" in stderr
