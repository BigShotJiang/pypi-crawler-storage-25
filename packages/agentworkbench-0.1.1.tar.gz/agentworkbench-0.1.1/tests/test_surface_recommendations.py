from __future__ import annotations

from agentworkbench.surface_recommendations import build_surface_recommendations


def test_surface_recommendations_prioritize_grounding_for_helpful_tool() -> None:
    behavior = {
        "surface_audits": {
            "tools": {"available": ["lookup"]},
            "mcps": {"available": ["memory"]},
        },
        "tool_audits": {
            "lookup": {
                "attempted": 3,
                "success": 3,
                "selected_evidence": 3,
                "supported_evidence": 1,
                "selected_evidence_use_rate": 0.333,
                "cases_with_unsupported_selected_evidence": 2,
            }
        },
        "mcp_audits": {"memory": {"attempted": 3, "success": 3, "selected_evidence_use_rate": 1.0}},
        "unused_available_tools": [],
        "unused_available_mcps": [],
    }
    recommendations = build_surface_recommendations(
        behavior,
        factor_effects=[
            {
                "factor": "tools:lookup",
                "average_score_effect": 0.22,
                "average_cost_effect": 0.000008,
                "selected_evidence_use_rate_effect": 0.11,
            }
        ],
    )

    lookup = next(item for item in recommendations if item["surface"] == "tools:lookup")
    assert lookup["recommendation"] == "keep_enabled_fix_grounding"
    assert lookup["average_score_effect"] == 0.22
    assert lookup["cases_with_unsupported_selected_evidence"] == 2


def test_surface_recommendations_can_flag_prune_and_interaction_paths() -> None:
    behavior = {
        "surface_audits": {
            "tools": {"available": ["lookup"]},
            "mcps": {"available": ["memory"]},
        },
        "tool_audits": {"lookup": {"attempted": 2, "success": 2, "selected_evidence_use_rate": 1.0}},
        "mcp_audits": {"memory": {"attempted": 0, "success": 0}},
        "unused_available_tools": [],
        "unused_available_mcps": ["memory"],
    }
    recommendations = build_surface_recommendations(
        behavior,
        factor_effects=[
            {
                "factor": "tools:lookup",
                "average_score_effect": 0.14,
                "average_cost_effect": 0.000004,
                "selected_evidence_use_rate_effect": 0.05,
            },
            {
                "factor": "mcps:memory",
                "average_score_effect": -0.09,
                "average_cost_effect": 0.000006,
                "selected_evidence_use_rate_effect": -0.02,
            },
        ],
        pair_interactions=[
            {
                "pair": "tools:lookup x prompts:reviewer",
                "average_score_interaction": 0.31,
            }
        ],
    )

    lookup = next(item for item in recommendations if item["surface"] == "tools:lookup")
    memory = next(item for item in recommendations if item["surface"] == "mcps:memory")
    assert lookup["recommendation"] == "keep_with_interaction"
    assert lookup["strongest_interaction"]["pair"] == "tools:lookup x prompts:reviewer"
    assert memory["recommendation"] == "prune_or_disable"
