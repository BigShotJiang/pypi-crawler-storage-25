from __future__ import annotations

import json

import pytest

from agentworkbench.config import CONTROL_DIR_NAME
from agentworkbench.evals import load_eval_cases
from agentworkbench.models import EvalCase
from agentworkbench.proposals import _target_files, generate_mutation_proposals
from agentworkbench.runner import (
    _failure_clusters,
    _load_experiment,
    compare_experiments,
    diagnose_experiment,
    run_experiment,
    status_summary,
)
from agentworkbench.scaffold import init_workbench
from agentworkbench.telemetry import enrich_run_artifact_payload
from agentworkbench.utils import read_json, read_jsonl, write_json, write_jsonl, write_text, write_yaml


def _prepare_eval(tmp_path, eval_id: str = "contract-eval") -> None:
    cases = [EvalCase(id="case-1", input="hello", expected="hello", rubric=[], tags=[])]
    write_jsonl(tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.jsonl", [case.model_dump(mode="json") for case in cases])
    write_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["case-1"], "full": ["case-1"]})
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "brief",
            "approval_status": "approved",
            "kind": "behavior",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": 1,
            "tags": [],
        },
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact, case):",
                "    return {'name': 'output_quality', 'value': 1.0, 'passed': True, 'reason': 'forced pass'}",
                "",
            ]
        ),
    )


def _write_python_agent_spec(tmp_path, *, timeout_seconds: int = 30) -> None:
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: python",
                "instructions: []",
                "prompts: {}",
                "model: {name: python-model}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  python:",
                "    callable: sample_runtime:run_case",
                "    cwd: .",
                f"    timeout_seconds: {timeout_seconds}",
                "metadata: {}",
                "",
            ]
        ),
    )


def test_init_preserves_existing_custom_files(tmp_path) -> None:
    init_workbench(tmp_path)
    (tmp_path / "AGENTS.md").write_text("# custom agents\n", encoding="utf-8")
    (tmp_path / CONTROL_DIR_NAME / "workbench.yaml").write_text("project_root: custom\n", encoding="utf-8")
    (tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml").write_text("id: sample-agent\nadapter: legacy-runtime\n", encoding="utf-8")
    (tmp_path / ".github" / "agents" / "optimizer.agent.md").write_text("custom optimizer\n", encoding="utf-8")

    init_workbench(tmp_path)

    assert (tmp_path / "AGENTS.md").read_text(encoding="utf-8") == "# custom agents\n"
    assert (tmp_path / CONTROL_DIR_NAME / "workbench.yaml").read_text(encoding="utf-8") == "project_root: custom\n"
    assert (tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml").read_text(encoding="utf-8") == "id: sample-agent\nadapter: legacy-runtime\n"
    assert (tmp_path / ".github" / "agents" / "optimizer.agent.md").read_text(encoding="utf-8") == "custom optimizer\n"


def test_init_updates_existing_gitignore_with_generated_artifact_dirs(tmp_path) -> None:
    init_workbench(tmp_path)
    (tmp_path / ".gitignore").write_text("node_modules/\n", encoding="utf-8")

    init_workbench(tmp_path)
    lines = (tmp_path / ".gitignore").read_text(encoding="utf-8").splitlines()

    assert lines[0] == "node_modules/"
    for entry in [
        ".agent-workbench/runs/",
        ".agent-workbench/reports/",
        ".agent-workbench/exports/",
        ".agent-workbench/proposals/",
        ".agent-workbench/patches/",
        ".agent-workbench/ablations/",
        ".agent-workbench/matrices/",
        ".agent-workbench/factorials/",
        ".agent-workbench/iterations/",
        ".agent-workbench/stability/",
    ]:
        assert entry in lines
        assert lines.count(entry) == 1
    for relative in ["benchmarks", "exports", "cache", "cache/provider"]:
        assert (tmp_path / CONTROL_DIR_NAME / relative).is_dir()


def test_load_eval_cases_requires_suite_file(tmp_path) -> None:
    init_workbench(tmp_path)
    write_jsonl(
        tmp_path / CONTROL_DIR_NAME / "evals" / "legacy.jsonl",
        [EvalCase(id="case-1", input="hello", expected="", rubric=[], tags=[]).model_dump(mode="json")],
    )
    write_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "legacy.splits.yaml", {"smoke": ["case-1"], "full": ["case-1"]})

    with pytest.raises(ValueError, match="missing `legacy.suite.yaml`"):
        load_eval_cases(tmp_path, "legacy", "smoke")


def test_run_experiment_can_resume_partial_rows_with_parallel_jobs(tmp_path) -> None:
    init_workbench(tmp_path)
    cases = [
        EvalCase(id="case-1", input="one", expected="one", rubric=[], tags=[]),
        EvalCase(id="case-2", input="two", expected="two", rubric=[], tags=[]),
        EvalCase(id="case-3", input="three", expected="three", rubric=[], tags=[]),
    ]
    write_jsonl(tmp_path / CONTROL_DIR_NAME / "evals" / "resume-eval.jsonl", [case.model_dump(mode="json") for case in cases])
    write_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "resume-eval.splits.yaml", {"smoke": ["case-1"], "full": [case.id for case in cases]})
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "resume-eval.suite.yaml",
        {
            "id": "resume-eval",
            "brief_id": "brief",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": len(cases),
            "tags": [],
        },
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "scorers" / "resume-eval_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact, case):",
                "    output = str(run_artifact.get('final_output') or '')",
                "    expected = str(case.get('expected') or '')",
                "    passed = expected in output",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'match' if passed else 'miss'}",
                "",
            ]
        ),
    )

    record, _aggregate = run_experiment(tmp_path, "sample-agent", "resume-eval", "full")
    exp_dir = tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id
    rows = read_json(exp_dir / "aggregate.json")
    assert rows["total_cases"] == 3
    full_rows = read_jsonl(exp_dir / "runs.jsonl")
    write_jsonl(exp_dir / "runs.partial.jsonl", full_rows[:1])
    for name in ["runs.jsonl", "aggregate.json", "behavior.json", "experiment.json"]:
        path = exp_dir / name
        if path.exists():
            path.unlink()

    resumed_record, resumed_aggregate = run_experiment(
        tmp_path,
        "sample-agent",
        "resume-eval",
        "full",
        jobs=2,
        resume_experiment=record.experiment_id,
    )

    assert resumed_record.experiment_id == record.experiment_id
    assert resumed_record.completed_case_ids == ["case-1", "case-2", "case-3"]
    assert resumed_aggregate["total_cases"] == 3
    assert not (exp_dir / "runs.partial.jsonl").exists()
    assert len(read_jsonl(exp_dir / "runs.jsonl")) == 3


def test_run_experiment_fails_when_command_exits_non_zero(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {default: hi}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os, sys",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps({'final_output': 'hello'}))",
                "      sys.stderr.write('boom\\n')",
                "      raise SystemExit(7)",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert aggregate["average_score"] == 0.0
    assert rows[0]["passed"] is False
    assert rows[0]["artifact"]["errors"] == ["Command exited with 7", "boom"]
    assert any(score["name"] == "execution_status" and score["passed"] is False for score in rows[0]["scores"])


def test_run_experiment_fails_when_command_does_not_write_output_file(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {default: hi}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      print('hello')",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert aggregate["average_score"] == 0.0
    assert rows[0]["passed"] is False
    assert rows[0]["artifact"]["errors"] == ["Command did not write AWB_OUTPUT_PATH"]
    assert any(score["name"] == "execution_status" and score["passed"] is False for score in rows[0]["scores"])


def test_failure_clusters_ignore_cases_that_only_improved() -> None:
    clusters = _failure_clusters(
        None,
        [
            {
                "case_id": "case-1",
                "score_delta": 0.4,
                "reason": "improved relative to baseline",
                "trace_events_added": [],
                "trace_events_removed": [],
            }
        ],
        {},
    )
    assert clusters == []


def test_failure_clusters_classify_missing_next_action_as_response_structure_gap() -> None:
    clusters = _failure_clusters(
        None,
        [
            {
                "case_id": "case-1",
                "reason": "missing required terms: next action; grounded terms: frontline billing; matched preferred surfaces: preferred_tools",
                "candidate_evidence": {
                    "evidence_summary": {
                        "selected_count": 2,
                        "used_count": 1,
                    }
                },
                "trace_events_added": [],
                "trace_events_removed": [],
            }
        ],
        {},
    )
    assert clusters[0]["category"] == "response_structure_gap"


def test_failure_clusters_classify_provider_rate_limits_separately() -> None:
    clusters = _failure_clusters(
        None,
        [
            {
                "case_id": "case-1",
                "reason": "changed relative to baseline",
                "candidate_evidence": {
                    "errors": ["HTTP Error 429: Too Many Requests"],
                },
                "trace_events_added": [],
                "trace_events_removed": [],
            }
        ],
        {},
    )
    assert clusters[0]["category"] == "provider_rate_limit"


def test_failure_clusters_ignore_score_neutral_output_only_changes() -> None:
    clusters = _failure_clusters(
        None,
        [
            {
                "case_id": "case-1",
                "score_delta": 0.0,
                "trace_events_added": [],
                "trace_events_removed": [],
            }
        ],
        {},
    )
    assert clusters == []


def test_failure_clusters_keep_score_neutral_contract_violations() -> None:
    clusters = _failure_clusters(
        None,
        [
            {
                "case_id": "case-1",
                "score_delta": 0.0,
                "candidate_evidence": {
                    "surface_contract_audits": {
                        "violations": ["tool_used_not_enabled:lookup"],
                    }
                },
                "trace_events_added": [],
                "trace_events_removed": [],
            }
        ],
        {},
    )
    assert clusters[0]["category"] == "surface_contract_violation"


def test_load_experiment_refreshes_stale_behavior_summary(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path, "refresh-eval")
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {default: hi}",
                "model: {name: test}",
                "tools: [{name: lookup, enabled: true}]",
                "skills: []",
                "plugins: []",
                "mcps: [{name: filesystem, enabled: true}]",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'Ship in the current window.',",
                "          'tool_calls': [{'name': 'lookup', 'status': 'success', 'mcp': 'filesystem'}],",
                "          'evidence_records': [",
                "              {'kind': 'retrieval', 'name': 'lookup', 'mcp': 'filesystem', 'hits': [",
                "                  {'snippet': 'If a release only changes UI copy with no backend risk, ship in the current window.', 'selected': True, 'used_in_output': False}",
                "              ], 'used_count': 0, 'used_in_output': False}",
                "          ],",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
    )
    record, _aggregate = run_experiment(tmp_path, "sample-agent", "refresh-eval", "smoke")
    experiment_path = tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "experiment.json"
    payload = read_json(experiment_path)
    payload["behavior_summary"].pop("behavior_summary_version", None)
    payload["behavior_summary"]["selected_evidence_use_rate"] = 0.0
    write_json(experiment_path, payload)

    refreshed, _ = _load_experiment(tmp_path, record.experiment_id)
    assert refreshed.behavior_summary["behavior_summary_version"].startswith("awb.behavior.v")
    assert refreshed.behavior_summary["selected_evidence_use_rate"] == 1.0


def test_run_experiment_fails_when_output_file_is_invalid_json(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {default: hi}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import os",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write('{invalid json')",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert aggregate["average_score"] == 0.0
    assert rows[0]["passed"] is False
    assert rows[0]["artifact"]["errors"][0].startswith("AWB output file was not valid JSON:")
    assert any(score["name"] == "execution_status" and score["passed"] is False for score in rows[0]["scores"])


def test_run_experiment_supports_object_form_command_and_cwd(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    agent_dir = tmp_path / "agent_app"
    agent_dir.mkdir()
    write_text(
        agent_dir / "runner.py",
        "\n".join(
            [
                "import json, os",
                "payload = {",
                "    'final_output': os.environ['AWB_INPUT'],",
                "    'prompt_keys_used': ['system'],",
                "    'step_count': 1,",
                "}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "owned_paths:",
                "  - agent_app/runner.py",
                "surface_paths:",
                "  runtime:",
                "    - agent_app/runner.py",
                "required_env: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - runner.py",
                "    cwd: agent_app",
                "    timeout_seconds: 10",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")

    assert aggregate["passed_cases"] == 1
    assert record.spec_snapshot["command_cwd"] == "agent_app"
    assert record.spec_snapshot["owned_paths"] == ["agent_app/runner.py"]
    report = (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "report.md").read_text(encoding="utf-8")
    assert "Runtime entrypoint" in report
    assert "Owned files" in report


def test_run_experiment_fails_when_required_env_missing(tmp_path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "required_env:",
                "  - OPENAI_API_KEY",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - -c",
                "      - print('should not execute')",
                "    cwd: .",
                "    timeout_seconds: 10",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert rows[0]["artifact"]["errors"] == ["Missing required environment variables: OPENAI_API_KEY"]


def test_run_experiment_loads_required_env_from_workbench_env_file(tmp_path, monkeypatch) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "workbench.yaml",
        "\n".join(
            [
                "snapshot_mode: auto",
                "artifacts_dir: .agent-workbench/runs",
                "env_files:",
                "  - .env.providers.local",
                "gates:",
                "  min_average_score_delta: 0.0",
                "  min_passed_case_delta: 0",
                "  require_clean_benchmark: true",
                "  max_average_latency_ms_delta: null",
                "  max_average_step_count_delta: null",
                "  max_average_cost_estimate_delta: null",
                "  max_regressed_cases: 0",
                "",
            ]
        ),
    )
    write_text(tmp_path / ".env.providers.local", "OPENAI_API_KEY=test-from-file\n")
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "required_env:",
                "  - OPENAI_API_KEY",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - -c",
                "      - |",
                "        import json, os",
                "        payload = {'final_output': os.environ['OPENAI_API_KEY']}",
                "        open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "    cwd: .",
                "    timeout_seconds: 10",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 1
    assert rows[0]["artifact"]["final_output"] == "test-from-file"


def test_run_experiment_reports_timeout_for_object_command(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "required_env: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - -c",
                "      - |",
                "        import time",
                "        time.sleep(2)",
                "    cwd: .",
                "    timeout_seconds: 1",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert any("Command timed out after 1 seconds" in error for error in rows[0]["artifact"]["errors"])


def test_run_experiment_auto_enriches_sparse_runtime_telemetry(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts:",
                "  system: prompts/system.md",
                "  reviewer: prompts/reviewer.md",
                "model: {name: demo-model}",
                "tools:",
                "  - name: lookup",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps:",
                "  - name: filesystem",
                "    enabled: true",
                "  - name: memory",
                "    enabled: true",
                "required_env: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - -c",
                "      - |",
                "        import json, os",
                "        payload = {",
                "          'final_output': 'hello',",
                "          'events': [",
                "            {'kind': 'prompt_load', 'name': 'system'},",
                "            {'kind': 'retrieval', 'name': 'lookup', 'mcp': 'filesystem', 'status': 'success', 'hits': 1},",
                "            {'kind': 'memory_lookup', 'name': 'customer_memory', 'mcp': 'memory', 'status': 'success'},",
                "            {'kind': 'provider_response', 'name': 'success', 'provider': 'groq', 'model_name': 'demo-model'},",
                "          ],",
                "          'evidence_records': [",
                "            {",
                "              'kind': 'retrieval',",
                "              'name': 'lookup',",
                "              'query': 'hello',",
                "              'status': 'success',",
                "              'mcp': 'filesystem',",
                "              'hits': [{'snippet': 'hello', 'selected': True}],",
                "            }",
                "          ],",
                "        }",
                "        open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "    cwd: .",
                "    timeout_seconds: 10",
                "metadata: {}",
                "",
            ]
        ),
    )

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = read_jsonl(tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl")
    artifact = rows[0]["artifact"]

    assert aggregate["passed_cases"] == 1
    assert artifact["prompt_keys_used"] == ["system"]
    assert artifact["mcp_servers_used"] == ["filesystem", "memory"]
    assert artifact["tool_calls"][0]["name"] == "lookup"
    assert "tool:lookup" in artifact["workflow_trace"]
    assert "prompt:system" in artifact["workflow_trace"]
    assert artifact["trace_events"]
    assert artifact["metadata"]["provider"] == "groq"
    assert artifact["metadata"]["model_name"] == "demo-model"
    assert int(artifact["step_count"]) >= 1


def test_enrich_run_artifact_preserves_explicit_empty_surface_fields() -> None:
    artifact = enrich_run_artifact_payload(
        {
            "final_output": "fallback",
            "structured_output": {
                "mcp_servers_used": [],
                "tool_calls": [],
                "workflow_trace": ["prompt:system", "tool:lookup", "mcp:memory"],
                "prompt_keys_used": ["system"],
            },
            "events": [
                {"kind": "retrieval", "name": "lookup", "status": "success", "mcp": "memory"},
                {"kind": "memory_lookup", "name": "customer_memory", "status": "success", "mcp": "memory"},
            ],
            "evidence_records": [
                {"kind": "retrieval", "name": "lookup", "status": "success", "mcp": "memory", "hits": [{"selected": True}]}
            ],
            "workflow_trace": ["prompt:system", "tool:lookup", "mcp:memory"],
            "prompt_keys_used": ["system"],
            "mcp_servers_used": [],
            "tool_calls": [],
        },
        spec_snapshot={
            "prompt_keys": ["system"],
            "tool_names": ["lookup"],
            "mcp_names": ["memory"],
        },
    )

    assert artifact["prompt_keys_used"] == ["system"]
    assert artifact["tool_calls"] == []
    assert artifact["mcp_servers_used"] == []
    assert "mcp:memory" in artifact["workflow_trace"]
    assert artifact["trace_events"]


def test_compare_experiments_includes_statistical_summary(tmp_path) -> None:
    init_workbench(tmp_path)
    cases = [
        EvalCase(id="case-1", input="alpha", expected="approved", rubric=[], tags=[]),
        EvalCase(id="case-2", input="beta", expected="approved", rubric=[], tags=[]),
        EvalCase(id="case-3", input="gamma", expected="approved", rubric=[], tags=[]),
    ]
    write_jsonl(tmp_path / CONTROL_DIR_NAME / "evals" / "stats-eval.jsonl", [case.model_dump(mode="json") for case in cases])
    write_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / "stats-eval.splits.yaml", {"smoke": ["case-1"], "full": [case.id for case in cases]})
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / "stats-eval.suite.yaml",
        {
            "id": "stats-eval",
            "brief_id": "brief",
            "approval_status": "approved",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": len(cases),
            "tags": [],
        },
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "scorers" / "stats-eval_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact, case):",
                "    output = str(run_artifact.get('final_output') or '')",
                "    expected = str(case.get('expected') or '')",
                "    passed = expected in output",
                "    return {'name': 'output_quality', 'value': 1.0 if passed else 0.0, 'passed': passed, 'reason': 'match' if passed else 'miss'}",
                "",
            ]
        ),
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "baseline-agent.yaml",
        "\n".join(
            [
                "id: baseline-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      text = os.environ.get('AWB_INPUT', '')",
                "      out = 'approved' if text == 'alpha' else 'fallback'",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps({'final_output': out}))",
                "metadata: {}",
                "",
            ]
        ),
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "candidate-agent.yaml",
        "\n".join(
            [
                "id: candidate-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {}",
                "model: {name: test}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps({'final_output': 'approved'}))",
                "metadata: {}",
                "",
            ]
        ),
    )

    baseline_record, _ = run_experiment(tmp_path, "baseline-agent", "stats-eval", "full")
    candidate_record, _ = run_experiment(tmp_path, "candidate-agent", "stats-eval", "full")
    comparison = compare_experiments(tmp_path, baseline_record.experiment_id, candidate_record.experiment_id)

    assert comparison.statistical_summary["shared_case_count"] == 3
    score_summary = comparison.statistical_summary["average_score_delta"]
    assert score_summary["count"] == 3
    assert score_summary["ci_low"] <= score_summary["mean"] <= score_summary["ci_high"]
    assert comparison.statistical_summary["pass_rate_delta"]["probability_positive"] is not None


def test_run_experiment_python_adapter_respects_timeout(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_text(
        tmp_path / "sample_runtime.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "import time",
                "",
                "def run_case(case, context, project_root):",
                "    time.sleep(2)",
                "    return {'final_output': 'done'}",
                "",
            ]
        ),
    )
    _write_python_agent_spec(tmp_path, timeout_seconds=1)

    record, aggregate = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert aggregate["passed_cases"] == 0
    assert rows[0]["passed"] is False
    assert any("Python adapter timed out after 1 seconds" in error for error in rows[0]["artifact"]["errors"])


def test_run_experiment_python_adapter_reloads_target_module_between_runs(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    runtime_path = tmp_path / "sample_runtime.py"
    runtime_path.write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def run_case(case, context, project_root):",
                "    return {'final_output': 'first'}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    _write_python_agent_spec(tmp_path, timeout_seconds=30)

    first_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    first_rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / first_record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    runtime_path.write_text(
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def run_case(case, context, project_root):",
                "    return {'final_output': 'second output'}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    second_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    second_rows = [
        json.loads(line)
        for line in (tmp_path / CONTROL_DIR_NAME / "runs" / second_record.experiment_id / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert first_rows[0]["artifact"]["final_output"] == "first"
    assert second_rows[0]["artifact"]["final_output"] == "second output"


def test_status_normalizes_legacy_experiment_metadata(tmp_path) -> None:
    init_workbench(tmp_path)
    legacy_id = "legacy-agent-legacy-eval-smoke-20260330010101010101"
    experiment_dir = tmp_path / CONTROL_DIR_NAME / "runs" / legacy_id
    experiment_dir.mkdir(parents=True)
    write_json(
        experiment_dir / "experiment.json",
        {
            "experiment_id": legacy_id,
            "agent_id": "legacy-agent",
            "eval_id": "legacy-eval",
            "repo_before": {},
            "repo_after": {},
            "changed_files": [],
            "benchmark_hashes": {"briefs/legacy.yaml": "abc123"},
            "scores": {"average_score": 0.5, "passed_cases": 1, "total_cases": 1},
            "behavior_summary": {"average_cost_estimate": 0.0123},
            "status": "completed",
            "promotion_status": "candidate",
        },
    )

    status_payload = status_summary(tmp_path, agent_id="legacy-agent", eval_id="legacy-eval", subset="smoke")
    assert status_payload["total_experiments"] == 1
    assert status_payload["latest_experiment"]["subset"] == "smoke"
    assert status_payload["latest_experiment"]["created_at"] == "2026-03-30T01:01:01Z"


def test_status_prefers_latest_run_over_best_score_for_latest_fields(tmp_path) -> None:
    init_workbench(tmp_path)
    older_best_id = "legacy-agent-legacy-eval-smoke-20260330010101010101"
    newer_worse_id = "legacy-agent-legacy-eval-smoke-20260330010202020202"
    shared_hashes = {"briefs/legacy.yaml": "abc123"}

    for experiment_id, score in ((older_best_id, 1.0), (newer_worse_id, 0.5)):
        experiment_dir = tmp_path / CONTROL_DIR_NAME / "runs" / experiment_id
        experiment_dir.mkdir(parents=True)
        write_json(
            experiment_dir / "experiment.json",
            {
                "experiment_id": experiment_id,
                "agent_id": "legacy-agent",
                "eval_id": "legacy-eval",
                "repo_before": {},
                "repo_after": {},
                "changed_files": [],
                "benchmark_hashes": shared_hashes,
                "scores": {"average_score": score, "passed_cases": 1, "total_cases": 1},
                "behavior_summary": {"average_cost_estimate": 0.0123},
                "status": "completed",
                "promotion_status": "candidate",
            },
        )

    status_payload = status_summary(tmp_path, agent_id="legacy-agent", eval_id="legacy-eval", subset="smoke")

    assert status_payload["latest_experiment"]["experiment_id"] == newer_worse_id
    assert status_payload["streams"][0]["latest_run"]["experiment_id"] == newer_worse_id
    assert status_payload["streams"][0]["latest_candidate"]["experiment_id"] == newer_worse_id
    assert status_payload["streams"][0]["best_run"]["experiment_id"] == older_best_id


def test_compare_and_diagnose_surface_cost_budget_signal(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "workbench.yaml",
        {
            "gates": {
                "max_average_cost_estimate_delta": 0.0,
            }
        },
    )
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'hello',",
                "          'tool_calls': [{'name': 'repo_search'}],",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 100, 'output': 20},",
                "          'cost_estimate': 0.01,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    baseline_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    baseline_report = (
        tmp_path / CONTROL_DIR_NAME / "runs" / baseline_record.experiment_id / "report.md"
    ).read_text(encoding="utf-8")
    assert "Avg cost estimate" in baseline_report
    assert "Total token usage" in baseline_report

    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'hello',",
                "          'tool_calls': [{'name': 'repo_search'}],",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 240, 'output': 60},",
                "          'cost_estimate': 0.05,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    candidate_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    comparison = compare_experiments(tmp_path, baseline_record.experiment_id, candidate_record.experiment_id)

    assert comparison.gate_results["average_cost_estimate_delta"]["passed"] is False
    assert comparison.behavior_deltas["avg_cost_estimate_delta"] == pytest.approx(0.04)
    assert comparison.behavior_deltas["total_token_usage_deltas"] == {"input": 140, "output": 40}
    assert comparison.behavior_deltas["average_token_usage_deltas"] == {"input": 140.0, "output": 40.0}

    diagnosis = diagnose_experiment(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
    )
    categories = {item["category"] for item in diagnosis["suggested_mutations"]}
    assert "cost_budget" in categories

    proposals = generate_mutation_proposals(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
        limit=3,
    )
    proposal_categories = {item["category"] for item in proposals["proposals"]}
    assert "cost_budget" in proposal_categories


def test_token_only_overhead_triggers_cost_budget_diagnosis(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'hello',",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 100, 'output': 20},",
                "          'cost_estimate': 0.0,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    baseline_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'hello',",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "          'token_usage': {'input': 260, 'output': 40},",
                "          'cost_estimate': 0.0,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    candidate_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    diagnosis = diagnose_experiment(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
    )
    categories = {item["category"] for item in diagnosis["suggested_mutations"]}
    assert "cost_budget" in categories


def test_matched_retrieval_surfaces_trigger_retrieval_quality_diagnosis(tmp_path) -> None:
    init_workbench(tmp_path)
    eval_id = "grounding-eval"
    write_jsonl(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.jsonl",
        [
            EvalCase(
                id="case-1",
                input="Can this customer get a refund?",
                expected="manager approval",
                rubric=[],
                tags=["grounding"],
            ).model_dump(mode="json")
        ],
    )
    write_yaml(tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.splits.yaml", {"smoke": ["case-1"], "full": ["case-1"]})
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "brief",
            "approval_status": "approved",
            "kind": "behavior",
            "score_weights": {"output_quality": 0.7, "process_alignment": 0.3},
            "notes": [],
            "generated_case_count": 1,
            "tags": ["grounding"],
        },
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_cases(run_artifact, case):",
                "    final_output = (run_artifact.get('final_output') or '').strip().lower()",
                "    expected = (case.get('expected') or '').strip().lower()",
                "    tools = sorted({str((item or {}).get('name') or '') for item in (run_artifact.get('tool_calls') or []) if (item or {}).get('name')})",
                "    output_quality = {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if expected and expected in final_output else 0.0,",
                "        'passed': bool(expected and expected in final_output),",
                "        'reason': 'expected text present' if expected and expected in final_output else 'expected text missing',",
                "    }",
                "    process_alignment = {",
                "        'name': 'process_alignment',",
                "        'value': 1.0 if 'policy_search' in tools else 0.0,",
                "        'passed': 'policy_search' in tools,",
                "        'reason': 'matched preferred surfaces: preferred_tools' if 'policy_search' in tools else 'missing required_tools: policy_search',",
                "    }",
                "    return [output_quality, process_alignment]",
                "",
            ]
        ),
    )
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: policy_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      payload = {",
                "          'final_output': 'Refund requires manager approval.',",
                "          'tool_calls': [{'name': 'policy_search'}],",
                "          'prompt_keys_used': ['system'],",
                "          'step_count': 1,",
                "      }",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    baseline_record, _ = run_experiment(tmp_path, "sample-agent", eval_id, "smoke")
    spec_path.write_text(
        spec_path.read_text(encoding="utf-8").replace(
            "'final_output': 'Refund requires manager approval.'",
            "'final_output': 'Approve directly.'",
        ),
        encoding="utf-8",
    )
    candidate_record, _ = run_experiment(tmp_path, "sample-agent", eval_id, "smoke")
    diagnosis = diagnose_experiment(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
    )
    categories = [item["category"] for item in diagnosis["suggested_mutations"]]
    assert "retrieval_quality" in categories
    assert "prompt_grounding" in categories

    proposals = generate_mutation_proposals(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
        limit=2,
    )
    proposal_categories = [item["category"] for item in proposals["proposals"]]
    assert "retrieval_quality" in proposal_categories
    assert proposals["proposals"][0]["category"] == "retrieval_quality"
    assert any("--repeat 2" in command for command in proposals["proposals"][0]["validation_commands"])


def test_diagnose_prioritizes_current_failed_cases_over_neutral_output_churn(tmp_path) -> None:
    init_workbench(tmp_path)
    eval_id = "focus-eval"
    write_jsonl(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.jsonl",
        [
            EvalCase(id="changed-pass", input="alpha", expected="hello", rubric=[], tags=["output"]).model_dump(mode="json"),
            EvalCase(id="standing-fail", input="beta", expected="goodbye", rubric=[], tags=["output"]).model_dump(mode="json"),
        ],
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.splits.yaml",
        {"smoke": ["changed-pass", "standing-fail"], "full": ["changed-pass", "standing-fail"]},
    )
    write_yaml(
        tmp_path / CONTROL_DIR_NAME / "evals" / f"{eval_id}.suite.yaml",
        {
            "id": eval_id,
            "brief_id": "brief",
            "approval_status": "approved",
            "kind": "behavior",
            "score_weights": {"output_quality": 1.0},
            "notes": [],
            "generated_case_count": 2,
            "tags": ["output"],
        },
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "scorers" / f"{eval_id}_default.py",
        "\n".join(
            [
                "from __future__ import annotations",
                "",
                "def score_case(run_artifact, case):",
                "    final_output = (run_artifact.get('final_output') or '').strip().lower()",
                "    expected = (case.get('expected') or '').strip().lower()",
                "    passed = bool(expected and expected in final_output)",
                "    return {",
                "        'name': 'output_quality',",
                "        'value': 1.0 if passed else 0.0,",
                "        'passed': passed,",
                "        'reason': 'expected text present' if passed else 'expected text missing',",
                "    }",
                "",
            ]
        ),
    )
    spec_path = tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml"
    spec_path.write_text(
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts: {system: prompts/system.md}",
                "model: {name: baseline-model}",
                "tools: []",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - -c",
                "    - |",
                "      import json, os",
                "      outputs = {'alpha': 'hello', 'beta': 'nope'}",
                "      payload = {'final_output': outputs[os.environ['AWB_INPUT']], 'prompt_keys_used': ['system'], 'step_count': 1}",
                "      open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
                "metadata: {}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    baseline_record, _ = run_experiment(tmp_path, "sample-agent", eval_id, "smoke")
    spec_path.write_text(
        spec_path.read_text(encoding="utf-8").replace("'alpha': 'hello'", "'alpha': 'hello there'"),
        encoding="utf-8",
    )
    candidate_record, _ = run_experiment(tmp_path, "sample-agent", eval_id, "smoke")

    diagnosis = diagnose_experiment(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
    )
    assert diagnosis["focus_cases"][0]["case_id"] == "standing-fail"
    rationales = {item["category"]: item["rationale"] for item in diagnosis["suggested_mutations"]}
    assert rationales["prompt_grounding"] == "The current failing cases are still missing expected content."

    proposals = generate_mutation_proposals(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
        limit=3,
    )
    assert proposals["proposals"][0]["related_cases"][0] == "standing-fail"


def test_compare_tracks_between_run_surface_file_changes(tmp_path) -> None:
    init_workbench(tmp_path)
    _prepare_eval(tmp_path)
    agent_root = tmp_path / "agent_app"
    (agent_root / "prompts").mkdir(parents=True)
    write_text(
        agent_root / "runtime.py",
        "\n".join(
            [
                "import json, os",
                "payload = {",
                "    'final_output': 'hello',",
                "    'prompt_keys_used': ['system'],",
                "    'tool_calls': [{'name': 'repo_search'}],",
                "    'step_count': 1,",
                "}",
                "open(os.environ['AWB_OUTPUT_PATH'], 'w', encoding='utf-8').write(json.dumps(payload))",
            ]
        ),
    )
    write_text(agent_root / "prompts" / "system.md", "Baseline system prompt.\n")
    write_text(
        agent_root / "tools.py",
        "\n".join(
            [
                '"""Baseline repo search docs."""',
                "",
                "def repo_search(query: str) -> str:",
                "    return query",
                "",
            ]
        ),
    )
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions:",
                "  - Use the system prompt.",
                "prompts:",
                "  system: agent_app/prompts/system.md",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "owned_paths:",
                "  - agent_app/runtime.py",
                "  - agent_app/prompts/system.md",
                "  - agent_app/tools.py",
                "surface_paths:",
                "  prompts:",
                "    - agent_app/prompts/system.md",
                "  tools:",
                "    - agent_app/tools.py",
                "  runtime:",
                "    - agent_app/runtime.py",
                "required_env: []",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    argv:",
                "      - python3",
                "      - agent_app/runtime.py",
                "    cwd: .",
                "    timeout_seconds: 10",
                "metadata: {}",
                "",
            ]
        ),
    )

    baseline_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")

    write_text(agent_root / "prompts" / "system.md", "Candidate system prompt with stricter grounding.\n")
    write_text(
        agent_root / "tools.py",
        "\n".join(
            [
                '"""Candidate repo search docs with ranking guidance."""',
                "",
                "def repo_search(query: str) -> str:",
                "    return query.upper()",
                "",
            ]
        ),
    )

    candidate_record, _ = run_experiment(tmp_path, "sample-agent", "contract-eval", "smoke")
    comparison = compare_experiments(tmp_path, baseline_record.experiment_id, candidate_record.experiment_id)

    assert comparison.repo_changes == ["agent_app/prompts/system.md", "agent_app/tools.py"]
    assert comparison.repo_change_summary["surface_areas_changed"] == ["prompts", "tools"]
    assert comparison.repo_change_summary["surface_files"]["prompts"] == ["agent_app/prompts/system.md"]
    assert comparison.repo_change_summary["surface_files"]["tools"] == ["agent_app/tools.py"]
    assert comparison.baseline_runtime_changes == []
    assert comparison.candidate_runtime_changes == []

    compare_report = (
        tmp_path / CONTROL_DIR_NAME / "reports" / f"compare-{baseline_record.experiment_id}-to-{candidate_record.experiment_id}.md"
    ).read_text(encoding="utf-8")
    assert "Between-Run Repo Changes" in compare_report
    assert "Surface areas changed: prompts, tools" in compare_report

    diagnosis = diagnose_experiment(
        tmp_path,
        experiment_id=candidate_record.experiment_id,
        baseline_id=baseline_record.experiment_id,
    )
    assert diagnosis["repo_changes"] == ["agent_app/prompts/system.md", "agent_app/tools.py"]
    assert diagnosis["repo_change_summary"]["surface_areas_changed"] == ["prompts", "tools"]


def test_target_files_prioritize_changed_surface_files(tmp_path) -> None:
    init_workbench(tmp_path)
    (tmp_path / "agent_app" / "prompts").mkdir(parents=True)
    write_text(tmp_path / "agent_app" / "runtime.py", "print('runtime')\n")
    write_text(tmp_path / "agent_app" / "prompts" / "system.md", "prompt\n")
    write_text(tmp_path / "agent_app" / "tools.py", "def repo_search(query):\n    return query\n")
    write_text(
        tmp_path / CONTROL_DIR_NAME / "agents" / "sample-agent.yaml",
        "\n".join(
            [
                "id: sample-agent",
                "adapter: command",
                "instructions: []",
                "prompts:",
                "  system: agent_app/prompts/system.md",
                "model: {name: baseline-model}",
                "tools:",
                "  - name: repo_search",
                "    enabled: true",
                "skills: []",
                "plugins: []",
                "mcps: []",
                "surface_paths:",
                "  prompts:",
                "    - agent_app/prompts/system.md",
                "  tools:",
                "    - agent_app/tools.py",
                "  runtime:",
                "    - agent_app/runtime.py",
                "runtime: {env: {}}",
                "entrypoints:",
                "  command:",
                "    - python3",
                "    - agent_app/runtime.py",
                "metadata: {}",
                "",
            ]
        ),
    )
    diagnosis = {
        "agent_id": "sample-agent",
        "eval_id": "contract-eval",
        "repo_change_summary": {
            "surface_files": {
                "prompts": ["agent_app/prompts/system.md"],
                "tools": ["agent_app/tools.py"],
            },
            "agent_spec_files": [f"{CONTROL_DIR_NAME}/agents/sample-agent.yaml"],
        },
    }

    assert _target_files(tmp_path, diagnosis, "tool_routing")[:3] == [
        "agent_app/tools.py",
        "agent_app/prompts/system.md",
        f"{CONTROL_DIR_NAME}/agents/sample-agent.yaml",
    ]
