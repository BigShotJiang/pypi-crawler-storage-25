from __future__ import annotations

from agentworkbench.scorer_utils import (
    default_score_bundle,
    grounding_provenance,
    score_grounding_support,
    score_json_schema_adherence,
    score_output_quality,
    score_process_alignment,
)


def test_output_quality_can_require_grounded_terms() -> None:
    case = {
        "expected": "ship in the current window",
        "metadata": {
            "required_terms": ["ship in the current window"],
            "grounding_required_terms": ["ship in the current window"],
            "require_selected_evidence": True,
        },
    }
    grounded_artifact = {
        "final_output": "Ship in the current window and post the next action.",
        "evidence_records": [
            {
                "kind": "retrieval",
                "name": "release_checklist_search",
                "status": "success",
                "hits": [
                    {
                        "snippet": "If a release only changes UI copy with no backend risk, ship in the current window.",
                        "selected": True,
                    }
                ],
            }
        ],
    }
    score = score_output_quality(grounded_artifact, case)
    assert score["passed"] is True
    assert score["value"] == 1.0

    ungrounded_artifact = {
        "final_output": "Ship in the current window and post the next action.",
        "evidence_records": [
            {
                "kind": "retrieval",
                "name": "release_checklist_search",
                "status": "success",
                "hits": [
                    {
                        "snippet": "Delay the release until a rollback plan is approved.",
                        "selected": True,
                    }
                ],
            }
        ],
    }
    score = score_output_quality(ungrounded_artifact, case)
    assert score["passed"] is False
    assert "ungrounded required terms" in score["reason"]
    assert score["grounding_provenance"]["unsupported_terms"] == ["ship in the current window"]


def test_grounding_provenance_tracks_term_to_selected_source_labels() -> None:
    case = {
        "metadata": {
            "required_terms": ["manager approval", "courtesy extension"],
            "grounding_required_terms": ["manager approval", "courtesy extension"],
            "require_selected_evidence": True,
        }
    }
    artifact = {
        "final_output": "Manager approval is required. Next action: escalate.",
        "evidence_records": [
            {
                "kind": "retrieval",
                "name": "policy_search",
                "status": "success",
                "hits": [
                    {
                        "path": "knowledge/refunds.md",
                        "line": 5,
                        "snippet": "Manager approval is required when usage is above 25 credits.",
                        "selected": True,
                    }
                ],
            },
            {
                "kind": "memory_lookup",
                "name": "customer_memory",
                "status": "success",
                "mcp": "memory",
                "hits": [
                    {
                        "path": "knowledge/customer-notes/acme-vip.md",
                        "line": 4,
                        "snippet": "Last month ACME received a courtesy extension, not a refund.",
                        "selected": True,
                    }
                ],
            },
        ],
    }

    provenance = grounding_provenance(artifact, case)

    assert provenance["grounded_terms"] == ["manager approval", "courtesy extension"]
    assert provenance["unsupported_terms"] == []
    assert provenance["missing_output_terms"] == ["courtesy extension"]
    assert provenance["selected_source_labels"] == ["memory_lookup:customer_memory", "retrieval:policy_search"]
    manager_term = next(item for item in provenance["term_matches"] if item["term"] == "manager approval")
    courtesy_term = next(item for item in provenance["term_matches"] if item["term"] == "courtesy extension")
    assert manager_term["supporting_source_labels"] == ["retrieval:policy_search"]
    assert courtesy_term["supporting_source_labels"] == ["memory_lookup:customer_memory"]
    assert courtesy_term["output_present"] is False


def test_process_alignment_checks_forbidden_surfaces_and_sequence() -> None:
    case = {
        "metadata": {
            "process_expectations": {
                "required_tools": ["policy_search"],
                "forbidden_mcps": ["memory"],
                "workflow_sequence": ["tool:policy_search", "skill:policy_grounding"],
            }
        }
    }
    artifact = {
        "tool_calls": [{"name": "policy_search"}],
        "mcp_servers_used": ["memory"],
        "workflow_trace": ["tool:policy_search", "skill:policy_grounding"],
    }
    score = score_process_alignment(artifact, case)
    assert score["passed"] is False
    assert "forbidden forbidden_mcps" in score["reason"]


def test_grounding_support_exposes_advisory_metric() -> None:
    case = {
        "metadata": {
            "required_terms": ["manager approval"],
            "grounding_required_terms": ["manager approval"],
            "require_selected_evidence": True,
        }
    }
    artifact = {
        "final_output": "Manager approval is required.",
        "evidence_records": [
            {
                "kind": "retrieval",
                "name": "policy_search",
                "status": "success",
                "hits": [
                    {
                        "snippet": "Manager approval is required when usage is above 25 credits.",
                        "selected": True,
                    }
                ],
            }
        ],
    }

    score = score_grounding_support(artifact, case)

    assert score is not None
    assert score["passed"] is True
    assert score["value"] == 1.0
    assert score["weight"] == 0.0


def test_json_schema_adherence_validates_structured_output() -> None:
    case = {
        "metadata": {
            "json_schema": {
                "type": "object",
                "required": ["decision", "next_action"],
                "properties": {
                    "decision": {"type": "string"},
                    "next_action": {"type": "string"},
                    "checks": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"type": "string"},
                    },
                },
            }
        }
    }
    artifact = {
        "structured_output": {
            "decision": "delay",
            "next_action": "escalate",
            "checks": ["rollback"],
        }
    }

    score = score_json_schema_adherence(artifact, case)

    assert score is not None
    assert score["passed"] is True
    assert score["structured_output_source"] == "structured_output"


def test_json_schema_adherence_prefers_nested_structured_output_payload() -> None:
    case = {
        "metadata": {
            "json_schema": {
                "type": "object",
                "required": ["decision"],
                "properties": {"decision": {"type": "string"}},
            }
        }
    }
    artifact = {
        "structured_output": {
            "final_output": '{"decision":"ship"}',
            "structured_output": {"decision": "ship"},
            "events": [{"kind": "provider_response", "name": "success"}],
        }
    }

    score = score_json_schema_adherence(artifact, case)

    assert score is not None
    assert score["passed"] is True
    assert score["structured_output_source"] == "structured_output.structured_output"


def test_default_score_bundle_adds_optional_advisory_metrics_when_configured() -> None:
    case = {
        "expected": "ship in the current window",
        "metadata": {
            "required_terms": ["ship in the current window"],
            "grounding_required_terms": ["ship in the current window"],
            "require_selected_evidence": True,
            "json_schema": {
                "type": "object",
                "required": ["decision"],
                "properties": {"decision": {"type": "string"}},
            },
        },
    }
    artifact = {
        "final_output": '{"decision":"ship in the current window"}',
        "evidence_records": [
            {
                "kind": "retrieval",
                "name": "release_checklist_search",
                "status": "success",
                "hits": [
                    {
                        "snippet": "If a release only changes UI copy with no backend risk, ship in the current window.",
                        "selected": True,
                    }
                ],
            }
        ],
        "structured_output": {"decision": "ship in the current window"},
    }

    scores = default_score_bundle(artifact, case)
    metric_names = {item["name"] for item in scores}

    assert {"output_quality", "process_alignment", "grounding_support", "json_schema_adherence"} <= metric_names
