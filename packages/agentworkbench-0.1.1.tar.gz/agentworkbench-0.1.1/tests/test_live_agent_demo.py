from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def _run_demo(demo_root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    completed = subprocess.run(
        [sys.executable, "-m", "agentworkbench", *args],
        cwd=demo_root,
        env=env,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        raise AssertionError(f"Command failed: {' '.join(args)}\nSTDOUT:\n{completed.stdout}\nSTDERR:\n{completed.stderr}")
    return completed


def _experiment_ids(demo_root: Path) -> set[str]:
    runs_root = demo_root / ".agent-workbench" / "runs"
    if not runs_root.exists():
        return set()
    return {path.name for path in runs_root.iterdir() if path.is_dir()}


def test_live_agent_demo_repo_runs_full_optimization_loop(tmp_path: Path) -> None:
    source_root = Path(__file__).resolve().parents[1] / "examples" / "live-agent-demo"
    demo_root = tmp_path / "live-agent-demo"
    shutil.copytree(source_root, demo_root)

    _run_demo(demo_root, "learn")
    summary = json.loads((demo_root / ".agent-workbench" / "discovery" / "repo-summary.json").read_text(encoding="utf-8"))
    assert "target_agent/prompts/system.md" in summary["candidate_prompt_files"]
    assert "target_agent/cli.py" in summary["confirmed_owned_files"]

    _run_demo(demo_root, "brief", "packet", "--brief-id", "live-support-agent", "--agent-id", "live-support-candidate")
    packet = (demo_root / ".agent-workbench" / "briefs" / "live-support-agent.packet.md").read_text(encoding="utf-8")
    assert "Target Agent Files" in packet
    assert "target_agent/prompts/reviewer.md" in packet

    before_runs = _experiment_ids(demo_root)
    _run_demo(demo_root, "run", "--agent-id", "live-support-baseline", "--eval-id", "live-support-agent", "--subset", "full")
    baseline = sorted(_experiment_ids(demo_root) - before_runs)[-1]

    before_runs = _experiment_ids(demo_root)
    _run_demo(demo_root, "run", "--agent-id", "live-support-candidate", "--eval-id", "live-support-agent", "--subset", "full")
    candidate = sorted(_experiment_ids(demo_root) - before_runs)[-1]

    _run_demo(demo_root, "compare", "--baseline", baseline, "--candidate", candidate)
    compare_payload = json.loads((demo_root / ".agent-workbench" / "reports" / f"compare-{baseline}-to-{candidate}.json").read_text(encoding="utf-8"))
    assert compare_payload["recommended_action"] in {"reject", "review"}
    assert compare_payload["changed_cases"]
    assert compare_payload["behavior_deltas"]["avg_step_count_delta"] > 0
    assert compare_payload["behavior_deltas"]["avg_trace_event_count_delta"] > 0
    assert compare_payload["behavior_deltas"]["trace_event_label_deltas"]
    assert "decision:reviewer_enabled" in compare_payload["behavior_deltas"]["trace_events_added"]
    assert compare_payload["changed_cases"][0]["candidate_evidence"]["trace_events"]
    assert "workflow_memory" in compare_payload["behavior_deltas"]["plugins_used_added"]

    _run_demo(demo_root, "diagnose", "--experiment", candidate)
    diagnose_payload = json.loads((demo_root / ".agent-workbench" / "reports" / "diagnose-latest.json").read_text(encoding="utf-8"))
    categories = {item["category"] for item in diagnose_payload["suggested_mutations"]}
    assert {"prompt_grounding", "tool_routing", "step_budget"} <= categories
    assert diagnose_payload["focus_cases"][0]["candidate_evidence"]["trace_events"]

    _run_demo(demo_root, "propose", "--experiment", candidate, "--limit", "3")
    proposals_payload = json.loads((demo_root / ".agent-workbench" / "proposals" / "latest.json").read_text(encoding="utf-8"))
    proposal_targets = {path for proposal in proposals_payload["proposals"] for path in proposal["target_files"]}
    assert any(path.startswith("target_agent/") for path in proposal_targets)

    _run_demo(demo_root, "patch-template", "--experiment", candidate)
    patch_payload = json.loads((demo_root / ".agent-workbench" / "patches" / "latest.json").read_text(encoding="utf-8"))
    assert patch_payload["experiment_id"] == candidate
    assert any(path.startswith("target_agent/") for path in patch_payload["target_files"])


def test_live_agent_demo_python_adapter_and_ablation(tmp_path: Path) -> None:
    source_root = Path(__file__).resolve().parents[1] / "examples" / "live-agent-demo"
    demo_root = tmp_path / "live-agent-demo"
    shutil.copytree(source_root, demo_root)

    _run_demo(demo_root, "learn")
    before_runs = _experiment_ids(demo_root)
    _run_demo(demo_root, "run", "--agent-id", "live-support-candidate-python", "--eval-id", "live-support-agent", "--subset", "full")
    experiment_id = sorted(_experiment_ids(demo_root) - before_runs)[-1]
    record = json.loads((demo_root / ".agent-workbench" / "runs" / experiment_id / "experiment.json").read_text(encoding="utf-8"))
    assert record["spec_snapshot"]["adapter"] == "python"
    assert record["behavior_summary"]["trace_schema_versions"] == ["awb.trace.v1"]

    _run_demo(demo_root, "ablate", "--experiment", experiment_id, "--surfaces", "prompts,tools", "--limit", "4")
    payload = json.loads((demo_root / ".agent-workbench" / "ablations" / "latest.json").read_text(encoding="utf-8"))
    assert payload["source_experiment_id"] == experiment_id
    assert payload["results"]
    reviewer = next(item for item in payload["results"] if item["surface_kind"] == "prompts" and item["surface_name"] == "reviewer")
    assert "decision:reviewer_enabled" in reviewer["trace_events_removed"]
    assert "candidate_on_frontier" in reviewer["pareto_summary"]
