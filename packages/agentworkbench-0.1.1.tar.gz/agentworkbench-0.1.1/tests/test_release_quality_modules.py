from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import numpy as np

from agentworkbench.active_learning import ActiveLearningSelector, DiversitySampler, UncertaintySampler
from agentworkbench.bayesian import (
    BayesianOptimizer,
    ExpectedImprovement,
    ParameterSpace,
    SurfaceBayesianOptimizer,
    UpperConfidenceBound,
    optimize_with_bayesian,
)
from agentworkbench.benchmark_quality import (
    check_benchmark_quality,
    compute_agreement,
    compute_benchmark_quality,
    compute_coverage,
    compute_discrimination,
    compute_diversity,
    compute_reliability,
)
from agentworkbench.human_integration import HintIntegration, HintKind, create_hint_system
from agentworkbench.learned_scorer import (
    LinearScorer,
    PreferenceModel,
    ScorerWeights,
    fit_from_experiments,
    load_learned_scorer,
    register_feature_extractor,
    save_learned_scorer,
)


def _cases() -> list[dict[str, object]]:
    return [
        {"id": "case-a", "input": "search the repo for a policy", "tags": ["retrieval", "policy"]},
        {"id": "case-b", "input": "summarize an incident", "tags": ["incident"]},
        {"id": "case-c", "input": "route a refund request", "tags": ["routing", "refund"]},
    ]


def _experiment(experiment_id: str, score: float, passed: int) -> SimpleNamespace:
    return SimpleNamespace(
        experiment_id=experiment_id,
        scores={"average_score": score, "passed_cases": passed, "total_cases": 4},
        behavior_summary={
            "average_latency_ms": 100.0 + passed,
            "average_cost_estimate": 0.01 * passed,
            "evidence_use_rate": score,
        },
    )


def test_active_learning_selectors_prioritize_and_update() -> None:
    selector = ActiveLearningSelector()
    history = [
        {"case": {"id": "case-a"}, "passed": False},
        {"case": {"id": "case-a"}, "passed": True},
        {"case": {"id": "case-b"}, "passed": True},
    ]

    features = selector.compute_features(_cases(), history)
    prioritized = selector.prioritize(_cases(), history, max_select=2)
    selector.update("case-a", passed=True)

    assert set(features) == {"case-a", "case-b", "case-c"}
    assert len(prioritized) == 2
    assert all(case_id in features for case_id in prioritized)

    uncertainty = UncertaintySampler()
    uncertainty.set_uncertainty("case-b", 0.9)
    assert uncertainty.sample(_cases(), n=1) == ["case-b"]

    diverse = DiversitySampler().sample(_cases(), n=2)
    assert len(diverse) == 2


def test_benchmark_quality_metrics_cover_success_and_warning_paths() -> None:
    cases = _cases()
    behaviors = [{"tags": ["retrieval"], "category": "routing"}, {"tags": ["missing"], "category": "policy"}]
    experiments = [
        {"passed_cases": 1, "total_cases": 4},
        {"passed_cases": 3, "total_cases": 4},
    ]
    stability = [{"average_score": 0.4}, {"average_score": 0.6}, {"average_score": 0.5}]

    assert compute_coverage(cases, behaviors) > 0.0
    assert compute_discrimination(experiments) > 0.0
    assert compute_reliability(experiments, stability) > 0.0
    assert compute_diversity(cases) > 0.0
    assert compute_agreement([True, False], [True, True]) == 0.5

    quality = compute_benchmark_quality(cases, behaviors, experiments, stability, human_judgments=[False, True])
    passed, checked = check_benchmark_quality(cases, min_quality=0.1, brief_behaviors=behaviors, experiments=experiments)

    assert quality.recommendation in {"excellent", "acceptable", "needs_improvement", "poor"}
    assert passed is checked.is_acceptable(0.1)


def test_learned_scorer_fit_update_feature_importance_and_persistence(tmp_path: Path) -> None:
    weights = ScorerWeights(score_weight=0.5, latency_weight=0.2, cost_weight=0.1, evidence_weight=0.2)
    assert 0.0 <= weights.predict({"score": 0.8, "normalized_latency": 0.2, "normalized_cost": 0.1}) <= 1.0

    linear = LinearScorer(["score", "latency_ms"])
    assert linear.predict({"score": 0.5}) == 0.5
    linear.fit([{"score": 0.2, "latency_ms": 50.0}, {"score": 0.9, "latency_ms": 20.0}], [0.2, 0.9])
    before = linear.predict({"score": 0.8, "latency_ms": 25.0})
    linear.update({"score": 0.8, "latency_ms": 25.0}, 0.95)
    assert 0.0 <= before <= 1.0

    experiments = [_experiment("exp-a", 0.2, 1), _experiment("exp-b", 0.8, 3), _experiment("exp-c", 0.6, 2)]
    preference = PreferenceModel()
    preference.fit(experiments, [False, True, True])
    assert 0.0 <= preference.preference_score({"score": 0.7, "latency": 100.0, "cost": 0.02}) <= 1.0

    scorer = fit_from_experiments(experiments, feedback=[{"experiment_id": "exp-b", "decision": "promote"}])
    prediction = scorer.predict({"score": 0.7, "latency_ms": 100.0, "cost_estimate": 0.02, "evidence_use": 0.7})
    scorer.update({"score": 0.7, "latency_ms": 100.0, "cost_estimate": 0.02, "evidence_use": 0.7}, 0.75)
    assert 0.0 <= prediction <= 1.0
    assert scorer.feature_importance()

    path = tmp_path / "scorer.json"
    save_learned_scorer(scorer, path)
    loaded = load_learned_scorer(path)
    assert loaded.features == scorer.features

    @register_feature_extractor("score_plus_latency")
    def _extract(features: dict[str, float]) -> float:
        return features.get("score", 0.0) + features.get("latency", 0.0)

    assert _extract({"score": 1.0, "latency": 2.0}) == 3.0


def test_bayesian_helpers_suggest_and_record_observations() -> None:
    space = ParameterSpace({"temperature": (0.0, 1.0), "max_tokens": [128, 256], "use_tool": [True, False]})
    vector = space.to_vector({"temperature": 0.5, "max_tokens": 256, "use_tool": True})
    params = space.from_vector(vector)
    assert 0.0 <= params["temperature"] <= 1.0
    assert params["max_tokens"] in {128, 256}

    mu = np.array([0.4, 0.8], dtype=np.float64)
    sigma = np.array([0.1, 0.2], dtype=np.float64)
    assert ExpectedImprovement().compute(mu, sigma, best=0.5).shape == (2,)
    assert UpperConfidenceBound().compute(mu, sigma, best=0.5).shape == (2,)

    optimizer = BayesianOptimizer(space, n_initial=2)
    for config in optimizer.suggest_initial():
        optimizer.observe(config, float(config["temperature"]))
    suggestion = optimizer.suggest()
    assert isinstance(suggestion, dict)

    surface_optimizer = SurfaceBayesianOptimizer(["tools", "prompts"], n_initial=1)
    combo = surface_optimizer.suggest_surface_combo()
    surface_optimizer.observe_surface_combo(combo, 0.4)
    assert set(combo) == {"tools", "prompts"}

    result = optimize_with_bayesian(lambda cfg: float(cfg.get("temperature", 0.0)), space, budget=3, n_initial=1)
    assert result.n_iterations >= 1


def test_human_hint_system_and_integration_apply_feedback() -> None:
    hint_system = create_hint_system(confidence_threshold=0.8)
    result = {
        "experiment_id": "exp-1",
        "confidence": 0.2,
        "score_stddev": 0.3,
        "temperature": 0.9,
        "max_tokens": 4096,
        "tool_count": 1,
        "average_latency_ms": 1500,
        "average_cost_estimate": 0.7,
    }

    assert hint_system.should_ask(result)
    hint = hint_system.generate_hint(result)
    assert hint is not None
    assert hint.kind == HintKind.DIRECTION
    hint_system.record_hint(hint, "lower")
    assert hint_system.get_learned_direction()

    priority_hint = hint_system._generate_priority_hint(result)
    hint_system.record_hint(priority_hint, "latency")
    assert hint_system.get_priority_rankings()

    alternative_hint = hint_system._generate_alternative_hint({"tools": 0.4})
    hint_system.record_hint(alternative_hint, "different tool")
    assert hint_system.get_alternatives()

    integration = HintIntegration()
    integration.incorporate_feedback(hint, "lower")
    adjusted = integration.apply_hint_to_suggestion({"temperature": 0.5})
    assert adjusted["temperature"] < 0.5
