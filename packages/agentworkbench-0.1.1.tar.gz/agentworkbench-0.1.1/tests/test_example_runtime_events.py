from __future__ import annotations

import importlib
import sys
from pathlib import Path

from agentworkbench.evidence import artifact_evidence_summary
from agentworkbench.tracing import normalize_trace_events, trace_event_label


def _clear_target_agent_modules() -> None:
    for name in list(sys.modules):
        if name == "target_agent" or name.startswith("target_agent."):
            sys.modules.pop(name)


def _import_example_runtime(monkeypatch, example_name: str):
    demo_root = Path(__file__).resolve().parents[1] / "examples" / example_name
    _clear_target_agent_modules()
    monkeypatch.syspath_prepend(str(demo_root))
    return demo_root, importlib.import_module("target_agent.runtime")


def _import_example_module(monkeypatch, example_name: str, module_name: str):
    demo_root = Path(__file__).resolve().parents[1] / "examples" / example_name
    _clear_target_agent_modules()
    monkeypatch.syspath_prepend(str(demo_root))
    return demo_root, importlib.import_module(module_name)


def test_live_agent_demo_runtime_emits_explicit_decision_events(monkeypatch) -> None:
    demo_root, runtime = _import_example_runtime(monkeypatch, "live-agent-demo")
    payload = runtime.run_case(
        {
            "id": "live-support-workflow-2",
            "input": "Check memory-backed workflow state before answering why the candidate regressed.",
        },
        {
            "agent": {
                "prompts": {
                    "system": "target_agent/prompts/system.md",
                    "reviewer": "target_agent/prompts/reviewer.md",
                },
                "owned_paths": ["target_agent/runtime.py"],
            }
        },
        "candidate",
        demo_root,
    )

    labels = [trace_event_label(event) for event in normalize_trace_events(payload)]
    assert payload["events"]
    assert "decision:memory_guided_answer" in labels
    assert "decision:memory_consulted" in labels
    assert "decision:reviewer_enabled" in labels
    assert "planning:task_planner" in labels
    assert "budget:step_heavy" in labels


def test_live_provider_demo_runtime_emits_provider_and_memory_events(monkeypatch) -> None:
    demo_root, runtime = _import_example_runtime(monkeypatch, "live-provider-demo")
    captured_messages: dict[str, list[dict[str, str]]] = {}

    def _provider_response(model, messages):
        captured_messages["messages"] = messages
        return "Use the refund rule and customer note. Next action: reply to the customer.", {"input": 123, "output": 45, "total": 168}

    monkeypatch.setattr(
        runtime,
        "_provider_response",
        _provider_response,
    )
    payload = runtime.run_case(
        {
            "id": "support-memory",
            "input": "Customer renewed 2 days ago and used 3 credits. Can they get a refund?",
            "metadata": {
                "requires_policy_search": True,
                "requires_customer_memory": True,
                "customer_id": "acme-vip",
                "facts": {"tier": "vip"},
            },
        },
        {
            "agent": {
                "prompts": {
                    "system": "target_agent/prompts/system.md",
                    "reviewer": "target_agent/prompts/reviewer.md",
                },
                "model": {"provider": "groq", "name": "demo-provider"},
                "tools": [
                    {"name": "policy_search", "enabled": True},
                    {"name": "customer_memory", "enabled": True},
                ],
                "skills": [
                    {"name": "memory_recall", "enabled": True},
                    {"name": "policy_grounding", "enabled": True},
                    {"name": "response_review", "enabled": True},
                ],
                "plugins": [
                    {"name": "knowledge_base", "enabled": True},
                    {"name": "workflow_memory", "enabled": True},
                ],
                "mcps": [
                    {"name": "filesystem", "enabled": True},
                    {"name": "memory", "enabled": True},
                ],
            }
        },
        demo_root,
    )

    labels = [trace_event_label(event) for event in normalize_trace_events(payload)]
    assert payload["events"]
    assert payload["metadata"]["customer_history_loaded"] is True
    assert "decision:customer_memory_required" in labels
    assert "memory_lookup:customer_memory" in labels
    assert "provider_request:chat_completion" in labels
    assert "provider_response:success" in labels
    assert "decision:customer_history_loaded" in labels
    assert "decision:customer_history_phrase_injected" in labels
    assert "decision:reviewer_enabled" in labels
    assert "decision:response_ready" in labels
    assert payload["metadata"]["customer_history_phrase_injected"] is True
    assert 'courtesy extension, not a refund' in payload["final_output"]
    user_message = captured_messages["messages"][-1]["content"]
    assert "Sentence 2 must start exactly with 'Next action:'" in user_message
    assert "Selected customer-specific history:" in user_message
    assert "Selected policy context:" in user_message
    assert "Selected incident context:" not in user_message
    assert "knowledge/refunds.md#L" not in user_message
    evidence_records, evidence_summary = artifact_evidence_summary(payload)
    assert len(evidence_records) == 2
    assert {item["label"] for item in evidence_records} == {"retrieval:policy_search", "memory_lookup:customer_memory"}
    assert evidence_summary["selected_count"] == 2
    assert "memory_lookup:customer_memory" in evidence_summary["source_labels"]


def test_live_provider_demo_release_runtime_keeps_launch_skill_when_calendar_is_empty(monkeypatch) -> None:
    demo_root, runtime = _import_example_runtime(monkeypatch, "live-provider-demo")
    monkeypatch.setattr(
        runtime,
        "_provider_response",
        lambda model, messages: ("Delay the release until a rollback plan is approved.", {"input": 200, "output": 20, "total": 220}),
    )
    payload = runtime.run_case(
        {
            "id": "release-migration-only",
            "input": "The release contains a backward incompatible database migration, but there is no finance export work and we are not in month-end freeze. Should we ship?",
            "metadata": {
                "requires_release_checklist_search": True,
                "requires_launch_calendar_lookup": True,
            },
        },
        {
            "agent": {
                "prompts": {
                    "system": "target_agent/prompts/release_system.md",
                    "reviewer": "target_agent/prompts/release_reviewer.md",
                },
                "model": {"provider": "groq", "name": "demo-provider"},
                "tools": [
                    {"name": "release_checklist_search", "enabled": True},
                    {"name": "launch_calendar_lookup", "enabled": True},
                ],
                "skills": [
                    {"name": "risk_review", "enabled": True},
                    {"name": "launch_window_check", "enabled": True},
                    {"name": "response_review", "enabled": True},
                ],
                "plugins": [{"name": "runbook_index", "enabled": True}],
                "mcps": [{"name": "filesystem", "enabled": True}],
            }
        },
        demo_root,
    )

    assert "skill:launch_window_check" in payload["workflow_trace"]
    launch_lookup = next(item for item in payload["tool_calls"] if item["name"] == "launch_calendar_lookup")
    assert launch_lookup["status"] == "empty"


def test_live_provider_demo_runtime_emits_skip_event_when_customer_history_missing(monkeypatch) -> None:
    demo_root, runtime = _import_example_runtime(monkeypatch, "live-provider-demo")

    def _should_not_run(model, messages):
        raise AssertionError("provider call should be skipped when required customer history is missing")

    monkeypatch.setattr(runtime, "_provider_response", _should_not_run)
    payload = runtime.run_case(
        {
            "id": "support-memory-missing",
            "input": "Customer asks about a refund with no available memory note.",
            "metadata": {
                "requires_customer_memory": True,
                "customer_id": "missing-customer",
            },
        },
        {
            "agent": {
                "prompts": {
                    "system": "target_agent/prompts/system.md",
                    "reviewer": "target_agent/prompts/reviewer.md",
                },
                "model": {"provider": "groq", "name": "demo-provider"},
                "tools": [{"name": "customer_memory", "enabled": True}],
                "skills": [{"name": "memory_recall", "enabled": True}],
                "plugins": [{"name": "workflow_memory", "enabled": True}],
                "mcps": [{"name": "memory", "enabled": True}],
            }
        },
        demo_root,
    )

    labels = [trace_event_label(event) for event in normalize_trace_events(payload)]
    assert payload["final_output"] == "I need customer history."
    assert "decision:customer_history_missing" in labels
    assert "provider_request:skipped" in labels


def test_live_provider_demo_memory_recall_prioritizes_decisive_history_lines(monkeypatch) -> None:
    demo_root, memory = _import_example_module(monkeypatch, "live-provider-demo", "target_agent.memory")

    router_history = memory.recall_customer_history(
        demo_root,
        "zenith-enterprise",
        "Zenith Enterprise wants another SSO exception reviewed. Where should the request go?",
    )
    assert "prior SSO exception denied" in router_history
    assert "follow-up exception requests back to Account Security" not in router_history
    assert "# Customer History" not in router_history

    refund_history = memory.recall_customer_history(
        demo_root,
        "acme-vip",
        "VIP customer ACME renewed 8 days ago, used 40 credits, and already received a courtesy extension last month. Can support refund them directly?",
    )
    assert "courtesy extension" in refund_history
    assert "priority handling" not in refund_history


def test_live_provider_demo_release_search_keeps_strong_multi_constraint_hits(monkeypatch) -> None:
    demo_root, tools = _import_example_module(monkeypatch, "live-provider-demo", "target_agent.tools")

    risky_hits = tools.release_checklist_search(
        "The release includes a backward incompatible database migration and finance exports would change during month-end freeze. Should we ship?",
        demo_root,
    )
    risky_snippets = [item["snippet"] for item in risky_hits]
    assert any("rollback plan" in snippet for snippet in risky_snippets)
    assert any("notify finance operations" in snippet for snippet in risky_snippets)

    ui_hits = tools.release_checklist_search(
        "This release only changes onboarding UI copy and there is no backend risk. Should we ship now?",
        demo_root,
    )
    assert [item["snippet"] for item in ui_hits] == [
        "- If a release only changes UI copy with no backend risk, ship in the current window."
    ]

    migration_only_hits = tools.release_checklist_search(
        "The release contains a backward incompatible database migration, but there is no finance export work and we are not in month-end freeze. Should we ship?",
        demo_root,
    )
    migration_only_snippets = [item["snippet"] for item in migration_only_hits]
    assert any("rollback plan" in snippet for snippet in migration_only_snippets)
    assert all("finance exports" not in snippet for snippet in migration_only_snippets)

    calendar_hits = tools.launch_calendar_lookup(
        "The release contains a backward incompatible database migration, but there is no finance export work and we are not in month-end freeze. Should we ship?",
        demo_root,
    )
    assert calendar_hits == []


def test_live_provider_demo_router_runtime_marks_history_as_required_for_routing(monkeypatch) -> None:
    demo_root, runtime = _import_example_runtime(monkeypatch, "live-provider-demo")
    captured_messages: dict[str, list[dict[str, str]]] = {}

    def _provider_response(model, messages):
        captured_messages["messages"] = messages
        return "Account Security. Next action: route the request.", {"input": 200, "output": 20, "total": 220}

    monkeypatch.setattr(runtime, "_provider_response", _provider_response)
    runtime.run_case(
        {
            "id": "router-enterprise",
            "input": "Zenith Enterprise wants another SSO exception reviewed. Where should the request go?",
            "metadata": {
                "customer_id": "zenith-enterprise",
                "requires_customer_memory": True,
                "requires_routing_policy_search": True,
                "requires_team_directory_lookup": True,
            },
        },
        {
            "agent": {
                "prompts": {
                    "system": "target_agent/prompts/router_system.md",
                    "reviewer": "target_agent/prompts/router_reviewer.md",
                },
                "model": {"provider": "groq", "name": "demo-provider"},
                "tools": [
                    {"name": "routing_policy_search", "enabled": True},
                    {"name": "team_directory_lookup", "enabled": True},
                    {"name": "customer_memory", "enabled": True},
                ],
                "skills": [
                    {"name": "history_recall", "enabled": True},
                    {"name": "route_selection", "enabled": True},
                    {"name": "team_matching", "enabled": True},
                    {"name": "response_review", "enabled": True},
                ],
                "plugins": [
                    {"name": "directory_index", "enabled": True},
                    {"name": "workflow_memory", "enabled": True},
                ],
                "mcps": [
                    {"name": "filesystem", "enabled": True},
                    {"name": "memory", "enabled": True},
                ],
            }
        },
        demo_root,
    )

    user_message = captured_messages["messages"][-1]["content"]
    assert "Required customer-specific history:" in user_message
    assert "quote that exact history line after 'because'" in user_message


def test_live_provider_demo_support_policy_search_returns_decisive_policy_lines(monkeypatch) -> None:
    demo_root, tools = _import_example_module(monkeypatch, "live-provider-demo", "target_agent.tools")

    eligible_hits = tools.policy_search(
        "A Pro customer renewed 10 days ago, used 6 credits, and wants a refund. What should support say?",
        demo_root,
    )
    eligible_paths = {item["path"] for item in eligible_hits}
    eligible_snippets = [item["snippet"] for item in eligible_hits]
    assert eligible_paths == {"knowledge/refunds.md"}
    assert any("14-day refund window" in snippet for snippet in eligible_snippets)
    assert any("approve directly" in snippet for snippet in eligible_snippets)

    threshold_hits = tools.policy_search(
        "VIP customer ACME renewed 8 days ago, used 40 credits, and already received a courtesy extension last month. Can support refund them directly?",
        demo_root,
    )
    threshold_snippets = [item["snippet"] for item in threshold_hits]
    assert any("manager approval is required" in snippet for snippet in threshold_snippets)
