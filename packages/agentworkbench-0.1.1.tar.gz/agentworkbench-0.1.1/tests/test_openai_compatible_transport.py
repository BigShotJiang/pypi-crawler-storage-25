from __future__ import annotations

import json
import urllib.error
from email.message import Message
from typing import Literal

import pytest

from agentworkbench.models import AgentSpec, EvalCase, ProviderEntrypoint
from agentworkbench.providers import base as provider_base
from agentworkbench.providers import openai_compatible as provider_transport
from agentworkbench.providers.openai_compatible import (
    TransportError,
    build_messages,
    build_request_body,
    http_request,
    parse_response,
    provider_tools,
    recover_tool_use_failed_response,
    request_headers,
)


class _FakeHTTPResponse:
    def __init__(self, payload: object) -> None:
        self._payload = payload

    def __enter__(self) -> _FakeHTTPResponse:
        return self

    def __exit__(self, _exc_type: object, exc: object, _tb: object) -> Literal[False]:
        return False

    def read(self) -> bytes:
        if isinstance(self._payload, bytes):
            return self._payload
        if isinstance(self._payload, str):
            return self._payload.encode("utf-8")
        return json.dumps(self._payload).encode("utf-8")


def test_request_headers_allow_explicit_overrides() -> None:
    headers = request_headers(
        ProviderEntrypoint(headers={"Authorization": "Bearer override", "X-Test": "1"}),
        "ignored",
    )

    assert headers["Authorization"] == "Bearer override"
    assert headers["X-Test"] == "1"
    assert headers["Content-Type"] == "application/json"


def test_provider_base_helpers_cover_aliases_and_fallbacks() -> None:
    assert provider_base.classify_error("unauthorized", 401) is provider_base.RetryClassification.AUTH
    assert provider_base.classify_error("forbidden", 403) is provider_base.RetryClassification.AUTH
    assert provider_base.classify_error("too many requests", 429) is provider_base.RetryClassification.RATE_LIMIT
    assert provider_base.classify_error("timed out") is provider_base.RetryClassification.TIMEOUT
    assert provider_base.classify_error("invalid request", 400) is provider_base.RetryClassification.BAD_REQUEST
    assert provider_base.classify_error("service unavailable", 503) is provider_base.RetryClassification.TRANSIENT
    assert provider_base.classify_error("connection reset by peer") is provider_base.RetryClassification.TRANSIENT
    assert provider_base.classify_error("mystery failure") is provider_base.RetryClassification.UNKNOWN

    capabilities = provider_base.get_provider_capabilities("openai_compatible")
    assert capabilities.to_dict()["tool_calling"] is True
    assert provider_base.ProviderCapabilities(reasoning_tokens=True).to_dict()["reasoning_tokens"] is True
    assert provider_base.get_provider_capabilities("unknown-provider").to_dict()["tool_calling"] is False

    config = provider_base.ProviderConfig(
        provider="openai-compatible",
        base_url="https://example.test/v1/chat/completions",
        api_key_env="EXAMPLE_API_KEY",
        model_name="demo-model",
    )
    response = provider_base.ProviderResponse(
        final_output="done",
        tool_calls=[{"name": "lookup_policy"}],
        token_usage={"total": 7},
        finish_reason="stop",
        response_id="resp_1",
    )

    assert config.to_dict()["provider"] == "openai-compatible"
    assert config.to_dict()["capabilities"]["tool_calling"] is True
    assert response.to_dict()["response_id"] == "resp_1"
    assert response.raw_payload == {}


def test_transport_helpers_compact_rich_payloads() -> None:
    assert provider_transport._message_content([" first ", {"type": "text", "text": "second"}, {"content": "third"}]) == (
        "first\nsecond\nthird"
    )
    assert provider_transport._message_content(123) == "123"
    assert provider_transport._text_preview("abcdefghij", limit=6) == "abc..."
    assert provider_transport._text_preview("short", limit=10) == "short"
    assert provider_transport._compact_tool_call_names(
        [{"name": "one"}, {"function": {"name": "two"}}, "skip"],
        limit=2,
    ) == ["one", "two"]
    assert provider_transport._compact_trace_markers(
        [{"kind": "provider_response", "name": "ok"}, {"kind": "", "name": "skip"}]
    ) == ["provider_response:ok", "skip"]
    assert provider_transport._compact_evidence_markers(
        [{"kind": "retrieval", "name": "policy"}, {"kind": "", "name": "fallback"}]
    ) == ["retrieval:policy", "fallback"]

    compact_step = provider_transport._compact_chain_step(
        {
            "step": 1,
            "node_id": "router",
            "agent_id": "router-agent",
            "selected_edges": [{"to": "refund", "label": "refund-route", "default": False}],
            "artifact_summary": {
                "final_output": "route=refund",
                "tool_calls": [{"name": "refund_lookup"}],
                "evidence_records": [{"kind": "retrieval", "name": "policy"}],
                "trace_events": [{"kind": "provider_response", "name": "ok"}],
                "errors": ["bad input"],
            },
        }
    )
    assert compact_step["tool_calls"] == ["refund_lookup"]
    assert compact_step["selected_edges"][0]["to"] == "refund"
    assert compact_step["errors"] == ["bad input"]
    selected_edge_step = provider_transport._compact_chain_step(
        {
            "selected_edge": {"to": "escalation", "label": "fallback", "default": True},
            "artifact_summary": {"final_output": "Escalate this case."},
        }
    )
    assert selected_edge_step["selected_edges"][0]["default"] is True
    assert provider_transport._compact_chain_step("skip") == {}

    compact_context = provider_transport._compact_shared_context(
        {
            "customer": "enterprise tier",
            "flags": ["sla", "billing"],
            "nested": {"priority": "p1", "owner": "ops"},
            "count": 2,
        }
    )
    assert compact_context["customer"] == "enterprise tier"
    assert compact_context["flags"] == ["sla", "billing"]
    assert compact_context["nested"]["priority"] == "p1"
    assert compact_context["count"] == 2
    assert provider_transport._compact_shared_context("skip") == {}


def test_chain_context_blob_supports_compact_full_and_off_modes() -> None:
    chain_context = {
        "case_id": "case-1",
        "original_input": "Handle the refund",
        "accumulated_output": "refund path",
        "steps": [{"step": 0, "agent_id": "router", "artifact_summary": {"final_output": "refund"}}],
        "shared_context": {"customer_tier": "enterprise"},
    }

    compact_blob = provider_transport._chain_context_blob(chain_context, "compact")
    assert '"case_id": "case-1"' in compact_blob
    assert "customer_tier" in compact_blob
    assert provider_transport._chain_context_blob(chain_context, "full").startswith("{\n")
    assert provider_transport._chain_context_blob({}, "compact") == ""
    assert provider_transport._chain_context_blob(chain_context, "off") == ""
    assert provider_transport._chain_context_blob("plain text context", "compact") == "plain text context"


def test_build_messages_and_request_body_cover_turns_and_tools(tmp_path) -> None:
    prompt_dir = tmp_path / "prompts"
    prompt_dir.mkdir()
    (prompt_dir / "system.md").write_text("Answer precisely.\n", encoding="utf-8")

    spec = AgentSpec(
        id="provider-agent",
        adapter="provider",
        instructions=["Use the provided tool when needed."],
        prompts={"system": "prompts/system.md", "reviewer": "Double-check the answer."},
        model={"name": "demo-model", "temperature": 0, "top_p": 1},
        tools=[
            {
                "name": "lookup_policy",
                "description": "Find the policy",
                "parameters": {
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                },
            },
            {
                "function": {
                    "name": "route_incident",
                    "description": "Route incidents",
                    "parameters": {"type": "object", "properties": {"summary": {"type": "string"}}},
                }
            },
            {"name": "disabled_tool", "enabled": False, "parameters": {"type": "object"}},
            {"name": "missing_schema"},
        ],
    )
    case = EvalCase(
        id="case-1",
        input="Handle this refund",
        turns=[{"role": "assistant", "content": "Earlier answer"}, {"role": "weird", "content": "Normalize me"}],
        metadata={"chain_context": {"case_id": "case-1", "steps": []}},
    )

    messages, prompt_keys = build_messages(tmp_path, spec, case, ProviderEntrypoint(tool_format="compact"))
    request_body = build_request_body(spec, messages, ProviderEntrypoint(tool_format="compact", extra_body={"seed": 7}))
    compact_tools = provider_tools(spec, tool_format="compact")

    assert prompt_keys == ["system", "reviewer"]
    assert messages[0]["role"] == "system"
    assert messages[1]["role"] == "assistant"
    assert messages[2]["role"] == "user"
    assert request_body["model"] == "demo-model"
    assert request_body["seed"] == 7
    assert len(request_body["tools"]) == 2
    assert len(compact_tools) == 2
    assert request_body["tools"][0]["function"]["name"] == "lookup_policy"
    assert request_body["tools"][1]["function"]["name"] == "route_incident"
    assert compact_tools[0]["function"]["parameters"]["required"] == ["query"]

    with pytest.raises(ValueError, match="unknown field"):
        build_messages(
            tmp_path,
            spec,
            EvalCase(id="case-2", input="bad"),
            ProviderEntrypoint(user_prompt_template="{unknown}"),
        )


def test_prompt_resolution_and_message_building_edge_cases(tmp_path) -> None:
    prompt_dir = tmp_path / "prompts"
    prompt_dir.mkdir()
    (prompt_dir / "reviewer.md").write_text("Verify the final answer.\n", encoding="utf-8")

    resolved = provider_transport._resolve_prompt_value(tmp_path, "prompts/reviewer.md")
    assert resolved == "Verify the final answer."
    assert provider_transport._resolve_prompt_value(tmp_path, "Use literal content.") == "Use literal content."
    assert provider_transport._resolve_prompt_value(tmp_path, "") == ""

    prompts = provider_transport._resolved_prompts(
        tmp_path,
        {"system": "System guidance", "reviewer": "prompts/reviewer.md", "blank": "  "},
    )
    assert prompts == {"reviewer": "Verify the final answer.", "system": "System guidance"}

    explicit_keys = provider_transport._ordered_prompt_keys(
        ProviderEntrypoint(prompt_keys=["reviewer", "system"]),
        prompts,
    )
    assert explicit_keys == ["reviewer", "system"]
    inferred_keys = provider_transport._ordered_prompt_keys(
        ProviderEntrypoint(system_prompt_key="system"),
        prompts,
    )
    assert inferred_keys == ["system", "reviewer"]

    spec = AgentSpec(
        id="provider-agent",
        adapter="provider",
        instructions=["Keep the reply short."],
        prompts={},
        model={"name": "demo-model"},
        tools=[],
    )
    case = EvalCase(id="case-2", input="hello")

    messages, prompt_keys = build_messages(
        tmp_path,
        spec,
        case,
        ProviderEntrypoint(include_instructions=False, user_prompt_template="{input}"),
    )

    assert prompt_keys == []
    assert messages == [{"role": "user", "content": "hello"}]


def test_http_request_wraps_url_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise_url_error(*_args: object, **_kwargs: object) -> _FakeHTTPResponse:
        raise urllib.error.URLError("network down")

    monkeypatch.setattr("agentworkbench.providers.openai_compatible.urllib.request.urlopen", _raise_url_error)

    with pytest.raises(TransportError, match="network down"):
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)


def test_http_request_wraps_http_timeout_and_os_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    class _FakeHTTPError(urllib.error.HTTPError):
        def __init__(self) -> None:
            super().__init__("https://example.test", 400, "bad request", hdrs=Message(), fp=None)

        def read(self, n: int = -1) -> bytes:
            del n
            return b'{"error":"bad request"}'

    def _raise_http_error(*_args: object, **_kwargs: object) -> _FakeHTTPResponse:
        raise _FakeHTTPError()

    def _raise_timeout(*_args: object, **_kwargs: object) -> _FakeHTTPResponse:
        raise TimeoutError()

    def _raise_os_error(*_args: object, **_kwargs: object) -> _FakeHTTPResponse:
        raise OSError("socket closed")

    monkeypatch.setattr("agentworkbench.providers.openai_compatible.urllib.request.urlopen", _raise_http_error)
    with pytest.raises(TransportError, match="HTTP 400"):
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)

    monkeypatch.setattr("agentworkbench.providers.openai_compatible.urllib.request.urlopen", _raise_timeout)
    with pytest.raises(TransportError, match="timed out"):
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)

    monkeypatch.setattr("agentworkbench.providers.openai_compatible.urllib.request.urlopen", _raise_os_error)
    with pytest.raises(TransportError, match="socket closed"):
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)


def test_http_request_handles_http_error_body_read_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    class _UnreadableHTTPError(urllib.error.HTTPError):
        def __init__(self) -> None:
            super().__init__("https://example.test", 502, "bad gateway", hdrs=Message(), fp=None)

        def read(self, n: int = -1) -> bytes:
            del n
            raise OSError("body unavailable")

    def _raise_http_error(*_args: object, **_kwargs: object) -> _FakeHTTPResponse:
        raise _UnreadableHTTPError()

    monkeypatch.setattr("agentworkbench.providers.openai_compatible.urllib.request.urlopen", _raise_http_error)
    with pytest.raises(TransportError) as exc_info:
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)

    assert exc_info.value.http_code == 502
    assert exc_info.value.body == ""


def test_http_request_rejects_invalid_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "agentworkbench.providers.openai_compatible.urllib.request.urlopen",
        lambda *_args, **_kwargs: _FakeHTTPResponse("not json"),
    )

    with pytest.raises(TransportError, match="valid JSON"):
        http_request("https://example.test", {"ok": True}, {"Authorization": "Bearer test"}, 5)


def test_parse_response_supports_text_lists_and_tool_calls() -> None:
    parsed = parse_response(
        {
            "id": "resp_123",
            "choices": [
                {
                    "message": {
                        "content": [
                            {"type": "text", "text": "approved"},
                            {"content": "with evidence"},
                        ],
                        "tool_calls": [
                            {
                                "id": "call_1",
                                "function": {
                                    "name": "lookup_policy",
                                    "arguments": "{\"query\":\"refund\"}",
                                },
                            }
                        ],
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 4, "completion_tokens": 3, "total_tokens": 7},
        }
    )

    assert parsed.final_output == "approved\nwith evidence"
    assert parsed.tool_calls == [{"name": "lookup_policy", "status": "requested", "id": "call_1", "arguments": "{\"query\":\"refund\"}"}]
    assert parsed.token_usage == {"input": 4, "output": 3, "total": 7}
    assert parsed.response_id == "resp_123"


def test_parse_response_rejects_missing_choices() -> None:
    with pytest.raises(ValueError, match="choices\\[0\\]"):
        parse_response({})


def test_parse_response_rejects_bad_message_shapes_and_skips_sparse_tool_rows() -> None:
    with pytest.raises(ValueError, match="must be an object"):
        parse_response({"choices": [{"message": "bad"}]})

    parsed = parse_response(
        {
            "choices": [
                {
                    "message": {
                        "content": "approved",
                        "tool_calls": [
                            "skip",
                            {"id": "call_1", "function": {}},
                            {"function": {"name": "lookup_policy"}},
                        ],
                    }
                }
            ]
        }
    )

    assert parsed.tool_calls == [
        {"name": "call_1", "status": "requested", "id": "call_1"},
        {"name": "lookup_policy", "status": "requested"},
    ]
    assert parsed.finish_reason == ""
    assert parsed.response_id == ""


def test_recover_tool_use_failed_response_handles_invalid_payloads() -> None:
    assert recover_tool_use_failed_response("") is None
    assert recover_tool_use_failed_response("not json") is None
    assert recover_tool_use_failed_response(json.dumps({"error": {"code": "other"}})) is None
    assert recover_tool_use_failed_response(json.dumps({"error": []})) is None

    invalid_arguments = recover_tool_use_failed_response(
        json.dumps(
            {
                "error": {
                    "code": "tool_use_failed",
                    "message": "bad function output",
                    "failed_generation": "<function=route_refund>{not-json}",
                }
            }
        )
    )
    assert invalid_arguments is None


def test_recover_tool_use_failed_response_normalizes_raw_arguments() -> None:
    recovered = recover_tool_use_failed_response(
        json.dumps(
            {
                "error": {
                    "code": "tool_use_failed",
                    "message": "bad function output",
                    "failed_generation": "<function=route_refund>refund request",
                }
            }
        ),
        response_id="resp_recovered",
    )

    assert recovered is not None
    tool_calls = recovered["choices"][0]["message"]["tool_calls"]
    assert tool_calls[0]["function"]["name"] == "route_refund"
    assert tool_calls[0]["function"]["arguments"] == "{\"raw\": \"refund request\"}"


def test_recover_tool_use_failed_response_supports_multiple_calls_and_fingerprints() -> None:
    recovered = recover_tool_use_failed_response(
        json.dumps(
            {
                "error": {
                    "code": "tool_use_failed",
                    "message": "bad function output",
                    "failed_generation": (
                        "<function=route_refund>{\"reason\":\"customer asked\"}"
                        "<function=lookup_policy>{\"query\":\"refund policy\"}"
                    ),
                }
            }
        )
    )

    assert recovered is not None
    tool_calls = recovered["choices"][0]["message"]["tool_calls"]
    assert [item["function"]["name"] for item in tool_calls] == ["route_refund", "lookup_policy"]
    assert recovered["awb_recovery"]["error"]["code"] == "tool_use_failed"
    assert provider_transport.request_fingerprint({"b": 2, "a": 1}) == provider_transport.request_fingerprint(
        {"a": 1, "b": 2}
    )
