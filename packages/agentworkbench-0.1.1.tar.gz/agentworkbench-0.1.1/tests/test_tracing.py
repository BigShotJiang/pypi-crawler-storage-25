from __future__ import annotations

from pathlib import Path

from agentworkbench.snapshot import capture_snapshot
from agentworkbench.tracing import normalize_trace_events, trace_event_label


def test_normalize_trace_events_uses_workflow_and_surface_usage() -> None:
    trace_events = normalize_trace_events(
        {
            "workflow_trace": ["prompt:system", "tool:repo_search", "skill:planner"],
            "tool_calls": [{"name": "repo_search", "hits": 2}],
            "skills_used": ["planner"],
            "plugins_used": ["repo_index"],
            "mcp_servers_used": ["filesystem"],
            "prompt_keys_used": ["system", "reviewer"],
        }
    )

    labels = [trace_event_label(event) for event in trace_events]
    assert labels[:3] == ["prompt:system", "tool:repo_search", "skill:planner"]
    assert "plugin:repo_index" in labels
    assert "mcp:filesystem" in labels
    assert "prompt:reviewer" in labels
    assert "tool_call:repo_search" in labels


def test_normalize_trace_events_accepts_explicit_events() -> None:
    trace_events = normalize_trace_events(
        {
            "events": [
                {"kind": "decision", "name": "grounding", "score": 0.8},
                "tool:repo_search",
            ],
        }
    )

    assert trace_events[0]["label"] == "decision:grounding"
    assert trace_events[0]["data"] == {"score": 0.8}
    assert trace_events[1]["label"] == "tool:repo_search"


def test_snapshot_capture_keeps_texts_for_between_run_trace_diff(tmp_path: Path) -> None:
    target = tmp_path / "prompt.md"
    target.write_text("baseline\n", encoding="utf-8")
    before = capture_snapshot(tmp_path, "filesystem")
    target.write_text("candidate\n", encoding="utf-8")
    after = capture_snapshot(tmp_path, "filesystem")

    assert before["texts"]["prompt.md"] == "baseline\n"
    assert after["texts"]["prompt.md"] == "candidate\n"
