"""Test fixtures for telemetry edge cases.

These fixtures cover:
- Sparse telemetry: partial events, missing fields
- Contradictory telemetry: conflicting signals from different sources
- Explicit-empty telemetry: agent explicitly emits empty/no-op telemetry
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


@pytest.fixture()
def sparse_telemetry_events() -> list[dict]:
    """Minimal telemetry with only a few fields populated."""
    return [
        {
            "seq": 1,
            "kind": "tool_call",
            "name": "read_file",
            "provenance": "raw",
            "source": "workflow_trace",
        },
        {
            "seq": 2,
            "kind": "prompt",
            "provenance": "inferred",
            "source": "heuristic",
        },
    ]


@pytest.fixture()
def contradictory_telemetry_events() -> list[dict]:
    """Telemetry with conflicting signals from different sources."""
    return [
        {
            "seq": 1,
            "kind": "tool_call",
            "name": "search",
            "provenance": "raw",
            "source": "workflow_trace",
            "field": "tools_used",
        },
        {
            "seq": 2,
            "kind": "tool_call",
            "name": "search",
            "provenance": "inferred",
            "source": "heuristic",
            "field": "tools_used",
        },
        {
            "seq": 3,
            "kind": "tool_call",
            "name": "grep",
            "provenance": "raw",
            "source": "workflow_trace",
            "field": "tools_used",
        },
        {
            "seq": 4,
            "kind": "provider_request",
            "provenance": "raw",
            "source": "provider_request",
            "data": {"model": "gpt-4"},
        },
        {
            "seq": 5,
            "kind": "provider_response",
            "provenance": "inferred",
            "source": "heuristic",
            "data": {"model": "claude-3"},
        },
    ]


@pytest.fixture()
def explicit_empty_telemetry_events() -> list[dict]:
    """Agent explicitly emitted empty/no-op telemetry."""
    return [
        {
            "seq": 0,
            "kind": "startup",
            "name": "agent_start",
            "provenance": "raw",
            "source": "runtime",
            "data": {"no_events": True},
        },
    ]


@pytest.fixture()
def no_telemetry_events() -> list[dict]:
    """Completely empty telemetry."""
    return []


@pytest.fixture()
def sparse_telemetry_row(sparse_telemetry_events) -> dict:
    """A run row with sparse telemetry."""
    return {
        "case": {"id": "case-1", "prompt": "What is 2+2?"},
        "artifact": {
            "output": "4",
            "trace_events": sparse_telemetry_events,
            "workflow_trace": ["tool:read_file"],
            "tool_calls": [{"name": "read_file", "status": "success"}],
        },
        "scores": {"output_quality": 0.9},
    }


@pytest.fixture()
def contradictory_telemetry_row(contradictory_telemetry_events) -> dict:
    """A run row with contradictory telemetry."""
    return {
        "case": {"id": "case-2", "prompt": "Search the codebase"},
        "artifact": {
            "output": "Found results",
            "trace_events": contradictory_telemetry_events,
            "workflow_trace": ["tool:search", "tool:grep"],
            "tool_calls": [
                {"name": "search", "status": "success"},
                {"name": "grep", "status": "success"},
            ],
        },
        "scores": {"output_quality": 0.7},
    }


@pytest.fixture()
def explicit_empty_telemetry_row(explicit_empty_telemetry_events) -> dict:
    """A run row with explicit empty telemetry."""
    return {
        "case": {"id": "case-3", "prompt": "Simple question"},
        "artifact": {
            "output": "Answer",
            "trace_events": explicit_empty_telemetry_events,
            "workflow_trace": [],
            "tool_calls": [],
        },
        "scores": {"output_quality": 0.5},
    }


@pytest.fixture()
def telemetry_fixtures_dir(tmp_path: Path) -> Path:
    """Create a directory with all telemetry fixture files."""
    fixtures_dir = tmp_path / "telemetry_fixtures"
    fixtures_dir.mkdir()

    fixture_data = {
        "sparse": [
            {"seq": 1, "kind": "tool_call", "name": "read_file", "provenance": "raw", "source": "workflow_trace"},
            {"seq": 2, "kind": "prompt", "provenance": "inferred", "source": "heuristic"},
        ],
        "contradictory": [
            {
                "seq": 1,
                "kind": "tool_call",
                "name": "search",
                "provenance": "raw",
                "source": "workflow_trace",
                "field": "tools_used",
            },
            {
                "seq": 2,
                "kind": "tool_call",
                "name": "search",
                "provenance": "inferred",
                "source": "heuristic",
                "field": "tools_used",
            },
            {
                "seq": 3,
                "kind": "provider_request",
                "provenance": "raw",
                "source": "provider_request",
                "data": {"model": "gpt-4"},
            },
            {
                "seq": 4,
                "kind": "provider_response",
                "provenance": "inferred",
                "source": "heuristic",
                "data": {"model": "claude-3"},
            },
        ],
        "explicit_empty": [
            {
                "seq": 0,
                "kind": "startup",
                "name": "agent_start",
                "provenance": "raw",
                "source": "runtime",
                "data": {"no_events": True},
            },
        ],
    }

    for name, events in fixture_data.items():
        (fixtures_dir / f"{name}.json").write_text(json.dumps(events, indent=2), encoding="utf-8")

    return fixtures_dir
