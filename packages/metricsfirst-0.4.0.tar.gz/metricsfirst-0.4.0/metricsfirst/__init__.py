"""
MetricsFirst SDK for Python
Track analytics for your Telegram bots and web funnels
"""

from .client import MetricsFirst
from .async_client import AsyncMetricsFirst
from .types import (
    ServiceEventData,
    ErrorEventData,
    ErrorSeverity,
    PurchaseEventData,
    PurchaseStatus,
    RecurringChargeEventData,
    RefundEventData,
    UserIdentifyData,
    # Funnel tracking types (legacy)
    UtmParams,
    FunnelEventData,
    IdentityLinkData,
    # Funnel ID-based tracking
    FunnelStepData,
    UserIdentityLinkData,
    # Stage-based funnel tracking (v2)
    FunnelEventType,
    StageEventData,
)

__version__ = "0.4.0"
__all__ = [
    "MetricsFirst",
    "AsyncMetricsFirst",
    "ServiceEventData",
    "ErrorEventData",
    "ErrorSeverity",
    "PurchaseEventData",
    "PurchaseStatus",
    "RecurringChargeEventData",
    "RefundEventData",
    "UserIdentifyData",
    # Funnel tracking types (legacy)
    "UtmParams",
    "FunnelEventData",
    "IdentityLinkData",
    # Funnel ID-based tracking
    "FunnelStepData",
    "UserIdentityLinkData",
    # Stage-based funnel tracking (v2)
    "FunnelEventType",
    "StageEventData",
]

