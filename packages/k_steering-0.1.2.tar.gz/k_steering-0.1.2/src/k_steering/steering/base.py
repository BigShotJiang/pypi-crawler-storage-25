import json
import logging
import os
import pickle
import random
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Mapping

import torch
import torch.nn.functional as F
from huggingface_hub import hf_hub_download
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.utils import PushToHubMixin

from k_steering.steering.config import SteeringConfig, TrainerConfig

_LOGGER = logging.getLogger(__name__)


class ActivationSteering(ABC, PushToHubMixin):
    """
    Base class for activation steering methods

    Provides common functionality for:
    - Model loading
    - Caching hidden states
    - Save/load operations
    - Basic generation interface

    Subclasses should implement:
    - build_steering_trainer()
    - _apply_steering()
    """

    def __init__(
        self,
        model_name: str,
        steering_config: SteeringConfig | None = None,
        trainer_config: TrainerConfig | None = None,
        device: str | None = None,
    ):
        """
        Initialize activation steering base

        Args:
            model_name (str): HuggingFace model name or path
            steering_config (SteeringConfig): Configuration for steering behavior
            trainer_config (TrainerConfig): Configuration for training classifier
            device (str): Device to load model on (auto-detected if None)
        """
        
        self.model_name = model_name
        self.steering_config = steering_config or SteeringConfig()
        self.trainer_config = trainer_config or TrainerConfig()
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")


        # Setup logging
        self.logger = _LOGGER
        logging.basicConfig(level=logging.INFO)
        output_dir = self.steering_config.output_dir if self.steering_config.output_dir else "./outputs"
        os.makedirs(output_dir, exist_ok=True)
        file_handler = logging.FileHandler(
            os.path.join(output_dir, "steering_log.log")
        )
        file_handler.setLevel(logging.INFO)
        self.logger.addHandler(file_handler)
        self.logger.setLevel(logging.INFO)
        
        
        # Load model and tokenizer
        self.model, self.tokenizer = self._load_hf_model(model_name)

        # State variables (populated during fit)
        self.dataset = None
        self.unique_labels = None
        self.eval_prompts = None
        self.cache = None
        self._is_fitted = False

        # Steering components (subclass-specific)
        self.steering_vectors = {}
        self.k_clf = None
        
    def __str__(self) -> str:
        status = "Fitted" if self._is_fitted else "Not Fitted"
        
        return (
            f"{self.__class__.__name__} Summary:\n"
            f"  - Model: {self.model_name}\n"
            f"  - Device: {self.device}\n"
            f"  - Status: {status}\n"
            f"  - Steering Config: {self.steering_config}\n"
            f"  - Trainer Config: {self.trainer_config}\n"
        )
        

    def _load_hf_model(
        self, model_name: str
    ) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
        """
        Load HuggingFace model and tokenizer

        Args:
            model_name (str): Huggingface Model identifier

        Returns:
            Tuple of (model, tokenizer)
        """
        self.logger.info(f"Loading Model: {model_name} from HuggingFace")
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
            _attn_implementation="eager",
            output_hidden_states=True,
            device_map="auto" if self.device == "cuda" else None,
        )

        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        model.eval()
        return model, tokenizer

    @abstractmethod
    def _load_task(self, task_name: str, max_samples:int = None) -> tuple[Any, list[str], list[str]]:
        """
        Load predefined task dataset

        Args:
            task_name (str): Name of Predefined task to load

        Returns:
            Tuple of (dataset, unique_labels, eval_prompts)
        """
        # TODO: Implement task loading from registry
        raise NotImplementedError(
            f"Task loading for '{task_name}' not implemented. "
            "Override this method or provide custom dataset."
        )

    def _extract_labels(self, dataset: Any) -> list[str]:
        """
        Extract unique labels from dataset

        Args:
            dataset (Any): Dataset object

        Returns:
            List of unique label strings
        """
        # Default implementation assumes dataset has 'label' field
        if hasattr(dataset, "__iter__"):
            labels = [item.get("label") for item in dataset if "label" in item]
            return list(set(labels))
        raise NotImplementedError("Override this method for custom dataset structure")

    def get_hidden_cache(
        self,
        prompts: dict[str, list[str]],  # e.g. {"train": [...], "eval": [...]}
        batch_size: int = 64,
        return_attention_mask: bool = True,
    ) -> dict[str, dict[int | str, torch.Tensor]]:
        """
        Get cached hidden states for multiple named prompt splits.

        Args:
            prompts (Dict): Dict mapping split name -> list of prompts
            batch_size (int): Batch size for processing
            return_attention_mask (bool): Whether to include attention masks

        Returns:
            {
            split_name: {
                layer_idx: Tensor [B, T, D],
                ...
                "attention_mask": Tensor [B, T]
            }
            }
        """
        num_layers = self.model.config.num_hidden_layers
        all_caches: dict[str, dict[int | str, torch.Tensor]] = {}

        with torch.no_grad():
            for split_name, split_prompts in prompts.items():
                cache = {i: [] for i in range(num_layers + 1)}
                attention_masks = [] if return_attention_mask else None
                for i in range(0, len(split_prompts), batch_size):
                    batch = split_prompts[i : i + batch_size]

                    inputs = self.tokenizer(
                        batch,
                        return_tensors="pt",
                        padding=True,
                        truncation=True,
                    ).to(self.device)

                    if return_attention_mask:
                        attention_masks.append(inputs["attention_mask"])
                    # print(f"DEBUG: inputs type: {type(inputs)}, inputs: {inputs}")
                    outputs = self.model(
                        **inputs,
                        output_hidden_states=True,
                        return_dict=True,
                    )

                    for layer_idx, hidden in enumerate(outputs.hidden_states):
                        cache[layer_idx].append(hidden.cpu())

                # concatenate batches
                # cache = {k: torch.cat(v, dim=0) for k, v in cache.items()}
                for layer_idx, tensors in cache.items():
                    # tensors: list of [B, T_i, D]
                    max_T = max(t.size(1) for t in tensors)

                    padded = [
                        F.pad(t, (0, 0, 0, max_T - t.size(1)))  # pad dim=1
                        for t in tensors
                    ]

                    cache[layer_idx] = torch.cat(padded, dim=0)

                if return_attention_mask:
                    max_att_T = max(t.size(1) for t in attention_masks)
                    attn_padded = [
                        F.pad(t, (0, max_att_T - t.size(1)))  # pad dim=1
                        for t in attention_masks
                    ]
                    cache["attention_mask"] = torch.cat(attn_padded, dim=0)

                all_caches[split_name] = cache

        return all_caches

    def get_layer_cache(
        self,
        split_name: str,
        layer_idx: int,
        prompts: dict[str, list[str]] | None = None,
        batch_size: int = 64,
        use_cached: bool = True,
    ) -> torch.Tensor:
        """
        Extract the last non-padding token representation for a given
        layer and named split.
        
        Args:
            split_name (str): Split Name for prompt type
            layer_idx (int) : Layer ID for layer wise cache
            prompts (Dict) : Dict of Prompts with Named Splits (only when cache is not defined)
            batch_size (int) : Batch Size for generating cache
            use_cache (bool): Boolean for using existing cache or not

        Returns:
            Tensor of shape [num_prompts, hidden_dim]
        """
        # ---------- ensure cache for split exists ----------
        if (
            not use_cached
            or self.cache is None
            or split_name not in self.cache
            or "attention_mask" not in self.cache[split_name]
        ):
            if prompts is None or split_name not in prompts:
                raise ValueError(
                    f"Must provide prompts for split '{split_name}' "
                    "if cache is not available"
                )

            # compute cache only for this split
            self.cache = self.cache or {}
            self.cache.update(
                self.get_hidden_cache(
                    {split_name: prompts[split_name]},
                    batch_size=batch_size,
                    return_attention_mask=True,
                )
            )

        split_cache = self.cache[split_name]
        hidden = split_cache[layer_idx] 
        attention_mask = split_cache["attention_mask"]   # [B, T]

        # last non-padding token index
        lengths = attention_mask.sum(dim=1) - 1

        # collect last-token representations
        vectors = [hidden[i, idx] for i, idx in enumerate(lengths)]

        return torch.stack(vectors, dim=0)

    @abstractmethod
    def build_steering_trainer(
        self, eval: bool = False
    ):
        """
        Build steering classifier/vectors from cached activations

        Args:
            cache (dict): Cached hidden states
            eval (bool): Whether to build evaluation classifier

        Returns:
            Classifier/steering vectors (subclass-specific)
        """
        pass

    @abstractmethod
    def _apply_steering(
        self, hidden_states: torch.Tensor, layer_idx: int, steering_strength: float
    ) -> torch.Tensor:
        """
        Apply steering to hidden states at a specific layer

        Args:
            hidden_states (torch.Tensor): Original hidden states
            layer_idx (int): Current layer index
            steering_strength (float): Strength of steering

        Returns:
            torch.Tensor: Modified hidden states
        """
        pass

    def fit(
        self,
        task: str | None = None,
        dataset: Any | None = None,
        eval_prompts: list[str] | None = None,
        batch_size: int = 64,
        max_samples: int = None
    ) -> "ActivationSteering":
        """
        Fit the steering model on a task or dataset

        Args:
            task (str): Name of predefined task
            dataset (Any): Custom dataset
            eval_prompts (list): Optional evaluation prompts
            batch_size (int): Batch size for caching

        Returns:
            self for method chaining
        """
        # Load data
        if task is not None:
            self.dataset, self.unique_labels, self.eval_prompts = self._load_task(task,max_samples)
        elif dataset is not None:
            if max_samples:
                random.seed(42)
                self.dataset = random.sample(dataset, max_samples)
                self.eval_prompts = random.sample(eval_prompts, max_samples) or []
                self.unique_labels = self._extract_labels(dataset)
            else:
                self.dataset = dataset
                self.unique_labels = self._extract_labels(dataset)
                self.eval_prompts = eval_prompts or []
                
            
        else:
            raise ValueError("Either 'task' or 'dataset' must be provided")
        
        self.tone2idx = {t: i for i, t in enumerate(self.unique_labels)}

        # Prepare prompts
        train_prompts = self._get_prompts_from_dataset(self.dataset)
        self.logger.info(f"Number of training prompts: {len(train_prompts)}")
        self.logger.info(f"Number of eval prompts: {len(self.eval_prompts)}")
        self.n_train_prompts = len(train_prompts)
        all_prompts = {
                            "train": train_prompts,
                            "eval": self.eval_prompts,
                        }

        # Cache hidden states
        self.logger.info(f"Caching hidden states for {all_prompts.keys()} prompt splits...")
        self.cache = self.get_hidden_cache(all_prompts, batch_size=batch_size)

        # Build classifier/steering vectors
        self.logger.info("Building Steering Trainer...")
        self.build_steering_trainer(eval=False)
        self._is_fitted = True

        self.logger.info("Training complete!")
        return self

    def _get_prompts_from_dataset(self, dataset: Any) -> list[str]:
        """
        Extract prompts from dataset

        Args:
            dataset (Any): Dataset object

        Returns:
            List of prompt strings
        """
        if hasattr(dataset, "__iter__"):
            prompts = [item.get("prompt", item.get("text", "")) for item in dataset]
            return [p for p in prompts if p]
        raise NotImplementedError("Override for custom dataset structure")

    def get_steered_output(
        self,
        input_prompts: list[str],
        steering_strength: float | None = None,
        layers: list[int] | None = None,
        target_labels: list[str] | None = None,
        avoid_labels: list[str] | None = None,
        layer_strengths: dict[int, float] | None = None,
        max_new_tokens: int = 100,
        return_dict: bool = False,
        *,
        generation_kwargs,
    ) -> str | dict[str, Any]:
        """
        Generate steered output for input prompt

        Args:
            input_prompt (list): Input text
            steering_strength (float): Override default strength
            layers (list): Override target layers
            target_labels (list): Labels for steering behaviour towards
            avoid_labels (list): Labels for steering behaviour away from 
            layer_strengths (dict): Layer-specific strengths
            max_new_tokens (int): Maximum tokens to generate
            return_dict (bool): Return full output dictionary
            generation_kwargs: Additional generation parameters

        Returns:
            Generated text or output dictionary
        """
        if not self._is_fitted:
            raise RuntimeError(
                "Model must be fitted before generation. Call fit() first."
            )

        # Get effective steering parameters
        self.steering_strength = steering_strength or self.steering_config.steering_strength
        self.target_layers = layers or self.steering_config.steer_layers
        self.layer_strengths = layer_strengths or self.steering_config.layer_strengths
        self.target_lbls = target_labels
        self.avoid_lbls = avoid_labels

        # Prepare generation
        self.gen_kwargs = self._prepare_generation_kwargs(generation_kwargs
        )

        # Subclass-specific steering implementation
        output = self._generate_with_steering(
            input_prompts=input_prompts,
            steering_strength = self.steering_strength,
            target_labels=self.target_lbls,
            avoid_labels=self.avoid_lbls,
            target_layers=self.target_layers,
            layer_strengths=self.layer_strengths,
            generation_kwargs=self.gen_kwargs
        )

        if return_dict:
            return output
        return output.get("text", output)

    def _prepare_generation_kwargs(
        self,
        generation_kwargs: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        generation_kwargs = dict(generation_kwargs or {})

        # Defaults
        defaults = {
            "max_new_tokens": 100,
            "temperature": 1.0,
            "top_p": 0.9,
            "do_sample": True,
        }

        # Resolve known keys: user value > default
        gen_kwargs = {
            key: generation_kwargs.pop(key, default)
            for key, default in defaults.items()
        }

        # Add tokenizer-specific values
        gen_kwargs.update(
            {
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
            }
        )

        # Pass through any extra user-provided generation args
        gen_kwargs.update(generation_kwargs)

        return gen_kwargs
    def _generate_with_steering(
        self,
        input_prompt: str,
        steering_strength: float,
        target_labels: list[str],
        avoid_labels: list[str] | None,
        target_layers: list[int] | None,
        layer_strengths: dict[int, float],
        generation_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Generate text with steering applied (base implementation)

        Args:
            input_prompt (str): Input text
            steering_strength (float): Global steering strength
            target_labels (list): Labels for steering behaviour towards
            avoid_labels (list): Labels for steering behaviour away from 
            target_layers (list): Layers to apply steering
            layer_strengths (dict): Layer-specific strengths
            generation_kwargs: Generation parameters

        Returns:
            Dictionary with generation results
        """
        # Basic implementation - subclasses can override
        inputs = self.tokenizer(input_prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(**inputs, **generation_kwargs)

        generated_text = self.tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1] :], skip_special_tokens=True
        )

        return {
            "text": generated_text,
            "input_prompt": input_prompt,
            "steering_strength": steering_strength,
            "target_layers": target_layers,
        }

    def save(
        self,
        model_path: str | Path,
        filename: str,
        *,
        push_to_hub: bool = False,
        repo_id: str | None = None,
        commit_message: str = "Add steering model artifacts",
        private: bool | None = True,
    ) -> None:
        """
        Save steering model to Disk or Huggingface

        Args:
            model_path (str): Directory to save
            filename (str): Base filename
            push_to_hub (bool): Boolean flag if model is to be saved on Hugginface
            repo_id (str) : Hugginface repository id for model 
            commit_message (str): Commit Message for Hugginface
            private (bool): Boolean flag for pushing to a private huggingface repository
        """
        model_path = Path(model_path)
        model_path.mkdir(parents=True, exist_ok=True)

        # Save steering config
        config_path = model_path / f"{filename}_steering_config.json"
        with open(config_path, "w") as f:
            json.dump(self.steering_config.to_dict(), f, indent=2)

        # Save trainer config
        config_path = model_path / f"{filename}_trainer_config.json"
        with open(config_path, "w") as f:
            json.dump(self.trainer_config.to_dict(), f, indent=2)

        # Save classifier/steering vectors
        if self.k_clf is not None:
            clf_path = model_path / f"{filename}_classifier.pkl"
            with open(clf_path, "wb") as f:
                pickle.dump(self.k_clf, f)

        if self.steering_vectors is not None:
            vec_path = model_path / f"{filename}_vectors.pt"
            torch.save(self.steering_vectors, vec_path)

        # Save metadata
        metadata = {
            "model_name": self.model_name,
            "unique_labels": self.unique_labels,
            "is_fitted": self._is_fitted,
            "class_name": self.__class__.__name__,
        }
        metadata_path = model_path / f"{filename}_metadata.json"
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)

        self.logger.info(f"Model saved to {model_path / filename}")

        if push_to_hub:
            self.push_to_hub(
                repo_id=repo_id,
                commit_message=commit_message,
                private=private,
                local_dir=str(model_path),
            )

    def save_pretrained(
        self,
        save_directory: str | Path,
        *,
        filename: str = "activation_steering",
        **kwargs,
    ):
        self.save(
            model_path=save_directory,
            filename=filename,
            push_to_hub=False,  # important: avoid recursion
        )
        
    def _get_repo_url(self, repo_id: str) -> str:
        return f"https://huggingface.co/{repo_id}"

    @classmethod
    def load(
        cls,
        model_path: str | Path,
        filename: str,
        *,
        repo_id: str | None = None,
        revision: str | None = None,
    ) -> "ActivationSteering":
        """
        Load steering model from local disk or Hugging Face Hub.

        Args:
            model_path (str): Local directory OR cache dir for HF download
            filename (str): Base filename
            repo_id (str): Hugging Face repo id (if loading from hub)
            revision (str): Branch / tag / commit
        """
        # ---------- resolve files ----------
        if repo_id is not None:
            # Download artifacts from HF into cache
            def hf(path: str) -> Path:
                return Path(
                    hf_hub_download(
                        repo_id=repo_id,
                        filename=path,
                        revision=revision,
                        cache_dir=model_path
                    )
                )

            metadata_path = hf(f"{filename}_metadata.json")
            steering_config_path = hf(f"{filename}_steering_config.json")
            trainer_config_path = hf(f"{filename}_trainer_config.json")
            try:
                clf_path = hf(f"{filename}_classifier.pkl")
            except Exception:
                pass
            try:
                vec_path = hf(f"{filename}_vectors.pt")
            except Exception:
                pass

        else:
            model_path = Path(model_path)
            metadata_path = model_path / f"{filename}_metadata.json"
            steering_config_path = model_path / f"{filename}_steering_config.json"
            trainer_config_path = model_path / f"{filename}_trainer_config.json"
            clf_path = model_path / f"{filename}_classifier.pkl"
            vec_path = model_path / f"{filename}_vectors.pt"

        # ---------- load metadata ----------
        try:
            with open(metadata_path) as f:
                metadata = json.load(f)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File {metadata_path} not found.") from e

        # ---------- load steering config ----------
        try:
            with open(steering_config_path) as f:
                steering_config_dict = json.load(f)
            steering_config = SteeringConfig.from_dict(steering_config_dict)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File {steering_config_path} not found.") from e

        # ---------- load trainer config ----------
        try:
            with open(trainer_config_path) as f:
                trainer_config_dict = json.load(f)
            trainer_config = TrainerConfig.from_dict(trainer_config_dict)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File {trainer_config_path} not found.") from e

        # ---------- initialize instance ----------
        instance = cls(metadata["model_name"], steering_config, trainer_config)
        instance.unique_labels = metadata["unique_labels"]
        instance._is_fitted = metadata["is_fitted"]
        instance.tone2idx = {t: i for i, t in enumerate(metadata['unique_labels'])}

        # ---------- load classifier ----------
        # if clf_path.exists():
        try:
            with open(clf_path, "rb") as f:
                instance.k_clf = pickle.load(f)
        except (pickle.UnpicklingError, EOFError, AttributeError, ImportError, IndexError) as e:
            print(f"Error unpickling data: {e}")
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File {clf_path} not found.") from e
        except UnboundLocalError as e:
            raise UnboundLocalError("Error Loading File") from e
    
        # ---------- load steering vectors ----------
        # if vec_path.exists():
        try:
            instance.steering_vectors = torch.load(vec_path, map_location="cpu")
        except Exception as e:
            raise RuntimeError(
                                f"Failed to load steering vectors from {vec_path}"
                                ) from e

        cls.logger.info(
            f"Model loaded from "
            f"{repo_id if repo_id is not None else metadata_path.parent}"
        )
        return instance

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"model_name='{self.model_name}', "
            f"fitted={self._is_fitted}, "
            f"steering_strength={self.steering_config.steering_strength})"
        )
        

