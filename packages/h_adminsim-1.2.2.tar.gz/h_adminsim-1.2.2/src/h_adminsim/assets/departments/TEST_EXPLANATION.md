# Test Explanation by Subspecialty

내과(Internal Medicine) 9개 진료과별 검사 항목, 스케줄링 제약 조건, 및 근거 가이드라인을 정리합니다.

---

## 범례

| 필드 | 설명 |
|------|------|
| `Priority`          | 0 = 기본 검사, 1 = 중간 우선순위, 2 = 고난이도/침습적 검사 |
| `Result (h)`        | 결과 반환까지 걸리는 시간 (시간 단위) |
| `Duration (h)`      | 검사 소요 시간 (시간 단위) |
| `depends_on`        | 해당 검사 전에 선행되어야 하는 검사 코드 |
| `avoid_same_day`    | 같은 날 동시에 시행하면 안 되는 검사 코드 |
| `not_combined_with` | 임상적으로 동시에 수행하지 않는 검사 코드 |

&nbsp;

---

## 1. Gastroenterology - `IMGAS`
### 검사 목록 및 참고 가이드라인

| Code | Test |  Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|-----------|--------------|------------|------------|----------------|
| IMGAS-T01 | [Abdominal Ultrasound (복부 초음파)](https://www.samsunghospital.com/en/health-library/test-procedures/abdominal-ultrasound.do) | 0 | [0.5](https://www.samsunghospital.com/en/health-library/test-procedures/abdominal-ultrasound.do) | 3 | - | - |
| IMGAS-T02 | [Liver Fibrosis Scan (간 섬유화 검사)](https://www.nhimc.or.kr/conts/104005012000000.do) | 0 | [0.25](https://www.nhimc.or.kr/conts/104005012000000.do) | 2 | - | - |
| IMGAS-T03 | [Urea breath test (Helicobacter Pylori Breath Test, 헬리코박터 호흡 검사)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=329) | 0 | [0.5](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=329) | 3 | - | - |
| IMGAS-T04 | [Upper GI Endoscopy (상부위장관내시경)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=42) | 1 | [0.5](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=42) | 24 | - | - |
| IMGAS-T05 | [Colonoscopy (대장내시경)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=45) | 1 | [2.5](https://madeforthismoment.asahq.org/preparing-for-surgery/procedures/colonoscopy/#:~:text=How%20long%20does%20a%20colonoscopy%20take?%20The,typically%20ranges%20from%20two%20to%20three%20hours.) | 48 | - | IMGAS-T06 |
| IMGAS-T06 | [ERCP (내시경역행담췌관조영술)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=46) | 2 | [1.5](https://my.clevelandclinic.org/health/diagnostics/4951-ercp-endoscopic-retrograde-cholangiopancreatography) | 48 | IMGAS-T01 | IMGAS-T05 |


### Priority 근거
- 0: 비침습적 스크리닝으로 가능한 빠른 검사
- 1: 비침습적 검사 이후 더 정확한 진단을 위한 침습적 검사
- 2: 고위험 치료 목적의 침습적 검사

### 스케줄링 제약 근거
- **T05 ↔ T06 (avoid):** 간혹 동시에 하는 경우가 있지만 cumulative sedation risks가 존재 ([Safety Outcomes of Same-Day Endoscopic Retrograde Cholangiopancreatography and Colonoscopy: A Retrospective Cohort Study](https://journals.lww.com/ajg/fulltext/2025/10002/s176_safety_outcomes_of_same_day_endoscopic.177.aspx)).
- **T06 depends_on T01:** US를 ERCP 하기 전 선행하는 것을 권고. "We suggest the following high-risk criteria for choledocholithiasis, which should directly prompt ERCP: (1) Common bile duct stone on US or cross-sectional imaging ..." ([ASGE 2019 Choledocholithiasis Guideline](https://pmc.ncbi.nlm.nih.gov/articles/PMC8594622/); [Controversies in ERCP, PMC9258020](https://pmc.ncbi.nlm.nih.gov/articles/PMC9258020/))

&nbsp;

---

## 2. Cardiology - `IMCAR`
### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMCAR-T01 | [Echocardiography (심장 초음파)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=516) | 0 | [0.5](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=516) | 6 | - | - |
| IMCAR-T02 | [Electrocardiogram (심전도, ECG)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=28) | 0 | [0.05](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=28) | 1 | - | - |
| IMCAR-T03 | [24-hour Holter Monitor Setup (24시간 홀터 모니터)](https://heart.amc.seoul.kr/asan/depts/heart/K/content.do?menuId=5036) | 0 | [0.25](https://heart.amc.seoul.kr/asan/depts/heart/K/content.do?menuId=5036) | 48 | - | - |
| IMCAR-T04 | [Cardiac Stress Test (심장 운동부하검사)](http://www.samsunghospital.com/home/hbv/disease/check/view.do?VIEW=guide05) | 1 | [0.5](http://www.samsunghospital.com/home/hbv/disease/check/view.do?VIEW=guide05) | 6 | IMCAR-T02 | - |
| IMCAR-T05 | [Coronary CT Angiography (관상동맥 CT 조영술)](https://health.amc.seoul.kr/health/personal/checkInformation.do?checkno=41) | 1 | [0.5](https://health.amc.seoul.kr/health/personal/checkInformation.do?checkno=41) | 12 | - | - |
| IMCAR-T06 | [Cardiac MRI (심장 MRI)](https://heart.amc.seoul.kr/asan/depts/heart/K/content.do?menuId=5032) | 2 | [1.0](https://heart.amc.seoul.kr/asan/depts/heart/K/content.do?menuId=5032) | 36 | IMCAR-T02 | - |

### Priority 근거
- 0: 초기 심장 평가를 위한 비침습적 기초 검사
- 1: 기초 검사 이후 심장 기능 또는 관상동맥 상태를 평가하기 위한 추가 진단 검사
- 2: 특정 적응증에서 시행되는 고급 영상 검사로, 정밀한 조직 특성 평가 및 복잡한 진단에 사용됨

### 스케줄링 제약 근거
- **T04 depends_on T02:** 기저 ECG 없이 운동부하 진행 불가. "The resting ECG, heart rate, and blood pressure are obtained prior to starting the exercise regimen. The baseline ECG should be evaluated closely prior to starting the exercise portion of the test." ([Treadmill Stress Testing, StatPearls](https://www.ncbi.nlm.nih.gov/books/NBK499903/))
- **T06 depends_on T02:** 심장초음파는 CMR 전 구조적 기능 평가의 1차 검사로 선행됨. "Echocardiography is the imaging technique of first choice ... CMR should be considered when echocardiography is unavailable or non-diagnostic" ([CMR in ESC Guidelines, PMC10364363](https://pmc.ncbi.nlm.nih.gov/articles/PMC10364363/)).

&nbsp;

---

## 3. Pulmonary - `IMPUL`
### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMPUL-T01 | [Pulmonary Function Test (폐기능 검사, PFT)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=304) | 0 | [0.5](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=304) | 3 | - | IMPUL-T05 |
| IMPUL-T02 | [Chest CT Scan (흉부 CT)](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000006) | 0 | [0.25](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000006) | 6 | - | - |
| IMPUL-T03 | [Arterial Blood Gas Analysis (동맥혈 가스 분석)](https://my.clevelandclinic.org/health/diagnostics/22409-arterial-blood-gas-abg) | 0 | [0.5](https://my.clevelandclinic.org/health/diagnostics/22409-arterial-blood-gas-abg) | 2 | - | - |
| IMPUL-T04 | [Sputum Analysis (객담검사)](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000121) | 0 | [0.25](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000121) | 48 | - | - |
| IMPUL-T05 | [Methacholine Challenge Test (메타콜린 기도유발검사)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=383) | 1 | [0.75](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=383) | 3 | IMPUL-T01 | IMPUL-T01, IMPUL-T06 |
| IMPUL-T06 | [Bronchoscopy (기관지내시경)](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000120) | 2 | [0.5](https://www.snuh.org/health/nMedInfo/nView.do?category=TEST&medid=BA000120) | 72 | IMPUL-T02 | IMPUL-T05 |

### Priority 근거
* 0: 호흡기 증상에 대한 초기 평가를 위한 비침습적 또는 기본 검사로, 폐기능, 영상, 가스 교환 상태를 전반적으로 확인하는 데 사용됨
* 1: 초기 검사 결과를 바탕으로 특정 질환을 평가하기 위한 추가 기능 검사 또는 유발 검사
* 2: 비침습적 검사로 충분한 진단이 어려운 경우 시행되는 침습적 또는 고난도 검사로, 병변의 직접 확인 및 조직학적 진단에 사용됨

### 스케줄링 제약 근거

&nbsp;

---

## 4. Endocrinology/Metabolism - `IMEND`
### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMEND-T01 | [Thyroid Ultrasound (갑상선 초음파)](https://www.endocrinemds.com/blogs/how-long-does-a-thyroid-ultrasound-take/#:~:text=A%20thyroid%20ultrasound%20is%20a%20quick%20and,with%20no%20known%20side%20effects%20or%20complications.) | 0 | [0.5](https://www.endocrinemds.com/blogs/how-long-does-a-thyroid-ultrasound-take/#:~:text=A%20thyroid%20ultrasound%20is%20a%20quick%20and,with%20no%20known%20side%20effects%20or%20complications.) | 3 | - | - |
| IMEND-T02 | [Bone Densitometry (골밀도 검사, DEXA)](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=52) | 0 | [0.1](https://www.amc.seoul.kr/asan/healthinfo/management/managementDetail.do?managementId=52) | 6 | - | - |
| IMEND-T03 | [HbA1c Blood Test (당화혈색소 검사)](https://www.southtees.nhs.uk/resources/the-hba1c-test/) | 0 | [0.1](https://www.southtees.nhs.uk/resources/the-hba1c-test/) | 6 | - | - |
| IMEND-T04 | Thyroid Fine Needle Aspiration (갑상선 세침흡인검사, FNA) | 1 | 0.5 | 120 | IMEND-T01 | - |
| IMEND-T05 | Oral Glucose Tolerance Test (경구 당부하 검사, OGTT) | 1 | 2.0 | 6 | IMEND-T03 | IMEND-T03 |
| IMEND-T06 | Adrenal CT Scan (부신 CT) | 1 | 0.5 | 12 | - | - |

### 스케줄링 제약 근거

- **T02 depends_on T01:** 갑상선 FNA는 초음파 유도 하에 시행되므로, 결절 위치·크기·에코 소견 확인 후 적응증 결정 필요 (ATA 갑상선 결절 가이드라인)

---

## 5. Nephrology - `IMNEP`

### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMNEP-T01 | Renal Ultrasound (신장 초음파) | 0 | 0.5 | 3 | - | - |
| IMNEP-T02 | 24-hour Urine Collection Analysis (24시간 소변 수집 검사) | 0 | 0.25 | 48 | - | - |
| IMNEP-T03 | Renal Biopsy (신장 생검) | 2 | 1.0 | 120 | T01, T04 | T06 |
| IMNEP-T04 | GFR Measurement (사구체여과율 측정) | 0 | 0.5 | 6 | - | - |
| IMNEP-T05 | Dialysis Access Evaluation (투석 접근로 평가) | 1 | 0.5 | 6 | T04 | - |
| IMNEP-T06 | Renal CT Angiography (신장 CT 조영술) | 1 | 0.75 | 12 | T01, T04 | T03 |

### 스케줄링 제약 근거

- **T03 depends_on T01, T04:** 신장 생검 전 초음파로 신장 위치·크기 확인, GFR로 신기능 평가 필요 (KDIGO 생검 전 평가 기준)
- **T06 depends_on T01, T04:** CT Angiography 전 초음파 영상 및 신기능(GFR) 확인으로 조영제 안전성 평가
- **T05 depends_on T04:** 투석 접근로 평가 전 현재 신기능 수준 확인 필요
- **T03 ↔ T06 (avoid):** 생검(침습) + CT 조영제를 같은 날 시행 시 신독성 및 출혈 위험 중복

---

## 6. Hematology/Oncology - `IMHEM`

### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMHEM-T01 | Complete Blood Count with Differential (전혈구 검사, CBC) | 0 | 0.25 | 3 | - | - |
| IMHEM-T02 | Bone Marrow Biopsy (골수 생검) | 2 | 1.0 | 96 | T01, T05, T06 | T03, T04 |
| IMHEM-T03 | CT Scan with Contrast (조영증강 CT) | 1 | 0.75 | 12 | T01 | T04, T02 |
| IMHEM-T04 | PET-CT Scan (양전자방출단층촬영) | 1 | 2.0 | 36 | T01 | T03, T02 |
| IMHEM-T05 | Peripheral Blood Smear (말초혈액도말 검사) | 0 | 0.25 | 3 | - | - |
| IMHEM-T06 | Coagulation Panel (응고 검사) | 0 | 0.25 | 3 | - | - |

### 스케줄링 제약 근거

- **T02 depends_on T01, T05, T06:** 골수 생검 전 CBC·말초혈액도말·응고검사로 혈구 이상 및 출혈 위험 평가 필요 (ASH/NCCN 진단 프로토콜)
- **T03, T04 depends_on T01:** CBC 없이 CT/PET-CT staging 진행 불가 - 기저 혈구 수치가 임상 해석에 필수
- **T03 ↔ T04 (avoid):** CT 조영제 + PET 방사성 추적자를 동일 날 투여 시 방사선 노출 과다 및 결과 해석 교란
- **T02 ↔ T03, T04 (avoid):** 골수 생검 후 충분한 회복 필요, 이동·체위 변경이 요구되는 영상 검사 병행 위험

---

## 7. Infectious Diseases - `IMINF`

### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMINF-T01 | Blood Culture (혈액 배양 검사) | 0 | 0.25 | 96 | - | - |
| IMINF-T02 | Chest X-ray (흉부 X선) | 0 | 0.25 | 3 | - | - |
| IMINF-T03 | Lumbar Puncture (요추 천자) | 1 | 0.75 | 48 | T02 | - |
| IMINF-T04 | HIV Viral Load Test (HIV 바이러스 부하 검사) | 0 | 0.25 | 60 | - | - |
| IMINF-T05 | Tuberculosis Skin Test (결핵 피부 반응 검사, TST) | 0 | 0.25 | 72 | - | - |
| IMINF-T06 | Wound Culture and Sensitivity (상처 배양 및 감수성 검사) | 0 | 0.25 | 60 | - | - |

### 스케줄링 제약 근거

- **T03 depends_on T02:** 요추천자(lumbar puncture) 전 흉부X선으로 두개내압 상승 원인(폐렴, 결핵 등)을 배제해야 함 (IDSA 수막염 진단 가이드라인)
- **T05:** TST 결과는 48~72시간 후 판독 필수 - 당일 판독 불가, 재방문 필요 (ATS/CDC/IDSA TB 진단 가이드라인)

---

## 8. Allergy - `IMALL`

### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMALL-T01 | Skin Prick Test (피부 단자 검사, SPT) | 0 | 0.5 | 1 | - | T05, T06 |
| IMALL-T02 | Specific IgE Blood Test (특이 IgE 혈액 검사) | 0 | 0.25 | 36 | - | - |
| IMALL-T03 | Patch Test (첩포 검사) | 1 | 0.5 | 72 | T01 | T01, T05, T06 |
| IMALL-T04 | Spirometry (폐활량 측정) | 0 | 0.5 | 2 | - | - |
| IMALL-T05 | Oral Food Challenge (경구 식품 유발 검사, OFC) | 2 | 2.0 | 3 | T01, T02 | T01, T03, T06 |
| IMALL-T06 | Drug Provocation Test (약물 유발 검사) | 2 | 1.5 | 3 | T01, T02, T04 | T01, T03, T05 |

### 스케줄링 제약 근거

- **T05 depends_on T01, T02:** 식품 경구유발검사 전 피부반응검사(SPT) + 혈청 IgE로 감작 여부 확인 필수 (AAAAI OFC 가이드라인)
- **T06 depends_on T01, T02, T04:** 약물유발검사 전 SPT·IgE로 IgE 매개 여부 확인, 폐기능 검사로 기저 기도 상태 평가 필요 (AAAAI Drug Allergy 2022)
- **T03 depends_on T01:** 첩포검사(patch test)는 SPT로 즉시형 반응 배제 후 지연형 반응 평가
- **T01 ↔ T05, T06 (avoid):** SPT 시행 직후 이중 알레르겐 자극(OFC/Drug challenge) → 전신 아나필락시스 위험 중복
- **T05 ↔ T06 (avoid):** 식품과 약물 이중 유발검사를 동일 날 시행 시 반응 원인 구별 불가

---

## 9. Rheumatology - `IMRHE`

### 검사 목록 및 참고 가이드라인

| Code | Test | Priority | Duration (h) | Result (h) | depends_on | avoid_same_day |
|------|------|----------|--------------|------------|------------|----------------|
| IMRHE-T01 | Rheumatoid Factor and Anti-CCP Test (류마티스 인자 및 항-CCP 검사) | 0 | 0.25 | 36 | - | - |
| IMRHE-T02 | Joint Ultrasound (관절 초음파) | 1 | 0.5 | 3 | T03 | - |
| IMRHE-T03 | Joint X-ray (관절 X선) | 0 | 0.25 | 3 | - | - |
| IMRHE-T04 | MRI of Joints (관절 MRI) | 2 | 1.0 | 36 | T03, T01 | - |
| IMRHE-T05 | ANA Panel (항핵항체 검사) | 0 | 0.25 | 36 | - | - |
| IMRHE-T06 | Synovial Fluid Analysis (활액 분석) | 1 | 0.5 | 36 | T03, T02 | T04 |

### 스케줄링 제약 근거

- **T02 depends_on T03:** 관절 초음파 전 X선으로 골 미란·연골 손상 등 구조적 이상 확인 필요 (ACR 근골격계 초음파 가이드라인)
- **T04 depends_on T03, T01:** MRI 전 X선으로 관절 구조 파악, RF/Anti-CCP로 자가면역 여부 확인 필요
- **T06 depends_on T03, T02:** 활액 분석 전 X선·초음파로 관절 삼출 및 천자 가능 위치 확인 필요
- **T06 ↔ T04 (avoid):** 관절 천자(활액 채취) 후 같은 날 MRI 시행 시 천자 부위 조영 효과로 영상 해석 교란

---

## 데이터 출처

- 진료과 코드 분류: [응급의료에 관한 법률 시행규칙 별표 (emergency.or.kr)](https://emergency.or.kr/bbs/general-notice/2513)
- 각 학회 공식 임상 진료 가이드라인 (위 각 항목 참고)
- `avoid_same_day` / `depends_on` 제약 조건: 위 가이드라인 내 pre-procedural workup 섹션 및 임상 관례 기반
