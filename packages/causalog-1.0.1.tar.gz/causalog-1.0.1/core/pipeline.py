"""
pipeline.py
───────────
Orchestrates the full CausaLog RCA pipeline.

Existing stages (unchanged):
    preprocessing → nlp → clustering → anomaly → ontology → rca → explanation

New intelligence layer (appended after ontology mapping):
    feature_builder → hypothesis_engine → validator →
    temporal_analysis → insight_engine → debug_assistant

The return dict is a superset of the original — all existing keys are
preserved so nothing downstream breaks.
"""

from core.preprocessing import preprocess_logs
from core.nlp           import extract_keywords
from core.clustering    import cluster_logs
from core.anomaly       import detect_anomalies
from core.ontology      import map_ontology
from core.rca_engine    import root_cause
from core.explanation   import generate_explanations, generate_explanation_report

# ── Intelligence layer ────────────────────────────────────────────────────────
from core.intelligence.feature_builder   import build_features
from core.intelligence.hypothesis_engine import generate_hypotheses
from core.intelligence.validator         import validate_hypotheses
from core.intelligence.temporal_analysis import analyse_temporal
from core.intelligence.insight_engine    import generate_insights
from core.intelligence.debug_assistant   import generate_debug_suggestions
from core.intelligence.causal_reasoning  import build_causal_graph


def run_pipeline(logs):
    """
    Run the complete CausaLog pipeline.

    Parameters
    ----------
    logs : list[str]
        Raw log lines (from file_loader.load_logs or CLI).

    Returns
    -------
    dict with keys:
        data              – enriched pd.DataFrame
        causes            – {summary: {...}, details: [...]}          [existing]
        explanations      – list[str]                                 [existing]
        hypotheses        – validated hypotheses with confidence       [NEW]
        insights          – dashboard-ready insight cards             [NEW]
        debug_suggestions – per-cause actionable fix steps            [NEW]
        temporal          – trend + spike analysis                    [NEW]
        features          – raw numeric signals (for API consumers)   [NEW]
    """
    # ── Stage 1-7: existing pipeline (unchanged) ──────────────────────────
    df = preprocess_logs(logs)

    if df.empty:
        return _empty_result(df)

    df = extract_keywords(df)
    df = cluster_logs(df)
    df = detect_anomalies(df)
    df = map_ontology(df)

    causes       = root_cause(df)
    explanations = generate_explanations(df)

    # ── Stage 8+: intelligence layer ──────────────────────────────────────
    features             = build_features(df)
    raw_hypotheses       = generate_hypotheses(features)
    validated_hypotheses = validate_hypotheses(raw_hypotheses, features)
    temporal             = analyse_temporal(features, df)
    causal_graph         = build_causal_graph(df)
    insights             = generate_insights(validated_hypotheses, temporal, features)
    debug_suggestions    = generate_debug_suggestions(validated_hypotheses)
    explanation_report   = generate_explanation_report(
        df, hypotheses=validated_hypotheses, temporal=temporal, causal_graph=causal_graph
    )

    return {
        # ── Existing outputs (contract preserved) ─────────────────────────
        "data":             df,
        "causes":           causes,
        "explanations":     explanations,
        # ── New intelligence outputs ───────────────────────────────────────
        "hypotheses":       validated_hypotheses,
        "insights":         insights,
        "debug_suggestions":debug_suggestions,
        "temporal":         temporal,
        "predictive":       temporal.get("early_warning", {}),
        "causal_graph":     causal_graph,
        "explanation_report": explanation_report,
        "features":         features,
    }


def _empty_result(df):
    return {
        "data":             df,
        "causes":           {"summary": {}, "details": []},
        "explanations":     [],
        "hypotheses":       [],
        "insights":         [],
        "debug_suggestions":[],
        "temporal":         {
            "trend":"stable","slope":0.0,
            "spikes":[],"service_trends":{},
            "first_failure_point": None,
            "early_warning": {"is_warning": False, "risk_score": 0.0, "prediction": "No risk signal."},
            "summary":"No data.",
        },
        "predictive":       {"is_warning": False, "risk_score": 0.0, "prediction": "No risk signal."},
        "causal_graph":     {"nodes": [], "edges": [], "chains": [], "first_failure_point": None},
        "explanation_report": {"narrative": "No data.", "key_points": [], "top_hypotheses": [], "first_failure_point": None, "early_warning": {"is_warning": False, "risk_score": 0.0, "prediction": "No risk signal."}, "causal_chains": []},
        "features":         {
            "total_logs":0,"error_count":0,"warning_count":0,
            "anomaly_count":0,"error_rate":0.0,"anomaly_ratio":0.0,
            "services":{},"cause_distribution":{},"time_series":[],
            "top_keywords":[],"cross_service_correlation":[],
        },
    }
