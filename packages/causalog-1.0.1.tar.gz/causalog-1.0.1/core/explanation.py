def generate_explanations(logs_df):
    """
    Generate a human-readable explanation sentence for every log row.

    Format: "<level> from <service> — <cause>. [⚠ Anomaly detected.]"
    """
    explanations = []

    for _, row in logs_df.iterrows():
        level   = row.get("level", "Log entry")
        service = row.get("service", "an unknown service")
        cause   = row.get("cause", "an unknown issue")
        anomaly = bool(row.get("anomaly", 0))

        sentence = f"{level} from {service} — likely caused by {cause}."
        if anomaly:
            sentence += " ⚠ This entry was flagged as anomalous."

        explanations.append(sentence)

    return explanations


def generate_explanation_report(logs_df, hypotheses=None, temporal=None, causal_graph=None):
    """
    Rich, context-aware narrative summary for conversational/debug UIs.
    """
    hypotheses = hypotheses or []
    temporal = temporal or {}
    causal_graph = causal_graph or {}

    total = len(logs_df) if logs_df is not None else 0
    errors = int(logs_df["level"].isin({"ERROR", "CRITICAL"}).sum()) if total and "level" in logs_df.columns else 0
    anomalies = int(logs_df["anomaly"].sum()) if total and "anomaly" in logs_df.columns else 0

    top = hypotheses[0] if hypotheses else {"cause": "Unknown", "confidence": 0.0}
    top2 = hypotheses[1] if len(hypotheses) > 1 else None
    first = temporal.get("first_failure_point")
    warning = temporal.get("early_warning", {})
    chains = causal_graph.get("chains", [])

    lines = [
        f"Processed {total} logs with {errors} error/critical events and {anomalies} anomalies.",
        f"Most probable root cause is '{top['cause']}' ({int(top.get('confidence', 0) * 100)}% confidence).",
    ]
    if top2:
        lines.append(
            f"Alternative hypothesis: '{top2['cause']}' ({int(top2.get('confidence', 0) * 100)}%)."
        )
    if first:
        lines.append(
            f"First failure point appears at {first.get('timestamp')} in service '{first.get('service')}' with cause '{first.get('cause')}'."
        )
    if chains:
        path = " -> ".join(chains[0].get("path", []))
        if path:
            lines.append(f"Likely propagation path: {path}.")
    if warning.get("prediction"):
        lines.append(warning["prediction"])

    return {
        "narrative": " ".join(lines),
        "key_points": lines,
        "top_hypotheses": hypotheses[:3],
        "first_failure_point": first,
        "early_warning": warning,
        "causal_chains": chains[:3],
    }
