"""
causal_reasoning.py
──────────────────
Builds a lightweight causal graph from ordered error/anomaly events.

Graph schema:
    {
        "nodes": [{"id":"api-gw","type":"service","errors":12,"anomalies":3}, ...],
        "edges": [{"source":"db","target":"api-gw","weight":5,"lag_seconds":12.4,
                   "reason":"temporal_propagation"}, ...],
        "chains": [{"path":["db","api-gw","auth-svc"],"score":0.74}, ...],
        "first_failure_point": {"service":"db","timestamp":"...","cause":"Database Failure"},
    }
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, List


def build_causal_graph(df, max_window_seconds: int = 180) -> Dict[str, Any]:
    if df is None or df.empty:
        return {"nodes": [], "edges": [], "chains": [], "first_failure_point": None}

    tdf = df.copy()
    if "timestamp" in tdf.columns:
        tdf = tdf[tdf["timestamp"].notna()].sort_values("timestamp")
    if tdf.empty:
        return {"nodes": [], "edges": [], "chains": [], "first_failure_point": None}

    error_mask = tdf["level"].isin({"ERROR", "CRITICAL"}) | (tdf.get("anomaly", 0) == 1)
    events = tdf[error_mask].copy()
    if events.empty:
        return {"nodes": [], "edges": [], "chains": [], "first_failure_point": None}

    nodes = _build_nodes(events)
    edge_stats = _build_edges(events, max_window_seconds=max_window_seconds)
    edges = _format_edges(edge_stats)
    chains = _derive_chains(edges)
    first = _first_failure_point(events)

    return {"nodes": nodes, "edges": edges, "chains": chains, "first_failure_point": first}


def _build_nodes(events) -> List[Dict[str, Any]]:
    nodes = []
    for service, grp in events.groupby("service"):
        nodes.append(
            {
                "id": str(service),
                "type": "service",
                "errors": int(grp["level"].isin({"ERROR", "CRITICAL"}).sum()),
                "anomalies": int(grp.get("anomaly", 0).sum()) if "anomaly" in grp.columns else 0,
                "top_cause": str(grp["cause"].mode().iloc[0]) if "cause" in grp.columns and not grp["cause"].mode().empty else "Unknown",
            }
        )
    return sorted(nodes, key=lambda n: n["errors"], reverse=True)


def _build_edges(events, max_window_seconds: int) -> Dict[tuple, Dict[str, Any]]:
    edge_stats: Dict[tuple, Dict[str, Any]] = defaultdict(lambda: {"weight": 0, "lags": []})
    rows = list(events.itertuples(index=False))
    for i in range(len(rows) - 1):
        src = rows[i]
        for j in range(i + 1, len(rows)):
            dst = rows[j]
            lag = (dst.timestamp - src.timestamp).total_seconds()
            if lag > max_window_seconds:
                break
            if src.service == dst.service:
                continue
            key = (str(src.service), str(dst.service))
            edge_stats[key]["weight"] += 1
            edge_stats[key]["lags"].append(lag)
    return edge_stats


def _format_edges(edge_stats: Dict[tuple, Dict[str, Any]]) -> List[Dict[str, Any]]:
    edges: List[Dict[str, Any]] = []
    for (source, target), stats in edge_stats.items():
        if stats["weight"] < 2:
            continue
        avg_lag = sum(stats["lags"]) / max(len(stats["lags"]), 1)
        edges.append(
            {
                "source": source,
                "target": target,
                "weight": int(stats["weight"]),
                "lag_seconds": round(avg_lag, 2),
                "reason": "temporal_propagation",
            }
        )
    return sorted(edges, key=lambda e: e["weight"], reverse=True)


def _derive_chains(edges: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not edges:
        return []
    out_map = defaultdict(list)
    weights = Counter()
    for e in edges:
        out_map[e["source"]].append(e["target"])
        weights[(e["source"], e["target"])] = e["weight"]

    chains: List[Dict[str, Any]] = []
    for e in edges[:8]:
        start = e["source"]
        mid = e["target"]
        if out_map.get(mid):
            end = out_map[mid][0]
            score = (weights[(start, mid)] + weights.get((mid, end), 1)) / 20.0
            chains.append({"path": [start, mid, end], "score": round(min(0.99, score), 3)})
        else:
            chains.append({"path": [start, mid], "score": round(min(0.99, e["weight"] / 10.0), 3)})
    return chains[:6]


def _first_failure_point(events) -> Dict[str, Any]:
    first = events.iloc[0]
    return {
        "service": str(first.get("service", "Unknown")),
        "timestamp": str(first.get("timestamp", "")),
        "cause": str(first.get("cause", "Unknown")),
        "level": str(first.get("level", "")),
        "message": str(first.get("message", ""))[:200],
    }
