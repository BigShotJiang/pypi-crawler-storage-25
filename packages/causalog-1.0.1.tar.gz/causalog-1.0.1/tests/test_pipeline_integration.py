"""Integration tests for the full pipeline (spaCy stubbed for offline runs)."""
import sys, os, types, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# ── Minimal spaCy stub ────────────────────────────────────────────────────────
_STOPS = {"the","is","at","in","a","an","for","to","of","by","on","it","be"}

class _Token:
    def __init__(self, t):
        self.text = t; self.lemma_ = t.lower()
        self.is_alpha = t.isalpha(); self.is_stop = t.lower() in _STOPS

class _Doc:
    def __init__(self, text): self._t = [_Token(w) for w in str(text).split()]
    def __iter__(self): return iter(self._t)

class _NLP:
    def __call__(self, text): return _Doc(text)

_spacy = types.ModuleType("spacy")
_spacy.load = lambda name: _NLP()
_spacy.blank = lambda lang: _NLP()
sys.modules.setdefault("spacy", _spacy)
# ─────────────────────────────────────────────────────────────────────────────

import pandas as pd
from core.pipeline import run_pipeline

SAMPLE = [
    "2026-04-08 10:15:23,112 INFO  [AuthService] User login attempt: user_id=10234",
    "2026-04-08 10:15:24,789 INFO  [PaymentService] Initiating payment: order_id=ORD78452",
    "2026-04-08 10:15:25,102 ERROR [PaymentService] Payment failed: Gateway timeout",
    "2026-04-08 10:15:27,567 ERROR [PaymentService] Payment failed: Gateway timeout",
    "2026-04-08 10:16:02,876 ERROR [Database] Connection timeout: db_host=10.0.0.5",
    "2026-04-08 10:16:02,877 ERROR [InventoryService] Failed to sync: DBConnectionError",
    "2026-04-08 10:17:04,223 INFO  [Database] Connection established: db_host=10.0.0.5",
    "2026-04-08 10:18:10,112 INFO  [API] Request received: GET /api/orders/ORD78452",
    "2026-04-08 10:18:10,223 ERROR [API] Internal server error: Order not found",
    "2026-04-08 10:19:56,112 INFO  [HealthCheck] PaymentService: DEGRADED",
]

class TestPipelineIntegration(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.results = run_pipeline(SAMPLE)
        cls.df = cls.results["data"]

    def test_returns_expected_keys(self):
        for k in (
            "data", "causes", "explanations", "hypotheses", "temporal",
            "predictive", "causal_graph", "explanation_report", "debug_suggestions",
        ):
            self.assertIn(k, self.results)

    def test_data_is_dataframe(self):
        self.assertIsInstance(self.df, pd.DataFrame)

    def test_all_columns_present(self):
        expected = {"raw","timestamp","level","service","message",
                    "keywords","cluster","cluster_label","anomaly","cause"}
        self.assertFalse(expected - set(self.df.columns),
                         f"Missing: {expected - set(self.df.columns)}")

    def test_row_count(self):
        self.assertEqual(len(self.df), len(SAMPLE))

    def test_causes_structure(self):
        self.assertIn("summary", self.results["causes"])
        self.assertIn("details", self.results["causes"])

    def test_explanations_match_row_count(self):
        self.assertEqual(len(self.results["explanations"]), len(self.df))

    def test_timeout_root_cause_detected(self):
        summary = self.results["causes"]["summary"]
        self.assertTrue(
            any("Timeout" in k or "Traffic" in k for k in summary),
            f"Expected timeout cause, got: {list(summary.keys())}"
        )

    def test_anomaly_column_is_binary(self):
        self.assertTrue(set(self.df["anomaly"].unique()).issubset({0, 1}))

    def test_cause_column_never_empty(self):
        for v in self.df["cause"]:
            self.assertTrue(v and len(str(v)) > 0)

    def test_empty_input(self):
        r = run_pipeline([])
        self.assertTrue(r["data"].empty)
        self.assertEqual(r["causes"], {"summary":{}, "details":[]})
        self.assertEqual(r["explanations"], [])

    def test_single_log_line(self):
        r = run_pipeline(["2026-04-08 10:00:00 ERROR [SVC] Something broke"])
        self.assertEqual(len(r["data"]), 1)
        self.assertEqual(len(r["explanations"]), 1)

    def test_no_crash_on_unparseable_logs(self):
        r = run_pipeline(["garbage @@@ !!!", "more garbage", "2026-04-08 10:00:01 INFO [S] OK"])
        self.assertFalse(r["data"].empty)

    def test_details_only_has_error_critical(self):
        from config.settings import CRITICAL_LEVELS
        for d in self.results["causes"]["details"]:
            self.assertIn(d["level"], CRITICAL_LEVELS)

    def test_cluster_labels_are_strings(self):
        for v in self.df["cluster_label"]:
            self.assertIsInstance(v, str)

    def test_service_column_populated(self):
        non_unknown = self.df[self.df["service"] != "Unknown"]
        self.assertGreater(len(non_unknown), 0)

    def test_predictive_and_graph_shapes(self):
        pred = self.results["predictive"]
        self.assertIn("risk_score", pred)
        self.assertIn("prediction", pred)
        graph = self.results["causal_graph"]
        self.assertIn("nodes", graph)
        self.assertIn("edges", graph)
        self.assertIn("chains", graph)

if __name__ == "__main__":
    unittest.main()
