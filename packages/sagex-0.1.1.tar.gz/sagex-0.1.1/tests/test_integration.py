"""Phase 11 acceptance criteria: end-to-end integration test.

A single async test that wires together the real runner, real SQLite DB,
real ChromaDB vector store, and a stub LLM — no actual Anthropic API calls.
"""

from __future__ import annotations

import subprocess
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from conftest import SmartStubAnthropicClient

from sagex.api.server import ProjectRegistry
from sagex.config import (
    AgentConfig,
    AgentsConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    SecurityAgentConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventBus, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.knowledge.store import KnowledgeStore
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker
from sagex.runner import Runner
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_config(tmp_path: Path) -> ProjectConfig:
    return ProjectConfig(
        name="int-proj",
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
            # Lower threshold so our stub rule (conf=0.5) appears in context
            min_confidence_threshold=0.0,
        ),
        budget=BudgetConfig(),
        agents=AgentsConfig(security=SecurityAgentConfig(enabled=False)),
    )


def _large_diff(lines: int = 25) -> str:
    """Return a diff large enough (>= 5 changed lines) to force LLM triage."""
    return "".join(f"+line_{i} = True\n" for i in range(lines))


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------


async def test_full_cycle_writes_episode_and_rule(tmp_path: Path) -> None:
    """Full pipeline: event → triage (LLM) → plan → execute → meta → DB writes."""

    # 1. Create a minimal git repo with a Python file
    subprocess.run(
        ["git", "init", str(tmp_path)], check=True, capture_output=True
    )
    (tmp_path / "service.py").write_text("def hello():\n    pass\n")

    # 2. Build config and DB
    config = _make_config(tmp_path)
    db = RulesDB(config.knowledge.db_path)

    # 3. Build BudgetManager with SmartStubAnthropicClient
    smart_stub = SmartStubAnthropicClient()
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    budget = BudgetManager(BudgetConfig(), tracker, cache, client=smart_stub)

    def _fake_make_budget(_cfg: Any) -> BudgetManager:
        return budget

    # 4. Set up runner
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)

    # 5. Build event — large diff on service.py forces LLM triage
    event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="int-proj",
        repo_root=str(tmp_path),
        file_paths=["service.py"],
        diff=_large_diff(),
    )

    # 6. Execute the full cycle (directly, no asyncio.wait_for needed)
    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=MagicMock(return_value="pass"),
    ):
        await runner._handle_event(event)

    # 7. Episode written with status="completed" and test_result_after set
    episodes = db.get_recent_episodes("int-proj", limit=10)
    assert len(episodes) >= 1, "No episodes written"
    ep = episodes[0]
    assert ep.status == "completed", f"Expected completed, got {ep.status!r}"
    assert ep.test_result_after == "pass"

    # 8. Rule written by meta agent
    rules = db.get_rules_for_project("int-proj", min_confidence=0.0)
    assert len(rules) >= 1, "No rules written"
    found_patterns = [r.trigger_pattern for r in rules]
    assert any(r.trigger_pattern == "service.py changed" for r in rules), (
        f"Expected 'service.py changed' rule, got {found_patterns}"
    )

    # 9. Rule is retrievable via get_relevant_context (tests the full store pipeline)
    store = KnowledgeStore(config.knowledge, "int-proj")
    context = store.get_relevant_context("service.py changed")
    assert any(
        r.trigger_pattern == "service.py changed" for r in context.rules
    ), "Rule not found in get_relevant_context"

    # 10. Token usage records exist for both triage and task agent
    since = (datetime.now(UTC) - timedelta(hours=1)).isoformat()
    usage_records = db.get_token_usage("int-proj", since_iso=since)
    assert len(usage_records) >= 2, (
        f"Expected >= 2 usage records, got {len(usage_records)}"
    )
    agent_types = {r.agent_type for r in usage_records}
    assert "triage" in agent_types, f"No triage usage record. Got: {agent_types}"
    assert "task" in agent_types, f"No task usage record. Got: {agent_types}"
