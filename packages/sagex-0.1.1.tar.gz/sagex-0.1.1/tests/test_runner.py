"""Phase 9 acceptance criteria: main runner and orchestration loop."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

from conftest import StubAnthropicClient

from sagex.agents.task_agent import ExecutionResult
from sagex.api.server import ProjectRegistry
from sagex.config import (
    AgentConfig,
    AgentsConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    SecurityAgentConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventBus, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.knowledge.store import KnowledgeStore
from sagex.llm.budget import BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker
from sagex.runner import Runner, _execute_with_retry
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_db(tmp_path: Path) -> RulesDB:
    db = RulesDB(str(tmp_path / "rules.db"))
    db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    return db


def _make_budget(db: RulesDB, responses: list[str] | None = None) -> BudgetManager:
    # NOTE: _event() uses auth.py with a 1-line diff — rule-based triage returns
    # "low" without an LLM call.  Default responses start with the task-agent plan.
    stub = StubAnthropicClient(
        responses=responses
        or [
            '{"summary":"ok","severity":"low","actions":[],'
            '"checks_required":[],"rules_applied":[],"confidence":0.8,"skip_reason":null}',
            '{"outcome":"good","outcome_reason":"pass","lesson":null,"rule":null,"rule_updates":[]}',
        ]
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _make_config(
    tmp_path: Path,
    *,
    require_approval: bool = False,
    security_enabled: bool = False,
    auto_remediate: bool = False,
    approval_timeout: int = 300,
) -> ProjectConfig:
    return ProjectConfig(
        name="test-proj",
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(
            require_approval=require_approval,
            approval_timeout_seconds=approval_timeout,
        ),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        budget=BudgetConfig(),
        agents=AgentsConfig(
            security=SecurityAgentConfig(
                enabled=security_enabled,
                auto_remediate=auto_remediate,
            )
        ),
    )


def _event() -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["auth.py"],
        diff="+x = 1\n",
    )


def _make_runner(
    tmp_path: Path, config: ProjectConfig
) -> tuple[Runner, ProjectRegistry, RulesDB]:
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)
    return runner, registry, db


# ---------------------------------------------------------------------------
# Helper: patch runner internals to avoid real LLM/disk/subprocess
# ---------------------------------------------------------------------------


def _patch_runner(db: RulesDB, responses: list[str] | None = None) -> Any:
    """Return a context manager that patches _make_budget_manager and _run_tests."""
    budget = _make_budget(db, responses)

    def _fake_make_budget(_config: Any) -> BudgetManager:
        return budget

    return patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=MagicMock(return_value="pass"),
    )


# ---------------------------------------------------------------------------
# store.record_episode / write_rule / update_rule_outcome are coroutines
# ---------------------------------------------------------------------------


def _make_store(tmp_path: Path) -> KnowledgeStore:
    _make_db(tmp_path)  # run migrations first
    return KnowledgeStore(
        KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        "test-proj",
    )


def test_store_record_episode_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).record_episode)


def test_store_write_rule_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).write_rule)


def test_store_update_rule_outcome_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).update_rule_outcome)


# ---------------------------------------------------------------------------
# Full cycle
# ---------------------------------------------------------------------------


async def test_full_cycle_episode_written_completed(tmp_path: Path) -> None:
    """Full cycle: event → triage → task → execute → meta → episode completed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    with _patch_runner(db):
        await runner._handle_event(_event())

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "completed"


async def test_full_cycle_rule_written_when_meta_returns_rule(
    tmp_path: Path,
) -> None:
    """When meta agent returns a rule, it is persisted to the DB."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # triage is rule-based for auth.py + 1-line diff → no LLM call for triage
    plan_resp = (
        '{"summary":"ok","severity":"low","actions":[],'
        '"checks_required":[],"rules_applied":[],"confidence":0.8,"skip_reason":null}'
    )
    meta_response = (
        '{"outcome":"partial","outcome_reason":"ok",'
        '"lesson":"add tests","rule":{'
        '"trigger_pattern":"auth modified",'
        '"lesson":"always add tests",'
        '"tags":["auth","testing"],'
        '"initial_confidence":0.4},'
        '"rule_updates":[]}'
    )
    responses = [plan_resp, meta_response]

    with _patch_runner(db, responses):
        await runner._handle_event(_event())

    rules = db.get_rules_for_project("test-proj", min_confidence=0.0)
    assert any(r.trigger_pattern == "auth modified" for r in rules)


# ---------------------------------------------------------------------------
# Skip triage
# ---------------------------------------------------------------------------


async def test_skip_triage_llm_skip_episode_written(tmp_path: Path) -> None:
    """LLM triage returning 'skip' → no task agent call, episode written as skipped."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # Use a large diff with an unknown file to force LLM triage (inconclusive rule-based)
    large_diff = "+x = 1\n" * 20  # 20 changed lines → inconclusive → LLM called
    llm_skip_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["some_module.py"],
        diff=large_diff,
    )

    # The LLM returns 'skip'
    skip_response = '{"severity":"skip","reason":"auto-generated code"}'
    budget = _make_budget(db, [skip_response])

    def _fake_make_budget(_config: Any) -> BudgetManager:
        return budget

    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=MagicMock(return_value="pass"),
    ):
        await runner._handle_event(llm_skip_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "skipped"


async def test_skip_via_rule_based_triage(tmp_path: Path) -> None:
    """Log file → rule-based skip (no LLM call), episode written as skipped."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    skip_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["app.log"],
    )

    with _patch_runner(db):
        await runner._handle_event(skip_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "skipped"


# ---------------------------------------------------------------------------
# BudgetExceededError
# ---------------------------------------------------------------------------


async def test_budget_exceeded_episode_written_runner_continues(
    tmp_path: Path,
) -> None:
    """BudgetExceededError in plan phase → episode written, runner not crashed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    def _exploding_budget(_config: Any) -> BudgetManager:
        raise BudgetExceededError("hourly limit reached")

    with patch("sagex.runner._make_budget_manager", _exploding_budget):
        # Should not raise — exception is caught in _plan_phase
        await runner._handle_event(_event())

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    ep = episodes[0]
    assert ep.error_message is not None
    assert "hourly limit" in ep.error_message


# ---------------------------------------------------------------------------
# Deregistered project
# ---------------------------------------------------------------------------


async def test_deregistered_project_no_exception(tmp_path: Path) -> None:
    """Deregistered project mid-cycle → _handle_event exits cleanly."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)
    registry.deregister("test-proj")

    # Should return immediately without touching DB or raising
    with _patch_runner(db):
        await runner._handle_event(_event())

    # No episodes written
    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) == 0


# ---------------------------------------------------------------------------
# Approval flow
# ---------------------------------------------------------------------------


async def test_approval_approved_episode_completed(tmp_path: Path) -> None:
    """Approval resolves (approved) → episode status='completed'."""
    config = _make_config(tmp_path, require_approval=True, approval_timeout=60)
    runner, registry, db = _make_runner(tmp_path, config)

    # Capture the real asyncio.sleep before patching so the mock can use it
    _real_sleep = asyncio.sleep

    async def _auto_approve() -> None:
        await _real_sleep(0.05)
        approvals = db.get_pending_approvals("test-proj")
        for a in approvals:
            await db.resolve_approval(a.id, "approved")

    # Patch runner's sleep to yield without waiting; use real sleep to avoid recursion
    async def _yielding_sleep(n: float) -> None:
        await _real_sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            approve_task = asyncio.create_task(_auto_approve())
            await runner._handle_event(_event())
            await approve_task

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert any(ep.status == "completed" for ep in episodes)


async def test_approval_rejected_episode_skipped(tmp_path: Path) -> None:
    """Approval rejected → episode status='skipped', no ActionExecutor."""
    config = _make_config(tmp_path, require_approval=True, approval_timeout=60)
    runner, registry, db = _make_runner(tmp_path, config)

    _real_sleep = asyncio.sleep

    async def _auto_reject() -> None:
        await _real_sleep(0.05)
        approvals = db.get_pending_approvals("test-proj")
        for a in approvals:
            await db.resolve_approval(a.id, "rejected")

    async def _yielding_sleep(n: float) -> None:
        await _real_sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            reject_task = asyncio.create_task(_auto_reject())
            await runner._handle_event(_event())
            await reject_task

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert any(ep.status == "skipped" for ep in episodes)


async def test_approval_timeout_resolve_called(tmp_path: Path) -> None:
    """Approval timeout → resolve_approval('timeout') is called."""
    # Use approval_timeout=0 so the while loop exits on the first check.
    # The sleep mock yields to the event loop without waiting.
    config = _make_config(tmp_path, require_approval=True, approval_timeout=0)
    runner, registry, db = _make_runner(tmp_path, config)

    async def _yielding_sleep(n: float) -> None:
        await asyncio.sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            await runner._handle_event(_event())

    # Approval should be resolved as "timeout"
    approval = db._conn.execute(
        "SELECT status FROM pending_approvals WHERE project_name='test-proj'"
    ).fetchone()
    if approval:
        assert approval[0] == "timeout"


# ---------------------------------------------------------------------------
# Semaphore: 4th event can reach approval wait while 3 others execute
# ---------------------------------------------------------------------------


async def test_semaphore_limit_respected(tmp_path: Path) -> None:
    """The runner semaphore starts at 3; concurrent events can proceed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # Verify semaphore initial value
    assert runner._semaphore._value == 3


# ---------------------------------------------------------------------------
# _execute_with_retry
# ---------------------------------------------------------------------------


async def test_execute_with_retry_succeeds_first_attempt(tmp_path: Path) -> None:
    """_execute_with_retry returns on first success."""
    config = _make_config(tmp_path)
    plan: dict[str, Any] = {"skip_reason": None, "actions": []}

    with patch("sagex.runner._run_tests", return_value="pass"):
        result = await _execute_with_retry(plan, config, None, config.runner)

    assert isinstance(result, ExecutionResult)


# ---------------------------------------------------------------------------
# Gap #3: max_concurrent_tasks taken from constructor param
# ---------------------------------------------------------------------------


def test_runner_semaphore_uses_max_concurrent_tasks_param(tmp_path: Path) -> None:
    """Runner honours the max_concurrent_tasks constructor parameter."""
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager, max_concurrent_tasks=5)
    assert runner._semaphore._value == 5


# ---------------------------------------------------------------------------
# Gap #6: _maybe_notify is async def
# ---------------------------------------------------------------------------


def test_maybe_notify_is_async() -> None:
    """_maybe_notify must be declared async def so it runs in the event loop."""
    from sagex.runner import _maybe_notify

    assert asyncio.iscoroutinefunction(_maybe_notify)


# ---------------------------------------------------------------------------
# Gap #8: security_risk log emitted when security enabled and risk found
# ---------------------------------------------------------------------------


async def test_security_risk_log_emitted_when_risk_found(tmp_path: Path) -> None:
    """security_risk is logged when the pattern scan detects a risk."""
    config = _make_config(tmp_path, security_enabled=True, auto_remediate=False)
    runner, registry, db = _make_runner(tmp_path, config)

    log_records: list[logging.LogRecord] = []

    class _CapHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.runner as runner_mod

    logger = logging.getLogger(runner_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    handler = _CapHandler()
    logger.addHandler(handler)

    # diff with a hardcoded credential triggers "critical" security risk
    risky_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["config.py"],
        diff='+API_KEY = "sk-abcdefghijklmnopqrstuvwx"\n',
    )

    try:
        with _patch_runner(db):
            await runner._handle_event(risky_event)
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert "security_risk" in msgs


# ---------------------------------------------------------------------------
# Gap #2: auto_remediate=True calls SecurityAgent.audit() and continues
# ---------------------------------------------------------------------------


async def test_auto_remediate_calls_security_audit_and_continues(
    tmp_path: Path,
) -> None:
    """When auto_remediate=True and a risk is found, SecurityAgent.audit is called
    and the event continues to the task agent (episode is NOT skipped)."""
    config = _make_config(tmp_path, security_enabled=True, auto_remediate=True)
    runner, registry, db = _make_runner(tmp_path, config)

    # audit() returns a minimal security report; task + meta follow
    audit_response = (
        '{"severity":"critical","description":"hardcoded key",'
        '"file_path":"config.py","remediation":null}'
    )
    plan_response = (
        '{"summary":"remove key","severity":"critical","actions":[],'
        '"checks_required":[],"rules_applied":[],"confidence":0.9,"skip_reason":null}'
    )
    meta_response = (
        '{"outcome":"good","outcome_reason":"key removed",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )

    stub = StubAnthropicClient(
        responses=[audit_response, plan_response, meta_response]
    )
    budget = BudgetManager(
        BudgetConfig(),
        TokenTracker(db),
        ContentCache(db, ttl_minutes=60),
        client=stub,
    )

    def _fake_budget(_config: Any) -> BudgetManager:
        return budget

    risky_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["config.py"],
        diff='+API_KEY = "sk-abcdefghijklmnopqrstuvwx"\n',
    )

    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_budget,
        _run_tests=MagicMock(return_value="pass"),
    ):
        await runner._handle_event(risky_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    # episode must NOT be skipped — it continued past security check
    assert episodes[0].status == "completed"


async def test_execute_with_retry_retries_on_failure(tmp_path: Path) -> None:
    """_execute_with_retry retries up to retry_max_attempts."""
    config = _make_config(tmp_path)
    plan: dict[str, Any] = {"skip_reason": None, "actions": []}

    call_count = 0

    def _failing_execute(
        self: Any, plan: Any, config: Any, test_output_before: Any = None
    ) -> ExecutionResult:
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise RuntimeError("transient error")
        return ExecutionResult(test_result="pass")

    with patch("sagex.runner.ActionExecutor.execute", _failing_execute):
        with patch("sagex.runner.asyncio.sleep", new=AsyncMock(return_value=None)):
            result = await _execute_with_retry(plan, config, None, config.runner)

    assert call_count == 3
    assert result.test_result == "pass"
