"""Phase 2 acceptance criteria: knowledge store, SQLite migrations, Bayesian confidence."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from conftest import MockEmbedder

from sagex.config import KnowledgeConfig
from sagex.knowledge.rules_db import Episode, PendingApproval, Rule, RulesDB
from sagex.knowledge.store import KnowledgeStore

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


@pytest.fixture
def store(tmp_path: Path) -> KnowledgeStore:
    cfg = KnowledgeConfig(
        db_path=str(tmp_path / "rules.db"),
        vector_path=str(tmp_path / "vectors"),
    )
    return KnowledgeStore(cfg, project_name="test-proj", embedder=MockEmbedder())  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Migration tests
# ---------------------------------------------------------------------------

def test_migrations_create_all_tables(tmp_path: Path) -> None:
    """All 5 migrations run on a fresh DB; all 7 tables exist."""
    db = RulesDB(str(tmp_path / "rules.db"))
    conn = db._conn
    tables = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    expected = {
        "rules", "episodes", "token_usage", "content_cache",
        "pending_approvals", "event_queue", "schema_version",
    }
    assert expected.issubset(tables), f"Missing tables: {expected - tables}"


def test_schema_version_is_5(db: RulesDB) -> None:
    """After fresh init, schema_version reaches 5."""
    assert db._get_schema_version() == 5


def test_migrations_idempotent(tmp_path: Path) -> None:
    """Running RulesDB.__init__ twice does not error or duplicate rows."""
    path = str(tmp_path / "rules.db")
    db1 = RulesDB(path)
    assert db1._get_schema_version() == 5
    db2 = RulesDB(path)  # re-open same file
    assert db2._get_schema_version() == 5


def test_wal_mode(db: RulesDB) -> None:
    """SQLite connection uses WAL journal mode as required."""
    row = db._conn.execute("PRAGMA journal_mode").fetchone()
    assert row[0] == "wal"


# ---------------------------------------------------------------------------
# Rule CRUD + confidence
# ---------------------------------------------------------------------------

async def test_write_and_read_rule(db: RulesDB) -> None:
    """Write a rule; read it back; verify defaults."""
    rule = Rule(trigger_pattern="auth modified", lesson="check middleware", project_name="p")
    rule_id = await db.write_rule(rule)
    fetched = db.get_rule(rule_id)
    assert fetched is not None
    assert fetched.confidence == pytest.approx(0.3)
    assert fetched.status == "unvalidated"
    assert fetched.times_applied == 0
    assert fetched.times_correct == 0
    assert fetched.trigger_pattern == "auth modified"
    assert fetched.lesson == "check middleware"


async def test_confidence_increases_correctly_applied_twice(db: RulesDB) -> None:
    """Applying a rule correctly twice → Bayesian confidence rises; status → active."""
    rule = Rule(trigger_pattern="t", lesson="l", project_name="p")
    rule_id = await db.write_rule(rule)

    # First correct application: alpha=2, beta=1 → 2/3 ≈ 0.667
    await db.update_confidence(rule_id, correct=True)
    r1 = db.get_rule(rule_id)
    assert r1 is not None
    assert r1.confidence == pytest.approx(2 / 3)
    assert r1.status == "unvalidated"  # only 1 correct so far

    # Second correct application: alpha=3, beta=1 → 3/4 = 0.75; now active
    await db.update_confidence(rule_id, correct=True)
    r2 = db.get_rule(rule_id)
    assert r2 is not None
    assert r2.confidence == pytest.approx(3 / 4)
    assert r2.status == "active"


async def test_confidence_decreases_after_incorrect(db: RulesDB) -> None:
    """Confidence decreases when an incorrect application follows a correct one."""
    rule = Rule(trigger_pattern="t", lesson="l", project_name="p")
    rule_id = await db.write_rule(rule)

    # First correct: confidence → 2/3 ≈ 0.667
    await db.update_confidence(rule_id, correct=True)
    r1 = db.get_rule(rule_id)
    assert r1 is not None
    after_correct = r1.confidence

    # Incorrect: applied=2, correct=1 → alpha=2, beta=2 → 2/4 = 0.5
    await db.update_confidence(rule_id, correct=False)
    r2 = db.get_rule(rule_id)
    assert r2 is not None
    assert r2.confidence < after_correct
    assert r2.confidence == pytest.approx(2 / 4)


async def test_archive_low_confidence_rules(db: RulesDB) -> None:
    """Rules with confidence < threshold are archived; count returned."""
    low = Rule(trigger_pattern="t", lesson="l", project_name="p", confidence=0.1)
    high = Rule(trigger_pattern="t2", lesson="l2", project_name="p", confidence=0.9)
    await db.write_rule(low)
    await db.write_rule(high)

    archived = await db.archive_low_confidence_rules("p", threshold=0.2)
    assert archived == 1

    fetched_low = db.get_rule(low.id)
    assert fetched_low is not None
    assert fetched_low.status == "archived"

    fetched_high = db.get_rule(high.id)
    assert fetched_high is not None
    assert fetched_high.status != "archived"


async def test_get_rules_for_project_excludes_archived(db: RulesDB) -> None:
    """get_rules_for_project never returns archived rules."""
    active = Rule(trigger_pattern="t", lesson="l", project_name="p", confidence=0.8)
    archived = Rule(trigger_pattern="t2", lesson="l2", project_name="p",
                    confidence=0.9, status="archived")
    await db.write_rule(active)
    await db.write_rule(archived)

    results = db.get_rules_for_project("p", min_confidence=0.0)
    ids = [r.id for r in results]
    assert active.id in ids
    assert archived.id not in ids


# ---------------------------------------------------------------------------
# Episode CRUD
# ---------------------------------------------------------------------------

async def test_write_and_read_episode(db: RulesDB) -> None:
    ep = Episode(
        project_name="p",
        trigger_event='{"type": "file_modified"}',
        status="completed",
    )
    ep_id = await db.write_episode(ep)
    fetched = db.get_episode(ep_id)
    assert fetched is not None
    assert fetched.project_name == "p"
    assert fetched.status == "completed"
    assert fetched.regression_detected == 0


async def test_get_recent_episodes_order(db: RulesDB) -> None:
    """get_recent_episodes returns episodes in descending created_at order."""
    for i in range(3):
        ep = Episode(project_name="p", trigger_event=f'{{"i":{i}}}')
        await db.write_episode(ep)
    episodes = db.get_recent_episodes("p", limit=3)
    assert len(episodes) == 3
    # Most recent first
    assert episodes[0].created_at >= episodes[1].created_at


# ---------------------------------------------------------------------------
# Pending approvals
# ---------------------------------------------------------------------------

async def test_write_and_resolve_approval(db: RulesDB) -> None:
    ep = Episode(project_name="p", trigger_event="{}")
    ep_id = await db.write_episode(ep)

    approval = PendingApproval(project_name="p", episode_id=ep_id, plan_json="{}")
    appr_id = await db.write_pending_approval(approval)

    pending = db.get_pending_approvals("p")
    assert any(a.id == appr_id for a in pending)

    await db.resolve_approval(appr_id, "approved")
    after = db.get_pending_approvals("p")
    assert not any(a.id == appr_id for a in after)


# ---------------------------------------------------------------------------
# KnowledgeStore — conflict detection
# ---------------------------------------------------------------------------

async def test_detect_conflicts_same_trigger_different_lesson(store: KnowledgeStore) -> None:
    """Rules with the same trigger_pattern but different lessons are flagged."""
    rule1 = Rule(
        trigger_pattern="auth module modified",
        lesson="update session middleware",
        project_name="test-proj",
        confidence=0.6,
    )
    rule2 = Rule(
        trigger_pattern="auth module modified",   # identical trigger
        lesson="check token expiry",              # different lesson
        project_name="test-proj",
        confidence=0.6,
    )
    await store._db.write_rule(rule1)
    await store._db.write_rule(rule2)

    rules = store._db.get_rules_for_project("test-proj", min_confidence=0.0)
    has_conflicts, note = store.detect_conflicts(rules)
    assert has_conflicts, f"Expected conflict, got: {note}"
    assert "vs" in note


async def test_detect_no_conflicts_same_lesson(store: KnowledgeStore) -> None:
    """Rules with same trigger AND same lesson are not flagged as conflicting."""
    rule1 = Rule(
        trigger_pattern="auth modified",
        lesson="check middleware",
        project_name="test-proj",
    )
    rule2 = Rule(
        trigger_pattern="auth modified",
        lesson="check middleware",  # same lesson — no conflict
        project_name="test-proj",
    )
    await store._db.write_rule(rule1)
    await store._db.write_rule(rule2)

    rules = store._db.get_rules_for_project("test-proj", 0.0)
    has_conflicts, _ = store.detect_conflicts(rules)
    assert not has_conflicts


# ---------------------------------------------------------------------------
# KnowledgeStore — episode embedding + semantic search
# ---------------------------------------------------------------------------

async def test_record_episode_and_query(store: KnowledgeStore) -> None:
    """Write + embed an episode; querying with the same text returns it."""
    situation = "auth module changed"
    ep = Episode(
        project_name="test-proj",
        trigger_event=f'{{"situation": "{situation}"}}',
        actions_taken='["updated session.py"]',
    )
    ep_id = await store.record_episode(ep)

    ctx = store.get_relevant_context(situation)
    ids = [item["id"] for item in ctx.similar_episodes]
    assert ep_id in ids, f"Episode {ep_id} not in query results: {ids}"


# ---------------------------------------------------------------------------
# Export / import
# ---------------------------------------------------------------------------

async def test_export_rules_filters_by_confidence_and_count(
    store: KnowledgeStore,
) -> None:
    """export_rules returns only rules above confidence and min_applied thresholds."""
    good = Rule(
        trigger_pattern="when tests fail",
        lesson="run pytest -x",
        project_name="test-proj",
        confidence=0.9,
        times_applied=15,
        times_correct=14,
    )
    low_conf = Rule(
        trigger_pattern="when config changes",
        lesson="restart server",
        project_name="test-proj",
        confidence=0.5,   # below 0.85
        times_applied=20,
    )
    low_applied = Rule(
        trigger_pattern="when deps updated",
        lesson="rebuild venv",
        project_name="test-proj",
        confidence=0.9,
        times_applied=3,  # below min_applied=10
    )
    for r in (good, low_conf, low_applied):
        await store._db.write_rule(r)

    exported = store.export_rules(min_confidence=0.85, min_applied=10)
    patterns = [e["trigger_pattern"] for e in exported]
    assert "when tests fail" in patterns
    assert "when config changes" not in patterns
    assert "when deps updated" not in patterns


async def test_import_rules_into_second_store(
    tmp_path: Path, store: KnowledgeStore
) -> None:
    """Rules exported from one store can be imported into another."""
    rule = Rule(
        trigger_pattern="auth change",
        lesson="update middleware",
        project_name="test-proj",
        confidence=0.9,
        times_applied=12,
        times_correct=11,
    )
    await store._db.write_rule(rule)

    exported = store.export_rules(min_confidence=0.85, min_applied=10)
    assert len(exported) == 1

    cfg2 = KnowledgeConfig(
        db_path=str(tmp_path / "rules2.db"),
        vector_path=str(tmp_path / "vectors2"),
    )
    store2 = KnowledgeStore(cfg2, project_name="test-proj", embedder=MockEmbedder())  # type: ignore[arg-type]
    imported = await store2.import_rules(exported)
    assert imported == 1

    rules = store2._db.get_rules_for_project("test-proj", 0.0)
    assert any(r.trigger_pattern == "auth change" for r in rules)


# ---------------------------------------------------------------------------
# Concurrency
# ---------------------------------------------------------------------------

async def test_concurrent_write_rule_no_locking_errors(db: RulesDB) -> None:
    """3 concurrent write_rule calls complete without 'database is locked' errors."""
    rules = [
        Rule(trigger_pattern=f"trigger {i}", lesson=f"lesson {i}", project_name="p")
        for i in range(3)
    ]
    await asyncio.gather(*[db.write_rule(r) for r in rules])

    stored = db.get_rules_for_project("p", min_confidence=0.0)
    assert len(stored) == 3
