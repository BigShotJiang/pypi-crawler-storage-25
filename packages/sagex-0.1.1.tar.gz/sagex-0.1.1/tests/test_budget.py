"""Phase 3 acceptance criteria: LLM budget, prompt cache, and token tracker."""

from __future__ import annotations

import asyncio
import inspect
from datetime import UTC
from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.config import BudgetConfig
from sagex.knowledge.rules_db import RulesDB
from sagex.llm.budget import AgentOutputError, BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache, build_cached_request
from sagex.llm.token_tracker import MODEL_PRICING, TokenTracker

# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

class _FakeUsage:
    """Fake Anthropic Usage object for tests that want specific token counts."""

    def __init__(
        self,
        input_tokens: int = 10,
        output_tokens: int = 20,
        cache_read: int = 0,
        cache_write: int = 0,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_read_input_tokens = cache_read
        self.cache_creation_input_tokens = cache_write


@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


@pytest.fixture
def tracker(db: RulesDB) -> TokenTracker:
    return TokenTracker(db)


@pytest.fixture
def cache(db: RulesDB) -> ContentCache:
    return ContentCache(db, ttl_minutes=60)


@pytest.fixture
def config() -> BudgetConfig:
    return BudgetConfig(
        hourly_token_limit=50_000,
        daily_token_limit=500_000,
        enable_prompt_caching=True,
    )


@pytest.fixture
def manager(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> BudgetManager:
    stub = StubAnthropicClient(responses=['{"status": "ok"}'])
    return BudgetManager(config, tracker, cache, client=stub)


# ---------------------------------------------------------------------------
# Async type checks
# ---------------------------------------------------------------------------

def test_budget_manager_call_is_async() -> None:
    """BudgetManager.call() must be declared async def."""
    assert asyncio.iscoroutinefunction(BudgetManager.call)


def test_token_tracker_record_is_async() -> None:
    """TokenTracker.record() must be declared async def."""
    assert asyncio.iscoroutinefunction(TokenTracker.record)


# ---------------------------------------------------------------------------
# Basic call
# ---------------------------------------------------------------------------

async def test_call_returns_stub_text(manager: BudgetManager) -> None:
    """call() returns the text emitted by the stub client."""
    text = await manager.call(
        project="proj",
        agent_type="task",
        system="You are helpful.",
        user="Hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )
    assert text == '{"status": "ok"}'


# ---------------------------------------------------------------------------
# Content-hash cache
# ---------------------------------------------------------------------------

async def test_call_returns_cached_on_second_call(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """Second identical call returns cached result without hitting the API."""
    stub = StubAnthropicClient(responses=["first response", "second response"])
    mgr = BudgetManager(config, tracker, cache, client=stub)

    r1 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )
    r2 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )

    assert r1 == "first response"
    assert r2 == "first response"   # cached — not "second response"
    assert stub.call_count == 1     # API called only once


async def test_cache_respects_ttl(
    config: BudgetConfig,
    tracker: TokenTracker,
    db: RulesDB,
) -> None:
    """Expired cache entries (ttl_minutes=0) are not returned."""
    expired_cache = ContentCache(db, ttl_minutes=0)
    stub = StubAnthropicClient(responses=["response A", "response B"])
    mgr = BudgetManager(config, tracker, expired_cache, client=stub)

    await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )
    # With ttl=0, entry is immediately expired — second call must hit API again
    r2 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )
    assert stub.call_count == 2
    assert r2 == "response B"


# ---------------------------------------------------------------------------
# Budget enforcement
# ---------------------------------------------------------------------------

async def test_budget_exceeded_hourly(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """BudgetExceededError is raised when the hourly token limit is breached."""
    # Fill hourly bucket past the 50 000 limit
    big_usage = _FakeUsage(input_tokens=40_000, output_tokens=15_000)
    await tracker.record("proj", "task", "claude-sonnet-4-5", big_usage)

    stub = StubAnthropicClient()
    mgr = BudgetManager(config, tracker, cache, client=stub)

    with pytest.raises(BudgetExceededError, match="Hourly"):
        await mgr.call(
            project="proj",
            agent_type="task",
            system="sys",
            user="user",
            model="claude-sonnet-4-5",
            max_tokens=100,
        )


# ---------------------------------------------------------------------------
# Token cost computation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "model,input_t,output_t,expected_usd",
    [
        (
            "claude-haiku-4-5",
            1_000_000,
            0,
            MODEL_PRICING["claude-haiku-4-5"]["input"] * 1_000_000,
        ),
        (
            "claude-sonnet-4-5",
            0,
            1_000_000,
            MODEL_PRICING["claude-sonnet-4-5"]["output"] * 1_000_000,
        ),
        (
            "claude-opus-4-5",
            500_000,
            500_000,
            (
                MODEL_PRICING["claude-opus-4-5"]["input"] * 500_000
                + MODEL_PRICING["claude-opus-4-5"]["output"] * 500_000
            ),
        ),
    ],
)
def test_token_cost_computed_correctly(
    model: str,
    input_t: int,
    output_t: int,
    expected_usd: float,
) -> None:
    """compute_cost is correct for all three models."""
    actual = TokenTracker.compute_cost(model, input_t, output_t)
    assert actual == pytest.approx(expected_usd, rel=1e-6)


def test_cost_includes_cache_tokens() -> None:
    """Cache read/write tokens are factored into the cost."""
    cost_plain = TokenTracker.compute_cost("claude-sonnet-4-5", 1000, 0)
    cost_with_cache = TokenTracker.compute_cost(
        "claude-sonnet-4-5", 1000, 0, cache_read_tokens=1000
    )
    # Cache read is cheaper than input; cost_with_cache > cost_plain
    assert cost_with_cache > cost_plain


# ---------------------------------------------------------------------------
# call_json and AgentOutputError
# ---------------------------------------------------------------------------

async def test_call_json_parses_valid_json(manager: BudgetManager) -> None:
    """call_json() returns a dict on valid JSON response."""
    result = await manager.call_json(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-5",
        max_tokens=100,
    )
    assert isinstance(result, dict)
    assert result["status"] == "ok"


async def test_call_json_raises_agent_output_error_on_double_malformed(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """call_json() raises AgentOutputError when both attempts return bad JSON."""
    stub = StubAnthropicClient(responses=["not json at all", "still not json"])
    mgr = BudgetManager(config, tracker, cache, client=stub)

    with pytest.raises(AgentOutputError):
        await mgr.call_json(
            project="proj",
            agent_type="task",
            system="sys",
            user="give me json",
            model="claude-sonnet-4-5",
            max_tokens=100,
        )
    # Both calls reached the API
    assert stub.call_count == 2


# ---------------------------------------------------------------------------
# _call_with_retry: asyncio.sleep only
# ---------------------------------------------------------------------------

def test_call_with_retry_uses_asyncio_sleep_not_time_sleep() -> None:
    """_call_with_retry must use asyncio.sleep; time module must not be imported."""

    # asyncio.sleep must be present in the retry method itself
    retry_source = inspect.getsource(BudgetManager._call_with_retry)
    assert "asyncio.sleep" in retry_source

    # The module must not import the time module (which would enable time.sleep)
    import ast
    import importlib.util

    spec = importlib.util.find_spec("sagex.llm.budget")
    assert spec is not None and spec.origin is not None
    tree = ast.parse(open(spec.origin).read())
    imported_names = [
        node.names[0].name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
    ]
    assert "time" not in imported_names


# ---------------------------------------------------------------------------
# build_cached_request — cache_control threshold guard
# ---------------------------------------------------------------------------

def test_build_cached_request_no_cache_control_for_short_prompt() -> None:
    """Short system prompt (< 1024 estimated tokens) must NOT get cache_control."""
    short_system = "You are a helpful assistant."  # well under 1024 tokens
    result = build_cached_request(
        system_prompt=short_system,
        user_prompt="hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    # When short, system is returned as a plain string — no cache_control key
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )


def test_build_cached_request_has_cache_control_for_long_prompt() -> None:
    """Long system prompt (>= 1024 estimated tokens) must include cache_control."""
    # 1024 tokens ≈ 4096 characters
    long_system = "X" * 4096
    result = build_cached_request(
        system_prompt=long_system,
        user_prompt="hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    assert isinstance(system, list)
    assert any("cache_control" in block for block in system)


def test_build_cached_request_no_cache_control_when_disabled() -> None:
    """cache_control is never applied when enable_prompt_caching=False."""
    long_system = "X" * 4096
    result = build_cached_request(
        system_prompt=long_system,
        user_prompt="hello",
        model="claude-sonnet-4-5",
        max_tokens=100,
        enable_prompt_caching=False,
    )
    system = result["system"]
    # With caching disabled, system is a plain string even for long prompts
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )


def test_build_cached_request_haiku_threshold_is_2048_tokens() -> None:
    """Haiku requires 2048 tokens (8192 chars); just below threshold → no cache_control."""
    # 2047 tokens ≈ 8188 chars — just below Haiku's 2048-token threshold
    just_under = "Y" * 8188
    result = build_cached_request(
        system_prompt=just_under,
        user_prompt="hello",
        model="claude-haiku-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )

    # 2048 tokens ≈ 8192 chars — at the threshold → cache_control applied
    at_threshold = "Y" * 8192
    result2 = build_cached_request(
        system_prompt=at_threshold,
        user_prompt="hello",
        model="claude-haiku-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system2 = result2["system"]
    assert isinstance(system2, list)
    assert any("cache_control" in block for block in system2)


# ---------------------------------------------------------------------------
# TokenTracker.record round-trip
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Gap #4: budget alert fires at threshold
# ---------------------------------------------------------------------------


async def test_budget_alert_logged_when_approaching_daily_limit(
    db: RulesDB,
) -> None:
    """A warning is logged when daily usage reaches alert_threshold (80%)."""
    import logging

    tight_config = BudgetConfig(
        hourly_token_limit=1_000_000,
        daily_token_limit=10_000,
        alert_threshold=0.8,
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)

    # Record 8 100 tokens — 81 % of the 10 000 daily limit
    class _BigUsage:
        input_tokens = 8_100
        output_tokens = 0
        cache_read_input_tokens = 0
        cache_creation_input_tokens = 0

    await tracker.record("proj", "task", "claude-sonnet-4-5", _BigUsage())

    stub = StubAnthropicClient(responses=['{"ok":1}'])
    mgr = BudgetManager(tight_config, tracker, cache, client=stub)

    log_records: list[logging.LogRecord] = []

    class _Cap(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.llm.budget as budget_mod

    logger = logging.getLogger(budget_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    cap = _Cap()
    logger.addHandler(cap)
    try:
        # check_budget reads usage; should emit budget_alert warning
        mgr.check_budget("proj")
    finally:
        logger.removeHandler(cap)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert any("budget_alert" in m for m in msgs), f"expected budget_alert, got: {msgs}"


async def test_tracker_record_persists_to_db(db: RulesDB, tracker: TokenTracker) -> None:
    """record() stores the usage record; get_summary reflects it."""
    from datetime import datetime, timedelta

    usage = _FakeUsage(input_tokens=100, output_tokens=50)
    rec = await tracker.record("proj", "task", "claude-sonnet-4-5", usage)

    assert rec.input_tokens == 100
    assert rec.output_tokens == 50
    assert rec.cost_usd == pytest.approx(
        TokenTracker.compute_cost("claude-sonnet-4-5", 100, 50)
    )

    since = (datetime.now(UTC) - timedelta(minutes=5)).isoformat()
    summary = tracker.get_summary("proj", since)
    assert summary["total_calls"] == 1
    assert summary["input_tokens"] == 100
    assert summary["output_tokens"] == 50
