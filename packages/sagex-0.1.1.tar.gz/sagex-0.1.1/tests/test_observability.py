"""Phase 10 acceptance criteria: structured logging, CLI commands, dry-run."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from click.testing import CliRunner
from conftest import StubAnthropicClient
from httpx import ASGITransport, AsyncClient

from sagex.api.server import ProjectRegistry, create_app
from sagex.cli import main
from sagex.config import (
    AgentConfig,
    AgentsConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    SecurityAgentConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventBus, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker
from sagex.logging import JSONFormatter
from sagex.runner import Runner
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_db(tmp_path: Path) -> RulesDB:
    db = RulesDB(str(tmp_path / "rules.db"))
    db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    return db


def _make_config(tmp_path: Path) -> ProjectConfig:
    return ProjectConfig(
        name="obs-proj",
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        budget=BudgetConfig(),
        agents=AgentsConfig(security=SecurityAgentConfig(enabled=False)),
    )


def _make_budget(db: RulesDB) -> BudgetManager:
    stub = StubAnthropicClient(
        responses=[
            '{"summary":"ok","severity":"low","actions":[],'
            '"checks_required":[],"rules_applied":[],"confidence":0.8,"skip_reason":null}',
            '{"outcome":"good","outcome_reason":"pass","lesson":null,"rule":null,"rule_updates":[]}',
        ]
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _event(extra: dict[str, Any] | None = None) -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="obs-proj",
        repo_root="/repo",
        file_paths=["auth.py"],
        diff="+x = 1\n",
        extra=extra or {},
    )


def _patch_runner(db: RulesDB) -> Any:
    budget = _make_budget(db)

    def _fake_make_budget(_config: Any) -> BudgetManager:
        return budget

    return patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=MagicMock(return_value="pass"),
    )


# ---------------------------------------------------------------------------
# Task 10.1 — JSONFormatter
# ---------------------------------------------------------------------------


def test_json_formatter_produces_valid_json() -> None:
    """JSONFormatter.format() returns a parseable JSON string."""
    formatter = JSONFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="runner.py",
        lineno=1,
        msg="event_received",
        args=(),
        exc_info=None,
    )
    output = formatter.format(record)
    parsed = json.loads(output)
    assert parsed["level"] == "INFO"
    assert parsed["msg"] == "event_received"
    assert "ts" in parsed
    assert "module" in parsed


def test_json_formatter_extra_dict_spread_into_output() -> None:
    """extra={'extra': {...}} spreads into top-level JSON keys."""
    formatter = JSONFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="runner.py",
        lineno=1,
        msg="triage_result",
        args=(),
        exc_info=None,
    )
    record.extra = {"project": "my-proj", "severity": "low", "used_llm": False}  # type: ignore[attr-defined]
    output = formatter.format(record)
    parsed = json.loads(output)
    assert parsed["project"] == "my-proj"
    assert parsed["severity"] == "low"
    assert parsed["used_llm"] is False


def test_json_formatter_no_extra_does_not_crash() -> None:
    """Records without an extra attribute produce valid JSON."""
    formatter = JSONFormatter()
    record = logging.LogRecord(
        name="test",
        level=logging.WARNING,
        pathname="runner.py",
        lineno=42,
        msg="budget_exceeded",
        args=(),
        exc_info=None,
    )
    output = formatter.format(record)
    parsed = json.loads(output)
    assert parsed["level"] == "WARNING"


# ---------------------------------------------------------------------------
# Task 10.1 — structured log calls from runner
# ---------------------------------------------------------------------------


async def test_runner_emits_event_received_log(tmp_path: Path) -> None:
    """runner._handle_event emits an 'event_received' log."""
    config = _make_config(tmp_path)
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)

    log_records: list[logging.LogRecord] = []

    class _CapHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.runner as runner_mod

    logger = logging.getLogger(runner_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    handler = _CapHandler()
    logger.addHandler(handler)
    try:
        with _patch_runner(db):
            await runner._handle_event(_event())
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert "event_received" in msgs


async def test_runner_emits_triage_and_plan_logs(tmp_path: Path) -> None:
    """Pipeline emits triage_result, knowledge_loaded, and plan_produced logs."""
    config = _make_config(tmp_path)
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)

    log_records: list[logging.LogRecord] = []

    class _CapHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.runner as runner_mod

    logger = logging.getLogger(runner_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    handler = _CapHandler()
    logger.addHandler(handler)
    try:
        with _patch_runner(db):
            await runner._handle_event(_event())
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert "triage_result" in msgs
    assert "knowledge_loaded" in msgs
    assert "plan_produced" in msgs
    assert "execution_complete" in msgs
    assert "meta_outcome" in msgs


# ---------------------------------------------------------------------------
# Task 10.4 — Dry-run mode
# ---------------------------------------------------------------------------


async def test_dry_run_episode_written_as_skipped(tmp_path: Path) -> None:
    """event.extra['dry_run']=True → episode written with status='skipped'."""
    config = _make_config(tmp_path)
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)

    with _patch_runner(db):
        await runner._handle_event(_event(extra={"dry_run": True}))

    episodes = db.get_recent_episodes("obs-proj", limit=10)
    assert len(episodes) >= 1
    ep = episodes[0]
    assert ep.status == "skipped"
    assert ep.error_message == "dry_run"


async def test_dry_run_does_not_call_action_executor(tmp_path: Path) -> None:
    """Dry-run: ActionExecutor.execute is never called."""
    config = _make_config(tmp_path)
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)

    with _patch_runner(db):
        with patch("sagex.runner.ActionExecutor.execute") as mock_exec:
            await runner._handle_event(_event(extra={"dry_run": True}))
            mock_exec.assert_not_called()


# ---------------------------------------------------------------------------
# Task 10.3 — Rich usage endpoint
# ---------------------------------------------------------------------------


async def test_usage_endpoint_returns_rich_fields(tmp_path: Path) -> None:
    """GET /projects/{name}/usage returns all Phase 10 fields."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_config(tmp_path)
    registry.register(config)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/projects/obs-proj/usage?period=24h")
        assert resp.status_code == 200
        data = resp.json()

    required_fields = [
        "total_events",
        "skipped_by_triage",
        "skip_pct",
        "cache_hits",
        "api_calls",
        "input_tokens_fresh",
        "input_tokens_cached",
        "output_tokens",
        "cache_savings_usd",
        "estimated_cost_usd",
        "by_agent",
    ]
    for field in required_fields:
        assert field in data, f"Missing field: {field}"


async def test_usage_endpoint_by_agent_breakdown(tmp_path: Path) -> None:
    """by_agent accumulates calls and token counts per agent_type."""
    db = RulesDB(str(tmp_path / "global.db"))
    proj_db = RulesDB(str(tmp_path / "rules.db"))
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )

    from sagex.llm.token_tracker import TokenUsageRecord

    # Insert two records with different agent_types
    rec1 = TokenUsageRecord(
        id="r1", ts="2099-01-01T00:00:00", project="obs-proj",
        agent_type="triage", model="claude-haiku-4-5",
        input_tokens=100, output_tokens=50,
        cache_read_tokens=0, cache_write_tokens=0,
        cost_usd=0.001, call_hash=None, was_cached=False,
    )
    rec2 = TokenUsageRecord(
        id="r2", ts="2099-01-01T00:01:00", project="obs-proj",
        agent_type="task", model="claude-sonnet-4-5",
        input_tokens=200, output_tokens=100,
        cache_read_tokens=0, cache_write_tokens=0,
        cost_usd=0.002, call_hash=None, was_cached=False,
    )
    await proj_db.write_token_usage(rec1)
    await proj_db.write_token_usage(rec2)

    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_config(tmp_path)
    registry.register(config)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/projects/obs-proj/usage?period=1h")
        assert resp.status_code == 200
        data = resp.json()

    assert "triage" in data["by_agent"]
    assert "task" in data["by_agent"]
    assert data["by_agent"]["triage"]["calls"] == 1
    assert data["by_agent"]["task"]["tokens"] == 300


# ---------------------------------------------------------------------------
# Task 10.2 — status CLI command
# ---------------------------------------------------------------------------


def test_status_cli_prints_summary() -> None:
    """agentis status prints project name, rules, tokens, and episodes."""
    episodes_resp = {
        "episodes": [
            {
                "id": "ep_1",
                "status": "completed",
                "severity": "low",
                "test_result_after": "pass",
                "regression_detected": 0,
                "lesson_extracted": None,
                "created_at": "2099-01-01T00:00:00",
            }
        ]
    }
    rules_resp = {
        "rules": [
            {"id": "r1", "status": "active", "trigger_pattern": "x", "lesson": "y",
             "confidence": 0.9, "tags": []},
        ]
    }
    usage_resp = {
        "input_tokens_fresh": 1000,
        "output_tokens": 500,
        "estimated_cost_usd": 0.0042,
    }

    runner = CliRunner()
    with patch("httpx.get") as mock_get:
        def _side_effect(url: str, **kwargs: Any) -> MagicMock:
            resp = MagicMock()
            if "episodes" in url:
                resp.json.return_value = episodes_resp
            elif "rules" in url:
                resp.json.return_value = rules_resp
            else:
                resp.json.return_value = usage_resp
            return resp

        mock_get.side_effect = _side_effect
        result = runner.invoke(main, ["status", "my-project"])

    assert result.exit_code == 0
    assert "my-project" in result.output
    assert "Rules:" in result.output
    assert "Tokens today:" in result.output
    assert "Recent episodes:" in result.output


# ---------------------------------------------------------------------------
# Task 10.3 — usage CLI command
# ---------------------------------------------------------------------------


def test_usage_cli_prints_breakdown() -> None:
    """agentis usage prints per-agent breakdown."""
    usage_resp = {
        "total_events": 10,
        "skipped_by_triage": 3,
        "skip_pct": 30.0,
        "cache_hits": 2,
        "api_calls": 8,
        "input_tokens_fresh": 5000,
        "input_tokens_cached": 1000,
        "output_tokens": 2500,
        "cache_savings_usd": 0.0009,
        "estimated_cost_usd": 0.025,
        "by_agent": {
            "triage": {"calls": 4, "tokens": 2000},
            "task": {"calls": 4, "tokens": 5500},
        },
    }

    runner = CliRunner()
    with patch("httpx.get") as mock_get:
        resp = MagicMock()
        resp.json.return_value = usage_resp
        mock_get.return_value = resp
        result = runner.invoke(main, ["usage", "my-project", "--last", "7d"])

    assert result.exit_code == 0
    assert "my-project" in result.output
    assert "Total events:" in result.output
    assert "By agent type:" in result.output
    assert "triage" in result.output
    assert "task" in result.output


# ---------------------------------------------------------------------------
# Task 10.4 — trigger CLI command
# ---------------------------------------------------------------------------


def test_trigger_cli_posts_event() -> None:
    """agentis trigger posts to /notify."""
    runner = CliRunner()
    with patch("httpx.post") as mock_post:
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        mock_post.return_value = resp
        result = runner.invoke(main, ["trigger", "my-project"])

    assert result.exit_code == 0
    assert "triggered" in result.output
    call_kwargs = mock_post.call_args
    assert call_kwargs is not None
    body = call_kwargs[1]["json"] if "json" in call_kwargs[1] else call_kwargs[0][1]
    assert body["project_name"] == "my-project"
    assert body["extra"]["dry_run"] is False


# ---------------------------------------------------------------------------
# Gap #1 — notify CLI subcommand (called by git hooks)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Gap #5 — configure_logging() called in serve()
# ---------------------------------------------------------------------------


def test_serve_calls_configure_logging() -> None:
    """agentis serve must call configure_logging() before starting uvicorn."""
    runner = CliRunner()
    with patch("sagex.logging.configure_logging") as mock_cfg_log, patch(
        "asyncio.run"
    ) as mock_run:
        mock_run.return_value = None
        runner.invoke(main, ["serve", "--port", "19999"])

    mock_cfg_log.assert_called_once()


def test_notify_cli_posts_to_runtime(tmp_path: Path) -> None:
    """agentis notify --event=commit --repo=... posts to /notify."""
    # Write a minimal config.yaml so notify can resolve the project name
    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    (agents_dir / "config.yaml").write_text(
        f"name: hook-proj\nrepo_root: {tmp_path}\n"
        "watch:\n  paths: [.]\ntest:\n  command: echo pass\n"
    )

    runner = CliRunner()
    with patch("httpx.post") as mock_post:
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        mock_post.return_value = resp
        result = runner.invoke(
            main,
            ["notify", "--event", "commit", "--repo", str(tmp_path)],
        )

    assert result.exit_code == 0, result.output
    assert "hook-proj" in result.output
    call_kwargs = mock_post.call_args
    body = call_kwargs[1]["json"]
    assert body["project_name"] == "hook-proj"
    assert body["event_type"] == "commit"
    assert body["repo_root"] == str(tmp_path)


def test_notify_cli_falls_back_to_dirname_when_no_config(tmp_path: Path) -> None:
    """When .agents/config.yaml is absent, project_name defaults to repo dirname."""
    runner = CliRunner()
    with patch("httpx.post") as mock_post:
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        mock_post.return_value = resp
        result = runner.invoke(
            main,
            ["notify", "--event", "push", "--repo", str(tmp_path)],
        )

    assert result.exit_code == 0, result.output
    call_kwargs = mock_post.call_args
    body = call_kwargs[1]["json"]
    assert body["project_name"] == tmp_path.name
    assert body["event_type"] == "push"


def test_trigger_cli_dry_run_flag() -> None:
    """agentis trigger --dry-run passes dry_run=True in extra."""
    runner = CliRunner()
    with patch("httpx.post") as mock_post:
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        mock_post.return_value = resp
        result = runner.invoke(main, ["trigger", "my-project", "--dry-run"])

    assert result.exit_code == 0
    assert "Dry run" in result.output
    call_kwargs = mock_post.call_args
    body = call_kwargs[1]["json"]
    assert body["extra"]["dry_run"] is True
