"""Phase 4 acceptance criteria: watcher, event bus, and dead-letter queue."""

from __future__ import annotations

import asyncio
import subprocess
from pathlib import Path

import pytest

from sagex.config import (
    AgentConfig,
    BudgetConfig,
    KnowledgeConfig,
    NotificationsConfig,
    ProjectConfig,
    RunnerConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventBus, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.watcher import (
    ProjectWatcher,
    _should_ignore,
    get_diff_with_context,
    get_git_diff,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


@pytest.fixture
def bus(db: RulesDB) -> EventBus:
    return EventBus(db, max_size=10)


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """A minimal git repo with one committed file."""
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init", "-b", "main"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"], cwd=repo, check=True, capture_output=True
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"], cwd=repo, check=True, capture_output=True
    )
    seed = repo / "seed.py"
    seed.write_text("x = 1\n")
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "init"], cwd=repo, check=True, capture_output=True
    )
    return repo


def _make_config(repo: Path, watch_paths: list[str] | None = None) -> ProjectConfig:
    return ProjectConfig(
        name="test-proj",
        repo_root=str(repo),
        watch=WatchConfig(
            paths=watch_paths or [str(repo)],
            debounce_seconds=0.1,
        ),
        test=TestConfig(command="pytest"),
        agent=AgentConfig(),
        knowledge=KnowledgeConfig(),
        budget=BudgetConfig(),
        runner=RunnerConfig(),
        notifications=NotificationsConfig(),
    )


# ---------------------------------------------------------------------------
# AgentEvent round-trip
# ---------------------------------------------------------------------------

def test_agent_event_type_coercion() -> None:
    """AgentEvent coerces string 'type' back to EventType on construction."""
    evt = AgentEvent(
        type="file_modified",  # type: ignore[arg-type]
        project_name="p",
        repo_root="/tmp",
    )
    assert evt.type == EventType.FILE_MODIFIED
    assert isinstance(evt.type, EventType)


def test_agent_event_timestamp_coercion() -> None:
    """AgentEvent coerces ISO string 'timestamp' back to datetime."""
    from datetime import UTC, datetime

    ts_str = "2024-01-01T00:00:00+00:00"
    evt = AgentEvent(
        type=EventType.MANUAL,
        project_name="p",
        repo_root="/tmp",
        timestamp=ts_str,  # type: ignore[arg-type]
    )
    assert isinstance(evt.timestamp, datetime)
    assert evt.timestamp == datetime(2024, 1, 1, tzinfo=UTC)


# ---------------------------------------------------------------------------
# EventBus — publish / subscribe
# ---------------------------------------------------------------------------

async def test_publish_and_subscribe(bus: EventBus) -> None:
    """Published event is received by subscribe()."""
    evt = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="p",
        repo_root="/tmp",
        file_paths=["foo.py"],
    )
    published = await bus.publish(evt)
    assert published is True

    received = await asyncio.wait_for(bus.subscribe(), timeout=1.0)
    assert received.id == evt.id
    assert received.file_paths == ["foo.py"]


async def test_publish_drops_when_full(db: RulesDB) -> None:
    """EventBus drops events gracefully (returns False, no exception) when full."""
    tiny_bus = EventBus(db, max_size=2)
    evt = AgentEvent(type=EventType.MANUAL, project_name="p", repo_root="/tmp")

    # Fill the queue
    assert await tiny_bus.publish(evt) is True
    assert await tiny_bus.publish(evt) is True

    # Next publish must drop, not raise
    dropped = await tiny_bus.publish(evt)
    assert dropped is False


# ---------------------------------------------------------------------------
# EventBus — SQLite persistence and reload
# ---------------------------------------------------------------------------

async def test_events_persisted_to_sqlite(bus: EventBus, db: RulesDB) -> None:
    """Published events appear in the event_queue table."""
    evt = AgentEvent(type=EventType.MANUAL, project_name="p", repo_root="/tmp")
    await bus.publish(evt)

    rows = db._conn.execute(
        "SELECT id, status FROM event_queue WHERE id = ?", (evt.id,)
    ).fetchall()
    assert len(rows) == 1
    assert rows[0][1] == "queued"


async def test_subscribe_marks_event_processing(bus: EventBus, db: RulesDB) -> None:
    """subscribe() sets the event status to 'processing' in SQLite."""
    evt = AgentEvent(type=EventType.MANUAL, project_name="p", repo_root="/tmp")
    await bus.publish(evt)
    await bus.subscribe()

    row = db._conn.execute(
        "SELECT status FROM event_queue WHERE id = ?", (evt.id,)
    ).fetchone()
    assert row[0] == "processing"


async def test_reload_persisted_events(db: RulesDB) -> None:
    """reload_persisted_events re-enqueues unprocessed events from a previous run."""
    # Simulate a prior session: write events directly to DB
    bus1 = EventBus(db, max_size=10)
    evt1 = AgentEvent(type=EventType.MANUAL, project_name="p", repo_root="/tmp")
    evt2 = AgentEvent(type=EventType.FILE_MODIFIED, project_name="p", repo_root="/tmp")
    await bus1.publish(evt1)
    await bus1.publish(evt2)

    # New EventBus instance (simulating restart) — queue starts empty
    bus2 = EventBus(db, max_size=10)
    assert bus2._queue.empty()

    count = bus2.reload_persisted_events()
    assert count == 2
    assert not bus2._queue.empty()


# ---------------------------------------------------------------------------
# git helpers
# ---------------------------------------------------------------------------

def test_get_git_diff_returns_diff_after_modification(git_repo: Path) -> None:
    """get_git_diff returns non-empty diff after a tracked file is modified."""
    target = git_repo / "seed.py"
    target.write_text("x = 2\n")  # modify the committed file

    diff = get_git_diff(str(git_repo), [str(target)])
    assert diff is not None
    assert "x = 2" in diff or "-x = 1" in diff


def test_get_git_diff_returns_none_on_invalid_repo(tmp_path: Path) -> None:
    """get_git_diff returns None when the path is not a git repo."""
    result = get_git_diff(str(tmp_path), ["nonexistent.py"])
    assert result is None


def test_get_diff_with_context_truncates_at_max_chars(git_repo: Path) -> None:
    """get_diff_with_context truncates output exceeding max_chars with a marker."""
    target = git_repo / "seed.py"
    # Write enough content to exceed a tiny max_chars budget
    target.write_text("x = 2\n" + "# comment\n" * 100)

    result = get_diff_with_context(str(git_repo), [str(target)], max_chars=50)
    assert result is not None
    assert "truncated" in result
    assert len(result.split("truncated")[0]) <= 60  # head portion is capped


def test_get_diff_with_context_no_truncation_within_limit(git_repo: Path) -> None:
    """Small diffs are returned in full without a truncation marker."""
    target = git_repo / "seed.py"
    target.write_text("x = 2\n")

    result = get_diff_with_context(str(git_repo), [str(target)], max_chars=8000)
    assert result is not None
    assert "truncated" not in result


# ---------------------------------------------------------------------------
# ignore-list check
# ---------------------------------------------------------------------------

def test_should_ignore_matches_glob_pattern() -> None:
    """Paths matching ignore globs are suppressed."""
    assert _should_ignore("/path/to/__pycache__/foo.pyc", ["**/__pycache__/**"])
    assert _should_ignore("/path/to/output.log", ["*.log"])


def test_should_ignore_dotenv_not_ignored_by_default() -> None:
    """.env files are NOT in the default ignore list — they must fire events."""
    from sagex.config import WatchConfig

    default_ignore = WatchConfig(paths=["."]).ignore
    # .env should not be ignored
    assert not _should_ignore("/project/.env", default_ignore)
    assert not _should_ignore("/project/.env.local", default_ignore)


# ---------------------------------------------------------------------------
# Full watcher integration: file modification → event on bus
# ---------------------------------------------------------------------------

async def test_file_modification_fires_event(git_repo: Path, db: RulesDB) -> None:
    """Modifying a watched file produces an AgentEvent on the bus within debounce + 0.5s."""
    local_bus = EventBus(db, max_size=10)
    local_bus.attach_loop(asyncio.get_running_loop())
    config = _make_config(git_repo)
    watcher = ProjectWatcher(config, local_bus)
    watcher.start()
    try:
        # Modify a file in the watched repo
        target = git_repo / "seed.py"
        target.write_text("x = 99\n")

        # Wait for debounce (0.1s) + margin
        event = await asyncio.wait_for(local_bus.subscribe(), timeout=2.0)
        assert event.type == EventType.FILE_MODIFIED
        assert event.project_name == "test-proj"
        assert any("seed.py" in p for p in event.file_paths)
    finally:
        watcher.stop()


async def test_ignored_paths_do_not_fire_events(git_repo: Path, db: RulesDB) -> None:
    """Files matching the ignore list do not produce bus events."""
    local_bus = EventBus(db, max_size=10)
    local_bus.attach_loop(asyncio.get_running_loop())
    config = _make_config(git_repo)
    watcher = ProjectWatcher(config, local_bus)
    watcher.start()
    try:
        # Create a .log file — matched by "*.log" in default ignore
        log_file = git_repo / "output.log"
        log_file.write_text("some log output\n")

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(local_bus.subscribe(), timeout=0.5)
    finally:
        watcher.stop()


async def test_dotenv_modification_fires_event(git_repo: Path, db: RulesDB) -> None:
    """.env file modification fires an event (not in default ignore list)."""
    local_bus = EventBus(db, max_size=10)
    local_bus.attach_loop(asyncio.get_running_loop())
    config = _make_config(git_repo)
    watcher = ProjectWatcher(config, local_bus)
    watcher.start()
    try:
        env_file = git_repo / ".env"
        env_file.write_text("SECRET=hunter2\n")

        event = await asyncio.wait_for(local_bus.subscribe(), timeout=2.0)
        assert event.type == EventType.FILE_MODIFIED
        assert any(".env" in p for p in event.file_paths)
    finally:
        watcher.stop()
