"""Phase 8 acceptance criteria: Registration API."""

from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path

import pytest
import yaml
from httpx import ASGITransport, AsyncClient

from sagex.api.server import ProjectRegistry, create_app
from sagex.config import (
    AgentConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import EventBus
from sagex.knowledge.rules_db import PendingApproval, RulesDB
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_project_config(name: str, tmp_path: Path) -> ProjectConfig:
    return ProjectConfig(
        name=name,
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / f"{name}_rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        budget=BudgetConfig(),
    )


@pytest.fixture
async def client(tmp_path: Path) -> AsyncIterator[AsyncClient]:
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac


@pytest.fixture
async def client_with_project(
    tmp_path: Path,
) -> AsyncIterator[tuple[AsyncClient, ProjectConfig]]:
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("test-proj", tmp_path)
    registry.register(config)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac, config


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


async def test_health_returns_200(client: AsyncClient) -> None:
    resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "version" in data


# ---------------------------------------------------------------------------
# Project registration
# ---------------------------------------------------------------------------


async def test_register_project_appears_in_list(tmp_path: Path) -> None:
    """Register a project → it appears in GET /projects."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    # config_path must be .agents/config.yaml (security requirement)
    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    config_path.write_text(
        yaml.dump(
            {
                "name": "my-proj",
                "repo_root": str(tmp_path),
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post("/projects/register", json={"config_path": str(config_path)})
        assert resp.status_code == 201
        assert resp.json()["name"] == "my-proj"

        resp = await ac.get("/projects")
        assert "my-proj" in resp.json()["projects"]


async def test_register_rejects_arbitrary_config_path(tmp_path: Path) -> None:
    """register endpoint must reject config paths outside .agents/config.yaml."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Attempt to read an arbitrary file (simulates path-traversal attack)
        resp = await ac.post("/projects/register", json={"config_path": "/etc/passwd"})
        assert resp.status_code == 400

        # Also reject a valid-looking path that lacks .agents directory
        bad_path = tmp_path / "config.yaml"
        bad_path.write_text("name: evil\n")
        resp = await ac.post("/projects/register", json={"config_path": str(bad_path)})
        assert resp.status_code == 400


async def test_deregister_project_removes_it(client: AsyncClient) -> None:
    """Register then deregister → project is gone."""
    # inject directly via registry
    registry = client._transport.app.state.registry  # type: ignore[attr-defined]
    config = ProjectConfig(
        name="gone-proj",
        repo_root="/tmp",
        watch=WatchConfig(paths=["/tmp"]),
        test=TestConfig(command="echo pass"),
    )
    registry.register(config)

    resp = await client.get("/projects")
    assert "gone-proj" in resp.json()["projects"]

    resp = await client.delete("/projects/gone-proj")
    assert resp.status_code == 200

    resp = await client.get("/projects")
    assert "gone-proj" not in resp.json()["projects"]


async def test_deregister_unknown_project_returns_404(client: AsyncClient) -> None:
    resp = await client.delete("/projects/does-not-exist")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Notify → event on bus
# ---------------------------------------------------------------------------


async def test_notify_queues_event(tmp_path: Path) -> None:
    """POST /notify → event on the event bus."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/notify",
            json={
                "project_name": "my-proj",
                "event_type": "file_modified",
                "repo_root": "/repo",
                "file_paths": ["main.py"],
            },
        )
        assert resp.status_code == 202
        data = resp.json()
        assert data["status"] == "queued"
        assert "event_id" in data

    # Event should be on the bus
    assert bus._queue.qsize() == 1


# ---------------------------------------------------------------------------
# Queue status
# ---------------------------------------------------------------------------


async def test_queue_status_returns_depth(client: AsyncClient) -> None:
    resp = await client.get("/queue/status")
    assert resp.status_code == 200
    assert resp.json()["depth"] == 0


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------


async def test_list_rules_empty(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/rules")
    assert resp.status_code == 200
    assert resp.json()["rules"] == []


async def test_list_rules_unknown_project_returns_404(client: AsyncClient) -> None:
    resp = await client.get("/projects/no-such-project/rules")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------


async def test_usage_summary(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/usage?period=24h")
    assert resp.status_code == 200
    data = resp.json()
    assert "total_input_tokens" in data
    assert "total_output_tokens" in data
    assert "total_cost_usd" in data
    assert data["period"] == "24h"


async def test_usage_history(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/usage/history?period=24h")
    assert resp.status_code == 200
    data = resp.json()
    assert "history" in data
    assert isinstance(data["history"], list)


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


async def test_list_approvals_empty(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/approvals")
    assert resp.status_code == 200
    assert resp.json()["approvals"] == []


async def test_approve_resolves_approval(
    tmp_path: Path,
) -> None:
    """POST /approvals/{id}/approve → approval is resolved."""
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("proj", tmp_path)
    registry.register(config)

    # Write an approval directly into the project DB
    proj_db = RulesDB(config.knowledge.db_path)
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    approval = PendingApproval(
        project_name="proj",
        episode_id="ep_001",
        plan_json='{"actions":[]}',
    )
    await proj_db.write_pending_approval(approval)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Should appear in list
        resp = await ac.get("/projects/proj/approvals")
        assert resp.status_code == 200
        approvals = resp.json()["approvals"]
        assert len(approvals) == 1
        appr_id = approvals[0]["id"]

        # Approve it
        resp = await ac.post(f"/projects/proj/approvals/{appr_id}/approve")
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

        # Should no longer be pending
        resp = await ac.get("/projects/proj/approvals")
        assert resp.json()["approvals"] == []


async def test_reject_resolves_approval(
    tmp_path: Path,
) -> None:
    """POST /approvals/{id}/reject → approval is resolved as rejected."""
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("proj2", tmp_path)
    registry.register(config)

    proj_db = RulesDB(config.knowledge.db_path)
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    approval = PendingApproval(
        project_name="proj2",
        episode_id="ep_002",
        plan_json='{"actions":[]}',
    )
    await proj_db.write_pending_approval(approval)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/projects/proj2/approvals")
        appr_id = resp.json()["approvals"][0]["id"]

        resp = await ac.post(f"/projects/proj2/approvals/{appr_id}/reject")
        assert resp.status_code == 200
        assert resp.json()["status"] == "rejected"


# ---------------------------------------------------------------------------
# Gap #7: RulesDB cached per db_path (migrations only run once)
# ---------------------------------------------------------------------------


async def test_get_db_returns_same_instance_for_same_project(tmp_path: Path) -> None:
    """Multiple calls to _get_db for the same project return the cached instance."""
    from fastapi import Request

    from sagex.api.routes import _get_db

    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("cache-proj", tmp_path)
    registry.register(config)

    # Fake a minimal Request object pointing at our app
    scope = {"type": "http", "method": "GET", "path": "/", "headers": []}
    scope["app"] = app  # type: ignore[assignment]
    request = Request(scope)  # type: ignore[arg-type]

    db1 = _get_db(request, "cache-proj")
    db2 = _get_db(request, "cache-proj")
    assert db1 is db2, "Expected the same RulesDB instance (cached)"
