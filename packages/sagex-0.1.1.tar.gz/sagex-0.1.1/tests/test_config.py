"""Tests for config models — Phase 1 acceptance criteria."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from sagex.config import (
    AgentConfig,
    AgentsConfig,
    BudgetConfig,
    KnowledgeConfig,
    NotificationsConfig,
    RunnerConfig,
    SecurityAgentConfig,
    WatchConfig,
    load_config,
)
from sagex.config import (
    TestConfig as ProjectTestConfig,  # alias avoids pytest collection warning
)

# ---------------------------------------------------------------------------
# YAML fixtures
# ---------------------------------------------------------------------------

MINIMAL_YAML = textwrap.dedent("""\
    name: test-project
    repo_root: .
    watch:
      paths:
        - "src/**/*.py"
    test:
      command: "pytest tests/"
""")

FULL_YAML = textwrap.dedent("""\
    name: full-project
    repo_root: /some/path
    watch:
      paths:
        - "src/**/*.py"
        - "tests/**/*.py"
      ignore:
        - "**/__pycache__/**"
      debounce_seconds: 3.5
    test:
      command: "pytest tests/ -x"
      timeout_seconds: 60
      working_dir: /some/path
    agent:
      model: "claude-sonnet-4-5"
      triage_model: "claude-haiku-4-5"
      max_tokens: 2048
      temperature: 0.1
      triage_temperature: 0.0
    knowledge:
      min_confidence_threshold: 0.5
      max_rules_in_context: 5
      max_context_chars: 4000
      context_window_lines: 20
    budget:
      hourly_token_limit: 10000
      daily_token_limit: 100000
      alert_threshold: 0.9
      content_cache_ttl_minutes: 30
      enable_prompt_caching: false
    runner:
      max_concurrent_tasks: 2
      queue_max_size: 50
      require_approval: true
      approval_timeout_seconds: 120
      retry_max_attempts: 2
      retry_backoff_seconds: 1.0
    agents:
      security:
        enabled: true
        watch_extra:
          - ".env*"
          - "**/Dockerfile*"
        auto_remediate: true
    notifications:
      webhook_url: "https://example.com/hook"
      on:
        - "critical"
    runtime_url: "http://localhost:9000"
""")

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_minimal_config_loads(tmp_path: Path) -> None:
    """Minimal YAML with only required fields loads without error."""
    f = tmp_path / "config.yaml"
    f.write_text(MINIMAL_YAML)
    config = load_config(f)
    assert config.name == "test-project"
    assert config.repo_root == "."
    assert "src/**/*.py" in config.watch.paths
    assert config.test.command == "pytest tests/"


def test_defaults_applied(tmp_path: Path) -> None:
    """All optional sections get correct default values when omitted."""
    f = tmp_path / "config.yaml"
    f.write_text(MINIMAL_YAML)
    config = load_config(f)

    # Agent
    assert config.agent.model == "claude-sonnet-4-5"
    assert config.agent.triage_model == "claude-haiku-4-5"
    assert config.agent.max_tokens == 2048
    assert config.agent.triage_max_tokens == 512
    assert config.agent.meta_max_tokens == 1024
    assert config.agent.security_max_tokens == 1024
    assert config.agent.summariser_max_tokens == 512
    assert config.agent.temperature == 0.2
    assert config.agent.triage_temperature == 0.0

    # Budget
    assert config.budget.hourly_token_limit == 50_000
    assert config.budget.daily_token_limit == 500_000
    assert config.budget.alert_threshold == 0.8
    assert config.budget.content_cache_ttl_minutes == 60
    assert config.budget.enable_prompt_caching is True

    # Runner
    assert config.runner.max_concurrent_tasks == 3
    assert config.runner.queue_max_size == 100
    assert config.runner.require_approval is False
    assert config.runner.approval_timeout_seconds == 300
    assert config.runner.retry_max_attempts == 3
    assert config.runner.retry_backoff_seconds == 2.0

    # Knowledge
    assert config.knowledge.min_confidence_threshold == 0.4
    assert config.knowledge.max_rules_in_context == 5
    assert config.knowledge.max_episodes_in_context == 3
    assert config.knowledge.max_rule_chars == 200
    assert config.knowledge.max_episode_chars == 200
    assert config.knowledge.max_context_chars == 4000
    assert config.knowledge.context_window_lines == 30

    # Security
    assert config.agents.security.enabled is False
    assert config.agents.security.auto_remediate is False

    # Notifications
    assert config.notifications.webhook_url is None
    assert "critical" in config.notifications.on
    assert "regression_detected" in config.notifications.on

    # Runtime URL
    assert config.runtime_url == "http://localhost:8765"


def test_full_config_all_fields_overrideable(tmp_path: Path) -> None:
    """Every field can be overridden from its default."""
    f = tmp_path / "config.yaml"
    f.write_text(FULL_YAML)
    config = load_config(f)

    assert config.name == "full-project"
    assert config.watch.debounce_seconds == 3.5
    assert config.test.timeout_seconds == 60
    assert config.test.working_dir == "/some/path"
    assert config.agent.max_tokens == 2048
    assert config.agent.temperature == 0.1
    assert config.budget.hourly_token_limit == 10_000
    assert config.budget.enable_prompt_caching is False
    assert config.runner.require_approval is True
    assert config.runner.approval_timeout_seconds == 120
    assert config.runner.retry_backoff_seconds == 1.0
    assert config.agents.security.enabled is True
    assert config.agents.security.auto_remediate is True
    assert ".env*" in config.agents.security.watch_extra
    assert config.notifications.webhook_url == "https://example.com/hook"
    assert config.notifications.on == ["critical"]
    assert config.runtime_url == "http://localhost:9000"


def test_watch_default_ignore_never_excludes_dotenv() -> None:
    """Default ignore list must NOT block .env* — security agent must see them."""
    defaults = WatchConfig(paths=["src/**/*.py"])
    for pattern in defaults.ignore:
        assert ".env" not in pattern, (
            f"Default ignore pattern '{pattern}' would suppress .env events. "
            "Security agent must be able to watch .env files."
        )


def test_security_watch_extra_covers_sensitive_paths() -> None:
    """SecurityAgentConfig.watch_extra includes .env*, secrets, and Dockerfiles."""
    sec = SecurityAgentConfig()
    combined = " ".join(sec.watch_extra)
    assert ".env" in combined
    assert "secret" in combined.lower()
    assert "Dockerfile" in combined


def test_nested_config_instances_are_correct_types(tmp_path: Path) -> None:
    """Nested config sections deserialise to the correct Pydantic model types."""
    f = tmp_path / "config.yaml"
    f.write_text(MINIMAL_YAML)
    config = load_config(f)

    assert isinstance(config.agent, AgentConfig)
    assert isinstance(config.knowledge, KnowledgeConfig)
    assert isinstance(config.budget, BudgetConfig)
    assert isinstance(config.runner, RunnerConfig)
    assert isinstance(config.agents, AgentsConfig)
    assert isinstance(config.agents.security, SecurityAgentConfig)
    assert isinstance(config.notifications, NotificationsConfig)
    assert isinstance(config.watch, WatchConfig)
    assert isinstance(config.test, ProjectTestConfig)


def test_invalid_yaml_raises(tmp_path: Path) -> None:
    """Missing required fields raises a validation error."""
    f = tmp_path / "config.yaml"
    f.write_text("name: only-name\n")  # missing repo_root, watch, test
    with pytest.raises(Exception):
        load_config(f)


def test_watch_config_default_ignore_populated() -> None:
    """Default ignore list contains the expected cache/git patterns."""
    w = WatchConfig(paths=["src/"])
    ignore_str = " ".join(w.ignore)
    assert "__pycache__" in ignore_str
    assert ".git" in ignore_str
    assert "node_modules" in ignore_str


def test_knowledge_db_paths_default() -> None:
    """Knowledge db_path and vector_path have sensible defaults."""
    k = KnowledgeConfig()
    assert "rules.db" in k.db_path
    assert "vectors" in k.vector_path
