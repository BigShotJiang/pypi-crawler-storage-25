"""Structured JSON logging formatter for Agentis.

Usage
-----
from sagex.logging import JSONFormatter, configure_logging
configure_logging()  # call once at startup (e.g. in cli.py serve)
"""

from __future__ import annotations

import json
import logging

_STANDARD_LOG_RECORD_KEYS: frozenset[str] = frozenset(
    (
        "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
        "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
        "created", "msecs", "relativeCreated", "thread", "threadName",
        "processName", "process", "message", "taskName",
    )
)


class JSONFormatter(logging.Formatter):
    """Format log records as single-line JSON suitable for log aggregators.

    Structured fields may be passed in two ways:

    1. Nested dict (preferred):
       ``_log.info("msg", extra={"extra": {"project": "x"}})``
    2. Flat kwargs (standard Python logging):
       ``_log.info("msg", extra={"project": "x"})``

    Both forms are merged into the top-level JSON output.
    """

    def format(self, record: logging.LogRecord) -> str:
        # Collect non-standard attributes set by extra={...} flat-style calls
        flat_extra = {
            k: v
            for k, v in record.__dict__.items()
            if k not in _STANDARD_LOG_RECORD_KEYS
        }
        # Nested-dict style takes precedence and is merged on top
        nested_extra: dict[str, object] = getattr(record, "extra", {})
        return json.dumps(
            {
                "ts": self.formatTime(record),
                "level": record.levelname,
                "msg": record.getMessage(),
                "module": record.module,
                **flat_extra,
                **nested_extra,
            }
        )


def configure_logging(level: int = logging.INFO) -> None:
    """Install the JSON formatter on the root logger at *level*."""
    handler = logging.StreamHandler()
    handler.setFormatter(JSONFormatter())
    root = logging.getLogger()
    root.setLevel(level)
    if not root.handlers:
        root.addHandler(handler)
    else:
        for h in root.handlers:
            h.setFormatter(JSONFormatter())
