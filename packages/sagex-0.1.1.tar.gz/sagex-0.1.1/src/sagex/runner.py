"""Main orchestration loop: observe-act-reflect cycle.

The ``Runner`` listens on the ``EventBus`` and processes each event through:
  1. Security check (optional, zero-token pattern scan)
  2. Triage (rule-based → Haiku if inconclusive)
  3. Test run before acting
  4. Knowledge context load
  5. Task agent plan
  6. (Optional) approval gate — runs OUTSIDE the semaphore
  7. Action execution + test run after
  8. Meta agent reflection
  9. Knowledge update

The semaphore (default 3) limits concurrent *active computation* only.
Approval waits run outside the semaphore so they don't block other events.
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import subprocess
import time
from datetime import UTC, datetime
from typing import Any

import httpx

from sagex.agents.meta_agent import MetaAgent, detect_regression
from sagex.agents.security_agent import SecurityAgent, SecurityRisk, classify_security_risk
from sagex.agents.task_agent import ActionExecutor, ExecutionResult, TaskAgent
from sagex.agents.triage_agent import TriageAgent, TriageResult
from sagex.api.server import ProjectRegistry
from sagex.config import ProjectConfig
from sagex.event_bus import AgentEvent, EventBus
from sagex.knowledge.rules_db import Episode, PendingApproval, Rule, RulesDB
from sagex.knowledge.store import KnowledgeContext, KnowledgeStore
from sagex.llm.budget import BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker
from sagex.watcher import WatcherManager

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _serialise(event: AgentEvent) -> str:
    return json.dumps(dataclasses.asdict(event), default=str)


def _make_budget_manager(config: ProjectConfig) -> BudgetManager:
    db = RulesDB(config.knowledge.db_path)
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=config.budget.content_cache_ttl_minutes)
    return BudgetManager(config.budget, tracker, cache)


def _run_tests(config: ProjectConfig) -> str:
    """Run the project test suite and return 'pass' or 'fail'."""
    try:
        proc = subprocess.run(
            config.test.command,
            shell=True,
            cwd=config.test.working_dir or config.repo_root,
            capture_output=True,
            text=True,
            timeout=config.test.timeout_seconds,
        )
        return "pass" if proc.returncode == 0 else "fail"
    except Exception:
        return "fail"


def _run_security_check(
    event: AgentEvent,
    config: ProjectConfig,
) -> SecurityRisk | None:
    """Run the zero-token security pattern scan on the event diff."""
    diff = event.diff or event.diff_context or ""
    if not diff:
        return None
    worst: SecurityRisk | None = None
    for file_path in event.file_paths:
        risk = classify_security_risk(diff, file_path)
        if risk and (
            worst is None
            or {"critical": 3, "high": 2, "medium": 1}.get(risk.severity, 0)
            > {"critical": 3, "high": 2, "medium": 1}.get(worst.severity, 0)
        ):
            worst = risk
    return worst


async def _maybe_notify(config: ProjectConfig, episode: Episode) -> None:
    """Fire webhook notification if configured and conditions match."""
    webhook_url = config.notifications.webhook_url
    if not webhook_url:
        return
    on_conditions = config.notifications.on
    should_notify = (
        episode.severity in on_conditions
        or (episode.regression_detected and "regression_detected" in on_conditions)
    )
    if not should_notify:
        return
    try:
        async with httpx.AsyncClient() as client:
            await client.post(
                webhook_url,
                json={
                    "project": episode.project_name,
                    "episode_id": episode.id,
                    "severity": episode.severity,
                    "regression": bool(episode.regression_detected),
                    "status": episode.status,
                },
                timeout=5.0,
            )
    except Exception as exc:
        _log.warning("webhook_failed", extra={"url": webhook_url, "error": str(exc)})


# ---------------------------------------------------------------------------
# Retry wrapper
# ---------------------------------------------------------------------------


async def _execute_with_retry(
    plan: dict[str, Any],
    config: ProjectConfig,
    test_before: str | None,
    runner_config: Any,
) -> ExecutionResult:
    executor = ActionExecutor()
    last_error: Exception | None = None
    for attempt in range(runner_config.retry_max_attempts):
        try:
            return executor.execute(plan, config, test_before)
        except Exception as exc:
            last_error = exc
            await asyncio.sleep(runner_config.retry_backoff_seconds**attempt)
    raise last_error  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Approval wait
# ---------------------------------------------------------------------------


async def _wait_for_approval(
    plan: dict[str, Any],
    episode: Episode,
    store: KnowledgeStore,
    config: ProjectConfig,
) -> bool:
    """Write a PendingApproval and poll until resolved or timed out.

    Must be called WITHOUT holding the runner semaphore.
    """
    approval = PendingApproval(
        project_name=episode.project_name,
        episode_id=episode.id,
        plan_json=json.dumps(plan),
        status="pending",
        created_at=_now(),
    )
    approval_id = await store._db.write_pending_approval(approval)

    loop = asyncio.get_running_loop()
    deadline = loop.time() + config.runner.approval_timeout_seconds
    while loop.time() < deadline:
        await asyncio.sleep(5)
        resolved = store._db.get_approval(approval_id)
        if resolved is None:
            continue
        if resolved.status == "approved":
            return True
        if resolved.status == "rejected":
            return False

    await store._db.resolve_approval(approval_id, "timeout")
    return False


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


class Runner:
    """Orchestrates the observe-act-reflect loop for all registered projects."""

    def __init__(
        self,
        event_bus: EventBus,
        registry: ProjectRegistry,
        watcher_manager: WatcherManager,
        max_concurrent_tasks: int = 3,
    ) -> None:
        self._bus = event_bus
        self._registry = registry
        self._watcher_manager = watcher_manager
        self._semaphore = asyncio.Semaphore(max_concurrent_tasks)

    async def run(self) -> None:
        """Consume events from the bus forever."""
        while True:
            event = await self._bus.subscribe()
            asyncio.create_task(self._handle_event(event))

    async def _handle_event(self, event: AgentEvent) -> None:
        config = self._registry.get(event.project_name)
        if config is None:
            return

        _log.info(
            "event_received",
            extra={
                "extra": {
                    "event_id": event.id,
                    "event_type": str(event.type),
                    "project": event.project_name,
                    "file_count": len(event.file_paths),
                }
            },
        )

        try:
            # Phase 1: triage + plan — held under semaphore
            result_tuple = await self._plan_phase(event, config)
            (
                plan,
                episode,
                triage,
                context,
                test_before,
                store,
                budget,
                task_agent,
                meta_agent,
                should_skip,
            ) = result_tuple

            if should_skip:
                return

            # Phase 2: approval gate — runs WITHOUT semaphore
            if config.runner.require_approval:
                approved = await _wait_for_approval(plan, episode, store, config)
                if not approved:
                    episode.status = "skipped"
                    await store.record_episode(episode)
                    return

            # Phase 3: execution + reflection — back under semaphore
            async with self._semaphore:
                await self._execute_phase(
                    event,
                    plan,
                    episode,
                    triage,
                    context,
                    test_before,
                    store,
                    budget,
                    meta_agent,
                    config,
                )
        finally:
            await self._bus.mark_event_done(event.id)

    async def _plan_phase(
        self, event: AgentEvent, config: ProjectConfig
    ) -> tuple[
        Any,
        Episode,
        Any,
        Any,
        Any,
        KnowledgeStore,
        BudgetManager,
        TaskAgent,
        MetaAgent,
        bool,
    ]:
        """Triage + plan, held under semaphore."""
        async with self._semaphore:
            store = KnowledgeStore(config.knowledge, event.project_name)
            episode = Episode(
                project_name=event.project_name,
                status="failed",
                trigger_event=_serialise(event),
                context_snapshot="{}",
                created_at=_now(),
            )
            # Placeholder agents; replaced inside the try block after budget is created
            task_agent: TaskAgent | None = None
            meta_agent: MetaAgent | None = None

            try:
                budget = _make_budget_manager(config)
                triage_agent = TriageAgent(config.agent, budget)
                task_agent = TaskAgent(config.agent, budget, config.knowledge)
                meta_agent = MetaAgent(config.agent, budget)

                _skip_tuple: tuple[
                    Any,
                    Episode,
                    Any,
                    Any,
                    Any,
                    KnowledgeStore,
                    BudgetManager,
                    TaskAgent,
                    MetaAgent,
                    bool,
                ] = (
                    None, episode, None, None, None,
                    store, budget, task_agent, meta_agent, True,
                )

            except Exception as exc:
                # Budget setup failed (e.g. BudgetExceededError)
                _log.warning("plan_phase_setup_error", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return (  # type: ignore[return-value]
                    None, episode, None, None, None, store, None, None, None, True
                )

            try:
                # 1. Security check
                if config.agents.security.enabled:
                    risk = _run_security_check(event, config)
                    if risk:
                        _log.info(
                            "security_risk",
                            extra={
                                "extra": {
                                    "project": event.project_name,
                                    "severity": risk.severity,
                                    "description": risk.description,
                                    "auto_remediate": config.agents.security.auto_remediate,
                                }
                            },
                        )
                        if config.agents.security.auto_remediate:
                            # LLM-backed deep audit; result informs task agent context
                            security_agent = SecurityAgent(
                                config.agent, budget, config.agents.security
                            )
                            diff = event.diff or event.diff_context or ""
                            audit = await security_agent.audit(event, diff, risk)
                            episode.severity = str(audit.get("severity", risk.severity))
                            _log.info(
                                "security_audit",
                                extra={
                                    "extra": {
                                        "project": event.project_name,
                                        "severity": episode.severity,
                                        "description": audit.get("description"),
                                    }
                                },
                            )
                        else:
                            episode.severity = risk.severity
                            episode.status = "skipped"
                            await store.record_episode(episode)
                            await _maybe_notify(config, episode)
                            return _skip_tuple

                # 2. Triage
                triage = await triage_agent.classify(event)
                _log.info(
                    "triage_result",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "severity": triage.severity,
                            "used_llm": triage.used_llm,
                            "tokens_used": triage.tokens_used,
                        }
                    },
                )
                if triage.severity == "skip":
                    episode.status = "skipped"
                    episode.severity = "skip"
                    await store.record_episode(episode)
                    return _skip_tuple

                # 3. Run tests before acting
                test_before = _run_tests(config)
                episode.test_result_before = test_before

                # 4. Load knowledge context
                situation = f"{event.type}: {', '.join(event.file_paths)}"
                context = store.get_relevant_context(situation)
                _log.info(
                    "knowledge_loaded",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "rule_count": len(context.rules),
                            "episode_count": len(context.similar_episodes),
                            "has_conflicts": context.has_conflicts,
                        }
                    },
                )

                # 5. Task agent plans
                plan = await task_agent.plan(event, triage, context, test_before)
                _log.info(
                    "plan_produced",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "action_count": len(plan.get("actions", [])),
                            "severity": plan.get("severity"),
                            "confidence": plan.get("confidence"),
                        }
                    },
                )

                return (
                    plan,
                    episode,
                    triage,
                    context,
                    test_before,
                    store,
                    budget,
                    task_agent,
                    meta_agent,
                    False,
                )

            except BudgetExceededError as exc:
                _log.warning("budget_exceeded", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return _skip_tuple

            except Exception as exc:
                _log.error("plan_phase_error", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return _skip_tuple

    async def _execute_phase(
        self,
        event: AgentEvent,
        plan: dict[str, Any],
        episode: Episode,
        triage: TriageResult,
        context: KnowledgeContext,
        test_before: str | None,
        store: KnowledgeStore,
        budget: BudgetManager,
        meta_agent: MetaAgent,
        config: ProjectConfig,
    ) -> None:
        """Execute plan, reflect, and update knowledge. Held under semaphore."""
        # Dry-run: log plan and skip execution
        if event.extra.get("dry_run"):
            _log.info(
                "dry_run_plan",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "plan": plan,
                    }
                },
            )
            episode.status = "skipped"
            episode.error_message = "dry_run"
            await store.record_episode(episode)
            return

        try:
            # 6. Execute plan with retry
            _t0 = time.monotonic()
            result = await _execute_with_retry(plan, config, test_before, config.runner)
            duration_ms = int((time.monotonic() - _t0) * 1000)

            # 7. Build episode
            episode.rules_applied = json.dumps(plan.get("rules_applied", []))
            episode.actions_taken = json.dumps(result.actions_taken)
            episode.files_modified = json.dumps(result.files_modified)
            episode.test_result_after = result.test_result
            episode.regression_detected = int(
                detect_regression(test_before, result.test_result)
            )
            episode.severity = triage.severity
            episode.status = "completed"

            _log.info(
                "execution_complete",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "files_modified": result.files_modified,
                        "test_result": result.test_result,
                        "duration_ms": duration_ms,
                    }
                },
            )

            # 8. Meta agent reflects
            reflection = await meta_agent.reflect(event, triage, plan, result, episode)

            # 9. Update knowledge
            episode.lesson_extracted = reflection.get("lesson")
            await store.record_episode(episode)

            rule_id: str | None = None
            if reflection.get("rule"):
                r = reflection["rule"]
                raw_tags = r.get("tags")
                tags: list[str] = (
                    [str(t) for t in raw_tags] if isinstance(raw_tags, list) else []
                )
                rule = Rule(
                    trigger_pattern=str(r.get("trigger_pattern", "")),
                    lesson=str(r.get("lesson", "")),
                    confidence=float(r.get("initial_confidence", 0.3)),
                    status="unvalidated",
                    tags=tags,
                    source_episode_id=episode.id,
                    project_name=event.project_name,
                )
                rule_id = await store.write_rule(rule)
                episode.rule_generated_id = rule_id
                await store.record_episode(episode)

            _log.info(
                "meta_outcome",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "outcome": reflection.get("outcome"),
                        "rule_written": rule_id,
                    }
                },
            )

            for upd in reflection.get("rule_updates", []):
                await store.update_rule_outcome(
                    str(upd.get("rule_id", "")), bool(upd.get("was_correct", False))
                )

            # 10. Archive low-confidence rules periodically
            await store._db.archive_low_confidence_rules(event.project_name)

            # 11. Webhook
            await _maybe_notify(config, episode)

        except BudgetExceededError as exc:
            _log.warning("budget_exceeded", extra={
                "project": event.project_name, "error": str(exc)
            })
            episode.error_message = str(exc)
            await store.record_episode(episode)

        except Exception as exc:
            _log.error("execute_phase_error", extra={
                "project": event.project_name, "error": str(exc)
            })
            episode.error_message = str(exc)
            await store.record_episode(episode)
