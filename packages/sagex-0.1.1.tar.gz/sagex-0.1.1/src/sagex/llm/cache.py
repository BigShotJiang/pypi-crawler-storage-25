"""Prompt content-hash deduplication cache backed by the SQLite content_cache table.

ContentCache.get() is synchronous (WAL allows concurrent reads).
ContentCache.set() is async def and serialised through RulesDB._write().

``build_cached_request`` is a standalone helper that constructs the API
request dict, applying ``cache_control`` only when the system prompt meets
the per-model token threshold.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime, timedelta
from typing import Any

# ---------------------------------------------------------------------------
# Prompt-caching token thresholds (Anthropic requirement)
# Applying cache_control below these limits adds overhead with no benefit.
# ---------------------------------------------------------------------------

_CACHE_MIN_TOKENS: dict[str, int] = {
    "claude-haiku-4-5": 2048,
    "claude-sonnet-4-5": 1024,
    "claude-opus-4-5": 1024,
}
_CHARS_PER_TOKEN = 4  # safe approximation for English / code


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // _CHARS_PER_TOKEN)


# ---------------------------------------------------------------------------
# Content-hash cache
# ---------------------------------------------------------------------------

class ContentCache:
    """Content-addressed cache for LLM responses.

    Parameters
    ----------
    db:
        A live ``RulesDB`` instance (typed as ``Any`` to avoid a circular
        import — the actual runtime type is always ``RulesDB``).
    ttl_minutes:
        How long a cached response is considered fresh.
    """

    def __init__(self, db: Any, ttl_minutes: int = 60) -> None:
        self._db = db
        self._ttl = timedelta(minutes=ttl_minutes)

    def _hash(self, system: str, user: str) -> str:
        """SHA-256 of ``system || '||' || user`` (hex digest)."""
        return hashlib.sha256(f"{system}||{user}".encode()).hexdigest()

    def get(self, system: str, user: str) -> str | None:
        """Return the cached response for ``(system, user)``, or ``None`` on miss/expiry."""
        call_hash = self._hash(system, user)
        row = self._db._conn.execute(
            "SELECT response, created_at FROM content_cache WHERE hash = ?",
            (call_hash,),
        ).fetchone()
        if row is None:
            return None
        created_at = datetime.fromisoformat(row[1])
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)
        if datetime.now(UTC) - created_at > self._ttl:
            return None
        return str(row[0])

    async def set(self, system: str, user: str, response: str) -> None:
        """Upsert *response* into the cache under the ``(system, user)`` hash (async write)."""
        call_hash = self._hash(system, user)
        now = datetime.now(UTC).isoformat()
        await self._db._write(
            """INSERT OR REPLACE INTO content_cache (hash, response, created_at)
               VALUES (?, ?, ?)""",
            (call_hash, response, now),
        )


# ---------------------------------------------------------------------------
# Request builder
# ---------------------------------------------------------------------------

def build_cached_request(
    system_prompt: str,
    user_prompt: str,
    model: str,
    max_tokens: int,
    enable_prompt_caching: bool = True,
) -> dict[str, Any]:
    """Build the Anthropic API request dict.

    Applies ``cache_control`` to the system prompt **only** when:
    - ``enable_prompt_caching`` is ``True``, AND
    - the estimated token count of the system prompt meets the per-model
      minimum (1 024 tokens for Sonnet/Opus, 2 048 for Haiku).

    Below the threshold, ``cache_control`` is silently ignored by the API but
    still adds overhead — we skip it explicitly.
    """
    min_tokens = _CACHE_MIN_TOKENS.get(model, 1024)
    should_cache = (
        enable_prompt_caching
        and _estimate_tokens(system_prompt) >= min_tokens
    )

    system: list[dict[str, Any]] | str
    if should_cache:
        system = [
            {
                "type": "text",
                "text": system_prompt,
                "cache_control": {"type": "ephemeral"},
            }
        ]
    else:
        system = system_prompt

    return {
        "model": model,
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user_prompt}],
    }
