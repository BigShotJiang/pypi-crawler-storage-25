"""Token usage tracking: records LLM call costs to the SQLite store.

TokenUsageRecord is the concrete type that RulesDB.write_token_usage and
get_token_usage operate on.  It is intentionally kept dependency-free so
that rules_db.py can lazy-import it without a circular-import risk.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Pricing table (per-token costs in USD, 2025 Anthropic rates)
# ---------------------------------------------------------------------------

MODEL_PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-5": {
        "input": 15.0 / 1_000_000,
        "output": 75.0 / 1_000_000,
        "cache_write": 18.75 / 1_000_000,
        "cache_read": 1.5 / 1_000_000,
    },
    "claude-sonnet-4-5": {
        "input": 3.0 / 1_000_000,
        "output": 15.0 / 1_000_000,
        "cache_write": 3.75 / 1_000_000,
        "cache_read": 0.30 / 1_000_000,
    },
    "claude-haiku-4-5": {
        "input": 0.80 / 1_000_000,
        "output": 4.0 / 1_000_000,
        "cache_write": 1.0 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _short_uuid() -> str:
    return uuid.uuid4().hex[:8]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class TokenUsageRecord:
    id: str
    ts: str
    project: str
    agent_type: str
    model: str
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    cost_usd: float
    call_hash: str | None
    was_cached: bool


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------

class TokenTracker:
    """Async recorder + sync summary reader for token usage."""

    def __init__(self, db: Any) -> None:  # db: RulesDB — Any avoids circular import
        self._db = db

    async def record(
        self,
        project: str,
        agent_type: str,
        model: str,
        usage: Any,                  # anthropic Usage object or zero-usage sentinel
        call_hash: str | None = None,
        was_cached: bool = False,
    ) -> TokenUsageRecord:
        """Build a TokenUsageRecord from an Anthropic usage object and persist it.

        Async — calls ``self._db.write_token_usage()`` which acquires the
        ``RulesDB`` write lock. Always ``await`` this method.
        """
        input_tokens: int = getattr(usage, "input_tokens", 0) or 0
        output_tokens: int = getattr(usage, "output_tokens", 0) or 0
        cache_read: int = getattr(usage, "cache_read_input_tokens", 0) or 0
        cache_write: int = getattr(usage, "cache_creation_input_tokens", 0) or 0
        cost = self.compute_cost(model, input_tokens, output_tokens, cache_read, cache_write)

        rec = TokenUsageRecord(
            id=f"tok_{_short_uuid()}",
            ts=_now_iso(),
            project=project,
            agent_type=agent_type,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            cost_usd=cost,
            call_hash=call_hash,
            was_cached=was_cached,
        )
        await self._db.write_token_usage(rec)
        return rec

    def get_summary(self, project: str, since_iso: str) -> dict[str, int | float]:
        """Return aggregated statistics for *project* since *since_iso* (sync read)."""
        records: list[Any] = self._db.get_token_usage(project, since_iso)
        total_input = sum(r.input_tokens for r in records)
        total_output = sum(r.output_tokens for r in records)
        total_cost = sum(r.cost_usd for r in records)
        cached_calls = sum(1 for r in records if r.was_cached)
        return {
            "total_calls": len(records),
            "input_tokens": total_input,
            "output_tokens": total_output,
            "total_cost_usd": total_cost,
            "cached_calls": cached_calls,
        }

    @staticmethod
    def compute_cost(
        model: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
    ) -> float:
        """Compute USD cost from token counts using the MODEL_PRICING table."""
        pricing = MODEL_PRICING.get(model, MODEL_PRICING["claude-sonnet-4-5"])
        return (
            input_tokens * pricing["input"]
            + output_tokens * pricing["output"]
            + cache_read_tokens * pricing["cache_read"]
            + cache_write_tokens * pricing["cache_write"]
        )
