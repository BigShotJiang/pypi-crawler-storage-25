"""BudgetManager — the single entry point for all Anthropic API calls.

Every LLM call in Agentis flows through this module.  Never instantiate
``anthropic.AsyncAnthropic`` outside of this file.

Call pipeline
-------------
call(project, agent_type, system, user, model, max_tokens)
  ├─ check_budget()              ← sync read; raises BudgetExceededError
  ├─ ContentCache.get()          ← sync read; instant cache hit
  ├─ build_cached_request()      ← applies cache_control if prompt is large
  ├─ _call_with_retry()          ← async Anthropic client, asyncio.sleep backoff
  ├─ TokenTracker.record()       ← async write to token_usage table
  └─ ContentCache.set()          ← async write to content_cache table
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from datetime import UTC, datetime, timedelta
from typing import Any

import anthropic

from sagex.config import BudgetConfig
from sagex.llm.cache import ContentCache, build_cached_request
from sagex.llm.token_tracker import TokenTracker

_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class BudgetExceededError(Exception):
    """Raised when the token budget for the current period is exhausted."""


class AgentOutputError(Exception):
    """Raised when an agent returns malformed JSON after one retry."""


# ---------------------------------------------------------------------------
# Zero-usage sentinel (used when returning a cached response)
# ---------------------------------------------------------------------------

class _ZeroUsage:
    """Fake anthropic Usage object for cache-hit records (no tokens consumed)."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0


# ---------------------------------------------------------------------------
# BudgetManager
# ---------------------------------------------------------------------------

class BudgetManager:
    """Facade over the Anthropic async client with budget enforcement,
    prompt caching, token tracking, and content-hash deduplication.

    Parameters
    ----------
    config:
        Budget limits and caching knobs.
    tracker:
        Pre-constructed ``TokenTracker`` instance.
    content_cache:
        Pre-constructed ``ContentCache`` instance.
    client:
        Optional override — inject a ``StubAnthropicClient`` in tests so
        the real API is never called.
    api_key:
        Anthropic API key.  Falls back to ``ANTHROPIC_API_KEY`` env var when
        *client* is ``None``.
    """

    def __init__(
        self,
        config: BudgetConfig,
        tracker: TokenTracker,
        content_cache: ContentCache,
        client: Any = None,
        api_key: str | None = None,
    ) -> None:
        self._config = config
        self._tracker = tracker
        self._cache = content_cache
        if client is not None:
            self._client: Any = client
        else:
            self._client = anthropic.AsyncAnthropic(
                api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", "")
            )

    # ------------------------------------------------------------------ Budget

    @staticmethod
    def _since_hours(hours: int) -> str:
        return (datetime.now(UTC) - timedelta(hours=hours)).isoformat()

    def check_budget(self, project: str) -> None:
        """Raise ``BudgetExceededError`` when hourly or daily limits are breached.

        Sync — reads token_usage via WAL reader; no write lock needed.
        """
        hourly = self._tracker.get_summary(project, self._since_hours(1))
        hourly_total = hourly["input_tokens"] + hourly["output_tokens"]
        if hourly_total >= self._config.hourly_token_limit:
            raise BudgetExceededError(
                f"Hourly token limit exceeded: {hourly_total} >= "
                f"{self._config.hourly_token_limit}"
            )

        daily = self._tracker.get_summary(project, self._since_hours(24))
        daily_total = daily["input_tokens"] + daily["output_tokens"]
        if daily_total >= self._config.daily_token_limit:
            raise BudgetExceededError(
                f"Daily token limit exceeded: {daily_total} >= "
                f"{self._config.daily_token_limit}"
            )

        # Alert when approaching the daily limit
        daily_pct = daily_total / self._config.daily_token_limit
        if daily_pct >= self._config.alert_threshold:
            _log.warning(
                "budget_alert",
                extra={
                    "extra": {
                        "project": project,
                        "daily_pct": round(daily_pct * 100),
                        "daily_total": daily_total,
                        "daily_limit": self._config.daily_token_limit,
                    }
                },
            )

    # ------------------------------------------------------------------ Retry

    async def _call_with_retry(
        self,
        request: dict[str, Any],
        max_attempts: int = 3,
    ) -> Any:
        """Call the Anthropic API with exponential-backoff retry on transient errors.

        Uses ``asyncio.sleep`` — never ``time.sleep``.
        """
        for attempt in range(max_attempts):
            try:
                return await self._client.messages.create(**request)
            except anthropic.RateLimitError:
                if attempt == max_attempts - 1:
                    raise
                await asyncio.sleep(2.0**attempt)
            except anthropic.APIStatusError as exc:
                if exc.status_code >= 500 and attempt < max_attempts - 1:
                    await asyncio.sleep(2.0**attempt)
                    continue
                raise
        raise RuntimeError("unreachable")  # pragma: no cover

    # ------------------------------------------------------------------ Public API

    async def call(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float = 0.2,
    ) -> str:
        """Make one LLM call, enforcing budget, caching, and token tracking.

        Returns the raw text from the first content block.
        """
        self.check_budget(project)

        # Content-hash deduplication — instant cache hit
        cached = self._cache.get(system, user)
        if cached is not None:
            await self._tracker.record(
                project,
                agent_type,
                model,
                _ZeroUsage(),
                call_hash=self._cache._hash(system, user),
                was_cached=True,
            )
            return cached

        request = build_cached_request(
            system,
            user,
            model,
            max_tokens,
            enable_prompt_caching=self._config.enable_prompt_caching,
        )
        request["temperature"] = temperature

        response = await self._call_with_retry(request)
        text: str = response.content[0].text

        await self._tracker.record(
            project,
            agent_type,
            model,
            response.usage,
            call_hash=self._cache._hash(system, user),
            was_cached=False,
        )
        await self._cache.set(system, user, text)
        return text

    @staticmethod
    def _strip_fences(text: str) -> str:
        """Strip markdown code fences that models sometimes wrap JSON in.

        Handles: ```json\\n{...}\\n``` and ``` ... ```
        """
        stripped = text.strip()
        stripped = re.sub(r"^```(?:json)?\s*\n?", "", stripped)
        stripped = re.sub(r"\n?```\s*$", "", stripped)
        return stripped.strip()

    async def call_json(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float = 0.2,
    ) -> dict[str, object]:
        """Like ``call()``, but parse the response as JSON.

        Strips markdown code fences before parsing (models occasionally wrap
        JSON in ```json ... ``` despite being told not to).
        On malformed JSON: retry once with a correction prompt.
        If still invalid: raise ``AgentOutputError``.
        """
        text = self._strip_fences(await self.call(
            project=project,
            agent_type=agent_type,
            system=system,
            user=user,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
        ))
        try:
            result: dict[str, object] = json.loads(text)
            return result
        except json.JSONDecodeError:
            correction = (
                user
                + "\n\nYour previous response was not valid JSON. "
                "Return ONLY the JSON object, no prose, no markdown fences."
            )
            text2 = self._strip_fences(await self.call(
                project=project,
                agent_type=agent_type,
                system=system,
                user=correction,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
            ))
            try:
                result2: dict[str, object] = json.loads(text2)
                return result2
            except json.JSONDecodeError as exc:
                raise AgentOutputError(
                    f"Agent returned malformed JSON after retry: {text2[:200]}"
                ) from exc
