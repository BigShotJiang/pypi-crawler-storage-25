"""Sagex — self-hosted, self-learning local code agent."""

__version__ = "0.1.0"
