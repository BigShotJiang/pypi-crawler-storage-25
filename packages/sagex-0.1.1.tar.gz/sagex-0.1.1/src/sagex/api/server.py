"""FastAPI application factory and project registry.

The app is wired up here; all routes live in ``routes.py``.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI

from sagex.config import ProjectConfig

if TYPE_CHECKING:
    from sagex.event_bus import EventBus
    from sagex.watcher import WatcherManager


# ---------------------------------------------------------------------------
# Project registry
# ---------------------------------------------------------------------------


class ProjectRegistry:
    """In-memory registry of active ``ProjectConfig`` objects."""

    def __init__(self) -> None:
        self._projects: dict[str, ProjectConfig] = {}

    def register(self, config: ProjectConfig) -> None:
        """Add or replace a project configuration."""
        self._projects[config.name] = config

    def deregister(self, name: str) -> None:
        """Remove a project by name.  No-op if not found."""
        self._projects.pop(name, None)

    def get(self, name: str) -> ProjectConfig | None:
        """Return the ``ProjectConfig`` for *name*, or ``None``."""
        return self._projects.get(name)

    def list_all(self) -> list[ProjectConfig]:
        """Return all registered project configs."""
        return list(self._projects.values())


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app(
    bus: EventBus,
    watcher_manager: WatcherManager,
    registry: ProjectRegistry,
    runner: Any | None = None,
) -> FastAPI:
    """Create and return the FastAPI application.

    Parameters
    ----------
    bus:
        The shared ``EventBus`` instance.
    watcher_manager:
        The ``WatcherManager`` that controls filesystem watchers.
    registry:
        The ``ProjectRegistry`` holding all registered projects.
    runner:
        Optional runner task (may be ``None`` in tests).
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        # Startup: reload any persisted unprocessed events
        bus.reload_persisted_events()
        yield
        # Shutdown: stop all watchers
        watcher_manager.stop_all()

    app = FastAPI(
        title="Agent Runtime",
        version="0.1.0",
        lifespan=lifespan,
    )
    app.state.bus = bus
    app.state.registry = registry
    app.state.watcher_manager = watcher_manager
    app.state.runner = runner

    # Register routes
    from sagex.api.routes import router  # noqa: PLC0415

    app.include_router(router)

    return app
