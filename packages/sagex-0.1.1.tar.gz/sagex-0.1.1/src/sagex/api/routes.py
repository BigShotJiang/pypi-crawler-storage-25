"""All API route handlers for the Agent Runtime server."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from sagex.config import load_config
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.knowledge.store import KnowledgeStore

router = APIRouter()


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    config_path: str


class NotifyRequest(BaseModel):
    project_name: str
    event_type: str
    repo_root: str
    file_paths: list[str] = []
    extra: dict[str, Any] = {}


class RuleFeedbackRequest(BaseModel):
    was_correct: bool


class UsageQueryRequest(BaseModel):
    period: str = "24h"


class RulesExportRequest(BaseModel):
    min_confidence: float = 0.85
    min_applied: int = 10


class RulesImportRequest(BaseModel):
    rules: list[dict[str, Any]]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_db(request: Request, project_name: str) -> RulesDB:
    """Return the RulesDB for *project_name*, or raise 404.

    Caches one RulesDB instance per db_path in ``app.state._db_cache`` so
    migrations only run once per process lifetime.
    """
    registry = request.app.state.registry
    config = registry.get(project_name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{project_name}' not found")

    if not hasattr(request.app.state, "_db_cache"):
        request.app.state._db_cache = {}
    db_cache: dict[str, RulesDB] = request.app.state._db_cache
    db_path = config.knowledge.db_path
    if db_path not in db_cache:
        db = RulesDB(db_path)
        db.run_migrations(Path(__file__).parent.parent / "knowledge" / "migrations")
        db_cache[db_path] = db
    return db_cache[db_path]


def _period_to_iso(period: str) -> str:
    """Convert a period string like '24h' or '7d' to an ISO timestamp string."""
    import datetime

    if len(period) < 2 or period[-1] not in {"h", "d"} or not period[:-1].isdigit():
        raise HTTPException(
            status_code=422,
            detail="Invalid period. Supported formats: '<N>h' or '<N>d' (e.g. '24h', '7d').",
        )
    value = int(period[:-1])
    now = datetime.datetime.now(datetime.UTC)
    if period.endswith("h"):
        delta = datetime.timedelta(hours=value)
    else:
        delta = datetime.timedelta(days=value)
    return (now - delta).isoformat()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": "0.1.0"}


# ---------------------------------------------------------------------------
# Project management
# ---------------------------------------------------------------------------


@router.post("/projects/register", status_code=201)
async def register_project(
    body: RegisterRequest, request: Request
) -> dict[str, str]:
    config_path = Path(body.config_path).resolve()
    # Require the config file to be named config.yaml inside a .agents directory.
    # This prevents path traversal reads of arbitrary files on the host.
    if config_path.name != "config.yaml" or ".agents" not in config_path.parts:
        raise HTTPException(
            status_code=400,
            detail="config_path must point to a .agents/config.yaml file",
        )
    try:
        config = load_config(config_path)
    except Exception:
        raise HTTPException(status_code=400, detail="Failed to load project config")
    request.app.state.registry.register(config)
    return {"name": config.name, "status": "registered"}


@router.delete("/projects/{name}", status_code=200)
async def deregister_project(name: str, request: Request) -> dict[str, str]:
    registry = request.app.state.registry
    if registry.get(name) is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    registry.deregister(name)
    return {"name": name, "status": "deregistered"}


@router.get("/projects")
async def list_projects(request: Request) -> dict[str, list[str]]:
    projects = request.app.state.registry.list_all()
    return {"projects": [p.name for p in projects]}


# ---------------------------------------------------------------------------
# Event notification
# ---------------------------------------------------------------------------


@router.post("/notify", status_code=202)
async def notify(body: NotifyRequest, request: Request) -> dict[str, str]:
    bus = request.app.state.bus
    try:
        event_type = EventType(body.event_type)
    except ValueError:
        event_type = EventType.FILE_MODIFIED

    event = AgentEvent(
        type=event_type,
        project_name=body.project_name,
        repo_root=body.repo_root,
        file_paths=body.file_paths,
        extra=body.extra,
    )
    await bus.publish(event)
    return {"status": "queued", "event_id": event.id}


# ---------------------------------------------------------------------------
# Queue status
# ---------------------------------------------------------------------------


@router.get("/queue/status")
async def queue_status(request: Request) -> dict[str, int]:
    bus = request.app.state.bus
    return {"depth": bus._queue.qsize()}


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/rules")
async def list_rules(
    name: str,
    request: Request,
    tag: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    db = _get_db(request, name)
    rules = db.get_rules_for_project(name, min_confidence=0.0)
    if status is not None:
        rules = [r for r in rules if r.status == status]
    if tag is not None:
        rules = [r for r in rules if tag in r.tags]
    return {
        "rules": [
            {
                "id": r.id,
                "trigger_pattern": r.trigger_pattern,
                "lesson": r.lesson,
                "confidence": r.confidence,
                "status": r.status,
                "tags": r.tags,
            }
            for r in rules
        ]
    }


@router.post("/projects/{name}/rules/{rule_id}/feedback")
async def rule_feedback(
    name: str, rule_id: str, body: RuleFeedbackRequest, request: Request
) -> dict[str, str]:
    db = _get_db(request, name)
    await db.update_confidence(rule_id, body.was_correct)
    return {"rule_id": rule_id, "status": "updated"}


@router.post("/projects/{name}/rules/export")
async def export_rules(
    name: str, body: RulesExportRequest, request: Request
) -> dict[str, Any]:
    registry = request.app.state.registry
    config = registry.get(name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    store = KnowledgeStore(config.knowledge, name)
    exported = store.export_rules(
        min_confidence=body.min_confidence,
        min_applied=body.min_applied,
    )
    return {"rules": exported, "count": len(exported)}


@router.post("/projects/{name}/rules/import")
async def import_rules(
    name: str, body: RulesImportRequest, request: Request
) -> dict[str, Any]:
    registry = request.app.state.registry
    config = registry.get(name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    store = KnowledgeStore(config.knowledge, name)
    count = await store.import_rules(body.rules)
    return {"imported": count}


# ---------------------------------------------------------------------------
# Episodes
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/episodes")
async def list_episodes(
    name: str, request: Request, limit: int = 20
) -> dict[str, Any]:
    db = _get_db(request, name)
    episodes = db.get_recent_episodes(name, limit=limit)
    return {
        "episodes": [
            {
                "id": e.id,
                "status": e.status,
                "severity": e.severity,
                "test_result_before": e.test_result_before,
                "test_result_after": e.test_result_after,
                "regression_detected": e.regression_detected,
                "lesson_extracted": e.lesson_extracted,
                "created_at": e.created_at,
            }
            for e in episodes
        ]
    }


# ---------------------------------------------------------------------------
# Token usage
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/usage")
async def usage_summary(
    name: str,
    request: Request,
    period: str = "24h",
) -> dict[str, Any]:
    db = _get_db(request, name)
    since = _period_to_iso(period)
    rows = db.get_token_usage(name, since_iso=since)
    ep_stats = db.get_episode_stats(name, since_iso=since)

    total_input = sum(r.input_tokens for r in rows)
    total_output = sum(r.output_tokens for r in rows)
    total_cost = sum(r.cost_usd for r in rows)
    cache_read = sum(r.cache_read_tokens for r in rows)
    cache_hits = sum(1 for r in rows if r.was_cached)
    input_fresh = sum(r.input_tokens for r in rows if not r.was_cached)
    input_cached = cache_read

    total_events = ep_stats["total"]
    skipped = ep_stats["skipped"]
    skip_pct = round(skipped / total_events * 100, 1) if total_events else 0.0

    # Estimate savings: cache_read tokens cost ~10% of normal input price
    # Rough saving = cache_read_tokens * 0.9 * avg_input_price_per_token
    # Use a conservative $3/1M tokens (sonnet rate) as baseline
    avg_input_rate = 3.0 / 1_000_000
    cache_savings = round(cache_read * avg_input_rate * 0.9, 6)

    by_agent: dict[str, dict[str, int]] = {}
    for r in rows:
        agent = r.agent_type or "unknown"
        if agent not in by_agent:
            by_agent[agent] = {"calls": 0, "tokens": 0}
        by_agent[agent]["calls"] += 1
        by_agent[agent]["tokens"] += r.input_tokens + r.output_tokens

    return {
        "period": period,
        "total_events": total_events,
        "skipped_by_triage": skipped,
        "skip_pct": skip_pct,
        "cache_hits": cache_hits,
        "api_calls": sum(1 for r in rows if not r.was_cached),
        "input_tokens_fresh": input_fresh,
        "input_tokens_cached": input_cached,
        "output_tokens": total_output,
        "cache_savings_usd": cache_savings,
        "estimated_cost_usd": round(total_cost, 6),
        # legacy aliases kept for existing test_api.py assertions
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "total_cost_usd": round(total_cost, 6),
        "call_count": len(rows),
        "by_agent": by_agent,
    }


@router.get("/projects/{name}/usage/history")
async def usage_history(
    name: str,
    request: Request,
    period: str = "24h",
) -> dict[str, Any]:
    db = _get_db(request, name)
    since = _period_to_iso(period)
    rows = db.get_token_usage(name, since_iso=since)
    history = [
        {
            "id": r.id,
            "agent_type": r.agent_type,
            "input_tokens": r.input_tokens,
            "output_tokens": r.output_tokens,
            "model": r.model,
            "cost_usd": r.cost_usd,
            "timestamp": r.ts,
        }
        for r in rows
    ]
    return {"period": period, "history": history}


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/approvals")
async def list_approvals(name: str, request: Request) -> dict[str, Any]:
    db = _get_db(request, name)
    approvals = db.get_pending_approvals(name)
    return {
        "approvals": [
            {
                "id": a.id,
                "episode_id": a.episode_id,
                "plan_json": a.plan_json,
                "status": a.status,
                "created_at": a.created_at,
            }
            for a in approvals
        ]
    }


@router.post("/projects/{name}/approvals/{approval_id}/approve")
async def approve(
    name: str, approval_id: str, request: Request
) -> dict[str, str]:
    db = _get_db(request, name)
    await db.resolve_approval(approval_id, "approved")
    return {"approval_id": approval_id, "status": "approved"}


@router.post("/projects/{name}/approvals/{approval_id}/reject")
async def reject(
    name: str, approval_id: str, request: Request
) -> dict[str, str]:
    db = _get_db(request, name)
    await db.resolve_approval(approval_id, "rejected")
    return {"approval_id": approval_id, "status": "rejected"}
