"""Filesystem watcher: detects changes and publishes typed AgentEvents.

Uses watchdog for cross-platform filesystem events.  Changed paths are
debounced (collected for ``debounce_seconds`` then fired as one event) to
avoid flooding the bus on rapid saves.

Public surface
--------------
- ``get_git_diff``           — raw ``git diff HEAD`` output
- ``get_diff_with_context``  — diff with ±N surrounding lines, truncated to max_chars
- ``ProjectWatcher``         — single-project watcher
- ``WatcherManager``         — multi-project watcher registry
"""

from __future__ import annotations

import fnmatch
import logging
import subprocess
import threading
from time import monotonic
from typing import TYPE_CHECKING, Any

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from sagex.event_bus import AgentEvent, EventBus, EventType

if TYPE_CHECKING:
    from sagex.config import ProjectConfig

_log = logging.getLogger(__name__)

_TRUNCATION_MARKER = "... [truncated — {remaining} chars omitted] ..."


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def get_git_diff(repo_root: str, file_paths: list[str]) -> str | None:
    """Run ``git diff HEAD -- <files>`` and return stdout.

    Returns ``None`` on subprocess error or empty output.
    """
    try:
        result = subprocess.run(
            ["git", "diff", "HEAD", "--"] + file_paths,
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout or None
    except Exception as exc:
        _log.debug("get_git_diff error: %s", exc)
        return None


def get_diff_with_context(
    repo_root: str,
    file_paths: list[str],
    context_lines: int = 30,
    max_chars: int = 8000,
) -> str | None:
    """Return ``git diff`` with ±``context_lines`` of surrounding code.

    If the output exceeds ``max_chars``, it is truncated with a clear marker.
    No LLM call is made here — this is raw content delivery only.
    """
    try:
        result = subprocess.run(
            ["git", "diff", f"-U{context_lines}", "HEAD", "--"] + file_paths,
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        output = result.stdout
        if not output:
            return None
        if len(output) <= max_chars:
            return output
        remaining = len(output) - max_chars
        marker = _TRUNCATION_MARKER.format(remaining=remaining)
        return output[:max_chars] + "\n" + marker
    except Exception as exc:
        _log.debug("get_diff_with_context error: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Ignore-list check
# ---------------------------------------------------------------------------

def _should_ignore(path: str, ignore_patterns: list[str]) -> bool:
    """Return ``True`` if *path* matches any of the ignore glob patterns."""
    import os

    # Normalize to forward slashes for cross-platform consistency
    normalized = path.replace("\\", "/")
    basename = os.path.basename(path)
    for pattern in ignore_patterns:
        if fnmatch.fnmatch(normalized, pattern):
            return True
        # Also match against the basename only (for patterns like "*.log")
        if fnmatch.fnmatch(basename, pattern):
            return True
    return False


# ---------------------------------------------------------------------------
# Watchdog handler with debounce
# ---------------------------------------------------------------------------

class _DebounceHandler(FileSystemEventHandler):
    """Collects filesystem events and fires one consolidated AgentEvent after debounce."""

    def __init__(self, config: ProjectConfig, bus: EventBus) -> None:
        super().__init__()
        self._config = config
        self._bus = bus
        self._pending: dict[str, float] = {}  # path → last-seen monotonic time
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        path = str(event.src_path)
        if _should_ignore(path, self._config.watch.ignore):
            return
        with self._lock:
            self._pending[path] = monotonic()
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(
                self._config.watch.debounce_seconds,
                self._fire,
            )
            self._timer.daemon = True
            self._timer.start()

    def _fire(self) -> None:
        with self._lock:
            paths = list(self._pending.keys())
            self._pending.clear()
            self._timer = None
        if not paths:
            return

        diff = get_git_diff(self._config.repo_root, paths)
        context = get_diff_with_context(
            self._config.repo_root,
            paths,
            context_lines=self._config.knowledge.context_window_lines,
            max_chars=self._config.knowledge.max_context_chars,
        )
        agent_event = AgentEvent(
            type=EventType.FILE_MODIFIED,
            project_name=self._config.name,
            repo_root=self._config.repo_root,
            file_paths=paths,
            diff=diff,
            diff_context=context,
        )
        self._bus.publish_sync(agent_event)


# ---------------------------------------------------------------------------
# ProjectWatcher
# ---------------------------------------------------------------------------

class ProjectWatcher:
    """Watches a single project's paths and publishes events to the bus."""

    def __init__(self, config: ProjectConfig, bus: EventBus) -> None:
        self._config = config
        self._bus = bus
        self._observer: Any = Observer()
        self._handler = _DebounceHandler(config, bus)

    def start(self) -> None:
        for watch_path in self._config.watch.paths:
            self._observer.schedule(self._handler, watch_path, recursive=True)
        self._observer.start()
        _log.info("watcher started", extra={"project": self._config.name})

    def stop(self) -> None:
        self._observer.stop()
        self._observer.join()
        _log.info("watcher stopped", extra={"project": self._config.name})


# ---------------------------------------------------------------------------
# WatcherManager
# ---------------------------------------------------------------------------

class WatcherManager:
    """Registry of ProjectWatchers for multiple projects."""

    def __init__(self, bus: EventBus) -> None:
        self._bus = bus
        self._watchers: dict[str, ProjectWatcher] = {}

    def add_project(self, config: ProjectConfig) -> None:
        if config.name in self._watchers:
            return
        watcher = ProjectWatcher(config, self._bus)
        self._watchers[config.name] = watcher

    def remove_project(self, project_name: str) -> None:
        watcher = self._watchers.pop(project_name, None)
        if watcher is not None:
            watcher.stop()

    def start_all(self) -> None:
        for watcher in self._watchers.values():
            watcher.start()

    def stop_all(self) -> None:
        for watcher in self._watchers.values():
            watcher.stop()
        self._watchers.clear()
