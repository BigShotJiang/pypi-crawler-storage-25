"""Unified knowledge store interface.

KnowledgeStore wraps RulesDB (SQLite) + VectorDB (ChromaDB) and exposes the
single API used by agents and the runner.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from sagex.config import KnowledgeConfig
from sagex.knowledge.embedder import Embedder
from sagex.knowledge.rules_db import Episode, Rule, RulesDB
from sagex.knowledge.vector_db import VectorDB

# ---------------------------------------------------------------------------
# Return type
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeContext:
    rules: list[Rule]
    similar_episodes: list[dict[str, object]]
    has_conflicts: bool = False
    conflict_note: str = ""


# ---------------------------------------------------------------------------
# Cosine similarity (no numpy dep at module level)
# ---------------------------------------------------------------------------

def _cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# KnowledgeStore
# ---------------------------------------------------------------------------

class KnowledgeStore:
    """Facade over RulesDB + VectorDB for a single project.

    Parameters
    ----------
    embedder:
        Optional override — inject a deterministic mock in tests to avoid
        downloading the sentence-transformers model.
    """

    def __init__(
        self,
        config: KnowledgeConfig,
        project_name: str,
        embedder: Embedder | None = None,
    ) -> None:
        self._config = config
        self._project_name = project_name
        self._embedder = embedder or Embedder()
        self._db = RulesDB(config.db_path)
        self._vector_db = VectorDB(config.vector_path, self._embedder)

    # ------------------------------------------------------------------ Read

    def get_relevant_context(self, situation_text: str) -> KnowledgeContext:
        """Load rules + semantically similar episodes for the given situation."""
        rules = self._db.get_rules_for_project(
            self._project_name, self._config.min_confidence_threshold
        )[: self._config.max_rules_in_context]

        similar_episodes = self._vector_db.query(
            situation_text,
            self._project_name,
            n_results=self._config.max_episodes_in_context,
        )

        has_conflicts, conflict_note = self.detect_conflicts(rules)
        return KnowledgeContext(
            rules=rules,
            similar_episodes=similar_episodes,
            has_conflicts=has_conflicts,
            conflict_note=conflict_note,
        )

    def detect_conflicts(self, rules: list[Rule]) -> tuple[bool, str]:
        """Flag pairs of rules with similar triggers but different lessons.

        Embeds each rule's ``trigger_pattern``. Pairs with cosine similarity
        > 0.85 and different ``lesson`` text are considered conflicting.
        """
        if len(rules) < 2:
            return False, ""

        embeddings = [self._embedder.embed(r.trigger_pattern) for r in rules]
        conflicts: list[str] = []

        for i in range(len(rules)):
            for j in range(i + 1, len(rules)):
                sim = _cosine_similarity(embeddings[i], embeddings[j])
                if sim > 0.85 and rules[i].lesson != rules[j].lesson:
                    conflicts.append(
                        f"Rule {rules[i].id} vs {rules[j].id} (sim={sim:.2f})"
                    )

        if conflicts:
            return True, "Conflicting rules: " + "; ".join(conflicts)
        return False, ""

    # ------------------------------------------------------------------ Write

    async def record_episode(self, episode: Episode) -> str:
        ep_id = await self._db.write_episode(episode)
        # Index in vector store for semantic retrieval
        self._vector_db.upsert(
            id=ep_id,
            text=f"{episode.trigger_event} {episode.actions_taken}",
            metadata={"project_name": self._project_name, "type": "episode"},
        )
        return ep_id

    async def write_rule(self, rule: Rule) -> str:
        rule_id = await self._db.write_rule(rule)
        self._vector_db.upsert(
            id=rule_id,
            text=f"{rule.trigger_pattern} {rule.lesson}",
            metadata={"project_name": self._project_name, "type": "rule"},
        )
        return rule_id

    async def update_rule_outcome(self, rule_id: str, was_correct: bool) -> None:
        await self._db.update_confidence(rule_id, was_correct)

    # ------------------------------------------------------------------ Export / import

    def export_rules(
        self,
        min_confidence: float = 0.85,
        min_applied: int = 10,
    ) -> list[dict[str, object]]:
        """Return high-confidence, frequently applied rules as plain dicts."""
        rules = self._db.get_rules_for_project(self._project_name, min_confidence)
        return [
            {
                "trigger_pattern": r.trigger_pattern,
                "lesson": r.lesson,
                "confidence": r.confidence,
                "times_applied": r.times_applied,
                "times_correct": r.times_correct,
                "tags": r.tags,
                "source_episode_id": r.source_episode_id,
            }
            for r in rules
            if r.times_applied >= min_applied
        ]

    async def import_rules(self, rules_export: list[dict[str, object]]) -> int:
        """Insert exported rules into this store. Returns count imported."""
        count = 0
        for r in rules_export:
            raw_tags = r.get("tags")
            tags: list[str] = [str(t) for t in raw_tags] if isinstance(raw_tags, list) else []
            rule = Rule(
                trigger_pattern=str(r["trigger_pattern"]),
                lesson=str(r["lesson"]),
                project_name=self._project_name,
                confidence=float(r.get("confidence", 0.3)),  # type: ignore[arg-type]
                tags=tags,
                source_episode_id=str(r["source_episode_id"])
                if r.get("source_episode_id")
                else None,
            )
            await self._db.write_rule(rule)
            count += 1
        return count
