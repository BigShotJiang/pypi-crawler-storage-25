"""sentence-transformers wrapper with lazy model loading.

The model (~90 MB) is downloaded once and cached at
~/.cache/sentence_transformers/. Subsequent loads are instant.
"""

from __future__ import annotations

from typing import Any


class Embedder:
    MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self) -> None:
        self._model: Any = None  # SentenceTransformer, lazy-loaded on first use

    def _load(self) -> None:
        if self._model is None:
            from sentence_transformers import (
                SentenceTransformer,  # type: ignore[import-untyped,unused-ignore]
            )

            self._model = SentenceTransformer(self.MODEL_NAME)

    def embed(self, text: str) -> list[float]:
        self._load()
        result: list[float] = self._model.encode(text).tolist()
        return result

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        self._load()
        result: list[list[float]] = self._model.encode(texts).tolist()
        return result
