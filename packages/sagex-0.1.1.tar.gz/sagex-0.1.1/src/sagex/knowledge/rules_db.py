"""SQLite knowledge store: rules, episodes, token usage, approvals, event queue.

All 7 tables live in a single rules.db file. WAL mode + asyncio.Lock() prevents
concurrent write corruption. Read methods are synchronous (WAL allows concurrent
readers); write methods are async def and serialised through _write().

Cross-phase type notes
----------------------
- TokenUsageRecord (Phase 3) and AgentEvent (Phase 4) are referenced via Any
  here so that ``mypy src/`` passes with zero errors at Phase 2 completion.
  The type annotations will be tightened when those modules are created.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _short_uuid() -> str:
    return uuid.uuid4().hex[:8]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class Rule:
    trigger_pattern: str
    lesson: str
    project_name: str
    id: str = field(default_factory=lambda: f"rule_{_short_uuid()}")
    confidence: float = 0.3
    times_applied: int = 0
    times_correct: int = 0
    status: str = "unvalidated"
    tags: list[str] = field(default_factory=list)
    source_episode_id: str | None = None
    created_at: str = field(default_factory=_now_iso)
    last_used_at: str | None = None


@dataclass
class Episode:
    project_name: str
    trigger_event: str  # JSON blob
    id: str = field(default_factory=lambda: f"ep_{_short_uuid()}")
    status: str = "completed"
    context_snapshot: str = "{}"
    rules_applied: str = "[]"
    actions_taken: str = "[]"
    files_modified: str = "[]"
    test_result_before: str | None = None
    test_result_after: str | None = None
    regression_detected: int = 0
    severity: str | None = None
    lesson_extracted: str | None = None
    rule_generated_id: str | None = None
    error_message: str | None = None
    created_at: str = field(default_factory=_now_iso)


@dataclass
class PendingApproval:
    project_name: str
    episode_id: str
    plan_json: str
    id: str = field(default_factory=lambda: f"appr_{_short_uuid()}")
    status: str = "pending"
    created_at: str = field(default_factory=_now_iso)
    resolved_at: str | None = None


# ---------------------------------------------------------------------------
# RulesDB
# ---------------------------------------------------------------------------

class RulesDB:
    """Single-file SQLite store for all Agentis knowledge tables.

    Open once per project; share across async tasks. The asyncio write lock
    serialises all INSERT/UPDATE/DELETE; reads are concurrent (WAL mode).
    """

    def __init__(self, db_path: str) -> None:
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._write_lock = asyncio.Lock()
        self.run_migrations(Path(__file__).parent / "migrations")

    # ------------------------------------------------------------------ Schema

    def run_migrations(self, migrations_dir: Path) -> None:
        """Apply any unapplied migrations in ascending version order."""
        current = self._get_schema_version()
        for sql_file in sorted(migrations_dir.glob("*.sql")):
            version = int(sql_file.stem.split("_")[0])
            if version > current:
                self._conn.executescript(sql_file.read_text())
                self._conn.commit()

    def _get_schema_version(self) -> int:
        try:
            row = self._conn.execute(
                "SELECT MAX(version) FROM schema_version"
            ).fetchone()
            return int(row[0]) if row and row[0] is not None else 0
        except sqlite3.OperationalError:
            return 0

    # ------------------------------------------------------------------ Core write primitive

    async def _write(self, sql: str, params: tuple[Any, ...] = ()) -> None:
        """All INSERT/UPDATE/DELETE must flow through here to serialise writes."""
        async with self._write_lock:
            self._conn.execute(sql, params)
            self._conn.commit()

    # ------------------------------------------------------------------ Rules

    async def write_rule(self, rule: Rule) -> str:
        await self._write(
            """INSERT OR REPLACE INTO rules
               (id, trigger_pattern, lesson, confidence, times_applied,
                times_correct, status, tags, source_episode_id, project_name,
                created_at, last_used_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                rule.id, rule.trigger_pattern, rule.lesson, rule.confidence,
                rule.times_applied, rule.times_correct, rule.status,
                json.dumps(rule.tags), rule.source_episode_id, rule.project_name,
                rule.created_at, rule.last_used_at,
            ),
        )
        return rule.id

    def get_rule(self, rule_id: str) -> Rule | None:
        row = self._conn.execute(
            "SELECT * FROM rules WHERE id = ?", (rule_id,)
        ).fetchone()
        return self._row_to_rule(row) if row else None

    def get_rules_for_project(
        self, project_name: str, min_confidence: float
    ) -> list[Rule]:
        rows = self._conn.execute(
            """SELECT * FROM rules
               WHERE project_name = ? AND confidence >= ? AND status != 'archived'
               ORDER BY confidence DESC""",
            (project_name, min_confidence),
        ).fetchall()
        return [self._row_to_rule(r) for r in rows]

    async def update_confidence(self, rule_id: str, correct: bool) -> None:
        """Bayesian confidence update: Beta(correct+1, incorrect+1) mean."""
        rule = self.get_rule(rule_id)
        if rule is None:
            return
        new_applied = rule.times_applied + 1
        new_correct = rule.times_correct + (1 if correct else 0)
        alpha = new_correct + 1
        beta_val = (new_applied - new_correct) + 1
        new_confidence = alpha / (alpha + beta_val)
        new_status = rule.status
        if rule.status == "unvalidated" and new_correct >= 2:
            new_status = "active"
        await self._write(
            """UPDATE rules SET confidence=?, times_applied=?, times_correct=?,
               status=?, last_used_at=? WHERE id=?""",
            (new_confidence, new_applied, new_correct, new_status, _now_iso(), rule_id),
        )

    async def archive_low_confidence_rules(
        self, project_name: str, threshold: float = 0.2
    ) -> int:
        count: int = self._conn.execute(
            """SELECT COUNT(*) FROM rules
               WHERE project_name = ? AND confidence < ? AND status != 'archived'""",
            (project_name, threshold),
        ).fetchone()[0]
        if count:
            await self._write(
                """UPDATE rules SET status='archived'
                   WHERE project_name = ? AND confidence < ? AND status != 'archived'""",
                (project_name, threshold),
            )
        return count

    def _row_to_rule(self, row: tuple[Any, ...]) -> Rule:
        # Column order matches CREATE TABLE in 001_initial.sql:
        # id(0) trigger_pattern(1) lesson(2) confidence(3) times_applied(4)
        # times_correct(5) status(6) tags(7) source_episode_id(8) project_name(9)
        # created_at(10) last_used_at(11)
        return Rule(
            id=row[0],
            trigger_pattern=row[1],
            lesson=row[2],
            confidence=float(row[3]),
            times_applied=int(row[4]),
            times_correct=int(row[5]),
            status=row[6],
            tags=json.loads(row[7]),
            source_episode_id=row[8],
            project_name=row[9],
            created_at=row[10],
            last_used_at=row[11],
        )

    # ------------------------------------------------------------------ Episodes

    async def write_episode(self, episode: Episode) -> str:
        await self._write(
            """INSERT OR REPLACE INTO episodes
               (id, project_name, status, trigger_event, context_snapshot,
                rules_applied, actions_taken, files_modified, test_result_before,
                test_result_after, regression_detected, severity, lesson_extracted,
                rule_generated_id, error_message, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                episode.id, episode.project_name, episode.status,
                episode.trigger_event, episode.context_snapshot,
                episode.rules_applied, episode.actions_taken,
                episode.files_modified, episode.test_result_before,
                episode.test_result_after, episode.regression_detected,
                episode.severity, episode.lesson_extracted,
                episode.rule_generated_id, episode.error_message,
                episode.created_at,
            ),
        )
        return episode.id

    def get_episode(self, episode_id: str) -> Episode | None:
        row = self._conn.execute(
            "SELECT * FROM episodes WHERE id = ?", (episode_id,)
        ).fetchone()
        return self._row_to_episode(row) if row else None

    def get_recent_episodes(
        self, project_name: str, limit: int = 20
    ) -> list[Episode]:
        rows = self._conn.execute(
            """SELECT * FROM episodes WHERE project_name = ?
               ORDER BY created_at DESC LIMIT ?""",
            (project_name, limit),
        ).fetchall()
        return [self._row_to_episode(r) for r in rows]

    def _row_to_episode(self, row: tuple[Any, ...]) -> Episode:
        # Column order: id(0) project_name(1) status(2) trigger_event(3)
        # context_snapshot(4) rules_applied(5) actions_taken(6) files_modified(7)
        # test_result_before(8) test_result_after(9) regression_detected(10)
        # severity(11) lesson_extracted(12) rule_generated_id(13)
        # error_message(14) created_at(15)
        return Episode(
            id=row[0],
            project_name=row[1],
            status=row[2],
            trigger_event=row[3],
            context_snapshot=row[4],
            rules_applied=row[5],
            actions_taken=row[6],
            files_modified=row[7],
            test_result_before=row[8],
            test_result_after=row[9],
            regression_detected=int(row[10]),
            severity=row[11],
            lesson_extracted=row[12],
            rule_generated_id=row[13],
            error_message=row[14],
            created_at=row[15],
        )

    # ------------------------------------------------------------------ Token usage
    # Type: Any — will be TokenUsageRecord once Phase 3 (token_tracker.py) is complete.

    async def write_token_usage(self, usage: Any) -> None:
        await self._write(
            """INSERT INTO token_usage
               (id, ts, project, agent_type, model, input_tokens, output_tokens,
                cache_read_tokens, cache_write_tokens, cost_usd, call_hash, was_cached)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                usage.id, usage.ts, usage.project, usage.agent_type, usage.model,
                usage.input_tokens, usage.output_tokens, usage.cache_read_tokens,
                usage.cache_write_tokens, usage.cost_usd, usage.call_hash,
                int(usage.was_cached),
            ),
        )

    def get_token_usage(self, project_name: str, since_iso: str) -> list[Any]:
        """Returns list[TokenUsageRecord] — lazy-imports from token_tracker (Phase 3)."""
        from sagex.llm.token_tracker import TokenUsageRecord

        rows = self._conn.execute(
            "SELECT * FROM token_usage WHERE project = ? AND ts >= ? ORDER BY ts",
            (project_name, since_iso),
        ).fetchall()
        return [
            TokenUsageRecord(
                id=r[0], ts=r[1], project=r[2], agent_type=r[3], model=r[4],
                input_tokens=r[5], output_tokens=r[6], cache_read_tokens=r[7],
                cache_write_tokens=r[8], cost_usd=r[9], call_hash=r[10],
                was_cached=bool(r[11]),
            )
            for r in rows
        ]

    # ------------------------------------------------------------------ Pending approvals

    async def write_pending_approval(self, approval: PendingApproval) -> str:
        await self._write(
            """INSERT OR REPLACE INTO pending_approvals
               (id, project_name, episode_id, plan_json, status, created_at, resolved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                approval.id, approval.project_name, approval.episode_id,
                approval.plan_json, approval.status, approval.created_at,
                approval.resolved_at,
            ),
        )
        return approval.id

    async def resolve_approval(self, approval_id: str, status: str) -> None:
        await self._write(
            "UPDATE pending_approvals SET status=?, resolved_at=? WHERE id=?",
            (status, _now_iso(), approval_id),
        )

    def get_approval(self, approval_id: str) -> PendingApproval | None:
        """Return a ``PendingApproval`` by id regardless of status."""
        row = self._conn.execute(
            "SELECT * FROM pending_approvals WHERE id = ?",
            (approval_id,),
        ).fetchone()
        return self._row_to_approval(row) if row else None

    def get_pending_approvals(self, project_name: str) -> list[PendingApproval]:
        rows = self._conn.execute(
            "SELECT * FROM pending_approvals WHERE project_name = ? AND status = 'pending'",
            (project_name,),
        ).fetchall()
        return [self._row_to_approval(r) for r in rows]

    def _row_to_approval(self, row: tuple[Any, ...]) -> PendingApproval:
        # id(0) project_name(1) episode_id(2) plan_json(3) status(4)
        # created_at(5) resolved_at(6)
        return PendingApproval(
            id=row[0],
            project_name=row[1],
            episode_id=row[2],
            plan_json=row[3],
            status=row[4],
            created_at=row[5],
            resolved_at=row[6],
        )

    # ------------------------------------------------------------------ Event queue
    # Type: Any — will be AgentEvent once Phase 4 (event_bus.py) is complete.

    async def persist_event(self, event: Any) -> None:
        import dataclasses

        event_json = json.dumps(dataclasses.asdict(event), default=str)
        await self._write(
            """INSERT OR IGNORE INTO event_queue
               (id, project_name, event_json, status, created_at)
               VALUES (?, ?, ?, 'queued', ?)""",
            (event.id, event.project_name, event_json, _now_iso()),
        )

    async def mark_event_processing(self, event_id: str) -> None:
        await self._write(
            "UPDATE event_queue SET status='processing' WHERE id=?",
            (event_id,),
        )

    async def mark_event_done(self, event_id: str) -> None:
        await self._write(
            "UPDATE event_queue SET status='done' WHERE id=?",
            (event_id,),
        )

    def get_episode_stats(
        self, project_name: str, since_iso: str
    ) -> dict[str, int]:
        """Return total and skipped episode counts for *project_name* since *since_iso*."""
        total: int = self._conn.execute(
            "SELECT COUNT(*) FROM episodes WHERE project_name=? AND created_at>=?",
            (project_name, since_iso),
        ).fetchone()[0]
        skipped: int = self._conn.execute(
            """SELECT COUNT(*) FROM episodes
               WHERE project_name=? AND created_at>=? AND status='skipped'""",
            (project_name, since_iso),
        ).fetchone()[0]
        return {"total": total, "skipped": skipped}

    def get_unprocessed_events(self) -> list[Any]:
        """Returns list[AgentEvent] — lazy-imports from event_bus (Phase 4)."""
        from sagex.event_bus import AgentEvent

        rows = self._conn.execute(
            """SELECT event_json FROM event_queue
               WHERE status IN ('queued', 'processing')
               ORDER BY created_at""",
        ).fetchall()
        events = []
        for (event_json,) in rows:
            data = json.loads(event_json)
            events.append(AgentEvent(**data))
        return events
