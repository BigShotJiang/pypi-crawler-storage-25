"""Pydantic config models for Agentis projects."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field


class WatchConfig(BaseModel):
    paths: list[str]
    ignore: list[str] = [
        "**/__pycache__/**",
        "**/.git/**",
        "**/node_modules/**",
        "**/*.log",
        "**/*.lock",
        # NOTE: .env* is intentionally NOT in the default ignore list.
        # Security-sensitive files must always be watchable so the security
        # agent can detect credential leaks. If you want to suppress .env
        # watch events, add "**/.env*" to this list explicitly in config.yaml.
    ]
    debounce_seconds: float = 2.0


class TestConfig(BaseModel):
    command: str
    timeout_seconds: int = 120
    working_dir: str | None = None


class AgentConfig(BaseModel):
    model: str = "claude-sonnet-4-5"
    triage_model: str = "claude-haiku-4-5"
    max_tokens: int = 2048
    triage_max_tokens: int = 512
    meta_max_tokens: int = 1024
    security_max_tokens: int = 1024
    summariser_max_tokens: int = 512
    temperature: float = 0.2
    triage_temperature: float = 0.0


class KnowledgeConfig(BaseModel):
    db_path: str = ".agents/knowledge/rules.db"
    vector_path: str = ".agents/knowledge/vectors"
    min_confidence_threshold: float = 0.4
    max_rules_in_context: int = 5
    max_episodes_in_context: int = 3
    max_rule_chars: int = 200
    max_episode_chars: int = 200
    max_context_chars: int = 4000
    context_window_lines: int = 30


class BudgetConfig(BaseModel):
    hourly_token_limit: int = 50_000
    daily_token_limit: int = 500_000
    alert_threshold: float = 0.8
    content_cache_ttl_minutes: int = 60
    enable_prompt_caching: bool = True


class RunnerConfig(BaseModel):
    max_concurrent_tasks: int = 3
    queue_max_size: int = 100
    require_approval: bool = False
    approval_timeout_seconds: int = 300
    retry_max_attempts: int = 3
    retry_backoff_seconds: float = 2.0


class SecurityAgentConfig(BaseModel):
    enabled: bool = False
    watch_extra: list[str] = [
        ".env*",
        "**/*secret*",
        "**/*credential*",
        "**/requirements*.txt",
        "**/package.json",
        "**/Dockerfile*",
    ]
    auto_remediate: bool = False


class AgentsConfig(BaseModel):
    security: SecurityAgentConfig = Field(default_factory=SecurityAgentConfig)


class NotificationsConfig(BaseModel):
    webhook_url: str | None = None
    on: list[str] = ["critical", "regression_detected"]


class ProjectConfig(BaseModel):
    name: str
    repo_root: str
    watch: WatchConfig
    test: TestConfig
    agent: AgentConfig = Field(default_factory=AgentConfig)
    knowledge: KnowledgeConfig = Field(default_factory=KnowledgeConfig)
    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    runner: RunnerConfig = Field(default_factory=RunnerConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    notifications: NotificationsConfig = Field(default_factory=NotificationsConfig)
    runtime_url: str = "http://localhost:8765"


def load_config(config_path: Path) -> ProjectConfig:
    """Load and validate a .agents/config.yaml file.

    PyYAML (YAML 1.1) parses the bare key ``on`` as the boolean ``True``.
    This is a known gotcha for the ``notifications.on`` field — we normalise
    it back to the string key ``"on"`` before handing the dict to Pydantic.
    """
    raw: dict[str, object] = yaml.safe_load(config_path.read_text())
    if isinstance(raw.get("notifications"), dict):
        notifs: dict[object, object] = raw["notifications"]  # type: ignore[assignment]
        if True in notifs:
            notifs["on"] = notifs.pop(True)
    return ProjectConfig.model_validate(raw)
