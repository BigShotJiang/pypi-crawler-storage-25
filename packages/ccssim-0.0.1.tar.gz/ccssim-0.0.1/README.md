# CCSsim

Integrated CO₂ injection simulation platform.

Pre-release placeholder. Real release coming soon.

- Website: https://ccssim.com
- GitHub: https://github.com/ccssim
