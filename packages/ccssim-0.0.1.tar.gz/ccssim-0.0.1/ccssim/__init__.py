"""CCSsim — Integrated CO₂ injection simulation platform."""
__version__ = "0.0.1"
