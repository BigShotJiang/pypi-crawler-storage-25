# pseudoc

**Name reserved for the [Pseudo](https://github.com/siliconyouth/pseudo) language.**

The Pseudo language is currently in pre-v1 development. The actual Python runtime + compiler bindings will be published to PyPI when **v1.0 Ludens** ships.

Until then, this package is a placeholder.

## Where to follow development

- **Source**: [github.com/siliconyouth/pseudo](https://github.com/siliconyouth/pseudo)
- **Marketing site**: [pseudoc.com](https://pseudoc.com) (lands at v1.0)
- **Design specification**: see GitHub repo
- **Compatibility matrix**: COMPATIBILITY.md in the repo
- **Standards conformance**: CONFORMANCE.md in the repo

## What is Pseudo?

A typed pseudocode language that compiles deterministically to **10 native targets** (per ADR-0019 + ADR-0032): TypeScript, Rust, Python, Go, Swift, Kotlin, C# 14 / .NET 10 LTS, C++23, WASM/WASI Preview 2, shell. Comments are language protocol. Tools-first execution. Multi-agent first-class. Local + remote RAG search.

## License

Dual-licensed: MIT OR Apache-2.0.

## Owner

Vladimir Dukelic — [@siliconyouth](https://github.com/siliconyouth) — vladimir@dukelic.com
