# Copyright 2026 The SlymeLab Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
slyme pytree utility module.
"""

from .core import (
    # Types & Keys
    KeyPath,
    PyTreeKey,
    SequenceKey,
    MappingKey,
    AttributeKey,
    CallKey,
    P,
    PyTreeAux,
    # Structure & Engine
    PyTreeDef,
    LeafDef,
    ContainerDef,
    TraverseAux,
    PyTreeEngine,
    # Instances
    PYTREE_ENGINE_REGISTRY,
)

__all__ = [
    "KeyPath",
    "PyTreeKey",
    "SequenceKey",
    "MappingKey",
    "AttributeKey",
    "CallKey",
    "P",
    "PyTreeAux",
    "PyTreeDef",
    "LeafDef",
    "ContainerDef",
    "TraverseAux",
    "PyTreeEngine",
    "PYTREE_ENGINE_REGISTRY",
]
