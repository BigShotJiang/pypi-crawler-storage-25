# Copyright 2026 The SlymeLab Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Protocol, runtime_checkable


@runtime_checkable
class HasExtraRepr(Protocol):
    """
    Protocol for objects that provide an extended string representation.

    This allows objects to expose internal state details for logging,
    debugging, or rendering without overriding the standard __repr__.
    """

    def extra_repr(self) -> str:
        """Return the extra representation string."""
        ...


@runtime_checkable
class HasTypeRepr(Protocol):
    """
    Protocol for objects that provide a custom type name for rendering.

    This allows objects (like functional wrappers) to masquerade as their
    underlying logic (e.g. function name) instead of their implementation class.
    """

    def type_repr(self) -> str:
        """Return the custom type name string."""
        ...
