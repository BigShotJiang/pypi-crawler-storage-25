"""Custom tools via the in-process MCP adapter.

Mix LangChain ``BaseTool`` instances and bare callables with the built-in
tool names — ``bind_tools`` registers every custom tool with an
in-process MCP server (named ``"langchain-tools"``) that the SDK exposes
to the CLI. Tool execution happens in your Python process; the result
flows back into the conversation automatically.

Pydantic model classes can also be bound (without a handler) — useful
for ``with_structured_output``-style patterns where you want the model
to emit a structured call you intercept yourself.

Run with: ``uv run python examples/04_custom_tools.py``
"""

from __future__ import annotations

from langchain_core.messages import HumanMessage
from langchain_core.tools import tool
from pydantic import BaseModel, Field

from langchain_claude_agent_sdk import ChatClaudeAgent


@tool
def get_inventory(sku: str) -> dict[str, int | str]:
    """Look up current stock for a product SKU.

    Returns the SKU, stock count, and warehouse location.
    """
    # Pretend this hits a database; for the example we just fabricate.
    fake_stock = {"WIDGET-001": 42, "GIZMO-002": 0, "DOOHICKEY-003": 7}
    return {
        "sku": sku,
        "stock": fake_stock.get(sku, 0),
        "warehouse": "BLD-3-A14",
    }


def square(n: int) -> int:
    """Return the square of an integer."""
    return n * n


class CustomerLookup(BaseModel):
    """Look up a customer by email or customer id."""

    email: str | None = Field(default=None, description="Customer's email address.")
    customer_id: str | None = Field(default=None, description="Internal customer id.")


def main() -> None:
    model = ChatClaudeAgent()

    # Mix three tool types in one bind_tools call:
    # - BaseTool (decorated function)
    # - bare callable (auto-decorated)
    # - Pydantic class (schema-only, echo handler)
    bound = model.bind_tools([get_inventory, square, CustomerLookup])

    response = bound.invoke(
        [HumanMessage("What's the inventory for SKU WIDGET-001? And square of 7?")]
    )

    print("=== response ===")
    print(response.content)
    print()
    print("=== tool calls observed ===")
    for call in response.tool_calls:
        print(f"- {call['name']}({call['args']})")
    print()
    print("usage:", response.usage_metadata)


if __name__ == "__main__":
    main()
