"""Basic single-turn and multi-turn invocation.

Demonstrates the simplest use case: instantiate ``ChatClaudeAgent``,
call ``invoke()`` with a list of messages, read the response. Then
continue the conversation by appending to the history — the chat model
will pick up ``session_id`` from the previous ``AIMessage`` and resume
the CLI session.

Run with: ``uv run python examples/01_basic_invoke.py``
"""

from __future__ import annotations

import asyncio

from langchain_core.messages import HumanMessage, SystemMessage

from langchain_claude_agent_sdk import ChatClaudeAgent


def sync_single_turn() -> None:
    model = ChatClaudeAgent()

    response = model.invoke(
        [
            SystemMessage("You answer in exactly one sentence."),
            HumanMessage("What is asyncio useful for?"),
        ]
    )

    print("=== sync single-turn ===")
    print(response.content)
    print()
    print("usage:", response.usage_metadata)
    print("cost (USD):", response.response_metadata.get("total_cost_usd"))
    print("session:", response.response_metadata.get("session_id"))
    print()


async def async_multi_turn() -> None:
    model = ChatClaudeAgent()

    history = [
        SystemMessage("You answer in exactly one sentence."),
        HumanMessage("Define 'event loop' for a Python newcomer."),
    ]

    first = await model.ainvoke(history)
    print("=== async multi-turn — first turn ===")
    print(first.content)
    print()

    # Append the assistant turn and ask a follow-up. ChatClaudeAgent
    # reads session_id off `first.response_metadata` and resumes the
    # CLI session — prior turns are not re-billed.
    history.extend([first, HumanMessage("Give a one-line analogy.")])
    second = await model.ainvoke(history)
    print("=== async multi-turn — follow-up ===")
    print(second.content)
    print()
    print("resumed from session:", first.response_metadata.get("session_id"))


if __name__ == "__main__":
    sync_single_turn()
    asyncio.run(async_multi_turn())
