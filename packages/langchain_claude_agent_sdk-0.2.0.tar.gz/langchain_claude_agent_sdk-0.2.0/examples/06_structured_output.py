"""``with_structured_output`` — Pydantic, JSON schema, and include_raw.

``ChatClaudeAgent.with_structured_output(schema)`` returns a Runnable
that parses the model's reply against ``schema`` and hands back a typed
result. Because the Claude Agent SDK exposes no runtime knob to force a
specific tool call (every ``tool_choice`` value is accepted-and-ignored),
this override renders the schema into a leading ``SystemMessage`` and
parses the assistant's reply directly with ``PydanticOutputParser`` /
``JsonOutputParser`` — see ``_structured_output.py`` for the rationale.

This example shows three shapes:

1. Pydantic model class → parsed instance.
2. Bare JSON-schema dict → parsed dict.
3. ``include_raw=True`` → ``{"raw": AIMessage, "parsed": ..., "parsing_error": ...}``
   so you can inspect ``response_metadata`` (cost, session_id) and recover
   from parse failures.

Run with: ``uv run python examples/06_structured_output.py``
"""

from __future__ import annotations

import asyncio

from pydantic import BaseModel, Field

from langchain_claude_agent_sdk import ChatClaudeAgent


class StudyPlan(BaseModel):
    """A short curriculum for learning a topic."""

    topic: str = Field(description="Subject of the plan")
    steps: list[str] = Field(description="Ordered learning steps")
    estimated_hours: int = Field(description="Total hours to complete the plan")


def pydantic_path() -> None:
    print("=== Pydantic schema → parsed model instance ===")
    model = ChatClaudeAgent()
    structured = model.with_structured_output(StudyPlan)
    plan = structured.invoke("Plan three steps for studying FORTRAN.")
    assert isinstance(plan, StudyPlan)
    print(f"topic: {plan.topic}")
    print(f"steps: {plan.steps}")
    print(f"estimated_hours: {plan.estimated_hours}")
    print()


def dict_schema_path() -> None:
    print("=== Bare JSON schema dict → parsed dict ===")
    model = ChatClaudeAgent()
    schema: dict[str, object] = {
        "name": "WeatherReport",
        "description": "One-line current weather for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string"},
                "condition": {"type": "string"},
                "temperature_f": {"type": "number"},
            },
            "required": ["city", "condition", "temperature_f"],
        },
    }
    structured = model.with_structured_output(schema)
    report = structured.invoke("Give me a fictional weather report for Boston.")
    assert isinstance(report, dict)
    print(report)
    print()


async def include_raw_path() -> None:
    # `include_raw=True` returns the canonical
    # `{"raw": AIMessage, "parsed": Schema | None, "parsing_error": ... | None}`
    # so you can read CLI-only response_metadata extras alongside the parsed
    # result, and recover from parse failures yourself.
    print("=== include_raw=True → inspect cost + session_id alongside parsed model ===")
    model = ChatClaudeAgent()
    structured = model.with_structured_output(StudyPlan, include_raw=True)
    result = await structured.ainvoke("Plan two steps for learning to juggle.")
    assert isinstance(result, dict)
    print(f"parsed: {result['parsed']}")
    print(f"parsing_error: {result['parsing_error']}")
    print(f"session_id: {result['raw'].response_metadata.get('session_id')}")
    print(f"total_cost_usd: {result['raw'].response_metadata.get('total_cost_usd')}")


def main() -> None:
    pydantic_path()
    dict_schema_path()
    asyncio.run(include_raw_path())


if __name__ == "__main__":
    main()
