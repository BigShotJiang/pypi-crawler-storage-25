# Examples

Runnable examples for `langchain-claude-agent-sdk`.

## Prerequisites

1. The `claude` CLI installed and authenticated against your Anthropic
   account (`claude login` once). See the
   [Claude Code install docs](https://docs.claude.com/en/docs/claude-code).
2. Python 3.10 or newer.
3. This package and its examples extras:

   ```bash
   # From a clone:
   uv sync --extra dev --extra examples
   # From a published install:
   pip install "langchain-claude-agent-sdk[examples]"
   ```

The `examples` extra installs `langgraph`, which is only needed by
`05_langgraph_agent.py`. The other scripts run from a plain
`langchain-claude-agent-sdk` install.

## Running

Each example is a self-contained script. From the repo root:

```bash
uv run python examples/01_basic_invoke.py
uv run python examples/02_streaming.py
uv run python examples/03_builtin_tools.py
uv run python examples/04_custom_tools.py
uv run python examples/05_langgraph_agent.py
uv run python examples/06_structured_output.py
```

Every example hits the real `claude` CLI, so each call counts against your
local Claude authentication (Max/Pro subscription quota or API-key billing,
per Anthropic's pricing page).

## What each example shows

| Script | Demonstrates |
| --- | --- |
| `01_basic_invoke.py` | Sync and async single-turn invocation; reading `usage_metadata`, `response_metadata.session_id`, and `total_cost_usd`. |
| `02_streaming.py` | `astream()` with chunk-level iteration; folding chunks back into a complete `AIMessage`. |
| `03_builtin_tools.py` | `bind_tools(["WebSearch", "Read", ...])` for Claude Code's built-in tools — the CLI handles tool execution. |
| `04_custom_tools.py` | `bind_tools([my_basetool, my_pydantic_model])` for custom tools registered as in-process MCP — the SDK runs your handlers in-process. |
| `05_langgraph_agent.py` | Dropping `ChatClaudeAgent` into a LangGraph agent loop with no other changes. Requires the `examples` extra. |
| `06_structured_output.py` | `with_structured_output(schema)` for Pydantic, JSON-schema dict, and `include_raw=True` shapes. |

## Multi-turn state

Once you have an `AIMessage` from a previous invocation, pass the full
message history to the next call. The chat model extracts
`session_id` from the most recent `AIMessage.response_metadata` and uses
`ClaudeAgentOptions.resume=` to continue the CLI session rather than
re-billing prior turns. See `01_basic_invoke.py` for the pattern.
