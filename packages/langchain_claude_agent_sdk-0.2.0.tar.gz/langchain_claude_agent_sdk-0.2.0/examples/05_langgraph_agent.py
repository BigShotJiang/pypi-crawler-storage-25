"""ChatClaudeAgent inside a LangGraph agent.

The whole point of the spec-compliant ``AIMessage.tool_calls`` + populated
``usage_metadata`` work is that standard LangChain / LangGraph integrations
don't require any provider-specific shims. This example uses LangGraph's
prebuilt ReAct agent — it works with ``ChatClaudeAgent`` the same way it
works with ``ChatAnthropic`` or ``ChatOpenAI``.

Requires the ``examples`` extra (installs ``langgraph``):
    uv sync --extra examples
    # or, from a published install:
    pip install "langchain-claude-agent-sdk[examples]"

Run with: ``uv run python examples/05_langgraph_agent.py``
"""

from __future__ import annotations

from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

from langchain_claude_agent_sdk import ChatClaudeAgent


@tool
def get_weather(city: str) -> str:
    """Return a one-line weather report for a city."""
    # Stub: a real version would call a weather API.
    return f"{city}: 72°F and sunny, 5% chance of rain."


@tool
def add(a: int, b: int) -> int:
    """Add two integers."""
    return a + b


def main() -> None:
    model = ChatClaudeAgent()
    agent = create_react_agent(model, tools=[get_weather, add])

    result = agent.invoke(
        {
            "messages": [
                (
                    "user",
                    "What's the weather in Boston, and what is 17 + 25? Use the tools.",
                )
            ]
        }
    )

    print("=== final agent state ===")
    for message in result["messages"]:
        kind = message.__class__.__name__
        snippet = message.content if isinstance(message.content, str) else repr(message.content)
        print(f"[{kind}] {snippet[:200]}")


if __name__ == "__main__":
    main()
