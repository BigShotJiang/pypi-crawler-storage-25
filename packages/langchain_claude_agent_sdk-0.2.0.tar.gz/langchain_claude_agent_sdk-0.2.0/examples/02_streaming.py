"""Streaming responses with astream().

ChatClaudeAgent streams one chunk per Claude content block (text,
tool-use, or thinking). The final chunk carries ``usage_metadata`` and
the CLI-only ``response_metadata`` extras (session_id, total_cost_usd,
duration_ms, ...). Folding chunks back together yields the same
``AIMessage`` ``invoke()`` would have returned.

Run with: ``uv run python examples/02_streaming.py``
"""

from __future__ import annotations

import asyncio

from langchain_core.messages import AIMessageChunk, HumanMessage

from langchain_claude_agent_sdk import ChatClaudeAgent


async def stream_and_fold() -> None:
    model = ChatClaudeAgent()

    print("=== streaming ===")
    chunks: list[AIMessageChunk] = []
    async for chunk in model.astream([HumanMessage("List five fruits, one per line.")]):
        # Print text content as it arrives. Final chunk has empty content
        # but populates usage_metadata; skip its empty print.
        if chunk.content:
            print(chunk.content, end="", flush=True)
        chunks.append(chunk)
    print("\n")

    # Fold the chunks back into a single AIMessageChunk. This is exactly
    # what LangChain's outer machinery does for callers that don't want
    # to stream — the result is equivalent to invoke().
    folded = chunks[0]
    for c in chunks[1:]:
        folded = folded + c

    print("=== folded result ===")
    print("total tokens:", folded.usage_metadata)
    print("session:", folded.response_metadata.get("session_id"))
    print("cost (USD):", folded.response_metadata.get("total_cost_usd"))


if __name__ == "__main__":
    asyncio.run(stream_and_fold())
