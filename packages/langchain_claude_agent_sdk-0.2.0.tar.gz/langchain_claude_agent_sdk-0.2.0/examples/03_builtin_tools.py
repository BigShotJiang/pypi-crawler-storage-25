"""Built-in Claude Code tools via bind_tools().

Pass tool names as plain strings to ``bind_tools`` and the CLI runs them
in-process — you don't have to dispatch tool calls yourself. The
``AIMessage.tool_calls`` field still surfaces which tools were called and
with what arguments, for observability.

The full set of built-in tool names is documented in the
[Claude Code reference](https://docs.claude.com/en/docs/claude-code).
Common ones: ``WebSearch``, ``WebFetch``, ``Read``, ``Write``, ``Edit``,
``Bash``, ``Glob``, ``Grep``, ``Task``.

Run with: ``uv run python examples/03_builtin_tools.py``
"""

from __future__ import annotations

from langchain_core.messages import HumanMessage

from langchain_claude_agent_sdk import ChatClaudeAgent


def main() -> None:
    model = ChatClaudeAgent()

    # Give the model permission to read files and search with grep.
    bound = model.bind_tools(["Read", "Grep", "Glob"])

    response = bound.invoke(
        [HumanMessage("Summarize what PHASES.md says about Phase 6, in two sentences.")]
    )

    print("=== response ===")
    print(response.content)
    print()
    print("=== tool calls observed ===")
    for call in response.tool_calls:
        print(f"- {call['name']}({call['args']})")
    print()
    print("usage:", response.usage_metadata)
    print("cost (USD):", response.response_metadata.get("total_cost_usd"))


if __name__ == "__main__":
    main()
