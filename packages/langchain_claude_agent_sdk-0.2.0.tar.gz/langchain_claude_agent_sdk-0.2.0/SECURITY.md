# Security policy

We take the security of `langchain-claude-agent-sdk` and the people who use
it seriously. This document explains how to report vulnerabilities and what
to expect in return.

## Supported versions

Until a stable 1.0.0 release, **only the latest published version** receives
security fixes. Once 1.0.0 ships, this table will be updated to reflect the
supported release lines.

| Version | Supported |
| ------- | --------- |
| `0.x`   | Latest minor only |
| `< 0.x` | Not supported |

## Reporting a vulnerability

**Please do not open a public issue for vulnerabilities.** Public reports
expose users before a fix is available.

Report security issues by email to **brhodes@linux.com** with the
subject line **`SECURITY: langchain-claude-agent-sdk`**.

Include, at minimum:

- A description of the vulnerability and its potential impact.
- Steps to reproduce, ideally a minimal proof-of-concept.
- The affected version(s).
- Any suggested mitigations or fixes, if you have them.

You may encrypt your report with the maintainer's public key on request.

### What to expect

| Stage | Target timeline |
| --- | --- |
| Acknowledgement of receipt | within **3 business days** |
| Initial triage and severity assessment | within **7 business days** |
| Fix release for confirmed high/critical issues | within **30 days** of confirmation |
| Public disclosure | coordinated with reporter, typically **after a fix is released** |

Disclosure timelines may vary for low-severity issues or those that depend on
fixes in upstream projects (`claude-agent-sdk`, the `claude` CLI itself, or
`langchain-core`). The maintainer will keep you informed.

### Out of scope

The following are **not** vulnerabilities in this package; please direct
reports to the appropriate upstream:

- Bugs in the `claude` CLI, the Claude Agent SDK, or the Anthropic API:
  report to Anthropic (https://www.anthropic.com/responsible-disclosure-policy).
- Bugs in LangChain or LangGraph: report to LangChain
  (https://github.com/langchain-ai/langchain/security).
- Issues with a user's own model auth (`~/.claude/.credentials.json`),
  shell environment, or third-party MCP servers they configure.
- Behaviour that follows from the documented design — for example, that this
  package executes the `claude` CLI as a subprocess and inherits its
  permissions. (If you believe a documented behaviour represents an
  exploitable design flaw, do report it.)

## Credit

We will credit reporters in the relevant `CHANGELOG.md` entry and release
notes unless you ask to remain anonymous.

## Hardening guidance for downstream users

`ChatClaudeAgent` invokes a subprocess (`claude`) with whatever
authentication is on the host. Treat the process running this package the
same way you would treat any other process that can spend money against your
Anthropic auth:

- Run under a dedicated user account when used in unattended workflows.
- Avoid setting `permission_mode="bypassPermissions"` (or
  `extra_options={"permission_mode": "bypassPermissions"}`) in code paths
  that handle untrusted input.
- Be deliberate about `allowed_tools` — `Bash`, `Write`, and `Edit` are
  particularly powerful.
- If you operate in a regulated environment, review the
  [Billing and Terms of Service](./README.md#billing-and-terms-of-service)
  section of the README; this package is not a substitute for an Anthropic
  enterprise agreement.

### Multi-turn transcript fallback and prompt injection

`ChatClaudeAgent` has two paths for continuing a conversation:

1. **Session resume (preferred).** When the most recent `AIMessage` in the
   history carries `response_metadata["session_id"]` (which `to_ai_message`
   always populates), the next call resumes that CLI session and only the
   new messages are forwarded. The CLI keeps the real conversation state on
   its side, so prior turns — including tool results — are not re-serialized
   into the prompt. **This path is not affected by the issue below.**
2. **Transcript fallback.** For histories assembled without a `session_id`
   (for example, a hand-built `[Human, AI, Tool(web result), Human]`
   sequence), prior turns are serialized into a plain-text transcript
   prefix and prepended to the new user message. The format uses simple
   role labels (`User:`, `Assistant:`, `Tool[name]:`); content is not
   escaped or fenced.

The transcript fallback inherits the standard
[indirect prompt-injection](https://owasp.org/www-project-top-10-for-large-language-model-applications/)
risk: any prior message whose content is attacker-controlled (a fetched web
page, a tool result, a third-party search snippet) can include text that
looks like a new `User:` turn and steer the model. This is not a bug we
can fully fix from inside an LLM wrapper, but you can avoid it almost
entirely by **letting `ChatClaudeAgent` round-trip its own `AIMessage`s
through your history store** — LangGraph and `RunnableWithMessageHistory`
already do this, which keeps the `session_id` intact and routes every
follow-up through the session-resume path.

If you must build histories by hand and your application surfaces
untrusted text to the model, treat the transcript fallback as best-effort
for *continuity* only, not as a security boundary.
