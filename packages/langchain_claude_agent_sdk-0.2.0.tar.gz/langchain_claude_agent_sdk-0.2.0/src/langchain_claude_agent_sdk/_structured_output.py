"""JSON-schema-prompting implementation of ``with_structured_output``.

The Claude Agent SDK does not expose a runtime knob that constrains or
forces tool selection — every value passed to
``bind_tools(..., tool_choice=...)`` is accepted-and-ignored — so the
canonical ``BaseChatModel.with_structured_output`` path, which binds the
schema as a tool and trusts ``tool_choice="any"`` to force a call, fails
silently against the real CLI: the model receives the bound schema tool,
ignores it, replies with prose, and ``PydanticToolsParser`` returns
``None``.

Instead we render the schema as JSON into a leading ``SystemMessage`` and
parse the assistant's reply directly. The public surface
(:meth:`langchain_claude_agent_sdk.ChatClaudeAgent.with_structured_output`)
still matches the canonical signature (``schema``, ``include_raw``,
``method``, ``strict``, plus ``**kwargs`` validation), but every
``method`` routes through the same JSON-prompting impl because that's the
only path the SDK can deliver reliably.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from operator import itemgetter
from typing import Any

from langchain_core.language_models import LanguageModelInput
from langchain_core.messages import (
    BaseMessage,
    HumanMessage,
    SystemMessage,
    convert_to_messages,
)
from langchain_core.output_parsers import (
    BaseOutputParser,
    JsonOutputParser,
    PydanticOutputParser,
)
from langchain_core.prompt_values import PromptValue
from langchain_core.runnables import (
    Runnable,
    RunnableLambda,
    RunnableMap,
    RunnablePassthrough,
)
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_core.utils.pydantic import is_basemodel_subclass
from pydantic import BaseModel

# The format-instruction string is intentionally direct. Anthropic Claude
# models will write prose by default when not given a crisp constraint;
# the wording below is what empirically tips reliable adherence to a
# JSON-only reply (no preface, no fences, no trailing commentary).
_INSTRUCTIONS_TEMPLATE = """\
You MUST reply with ONLY a single JSON object that conforms to the JSON \
schema below. Do not include any prose, explanation, apologies, markdown, \
or code fences. Reply with the JSON object only — nothing before it and \
nothing after it.

JSON schema:
{schema}
"""


def build_structured_output_runnable(
    model: Runnable[LanguageModelInput, Any],
    schema: type[BaseModel] | dict[str, Any] | type,
    *,
    include_raw: bool,
) -> Runnable[LanguageModelInput, Any]:
    """Wrap ``model`` so its reply is parsed against ``schema``.

    Args:
        model: The chat model (or any ``AIMessage``-producing runnable)
            to wrap.
        schema: A Pydantic model class, a ``TypedDict``, a bare JSON
            schema ``dict``, or an OpenAI/Anthropic tool-spec ``dict``.
        include_raw: If ``True``, the returned runnable emits the
            canonical ``{"raw": AIMessage, "parsed": <schema>,
            "parsing_error": Exception | None}`` shape so the caller can
            inspect ``response_metadata`` (cost, session_id, ...) and
            recover from parse failures. If ``False``, the parsed
            schema instance is returned directly.

    Returns:
        A Runnable that converts ``LanguageModelInput`` into either the
        parsed schema (default) or the include-raw dict.
    """
    parser, schema_dict = _resolve_parser_and_schema(schema)
    instructions = _INSTRUCTIONS_TEMPLATE.format(
        schema=json.dumps(schema_dict, indent=2, sort_keys=True, ensure_ascii=False)
    )

    inject: Runnable[LanguageModelInput, list[BaseMessage]] = RunnableLambda(
        lambda inp: _inject_schema_instructions(inp, instructions),
        name="inject_json_schema_instructions",
    )
    chain_to_raw: Runnable[LanguageModelInput, Any] = inject | model

    if include_raw:
        # Matches BaseChatModel.with_structured_output's include_raw shape
        # so callers can swap providers without rewriting downstream code.
        parser_assign = RunnablePassthrough.assign(
            parsed=itemgetter("raw") | parser,
            parsing_error=lambda _: None,
        )
        parser_none = RunnablePassthrough.assign(parsed=lambda _: None)
        parser_with_fallback = parser_assign.with_fallbacks(
            [parser_none], exception_key="parsing_error"
        )
        return RunnableMap(raw=chain_to_raw) | parser_with_fallback
    return chain_to_raw | parser


def _resolve_parser_and_schema(
    schema: type[BaseModel] | dict[str, Any] | type,
) -> tuple[BaseOutputParser[Any], dict[str, Any]]:
    """Pick the right parser and extract the JSON schema for the prompt.

    Pydantic classes get a :class:`PydanticOutputParser` so the caller
    gets a validated model instance back. Everything else (``TypedDict``,
    bare JSON schema dict, OpenAI/Anthropic tool spec) is normalized
    through ``convert_to_openai_tool`` to recover the inner JSON schema
    and parsed with :class:`JsonOutputParser`, returning a ``dict``.
    """
    if isinstance(schema, type) and is_basemodel_subclass(schema):
        parser: BaseOutputParser[Any] = PydanticOutputParser(pydantic_object=schema)
        return parser, _pydantic_json_schema(schema)

    spec = convert_to_openai_tool(schema)
    schema_dict = spec.get("function", {}).get("parameters") or {}
    return JsonOutputParser(), schema_dict


def _pydantic_json_schema(klass: type[BaseModel]) -> dict[str, Any]:
    # ``pyproject.toml`` pins ``pydantic>=2.7.4``, so ``model_json_schema``
    # is always present. Caller-supplied field descriptions / defaults
    # survive verbatim into the rendered prompt.
    schema: dict[str, Any] = klass.model_json_schema()
    return schema


def _inject_schema_instructions(input: LanguageModelInput, instructions: str) -> list[BaseMessage]:
    """Insert a ``SystemMessage`` carrying the JSON instructions.

    The instructions go *after* any leading ``SystemMessage``s the caller
    already supplied so the JSON-only directive is the last system-level
    guidance the model reads before the conversation body — empirically
    improves adherence on Claude.
    """
    messages = _coerce_to_messages(input)
    insert_at = 0
    while insert_at < len(messages) and isinstance(messages[insert_at], SystemMessage):
        insert_at += 1
    return [
        *messages[:insert_at],
        SystemMessage(content=instructions),
        *messages[insert_at:],
    ]


def _coerce_to_messages(input: LanguageModelInput) -> list[BaseMessage]:
    """Normalize a ``LanguageModelInput`` into ``list[BaseMessage]``.

    Matches ``BaseChatModel._convert_input`` semantics so all the forms
    LangChain accepts upstream (bare strings, ``PromptValue``,
    ``(role, content)`` tuples, dicts) flow through cleanly.
    """
    if isinstance(input, str):
        return [HumanMessage(content=input)]
    if isinstance(input, PromptValue):
        return list(input.to_messages())
    if isinstance(input, Sequence):
        return list(convert_to_messages(input))
    msg = (
        "Unsupported input type for structured-output runnable: "
        f"{type(input).__name__}. Expected str, PromptValue, or Sequence."
    )
    raise TypeError(msg)
