"""ChatClaudeAgent: LangChain BaseChatModel backed by claude-agent-sdk."""

from __future__ import annotations

import asyncio
import dataclasses
import difflib
import logging
import subprocess
from collections.abc import AsyncIterator, Callable, Sequence
from typing import Any, Literal

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    CLINotFoundError,
    ResultMessage,
    query,
)
from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models import BaseChatModel, LanguageModelInput
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from langchain_claude_agent_sdk._messages import (
    PreparedPrompt,
    assistant_message_to_chunks,
    prepare_prompt,
    result_to_final_chunk,
    to_ai_message,
)
from langchain_claude_agent_sdk._structured_output import (
    build_structured_output_runnable,
)
from langchain_claude_agent_sdk._tools import (
    LANGCHAIN_TOOL_SERVER_NAME,
    build_mcp_server_from_tools,
)

logger = logging.getLogger(__name__)


# Kwarg keys under which ``bind_tools`` stashes per-binding state via
# ``self.bind(...)``. Picked to avoid colliding with any standard
# LangChain or harness kwarg.
_ALLOWED_TOOLS_KWARG = "allowed_tools"
_MCP_SERVERS_KWARG = "mcp_servers"

# Names of every field on ``ClaudeAgentOptions`` at import time. Used to
# validate ``extra_options`` keys at construction time so typos like
# ``permision_mode`` surface with a "did you mean" hint instead of an
# opaque dataclass TypeError at the first ``query()`` call. Pinning the
# SDK version (see ``pyproject.toml``) means this set is stable for any
# given install; bumping ``claude-agent-sdk`` refreshes it implicitly.
_VALID_CLAUDE_AGENT_OPTION_KEYS: frozenset[str] = frozenset(
    f.name for f in dataclasses.fields(ClaudeAgentOptions)
)

# Wall-clock limit for the ``claude --version`` pre-flight probe.
# Generous enough for cold-start NPM shims; short enough that an
# unreachable / hung CLI doesn't block model construction indefinitely.
_CLI_PROBE_TIMEOUT_SECONDS = 5.0


def _warn_stop_ignored(stop: list[str] | None) -> None:
    """Log a warning when ``stop`` would have a non-trivial effect.

    Empty list and ``None`` are intentionally silent — the standard
    ``langchain-tests`` harness invokes models with ``stop=[]`` by
    default, and ``None`` means "no constraint set."
    """
    if stop:
        logger.warning(
            "ChatClaudeAgent: `stop` sequences are not supported by the "
            "Claude Agent SDK and will be ignored. The model decides when "
            "to stop on its own. (Received: %r)",
            stop,
        )


def _warn_tool_choice_ignored(tool_choice: str | dict[str, Any] | None) -> None:
    """Log a warning when ``tool_choice`` would constrain selection.

    ``None`` and ``"auto"`` describe the SDK's actual behavior
    (model decides freely), so they're silent. Every other value —
    ``"any"``, ``"required"``, ``"none"``, ``{"type": "tool", ...}`` —
    expresses a constraint the canonical providers enforce but the
    Claude Agent SDK does not.
    """
    if tool_choice is None or tool_choice == "auto":
        return
    logger.warning(
        "ChatClaudeAgent.bind_tools: `tool_choice=%r` is accepted for "
        "signature parity with langchain-anthropic / langchain-openai, "
        "but the Claude Agent SDK has no runtime knob to constrain or "
        "force tool selection. The model will decide whether to call a "
        "tool on its own; use the system prompt for stronger guidance.",
        tool_choice,
    )


def _validate_cli() -> None:
    """Probe the ``claude`` CLI by running ``claude --version``.

    Surfaces install / availability problems at construction time
    rather than at the first ``invoke()`` call — see ollama's
    ``validate_model_on_init`` for the structural template
    (``langchain-ollama`` does the same thing against its HTTP server).

    Raises:
        CLINotFoundError: when the ``claude`` binary is not on PATH.
            Reuses the SDK's own exception type so downstream
            ``except CLINotFoundError`` handlers keep working
            regardless of which code path raised.
        RuntimeError: when the binary is present but the probe
            exits non-zero or times out.
    """
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            timeout=_CLI_PROBE_TIMEOUT_SECONDS,
            check=False,
            text=True,
        )
    except FileNotFoundError as exc:
        raise CLINotFoundError(
            "Claude Code CLI not found on PATH. Install with:\n"
            "  npm install -g @anthropic-ai/claude-code\n"
            "Then authenticate once with `claude login`. See "
            "https://docs.claude.com/en/docs/claude-code for details. "
            "Pass `validate_cli_on_init=False` to skip this pre-flight check."
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"`claude --version` probe timed out after "
            f"{_CLI_PROBE_TIMEOUT_SECONDS:g}s. Run `claude --version` from "
            "your shell to diagnose; the binary may be hung or extremely "
            "slow to start."
        ) from exc
    if result.returncode != 0:
        stderr = result.stderr.strip() or "<empty stderr>"
        raise RuntimeError(
            f"`claude --version` exited with status {result.returncode}. "
            f"stderr: {stderr}. Run `claude --version` from your shell to "
            "diagnose; the install may be corrupted."
        )


class ChatClaudeAgent(BaseChatModel):
    """LangChain chat model backed by Anthropic's Claude Agent SDK.

    Routes calls through the bundled ``claude`` CLI, so usage counts against
    the local user's Claude authentication (Max/Pro subscription or API key)
    rather than per-token API metering.

    Limitations to be aware of:

    - **Stop sequences are silently ignored.** The Claude Agent SDK's
      ``query()`` interface does not expose stop sequences; calls with
      ``stop=[...]`` proceed normally and the model decides where to stop on
      its own. Accepted for API compatibility, not honored.
    - **Sync ``invoke`` cannot run inside an active asyncio event loop.**
      The underlying SDK is async-only; the sync facade uses
      ``asyncio.run`` and raises ``RuntimeError`` if a loop is already
      running. From async contexts (LangGraph, FastAPI, Jupyter with
      ``%autoawait``) call ``ainvoke`` / ``astream`` directly.
    - **Multi-turn without a session id is lossy.** When a prior
      ``AIMessage`` in the history carries
      ``response_metadata['session_id']``, the next call resumes that CLI
      session and only the new messages are forwarded — full fidelity.
      Histories without a session id fall back to a plain-text transcript
      prefix, which is best-effort and not suitable for round-tripping
      tool-call / tool-result pairs precisely.
    - **Streaming granularity is per content block, not per token.** The
      Claude Agent SDK can be configured to emit raw token-level events
      (``ClaudeAgentOptions.include_partial_messages``); ``astream`` /
      ``stream`` currently yields one chunk per ``TextBlock`` /
      ``ToolUseBlock`` / ``ThinkingBlock`` instead. The final chunk
      carries ``usage_metadata`` and the CLI-only ``response_metadata``
      extras (``session_id``, ``total_cost_usd``, ``num_turns``, etc.).
    """

    # populate_by_name lets users pass either ``model="..."`` or
    # ``model_name="..."`` — the latter matches the constructor convention
    # used by langchain-anthropic (``model: str = Field(alias="model_name")``)
    # and langchain-openai, so callers migrating from those providers don't
    # need to rename their kwarg.
    model_config = ConfigDict(populate_by_name=True)

    model: str | None = Field(default=None, alias="model_name")
    """Model identifier to forward to the CLI (e.g. ``"claude-sonnet-4-6"``).
    ``None`` lets the CLI pick its default. Also accepts the kwarg name
    ``model_name`` for compatibility with other LangChain providers."""

    append_system_prompt: bool = True
    """If True, SystemMessage content is appended to Claude Code's default
    system prompt (preserving the tool-enabling preamble). If False, it
    *replaces* the default system prompt."""

    max_turns: int | None = None
    """Cap on the number of agent turns per call. ``None`` defers to the CLI."""

    cwd: str | None = None
    """Working directory the CLI runs in. ``None`` uses the current process cwd."""

    extra_options: dict[str, Any] = Field(default_factory=dict)
    """Escape hatch for any ``ClaudeAgentOptions`` field not exposed above.

    Keys are validated at construction time against the set of
    ``ClaudeAgentOptions`` field names from the pinned ``claude-agent-sdk``;
    a typo like ``permision_mode`` raises ``ValueError`` with a
    "did you mean" suggestion rather than silently flowing through to a
    later opaque dataclass ``TypeError``."""

    validate_cli_on_init: bool = False
    """If ``True``, run ``claude --version`` at construction time so a missing
    or broken CLI install fails fast with an actionable error
    (:class:`claude_agent_sdk.CLINotFoundError` with the install command, or
    :class:`RuntimeError` with the probe's stderr). Defaults to ``False`` —
    instantiation stays free of subprocess work, matching the cloud-provider
    norm (``langchain-anthropic`` / ``langchain-openai`` defer to first call).
    Opt in when the model is constructed far from where it's used (web
    application startup, test fixtures, long-lived workers) so the failure
    surfaces near the bad-install diagnostic, not deep in a request handler.

    Mirrors :class:`langchain_ollama.ChatOllama`'s ``validate_model_on_init``
    pattern — both packages target a local subsystem (CLI / HTTP daemon)
    where bad-install errors are a real first-time-user friction point."""

    @model_validator(mode="after")
    def _maybe_validate_cli(self) -> ChatClaudeAgent:
        # Runs after every field has been populated so the opt-in flag
        # can be set positionally or by alias before the probe fires.
        if self.validate_cli_on_init:
            _validate_cli()
        return self

    @field_validator("extra_options")
    @classmethod
    def _validate_extra_options_keys(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            return value
        unknown = sorted(k for k in value if k not in _VALID_CLAUDE_AGENT_OPTION_KEYS)
        if not unknown:
            return value
        suggestions: list[str] = []
        for key in unknown:
            close = difflib.get_close_matches(key, _VALID_CLAUDE_AGENT_OPTION_KEYS, n=1, cutoff=0.7)
            if close:
                suggestions.append(f"{key!r} (did you mean {close[0]!r}?)")
            else:
                suggestions.append(repr(key))
        raise ValueError(
            "extra_options contains keys not recognized by ClaudeAgentOptions: "
            + ", ".join(suggestions)
            + ". The valid key set is the field names on "
            "``claude_agent_sdk.ClaudeAgentOptions`` for the pinned SDK version."
        )

    @property
    def _llm_type(self) -> str:
        return "claude-agent"

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {"model": self.model}

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise RuntimeError(
                "ChatClaudeAgent._generate cannot run inside an active event loop; "
                "use ainvoke / _agenerate instead."
            )
        return asyncio.run(self._agenerate(messages, stop=stop, run_manager=None, **kwargs))

    async def _agenerate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: AsyncCallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        # `stop` is accepted for LangChain BaseChatModel compatibility but
        # silently ignored: the Claude Agent SDK's `query()` does not expose
        # stop sequences. Raising would block langchain-tests harness runs
        # and surprise callers who pass stop= uniformly across providers.
        # Emit a logger.warning (mistralai's pattern) so users notice without
        # the call failing — empty/None values stay quiet to avoid noise
        # from the standard harness's default `stop=[]`.
        _warn_stop_ignored(stop)

        prepared = prepare_prompt(messages)
        options = self._build_options(prepared, overrides=_options_from_kwargs(kwargs))
        prompt_text = self._build_prompt_text(prepared)

        assistant_messages: list[AssistantMessage] = []
        result_message: ResultMessage | None = None
        async for sdk_msg in query(prompt=prompt_text, options=options):
            if isinstance(sdk_msg, AssistantMessage):
                assistant_messages.append(sdk_msg)
            elif isinstance(sdk_msg, ResultMessage):
                result_message = sdk_msg

        ai_message = to_ai_message(assistant_messages, result_message)
        return ChatResult(generations=[ChatGeneration(message=ai_message)])

    async def _astream(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: AsyncCallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatGenerationChunk]:
        # Stop sequences are accepted-and-ignored, same as `_agenerate`.
        _warn_stop_ignored(stop)

        prepared = prepare_prompt(messages)
        options = self._build_options(prepared, overrides=_options_from_kwargs(kwargs))
        prompt_text = self._build_prompt_text(prepared)

        # Streaming granularity is one chunk per SDK content block
        # (TextBlock, ToolUseBlock, ThinkingBlock). True token-level
        # streaming is reachable by setting
        # ``ClaudeAgentOptions.include_partial_messages=True`` and
        # translating the resulting ``StreamEvent`` deltas — deferred to
        # a follow-up; block-level streaming is enough to satisfy the
        # standard-harness contract and to give callers visible
        # progress on multi-block agent runs.
        block_offset = 0
        async for sdk_msg in query(prompt=prompt_text, options=options):
            if isinstance(sdk_msg, AssistantMessage):
                for chunk in assistant_message_to_chunks(sdk_msg, base_index=block_offset):
                    if run_manager is not None:
                        await run_manager.on_llm_new_token(
                            chunk.content if isinstance(chunk.content, str) else "",
                            chunk=ChatGenerationChunk(message=chunk),
                        )
                    yield ChatGenerationChunk(message=chunk)
                block_offset += len(sdk_msg.content)
            elif isinstance(sdk_msg, ResultMessage):
                yield ChatGenerationChunk(message=result_to_final_chunk(sdk_msg))

    def bind_tools(
        self,
        tools: Sequence[str | dict[str, Any] | type[BaseModel] | Callable[..., Any] | BaseTool],
        *,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, AIMessage]:
        """Bind a set of tools the model is allowed to call.

        Accepts a mix of built-in tool names and custom tools, matching
        the ``langchain-anthropic`` / ``langchain-openai`` signature so
        callers don't need to rewrite anything when migrating.

        Tool-spec routing:

        - ``str`` entries are built-in Claude Code tool names
          (``"WebSearch"``, ``"WebFetch"``, ``"Read"``, ``"Write"``,
          ``"Edit"``, ``"Bash"``, ``"Glob"``, ``"Grep"``, ``"Task"``,
          ...). They land in ``ClaudeAgentOptions.allowed_tools``
          unmodified.
        - :class:`~langchain_core.tools.BaseTool` and bare callables are
          wrapped in an executable in-process MCP tool. The CLI will
          invoke ``BaseTool.ainvoke`` for each call and feed the result
          back into the conversation automatically.
        - Pydantic model classes and JSON-schema ``dict`` entries are
          wrapped in a schema-only MCP tool whose handler echoes the
          received args. They exist so the model can emit a structured
          call (for ``with_structured_output``-style patterns and for
          callers that intercept ``AIMessage.tool_calls`` themselves);
          the echo handler ensures the agent loop progresses
          deterministically rather than stalling on a missing backend.

        Custom tools are all grouped into a single in-process MCP server
        registered under ``"langchain-tools"``; the CLI references them
        with ``mcp__langchain-tools__<tool_name>`` patterns in
        ``allowed_tools``.

        Args:
            tools: A sequence of allowed-tool specs as described above.
            tool_choice: Best-effort hint to the model about which tool
                to pick. The Claude Agent SDK does not expose a runtime
                parameter that constrains or forces tool selection, so
                values other than ``None`` and ``"auto"`` are accepted
                but do not change CLI behavior. Provided for signature
                parity with the canonical providers; rely on the system
                prompt if you need stronger guidance.
            **kwargs: Additional kwargs forwarded to :meth:`bind`.

        Returns:
            A :class:`Runnable` whose every downstream invocation runs
            with ``allowed_tools`` and ``mcp_servers`` set to the
            resolved values.
        """
        _warn_tool_choice_ignored(tool_choice)

        builtin_tools: list[str] = []
        custom_tools: list[Any] = []
        for tool in tools:
            if isinstance(tool, str):
                builtin_tools.append(tool)
            else:
                custom_tools.append(tool)

        allowed_tools: list[str] = list(builtin_tools)
        mcp_servers: dict[str, Any] = {}
        if custom_tools:
            server, mcp_allowed = build_mcp_server_from_tools(custom_tools)
            mcp_servers[LANGCHAIN_TOOL_SERVER_NAME] = server
            allowed_tools.extend(mcp_allowed)

        return self.bind(
            **{
                _ALLOWED_TOOLS_KWARG: allowed_tools,
                _MCP_SERVERS_KWARG: mcp_servers,
            },
            **kwargs,
        )

    def with_structured_output(
        self,
        schema: dict[str, Any] | type | None = None,
        *,
        include_raw: bool = False,
        method: Literal["function_calling", "json_mode", "json_schema"] = "json_schema",
        strict: bool | None = None,
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, dict[str, Any] | BaseModel]:
        """Return a Runnable that parses model output against ``schema``.

        Overrides :meth:`BaseChatModel.with_structured_output`. The
        canonical default binds ``schema`` as a tool and trusts
        ``tool_choice="any"`` to force a call, then parses the resulting
        ``tool_calls`` — but the Claude Agent SDK exposes no runtime knob
        to constrain or force tool selection (every value passed to
        ``bind_tools(..., tool_choice=...)`` is accepted-and-ignored). The
        net effect against the real CLI is the model ignores the bound
        schema tool, replies with prose, and ``PydanticToolsParser``
        returns ``None``.

        This override sidesteps the unenforceable tool path entirely:
        ``schema`` is rendered into a leading ``SystemMessage`` and the
        assistant's reply is parsed directly with
        :class:`PydanticOutputParser` (Pydantic schemas) or
        :class:`JsonOutputParser` (dict / TypedDict / tool-spec schemas).

        Args:
            schema: A Pydantic model class, ``TypedDict``, bare JSON
                schema ``dict``, or OpenAI/Anthropic tool-spec ``dict``.
            include_raw: If ``True``, the returned Runnable emits the
                canonical ``{"raw": AIMessage, "parsed": <schema>,
                "parsing_error": Exception | None}`` shape so callers can
                inspect ``response_metadata`` (cost, session_id, ...)
                and recover from parse failures. If ``False``, the parsed
                schema instance is returned directly.
            method: Accepted for signature parity with
                ``langchain-anthropic`` / ``langchain-openai``. All values
                route through the same JSON-prompting impl — there is no
                ``function_calling`` path the SDK can deliver reliably.
            strict: Accepted for signature parity. The SDK exposes no
                strict-decoding flag; treated as a no-op.
            **kwargs: Disallowed. Raises ``ValueError`` to surface
                accidental typos, matching the canonical default.

        Returns:
            A Runnable producing a parsed schema instance (Pydantic
            schemas) or a ``dict`` (non-Pydantic schemas) — or, if
            ``include_raw=True``, the canonical raw/parsed dict.
        """
        if schema is None:
            raise ValueError("with_structured_output requires a non-None schema argument.")
        # See docstring — accepted-and-ignored for signature parity with
        # the canonical providers; the SDK has no equivalent runtime knob.
        _ = method
        _ = strict
        if kwargs:
            raise ValueError(f"Received unsupported arguments {kwargs}")
        return build_structured_output_runnable(self, schema, include_raw=include_raw)

    def _build_options(
        self,
        prepared: PreparedPrompt,
        *,
        overrides: dict[str, Any] | None = None,
    ) -> ClaudeAgentOptions:
        fields: dict[str, Any] = {}
        if self.model is not None:
            fields["model"] = self.model
        if self.max_turns is not None:
            fields["max_turns"] = self.max_turns
        if self.cwd is not None:
            fields["cwd"] = self.cwd
        if prepared.resume_session_id is not None:
            fields["resume"] = prepared.resume_session_id
        if prepared.system_text is not None:
            if self.append_system_prompt:
                fields["system_prompt"] = {
                    "type": "preset",
                    "preset": "claude_code",
                    "append": prepared.system_text,
                }
            else:
                fields["system_prompt"] = prepared.system_text
        _merge_options(fields, self.extra_options)
        if overrides:
            _merge_options(fields, overrides)
        return ClaudeAgentOptions(**fields)

    @staticmethod
    def _build_prompt_text(prepared: PreparedPrompt) -> str:
        if prepared.transcript_prefix:
            return f"{prepared.transcript_prefix}\n\nUser: {prepared.new_user_text}"
        return prepared.new_user_text


def _merge_options(fields: dict[str, Any], layer: dict[str, Any]) -> None:
    """Layer ``layer`` on top of ``fields`` in place.

    Dict-typed ``ClaudeAgentOptions`` fields (currently ``mcp_servers``)
    are *merged* per-key so a user-provided MCP server (via
    ``extra_options``) and a binding-provided one (via ``bind_tools``)
    coexist instead of one wholesale-replacing the other. All other
    keys overwrite (the layer wins).
    """
    for key, value in layer.items():
        if key == _MCP_SERVERS_KWARG and isinstance(value, dict):
            merged = dict(fields.get(_MCP_SERVERS_KWARG) or {})
            merged.update(value)
            fields[_MCP_SERVERS_KWARG] = merged
        else:
            fields[key] = value


def _options_from_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Extract per-call ClaudeAgentOptions overrides from runtime kwargs.

    LangChain's ``Runnable.bind(...)`` stashes bound kwargs (e.g. those
    set by ``ChatClaudeAgent.bind_tools``) and forwards them through
    ``invoke`` / ``astream`` into ``_agenerate`` / ``_astream`` as
    ``**kwargs``. We pluck out the ones that map onto
    ``ClaudeAgentOptions`` fields so they take precedence over the
    instance-level configuration:

    - ``allowed_tools``: the list of built-in and ``mcp__...``-qualified
      tool names the model is permitted to call.
    - ``mcp_servers``: the dict of in-process MCP servers registered for
      this binding. Merged with any user-provided servers in
      ``ChatClaudeAgent.extra_options`` (bound value wins on key
      collision).
    """
    overrides: dict[str, Any] = {}
    allowed_tools = kwargs.get(_ALLOWED_TOOLS_KWARG)
    if allowed_tools is not None:
        overrides[_ALLOWED_TOOLS_KWARG] = list(allowed_tools)
    mcp_servers = kwargs.get(_MCP_SERVERS_KWARG)
    if mcp_servers:
        overrides[_MCP_SERVERS_KWARG] = dict(mcp_servers)
    return overrides
