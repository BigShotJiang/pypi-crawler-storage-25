"""Translation between LangChain messages and the Claude Agent SDK wire format."""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any, TypedDict

from claude_agent_sdk import (
    AssistantMessage,
    ResultMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
)
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.messages.ai import InputTokenDetails, UsageMetadata
from langchain_core.messages.tool import ToolCall, ToolCallChunk


class ClaudeAgentResponseMetadata(TypedDict, total=False):
    """Typed view of the ``response_metadata`` dict ``ChatClaudeAgent`` produces.

    LangChain's :attr:`AIMessage.response_metadata` is typed as
    ``dict[str, Any]``, so this ``TypedDict`` is for *callers* who want
    static-checked field access without spelunking the README. Use it via
    ``typing.cast`` or assign it as an annotation:

    .. code-block:: python

        from typing import cast
        from langchain_claude_agent_sdk import ClaudeAgentResponseMetadata

        response = model.invoke([HumanMessage("hi")])
        meta = cast(ClaudeAgentResponseMetadata, response.response_metadata)
        print(meta["session_id"])  # IDE autocomplete works here

    Every key is declared ``total=False`` because the CLI doesn't populate
    every field on every reply (e.g. ``thinking`` only appears when the
    model returns thinking blocks; ``is_error`` only when the run failed).

    Keys (and their sources):

    - ``session_id``: CLI session id; pass into the next call's history
      to resume rather than re-bill prior turns.
    - ``total_cost_usd``: Anthropic-billed cost for this turn.
    - ``num_turns``: agent turns the CLI took (>=1).
    - ``duration_ms``, ``duration_api_ms``: wall-clock and API-only
      durations in milliseconds.
    - ``stop_reason``: ``"end_turn"`` / ``"max_tokens"`` / etc.
    - ``model_name``: the model the CLI actually used (may differ from
      what you requested if the CLI fell back).
    - ``thinking``: list of ``{"thinking": str, "signature": str}``
      dicts preserved from any ``ThinkingBlock``s in the reply.
    - ``is_error``: present and ``True`` when the run failed; absent
      otherwise (so a falsy check is safe).
    """

    session_id: str
    total_cost_usd: float
    num_turns: int
    duration_ms: int
    duration_api_ms: int
    stop_reason: str
    model_name: str
    thinking: list[dict[str, str]]
    is_error: bool


@dataclass(frozen=True)
class PreparedPrompt:
    """The pieces a chat-model call needs after translating LangChain inputs.

    ``system_text`` is the concatenation of leading SystemMessage content (if any).
    ``new_user_text`` is the new user turn to send.
    ``resume_session_id`` is the session_id to resume from when continuing a
    prior conversation (extracted from the last AIMessage.response_metadata).
    ``transcript_prefix`` is a textual replay of prior turns prepended to the
    new user message when no resume session is available — a fallback so
    arbitrarily-constructed histories still round-trip something coherent.
    """

    system_text: str | None
    new_user_text: str
    resume_session_id: str | None
    transcript_prefix: str | None


def prepare_prompt(messages: list[BaseMessage]) -> PreparedPrompt:
    """Translate a LangChain message list into the shape the SDK call needs."""
    if not messages:
        raise ValueError("ChatClaudeAgent requires at least one message.")

    system_chunks: list[str] = []
    i = 0
    while i < len(messages) and isinstance(messages[i], SystemMessage):
        system_chunks.append(_text_of(messages[i]))
        i += 1
    system_text = "\n\n".join(s for s in system_chunks if s) or None

    body = messages[i:]
    if not body:
        raise ValueError(
            "ChatClaudeAgent requires at least one non-system message; got only SystemMessages."
        )

    last_ai_session: str | None = None
    last_ai_index: int = -1
    for j, msg in enumerate(body):
        if isinstance(msg, AIMessage):
            session_id = msg.response_metadata.get("session_id") if msg.response_metadata else None
            if isinstance(session_id, str) and session_id:
                last_ai_session = session_id
                last_ai_index = j

    if last_ai_session is not None:
        tail = body[last_ai_index + 1 :]
        new_user_text = _join_user_turns(tail)
        if not new_user_text:
            raise ValueError("No new user input after the most recent AIMessage; nothing to send.")
        return PreparedPrompt(
            system_text=system_text,
            new_user_text=new_user_text,
            resume_session_id=last_ai_session,
            transcript_prefix=None,
        )

    if len(body) == 1 and isinstance(body[0], HumanMessage):
        return PreparedPrompt(
            system_text=system_text,
            new_user_text=_text_of(body[0]),
            resume_session_id=None,
            transcript_prefix=None,
        )

    last_human_idx = _last_human_index(body)
    if last_human_idx < 0:
        raise ValueError("Conversation must end with a HumanMessage to send to Claude.")

    transcript = _format_transcript(body[:last_human_idx])
    new_user_text = _join_user_turns(body[last_human_idx:])
    return PreparedPrompt(
        system_text=system_text,
        new_user_text=new_user_text,
        resume_session_id=None,
        transcript_prefix=transcript or None,
    )


def to_ai_message(
    assistant_messages: list[AssistantMessage],
    result: ResultMessage | None,
) -> AIMessage:
    """Fold one or more SDK AssistantMessages plus the terminal ResultMessage
    into a single LangChain AIMessage."""
    text_parts: list[str] = []
    tool_calls: list[ToolCall] = []
    thinking_blocks: list[dict[str, str]] = []
    model_name: str | None = None
    message_id: str | None = None
    stop_reason: str | None = None

    for am in assistant_messages:
        if model_name is None:
            model_name = am.model
        if message_id is None:
            message_id = am.message_id
        if am.stop_reason:
            stop_reason = am.stop_reason
        for block in am.content:
            if isinstance(block, TextBlock):
                text_parts.append(block.text)
            elif isinstance(block, ToolUseBlock):
                tool_calls.append(
                    ToolCall(
                        name=block.name,
                        args=dict(block.input) if isinstance(block.input, dict) else {},
                        id=block.id,
                        type="tool_call",
                    )
                )
            elif isinstance(block, ThinkingBlock):
                thinking_blocks.append({"thinking": block.thinking, "signature": block.signature})

    content = "".join(text_parts)
    response_metadata: dict[str, Any] = {}
    if model_name:
        response_metadata["model_name"] = model_name
    if stop_reason:
        response_metadata["stop_reason"] = stop_reason
    if thinking_blocks:
        response_metadata["thinking"] = thinking_blocks

    usage_metadata: UsageMetadata | None = None
    if result is not None:
        response_metadata.update(_result_response_metadata(result))
        usage_metadata = _build_usage_metadata(result.usage)

    return AIMessage(
        content=content,
        id=message_id,
        tool_calls=tool_calls,
        response_metadata=response_metadata,
        usage_metadata=usage_metadata,
    )


def assistant_message_to_chunks(
    assistant_message: AssistantMessage,
    *,
    base_index: int = 0,
) -> Iterator[AIMessageChunk]:
    """Yield one :class:`AIMessageChunk` per content block in an SDK
    ``AssistantMessage`` for the streaming path.

    ``base_index`` is the starting block index for any tool-call chunks so
    that chunks from consecutive AssistantMessages within a single agent
    run accumulate correctly via ``AIMessageChunk.__add__`` — the caller
    should pass the running count of blocks already emitted.

    Per the LangChain streaming contract:

    - ``TextBlock`` becomes a chunk with the block's text as ``content``.
    - ``ToolUseBlock`` becomes a chunk with a single
      :class:`ToolCallChunk`. The full tool call is emitted in one shot
      (we don't stream partial JSON deltas) — the SDK exposes the
      complete ``input`` dict by the time the AssistantMessage arrives.
    - ``ThinkingBlock`` becomes a chunk whose ``response_metadata`` adds
      a ``thinking`` entry; merging multiple thinking blocks across
      chunks accumulates them naturally.

    The first chunk yielded for the message also carries ``model_name``
    (and the message ``id``) on its metadata so consumers learn the model
    immediately, without waiting for the terminal chunk. Subsequent
    chunks omit them so they don't get re-overwritten on merge.
    """
    first_chunk = True
    for offset, block in enumerate(assistant_message.content):
        response_metadata: dict[str, Any] = {}
        if first_chunk:
            if assistant_message.model:
                response_metadata["model_name"] = assistant_message.model
            first_chunk = False
        chunk_id = assistant_message.message_id if offset == 0 else None

        if isinstance(block, TextBlock):
            yield AIMessageChunk(
                content=block.text,
                id=chunk_id,
                response_metadata=response_metadata,
            )
        elif isinstance(block, ToolUseBlock):
            args_json = json.dumps(block.input) if isinstance(block.input, dict) else "{}"
            yield AIMessageChunk(
                content="",
                id=chunk_id,
                tool_call_chunks=[
                    ToolCallChunk(
                        name=block.name,
                        args=args_json,
                        id=block.id,
                        index=base_index + offset,
                        type="tool_call_chunk",
                    )
                ],
                response_metadata=response_metadata,
            )
        elif isinstance(block, ThinkingBlock):
            response_metadata["thinking"] = [
                {"thinking": block.thinking, "signature": block.signature}
            ]
            yield AIMessageChunk(
                content="",
                id=chunk_id,
                response_metadata=response_metadata,
            )


def result_to_final_chunk(result: ResultMessage) -> AIMessageChunk:
    """Build the terminal :class:`AIMessageChunk` for the streaming path.

    Carries the CLI-only ``response_metadata`` extras (``session_id``,
    ``total_cost_usd``, ``num_turns``, ``duration_ms``, etc.) and the
    final ``usage_metadata`` folded from ``ResultMessage.usage`` (with
    cache buckets matched into the LangChain ``UsageMetadata`` contract).
    The chunk's ``content`` is empty so it doesn't double-count any text
    already streamed via prior block chunks.
    """
    # Widen the TypedDict to plain dict[str, Any] for the AIMessageChunk
    # contract — TypedDicts aren't invariantly assignable to dict[Any, Any]
    # under mypy --strict even though they're dicts at runtime.
    metadata: dict[str, Any] = dict(_result_response_metadata(result))
    return AIMessageChunk(
        content="",
        response_metadata=metadata,
        usage_metadata=_build_usage_metadata(result.usage),
    )


def _result_response_metadata(result: ResultMessage) -> ClaudeAgentResponseMetadata:
    """Pull CLI-only fields off a ``ResultMessage`` into a metadata dict.

    Used by both the non-streaming (``to_ai_message``) and streaming
    (``result_to_final_chunk``) paths so the response_metadata surface
    is identical regardless of how the model was invoked. Return type
    is :class:`ClaudeAgentResponseMetadata` so callers who cast the
    dict get IDE / mypy field-name help.
    """
    metadata: ClaudeAgentResponseMetadata = {}
    if result.session_id:
        metadata["session_id"] = result.session_id
    if result.total_cost_usd is not None:
        metadata["total_cost_usd"] = result.total_cost_usd
    if result.num_turns is not None:
        metadata["num_turns"] = result.num_turns
    if result.duration_ms is not None:
        metadata["duration_ms"] = result.duration_ms
    if result.duration_api_ms is not None:
        metadata["duration_api_ms"] = result.duration_api_ms
    if result.stop_reason:
        metadata["stop_reason"] = result.stop_reason
    if result.is_error:
        metadata["is_error"] = True
    return metadata


def _text_of(message: BaseMessage) -> str:
    content = message.content
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                block_type = block.get("type")
                if block_type == "text":
                    parts.append(str(block.get("text", "")))
                else:
                    raise ValueError(
                        f"ChatClaudeAgent received an unsupported content block of "
                        f"type {block_type!r} on a {type(message).__name__}. The Claude "
                        "Agent SDK routes messages through the `claude` CLI as plain "
                        "text, so only string content and 'text'-typed blocks are "
                        "forwarded. Image / multimodal blocks are not yet supported."
                    )
            else:
                raise ValueError(
                    f"ChatClaudeAgent received an unsupported content block of type "
                    f"{type(block).__name__} on a {type(message).__name__}. Expected "
                    "str or a dict with 'type': 'text'."
                )
        return "".join(parts)
    return str(content)


def _join_user_turns(msgs: list[BaseMessage]) -> str:
    chunks: list[str] = []
    for m in msgs:
        if isinstance(m, HumanMessage):
            chunks.append(_text_of(m))
        elif isinstance(m, ToolMessage):
            chunks.append(f"[tool {m.name or m.tool_call_id} result]\n{_text_of(m)}")
    return "\n\n".join(c for c in chunks if c)


def _last_human_index(msgs: list[BaseMessage]) -> int:
    for j in range(len(msgs) - 1, -1, -1):
        if isinstance(msgs[j], HumanMessage):
            return j
    return -1


def _format_transcript(msgs: list[BaseMessage]) -> str:
    lines: list[str] = []
    for m in msgs:
        if isinstance(m, HumanMessage):
            lines.append(f"User: {_text_of(m)}")
        elif isinstance(m, AIMessage):
            text = _text_of(m)
            if text:
                lines.append(f"Assistant: {text}")
            for tc in m.tool_calls or []:
                lines.append(f"Assistant tool call {tc.get('name')}({tc.get('args')!r})")
        elif isinstance(m, ToolMessage):
            lines.append(f"Tool[{m.name or m.tool_call_id}]: {_text_of(m)}")
    return "\n".join(lines)


def _build_usage_metadata(usage: dict[str, Any] | None) -> UsageMetadata | None:
    if not usage:
        return None
    # Anthropic reports `input_tokens` as the *non-cached* portion of input.
    # The LangChain UsageMetadata contract expects `input_tokens` to be the
    # full input bill, with cached portions broken out under
    # `input_token_details`. Fold the buckets back in to match that contract,
    # matching langchain-anthropic's accounting.
    base_input_tokens = int(usage.get("input_tokens", 0) or 0)
    output_tokens = int(usage.get("output_tokens", 0) or 0)
    cache_creation = int(usage.get("cache_creation_input_tokens", 0) or 0)
    cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)

    full_input_tokens = base_input_tokens + cache_creation + cache_read
    metadata: UsageMetadata = UsageMetadata(
        input_tokens=full_input_tokens,
        output_tokens=output_tokens,
        total_tokens=full_input_tokens + output_tokens,
    )
    if cache_creation or cache_read:
        metadata["input_token_details"] = InputTokenDetails(
            audio=0,
            cache_creation=cache_creation,
            cache_read=cache_read,
        )
    return metadata
