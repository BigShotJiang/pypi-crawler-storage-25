"""Convert LangChain-style tool specs into Claude Agent SDK MCP tools.

Custom tools (anything that isn't a built-in Claude Code tool name) are
exposed to the CLI via an in-process MCP server. Each call to
``ChatClaudeAgent.bind_tools`` builds one server (named
``LANGCHAIN_TOOL_SERVER_NAME``) holding every custom tool, then references
the tools from ``ClaudeAgentOptions.allowed_tools`` using the canonical
``mcp__<server>__<tool>`` pattern.

The four supported input shapes — matching the ``Sequence[str | dict |
type[BaseModel] | Callable | BaseTool]`` signature ``bind_tools`` exposes:

- :class:`BaseTool` and bare callables are wrapped in an *executable*
  handler that calls ``BaseTool.ainvoke``. The model's tool calls run
  to completion inside the CLI subprocess and the result is fed back
  into the conversation automatically.
- Pydantic model classes and JSON-schema ``dict`` entries are wrapped
  in an *echo* handler that returns the args as JSON. They exist so
  the model can *emit* a structured call (for ``with_structured_output``
  patterns and for callers that intercept ``AIMessage.tool_calls``
  themselves); there is no callable backend to invoke, so the handler
  simply records the call shape.

This module is private. ``ChatClaudeAgent.bind_tools`` is the only
public entry point.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

from claude_agent_sdk import McpSdkServerConfig, SdkMcpTool, create_sdk_mcp_server
from langchain_core.tools import BaseTool
from langchain_core.tools import tool as _tool_decorator
from langchain_core.utils.function_calling import convert_to_openai_tool
from pydantic import BaseModel

# Single canonical MCP server name for every custom tool bound to a
# ChatClaudeAgent instance. The CLI references tools through this server
# under the ``mcp__langchain-tools__<tool_name>`` pattern.
LANGCHAIN_TOOL_SERVER_NAME = "langchain-tools"

# Server version reported to the SDK. Informational only; bump
# deliberately if downstream tooling ever needs to discriminate.
LANGCHAIN_TOOL_SERVER_VERSION = "1.0.0"


def build_mcp_server_from_tools(
    tools: Sequence[Any],
) -> tuple[McpSdkServerConfig, list[str]]:
    """Wrap LangChain-style tools into a single in-process MCP server.

    Args:
        tools: A sequence of :class:`BaseTool`, callable, Pydantic model
            class, or JSON-schema ``dict`` entries. (Plain ``str``
            entries are handled separately in ``bind_tools`` as built-in
            tool names and should not reach this function.)

    Returns:
        A tuple of:

        - ``McpSdkServerConfig`` ready to slot into
          ``ClaudeAgentOptions.mcp_servers`` under the key
          ``LANGCHAIN_TOOL_SERVER_NAME``.
        - The list of fully-qualified allowed-tool names
          (``mcp__langchain-tools__<tool_name>``) to merge into
          ``ClaudeAgentOptions.allowed_tools``.
    """
    sdk_tools = [_normalize_tool(t) for t in tools]
    server = create_sdk_mcp_server(
        name=LANGCHAIN_TOOL_SERVER_NAME,
        version=LANGCHAIN_TOOL_SERVER_VERSION,
        tools=sdk_tools,
    )
    allowed = [qualified_tool_name(t.name) for t in sdk_tools]
    return server, allowed


def qualified_tool_name(tool_name: str) -> str:
    """Return the MCP ``allowed_tools`` identifier for a bound tool."""
    return f"mcp__{LANGCHAIN_TOOL_SERVER_NAME}__{tool_name}"


def _normalize_tool(t: Any) -> SdkMcpTool[Any]:
    """Dispatch a tool spec to its type-specific converter."""
    if isinstance(t, BaseTool):
        return _basetool_to_sdk(t)
    if isinstance(t, type) and issubclass(t, BaseModel):
        return _pydantic_class_to_sdk(t)
    if isinstance(t, dict):
        return _dict_schema_to_sdk(t)
    if callable(t):
        return _callable_to_sdk(t)
    raise TypeError(
        f"Unsupported tool type for ChatClaudeAgent.bind_tools: "
        f"{type(t).__name__}. Expected str (built-in tool name), BaseTool, "
        f"callable, Pydantic model class, or JSON-schema dict."
    )


def _basetool_to_sdk(t: BaseTool) -> SdkMcpTool[Any]:
    return SdkMcpTool(
        name=t.name,
        description=t.description or t.name,
        input_schema=_extract_schema(t.args_schema),
        handler=_make_basetool_handler(t),
    )


def _callable_to_sdk(fn: Callable[..., Any]) -> SdkMcpTool[Any]:
    return _basetool_to_sdk(_tool_decorator(fn))


def _pydantic_class_to_sdk(klass: type[BaseModel]) -> SdkMcpTool[Any]:
    schema = _extract_schema(klass)
    name = klass.__name__
    description = (klass.__doc__ or schema.get("description") or name).strip()
    return SdkMcpTool(
        name=name,
        description=description,
        input_schema=schema,
        handler=_make_echo_handler(),
    )


def _dict_schema_to_sdk(d: dict[str, Any]) -> SdkMcpTool[Any]:
    # Use convert_to_openai_tool to normalize whatever shape the caller
    # passed (bare schema, OpenAI function-spec dict, Anthropic tool-spec
    # dict) into the OpenAI function-spec we can read predictably.
    name: str
    description: str
    schema: dict[str, Any]
    try:
        spec = convert_to_openai_tool(d)
    except Exception:
        spec = None
    if spec and "function" in spec:
        fn_spec = spec["function"]
        name = fn_spec.get("name") or d.get("name") or "tool"
        description = fn_spec.get("description") or d.get("description") or name
        schema = fn_spec.get("parameters") or {}
    else:
        name = d.get("name") or "tool"
        description = d.get("description") or name
        schema = d.get("parameters") or d.get("input_schema") or {}
    return SdkMcpTool(
        name=name,
        description=description,
        input_schema=schema or {"type": "object", "properties": {}},
        handler=_make_echo_handler(),
    )


def _extract_schema(schema_class: Any) -> dict[str, Any]:
    if schema_class is None:
        return {"type": "object", "properties": {}}
    if isinstance(schema_class, dict):
        return schema_class
    # Pydantic v2 → model_json_schema; v1 → schema. Defensive: both can
    # raise if the model uses unsupported types.
    if hasattr(schema_class, "model_json_schema"):
        try:
            schema: dict[str, Any] = schema_class.model_json_schema()
            return schema
        except Exception:
            return {"type": "object", "properties": {}}
    if hasattr(schema_class, "schema"):
        try:
            schema_v1: dict[str, Any] = schema_class.schema()
            return schema_v1
        except Exception:
            return {"type": "object", "properties": {}}
    return {"type": "object", "properties": {}}


def _make_basetool_handler(
    tool: BaseTool,
) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
    """Build an MCP handler that runs a ``BaseTool`` via ``ainvoke``.

    Returns ``{"content": [...], "is_error": True}`` on exception so the
    model sees the failure and can recover instead of the whole agent
    run crashing.
    """

    async def handler(args: dict[str, Any]) -> dict[str, Any]:
        try:
            result = await tool.ainvoke(args)
        except Exception as exc:
            return {
                "content": [{"type": "text", "text": str(exc)}],
                "is_error": True,
            }
        if isinstance(result, str):
            text = result
        else:
            try:
                text = json.dumps(result, default=str)
            except (TypeError, ValueError):
                text = str(result)
        return {"content": [{"type": "text", "text": text}]}

    return handler


def _make_echo_handler() -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
    """Build an MCP handler that echoes args as JSON.

    Used for schema-only tools (Pydantic classes, dict schemas) that
    have no executable backend. The model emits the structured call
    and the handler records the shape so the agent loop progresses
    deterministically rather than stalling on a missing handler.
    """

    async def handler(args: dict[str, Any]) -> dict[str, Any]:
        return {"content": [{"type": "text", "text": json.dumps(args, default=str)}]}

    return handler
