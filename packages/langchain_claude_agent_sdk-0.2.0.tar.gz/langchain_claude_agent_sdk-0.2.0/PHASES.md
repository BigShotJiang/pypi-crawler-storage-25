# Implementation Phases

Phase tracker for `langchain-claude-agent-sdk`. Source of truth for "what's done,
what's next" across Claude Code sessions. Update statuses as phases complete.

See `README.md` for the user-facing pitch and `DESIGN.md` for the historical
design exploration that preceded this package.

## Project shape (reminder)

Single Python package, `langchain-claude-agent-sdk`, that exposes a LangChain
`ChatClaudeAgent(BaseChatModel)` built on top of Anthropic's official
`claude-agent-sdk` Python package. Routes calls through the bundled `claude`
CLI so usage counts against the user's local Claude auth (Max/Pro subscription
or API key) rather than per-token API billing.

## Phase status

| #   | Phase                                                       | Status      |
| --- | ----------------------------------------------------------- | ----------- |
| 0   | Repo scaffolding (pyproject, src layout, ruff, mypy, tests) | **DONE**    |
| 1   | Standalone `claude-code` CLI-wrapper package                | **SKIPPED** |
| 2   | Multi-turn over `--input-format stream-json`                | **SKIPPED** |
| 3   | `_generate` / `_agenerate` + system messages + usage        | **DONE**    |
| 4   | `_stream` / `_astream`                                      | **DONE**    |
| 5   | `bind_tools` (built-in tool passthrough) + standard harness | **DONE**    |
| 6   | `bind_tools` for custom tools via in-process MCP server     | **DONE**    |
| 7   | Docs, examples, first PyPI release                          | **DONE**    |
| 7.5 | `with_structured_output` JSON-prompting override            | **DONE**    |

## Why phases 1 and 2 are skipped

The original plan in `README.md` called for a lower `claude-code` package
wrapping the `claude` CLI subprocess directly. Mid-planning we discovered
Anthropic ships **`claude-agent-sdk`** (v0.2.86+, MIT, `anthropics/claude-agent-sdk-python`)
— the official Python SDK that does everything phases 1 and 2 were going to
build: subprocess + stream-json parsing, typed messages, multi-turn, exception
hierarchy, in-process MCP, session handling.

Building our own would have been duplicative and worse. We depend on
`claude-agent-sdk` directly and skip those phases entirely. Wyrd's substrate
replacement (`wyrd/core/llm.py`) should likewise be a direct
`claude-agent-sdk` import — no intermediate wrapper needed.

**Do not revisit phases 1 or 2.** If a future session wonders whether to
extract a lower-level CLI wrapper: don't. The answer is `claude-agent-sdk`.

## Phase details and pointers

### Phase 0 — Scaffolding (DONE)

Layout mirrors `langchain-anthropic`. Hatchling build, strict mypy, ruff with
a sensible subset, pytest with `asyncio_mode = "auto"`, `langchain-tests>=1.1.9`
in dev deps for the standard harness later.

- Package: `src/langchain_claude_agent_sdk/`
- Class stub: `ChatClaudeAgent` in `chat_models.py` (only `_llm_type` and
  `_identifying_params` work; the four LLM methods raise NotImplementedError)
- Tests: 3 import-smoke tests passing
- License: MIT, copyright Blake Rhodes 2026

Run `make check` to verify everything still passes after changes.

### Phase 3 — `_generate` / `_agenerate` (DONE)

Implemented in `chat_models.py` + `_messages.py`. `_agenerate` calls
`claude_agent_sdk.query()` and drains its async iterator; `_generate` is a
thin `asyncio.run` facade that refuses to execute inside an active event loop.

Multi-turn approach (deviation from the original "use ClaudeSDKClient" plan):
the CLI's stream-json input does not accept replayed assistant turns, so we
take two paths instead.

1. If the most recent `AIMessage` in the history carries
   `response_metadata["session_id"]` (which `to_ai_message` always populates),
   we set `ClaudeAgentOptions.resume=<session_id>` and forward only the
   messages *after* that turn. This is the LangGraph-friendly happy path: the
   CLI keeps the real session state, no re-billing of prior turns.
2. Otherwise (history without a session id), we serialize prior turns into a
   plain-text transcript prefix and send the whole thing via `query()`. Crude
   but works for arbitrary user-constructed histories.

`AIMessage` mapping:
- `usage_metadata` populated from `ResultMessage.usage` with
  `cache_creation` / `cache_read` buckets folded into `input_tokens` and
  surfaced under `input_token_details`. Total tokens include cache buckets.
- `tool_calls` populated from `ToolUseBlock`s (NOT stuffed into
  `response_metadata`).
- `response_metadata` carries CLI-only extras: `session_id`,
  `total_cost_usd`, `num_turns`, `duration_ms`, `duration_api_ms`,
  `model_name`, `stop_reason`, and `thinking` (preserved `ThinkingBlock`s).

SystemMessage handling: `append_system_prompt=True` (default) sends a
`SystemPromptPreset({"type":"preset","preset":"claude_code","append":...})`;
flip to `False` to replace the Claude Code preset entirely.

Tests: 23 new unit tests in `test_messages.py` + `test_generate.py` covering
message translation, tool-call extraction, usage with cache buckets,
session-id resume, transcript fallback, append-vs-replace system prompt,
loop-running guard, and stop-sequence rejection. SDK is monkeypatched —
no integration tests yet (those land in Phase 5 with the standard harness).

### Phase 4 — Streaming (DONE)

Implemented as `ChatClaudeAgent._astream` in `chat_models.py`, with helpers
`assistant_message_to_chunks` and `result_to_final_chunk` in `_messages.py`.
The non-streaming and streaming paths share `_result_response_metadata` so
`response_metadata` extras (session_id, cost, duration, etc.) appear identical
regardless of how the model was invoked.

**Granularity decision: per content block, not per token.** The SDK
*can* emit raw Anthropic stream-event deltas via
`ClaudeAgentOptions.include_partial_messages=True` (yielding
`StreamEvent` objects with a token-level `event` dict). We do not
enable that mode in Phase 4.

- One chunk per `TextBlock` / `ToolUseBlock` / `ThinkingBlock` is enough
  to satisfy the standard-harness streaming tests (folded chunks via
  `AIMessageChunk.__add__` recover the full message; usage_metadata is
  present on exactly one chunk).
- True token-level streaming via `include_partial_messages` adds a
  whole second translation layer (StreamEvent.event dict → AIMessageChunk
  with partial JSON args, content-block lifecycle tracking, etc.) for
  benefit that only matters in interactive-UI scenarios — our audience
  is mostly background agent runs. **Track as Phase 4.5 if anyone
  surfaces a real need.**
- Tool-call chunks carry monotonically-increasing `index` across
  consecutive AssistantMessages (Phase 6 / agent-loop case) so
  AIMessageChunk merge doesn't collide tool calls from different turns.
- The final chunk is empty content with `usage_metadata` populated; the
  LangChain outer machinery appends its own `chunk_position='last'`
  sentinel after — tests filter that out before asserting.

`_stream` (sync) is not implemented separately. `model.stream(...)` from
sync callers falls back to `_generate` and yields a single chunk — fine
for now; revisit if sync streaming becomes a real need.

### Phase 5 — `bind_tools` (built-in passthrough) (DONE)

`ChatClaudeAgent.bind_tools` accepts the canonical
`Sequence[str | dict | type[BaseModel] | Callable | BaseTool]` shape used by
`langchain-anthropic` / `langchain-openai`, and:

- **`str` entries** are treated as built-in Claude Code tool names
  ("WebSearch", "WebFetch", "Read", "Write", "Edit", "Bash", "Glob",
  "Grep", "Task", ...). They route to `ClaudeAgentOptions.allowed_tools`
  via `self.bind(allowed_tools=[...])` so each downstream `invoke` /
  `astream` runs with the bound list. `_options_from_kwargs` extracts
  the bound list in `_agenerate` / `_astream` and merges it through
  `_build_options.overrides=` — bound runtime values override
  construction-time `extra_options`.
- **All other tool types** (`BaseTool`, Pydantic models, callables,
  OpenAI-style dict schemas) raise `NotImplementedError` pointing at
  Phase 6. The signature stays symmetric with the canonical providers so
  the only thing changing in Phase 6 is *what* `bind_tools` accepts —
  not the shape callers write.
- **`tool_choice`** is accepted as `None` or `"auto"` (no-op; model
  decides). Any other value raises `NotImplementedError`; the SDK does
  not expose a way to constrain or force tool selection.

The standard-tests harness (`tests/unit_tests/test_standard.py`) was wired
in the previous session. With `bind_tools` now overridden, the harness'
default `has_tool_calling` auto-detection would flip to `True` — and
`test_bind_tool_pydantic` would call our `bind_tools` with a Pydantic
model and break. We explicitly set `has_tool_calling = False` and
`has_structured_output = False` on the test class with a docstring
explaining the Phase 6 transition; both flags flip when Phase 6 lands
proper custom-tool support.

### Phase 6 — Custom tools via in-process MCP (DONE)

`ChatClaudeAgent.bind_tools` accepts the canonical mixed tool list. Every
non-string tool is converted into an `SdkMcpTool` and grouped into one
in-process MCP server registered under `"langchain-tools"`. The CLI
references each via `mcp__langchain-tools__<tool_name>` patterns added
to `allowed_tools`.

`_tools.py:_normalize_tool` dispatches on input type:

- `BaseTool` and bare callables (auto-decorated with `@tool`) get an
  **executable handler** that calls `BaseTool.ainvoke`. The CLI runs the
  tool to completion in-process and feeds the result back into the
  conversation. Result serialization: strings pass through; other shapes
  go through `json.dumps(default=str)` with a final fallback to
  `str(result)`. Exceptions return
  `{"content": [{"type": "text", ...}], "is_error": True}` so the model
  sees the failure and can recover.
- Pydantic model classes and JSON-schema dicts get an **echo handler**
  that returns the args as JSON. They exist so the model can *emit* a
  structured call (for `with_structured_output`-style patterns and for
  callers that intercept `AIMessage.tool_calls` themselves) — the echo
  ensures the agent loop progresses deterministically rather than
  stalling on a missing backend.

Schema extraction is defensive: Pydantic v2 (`model_json_schema`) and
v1 (`schema`) both work; failures (e.g. unsupported types) fall back to
`{"type": "object", "properties": {}}` rather than raising.

`tool_choice` accepts *any* value. The Claude Agent SDK does not expose
a runtime knob to constrain or force tool selection, so the kwarg is a
best-effort hint only. Provided for signature parity with the canonical
providers; rely on the system prompt if you need stronger guidance.

Options merging is now layer-aware (`_merge_options`): if the user
pre-registered their own MCP servers via `extra_options["mcp_servers"]`,
`bind_tools`' `"langchain-tools"` server coexists with them rather than
wholesale-replacing.

Standard-harness impact: `tests/unit_tests/test_standard.py` removes the
Phase 5 `has_tool_calling = False` / `has_structured_output = False`
overrides. The harness now auto-detects both as `True` (from
`bind_tools` and `with_structured_output` being meaningfully overridden);
`test_bind_tool_pydantic` and `test_with_structured_output[PersonA]`
both pass.

### Phase 7 — Docs, examples, PyPI release (DONE)

Initial public release shipped as `0.1.0` (skipping `0.0.1` — the
development version was never published).

- `examples/` directory with five self-contained scripts covering basic
  invoke, streaming, built-in tools, custom tools, and LangGraph
  integration. `examples/README.md` documents prerequisites, invocation,
  and the per-example scope.
- `.forgejo/workflows/release.yml` triggers on `v<version>` tag pushes,
  builds + uploads to PyPI via a `PYPI_API_TOKEN` secret. PyPI does not
  yet support Codeberg / Forgejo as a trusted publisher; the workflow
  pre-flight-checks tag/`pyproject.toml`/`_version.py` agreement before
  any upload, and the migration-to-trusted-publishing path is documented
  inline so the future swap is mechanical.
- `pyproject.toml` `[tool.hatch.build.targets.sdist]` includes
  `examples/` so the released sdist carries them.
- `CONTRIBUTING.md`'s "Releasing" section is rewritten with the full
  one-time setup (PYPI_API_TOKEN scoping), the release dance
  (`cz bump --changelog` → `git push --follow-tags`), and the
  "do not retag on upload failure" guardrail.

After 0.1.0: the natural follow-ups are (a) true token-level streaming
via `ClaudeAgentOptions.include_partial_messages` (currently deferred —
block-level streaming satisfies the harness contract) and (b) replacing
the PyPI API token with trusted publishing once PyPI ships Forgejo
support. Both tracked as enhancements rather than new phases.

### Phase 7.5 — `with_structured_output` override (DONE)

Bugfix landed after 0.1.1. The inherited
`BaseChatModel.with_structured_output` relies on
`bind_tools([schema], tool_choice="any") | PydanticToolsParser(...)` to
force the model into emitting a structured tool call — but the Claude
Agent SDK exposes no runtime knob to constrain or force tool selection
(Phase 6 documented `tool_choice` as accepted-and-ignored, signature
parity only). Against the real CLI the model ignored the bound schema
tool, replied with prose, and the tools parser returned `None`. Unit
harnesses that fake the SDK never surfaced this because they never asked
the model to actually use the tool.

The fix in `_structured_output.py` + `chat_models.py` overrides
`with_structured_output` to render the schema into a leading
`SystemMessage` and parse the assistant's reply directly with
`PydanticOutputParser` (Pydantic classes) or `JsonOutputParser`
(TypedDict / dict / OpenAI/Anthropic tool-spec). The override:

- preserves the canonical signature (`schema`, `include_raw`, `method`,
  `strict`, plus extra-kwargs rejection) so callers migrating from
  `langchain-anthropic` / `langchain-openai` need no changes;
- routes every `method` through the same JSON-prompting impl — there is
  no `function_calling` path the SDK can deliver reliably, so we don't
  pretend otherwise;
- preserves the caller's existing `SystemMessage`s and inserts the JSON
  directive *after* them so it's the last system-level guidance the
  model reads (empirically improves adherence on Claude);
- emits the canonical
  `{"raw": AIMessage, "parsed": ..., "parsing_error": ...}` shape under
  `include_raw=True` so cost / session_id / token usage in
  `response_metadata` are still inspectable;
- registers **no MCP server and no `allowed_tools` entry** for the
  schema — the model sees JSON instructions and a conversation, not a
  competing tool affordance.

Tests live in `tests/unit_tests/test_structured_output.py` (16 cases:
Pydantic / dict / TypedDict schemas, fence tolerance, system-prompt
injection placement, no-tool-binding assertion, include_raw happy and
parse-error paths, all `method` × `strict` permutations, kwarg
validation, async invoke, PromptValue / string / unsupported inputs).
Coverage on `_structured_output.py` is 100%; package coverage moved
from 96.39% to 97.21%.

## Key technical decisions (don't relitigate without reason)

- **System prompt default:** `append_system_prompt=True`. Replacing the
  Claude Code system prompt breaks tool affordances; appending preserves them.
  Opt-out via constructor flag.
- **Auth:** rely on the bundled CLI's existing auth (`~/.claude/.credentials.json`).
  No `api_key` field on our class. ToS note in README: this is for users
  running under their own Max/Pro/API auth, not for multi-tenant SaaS
  redistribution.
- **Economics caveat (post-2026-06-15):** Agent SDK usage draws from a
  separate monthly Agent SDK credit pool (Pro $20, Max 5x $100, Max 20x $200),
  not unmetered Max windows. Doc this clearly in the README.

## Conventions

- Branch / commit per phase. Phase completion = `make check` green +
  PHASES.md updated.
- Mark the next phase's row `**IN PROGRESS**` when starting, `**DONE**` when
  green.
- New design pivots get a "Why phase X changed" subsection here, not buried
  in commit messages.
