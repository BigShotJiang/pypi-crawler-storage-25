# Design notes (historical)

> **Status:** Historical artifact. This file is the original design exploration
> that preceded `langchain-claude-agent-sdk`. It is preserved for context — the
> reasoning is still useful — but the package name, package shape, and
> implementation path documented below have **changed**:
>
> - The class is now `ChatClaudeAgent`, not `ChatClaudeCode`; the package is
>   `langchain-claude-agent-sdk`.
> - The "two packages" recommendation (`claude-code` + `langchain-claude-code`)
>   is obsolete. We depend directly on Anthropic's official `claude-agent-sdk`
>   Python package, which does the subprocess + stream-json + multi-turn work
>   the lower package would have done. See `PHASES.md` for why phases 1 and 2
>   were skipped.
> - The "substrate already exists in wyrd" note is also obsolete: wyrd should
>   itself migrate to `claude-agent-sdk` rather than us extracting from it.
>
> For the current shape of the package and how to use it, read `README.md`.
> For the phase tracker, read `PHASES.md`. For the implementation, read the
> code.

---

# langchain-claude-code (original design)

A LangChain-compatible adapter that uses the `claude` CLI (Claude Code) as the
backend instead of the Anthropic API. Lets LangChain / LangGraph code run
against a Claude Code subscription's fixed-cost billing instead of per-token
API rates.

## Why this exists

The LangChain ecosystem implicitly assumes per-token API billing. Anyone
running multi-agent workflows — even modest ones — bleeds money against that
model. A 25–40-call run that's effectively free on a Claude Max subscription
is eye-watering through the API.

A drop-in `ChatClaudeCode` class lets the LangChain/LangGraph tutorials,
templates, and ecosystem code work against a fixed-cost backend without
rewriting any of the calling code.

**Audience:** LangChain users who already pay for Claude; people building
agent workflows who can't justify API costs; researchers experimenting with
multi-agent designs at non-trivial scale.

## What the package needs to do

### Minimum viable

```python
class ChatClaudeCode(BaseChatModel):
    async def _agenerate(self, messages, stop=None, **kw) -> ChatResult:
        # Flatten LangChain messages → single prompt string
        # Subprocess `claude --output-format stream-json`
        # Parse the stream into AIMessageChunk events
```

That alone covers the bulk of LangChain code that just wants a chat model.

### The harder, more interesting work

- **Tool use translation.** Claude Code's `--allowedTools WebSearch WebFetch …`
  is a pre-declared whitelist that the model calls *itself* — different from
  API tool use where the caller intercepts and replies. Two approaches:
  - Map `bind_tools(...)` to `--allowedTools` for built-in tools only.
  - Run a wrapping subprocess that intercepts tool-call events from the
    stream and rolls a fake API-style tool-use round-trip for custom tools.
- **Streaming chunks.** Claude Code's stream-json events → LangChain
  `AIMessageChunk` deltas. Direct mapping per event type.
- **Token counts / usage callbacks.** LangChain wants `usage_metadata` for
  cost callbacks. Claude Code's stream-json may or may not surface this —
  needs checking; may be derivable from the event stream; may just have to be
  `None` and document the limitation.
- **System messages.** Trivial — prepend to the prompt.

## Real risks

- **Format drift.** Anthropic owns the CLI's JSON output format; they can
  change it whenever. The adapter carries a perpetual maintenance tax.
- **No formal endorsement.** Anthropic documents `--output-format stream-json`
  and headless mode, which reads like blessing, but they haven't said "build
  on this." If they ever decide they don't want subscription pricing routed
  through LangChain ecosystems, the package's footing changes.
- **Rate limits.** Subscription rate limits will bite long-running
  multi-agent workflows — a 100-agent LangGraph swarm would hit them.
  Sequential-ish wyrd-style runs don't.

## Recommended path: two packages, not one

1. **`claude-code`** — standalone Python primitives: `ask`, `deep_research`,
   `ask_or_error`. Subprocess management, stream-json parsing, error
   handling, JSON extraction from messy replies, timeout handling,
   `available()`. **No LangChain dependency.** Useful to people who aren't
   on LangChain at all.
2. **`langchain-claude-code`** — thin adapter on top:
   `ChatClaudeCode(BaseChatModel)` and friends. Translates LangChain's
   message arrays and tool bindings into `claude-code` primitives.

This split means anyone wanting to script `claude` from Python — without
LangChain — gets a useful library. People who want LangChain interop get the
adapter. The lower package is the load-bearing piece; the upper is a
~few-hundred-line shim.

## Substrate already exists

The `wyrd` project's `core/llm.py` (`~/src/wyrd/src/wyrd/core/llm.py`)
already does ~70% of the substrate work:

- subprocess management (`asyncio.create_subprocess_exec`, 16MB stdout buffer)
- stream-json parsing (event-by-event with tool-call extraction)
- error handling (CLI missing, timeout, crash, non-JSON reply)
- `_extract_json` — pulls JSON out of code fences and leading prose
- per-call timeouts with stall detection (B14)
- `available()` — graceful degradation when the CLI isn't on PATH

The natural starting point is extracting that file into the `claude-code`
package, cleaning up the wyrd-specific helpers, and publishing.

## Naming notes

- **`langchain-claude-code`** reads cleanly, doesn't claim Anthropic
  affiliation, signals "adapter, not reimplementation."
- Avoid anything that could be mistaken for official Anthropic branding
  (`anthropic-*`, `claude-langchain-official`, etc.).
- Lowercase, hyphenated — matches the LangChain ecosystem's convention for
  third-party packages (`langchain-anthropic`, `langchain-openai`, etc.).

## Status

Idea stage. Captured here so it doesn't evaporate.
