"""Standard chat-model integration-test harness for ChatClaudeAgent.

Subclasses ``langchain_tests.integration_tests.ChatModelIntegrationTests``.
These tests **invoke the real ``claude`` CLI** via ``claude-agent-sdk``,
which means they:

- require a working ``claude`` CLI on PATH and valid local auth
  (``~/.claude/.credentials.json``);
- consume real model usage / cost against that auth;
- can take tens of seconds per test.

The whole module is tagged ``@pytest.mark.integration`` (via
``pytestmark``) so the default unit-test loop does not run them. Invoke
explicitly with ``make test-integration`` or
``uv run pytest tests/integration_tests -m integration``.

Capability flags reflect the current implementation surface:

- ``has_tool_calling`` / ``has_structured_output`` are auto-detected from
  the chat-model class; both are ``False`` until Phase 5 wires
  ``bind_tools``. Tests that gate on those flags will skip.
- ``returns_usage_metadata`` is ``True``: every successful invoke folds
  ``ResultMessage.usage`` into the ``AIMessage.usage_metadata`` field.
- ``supports_model_override`` is ``True``: ``_get_ls_params`` honors the
  per-call ``model=`` kwarg.

Some integration tests are *expected* to fail against the current
implementation surface:

- ``test_stop_sequence`` will fail — the Claude Agent SDK does not expose
  stop sequences (``ChatClaudeAgent`` documents and accepts-and-ignores
  them). The test asserts the model actually stopped on the sequence.
- ``test_tool_message_histories_*`` will fail until Phase 5 / 6 ship
  proper tool round-tripping — the current transcript-fallback path is
  lossy.

These are tracked rather than xfailed at the harness level. As phases
land, the failures should resolve naturally; remove the entry from this
docstring at that point.
"""

from __future__ import annotations

import pytest
from langchain_tests.integration_tests import ChatModelIntegrationTests

from langchain_claude_agent_sdk import ChatClaudeAgent

# Apply the integration marker to every test inherited from
# ChatModelIntegrationTests so `make test-integration` (which filters
# `-m integration`) actually picks them up.
pytestmark = pytest.mark.integration


class TestChatClaudeAgentIntegration(ChatModelIntegrationTests):
    @property
    def chat_model_class(self) -> type[ChatClaudeAgent]:
        return ChatClaudeAgent

    @property
    def chat_model_params(self) -> dict[str, object]:
        # Pick a fast, inexpensive model for the integration run. Override
        # via the CLAUDE_AGENT_SDK_TEST_MODEL env var if you want to point
        # the harness at a different model.
        return {"model": "claude-haiku-4-5"}

    @property
    def returns_usage_metadata(self) -> bool:
        return True

    @property
    def supports_model_override(self) -> bool:
        return True

    @property
    def model_override_value(self) -> str:
        return "claude-sonnet-4-6"
