"""bind_tools (Phase 5) — built-in tool passthrough only."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import pytest
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ResultMessage,
    TextBlock,
)
from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableBinding
from langchain_core.tools import tool
from pydantic import BaseModel

import langchain_claude_agent_sdk.chat_models as chat_models_module
from langchain_claude_agent_sdk import ChatClaudeAgent


def _make_assistant(text: str = "ok") -> AssistantMessage:
    return AssistantMessage(
        content=[TextBlock(text=text)],
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id="msg",
        stop_reason="end_turn",
        session_id="sess",
        uuid="u",
    )


def _make_result() -> ResultMessage:
    return ResultMessage(
        subtype="success",
        duration_ms=10,
        duration_api_ms=8,
        is_error=False,
        num_turns=1,
        session_id="sess",
        stop_reason="end_turn",
        total_cost_usd=0.0,
        usage={"input_tokens": 1, "output_tokens": 1},
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=None,
        api_error_status=None,
        uuid="ur",
    )


class _FakeQuery:
    def __init__(self, canned: list[Any]) -> None:
        self.canned = canned
        self.captured_options: ClaudeAgentOptions | None = None

    def __call__(
        self,
        *,
        prompt: Any,
        options: ClaudeAgentOptions | None = None,
        transport: Any = None,
    ) -> AsyncIterator[Any]:
        self.captured_options = options
        canned = list(self.canned)

        async def _iter() -> AsyncIterator[Any]:
            for msg in canned:
                yield msg

        return _iter()


@pytest.fixture
def fake_query(monkeypatch: pytest.MonkeyPatch) -> _FakeQuery:
    fake = _FakeQuery([_make_assistant("done"), _make_result()])
    monkeypatch.setattr(chat_models_module, "query", fake)
    return fake


def test_bind_tools_returns_runnable_binding() -> None:
    model = ChatClaudeAgent()
    bound = model.bind_tools(["WebSearch", "Read"])
    assert isinstance(bound, RunnableBinding)


def test_bind_tools_routes_strings_to_allowed_tools(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent()
    bound = model.bind_tools(["WebSearch", "Read", "Bash"])
    bound.invoke([HumanMessage("search for X")])

    assert fake_query.captured_options is not None
    assert fake_query.captured_options.allowed_tools == ["WebSearch", "Read", "Bash"]


def test_bind_tools_overrides_extra_options_allowed_tools(
    fake_query: _FakeQuery,
) -> None:
    # If both extra_options and bind_tools specify allowed_tools, the
    # runtime bind_tools call wins (more specific).
    model = ChatClaudeAgent(extra_options={"allowed_tools": ["Bash"]})
    bound = model.bind_tools(["Read"])
    bound.invoke([HumanMessage("hi")])
    assert fake_query.captured_options is not None
    assert fake_query.captured_options.allowed_tools == ["Read"]


def test_bind_tools_without_binding_uses_extra_options(fake_query: _FakeQuery) -> None:
    # No bind_tools call: extra_options['allowed_tools'] still flows through.
    model = ChatClaudeAgent(extra_options={"allowed_tools": ["WebFetch"]})
    model.invoke([HumanMessage("hi")])
    assert fake_query.captured_options is not None
    assert fake_query.captured_options.allowed_tools == ["WebFetch"]


def test_bind_tools_empty_list_clears_allowed_tools(fake_query: _FakeQuery) -> None:
    # bind_tools([]) explicitly disables tool calling for this binding.
    model = ChatClaudeAgent(extra_options={"allowed_tools": ["Bash"]})
    bound = model.bind_tools([])
    bound.invoke([HumanMessage("hi")])
    assert fake_query.captured_options is not None
    assert fake_query.captured_options.allowed_tools == []


def test_bind_tools_accepts_basetool(fake_query: _FakeQuery) -> None:
    @tool
    def my_tool(x: int) -> int:
        """double the input."""
        return x * 2

    model = ChatClaudeAgent()
    bound = model.bind_tools([my_tool])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    assert opts.allowed_tools == ["mcp__langchain-tools__my_tool"]
    assert "langchain-tools" in opts.mcp_servers


def test_bind_tools_accepts_pydantic_model(fake_query: _FakeQuery) -> None:
    class Adder(BaseModel):
        """add two integers."""

        a: int
        b: int

    model = ChatClaudeAgent()
    bound = model.bind_tools([Adder])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    assert opts.allowed_tools == ["mcp__langchain-tools__Adder"]
    assert "langchain-tools" in opts.mcp_servers


def test_bind_tools_accepts_callable(fake_query: _FakeQuery) -> None:
    def double(x: int) -> int:
        """double the input."""
        return x * 2

    model = ChatClaudeAgent()
    bound = model.bind_tools([double])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    # The @tool decorator preserves the function name.
    assert opts.allowed_tools == ["mcp__langchain-tools__double"]


def test_bind_tools_accepts_openai_dict_schema(fake_query: _FakeQuery) -> None:
    schema = {
        "type": "function",
        "function": {
            "name": "echo",
            "description": "echo back the input",
            "parameters": {
                "type": "object",
                "properties": {"text": {"type": "string"}},
                "required": ["text"],
            },
        },
    }
    model = ChatClaudeAgent()
    bound = model.bind_tools([schema])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    assert opts.allowed_tools == ["mcp__langchain-tools__echo"]


def test_bind_tools_mixed_builtin_and_custom(fake_query: _FakeQuery) -> None:
    @tool
    def double(x: int) -> int:
        """double."""
        return x * 2

    model = ChatClaudeAgent()
    bound = model.bind_tools(["WebSearch", "Read", double])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    # Built-ins come first, then mcp-qualified custom tools.
    assert opts.allowed_tools == [
        "WebSearch",
        "Read",
        "mcp__langchain-tools__double",
    ]
    assert "langchain-tools" in opts.mcp_servers


def test_bind_tools_tool_choice_accepted_as_best_effort_hint(
    fake_query: _FakeQuery,
) -> None:
    # The Claude Agent SDK does not expose a way to enforce tool choice,
    # so every value is accepted but does not affect the resulting
    # options. The contract is signature parity for callers migrating
    # from langchain-anthropic / langchain-openai; document but don't
    # raise. (See the warning-emission tests below for what users observe.)
    model = ChatClaudeAgent()
    for choice in (None, "auto", "any", "required", "none", {"type": "tool", "name": "WebSearch"}):
        bound = model.bind_tools(["WebSearch"], tool_choice=choice)
        assert isinstance(bound, RunnableBinding)


def test_bind_tools_warns_when_tool_choice_would_constrain(
    fake_query: _FakeQuery, caplog: pytest.LogCaptureFixture
) -> None:
    # "any" / "required" / "none" / dict values express a constraint the
    # canonical providers enforce; users migrating from langchain-anthropic
    # would expect them to bite. Surface a logger.warning so the silent
    # divergence is visible.
    model = ChatClaudeAgent()
    constraining_values: list[Any] = [
        "any",
        "required",
        "none",
        {"type": "tool", "name": "WebSearch"},
    ]
    for choice in constraining_values:
        caplog.clear()
        with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
            model.bind_tools(["WebSearch"], tool_choice=choice)
        warnings = [r for r in caplog.records if r.levelname == "WARNING"]
        assert len(warnings) == 1, f"expected one warning for tool_choice={choice!r}"
        assert "no runtime knob to constrain or force tool selection" in warnings[0].getMessage()


def test_bind_tools_no_warning_for_none_or_auto(
    fake_query: _FakeQuery, caplog: pytest.LogCaptureFixture
) -> None:
    # None and "auto" describe the SDK's actual behavior (model decides),
    # so warning would just spam logs without diagnostic value.
    model = ChatClaudeAgent()
    for choice in (None, "auto"):
        caplog.clear()
        with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
            model.bind_tools(["WebSearch"], tool_choice=choice)
        assert [r for r in caplog.records if r.levelname == "WARNING"] == [], (
            f"expected no warning for tool_choice={choice!r}"
        )


def test_bind_tools_merges_with_user_mcp_servers(fake_query: _FakeQuery) -> None:
    # If the user pre-registered their own mcp_servers via extra_options,
    # bind_tools' langchain-tools server should coexist rather than
    # replace it.
    user_server_marker = object()
    model = ChatClaudeAgent(
        extra_options={"mcp_servers": {"my-own-server": user_server_marker}},
    )

    @tool
    def double(x: int) -> int:
        """double."""
        return x * 2

    bound = model.bind_tools([double])
    bound.invoke([HumanMessage("hi")])

    opts = fake_query.captured_options
    assert opts is not None
    assert "my-own-server" in opts.mcp_servers
    assert opts.mcp_servers["my-own-server"] is user_server_marker
    assert "langchain-tools" in opts.mcp_servers


def test_bind_tools_rejects_unsupported_type() -> None:
    # Sanity: passing something that isn't str/BaseTool/callable/Pydantic/
    # dict still surfaces a clear error.
    model = ChatClaudeAgent()
    with pytest.raises(TypeError, match="Unsupported tool type"):
        model.bind_tools([42])  # type: ignore[arg-type,list-item]


async def test_bind_tools_flows_through_astream(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = _FakeQuery([_make_assistant("done"), _make_result()])
    monkeypatch.setattr(chat_models_module, "query", fake)

    model = ChatClaudeAgent()
    bound = model.bind_tools(["WebSearch", "WebFetch"])
    async for _ in bound.astream([HumanMessage("hi")]):
        pass
    assert fake.captured_options is not None
    assert fake.captured_options.allowed_tools == ["WebSearch", "WebFetch"]
