"""_astream tests with the SDK monkeypatched."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import pytest
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ResultMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
)
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage

import langchain_claude_agent_sdk.chat_models as chat_models_module
from langchain_claude_agent_sdk import ChatClaudeAgent


def _make_assistant(
    text: str = "ok",
    tool_uses: list[ToolUseBlock] | None = None,
    thinking: list[ThinkingBlock] | None = None,
    model: str = "claude-sonnet-4-6",
) -> AssistantMessage:
    content: list[Any] = []
    if thinking:
        content.extend(thinking)
    if text:
        content.append(TextBlock(text=text))
    if tool_uses:
        content.extend(tool_uses)
    return AssistantMessage(
        content=content,
        model=model,
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id="msg",
        stop_reason="end_turn",
        session_id="sess-1",
        uuid="u",
    )


def _make_result(
    *,
    input_tokens: int = 5,
    output_tokens: int = 7,
    cache_creation: int = 0,
    cache_read: int = 0,
) -> ResultMessage:
    usage = {"input_tokens": input_tokens, "output_tokens": output_tokens}
    if cache_creation:
        usage["cache_creation_input_tokens"] = cache_creation
    if cache_read:
        usage["cache_read_input_tokens"] = cache_read
    return ResultMessage(
        subtype="success",
        duration_ms=100,
        duration_api_ms=80,
        is_error=False,
        num_turns=1,
        session_id="sess-1",
        stop_reason="end_turn",
        total_cost_usd=0.001,
        usage=usage,
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=None,
        api_error_status=None,
        uuid="ur",
    )


class _FakeQuery:
    def __init__(self, canned: list[Any]) -> None:
        self.canned = canned
        self.captured_prompt: Any = None
        self.captured_options: ClaudeAgentOptions | None = None

    def __call__(
        self,
        *,
        prompt: Any,
        options: ClaudeAgentOptions | None = None,
        transport: Any = None,
    ) -> AsyncIterator[Any]:
        self.captured_prompt = prompt
        self.captured_options = options
        canned = list(self.canned)

        async def _iter() -> AsyncIterator[Any]:
            for msg in canned:
                yield msg

        return _iter()


def _install_fake(monkeypatch: pytest.MonkeyPatch, canned: list[Any]) -> _FakeQuery:
    fake = _FakeQuery(canned)
    monkeypatch.setattr(chat_models_module, "query", fake)
    return fake


async def _collect(model: ChatClaudeAgent, history: list[Any]) -> list[AIMessageChunk]:
    # `model.astream(...)` unwraps `ChatGenerationChunk.message` and yields
    # the inner AIMessageChunk directly. LangChain's outer machinery also
    # appends a synthetic empty chunk with chunk_position='last' as an
    # end-of-stream sentinel; we drop it so tests assert against the
    # chunks we actually emit from `_astream`.
    chunks: list[AIMessageChunk] = []
    async for chunk in model.astream(history):
        if (
            getattr(chunk, "chunk_position", None) == "last"
            and chunk.content == ""
            and not chunk.tool_call_chunks
            and chunk.usage_metadata is None
        ):
            continue
        chunks.append(chunk)
    return chunks


def _fold(chunks: list[AIMessageChunk]) -> AIMessageChunk:
    """Accumulate chunks via AIMessageChunk.__add__ (same path
    LangChain consumers use to recover the full message)."""
    folded = chunks[0]
    for c in chunks[1:]:
        folded = folded + c
    return folded


async def test_astream_yields_one_chunk_per_text_block(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake(
        monkeypatch,
        [
            AssistantMessage(
                content=[TextBlock(text="hello "), TextBlock(text="world")],
                model="m",
                parent_tool_use_id=None,
                error=None,
                usage=None,
                message_id="msg",
                stop_reason="end_turn",
                session_id="s",
                uuid="u",
            ),
            _make_result(),
        ],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("hi")])
    # Two text blocks + one final result chunk.
    assert len(chunks) == 3
    assert chunks[0].content == "hello "
    assert chunks[1].content == "world"
    assert chunks[2].content == ""


async def test_astream_chunks_concat_matches_invoke(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    canned = [
        AssistantMessage(
            content=[TextBlock(text="part one. "), TextBlock(text="part two.")],
            model="claude-sonnet-4-6",
            parent_tool_use_id=None,
            error=None,
            usage=None,
            message_id="msg",
            stop_reason="end_turn",
            session_id="s",
            uuid="u",
        ),
        _make_result(),
    ]
    _install_fake(monkeypatch, canned)
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("hi")])
    folded = _fold(chunks)
    assert isinstance(folded, AIMessageChunk)
    assert folded.content == "part one. part two."

    # The folded chunk should also carry usage_metadata + the CLI-only
    # response_metadata extras from the terminal result chunk.
    assert folded.usage_metadata is not None
    assert folded.usage_metadata["input_tokens"] == 5
    assert folded.usage_metadata["output_tokens"] == 7
    assert folded.response_metadata.get("session_id") == "sess-1"
    assert folded.response_metadata.get("total_cost_usd") == pytest.approx(0.001)


async def test_astream_emits_model_name_on_first_chunk(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake(
        monkeypatch,
        [_make_assistant("hi", model="claude-haiku-4-5"), _make_result()],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("hi")])
    assert chunks[0].response_metadata.get("model_name") == "claude-haiku-4-5"
    # Subsequent chunks should not re-set model_name (one source of truth).
    for c in chunks[1:]:
        assert "model_name" not in c.response_metadata


async def test_astream_emits_tool_call_chunk(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake(
        monkeypatch,
        [
            AssistantMessage(
                content=[
                    TextBlock(text="let me look"),
                    ToolUseBlock(id="tu_1", name="Read", input={"path": "/x"}),
                ],
                model="m",
                parent_tool_use_id=None,
                error=None,
                usage=None,
                message_id="msg",
                stop_reason="tool_use",
                session_id="s",
                uuid="u",
            ),
            _make_result(),
        ],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("read /x")])
    tc_chunks = [c for c in chunks if c.tool_call_chunks]
    assert len(tc_chunks) == 1
    tcc = tc_chunks[0].tool_call_chunks[0]
    assert tcc["name"] == "Read"
    assert tcc["id"] == "tu_1"
    assert json.loads(tcc["args"] or "") == {"path": "/x"}
    assert tcc["index"] == 1  # second block in the message (after the TextBlock)


async def test_astream_emits_thinking_in_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake(
        monkeypatch,
        [
            _make_assistant(
                "answer",
                thinking=[ThinkingBlock(thinking="hmm", signature="sig-1")],
            ),
            _make_result(),
        ],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("solve x")])
    thinking_chunks = [c for c in chunks if "thinking" in c.response_metadata]
    assert len(thinking_chunks) == 1
    assert thinking_chunks[0].response_metadata["thinking"] == [
        {"thinking": "hmm", "signature": "sig-1"}
    ]


async def test_astream_usage_metadata_only_on_final_chunk(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake(
        monkeypatch,
        [_make_assistant("hi"), _make_result(input_tokens=2, output_tokens=4)],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("hi")])
    # Every chunk except the last should have usage_metadata=None.
    for c in chunks[:-1]:
        assert c.usage_metadata is None
    assert chunks[-1].usage_metadata is not None
    assert chunks[-1].usage_metadata["input_tokens"] == 2
    assert chunks[-1].usage_metadata["output_tokens"] == 4
    assert chunks[-1].usage_metadata["total_tokens"] == 6


async def test_astream_handles_multiple_assistant_messages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Agent-loop case: two AssistantMessages back-to-back. Tool-call
    # chunk indices must accumulate so they don't collide.
    _install_fake(
        monkeypatch,
        [
            AssistantMessage(
                content=[
                    TextBlock(text="step 1 "),
                    ToolUseBlock(id="tu_a", name="A", input={}),
                ],
                model="m",
                parent_tool_use_id=None,
                error=None,
                usage=None,
                message_id="m1",
                stop_reason="tool_use",
                session_id="s",
                uuid="u1",
            ),
            AssistantMessage(
                content=[
                    TextBlock(text="step 2 "),
                    ToolUseBlock(id="tu_b", name="B", input={}),
                ],
                model="m",
                parent_tool_use_id=None,
                error=None,
                usage=None,
                message_id="m2",
                stop_reason="tool_use",
                session_id="s",
                uuid="u2",
            ),
            _make_result(),
        ],
    )
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("agent run")])
    tc_chunks = [c.tool_call_chunks[0] for c in chunks if c.tool_call_chunks]
    assert len(tc_chunks) == 2
    # First tool is the second block in message 1, so index 1.
    # Second tool is the second block in message 2 (after 2 blocks already
    # emitted), so base_index=2 + offset=1 => index 3.
    assert tc_chunks[0]["index"] == 1
    assert tc_chunks[1]["index"] == 3
    assert tc_chunks[0]["name"] == "A"
    assert tc_chunks[1]["name"] == "B"


async def test_astream_warns_on_stop_and_continues(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    _install_fake(monkeypatch, [_make_assistant("ok"), _make_result()])
    # Passing stop= must not raise; the stream path emits the same
    # logger.warning the non-streaming path does and still yields the
    # final usage chunk normally.
    model = ChatClaudeAgent()
    chunks: list[AIMessageChunk] = []
    with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
        async for chunk in model.astream([HumanMessage("hi")], stop=["END"]):
            if getattr(chunk, "chunk_position", None) == "last" and chunk.usage_metadata is None:
                continue
            chunks.append(chunk)
    assert chunks[-1].usage_metadata is not None
    warnings = [r for r in caplog.records if r.levelname == "WARNING"]
    assert len(warnings) == 1
    assert "`stop` sequences are not supported" in warnings[0].getMessage()


async def test_astream_aggregates_to_match_invoke(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The folded streaming result should match what invoke() returns.
    # This is the invariant the langchain-tests harness's test_stream
    # relies on.
    canned = [
        _make_assistant("the answer is 42"),
        _make_result(input_tokens=11, output_tokens=13),
    ]
    _install_fake(monkeypatch, canned)
    chunks = await _collect(ChatClaudeAgent(), [HumanMessage("q?")])
    folded = _fold(chunks)

    _install_fake(monkeypatch, canned)
    invoked: AIMessage = await ChatClaudeAgent().ainvoke([HumanMessage("q?")])

    assert folded.content == invoked.content
    assert folded.usage_metadata == invoked.usage_metadata
    for k in ("session_id", "total_cost_usd", "num_turns", "duration_ms"):
        assert folded.response_metadata.get(k) == invoked.response_metadata.get(k)
