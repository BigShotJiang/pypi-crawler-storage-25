"""_generate / _agenerate tests with the SDK monkeypatched."""

from __future__ import annotations

import asyncio
import subprocess
from collections.abc import AsyncIterator
from typing import Any

import pytest
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    CLINotFoundError,
    ResultMessage,
    TextBlock,
    ToolUseBlock,
)
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

import langchain_claude_agent_sdk.chat_models as chat_models_module
from langchain_claude_agent_sdk import ChatClaudeAgent


def _make_assistant(
    text: str = "ok", tool_uses: list[ToolUseBlock] | None = None
) -> AssistantMessage:
    content: list[Any] = [TextBlock(text=text)]
    if tool_uses:
        content.extend(tool_uses)
    return AssistantMessage(
        content=content,
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage={"input_tokens": 5, "output_tokens": 7},
        message_id="msg",
        stop_reason="end_turn",
        session_id="sess-1",
        uuid="u",
    )


def _make_result(session_id: str = "sess-1") -> ResultMessage:
    return ResultMessage(
        subtype="success",
        duration_ms=100,
        duration_api_ms=80,
        is_error=False,
        num_turns=1,
        session_id=session_id,
        stop_reason="end_turn",
        total_cost_usd=0.001,
        usage={"input_tokens": 5, "output_tokens": 7},
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=None,
        api_error_status=None,
        uuid="ur",
    )


class _FakeQuery:
    """Captures the args passed to ``query`` and returns canned messages."""

    def __init__(self, canned: list[Any]) -> None:
        self.canned = canned
        self.captured_prompt: Any = None
        self.captured_options: ClaudeAgentOptions | None = None

    def __call__(
        self,
        *,
        prompt: Any,
        options: ClaudeAgentOptions | None = None,
        transport: Any = None,
    ) -> AsyncIterator[Any]:
        self.captured_prompt = prompt
        self.captured_options = options
        canned = list(self.canned)

        async def _iter() -> AsyncIterator[Any]:
            for msg in canned:
                yield msg

        return _iter()


@pytest.fixture
def fake_query(monkeypatch: pytest.MonkeyPatch) -> _FakeQuery:
    fake = _FakeQuery([_make_assistant("hi there"), _make_result()])
    monkeypatch.setattr(chat_models_module, "query", fake)
    return fake


def test_generate_simple_human(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent()
    result = model.invoke([HumanMessage("hello")])
    assert isinstance(result, AIMessage)
    assert result.content == "hi there"
    assert result.usage_metadata is not None
    assert result.usage_metadata["input_tokens"] == 5
    assert result.usage_metadata["output_tokens"] == 7
    assert result.response_metadata["session_id"] == "sess-1"
    assert result.response_metadata["total_cost_usd"] == pytest.approx(0.001)
    assert fake_query.captured_prompt == "hello"


def test_generate_appends_system_prompt_by_default(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent()
    model.invoke([SystemMessage("be terse"), HumanMessage("hello")])
    opts = fake_query.captured_options
    assert opts is not None
    sp = opts.system_prompt
    assert isinstance(sp, dict)
    assert sp["type"] == "preset"
    assert sp["preset"] == "claude_code"
    assert sp["append"] == "be terse"


def test_generate_replaces_system_prompt_when_flagged(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent(append_system_prompt=False)
    model.invoke([SystemMessage("be terse"), HumanMessage("hello")])
    opts = fake_query.captured_options
    assert opts is not None
    assert opts.system_prompt == "be terse"


def test_generate_forwards_model_and_max_turns(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent(model="claude-haiku-4-5", max_turns=4)
    model.invoke([HumanMessage("hi")])
    opts = fake_query.captured_options
    assert opts is not None
    assert opts.model == "claude-haiku-4-5"
    assert opts.max_turns == 4


def test_generate_forwards_cwd_and_extra_options(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent(
        cwd="/tmp/workdir",
        extra_options={"permission_mode": "acceptEdits"},
    )
    model.invoke([HumanMessage("hi")])
    opts = fake_query.captured_options
    assert opts is not None
    assert opts.cwd == "/tmp/workdir"
    assert opts.permission_mode == "acceptEdits"


def test_extra_options_empty_dict_is_accepted() -> None:
    # Default factory path: no validation work, no error.
    model = ChatClaudeAgent()
    assert model.extra_options == {}


def test_extra_options_rejects_typo_with_did_you_mean_hint() -> None:
    # A close typo of a real ClaudeAgentOptions field should surface the
    # intended name so the user can fix it without spelunking the SDK source.
    with pytest.raises(ValueError, match=r"'permision_mode' \(did you mean 'permission_mode'\?\)"):
        ChatClaudeAgent(extra_options={"permision_mode": "acceptEdits"})


def test_extra_options_rejects_completely_unknown_key_without_suggestion() -> None:
    # When no field name is within edit-distance, the error names the bad
    # key but omits a misleading suggestion.
    with pytest.raises(ValueError, match="'totally_fictional_key'") as excinfo:
        ChatClaudeAgent(extra_options={"totally_fictional_key": 1})
    assert "did you mean" not in str(excinfo.value)


def test_extra_options_reports_all_unknown_keys_at_once() -> None:
    # A single construction error should list every bad key so users can
    # fix them in one pass rather than play whack-a-mole.
    with pytest.raises(ValueError, match="extra_options contains keys") as excinfo:
        ChatClaudeAgent(extra_options={"bogus_one": 1, "bogus_two": 2})
    msg = str(excinfo.value)
    assert "'bogus_one'" in msg
    assert "'bogus_two'" in msg


# ----- validate_cli_on_init pre-flight probe -----


def test_validate_cli_on_init_defaults_false_skips_probe(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The default must be free of subprocess work — accidentally turning
    # this on by default would spawn a process on every model
    # instantiation, including inside test suites that have no claude CLI.
    def _explode(*args: object, **kwargs: object) -> object:
        msg = "subprocess.run must not be called when validate_cli_on_init is False"
        raise AssertionError(msg)

    monkeypatch.setattr(chat_models_module.subprocess, "run", _explode)
    model = ChatClaudeAgent()
    assert model.validate_cli_on_init is False


def test_validate_cli_on_init_success_returns_silently(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[object, ...]] = []

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        calls.append((args, kwargs))
        return subprocess.CompletedProcess(args=args[0], returncode=0, stdout="1.0.0\n", stderr="")

    monkeypatch.setattr(chat_models_module.subprocess, "run", _fake_run)
    model = ChatClaudeAgent(validate_cli_on_init=True)
    assert model.validate_cli_on_init is True
    assert len(calls) == 1
    assert calls[0][0][0] == ["claude", "--version"]


def test_validate_cli_on_init_raises_clinotfound_when_binary_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _missing_binary(*args: object, **kwargs: object) -> object:
        raise FileNotFoundError(2, "No such file or directory: 'claude'")

    monkeypatch.setattr(chat_models_module.subprocess, "run", _missing_binary)
    with pytest.raises(CLINotFoundError, match="npm install -g @anthropic-ai/claude-code"):
        ChatClaudeAgent(validate_cli_on_init=True)


def test_validate_cli_on_init_raises_runtimeerror_on_nonzero_exit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _broken_install(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(
            args=args[0], returncode=127, stdout="", stderr="missing libnode.so.108"
        )

    monkeypatch.setattr(chat_models_module.subprocess, "run", _broken_install)
    with pytest.raises(RuntimeError, match=r"exited with status 127.*missing libnode\.so\.108"):
        ChatClaudeAgent(validate_cli_on_init=True)


def test_validate_cli_on_init_raises_runtimeerror_on_timeout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _hung(*args: object, **kwargs: object) -> object:
        raise subprocess.TimeoutExpired(cmd="claude --version", timeout=5.0)

    monkeypatch.setattr(chat_models_module.subprocess, "run", _hung)
    with pytest.raises(RuntimeError, match="timed out after 5s"):
        ChatClaudeAgent(validate_cli_on_init=True)


def test_validate_cli_on_init_nonzero_exit_with_empty_stderr_uses_placeholder(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The error helper substitutes a placeholder when stderr is empty so
    # the message still reads coherently instead of "stderr: ."
    def _silent_failure(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(args=args[0], returncode=1, stdout="", stderr="")

    monkeypatch.setattr(chat_models_module.subprocess, "run", _silent_failure)
    with pytest.raises(RuntimeError, match="<empty stderr>"):
        ChatClaudeAgent(validate_cli_on_init=True)


def test_generate_skips_non_assistant_non_result_sdk_messages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from claude_agent_sdk import SystemMessage as SdkSystemMessage

    canned = [
        SdkSystemMessage(subtype="init", data={"any": "thing"}),
        _make_assistant("hello"),
        _make_result(),
    ]
    fake = _FakeQuery(canned)
    monkeypatch.setattr(chat_models_module, "query", fake)
    model = ChatClaudeAgent()
    result = model.invoke([HumanMessage("hi")])
    assert result.content == "hello"


def test_generate_extracts_tool_calls(monkeypatch: pytest.MonkeyPatch) -> None:
    canned = [
        _make_assistant(
            "checking",
            tool_uses=[ToolUseBlock(id="t1", name="Bash", input={"cmd": "ls"})],
        ),
        _make_result(),
    ]
    fake = _FakeQuery(canned)
    monkeypatch.setattr(chat_models_module, "query", fake)
    model = ChatClaudeAgent()
    result = model.invoke([HumanMessage("list files")])
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "Bash"
    assert result.tool_calls[0]["args"] == {"cmd": "ls"}


def test_generate_resume_uses_session_id_from_history(fake_query: _FakeQuery) -> None:
    history = [
        HumanMessage("first"),
        AIMessage(
            "first answer",
            response_metadata={"session_id": "prev-sess"},
        ),
        HumanMessage("second"),
    ]
    model = ChatClaudeAgent()
    model.invoke(history)
    opts = fake_query.captured_options
    assert opts is not None
    assert opts.resume == "prev-sess"
    assert fake_query.captured_prompt == "second"


def test_generate_transcript_fallback_when_no_session(fake_query: _FakeQuery) -> None:
    history = [
        HumanMessage("first"),
        AIMessage("first answer"),
        HumanMessage("second"),
    ]
    model = ChatClaudeAgent()
    model.invoke(history)
    opts = fake_query.captured_options
    assert opts is not None
    assert opts.resume is None
    prompt = fake_query.captured_prompt
    assert isinstance(prompt, str)
    assert "User: first" in prompt
    assert "Assistant: first answer" in prompt
    assert prompt.rstrip().endswith("User: second")


def test_generate_warns_and_ignores_nonempty_stop_sequences(
    fake_query: _FakeQuery, caplog: pytest.LogCaptureFixture
) -> None:
    # The Claude Agent SDK does not expose stop sequences. Raising would
    # block the langchain-tests standard harness and surprise callers using
    # `stop=` uniformly across providers, so we emit a logger.warning
    # (mistralai's pattern) instead. The list is still not forwarded into
    # ClaudeAgentOptions and does not appear in the prompt.
    model = ChatClaudeAgent()
    with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
        result = model.invoke([HumanMessage("hi")], stop=["STOP", "END"])
    assert result.content == "hi there"
    assert "STOP" not in (fake_query.captured_prompt or "")
    assert "END" not in (fake_query.captured_prompt or "")
    warnings = [r for r in caplog.records if r.levelname == "WARNING"]
    assert len(warnings) == 1
    assert "`stop` sequences are not supported" in warnings[0].getMessage()


def test_generate_empty_stop_list_is_silent(
    fake_query: _FakeQuery, caplog: pytest.LogCaptureFixture
) -> None:
    # The standard-test harness invokes models with stop=[] by default;
    # warning on that would spam every harness run with noise. Empty list
    # and None both mean "no constraint" and stay quiet.
    model = ChatClaudeAgent()
    with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
        result = model.invoke([HumanMessage("hi")], stop=[])
    assert result.content == "hi there"
    assert [r for r in caplog.records if r.levelname == "WARNING"] == []


def test_generate_none_stop_is_silent(
    fake_query: _FakeQuery, caplog: pytest.LogCaptureFixture
) -> None:
    model = ChatClaudeAgent()
    with caplog.at_level("WARNING", logger="langchain_claude_agent_sdk.chat_models"):
        model.invoke([HumanMessage("hi")])
    assert [r for r in caplog.records if r.levelname == "WARNING"] == []


def test_model_field_accepts_model_kwarg(fake_query: _FakeQuery) -> None:
    # Canonical LangChain provider constructor — `model=`.
    m = ChatClaudeAgent(model="claude-sonnet-4-6")
    assert m.model == "claude-sonnet-4-6"
    m.invoke([HumanMessage("hi")])
    assert fake_query.captured_options is not None
    assert fake_query.captured_options.model == "claude-sonnet-4-6"


def test_model_field_accepts_model_name_alias(fake_query: _FakeQuery) -> None:
    # Compatibility with langchain-anthropic / langchain-openai callers
    # who pass `model_name=` uniformly across providers.
    m = ChatClaudeAgent(model_name="claude-sonnet-4-6")
    assert m.model == "claude-sonnet-4-6"
    m.invoke([HumanMessage("hi")])
    assert fake_query.captured_options is not None
    assert fake_query.captured_options.model == "claude-sonnet-4-6"


def test_generate_raises_inside_running_loop(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent()

    async def call_from_loop() -> None:
        with pytest.raises(RuntimeError, match="active event loop"):
            model.invoke([HumanMessage("hi")])

    asyncio.run(call_from_loop())


async def test_agenerate_works_inside_event_loop(fake_query: _FakeQuery) -> None:
    model = ChatClaudeAgent()
    result = await model.ainvoke([HumanMessage("hello")])
    assert result.content == "hi there"
