"""Smoke test: package imports cleanly and exposes its public surface."""

from typing import cast

from langchain_claude_agent_sdk import (
    ChatClaudeAgent,
    ClaudeAgentResponseMetadata,
    __version__,
)


def test_version_is_set() -> None:
    assert __version__
    assert isinstance(__version__, str)


def test_chat_model_class_exists() -> None:
    assert ChatClaudeAgent is not None
    assert ChatClaudeAgent.__name__ == "ChatClaudeAgent"


def test_chat_model_reports_llm_type() -> None:
    model = ChatClaudeAgent()
    assert model._llm_type == "claude-agent"


def test_response_metadata_typeddict_is_exported_and_accepts_known_keys() -> None:
    # TypedDict is a runtime-accessible class; constructing one verifies the
    # export resolves and the declared keys round-trip as a plain dict.
    meta: ClaudeAgentResponseMetadata = {
        "session_id": "sess-abc",
        "total_cost_usd": 0.0042,
        "num_turns": 3,
        "duration_ms": 1200,
        "duration_api_ms": 980,
        "stop_reason": "end_turn",
        "model_name": "claude-sonnet-4-6",
        "thinking": [{"thinking": "...", "signature": "sig"}],
        "is_error": False,
    }
    # Round-trip through cast to confirm runtime behavior is plain-dict.
    assert cast(dict[str, object], meta)["session_id"] == "sess-abc"
