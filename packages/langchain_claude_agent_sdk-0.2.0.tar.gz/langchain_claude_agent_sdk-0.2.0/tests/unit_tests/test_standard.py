"""Standard chat-model unit-test harness for ChatClaudeAgent.

Subclasses ``langchain_tests.unit_tests.ChatModelUnitTests`` so this package
runs the same conformance battery that every official LangChain partner
package (langchain-anthropic, langchain-openai, langchain-groq, ...) runs.
The harness is the de-facto entry credential for being a "real" LangChain
provider; passing it is what tells the ecosystem we hold up our end of the
contract.

Capability flags reflect the package's *current* state, not the eventual
target shape:

- ``has_tool_calling`` is left at its auto-detected default (``True``
  once ``ChatClaudeAgent.bind_tools`` is overridden — Phase 5 added the
  built-in passthrough, Phase 6 added custom tools via in-process
  MCP). The harness ``test_bind_tool_pydantic`` test passes
  :class:`~langchain_core.tools.BaseTool`, callables, Pydantic model
  classes, and dict schemas through ``bind_tools``; the Phase 6
  implementation wraps each one in an SdkMcpTool registered under the
  shared ``"langchain-tools"`` MCP server, so the harness ``assert
  isinstance(tool_model, RunnableBinding)`` clears cleanly.
- ``has_structured_output`` likewise picks up Phase 6's custom-tool
  support — LangChain's default ``with_structured_output`` routes
  through ``bind_tools`` with a Pydantic model, which now binds without
  raising.
- ``returns_usage_metadata`` is ``True``: ``_build_usage_metadata`` already
  populates ``input_tokens`` / ``output_tokens`` / ``total_tokens`` with
  cache buckets folded in and surfaced under ``input_token_details``.
- ``supports_model_override`` is ``True``: ``BaseChatModel._get_ls_params``
  already honors a per-call ``model=`` kwarg, which the harness verifies.

Tests that depend on capabilities we don't yet expose skip automatically
based on the flags above.
"""

from __future__ import annotations

from langchain_tests.unit_tests import ChatModelUnitTests

from langchain_claude_agent_sdk import ChatClaudeAgent


class TestChatClaudeAgentStandard(ChatModelUnitTests):
    @property
    def chat_model_class(self) -> type[ChatClaudeAgent]:
        return ChatClaudeAgent

    @property
    def chat_model_params(self) -> dict[str, object]:
        # The harness inspects ``ls_model_name`` (BaseChatModel._get_ls_params)
        # and requires it to be a string, not None. Pass an explicit model
        # id here so every test instantiation has one. The unit harness
        # never actually invokes the CLI, so the id only needs to be
        # plausible — no need to match a model that's currently available.
        return {"model": "claude-sonnet-4-6"}

    @property
    def returns_usage_metadata(self) -> bool:
        # _build_usage_metadata populates the field on every AIMessage
        # backed by a ResultMessage (which is every successful invoke).
        return True

    @property
    def supports_model_override(self) -> bool:
        # BaseChatModel._get_ls_params already honors model=<override>;
        # we don't customize that path, so the override surfaces in
        # ls_model_name unchanged. Verified separately in test_generate.py.
        return True

    @property
    def model_override_value(self) -> str:
        # Used by test_standard_params_model_override. Any plausible model
        # id works — the test only checks the value round-trips through
        # _get_ls_params, not that the model actually exists.
        return "claude-haiku-4-5"
