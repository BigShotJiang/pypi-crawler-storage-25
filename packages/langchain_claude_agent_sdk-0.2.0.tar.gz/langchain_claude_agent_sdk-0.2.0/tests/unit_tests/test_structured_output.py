"""with_structured_output override (JSON-schema prompting).

The override exists because the Claude Agent SDK does not honor
``tool_choice``; the canonical ``BaseChatModel.with_structured_output``
path returns ``None`` against the real CLI. These tests pin the
JSON-prompting behavior, the canonical ``include_raw`` shape, the
canonical signature (``method`` / ``strict`` / ``**kwargs``), and the
explicit guarantee that no tool / MCP server is registered.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any, TypedDict

import pytest
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ResultMessage,
    TextBlock,
)
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, Field

import langchain_claude_agent_sdk.chat_models as chat_models_module
from langchain_claude_agent_sdk import ChatClaudeAgent


def _assistant(text: str) -> AssistantMessage:
    return AssistantMessage(
        content=[TextBlock(text=text)],
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id="msg",
        stop_reason="end_turn",
        session_id="sess",
        uuid="u",
    )


def _result() -> ResultMessage:
    return ResultMessage(
        subtype="success",
        duration_ms=10,
        duration_api_ms=8,
        is_error=False,
        num_turns=1,
        session_id="sess",
        stop_reason="end_turn",
        total_cost_usd=0.0,
        usage={"input_tokens": 1, "output_tokens": 1},
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=None,
        api_error_status=None,
        uuid="ur",
    )


class _FakeQuery:
    """Records the prompt/options the SDK call would have received."""

    def __init__(self, text: str) -> None:
        self.text = text
        self.captured_options: ClaudeAgentOptions | None = None
        self.captured_prompt: str | None = None

    def __call__(
        self,
        *,
        prompt: Any,
        options: ClaudeAgentOptions | None = None,
        transport: Any = None,
    ) -> AsyncIterator[Any]:
        self.captured_options = options
        self.captured_prompt = prompt

        async def _iter() -> AsyncIterator[Any]:
            yield _assistant(self.text)
            yield _result()

        return _iter()


class _Plan(BaseModel):
    """A research plan."""

    topic: str = Field(description="Subject of the plan")
    steps: list[str] = Field(default_factory=list)


def test_with_structured_output_returns_pydantic_instance(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeQuery(text=json.dumps({"topic": "FORTRAN", "steps": ["one", "two"]}))
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    result = structured.invoke([HumanMessage("plan FORTRAN history")])

    assert isinstance(result, _Plan)
    assert result.topic == "FORTRAN"
    assert result.steps == ["one", "two"]


def test_with_structured_output_returns_dict_for_dict_schema(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeQuery(text='{"name": "Ada", "age": 36}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    schema = {
        "name": "person",
        "description": "a person",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name", "age"],
        },
    }
    structured = ChatClaudeAgent().with_structured_output(schema)
    result = structured.invoke([HumanMessage("describe Ada")])

    assert result == {"name": "Ada", "age": 36}


def test_with_structured_output_returns_dict_for_typeddict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Person(TypedDict):
        name: str
        age: int

    fake = _FakeQuery(text='{"name": "Ada", "age": 36}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(Person)
    result = structured.invoke([HumanMessage("describe Ada")])

    assert result == {"name": "Ada", "age": 36}


def test_with_structured_output_tolerates_markdown_fences(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The instructions explicitly tell the model not to use fences, but
    # JsonOutputParser (and its PydanticOutputParser subclass) strip them
    # via parse_json_markdown for free — exercise that fallback so a
    # less-compliant model still produces a parsed result.
    fake = _FakeQuery(text='```json\n{"topic": "X", "steps": []}\n```')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    result = structured.invoke([HumanMessage("x")])

    assert isinstance(result, _Plan)
    assert result.topic == "X"


def test_with_structured_output_injects_schema_into_system_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    structured.invoke([HumanMessage("x")])

    opts = fake.captured_options
    assert opts is not None
    # Default ``append_system_prompt=True`` builds a preset dict and
    # carries our JSON instructions in ``append``. The schema's field
    # names must appear so the model has the contract to satisfy.
    sp = opts.system_prompt
    assert isinstance(sp, dict)
    assert sp.get("type") == "preset"
    assert sp.get("preset") == "claude_code"
    append_text = sp.get("append") or ""
    assert "JSON schema" in append_text
    assert "topic" in append_text  # field name from _Plan
    assert "steps" in append_text


def test_with_structured_output_does_not_bind_schema_as_tool(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The whole point of this override: we go through prompting, NOT
    # through bind_tools + tool_choice (which the SDK cannot enforce).
    # ``allowed_tools`` / ``mcp_servers`` must be untouched so the model
    # does not see a competing schema-tool affordance.
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    structured.invoke([HumanMessage("x")])

    opts = fake.captured_options
    assert opts is not None
    assert not opts.allowed_tools
    assert not opts.mcp_servers


def test_with_structured_output_preserves_user_system_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # A caller-supplied SystemMessage must remain in place; the JSON
    # instructions get inserted *after* it so the JSON-only directive
    # is the last system-level guidance the model reads.
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    structured.invoke([SystemMessage("You answer with great care."), HumanMessage("x")])

    opts = fake.captured_options
    assert opts is not None
    sp = opts.system_prompt
    assert isinstance(sp, dict)
    append_text = sp.get("append") or ""
    user_idx = append_text.find("answer with great care")
    schema_idx = append_text.find("JSON schema")
    assert user_idx >= 0
    assert schema_idx >= 0
    assert user_idx < schema_idx


def test_with_structured_output_accepts_string_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # LangChain's LanguageModelInput allows bare strings; ensure
    # _coerce_to_messages wraps them into a HumanMessage rather than
    # iterating the string itself.
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    result = structured.invoke("plan X")

    assert isinstance(result, _Plan)
    assert fake.captured_prompt == "plan X"


def test_with_structured_output_include_raw(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeQuery(text='{"topic": "X", "steps": ["a"]}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan, include_raw=True)
    result = structured.invoke([HumanMessage("x")])

    assert isinstance(result, dict)
    assert set(result.keys()) == {"raw", "parsed", "parsing_error"}
    assert result["parsing_error"] is None
    parsed = result["parsed"]
    assert isinstance(parsed, _Plan)
    assert parsed.topic == "X"
    raw = result["raw"]
    assert isinstance(raw, AIMessage)
    # The CLI-only response_metadata round-trips through the raw payload
    # so callers using include_raw can still inspect cost / session_id /
    # token usage exactly as if they had called .invoke() directly.
    assert raw.response_metadata.get("session_id") == "sess"
    assert raw.usage_metadata is not None


def test_with_structured_output_include_raw_records_parse_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # If the model writes prose instead of JSON, include_raw must still
    # return the raw AIMessage and set parsing_error rather than blowing
    # up — matches the canonical BaseChatModel contract.
    fake = _FakeQuery(text="Sorry, here is some prose instead.")
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan, include_raw=True)
    result = structured.invoke([HumanMessage("x")])

    assert result["parsed"] is None
    assert result["parsing_error"] is not None
    assert "Sorry" in result["raw"].content


def test_with_structured_output_method_kwarg_accepted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The standard harness's test_with_structured_output iterates over
    # method ∈ {"json_schema", "function_calling", "json_mode"} and
    # strict ∈ {None, False, True}; all permutations must produce a
    # working Runnable. We route every method through the same
    # JSON-prompting impl, but the kwargs must be silently accepted.
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    model = ChatClaudeAgent()
    for method in ("json_schema", "function_calling", "json_mode"):
        for strict in (None, False, True):
            runnable = model.with_structured_output(_Plan, method=method, strict=strict)
            assert runnable is not None
            assert isinstance(runnable.invoke([HumanMessage("x")]), _Plan)


def test_with_structured_output_rejects_unsupported_kwargs() -> None:
    with pytest.raises(ValueError, match="unsupported arguments"):
        ChatClaudeAgent().with_structured_output(_Plan, frobnicate=True)


def test_with_structured_output_rejects_none_schema() -> None:
    with pytest.raises(ValueError, match="non-None schema"):
        ChatClaudeAgent().with_structured_output(None)


async def test_with_structured_output_works_via_ainvoke(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeQuery(text='{"topic": "X", "steps": ["a"]}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    result = await structured.ainvoke([HumanMessage("x")])

    assert isinstance(result, _Plan)
    assert result.steps == ["a"]


def test_with_structured_output_accepts_prompt_value(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # ChatPromptTemplate.format_prompt(...) returns a PromptValue;
    # LangChain pipelines hand that shape to the model. Ensure the
    # inject lambda routes through PromptValue.to_messages() instead of
    # treating the PromptValue like an iterable of characters.
    from langchain_core.prompts import ChatPromptTemplate

    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    prompt = ChatPromptTemplate.from_messages([("human", "{topic}")])
    structured = ChatClaudeAgent().with_structured_output(_Plan)
    result = structured.invoke(prompt.format_prompt(topic="FORTRAN"))

    assert isinstance(result, _Plan)
    assert fake.captured_prompt == "FORTRAN"


def test_with_structured_output_rejects_unsupported_input_type(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # An int (or any non-str / non-PromptValue / non-Sequence input)
    # should surface a clear TypeError rather than crashing somewhere
    # deeper in the pipeline.
    fake = _FakeQuery(text='{"topic": "X", "steps": []}')
    monkeypatch.setattr(chat_models_module, "query", fake)

    structured = ChatClaudeAgent().with_structured_output(_Plan)
    with pytest.raises(TypeError, match="Unsupported input type"):
        structured.invoke(42)  # type: ignore[arg-type]
