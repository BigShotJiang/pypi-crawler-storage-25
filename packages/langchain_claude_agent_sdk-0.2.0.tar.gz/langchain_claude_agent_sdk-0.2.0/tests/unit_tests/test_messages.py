"""Translation helpers between LangChain messages and the SDK wire format."""

from __future__ import annotations

import pytest
from claude_agent_sdk import (
    AssistantMessage,
    ResultMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
)
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from langchain_claude_agent_sdk._messages import prepare_prompt, to_ai_message


def test_prepare_prompt_single_human() -> None:
    prepared = prepare_prompt([HumanMessage("hello")])
    assert prepared.new_user_text == "hello"
    assert prepared.system_text is None
    assert prepared.resume_session_id is None
    assert prepared.transcript_prefix is None


def test_prepare_prompt_system_plus_human() -> None:
    prepared = prepare_prompt([SystemMessage("be brief"), HumanMessage("hello")])
    assert prepared.system_text == "be brief"
    assert prepared.new_user_text == "hello"
    assert prepared.resume_session_id is None


def test_prepare_prompt_multiple_system_messages_join() -> None:
    prepared = prepare_prompt([SystemMessage("one"), SystemMessage("two"), HumanMessage("q")])
    assert prepared.system_text == "one\n\ntwo"


def test_prepare_prompt_resume_uses_latest_session_id() -> None:
    prepared = prepare_prompt(
        [
            HumanMessage("first"),
            AIMessage("first answer", response_metadata={"session_id": "old-sess"}),
            HumanMessage("second"),
            AIMessage("second answer", response_metadata={"session_id": "new-sess"}),
            HumanMessage("third"),
        ]
    )
    assert prepared.resume_session_id == "new-sess"
    assert prepared.new_user_text == "third"
    assert prepared.transcript_prefix is None


def test_prepare_prompt_transcript_fallback_when_no_session_id() -> None:
    prepared = prepare_prompt(
        [
            HumanMessage("first"),
            AIMessage("first answer"),
            HumanMessage("second"),
        ]
    )
    assert prepared.resume_session_id is None
    assert prepared.new_user_text == "second"
    assert prepared.transcript_prefix is not None
    assert "User: first" in prepared.transcript_prefix
    assert "Assistant: first answer" in prepared.transcript_prefix


def test_prepare_prompt_includes_tool_messages_after_resume() -> None:
    prepared = prepare_prompt(
        [
            HumanMessage("compute 2+2"),
            AIMessage(
                "calling tool",
                response_metadata={"session_id": "sess-1"},
                tool_calls=[{"name": "calc", "args": {"x": 2}, "id": "tu_1", "type": "tool_call"}],
            ),
            ToolMessage("4", tool_call_id="tu_1", name="calc"),
            HumanMessage("thanks"),
        ]
    )
    assert prepared.resume_session_id == "sess-1"
    assert "[tool calc result]" in prepared.new_user_text
    assert "4" in prepared.new_user_text
    assert "thanks" in prepared.new_user_text


def test_prepare_prompt_empty_raises() -> None:
    with pytest.raises(ValueError, match="at least one message"):
        prepare_prompt([])


def test_prepare_prompt_system_only_raises() -> None:
    with pytest.raises(ValueError, match="non-system message"):
        prepare_prompt([SystemMessage("only system")])


def test_prepare_prompt_resume_without_followup_raises() -> None:
    with pytest.raises(ValueError, match="No new user input"):
        prepare_prompt(
            [
                HumanMessage("hi"),
                AIMessage("hi back", response_metadata={"session_id": "sess"}),
            ]
        )


def test_to_ai_message_extracts_text_and_usage() -> None:
    assistant = AssistantMessage(
        content=[TextBlock(text="hello ")],
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage={
            "input_tokens": 12,
            "output_tokens": 3,
            "cache_creation_input_tokens": 100,
            "cache_read_input_tokens": 200,
        },
        message_id="msg_1",
        stop_reason="end_turn",
        session_id="sess-xyz",
        uuid="u1",
    )
    assistant2 = AssistantMessage(
        content=[TextBlock(text="world")],
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id="msg_1",
        stop_reason="end_turn",
        session_id="sess-xyz",
        uuid="u2",
    )
    result = ResultMessage(
        subtype="success",
        duration_ms=1234,
        duration_api_ms=900,
        is_error=False,
        num_turns=2,
        session_id="sess-xyz",
        stop_reason="end_turn",
        total_cost_usd=0.0123,
        usage={
            "input_tokens": 12,
            "output_tokens": 3,
            "cache_creation_input_tokens": 100,
            "cache_read_input_tokens": 200,
        },
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=None,
        api_error_status=None,
        uuid="ur",
    )

    ai = to_ai_message([assistant, assistant2], result)
    assert ai.content == "hello world"
    assert ai.id == "msg_1"
    assert ai.usage_metadata is not None
    assert ai.usage_metadata["input_tokens"] == 12 + 100 + 200
    assert ai.usage_metadata["output_tokens"] == 3
    assert ai.usage_metadata["total_tokens"] == 12 + 3 + 100 + 200
    assert ai.usage_metadata["input_token_details"]["cache_creation"] == 100
    assert ai.usage_metadata["input_token_details"]["cache_read"] == 200
    assert ai.response_metadata["session_id"] == "sess-xyz"
    assert ai.response_metadata["total_cost_usd"] == pytest.approx(0.0123)
    assert ai.response_metadata["num_turns"] == 2
    assert ai.response_metadata["duration_ms"] == 1234
    assert ai.response_metadata["model_name"] == "claude-sonnet-4-6"
    assert ai.response_metadata["stop_reason"] == "end_turn"


def test_to_ai_message_extracts_tool_calls() -> None:
    assistant = AssistantMessage(
        content=[
            TextBlock(text="let me look"),
            ToolUseBlock(id="tu_abc", name="Read", input={"path": "/x"}),
        ],
        model="claude-sonnet-4-6",
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id="msg",
        stop_reason="tool_use",
        session_id="s",
        uuid="u",
    )
    ai = to_ai_message([assistant], None)
    assert ai.content == "let me look"
    assert len(ai.tool_calls) == 1
    tc = ai.tool_calls[0]
    assert tc["name"] == "Read"
    assert tc["args"] == {"path": "/x"}
    assert tc["id"] == "tu_abc"
    assert tc["type"] == "tool_call"


def test_to_ai_message_preserves_thinking_blocks() -> None:
    assistant = AssistantMessage(
        content=[
            ThinkingBlock(thinking="hmm", signature="sig-1"),
            TextBlock(text="answer"),
        ],
        model="m",
        parent_tool_use_id=None,
        error=None,
        usage=None,
        message_id=None,
        stop_reason=None,
        session_id=None,
        uuid="u",
    )
    ai = to_ai_message([assistant], None)
    assert ai.content == "answer"
    assert ai.response_metadata["thinking"] == [{"thinking": "hmm", "signature": "sig-1"}]


def test_to_ai_message_no_usage_when_result_missing() -> None:
    ai = to_ai_message([], None)
    assert ai.usage_metadata is None
    assert ai.content == ""
    assert ai.tool_calls == []


def test_usage_metadata_total_equals_input_plus_output() -> None:
    # The LangChain UsageMetadata contract: total_tokens == input + output.
    # `input_tokens` includes cached portions; cache buckets are also
    # surfaced under input_token_details. This is the invariant that any
    # external cost calculator (langsmith, callbacks) will rely on.
    from langchain_claude_agent_sdk._messages import _build_usage_metadata

    cases = [
        # (raw_usage, expected_input, expected_total)
        ({"input_tokens": 0, "output_tokens": 0}, 0, 0),
        ({"input_tokens": 10, "output_tokens": 5}, 10, 15),
        (
            {
                "input_tokens": 12,
                "output_tokens": 3,
                "cache_creation_input_tokens": 100,
                "cache_read_input_tokens": 200,
            },
            312,
            315,
        ),
        (
            {
                "input_tokens": 0,  # all input came from cache hits
                "output_tokens": 7,
                "cache_read_input_tokens": 500,
            },
            500,
            507,
        ),
    ]
    for raw, expected_input, expected_total in cases:
        u = _build_usage_metadata(raw)
        assert u is not None, raw
        assert u["input_tokens"] == expected_input, raw
        assert u["total_tokens"] == expected_total, raw
        assert u["total_tokens"] == u["input_tokens"] + u["output_tokens"], raw


def test_to_ai_message_marks_is_error_in_response_metadata() -> None:
    result = ResultMessage(
        subtype="error_during_execution",
        duration_ms=10,
        duration_api_ms=5,
        is_error=True,
        num_turns=1,
        session_id="s",
        stop_reason=None,
        total_cost_usd=None,
        usage=None,
        result=None,
        structured_output=None,
        model_usage=None,
        permission_denials=None,
        deferred_tool_use=None,
        errors=["boom"],
        api_error_status=None,
        uuid="ur",
    )
    ai = to_ai_message([], result)
    assert ai.response_metadata["is_error"] is True


def test_prepare_prompt_handles_block_list_content() -> None:
    # Text-typed dict blocks interleaved with bare strings are concatenated;
    # this is the canonical LangChain content shape for text-only messages.
    prepared = prepare_prompt(
        [
            SystemMessage(
                content=[
                    {"type": "text", "text": "alpha "},
                    "beta",
                ]
            ),
            HumanMessage(content=[{"type": "text", "text": "ping"}]),
        ]
    )
    assert prepared.system_text == "alpha beta"
    assert prepared.new_user_text == "ping"


def test_prepare_prompt_rejects_image_url_block_with_actionable_error() -> None:
    # The Agent SDK routes through the CLI as plain text, so non-text content
    # blocks (image_url, image, etc.) cannot be forwarded. Silently dropping
    # them — the prior behavior — let a user pass a vision-style message and
    # get a baffling "Claude ignored my image" response. Surface the limit
    # explicitly at translation time.
    with pytest.raises(ValueError, match="unsupported content block of type 'image_url'"):
        prepare_prompt(
            [
                HumanMessage(
                    content=[
                        {"type": "text", "text": "what's in this image?"},
                        {"type": "image_url", "image_url": "https://example.com/cat.png"},
                    ]
                )
            ]
        )


def test_prepare_prompt_rejects_unknown_dict_block_type() -> None:
    with pytest.raises(ValueError, match="unsupported content block of type 'mystery'"):
        prepare_prompt([HumanMessage(content=[{"type": "mystery", "data": "x"}])])


def test_prepare_prompt_rejects_non_dict_non_str_block() -> None:
    # Defensive: a malformed list element that's neither str nor dict should
    # fail loudly rather than be silently ``str()``-coerced and confuse the
    # model. Pydantic's own validator rejects this shape at construction
    # time, so we go through ``object.__setattr__`` to reach the defensive
    # branch (mirrors test_prepare_prompt_falls_back_when_content_is_unexpected_type).
    msg = HumanMessage("placeholder")
    object.__setattr__(msg, "content", [42])
    with pytest.raises(ValueError, match="unsupported content block of type int"):
        prepare_prompt([msg])


def test_prepare_prompt_transcript_includes_tool_calls_and_tool_messages() -> None:
    prepared = prepare_prompt(
        [
            HumanMessage("what's 2+2?"),
            AIMessage(
                "calling tool",
                tool_calls=[{"name": "calc", "args": {"x": 2}, "id": "tu1", "type": "tool_call"}],
            ),
            ToolMessage("4", tool_call_id="tu1", name="calc"),
            AIMessage("the answer is 4"),
            HumanMessage("thanks"),
        ]
    )
    assert prepared.resume_session_id is None
    assert prepared.transcript_prefix is not None
    transcript = prepared.transcript_prefix
    assert "User: what's 2+2?" in transcript
    assert "Assistant: calling tool" in transcript
    assert "Assistant tool call calc(" in transcript
    assert "Tool[calc]: 4" in transcript
    assert "Assistant: the answer is 4" in transcript
    assert prepared.new_user_text == "thanks"


def test_prepare_prompt_history_with_no_human_raises() -> None:
    # When the body has no HumanMessage at all (e.g., orphan AIMessage +
    # ToolMessage), there is nothing to send and we surface a clear error.
    with pytest.raises(ValueError, match="end with a HumanMessage"):
        prepare_prompt(
            [
                AIMessage("orphan reply"),
                ToolMessage("orphan tool", tool_call_id="tu1", name="calc"),
            ]
        )


def test_prepare_prompt_falls_back_when_content_is_unexpected_type() -> None:
    msg = HumanMessage("placeholder")
    object.__setattr__(msg, "content", 42)
    prepared = prepare_prompt([msg])
    assert prepared.new_user_text == "42"
