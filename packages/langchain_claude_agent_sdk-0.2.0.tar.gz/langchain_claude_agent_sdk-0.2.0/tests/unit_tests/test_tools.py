"""Unit tests for the LangChain -> SdkMcpTool conversion in _tools.py."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import pytest
from claude_agent_sdk import SdkMcpTool
from langchain_core.tools import tool
from pydantic import BaseModel

from langchain_claude_agent_sdk._tools import (
    LANGCHAIN_TOOL_SERVER_NAME,
    _normalize_tool,
    build_mcp_server_from_tools,
    qualified_tool_name,
)


def _run(coro: Any) -> Any:
    return asyncio.run(coro)


def test_qualified_tool_name_format() -> None:
    assert qualified_tool_name("my_tool") == "mcp__langchain-tools__my_tool"


def test_normalize_basetool_preserves_name_description_schema() -> None:
    @tool
    def adder(a: int, b: int) -> int:
        """Sum two integers."""
        return a + b

    sdk_tool = _normalize_tool(adder)
    assert isinstance(sdk_tool, SdkMcpTool)
    assert sdk_tool.name == "adder"
    assert "Sum two integers" in sdk_tool.description
    assert sdk_tool.input_schema["properties"]["a"]["type"] == "integer"
    assert sdk_tool.input_schema["properties"]["b"]["type"] == "integer"
    assert sorted(sdk_tool.input_schema["required"]) == ["a", "b"]


def test_basetool_handler_invokes_and_serializes_string_result() -> None:
    @tool
    def greet(name: str) -> str:
        """Greet someone."""
        return f"hello {name}"

    sdk_tool = _normalize_tool(greet)
    out = _run(sdk_tool.handler({"name": "Blake"}))
    assert out == {"content": [{"type": "text", "text": "hello Blake"}]}


def test_basetool_handler_json_serializes_non_string_result() -> None:
    @tool
    def doubler(x: int) -> dict[str, int]:
        """Return doubled value as a dict."""
        return {"result": x * 2}

    sdk_tool = _normalize_tool(doubler)
    out = _run(sdk_tool.handler({"x": 7}))
    assert out["content"][0]["type"] == "text"
    assert json.loads(out["content"][0]["text"]) == {"result": 14}
    assert "is_error" not in out


def test_basetool_handler_returns_is_error_on_exception() -> None:
    @tool
    def boom(x: int) -> int:
        """Always raise."""
        raise ValueError(f"boom-{x}")

    sdk_tool = _normalize_tool(boom)
    out = _run(sdk_tool.handler({"x": 1}))
    assert out["is_error"] is True
    assert "boom-1" in out["content"][0]["text"]


def test_normalize_callable_uses_tool_decorator() -> None:
    def triple(x: int) -> int:
        """Triple the input."""
        return x * 3

    sdk_tool = _normalize_tool(triple)
    assert sdk_tool.name == "triple"
    assert "Triple the input" in sdk_tool.description
    out = _run(sdk_tool.handler({"x": 4}))
    assert out["content"][0]["text"] == "12"


def test_normalize_pydantic_class_uses_echo_handler() -> None:
    class SearchQuery(BaseModel):
        """Query string for searching."""

        q: str
        limit: int = 10

    sdk_tool = _normalize_tool(SearchQuery)
    assert sdk_tool.name == "SearchQuery"
    assert "Query string" in sdk_tool.description
    # Echo handler: returns args as JSON without invoking anything.
    out = _run(sdk_tool.handler({"q": "claude", "limit": 5}))
    assert json.loads(out["content"][0]["text"]) == {"q": "claude", "limit": 5}
    assert "is_error" not in out


def test_normalize_dict_schema_openai_function_shape() -> None:
    spec = {
        "type": "function",
        "function": {
            "name": "lookup",
            "description": "Look something up.",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        },
    }
    sdk_tool = _normalize_tool(spec)
    assert sdk_tool.name == "lookup"
    assert sdk_tool.description == "Look something up."
    assert sdk_tool.input_schema["properties"]["key"]["type"] == "string"


def test_normalize_dict_schema_bare_tool_shape() -> None:
    # Some callers pass a bare {name, description, parameters} dict
    # rather than the OpenAI wrapper.
    spec = {
        "name": "noop",
        "description": "Does nothing.",
        "parameters": {"type": "object", "properties": {}},
    }
    sdk_tool = _normalize_tool(spec)
    assert sdk_tool.name == "noop"
    assert sdk_tool.description == "Does nothing."


def test_normalize_unsupported_type_raises() -> None:
    with pytest.raises(TypeError, match="Unsupported tool type"):
        _normalize_tool(42)


def test_build_mcp_server_returns_server_and_allowed_list() -> None:
    @tool
    def alpha(x: int) -> int:
        """alpha."""
        return x

    @tool
    def beta(y: str) -> str:
        """beta."""
        return y

    server, allowed = build_mcp_server_from_tools([alpha, beta])
    assert server["type"] == "sdk"
    assert server["name"] == LANGCHAIN_TOOL_SERVER_NAME
    assert allowed == [
        "mcp__langchain-tools__alpha",
        "mcp__langchain-tools__beta",
    ]


def test_build_mcp_server_with_no_tools_returns_empty_allowed() -> None:
    server, allowed = build_mcp_server_from_tools([])
    assert server["name"] == LANGCHAIN_TOOL_SERVER_NAME
    assert allowed == []


def test_normalize_dict_schema_falls_back_when_convert_fails() -> None:
    # A dict that convert_to_openai_tool can't normalize: no "type"
    # field, no openai wrapper. We still pull name/description/parameters
    # off the raw dict.
    spec = {
        "name": "raw_tool",
        "description": "a raw tool",
        "input_schema": {"type": "object", "properties": {"k": {"type": "string"}}},
    }
    sdk_tool = _normalize_tool(spec)
    assert sdk_tool.name == "raw_tool"
    assert sdk_tool.description == "a raw tool"
    assert sdk_tool.input_schema["properties"]["k"]["type"] == "string"


def test_normalize_dict_schema_defaults_when_nothing_extractable() -> None:
    # Convert_to_openai_tool may succeed with a degenerate result, or
    # fail outright. Either way, an empty dict still produces a usable
    # SdkMcpTool with the canonical empty-object schema.
    sdk_tool = _normalize_tool({})
    assert sdk_tool.name == "tool"
    assert sdk_tool.description == "tool"
    assert sdk_tool.input_schema == {"type": "object", "properties": {}}


def test_basetool_handler_serializes_custom_object_via_default_str() -> None:
    # Drive the json.dumps(default=str) fallback by returning an object
    # that json can't natively serialize. str(obj) lands in the text.
    @tool
    def make_box():  # type: ignore[no-untyped-def]
        """Return a custom object."""

        class Box:
            def __repr__(self) -> str:
                return "Box(unjsonable)"

        return Box()

    sdk_tool = _normalize_tool(make_box)
    out = _run(sdk_tool.handler({}))
    assert "Box(unjsonable)" in out["content"][0]["text"]
    assert "is_error" not in out


def test_extract_schema_accepts_a_bare_dict() -> None:
    # If somebody hands us a BaseTool whose args_schema is itself a
    # dict (custom subclass), pass it straight through. Mirrors how
    # langchain-anthropic's helpers treat already-rendered schemas.
    from langchain_claude_agent_sdk._tools import _extract_schema

    schema = {"type": "object", "properties": {"x": {"type": "integer"}}}
    assert _extract_schema(schema) is schema


def test_extract_schema_returns_empty_for_unknown_object() -> None:
    from langchain_claude_agent_sdk._tools import _extract_schema

    class Plain:
        pass

    assert _extract_schema(Plain) == {"type": "object", "properties": {}}


def test_extract_schema_handles_pydantic_v1_style_class() -> None:
    # A class that exposes .schema() (v1-style) but not
    # .model_json_schema() should be unwrapped via the v1 path.
    from langchain_claude_agent_sdk._tools import _extract_schema

    class V1Like:
        @staticmethod
        def schema() -> dict[str, Any]:
            return {"type": "object", "properties": {"y": {"type": "string"}}}

    extracted = _extract_schema(V1Like)
    assert extracted["properties"]["y"]["type"] == "string"


def test_extract_schema_pydantic_v2_failure_falls_back_to_empty() -> None:
    from langchain_claude_agent_sdk._tools import _extract_schema

    class BrokenV2:
        @staticmethod
        def model_json_schema() -> dict[str, Any]:
            raise RuntimeError("schema generation blew up")

    assert _extract_schema(BrokenV2) == {"type": "object", "properties": {}}


def test_extract_schema_pydantic_v1_failure_falls_back_to_empty() -> None:
    from langchain_claude_agent_sdk._tools import _extract_schema

    class BrokenV1:
        @staticmethod
        def schema() -> dict[str, Any]:
            raise RuntimeError("v1 schema generation blew up")

    assert _extract_schema(BrokenV1) == {"type": "object", "properties": {}}
