# Changelog

All notable changes to `langchain-claude-agent-sdk` are documented in this
file.

The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/)
and this project adheres to [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html).

Pre-1.0.0 versions follow [ZeroVer](https://0ver.org/): minor versions may
contain breaking changes. Once a stable 1.0.0 ships, the usual SemVer
guarantees apply.

## v0.2.0 — 2026-05-23

Developer-experience release. Three rounds of changes informed by a
side-by-side audit of `langchain-anthropic`, `langchain-openai`,
`langchain-mistralai`, and `langchain-ollama`: lift the dominant pattern
where one exists, diverge consciously toward `langchain-ollama`'s shape
on the items where we're structurally closer to it (local-subsystem,
not hosted API), and ship one deliberate differentiator
(`ClaudeAgentResponseMetadata`) where our metadata surface is unusually
rich. No backwards-incompatible runtime behavior for callers who weren't
relying on previously-silent failure modes — see the "Changed" entries
for the two callable-visible deltas.

### Added

- **`extra_options` keys are validated at construction time.** Each key
  in the dict passed to `ChatClaudeAgent(extra_options=...)` is checked
  against the set of field names on the pinned
  `claude_agent_sdk.ClaudeAgentOptions`. Unknown keys raise `ValueError`
  listing every bad key in one shot, with a `difflib`-driven "did you
  mean" hint for close typos (`'permision_mode' (did you mean
  'permission_mode'?)`). Replaces the prior opaque dataclass `TypeError`
  surfaced at the first `query()` call. Patterned after the
  warn-on-unknown idiom shared by `langchain-openai` /
  `langchain-mistralai` (via `langchain_core.utils._build_model_kwargs`),
  adapted for our explicit `extra_options` shape.
- **Opt-in `validate_cli_on_init` pre-flight probe.** New
  `validate_cli_on_init: bool = False` constructor field. When `True`,
  the model runs `claude --version` at construction time and raises
  `claude_agent_sdk.CLINotFoundError` (with the npm install command and
  a `claude login` reminder) if the binary isn't on PATH, or
  `RuntimeError` if the probe exits non-zero or times out. Defaults to
  `False` so existing callers see no behavior change; opt in when
  constructing the model far from where it's used (web servers, test
  fixtures, long-lived workers) so missing-CLI failures surface near
  the bad-install diagnostic instead of deep in a request handler.
  Structural analogue of `langchain-ollama`'s `validate_model_on_init`
  — both packages target a local subsystem where bad-install errors are
  the dominant first-time-user pain.
- **`ClaudeAgentResponseMetadata` TypedDict export.** New
  `from langchain_claude_agent_sdk import ClaudeAgentResponseMetadata`
  gives static-typed access to the CLI-only keys this package adds to
  `AIMessage.response_metadata` (`session_id`, `total_cost_usd`,
  `num_turns`, `duration_ms`, `duration_api_ms`, `stop_reason`,
  `model_name`, `thinking`, `is_error`). LangChain's
  `AIMessage.response_metadata` is typed `dict[str, Any]` upstream, so
  callers `cast(ClaudeAgentResponseMetadata, response.response_metadata)`
  to recover IDE / mypy field-name help. No comparable partner package
  ships one; this is a deliberate differentiator since our metadata
  surface is unusually rich (cost, session, durations vs. just
  `finish_reason`).
- **`examples` optional-dependency group + new structured-output
  example.** `pyproject.toml` now defines
  `[project.optional-dependencies.examples]` with `langgraph` as the
  only entry; install via `uv sync --extra examples` (or
  `pip install "langchain-claude-agent-sdk[examples]"`). Closes a
  friction point where a contributor who ran `make install` and then
  tried `examples/05_langgraph_agent.py` got `ImportError`. New
  `examples/06_structured_output.py` walks `with_structured_output`
  through a Pydantic model, a bare JSON-schema dict, and the
  `include_raw=True` shape that exposes `session_id` /
  `total_cost_usd` alongside the parsed result.
- **`make bootstrap` target.** One-shot `make install && make
  install-hooks` for new contributors. `make install` and
  `make install-hooks` remain as discrete targets so CI and scripted
  environments can opt out of hook installation. `CONTRIBUTING.md`
  updated to recommend `bootstrap`.

### Changed

- **Non-text content blocks now raise instead of being silently
  dropped.** Passing
  `HumanMessage(content=[{"type": "image_url", ...}, ...])` used to
  drop the image block on the floor and forward only the text — a
  confusing "Claude ignored my image" outcome with no diagnostic. The
  translation layer now raises `ValueError` naming the unsupported
  block type and explaining that the Agent SDK routes through the CLI
  as plain text. Affects `HumanMessage` / `SystemMessage` /
  `ToolMessage` content lists. Aligns with how every partner package
  (`anthropic`, `openai`, `mistralai`, `ollama`) handles unknown
  content blocks: translate or refuse, never silently drop. **Callers
  who were relying on the silent-drop behavior to ignore image blocks
  will need to filter their content lists upstream of
  `ChatClaudeAgent`.**
- **Silently-ignored kwargs now emit `logger.warning` instead of being
  truly silent.** Passing `stop=[...]` to `invoke()` / `astream()` or
  `tool_choice="any"` / `"required"` / `"none"` /
  `{"type": "tool", ...}` to `bind_tools()` now logs a warning on
  `langchain_claude_agent_sdk.chat_models` explaining the SDK can't
  honor the request, so the silent divergence from
  `langchain-anthropic` / `langchain-openai` becomes visible in
  standard observability. `stop=None`, `stop=[]`, `tool_choice=None`,
  and `tool_choice="auto"` stay quiet — they describe the SDK's actual
  behavior and the harness's default invocation would otherwise spam
  every test run. Matches `langchain-mistralai`'s pattern for
  unsupported `stop`.
- **`make lint` now also runs `ruff format --check`.** Brings the local
  pre-PR bar in line with every comparator partner package
  (`langchain-anthropic`, `langchain-openai`, `langchain-mistralai`,
  `langchain-ollama`) and with what our own CI already enforces. A
  contributor who skips the pre-commit hooks no longer learns about
  format drift only from a red CI run.

### Fixed

- **`_text_of` no longer silently drops malformed content list items.**
  Defensive raise (`ValueError` naming the bad block type) for the
  cases Pydantic's `HumanMessage(content=[...])` validator does not
  itself catch. See the "Changed" entry above for the related
  non-text-block behavior.

## v0.1.3 (2026-05-23)

### Fix

- **ci**: pin uv installer SHA and third-party action SHAs

## v0.1.2 (2026-05-23)

### Fix

- **chat-models**: override with_structured_output with JSON-schema prompting

## v0.1.1 (2026-05-23)

### Fix

- **ci**: switch to codeberg-* runner labels

## v0.1.0 (2026-05-23)

### Feat

- **chat-models**: custom tools via in-process MCP (Phase 6)
- **chat-models**: bind_tools for built-in tool passthrough (Phase 5)
- **chat-models**: implement _astream for streaming chat (Phase 4)
- **chat-models**: implement _generate / _agenerate (Phase 3)

### Fix

- **chat-models**: accept stop= silently and clarify usage-metadata math
