# Contributing to langchain-claude-agent-sdk

Thanks for considering a contribution. This project aims to be the
production-grade LangChain provider for the official Claude Agent SDK;
contributions are held to that bar.

By participating in this project you agree to abide by the
[Code of Conduct](./CODE_OF_CONDUCT.md).

---

## Quick reference

| Task | Command |
| --- | --- |
| **One-shot bootstrap** (deps + pre-commit hooks) | **`make bootstrap`** |
| Install dev environment only | `make install` |
| Install pre-commit hooks only | `make install-hooks` |
| Lint (ruff check + ruff format --check) | `make lint` |
| Auto-format + auto-fix | `make format` |
| Type-check (strict) | `make typecheck` |
| Run unit tests | `make test` |
| Run integration tests (real CLI) | `make test-integration` |
| Coverage report (enforces 95% floor) | `make coverage` |
| Full pre-PR check | `make check` |
| Run pre-commit on all files | `make precommit` |
| Build sdist + wheel | `make build` |
| `twine check` distributions | `make distcheck` |

`make check` runs `lint + typecheck + test` and is the minimum local bar
before opening a pull request. CI also runs `make coverage` and `make distcheck`.

---

## Development environment

This project uses [`uv`](https://docs.astral.sh/uv/) for dependency
management. If you don't have it:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Then:

```bash
git clone https://codeberg.org/brhodes/langchain-claude-agent-sdk
cd langchain-claude-agent-sdk
make bootstrap       # one-shot: install dev deps + pre-commit hooks
make check           # confirm a clean baseline
```

(`make bootstrap` is `make install && make install-hooks`. Use the
individual targets if you want one without the other — for example,
CI invokes `make install` directly to skip pre-commit hook setup.)

Supported Python versions: **3.10, 3.11, 3.12, 3.13**. CI runs all four.

---

## Branch and commit conventions

### Branch model

- `main` is always green. Never push directly; open a pull request.
- Topic branches: `<type>/<short-slug>` — e.g. `feat/streaming`,
  `fix/usage-metadata-cache-bucket`, `docs/release-process`.
- Rebase onto `main` before merge; merge with fast-forward when possible.

### Conventional Commits

All commits must follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/).
The `commitizen` commit-msg hook enforces this if you installed the hooks.

Allowed types: `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`,
`chore`, `ci`, `build`, `revert`.

Common scopes for this project: `chat-models`, `messages`, `streaming`,
`tools`, `mcp`, `packaging`, `deps`, `ci`, `docs`.

Examples:

```
feat(chat-models): implement _generate / _agenerate (Phase 3)
fix(messages): include cache_creation tokens in input_tokens total
docs: clarify Agent SDK billing caveat in README
chore(deps): bump claude-agent-sdk lower bound to 0.3.0
```

Breaking changes: append `!` after the type/scope or include a
`BREAKING CHANGE:` footer. Pre-1.0.0, breaking changes are permitted in
minor versions but must still be marked.

### Pre-commit hooks

Installing the hooks (`make install-hooks`) runs ruff, mypy, basic file
hygiene, and the commitizen commit-msg check before every commit. **Do not
bypass hooks with `--no-verify`.** If a hook fails, fix the underlying issue
and commit again — never silence the hook to land a commit.

---

## Pull request checklist

Before opening a PR:

- [ ] Branch is rebased onto current `main`.
- [ ] `make check` is green locally.
- [ ] `make coverage` meets the 95% floor (CI will block otherwise).
- [ ] New or changed behaviour has tests (unit and, when reasonable,
      integration).
- [ ] Public-facing changes update `README.md`, docstrings, and/or
      `DESIGN.md`/`PHASES.md` as appropriate.
- [ ] A `CHANGELOG.md` entry under `[Unreleased]` describes the user-visible
      change. Skip only for invisible refactors and pure CI/dev changes.
- [ ] Commit messages follow Conventional Commits.
- [ ] No `--no-verify` was used.
- [ ] Type annotations are present; mypy is happy under `--strict`.
- [ ] No secrets, credentials, or personal data committed.

The PR template (`.gitea/PULL_REQUEST_TEMPLATE.md`) restates this list.

---

## Testing

### Unit tests (`tests/unit_tests/`)

- Run on every commit. **Must not hit the network or the real `claude` CLI.**
- The SDK is monkeypatched via `pytest`'s `monkeypatch` fixture or a small
  `_FakeQuery` collaborator (see `tests/unit_tests/test_generate.py`).
- Write tests at the smallest scope that catches the regression. Prefer one
  assertion per behaviour; group related behaviours by descriptive function
  name (`test_<unit>_<behaviour>`).

### Integration tests (`tests/integration_tests/`)

- Marked `@pytest.mark.integration`. Skipped from the default `make test`
  run; invoked via `make test-integration`.
- Hit the real `claude` CLI and so require local authentication
  (`~/.claude/.credentials.json`). They are gated in CI to avoid burning the
  maintainer's subscription on every PR — opt in by maintainer.

### Coverage

`pytest-cov` with branch coverage. The CI gate is **95% combined line +
branch coverage**. The floor lives in `pyproject.toml` under
`[tool.coverage.report]`. Raising the floor is welcome in any PR that
genuinely improves coverage; lowering it requires explicit reviewer sign-off.

---

## Releasing

Releases are cut from `main`. The
[`release.yml` workflow](./.forgejo/workflows/release.yml) handles the actual
build + PyPI upload — it triggers on `v<version>` tag pushes and verifies
that the tag matches the version recorded in `pyproject.toml` *and*
`_version.py` before uploading.

### One-time setup

PyPI does not yet support Codeberg / Forgejo as a trusted publisher, so the
release workflow authenticates with a long-lived API token.

1. Create a PyPI account and the `langchain-claude-agent-sdk` project (or
   set it as a "pending publisher" if it's the very first upload).
2. Generate a **project-scoped** API token from PyPI's account settings.
   Scoping to one project keeps blast radius small.
3. In Codeberg → repo Settings → Secrets and Variables → Actions, add a
   secret named `PYPI_API_TOKEN` with the value from step 2 (include the
   `pypi-` prefix).

Verify by triggering the workflow on a test tag (e.g. `v0.0.1.dev0`) and
checking that the build job succeeds and the upload step is reached.
When PyPI ships Forgejo trusted publishing, replace the token with the
official action and drop the secret.

### Cutting a release

```bash
# 1. Confirm main is green and CHANGELOG [Unreleased] is accurate.
git switch main && git pull --ff-only
make check && make coverage && make distcheck

# 2. Promote [Unreleased] to [X.Y.Z] - YYYY-MM-DD in CHANGELOG.md and
#    bump pyproject.toml + _version.py to the same version. commitizen
#    can do this for you:
uv run cz bump --changelog
# Or do it manually if you need to override the increment (e.g. jumping
# 0.0.1 -> 0.1.0 with no breaking-change-marked commits between).

# 3. Push the bump commit and the tag. The release workflow runs on the
#    tag push; main's CI also runs on the bump commit.
git push --follow-tags origin main
```

A release is not "done" until:

- The version bump commit and `v<version>` tag are pushed.
- The release workflow finishes successfully on Codeberg.
- The PyPI release page renders correctly (README, links, classifiers).
- The Codeberg release page has the matching `v<version>` tag and a
  CHANGELOG excerpt.

If the release workflow ever fails mid-upload, do **not** retag — bump the
patch version, fix the underlying issue, and tag the new version. PyPI
filenames are immutable; retagging the same version is a footgun.

### Manual fallback

If the workflow is down or you need to publish from your laptop:

```bash
make build
uv run twine check --strict dist/*
uv run twine upload dist/*
```

Use the same project-scoped API token. Document the manual upload in the
CHANGELOG entry if it happens.

---

## Questions

Open an issue at
[codeberg.org/brhodes/langchain-claude-agent-sdk/issues](https://codeberg.org/brhodes/langchain-claude-agent-sdk/issues)
or, for sensitive matters, see [SECURITY.md](./SECURITY.md).
