#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""Command-line interface for the Veculo SDK.

Usage::

    veculo connect --endpoint https://api.veculo.com --api-key vk-... --cluster-id cl-a7f3b2
    veculo status
    veculo put-vertex --id alice --label person --property name=Alice
    veculo get-vertex --id alice
    veculo put-edge --source alice --target bob --type knows
    veculo query --embedding "0.1,0.2,0.3" --top-k 10
    veculo expand --embedding "0.1,0.2,0.3" --top-k 10 --alpha 0.7
    veculo temporal --id dri-1 --start-time 1700000000000 --edge-type accessed
    veculo aggregate --aggregation GROUP_BY_EDGE_TYPE --id dri-1
    veculo find-path --source dri-1 --target system-x
    veculo find-intersection --anchors system-x system-y --edge-type accessed --direction incoming
    veculo find-triangles --id vertex-1
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

_CONFIG_DIR = Path.home() / ".veculo"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


# ------------------------------------------------------------------
# Config helpers
# ------------------------------------------------------------------


def _load_config() -> dict[str, str]:
    """Load saved configuration from ``~/.veculo/config.json``."""
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_config(config: dict[str, str]) -> None:
    """Persist configuration to ``~/.veculo/config.json``."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")


def _resolve(key: str, args: argparse.Namespace, config: dict[str, str]) -> str | None:
    """Resolve a value from CLI args, then config file, then env vars."""
    cli_val = getattr(args, key, None)
    if cli_val:
        return cli_val
    if key in config:
        return config[key]
    env_map = {
        "endpoint": "VECULO_ENDPOINT",
        "api_key": "VECULO_API_KEY",
        "cluster_id": "VECULO_CLUSTER_ID",
        "cluster_name": "VECULO_CLUSTER_NAME",
    }
    return os.environ.get(env_map.get(key, ""))


def _get_client(args: argparse.Namespace) -> Any:
    """Build a VeculoClient from resolved configuration."""
    from veculo.client import VeculoClient

    config = _load_config()
    endpoint = _resolve("endpoint", args, config)
    api_key = _resolve("api_key", args, config)
    cluster_id = _resolve("cluster_id", args, config)
    cluster_name = _resolve("cluster_name", args, config)
    return VeculoClient(
        endpoint=endpoint,
        api_key=api_key,
        cluster_id=cluster_id,
        cluster_name=cluster_name,
    )


def _print_json(data: Any) -> None:
    """Pretty-print a JSON-serializable object to stdout."""
    print(json.dumps(data, indent=2))


# ------------------------------------------------------------------
# Subcommand handlers
# ------------------------------------------------------------------


def _cmd_connect(args: argparse.Namespace) -> None:
    """Save connection details to ``~/.veculo/config.json``."""
    config: dict[str, str] = {}
    if args.endpoint:
        config["endpoint"] = args.endpoint
    if args.api_key:
        config["api_key"] = args.api_key
    if args.cluster_id:
        config["cluster_id"] = args.cluster_id
    if args.cluster_name:
        config["cluster_name"] = args.cluster_name
    _save_config(config)
    print(f"Configuration saved to {_CONFIG_FILE}")


def _cmd_status(args: argparse.Namespace) -> None:
    """Print cluster metrics / health."""
    client = _get_client(args)
    _print_json(client.get_metrics())


def _cmd_put_vertex(args: argparse.Namespace) -> None:
    """Insert or update a vertex."""
    client = _get_client(args)
    properties = _parse_properties(args.property) if args.property else None
    embedding = _parse_embedding(args.embedding) if args.embedding else None
    result = client.put_vertex(
        id=args.id,
        label=args.label or "default",
        properties=properties,
        embedding=embedding,
        visibility=args.visibility,
    )
    _print_json(result)


def _cmd_get_vertex(args: argparse.Namespace) -> None:
    """Retrieve a vertex by ID."""
    client = _get_client(args)
    result = client.get_vertex(id=args.id, authorizations=args.authorizations)
    _print_json(result)


def _cmd_put_edge(args: argparse.Namespace) -> None:
    """Create an edge between two vertices."""
    client = _get_client(args)
    properties = _parse_properties(args.property) if args.property else None
    result = client.put_edge(
        source=args.source,
        target=args.target,
        edge_type=args.type,
        properties=properties,
        visibility=args.visibility,
    )
    _print_json(result)


def _cmd_query(args: argparse.Namespace) -> None:
    """Execute a hybrid query."""
    client = _get_client(args)
    embedding = _parse_embedding(args.embedding) if args.embedding else None
    result = client.query(
        embedding=embedding,
        top_k=args.top_k,
        edge_type=args.edge_type,
        depth=args.depth,
        authorizations=args.authorizations,
    )
    _print_json(result)


def _cmd_upload(args: argparse.Namespace) -> None:
    """Upload a file and create a vertex."""
    client = _get_client(args)
    properties = _parse_properties(args.property) if args.property else None
    result = client.put_vertex_with_file(
        id=args.id,
        file_path=args.file,
        label=args.label or "document",
        properties=properties,
        visibility=args.visibility,
    )
    _print_json(result)


def _cmd_temporal(args: argparse.Namespace) -> None:
    """Query edges within a time range."""
    client = _get_client(args)
    result = client.query_temporal(
        vertex_id=args.id,
        start_time=args.start_time,
        end_time=args.end_time,
        edge_type=args.edge_type,
        time_field=args.time_field,
    )
    _print_json(result)


def _cmd_aggregate(args: argparse.Namespace) -> None:
    """Run a server-side aggregation query."""
    client = _get_client(args)
    result = client.aggregate(
        aggregation=args.aggregation,
        vertex_id=args.id,
        edge_type=args.edge_type,
        time_bucket=args.time_bucket,
        start_time=args.start_time,
        end_time=args.end_time,
        limit=args.limit,
    )
    _print_json(result)


def _cmd_expand(args: argparse.Namespace) -> None:
    """Execute a topological vector expansion query."""
    client = _get_client(args)
    embedding = _parse_embedding(args.embedding)
    result = client.query_expand(
        embedding=embedding,
        top_k=args.top_k,
        threshold=args.threshold,
        alpha=args.alpha,
        depth=args.depth,
    )
    results = result.get("results", [])
    if not results:
        print("No results found.")
        return
    print(f"{'VERTEX ID':<30} {'SCORE':<10} {'SOURCE':<12} {'CONNECTED SEEDS'}")
    print("-" * 80)
    for r in results:
        seeds = r.get("connected_seeds", [])
        seeds_str = ", ".join(seeds) if seeds else "-"
        print(f"{r.get('vertex_id', ''):<30} {r.get('score', 0):<10.4f} {r.get('source', ''):<12} {seeds_str}")


def _cmd_reason(args: argparse.Namespace) -> None:
    """Execute SSM reasoning traversal."""
    client = _get_client(args)
    embedding = _parse_embedding(args.embedding) if args.embedding else None
    query = args.query if hasattr(args, "query") and args.query else None
    if not embedding and not query:
        print("Error: provide --query or --embedding", file=sys.stderr)
        sys.exit(1)
    strategy = args.strategy if hasattr(args, "strategy") and args.strategy else None
    result = client.reason(
        query=query,
        embedding=embedding,
        start_vertex=args.start_vertex,
        strategy=strategy,
        max_depth=args.max_depth if args.max_depth != 5 else None,
        alpha=args.alpha if args.alpha != 0.8 else None,
        threshold=args.threshold if args.threshold != 0.3 else None,
    )
    path = result.get("path", [])
    if not path:
        print("No reasoning path found.")
        if result.get("termination_reason"):
            print(f"Reason: {result['termination_reason']}")
        return
    print(f"Reasoning path ({len(path)} hops):")
    print(f"{'HOP':<5} {'VERTEX ID':<30} {'SCORE':<10}")
    print("-" * 50)
    for i, hop in enumerate(path):
        print(f"{i+1:<5} {hop.get('vertex_id', ''):<30} {hop.get('score', 0):<10.4f}")
    if result.get("termination_reason"):
        print(f"\nTerminated: {result['termination_reason']}")


def _cmd_find_path(args: argparse.Namespace) -> None:
    """Find paths between two vertices."""
    client = _get_client(args)
    result = client.find_path(
        source=args.source,
        target=args.target,
        edge_type=args.edge_type,
        max_depth=args.max_depth,
        find_all=args.find_all,
        max_paths=args.max_paths,
    )
    paths = result.get("paths", [])
    if not paths:
        print("No path found.")
        return
    for i, path in enumerate(paths):
        print(f"Path {i + 1}: {' → '.join(path)}")


def _cmd_find_intersection(args: argparse.Namespace) -> None:
    """Find vertices connected to all anchor vertices."""
    client = _get_client(args)
    result = client.find_intersection(
        anchor_vertices=args.anchors,
        edge_types=[args.edge_type] if args.edge_type else [],
        direction=args.direction,
    )
    vertices = result.get("vertices", [])
    if not vertices:
        print("No intersection found.")
        return
    print(f"Found {len(vertices)} vertices connected to all anchors:")
    for v in vertices:
        print(f"  {v}")


def _cmd_find_triangles(args: argparse.Namespace) -> None:
    """Find triangles involving a vertex."""
    client = _get_client(args)
    result = client.find_triangles(
        vertex_id=args.id,
        edge_type=args.edge_type,
        max_triangles=args.max_triangles,
    )
    triangles = result.get("triangles", [])
    if not triangles:
        print("No triangles found.")
        return
    print(f"Found {len(triangles)} triangles:")
    for t in triangles:
        print(f"  {' — '.join(t)}")


def _cmd_jobs(args: argparse.Namespace) -> None:
    """List file extraction jobs."""
    client = _get_client(args)
    result = client.list_jobs()
    jobs = result.get("jobs", [])
    if not jobs:
        print("No file uploads found.")
        return
    # Pretty print as table
    print(f"{'VERTEX ID':<30} {'FILENAME':<25} {'TYPE':<15} {'STATUS':<12} {'DETAILS'}")
    print("-" * 100)
    for job in jobs:
        details = []
        if job.get("has_text"):
            details.append("text")
        if job.get("has_embedding"):
            details.append("embedding")
        if job.get("page_count"):
            details.append(f"{job['page_count']} pages")
        print(f"{job.get('vertex_id', ''):<30} {job.get('filename', ''):<25} {job.get('content_type', ''):<15} {job.get('status', ''):<12} {', '.join(details)}")


# ------------------------------------------------------------------
# Argument parsing helpers
# ------------------------------------------------------------------


def _parse_properties(pairs: list[str]) -> dict[str, str]:
    """Parse ``key=value`` pairs into a dictionary."""
    props: dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            print(f"Warning: ignoring malformed property '{pair}' (expected key=value)", file=sys.stderr)
            continue
        key, _, value = pair.partition("=")
        props[key] = value
    return props


def _parse_embedding(raw: str) -> list[float]:
    """Parse a comma-separated string of floats into a list."""
    return [float(x.strip()) for x in raw.split(",")]


# ------------------------------------------------------------------
# Main entry point
# ------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    """Construct the argument parser tree."""
    parser = argparse.ArgumentParser(
        prog="veculo",
        description="Veculo CLI -- managed graph+vector database",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # -- connect -------------------------------------------------------
    p_connect = subparsers.add_parser("connect", help="Save connection configuration")
    p_connect.add_argument("--endpoint", help="API endpoint URL")
    p_connect.add_argument("--api-key", dest="api_key", help="Veculo API key")
    p_connect.add_argument("--cluster-id", dest="cluster_id", help="Cluster ID (e.g., cl-a7f3b2)")
    p_connect.add_argument("--cluster", dest="cluster_name", help="Cluster name (e.g., 'production')")

    # -- status --------------------------------------------------------
    subparsers.add_parser("status", help="Show cluster status and metrics")

    # -- put-vertex ----------------------------------------------------
    p_pv = subparsers.add_parser("put-vertex", help="Insert or update a vertex")
    p_pv.add_argument("--id", required=True, help="Vertex ID")
    p_pv.add_argument("--label", default="default", help="Vertex label")
    p_pv.add_argument(
        "--property", action="append", metavar="KEY=VALUE", help="Vertex property (repeatable)"
    )
    p_pv.add_argument("--embedding", help="Comma-separated vector embedding")
    p_pv.add_argument("--visibility", help="Visibility expression")

    # -- get-vertex ----------------------------------------------------
    p_gv = subparsers.add_parser("get-vertex", help="Retrieve a vertex by ID")
    p_gv.add_argument("--id", required=True, help="Vertex ID")
    p_gv.add_argument("--authorizations", help="Visibility authorizations")

    # -- put-edge ------------------------------------------------------
    p_pe = subparsers.add_parser("put-edge", help="Create an edge between two vertices")
    p_pe.add_argument("--source", required=True, help="Source vertex ID")
    p_pe.add_argument("--target", required=True, help="Target vertex ID")
    p_pe.add_argument("--type", required=True, help="Edge type")
    p_pe.add_argument(
        "--property", action="append", metavar="KEY=VALUE", help="Edge property (repeatable)"
    )
    p_pe.add_argument("--visibility", help="Visibility expression")

    # -- upload --------------------------------------------------------
    p_upload = subparsers.add_parser("upload", help="Upload a file and create a vertex")
    p_upload.add_argument("--id", required=True, help="Vertex ID")
    p_upload.add_argument("--file", required=True, help="Path to file")
    p_upload.add_argument("--label", default="document", help="Vertex label")
    p_upload.add_argument(
        "--property", action="append", metavar="KEY=VALUE", help="Vertex property (repeatable)"
    )
    p_upload.add_argument("--visibility", help="Visibility expression")

    # -- jobs ----------------------------------------------------------
    p_jobs = subparsers.add_parser("jobs", help="List file extraction jobs")

    # -- query ---------------------------------------------------------
    p_q = subparsers.add_parser("query", help="Execute a hybrid vector+graph query")
    p_q.add_argument("--embedding", help="Comma-separated query vector")
    p_q.add_argument("--top-k", dest="top_k", type=int, default=10, help="Number of results")
    p_q.add_argument("--edge-type", dest="edge_type", help="Edge type filter for graph expansion")
    p_q.add_argument("--depth", type=int, default=1, help="Graph traversal depth")
    p_q.add_argument("--authorizations", help="Visibility authorizations")

    # -- temporal ------------------------------------------------------
    p_temp = subparsers.add_parser("temporal", help="Query edges within a time range")
    p_temp.add_argument("--id", required=True, help="Vertex ID")
    p_temp.add_argument("--start-time", dest="start_time", type=int, help="Start time (epoch millis)")
    p_temp.add_argument("--end-time", dest="end_time", type=int, help="End time (epoch millis)")
    p_temp.add_argument("--edge-type", dest="edge_type", help="Edge type filter")
    p_temp.add_argument("--time-field", dest="time_field", default="write_time",
                        choices=["write_time", "event_time"], help="Time field to filter on")

    # -- aggregate -----------------------------------------------------
    p_agg = subparsers.add_parser("aggregate", help="Run server-side aggregation")
    p_agg.add_argument("--aggregation", required=True,
                       choices=["COUNT", "COUNT_DISTINCT", "GROUP_BY_EDGE_TYPE",
                                "GROUP_BY_TIME", "DEGREE", "TOP_CONNECTED"],
                       help="Aggregation type")
    p_agg.add_argument("--id", help="Vertex ID (optional)")
    p_agg.add_argument("--edge-type", dest="edge_type", help="Edge type filter")
    p_agg.add_argument("--time-bucket", dest="time_bucket",
                       choices=["HOUR", "DAY", "WEEK", "MONTH"], help="Time bucket for GROUP_BY_TIME")
    p_agg.add_argument("--start-time", dest="start_time", type=int, help="Start time (epoch millis)")
    p_agg.add_argument("--end-time", dest="end_time", type=int, help="End time (epoch millis)")
    p_agg.add_argument("--limit", type=int, default=100, help="Max results")

    # -- expand --------------------------------------------------------
    p_expand = subparsers.add_parser("expand", help="Topological vector expansion query")
    p_expand.add_argument("--embedding", required=True, help="Comma-separated query vector")
    p_expand.add_argument("--top-k", dest="top_k", type=int, default=10, help="Number of results")
    p_expand.add_argument("--threshold", type=float, default=0.5, help="Min similarity for seeds")
    p_expand.add_argument("--alpha", type=float, default=0.7,
                          help="Weight: 0=pure connectivity, 1=pure similarity")
    p_expand.add_argument("--depth", type=int, default=1, help="Graph traversal depth")

    # -- reason --------------------------------------------------------
    p_reason = subparsers.add_parser("reason", help="SSM reasoning: semantic multi-hop traversal")
    p_reason.add_argument("--query", help="Text query (embedded server-side)")
    p_reason.add_argument("--embedding", help="Comma-separated query vector (alternative to --query)")
    p_reason.add_argument("--start-vertex", dest="start_vertex", help="Start vertex ID")
    p_reason.add_argument("--strategy",
                          choices=["root_cause", "access_trace", "compliance", "influence",
                                   "fraud", "knowledge", "supply_chain", "explore"],
                          help="Pre-built reasoning strategy")
    p_reason.add_argument("--max-depth", dest="max_depth", type=int, default=5, help="Max hops")
    p_reason.add_argument("--alpha", type=float, default=0.8, help="State momentum (0-1)")
    p_reason.add_argument("--threshold", type=float, default=0.3, help="Min score to continue")

    # -- find-path -----------------------------------------------------
    p_path = subparsers.add_parser("find-path", help="Find paths between two vertices")
    p_path.add_argument("--source", required=True, help="Source vertex ID")
    p_path.add_argument("--target", required=True, help="Target vertex ID")
    p_path.add_argument("--edge-type", dest="edge_type", help="Edge type to follow")
    p_path.add_argument("--max-depth", dest="max_depth", type=int, default=5, help="Max path length")
    p_path.add_argument("--find-all", dest="find_all", action="store_true", help="Find all paths")
    p_path.add_argument("--max-paths", dest="max_paths", type=int, default=10, help="Max paths to return")

    # -- find-intersection ---------------------------------------------
    p_inter = subparsers.add_parser("find-intersection",
                                    help="Find vertices connected to all anchor vertices")
    p_inter.add_argument("--anchors", nargs="+", required=True, help="Anchor vertex IDs")
    p_inter.add_argument("--edge-type", dest="edge_type", help="Edge type filter")
    p_inter.add_argument("--direction", default="both",
                         choices=["outgoing", "incoming", "both"], help="Edge direction")

    # -- find-triangles ------------------------------------------------
    p_tri = subparsers.add_parser("find-triangles", help="Find triangles involving a vertex")
    p_tri.add_argument("--id", required=True, help="Center vertex ID")
    p_tri.add_argument("--edge-type", dest="edge_type", help="Edge type filter")
    p_tri.add_argument("--max-triangles", dest="max_triangles", type=int, default=100,
                       help="Max triangles to return")

    return parser


def main(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    handlers = {
        "connect": _cmd_connect,
        "status": _cmd_status,
        "put-vertex": _cmd_put_vertex,
        "get-vertex": _cmd_get_vertex,
        "put-edge": _cmd_put_edge,
        "query": _cmd_query,
        "expand": _cmd_expand,
        "reason": _cmd_reason,
        "upload": _cmd_upload,
        "jobs": _cmd_jobs,
        "temporal": _cmd_temporal,
        "aggregate": _cmd_aggregate,
        "find-path": _cmd_find_path,
        "find-intersection": _cmd_find_intersection,
        "find-triangles": _cmd_find_triangles,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    try:
        handler(args)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
