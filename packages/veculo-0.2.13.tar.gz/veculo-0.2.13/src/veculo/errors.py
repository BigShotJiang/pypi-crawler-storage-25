#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""Exception classes for the Veculo SDK."""

from __future__ import annotations


class VeculoError(Exception):
    """Base exception for all Veculo SDK errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API, if applicable.
        body: Raw response body, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        body: dict | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.body = body
        super().__init__(message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(VeculoError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401/403)."""


class NotFoundError(VeculoError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class ValidationError(VeculoError):
    """Raised when the request fails server-side validation (HTTP 400/422)."""
