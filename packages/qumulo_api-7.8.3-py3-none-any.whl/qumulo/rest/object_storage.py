# Copyright (c) 2024 Qumulo, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.

from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional, Sequence

import qumulo.lib.request as request

from qumulo.lib.auth import Credentials


@dataclass
class ObjectStoreNameAndCredentials:
    store_name: str
    access_key_id: str
    secret_access_key: str


@request.request
def get_uris(
    conninfo: request.Connection, _credentials: Optional[Credentials]
) -> request.RestResponse:
    return conninfo.send_request('GET', '/v1/object-storage/uris')


@request.request
def add_uris(
    conninfo: request.Connection,
    _credentials: Optional[Credentials],
    new_uris: Sequence[str],
    new_object_storage_credentials: Optional[Sequence[ObjectStoreNameAndCredentials]] = None,
) -> request.RestResponse:
    maybe_credentials = (
        [asdict(credential) for credential in new_object_storage_credentials]
        if new_object_storage_credentials is not None
        else None
    )

    uris_and_credentials: Dict[str, Any] = {
        'uris': new_uris,
        'maybe_credentials': maybe_credentials,
    }

    return conninfo.send_request('POST', '/v2/object-storage/add-uris', body=uris_and_credentials)


@request.request
def get_external_credentials_source(
    conninfo: request.Connection, _credentials: Optional[Credentials]
) -> request.RestResponse:
    return conninfo.send_request('GET', '/v1/object-storage/external-credentials-source')
