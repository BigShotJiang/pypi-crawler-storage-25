# Copyright (c) 2026 Qumulo, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.


import argparse

from argparse import SUPPRESS

import qumulo.lib.opts
import qumulo.rest.rdma as rdma

from qumulo.rest_client import RestClient


class RdmaGetSettingsCommand(qumulo.lib.opts.Subcommand):
    NAME = 'rdma_get_settings'
    SYNOPSIS = SUPPRESS

    @staticmethod
    def main(rest_client: RestClient, _args: argparse.Namespace) -> None:
        print(rdma.get_settings(rest_client.conninfo, rest_client.credentials))


class RdmaGetStatusCommand(qumulo.lib.opts.Subcommand):
    NAME = 'rdma_get_status'
    SYNOPSIS = SUPPRESS

    @staticmethod
    def main(rest_client: RestClient, _args: argparse.Namespace) -> None:
        print(rdma.get_status(rest_client.conninfo, rest_client.credentials))


class RdmaSetSettingsCommand(qumulo.lib.opts.Subcommand):
    NAME = 'rdma_set_settings'
    SYNOPSIS = SUPPRESS

    @staticmethod
    def options(parser: argparse.ArgumentParser) -> None:
        group = parser.add_mutually_exclusive_group(required=True)
        group.add_argument('--enable', action='store_true', default=None, dest='rdma_enabled')
        group.add_argument('--disable', action='store_false', dest='rdma_enabled')

    @staticmethod
    def main(rest_client: RestClient, args: argparse.Namespace) -> None:
        print(
            rdma.set_settings(
                rest_client.conninfo, rest_client.credentials, rdma_enabled=args.rdma_enabled
            )
        )
