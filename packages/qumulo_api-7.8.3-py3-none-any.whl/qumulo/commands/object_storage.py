# Copyright (c) 2024 Qumulo, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.

import argparse
import textwrap

from typing import Any, List, Optional, Sequence, Union

import qumulo.commands.cluster
import qumulo.lib.opts

from qumulo.rest.object_storage import ObjectStoreNameAndCredentials
from qumulo.rest_client import RestClient


class ObjectStorageGetURIsCommand(qumulo.lib.opts.Subcommand):
    NAME = 'get_object_storage_uris'
    SYNOPSIS = (
        'Get the list of object storage uris configured on the cluster. These object storage uris '
        'store the persisted pstore data for an object-backed cluster. For a cluster that is not '
        'backed by objects, the returned list is always empty.'
    )

    @staticmethod
    def main(rest_client: RestClient, _args: argparse.Namespace) -> None:
        print(rest_client.object_storage.get_uris())


class ParseObjectStoreNameAndCredentials(argparse.Action):
    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: Union[str, Sequence[Any], None],
        option_string: Optional[str] = None,
    ) -> None:
        assert values is not None

        credentials: List[ObjectStoreNameAndCredentials] = []
        for entry in values:
            store_name, access_key_id, secret_access_key = entry.split(',')
            credentials.append(
                ObjectStoreNameAndCredentials(store_name, access_key_id, secret_access_key)
            )

        setattr(namespace, self.dest, credentials)


class ParseObjectStoreNameAndCredentialsFile(argparse.Action):
    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: Union[str, Sequence[Any], None],
        option_string: Optional[str] = None,
    ) -> None:
        assert values is not None

        credentials: List[ObjectStoreNameAndCredentials] = []
        filename = values if isinstance(values, str) else values[0]
        with open(filename, 'r', encoding='utf-8') as infile:
            for line in infile:
                entry = line.strip()
                if not entry:
                    continue
                store_name, access_key_id, secret_access_key = entry.split(',')
                credentials.append(
                    ObjectStoreNameAndCredentials(store_name, access_key_id, secret_access_key)
                )

        # Save the value specifically to the credentials arg so if credentials are provided either
        # by file or by cli they always end up in the same argument.
        setattr(namespace, 'credentials', credentials)


class ObjectStorageAddURIsCommand(qumulo.lib.opts.Subcommand):
    NAME = 'add_object_storage_uris'
    SYNOPSIS = (
        "Add object storage URIs and associated credentials for configuring the cluster's data "
        'persistence. As the system provisions additional storage capacity on the cluster (which '
        'increases together with the clamp increase functionality), the file system recognizes and '
        'uses any new object storage URIs. Ensure that the new URIs point to empty S3 buckets or '
        'storage accounts and that the nodes on the cluster have sufficient permissions to perform '
        'LIST, PUT, GET, and DELETE operations on these buckets or accounts. Performing this '
        'action on a cluster not backed by objects results in an error.'
    )

    @staticmethod
    def options(parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            '--uris', nargs='+', default=[], help='The new URIs to add to the cluster.'
        )

        group = parser.add_mutually_exclusive_group(required=False)
        group.add_argument(
            '--credentials-file',
            default=None,
            action=ParseObjectStoreNameAndCredentialsFile,
            help=textwrap.dedent(
                """\
                The new credentials to add to the cluster. Parsed as comma delimited tuples where
                each tuple is on its own line in the file:
                <store_name-1>,<access_key_id-1>,<secret_access_key-1>
                <store_name-2>,<access_key_id-2>,<secret_access_key-2>...
            """
            ),
        )
        group.add_argument(
            '--credentials',
            nargs='+',
            default=None,
            action=ParseObjectStoreNameAndCredentials,
            help=textwrap.dedent(
                """\
                The new credentials to add to the file via stdin. Parsed as comma delimited tuples
                where each tuple is separated by a space:
                <store_name-1>,<access_key_id-1>,<secret_access_key-1>
                <store_name-2>,<access_key_id-2>,<secret_access_key-2>...
            """
            ),
        )

    @staticmethod
    def main(rest_client: RestClient, args: argparse.Namespace) -> None:
        rest_client.object_storage.add_uris(args.uris, args.credentials)
