"""Tips displayed while a turn is running."""
from __future__ import annotations

LOADING_TIPS: tuple[str, ...] = (
    "Use /context when a task starts to feel fuzzy.",
    "Attach @files to make the model read the right surface first.",
    "Use Shift+Tab to switch between act and plan mode.",
    "Use /compact before a long follow-up in the same session.",
    "Press Ctrl+C once to interrupt the current operation.",
    "Use /rewind when the last turn took the wrong branch.",
    "Ask for source-level diagnosis before changing brittle code.",
    "Name the failing boundary before patching behavior.",
    "Prefer one visible behavior change per small patch.",
    "Keep queue messages invisible until they are consumed.",
    "Check scrollback output separately from live TUI state.",
    "For TUI bugs, separate layout state from history output.",
    "Use @path hints when the answer depends on local files.",
    "Review tests around the boundary you are about to touch.",
    "Use /model when the task needs a different reasoning tier.",
    "Small focused prompts usually beat broad fuzzy requests.",
)
