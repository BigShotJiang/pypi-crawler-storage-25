"""TUI logging adapter - 将 warning/error 日志送入 renderer pending 队列。"""
from __future__ import annotations

import logging
import os
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from comate_cli.terminal_agent.event_renderer import EventRenderer


logger = logging.getLogger(__name__)

_COMATE_LOGGING_SESSION_MARKER = "_comate_tui_logging_session"
_RECENT_DUPLICATE_LOG_WINDOW_SECONDS = 0.5
_recent_log_message_times: dict[str, float] = {}
_recent_log_message_lock = threading.Lock()
_active_tui_logging_session: "TUILoggingSession | None" = None
_active_tui_logging_session_lock = threading.Lock()

_LOG_LEVEL_ENV_VAR = "COMATE_LOG_LEVEL"
_VALID_LOG_LEVELS: tuple[str, ...] = ("DEBUG", "INFO", "WARNING", "ERROR")
_DEFAULT_LOG_LEVEL = logging.INFO
_invalid_log_level_warned = False


def _should_drop_recent_duplicate_log(msg_key: str) -> bool:
    now = time.monotonic()
    with _recent_log_message_lock:
        expired_keys = [
            key
            for key, ts in _recent_log_message_times.items()
            if now - ts > _RECENT_DUPLICATE_LOG_WINDOW_SECONDS
        ]
        for key in expired_keys:
            _recent_log_message_times.pop(key, None)

        previous = _recent_log_message_times.get(msg_key)
        _recent_log_message_times[msg_key] = now
        return previous is not None


class TUILoggingHandler(logging.Handler):
    """自定义 logging handler，将日志友好地显示在 TUI 中

    特性：
    - WARNING/ERROR 显示给用户，带颜色标识
    - 首次显示机制：相同消息只显示一次
    - 仅入 EventRenderer pending 队列，由明确 boundary 写入 scrollback
    """

    def __init__(self, renderer: EventRenderer) -> None:
        super().__init__()
        self._renderer = renderer
        self._shown_messages: set[str] = set()  # 跟踪已显示的消息（首次显示）

    def emit(self, record: logging.LogRecord) -> None:
        """处理日志记录"""
        try:
            # 只处理 WARNING 和 ERROR
            if record.levelno < logging.WARNING:
                return

            # 生成友好消息
            msg = self._format_message(record)
            if not msg:
                return

            # 首次显示检查
            msg_key = self._get_message_key(record)
            if _should_drop_recent_duplicate_log(msg_key):
                return
            if msg_key in self._shown_messages:
                return
            self._shown_messages.add(msg_key)

            # 按日志级别映射 severity，渲染层负责视觉区分
            severity: Literal["warning", "error"] = (
                "error" if record.levelno >= logging.ERROR else "warning"
            )
            self._renderer.enqueue_log(
                severity=severity,
                message=msg,
            )

        except Exception:
            self.handleError(record)

    def _format_message(self, record: logging.LogRecord) -> str:
        """格式化日志消息为用户友好格式（不嵌入 emoji，由渲染层负责视觉样式）"""
        msg = record.getMessage()

        # 特殊处理：token count fallback
        if "token count failed" in msg.lower() and "fallback" in msg.lower():
            return "Token estimation using fallback (working normally)"

        return self._simplify_message(msg)

    def _simplify_message(self, msg: str) -> str:
        """简化技术细节"""
        # 去掉常见的技术参数
        if "exc_type=" in msg:
            # 截断到第一个技术参数之前
            parts = msg.split("exc_type=")
            msg = parts[0].rstrip(": ,")

        if "timeout_ms=" in msg:
            parts = msg.split("timeout_ms=")
            msg = parts[0].rstrip(": ,")

        # 限制长度
        max_len = 100
        if len(msg) > max_len:
            msg = msg[:max_len] + "..."

        return msg

    def _get_message_key(self, record: logging.LogRecord) -> str:
        """生成消息的唯一键（用于首次显示检查）"""
        # 使用 logger 名称 + 消息内容的前 50 个字符
        msg = record.getMessage()
        # 对于 token count，使用固定 key
        if "token count failed" in msg.lower():
            return "token_count_fallback"
        # 其他消息用完整内容作为 key
        return f"{record.name}:{msg[:50]}"

class _DropTerminalStreamFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        del record
        return False


class TUILoggingSession:
    def __init__(
        self,
        *,
        root_logger: logging.Logger,
        added_handlers: list[logging.Handler],
        muted_handlers: list[tuple[logging.Handler, logging.Filter]],
        previous_level: int,
    ) -> None:
        self._root_logger = root_logger
        self._added_handlers = list(added_handlers)
        self._muted_handlers = list(muted_handlers)
        self._previous_level = previous_level
        self._closed = False

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        for handler, log_filter in self._muted_handlers:
            try:
                handler.removeFilter(log_filter)
            except Exception:
                continue

        for handler in self._added_handlers:
            try:
                self._root_logger.removeHandler(handler)
            except Exception:
                continue
            try:
                handler.close()
            except Exception:
                continue

        self._root_logger.setLevel(self._previous_level)
        with _active_tui_logging_session_lock:
            global _active_tui_logging_session
            if _active_tui_logging_session is self:
                _active_tui_logging_session = None


def _read_level_from_settings_env(project_root: Path | None) -> str:
    """从 settings.json 的 env 段读取 COMATE_LOG_LEVEL。

    查找顺序：project settings(.agent/settings.json) → user settings(~/.agent/settings.json)。
    复用 SDK 侧的 load_settings_file，不引入独立解析路径。
    返回空串表示未配置或读取失败，由调用方决定如何降级。
    """
    try:
        from comate_agent_sdk.agent.settings import USER_SETTINGS_PATH, load_settings_file
    except Exception:
        return ""

    def _lookup(path: Path) -> str:
        try:
            cfg = load_settings_file(path)
        except Exception:
            return ""
        if cfg is None or cfg.env is None:
            return ""
        raw = cfg.env.get(_LOG_LEVEL_ENV_VAR, "")
        return raw.strip() if isinstance(raw, str) else ""

    if project_root is not None:
        value = _lookup(Path(project_root) / ".agent" / "settings.json")
        if value:
            return value

    return _lookup(USER_SETTINGS_PATH)


def _resolve_log_level(project_root: Path | None = None) -> int:
    """解析生效日志级别。

    优先级：os.environ[COMATE_LOG_LEVEL]
          > project .agent/settings.json env.COMATE_LOG_LEVEL
          > user ~/.agent/settings.json env.COMATE_LOG_LEVEL
          > INFO。
    非法值降级 INFO，并在整个进程生命周期内最多 warn 一次。
    """
    global _invalid_log_level_warned

    raw = os.environ.get(_LOG_LEVEL_ENV_VAR, "").strip()
    if not raw:
        raw = _read_level_from_settings_env(project_root)

    if not raw:
        return _DEFAULT_LOG_LEVEL

    normalized = raw.upper()
    if normalized not in _VALID_LOG_LEVELS:
        if not _invalid_log_level_warned:
            _invalid_log_level_warned = True
            logger.warning(
                f"Invalid {_LOG_LEVEL_ENV_VAR}={raw!r}; falling back to INFO. "
                f"Valid values: {list(_VALID_LOG_LEVELS)}"
            )
        return _DEFAULT_LOG_LEVEL

    return getattr(logging, normalized)


def _build_file_handler(level: int) -> logging.Handler:
    from concurrent_log_handler import ConcurrentRotatingFileHandler

    log_dir = os.path.join(os.path.expanduser("~"), ".comate", "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "agent.log")
    file_handler = ConcurrentRotatingFileHandler(
        log_path,
        maxBytes=10 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    return file_handler


def _should_mute_terminal_stream(handler: logging.Handler) -> bool:
    if not isinstance(handler, logging.StreamHandler):
        return False
    stream = getattr(handler, "stream", None)
    return stream in {sys.stdout, sys.stderr, sys.__stdout__, sys.__stderr__}


def setup_tui_logging(
    renderer: EventRenderer,
    *,
    project_root: Path | None = None,
) -> TUILoggingSession:
    """统一日志初始化：文件 + TUI 双通道。

    - 所有日志（含 traceback）写入 ~/.comate/logs/agent.log
      （ConcurrentRotatingFileHandler：跨进程文件锁 + Windows rename 重试）
    - WARNING/ERROR 以用户友好格式显示在 TUI scrollback
    - 临时静默 root logger 上写往 stdout/stderr 的 stream handler，避免污染 TUI

    日志级别通过 COMATE_LOG_LEVEL 控制（默认 INFO，可设为 DEBUG/INFO/WARNING/ERROR）。
    查找顺序：os.environ > project .agent/settings.json env > user ~/.agent/settings.json env。
    root 与 file handler 同步应用该级别——第三方库（anthropic/httpx/...）的 DEBUG 噪音随之收敛。
    TUI handler 始终固定 WARNING，不受此开关影响，避免 DEBUG 刷屏。
    """
    root = logging.getLogger()
    previous_level = root.level
    level = _resolve_log_level(project_root)

    with _active_tui_logging_session_lock:
        global _active_tui_logging_session
        active_session = _active_tui_logging_session
    if active_session is not None:
        active_session.close()
    with _recent_log_message_lock:
        _recent_log_message_times.clear()

    stale_handlers: list[logging.Handler] = []
    for handler in list(root.handlers):
        if not getattr(handler, _COMATE_LOGGING_SESSION_MARKER, False):
            continue
        try:
            root.removeHandler(handler)
        except Exception:
            pass
        stale_handlers.append(handler)

    for handler in stale_handlers:
        try:
            handler.close()
        except Exception:
            continue

    # 1. 日志文件 handler（完整调试信息，含 traceback）
    file_handler = _build_file_handler(level)
    setattr(file_handler, _COMATE_LOGGING_SESSION_MARKER, True)
    root.addHandler(file_handler)
    # root 级别与 file handler 保持一致——这是单 knob 控第三方 DEBUG 噪音的关键：
    # 第三方 logger level=NOTSET 会继承 root 的 effective level，DEBUG 记录
    # 在 isEnabledFor 阶段就被丢弃，不会走到任何 handler。
    root.setLevel(level)

    # 2. TUI handler 挂到 root（覆盖所有命名空间的 WARNING/ERROR）
    tui_handler = TUILoggingHandler(renderer)
    tui_handler.setLevel(logging.WARNING)
    setattr(tui_handler, _COMATE_LOGGING_SESSION_MARKER, True)
    root.addHandler(tui_handler)

    # 3. 临时静默直写终端的 handler，避免污染主 TUI 输出
    muted_handlers: list[tuple[logging.Handler, logging.Filter]] = []
    for handler in list(root.handlers):
        if handler in {file_handler, tui_handler}:
            continue
        if not _should_mute_terminal_stream(handler):
            continue
        log_filter = _DropTerminalStreamFilter()
        handler.addFilter(log_filter)
        muted_handlers.append((handler, log_filter))

    session = TUILoggingSession(
        root_logger=root,
        added_handlers=[file_handler, tui_handler],
        muted_handlers=muted_handlers,
        previous_level=previous_level,
    )
    with _active_tui_logging_session_lock:
        _active_tui_logging_session = session
    return session
