from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

from prompt_toolkit.application import run_in_terminal
from rich.console import Console

from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.context.items import TOOL_OBSERVABLE_INPUTS_METADATA_KEY
from comate_agent_sdk.llm.messages import AssistantMessage, UserMessage

from comate_cli.terminal_agent.history_printer import (
    print_history_group_sync,
    render_history_group,
)
from comate_cli.terminal_agent.logo import print_logo
from comate_cli.terminal_agent.markdown_render import render_markdown_to_plain
from comate_cli.terminal_agent.models import HistoryEntry
from comate_cli.terminal_agent.tool_view import should_show_tool_in_scrollback

console = Console()
logger = logging.getLogger(__name__)


class HistorySyncMixin:
    # 跨 drain 跟踪上一次 drain 末尾是否是 assistant entry（streaming 管线把一条逻辑
    # message 拆成 N 条 entry，需要 seed 让 history_printer 把 run 续上）。class-level
    # default 让所有 host（含测试 dummy）无需显式初始化也能用。
    _last_drained_was_assistant: bool = False
    _last_drained_thinking_tail_needs_gap: bool = False

    async def _replay_scrollback_after_rewind(self) -> None:
        """清屏并重建 scrollback：Logo + 当前会话历史。"""
        self._renderer.reset_history_view()
        self._printed_history_index = 0
        self._last_drained_was_assistant = False
        self._last_drained_thinking_tail_needs_gap = False

        def _clear_and_print_logo() -> None:
            out = sys.__stdout__ or sys.stdout
            out.write("\x1b[3J\x1b[2J\x1b[H")
            out.flush()
            scrollback_console = Console(
                file=out,
                force_terminal=True,
                width=self._terminal_width(),
            )
            project_root = self._renderer._project_root or Path.cwd()
            print_logo(scrollback_console, project_root=project_root)

        try:
            await run_in_terminal(_clear_and_print_logo, in_executor=True)
        except Exception as exc:
            logger.warning(
                f"failed to clear terminal and replay logo: {exc}",
                exc_info=True,
            )

        self.add_resume_history("resume")

    def add_resume_history(self, mode: str) -> None:
        if mode != "resume":
            return

        items = self._session._agent._context.get_conversation_items_snapshot()
        history: list[Any] = []
        for item in items:
            if item.item_type not in (
                ItemType.USER_MESSAGE,
                ItemType.ASSISTANT_MESSAGE,
                ItemType.TOOL_RESULT,
            ):
                continue
            if item.item_type == ItemType.USER_MESSAGE:
                message = getattr(item, "message", None)
                if isinstance(message, UserMessage) and bool(getattr(message, "is_meta", False)):
                    continue
            history.append(item)
        if not history:
            return

        self._renderer.append_system_message(f"history loaded: {len(history)} messages")

        # 维护 tool_call_id 映射，用于匹配工具调用和结果
        tool_call_info: dict[str, tuple[str, str]] = {}  # tool_call_id → (tool_name, signature)
        tool_call_args: dict[str, dict[str, Any]] = {}

        for item in history:
            if item.item_type == ItemType.USER_MESSAGE:
                message = getattr(item, "message", None)
                content = str(item.content_text or "").strip()
                if not content and isinstance(message, UserMessage):
                    content = str(message.text or "").strip()
                if content:
                    self._renderer.seed_user_message(content)
                continue

            # 处理 AssistantMessage - 提取 tool_calls 信息但不渲染为动态组件
            if item.item_type == ItemType.ASSISTANT_MESSAGE:
                message = getattr(item, "message", None)
                if isinstance(message, AssistantMessage) and message.tool_calls:
                    for tc in message.tool_calls:
                        tool_name = tc.function.name
                        args_str = tc.function.arguments
                        try:
                            import json

                            args_dict = json.loads(args_str) if args_str else {}
                        except json.JSONDecodeError:
                            args_dict = {"_raw": args_str}
                        observable_inputs = (getattr(item, "metadata", {}) or {}).get(
                            TOOL_OBSERVABLE_INPUTS_METADATA_KEY
                        )
                        if isinstance(observable_inputs, dict):
                            observable_input = observable_inputs.get(tc.id)
                            if isinstance(observable_input, dict):
                                args_dict = observable_input
                        signature = self._build_resume_tool_signature(tool_name, args_dict)
                        # 存储映射，不调用 restore_tool_call（避免加入 _running_tools）
                        tool_call_info[tc.id] = (tool_name, signature)
                        tool_call_args[tc.id] = args_dict

                # 显示 assistant text
                assistant_text = self._extract_assistant_text(item).strip()
                if assistant_text:
                    self._renderer.append_assistant_message(assistant_text)
                continue

            # 处理 TOOL_RESULT - 直接输出静态文本（无计时器）
            if item.item_type == ItemType.TOOL_RESULT:
                message = getattr(item, "message", None)
                if message is None:
                    continue

                tool_call_id = getattr(message, "tool_call_id", None)
                is_error = getattr(message, "is_error", False)

                # 从映射中获取工具信息
                if tool_call_id and tool_call_id in tool_call_info:
                    tool_name, signature = tool_call_info[tool_call_id]
                else:
                    # 回退：直接使用 tool_name
                    tool_name = getattr(message, "tool_name", item.tool_name or "UnknownTool")
                    signature = f"{tool_name}()"

                # Apply shared visibility filter.
                resume_args = tool_call_args.get(tool_call_id, {}) if tool_call_id else {}
                if not should_show_tool_in_scrollback(tool_name, resume_args, is_result=True, is_error=is_error):
                    continue

                # Extract metadata from ContextItem
                item_metadata = getattr(item, "metadata", {}) or {}

                # Extract diff from raw_envelope for Edit
                diff_lines: list[str] | None = None
                if tool_name == "Edit" and not is_error:
                    envelope = item_metadata.get("tool_raw_envelope")
                    if isinstance(envelope, dict):
                        data = envelope.get("data", {})
                        if isinstance(data, dict):
                            diff = data.get("diff")
                            if isinstance(diff, list) and len(diff) > 0:
                                diff_lines = diff

                subtitle = None
                if is_error:
                    subtitle = str(item.content_text or getattr(message, "content", "") or "").strip() or None
                else:
                    subtitle_metadata = {"diff": diff_lines} if diff_lines is not None else None
                    subtitle = self._renderer._build_tool_subtitle(
                        tool_name,
                        str(item.content_text or getattr(message, "content", "") or ""),
                        subtitle_metadata,
                    )

                # Extract model_name for Agent tools
                model_name = ""
                if tool_name.lower() == "agent":
                    exec_meta = item_metadata.get("tool_execution_meta")
                    if isinstance(exec_meta, dict):
                        model_name = exec_meta.get("model_name", "")

                # 直接追加静态 HistoryEntry（无计时器）
                self._renderer.append_static_tool_result(
                    signature,
                    is_error,
                    diff_lines=diff_lines,
                    model_name=model_name,
                    subtitle=subtitle,
                )
                continue

        self._drain_history_sync()

    def _summarize_tool_args(self, tool_name: str, args: dict[str, Any]) -> str:
        """Summarize tool arguments for display in history."""
        from comate_cli.terminal_agent.tool_view import summarize_tool_args

        summary = summarize_tool_args(tool_name, args, self._renderer._project_root).strip()
        return summary

    @staticmethod
    def _lookup_arg(args: dict[str, Any], *keys: str) -> Any:
        for key in keys:
            if key in args:
                return args.get(key)
        params = args.get("params")
        if isinstance(params, dict):
            for key in keys:
                if key in params:
                    return params.get(key)
        return None

    def _build_resume_tool_signature(self, tool_name: str, args: dict[str, Any]) -> str:
        from comate_cli.terminal_agent.tool_view import resolve_display_tool_name

        lowered = tool_name.lower()
        if lowered != "agent":
            display_name = resolve_display_tool_name(tool_name, args)
            summary = self._summarize_tool_args(tool_name, args)
            if summary:
                return f"{display_name}({summary})"
            return f"{display_name}()"

        raw_subagent = self._lookup_arg(args, "subagent_type")
        subagent_name = raw_subagent.strip() if isinstance(raw_subagent, str) else ""
        if not subagent_name:
            subagent_name = "Agent"

        raw_description = self._lookup_arg(args, "description")
        description = raw_description.strip() if isinstance(raw_description, str) else ""
        if description and description != subagent_name:
            return f"{subagent_name}({description})"
        return subagent_name

    @staticmethod
    def _extract_assistant_text(item: Any) -> str:
        """从 ContextItem 提取用于显示的文本（不含 tool_calls JSON）"""
        message = getattr(item, "message", None)
        if message is None:
            return ""

        # 优先使用 message.text（纯文本，不含 tool_calls）
        if hasattr(message, "text"):
            text = message.text
            if isinstance(text, str):
                return text

        # 回退：处理非标准 content
        msg_content = getattr(message, "content", "")
        if isinstance(msg_content, str):
            return msg_content
        if isinstance(msg_content, list):
            text_parts: list[str] = []
            for part in msg_content:
                if isinstance(part, dict) and part.get("type") == "text":
                    text_parts.append(str(part.get("text", "")))
            return "".join(text_parts)

        return ""

    async def _drain_history_async(self) -> None:
        pending = self._pending_history_entries()
        if not pending:
            return
        team_pending = [
            entry
            for entry in pending
            if entry.entry_type == "system" and isinstance(entry.text, str) and entry.text.startswith("[team] ")
        ]
        if team_pending:
            logger.debug(
                "[team-diag] history_async_drain "
                "session_id=%r pending_count=%d team_pending_count=%d printed_index=%d",
                getattr(self._session, "session_id", ""),
                len(pending),
                len(team_pending),
                self._printed_history_index,
            )
            for entry in team_pending:
                logger.debug(
                    "[team-diag] history_async_entry text=%r",
                    entry.text,
                )
        group = render_history_group(
            console,
            pending,
            terminal_width=self._terminal_width(),
            render_markdown_to_plain=render_markdown_to_plain,
            prev_was_assistant=self._last_drained_was_assistant,
            prev_was_thinking=self._last_drained_thinking_tail_needs_gap,
            assume_run_continues_at_tail=getattr(self, "_busy", False),
        )
        if group is None:
            return
        busy = getattr(self, "_busy", False)
        self._last_drained_was_assistant = pending[-1].entry_type == "assistant"
        self._last_drained_thinking_tail_needs_gap = (
            pending[-1].entry_type == "thinking" and busy
        )

        def _print() -> None:
            width = self._terminal_width()
            out = sys.__stdout__ or sys.stdout
            scrollback_console = Console(
                file=out,
                force_terminal=True,
                width=width,
            )
            print_history_group_sync(scrollback_console, group)

        await run_in_terminal(_print, in_executor=True)

    def _drain_history_sync(self) -> None:
        pending = self._pending_history_entries()
        if not pending:
            return
        team_pending = [
            entry
            for entry in pending
            if entry.entry_type == "system" and isinstance(entry.text, str) and entry.text.startswith("[team] ")
        ]
        if team_pending:
            logger.debug(
                "[team-diag] history_sync_drain "
                "session_id=%r pending_count=%d team_pending_count=%d printed_index=%d",
                getattr(self._session, "session_id", ""),
                len(pending),
                len(team_pending),
                self._printed_history_index,
            )
            for entry in team_pending:
                logger.debug(
                    "[team-diag] history_sync_entry text=%r",
                    entry.text,
                )
        group = render_history_group(
            console,
            pending,
            terminal_width=self._terminal_width(),
            render_markdown_to_plain=render_markdown_to_plain,
            prev_was_assistant=self._last_drained_was_assistant,
            prev_was_thinking=self._last_drained_thinking_tail_needs_gap,
            assume_run_continues_at_tail=getattr(self, "_busy", False),
        )
        if group is None:
            return
        busy = getattr(self, "_busy", False)
        self._last_drained_was_assistant = pending[-1].entry_type == "assistant"
        self._last_drained_thinking_tail_needs_gap = (
            pending[-1].entry_type == "thinking" and busy
        )
        print_history_group_sync(console, group)

    def _pending_history_entries(self) -> list[HistoryEntry]:
        entries = self._renderer.history_entries()
        if self._printed_history_index >= len(entries):
            return []
        previous_index = self._printed_history_index
        pending = entries[self._printed_history_index :]
        self._printed_history_index = len(entries)
        team_pending = [
            entry
            for entry in pending
            if entry.entry_type == "system" and isinstance(entry.text, str) and entry.text.startswith("[team] ")
        ]
        if team_pending:
            logger.debug(
                "[team-diag] history_pending "
                "session_id=%r previous_index=%d new_index=%d total_entries=%d team_pending_count=%d",
                getattr(self._session, "session_id", ""),
                previous_index,
                self._printed_history_index,
                len(entries),
                len(team_pending),
            )
            for entry in team_pending:
                logger.debug(
                    "[team-diag] history_pending_entry text=%r",
                    entry.text,
                )
        return pending
