from __future__ import annotations

import time
import unittest
from types import SimpleNamespace

from prompt_toolkit.completion import Completion

from comate_cli.terminal_agent.tui_parts.render_panels import RenderPanelsMixin


class _FakeCompleteState:
    def __init__(
        self,
        completions: list[Completion],
        selected_index: int | None,
    ) -> None:
        self.completions = completions
        self.complete_index = selected_index
        if selected_index is None:
            self.current_completion = None
        elif 0 <= selected_index < len(completions):
            self.current_completion = completions[selected_index]
        else:
            self.current_completion = None


class _FakeStatusBar:
    def __init__(self) -> None:
        self.git_diff_calls = 0

    def get_mode(self) -> str:
        return "act"

    def info_status_text(self) -> str:
        return "model | ~main / 100%  left"

    def git_diff_fragments(self) -> list[tuple[str, str]]:
        self.git_diff_calls += 1
        return []

    @property
    def transient_message(self) -> str | None:
        return None


class _FakeLoadingState:
    def __init__(self, text: str = "") -> None:
        self.text = text


class _FakeRenderer:
    def __init__(self) -> None:
        self.active_todos = False
        self.running_subagents = False
        self.running_tools = False
        self.todo_lines: list[str] = []
        self.tool_entries: list[tuple[int, str]] = [(0, "Agent(task) · 1s · +1 tool uses")]

    def has_active_todos(self) -> bool:
        return self.active_todos

    def has_running_subagents(self) -> bool:
        return self.running_subagents

    def has_running_tools(self) -> bool:
        return self.running_tools

    def loading_state(self) -> _FakeLoadingState:
        return _FakeLoadingState("")

    def loading_aux_text(self) -> str:
        return ""

    def compute_required_tool_panel_lines(self) -> int:
        return len(self.tool_entries)

    def tool_panel_entries(self, *, max_lines: int) -> list[tuple[int, str]]:
        return list(self.tool_entries[:max_lines])

    def todo_panel_lines(self, *, max_lines: int) -> list[str]:
        if len(self.todo_lines) <= max_lines:
            return list(self.todo_lines)
        clipped = list(self.todo_lines[: max_lines - 1])
        clipped.append(f"… (+{len(self.todo_lines) - (max_lines - 1)})")
        return clipped

    def todo_all_lines(self) -> list[str]:
        return list(self.todo_lines)


class _FakeTUI(RenderPanelsMixin):
    def __init__(
        self,
        complete_state: _FakeCompleteState | None,
        *,
        width: int = 80,
    ) -> None:
        self._input_area = SimpleNamespace(
            buffer=SimpleNamespace(complete_state=complete_state)
        )
        self._status_bar = _FakeStatusBar()
        self._app = None
        self._width = width
        self._renderer = _FakeRenderer()
        self._todo_panel_max_lines = 6
        self._todo_panel_expanded_max_lines = 8
        self._todo_panel_expanded = False
        self._todo_panel_scroll = 0
        self._loading_frame = 0
        self._busy = False
        self._tool_panel_max_lines = 4
        self._tool_result_flash_active = False
        self._tool_result_animator = SimpleNamespace(is_active=False)
        self._animator = SimpleNamespace(is_active=False)
        self._run_start_time: float | None = None
        self._fallback_loading_phrase = "Thinking"
        self._loading_tip_text = ""
        self._loading_tip_show_at_monotonic: float | None = None

    @staticmethod
    def _format_run_elapsed(seconds: float) -> str:
        elapsed = max(seconds, 0.0)
        if elapsed < 10.0:
            return f"{elapsed:.1f}s"
        if elapsed < 60.0:
            return f"{int(elapsed)}s"
        minutes = int(elapsed) // 60
        secs = int(elapsed) % 60
        return f"{minutes}m {secs}s"

    def _terminal_width(self) -> int:
        return self._width


def _join_fragments(fragments: list[tuple[str, str]]) -> str:
    return "".join(text for _, text in fragments)


class TestCompletionStatusPanel(unittest.TestCase):
    def test_slash_completion_renders_name_and_meta(self) -> None:
        completion = Completion(
            text="/help",
            start_position=0,
            display="/help (h)",
            display_meta="Show available slash commands",
        )
        tui = _FakeTUI(_FakeCompleteState([completion], selected_index=0))

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("/help (h)", text)
        self.assertIn("Show available slash commands", text)

    def test_slash_completion_aligns_command_and_description_columns(self) -> None:
        completions = [
            Completion(
                text="/m",
                start_position=0,
                display="/m",
                display_meta="switch model",
            ),
            Completion(
                text="/very-long-command",
                start_position=0,
                display="/very-long-command",
                display_meta="long command desc",
            ),
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=0))

        fragments = tui._completion_panel_text()
        text = _join_fragments(fragments)

        expected_first_gap = (len("/very-long-command") - len("/m")) + 5
        self.assertIn(f"› /m{' ' * expected_first_gap}switch model", text)
        self.assertIn("  /very-long-command     long command desc", text)
        self.assertTrue(
            any(
                style == "class:completion.status.meta" and "switch model" in row
                for style, row in fragments
            )
        )

    def test_mention_completion_renders_path_without_meta_separator(self) -> None:
        completion = Completion(
            text="src/main.py ",
            start_position=0,
            display="src/main.py",
        )
        tui = _FakeTUI(_FakeCompleteState([completion], selected_index=0))

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("src/main.py", text)
        self.assertNotIn("—", text)

    def test_selected_completion_uses_current_style(self) -> None:
        completions = [
            Completion(text="/help", start_position=0, display="/help"),
            Completion(text="/model", start_position=0, display="/model"),
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=1))

        fragments = tui._completion_panel_text()

        selected_rows = [
            text
            for style, text in fragments
            if style == "class:completion.status.current"
        ]
        self.assertTrue(any("/model" in row for row in selected_rows))

    def test_overflow_shows_more_indicator_and_caps_height(self) -> None:
        completions = [
            Completion(text=f"/cmd{i}", start_position=0, display=f"/cmd{i}")
            for i in range(12)
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=4))

        text = _join_fragments(tui._completion_panel_text())

        self.assertEqual(tui._completion_panel_height(), 8)
        self.assertIn("/cmd4", text)
        self.assertIn("… and 4 more", text)

    def test_overflow_at_bottom_hides_more_indicator(self) -> None:
        completions = [
            Completion(text=f"/cmd{i}", start_position=0, display=f"/cmd{i}")
            for i in range(12)
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=11))

        text = _join_fragments(tui._completion_panel_text())

        self.assertNotIn("… and", text)

    def test_long_row_is_truncated(self) -> None:
        completion = Completion(
            text="/very-long-command-name",
            start_position=0,
            display="/very-long-command-name",
            display_meta="meta information is also very long",
        )
        tui = _FakeTUI(
            _FakeCompleteState([completion], selected_index=0),
            width=16,
        )

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("…", text)

    def test_loading_hide_gate(self) -> None:
        tui = _FakeTUI(None)
        # 默认：无 todo 无工具 → 不隐藏
        self.assertFalse(tui._should_hide_loading_panel())

        # 有 todo，无工具运行 → 隐藏
        tui._renderer.active_todos = True
        tui._renderer.running_tools = False
        self.assertTrue(tui._should_hide_loading_panel())
        self.assertEqual(tui._loading_text(), [("", " ")])

        # 有 todo 且有工具运行（subagent 执行中）→ 不隐藏，工具面板继续承载多行工具信息
        tui._renderer.active_todos = True
        tui._renderer.running_tools = True
        self.assertFalse(tui._should_hide_loading_panel())
        self.assertNotEqual(tui._loading_text(), [("", " ")])

        # 无 todo，有工具运行 → 不隐藏
        tui._renderer.active_todos = False
        tui._renderer.running_tools = True
        self.assertFalse(tui._should_hide_loading_panel())

    def test_loading_tip_waits_for_delay(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._busy = True
        tui._loading_tip_text = "Use /context when a task starts to feel fuzzy."
        tui._loading_tip_show_at_monotonic = time.monotonic() + 10.0

        text = _join_fragments(tui._loading_text())

        self.assertIn("Thinking", text)
        self.assertNotIn("Tip:", text)
        self.assertEqual(tui._loading_height(), 1)

    def test_loading_tip_renders_as_temporary_subtitle_line(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._busy = True
        tui._loading_tip_text = "Use /context when a task starts to feel fuzzy."
        tui._loading_tip_show_at_monotonic = time.monotonic() - 0.1

        text = _join_fragments(tui._loading_text())

        self.assertIn("\n", text)
        self.assertIn("⎿", text)
        self.assertIn("Tip: Use /context", text)
        self.assertEqual(tui._loading_height(), 2)

    def test_loading_tip_hidden_while_running_tools_own_panel(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._busy = True
        tui._renderer.running_tools = True
        tui._loading_tip_text = "Use /context when a task starts to feel fuzzy."
        tui._loading_tip_show_at_monotonic = time.monotonic() - 0.1

        text = _join_fragments(tui._loading_text())

        self.assertNotIn("Tip:", text)
        self.assertNotIn("⎿", text)

    def test_todo_title_uses_shimmer_fragments(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._renderer.todo_lines = [
            "发布流程",
            "  ◉ 撰写方案 ⏳",
        ]
        tui._loading_frame = 7

        fragments = tui._todo_text()
        header_styles: set[str] = set()
        header_text_parts: list[str] = []
        for style, text in fragments:
            if text == "\n":
                break
            header_styles.add(style)
            header_text_parts.append(text)

        header_text = "".join(header_text_parts)
        self.assertIn("发布流程", header_text)
        self.assertGreater(len(header_styles), 1)

    def test_todo_title_appends_elapsed_suffix_when_running(self) -> None:
        tui = _FakeTUI(None, width=120)
        tui._renderer.todo_lines = [
            "发布流程",
            "  ◉ 撰写方案 ⏳",
        ]
        tui._run_start_time = time.monotonic() - 12.0

        text = _join_fragments(tui._todo_text())

        self.assertIn("发布流程", text)
        self.assertIn("ctrl+c to interrupt", text)

    def test_expanded_todo_panel_shows_scroll_hint_and_range(self) -> None:
        tui = _FakeTUI(None, width=120)
        tui._renderer.active_todos = True
        tui._renderer.todo_lines = [
            "发布流程",
            "  ◉ task-1",
            "  ○ task-2",
            "  ○ task-3",
            "  ○ task-4",
            "  ○ task-5",
            "  ○ task-6",
            "  ○ task-7",
            "  ○ task-8",
        ]
        tui._todo_panel_expanded = True

        text = _join_fragments(tui._todo_text())

        self.assertIn("Ctrl+Y collapse", text)
        self.assertIn("[1-7/8]", text)
        self.assertEqual(tui._todo_height(), 8)

    def test_collapsed_todo_panel_shows_expand_hint_when_folded(self) -> None:
        tui = _FakeTUI(None, width=120)
        tui._renderer.active_todos = True
        tui._renderer.todo_lines = [
            "发布流程",
            "  ◉ task-1",
            "  ○ task-2",
            "  ○ task-3",
            "  ○ task-4",
            "  ○ task-5",
            "  ○ task-6",
            "  ○ task-7",
        ]

        text = _join_fragments(tui._todo_text())

        self.assertIn("Ctrl+Y to expand", text)

    def test_expanded_todo_panel_respects_scroll_offset(self) -> None:
        tui = _FakeTUI(None, width=120)
        tui._renderer.active_todos = True
        tui._renderer.todo_lines = [
            "发布流程",
            "  ◉ task-1",
            "  ○ task-2",
            "  ○ task-3",
            "  ○ task-4",
            "  ○ task-5",
            "  ○ task-6",
            "  ○ task-7",
            "  ○ task-8",
        ]
        tui._todo_panel_expanded = True
        tui._todo_panel_scroll = 2

        text = _join_fragments(tui._todo_text())

        self.assertIn("[2-8/8]", text)
        self.assertIn("task-2", text)
        self.assertIn("task-8", text)
        self.assertNotIn("task-1", text)

    def test_status_text_skips_git_diff_when_busy(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._busy = True

        _join_fragments(tui._status_text())

        self.assertEqual(tui._status_bar.git_diff_calls, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
