from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

from prompt_toolkit.history import InMemoryHistory

from comate_agent_sdk.agent.events import TeamMessageEvent
from comate_cli.terminal_agent.tui import TerminalAgentTUI


class _FakeRenderer:
    latest_diff_lines = None

    def __init__(self) -> None:
        self.team_messages: list[dict[str, object]] = []
        self._show_thinking_cb = None

    def history_entries(self) -> list[object]:
        return []

    def append_team_message_event(self, **kwargs) -> None:
        self.team_messages.append(dict(kwargs))

    def append_system_message(self, _text: str, severity: str | None = None) -> None:
        return None

    def has_active_todos(self) -> bool:
        return False

    def has_running_tools(self) -> bool:
        return False


class _FakeSession:
    def __init__(self) -> None:
        self.session_id = "session-for-team-message-test"
        self._cwd = "."
        self._storage_root = "."
        self._agent = SimpleNamespace(
            _team=SimpleNamespace(team_message_event_callback=None),
            _runtime_state=SimpleNamespace(skills=[]),
        )

    def get_mode(self) -> str:
        return "act"

    def peek_queue(self) -> list[object]:
        return []


class _FakeStatusBar:
    transient_message = ""
    transient_severity = None
    has_transient = False

    def __init__(self) -> None:
        self.mode = "act"

    def set_mode(self, mode: str) -> None:
        self.mode = mode

    def get_mode(self) -> str:
        return self.mode

    def info_status_text(self) -> str:
        return "test-model"

    def git_diff_fragments(self) -> list[tuple[str, str]]:
        return []


def test_team_message_callback_does_not_wrap_run_in_terminal_with_background_task() -> None:
    session = _FakeSession()
    renderer = _FakeRenderer()
    fake_app = SimpleNamespace(create_background_task_called=False)

    def _create_background_task(_future) -> None:
        fake_app.create_background_task_called = True

    fake_app.create_background_task = _create_background_task

    def _run_in_terminal_now(func, render_cli_done=False, in_executor=False):  # type: ignore[no-untyped-def]
        assert render_cli_done is False
        assert in_executor is False
        func()
        return object()

    with (
        patch(
            "comate_cli.terminal_agent.tui.discover_custom_slash_commands",
            return_value=SimpleNamespace(warnings=[], commands=[]),
        ),
        patch.object(TerminalAgentTUI, "_create_input_history", return_value=InMemoryHistory()),
        patch("prompt_toolkit.application.get_app", return_value=fake_app),
        patch("comate_cli.terminal_agent.tui.run_in_terminal", side_effect=_run_in_terminal_now),
    ):
        TerminalAgentTUI(session, _FakeStatusBar(), renderer)  # type: ignore[arg-type]
        callback = session._agent._team.team_message_event_callback
        callback(
            TeamMessageEvent(
                agent_name="team-lead",
                from_agent="worker",
                to_agent="team-lead",
                message_type="message",
                content_preview="ready",
                timestamp="2026-05-06T00:00:00Z",
            )
        )

    assert fake_app.create_background_task_called is False
    assert renderer.team_messages == [
        {
            "agent_name": "team-lead",
            "from_agent": "worker",
            "to_agent": "team-lead",
            "message_type": "message",
            "content_preview": "ready",
            "timestamp": "2026-05-06T00:00:00Z",
        }
    ]
