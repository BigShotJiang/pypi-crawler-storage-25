from __future__ import annotations

import asyncio
import unittest
from collections.abc import Callable

from comate_agent_sdk.agent.compaction.models import ManualCompactionResult
from comate_cli.terminal_agent.slash_commands import SlashCommandSpec
from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin
from comate_cli.terminal_agent.tui_parts.slash_command_registry import SlashCommandRegistry


class _DummyRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []
        self.events: list[tuple[str, str, str]] = []

    def append_system_message(self, content: str, *, severity: str = "info") -> None:
        self.messages.append((content, severity))
        self.events.append(("system", content, severity))

    def seed_user_message(self, content: str) -> None:
        self.events.append(("user", content, "info"))

    def append_subtitle(self, content: str, *, severity: str = "info") -> None:
        self.events.append(("subtitle", content, severity))


class _DummyStatusBar:
    def __init__(self) -> None:
        self.refresh_calls = 0

    async def refresh(self) -> None:
        self.refresh_calls += 1


class _DummySession:
    def __init__(
        self,
        result: ManualCompactionResult,
        *,
        delay_s: float = 0.0,
        error: Exception | None = None,
        on_call: Callable[[], None] | None = None,
    ) -> None:
        self._result = result
        self._delay_s = max(delay_s, 0.0)
        self._error = error
        self._on_call = on_call

    async def compact_context_manual(self) -> ManualCompactionResult:
        if self._on_call is not None:
            self._on_call()
        if self._error is not None:
            raise self._error
        if self._delay_s > 0:
            await asyncio.sleep(self._delay_s)
        return self._result


class _DummyCommands(CommandsMixin):
    def __init__(
        self,
        result: ManualCompactionResult,
        *,
        delay_s: float = 0.0,
        error: Exception | None = None,
        on_call: Callable[[], None] | None = None,
    ) -> None:
        self._renderer = _DummyRenderer()
        self._status_bar = _DummyStatusBar()
        self._session = _DummySession(
            result,
            delay_s=delay_s,
            error=error,
            on_call=on_call,
        )
        self._busy = False
        self._run_start_time = None
        self._initializing = False
        self._is_compacting = False
        self._compact_task = None
        self._compact_cancel_requested = False
        self._pending_exit_after_compact_cancel = False
        self._exit_calls = 0
        self._refresh_calls = 0
        self._slash_registry = SlashCommandRegistry()
        self._slash_registry.register(
            spec=SlashCommandSpec(
                name="compact",
                description="compact",
                execution_kind="llm",
            ),
            handler=self._slash_compact,
        )

    def _set_busy(self, value: bool) -> None:
        self._busy = value

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1

    def _exit_app(self) -> None:
        self._exit_calls += 1


class TestCompactCommandSemantics(unittest.TestCase):
    def test_compact_sets_and_clears_run_timer(self) -> None:
        async def _run() -> None:
            started_during_call = {"value": False}
            commands = _DummyCommands(
                ManualCompactionResult(
                    attempted=True,
                    compacted=True,
                    tokens_before=1000,
                    tokens_after=120,
                    reason="success",
                ),
                delay_s=0.05,
                on_call=lambda: started_during_call.__setitem__(
                    "value", commands._run_start_time is not None
                ),
            )

            task = asyncio.create_task(commands._execute_command("/compact"))
            await asyncio.sleep(0)
            self.assertTrue(commands._busy)
            self.assertIsNotNone(commands._run_start_time)
            await task
            self.assertFalse(commands._busy)
            self.assertIsNone(commands._run_start_time)
            self.assertTrue(started_during_call["value"])

        asyncio.run(_run())

    def test_compact_refreshes_status_bar_after_success(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=True,
                tokens_before=1000,
                tokens_after=120,
                reason="success",
            )
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(commands._status_bar.refresh_calls, 1)
        self.assertTrue(
            any(
                kind == "subtitle" and "/compact completed:" in msg
                for kind, msg, _ in commands._renderer.events
            )
        )
        self.assertEqual(commands._exit_calls, 0)

    def test_compact_reports_not_attempted_in_english(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=False,
                compacted=False,
                reason="disabled",
            )
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(commands._renderer.events[-1][0], "subtitle")
        self.assertEqual(commands._renderer.events[-1][1], "/compact skipped: disabled")
        self.assertEqual(commands._renderer.events[-1][2], "warning")

    def test_compact_reports_no_changes_in_english(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=False,
                reason="The context was left unchanged.",
            )
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(commands._renderer.events[-1][0], "subtitle")
        self.assertEqual(
            commands._renderer.events[-1][1],
            "/compact made no changes: The context was left unchanged.",
        )
        self.assertEqual(commands._renderer.events[-1][2], "warning")

    def test_compact_no_changes_attaches_result_to_command_anchor(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=False,
                reason="The context was left unchanged.",
            )
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(
            commands._renderer.events,
            [
                ("user", "/compact", "info"),
                (
                    "subtitle",
                    "/compact made no changes: The context was left unchanged.",
                    "warning",
                ),
            ],
        )

    def test_compact_reports_cancelled_in_english(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=False,
                cancelled=True,
                reason="cancelled",
            )
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(commands._renderer.events[-1][0], "subtitle")
        self.assertEqual(
            commands._renderer.events[-1][1],
            "Manual compaction was cancelled. Changes were rolled back.",
        )
        self.assertEqual(commands._renderer.events[-1][2], "warning")

    def test_compact_rejects_args(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=False,
                compacted=False,
                reason="unused",
            )
        )

        asyncio.run(commands._execute_command("/compact --bad"))

        self.assertEqual(commands._status_bar.refresh_calls, 0)
        self.assertEqual(
            commands._renderer.events,
            [
                ("user", "/compact --bad", "info"),
                ("subtitle", "Usage: /compact", "error"),
            ],
        )

    def test_compact_exception_clears_run_timer(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=False,
                compacted=False,
                reason="unused",
            ),
            error=RuntimeError("boom"),
        )

        asyncio.run(commands._execute_command("/compact"))

        self.assertFalse(commands._busy)
        self.assertIsNone(commands._run_start_time)
        self.assertEqual(commands._status_bar.refresh_calls, 1)
        self.assertTrue(
            any(
                kind == "subtitle" and msg.startswith("/compact failed:")
                for kind, msg, _severity in commands._renderer.events
            )
        )

    def test_compact_rejects_duplicate_run_in_english(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=True,
                tokens_before=1000,
                tokens_after=120,
                reason="success",
            )
        )
        commands._is_compacting = True

        asyncio.run(commands._execute_command("/compact"))

        self.assertEqual(
            commands._renderer.events[-1][1],
            "/compact is already running. Please wait.",
        )
        self.assertEqual(commands._renderer.events[-1][0], "subtitle")
        self.assertEqual(commands._renderer.events[-1][2], "warning")


if __name__ == "__main__":
    unittest.main()
