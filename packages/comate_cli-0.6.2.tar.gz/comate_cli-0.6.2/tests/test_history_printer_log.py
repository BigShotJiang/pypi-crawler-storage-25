"""log entry 渲染分支与 _render_subtitle_line 三态测试。"""
from __future__ import annotations

from io import StringIO

from rich.console import Console
from rich.text import Text

from comate_cli.terminal_agent.figures import BLACK_CIRCLE, HEAVY_MULTIPLICATION
from comate_cli.terminal_agent.history_printer import (
    _render_subtitle_line,
    print_history_group_sync,
    render_history_group,
)
from comate_cli.terminal_agent.models import HistoryEntry


def _styles_in(line: Text) -> list[str]:
    """返回 rich Text 内每段的 style 字符串列表。"""
    return [str(span.style) for span in line.spans]


def test_render_subtitle_line_default_dim() -> None:
    line = _render_subtitle_line("subtitle text")
    plain = line.plain
    assert "⎿" in plain
    assert "subtitle text" in plain
    styles = _styles_in(line)
    assert any("dim" in style for style in styles)


def test_render_subtitle_line_warning_yellow() -> None:
    line = _render_subtitle_line("warn body", warning=True)
    styles = _styles_in(line)
    assert any("#E8B830" in style for style in styles)


def test_render_subtitle_line_error_uses_hex_red() -> None:
    """error 色值从 bold red 迁移到 bold #FF6B6B。"""
    line = _render_subtitle_line("err body", error=True)
    styles = _styles_in(line)
    assert any("#FF6B6B" in style for style in styles)
    assert any("bold" in style for style in styles)


def test_render_subtitle_line_multiline_indents_continuation() -> None:
    """attached log 多行只在首行出现 ⎿，后续行用 6 空格对齐。"""
    line = _render_subtitle_line("first\nsecond", warning=True)
    lines = line.plain.splitlines()
    assert lines[0].startswith("  ⎿  first")
    assert lines[1] == "      second"


def _render_to_string(entries: list[HistoryEntry]) -> str:
    """渲染 entries 到字符串，便于断言 plain text 与 ANSI。"""
    buf = StringIO()
    console = Console(
        file=buf,
        force_terminal=True,
        color_system="truecolor",
        no_color=False,
        width=120,
    )
    group = render_history_group(
        console,
        entries,
        terminal_width=120,
        render_markdown_to_plain=lambda text, width: text,
    )
    if group is None:
        return ""
    print_history_group_sync(console, group)
    return buf.getvalue()


def test_log_attached_warning_renders_with_subtitle_glyph_and_yellow() -> None:
    entries = [
        HistoryEntry(entry_type="user", text="hello"),
        HistoryEntry(entry_type="log", text="net slow", severity="warning", attached=True),
    ]
    out = _render_to_string(entries)
    assert "⎿" in out
    assert "net slow" in out
    assert "E8B830" in out or "232;184;48" in out


def test_file_ref_warning_renders_with_subtitle_glyph_and_yellow() -> None:
    entries = [
        HistoryEntry(entry_type="user", text="/compact"),
        HistoryEntry(entry_type="file_ref", text="no changes", severity="warning"),
    ]
    out = _render_to_string(entries)
    assert "⎿" in out
    assert "no changes" in out
    assert "E8B830" in out or "232;184;48" in out


def test_log_attached_error_renders_red_bold() -> None:
    entries = [
        HistoryEntry(entry_type="user", text="hi"),
        HistoryEntry(entry_type="log", text="boom", severity="error", attached=True),
    ]
    out = _render_to_string(entries)
    assert "⎿" in out
    assert "boom" in out
    assert "FF6B6B" in out or "255;107;107" in out
    assert "\x1b[1;" in out or "\x1b[1m" in out


def test_log_standalone_warning_uses_circle() -> None:
    entries = [
        HistoryEntry(entry_type="log", text="early warn", severity="warning", attached=False),
    ]
    out = _render_to_string(entries)
    assert BLACK_CIRCLE in out
    assert "early warn" in out


def test_log_standalone_error_uses_cross() -> None:
    entries = [
        HistoryEntry(entry_type="log", text="early err", severity="error", attached=False),
    ]
    out = _render_to_string(entries)
    assert HEAVY_MULTIPLICATION in out
    assert "early err" in out


def test_consecutive_log_entries_no_blank_line_between() -> None:
    """连续 log 之间不加空行，仅链尾追加。"""
    entries = [
        HistoryEntry(entry_type="user", text="x"),
        HistoryEntry(entry_type="log", text="a", severity="warning", attached=True),
        HistoryEntry(entry_type="log", text="b", severity="warning", attached=True),
        HistoryEntry(entry_type="log", text="c", severity="error", attached=True),
    ]
    out = _render_to_string(entries)
    log_section = out[out.index("a"):]
    assert "\n\n" not in log_section.split("c")[0]


def test_consecutive_attached_logs_share_single_subtitle_glyph() -> None:
    entries = [
        HistoryEntry(entry_type="assistant", text="done"),
        HistoryEntry(
            entry_type="log",
            text="MCP configured 1 server(s) but no tools were loaded.",
            severity="warning",
            attached=True,
        ),
        HistoryEntry(
            entry_type="log",
            text="配置了 1 个 MCP server，但未加载到任何工具。",
            severity="warning",
            attached=True,
        ),
    ]

    out = _render_to_string(entries)

    assert out.count("⎿") == 1
    assert "MCP configured 1 server(s)" in out
    assert "配置了 1 个 MCP server" in out


def test_consecutive_file_refs_share_single_subtitle_glyph() -> None:
    entries = [
        HistoryEntry(entry_type="user", text="@src/ @docs/"),
        HistoryEntry(entry_type="file_ref", text="Listed directory src/"),
        HistoryEntry(entry_type="file_ref", text="Listed directory docs/"),
    ]

    out = _render_to_string(entries)

    assert out.count("⎿") == 1
    assert "Listed directory src/" in out
    assert "\n      " in out
    assert "Listed directory docs/" in out


def test_tool_result_subtitle_and_attached_log_share_single_glyph() -> None:
    entries = [
        HistoryEntry(
            entry_type="tool_result",
            text="Bash(command)",
            subtitle="Exit code 0",
        ),
        HistoryEntry(
            entry_type="log",
            text="cleanup completed",
            severity="warning",
            attached=True,
        ),
    ]

    out = _render_to_string(entries)

    assert out.count("⎿") == 1
    assert "Exit code 0" in out
    assert "cleanup completed" in out
