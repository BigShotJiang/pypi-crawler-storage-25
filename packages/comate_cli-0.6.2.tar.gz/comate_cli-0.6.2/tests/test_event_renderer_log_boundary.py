"""运行期 boundary 触发 flush_pending_logs 的集成测试。

boundary 列表：
  1. _flush_assistant_segment() 提交 assistant entry 之后
  2. _append_history_entry(tool_result) 之后
  3. seed_user_message() 提交 user entry 之后
  4. finalize_turn() 中 _force_flush_all / _flush_assistant_segment 之后
"""
from __future__ import annotations

import logging

from comate_agent_sdk.agent.events import TextDeltaEvent

from comate_cli.terminal_agent.event_renderer import EventRenderer
from comate_cli.terminal_agent.logging_adapter import TUILoggingHandler
from comate_cli.terminal_agent.models import HistoryEntry


def _log_entries(renderer: EventRenderer) -> list[HistoryEntry]:
    return [entry for entry in renderer.history_entries() if entry.entry_type == "log"]


def test_seed_user_message_flushes_pending_logs_attaching_to_user() -> None:
    """boundary 4：用户输入落地后，pending log 紧贴 user entry 之下。"""
    renderer = EventRenderer()
    renderer.enqueue_log(severity="error", message="net dropped")
    renderer.seed_user_message("hello")

    history = renderer.history_entries()
    assert history[-2].entry_type == "user"
    assert history[-1].entry_type == "log"
    assert history[-1].text == "net dropped"
    assert history[-1].attached is True


def test_start_turn_keeps_pending_logs_until_first_visible_anchor() -> None:
    """新 turn 开始不抢先落地 log；第一条 user anchor 承接它。"""
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="idle warn")
    renderer.start_turn()

    assert _log_entries(renderer) == []
    assert renderer._pending_logs == [("warning", "idle warn")]

    renderer.seed_user_message("hello")
    history = renderer.history_entries()
    assert [entry.entry_type for entry in history] == ["user", "log"]
    assert history[-1].text == "idle warn"
    assert history[-1].attached is True


def test_finalize_turn_flushes_pending_logs_after_text_delta_tail() -> None:
    """boundary 5：turn 收尾时 pending log 在真实 TextDelta 尾段之后落地。"""
    renderer = EventRenderer()
    renderer.seed_user_message("ddddd")
    renderer.handle_event(TextDeltaEvent(delta="assistant tail", message_id="m1"))
    renderer.enqueue_log(severity="warning", message="late warn")
    renderer.finalize_turn()
    history = renderer.history_entries()
    assistant_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "assistant")
    log_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "log")
    assert history[assistant_idx].text == "assistant tail\n"
    assert log_idx > assistant_idx
    assert history[log_idx].text == "late warn"
    assert history[log_idx].attached is True


def test_flush_assistant_segment_flushes_pending_logs() -> None:
    """boundary 2：assistant 段落落地后，pending log 贴在它下面。"""
    renderer = EventRenderer()
    renderer._assistant_buffer = "thinking aloud"
    renderer.enqueue_log(severity="warning", message="streaming warn")
    renderer._flush_assistant_segment()
    history = renderer.history_entries()
    assistant_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "assistant")
    log_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "log")
    assert log_idx > assistant_idx
    assert history[log_idx].attached is True


def test_tool_result_append_flushes_pending_logs_attaching_after_subtitle() -> None:
    """boundary 3：tool_result 入条后，pending log 贴在 subtitle 之后形成链。"""
    renderer = EventRenderer()
    renderer.seed_user_message("跑这个")
    renderer.enqueue_log(severity="warning", message="cleanup deferred")
    renderer.append_static_tool_result(
        signature="Bash(command=ls -la)",
        is_error=False,
        subtitle="Exit code 0",
    )
    history = renderer.history_entries()
    tool_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "tool_result")
    log_idx = next(i for i, entry in enumerate(history) if entry.entry_type == "log")
    assert log_idx == tool_idx + 1
    assert history[log_idx].attached is True


def test_interrupt_turn_does_not_drop_pending_logs() -> None:
    """用户中断不丢已入队 log，等下个 boundary 再落地。"""
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="will survive")
    renderer.interrupt_turn()
    assert len(renderer._pending_logs) == 1
    renderer.start_turn()
    assert len(renderer._pending_logs) == 1
    renderer.seed_user_message("next turn")
    logs = _log_entries(renderer)
    assert len(logs) == 1
    assert logs[0].text == "will survive"


def test_seed_user_message_flushes_log_after_file_ref_hint(tmp_path) -> None:
    """boundary 4：若 user message 产生 file_ref hint，log 排在 hint 后并 attached。"""
    (tmp_path / "main.py").write_text("x\n", encoding="utf-8")
    renderer = EventRenderer(project_root=tmp_path)
    renderer.enqueue_log(severity="warning", message="path context warn")
    renderer.seed_user_message("@main.py")

    history = renderer.history_entries()
    assert [entry.entry_type for entry in history[-3:]] == ["user", "file_ref", "log"]
    assert "Read main.py" in str(history[-2].text)
    assert history[-1].attached is True


def test_tick_progress_and_refresh_loading_animation_do_not_flush_logs() -> None:
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="heartbeat warn")

    renderer.tick_progress()
    renderer.refresh_loading_animation()

    assert renderer._pending_logs == [("warning", "heartbeat warn")]
    assert all(entry.entry_type != "log" for entry in renderer.history_entries())


def test_logger_warning_during_streaming_does_not_split_assistant_run() -> None:
    """streaming 中 logger.warning 不会插入到正在累积的 assistant 文本中间。"""
    renderer = EventRenderer()
    handler = TUILoggingHandler(renderer)
    handler.setLevel(logging.WARNING)

    renderer.seed_user_message("帮我跑这个")
    renderer.handle_event(TextDeltaEvent(delta="I'll run this for you. ", message_id="m1"))

    record = logging.LogRecord(
        name="x.y",
        level=logging.WARNING,
        pathname="",
        lineno=0,
        msg="token estimation fallback",
        args=(),
        exc_info=None,
    )
    handler.emit(record)

    assert any(item[1].startswith("token estimation") for item in renderer._pending_logs)
    assert all(entry.entry_type != "log" for entry in renderer.history_entries())

    renderer.handle_event(TextDeltaEvent(delta="Here's what I see.", message_id="m1"))
    renderer.finalize_turn()

    history = renderer.history_entries()
    assert history[-2].entry_type == "assistant"
    assert history[-2].text == "I'll run this for you. Here's what I see.\n"
    assert history[-1].entry_type == "log"
    assert history[-1].attached is True


def test_consecutive_logs_chain_under_single_anchor() -> None:
    """3 条 log 同 boundary 落地，全部挂在单一 anchor 下。"""
    renderer = EventRenderer()
    renderer.seed_user_message("hi")
    renderer.enqueue_log(severity="warning", message="a")
    renderer.enqueue_log(severity="warning", message="b")
    renderer.enqueue_log(severity="error", message="c")

    renderer.finalize_turn()

    logs = _log_entries(renderer)
    assert [entry.text for entry in logs] == ["a", "b", "c"]
    assert [entry.attached for entry in logs] == [True, True, True]
