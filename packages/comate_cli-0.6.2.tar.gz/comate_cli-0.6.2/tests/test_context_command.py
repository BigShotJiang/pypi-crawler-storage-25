from __future__ import annotations

import unittest
from types import SimpleNamespace

from comate_cli.terminal_agent.slash_commands import SlashCommandSpec
from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin
from comate_cli.terminal_agent.tui_parts.slash_command_registry import SlashCommandRegistry


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []
        self.events: list[tuple[str, str, str]] = []

    def append_system_message(self, text: str, *, severity: str = "info") -> None:
        self.messages.append((text, severity))
        self.events.append(("system", text, severity))

    def seed_user_message(self, text: str) -> None:
        self.events.append(("user", text, "info"))

    def append_subtitle(self, text: str, *, severity: str = "info") -> None:
        self.events.append(("subtitle", text, severity))


class _Harness(CommandsMixin):
    def __init__(self, *, session: object, renderer: _FakeRenderer) -> None:
        self._session = session
        self._renderer = renderer
        self._busy = False
        self._refresh_calls = 0
        self._slash_registry = SlashCommandRegistry()
        self._slash_registry.register(
            spec=SlashCommandSpec(
                name="context",
                description="context",
                execution_kind="local",
            ),
            handler=self._slash_context,
        )

    def _set_busy(self, value: bool) -> None:
        self._busy = value

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1


class TestContextCommand(unittest.IsolatedAsyncioTestCase):
    def _build_session(self) -> object:
        info = SimpleNamespace(
            context_limit=204800,
            next_step_estimated_tokens=35635,
            last_step_reported_tokens=32096,
            used_tokens=32610,
        )
        usage = SimpleNamespace(
            prompt_tokens=32068,
            prompt_cached_tokens=0,
            prompt_cache_creation_tokens=9701,
            completion_tokens=28,
            total_tokens=32096,
        )
        usage_entry = SimpleNamespace(usage=usage)
        token_cost = SimpleNamespace(usage_history=[usage_entry])
        agent = SimpleNamespace(_token_cost=token_cost)
        return SimpleNamespace(
            _agent=agent,
            get_context_info=self._make_async_return(info),
        )

    @staticmethod
    def _make_async_return(value):
        async def _inner():
            return value

        return _inner

    async def test_context_default_shows_only_est_and_actual(self) -> None:
        renderer = _FakeRenderer()
        session = self._build_session()
        app = _Harness(session=session, renderer=renderer)

        await app._slash_context("")

        message, severity = renderer.messages[-1]
        self.assertEqual(severity, "info")
        self.assertIn("Headroom (est):", message)
        self.assertIn("Last call (actual):", message)
        self.assertNotIn("Context Details", message)
        self.assertNotIn("breakdown(last call)", message)

    async def test_context_details_shows_breakdown_and_delta(self) -> None:
        renderer = _FakeRenderer()
        session = self._build_session()
        app = _Harness(session=session, renderer=renderer)

        await app._slash_context("--details")

        message, severity = renderer.messages[-1]
        self.assertEqual(severity, "info")
        self.assertIn("Context Details", message)
        self.assertIn("breakdown(last call):", message)
        self.assertIn("I=22,367", message)
        self.assertIn("delta_ir_vs_actual: +514", message)

    async def test_context_invalid_args_show_usage(self) -> None:
        renderer = _FakeRenderer()
        session = self._build_session()
        app = _Harness(session=session, renderer=renderer)

        await app._slash_context("--unknown")

        message, severity = renderer.messages[-1]
        self.assertEqual(severity, "error")
        self.assertEqual(message, "Usage: /context [--details]")

    async def test_execute_context_invalid_args_attaches_usage_to_command_anchor(self) -> None:
        renderer = _FakeRenderer()
        session = self._build_session()
        app = _Harness(session=session, renderer=renderer)

        await app._execute_command("/context --unknown")

        self.assertEqual(
            renderer.events,
            [
                ("user", "/context --unknown", "info"),
                ("subtitle", "Usage: /context [--details]", "error"),
            ],
        )
        self.assertEqual(app._refresh_calls, 1)


if __name__ == "__main__":
    unittest.main()
