from __future__ import annotations

from comate_cli.terminal_agent.event_renderer import EventRenderer
from comate_cli.terminal_agent.models import HistoryEntry


def test_history_entry_attached_defaults_to_false() -> None:
    entry = HistoryEntry(entry_type="user", text="hello")
    assert entry.attached is False


def test_history_entry_log_type_literal_accepted() -> None:
    entry = HistoryEntry(
        entry_type="log",
        text="warning happened",
        severity="warning",
        attached=True,
    )
    assert entry.entry_type == "log"
    assert entry.attached is True
    assert entry.severity == "warning"


def test_enqueue_log_appends_to_pending() -> None:
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="something")
    assert renderer._pending_logs == [("warning", "something")]


def test_enqueue_log_strips_and_drops_empty() -> None:
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="   \n  ")
    renderer.enqueue_log(severity="warning", message="")
    renderer.enqueue_log(severity="error", message="   real   ")
    assert renderer._pending_logs == [("error", "real")]


def test_enqueue_log_thread_safe() -> None:
    """50 线程各 enqueue 1 次，不丢条；跨线程顺序不要求。"""
    import threading

    renderer = EventRenderer()
    barrier = threading.Barrier(50)

    def worker(idx: int) -> None:
        barrier.wait()
        renderer.enqueue_log(severity="warning", message=f"msg-{idx}")

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(50)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert len(renderer._pending_logs) == 50
    assert {item[1] for item in renderer._pending_logs} == {f"msg-{i}" for i in range(50)}
    assert all(item[0] == "warning" for item in renderer._pending_logs)


def _seed_anchor(renderer: EventRenderer) -> None:
    """在 history 末尾放一条 user entry 作为 anchor。"""
    renderer.seed_user_message("hello")


def test_flush_pending_logs_empty_history_first_log_standalone() -> None:
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="alpha")
    renderer.enqueue_log(severity="error", message="beta")
    renderer.flush_pending_logs()

    log_entries = [entry for entry in renderer.history_entries() if entry.entry_type == "log"]
    assert [entry.text for entry in log_entries] == ["alpha", "beta"]
    assert log_entries[0].attached is False
    assert log_entries[1].attached is True


def test_flush_pending_logs_with_anchor_first_log_attached() -> None:
    renderer = EventRenderer()
    renderer._append_history_entry(
        HistoryEntry(entry_type="user", text="ddddd")
    )
    renderer.enqueue_log(severity="warning", message="net interrupted")
    renderer.flush_pending_logs()

    log_entries = [entry for entry in renderer.history_entries() if entry.entry_type == "log"]
    assert log_entries[0].attached is True


def test_flush_pending_logs_clears_queue() -> None:
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="x")
    renderer.flush_pending_logs()
    assert renderer._pending_logs == []


def test_flush_pending_logs_idempotent_when_empty() -> None:
    renderer = EventRenderer()
    renderer.flush_pending_logs()
    renderer.flush_pending_logs()
    assert renderer._pending_logs == []
    assert all(entry.entry_type != "log" for entry in renderer.history_entries())


def test_reset_history_view_clears_pending_logs() -> None:
    """reset / rewind / 会话切换不允许把旧 pending log 挂到新会话第一条 entry 上。"""
    renderer = EventRenderer()
    renderer.enqueue_log(severity="warning", message="old session warn")
    assert renderer._pending_logs == [("warning", "old session warn")]

    renderer.reset_history_view()

    assert renderer._pending_logs == []
    renderer.seed_user_message("new turn")
    assert all(entry.entry_type != "log" for entry in renderer.history_entries())
