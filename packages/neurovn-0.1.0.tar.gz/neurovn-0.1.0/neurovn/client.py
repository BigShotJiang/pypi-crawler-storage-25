from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from typing import Any, Iterable
from urllib import error, request


@dataclass
class NeurovnClient:
    base_url: str | None = None
    timeout: float = 15.0

    def __post_init__(self) -> None:
        if not self.base_url:
            self.base_url = os.environ.get("NEUROVN_API_URL") or os.environ.get("NEXT_PUBLIC_API_URL") or "http://localhost:8000"

    def _post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            f"{self.base_url}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else {}
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8")
            raise RuntimeError(body or exc.reason) from exc

    def estimate(self, nodes: list[dict[str, Any]], edges: list[dict[str, Any]], recursion_limit: int = 25) -> dict[str, Any]:
        return self._post_json(
            "/api/estimate",
            {
                "nodes": nodes,
                "edges": edges,
                "recursion_limit": recursion_limit,
            },
        )

    def create_trace_session(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post_json("/api/traces/sessions", payload)
