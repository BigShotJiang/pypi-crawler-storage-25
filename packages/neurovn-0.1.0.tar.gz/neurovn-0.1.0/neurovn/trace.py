from __future__ import annotations

import asyncio
import functools
import inspect
import json
import os
import time
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, TypeVar
from uuid import uuid4

from .client import NeurovnClient

F = TypeVar("F", bound=Callable[..., Any])

_CURRENT_SESSION: ContextVar["TraceSession | None"] = ContextVar("neurovn_current_session", default=None)
_CURRENT_STACK: ContextVar[list[str]] = ContextVar("neurovn_current_stack", default=[])


def _truncate(value: Any, limit: int = 320) -> str:
    try:
        text = json.dumps(value, default=str, ensure_ascii=False)
    except Exception:
        text = repr(value)
    if len(text) > limit:
        return text[: limit - 1] + "…"
    return text


def _infer_provider(model: str | None, provider: str | None = None) -> str:
    if provider:
        return provider
    if not model:
        return "OpenAI"
    lowered = model.lower()
    if lowered.startswith("claude"):
        return "Anthropic"
    if lowered.startswith("gemini"):
        return "Google"
    return "OpenAI"


def _extract_usage(result: Any) -> dict[str, int] | None:
    """Extract provider token-usage metadata when available.

    Supports common SDK response shapes where usage is either an object or dict.
    """
    usage = None
    if isinstance(result, dict):
        usage = result.get("usage")
    if usage is None:
        usage = getattr(result, "usage", None)
    if usage is None:
        return None

    def _read(value: Any, key: str):
        if isinstance(value, dict):
            return value.get(key)
        return getattr(value, key, None)

    prompt_tokens = _read(usage, "prompt_tokens")
    if prompt_tokens is None:
        prompt_tokens = _read(usage, "input_tokens")

    completion_tokens = _read(usage, "completion_tokens")
    if completion_tokens is None:
        completion_tokens = _read(usage, "output_tokens")

    total_tokens = _read(usage, "total_tokens")

    normalized: dict[str, int] = {}
    if prompt_tokens is not None:
        normalized["prompt_tokens"] = int(prompt_tokens)
    if completion_tokens is not None:
        normalized["completion_tokens"] = int(completion_tokens)
    if total_tokens is not None:
        normalized["total_tokens"] = int(total_tokens)
    elif "prompt_tokens" in normalized or "completion_tokens" in normalized:
        normalized["total_tokens"] = normalized.get("prompt_tokens", 0) + normalized.get("completion_tokens", 0)

    return normalized or None


def _append_usage(session: "TraceSession", node: "TraceNode", usage: dict[str, int] | None) -> None:
    if not usage:
        return
    usage_map = session.metadata.setdefault("actual_usage", {})
    usage_map[node.id] = usage

    usage_tokens = []
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        if key in usage:
            usage_tokens.append(f"{key}={usage[key]}")
    if usage_tokens:
        node.context = f"{node.context} {' '.join(usage_tokens)}"


@dataclass
class TraceNode:
    id: str
    type: str
    label: str
    context: str = ""
    model_provider: str | None = None
    model_name: str | None = None
    tool_id: str | None = None
    tool_category: str | None = None
    parent_id: str | None = None
    children: list[str] = field(default_factory=list)

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.id,
            "type": self.type,
            "label": self.label,
            "context": self.context,
        }
        if self.model_provider:
            payload["model_provider"] = self.model_provider
        if self.model_name:
            payload["model_name"] = self.model_name
        if self.tool_id:
            payload["tool_id"] = self.tool_id
        if self.tool_category:
            payload["tool_category"] = self.tool_category
        return payload


@dataclass
class TraceSession:
    workflow_name: str
    source: str = "sdk"
    canvas_name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    nodes: list[TraceNode] = field(default_factory=list)
    edges: list[dict[str, str]] = field(default_factory=list)
    root_node_id: str | None = None
    finished: bool = False

    def add_node(
        self,
        *,
        type: str,
        label: str,
        context: str = "",
        model_provider: str | None = None,
        model_name: str | None = None,
        tool_id: str | None = None,
        tool_category: str | None = None,
        parent_id: str | None = None,
    ) -> TraceNode:
        node = TraceNode(
            id=f"{type}-{uuid4().hex[:10]}",
            type=type,
            label=label,
            context=context,
            model_provider=model_provider,
            model_name=model_name,
            tool_id=tool_id,
            tool_category=tool_category,
        )
        parent = parent_id
        if parent is None:
            self.root_node_id = node.id if self.root_node_id is None else self.root_node_id
        else:
            node.parent_id = parent
            self.edges.append({"id": f"edge-{parent}-{node.id}", "source": parent, "target": node.id})
            for existing in self.nodes:
                if existing.id == parent:
                    existing.children.append(node.id)
                    break
        self.nodes.append(node)
        return node

    def _ensure_start_and_finish(self) -> None:
        if not self.nodes:
            return
        if self.root_node_id is None:
            self.root_node_id = self.nodes[0].id
        start_id = "start"
        finish_id = "finish"
        if not any(node.id == start_id for node in self.nodes):
            self.nodes.insert(0, TraceNode(id=start_id, type="startNode", label="Start"))
        if not any(node.id == finish_id for node in self.nodes):
            self.nodes.append(TraceNode(id=finish_id, type="finishNode", label="Finish"))
        if not any(edge["source"] == start_id for edge in self.edges):
            self.edges.insert(0, {"id": f"edge-{start_id}-{self.root_node_id}", "source": start_id, "target": self.root_node_id or start_id})

        leaf_nodes = [node.id for node in self.nodes if node.id not in {start_id, finish_id} and not node.children]
        for leaf_id in leaf_nodes:
            edge_id = f"edge-{leaf_id}-{finish_id}"
            if not any(edge["id"] == edge_id for edge in self.edges):
                self.edges.append({"id": edge_id, "source": leaf_id, "target": finish_id})

    def to_payload(self) -> dict[str, Any]:
        self._ensure_start_and_finish()
        return {
            "source": self.source,
            "workflow_name": self.workflow_name,
            "canvas_name": self.canvas_name or self.workflow_name,
            "nodes": [node.to_payload() for node in self.nodes],
            "edges": list(self.edges),
            "metadata": self.metadata,
        }

    def emit(self, client: NeurovnClient | None = None) -> dict[str, Any]:
        client = client or NeurovnClient()
        payload = self.to_payload()
        graph_nodes = payload["nodes"]
        graph_edges = payload["edges"]
        if not graph_nodes:
            return {}
        estimation = client.estimate(graph_nodes, graph_edges)
        payload["estimation"] = estimation
        return client.create_trace_session(payload)


class _TraceAPI:
    def __init__(self) -> None:
        self.client = NeurovnClient()

    def session(
        self,
        workflow_name: str,
        *,
        source: str = "sdk",
        canvas_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        session = TraceSession(
            workflow_name=workflow_name,
            source=source,
            canvas_name=canvas_name,
            metadata=metadata or {},
        )

        class _SessionContext:
            def __enter__(self_inner):
                self_inner._token = _CURRENT_SESSION.set(session)
                return session

            def __exit__(self_inner, exc_type, exc, tb):
                try:
                    if not session.finished:
                        session.emit(self.client)
                        session.finished = True
                finally:
                    _CURRENT_SESSION.reset(self_inner._token)
                return False

            async def __aenter__(self_inner):
                return self_inner.__enter__()

            async def __aexit__(self_inner, exc_type, exc, tb):
                return self_inner.__exit__(exc_type, exc, tb)

        return _SessionContext()

    def _decorate(
        self,
        *,
        kind: str,
        name: str,
        model: str | None = None,
        provider: str | None = None,
        tool_id: str | None = None,
        tool_category: str | None = None,
    ):
        def decorator(fn: F) -> F:
            if inspect.iscoroutinefunction(fn):

                @functools.wraps(fn)
                async def async_wrapper(*args, **kwargs):
                    session = _CURRENT_SESSION.get()
                    created_session = False
                    if session is None:
                        session = TraceSession(workflow_name=name)
                        token = _CURRENT_SESSION.set(session)
                        created_session = True
                    else:
                        token = None

                    context = f"args={_truncate(args)} kwargs={_truncate(kwargs)}"
                    stack = list(_CURRENT_STACK.get())
                    stack_token = _CURRENT_STACK.set(stack)
                    parent_id = stack[-1] if stack else None
                    node = session.add_node(
                        type=kind,
                        label=name,
                        context=context,
                        model_provider=_infer_provider(model, provider) if kind == "agentNode" else None,
                        model_name=model if kind == "agentNode" else None,
                        tool_id=tool_id,
                        tool_category=tool_category,
                        parent_id=parent_id,
                    )
                    stack.append(node.id)
                    _CURRENT_STACK.set(stack)
                    start = time.perf_counter()
                    try:
                        result = await fn(*args, **kwargs)
                        node.context = f"{node.context} return={_truncate(result)}"
                        _append_usage(session, node, _extract_usage(result))
                        return result
                    finally:
                        stack = list(_CURRENT_STACK.get())
                        if stack and stack[-1] == node.id:
                            stack.pop()
                            _CURRENT_STACK.set(stack)
                        node.context = f"{node.context} duration_ms={round((time.perf_counter() - start) * 1000, 2)}"
                        if created_session:
                            try:
                                session.emit(self.client)
                            finally:
                                session.finished = True
                                _CURRENT_SESSION.reset(token)  # type: ignore[arg-type]
                                _CURRENT_STACK.reset(stack_token)

                return async_wrapper  # type: ignore[return-value]

            @functools.wraps(fn)
            def sync_wrapper(*args, **kwargs):
                session = _CURRENT_SESSION.get()
                created_session = False
                if session is None:
                    session = TraceSession(workflow_name=name)
                    token = _CURRENT_SESSION.set(session)
                    created_session = True
                else:
                    token = None

                context = f"args={_truncate(args)} kwargs={_truncate(kwargs)}"
                stack = list(_CURRENT_STACK.get())
                stack_token = _CURRENT_STACK.set(stack)
                parent_id = stack[-1] if stack else None
                node = session.add_node(
                    type=kind,
                    label=name,
                    context=context,
                    model_provider=_infer_provider(model, provider) if kind == "agentNode" else None,
                    model_name=model if kind == "agentNode" else None,
                    tool_id=tool_id,
                    tool_category=tool_category,
                    parent_id=parent_id,
                )
                stack.append(node.id)
                _CURRENT_STACK.set(stack)
                start = time.perf_counter()
                try:
                    result = fn(*args, **kwargs)
                    node.context = f"{node.context} return={_truncate(result)}"
                    _append_usage(session, node, _extract_usage(result))
                    return result
                finally:
                    stack = list(_CURRENT_STACK.get())
                    if stack and stack[-1] == node.id:
                        stack.pop()
                        _CURRENT_STACK.set(stack)
                    node.context = f"{node.context} duration_ms={round((time.perf_counter() - start) * 1000, 2)}"
                    if created_session:
                        try:
                            session.emit(self.client)
                        finally:
                            session.finished = True
                            _CURRENT_SESSION.reset(token)  # type: ignore[arg-type]
                            _CURRENT_STACK.reset(stack_token)

            return sync_wrapper  # type: ignore[return-value]

        return decorator

    def agent(self, *, name: str, model: str, provider: str | None = None):
        return self._decorate(kind="agentNode", name=name, model=model, provider=provider)

    def tool(self, *, name: str, tool_id: str | None = None, tool_category: str | None = None):
        return self._decorate(kind="toolNode", name=name, tool_id=tool_id, tool_category=tool_category)


trace = _TraceAPI()
