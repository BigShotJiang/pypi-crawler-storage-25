# Neurovn SDK

Python SDK and CLI for tracing agentic AI workflows.

## Installation

The package name is `neurovn`.

```bash
pip install neurovn
```

If you are working from this monorepo before publishing, install it in editable mode:

```bash
cd neurovn-sdk
pip install -e .
```

## Quick Start

### Decorator Integration

```python
from neurovn import trace

@trace.agent(name="Research Agent", model="gpt-4o", provider="OpenAI")
async def research(query: str) -> str:
    return "research results"

@trace.tool(name="Web Search", tool_id="mcp_web_search", tool_category="mcp_server")
async def web_search(query: str) -> str:
    return "search results"

with trace.session("My Workflow", source="decorator"):
    result = await research("latest AI updates")
```

### CLI Integration

```bash
python -m neurovn trace ./workflow.json --workflow-name "My Workflow" --source cli
```

## Features

- **Trace Decorators**: Instrument Python functions with `@trace.agent` and `@trace.tool`
- **CLI**: Emit workflow JSON files to Neurovn backend
- **Session Management**: Group multiple calls into a workflow session
- **Usage Tracking**: Capture token usage from LLM responses

## Documentation

For full integration guides and examples, visit [Neurovn Docs](https://neurovn.com/docs).

## License

MIT
