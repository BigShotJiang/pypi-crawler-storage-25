from assassin.cli import main
main()
