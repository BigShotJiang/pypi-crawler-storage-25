from setuptools import setup, find_packages

setup(
    name="shadow4243",
    version="1.0.1",
    description="MAD Android Lab Programs CLI",
    author="Shadow4243",
    packages=find_packages(),
    package_data={
        "assassin": ["data/**/*"],
    },
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "shadow4243=assassin.cli:main",
        ],
    },
    python_requires=">=3.6",
)
