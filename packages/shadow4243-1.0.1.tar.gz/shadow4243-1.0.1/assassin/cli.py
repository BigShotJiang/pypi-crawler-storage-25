import os
import shutil

def main():
    data_dir = os.path.join(os.path.dirname(__file__), "data")

    import re
    def natural_key(s):
        return [int(c) if c.isdigit() else c.lower() for c in re.split(r'(\d+)', s)]

    folders = sorted([
        f for f in os.listdir(data_dir)
        if os.path.isdir(os.path.join(data_dir, f))
    ], key=natural_key)

    if not folders:
        print("No folders found.")
        return

    print("\n🗂  MAD Lab Programs\n")
    for i, folder in enumerate(folders, 1):
        print(f"  {i}. {folder}")
    print()

    while True:
        try:
            choice = input("Enter number to save folder here (0 to exit): ").strip()
            if choice == "0":
                print("Bye!")
                return
            idx = int(choice) - 1
            if 0 <= idx < len(folders):
                break
            else:
                print(f"Enter a number between 1 and {len(folders)}.")
        except ValueError:
            print("Invalid. Enter a number.")

    selected = folders[idx]
    src = os.path.join(data_dir, selected)
    dest = os.path.join(os.getcwd(), selected)

    if os.path.exists(dest):
        print(f"⚠️  '{selected}' already exists here. Skipping.")
    else:
        shutil.copytree(src, dest)
        print(f"\n✅ Saved '{selected}' to current directory!\n")
