package com.example.menu

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button1 = findViewById<Button>(R.id.b1)
        val button2 = findViewById<Button>(R.id.b2)

        textView = findViewById(R.id.textView)

        // ✅ Register Context Menu for TextView
        registerForContextMenu(textView)

        // OPTIONAL: open context menu on button click
        button1.setOnClickListener {
            openContextMenu(textView)
        }

        // ✅ POPUP MENU
        button2.setOnClickListener {

            val popupMenu = PopupMenu(this, button2)

            popupMenu.menuInflater.inflate(
                R.menu.option_menu,
                popupMenu.menu
            )

            popupMenu.setOnMenuItemClickListener {

                when (it.itemId) {

                    R.id.item1 -> {
                        Toast.makeText(
                            this,
                            "Open Selected",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    R.id.item2 -> {
                        Toast.makeText(
                            this,
                            "Search Selected",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    R.id.item3 -> {
                        Toast.makeText(
                            this,
                            "Exit Selected",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                true
            }

            popupMenu.show()
        }
    }

    // ✅ OPTION MENU

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(
            R.menu.option_menu,
            menu
        )

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {

            R.id.item1 -> {
                Toast.makeText(
                    this,
                    "Open Selected",
                    Toast.LENGTH_SHORT
                ).show()
            }

            R.id.item2 -> {
                Toast.makeText(
                    this,
                    "Search Selected",
                    Toast.LENGTH_SHORT
                ).show()
            }

            R.id.item3 -> {
                Toast.makeText(
                    this,
                    "Exit Selected",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        return true
    }

    // ✅ CONTEXT MENU

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {

        super.onCreateContextMenu(
            menu,
            v,
            menuInfo
        )

        menu?.setHeaderTitle(
            "Select Option"
        )

        val inflater: MenuInflater =
            menuInflater

        inflater.inflate(
            R.menu.option_menu,
            menu
        )
    }

    override fun onContextItemSelected(
        item: MenuItem
    ): Boolean {

        when(item.itemId) {

            R.id.item1 -> {

                Toast.makeText(
                    this,
                    "Open Clicked",
                    Toast.LENGTH_SHORT
                ).show()

                return true
            }

            R.id.item2 -> {

                Toast.makeText(
                    this,
                    "Search Clicked",
                    Toast.LENGTH_SHORT
                ).show()

                return true
            }

            R.id.item3 -> {

                Toast.makeText(
                    this,
                    "Exit Clicked",
                    Toast.LENGTH_SHORT
                ).show()

                return true
            }
        }

        return super.onContextItemSelected(item)
    }
}