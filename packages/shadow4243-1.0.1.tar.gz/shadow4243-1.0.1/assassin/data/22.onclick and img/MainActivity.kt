package com.example.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun zenitsu(view: View) {
        Toast.makeText(this,"Zenitsu",Toast.LENGTH_LONG).show()
    }

    fun tanjiro(view: View) {
        Toast.makeText(this,"Tanjiro",Toast.LENGTH_LONG).show()
    }
}