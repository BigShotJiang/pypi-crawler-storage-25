package com.example.myapplicationq1
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onButtonClick(view: View) {
        val fn=findViewById<EditText>(R.id.FirstName)
        val ln =findViewById<EditText>(R.id.Lastname)
        val em=findViewById<EditText>(R.id.Email)
        val edfn=findViewById<TextView>(R.id.textView1)
        val edln=findViewById<TextView>(R.id.textView2)
        val edem=findViewById<TextView>(R.id.textView3)

        edfn.text="First Name :${fn.text.toString()}"
        edln.text="Last Name :${ln.text.toString()}"
        edem.text="Email :${em.text.toString()}"


    }
}
