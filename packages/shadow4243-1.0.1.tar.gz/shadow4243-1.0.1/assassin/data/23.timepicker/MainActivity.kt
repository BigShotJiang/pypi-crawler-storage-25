package com.example.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.util.SimpleTimeZone

class MainActivity : AppCompatActivity() {
    private lateinit var time:TextView
    private lateinit var simpleTimePiker:TimePicker
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        time=findViewById(R.id.time)
        simpleTimePiker=findViewById(R.id.simpleTimePicker)
        simpleTimePiker.setIs24HourView(false)
        simpleTimePiker.setOnTimeChangedListener { _, hourOfDay, minute ->
            Toast.makeText(this,"$hourOfDay $minute",Toast.LENGTH_SHORT).show()
            time.text="Time is::$hourOfDay:$minute"
        }
    }
}


