 package com.example.myapplication


 import android.support.v7.app.AppCompatActivity
 import android.os.Bundle
 import android.widget.Toast

 class SecondActivity : AppCompatActivity() {
     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_second)
         Toast.makeText(applicationContext,"We moved to second Activity", Toast.LENGTH_LONG)
     }
 }