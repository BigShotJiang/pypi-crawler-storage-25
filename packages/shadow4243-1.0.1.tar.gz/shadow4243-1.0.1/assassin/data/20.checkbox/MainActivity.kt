package com.example.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onSubmit(view: View) {
        val sb=StringBuilder("toppings_label")
        if(findViewById<CheckBox>(R.id.checkbox1_chocolate).isChecked){
            val toppings = StringBuilder()

            if (findViewById<CheckBox>(R.id.checkbox1_chocolate).isChecked) {
                toppings.append(getString(R.string.chocolate_syrup))
            }

            if (findViewById<CheckBox>(R.id.checkbox2_sprinkles).isChecked) {
                toppings.append(getString(R.string.sprinkles))
            }

            if (findViewById<CheckBox>(R.id.checkbox3_nuts).isChecked) {
                toppings.append(getString(R.string.crushed_nuts))
            }

            Toast.makeText(applicationContext, toppings.toString(), Toast.LENGTH_LONG).show()
            fun onSubmit(view: View) {}
        }

    }

}


