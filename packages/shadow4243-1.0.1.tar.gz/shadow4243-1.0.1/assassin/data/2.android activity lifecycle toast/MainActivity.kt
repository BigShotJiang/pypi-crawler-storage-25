package com.example.myapplicationq1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private val tag="Main Activity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val msg ="onCrete"
        Toast.makeText(applicationContext,"onCreate",Toast.LENGTH_LONG).show()
    }
    override fun onStart() {
        super.onStart()
        val msg="App Started:"
        Toast.makeText(applicationContext,"App Started:",Toast.LENGTH_LONG).show()
    }
    override fun onRestart() {
        super.onRestart()
        val msg = "App restarted:"
        Toast.makeText(applicationContext,"App restarted:",Toast.LENGTH_LONG).show()
    }
    override fun onDestroy() {
        super.onDestroy()
        val msg = "App Destroyed:"
        Toast.makeText(applicationContext,"App Destroyed:",Toast.LENGTH_LONG).show()
    }
    override fun onPause() {
        super.onPause()
        val msg = "App Paused:"
        Toast.makeText(applicationContext,"App Paused:",Toast.LENGTH_LONG).show()
    }

    override fun onStop() {
        super.onStop()
        val msg = "App Stopped:"
        Toast.makeText(applicationContext,"App Stopped:",Toast.LENGTH_LONG).show()
    }
}
