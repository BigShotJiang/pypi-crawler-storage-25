package com.example.myapplicationq1


import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    private val tag="Main Activity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val msg ="onCrete"
        Log.d(tag,msg)
    }

    override fun onStart() {
        super.onStart()
        val msg="App Started:"
        Log.d(tag,msg)
    }
    override fun onRestart() {
        super.onRestart()
        val msg = "App restarted:"
        Log.d(tag, msg)
    }
    override fun onDestroy() {
        super.onDestroy()
        val msg = "App Destroyed:"
        Log.d(tag, msg)
    }
    override fun onPause() {
        super.onPause()
        val msg = "App Paused:"
        Log.d(tag, msg)
    }

    override fun onStop() {
        super.onStop()
        val msg = "App Stopped:"
        Log.d(tag, msg)
    }
}
