package com.example.myapplicationcie2

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fade_in = findViewById<Button>(R.id.button3)
        val fade_out = findViewById<Button>(R.id.button4)
        val bounce = findViewById<Button>(R.id.button)
        val rotate = findViewById<Button>(R.id.button2)
        val slide_down = findViewById<Button>(R.id.button9)
        val slide_up = findViewById<Button>(R.id.button5)
        val zoom_in = findViewById<Button>(R.id.button10)
        val zoom_out = findViewById<Button>(R.id.button11)
        val cross_fade = findViewById<Button>(R.id.button6)
        val blink = findViewById<Button>(R.id.button7)
        val move = findViewById<Button>(R.id.button8)

        val imageView = findViewById<ImageView>(R.id.imageView)

        fade_in.setOnClickListener {
            imageView.visibility = View.VISIBLE
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        }

        fade_out.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_out))
            Handler(Looper.getMainLooper()).postDelayed({
                imageView.visibility = View.GONE
            }, 1000)
        }

        zoom_in.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.zoom_in))
        }

        zoom_out.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.zoom_out))
        }

        slide_down.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_down))
        }

        slide_up.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up))
        }

        bounce.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.bounce))
        }

        rotate.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate))
        }

        cross_fade.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.cross_fade))
        }

        blink.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.blink))
        }

        move.setOnClickListener {
            imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.move))
        }
    }
}
