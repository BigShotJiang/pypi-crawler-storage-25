package com.example.myapplicationq1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }

    fun onButtonClick(view: View) {
        val txthello =findViewById<TextView>(R.id.txtMsg)
        val editTxtName :EditText=findViewById(R.id.txtname)

        txthello.text=editTxtName.text.toString()


    }
}
