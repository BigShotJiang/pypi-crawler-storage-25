package com.example.alert
import android.content.DialogInterface
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.widget.Button
class MainActivity : AppCompatActivity() {
    lateinit var showDialogMessage : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        showDialogMessage = findViewById(R.id.buttonDialogMessage)
        showDialogMessage.setOnClickListener {
            showAlertDialog()
        }
    }

    fun showAlertDialog()
    {
        var alertDialog = AlertDialog.Builder(this@MainActivity)
        alertDialog.setTitle("Change")//sets the heading of the of dialog
            .setMessage("Do you want to change the text of the button?")
            .setIcon(R.drawable.ic_baseline_11mp_24)
            .setCancelable(false)
            .setNegativeButton("No", DialogInterface.OnClickListener {
                    dialogInterface, which ->
                dialogInterface.cancel()
            })
            .setPositiveButton("Yes", DialogInterface.OnClickListener {
                    dialogInterface, which ->

                showDialogMessage.text = "Alert Dialog"
            })
        alertDialog.create().show()
    }
}