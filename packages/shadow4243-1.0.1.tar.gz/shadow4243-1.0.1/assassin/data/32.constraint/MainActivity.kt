package com.example.constraint

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val num1 =
            findViewById<EditText>(R.id.num1)

        val num2 =
            findViewById<EditText>(R.id.num2)

        val button =
            findViewById<Button>(R.id.button)

        val result =
            findViewById<TextView>(R.id.textViewResult)

        button.setOnClickListener {

            val sum =
                num1.text.toString().toInt() +
                        num2.text.toString().toInt()

            result.text =
                "Result = $sum"
        }
    }
}