package com.example.linear

import android.support.v7.app.AppCompatActivity
import android.os.Bundle


import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val et1 = findViewById<EditText>(R.id.editText1)
        val et2 = findViewById<EditText>(R.id.editText2)

        val plusBtn = findViewById<Button>(R.id.plusButton)
        val minusBtn = findViewById<Button>(R.id.minusButton)
        val multiplyBtn = findViewById<Button>(R.id.multiplyButton)
        val divideBtn = findViewById<Button>(R.id.divideButton)

        plusBtn.setOnClickListener {
            calculate(et1, et2, "+")
        }

        minusBtn.setOnClickListener {
            calculate(et1, et2, "-")
        }

        multiplyBtn.setOnClickListener {
            calculate(et1, et2, "*")
        }

        divideBtn.setOnClickListener {
            calculate(et1, et2, "/")
        }
    }

    private fun calculate(et1: EditText, et2: EditText, operator: String) {

        val num1 = et1.text.toString().toDoubleOrNull()
        val num2 = et2.text.toString().toDoubleOrNull()

        if (num1 == null || num2 == null) {
            Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        val result = when (operator) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> {
                if (num2 == 0.0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                    return
                }
                num1 / num2
            }
            else -> 0.0
        }

        et1.setText(result.toString())
    }
}