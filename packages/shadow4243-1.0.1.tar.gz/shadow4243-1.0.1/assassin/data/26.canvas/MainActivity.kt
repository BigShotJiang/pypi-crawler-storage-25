package com.example.canvas

import android.graphics.*
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bitmap = Bitmap.createBitmap(800, 1200, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Paint objects
        val redPaint = Paint().apply { color = Color.RED }
        val bluePaint = Paint().apply { color = Color.BLUE }
        val greenPaint = Paint().apply { color = Color.GREEN }

        // 🔴 Red Squares
        canvas.drawRect(100f, 300f, 200f, 400f, redPaint)
        canvas.drawRect(350f, 500f, 450f, 600f, redPaint)

        // 🔵 Blue Circles
        canvas.drawCircle(400f, 350f, 60f, bluePaint)
        canvas.drawCircle(400f, 800f, 60f, bluePaint)

        // 🟢 Green Triangles
        val path1 = Path()
        path1.moveTo(550f, 150f)
        path1.lineTo(600f, 50f)
        path1.lineTo(650f, 150f)
        path1.close()
        canvas.drawPath(path1, greenPaint)

        val path2 = Path()
        path2.moveTo(700f, 150f)
        path2.lineTo(750f, 50f)
        path2.lineTo(800f, 150f)
        path2.close()
        canvas.drawPath(path2, greenPaint)

        // Set to ImageView
        val imageView = findViewById<ImageView>(R.id.imageV)
        imageView.setImageBitmap(bitmap)
    }
}