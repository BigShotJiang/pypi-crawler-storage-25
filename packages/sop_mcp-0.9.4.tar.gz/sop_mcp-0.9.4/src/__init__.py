"""SOP MCP Server package."""
