class SanQiLiuYi:
    sanqi = ['乙', '丙', '丁']
    liuyi = ['甲子戊', '甲戌己', '甲申庚', '甲午辛', '甲辰壬', '甲寅癸']

    def __init__(self, yangdun:bool):
        self.yangdun = yangdun
        self.sequence = self.liuyi + self.sanqi

    def qiyi(self):
        if self.yangdun:
            return self.sequence
        else:
            return self.sequence.reverse()


class XunShou_Formate_Error:
    pass


class DiPan:
    dipan_original = {'坎一宫': '', '坤二宫': '', '震三宫': '', '巽四宫': '', '中五宫': '', '乾六宫': '', '兑七宫': '', '艮八宫': '', '离九宫': ''}
    jiugong = ['坎一宫', '坤二宫', '震三宫', '巽四宫', '中五宫', '乾六宫', '兑七宫', '艮八宫', '离九宫']

    def __init__(self, yangdun:bool, jushu:int, shigan_xunshou:str):
        self.dipan = self.dipan_original
        self.yangdun = yangdun
        self.jushu = jushu
        self.xunshou = shigan_xunshou
        if self.xunshou not in SanQiLiuYi.liuyi:
           raise XunShou_Formate_Error


    def paipan(self):
        qiyi = SanQiLiuYi(yangdun=self.yangdun).qiyi()
        xunshou_index = qiyi.index(self.xunshou)
        qiyi_reformatted = []
        for i in range(0, 9):
            index = xunshou_index + i
            if index <= 9:
                position = index - 1
            else:
                position = index - 9 - 1
            qiyi_reformatted.append(qiyi[position])

        for i in range(0, 9):
            gongwei = self.jushu + i
            if gongwei <= 9:
                position = gongwei - 1
            else:
                position = gongwei - 9 - 1
            gong = self.jiugong[position]
            self.dipan[gong] += qiyi_reformatted[position]

        return self.dipan
