# Qimendunjia :  _0.1_

### 1.Features
This programme aimed at providing a adaptable Qimen Dunjia operating module, offering the liberty of your own insights, which is absolutely the original theme of traditional Chinese philosophy.

### 2. Origins

奇门遁甲是中国古代术数文化中的巅峰之作，被誉为"帝王之学"与"方术之王"，其历史可追溯至四千多年前的黄帝战蚩尤传说。作为一门集天文、历法、数学、哲学、军事于一体的综合性预测决策体系，奇门遁甲以洛书九宫为框架，融合阴阳五行、天干地支、八卦八门等符号系统，构建出精密的时空分析模型。

"奇"指乙、丙、丁三奇，代表日月星三光之精华；"门"为休、生、伤、杜、景、死、惊、开八门，象征人生万事的不同境遇与选择；"遁甲"则指将六甲（甲子、甲戌、甲申、甲午、甲辰、甲寅）隐匿于六仪之下，以避凶煞、趋吉利的核心机制。通过排布天盘（九星）、地盘（九宫）、人盘（八门）、神盘（八神）四层盘局，结合时辰与方位，奇门遁甲能够推演事物发展的趋势、判断吉凶成败、选择最佳行动时机。

本项目所使用的奇门遁甲起课方法来源于明代阴阳官池本理所著《箋元遁甲句觧烟波釣叟歌》。池本理作为明代术数官员，精通天文历法与术数之学，其所著此书是对《烟波钓叟歌》这一奇门遁甲经典歌诀的权威笺注与解读，系统阐述了奇门起局、排盘、断卦的规范方法，被后世视为奇门遁甲传承中的重要法本。

在古代，奇门遁甲主要应用于军事战争、国家大典、营造选址等重大决策，姜太公、张良、诸葛亮、刘伯温等历史名人均精于此道，留下诸多运筹帷幄的传奇。而在当代，这门古老的智慧已延伸至商业竞争、投资理财、健康管理、人际关系等现代生活领域，其核心精神在于顺应天时、地利、人和，追求"天人合一"的和谐境界，体现了中国传统文化中动态平衡、因势利导的哲学智慧。

---

Qimen Dunjia (奇门遁甲), revered as the "Imperial Art" and "King of Chinese Metaphysics," represents the pinnacle of China's ancient divinatory and strategic sciences. With legendary origins tracing back over four millennia to the Yellow Emperor's mythical battle against Chiyou, this sophisticated system synthesizes astronomy, calendrical science, mathematics, philosophy, and military strategy into a unified framework for prediction and decision-making.

At its core, Qimen Dunjia operates through the Luoshu Nine Palaces, integrating the theories of Yin-Yang, Five Elements, Heavenly Stems and Earthly Branches, and the Eight Trigrams to construct a precise spatial-temporal analytical model. The term "Qi" (奇) refers to the Three Miracles—Yi, Bing, and Ding—embodying the essence of the sun, moon, and stars; "Men" (门) denotes the Eight Gates (Rest, Life, Harm, Obstruction, Scene, Death, Shock, and Open), symbolizing the diverse circumstances and choices in human affairs; while "Dunjia" (遁甲), the "Concealed Armor," describes the mechanism of hiding the Six Jia (甲子, 甲戌, 甲申, 甲午, 甲辰, 甲寅) beneath the Six Yi to evade inauspicious forces and attract favorable energies.

By arranging four interlocking cosmic plates—the Heaven Plate (Nine Stars), Earth Plate (Nine Palaces), Human Plate (Eight Gates), and Spirit Plate (Eight Deities)—and correlating them with specific hours and directions, practitioners can calculate developmental trends, assess success probabilities, and identify optimal timing for action.

The divination methods employed in this project are derived from _Jian Yuan Dunjia Jujie Yanbo Diaosou Ge_ (《箋元遁甲句觧烟波釣叟歌》), authored by Chi Benli, a Yin-Yang official from the Ming Dynasty. As a distinguished calendrical expert, Chi Benli produced this authoritative commentary on the classic _Song of the Fisherman in Misty Waves_ (《烟波钓叟歌》), systematically elucidating the standardized procedures for chart construction, plate arrangement, and hexagram interpretation. This work remains a foundational text in the orthodox transmission of Qimen Dunjia.

Historically, this art guided military campaigns, state ceremonies, and architectural siting; legendary strategists such as Jiang Taigong, Zhang Liang, Zhuge Liang, and Liu Bowen all mastered Qimen Dunjia, leaving behind enduring tales of tactical brilliance. In contemporary practice, this ancient wisdom has evolved to address modern challenges: business competition, investment timing, health management, and interpersonal dynamics. Its fundamental philosophy emphasizes aligning human endeavors with heavenly timing, geographical advantage, and harmonious relations—the "Unity of Heaven and Humanity" (天人合一). Ultimately, Qimen Dunjia embodies the traditional Chinese worldview of dynamic equilibrium and strategic adaptation, teaching that wisdom lies not in conquering nature, but in discerning and flowing with the underlying patterns of the cosmos.
