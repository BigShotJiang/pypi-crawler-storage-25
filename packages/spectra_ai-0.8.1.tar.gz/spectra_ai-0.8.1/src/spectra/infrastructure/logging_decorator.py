"""Logging decorator — records model, tokens, duration, cost per LLM call.

Security: prompt/response content truncated to _MAX_LOG_CHARS and
API key patterns (sk-ant-*) are redacted before logging.
"""

from __future__ import annotations

import re
import time

from spectra.entities.models import CacheUsage
from spectra.use_cases.interfaces import LLMGateway, ProgressObserver

_MAX_LOG_CHARS = 500
_SECRET_RE = re.compile(
    r"sk-ant-[A-Za-z0-9_-]+"  # Anthropic API keys
    r"|sk-[A-Za-z0-9]{20,}"  # OpenAI-style keys
    r"|ghp_[A-Za-z0-9]{36}"  # GitHub personal access tokens
    r"|github_pat_[A-Za-z0-9_]+"  # GitHub fine-grained tokens
)


def _sanitize(text: str) -> str:
    """Truncate and redact secrets from text before logging.

    Args:
        text: Raw text that may contain API keys or tokens.

    Returns:
        Text with secrets replaced by ``[REDACTED]`` and truncated
        to ``_MAX_LOG_CHARS`` characters.
    """
    redacted = _SECRET_RE.sub("[REDACTED]", text)
    if len(redacted) > _MAX_LOG_CHARS:
        return redacted[:_MAX_LOG_CHARS] + "...[truncated]"
    return redacted


class LoggingDecorator:
    """Wraps an LLMGateway and logs call metadata to a ProgressObserver.

    Captures model name, wall-clock duration, and token count for
    each LLM call and forwards them to the observer.
    """

    def __init__(self, inner: LLMGateway, observer: ProgressObserver) -> None:
        """Initialize the logging wrapper.

        Args:
            inner: Underlying LLM gateway to wrap.
            observer: Progress observer to receive call metadata.
        """
        self._inner = inner
        self._observer = observer

    @property
    def last_usage(self) -> tuple[int, int]:
        """Propagate token usage from the inner gateway."""
        return getattr(self._inner, "last_usage", (0, 0))

    @property
    def last_cache_usage(self) -> CacheUsage:
        """Propagate prompt-cache token counters from the inner gateway."""
        return getattr(self._inner, "last_cache_usage", CacheUsage())

    async def analyze(
        self,
        system_prompt: str,
        user_prompt: str,
        model: str,
        max_tokens: int,
        effort: str | None = None,
        cache_breakpoint_index: int | None = None,
    ) -> str:
        start = time.monotonic()
        result = await self._inner.analyze(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model=model,
            max_tokens=max_tokens,
            effort=effort,
            cache_breakpoint_index=cache_breakpoint_index,
        )
        self._log_call(model, start)
        return result

    async def analyze_with_thinking(
        self,
        system_prompt: str,
        user_prompt: str,
        model: str,
        max_tokens: int,
        effort: str | None = None,
        task_budget_tokens: int | None = None,
        cache_breakpoint_index: int | None = None,
    ) -> str:
        start = time.monotonic()
        result = await self._inner.analyze_with_thinking(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model=model,
            max_tokens=max_tokens,
            effort=effort,
            task_budget_tokens=task_budget_tokens,
            cache_breakpoint_index=cache_breakpoint_index,
        )
        self._log_call(model, start)
        return result

    def _log_call(self, model: str, start: float) -> None:
        duration = time.monotonic() - start
        inp, out = self.last_usage
        total_tokens = inp + out
        self._observer.on_stage_complete(
            stage="llm_call",
            message=_sanitize(f"{model} | {duration:.1f}s | {total_tokens} tokens"),
        )
