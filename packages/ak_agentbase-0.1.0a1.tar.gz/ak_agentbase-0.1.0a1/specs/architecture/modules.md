# Modules

## v0.1-alpha Module Structure

```
agentbase/
  __init__.py          Public API: get_llm, init_tracing, load_config
  config.py            YAML config loading, validation, environment resolution
  models.py            Model alias resolution, LiteLLM client creation
  tracing.py           Langfuse setup, trace tagging, callback configuration
  registry.py          Agent registry loading, contract validation
  types.py             Shared type definitions (AgentMetadata, ModelConfig, etc.)
  exceptions.py        AgentBase-specific errors (clear, actionable messages)
```

## Module Responsibilities

### `config.py`
- Load `agentbase.yaml` from project root (or specified path)
- Validate config schema (required fields, valid model aliases, valid environments)
- Resolve environment-specific values (which model ID does alias `smart` map to in `dev`?)
- Provide typed access to config values

### `models.py`
- Accept an agent name, resolve its model alias to a provider-specific model ID
- Configure and return a LiteLLM completion client with appropriate parameters
- Attach Langfuse callbacks to the client for automatic tracing
- Handle the mapping: agent_name → model_alias → environment → model_id → LiteLLM client

### `tracing.py`
- Initialize Langfuse client with project-level settings
- Provide trace/span creation helpers that auto-populate contract metadata
- Define the callback interface that `models.py` attaches to LLM clients
- Keep the Langfuse-specific code isolated behind a clean interface (adapter boundary for future LangSmith support)

### `registry.py`
- Load agent registry YAML (list of agents with contract fields)
- Validate that every agent has all required contract fields
- Provide lookup: given an agent name, return its full metadata
- Raise clear errors for unregistered agents or missing fields

### `types.py`
- Dataclasses/TypedDicts for: `AgentMetadata`, `ModelConfig`, `EnvironmentConfig`, `TracingConfig`
- No business logic — just shape definitions

### `exceptions.py`
- `AgentNotRegisteredError` — agent name not in registry
- `ContractViolationError` — required field missing
- `ConfigValidationError` — malformed YAML or invalid values
- `ModelResolutionError` — alias doesn't resolve in current environment
- Each error message tells the developer exactly what to fix

## Public API Surface (v0.1-alpha)

```python
# Initialize tracing (call once at app startup)
agentbase.init_tracing(project="my_project", environment="dev")

# Get a configured LLM client for a registered agent
llm = agentbase.get_llm("quiz_generator")

# Load and access config programmatically (if needed)
config = agentbase.load_config()
```

That's it. Three functions. The rest is internal.

## Future Modules (Not in v0.1-alpha)

| Module | Release | Purpose |
|--------|---------|---------|
| `cli.py` | v0.1-beta | `agentbase init`, `agentbase validate` commands |
| `overrides.py` | v0.1-beta | Load and apply project/agent overrides |
| `utils.py` | v0.1-beta | Retry logic, structured output parsing, streaming helpers |
| `health.py` | v0.2 | Agent health checks and latency probes |
| `prompts.py` | v0.2 | Prompt version tracking and resolution |
