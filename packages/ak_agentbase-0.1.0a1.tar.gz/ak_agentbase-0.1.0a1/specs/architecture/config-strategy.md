# Config Strategy

## Config Files

AgentBase uses two YAML config files:

| File | Purpose | Who Writes It |
|------|---------|--------------|
| `agentbase.yaml` | Model aliases, environment mappings, tracing settings, general config | AgentBase package (defaults) + project (customization) |
| `agents.yaml` | Agent registry: list of agents with contract metadata | Project developer |

Both files live in the consuming project's root directory (or a configurable path).

## agentbase.yaml Structure

```yaml
project: brainboard

environments:
  dev:
    langfuse_enabled: true
    langfuse_public_key: ${LANGFUSE_PUBLIC_KEY}
    langfuse_secret_key: ${LANGFUSE_SECRET_KEY}
    langfuse_host: https://cloud.langfuse.com
  production:
    langfuse_enabled: true
    langfuse_public_key: ${LANGFUSE_PUBLIC_KEY}
    langfuse_secret_key: ${LANGFUSE_SECRET_KEY}
    langfuse_host: https://cloud.langfuse.com

models:
  fast:
    dev: gpt-4o-mini
    production: gpt-4o-mini
    default_params:
      temperature: 0.3
      max_tokens: 1024
  smart:
    dev: gpt-4o-mini
    production: claude-sonnet-4-20250514
    default_params:
      temperature: 0.5
      max_tokens: 4096
  creative:
    dev: gpt-4o-mini
    production: gpt-4o
    default_params:
      temperature: 0.8
      max_tokens: 4096

defaults:
  environment: dev
  model_alias: smart
```

## agents.yaml Structure

```yaml
agents:
  - agent_name: quiz_generator
    agent_version: "0.1.0"
    model_alias: fast
    prompt_ref: "inline"
    owner: shivam
    status: experimental
    description: "Generates quiz questions from learning content"

  - agent_name: content_summarizer
    agent_version: "0.1.0"
    model_alias: smart
    prompt_ref: "langfuse:summarizer-v2"
    owner: shivam
    status: experimental
    description: "Summarizes long-form content into key points"
```

## Config Resolution Order

1. Load `agentbase.yaml` from project root
2. Determine current environment (from `AGENTBASE_ENV` env var, or config default)
3. Resolve model aliases for current environment
4. Load `agents.yaml` and validate all agents against the contract
5. Merge any overrides from `agentbase.overrides.yaml` (v0.1-beta)

## Environment Variables

AgentBase reads from `.env` (or actual environment):

| Variable | Purpose |
|----------|---------|
| `AGENTBASE_ENV` | Current environment: `dev`, `staging`, `production` |
| `LANGFUSE_PUBLIC_KEY` | Langfuse public key |
| `LANGFUSE_SECRET_KEY` | Langfuse secret key |
| `LANGFUSE_HOST` | Langfuse instance URL |
| `OPENAI_API_KEY` | OpenAI API key (used by LiteLLM) |
| `ANTHROPIC_API_KEY` | Anthropic API key (used by LiteLLM) |

AgentBase validates that required env vars are set on startup. Missing keys produce clear errors, not cryptic LiteLLM failures.

## Config Validation Rules

- Every model alias must have a mapping for every defined environment
- Every agent must have all contract fields
- Model alias referenced by an agent must exist in the models config
- Environment names must be consistent between `agentbase.yaml` and agent overrides
- No duplicate agent names within a project
