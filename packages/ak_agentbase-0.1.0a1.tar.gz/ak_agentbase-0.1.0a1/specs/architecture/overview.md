# Architecture Overview

## Conceptual Layers

```
┌─────────────────────────────────────────────┐
│           Consuming Project                  │
│  (e.g., new AI product, later Writerverse)  │
│                                              │
│  from agentbase import get_llm, init_tracing │
│  llm = get_llm("quiz_generator")            │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│              AgentBase Package               │
│                                              │
│  ┌───────────┐ ┌────────────┐ ┌──────────┐ │
│  │  Config    │ │ Tracing    │ │ Registry │ │
│  │  (YAML +  │ │ (Langfuse  │ │ (YAML    │ │
│  │  LiteLLM) │ │  adapter)  │ │  catalog)│ │
│  └─────┬─────┘ └─────┬──────┘ └──────────┘ │
│        │              │                      │
│  ┌─────▼─────────────▼──────────────────┐   │
│  │       Contract Enforcement            │   │
│  │  (validates metadata on every call)   │   │
│  └───────────────────────────────────────┘   │
└──────────────────┬──────────────────────────┘
                   │
        ┌──────────┴──────────┐
        ▼                     ▼
┌──────────────┐    ┌──────────────┐
│ LLM Providers│    │   Langfuse   │
│ (via LiteLLM)│    │              │
└──────────────┘    └──────────────┘
```

## Key Design Decisions

1. **Config-driven, not code-driven.** Model settings, aliases, and environment mappings live in YAML. Projects read config; they don't define it in code.

2. **Thin wrapper over LiteLLM.** AgentBase does not build an LLM client. It configures LiteLLM and returns the client. If LiteLLM adds a feature, AgentBase gets it for free.

3. **Langfuse is the only tracing backend in v0.1.** The tracing adapter has a clean interface so a LangSmith adapter can be added later without changing the consumer API.

4. **Contract enforcement at the call boundary.** When `get_llm()` is called, AgentBase validates that the agent exists in the registry with all required metadata. This is the enforcement point.

5. **No singletons, no global state.** AgentBase is initialized explicitly. Projects call `init_tracing()` and `get_llm()` with clear parameters. No hidden global configuration.

## What Happens on a Typical LLM Call

1. Project calls `agentbase.get_llm("quiz_generator")`
2. AgentBase looks up `quiz_generator` in the agent registry
3. Validates all contract fields are present
4. Resolves `model_alias` (e.g., `smart`) to actual model ID using current environment (e.g., `gpt-4o` in production)
5. Returns a LiteLLM-configured client with Langfuse tracing callbacks attached
6. The Langfuse trace is automatically tagged with: project, agent_name, agent_version, model_alias, environment
7. Cost is captured and attributed via these tags
