# Versioning Strategy

## What Gets Versioned

| Artifact | How Versioned | Where It Lives | When Tracked |
|----------|--------------|----------------|-------------|
| Agents | `agent_version` field in registry | `agents.yaml` | v0.1-alpha |
| Prompts | `prompt_ref` field (git SHA, Langfuse version, or tag) | `agents.yaml` (pointer only) | v0.1-alpha (declared), v0.2 (actively tracked) |
| Models | Exact model ID in alias mapping | `agentbase.yaml` | v0.1-alpha |
| AgentBase package | `__version__` in code; semver from v0.2 | `agentbase/__init__.py` | v0.1-alpha |
| Config schema | Implicit via AgentBase version | Changes with AgentBase releases | v0.1-alpha |

## Versioning Philosophy by Release

| Release | Level | Description |
|---------|-------|-------------|
| v0.1-alpha | **Know what exists** | Every agent declares a version. Prompts have a reference. Models are explicit. That's enough. |
| v0.2 | **Track changes** | Prompt version changes are logged. Agent version history is queryable. |
| v0.3 | **Compare versions** | Run same input through two agent versions. Compare cost, latency, output. |
| v0.4+ | **Evaluate continuously** | Automated scoring, regression detection, CI/CD quality gates. |

## Version Format

Agent versions are free-form strings. We do not enforce semver for agents — the overhead isn't justified until we have automated version comparison (v0.3+).

Good version strings:
- `0.1.0` — classic semver if you prefer
- `2024-05-16-a` — date-based
- `initial` — honest label for first version

Bad version strings:
- Empty or missing — contract violation
- `latest` — meaningless; which latest?

## Prompt Ref Format

The `prompt_ref` field accepts:
- `inline` — prompt is hard-coded in the agent's source code
- `git:<sha>` — prompt is in a specific git commit
- `langfuse:<version>` — prompt is managed in Langfuse prompt management
- `file:<path>` — prompt is in a file at the given path

AgentBase does not manage prompts. It records where they are so they can be audited and traced.
