# Package Boundary

## Decision

AgentBase lives in a monorepo with the first consuming project but is a separately importable package from day one. See ADR-003 for full rationale.

## Monorepo Structure

```
AgentBase/                    # Repository root
  agentbase/                  # The AgentBase package
    __init__.py
    config.py
    models.py
    tracing.py
    registry.py
    types.py
    exceptions.py
    py.test or tests/
  
  <first-project>/            # The consuming project (added when project is defined)
    agentbase.yaml
    agents.yaml
    .env
    src/
    ...
  
  specs/                      # This specs folder
  pyproject.toml              # Package definition for agentbase
  README.md
```

## Import Rules

| Rule | Enforced By |
|------|------------|
| Consuming project imports AgentBase as `from agentbase import ...` | Convention + code review |
| AgentBase has zero imports from the consuming project | Test: AgentBase test suite runs without the consuming project present |
| AgentBase does not import LangChain or LangGraph | Dependency check in tests |
| AgentBase dependencies: `litellm`, `langfuse`, `pyyaml`, `pydantic` (or dataclasses) | `pyproject.toml` |

## Extraction Plan (v0.2)

At v0.2, AgentBase is extracted to its own repository and published as a pip package:

1. Move `agentbase/` to its own repo
2. Publish to private PyPI or install from git URL
3. Consuming projects add `agentbase` to their requirements
4. No code changes needed in consuming projects (import path stays the same)

This works because the import boundary is clean from day one. Extraction is a packaging change, not an architectural change.

## Why Not Extract Now

- The API will change rapidly during v0.1. Publishing a package with a volatile API creates version churn.
- Co-location enables faster iteration: change AgentBase and test in the consuming project in one commit.
- The discipline of a clean import boundary gives us all the benefits of separation without the overhead of publishing.
