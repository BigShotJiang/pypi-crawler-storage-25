# Integrations

## Integration Principle

> AgentBase configures, connects, and catalogs. It does not orchestrate, host, or replace.

## Integration Map

| Tool | How AgentBase Integrates | When |
|------|-------------------------|------|
| **LiteLLM** | Internal engine. AgentBase configures LiteLLM and returns clients to consumers. Projects never import or configure LiteLLM directly. | v0.1-alpha |
| **Langfuse** | Primary observability backend. AgentBase initializes the Langfuse client, attaches trace callbacks to LLM clients, and auto-tags traces with contract metadata. | v0.1-alpha |
| **LangChain** | AgentBase provides LLM clients that work with LangChain. Projects use LangChain for chains/agents. AgentBase doesn't touch chain logic. | v0.1-alpha (compatible, not coupled) |
| **LangGraph** | Same as LangChain. AgentBase provides configured LLMs. LangGraph handles workflow orchestration. | v0.1-alpha (compatible, not coupled) |
| **LangSmith** | Not integrated. Architecture has a clean tracing adapter interface. LangSmith adapter can be built without changing the consumer API. | v0.3 if needed |
| **OpenAI / Anthropic / Google** | Abstracted behind LiteLLM. Projects specify model aliases; AgentBase resolves to provider-specific IDs. Projects do not import provider SDKs for LLM calls. | v0.1-alpha |
| **promptfoo / ragas** | Not integrated. Eval framework integration is v0.4+ scope. | v0.4+ |
| **Vector databases** | Not in scope. Project-specific. May standardize a connection pattern if multiple projects need it. | TBD |

## The Adapter Boundary

Tracing is the integration most likely to change (Langfuse today, possibly LangSmith later). The `tracing.py` module defines a clean interface:

- `init_tracing(project, environment)` — sets up the backend
- `get_trace_callback()` — returns a callback compatible with LiteLLM's callback system
- `create_trace(metadata)` — creates a trace with contract fields

The Langfuse-specific implementation lives behind this interface. A future LangSmith adapter would implement the same interface. Consuming projects never import Langfuse directly — they call AgentBase's tracing functions.

## What "Compatible, Not Coupled" Means

AgentBase does not depend on LangChain or LangGraph. It does not import them. It returns standard LiteLLM clients and Langfuse callbacks that happen to work with LangChain/LangGraph because those tools also integrate with LiteLLM and Langfuse.

If a project doesn't use LangChain, AgentBase still works. If a project uses a custom agent framework, AgentBase still works. The integration is at the LLM client and tracing layer, not at the orchestration layer.
