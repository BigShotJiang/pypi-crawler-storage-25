# Observability Strategy

## Decision

AgentBase computes standardized trace metadata and hands it to the consuming product.
The product decides which observability backend to use and how to attach the metadata.
AgentBase does not wire, initialize, or depend on any tracing tool.

## What AgentBase Provides

Every call to `agentbase.resolve()` returns a `ResolvedAgent` that includes `trace_metadata`:

```python
resolved = agentbase.resolve("quiz_generator")
resolved.trace_metadata  # → dict with generation_name, trace_name, tags, metadata
```

The metadata structure:

| Field | Source | Example |
|-------|--------|---------|
| `generation_name` | agent_name | `quiz_generator` |
| `trace_name` | project/agent_name | `brainboard/quiz_generator` |
| `tags` | [project, environment, status] | `["brainboard", "dev", "experimental"]` |
| `metadata.project` | agentbase.yaml | `brainboard` |
| `metadata.environment` | AGENTBASE_ENV | `dev` |
| `metadata.agent_name` | agents.yaml | `quiz_generator` |
| `metadata.agent_version` | agents.yaml | `0.1.0` |
| `metadata.model_alias` | agents.yaml | `fast` |
| `metadata.model_id` | resolved from alias + env | `gpt-4o-mini` |
| `metadata.owner` | agents.yaml | `shivam` |

## How Products Use It

Each product attaches the metadata to whichever tracing tool they use.

**LangSmith (LangGraph projects):**
```python
resolved = agentbase.resolve("quiz_generator")
llm = ChatOpenAI(model=resolved.model_id).with_config({
    "run_name": resolved.trace_metadata["generation_name"],
    "tags": resolved.trace_metadata["tags"],
    "metadata": resolved.trace_metadata["metadata"],
})
```

**Langfuse (via LangChain callback):**
```python
from langfuse.callback import CallbackHandler

resolved = agentbase.resolve("quiz_generator")
handler = CallbackHandler(
    trace_name=resolved.trace_metadata["trace_name"],
    tags=resolved.trace_metadata["tags"],
    metadata=resolved.trace_metadata["metadata"],
)
llm = ChatOpenAI(model=resolved.model_id, callbacks=[handler])
```

**Direct API (no LangChain):**
```python
resolved = agentbase.resolve("quiz_generator")
response = openai.chat.completions.create(
    model=resolved.model_id,
    **resolved.default_params,
    # attach metadata however the API supports
)
```

## What This Enables

- **Consistent naming:** Every trace across all products uses the same `project/agent_name` convention
- **Consistent tagging:** Every trace is tagged with project, environment, and agent status
- **Cost attribution:** Filter your tracing tool by `agent_name` or `project` tag
- **Zero vendor lock-in:** Switch tracing backends without touching AgentBase

## What AgentBase Does NOT Build

- Tracing client initialization
- Callback wiring
- SDK dependencies on LangSmith, Langfuse, or any other tool
- Custom dashboards or log aggregation
- Alerting
