# Principles

These principles guide every design and implementation decision in AgentBase. When in doubt, refer here.

## Core Principles

**1. Foundation, not framework.**
AgentBase provides infrastructure primitives (config, tracing, registry). It does not dictate how agents are built, what classes they inherit from, or how workflows are structured. Projects bring their own orchestration (LangGraph), their own agent logic, and their own architecture.

**2. Integrate, don't replace.**
LangChain, LangGraph, Langfuse, LiteLLM are good tools. AgentBase configures and standardizes access to them. It does not compete with them or reimplement their features.

**3. Opinionated defaults, visible overrides.**
AgentBase makes strong choices out of the box (Langfuse for observability, model aliases for abstraction). Projects can override any default — but overrides must be declared with a reason and are always visible. Hidden drift is the enemy.

**4. Each release is independently useful.**
No release exists only to enable the next one. v0.1-alpha delivers real value. v0.1-beta delivers more. If we stopped at any version, the work already done would still be worth it.

**5. New-project-first.**
AgentBase is proven by powering a new product from day one, not by migrating existing ones. Migration happens later, from confidence, not ambition.

**6. Code quality over speed.**
The foundation must be clean, well-tested, and something we'd build every future product on. A rushed foundation becomes the next thing we need to replace.

**7. No fake precision.**
Future releases are directional, not detailed. Only the current release has implementation tasks. We do not estimate timelines. We sequence by dependency and outcome.

## Decision Heuristics

When evaluating whether to add something to AgentBase:

| Question | If Yes | If No |
|----------|--------|-------|
| Would 2+ projects need this? | Consider for AgentBase | Keep in the project |
| Does this reduce duplicated setup? | Strong candidate | Probably project-specific |
| Does this improve cross-project visibility? | Strong candidate | Probably project-specific |
| Does this force a specific agent architecture? | Don't build it | Might be appropriate |
| Can an existing tool handle this? | Integrate, don't rebuild | Consider building |
| Would removing this break the Agent Contract? | It's core | It might be optional |
