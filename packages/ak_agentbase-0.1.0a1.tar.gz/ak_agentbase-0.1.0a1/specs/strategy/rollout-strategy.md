# Rollout Strategy

## The Rule

> AgentBase does not start as a migration project. It starts as the foundation for a new AI product.

## Rollout Sequence

### Phase 1: Build and Prove (v0.1-alpha, v0.1-beta)

- Build AgentBase core alongside a brand-new AI project
- The new project uses AgentBase from its first commit
- AgentBase and the project live in the same monorepo (but with a clean import boundary)
- No existing projects are touched
- Goal: prove that AgentBase provides everything a real product needs

### Phase 2: Harden and Extract (v0.2)

- Stabilize based on production learnings from the first project
- Extract AgentBase into a standalone pip-installable package
- Write onboarding documentation based on real experience, not theory
- A second new project should be able to adopt AgentBase from the docs alone

### Phase 3: Expand (v0.3)

- Begin onboarding existing projects (Writerverse, Skill-Deck, Brainboard)
- One project at a time, incremental adoption (not big-bang migration)
- Build migration playbooks specific to each project
- Cross-project visibility becomes real (cost dashboards, unified registry)

### Phase 4: Mature (v0.4+)

- Add evaluation, governance, and optimization capabilities
- Only after the multi-project foundation is stable

## Why This Order

| Alternative | Why We Rejected It |
|-------------|-------------------|
| Start by migrating Writerverse | Migration complexity distracts from designing the right foundation |
| Build the full platform first, then find users | Platform without users = guesswork. Real project pressure surfaces real problems. |
| Support both Langfuse and LangSmith from day one | Doubles integration surface. Pick one, commit, adapt later. |
| Build AgentBase in isolation, then integrate | A foundation without a consumer is untested abstraction. Co-development ensures fitness. |

## What Existing Projects Should Do Now

Nothing. Writerverse, Skill-Deck, and Brainboard continue as-is. They are not blocked by AgentBase and should not change their setup until AgentBase has been proven (v0.3).
