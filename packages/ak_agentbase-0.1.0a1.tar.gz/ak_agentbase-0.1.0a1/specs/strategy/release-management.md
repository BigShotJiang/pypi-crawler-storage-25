# Release Management

## Release Naming

| Release | Meaning |
|---------|---------|
| v0.1-alpha | First usable foundation — structural core |
| v0.1-beta | Developer experience polish |
| v0.2 | Production-hardened, standalone package |
| v0.3 | Multi-project ready |
| v0.4+ | AI operating layer |

## Release Rules

1. **Only the current release has detailed tasks.** Future releases have scope and direction, not implementation plans.
2. **A release is done when its acceptance criteria are met.** Not when all tasks are checked off — criteria may be met with fewer tasks than planned, or may require tasks not originally planned.
3. **No release ships with known broken acceptance criteria.** Fix or explicitly descope before marking done.
4. **Scope can shrink, not grow, during a release.** New ideas go to backlog or the next release. The only exception is a blocking bug discovered during implementation.
5. **No timelines.** Releases are sequenced by dependency and readiness. Sprints are sequenced by outcome.

## What Triggers the Next Release

| Transition | Trigger |
|-----------|---------|
| v0.1-alpha → v0.1-beta | v0.1-alpha acceptance criteria met; first project can use AgentBase for real agent development |
| v0.1-beta → v0.2 | v0.1-beta acceptance criteria met; DX is good enough that no one bypasses AgentBase |
| v0.2 → v0.3 | v0.2 acceptance criteria met; AgentBase is a stable standalone package; second project has adopted successfully |
| v0.3 → v0.4+ | At least 2 existing projects migrated; cross-project visibility is working |

## Versioning

- AgentBase is not published as a pip package until v0.2 extraction.
- Before v0.2: version is tracked in `agentbase/__init__.py` as `__version__`.
- At v0.2: standard semantic versioning begins with the first published release.
