# Success Metrics

## By Release

| Release | Metric | Target |
|---------|--------|--------|
| **v0.1-alpha** | Time to first traced LLM call in a new project | < 2 hours |
| **v0.1-alpha** | Contract compliance | 100% of agents have all required metadata; zero untagged Langfuse traces |
| **v0.1-alpha** | Code quality | Zero AgentBase-caused bugs in consuming project after initial integration |
| **v0.1-beta** | Developer preference | First project's team prefers AgentBase over manual setup; no one bypasses it |
| **v0.1-beta** | Config validation | `agentbase validate` catches misconfigs before runtime |
| **v0.2** | Second project adoption | A new project adopts AgentBase without hand-holding from AgentBase maintainer |
| **v0.2** | Production stability | Consuming project runs in production with zero AgentBase-caused incidents |
| **v0.3** | Migration completeness | All active AI projects running on AgentBase |
| **v0.3** | Cost visibility | "What did AI cost this month, by project?" answered in under 5 minutes |
| **v0.3** | Model migration speed | < 1 hour to switch all projects to a new model |
| **v0.4+** | Quality assurance | Zero undetected agent regressions reaching production |

## Anti-Metrics (Signs of Failure)

- AgentBase becomes a bottleneck: projects wait on AgentBase changes to ship
- Developers bypass AgentBase because direct setup is easier
- Agent registry is always out of date
- AgentBase tries to do everything and does nothing well
- Existing projects regress after migration
- Override files are full of entries with reason "because we had to" (means defaults are wrong)
- Adding a new agent takes more effort with AgentBase than without it
