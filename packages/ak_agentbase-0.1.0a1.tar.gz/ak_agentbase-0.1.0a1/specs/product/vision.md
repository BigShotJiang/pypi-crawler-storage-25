# Product Vision

## One-Line Vision

AgentBase is the internal AI foundation that every product builds on — so no project ever reinvents model config, observability, or agent management again.

## The Problem

Every AI-powered product we build requires the same foundational setup:

- Model configuration and provider routing
- Observability (traces, cost, latency, errors)
- API key management
- Agent registration and metadata
- Prompt versioning
- Environment handling (dev/staging/production)

Today, each project solves this independently. This creates:

- **Duplicated boilerplate** across Writerverse, Skill-Deck, Brainboard, and every future project
- **Configuration drift** — inconsistent model choices, parameters, and key management
- **No cross-project visibility** — no one can answer "what agents do we run, what do they cost?"
- **Manual model migration** — deprecation notices trigger per-project fire drills
- **Tribal knowledge** — agent landscape lives in individual developers' heads, not in a system

## What AgentBase Is

A shared Python package that standardizes how all AI products:

- Configure and call LLMs (via model aliases + LiteLLM)
- Set up observability (via Langfuse)
- Register and describe their agents
- Tag costs and traces with project/agent/environment metadata
- Handle environment-specific settings

## What AgentBase Is Not

- Not a framework (no BaseAgent class, no forced inheritance)
- Not an orchestration engine (use LangGraph)
- Not a replacement for Langfuse, LangChain, or LiteLLM
- Not a web platform, dashboard, or UI
- Not an eval framework or prompt editor

## Long-Term Ambition

AgentBase becomes the internal AI operating layer: the single source of truth for how we build, run, observe, and improve all AI capabilities across all products. Starting a new AI project should feel like plugging into a power grid, not building a generator.
