# Roadmap

## Planning Hierarchy

```
Vision → Strategy → Roadmap → Releases → Sprints → Tasks → Code
```

This document covers the Roadmap and Releases layers. Sprints and tasks are in `sprints/` and `implementation/`.

## Release Overview

| Release | Focus | Detail Level |
|---------|-------|-------------|
| **v0.1-alpha** | First usable foundation | Detailed (sprint-level tasks exist) |
| **v0.1-beta** | Developer experience polish | Defined scope, no task breakdown yet |
| **v0.2** | Production hardening + standalone package | Directional |
| **v0.3** | Multi-project readiness | Directional |
| **v0.4+** | Evaluation, governance, AI operating layer | Vision only |

## v0.1-alpha — First Usable Foundation

The minimum AgentBase that a new project can import and get real value from.

**Delivers:** Model config, provider abstraction, Langfuse tracing, agent registry, environment handling, cost tagging, basic tests.

**Proven by:** One new project consuming AgentBase from day one.

See: `planning/v0.1-alpha.md` for full scope. `implementation/tasks-v0.1-alpha.md` for tasks.

## v0.1-beta — Developer Experience Polish

Makes AgentBase pleasant, not just functional.

**Delivers:** `agentbase init` CLI, shared utilities (retry, structured output), override system, config validation, .env validation, basic docs, agent lifecycle states, basic local dev config.

See: `planning/v0.1-beta.md`

## v0.2 — Production Hardening

Stabilize based on first project's production experience. Extract to standalone package.

**Delivers:** Prompt version tracking, model fallback chains, advanced local dev mode (cache/replay), health checks, alerting, standalone pip package, onboarding docs.

See: `planning/v0.2.md`

## v0.3 — Multi-Project Readiness

Enable existing projects to adopt AgentBase. Cross-project visibility.

**Delivers:** Migration playbooks, cross-project registry, unified cost views, model migration as config change, project override system, LangSmith adapter (if needed).

See: `planning/v0.3.md`

## v0.4+ — AI Operating Layer

AgentBase becomes the full internal AI control plane.

**Delivers:** Eval integration, version comparison, A/B testing, cost optimization, agent performance trends, governance/audit, internal catalog UI (if justified).

See: `planning/v0.4-plus.md`

## Sequencing Principle

Each release is independently useful. No release exists only to enable the next one. Later releases are planned only when earlier ones are proven.
