# Users and Pain Points

## Primary Users

| User | What They Need |
|------|---------------|
| AI/Backend Developer (starting a new project) | Working LLM setup, observability, and cost tagging in hours, not days |
| AI/Backend Developer (maintaining a project) | Shared config they can trust; model changes as config updates, not code changes |
| Project Lead / PM | Visibility into what agents exist, what they cost, how they perform |
| New team member | Standardized setup across all projects; can understand agent landscape quickly |

**Primary user for v0.1:** Developer building the first new project on AgentBase.

## Current Pain Points

| Pain Point | Impact |
|------------|--------|
| Every project reinvents LLM config, observability, key management | 2-5 days of boilerplate per new project; bug fixes not propagated |
| No central view of what agents exist | Knowledge is tribal; onboarding is slow |
| No cross-product cost visibility | Budget surprises; can't allocate or optimize spend |
| Observability is inconsistent or absent | Can't compare reliability, latency, or quality across projects |
| Model deprecation requires per-project manual updates | Fire drills multiply by number of projects |
| Prompt versioning is ad-hoc | Can't roll back, audit, or compare prompt changes |
| API key sprawl | Each project manages its own .env with overlapping keys; rotation is manual |

## Emerging Pain Points (Not Yet Urgent)

| Pain Point | When It Becomes Urgent |
|------------|----------------------|
| Compliance: "What models and data flows do we use?" | When legal, customers, or partners ask |
| Agent reuse across products is impossible | When the third product needs the same pattern |
| No shared evaluation methodology | When quality regressions reach production unnoticed |
| Every new hire faces a different setup per project | When team scales beyond current size |
