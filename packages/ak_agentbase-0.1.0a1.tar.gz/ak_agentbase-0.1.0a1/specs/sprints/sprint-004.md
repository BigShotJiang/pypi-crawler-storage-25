# Sprint 004 — Configuration Validation & Observability Polish (v0.1-beta)

## Goal

Make integration friction-free and observability transparent. By end of sprint: config validation catches errors early, LangSmith dashboards are one-click ready, and cost optimization is documented.

## Status

**v0.1-alpha complete.** Starting v0.1-beta DX improvements.

## Scope

| Task | Type | Effort | Fit |
|------|------|--------|-----|
| Implement `agentbase validate` CLI | Tooling | 1–2h | v0.1-beta (config validation) |
| Create LangSmith dashboard templates | Documentation | 1–2h | v0.1-beta (observability) |
| Write cost optimization guide | Documentation | 1–2h | v0.1-beta (DX/education) |
| *(Later)* Implement `agentbase init` CLI scaffolding | Tooling | 2–3h | v0.1-beta (for Sprint 005) |

## Acceptance Criteria

### Task 1: Config Validator (`agentbase validate`)
- [ ] CLI command: `agentbase validate [agentbase.yaml] [agents.yaml]`
- [ ] Catches: missing contract fields, unresolved model aliases, missing env vars
- [ ] Clear error messages (not stack traces)
- [ ] Returns exit code 0 (valid) or 1 (invalid)
- [ ] Tested with both valid and invalid configs

### Task 2: LangSmith Dashboard Templates
- [ ] Document how to set up 4 dashboard cards:
  - Latency by agent (line chart)
  - Call volume by environment (stacked bar)
  - Error rate by agent (bar chart)
  - Cost breakdown by model (pie chart)
- [ ] Provide LangSmith query examples for each
- [ ] Include screenshot or step-by-step guide
- [ ] In `docs/MONITORING.md` (already created, expand "Dashboards" section)

### Task 3: Cost Optimization Guide
- [ ] Document: how to identify expensive agents
- [ ] Document: when to switch agents to cheaper models
- [ ] Document: ROI calculation per agent
- [ ] Document: A/B testing model changes
- [ ] In `docs/MONITORING.md` (add section "Cost Optimization")

## Out of Scope (This Sprint)

- `agentbase init` CLI (Sprint 005)
- Shared utilities (retry, structured output)
- Override system
- Local dev mode
- Migration tooling

## Dependencies

- v0.1-alpha complete (✓)
- shivam-portfolio validated (✓)
- LangSmith tracing working (✓)

## Execution Order

1. **Task 1** (config validator) — Unblocks future projects to validate faster
2. **Task 2** (dashboard templates) — Observability setup for Writerverse
3. **Task 3** (cost guide) — Documentation for ongoing cost management
4. **Task 4** (CLI scaffolding) — Deferred to Sprint 005; higher effort

## Success Metrics

✓ `agentbase validate` catches all config errors with clear messages
✓ New project can set up LangSmith dashboard in < 5 minutes
✓ Cost optimization guide is clear and actionable
✓ Portfolio integration remains working (no regressions)
