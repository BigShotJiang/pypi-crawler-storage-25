# Sprint 003 — First Consuming Project Integration

## Goal

Prove AgentBase works by integrating it into the first real AI project. By the end of this sprint, a new project has at least one working agent running through AgentBase with full Langfuse tracing and cost tagging.

## Scope

| Task | Area |
|------|------|
| Set up the consuming project directory in the monorepo | Project setup |
| Create `agentbase.yaml` for the project with real model aliases | Project config |
| Create `agents.yaml` with the project's first 1-2 agents | Project config |
| Set up `.env` with Langfuse and LLM provider keys | Project config |
| Implement at least one agent using `agentbase.get_llm()` | Project code |
| Verify Langfuse traces appear with correct metadata tags | Integration test |
| Verify cost attribution works in Langfuse dashboard | Manual verification |
| Fix any AgentBase issues discovered during integration | AgentBase code |
| Document any friction points or missing features | `planning/open-questions.md` or `planning/backlog.md` |

## Acceptance Criteria

1. The consuming project imports AgentBase as `from agentbase import get_llm, init_tracing` — no other AgentBase imports needed
2. At least one agent makes LLM calls through AgentBase and receives valid responses
3. All LLM calls appear in Langfuse with correct project, agent_name, environment, model_alias tags
4. Cost per agent is visible in Langfuse
5. AgentBase test suite still passes independently (no coupling introduced)
6. Any issues discovered are logged as backlog items or open questions, not hacked around

## Out of Scope

- Building the full consuming project (just enough to prove AgentBase works)
- CLI scaffolding (project is set up manually)
- Shared utilities usage
- Override system
- Local dev mode
- Production deployment (dev environment is sufficient)

## Dependencies

- Sprint 001 and Sprint 002 complete
- First project has been defined (at least: name, 1-2 initial agents, model choices)
- Langfuse instance accessible
- LLM provider API keys available

## What We Learn From This Sprint

This sprint is as much about learning as building:

- Does the config schema work in practice, or does it need changes?
- Is the public API (`get_llm`, `init_tracing`) sufficient, or are functions missing?
- What friction did the developer encounter?
- What did they wish existed in AgentBase?
- Are the error messages actually helpful?

Findings feed directly into v0.1-beta scope decisions.
