# Sprint 002 — Observability and Cost Tagging

## Goal

Wire Langfuse tracing into AgentBase so every LLM call is automatically traced with contract metadata and cost attribution. By the end of this sprint, calling `get_llm()` produces traced, tagged, cost-attributed LLM calls in Langfuse.

## Scope

| Task | Module |
|------|--------|
| Implement Langfuse initialization (`init_tracing()`) | `tracing.py` |
| Define the tracing adapter interface (protocol) | `tracing.py` |
| Implement Langfuse callback that auto-tags traces with contract metadata | `tracing.py` |
| Wire tracing callbacks into `get_llm()` return value | `models.py` |
| Add environment variable validation for Langfuse keys | `config.py` |
| Add tracing config section to `agentbase.yaml` | `config.py` |
| Expose `init_tracing` and `get_llm` from `__init__.py` public API | `__init__.py` |
| Write integration test: LLM call → Langfuse trace with correct tags | `tests/` |
| Write unit tests for tracing setup and callback behavior | `tests/` |

## Acceptance Criteria

1. `init_tracing(project="x", environment="dev")` initializes Langfuse without errors
2. Every LLM call via `get_llm()` creates a Langfuse trace with: project, environment, agent_name, agent_version, model_alias, resolved model_id
3. Cost is captured in Langfuse (Langfuse calculates this from model + tokens)
4. Missing Langfuse env vars produce a clear startup error (not a cryptic Langfuse SDK error)
5. Tracing adapter interface is defined as a Protocol — Langfuse implementation is the only implementation
6. Tracing can be disabled via config (for testing or environments without Langfuse)
7. All tests pass (including Sprint 001 tests)

## Out of Scope

- LangSmith adapter
- Custom dashboards or trace querying
- Alerting
- Health checks
- Advanced trace features (spans, nested traces for multi-agent workflows)

## Dependencies

- Sprint 001 complete (config, registry, model resolution)
- Langfuse account/instance available for integration testing

## Key Decisions to Make During This Sprint

- How to handle tracing in test environments (disable? mock? local Langfuse?)
- Whether `init_tracing()` should be mandatory or optional (recommended: mandatory with a disable flag)
