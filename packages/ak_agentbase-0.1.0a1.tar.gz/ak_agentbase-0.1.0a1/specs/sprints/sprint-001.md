# Sprint 001 — Config and Model Layer

## Goal

Build the smallest useful AgentBase: load config, resolve model aliases, and return a working LiteLLM client. By the end of this sprint, a consuming project can call `get_llm("agent_name")` and get a configured LLM.

## Scope

| Task | Module |
|------|--------|
| Define `agentbase.yaml` config schema | `config.py` |
| Define `agents.yaml` registry schema | `registry.py` |
| Implement config loading and validation | `config.py` |
| Implement agent registry loading and contract validation | `registry.py` |
| Implement model alias resolution per environment | `models.py` |
| Implement `get_llm()` with LiteLLM client creation | `models.py` |
| Define type structures | `types.py` |
| Define custom exceptions | `exceptions.py` |
| Set up package structure (`pyproject.toml`, `__init__.py`) | root |
| Write unit tests for config, registry, and model resolution | `tests/` |

## Acceptance Criteria

1. `agentbase.yaml` and `agents.yaml` can be loaded and validated
2. Invalid config produces `ConfigValidationError` with specific field information
3. Unregistered agent name produces `AgentNotRegisteredError`
4. Missing contract fields produce `ContractViolationError` with the missing field name
5. `get_llm("agent_name")` returns a LiteLLM client configured with the correct model for the current environment
6. Model alias `smart` resolves to different models in `dev` vs `production`
7. All tests pass
8. AgentBase has no imports from any consuming project

## Out of Scope

- Langfuse tracing (Sprint 002)
- .env loading or validation
- CLI commands
- Shared utilities
- Override system
- Any consuming project code

## Dependencies

- None. This is the starting sprint.

## Key Decisions to Make During This Sprint

- Final YAML schema for `agentbase.yaml` and `agents.yaml` (draft in `architecture/config-strategy.md`)
- Whether to use Pydantic or dataclasses for type definitions
- Sync vs async default for `get_llm()` return value
