# Scope and Boundaries

## What AgentBase Does

| Capability | Description |
|-----------|-------------|
| Model configuration | YAML-defined model registry with aliases, parameters, and per-environment resolution |
| Provider abstraction | Single `get_llm()` call that returns a ready-to-use client via LiteLLM |
| Observability setup | Pre-configured Langfuse tracing with automatic metadata tagging |
| Agent registry | Declarative YAML catalog of all agents with contract metadata |
| Cost tagging | Automatic project/agent/environment tags on every LLM call |
| Environment handling | Dev/staging/production profiles with different model mappings |
| Contract enforcement | Startup validation that all agents declare required metadata |

## What AgentBase Does NOT Do

| Not This | Why | Alternative |
|----------|-----|-------------|
| Agent orchestration | LangGraph handles multi-step workflows | Use LangGraph directly |
| Custom tracing backend | Langfuse is mature and sufficient | Use Langfuse |
| Prompt editing or management UI | Low ROI; prompts live in code or Langfuse | Use Langfuse prompt management or git |
| Model hosting or serving | We use hosted APIs | OpenAI, Anthropic APIs directly |
| Web dashboard | Langfuse provides dashboards | Use Langfuse UI |
| Evaluation framework | Domain-specific; premature to generalize | Build per-project first (v0.4+ reconsiders) |
| BaseAgent class hierarchy | Framework trap; forces conformity | Agents are any class/function |
| LangSmith support (v0.1) | One observability backend, done well | Adapter boundary exists for later |
| Migration tooling (v0.1) | Prove foundation first | v0.3 scope |
| Approval workflows | Bureaucracy at our scale; code review suffices | Standard PR review |

## The "Two-Project Rule"

Before adding a capability to AgentBase, it should be needed by at least two projects. If only one project needs it, it stays in that project. The exception is v0.1-alpha, where we're building for the anticipated needs of the first project.

## Scope Creep Signals

If you find yourself doing any of these, stop and check the specs:

- Adding a class that agents must inherit from
- Building UI of any kind
- Implementing workflow orchestration logic
- Creating a database or persistent backend
- Building features that only one project would use
- Adding LangSmith support before v0.3
- Writing migration scripts before v0.3
- Building prompt storage (as opposed to prompt reference tracking)
