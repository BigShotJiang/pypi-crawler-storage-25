# AgentBase Contract

The Agent Contract is the minimum metadata every AgentBase-powered agent must declare. It is what makes observability, cost tracking, and cross-project visibility work.

## Required Fields

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `project` | string | The product this agent belongs to | `brainboard` |
| `environment` | string | Where the agent is running | `dev`, `staging`, `production` |
| `agent_name` | string | Unique name within its project | `quiz_generator` |
| `agent_version` | string | Current version of this agent | `0.1.0`, `2024-05-16-a` |
| `model_alias` | string | Logical model name from AgentBase config | `fast`, `smart`, `creative` |
| `prompt_ref` | string | Pointer to the prompt version in use | `git:abc1234`, `langfuse:v3`, `inline` |
| `owner` | string | Person or team responsible | `shivam`, `content-team` |
| `status` | enum | Agent lifecycle state | `experimental`, `active`, `deprecated` |

## The model_alias Pattern

Agents reference logical aliases, not provider-specific model IDs.

```yaml
# In agentbase config
models:
  fast:
    dev: gpt-4o-mini
    production: gpt-4o-mini
  smart:
    dev: gpt-4o-mini
    production: claude-sonnet-4-20250514
  creative:
    dev: gpt-4o-mini
    production: gpt-4o
```

Switching the production model for all "smart" agents is a one-line config change.

## Enforcement

- **v0.1-alpha:** AgentBase validates required fields at startup. Missing fields produce a clear error with the field name and agent name. No silent passes.
- **Runtime:** Every LLM call is tagged in Langfuse with contract fields automatically. Developers do not manually add trace metadata.
- **Registry:** Every agent is declared in a YAML registry file with all contract fields. The registry is the source of truth.

## What the Contract Does NOT Dictate

- How agents are implemented (any class, any pattern)
- What framework agents use (LangChain, LangGraph, raw API calls)
- How prompts are structured or stored
- How workflows are organized
- How agents communicate with each other

The contract requires identification and accountability. It does not require conformity.
