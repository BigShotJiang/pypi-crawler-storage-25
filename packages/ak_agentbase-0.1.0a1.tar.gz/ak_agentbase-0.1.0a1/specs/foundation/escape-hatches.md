# Escape Hatches

## Principle

> AgentBase is opinionated by default. But it is not a cage.

Projects will sometimes need to deviate from shared defaults. This is legitimate, not a workaround. The requirement is that deviations are visible and auditable.

## How Overrides Work

| Rule | Detail |
|------|--------|
| Any shared default can be overridden | At the project level or per-agent level |
| Every override requires a `reason` | A string explaining why this agent deviates |
| Overrides are visible in config queries | Querying an agent's effective config shows both the default and the override |
| Overrides do not propagate | An override in Project A has no effect on Project B |
| Overrides are not second-class | No warnings, nag messages, or "you're doing it wrong" signals |

## Override Format

```yaml
# agentbase.overrides.yaml
overrides:
  - agent: quiz_generator
    field: model_alias
    default: smart
    override: fast
    reason: "Quiz generation is latency-sensitive; quality tradeoff is acceptable"

  - agent: essay_reviewer
    field: temperature
    default: 0.3
    override: 0.7
    reason: "Needs varied feedback phrasing to avoid repetitive reviews"
```

## What This Prevents

- **Hidden drift:** Changes are declared in config, not buried in .env files or code
- **Forced conformity:** Without escape hatches, projects fork AgentBase or bypass it entirely
- **Override archaeology:** Six months later, someone can read the override file and understand every deviation

## When to Override vs. When to Change the Default

- If one agent needs a different setting: override
- If most agents need a different setting: change the default and remove the overrides
- If the override file grows large with similar reasons: the default is probably wrong

## Implementation Phase

- **v0.1-alpha:** No override system. Defaults only. (Scope is one project; overrides add complexity before we know what needs overriding.)
- **v0.1-beta:** Override system ships. The first project's real needs inform the design.
- **v0.2+:** Override visibility in config queries and docs.
