# AgentBase Specs

This folder contains the product, strategy, architecture, and implementation specs for AgentBase.

## Purpose

Specs exist to prevent jumping from idea to code. They ensure that Claude Code (and any engineer) works from a clear plan, not from guesses.

## Structure

```
specs/
  product/          Product vision, users, roadmap, success metrics
  strategy/         Principles, rollout approach, release management
  foundation/       What AgentBase is (and isn't): contract, scope, escape hatches
  architecture/     Technical design: modules, integrations, config, observability
  decisions/        Architecture Decision Records (ADRs) for key choices
  planning/         Release plans: v0.1-alpha through v0.4+, backlog, open questions
  sprints/          Sprint-level breakdown with goals, tasks, acceptance criteria
  implementation/   Detailed tasks, testing strategy, acceptance criteria, Claude workflow
  migration/        Future notes on onboarding existing projects (not active yet)
  commands/         Proposed Claude Code command patterns (not implemented yet)
```

## How to Use

1. **Before building:** Read `product/vision.md`, the current release plan in `planning/`, and relevant ADRs in `decisions/`.
2. **While building:** Follow tasks in `implementation/tasks-v0.1-alpha.md`. Check acceptance criteria before marking done.
3. **When deciding:** Check `foundation/scope-and-boundaries.md` and `strategy/principles.md` before adding scope.
4. **When something changes:** Update the relevant spec. Specs are living documents, not artifacts.

## Rules

- Specs do not contain timelines or time estimates.
- Only the current release has detailed implementation tasks.
- Future releases are directional, not precise.
- If a spec contradicts the code, one of them is wrong. Fix it.
