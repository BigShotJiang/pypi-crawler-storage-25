# ADR-001: Prove AgentBase Through a New Project First

## Status

Accepted

## Context

AgentBase could be introduced by migrating existing projects (Writerverse, Skill-Deck, Brainboard) or by powering a brand-new project from day one.

## Decision

AgentBase will be proven through a new AI project that uses it from its first commit. Existing projects will not be migrated until AgentBase has been battle-tested in production (v0.3).

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Start by migrating Writerverse | Migration complexity distracts from designing the right foundation. Risk of breaking a working product to test an unproven library. |
| Build AgentBase in isolation, then find consumers | A foundation without real consumer pressure produces untested abstractions. |
| Build a throwaway test project | Toy projects don't surface real problems. AgentBase needs production stakes. |

## Consequences

- **Positive:** Clean environment to test the foundation. No legacy constraints. Design informed by real needs, not migration compromises.
- **Positive:** Existing projects are not at risk during AgentBase development.
- **Negative:** Delays the benefit to existing projects. They continue with duplicated setup until v0.3.
- **Negative:** Requires identifying/defining a suitable new project before v0.1-alpha work begins.
- **Constraint:** The first project must be a real product (2-4 agents, 2+ models, real users, shippable in reasonable scope).
