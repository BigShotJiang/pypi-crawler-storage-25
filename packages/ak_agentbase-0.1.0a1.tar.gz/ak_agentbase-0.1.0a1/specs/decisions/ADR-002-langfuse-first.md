# ADR-002: Standardize on Langfuse; No LangSmith in v0.1

## Status

Accepted

## Context

Multiple observability tools exist for LLM applications: Langfuse, LangSmith, Helicone, others. Supporting multiple tools in v0.1 would double the integration surface. Different projects currently use different tools (or none), creating fragmented visibility.

## Decision

Langfuse is the only supported observability backend through v0.2. The tracing module has a clean adapter interface so a LangSmith adapter can be built later without changing the consumer API. LangSmith support is deferred to v0.3, and only if a migrating project requires it.

## Why Langfuse

- Open-source, self-hostable — no vendor lock-in
- Cheaper at scale than LangSmith
- Good built-in prompt management (useful for future versions)
- Doesn't couple us to the LangChain ecosystem
- Has native LiteLLM integration

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Support both Langfuse and LangSmith from day one | Doubles integration effort. Two dashboards means no unified view. Fragmented observability is the problem we're solving. |
| LangSmith only | Vendor lock-in. Tied to LangChain ecosystem. More expensive. |
| Build custom tracing | Massive scope creep. Existing tools are good. |
| No observability in v0.1 | Observability is the second-most-valuable feature after model config. Deferring it defeats the purpose. |

## Consequences

- **Positive:** One integration to build and maintain. One dashboard for all visibility. Faster v0.1 delivery.
- **Positive:** Clean adapter boundary means switching costs are localized to one module.
- **Negative:** If a migrating project in v0.3 is deeply invested in LangSmith, we'll need to build the adapter then.
- **Commitment:** All projects on AgentBase use Langfuse. This is a standardization choice, not a technical limitation.
