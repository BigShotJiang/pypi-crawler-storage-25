# Architecture Decision Records

ADRs document key decisions that shape AgentBase. Each record captures what was decided, why, what alternatives were considered, and what consequences follow.

## Index

| ADR | Decision | Status |
|-----|----------|--------|
| [ADR-001](ADR-001-new-project-first.md) | Prove AgentBase through a new project, not migration | Accepted |
| [ADR-002](ADR-002-langfuse-first.md) | Standardize on Langfuse; no LangSmith in v0.1 | Accepted |
| [ADR-003](ADR-003-package-boundary.md) | Monorepo with clean import boundary; extract at v0.2 | Accepted |
| [ADR-004](ADR-004-foundation-not-framework.md) | AgentBase is a foundation, not a framework | Accepted |
| [ADR-005](ADR-005-no-forced-base-agent.md) | No forced BaseAgent class hierarchy | Accepted |

## When to Write a New ADR

- When a decision affects multiple modules or the overall architecture
- When a decision is non-obvious and someone might reasonably choose differently
- When reversing a decision later would be costly

## ADR Format

Each ADR follows: Context → Decision → Alternatives Considered → Consequences.
