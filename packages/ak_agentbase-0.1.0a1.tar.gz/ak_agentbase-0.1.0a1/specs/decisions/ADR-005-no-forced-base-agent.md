# ADR-005: No Forced BaseAgent Class Hierarchy

## Status

Accepted

## Context

It's tempting to create an abstract `BaseAgent` class that all agents must inherit from. This would give AgentBase control over initialization, execution, and cleanup. Many internal platform libraries take this approach.

## Decision

AgentBase does not provide or require a `BaseAgent` class. Agents can be functions, classes, LangGraph graphs, LangChain chains, or any other structure. AgentBase interacts with agents through configuration (registry YAML) and infrastructure (LLM clients, tracing), not through inheritance.

## Why This Matters

Real agents are diverse:

- A simple classifier is a single function call
- A content generator is a stateful class with multiple steps
- A research agent is a LangGraph workflow with branching
- A conversational agent maintains session state

Forcing these into one class hierarchy produces:
- Empty method implementations (`pass` in hooks that don't apply)
- Adapter classes to wrap third-party patterns (LangGraph → BaseAgent)
- Developers working around the base class instead of with it
- A coupling point that makes AgentBase changes break all agents

## What We Provide Instead

| Instead of... | We provide... |
|---------------|--------------|
| `BaseAgent.run()` | `get_llm()` — configured client the agent uses however it wants |
| `BaseAgent.__init__()` | Agent registry YAML — metadata about the agent, external to its code |
| `BaseAgent.on_error()` | Langfuse error tracing — automatic, no agent code needed |
| `BaseAgent.get_config()` | `load_config()` — typed config access if the agent needs it |

## Consequences

- **Positive:** Any agent pattern works with AgentBase. Zero refactoring to adopt.
- **Positive:** LangGraph, LangChain, and raw API agents are all first-class citizens.
- **Negative:** We can't enforce agent behavior patterns (e.g., mandatory error handling). We accept this: observability tells us when things fail; enforcement isn't our job.
