# ADR-004: AgentBase Is a Foundation, Not a Framework

## Status

Accepted

## Context

Internal infrastructure libraries tend to grow into frameworks that dictate how consuming code is structured. This creates coupling, resistance to adoption, and maintenance burden.

## Decision

AgentBase provides infrastructure primitives (config, tracing, registry, model abstraction). It does not dictate how agents are built, what classes they inherit from, how workflows are structured, or what orchestration patterns are used.

## What This Means in Practice

| Foundation (We Do This) | Framework (We Don't Do This) |
|------------------------|----------------------------|
| Provide `get_llm()` that returns a configured client | Require agents to inherit from `BaseAgent` |
| Auto-tag Langfuse traces with contract metadata | Require agents to call specific lifecycle hooks |
| Validate agent registry on startup | Require agents to register themselves via decorators |
| Provide retry utilities as opt-in imports | Wrap all LLM calls in a mandatory retry layer |
| Define a config format for model aliases | Require a specific project directory structure |

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Full agent framework with BaseAgent | Different agents have fundamentally different shapes (stateless function, stateful class, LangGraph workflow, multi-step chain). Forcing them into one hierarchy creates awkward abstractions. |
| Decorator-based registration | Couples agent code to AgentBase at the source level. YAML registry keeps registration external to agent implementation. |
| Mandatory agent lifecycle hooks (init/run/cleanup) | Over-specifies agent behavior. Some agents are one-shot functions. Some are long-running. A single lifecycle model doesn't fit. |

## Consequences

- **Positive:** Easy adoption — projects add config and tracing without restructuring their code.
- **Positive:** No resistance from developers who have their own preferred patterns.
- **Positive:** AgentBase doesn't break when agent implementations change.
- **Negative:** Less control over agent behavior. We can see what agents do (observability) but can't enforce how they do it.
- **Acceptable tradeoff:** Visibility is more valuable than control at our stage.
