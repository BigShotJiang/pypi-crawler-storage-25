# ADR-003: Monorepo with Clean Import Boundary; Extract at v0.2

## Status

Accepted

## Context

AgentBase needs to be consumed by multiple projects. It could be a standalone package from day one, or it could start in a monorepo with the first consuming project and be extracted later.

## Decision

AgentBase starts as a directory in the same repository as the first consuming project. However, it is a separately importable package from day one — the consuming project imports it as `from agentbase import ...` with zero reverse dependencies. Extraction to a standalone repo + pip package happens at v0.2.

## Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Standalone package from day one | Premature. The API will change rapidly in v0.1. Publishing a volatile package creates version churn and pip install friction during early development. |
| Monorepo forever | Doesn't scale. The second project shouldn't need to clone the first project's repo to use AgentBase. |
| Monorepo without import discipline | Creates hidden coupling. If AgentBase accidentally imports from the consuming project, extraction becomes a refactoring project instead of a packaging change. |

## Consequences

- **Positive:** Fast iteration in v0.1 — change AgentBase and test in the consumer in one commit.
- **Positive:** Clean boundary from day one means extraction at v0.2 is mechanical.
- **Negative:** Discipline required to maintain the import boundary. Tests should verify AgentBase doesn't depend on the consumer.
- **Rule:** AgentBase's test suite must pass without the consuming project present.
