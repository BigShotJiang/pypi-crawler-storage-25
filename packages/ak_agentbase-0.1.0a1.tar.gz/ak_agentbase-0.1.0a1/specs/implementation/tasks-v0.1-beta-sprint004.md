# Implementation Tasks — v0.1-beta Sprint 004

Configuration Validation & Observability Polish

---

## Sprint 004 Tasks

### TASK-018: Implement `agentbase validate` CLI

**Objective:** Create a CLI command to validate config files before runtime.

**Files:** `agentbase/cli.py`, `agentbase/__main__.py`, `pyproject.toml` (add `[project.scripts]`)

**Acceptance criteria:**
- [ ] Command `agentbase validate <agentbase.yaml> <agents.yaml>` works
- [ ] Validates: required fields, model alias resolution, env vars
- [ ] Exit code 0 (valid) or 1 (invalid)
- [ ] Error messages are clear and actionable (name the specific problem)
- [ ] Handles missing files with helpful error
- [ ] Works with no arguments (uses defaults: agentbase.yaml, agents.yaml in cwd)
- [ ] Integration test: run against valid portfolio config → exit 0
- [ ] Integration test: run against invalid config → exit 1 with error message

**Example output:**
```
$ agentbase validate
✓ agentbase.yaml valid
✓ agents.yaml valid
✓ All agents use defined model aliases
✓ All contract fields present
```

```
$ agentbase validate bad.yaml
✗ Model alias "unknown" referenced in agent "writer" but not defined in agentbase.yaml
✗ Agent "editor" missing required field: prompt_ref
```

---

### TASK-019: Expand LangSmith Dashboard Guide

**Objective:** Document how to set up LangSmith dashboards with concrete examples.

**Files:** `docs/MONITORING.md` (expand "Dashboards" section)

**Acceptance criteria:**
- [ ] Document 4 standard dashboard cards:
  - Latency by agent (how to query, what it shows, sample screenshot)
  - Call volume over time (by agent/environment, how to filter)
  - Error rate by agent (identify problem areas)
  - Cost breakdown by model (ROI per model)
- [ ] Provide copy-paste LangSmith query examples for each
- [ ] Step-by-step guide: "Create dashboard in 5 minutes"
- [ ] Include field names and filter syntax (tag=, status=, etc.)
- [ ] Example: "Dashboard for Writerverse" (sample queries)

**Success:** A new project operator can set up monitoring without trial-and-error

---

### TASK-020: Write Cost Optimization Guide

**Objective:** Document how to identify and optimize agent costs.

**Files:** `docs/MONITORING.md` (new "Cost Optimization" section)

**Acceptance criteria:**
- [ ] Document: how to find most expensive agents
- [ ] Document: when to switch agent to cheaper model (analysis framework)
- [ ] Document: ROI calculation (cost per feature, per user, per call)
- [ ] Document: A/B testing model changes (run both, compare latency & cost)
- [ ] Document: cost tracking over time (weekly review process)
- [ ] Provide real example: portfolio_assistant (hypothetical costs)
- [ ] Include: when to NOT optimize (latency/quality tradeoff)

**Success:** Teams can make cost optimization decisions with confidence

---

### TASK-021: Update Documentation Index

**Objective:** Keep specs and docs in sync with new tasks.

**Files:** `HANDOFF.md`, `CLAUDE.md`, `specs/implementation/README.md` (if exists)

**Acceptance criteria:**
- [ ] HANDOFF.md references Sprint 004 as current work
- [ ] CLAUDE.md mentions new CLI and expanded monitoring docs
- [ ] Updated memory (project-agentbase-vision.md)
- [ ] Sprint 004 plan visible in roadmap

---

## Sprint Execution Notes

### Task Order
1. TASK-018 (validate CLI) — Unblocks validation before runtime
2. TASK-019 (dashboard guide) — Observability setup
3. TASK-020 (cost guide) — Cost management education
4. TASK-021 (docs) — Keep everything in sync

### Effort Estimate
- TASK-018: 1–2 hours (CLI implementation + tests)
- TASK-019: 1–2 hours (documentation expansion)
- TASK-020: 1–2 hours (guide writing)
- TASK-021: 30 min (documentation updates)
- **Total: 4–6.5 hours**

### Testing Strategy
- Unit tests for validator: valid config, invalid fields, missing aliases
- Integration test: run validator on portfolio config
- Manual test: run `agentbase validate` in Writerverse (when ready)

### Deferred to Sprint 005
- `agentbase init` CLI scaffolding (higher effort, can wait for Writerverse integration)

---

## Completed: What's Already Done

✓ TASK-022: Portfolio end-to-end validated (chat widget, streaming, tracing)
✓ TASK-023: Scaffold templates created (agentbase.yaml, agents.yaml templates)
✓ Monitoring guide started (docs/MONITORING.md created)
✓ Project integration guide (specs/implementation/project-integration-guide.md)
