# Testing Strategy

## Principles

- Tests verify that AgentBase works correctly, not that LiteLLM or Langfuse work correctly
- AgentBase tests must pass without a consuming project present
- Prefer fast unit tests over slow integration tests
- Integration tests with real APIs are opt-in (require env vars to be set)

## Test Layers

### Unit Tests (Always Run)

| What | How | Example |
|------|-----|---------|
| Config loading and validation | Load test YAML fixtures; verify parsed output and error cases | `test_config.py` |
| Registry loading and contract validation | Load test agent registries; verify validation and lookup | `test_registry.py` |
| Model alias resolution | Given config + environment, verify correct model ID | `test_models.py` |
| Exception messages | Verify error messages include relevant context (agent name, field name) | `test_exceptions.py` |
| Type construction | Verify types accept valid data and reject invalid data | `test_types.py` |

### Integration Tests (Require API Keys)

| What | How | Gating |
|------|-----|--------|
| LLM call through AgentBase | Call `get_llm()` and make a real completion call | `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` set |
| Langfuse trace creation | Call `init_tracing()` + `get_llm()` and verify trace in Langfuse | `LANGFUSE_SECRET_KEY` set |
| Cost attribution | Verify cost appears in Langfuse trace | Same as above |

Integration tests are skipped (not failed) when env vars are missing. Use `pytest.mark.skipif` or equivalent.

## Test Fixtures

Store in `tests/fixtures/`:

- `valid_config.yaml` — well-formed `agentbase.yaml`
- `valid_agents.yaml` — well-formed `agents.yaml` with 2-3 test agents
- `invalid_config_missing_project.yaml` — config without `project` field
- `invalid_agents_missing_field.yaml` — agent missing a required contract field
- `invalid_agents_bad_alias.yaml` — agent referencing non-existent model alias

## What Not to Test

- LiteLLM's model routing logic (their tests cover this)
- Langfuse's trace storage and display (their tests cover this)
- YAML parsing correctness (PyYAML handles this)
- Consuming project's agent logic (their responsibility)

## Coverage Target

No specific percentage target. Every public function and every error path should have at least one test. Coverage tools can be added later if useful.

## Running Tests

```bash
# Unit tests only (no API keys needed)
pytest tests/ -m "not integration"

# All tests (requires API keys in .env)
pytest tests/
```
