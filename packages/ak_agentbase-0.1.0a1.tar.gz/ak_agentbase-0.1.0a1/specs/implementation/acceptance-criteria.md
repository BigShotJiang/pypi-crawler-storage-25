# Acceptance Criteria — v0.1-alpha

These are the definitive criteria for declaring v0.1-alpha complete. Every criterion must be verified.

## Functional Criteria

| # | Criterion | How to Verify |
|---|-----------|--------------|
| AC-01 | `from agentbase import get_llm, init_tracing` works | Import in a Python file |
| AC-02 | `init_tracing(project="x", environment="dev")` initializes Langfuse | Call it; check no errors; verify Langfuse client is created |
| AC-03 | `get_llm("agent_name")` returns a working LLM client | Call it; use the client to make a completion |
| AC-04 | Every LLM call appears in Langfuse with tags: project, environment, agent_name, agent_version, model_alias, model_id | Make a call; check Langfuse UI or API |
| AC-05 | Unregistered agent raises `AgentNotRegisteredError` with agent name in message | Call `get_llm("nonexistent")` |
| AC-06 | Missing contract field raises `ContractViolationError` with field name | Create an agent entry missing `owner`; load registry |
| AC-07 | Model alias resolves differently per environment | Set `AGENTBASE_ENV=dev` vs `production`; verify different model IDs |
| AC-08 | Malformed YAML raises `ConfigValidationError` with details | Load intentionally broken YAML |
| AC-09 | Missing env vars produce clear error naming the var | Unset a required key; attempt init |
| AC-10 | Cost attribution visible in Langfuse | Make calls; check cost data in Langfuse dashboard |

## Structural Criteria

| # | Criterion | How to Verify |
|---|-----------|--------------|
| AC-11 | AgentBase test suite passes without consuming project present | Run `pytest` from `agentbase/` or `tests/` alone |
| AC-12 | AgentBase has zero imports from any consuming project | Grep for imports; test in isolation |
| AC-13 | Config is loaded once, not re-parsed on every call | Code review; verify caching in `config.py` |

## Integration Criteria

| # | Criterion | How to Verify |
|---|-----------|--------------|
| AC-14 | A consuming project uses AgentBase for at least one real agent | Sprint 003 deliverable |
| AC-15 | Changing a model alias in config changes the agent's model without code changes | Modify `agentbase.yaml`; restart; verify new model in traces |
| AC-16 | Adding a new agent to the registry enables immediate use via `get_llm()` | Add entry to `agents.yaml`; call `get_llm()` for it |

## Not Acceptance Criteria (Explicitly)

These are NOT required for v0.1-alpha sign-off:

- CLI commands working
- Shared utilities available
- Override system functioning
- Local dev mode
- Documentation beyond code docstrings
- Production deployment
- Second project adoption
