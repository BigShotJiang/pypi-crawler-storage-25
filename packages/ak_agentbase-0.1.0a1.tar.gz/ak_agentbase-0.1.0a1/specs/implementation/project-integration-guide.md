# Project Integration Guide

How to integrate AgentBase into any project (Writerverse, Skill-Deck, etc.).

## Status

✓ **v0.1-alpha complete.** Pattern validated with shivam-portfolio.

This guide is the standard integration path for all future projects.

## Integration Overview

Integrating AgentBase into a project requires three things:

1. **Two YAML config files** (agentbase.yaml + agents.yaml)
2. **Two initialization calls** (load_config + init_tracing)
3. **One LLM call pattern** (resolve + langchain_config)

Estimated effort: **2–4 hours** for a typical project.

## Phase 1: Setup (30 min)

### 1.1 Copy Scaffold Files

From `scaffold/` directory, copy to your project root:
- `agentbase.yaml` → `agentbase.yaml` (your project)
- `agents.yaml` → `agents.yaml` (your project)

### 1.2 Edit Configuration

**agentbase.yaml:**
- Change `project:` to your project name
- Update `models:` with your model choices (fast/smart/creative)
- Set `defaults.model_alias` to your preferred default

**agents.yaml:**
- Add one entry per agent in your project
- Set `agent_name`, `agent_version`, `model_alias`, `prompt_ref`, `owner`, `status`

Example for Writerverse:

```yaml
agents:
  - agent_name: content_writer
    agent_version: "1.0.0"
    model_alias: smart
    prompt_ref: prompts/content_writer_v2
    owner: shivam
    status: active

  - agent_name: editor
    agent_version: "0.5.0"
    model_alias: fast
    prompt_ref: prompts/editor_v1
    owner: shivam
    status: experimental
```

### 1.3 Add Environment Variables

Create `.env` in project root (NOT committed):

```
AGENTBASE_ENV=dev
OPENAI_API_KEY=sk-proj-...
LANGCHAIN_API_KEY=lsv2_pt_...
```

`.env.example` (committed, no secrets):

```
AGENTBASE_ENV=dev
OPENAI_API_KEY=sk-proj-...
LANGCHAIN_API_KEY=lsv2_pt_...   # Get from smith.langchain.com
```

## Phase 2: Initialization (1–2 hours)

### 2.1 Startup Code

In your app's startup (FastAPI lifespan, Django apps.py, Flask app factory, etc.):

```python
import agentbase

# Call once at startup
agentbase.load_config(
    config_path="agentbase.yaml",
    registry_path="agents.yaml",
)
agentbase.init_tracing()
```

**Where to add:**
- **FastAPI:** In lifespan async context manager (see scaffold/_init_example.py)
- **Django:** In apps.py `ready()` method or middleware init
- **Flask:** In app factory after app creation
- **Scripts:** At module level or in main()

### 2.2 Validate Startup

Run your app and verify no errors:

```bash
# Should print no errors about config or tracing
python -c "
import agentbase
agentbase.load_config()
agentbase.init_tracing()
"
```

## Phase 3: LLM Integration (1–2 hours)

### 3.1 Update LLM Calls

For **every LLM call in your codebase**, change:

**Before:**
```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini")
response = await llm.ainvoke(messages)
```

**After:**
```python
import agentbase
from langchain_openai import ChatOpenAI

resolved = agentbase.resolve("content_writer")  # Your agent name
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
response = await llm.ainvoke(messages, config=resolved.langchain_config())
```

**Key patterns:**

- Use `resolved.model_id` instead of hardcoded model string
- Pass `**resolved.default_params` to LLM constructor
- **Always** pass `config=resolved.langchain_config()` to LLM calls
- The config enables automatic LangSmith tracing

### 3.2 Multiple Agents

If your project has multiple agents, resolve each separately:

```python
# For content_writer agent
resolved_writer = agentbase.resolve("content_writer")
writer_llm = ChatOpenAI(model=resolved_writer.model_id, **resolved_writer.default_params)

# For editor agent
resolved_editor = agentbase.resolve("editor")
editor_llm = ChatOpenAI(model=resolved_editor.model_id, **resolved_editor.default_params)

# Each LLM call gets its own trace metadata
writer_response = await writer_llm.ainvoke(messages, config=resolved_writer.langchain_config())
editor_response = await editor_llm.ainvoke(messages, config=resolved_editor.langchain_config())
```

### 3.3 Validation

After updating LLM calls, test:

```python
resolved = agentbase.resolve("your_agent_name")
print(resolved.model_id)  # Should print your configured model
print(resolved.trace_metadata)  # Should have generation_name, tags, metadata
```

## Phase 4: Testing & Observability (30 min)

### 4.1 Test End-to-End

1. Start your app
2. Send a request through the agent
3. Go to [smith.langchain.com](https://smith.langchain.com/)
4. Find your project (matches `project:` in agentbase.yaml)
5. Look for a trace with your agent's name
6. Verify metadata is populated

### 4.2 Set Up Dashboard

In LangSmith, create a dashboard:
- Card 1: Latency by agent (shows which agents are slow)
- Card 2: Call volume by environment (shows usage patterns)
- Card 3: Error rate (shows failures)
- Card 4: Cost by model (shows spend)

See `docs/MONITORING.md` for detailed setup.

### 4.3 Monitor Weekly

- Check error rates by agent
- Review costs by model
- Identify slow agents
- Flag experimental agents for promotion or deprecation

## Common Issues

| Issue | Cause | Fix |
|-------|-------|-----|
| "load_config() not called" | Startup code not running | Add to lifespan/ready/factory |
| "Agent not registered" | Typo in agent_name | Check agents.yaml |
| "LANGCHAIN_API_KEY not found" | .env not loaded | Set env var or use load_dotenv() |
| No traces in LangSmith | API key wrong or tracing disabled | Verify .env, check agentbase.yaml |
| Wrong model resolved | agents.yaml model_alias wrong | Check agents.yaml and agentbase.yaml |

## Integration Checklist

### Setup Phase
- [ ] Copy agentbase.yaml and agents.yaml
- [ ] Edit project name and agents
- [ ] Create .env with LANGCHAIN_API_KEY
- [ ] Verify config loads without error

### Initialization Phase
- [ ] Add agentbase imports to startup code
- [ ] Call load_config() and init_tracing() at app startup
- [ ] Verify startup completes without errors

### LLM Integration Phase
- [ ] Update all LLM instantiations to use resolved.model_id
- [ ] Add **resolved.default_params to LLM constructor
- [ ] Add config=resolved.langchain_config() to all LLM calls
- [ ] Verify LLM calls work and get responses

### Testing Phase
- [ ] Send test request through agent
- [ ] Verify trace appears in LangSmith within 30 seconds
- [ ] Check trace has correct metadata (generation_name, tags)
- [ ] Set up dashboard for monitoring

## Success Criteria

✓ Startup completes without AgentBase errors
✓ Agent resolves to correct model_id
✓ LLM calls return responses
✓ Traces appear in LangSmith with correct metadata
✓ Dashboard shows call volume and latency

## Time Estimates

| Phase | Effort | Notes |
|-------|--------|-------|
| Setup | 30 min | Copy files, edit configs |
| Initialization | 1–2 hours | Update startup code (depends on framework) |
| LLM Integration | 1–2 hours | Update all LLM calls (depends on # of agents) |
| Testing | 30 min | Verify traces and dashboard |
| **Total** | **3–5 hours** | Varies by project size and complexity |

## Next Steps After Integration

1. **Monitor for a week:** Verify traces, check error rates, review costs
2. **Optimize models:** Switch agents to cheaper models if appropriate
3. **Promote agents:** Move experimental agents to active after validation
4. **Scale:** Integrate additional projects using same pattern

## Support

- **AgentBase docs:** `CLAUDE.md`
- **Testing guide:** `TESTING_E2E.md`
- **Monitoring guide:** `docs/MONITORING.md`
- **API reference:** `agentbase/__init__.py`
- **Config format:** `specs/architecture/config-strategy.md`
