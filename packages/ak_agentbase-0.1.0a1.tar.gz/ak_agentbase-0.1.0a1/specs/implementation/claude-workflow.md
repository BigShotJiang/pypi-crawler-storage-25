# Claude Code Workflow

How Claude Code should use these specs to work on AgentBase.

## Before Writing Any Code

1. **Read the product vision** — `specs/product/vision.md`. Understand what AgentBase is and isn't.
2. **Read the current release plan** — `specs/planning/v0.1-alpha.md`. Understand what's in scope.
3. **Read the scope boundaries** — `specs/foundation/scope-and-boundaries.md`. Know what NOT to build.
4. **Read the relevant sprint** — `specs/sprints/sprint-00X.md`. Know the current goal and tasks.
5. **Read relevant ADRs** — if the task touches a decision area (tracing, packaging, agent architecture), read the ADR first.

## While Building

1. **Implement one task at a time** from `specs/implementation/tasks-v0.1-alpha.md`.
2. **Follow task order within a sprint.** Tasks are sequenced by dependency.
3. **Check acceptance criteria before marking a task done.** Each task has specific criteria.
4. **Write tests as part of the task**, not as a separate step. Each task specifies what to test.
5. **Respect "What not to do"** in each task. These exist because the scope is tempting to expand.

## When You Encounter Scope Creep

If you think "we should also add X" while building:

1. Check `specs/foundation/scope-and-boundaries.md` — is X explicitly out of scope?
2. Check `specs/planning/backlog.md` — is X already tracked?
3. If X is new and not in scope: add it to `specs/planning/backlog.md` or `specs/planning/open-questions.md`. Do not implement it.
4. If X is blocking the current task: note the blocker and proceed with the simplest workaround. Log the issue.

**Never implement features from a future release in the current release.** Even if it "would be easy."

## When Specs Don't Cover a Situation

1. Check `specs/strategy/principles.md` — does a principle guide the decision?
2. Check `specs/decisions/` — is there a relevant ADR?
3. If neither helps: make the simplest decision that doesn't close future options. Note the decision in the relevant spec or in `open-questions.md`.

## When to Update Specs

- **When a product decision changes** — update the relevant planning or strategy doc
- **When implementation reveals the spec was wrong** — update the spec to match reality
- **When a new question emerges** — add it to `specs/planning/open-questions.md`
- **When a new backlog item is identified** — add it to `specs/planning/backlog.md`

**Do not update specs just because code evolved.** Specs capture decisions and scope, not implementation details. Code is the source of truth for how things work.

## Task Completion Checklist

For each task:

- [ ] Acceptance criteria met
- [ ] Tests written and passing
- [ ] No imports from consuming project introduced
- [ ] No scope beyond the task's "Expected files/modules"
- [ ] No "What not to do" items violated
- [ ] Any issues or questions logged in backlog/open-questions

## File Reading Order (Quick Reference)

```
First time:    vision → principles → scope → current release plan → sprint → task
Returning:     current sprint → current task → relevant ADR if needed
Before commit: acceptance criteria → test results → scope boundaries
```
