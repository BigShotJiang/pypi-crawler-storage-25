# Implementation Tasks — v0.1-alpha

Each task is a discrete unit of work. Complete them in order within each sprint. Check acceptance criteria before marking done.

---

## Sprint 001 Tasks

### TASK-001: Package Setup ✓

**Objective:** Create the AgentBase package skeleton with proper Python packaging.

**Files:** `agentbase/__init__.py`, `agentbase/types.py`, `agentbase/exceptions.py`, `pyproject.toml`, `tests/__init__.py`

**Acceptance criteria:**
- `import agentbase` works
- `agentbase.__version__` returns a version string
- Dependencies declared in `pyproject.toml`: pyyaml, pydantic

---

### TASK-002: Type Definitions ✓

**Objective:** Define the core data structures used throughout AgentBase.

**Files:** `agentbase/types.py`

**Types defined:**
- `AgentStatus` — StrEnum: experimental, active, deprecated
- `AgentMetadata` — all 8 contract fields
- `ModelAliasConfig` — alias name, per-environment model IDs, default parameters
- `AgentBaseDefaults` — default environment and model alias
- `AgentBaseConfig` — project name, models, defaults; `.environments` is a computed property
- `ResolvedAgent` — output of `resolve()`: agent_name, model_id, default_params, trace_metadata

---

### TASK-003: Custom Exceptions ✓

**Objective:** Define clear, actionable error classes for AgentBase failure modes.

**Files:** `agentbase/exceptions.py`

**Exceptions:**
- `AgentBaseError` — base exception
- `ConfigValidationError` — malformed YAML, missing required config fields
- `AgentNotRegisteredError` — agent name not found in registry
- `ContractViolationError` — agent exists but missing required contract fields
- `ModelResolutionError` — model alias can't be resolved for current environment

---

### TASK-004: Config Loading and Validation ✓

**Objective:** Load `agentbase.yaml`, validate its structure, and provide typed access to config values.

**Files:** `agentbase/config.py`, `tests/test_config.py`, `tests/fixtures/`

**Key behaviors:**
- Load YAML from a file path (default: `agentbase.yaml` in current directory)
- Validate required fields: `project`, `models`
- Validate model aliases have mappings for all environments implied by any alias
- Support `${VAR}` interpolation in any YAML value
- Return a typed `AgentBaseConfig` object
- Determine current environment from `AGENTBASE_ENV` env var or config default

**Note:** No `environments:` section in `agentbase.yaml`. Valid environments are derived from model alias keys.

---

### TASK-005: Agent Registry ✓

**Objective:** Load `agents.yaml`, validate all agents against the contract, and provide agent lookup.

**Files:** `agentbase/registry.py`, `tests/test_registry.py`, `tests/fixtures/`

**Key behaviors:**
- Validate every agent has all 6 contract fields: agent_name, agent_version, model_alias, prompt_ref, owner, status
- Validate `model_alias` references exist in the loaded config
- Validate `status` is one of: experimental, active, deprecated
- `get_agent(name)` → `AgentMetadata` or `AgentNotRegisteredError`

---

### TASK-006: Model Resolution and resolve() ✓

**Objective:** Resolve model aliases to provider-specific model IDs and return a framework-agnostic `ResolvedAgent`.

**Files:** `agentbase/models.py`, `tests/test_models.py`

**Key behaviors:**
- Accept an agent name, registry, config, and optional environment
- Resolve agent's `model_alias` to a model ID for the current environment
- Compute standardized trace metadata (project, env, agent fields, resolved model_id)
- Return `ResolvedAgent(agent_name, model_id, default_params, trace_metadata)`
- Expose as `agentbase.resolve("agent_name")`

**What the consumer does with ResolvedAgent:**
```python
resolved = agentbase.resolve("quiz_generator")
# LangChain:
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
# Direct API:
response = openai.chat.completions.create(model=resolved.model_id)
```

**Acceptance criteria:**
- `resolve("quiz_generator")` returns a `ResolvedAgent`
- `model_id` is the provider-specific ID, not the alias
- Environment switching (dev vs production) resolves different model IDs
- `default_params` from the alias config are included
- `trace_metadata` contains all contract fields in standardized structure
- Unregistered agent raises `AgentNotRegisteredError`
- Alias with no mapping for current environment raises `ModelResolutionError`

---

### TASK-006b: Public API and Init ✓

**Objective:** Wire up the public API surface in `__init__.py`.

**Files:** `agentbase/__init__.py`, `tests/test_init.py`

**Public API:**
- `agentbase.load_config(config_path, registry_path)` → `AgentBaseConfig`
- `agentbase.resolve(agent_name, environment=None)` → `ResolvedAgent`

**Acceptance criteria:**
- `from agentbase import load_config, resolve` works
- `resolve()` before `load_config()` raises a clear error
- `resolve()` after `load_config()` returns the correct `ResolvedAgent`

---

### TASK-007: Trace Metadata ✓

**Objective:** Standardize trace metadata computation for all agents.

**Files:** `agentbase/tracing.py`, `tests/test_tracing.py`

**Key behaviors:**
- `build_trace_metadata(agent, model_id)` returns a consistent dict
- Structure: `{generation_name, trace_name, tags: [project, env, status], metadata: {...all fields}}`
- Called internally by `resolve()` — consumers get metadata via `ResolvedAgent.trace_metadata`

**What NOT to build:**
- No tracing backend initialization
- No SDK dependencies (LangSmith, Langfuse, etc.)
- No callback wiring

---

## Sprint 002 Tasks (Planned)

### TASK-008: First Project Integration

**Objective:** Integrate AgentBase into the first consuming project (Brainboard, Writerverse, or Skill-Deck).

**Key behaviors:**
- Project calls `agentbase.load_config()` at startup
- Project calls `agentbase.resolve("agent_name")` to get model config
- Project constructs its LLM client (ChatOpenAI, ChatAnthropic, etc.) from `resolved.model_id`
- Project attaches trace metadata to its chosen tracing tool (LangSmith or Langfuse)

**Acceptance criteria:**
- One working agent in the consuming project using `agentbase.resolve()`
- Changing a model alias in `agentbase.yaml` changes the model the agent uses without code changes
- Adding a new agent to `agents.yaml` makes it immediately available via `resolve()`

---

### TASK-009: Integration Verification

**Objective:** Verify end-to-end integration and document any friction.

**Acceptance criteria:**
- All v0.1-alpha acceptance criteria verified
- Issues found are logged in backlog (not silently worked around)
- v0.1-alpha declared complete
