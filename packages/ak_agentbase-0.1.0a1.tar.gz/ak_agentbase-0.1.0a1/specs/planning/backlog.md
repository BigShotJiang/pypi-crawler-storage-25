# Backlog

Items that have been identified but are not assigned to any release. Review periodically and promote to a release when the need is proven.

## Potential Future Items

| Item | Notes | Earliest Release |
|------|-------|-----------------|
| Vector database connection pattern | Standardize if 2+ projects need vector search | v0.3+ |
| Agent-to-agent communication patterns | May emerge from multi-agent projects | v0.3+ |
| Token budget management | Per-agent or per-request token limits | v0.2+ |
| Rate limiting at the AgentBase level | Global rate limits across all agents | v0.2+ |
| Config hot-reload | Change config without restarting the application | v0.2+ |
| Langfuse prompt management integration | Use Langfuse as prompt store, AgentBase as router | v0.2+ |
| Async/sync API parity | Ensure all functions work in both sync and async contexts | v0.1-beta+ |
| OpenTelemetry integration | Export traces to OTel collectors alongside Langfuse | v0.4+ |
| Cost budget alerts | Alert when a project exceeds a cost threshold | v0.3+ |
| Agent dependency graph | Visualize which agents call which agents | v0.4+ |

## Rules for This Backlog

- Items here have no commitment or timeline
- An item must have a proven need (from a real project) before being promoted to a release
- Prefer removing items that are no longer relevant over keeping a long list
- New ideas from implementation should be added here, not to the current release scope
