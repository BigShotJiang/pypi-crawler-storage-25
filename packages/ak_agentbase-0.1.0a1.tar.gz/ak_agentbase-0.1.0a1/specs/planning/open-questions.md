# Open Questions

Questions that need answers but don't have them yet. Each question includes when it needs to be decided and a suggested default.

## Active Questions

| # | Question | Decide By | Suggested Default |
|---|----------|----------|-------------------|
| 1 | **What is the first new project?** Must meet criteria: 2-4 agents, 2+ models, real users, shippable scope. | Before v0.1-alpha Sprint 3 | Define within one sprint of starting AgentBase work |
| 2 | **Should AgentBase manage prompt storage or just index?** | After first project's prompt patterns emerge | Index only (track `prompt_ref`, don't store prompts) |
| 3 | **Sync-first or async-first API?** LiteLLM supports both. Which should `get_llm()` return by default? | v0.1-alpha Sprint 1 | Sync by default, async variant as `get_llm_async()` |
| 4 | **How do we handle multi-agent workflows?** If one agent calls another, how is that traced? | After first project encounters this | Nested Langfuse traces (span per agent within a parent trace). Don't build orchestration. |
| 5 | **Should `agents.yaml` support inline model params per agent?** Or must all params come from the model alias? | v0.1-alpha Sprint 2 | Allow per-agent param overrides in v0.1-beta; alias-only in v0.1-alpha |

## Resolved Questions

| # | Question | Resolution |
|---|----------|-----------|
| R1 | Langfuse or LangSmith? | Langfuse. See ADR-002. |
| R2 | Monorepo or standalone package? | Monorepo with clean boundary; extract at v0.2. See ADR-003. |
| R3 | Who owns AgentBase long-term? | Founder-owned in early phases. |
| R4 | Mandatory or optional registry? | Mandatory. Contract enforcement from v0.1-alpha. |
