# Claude Commands (Proposed)

These are proposed command patterns for working with AgentBase specs in Claude Code. **None of these are implemented yet.** They represent future workflow ideas.

## Proposed Commands

### /spec-plan

**Purpose:** Review the current specs and plan the next implementation step.

**What it would do:**
1. Read the current sprint file
2. Identify the next uncompleted task
3. Read the task's dependencies and acceptance criteria
4. Present a plan for implementing the task

**When to use:** Starting a new work session or moving to the next task.

---

### /spec-build

**Purpose:** Implement the current task following spec guidance.

**What it would do:**
1. Read the current task from `implementation/tasks-v0.1-alpha.md`
2. Read relevant architecture docs for the modules being built
3. Implement the code following acceptance criteria
4. Write tests as specified
5. Verify "What not to do" constraints

**When to use:** When ready to write code for a specific task.

---

### /spec-review

**Purpose:** Check completed work against spec criteria.

**What it would do:**
1. Read acceptance criteria for the current task/sprint
2. Verify each criterion against the actual code
3. Check for scope violations (imports from consuming project, out-of-scope features)
4. Report pass/fail for each criterion

**When to use:** After completing a task, before moving on.

---

### /spec-test

**Purpose:** Run the AgentBase test suite and report results.

**What it would do:**
1. Run `pytest tests/ -m "not integration"` for unit tests
2. Optionally run integration tests if API keys are available
3. Report results mapped to acceptance criteria

**When to use:** After any code change.

---

### /spec-update

**Purpose:** Update specs to reflect decisions made during implementation.

**What it would do:**
1. Identify what changed (new question, resolved question, scope change, backlog item)
2. Update the appropriate spec file
3. If a backlog item was added, confirm it's not in current scope

**When to use:** When implementation reveals something the specs didn't cover.

---

## Current Workflow (Without Commands)

Until these commands are implemented, follow the manual workflow in `implementation/claude-workflow.md`:

1. Read the relevant specs before starting work
2. Implement one task at a time
3. Check acceptance criteria manually
4. Run tests with `pytest`
5. Update specs when decisions change

The commands above would automate this workflow but are not required. The specs are useful on their own as reference documents.

## Implementation Notes

When building these commands:
- They should read spec files, not duplicate their content
- They should be thin wrappers that guide Claude Code to follow the workflow
- They should not add dependencies or infrastructure
- Start with `/spec-plan` and `/spec-review` — the highest-value commands
