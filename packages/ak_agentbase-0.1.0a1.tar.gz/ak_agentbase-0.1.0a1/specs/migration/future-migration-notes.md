# Future Migration Notes

Migration of existing projects is **not in scope until v0.3**. This file captures early observations that will inform migration planning later.

## Projects to Eventually Migrate

| Project | Current Setup | Notes |
|---------|--------------|-------|
| Writerverse | Own LangChain setup, own observability | Autonomous book-writing platform; likely complex agent workflows |
| Skill-Deck | Own LLM config, own tracing | Learning/skill-building product |
| Brainboard | TBD | May be the first AgentBase consumer depending on timing |

## Migration Principles (Preliminary)

- **Incremental, not big-bang.** Projects adopt AgentBase module-by-module.
- **One project at a time.** Each migration is complete before the next starts.
- **No regression.** A migrated project must not be worse off than before.
- **Project chooses pace.** AgentBase team provides the playbook; project team executes.

## Things to Watch During v0.1

As we build and use AgentBase for the first project, note anything that would make migration harder:

- Config patterns that assume a greenfield project
- API choices that conflict with how existing projects call LLMs
- Registry requirements that don't fit existing agent structures
- Langfuse tagging that conflicts with existing observability

Log observations here as they arise. They will inform the v0.3 migration playbooks.

## Current Observations

(None yet — this section will be populated during v0.1 development)
