# AgentBase — Claude Code Context

## What Is This Project

AgentBase is an internal shared AI agent foundation/control plane. It standardizes how all our AI-heavy products (Writerverse, Skill-Deck) configure models, register agents, and emit observability metadata — so no project reinvents this setup.

AgentBase is a **configuration and observability broker**, not a framework. It resolves, validates, and hands off. It does not orchestrate, construct model clients, or depend on any AI framework.

## Current State

- **Phase:** v0.1-alpha tagged. Sprint 004 (v0.1-beta DX) complete. 96 tests passing.
- **Code:** Core library + CLI + docs all finalized. shivam-portfolio working end-to-end.
- **Handoff:** Check `HANDOFF.md` at repo root for latest status and next steps.

## Before Writing Any Code

Always follow this reading order:

1. `HANDOFF.md` — current status and next steps
2. `specs/sprints/sprint-004.md` — completed v0.1-beta work (or latest sprint)
3. `specs/implementation/project-integration-guide.md` — how to integrate new projects
4. `specs/architecture/observability-strategy.md` — how tracing metadata works

## Key Architecture Decisions

These are settled. Do not re-debate or deviate unless explicitly asked:

- **No framework dependency.** AgentBase has zero dependencies on LiteLLM, LangChain, LangSmith, or Langfuse. Products import what they need.
- **`resolve()` not `get_llm()`.** AgentBase returns a `ResolvedAgent` (model_id, default_params, trace_metadata). Products construct their model client from it.
- **Tracing via env vars, not SDKs.** AgentBase's `init_tracing()` sets LANGCHAIN_TRACING_V2 and LANGCHAIN_PROJECT if tracing is configured. Products using LangChain automatically get tracing; products not using LangChain ignore it. No SDK wrapping.
- **Trace metadata in ResolvedAgent.** AgentBase computes standardized trace metadata (generation_name, tags, metadata) via `resolve()`. Products pass it to their model client (e.g., `llm.astream(..., config=resolved.langchain_config())`)
- **YAML config** (`agentbase.yaml` + `agents.yaml`). Not JSON, not TOML, not code.
- **Agent Contract** with 8 required fields enforced at startup. (See `specs/foundation/agentbase-contract.md`)
- **Model aliases** (`fast`, `smart`, `creative`) that resolve to provider-specific IDs per environment.
- **No `environments:` section in `agentbase.yaml`.** Valid environments are derived from model alias keys.
- **No BaseAgent class.** No forced inheritance. No decorators for registration.
- **No migration** of existing projects until v0.3.

## Public API

### Python API

```python
import agentbase
from langchain_openai import ChatOpenAI

# 0. (Optional) Validate config before running
# $ agentbase validate agentbase.yaml agents.yaml
# Exit code 0 if valid, 1 if any errors

# 1. Load config (validates YAML, parses agent registry, tracing settings)
agentbase.load_config(config_path="agentbase.yaml", registry_path="agents.yaml")

# 2. Initialize tracing (sets env vars for LangSmith if configured; validates LANGCHAIN_API_KEY)
agentbase.init_tracing()

# 3. Resolve an agent to get model config + trace metadata
resolved = agentbase.resolve("quiz_generator")
# resolved.model_id       → "gpt-4o-mini"
# resolved.default_params → {"temperature": 0.3, "max_tokens": 1024}
# resolved.trace_metadata → {"generation_name": ..., "trace_name": ..., "tags": [...], "metadata": {...}}

# 4. Products construct their model client and pass trace config to every call
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
response = await llm.astream(messages, config=resolved.langchain_config())
```

### CLI

```bash
# Validate config before running your app
agentbase validate [agentbase.yaml] [agents.yaml]
# Exit code 0 if valid, 1 if any errors. Checks:
# - YAML syntax and required fields
# - Model alias resolution
# - Environment variables (LANGCHAIN_API_KEY if using LangSmith)
```

## agentbase.yaml Format

```yaml
project: portfolio

models:
  fast:
    dev: gpt-4o-mini
    production: gpt-4o
  smart:
    dev: gpt-4o
    production: claude-sonnet-4-20250514

defaults:
  environment: dev
  model_alias: smart

tracing:
  backend: langsmith  # "langsmith" | "none"
  enabled: true       # set LANGCHAIN_TRACING_V2=true if enabled and backend is langsmith
```

**Notes:**
- No `environments:` section. The set of valid environments is derived from model alias keys.
- `tracing.backend`: "langsmith" sets LANGCHAIN_TRACING_V2=true and LANGCHAIN_PROJECT={project}. Set LANGCHAIN_API_KEY in .env to enable.
- `default_params` is optional and inherited per-model or per-alias.

## What NOT to Build

- Web UI, dashboard, or visualization
- Prompt editor or prompt storage (only track `prompt_ref` pointers)
- Evaluation framework
- Custom orchestration or workflow engine (use LangGraph)
- LLM client construction (that's the product's job)
- Tracing backend initialization or SDK wiring
- BaseAgent class or mandatory inheritance hierarchy
- Migration tooling (v0.3)

## Repo Structure

```
AgentBase/
  CLAUDE.md              ← You are here
  HANDOFF.md             ← Session handoff, next steps
  PRODUCT_PLAN.md        ← High-level product plan
  TESTING_E2E.md         ← End-to-end testing guide
  specs/                 ← Full spec system (architecture, planning, tasks)
  agentbase/
    __init__.py          ← Public API: load_config, resolve, init_tracing
    cli.py               ← CLI: agentbase validate command
    __main__.py          ← Entry point for python -m agentbase
    config.py            ← Config loading and parsing
    registry.py          ← Agent registry loading
    models.py            ← Agent resolution
    tracing.py           ← LangSmith tracing setup
    types.py             ← Pydantic models
    exceptions.py        ← Custom exception types
  tests/                 ← 96 unit tests (core + CLI validation)
  pyproject.toml         ← Package config (pyyaml, pydantic only)
  scaffold/              ← Project integration templates
    README.md            ← How to use the scaffold
    agentbase.yaml       ← Config template
    agents.yaml          ← Agent registry template
    _init_example.py     ← FastAPI, Django, sync, LangGraph examples
  docs/
    MONITORING.md        ← LangSmith dashboards + cost optimization
```

## Commit Messages

Format: `<type>(<scope>): <description>`

**Types:**
| Type | When to use |
|------|-------------|
| `feat` | New capability, module, or user-facing behavior |
| `fix` | Bug fix |
| `test` | Add or update tests only |
| `refactor` | Code change with no behavior change |
| `docs` | Docs, specs, comments only |
| `chore` | Build, deps, config, tooling |

**Scopes** (use the module name):
`config` · `registry` · `models` · `tracing` · `types` · `exceptions` · `pkg`

**Rules:**
- Lowercase, no period, imperative mood ("add X", not "adds X" or "added X")
- 72 chars max on subject line
- Body optional — use it for WHY, not WHAT

## Code Conventions

- Python 3.11+
- Type hints on all public functions
- Pydantic for data structures
- pytest for testing
- No comments unless the WHY is non-obvious
- Clear, actionable error messages that name the specific problem and how to fix it

## Dependencies (v0.1-alpha)

- `pyyaml==6.0.3` — config loading
- `pydantic==2.12.5` — type validation
- `pytest==9.0.3` — testing (dev)
- `ruff==0.15.12` — linting (dev)

No framework dependencies. No LiteLLM. No Langfuse. Products bring their own.

## Spec References

| Topic | File |
|-------|------|
| Product vision | `specs/product/vision.md` |
| What's in/out of scope | `specs/foundation/scope-and-boundaries.md` |
| Agent Contract (required metadata) | `specs/foundation/agentbase-contract.md` |
| Config format | `specs/architecture/config-strategy.md` |
| Module structure | `specs/architecture/modules.md` |
| Tracing design | `specs/architecture/observability-strategy.md` |
| All ADRs | `specs/decisions/README.md` |
| v0.1-alpha plan | `specs/planning/v0.1-alpha.md` |
| Implementation tasks | `specs/implementation/tasks-v0.1-alpha.md` |
| Acceptance criteria | `specs/implementation/acceptance-criteria.md` |
| Testing strategy | `specs/implementation/testing-strategy.md` |
| Open questions | `specs/planning/open-questions.md` |
| Backlog | `specs/planning/backlog.md` |

## External Project Integrations

### Writerverse Integration (Sprint 005)

**Worktree Location:** `/Users/shivam/Documents/github/writerverse/.claude/worktrees/feature/agentbase-v1`

**Branch:** `feature/agentbase-v1` (created from writerverse main on 2026-05-16)

**Current Integration Status:** 
- Pilot agents identified: `generate_scene`, `generate_synopsis`
- Ready for implementation once AgentBase config files are added
- Both agents already use LangChain, so tracing will be automatic

**How to Switch to Writerverse Worktree:**
```bash
# From any location:
cd /Users/shivam/Documents/github/writerverse/.claude/worktrees/feature/agentbase-v1

# Or use Claude Code to navigate to that directory
```

**What to Do When There:**
1. Copy `agentbase.yaml` + `agents.yaml` from AgentBase `scaffold/` to Writerverse root
2. Edit configs for Writerverse's model aliases and agent definitions
3. Modify `generate_scene.py` and `generate_synopsis.py` to use `agentbase.resolve()`
4. Add `agentbase.load_config()` and `agentbase.init_tracing()` to Django startup
5. Verify traces appear in LangSmith using dashboard guide from `docs/MONITORING.md`

**Note:** Writerverse main branch may have uncommitted changes from other agents. Always ensure the worktree is on `feature/agentbase-v1` before making changes.
