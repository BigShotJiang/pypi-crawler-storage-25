# AgentBase: Product Plan

**Version:** v0.3 (Final Draft)
**Date:** 2026-05-16
**Author:** Shivam
**Status:** Ready for execution

---

## Guiding Principle

> **AgentBase should be built aggressively in vision, but gradually in execution.**

AgentBase will not begin as a migration project. It will begin as the foundation for the next AI product, prove itself there, and then become the shared backbone for all products.

---

## 1. What Problem AgentBase Is Solving

Every AI-powered product we build requires the same foundational infrastructure:

- Which LLM to call, with what settings, through what provider
- How to manage, version, and compare prompts
- How to observe what agents are doing (traces, latency, errors, costs)
- How to connect to observability tools consistently
- How to manage API keys and model configurations without drift
- How to know what agents exist, who owns them, and how they perform

Today, every project solves this independently. Writerverse has its own setup. Skill-Deck has its own setup. Brainboard has its own setup. Every future AI product will face the same blank-slate problem.

This is not just a developer inconvenience — it is an organizational blind spot. No one can answer basic questions like:
- What AI agents do we run across all products?
- What do they cost us per month?
- What models are we using, and are any being deprecated?
- How does Agent X in Project Y perform compared to last month?

**AgentBase is the internal AI foundation that makes these questions trivially answerable, while making every new AI project faster to build and safer to operate.**

---

## 2. The Rollout Philosophy

| Principle | What It Means |
|-----------|---------------|
| **New-project-first** | AgentBase is proven by powering a brand-new AI product from day one — not by migrating existing ones |
| **No premature migration** | Writerverse, Skill-Deck, Brainboard stay on their current setup until AgentBase is battle-tested |
| **Foundation, not framework** | AgentBase provides infrastructure primitives — it does not dictate how you build agents or workflows |
| **Integrate, don't replace** | LangChain, LangGraph, Langfuse, LiteLLM stay. AgentBase configures, connects, and catalogs them. |
| **Each version is independently useful** | No phase exists only to "set up" the next phase. Every version delivers usable value. |
| **Code quality over speed** | We protect the foundation from becoming another mess that needs replacing in 6 months |
| **Opinionated defaults, visible overrides** | AgentBase makes strong choices out of the box, but projects can override when needed — as long as the override is declared and auditable |

---

## 3. Pain Points (Current and Emerging)

### What Hurts Today

| Pain Point | Impact |
|------------|--------|
| Every project reinvents LLM config, observability, key management | 2-5 days wasted per new project; fixes not shared |
| No central view of what agents exist across products | Knowledge is tribal; onboarding is slow |
| No cross-product cost visibility | Budget surprises; no way to optimize or allocate spend |
| Observability is inconsistent or absent | Can't compare reliability, latency, or quality across projects |
| Model deprecation requires updating every project manually | Fire drills when OpenAI/Anthropic change models |
| Prompt versioning is ad-hoc or nonexistent | Can't roll back, can't A/B test, can't audit |

### What Will Hurt as We Scale

| Future Pain Point | When It Bites |
|-------------------|---------------|
| Compliance/audit: "What models and data flows do we use?" | When any customer, partner, or legal team asks |
| Agent reuse is impossible across products | When the third product needs the same summarization pattern |
| Evaluations are per-project, incomparable | When quality regressions slip into production unnoticed |
| Team scaling: every new person faces a different setup per project | When we hire, or when anyone switches between projects |
| A/B testing models or prompts requires custom plumbing every time | When we want to optimize cost/quality tradeoffs seriously |

---

## 4. The AgentBase Contract

Every agent that runs on AgentBase must declare a minimum set of metadata. This is the contract. It's what makes cross-project visibility, cost tracking, and observability work. Without it, AgentBase is just another library.

### Required Metadata

| Field | What It Is | Example | Why It's Required |
|-------|-----------|---------|-------------------|
| `project` | The product this agent belongs to | `brainboard` | Cost allocation, trace filtering, ownership |
| `environment` | Where this agent is running | `dev`, `staging`, `production` | Separate dev noise from production signals |
| `agent_name` | Unique name for the agent within its project | `quiz_generator` | Trace identification, registry lookup |
| `agent_version` | Current version of this agent | `0.1.0`, `2024-05-16-a` | Know what's running; enable comparison |
| `model_alias` | Logical model name from AgentBase config | `fast`, `smart`, `cheap` | Decouple code from specific model IDs; enable model switching via config |
| `prompt_ref` | Pointer to the prompt version in use | `git:abc1234`, `langfuse:v3`, `inline` | Audit trail; know what prompt produced what output |
| `owner` | Team or person responsible | `shivam`, `content-team` | Accountability; who to ask when something breaks |
| `status` | Agent lifecycle state | `experimental`, `active`, `deprecated` | Prevent reliance on agents that are being sunsetted |

### How the Contract Is Enforced

- **v0.1-alpha:** Registration is a YAML entry in the agent registry file. AgentBase validates on startup that every agent call has the required fields. Missing fields produce a clear error, not a silent pass.
- **v0.1-beta and beyond:** Agents are auto-tagged in Langfuse traces using this metadata. The contract is what powers every downstream feature — cost dashboards, trace filtering, version tracking.
- **The contract does NOT dictate:** how agents are implemented, what framework they use, how prompts are structured, or how workflows are organized. It only requires identification and accountability.

### The `model_alias` Pattern

Agents do not reference model IDs directly (e.g., `gpt-4o-2024-08-06`). They reference a logical alias like `fast`, `smart`, or `creative`. AgentBase's config maps aliases to actual model IDs per environment:

```
# agentbase.yaml (example, not final schema)
models:
  fast:
    dev: gpt-4o-mini
    production: gpt-4o-mini
  smart:
    dev: gpt-4o
    production: claude-sonnet-4-20250514
```

This means: switching the production model for every "smart" agent across every project is a one-line config change. No code touches required.

---

## 5. The Escape Hatch Principle

> **AgentBase is opinionated by default. But it is not a cage.**

Projects will sometimes need to deviate from shared defaults. A specific agent might need a non-standard temperature. A project might need a model that isn't in the shared registry yet. A deadline might require skipping a pattern that AgentBase recommends.

**This is fine — as long as the override is visible.**

### How Overrides Work

| Rule | How It's Implemented |
|------|---------------------|
| **Any shared default can be overridden at the project or agent level** | Project-level override file (`agentbase.overrides.yaml`) or per-agent override in the registry entry |
| **Every override must include a reason** | The override entry has a required `reason` field: why this agent deviates from the default |
| **Overrides are visible in the registry** | Querying an agent's config shows both the default and the override, so drift is visible, not hidden |
| **Overrides do not propagate** | An override in Project A does not affect Project B. Shared defaults remain shared. |
| **Overrides are not second-class** | No warnings, no nag messages, no "you're doing it wrong" signals. Overrides are a legitimate feature, not a workaround. |

### What This Prevents

- **Hidden drift:** Today, a developer changes a temperature in their .env and nobody knows. With AgentBase, the change is declared in the override file with a reason. If someone asks "why is this agent using temperature 0.9?", the answer is in the config, not in someone's memory.
- **Forced conformity:** Without escape hatches, projects fork AgentBase or bypass it entirely. The escape hatch keeps them inside the system.
- **Override archaeology:** Six months later, someone can read the override file and understand every deviation and why it exists. Reasons decay slower than memory.

### Example Override

```
# agentbase.overrides.yaml (example, not final schema)
overrides:
  - agent: quiz_generator
    field: model_alias
    default: smart
    override: fast
    reason: "Quiz generation is latency-sensitive; quality tradeoff is acceptable for this use case"
    
  - agent: essay_reviewer
    field: temperature
    default: 0.3
    override: 0.7
    reason: "Needs more varied feedback phrasing to avoid repetitive reviews"
```

---

## 6. Package Strategy

### The Rule

> **AgentBase lives in a monorepo with the first project for iteration speed, but it is a separately importable package from day one.**

### What This Means in Practice

| Aspect | Decision |
|--------|----------|
| **Repo structure** | Monorepo: `agentbase/` (the package) and `<first-project>/` (the consuming project) as sibling directories |
| **Import boundary** | The first project imports AgentBase as `from agentbase import ...` — never reaches into AgentBase internals. Clean import contract from the start. |
| **No cross-contamination** | AgentBase has zero imports from the first project. If something in AgentBase references the project's code, it's a design mistake. |
| **Testing** | AgentBase has its own test suite that runs independently of the first project. |
| **Extraction timeline** | At v0.2, extract AgentBase into its own repo and publish as a pip-installable package. The monorepo was for speed; the extraction is for independence. |
| **Why not extract immediately?** | The API will change rapidly in v0.1. Publishing a package with a volatile API creates version churn and frustration. Better to stabilize first, publish second. |
| **Why not stay coupled?** | The second project needs to install AgentBase without cloning the first project's repo. Extraction at v0.2 is the natural boundary. |

---

## 7. Phased Roadmap

---

### v0.1-alpha — The Minimum Usable Foundation

**Goal:** The absolute minimum version of AgentBase that a new project can import and get real value from. This is the structural core — the parts without which nothing else works.

**Business problem solved:** A developer starting a new AI project has a working LLM layer with proper observability and cost tracking from their first commit. No boilerplate. No guessing.

#### Capabilities

| Capability | What It Does |
|------------|--------------|
| **Model configuration (YAML)** | Define available models, map logical aliases (`fast`, `smart`) to provider-specific model IDs, set default parameters per alias. One config file, shared truth. |
| **Provider abstraction (LiteLLM)** | `agentbase.get_llm("agent_name")` returns a ready-to-use LLM client. The underlying provider is determined by config + alias, not hard-coded. |
| **Langfuse observability connector** | `agentbase.init_tracing(project="x")` wires up Langfuse with consistent trace naming, automatic metadata tagging from the Agent Contract fields, and cost tracking per call. One import, done. |
| **Agent Contract enforcement** | Every agent call validates the required metadata (project, environment, agent_name, agent_version, model_alias, prompt_ref, owner, status). Missing fields produce a clear startup error. |
| **Agent registry (YAML)** | Declarative catalog: every agent is registered with its Contract metadata. This is the source of truth for "what agents exist in this project." Mandatory, not optional. |
| **Environment management** | Dev / staging / production profiles. Model alias resolution changes per environment. Standard .env template with validation on startup. |
| **Cost tagging** | Every LLM call is automatically tagged in Langfuse with project + agent_name + environment + model_alias. Cost attribution from day one, no extra effort. |

#### Intentionally NOT in v0.1-alpha

- Project scaffolding CLI (`agentbase init`)
- Shared utility library (retries, rate limits, streaming)
- Local development mode
- Prompt version tracking (prompt_ref is declared but not managed)
- Override system (overrides are a v0.1-beta concern)
- Model fallback chains
- Any web UI, dashboard, or visualization
- Migration tooling for existing projects
- LangSmith support (Langfuse only; architecture is pluggable for later)

#### Success Looks Like

- A new project imports AgentBase, defines its agents in YAML, and gets LLM calls + Langfuse traces + cost tags working in under 2 hours
- The Agent Contract is enforced: every agent is registered, every trace is tagged
- Switching a model for an agent is a config change, not a code change
- The AgentBase code has zero coupling to the consuming project
- Codebase is small, clean, and well-tested

#### Risks and Tradeoffs

| Risk | Mitigation |
|------|-----------|
| v0.1-alpha is too bare to feel useful | The core value (config + tracing + cost tagging) is already more than any project has today. The DX polish in v0.1-beta follows quickly. |
| YAML registry feels like bureaucracy | Keep it minimal: 8-10 lines per agent. Auto-validate, don't auto-generate. |
| LiteLLM dependency risk | Mature library, wide adoption. The abstraction boundary means we can replace it later without project-level changes. |
| Langfuse commitment | Correct call. Open-source, self-hostable, cheaper. The observability connector interface is pluggable — a LangSmith adapter can be built later without changing the consumer API. |

---

### v0.1-beta — Developer Experience Polish

**Goal:** Make AgentBase pleasant to use, not just functional. Add the developer-experience layer that makes the first project's team productive and happy.

**Business problem solved:** The first project's developers don't just tolerate AgentBase — they prefer it over manual setup. The experience is good enough that a second project would want it.

#### Capabilities (Additions to v0.1-alpha)

| Capability | What It Does |
|------------|--------------|
| **`agentbase init` CLI** | Scaffolds a new project directory: config files, .env template, agent registry with a sample entry, Langfuse setup, directory structure. Makes the right path the easy path. |
| **Shared utilities** | Retry logic with exponential backoff, rate-limit handling, structured output parsing (JSON mode), streaming helpers. Importable modules, not framework requirements. |
| **Override system** | The Escape Hatch. Projects can override any shared default at the project or agent level via `agentbase.overrides.yaml`. Every override requires a `reason` field. Overrides are visible in agent config queries. |
| **Basic local development config** | Environment profile for local dev: lower-cost models by default (e.g., alias `smart` maps to `gpt-4o-mini` in dev), reduced Langfuse verbosity, clear config separation from production. |
| **Config validation CLI** | `agentbase validate` — checks that all YAML config is valid, all agents have required Contract fields, all model aliases resolve, all overrides have reasons. Run in CI or before deploy. |
| **Agent lifecycle states** | Agents can be marked `experimental`, `active`, `deprecated`. Deprecated agents log a warning on use. Lifecycle is visible in the registry. |

#### Intentionally NOT in v0.1-beta

- Cached/mocked LLM responses for local dev (see note below)
- Trace replay for local debugging
- Prompt version tracking or management
- Model fallback chains
- Cross-project features
- Any web UI
- LangSmith adapter

**Note on local development mode:** Basic local config (cheaper models, lower verbosity) is in v0.1-beta. Advanced features like cached LLM responses and trace replay are deferred to v0.2. Cached replay sounds simple but involves response serialization, cache invalidation, prompt-change detection, and edge cases with streaming. Building it well takes time; building it badly creates false confidence. v0.2 is the right place for this after we understand real local dev workflows from the first project.

#### Success Looks Like

- `agentbase init` produces a working project skeleton that passes `agentbase validate` out of the box
- The first project's team uses shared utilities instead of writing their own retry/parsing logic
- At least one override is used with a clear reason, proving the escape hatch works
- A developer new to the project can read the registry and understand what agents exist, what they do, and what models they use
- `agentbase validate` catches config errors before they reach runtime

#### Risks and Tradeoffs

| Risk | Mitigation |
|------|-----------|
| Shared utilities become a junk drawer | Only add utilities that the first project actually uses. No speculative additions. |
| Override system creates a new flavor of drift | Overrides are visible and auditable — that's the difference. Review override files in code review like any other config. |
| `agentbase init` generates stale templates as AgentBase evolves | Templates are thin: mostly config and a sample agent. Keep them minimal so drift is small. Update when the API changes. |

---

### v0.2 — Hardened by Production

**Goal:** Refine AgentBase based on real-world learnings from the first project. Add the capabilities that were obviously missing. Reach the quality bar where a second project would confidently adopt it.

**Business problem solved:** AgentBase is no longer an experiment — it's infrastructure that has been through production pressure and is ready to support multiple products.

#### Capabilities (Additions to v0.1-beta)

| Capability | What It Does |
|------------|--------------|
| **Prompt version tracking** | Register which prompt version (git SHA, Langfuse version ID, or tagged string) each agent is using. Track changes over time. The `prompt_ref` contract field becomes actively managed, not just declared. |
| **Model fallback chains** | If primary model is down or rate-limited, automatically fall back to a secondary. Configured in YAML. Simple: primary + one fallback per alias. No complex routing. |
| **Advanced local dev mode** | Cached LLM responses: record real API responses, replay them locally. Trace replay: re-run a production trace locally for debugging. Built after understanding real workflows from v0.1. |
| **Health checks** | Built-in health probe for each agent: is it responding? What's its p95 latency? Error rate? Queryable endpoint or CLI command. |
| **Basic alerting** | Alert via Langfuse or webhook if an agent's error rate or latency breaches a configurable threshold. |
| **Standalone package extraction** | AgentBase extracted from the monorepo into its own repository. Published as a pip-installable package. Versioned independently. |
| **Onboarding documentation** | Clear docs: how to build an agent on AgentBase, how to register it, how to debug it, how to see its traces. Written from the experience of the first project, not from theory. |

#### Intentionally NOT in v0.2

- Migrating any existing project
- Cross-project comparison or benchmarking
- Evaluation framework
- Web UI
- LangSmith adapter (build it here if a real project asks; otherwise defer)

#### Success Looks Like

- The first project has been running on AgentBase in production for 4+ weeks with no AgentBase-caused incidents
- A second new project can adopt AgentBase by running `pip install agentbase`, `agentbase init`, and reading the docs — no hand-holding required
- Prompt changes are tracked and rollback is possible
- Local dev iteration doesn't burn API credits for basic testing
- The codebase is stable enough that changes to AgentBase don't break the consuming project

#### Risks and Tradeoffs

| Risk | Mitigation |
|------|-----------|
| Premature generalization from one project's needs | Be honest about what's project-specific vs. truly shared. Only promote to AgentBase what a second project would obviously need. |
| Package extraction introduces friction | Clean import boundary from day one (v0.1-alpha) makes this mechanical, not architectural. |
| Cached replay is more complex than expected | Scope it tightly: record/replay for single LLM calls only. Multi-step workflow replay is a v0.4+ concern. |

---

### v0.3 — Multi-Project Foundation

**Goal:** Bring existing projects (Writerverse, Skill-Deck, Brainboard) onto AgentBase. Prove that it works as a shared foundation, not just a single-project convenience.

**Business problem solved:** All AI products share one foundation. We can now see, compare, and manage agents across the entire organization from one place.

#### Capabilities (Additions to v0.2)

| Capability | What It Does |
|------------|--------------|
| **Migration guides and tooling** | Project-specific migration playbooks. Scripts to adopt AgentBase incrementally (not big-bang). |
| **Cross-project agent registry** | The registry now spans all products. Answer: "What agents exist across all our products? What models do they use? What's their status?" |
| **Unified cost dashboard** | Single view: cost per project, per agent, per model, per day/week/month. Built on Langfuse data, not a custom backend. |
| **Cross-project observability** | Consistent trace format across all projects. Compare latency, error rates, and costs between projects and agents in one view. |
| **Model migration as a config change** | When a model is deprecated or a better one is released: update one config, roll it out across all projects with staged deployment. |
| **Agent comparison (same agent, different versions)** | Run the same inputs through v1 and v2 of an agent. Compare output quality, cost, latency side by side. Manual review or basic automated scoring. |
| **Prompt A/B testing support** | Route a percentage of traffic to a new prompt version. Measure performance difference via observability data. |
| **LangSmith adapter** | If any migrating project uses LangSmith, build the adapter now. Same AgentBase consumer API, different backend. |

#### Intentionally NOT in v0.3

- Automated evaluation pipelines (CI/CD evals)
- Custom web UI (Langfuse dashboards are sufficient)
- Agent marketplace or sharing across orgs
- Self-service agent deployment (projects still deploy themselves)

#### Success Looks Like

- At least 2 existing projects are running on AgentBase without regression
- "What agents do we have?" is answered by checking one registry, not searching 4 repos
- "What did LLM calls cost us this month, by project?" is answered in under 5 minutes
- A model deprecation notice results in a 1-hour migration, not a multi-day fire drill
- No project is worse off after adopting AgentBase

#### Risks and Tradeoffs

| Risk | Mitigation |
|------|-----------|
| Migration breaks existing projects | Incremental migration: projects adopt AgentBase module-by-module, not all-at-once. Feature flags for gradual cutover. |
| Registry becomes a bottleneck or bureaucracy | Registration is lightweight (a YAML entry). No approval process. But required for observability to tag properly. |
| Cross-project comparison creates unhelpful competition | Frame it as "optimization opportunity," not "scorecard." Focus on cost and reliability, not output quality ranking. |
| Trying to migrate too many projects too fast | One project at a time. Each migration is complete before the next starts. |

---

### v0.4+ — The AI Operating System

**Goal:** AgentBase becomes the internal AI operating system — the single plane through which all AI capabilities are built, monitored, evaluated, and governed.

**Business problem solved:** AI is no longer a collection of independent experiments. It's a managed, observable, continuously-improving capability with clear governance, cost control, and quality assurance.

#### Capabilities (Additions to v0.3)

| Capability | What It Does |
|------------|--------------|
| **Evaluation framework** | Standard eval runner: agent + dataset + metrics = scorecard. Integrates with promptfoo, ragas, or custom evals. Results stored and compared over time. |
| **CI/CD quality gates** | Automated check on PR: "Did this change make the agent worse?" Blocks merge if quality regresses beyond threshold. |
| **Agent performance trends** | Historical dashboards: quality, cost, latency per agent over weeks/months. Spot degradation before users notice. |
| **Reusable agent patterns** | Common agent patterns (summarizer, classifier, extractor, conversational) available as composable building blocks. Not full agents — configurable starting points. |
| **Governance and compliance layer** | Audit trail: who changed what agent/prompt/model, when, why. Data flow mapping: what data passes through which agents. Model inventory for compliance reporting. |
| **Internal agent catalog UI** | Lightweight web interface: browse agents, see status, check performance, view cost trends. Not a builder — a visibility and management tool. |
| **Cost optimization recommendations** | Automated suggestions: "Agent X could use a cheaper model with similar quality" based on eval data. |
| **Multi-environment promotion** | Promote an agent version from dev -> staging -> production with confidence, backed by eval results. |

#### Intentionally NOT in v0.4+

- External-facing platform or marketplace
- Custom model hosting or fine-tuning infrastructure
- Replacing LangChain/LangGraph orchestration
- Real-time agent monitoring with auto-remediation (too complex, too risky)

#### Success Looks Like

- Every AI agent across all products is registered, observed, versioned, and evaluated through AgentBase
- Quality regressions are caught before reaching production
- Cost is optimized systematically, not by guesswork
- A new team member can understand the entire AI landscape in an afternoon
- Compliance questions ("What models do we use? What data flows through them?") are answered instantly
- AgentBase is the thing that makes us confident about scaling AI usage, not nervous about it

#### Risks and Tradeoffs

| Risk | Mitigation |
|------|-----------|
| Becoming too heavy, too prescriptive | AgentBase stays a foundation, not a cage. Projects can always override. |
| Building a UI nobody uses | Only build it when Langfuse dashboards provably can't answer the questions people are asking. Validate need first. |
| Eval framework becomes a false sense of security | Evals complement human judgment, don't replace it. No eval score alone should block a ship. |
| Governance becomes bureaucracy | Audit trail is automatic (from observability). No manual processes unless legally required. |

---

## 8. Integration Strategy

AgentBase integrates with the ecosystem — it does not compete with it.

| Tool | AgentBase's Role | When |
|------|-----------------|------|
| **LangChain / LangGraph** | AgentBase provides configured LLM instances and observability. Projects use LangChain/LangGraph for orchestration. AgentBase doesn't touch workflow logic. | v0.1-alpha |
| **LiteLLM** | Internal routing engine inside AgentBase. Projects never call LiteLLM directly — they call `agentbase.get_llm()`. Model switching is a config change. | v0.1-alpha |
| **Langfuse** | Primary and default observability backend. AgentBase auto-configures traces with standard metadata from the Agent Contract. All cross-project visibility runs through Langfuse. | v0.1-alpha |
| **LangSmith** | Not supported in v0.1 or v0.2. Adapter built if/when a migrating project requires it (v0.3). Architecture is pluggable — the observability connector has a clean interface that can be implemented for LangSmith without changing the consumer API. | v0.3 (if needed) |
| **OpenAI / Anthropic / Google / etc.** | Providers abstracted behind LiteLLM. AgentBase manages which provider serves which agent via model aliases. Projects don't import provider SDKs directly. | v0.1-alpha |
| **promptfoo / ragas** | Eval tools integrated in v0.4+. AgentBase provides the test harness and stores results; these tools provide the scoring. | v0.4+ |
| **Vector databases** | Project-specific. AgentBase may provide a standard connection pattern in later versions if multiple projects need it. | Not in scope for v0.1-v0.3 |

---

## 9. Versioning Strategy

### What Gets Versioned

| Artifact | How It's Versioned | Where It Lives |
|----------|-------------------|----------------|
| **Agents** | Version string in registry (e.g., `0.1.0`, `2024-05-16-a`) | AgentBase registry YAML |
| **Prompts** | Git commit SHA or Langfuse prompt version ID | In project code or Langfuse; AgentBase tracks the `prompt_ref` pointer |
| **Models** | Logical alias + exact model ID mapping | AgentBase model config YAML |
| **AgentBase itself** | Semantic versioning (library releases, starting at v0.2 extraction) | AgentBase package repo |
| **Workflows** | Versioned with the owning project | Project repo; registered in AgentBase catalog |

### Comparison Philosophy

- **v0.1:** Know what version is running. Manual comparison when needed.
- **v0.2:** Prompt version tracking enables before/after analysis.
- **v0.3:** Compare two versions of the same agent on the same inputs. Human judges quality.
- **v0.4+:** Automated comparison with eval metrics. CI/CD integration. Performance trends over time.

We deliberately avoid over-formalizing versioning in early phases. Simple version strings beat unused semver processes.

---

## 10. Success Metrics

### By Phase

| Phase | Key Metric | Target |
|-------|-----------|--------|
| **v0.1-alpha** | Time to first traced LLM call | < 2 hours from starting a new project with AgentBase |
| **v0.1-alpha** | Contract compliance | 100% of agents have all required metadata; zero untagged traces |
| **v0.1-beta** | DX satisfaction | First project's team prefers AgentBase over manual setup; no one bypasses it |
| **v0.1-beta** | Config validation | `agentbase validate` catches misconfigs before runtime in CI |
| **v0.2** | Second project adoption | New project adopts AgentBase without hand-holding |
| **v0.2** | Production stability | 4+ weeks in production, zero AgentBase-caused incidents |
| **v0.3** | Migration completeness | All active AI projects running on AgentBase |
| **v0.3** | Cost visibility | "What did AI cost this month, by project?" answered in 5 minutes |
| **v0.3** | Model migration speed | < 1 hour to switch all projects to a new model |
| **v0.4+** | Quality assurance | Zero undetected agent regressions reaching production |
| **v0.4+** | Organizational confidence | Leadership trusts the AI landscape report from AgentBase |

### Anti-Metrics (Signs of Failure)

- AgentBase becomes a bottleneck: projects wait on AgentBase changes to ship their features
- Developers bypass AgentBase because direct setup is easier or more flexible
- The registry is always out of date
- AgentBase tries to do everything and does nothing well
- Existing projects get worse after migration
- The override file is full of entries with reason "because we had to" — sign that defaults are wrong, not that projects are misbehaving

---

## 11. Strategic Opinions

### 11.1 What is the minimum version that a new project can use from day one?

**v0.1-alpha.** A new project needs exactly these four things to be non-negotiable:

1. **Model config + provider abstraction** — so it never hard-codes a model name or imports a provider SDK directly
2. **Langfuse observability pre-wired** — so every LLM call is traced from the first line of code
3. **Cost tagging via the Agent Contract** — so we know what this project costs from week one
4. **Enforced agent metadata** — so the registry is complete and accurate from day one, not backfilled later

v0.1-beta follows quickly with the DX layer (CLI, utilities, overrides, validation). But v0.1-alpha alone is enough to build on. A developer should feel like AgentBase gave them a 2-week head start, not a new constraint.

### 11.2 What should we delay until after the first project proves the need?

| Delay This | Why |
|-----------|-----|
| Cross-project registry features | Only matters when there are 2+ projects |
| Prompt management/storage | Let the first project figure out where prompts should live, then standardize |
| Evaluation framework | Evals are domain-specific. Let the first project define "good" before extracting patterns. |
| Migration tooling | Don't build migration tools until what you're migrating TO is stable |
| Web UI | Langfuse gives us dashboards. Custom UI is only justified when Langfuse can't answer questions that matter. |
| Advanced local dev (cache/replay) | Sounds simple, is complex. Understand real workflows first (v0.1), build the tool second (v0.2). |
| LangSmith adapter | Only if a migrating project in v0.3 actually needs it |

### 11.3 Where are we being too conservative?

1. **Agent registry should be mandatory and enforced from v0.1-alpha, not optional.** Done — the Agent Contract makes this the default.
2. **We should commit to Langfuse now, not hedge.** Done — Langfuse is the only supported backend through v0.2. Architecture is pluggable for later.
3. **The override system should ship in v0.1-beta, not later.** If the first project hits a case where it needs a non-standard setting and can't express it cleanly, they'll hack around AgentBase. The escape hatch prevents that.

### 11.4 Where are we at risk of overbuilding?

| Risk Area | Why We Should Resist |
|-----------|---------------------|
| Custom eval framework | Eval is deeply domain-specific. A generic framework will be unused or misleading. |
| Workflow orchestration | LangGraph exists. Building our own doesn't solve the actual pain (config + visibility). |
| Abstract "BaseAgent" class | Framework trap. Different agents have different shapes. Prefer composition and configuration over inheritance. |
| Approval workflows for agent changes | Bureaucracy disguised as safety. Code review IS the approval process at our scale. |
| Multi-tenant isolation | We're one team. Tagging and filtering in Langfuse is sufficient. |
| Cached local replay in v0.1 | Sounds simple; involves serialization, cache invalidation, streaming edge cases. Get it right in v0.2. |

### 11.5 What should AgentBase become long-term?

**The internal AI operating layer — the single source of truth for how we build, run, observe, and improve all AI capabilities across all products.**

In 12-18 months:
- Every AI agent is registered, versioned, and observable through AgentBase
- Every LLM call is routed through AgentBase's provider layer, giving us complete cost control and instant model migration
- Every prompt has a tracked version, with before/after quality data
- Quality regressions are caught before production
- A new AI product can be bootstrapped in a single day
- Leadership can see the full AI landscape at a glance

Starting a new AI project should feel like plugging into an existing power grid — not building a generator from scratch.

### 11.6 What should be the first new project, and why?

The ideal first project:

| Criteria | Why |
|----------|-----|
| Genuinely new (not a rewrite) | No legacy constraints |
| Has 2-4 distinct agents | Tests multi-agent registry and cost allocation |
| Uses at least 2 different model aliases | Tests provider abstraction |
| Has a "quality matters" dimension | Gives us a reason to eventually add evals |
| Shippable in 4-6 weeks | Production pressure on AgentBase quickly |
| Has real users (internal or external) | Real usage surfaces real problems |

**Do not use a test project or throwaway app.** AgentBase needs production pressure from a real product with real stakes.

### 11.7 Top 3 decisions before writing code

**Decision 1: Langfuse.** Done. Open-source, self-hostable, cheaper. Architecture is pluggable for alternatives later.

**Decision 2: What is the first real project?** Define within 1 week. Build AgentBase and the project concurrently — AgentBase slightly ahead, project closely behind.

**Decision 3: Monorepo, separately importable.** AgentBase and the first project are sibling directories in one repo. AgentBase is imported as a package with a clean boundary. Extract to standalone repo at v0.2.

---

## 12. What We Are NOT Building (at Any Phase)

| Not This | Because |
|----------|---------|
| A LangChain/LangGraph replacement | They handle orchestration. We handle configuration, visibility, and shared infrastructure. Different layers. |
| A custom tracing/observability backend | Langfuse exists. We configure and standardize access to it. |
| A model hosting/serving platform | We use hosted APIs. Self-hosting is a separate initiative if ever needed. |
| An agent marketplace or external platform | AgentBase is internal infrastructure, not a product for sale. |
| A "BaseAgent" class hierarchy | Framework trap. Agents are diverse in implementation, consistent in registration and observability. |
| Approval workflows or change management | Code review is the process. AgentBase provides visibility, not bureaucracy. |
| A LangSmith integration (until v0.3) | One observability backend, done well. Adapter later if a migrating project requires it. |

---

## 13. Open Questions (Remaining)

| # | Question | When to Decide | Suggested Default |
|---|----------|---------------|-------------------|
| 1 | Should AgentBase manage prompt storage or just index/link? | After first project's prompt patterns emerge | Index only. Don't own storage. |
| 2 | How do we handle agent-to-agent communication in multi-agent workflows? | After first project encounters this | Don't. LangGraph handles workflow orchestration. AgentBase handles per-agent config and observability. |
| 3 | When does a web UI become justified? | v0.3+ (when Langfuse provably can't answer key questions) | Not until cross-project comparison is a real workflow |
| 4 | Who owns AgentBase long-term? | Now | Founder-owned in early phases, then dedicated ownership if team grows |
| 5 | What is the first project? | Within 1 week of plan approval | See criteria in 11.6 |

---

## Summary: The Path

```
v0.1-alpha: The structural core. Config + Langfuse + Contract + Registry.
            "Every agent is identified, traced, and cost-tagged from line one."

v0.1-beta:  Developer experience. CLI + utilities + overrides + validation.
            "Building on AgentBase is faster and better than doing it yourself."

v0.2:       Hardened by production. Prompt tracking + fallbacks + local dev + standalone package.
            "A second project can adopt this without help."

v0.3:       Multi-project. Migration + cross-project visibility + cost dashboards.
            "We can see, compare, and manage all AI across all products."

v0.4+:      AI operating system. Evals + quality gates + governance + trends.
            "We don't just run AI — we continuously improve it."
```

The vision is bold: AgentBase as the AI operating layer for everything we build.
The execution is disciplined: prove it with one real project first, then expand from confidence.

---

*This is a living document. Next action: decide the first project (Section 11.7, Decision 2) and begin v0.1-alpha.*
