# AgentBase Observability & Monitoring

LangSmith tracing is wired automatically. Here's how to view and monitor it.

## Viewing Traces

### 1. Go to LangSmith
https://smith.langchain.com/

### 2. Select Your Project
Your project name (from `project:` in `agentbase.yaml`) appears as a project in LangSmith.

Example: If `agentbase.yaml` has `project: portfolio`, go to the "portfolio" project.

### 3. Find Traces
Each LLM call creates a trace. Look for:
- **Generation name:** Matches your `agent_name`
- **Status:** Success or error
- **Latency:** How long the call took
- **Input/Output:** The messages and response
- **Metadata:** Custom metadata from AgentBase

### Example Trace Structure

```
Trace: portfolio_assistant (generation_name)
├── Input: {"messages": [...]}
├── Output: {"response": "..."}
├── Latency: 1.2s
├── Model: gpt-4o-mini
├── Tags: [portfolio, dev, experimental]
└── Metadata:
    ├── agent_version: 0.1.0
    ├── model_id: gpt-4o-mini
    ├── model_alias: smart
    ├── owner: shivam
    └── environment: dev
```

## Understanding Trace Metadata

AgentBase automatically adds metadata to every trace:

| Field | Source | Example |
|-------|--------|---------|
| `generation_name` | agent_name | portfolio_assistant |
| `trace_name` | project/agent_name | portfolio/portfolio_assistant |
| `tags` | project, environment, status | [portfolio, dev, experimental] |
| `agent_version` | agents.yaml | 0.1.0 |
| `model_id` | Resolved at runtime | gpt-4o-mini |
| `model_alias` | agents.yaml | smart |
| `owner` | agents.yaml | shivam |
| `environment` | agentbase.yaml defaults | dev |

## Filtering & Searching

In LangSmith, you can filter traces by:
- **Agent name:** Filter by generation_name
- **Status:** Success or error
- **Latency:** Slow calls
- **Model:** Which model was used
- **Tags:** By project, environment, or status
- **Date range:** Time-based filtering

### Common Filters

**Find all experimental agents:**
Filter by tag = "experimental"

**Find production traces only:**
Filter by tag = "production"

**Find slow calls:**
Filter by latency > 2s

**Find errors:**
Filter by status = "error"

## Dashboards

### Create Your First Dashboard (5 minutes)

Follow these steps to set up a dashboard for monitoring your agents.

**Step 1: Open Dashboards**
1. Go to [smith.langchain.com](https://smith.langchain.com/)
2. Select your project (e.g., "portfolio")
3. Click **Dashboards** in the left sidebar
4. Click **+ Create Dashboard**
5. Name it (e.g., "Agent Overview")

**Step 2: Add Card 1 — Latency by Agent**
1. Click **+ Add card**
2. Choose **Line Chart**
3. Configure:
   - **Measure:** Latency (avg)
   - **Group by:** Name (this groups by generation_name / run_name)
   - **Time range:** Last 7 days
4. **What to look for:** Rising trends, agents slower than 2s

**Step 3: Add Card 2 — Call Volume Over Time**
1. Click **+ Add card**
2. Choose **Bar Chart**
3. Configure:
   - **Measure:** Count
   - **Group by:** Name
   - **Time range:** Last 7 days
4. **What to look for:** Usage spikes, agents with zero calls

**Step 4: Add Card 3 — Error Rate by Agent**
1. Click **+ Add card**
2. Choose **Bar Chart**
3. Configure:
   - **Measure:** Count where status = error
   - **Group by:** Name
   - **Time range:** Last 7 days
4. **What to look for:** Any agent with >1% error rate

**Step 5: Add Card 4 — Cost by Model**
1. Click **+ Add card**
2. Choose **Table**
3. Configure:
   - **Metric:** Total cost (sum of tokens × model rate)
   - **Group by:** Model name (metadata.model_id)
   - **Time range:** Last 30 days
4. **What to look for:** Expensive models, cost per agent

**Step 6: Save**
Click **Save Dashboard** and you're done.

### Dashboard Interpretation

| Card | Metric | Healthy | Warning | Action |
|------|--------|---------|---------|--------|
| **Latency** | avg < 1s | ✓ | > 2s | Investigate agent logic, model choice |
| **Volume** | steady | ✓ | zero calls | Check if agent is unused, retire if deprecated |
| **Errors** | < 1% | ✓ | > 5% | Debug the agent, check logs |
| **Cost** | stable | ✓ | +50% MoM | Consider cheaper model |

### Alternative Metrics

If you want to customize further:

**Percentile latency (P95):**
- Better than avg for catching outliers
- Set **Measure: Latency (p95)** instead of avg

**Success rate:**
- Show percentage of successful calls
- Set **Measure: Count where status = success** / total count

**Cost per call:**
- Divide total cost by call count
- Add custom card: **Cost ÷ Calls**

## Alerts (via API)

LangSmith doesn't have built-in alerts yet, but you can:

1. **Poll LangSmith API** to check for errors/anomalies
2. **Export traces** to a data warehouse (Datadog, Splunk) for alerting
3. **Monitor in your app** and send alerts to Slack/PagerDuty

Example: Check for error rate spike

```python
import requests
from datetime import datetime, timedelta

LANGSMITH_API_KEY = "your_key"
PROJECT = "portfolio"

def check_error_rate():
    # Query LangSmith API for recent errors
    response = requests.get(
        f"https://api.smith.langchain.com/projects/{PROJECT}/runs",
        headers={"X-API-Key": LANGSMITH_API_KEY},
        params={
            "filter": "status = error",
            "limit": 100,
            "createdAtBefore": datetime.now().isoformat(),
            "createdAtAfter": (datetime.now() - timedelta(hours=1)).isoformat(),
        }
    )
    
    errors = response.json()
    if len(errors) > 10:  # More than 10 errors in last hour
        # Send alert to Slack/PagerDuty
        print(f"ALERT: {len(errors)} errors in last hour")
```

## Cost Optimization

LangSmith automatically tracks costs based on tokens + model rates. Use this to identify expensive agents and optimize spend.

### Step 1: Find Your Most Expensive Agents

1. Go to your project in LangSmith
2. Click **Analytics** (top nav)
3. Look for the **Cost** card
4. Click the cost card to drill down by agent/model

You'll see a breakdown like:
- `portfolio_assistant` (gpt-4o-mini): $0.10 / 1000 calls
- `content_writer` (gpt-4o): $1.20 / 1000 calls
- `image_analyzer` (gpt-4-vision): $5.00 / 1000 calls

### Step 2: Decide Whether to Optimize

Use this framework to decide if switching models is worth it:

**Switch to a cheaper model if:**
- Cost per call > $0.05 AND agent is active (used in production)
- Latency difference < 200ms (acceptable to users)
- Quality is similar (no accuracy regression)

**Don't switch if:**
- Agent is experimental (cost < $1/month)
- Model is already the cheapest available
- Quality would degrade noticeably

### Step 3: Test the Change (A/B Testing)

Safe approach: run both models in parallel for a week.

**Example: Switch content_writer from gpt-4 to gpt-4o-mini**

1. Edit `agents.yaml`:
   ```yaml
   agents:
     - agent_name: content_writer
       model_alias: smart           # expensive: gpt-4
     - agent_name: content_writer_fast
       model_alias: fast            # cheap: gpt-4o-mini
   ```

2. Update your app to use both:
   ```python
   # Use fast version for 50% of requests
   if random.random() < 0.5:
       resolved = agentbase.resolve("content_writer_fast")
   else:
       resolved = agentbase.resolve("content_writer")
   ```

3. Run for a week, then in LangSmith:
   - Compare latency: is fast version acceptable?
   - Compare error rates: any regressions?
   - Compare cost: how much are you saving?
   - Manual quality check: read 10 samples from each

4. Decision:
   - **Results good:** Keep the cheap version, remove the expensive one from agents.yaml
   - **Results bad:** Revert to original version

### Step 4: Weekly Cost Review (10 min)

Schedule a 10-minute weekly review to catch cost spikes early:

1. Open LangSmith **Cost** card
2. Look at last 7 days vs. previous week
3. Check for:
   - **New agents** — costs added?
   - **Increased volume** — calls up, costs up proportionally?
   - **Model changes** — did an agent switch to a more expensive model?
4. If costs are up 50%+ from previous week:
   - Drill down to agent level
   - Investigate why (volume or model cost?)
   - Plan optimization if needed

### Cost Attribution by Agent

Once your agents are running, you can track cost per agent:

| Agent | Model | Calls | Avg Cost | Total Cost | % of Budget |
|-------|-------|-------|----------|-----------|-------------|
| portfolio_assistant | gpt-4o-mini | 1000 | $0.10 | $100 | 40% |
| content_writer | gpt-4 | 200 | $1.20 | $240 | 48% |
| image_analyzer | gpt-4-vision | 50 | $5.00 | $250 | 50% |
| **Total** | | **1250** | | **$590** | **~$6/user** |

Use this table to:
- Prioritize which agents to optimize
- Plan quarterly budget
- Show stakeholders where money is spent

### Preventing Cost Surprises

1. **Set spending limits** — LangSmith doesn't enforce limits, so add checks in your app:
   ```python
   monthly_cost = get_cost_from_langsmith(project, month=current_month)
   if monthly_cost > $1000:
       log_alert(f"Monthly cost ${monthly_cost} exceeded budget")
   ```

2. **Monitor model choices** — Ensure experimental agents don't use expensive models
   - Default fast model alias to gpt-4o-mini (cheaper)
   - Reserve gpt-4 for production agents that need it

3. **Regular audits** — Review agents.yaml quarterly:
   - Deprecated agents still running?
   - Experimental agents ready to optimize?
   - Unused models still configured?

## Integrations

LangSmith can send data to:
- **Datadog:** For centralized monitoring
- **Splunk:** For log aggregation
- **Custom webhooks:** For custom integrations

See LangSmith docs for setup: https://docs.smith.langchain.com/

## Troubleshooting

**No traces appearing?**
1. Verify `LANGCHAIN_API_KEY` is set and correct
2. Check `agentbase.yaml` has `tracing: backend: langsmith, enabled: true`
3. Wait 30 seconds (traces upload with delay)
4. Check app logs for `init_tracing()` errors

**Traces missing metadata?**
- Verify `agents.yaml` has all required fields
- Check app logs for validation errors at startup

**Cost seems wrong?**
- Verify correct model IDs in trace metadata
- LangSmith pricing may differ; check their rates

## Best Practices

1. **Use consistent agent names** across environments (same name in dev and production)
2. **Tag by status** (experimental, active, deprecated) to easily filter
3. **Set owner** in agents.yaml to track responsibility
4. **Monitor error rates** by agent weekly
5. **Review costs** weekly to catch expensive agents early
6. **Archive old agents** in LangSmith when deprecated

## Next Steps

- Set up dashboard for your top agents
- Create a weekly cost review process
- Integrate LangSmith data with your BI tool
- Set up alerts for error rate or cost spikes
