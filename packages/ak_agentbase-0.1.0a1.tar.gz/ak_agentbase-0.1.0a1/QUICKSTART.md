# AgentBase Quick Start — For Projects Using AgentBase

## 5-Minute Setup

### 1. Install AgentBase

```bash
pip install agentbase==0.1.0a1
```

### 2. Copy Config Files

Copy from [AgentBase scaffold/](https://github.com/Shivam1904/AgentBase/tree/main/scaffold) to your project root:
- `agentbase.yaml` — Model aliases and tracing settings
- `agents.yaml` — Agent registry

Customize `agentbase.yaml`:
```yaml
project: your-project-name

models:
  fast:
    dev: gpt-4o-mini
    production: gpt-4o
  smart:
    dev: gpt-4o
    production: claude-sonnet-4-20250514

defaults:
  environment: dev
  model_alias: smart

tracing:
  backend: langsmith
  enabled: true  # Set to false if you don't have LANGCHAIN_API_KEY yet
```

Customize `agents.yaml` — add your agents:
```yaml
agents:
  - agent_name: my_analyzer
    model_alias: smart
    owner: your_name
    status: active
    agent_version: "0.1.0"
    prompt_ref: "git:path/to/prompt.py"
    description: "What this agent does"
```

### 3. Set Environment Variables

Create `backend/.env` (or your project's .env):
```bash
# Required for LangSmith tracing
LANGCHAIN_API_KEY=lsv2_pt_xxxxx

# Required for LLM calls
OPENAI_API_KEY=sk-xxxxx
ANTHROPIC_API_KEY=sk-ant-xxxxx

# Optional
LANGSMITH_PROJECT=my-project-dev
```

**Get keys from:**
- [LangSmith API Keys](https://smith.langchain.com/settings/api-keys)
- [OpenAI API Keys](https://platform.openai.com/api-keys)
- [Anthropic API Keys](https://console.anthropic.com/account/keys)

### 4. Initialize AgentBase in Your App

**Django (settings.py):**
```python
import os
from decouple import config
import agentbase

# Load LANGCHAIN_API_KEY from .env before init_tracing
if not os.environ.get("LANGCHAIN_API_KEY"):
    langchain_key = config("LANGCHAIN_API_KEY", default=None)
    if langchain_key:
        os.environ["LANGCHAIN_API_KEY"] = langchain_key

# Initialize AgentBase
agentbase.load_config(
    config_path="agentbase.yaml",
    registry_path="agents.yaml"
)
agentbase.init_tracing()
```

**FastAPI (main.py):**
```python
import os
from decouple import config
import agentbase
from fastapi import FastAPI

# Load LANGCHAIN_API_KEY from .env
if not os.environ.get("LANGCHAIN_API_KEY"):
    langchain_key = config("LANGCHAIN_API_KEY", default=None)
    if langchain_key:
        os.environ["LANGCHAIN_API_KEY"] = langchain_key

# Initialize AgentBase
agentbase.load_config(config_path="agentbase.yaml", registry_path="agents.yaml")
agentbase.init_tracing()

app = FastAPI()
```

**Flask (app.py):**
```python
import os
from decouple import config
import agentbase
from flask import Flask

if not os.environ.get("LANGCHAIN_API_KEY"):
    langchain_key = config("LANGCHAIN_API_KEY", default=None)
    if langchain_key:
        os.environ["LANGCHAIN_API_KEY"] = langchain_key

agentbase.load_config(config_path="agentbase.yaml", registry_path="agents.yaml")
agentbase.init_tracing()

app = Flask(__name__)
```

### 5. Use AgentBase to Resolve Agents

```python
import agentbase
from langchain_openai import ChatOpenAI

# Resolve an agent
resolved = agentbase.resolve("my_analyzer")

# Get model config
llm = ChatOpenAI(
    model=resolved.model_id,
    **resolved.default_params
)

# Use in chains with tracing
chain = my_prompt | llm | output_parser
result = chain.invoke(
    {"input": "test"},
    config=resolved.langchain_config()
)
```

---

## Validation

```bash
# Check config is valid
agentbase validate agentbase.yaml agents.yaml
# Output: ✓ All checks passed

# View resolved agent
python -c "import agentbase; print(agentbase.resolve('my_analyzer'))"
```

---

## Common Issues

| Issue | Solution |
|-------|----------|
| `LANGCHAIN_API_KEY` not found | Set in `.env` and ensure it's loaded in settings BEFORE `agentbase.init_tracing()` |
| Model alias not found | Check spelling in `agentbase.yaml` and `agents.yaml` |
| Agent not found | Run `agentbase validate` to check `agents.yaml` syntax |
| Tracing not appearing | Verify `LANGCHAIN_API_KEY` is valid at https://smith.langchain.com |

---

## What AgentBase Provides

✅ **Model resolution** — `resolved.model_id`, `resolved.default_params`  
✅ **Trace metadata** — `resolved.langchain_config()` for LangSmith  
✅ **Environment management** — Dev/prod model switching  
✅ **Agent validation** — `agentbase validate` CLI  
✅ **Zero dependencies on frameworks** — Works with any LLM client  

---

## Next Steps

- [Full Architecture Guide](https://github.com/Shivam1904/AgentBase/blob/main/CLAUDE.md)
- [Publishing Guide](PUBLISH.md)
- [Integration Examples](https://github.com/Shivam1904/AgentBase/tree/main/scaffold)
