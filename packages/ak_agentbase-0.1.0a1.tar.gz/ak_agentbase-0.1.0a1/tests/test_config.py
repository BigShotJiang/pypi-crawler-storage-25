from pathlib import Path

import pytest

from agentbase.config import _config_cache, get_environment, load_config
from agentbase.exceptions import ConfigValidationError

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def clear_cache():
    _config_cache.clear()
    yield
    _config_cache.clear()


def test_valid_config_loads():
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    assert config.project == "brainboard"
    assert "dev" in config.environments
    assert "production" in config.environments
    assert "fast" in config.models
    assert "smart" in config.models


def test_valid_config_model_resolution():
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    assert config.models["fast"].environments["dev"] == "gpt-4o-mini"
    assert config.models["smart"].environments["production"] == "claude-sonnet-4-20250514"
    assert config.models["fast"].default_params["temperature"] == 0.3


def test_valid_config_defaults():
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    assert config.defaults.environment == "dev"
    assert config.defaults.model_alias == "smart"


def test_missing_project_raises():
    with pytest.raises(ConfigValidationError, match="project"):
        load_config(FIXTURES / "agentbase_no_project.yaml")


def test_missing_env_mapping_raises():
    with pytest.raises(ConfigValidationError, match="production"):
        load_config(FIXTURES / "agentbase_missing_env_mapping.yaml")


def test_env_var_interpolation(monkeypatch):
    monkeypatch.setenv("TEST_MODEL_ID", "gpt-4o-mini")
    config = load_config(FIXTURES / "agentbase_with_env_vars.yaml")
    assert config.models["fast"].environments["dev"] == "gpt-4o-mini"


def test_missing_env_var_raises(monkeypatch):
    monkeypatch.delenv("TEST_MODEL_ID", raising=False)
    with pytest.raises(ConfigValidationError, match="TEST_MODEL_ID"):
        load_config(FIXTURES / "agentbase_with_env_vars.yaml")


def test_config_is_cached():
    config1 = load_config(FIXTURES / "agentbase_valid.yaml")
    config2 = load_config(FIXTURES / "agentbase_valid.yaml")
    assert config1 is config2


def test_file_not_found_raises():
    with pytest.raises(ConfigValidationError, match="not found"):
        load_config("/nonexistent/path/agentbase.yaml")


def test_get_environment_from_env_var(monkeypatch):
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    monkeypatch.setenv("AGENTBASE_ENV", "production")
    assert get_environment(config) == "production"


def test_get_environment_from_default(monkeypatch):
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    assert get_environment(config) == "dev"


def test_tracing_defaults_to_none_when_not_specified():
    config = load_config(FIXTURES / "agentbase_valid.yaml")
    assert config.tracing.backend == "none"
    assert config.tracing.enabled is True
