import pytest
from pydantic import ValidationError

from agentbase.types import (
    AgentBaseConfig,
    AgentMetadata,
    AgentStatus,
    ModelAliasConfig,
    ResolvedAgent,
    TracingConfig,
)


def test_agent_status_values():
    assert AgentStatus.experimental == "experimental"
    assert AgentStatus.active == "active"
    assert AgentStatus.deprecated == "deprecated"


def test_agent_metadata_valid():
    agent = AgentMetadata(
        project="brainboard",
        environment="dev",
        agent_name="quiz_generator",
        agent_version="0.1.0",
        model_alias="fast",
        prompt_ref="inline",
        owner="shivam",
        status=AgentStatus.experimental,
    )
    assert agent.agent_name == "quiz_generator"
    assert agent.status == AgentStatus.experimental


def test_agent_metadata_status_from_string():
    agent = AgentMetadata(
        project="brainboard",
        environment="dev",
        agent_name="quiz_generator",
        agent_version="0.1.0",
        model_alias="fast",
        prompt_ref="inline",
        owner="shivam",
        status="active",
    )
    assert agent.status == AgentStatus.active


def test_agent_metadata_invalid_status():
    with pytest.raises(ValidationError):
        AgentMetadata(
            project="brainboard",
            environment="dev",
            agent_name="quiz_generator",
            agent_version="0.1.0",
            model_alias="fast",
            prompt_ref="inline",
            owner="shivam",
            status="invalid_status",
        )


def test_agent_metadata_missing_required_field():
    with pytest.raises(ValidationError):
        AgentMetadata(
            project="brainboard",
            environment="dev",
            agent_name="quiz_generator",
            agent_version="0.1.0",
            model_alias="fast",
            prompt_ref="inline",
            # owner missing
            status=AgentStatus.experimental,
        )


def test_model_alias_config():
    config = ModelAliasConfig(
        environments={"dev": "gpt-4o-mini", "production": "claude-sonnet-4-20250514"},
        default_params={"temperature": 0.5, "max_tokens": 4096},
    )
    assert config.environments["dev"] == "gpt-4o-mini"
    assert config.default_params["temperature"] == 0.5


def test_model_alias_config_empty_params():
    config = ModelAliasConfig(environments={"dev": "gpt-4o-mini"})
    assert config.default_params == {}


def test_agentbase_config_valid():
    config = AgentBaseConfig(
        project="brainboard",
        models={
            "fast": ModelAliasConfig(
                environments={"dev": "gpt-4o-mini", "production": "gpt-4o-mini"}
            ),
            "smart": ModelAliasConfig(
                environments={"dev": "gpt-4o-mini", "production": "claude-sonnet-4-20250514"}
            ),
        },
    )
    assert config.project == "brainboard"
    assert config.defaults.environment == "dev"
    assert config.defaults.model_alias == "smart"
    assert "dev" in config.environments
    assert "production" in config.environments


def test_agentbase_config_missing_project():
    with pytest.raises(ValidationError):
        AgentBaseConfig(
            models={"fast": ModelAliasConfig(environments={"dev": "gpt-4o-mini"})},
        )


def test_resolved_agent():
    resolved = ResolvedAgent(
        agent_name="quiz_generator",
        model_id="gpt-4o-mini",
        default_params={"temperature": 0.3},
        trace_metadata={"generation_name": "quiz_generator"},
    )
    assert resolved.model_id == "gpt-4o-mini"
    assert resolved.default_params["temperature"] == 0.3


def test_resolved_agent_defaults():
    resolved = ResolvedAgent(agent_name="quiz_generator", model_id="gpt-4o-mini")
    assert resolved.default_params == {}
    assert resolved.trace_metadata == {}


def test_resolved_agent_langchain_config():
    resolved = ResolvedAgent(
        agent_name="quiz_generator",
        model_id="gpt-4o-mini",
        trace_metadata={
            "generation_name": "quiz_generator",
            "tags": ["portfolio", "dev", "experimental"],
            "metadata": {"project": "portfolio", "model_id": "gpt-4o-mini"},
        },
    )
    config = resolved.langchain_config()
    assert config["run_name"] == "quiz_generator"
    assert "portfolio" in config["tags"]
    assert config["metadata"]["project"] == "portfolio"


def test_resolved_agent_langchain_config_fallback():
    resolved = ResolvedAgent(agent_name="quiz_generator", model_id="gpt-4o-mini")
    config = resolved.langchain_config()
    assert config["run_name"] == "quiz_generator"
    assert config["tags"] == []
    assert config["metadata"] == {}


def test_tracing_config_defaults():
    tc = TracingConfig()
    assert tc.backend == "none"
    assert tc.enabled is True


def test_tracing_config_langsmith():
    tc = TracingConfig(backend="langsmith", enabled=True)
    assert tc.backend == "langsmith"


def test_agentbase_config_with_tracing():
    config = AgentBaseConfig(
        project="portfolio",
        models={"fast": ModelAliasConfig(environments={"dev": "gpt-4o-mini"})},
        tracing=TracingConfig(backend="langsmith"),
    )
    assert config.tracing.backend == "langsmith"


def test_agentbase_config_tracing_defaults_to_none():
    config = AgentBaseConfig(
        project="portfolio",
        models={"fast": ModelAliasConfig(environments={"dev": "gpt-4o-mini"})},
    )
    assert config.tracing.backend == "none"
