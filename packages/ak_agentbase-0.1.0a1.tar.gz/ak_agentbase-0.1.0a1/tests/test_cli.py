import subprocess
from pathlib import Path

import pytest

from agentbase.cli import _validate

FIXTURES = Path(__file__).parent / "fixtures"


class TestValidateFunction:
    """Unit tests for _validate() function."""

    def test_validate_valid_config(self):
        """Valid config and agents should return True."""
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is True

    def test_validate_missing_config_file(self):
        """Missing config file should return False."""
        result = _validate(
            str(FIXTURES / "nonexistent.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is False

    def test_validate_missing_registry_file(self):
        """Missing registry file should return False."""
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "nonexistent.yaml"),
        )
        assert result is False

    def test_validate_no_project_field(self):
        """Config missing 'project' field should return False."""
        result = _validate(
            str(FIXTURES / "agentbase_no_project.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is False

    def test_validate_unknown_model_alias(self):
        """Agent with undefined model alias should return False."""
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "agents_unknown_alias.yaml"),
        )
        assert result is False

    def test_validate_missing_contract_field(self):
        """Agent missing required contract field should return False."""
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "agents_missing_owner.yaml"),
        )
        assert result is False

    def test_validate_duplicate_agent_names(self):
        """Duplicate agent names should return False."""
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "agents_duplicate.yaml"),
        )
        assert result is False

    def test_validate_tracing_with_key_set(self, monkeypatch):
        """Tracing enabled with LANGCHAIN_API_KEY set should pass."""
        monkeypatch.setenv("LANGCHAIN_API_KEY", "test-key")
        result = _validate(
            str(FIXTURES / "agentbase_with_tracing.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is True

    def test_validate_tracing_without_key(self, monkeypatch):
        """Tracing enabled without LANGCHAIN_API_KEY should fail."""
        monkeypatch.delenv("LANGCHAIN_API_KEY", raising=False)
        result = _validate(
            str(FIXTURES / "agentbase_with_tracing.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is False

    def test_validate_tracing_disabled(self, monkeypatch):
        """Tracing disabled should not require LANGCHAIN_API_KEY."""
        monkeypatch.delenv("LANGCHAIN_API_KEY", raising=False)
        # agentbase_valid.yaml has tracing disabled by default
        result = _validate(
            str(FIXTURES / "agentbase_valid.yaml"),
            str(FIXTURES / "agents_valid.yaml"),
        )
        assert result is True


class TestCliCommand:
    """Integration tests for agentbase validate CLI command."""

    def test_validate_command_valid_config(self):
        """Valid config should exit with code 0."""
        result = subprocess.run(
            [
                "python",
                "-m",
                "agentbase",
                "validate",
                str(FIXTURES / "agentbase_valid.yaml"),
                str(FIXTURES / "agents_valid.yaml"),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "✓" in result.stdout
        assert "All checks passed" in result.stdout

    def test_validate_command_invalid_config(self):
        """Invalid config should exit with code 1."""
        result = subprocess.run(
            [
                "python",
                "-m",
                "agentbase",
                "validate",
                str(FIXTURES / "agentbase_no_project.yaml"),
                str(FIXTURES / "agents_valid.yaml"),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "✗" in result.stdout

    def test_validate_command_missing_file(self):
        """Missing file should exit with code 1."""
        result = subprocess.run(
            [
                "python",
                "-m",
                "agentbase",
                "validate",
                str(FIXTURES / "nonexistent.yaml"),
                str(FIXTURES / "agents_valid.yaml"),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "✗" in result.stdout

    def test_validate_command_defaults(self):
        """validate without args should use agentbase.yaml and agents.yaml."""
        result = subprocess.run(
            ["python", "-m", "agentbase", "validate"],
            capture_output=True,
            text=True,
            cwd=str(FIXTURES),
        )
        # Will fail because we're in fixtures/ and it looks for agentbase.yaml
        # (which doesn't exist in fixtures root), but that's okay — we're testing
        # that it uses the defaults, not that they're found
        assert "agentbase.yaml" in result.stdout or "agentbase.yaml" in result.stderr

    def test_validate_command_help(self):
        """validate --help should show help text."""
        result = subprocess.run(
            ["python", "-m", "agentbase", "validate", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "agentbase.yaml" in result.stdout
        assert "agents.yaml" in result.stdout
