from pathlib import Path

import pytest

import agentbase
from agentbase.exceptions import AgentBaseError, AgentNotRegisteredError
from agentbase.types import ResolvedAgent

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def reset_agentbase_state():
    agentbase._config = None
    agentbase._registry = None
    agentbase._environment = None
    from agentbase.config import _config_cache
    from agentbase.registry import _registry_cache

    _config_cache.clear()
    _registry_cache.clear()
    yield
    agentbase._config = None
    agentbase._registry = None
    agentbase._environment = None
    _config_cache.clear()
    _registry_cache.clear()


def test_imports():
    from agentbase import load_config, resolve  # noqa: F401


def test_load_config_returns_config():
    config = agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    assert config.project == "brainboard"


def test_resolve_before_init_raises():
    with pytest.raises(AgentBaseError, match="load_config"):
        agentbase.resolve("quiz_generator")


def test_resolve_after_init(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("quiz_generator")
    assert isinstance(result, ResolvedAgent)
    assert result.model_id == "gpt-4o-mini"
    assert result.agent_name == "quiz_generator"


def test_resolve_unknown_agent_raises():
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    with pytest.raises(AgentNotRegisteredError):
        agentbase.resolve("nonexistent")


def test_resolve_includes_trace_metadata(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("quiz_generator")
    assert result.trace_metadata["generation_name"] == "quiz_generator"
    assert "brainboard" in result.trace_metadata["tags"]


def test_init_tracing_before_load_config_raises():
    with pytest.raises(AgentBaseError, match="load_config"):
        agentbase.init_tracing()


def test_init_tracing_none_backend_is_noop(monkeypatch):
    monkeypatch.delenv("LANGCHAIN_TRACING_V2", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    agentbase.init_tracing()  # backend=none — should not raise or set env vars
    import os

    assert os.environ.get("LANGCHAIN_TRACING_V2") is None


def test_version():
    assert isinstance(agentbase.__version__, str)
