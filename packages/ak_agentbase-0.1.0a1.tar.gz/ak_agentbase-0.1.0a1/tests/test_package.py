import agentbase


def test_version():
    assert isinstance(agentbase.__version__, str)
    assert len(agentbase.__version__) > 0
