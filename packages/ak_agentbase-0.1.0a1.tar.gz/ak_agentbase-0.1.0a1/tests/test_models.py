from pathlib import Path

import pytest

from agentbase.config import _config_cache, load_config
from agentbase.exceptions import AgentNotRegisteredError, ModelResolutionError
from agentbase.models import resolve, resolve_model
from agentbase.registry import _registry_cache, load_registry
from agentbase.types import ResolvedAgent

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def clear_caches():
    _config_cache.clear()
    _registry_cache.clear()
    yield
    _config_cache.clear()
    _registry_cache.clear()


@pytest.fixture()
def config():
    return load_config(FIXTURES / "agentbase_valid.yaml")


@pytest.fixture()
def registry(config):
    return load_registry(FIXTURES / "agents_valid.yaml", config, "dev")


def test_resolve_model_dev(config, registry):
    agent = registry["content_summarizer"]  # model_alias: smart
    model_id = resolve_model(agent, config, "dev")
    assert model_id == "gpt-4o-mini"


def test_resolve_model_production(config, registry):
    agent = registry["content_summarizer"]  # model_alias: smart
    model_id = resolve_model(agent, config, "production")
    assert model_id == "claude-sonnet-4-20250514"


def test_resolve_model_unknown_environment(config, registry):
    agent = registry["quiz_generator"]
    with pytest.raises(ModelResolutionError) as exc_info:
        resolve_model(agent, config, "staging")
    assert "fast" in str(exc_info.value)
    assert "staging" in str(exc_info.value)


def test_resolve_returns_resolved_agent(config, registry):
    result = resolve("quiz_generator", registry, config, "dev")
    assert isinstance(result, ResolvedAgent)


def test_resolve_model_id(config, registry):
    result = resolve("quiz_generator", registry, config, "dev")
    assert result.model_id == "gpt-4o-mini"


def test_resolve_agent_name(config, registry):
    result = resolve("quiz_generator", registry, config, "dev")
    assert result.agent_name == "quiz_generator"


def test_resolve_dev_vs_production(config, registry):
    dev = resolve("content_summarizer", registry, config, "dev")
    prod_registry = load_registry(FIXTURES / "agents_valid.yaml", config, "production")
    prod = resolve("content_summarizer", prod_registry, config, "production")
    assert dev.model_id == "gpt-4o-mini"
    assert prod.model_id == "claude-sonnet-4-20250514"


def test_resolve_applies_default_params(config, registry):
    result = resolve("quiz_generator", registry, config, "dev")
    assert result.default_params["temperature"] == 0.3
    assert result.default_params["max_tokens"] == 1024


def test_resolve_includes_trace_metadata(config, registry):
    result = resolve("quiz_generator", registry, config, "dev")
    assert result.trace_metadata["generation_name"] == "quiz_generator"
    assert "brainboard" in result.trace_metadata["tags"]
    assert result.trace_metadata["metadata"]["model_id"] == "gpt-4o-mini"


def test_resolve_unregistered_agent_raises(config, registry):
    with pytest.raises(AgentNotRegisteredError):
        resolve("nonexistent_agent", registry, config, "dev")


def test_resolve_unknown_environment_raises(config, registry):
    with pytest.raises(ModelResolutionError):
        resolve("quiz_generator", registry, config, "staging")


def test_resolve_uses_agentbase_env(config, registry, monkeypatch):
    monkeypatch.setenv("AGENTBASE_ENV", "production")
    result = resolve("content_summarizer", registry, config)
    assert result.model_id == "claude-sonnet-4-20250514"


def test_resolve_uses_config_default_env(config, registry, monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    result = resolve("content_summarizer", registry, config)
    assert result.model_id == "gpt-4o-mini"  # dev default
