from pathlib import Path

import pytest

from agentbase.config import _config_cache, load_config
from agentbase.exceptions import (
    AgentNotRegisteredError,
    ConfigValidationError,
    ContractViolationError,
)
from agentbase.registry import _registry_cache, get_agent, load_registry
from agentbase.types import AgentStatus

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def clear_caches():
    _config_cache.clear()
    _registry_cache.clear()
    yield
    _config_cache.clear()
    _registry_cache.clear()


@pytest.fixture()
def config():
    return load_config(FIXTURES / "agentbase_valid.yaml")


def test_valid_registry_loads(config):
    registry = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    assert "quiz_generator" in registry
    assert "content_summarizer" in registry
    assert "idea_generator" in registry


def test_agent_metadata_fields(config):
    registry = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    agent = registry["quiz_generator"]
    assert agent.agent_name == "quiz_generator"
    assert agent.agent_version == "0.1.0"
    assert agent.model_alias == "fast"
    assert agent.prompt_ref == "inline"
    assert agent.owner == "shivam"
    assert agent.status == AgentStatus.experimental
    assert agent.project == "brainboard"
    assert agent.environment == "dev"


def test_project_and_environment_injected_from_config(config):
    registry = load_registry(FIXTURES / "agents_valid.yaml", config, "production")
    agent = registry["content_summarizer"]
    assert agent.project == "brainboard"
    assert agent.environment == "production"


def test_missing_owner_raises_contract_violation(config):
    with pytest.raises(ContractViolationError) as exc_info:
        load_registry(FIXTURES / "agents_missing_owner.yaml", config, "dev")
    assert "quiz_generator" in str(exc_info.value)
    assert "owner" in str(exc_info.value)


def test_unknown_model_alias_raises(config):
    with pytest.raises(ConfigValidationError, match="turbo"):
        load_registry(FIXTURES / "agents_unknown_alias.yaml", config, "dev")


def test_duplicate_agent_name_raises(config):
    with pytest.raises(ConfigValidationError, match="quiz_generator"):
        load_registry(FIXTURES / "agents_duplicate.yaml", config, "dev")


def test_file_not_found_raises(config):
    with pytest.raises(ConfigValidationError, match="not found"):
        load_registry("/nonexistent/agents.yaml", config, "dev")


def test_get_agent_returns_metadata(config):
    registry = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    agent = get_agent("content_summarizer", registry)
    assert agent.agent_name == "content_summarizer"


def test_get_agent_unknown_raises(config):
    registry = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    with pytest.raises(AgentNotRegisteredError) as exc_info:
        get_agent("nonexistent_agent", registry)
    assert "nonexistent_agent" in str(exc_info.value)


def test_registry_is_cached(config):
    r1 = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    r2 = load_registry(FIXTURES / "agents_valid.yaml", config, "dev")
    assert r1 is r2
