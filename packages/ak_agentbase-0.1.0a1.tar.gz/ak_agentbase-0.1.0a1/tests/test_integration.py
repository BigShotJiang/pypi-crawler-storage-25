"""
Integration tests — verify end-to-end resolve() flow with real fixtures.
No external services required.
"""

from pathlib import Path

import pytest

import agentbase
from agentbase.config import _config_cache
from agentbase.registry import _registry_cache
from agentbase.types import ResolvedAgent

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def reset_state():
    agentbase._config = None
    agentbase._registry = None
    agentbase._environment = None
    _config_cache.clear()
    _registry_cache.clear()
    yield
    agentbase._config = None
    agentbase._registry = None
    agentbase._environment = None
    _config_cache.clear()
    _registry_cache.clear()


def test_resolve_returns_correct_model_in_dev(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("quiz_generator")
    assert isinstance(result, ResolvedAgent)
    assert result.model_id == "gpt-4o-mini"
    assert result.agent_name == "quiz_generator"


def test_resolve_returns_correct_model_in_production(monkeypatch):
    monkeypatch.setenv("AGENTBASE_ENV", "production")
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("content_summarizer")
    assert result.model_id == "claude-sonnet-4-20250514"


def test_resolve_trace_metadata_structure(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("quiz_generator")
    meta = result.trace_metadata

    assert meta["generation_name"] == "quiz_generator"
    assert meta["trace_name"] == "brainboard/quiz_generator"
    assert "brainboard" in meta["tags"]
    assert "dev" in meta["tags"]
    assert meta["metadata"]["project"] == "brainboard"
    assert meta["metadata"]["model_id"] == "gpt-4o-mini"
    assert meta["metadata"]["owner"] == "shivam"


def test_resolve_default_params_passed_through(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    result = agentbase.resolve("quiz_generator")
    assert result.default_params["temperature"] == 0.3
    assert result.default_params["max_tokens"] == 1024


def test_switching_environment_resolves_different_model(monkeypatch):
    monkeypatch.delenv("AGENTBASE_ENV", raising=False)
    agentbase.load_config(
        config_path=FIXTURES / "agentbase_valid.yaml",
        registry_path=FIXTURES / "agents_valid.yaml",
    )
    dev_result = agentbase.resolve("content_summarizer", environment="dev")
    prod_result = agentbase.resolve("content_summarizer", environment="production")
    assert dev_result.model_id != prod_result.model_id
    assert prod_result.model_id == "claude-sonnet-4-20250514"
