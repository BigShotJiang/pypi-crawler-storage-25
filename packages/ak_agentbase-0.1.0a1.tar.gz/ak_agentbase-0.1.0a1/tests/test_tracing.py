import os

import pytest

from agentbase.exceptions import ConfigValidationError
from agentbase.tracing import _init_langsmith, build_trace_metadata, init_tracing
from agentbase.types import (
    AgentBaseConfig,
    AgentMetadata,
    AgentStatus,
    ModelAliasConfig,
    TracingConfig,
)


def _make_config(backend: str = "none", enabled: bool = True) -> AgentBaseConfig:
    return AgentBaseConfig(
        project="test-project",
        models={"fast": ModelAliasConfig(environments={"dev": "gpt-4o-mini"})},
        tracing=TracingConfig(backend=backend, enabled=enabled),
    )


def test_build_trace_metadata():
    agent = AgentMetadata(
        project="writerverse",
        environment="dev",
        agent_name="quiz_generator",
        agent_version="0.1.0",
        model_alias="fast",
        prompt_ref="inline",
        owner="shivam",
        status=AgentStatus.experimental,
    )
    meta = build_trace_metadata(agent, "gpt-4o-mini")

    assert meta["generation_name"] == "quiz_generator"
    assert meta["trace_name"] == "writerverse/quiz_generator"
    assert "dev" in meta["tags"]
    assert "writerverse" in meta["tags"]
    assert "experimental" in meta["tags"]
    assert meta["metadata"]["agent_version"] == "0.1.0"
    assert meta["metadata"]["model_id"] == "gpt-4o-mini"
    assert meta["metadata"]["model_alias"] == "fast"
    assert meta["metadata"]["owner"] == "shivam"


def test_build_trace_metadata_production():
    agent = AgentMetadata(
        project="writerverse",
        environment="production",
        agent_name="content_writer",
        agent_version="1.2.0",
        model_alias="smart",
        prompt_ref="prompts/content_writer_v2",
        owner="shivam",
        status=AgentStatus.active,
    )
    meta = build_trace_metadata(agent, "claude-sonnet-4-20250514")

    assert meta["trace_name"] == "writerverse/content_writer"
    assert "production" in meta["tags"]
    assert "active" in meta["tags"]
    assert meta["metadata"]["model_id"] == "claude-sonnet-4-20250514"
    assert meta["metadata"]["environment"] == "production"


def test_init_tracing_none_is_noop(monkeypatch):
    monkeypatch.delenv("LANGCHAIN_TRACING_V2", raising=False)
    config = _make_config(backend="none")
    init_tracing(config)
    assert os.environ.get("LANGCHAIN_TRACING_V2") is None


def test_init_tracing_disabled_is_noop(monkeypatch):
    monkeypatch.delenv("LANGCHAIN_TRACING_V2", raising=False)
    config = _make_config(backend="langsmith", enabled=False)
    init_tracing(config)
    assert os.environ.get("LANGCHAIN_TRACING_V2") is None


def test_init_tracing_langsmith_sets_env_vars(monkeypatch):
    monkeypatch.setenv("LANGCHAIN_API_KEY", "ls-fake-key")
    monkeypatch.delenv("LANGCHAIN_TRACING_V2", raising=False)
    monkeypatch.delenv("LANGCHAIN_PROJECT", raising=False)
    config = _make_config(backend="langsmith")
    init_tracing(config)
    assert os.environ["LANGCHAIN_TRACING_V2"] == "true"
    assert os.environ["LANGCHAIN_PROJECT"] == "test-project"


def test_init_tracing_langsmith_missing_key_raises(monkeypatch):
    monkeypatch.delenv("LANGCHAIN_API_KEY", raising=False)
    config = _make_config(backend="langsmith")
    with pytest.raises(ConfigValidationError, match="LANGCHAIN_API_KEY"):
        init_tracing(config)


def test_init_tracing_unknown_backend_raises():
    config = _make_config(backend="datadog")
    with pytest.raises(ConfigValidationError, match="datadog"):
        init_tracing(config)


def test_init_langsmith_sets_project(monkeypatch):
    monkeypatch.setenv("LANGCHAIN_API_KEY", "ls-fake-key")
    _init_langsmith("my-project")
    assert os.environ["LANGCHAIN_PROJECT"] == "my-project"
    assert os.environ["LANGCHAIN_TRACING_V2"] == "true"
