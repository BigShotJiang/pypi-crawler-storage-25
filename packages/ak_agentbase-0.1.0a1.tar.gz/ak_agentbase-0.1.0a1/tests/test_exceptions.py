import pytest

from agentbase.exceptions import (
    AgentBaseError,
    AgentNotRegisteredError,
    ConfigValidationError,
    ContractViolationError,
    ModelResolutionError,
)


def test_exception_hierarchy():
    assert issubclass(ConfigValidationError, AgentBaseError)
    assert issubclass(AgentNotRegisteredError, AgentBaseError)
    assert issubclass(ContractViolationError, AgentBaseError)
    assert issubclass(ModelResolutionError, AgentBaseError)


def test_config_validation_error_message():
    err = ConfigValidationError("project field is required in agentbase.yaml")
    assert "project field is required" in str(err)


def test_agent_not_registered_error():
    err = AgentNotRegisteredError("quiz_generator")
    assert "quiz_generator" in str(err)
    assert err.agent_name == "quiz_generator"


def test_contract_violation_error():
    err = ContractViolationError("quiz_generator", "owner")
    assert "quiz_generator" in str(err)
    assert "owner" in str(err)
    assert err.agent_name == "quiz_generator"
    assert err.missing_field == "owner"


def test_model_resolution_error():
    err = ModelResolutionError("smart", "staging")
    assert "smart" in str(err)
    assert "staging" in str(err)
    assert err.alias == "smart"
    assert err.environment == "staging"


def test_exceptions_are_catchable_as_base():
    with pytest.raises(AgentBaseError):
        raise AgentNotRegisteredError("some_agent")

    with pytest.raises(AgentBaseError):
        raise ContractViolationError("some_agent", "owner")
