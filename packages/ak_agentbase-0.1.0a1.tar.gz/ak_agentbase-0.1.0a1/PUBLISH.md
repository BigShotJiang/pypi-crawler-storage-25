# Publishing AgentBase to PyPI

## Prerequisites

Install build and publishing tools:
```bash
pip install build twine
```

## Step-by-Step Publishing

### 1. Verify Tests Pass
```bash
cd /Users/shivam/Documents/github/AgentBase
python -m pytest tests/ -v
```

### 2. Update Version (if needed)
Edit `pyproject.toml`:
```toml
version = "0.1.0a2"  # or next version
```

### 3. Create Distribution Packages
```bash
python -m build
```

This creates:
- `dist/agentbase-0.1.0a1.tar.gz` (source distribution)
- `dist/agentbase-0.1.0a1-py3-none-any.whl` (wheel)

### 4. Upload to PyPI

**For public PyPI (requires PyPI account):**
```bash
python -m twine upload dist/* -u __token__ -p YOUR_PYPI_TOKEN
```

Get token from: https://pypi.org/manage/account/tokens/

**For test PyPI (recommended for first-time):**
```bash
python -m twine upload -r testpypi dist/* -u __token__ -p YOUR_TEST_PYPI_TOKEN
```

Test account: https://test.pypi.org/manage/account/tokens/

### 5. Verify Installation

After publishing to PyPI:
```bash
pip install agentbase==0.1.0a1
```

---

## How Projects Use AgentBase

### Installation

In project's `requirements.txt`:
```
agentbase==0.1.0a1
```

Or in `pyproject.toml`:
```toml
dependencies = [
    "agentbase==0.1.0a1",
]
```

Then:
```bash
pip install -r requirements.txt
# or
pip install .
```

### Project Setup (backend/.env)

```bash
# === AGENTBASE ===
LANGCHAIN_API_KEY=lsv2_pt_xxxxx
LANGSMITH_PROJECT=my-project-name
```

### Project Code (settings.py or main entry point)

```python
import os
from decouple import config
import agentbase

# Load LANGCHAIN_API_KEY from .env
if not os.environ.get("LANGCHAIN_API_KEY"):
    langchain_key = config("LANGCHAIN_API_KEY", default=None)
    if langchain_key:
        os.environ["LANGCHAIN_API_KEY"] = langchain_key

# Initialize AgentBase
agentbase.load_config(
    config_path="agentbase.yaml",
    registry_path="agents.yaml"
)
agentbase.init_tracing()

# Now use in your code
resolved = agentbase.resolve("agent_name")
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
```

### Project File Structure

```
my-project/
  agentbase.yaml          ← Copy from AgentBase scaffold/
  agents.yaml             ← Copy from AgentBase scaffold/
  backend/
    .env                  ← Project-specific (git-ignored)
    .env.example          ← Template (committed)
    requirements.txt      ← Includes: agentbase==0.1.0a1
    config/
      settings.py         ← Load LANGCHAIN_API_KEY before agentbase.init_tracing()
```

---

## Environment Variables Required

| Variable | Purpose | Example |
|----------|---------|---------|
| `LANGCHAIN_API_KEY` | LangSmith API key for tracing | `lsv2_pt_...` |
| `OPENAI_API_KEY` | OpenAI API key (if using gpt-4o) | `sk-...` |
| `ANTHROPIC_API_KEY` | Anthropic API key (if using Claude) | `sk-ant-...` |

**Note:** `LANGCHAIN_API_KEY` is only required if `tracing.enabled: true` in `agentbase.yaml`.

---

## Deployment Checklist

- [ ] Version bumped in `pyproject.toml`
- [ ] Tests pass: `pytest tests/`
- [ ] Distribution built: `python -m build`
- [ ] Uploaded to PyPI: `twine upload dist/*`
- [ ] Installation verified: `pip install agentbase==X.Y.Za#`
- [ ] Documented in project's README
- [ ] `requirements.txt` updated in each project
- [ ] `.env.example` created in each project with required vars
- [ ] Django/Flask settings load `LANGCHAIN_API_KEY` before `agentbase.init_tracing()`

---

## Rollback

If an issue is found after publishing:
1. Fix the bug in AgentBase
2. Bump version (e.g., `0.1.0a2`)
3. Rebuild and republish
4. Update projects to new version

Never delete a published version from PyPI (breaks installations).
