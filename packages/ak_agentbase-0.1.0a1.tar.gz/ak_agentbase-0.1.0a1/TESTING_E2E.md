# End-to-End Testing Guide

This guide verifies that AgentBase is properly integrated with shivam-portfolio and tracing is working end-to-end.

## Prerequisites

✓ AgentBase fully implemented (81 tests passing)
✓ shivam-portfolio API and frontend set up
✓ LANGCHAIN_API_KEY configured in `api/.env` (LangSmith credentials)
✓ Dependencies installed (`make install` or `pip install -r api/requirements.txt` + `npm install`)

## Testing Steps

### 1. Start Both Servers

```bash
cd /Users/shivam/Documents/github/shivam-portfolio
make dev
```

This will start:
- FastAPI API on `http://localhost:8001`
- Vite frontend on `http://localhost:5174` (or similar)

Wait for both to indicate they're ready. You should see:
- FastAPI: "Uvicorn running on http://127.0.0.1:8001"
- Vite: "Local: http://localhost:517X"

### 2. Test API Health

In another terminal:
```bash
curl http://localhost:8001/health
```

Expected response:
```json
{"status": "ok"}
```

### 3. Open the Chat Widget

Navigate to `http://localhost:5174` (or the actual Vite port) in your browser.

You should see a floating chat button in the bottom-right corner (AWS Console style).

### 4. Send a Test Message

Click the chat button to expand the widget. Type a message like:
```
What projects has Shivam worked on?
```

Press Enter. You should see:
- The message appears on the left (user message)
- The assistant response streams in on the right
- Chunks appear as they arrive (streaming response)
- Full response completes with "[DONE]"

### 5. Verify LangSmith Tracing

Go to https://smith.langchain.com/ and check the "AgentBase" project:

**Expected trace structure:**
- **Generation name:** `portfolio_assistant`
- **Tags:** `["portfolio", "dev", "experimental"]`
- **Metadata:**
  - `agent_version`: "0.1.0"
  - `model_id`: "gpt-4o-mini"
  - `model_alias`: "fast"
  - `owner`: "shivam"
  - `environment`: "dev"

**Trace should show:**
- Input: The user message
- Output: The full response from the LLM
- Timing: Complete execution time
- Model: The actual model used (gpt-4o-mini)

### 6. Test Multiple Messages

Send another message and verify:
- Previous messages remain in the widget
- New message generates a new trace in LangSmith
- Tags and metadata are consistent across traces

## Common Issues

**Issue:** API fails to start with "load_config()" error
- **Fix:** Check that `api/agentbase.yaml` and `api/agents.yaml` exist
- **Fix:** Verify `api/.env` has `OPENAI_API_KEY` set

**Issue:** Chat widget doesn't stream responses
- **Fix:** Check Vite proxy is configured: `vite.config.ts` should have `/api` → `http://localhost:8001`
- **Fix:** Check CORS headers in `api/main.py` include the correct port

**Issue:** No traces appear in LangSmith
- **Fix:** Verify `LANGCHAIN_API_KEY` is set correctly in `api/.env`
- **Fix:** Check `api/agentbase.yaml` has `tracing: backend: langsmith, enabled: true`
- **Fix:** Wait a few seconds for traces to upload to LangSmith

**Issue:** "LANGCHAIN_API_KEY not found" error
- **Fix:** Set `LANGCHAIN_API_KEY` in `api/.env` to your LangSmith API key from smith.langchain.com

## Success Criteria

✓ API and frontend start without errors
✓ Health check returns `{"status": "ok"}`
✓ Chat widget is visible and expandable
✓ Sending a message produces a streaming response
✓ Response appears in LangSmith under "AgentBase" project with correct metadata
✓ Multiple messages create multiple distinct traces
✓ All traces have consistent tags and metadata

---

## Next Steps After Validation

Once E2E testing confirms everything works:

1. **Document this for other projects:** Create a similar setup for Writerverse or Skill-Deck
2. **Consider scaling:** Determine if other projects should use the same pattern or if variations are needed
3. **Monitor observability:** Set up alerts or dashboards in LangSmith if needed
4. **Extend tracing:** Add more detailed tracing for specific flows if needed

