# AgentBase Project Scaffold

Minimal setup for integrating AgentBase into any project.

## Quick Start

Copy these three files into your project:
1. `agentbase.yaml` — Configuration (edit project name, models, defaults)
2. `agents.yaml` — Agent registry (edit for your agents)
3. `_init_example.py` — Initialization pattern (adapt for your framework)

## Files

### agentbase.yaml
Configuration for models, environments, and tracing. **Required.**

Edit:
- `project:` — Your project name (used as LANGCHAIN_PROJECT in LangSmith)
- `models:` — Model aliases per environment (e.g., fast, smart)
- `defaults:` — Default environment and model alias

Keep as-is:
- `tracing:` — Set LANGCHAIN_API_KEY in .env to enable LangSmith

### agents.yaml
Registry of all agents in your project. **Required.**

For each agent, provide:
- `agent_name` — Unique name (used in `agentbase.resolve()`)
- `agent_version` — Version string (e.g., "0.1.0")
- `model_alias` — Which model alias to use (fast, smart, etc.)
- `prompt_ref` — Pointer to prompt (e.g., "inline", "prompts/myagent_v2")
- `owner` — Responsible person
- `status` — experimental | active | deprecated

### _init_example.py
Example initialization code. Adapt to your framework:

```python
import agentbase

# At app startup (e.g., FastAPI lifespan, Django ready(), Flask app context):
agentbase.load_config(
    config_path="agentbase.yaml",
    registry_path="agents.yaml"
)
agentbase.init_tracing()

# When resolving an agent:
resolved = agentbase.resolve("agent_name")
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
response = await llm.astream(
    messages,
    config=resolved.langchain_config()
)
```

## Environment Setup

Create `.env` in your project root:

```
AGENTBASE_ENV=dev
OPENAI_API_KEY=sk-proj-...
LANGCHAIN_API_KEY=lsv2_pt_...
```

Get LANGCHAIN_API_KEY from [smith.langchain.com](https://smith.langchain.com/).

## Integration Checklist

- [ ] Copy `agentbase.yaml` and `agents.yaml` to project root
- [ ] Edit project name and agents in those files
- [ ] Add agentbase imports to your startup code
- [ ] Call `load_config()` and `init_tracing()` at app startup
- [ ] For each LLM call, pass `config=resolved.langchain_config()`
- [ ] Set `LANGCHAIN_API_KEY` in `.env`
- [ ] Test: Send a request and verify it appears in smith.langchain.com

## Validation

After integration, verify:

1. **Config loads without error:**
   ```bash
   python -c "import agentbase; agentbase.load_config()"
   ```

2. **Tracing initializes:**
   ```bash
   python -c "import agentbase; agentbase.load_config(); agentbase.init_tracing()"
   ```

3. **Agent resolves:**
   ```python
   resolved = agentbase.resolve("agent_name")
   print(resolved.model_id)  # Should be your configured model ID
   ```

4. **Traces appear in LangSmith:**
   - Send a request through your app
   - Go to [smith.langchain.com](https://smith.langchain.com/)
   - Find your project (matches `project:` in agentbase.yaml)
   - Look for traces with `generation_name` matching your agent_name

## Troubleshooting

**"load_config() not called"**
- Make sure you call `agentbase.load_config()` before `agentbase.resolve()`

**"LANGCHAIN_API_KEY not found"**
- Set `LANGCHAIN_API_KEY` in `.env` or as an environment variable
- Get it from [smith.langchain.com](https://smith.langchain.com/)

**"No traces in LangSmith"**
- Verify `LANGCHAIN_API_KEY` is correct
- Check `agentbase.yaml` has `tracing: backend: langsmith, enabled: true`
- Wait a few seconds for traces to upload

**"Agent not registered"**
- Check agent_name matches in both your code and `agents.yaml`
- Verify `agents.yaml` is in the correct path

## Next Steps

- **Observability:** See [MONITORING.md](../docs/MONITORING.md) for LangSmith setup
- **Advanced:** See CLAUDE.md for full API reference
