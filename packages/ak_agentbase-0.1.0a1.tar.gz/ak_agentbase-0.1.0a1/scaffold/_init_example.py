# AgentBase Integration Examples

# ============================================================================
# FastAPI (Recommended - matches shivam-portfolio)
# ============================================================================

from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from langchain_openai import ChatOpenAI
import agentbase

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Load config and initialize tracing
    agentbase.load_config(
        config_path="agentbase.yaml",
        registry_path="agents.yaml",
    )
    agentbase.init_tracing()
    yield
    # Shutdown code here if needed

app = FastAPI(lifespan=lifespan)

@app.post("/chat")
async def chat(messages: list[dict]):
    resolved = agentbase.resolve("example_agent")
    llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
    response = await llm.ainvoke(messages, config=resolved.langchain_config())
    return {"response": response.content}


# ============================================================================
# Django (Async View)
# ============================================================================

import agentbase
from django.http import JsonResponse
from langchain_openai import ChatOpenAI

# In django settings or apps.py:
agentbase.load_config()
agentbase.init_tracing()

async def chat_view(request):
    resolved = agentbase.resolve("example_agent")
    llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)
    response = await llm.ainvoke(
        request.json()["messages"],
        config=resolved.langchain_config()
    )
    return JsonResponse({"response": response.content})


# ============================================================================
# Sync Code / Scripts
# ============================================================================

import agentbase
from langchain_openai import ChatOpenAI

# Load config once at startup
agentbase.load_config()
agentbase.init_tracing()

def generate_response(messages: list[dict]) -> str:
    resolved = agentbase.resolve("example_agent")
    llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)

    # For sync code, use invoke() instead of ainvoke()
    response = llm.invoke(
        messages,
        config=resolved.langchain_config()
    )
    return response.content


# ============================================================================
# LangGraph Integration
# ============================================================================

from langgraph.graph import StateGraph
import agentbase
from langchain_openai import ChatOpenAI

agentbase.load_config()
agentbase.init_tracing()

resolved = agentbase.resolve("example_agent")
llm = ChatOpenAI(model=resolved.model_id, **resolved.default_params)

def generate_node(state):
    # Pass trace config to the LLM call
    response = llm.invoke(
        state["messages"],
        config=resolved.langchain_config()
    )
    return {"response": response.content}

workflow = StateGraph(state_schema=dict)
workflow.add_node("generate", generate_node)
# ... rest of graph setup
