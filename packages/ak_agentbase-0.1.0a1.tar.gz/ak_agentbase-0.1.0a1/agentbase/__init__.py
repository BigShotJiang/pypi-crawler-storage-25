__version__ = "0.1.0a1"

from pathlib import Path

from agentbase.config import get_environment
from agentbase.config import load_config as _load_config
from agentbase.exceptions import (
    AgentBaseError,
    AgentNotRegisteredError,
    ConfigValidationError,
    ContractViolationError,
    ModelResolutionError,
)
from agentbase.models import resolve as _resolve
from agentbase.registry import load_registry
from agentbase.types import (
    AgentBaseConfig,
    AgentMetadata,
    AgentStatus,
    ResolvedAgent,
    TracingConfig,
)

__all__ = [
    "__version__",
    "load_config",
    "resolve",
    "init_tracing",
    "AgentBaseConfig",
    "AgentMetadata",
    "AgentStatus",
    "ResolvedAgent",
    "TracingConfig",
    "AgentBaseError",
    "AgentNotRegisteredError",
    "ConfigValidationError",
    "ContractViolationError",
    "ModelResolutionError",
]

_config: AgentBaseConfig | None = None
_registry: dict[str, AgentMetadata] | None = None
_environment: str | None = None


def load_config(
    config_path: str | Path | None = None,
    registry_path: str | Path | None = None,
) -> AgentBaseConfig:
    global _config, _registry, _environment

    _config = _load_config(config_path)
    _environment = get_environment(_config)

    if registry_path is None:
        base = Path(config_path).parent if config_path else Path.cwd()
        registry_path = base / "agents.yaml"

    _registry = load_registry(registry_path, _config, _environment)
    return _config


def resolve(agent_name: str, environment: str | None = None) -> ResolvedAgent:
    if _config is None or _registry is None:
        raise AgentBaseError(
            "AgentBase is not initialized. Call agentbase.load_config() before using resolve()."
        )
    return _resolve(agent_name, _registry, _config, environment or _environment)


def init_tracing() -> None:
    if _config is None:
        raise AgentBaseError(
            "AgentBase is not initialized. Call agentbase.load_config() before init_tracing()."
        )
    from agentbase.tracing import init_tracing as _init_tracing

    _init_tracing(_config)
