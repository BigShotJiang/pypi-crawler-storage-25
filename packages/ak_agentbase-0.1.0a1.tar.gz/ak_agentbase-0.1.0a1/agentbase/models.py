from agentbase.config import get_environment
from agentbase.exceptions import ModelResolutionError
from agentbase.registry import get_agent
from agentbase.tracing import build_trace_metadata
from agentbase.types import AgentBaseConfig, AgentMetadata, ResolvedAgent


def resolve_model(agent: AgentMetadata, config: AgentBaseConfig, environment: str) -> str | None:
    if agent.model_alias is None:
        return None
    alias_config = config.models[agent.model_alias]
    if environment not in alias_config.environments:
        raise ModelResolutionError(agent.model_alias, environment)
    return alias_config.environments[environment]


def resolve(
    agent_name: str,
    registry: dict[str, AgentMetadata],
    config: AgentBaseConfig,
    environment: str | None = None,
) -> ResolvedAgent:
    env = environment or get_environment(config)
    agent = get_agent(agent_name, registry)
    model_id = resolve_model(agent, config, env)
    default_params = config.models[agent.model_alias].default_params if agent.model_alias else {}
    trace_metadata = build_trace_metadata(agent, model_id)
    return ResolvedAgent(
        agent_name=agent.agent_name,
        model_id=model_id,
        default_params=default_params,
        trace_metadata=trace_metadata,
    )
