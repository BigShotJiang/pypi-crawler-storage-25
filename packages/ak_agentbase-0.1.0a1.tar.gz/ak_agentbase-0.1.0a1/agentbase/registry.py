from pathlib import Path

import yaml

from agentbase.exceptions import (
    AgentNotRegisteredError,
    ConfigValidationError,
    ContractViolationError,
)
from agentbase.types import AgentBaseConfig, AgentMetadata

_CONTRACT_FIELDS = ("agent_name", "agent_version", "model_alias", "prompt_ref", "owner", "status")

_registry_cache: dict[str, dict[str, AgentMetadata]] = {}


def _validate_agent(raw: dict, config: AgentBaseConfig, environment: str) -> AgentMetadata:
    agent_name = raw.get("agent_name") or "<unknown>"

    for field in _CONTRACT_FIELDS:
        if field == "model_alias":
            continue
        if not raw.get(field):
            raise ContractViolationError(agent_name, field)

    model_alias = raw.get("model_alias")
    if model_alias is not None and model_alias not in config.models:
        raise ConfigValidationError(
            f"Agent '{agent_name}' references model alias '{model_alias}' which is not defined "
            f"in agentbase.yaml. Available aliases: {', '.join(sorted(config.models))}."
        )

    return AgentMetadata(
        project=config.project,
        environment=environment,
        agent_name=raw["agent_name"],
        agent_version=str(raw["agent_version"]),
        model_alias=raw.get("model_alias"),
        prompt_ref=raw["prompt_ref"],
        owner=raw["owner"],
        status=raw["status"],
    )


def load_registry(
    path: str | Path,
    config: AgentBaseConfig,
    environment: str,
) -> dict[str, AgentMetadata]:
    resolved = Path(path).resolve()
    cache_key = f"{resolved}:{environment}"

    if cache_key in _registry_cache:
        return _registry_cache[cache_key]

    if not resolved.exists():
        raise ConfigValidationError(
            f"Agent registry not found: {resolved}. Create agents.yaml in your project root."
        )

    with open(resolved) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict) or "agents" not in raw:
        raise ConfigValidationError("agents.yaml must have a top-level 'agents' list.")

    agents_raw = raw["agents"]
    if not isinstance(agents_raw, list):
        raise ConfigValidationError("'agents' in agents.yaml must be a list.")

    registry: dict[str, AgentMetadata] = {}
    for agent_raw in agents_raw:
        metadata = _validate_agent(agent_raw, config, environment)
        if metadata.agent_name in registry:
            raise ConfigValidationError(
                f"Duplicate agent name '{metadata.agent_name}' in agents.yaml. "
                f"Each agent must have a unique name within a project."
            )
        registry[metadata.agent_name] = metadata

    _registry_cache[cache_key] = registry
    return registry


def get_agent(name: str, registry: dict[str, AgentMetadata]) -> AgentMetadata:
    if name not in registry:
        raise AgentNotRegisteredError(name)
    return registry[name]
