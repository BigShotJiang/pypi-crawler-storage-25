class AgentBaseError(Exception):
    pass


class ConfigValidationError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message)


class AgentNotRegisteredError(AgentBaseError):
    def __init__(self, agent_name: str) -> None:
        super().__init__(
            f"Agent '{agent_name}' is not registered in agents.yaml. "
            f"Add an entry for '{agent_name}' with all required contract fields."
        )
        self.agent_name = agent_name


class ContractViolationError(AgentBaseError):
    def __init__(self, agent_name: str, missing_field: str) -> None:
        super().__init__(
            f"Agent '{agent_name}' is missing required contract field '{missing_field}'. "
            f"Add '{missing_field}' to the '{agent_name}' entry in agents.yaml."
        )
        self.agent_name = agent_name
        self.missing_field = missing_field


class ModelResolutionError(AgentBaseError):
    def __init__(self, alias: str, environment: str) -> None:
        super().__init__(
            f"Model alias '{alias}' has no mapping for environment '{environment}'. "
            f"Add a '{environment}' entry under 'models.{alias}' in agentbase.yaml."
        )
        self.alias = alias
        self.environment = environment
