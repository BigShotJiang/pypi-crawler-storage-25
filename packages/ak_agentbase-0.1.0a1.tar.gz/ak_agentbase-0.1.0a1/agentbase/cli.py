import argparse
import os
import sys

from agentbase.config import _config_cache, get_environment, load_config
from agentbase.exceptions import AgentBaseError
from agentbase.registry import _registry_cache, load_registry


def _validate(config_path: str, registry_path: str) -> bool:
    """Validate config and registry files.

    Returns True if valid, False if any errors found.
    """
    _config_cache.clear()
    _registry_cache.clear()

    config = None
    errors: list[str] = []

    # Step 1: Validate agentbase.yaml
    try:
        config = load_config(config_path)
        print(f"✓ {config_path} — project: {config.project}")
    except AgentBaseError as e:
        print(f"✗ {e}")
        errors.append(str(e))

    # Step 2: Validate agents.yaml (if config loaded successfully)
    if config is not None:
        try:
            environment = get_environment(config)
            load_registry(registry_path, config, environment)
            print(f"✓ {registry_path} — environment: {environment}")
        except AgentBaseError as e:
            print(f"✗ {e}")
            errors.append(str(e))

        # Step 3: Validate tracing env vars (if using LangSmith)
        if config.tracing.enabled and config.tracing.backend == "langsmith":
            if os.environ.get("LANGCHAIN_API_KEY"):
                print("✓ LANGCHAIN_API_KEY present")
            else:
                msg = "LANGCHAIN_API_KEY is not set (required when tracing.backend=langsmith)"
                print(f"✗ {msg}")
                errors.append(msg)

    if not errors:
        print("✓ All checks passed")
    return not errors


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(prog="agentbase", description="AgentBase CLI")
    sub = parser.add_subparsers(dest="command")

    val = sub.add_parser("validate", help="Validate agentbase.yaml and agents.yaml")
    val.add_argument(
        "config", nargs="?", default="agentbase.yaml", help="Path to agentbase.yaml"
    )
    val.add_argument(
        "agents", nargs="?", default="agents.yaml", help="Path to agents.yaml"
    )

    args = parser.parse_args()

    if args.command == "validate":
        ok = _validate(args.config, args.agents)
        sys.exit(0 if ok else 1)
    else:
        parser.print_help()
        sys.exit(1)
