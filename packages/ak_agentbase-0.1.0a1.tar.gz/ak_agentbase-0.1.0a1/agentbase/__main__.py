from agentbase.cli import main

main()
