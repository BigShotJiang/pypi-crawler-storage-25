from enum import StrEnum
from typing import Any

from pydantic import BaseModel


class AgentStatus(StrEnum):
    experimental = "experimental"
    active = "active"
    deprecated = "deprecated"


class AgentMetadata(BaseModel):
    project: str
    environment: str
    agent_name: str
    agent_version: str
    model_alias: str | None = None
    prompt_ref: str
    owner: str
    status: AgentStatus


class ModelAliasConfig(BaseModel):
    environments: dict[str, str]
    default_params: dict[str, Any] = {}


class AgentBaseDefaults(BaseModel):
    environment: str = "dev"
    model_alias: str = "smart"


class TracingConfig(BaseModel):
    backend: str = "none"  # "langsmith" | "none"
    enabled: bool = True


class AgentBaseConfig(BaseModel):
    project: str
    models: dict[str, ModelAliasConfig]
    defaults: AgentBaseDefaults = AgentBaseDefaults()
    tracing: TracingConfig = TracingConfig()

    @property
    def environments(self) -> set[str]:
        envs: set[str] = set()
        for alias_config in self.models.values():
            envs.update(alias_config.environments.keys())
        return envs


class ResolvedAgent(BaseModel):
    agent_name: str
    model_id: str | None
    default_params: dict[str, Any] = {}
    trace_metadata: dict[str, Any] = {}

    def langchain_config(self) -> dict[str, Any]:
        """RunnableConfig dict — pass as config= to any LangChain call."""
        return {
            "run_name": self.trace_metadata.get("generation_name", self.agent_name),
            "tags": self.trace_metadata.get("tags", []),
            "metadata": self.trace_metadata.get("metadata", {}),
        }
