import os
from typing import Any

from agentbase.exceptions import ConfigValidationError
from agentbase.types import AgentBaseConfig, AgentMetadata


def init_tracing(config: AgentBaseConfig) -> None:
    tc = config.tracing
    if not tc.enabled or tc.backend == "none":
        return
    if tc.backend == "langsmith":
        _init_langsmith(config.project)
    else:
        raise ConfigValidationError(
            f"Unknown tracing backend '{tc.backend}' in agentbase.yaml. "
            f"Supported values: 'langsmith', 'none'."
        )


def _init_langsmith(project: str) -> None:
    if not os.environ.get("LANGCHAIN_API_KEY"):
        raise ConfigValidationError(
            "Missing environment variable LANGCHAIN_API_KEY "
            "(required for LangSmith tracing). "
            "Get a key at smith.langchain.com and set LANGCHAIN_API_KEY in your environment."
        )
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_PROJECT"] = project


def build_trace_metadata(agent: AgentMetadata, model_id: str | None) -> dict[str, Any]:
    metadata = {
        "project": agent.project,
        "environment": agent.environment,
        "agent_name": agent.agent_name,
        "agent_version": agent.agent_version,
        "owner": agent.owner,
    }
    if agent.model_alias is not None:
        metadata["model_alias"] = agent.model_alias
    if model_id is not None:
        metadata["model_id"] = model_id
    return {
        "generation_name": agent.agent_name,
        "trace_name": f"{agent.project}/{agent.agent_name}",
        "tags": [agent.project, agent.environment, agent.status.value],
        "metadata": metadata,
    }
