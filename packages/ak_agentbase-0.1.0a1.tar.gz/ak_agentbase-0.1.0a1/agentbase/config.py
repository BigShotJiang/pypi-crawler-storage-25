import os
import re
from pathlib import Path
from typing import Any

import yaml

from agentbase.exceptions import ConfigValidationError
from agentbase.types import AgentBaseConfig, AgentBaseDefaults, ModelAliasConfig, TracingConfig

_config_cache: dict[str, AgentBaseConfig] = {}
_ENV_VAR_RE = re.compile(r"\$\{([^}]+)\}")


def _interpolate(value: Any) -> Any:
    if isinstance(value, str):

        def _sub(m: re.Match) -> str:
            var = m.group(1)
            if var not in os.environ:
                raise ConfigValidationError(
                    f"Environment variable '{var}' is referenced in agentbase.yaml but not set. "
                    f"Set '{var}' in your environment before starting the application."
                )
            return os.environ[var]

        return _ENV_VAR_RE.sub(_sub, value)
    if isinstance(value, dict):
        return {k: _interpolate(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_interpolate(v) for v in value]
    return value


def _parse_models(raw_models: dict) -> dict[str, ModelAliasConfig]:
    result = {}
    for alias, raw in raw_models.items():
        if not isinstance(raw, dict):
            raise ConfigValidationError(
                f"Model alias '{alias}' must be a YAML mapping in agentbase.yaml."
            )
        alias_dict = dict(raw)
        default_params = alias_dict.pop("default_params", {})
        if not alias_dict:
            raise ConfigValidationError(
                f"Model alias '{alias}' has no environment mappings in agentbase.yaml."
            )
        result[alias] = ModelAliasConfig(environments=alias_dict, default_params=default_params)
    return result


def _validate_coverage(models: dict[str, ModelAliasConfig]) -> None:
    all_envs: set[str] = set()
    for alias_config in models.values():
        all_envs.update(alias_config.environments.keys())
    for alias, alias_config in models.items():
        missing = all_envs - set(alias_config.environments)
        if missing:
            raise ConfigValidationError(
                f"Model alias '{alias}' is missing mappings for environment(s): "
                f"{', '.join(sorted(missing))}. "
                f"Add these under 'models.{alias}' in agentbase.yaml."
            )


def load_config(path: str | Path | None = None) -> AgentBaseConfig:
    resolved = Path(path).resolve() if path else (Path.cwd() / "agentbase.yaml").resolve()
    cache_key = str(resolved)

    if cache_key in _config_cache:
        return _config_cache[cache_key]

    if not resolved.exists():
        raise ConfigValidationError(
            f"Config file not found: {resolved}. Create agentbase.yaml in your project root."
        )

    with open(resolved) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ConfigValidationError("agentbase.yaml must be a YAML mapping at the top level.")

    raw = _interpolate(raw)

    for field in ("project", "models"):
        if field not in raw:
            raise ConfigValidationError(f"agentbase.yaml is missing required field '{field}'.")

    models = _parse_models(raw["models"])

    defaults_raw = raw.get("defaults", {})
    defaults = AgentBaseDefaults(**defaults_raw) if defaults_raw else AgentBaseDefaults()

    tracing_raw = raw.get("tracing", {})
    try:
        tracing = TracingConfig(**tracing_raw) if tracing_raw else TracingConfig()
    except Exception as e:
        raise ConfigValidationError(f"Invalid 'tracing' section in agentbase.yaml: {e}") from e

    config = AgentBaseConfig(
        project=raw["project"],
        models=models,
        defaults=defaults,
        tracing=tracing,
    )

    _validate_coverage(config.models)

    _config_cache[cache_key] = config
    return config


def get_environment(config: AgentBaseConfig) -> str:
    return os.environ.get("AGENTBASE_ENV", config.defaults.environment)
