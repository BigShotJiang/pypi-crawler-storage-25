Write a session handoff document to `HANDOFF.md` at the repo root.

This is used to transfer context between Claude Code sessions. The next session reads this file to understand where work left off.

Steps:

1. Read the current state of the codebase:
   - Check `git log --oneline -10` for recent commits (if git is initialized)
   - Check `git status` for uncommitted work
   - Check which files exist under `agentbase/` and `tests/`
   - Check the current sprint and task progress in `specs/`

2. Write `HANDOFF.md` with these sections:

   ## Last Session Summary
   - What was accomplished in this session (2-3 sentences max)

   ## Current Phase
   - Which release (v0.1-alpha, v0.1-beta, etc.)
   - Which sprint (001, 002, 003)
   - Which task (TASK-XXX)

   ## Completed
   - List of tasks/sprints completed so far

   ## In Progress
   - What was being worked on when the session ended
   - Any partially completed work

   ## Blocked or Needs Decision
   - Any blockers, open questions, or decisions needed before continuing

   ## Next Steps
   - The specific next task to start
   - Any context the next session needs to pick up cleanly

   ## Key Files Changed This Session
   - List of files created or modified

3. Keep it concise. The goal is a 60-second read that gets the next session productive immediately.

4. After writing, confirm to the user that the handoff is saved and what the next session should start with.
