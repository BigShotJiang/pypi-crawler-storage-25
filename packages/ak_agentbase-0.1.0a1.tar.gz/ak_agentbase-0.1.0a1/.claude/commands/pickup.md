Read the session handoff and prepare to continue work.

Steps:

1. Read `HANDOFF.md` at the repo root. If it doesn't exist, say so and instead read `CLAUDE.md` and the current sprint file to determine starting point.

2. Read the current sprint file referenced in the handoff (e.g., `specs/sprints/sprint-001.md`).

3. Read the current task from `specs/implementation/tasks-v0.1-alpha.md` — specifically the task mentioned in the handoff's "Next Steps" section.

4. Check the actual state of the codebase:
   - `git log --oneline -5` for recent commits (if git is initialized)
   - `git status` for any uncommitted changes
   - List files under `agentbase/` and `tests/` to confirm what exists
   - Verify that what the handoff claims matches reality

5. Present a brief summary to the user:
   - Where we left off (from handoff)
   - What's next (specific task with its objective)
   - Any blockers or decisions needed
   - Whether the codebase matches the handoff (flag discrepancies)

6. Ask the user if they want to continue with the next task or do something else.

Keep the summary short — 10 lines max. The user wants to get moving, not re-read the entire plan.
