from python_proxy_provider.models import DynamicConfig, Router, Service, Server


def test_merge_disjoint():
    a = DynamicConfig(
        routers={"r1": Router(rule="Host(`a`)", service="s1")},
        services={"s1": Service(servers=[Server(url="http://1")])},
    )
    b = DynamicConfig(
        routers={"r2": Router(rule="Host(`b`)", service="s2")},
        services={"s2": Service(servers=[Server(url="http://2")])},
    )
    merged = a.merge(b)
    assert "r1" in merged.routers
    assert "r2" in merged.routers
    assert "s1" in merged.services
    assert "s2" in merged.services


def test_merge_overwrite_router():
    a = DynamicConfig(
        routers={"r1": Router(rule="Host(`a`)", service="s1")},
    )
    b = DynamicConfig(
        routers={"r1": Router(rule="Host(`b`)", service="s2")},
    )
    merged = a.merge(b)
    assert merged.routers["r1"].rule == "Host(`b`)"
    assert merged.routers["r1"].service == "s2"


def test_merge_overwrite_service():
    a = DynamicConfig(
        services={"s1": Service(servers=[Server(url="http://1")])},
    )
    b = DynamicConfig(
        services={"s1": Service(servers=[Server(url="http://2"), Server(url="http://3")])},
    )
    merged = a.merge(b)
    assert len(merged.services["s1"].servers) == 2
    assert merged.services["s1"].servers[0].url == "http://2"


def test_merge_empty():
    a = DynamicConfig(
        routers={"r1": Router(rule="Host(`a`)", service="s1")},
    )
    merged = a.merge(DynamicConfig())
    assert "r1" in merged.routers
    assert len(merged.services) == 0


def test_merge_identity():
    a = DynamicConfig(
        routers={"r1": Router(rule="Host(`a`)", service="s1")},
        services={"s1": Service(servers=[Server(url="http://1")])},
    )
    merged = a.merge(a)
    assert len(merged.routers) == 1
    assert len(merged.services) == 1
