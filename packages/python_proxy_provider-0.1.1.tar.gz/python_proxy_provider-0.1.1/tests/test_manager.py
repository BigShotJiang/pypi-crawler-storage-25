import asyncio

import pytest

from python_proxy_provider.events import EventBus, ConfigEvent
from python_proxy_provider.manager import ProviderManager
from python_proxy_provider.models import DynamicConfig
from python_proxy_provider.providers.base import ProviderBase


class FakeProvider(ProviderBase):
    name = "fake"

    def __init__(self, bus, config: DynamicConfig):
        super().__init__(bus)
        self._config = config
        self.started = False

    async def start(self):
        self.started = True
        await self.bus.publish(ConfigEvent(provider=self.name, config=self._config))

    async def current_config(self):
        return self._config


@pytest.mark.asyncio
async def test_start_all():
    bus = EventBus()
    cfg = DynamicConfig()
    provider = FakeProvider(bus, cfg)
    manager = ProviderManager([provider])

    await manager.start_all()
    await asyncio.sleep(0.05)
    assert provider.started


@pytest.mark.asyncio
async def test_merged_config_updates():
    bus = EventBus()
    a = DynamicConfig()
    b = DynamicConfig()
    pa = FakeProvider(bus, a)
    pb = FakeProvider(bus, b)
    manager = ProviderManager([pa, pb])

    await manager.start_all()
    merge_task = asyncio.create_task(manager.run_merge_loop())
    await asyncio.sleep(0.1)

    merged = manager.merged_config()
    assert merged is not None

    merge_task.cancel()
    try:
        await merge_task
    except asyncio.CancelledError:
        pass


@pytest.mark.asyncio
async def test_stop_all():
    bus = EventBus()
    provider = FakeProvider(bus, DynamicConfig())
    manager = ProviderManager([provider])

    await manager.start_all()
    await manager.stop_all()

    assert provider._task is None or provider._task.done()


@pytest.mark.asyncio
async def test_empty_providers():
    manager = ProviderManager([])
    assert manager.merged_config() is not None
