import asyncio

import pytest

from python_proxy_provider.events import EventBus, ConfigEvent
from python_proxy_provider.models import DynamicConfig


@pytest.mark.asyncio
async def test_publish_subscribe():
    bus = EventBus()
    event = ConfigEvent(provider="test", config=DynamicConfig())

    async def reader():
        async for e in bus.subscribe():
            return e

    async def writer():
        await asyncio.sleep(0.05)
        await bus.publish(event)
        bus.close()

    result = await asyncio.gather(reader(), writer())
    assert result[0] is event


@pytest.mark.asyncio
async def test_close_stops_subscribe():
    bus = EventBus()
    bus.close()
    count = 0
    async for _ in bus.subscribe():
        count += 1
    assert count == 0


@pytest.mark.asyncio
async def test_publish_after_close():
    bus = EventBus()
    bus.close()
    event = ConfigEvent(provider="test", config=DynamicConfig())
    await bus.publish(event)


@pytest.mark.asyncio
async def test_multiple_events():
    bus = EventBus()
    events = [
        ConfigEvent(provider="p1", config=DynamicConfig()),
        ConfigEvent(provider="p2", config=DynamicConfig()),
    ]

    async def reader():
        result = []
        async for e in bus.subscribe():
            result.append(e)
            if len(result) == 2:
                bus.close()
        return result

    async def writer():
        await asyncio.sleep(0.05)
        for e in events:
            await bus.publish(e)
            await asyncio.sleep(0.05)

    result = await asyncio.gather(reader(), writer())
    assert len(result[0]) == 2
    assert result[0][0].provider == "p1"
    assert result[0][1].provider == "p2"
