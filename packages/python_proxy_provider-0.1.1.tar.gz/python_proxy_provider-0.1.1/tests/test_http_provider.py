import asyncio
import json

import pytest

from python_proxy_provider.events import EventBus
from python_proxy_provider.providers.http_provider import HttpProvider, close_client


@pytest.mark.asyncio
async def test_http_provider_fetch(httpserver):
    data = {"routers": {"r1": {"rule": "Host(`a`)", "service": "s1"}}, "services": {"s1": {"servers": [{"url": "http://localhost:5000"}]}}}
    httpserver.serve_content(content=json.dumps(data), headers={"Content-Type": "application/json"})

    bus = EventBus()
    provider = HttpProvider(bus, url=httpserver.url, interval_seconds=1)

    async def reader():
        async for event in bus.subscribe():
            assert event.provider == "http"
            assert "r1" in event.config.routers
            assert "s1" in event.config.services
            bus.close()
            return event

    async def starter():
        await provider.start_background()
        await asyncio.sleep(0.2)

    await asyncio.gather(reader(), starter())
    await provider.stop()
    await close_client()


@pytest.mark.asyncio
async def test_http_provider_handles_server_error(httpserver):
    httpserver.serve_content(content="Internal Server Error", code=500)

    bus = EventBus()
    provider = HttpProvider(bus, url=httpserver.url, interval_seconds=1)

    await provider.start_background()
    await asyncio.sleep(0.15)
    cfg = await provider.current_config()
    assert len(cfg.routers) == 0

    await provider.stop()
    await close_client()


@pytest.mark.asyncio
async def test_http_provider_stop():
    bus = EventBus()
    provider = HttpProvider(bus, url="http://localhost:1", interval_seconds=1)

    await provider.start_background()
    await provider.stop()

    assert provider._task is None or provider._task.done()
    await close_client()
