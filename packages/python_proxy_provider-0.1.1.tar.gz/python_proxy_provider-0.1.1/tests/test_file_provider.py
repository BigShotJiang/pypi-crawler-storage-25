import asyncio

import pytest

from python_proxy_provider.events import EventBus
from python_proxy_provider.providers.file_provider import FileProvider


@pytest.mark.asyncio
async def test_load_initial_config(tmp_path):
    config_file = tmp_path / "routes.yml"
    config_file.write_text("routers:\n  r1:\n    rule: Host(`a`)\n    service: s1\n")
    bus = EventBus()
    provider = FileProvider(bus, path=str(config_file))
    cfg = await provider.current_config()
    assert len(cfg.routers) == 0


@pytest.mark.asyncio
async def test_file_provider_publishes_on_start(tmp_path):
    config_file = tmp_path / "routes.yml"
    config_file.write_text("routers:\n  r1:\n    rule: Host(`a`)\n    service: s1\n")
    bus = EventBus()
    provider = FileProvider(bus, path=str(config_file))

    async def reader():
        async for event in bus.subscribe():
            assert event.provider == "file"
            assert "r1" in event.config.routers
            bus.close()
            return event

    async def starter():
        await provider.start_background()
        await asyncio.sleep(0.1)

    await asyncio.gather(reader(), starter())


@pytest.mark.asyncio
async def test_file_provider_reload(tmp_path):
    config_file = tmp_path / "routes.yml"
    config_file.write_text("routers:\n  r1:\n    rule: Host(`a`)\n    service: s1\n")
    bus = EventBus()
    provider = FileProvider(bus, path=str(config_file))

    await provider.start_background()
    await asyncio.sleep(0.2)
    config_file.write_text("routers:\n  r2:\n    rule: Host(`b`)\n    service: s2\n")

    found = False
    deadline = asyncio.get_event_loop().time() + 5
    async for event in bus.subscribe():
        if "r2" in event.config.routers:
            found = True
            break
        if asyncio.get_event_loop().time() > deadline:
            break

    await provider.stop()
    assert found


@pytest.mark.asyncio
async def test_file_provider_stop(tmp_path):
    config_file = tmp_path / "routes.yml"
    config_file.write_text("routers: {}\n")
    bus = EventBus()
    provider = FileProvider(bus, path=str(config_file))

    await provider.start_background()
    await provider.stop()

    assert provider._task is None or provider._task.done()
