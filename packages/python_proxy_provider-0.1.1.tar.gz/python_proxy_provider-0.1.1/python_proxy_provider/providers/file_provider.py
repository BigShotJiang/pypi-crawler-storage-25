from __future__ import annotations

import asyncio
import logging

import yaml
from watchfiles import awatch

from .base import ProviderBase
from ..events import ConfigEvent
from ..models import DynamicConfig

logger = logging.getLogger(__name__)


class FileProvider(ProviderBase):
    name = "file"

    def __init__(self, bus, path: str):
        super().__init__(bus)
        self.path = path
        self._config = DynamicConfig()

    def _load(self) -> DynamicConfig:
        with open(self.path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        return DynamicConfig.model_validate(raw)

    async def start(self) -> None:
        self._config = self._load()
        logger.info("FileProvider loaded %s: %d routers, %d services", self.path, len(self._config.routers), len(self._config.services))
        await self.bus.publish(ConfigEvent(provider=self.name, config=self._config))

        async for _ in awatch(self.path):
            try:
                self._config = self._load()
                logger.info("FileProvider reloaded %s", self.path)
                await self.bus.publish(ConfigEvent(provider=self.name, config=self._config))
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.warning("FileProvider: ignoring invalid config reload from %s", self.path, exc_info=True)

    async def stop(self) -> None:
        await super().stop()

    async def current_config(self) -> DynamicConfig:
        return self._config
