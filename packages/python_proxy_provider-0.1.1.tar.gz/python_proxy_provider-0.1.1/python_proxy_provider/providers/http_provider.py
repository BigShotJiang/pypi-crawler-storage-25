from __future__ import annotations

import asyncio
import logging

import httpx

from .base import ProviderBase
from ..events import ConfigEvent
from ..models import DynamicConfig

logger = logging.getLogger(__name__)

_client: httpx.AsyncClient | None = None


def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(timeout=10)
    return _client


async def close_client():
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


class HttpProvider(ProviderBase):
    name = "http"

    def __init__(self, bus, url: str, interval_seconds: int = 5):
        super().__init__(bus)
        self.url = url
        self.interval_seconds = interval_seconds
        self._config = DynamicConfig()

    async def start(self) -> None:
        client = _get_client()
        while True:
            try:
                r = await client.get(self.url)
                r.raise_for_status()
                data = r.json()
                self._config = DynamicConfig.model_validate(data)
                logger.info("HttpProvider fetched %s: %d routers, %d services", self.url, len(self._config.routers), len(self._config.services))
                await self.bus.publish(ConfigEvent(provider=self.name, config=self._config))
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.warning("HttpProvider: failed to fetch %s", self.url, exc_info=True)

            await asyncio.sleep(self.interval_seconds)

    async def stop(self) -> None:
        await super().stop()

    async def current_config(self) -> DynamicConfig:
        return self._config
