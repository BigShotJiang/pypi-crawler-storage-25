from __future__ import annotations

import abc
import asyncio
import logging
from typing import Optional

from ..models import DynamicConfig
from ..events import EventBus

logger = logging.getLogger(__name__)


class ProviderBase(abc.ABC):
    name: str

    def __init__(self, bus: EventBus):
        self.bus = bus
        self._task: Optional[asyncio.Task] = None

    @abc.abstractmethod
    async def start(self) -> None:
        """Start provider loop and publish config updates."""

    async def start_background(self) -> None:
        self._task = asyncio.create_task(self._run_wrapper())

    async def _run_wrapper(self) -> None:
        try:
            await self.start()
        except asyncio.CancelledError:
            logger.info("Provider %s cancelled", self.name)
        except Exception:
            logger.exception("Provider %s crashed", self.name)

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    @abc.abstractmethod
    async def current_config(self) -> DynamicConfig:
        """Return latest config snapshot."""
