from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import AsyncIterator

from .models import DynamicConfig

logger = logging.getLogger(__name__)


@dataclass
class ConfigEvent:
    provider: str
    config: DynamicConfig


class EventBus:
    def __init__(self):
        self._queue: asyncio.Queue[ConfigEvent] = asyncio.Queue()
        self._closed = asyncio.Event()

    async def publish(self, event: ConfigEvent):
        if self._closed.is_set():
            logger.warning("EventBus closed, dropping event from %s", event.provider)
            return
        await self._queue.put(event)

    async def subscribe(self) -> AsyncIterator[ConfigEvent]:
        while not self._closed.is_set():
            try:
                event = await asyncio.wait_for(self._queue.get(), timeout=1)
                yield event
            except asyncio.TimeoutError:
                continue

    def close(self):
        self._closed.set()
