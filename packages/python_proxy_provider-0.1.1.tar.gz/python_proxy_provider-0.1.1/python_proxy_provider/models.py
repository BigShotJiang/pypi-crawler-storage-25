from __future__ import annotations

import logging

from pydantic import BaseModel, Field
from typing import Dict, List

logger = logging.getLogger(__name__)


class Server(BaseModel):
    url: str


class Service(BaseModel):
    servers: List[Server] = Field(default_factory=list)


class Router(BaseModel):
    rule: str
    service: str


class DynamicConfig(BaseModel):
    routers: Dict[str, Router] = Field(default_factory=dict)
    services: Dict[str, Service] = Field(default_factory=dict)

    def merge(self, other: "DynamicConfig") -> "DynamicConfig":
        merged = DynamicConfig.model_validate(self.model_dump())
        for key in other.routers:
            if key in merged.routers:
                logger.warning("Router %r conflicts: overwriting with provider value", key)
        merged.routers.update(other.routers)
        for key in other.services:
            if key in merged.services:
                logger.warning("Service %r conflicts: overwriting with provider value", key)
        merged.services.update(other.services)
        return merged
