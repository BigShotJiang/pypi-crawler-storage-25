from __future__ import annotations

import asyncio
import logging
from typing import Dict, List, Optional

from .events import EventBus
from .models import DynamicConfig
from .providers.base import ProviderBase

logger = logging.getLogger(__name__)


class ProviderManager:
    def __init__(self, providers: List[ProviderBase]):
        self.providers = providers
        self.bus = providers[0].bus if providers else EventBus()
        self._configs: Dict[str, DynamicConfig] = {}
        self._merged = DynamicConfig()
        self._merge_task: Optional[asyncio.Task] = None

    def merged_config(self) -> DynamicConfig:
        return self._merged

    def _recompute(self):
        merged = DynamicConfig()
        for name, cfg in self._configs.items():
            logger.debug("Merging config from provider %s", name)
            merged = merged.merge(cfg)
        self._merged = merged
        logger.info("Merged config: %d routers, %d services", len(merged.routers), len(merged.services))

    async def start_all(self):
        for p in self.providers:
            await p.start_background()

    async def run_merge_loop(self):
        self._merge_task = asyncio.current_task()
        async for event in self.bus.subscribe():
            self._configs[event.provider] = event.config
            self._recompute()

    async def stop_all(self):
        logger.info("Stopping all providers...")
        for p in self.providers:
            await p.stop()
        self.bus.close()
        if self._merge_task and not self._merge_task.done():
            self._merge_task.cancel()
            try:
                await self._merge_task
            except asyncio.CancelledError:
                pass
