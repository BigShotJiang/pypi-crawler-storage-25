from __future__ import annotations

import asyncio
import json
import logging
import signal

import typer

from .events import EventBus
from .manager import ProviderManager
from .providers.file_provider import FileProvider
from .providers.http_provider import HttpProvider, close_client

app = typer.Typer(help="python-proxy-provider - dynamic config provider framework")

_log_levels = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
}


@app.command()
def run(
    file: str = typer.Option(None, "--file", help="Path to YAML config file"),
    http: str = typer.Option(None, "--http", help="URL returning JSON config"),
    log_level: str = typer.Option("INFO", "--log-level", help="Log level: DEBUG, INFO, WARNING, ERROR"),
):
    logging.basicConfig(level=_log_levels.get(log_level.upper(), logging.INFO), format="%(levelname)s %(name)s: %(message)s")

    if not file and not http:
        raise typer.BadParameter("You must specify at least --file or --http provider.")

    bus = EventBus()
    providers = []

    if file:
        providers.append(FileProvider(bus, path=file))

    if http:
        providers.append(HttpProvider(bus, url=http, interval_seconds=5))

    manager = ProviderManager(providers)

    async def printer():
        last: str | None = None
        while True:
            try:
                await asyncio.sleep(1)
                cfg = manager.merged_config().model_dump()
                text = json.dumps(cfg, indent=2, sort_keys=True)
                if text != last:
                    print("\n=== MERGED CONFIG UPDATED ===")
                    print(text)
                    last = text
            except asyncio.CancelledError:
                break

    async def main():
        loop = asyncio.get_running_loop()
        stop_event = asyncio.Event()

        def _signal_handler():
            logging.getLogger("python_proxy_provider").info("Shutdown signal received...")
            stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, _signal_handler)
            except NotImplementedError:
                pass

        await manager.start_all()
        printer_task = asyncio.create_task(printer())
        merge_task = asyncio.create_task(manager.run_merge_loop())

        await stop_event.wait()

        printer_task.cancel()
        merge_task.cancel()
        await manager.stop_all()
        await close_client()

    asyncio.run(main())


if __name__ == "__main__":
    app()
