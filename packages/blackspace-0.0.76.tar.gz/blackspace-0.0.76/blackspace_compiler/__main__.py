import argparse
from typing import cast

from .ast.context import EvaluationContext
from .parser.parser import parse


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Blackspace Compiler")
    parser.add_argument("input_file", help="Path to the input source code file")
    parser.add_argument("-o", "--output", help="Path to the output file", default="a.out")
    parser.add_argument(
        "--disable-optimizations",
        action="store_true",
        help="Disable optimizations",
        default=False,
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_file = cast(str, args.input_file)
    output_file = cast(str, args.output)
    disable_optimizations = cast(bool, args.disable_optimizations)

    with open(input_file, "r") as f:
        source_code = f.read()

    ast = parse(source_code)
    context = EvaluationContext()
    context.compiler_config.stack_overflow_guard = not disable_optimizations
    code = ast.evaluate(context)
    context.print_issues()

    with open(output_file, "w") as f:
        f.write(code)


if __name__ == "__main__":
    main()
