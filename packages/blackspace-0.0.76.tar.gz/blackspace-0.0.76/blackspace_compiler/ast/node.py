from abc import ABC
from dataclasses import dataclass


@dataclass(frozen=True)
class SourcePosition:
    line: int
    column: int


class AstNode(ABC):

    def __init__(self):
        super().__init__()
        self.source_position: SourcePosition | None = None

    def set_position(self, position: SourcePosition) -> None:
        self.source_position = position


def with_position[T: AstNode](node: T, position: SourcePosition) -> T:
    node.set_position(position)
    return node
