from enum import Enum, auto

from ....whitespace.snippets import FETCH, PUSH, READ_CHAR, READ_NUMBER
from ...context import EvaluationContext, IssueLevel
from ...types.primitives.int import IntegerType
from ...types.primitives.void import VoidType
from ...types.type import Type
from ..expression import Expression


class ReadMode(Enum):
    Number = auto()
    Character = auto()


class ReadExpression(Expression):
    def __init__(self, read_mode: ReadMode = ReadMode.Number) -> None:
        super().__init__()
        self._read_mode = read_mode

    def __repr__(self) -> str:
        return f"Read as {self._read_mode}"

    def get_type(self, context: EvaluationContext) -> Type:
        if self._read_mode == ReadMode.Number:
            return IntegerType()
        elif self._read_mode == ReadMode.Character:
            # We don't have a character type currently, so right now its handled as an integer
            return IntegerType()
        else:
            context.register_issue(
                IssueLevel.ERROR,
                self,
                f"Unknown read mode: {self._read_mode}",
            )
            return VoidType()

    def evaluate(self, context: EvaluationContext) -> str:
        # the data that is read will be stored in register A
        res = PUSH(context.compiler_config.register_a)

        if self._read_mode == ReadMode.Number:
            res += READ_NUMBER
        elif self._read_mode == ReadMode.Character:
            res += READ_CHAR
        else:
            context.register_issue(
                IssueLevel.ERROR,
                self,
                f"Unknown read mode: {self._read_mode}",
            )

        # Expressions need to leave the result on the stack, so we need to fetch it from register A
        res += PUSH(context.compiler_config.register_a) + FETCH

        return res
