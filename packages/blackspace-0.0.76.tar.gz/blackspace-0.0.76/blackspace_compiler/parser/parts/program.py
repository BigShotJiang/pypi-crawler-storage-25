from ...ast.node import with_position
from ...ast.statements.compound import CompoundStatement
from ...ast.statements.program import Program
from ...ast.statements.statement import Statement
from ..exceptions import ParseException
from ..stream import TokenStream, TokenType
from .statements.function import parse_function


def parse_program(stream: TokenStream) -> Program:
    functions: list[Statement] = []
    main_function_name = "main"
    found_main = False

    start_pos = stream.peek().position

    while not stream.peek().type == TokenType.EOF:
        funcdef = parse_function(stream)
        functions.append(funcdef)
        if funcdef.signature.name == main_function_name:
            found_main = True

    if not found_main:
        raise ParseException(start_pos, f"Entry function '{main_function_name}' is not defined.")

    return with_position(
        Program(statement=CompoundStatement(functions), entry_function=main_function_name),
        position=start_pos,
    )
