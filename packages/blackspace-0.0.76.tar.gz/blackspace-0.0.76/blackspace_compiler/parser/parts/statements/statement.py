from ....ast.expressions.expression import Expression
from ....ast.expressions.literals.bool import TrueLiteral
from ....ast.node import with_position
from ....ast.statements.compound import CompoundStatement
from ....ast.statements.condition import ConditionStatement
from ....ast.statements.loop import DoWhileStatement, ForLoopStatement, WhileLoopStatement
from ....ast.statements.statement import Statement
from ....ast.statements.void import VoidStatement
from ...exceptions import ParseException, UnexpectedTokenException
from ...stream import TokenStream, TokenType
from ..expressions import parse_expression
from .assignment import parse_assignment_fragment, parse_assignment_statement
from .return_stmt import parse_return_statement


def parse_block(stream: TokenStream) -> CompoundStatement:
    opener = stream.peek()
    if opener.type != TokenType.LBRACE:
        raise UnexpectedTokenException(opener, "Expected '{' to start a block statement")
    stream.next()  # Consume the '{'

    statements: list[Statement] = []
    while True:
        if stream.peek().type == TokenType.RBRACE:
            stream.next()  # Consume the '}'
            break
        if stream.peek().type == TokenType.EOF:
            raise UnexpectedTokenException(
                stream.peek(), "Unexpected end of file while parsing block statement"
            )

        statements.append(parse_statement(stream))

    return with_position(CompoundStatement(statements), opener.position)


def parse_if_statement(stream: TokenStream) -> ConditionStatement:
    if_token = stream.peek()
    if if_token.type != TokenType.KW_IF:
        raise UnexpectedTokenException(if_token, "Expected 'if' to start an if statement")
    stream.next()  # Consume the 'if'

    if stream.peek().type != TokenType.LPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected '(' after 'if'")
    stream.next()  # Consume the '('

    condition = parse_expression(stream)

    if stream.peek().type != TokenType.RPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected ')' after if condition")
    stream.next()  # Consume the ')'

    true_statement = parse_statement(stream)
    false_statement: Statement | None = None

    if stream.peek().type == TokenType.KW_ELSE:
        stream.next()  # Consume the 'else'
        false_statement = parse_statement(stream)

    return with_position(
        ConditionStatement(condition, true_statement, false_statement), if_token.position
    )


def parse_while_statement(stream: TokenStream) -> WhileLoopStatement:
    while_token = stream.peek()
    if while_token.type != TokenType.KW_WHILE:
        raise UnexpectedTokenException(while_token, "Expected 'while' to start a while statement")
    stream.next()  # Consume the 'while'

    if stream.peek().type != TokenType.LPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected '(' after 'while'")
    stream.next()  # Consume the '('

    condition = parse_expression(stream)

    if stream.peek().type != TokenType.RPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected ')' after while condition")
    stream.next()  # Consume the ')'

    body = parse_statement(stream)

    return with_position(WhileLoopStatement(condition, body), while_token.position)


def parse_do_while_statement(stream: TokenStream) -> DoWhileStatement:
    do_token = stream.peek()
    if do_token.type != TokenType.KW_DO:
        raise UnexpectedTokenException(do_token, "Expected 'do' to start a do-while statement")
    stream.next()  # Consume the 'do'

    body = parse_statement(stream)

    if stream.peek().type != TokenType.KW_WHILE:
        raise UnexpectedTokenException(stream.peek(), "Expected 'while' after 'do' block")
    stream.next()  # Consume the 'while'

    if stream.peek().type != TokenType.LPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected '(' after 'while'")
    stream.next()  # Consume the '('

    condition = parse_expression(stream)

    if stream.peek().type != TokenType.RPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected ')' after while condition")
    stream.next()  # Consume the ')'

    return with_position(DoWhileStatement(condition, body), do_token.position)


def parse_for_statement(stream: TokenStream) -> ForLoopStatement:
    for_token = stream.peek()
    if for_token.type != TokenType.KW_FOR:
        raise UnexpectedTokenException(for_token, "Expected 'for' to start a for statement")
    stream.next()  # Consume the 'for'

    if stream.peek().type != TokenType.LPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected '(' after 'for'")
    stream.next()  # Consume the '('

    initializer: Statement = with_position(
        CompoundStatement([]), for_token.position
    )  # default empty initializer
    if stream.peek().type != TokenType.SEMICOLON:
        initializer = parse_statement_fragment(stream)

    if stream.peek().type != TokenType.SEMICOLON:
        raise UnexpectedTokenException(stream.peek(), "Expected ';' after for loop initializer")
    stream.next()  # Consume the ';'

    condition: Expression = with_position(TrueLiteral(), for_token.position)
    if stream.peek().type != TokenType.SEMICOLON:
        condition = parse_expression(stream)

    if stream.peek().type != TokenType.SEMICOLON:
        raise UnexpectedTokenException(stream.peek(), "Expected ';' after for loop condition")
    stream.next()  # Consume the ';'

    increment: Statement = with_position(
        CompoundStatement([]), for_token.position
    )  # default empty increment
    if stream.peek().type != TokenType.RPAREN:
        increment = parse_statement_fragment(stream)

    if stream.peek().type != TokenType.RPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected ')' after for loop increment")
    stream.next()  # Consume the ')'

    body = parse_statement(stream)

    return with_position(
        ForLoopStatement(initializer, condition, increment, body), for_token.position
    )


def parse_void_statement(stream: TokenStream) -> VoidStatement:
    start_pos = stream.peek().position

    expr = parse_expression(stream)

    if stream.peek().type != TokenType.SEMICOLON:
        raise UnexpectedTokenException(stream.peek(), "Expected ';' after expression statement")
    stream.next()  # Consume the ';'

    return with_position(VoidStatement(expr), start_pos)


def parse_statement_fragment(stream: TokenStream) -> Statement:
    # Currently statement fragments only support assignment statements
    return parse_assignment_fragment(stream)


def parse_statement(stream: TokenStream) -> Statement:
    if stream.peek().type == TokenType.LBRACE:
        return parse_block(stream)
    elif stream.peek().type == TokenType.KW_IF:
        return parse_if_statement(stream)
    elif stream.peek().type == TokenType.KW_WHILE:
        return parse_while_statement(stream)
    elif stream.peek().type == TokenType.KW_DO:
        return parse_do_while_statement(stream)
    elif stream.peek().type == TokenType.KW_FOR:
        return parse_for_statement(stream)
    elif stream.peek().type == TokenType.KW_RETURN:
        return parse_return_statement(stream)
    elif stream.peek().type == TokenType.SEMICOLON:
        # no-op statement
        semicolon = stream.peek()
        stream.next()  # Consume the ';'
        return with_position(CompoundStatement([]), semicolon.position)
    else:
        stream_checkpoint = stream.checkpoint()

        try:
            assignment = parse_assignment_statement(stream)
            return assignment
        except ParseException:
            # Restore the stream to try parsing as a void statement
            stream.restore(stream_checkpoint)
            return parse_void_statement(stream)
