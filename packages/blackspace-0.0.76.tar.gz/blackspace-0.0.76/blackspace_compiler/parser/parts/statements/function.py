from ....ast.definitions.function import FunctionSignature, ParameterDefinition
from ....ast.definitions.variable import VariableDefinition
from ....ast.node import SourcePosition, with_position
from ....ast.statements.function import FunctionBodyStatement
from ....ast.types.primitives.void import VoidType
from ...exceptions import ParseException, UnexpectedTokenException
from ...stream import TokenStream, TokenType
from ..identifier import parse_identifier
from ..types import parse_type
from .statement import parse_block


def parse_parameter_definition(stream: TokenStream) -> tuple[ParameterDefinition, SourcePosition]:
    param_name, name_pos = parse_identifier(stream)

    if not stream.peek().type == TokenType.COLON:
        raise UnexpectedTokenException(stream.peek(), "Expected ':' after parameter name.")
    stream.next()  # Consume the colon

    param_type = parse_type(stream)
    if param_type == VoidType():
        raise ParseException(name_pos, "Parameters cannot have 'void' type.")

    return ParameterDefinition(name=param_name, type=param_type), name_pos


def parse_variable_definition(stream: TokenStream) -> tuple[VariableDefinition, SourcePosition]:
    is_mutable = False

    if stream.peek().type == TokenType.KW_CONST:
        stream.next()  # Consume 'const'
        is_mutable = False
    elif stream.peek().type == TokenType.KW_VAR:
        stream.next()  # Consume 'var'
        is_mutable = True
    else:
        raise UnexpectedTokenException(
            stream.peek(), "Expected 'const' or 'var' for variable declaration."
        )

    var_name, name_pos = parse_identifier(stream)

    if not stream.peek().type == TokenType.COLON:
        raise UnexpectedTokenException(stream.peek(), "Expected ':' after variable name.")
    stream.next()  # Consume the colon

    var_type = parse_type(stream)
    if var_type == VoidType():
        raise ParseException(name_pos, "Variables cannot have 'void' type.")

    return VariableDefinition(name=var_name, type=var_type, is_mutable=is_mutable), name_pos


def parse_function_signature(stream: TokenStream) -> FunctionSignature:
    if stream.peek().type != TokenType.KW_FN:
        raise UnexpectedTokenException(
            stream.peek(), "Expected 'fn' keyword for function declaration."
        )
    stream.next()  # Consume 'fn'

    func_name, name_pos = parse_identifier(stream)

    if stream.peek().type != TokenType.LPAREN:
        raise UnexpectedTokenException(stream.peek(), "Expected '(' after function name.")
    stream.next()  # Consume '('

    taken_names: set[str] = set()

    variables: list[VariableDefinition] = []
    parameters: list[ParameterDefinition] = []

    while stream.peek().type != TokenType.RPAREN:
        param_def, param_pos = parse_parameter_definition(stream)
        if param_def.name in taken_names:
            raise ParseException(
                param_pos,
                f"Duplicate parameter name '{param_def.name}' in function '{func_name}'.",
            )

        taken_names.add(param_def.name)
        parameters.append(param_def)
        variables.append(
            VariableDefinition(name=param_def.name, type=param_def.type, is_mutable=False)
        )

        if stream.peek().type == TokenType.COMMA:
            stream.next()  # Consume ','
        elif stream.peek().type != TokenType.RPAREN:
            raise UnexpectedTokenException(
                stream.peek(), "Expected ',' or ')' after parameter definition."
            )
    stream.next()  # Consume ')'

    if stream.peek().type != TokenType.ARROW:
        raise UnexpectedTokenException(stream.peek(), "Expected '->' after function parameters.")
    stream.next()  # Consume '->'

    return_type = parse_type(stream)

    if stream.peek().type == TokenType.LBRACKET:
        stream.next()  # Consume the first '['

        if stream.peek().type == TokenType.RBRACKET:
            raise UnexpectedTokenException(
                stream.peek(), "Expected variable definitions after '[' in function signature."
            )

        while stream.peek().type != TokenType.RBRACKET:
            var_def, var_pos = parse_variable_definition(stream)

            if var_def.name in taken_names:
                raise ParseException(
                    var_pos,
                    f"Duplicate variable name '{var_def.name}' in function '{func_name}'.",
                )

            taken_names.add(var_def.name)
            variables.append(var_def)

            if stream.peek().type == TokenType.COMMA:
                stream.next()  # Consume ','
            elif stream.peek().type != TokenType.RBRACKET:
                raise UnexpectedTokenException(
                    stream.peek(), "Expected ',' or ']' after variable definition."
                )
        stream.next()  # Consume ']'

    definition = FunctionSignature(
        name=func_name,
        parameters=parameters,
        return_type=return_type,
        variables=variables,
    )
    definition.assert_correct_variable_configuration()
    return definition


def parse_function(stream: TokenStream) -> FunctionBodyStatement:
    start_pos = stream.peek().position
    signature = parse_function_signature(stream)
    body = parse_block(stream)
    return with_position(FunctionBodyStatement(signature=signature, body=body), start_pos)
