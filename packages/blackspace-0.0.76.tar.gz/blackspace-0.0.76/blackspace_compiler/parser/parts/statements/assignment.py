from ....ast.expressions.expression import Expression
from ....ast.expressions.variables.array_index import ArrayIndex
from ....ast.expressions.variables.memory_fetch import MemoryFetch
from ....ast.expressions.variables.variable_access import VariableAccess
from ....ast.node import with_position
from ....ast.statements.assignment import AssignmentStatement
from ...exceptions import UnexpectedTokenException
from ...stream import TokenStream, TokenType
from ..expressions import parse_expression
from ..identifier import parse_identifier


def parse_assignment_target(stream: TokenStream) -> Expression:
    name, position = parse_identifier(stream)

    data_access: Expression = with_position(
        VariableAccess(name),
        position,
    )

    while stream.peek().type == TokenType.LBRACKET:
        # Array indexing

        openbr = stream.next()  # consume '['

        index = parse_expression(stream)
        if stream.peek().type != TokenType.RBRACKET:
            raise UnexpectedTokenException(stream.peek(), "Expected ']' after array index")
        stream.next()  # consume ']'

        data_access = with_position(
            ArrayIndex(with_position(MemoryFetch(data_access), openbr.position), index),
            openbr.position,
        )

    return data_access


def parse_assignment_fragment(stream: TokenStream) -> AssignmentStatement:
    target = parse_assignment_target(stream)

    if stream.peek().type != TokenType.ASSIGN:
        raise UnexpectedTokenException(stream.peek(), "Expected '=' after assignment target")
    assign_sign = stream.next()  # consume '='

    value = parse_expression(stream)

    return with_position(AssignmentStatement(target, value), assign_sign.position)


def parse_assignment_statement(stream: TokenStream) -> AssignmentStatement:
    statement = parse_assignment_fragment(stream)

    if stream.peek().type != TokenType.SEMICOLON:
        raise UnexpectedTokenException(
            stream.peek(), "Expected ';' at the end of an assignment statement"
        )
    stream.next()  # consume ';'

    return statement
