from ....ast.node import with_position
from ....ast.statements.function import ReturnStatement
from ...exceptions import UnexpectedTokenException
from ...stream import TokenStream, TokenType
from ..expressions import parse_expression


def parse_return_statement(stream: TokenStream) -> ReturnStatement:
    if stream.peek().type != TokenType.KW_RETURN:
        raise UnexpectedTokenException(
            stream.peek(), "Expected 'return' keyword at the beginning of a return statement"
        )
    return_sign = stream.next()  # consume 'return'

    if stream.peek().type == TokenType.SEMICOLON:
        stream.next()  # consume ';'
        return with_position(ReturnStatement(None), return_sign.position)

    value = parse_expression(stream)

    if stream.peek().type != TokenType.SEMICOLON:
        raise UnexpectedTokenException(
            stream.peek(), "Expected ';' at the end of a return statement"
        )
    stream.next()  # consume ';'
    return with_position(ReturnStatement(value), return_sign.position)
