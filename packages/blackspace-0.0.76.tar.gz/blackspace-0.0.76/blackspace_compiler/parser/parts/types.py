from ...ast.types.complex.array import ArrayType
from ...ast.types.complex.string import StringType
from ...ast.types.primitives.bool import BooleanType
from ...ast.types.primitives.int import IntegerType
from ...ast.types.primitives.void import VoidType
from ...ast.types.type import Type
from ..exceptions import UnexpectedTokenException
from ..stream import TokenStream, TokenType


def parse_type(stream: TokenStream) -> Type:
    token = stream.peek()

    base_type: Type | None = None
    allow_arrays = True

    if token.type == TokenType.KW_INT:
        base_type = IntegerType()
    elif token.type == TokenType.KW_BOOL:
        base_type = BooleanType()
    elif token.type == TokenType.KW_VOID:
        base_type = VoidType()
        allow_arrays = False
    elif token.type == TokenType.KW_STRING:
        base_type = StringType()
    else:
        raise UnexpectedTokenException(token, "Expected type")

    stream.next()  # consume the type token

    while allow_arrays:
        if stream.peek().type == TokenType.LBRACKET:
            stream_checkpoint = stream.checkpoint()
            stream.next()  # consume the '['

            if stream.peek().type == TokenType.RBRACKET:
                stream.next()  # consume the ']'
                base_type = ArrayType(base_type)
            else:
                stream.restore(stream_checkpoint)
                break
        else:
            break

    return base_type
