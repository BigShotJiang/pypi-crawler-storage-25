from ...ast.node import SourcePosition
from ..exceptions import UnexpectedTokenException
from ..stream import TokenStream, TokenType


def parse_identifier(stream: TokenStream) -> tuple[str, SourcePosition]:
    token = stream.peek()
    if token.type != TokenType.IDENTIFIER:
        raise UnexpectedTokenException(token, "Expected identifier")
    if token.value is None:
        raise UnexpectedTokenException(token, "Identifier token has no value")

    stream.next()  # consume the identifier token
    return (token.value, token.position)
