from ...ast.expressions.builtinfunctions.sizeof import SizeofExpression
from ...ast.expressions.expression import Expression
from ...ast.expressions.functions.function_call import FunctionCall
from ...ast.expressions.io.print_expr import PrintExpression, PrintMode
from ...ast.expressions.io.read_expr import ReadExpression, ReadMode
from ...ast.node import SourcePosition
from ..exceptions import ParseException


def create_function_call(
    position: SourcePosition,
    func_name: str,
    args: list[Expression],
) -> Expression:
    if func_name == "sizeof":
        if len(args) != 1:
            raise ParseException(position, "sizeof expects exactly one argument")
        return SizeofExpression(args[0])
    elif func_name == "print_int":
        if len(args) != 1:
            raise ParseException(position, "print_int expects exactly one argument")
        return PrintExpression(args[0], PrintMode.Number)
    elif func_name == "print_text":
        if len(args) != 1:
            raise ParseException(position, "print_text expects exactly one argument")
        return PrintExpression(args[0], PrintMode.Character)
    elif func_name == "read_int":
        if len(args) != 0:
            raise ParseException(position, "read_int expects no arguments")
        return ReadExpression(ReadMode.Number)
    elif func_name == "read_text":
        if len(args) != 0:
            raise ParseException(position, "read_text expects no arguments")
        return ReadExpression(ReadMode.Character)
    else:
        return FunctionCall(func_name, args)
