from ...ast.expressions.expression import Expression
from ...ast.expressions.literals.bool import FalseLiteral, TrueLiteral
from ...ast.expressions.literals.int import IntLiteral
from ...ast.expressions.operations.arithmetic import (
    AddOperator,
    DivideOperator,
    ModuloOperator,
    MultiplyOperator,
    SubtractOperator,
)
from ...ast.expressions.operations.boolean import AndOperator, NotOperator, OrOperator
from ...ast.expressions.operations.comparison import (
    EqualOperator,
    GreaterOrEqualThanOperator,
    GreaterThanOperator,
    LessOrEqualThanOperator,
    LessThanOperator,
    NotEqualOperator,
)
from ...ast.expressions.operations.operator import BinaryOperator
from ...ast.expressions.variables.array_index import ArrayIndex
from ...ast.expressions.variables.memory_fetch import MemoryFetch
from ...ast.expressions.variables.variable_access import VariableAccess
from ...ast.node import with_position
from ..exceptions import UnexpectedTokenException
from ..stream import TokenStream, TokenType
from .function_call import create_function_call
from .identifier import parse_identifier
from .literals import parse_bool_literal, parse_int_literal, parse_string_literal


def parse_variable_or_function_call(stream: TokenStream) -> Expression:
    name, position = parse_identifier(stream)

    if stream.peek().type == TokenType.LPAREN:
        stream.next()  # consume '('

        # function call
        args: list[Expression] = []

        while True:
            if stream.peek().type == TokenType.RPAREN:
                stream.next()  # consume ')'
                break
            args.append(parse_expression(stream))

            if stream.peek().type == TokenType.COMMA:
                stream.next()  # consume ','
                continue
            elif stream.peek().type != TokenType.RPAREN:
                raise UnexpectedTokenException(
                    stream.peek(), "Expected ',' or ')' after function argument"
                )

        return with_position(create_function_call(position, name, args), position)
    else:
        data_access: Expression = with_position(
            MemoryFetch(
                with_position(
                    VariableAccess(name),
                    position,
                )
            ),
            position,
        )

        while stream.peek().type == TokenType.LBRACKET:
            # Array indexing

            openbr = stream.next()  # consume '['

            index = parse_expression(stream)
            if stream.peek().type != TokenType.RBRACKET:
                raise UnexpectedTokenException(stream.peek(), "Expected ']' after array index")
            stream.next()  # consume ']'

            data_access = with_position(
                MemoryFetch(
                    with_position(
                        ArrayIndex(data_access, index),
                        openbr.position,
                    ),
                ),
                openbr.position,
            )

        return data_access


def parse_primary_expression(stream: TokenStream) -> Expression:
    token = stream.peek()

    if token.type == TokenType.INT_LITERAL:
        return parse_int_literal(stream)
    elif token.type == TokenType.STRING_LITERAL:
        return parse_string_literal(stream)
    elif token.type in [TokenType.TRUE, TokenType.FALSE]:
        return parse_bool_literal(stream)
    elif token.type == TokenType.IDENTIFIER:
        return parse_variable_or_function_call(stream)
    elif token.type == TokenType.LPAREN:
        stream.next()  # consume '('
        expr = parse_expression(stream)
        if stream.peek().type != TokenType.RPAREN:
            raise UnexpectedTokenException(stream.peek(), "Expected ')' after expression")
        stream.next()  # consume ')'
        return expr
    else:
        raise UnexpectedTokenException(token, f"Unexpected token: {token.type}")


def parse_unary_expression(stream: TokenStream) -> Expression:
    token = stream.peek()

    if token.type == TokenType.MINUS:
        stream.next()  # consume the '-'
        inner_expr = parse_unary_expression(stream)
        if isinstance(inner_expr, IntLiteral):
            # Constant folding for negative integers
            return with_position(IntLiteral(-inner_expr.value), token.position)
        else:
            return with_position(SubtractOperator(IntLiteral(0), inner_expr), token.position)
    elif token.type == TokenType.NOT:
        stream.next()  # consume the '!'
        inner_expr = parse_unary_expression(stream)
        if isinstance(inner_expr, TrueLiteral):
            return with_position(FalseLiteral(), token.position)
        elif isinstance(inner_expr, FalseLiteral):
            return with_position(TrueLiteral(), token.position)
        else:
            return with_position(NotOperator(inner_expr), token.position)
    else:
        return parse_primary_expression(stream)


BINARY_OPERATORS: dict[TokenType, tuple[int, type[BinaryOperator]]] = {
    TokenType.STAR: (7, MultiplyOperator),
    TokenType.SLASH: (7, DivideOperator),
    TokenType.PERCENT: (7, ModuloOperator),
    TokenType.PLUS: (6, AddOperator),
    TokenType.MINUS: (6, SubtractOperator),
    TokenType.LT: (5, LessThanOperator),
    TokenType.LTE: (5, LessOrEqualThanOperator),
    TokenType.GT: (5, GreaterThanOperator),
    TokenType.GTE: (5, GreaterOrEqualThanOperator),
    TokenType.EQ: (4, EqualOperator),
    TokenType.NEQ: (4, NotEqualOperator),
    TokenType.AND: (3, AndOperator),
    TokenType.OR: (2, OrOperator),
}


def parse_binary_expression(stream: TokenStream, min_precedence: int = 0) -> Expression:
    left_expr = parse_unary_expression(stream)

    while True:
        token = stream.peek()
        op_info = BINARY_OPERATORS.get(token.type)
        if not op_info:
            break

        precedence, operator_class = op_info
        if precedence < min_precedence:
            break

        stream.next()  # consume the operator
        right_expr = parse_binary_expression(stream, precedence + 1)
        left_expr = with_position(operator_class(left_expr, right_expr), token.position)

    return left_expr


def parse_expression(stream: TokenStream) -> Expression:
    return parse_binary_expression(stream)
