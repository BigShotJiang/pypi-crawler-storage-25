from ...ast.expressions.literals.bool import FalseLiteral, TrueLiteral
from ...ast.expressions.literals.int import IntLiteral
from ...ast.expressions.literals.string import StringLiteral
from ...ast.node import with_position
from ..exceptions import UnexpectedTokenException
from ..stream import TokenStream, TokenType


def parse_int_literal(stream: TokenStream) -> IntLiteral:
    token = stream.peek()
    if token.type != TokenType.INT_LITERAL:
        raise UnexpectedTokenException(token, "Expected integer literal")
    if token.value is None:
        raise UnexpectedTokenException(token, "Integer literal token has no value")
    stream.next()  # consume the integer literal token
    return with_position(IntLiteral(int(token.value)), token.position)


def parse_bool_literal(stream: TokenStream) -> TrueLiteral | FalseLiteral:
    token = stream.peek()
    if token.type == TokenType.TRUE:
        stream.next()
        return with_position(TrueLiteral(), token.position)
    elif token.type == TokenType.FALSE:
        stream.next()
        return with_position(FalseLiteral(), token.position)
    else:
        raise UnexpectedTokenException(token, "Expected boolean literal")


def parse_string_literal(stream: TokenStream) -> StringLiteral:
    token = stream.peek()
    if token.type != TokenType.STRING_LITERAL:
        raise UnexpectedTokenException(token, "Expected string literal")
    if token.value is None:
        raise UnexpectedTokenException(token, "String literal token has no value")
    stream.next()  # consume the string literal token
    return with_position(StringLiteral(token.value), token.position)
