RESERVED_KEYWORDS = set(
    [
        "int",
        "bool",
        "void",
        "string",
        "true",
        "false",
        "if",
        "else",
        "while",
        "for",
        "return",
        "fn",
        "var",
        "const",
    ]
)
