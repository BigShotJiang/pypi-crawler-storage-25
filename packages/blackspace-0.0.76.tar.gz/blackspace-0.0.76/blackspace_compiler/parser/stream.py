from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto

from ..ast.node import SourcePosition
from .exceptions import ParseException

KEYWORD_CHARS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")


class TextStream:
    def __init__(self, text: str) -> None:
        self.text = text
        self.pos = 0

    def peek(self, n: int = 1) -> str:
        return self.text[self.pos : self.pos + n]

    def next(self, n: int = 1) -> str:
        result = self.peek(n)
        self.pos += n
        return result

    def match(self, s: str) -> bool:
        """
        Mathes the string `s` at the current position. If it matches,
        advances the position and returns True.
        """
        if self.peek(len(s)) == s:
            self.pos += len(s)
            return True
        return False

    def match_keyword(self, s: str) -> bool:
        """
        Mathes the string `s` at the current position, ensuring that it is not
        followed by an alphanumeric character (to avoid matching keywords that are prefixes
        of longer identifiers).
        If it matches, advances the position and returns True.
        """
        if self.peek(len(s)) == s:
            next_char = self.peek(len(s) + 1)[-1] if len(self.peek(len(s) + 1)) > len(s) else None
            if next_char is None or next_char not in KEYWORD_CHARS:
                self.pos += len(s)
                return True
        return False

    def match_regex(self, pattern: str) -> str | None:
        """
        Matches the regex pattern at the current position. If it matches, advances the position
        and returns the matched string. Otherwise, returns None.
        """
        regex = re.compile(pattern)
        match = regex.match(self.text, self.pos)
        if match:
            self.pos = match.end()
            return match.group(0)
        return None

    def skip_whitespace(self) -> None:
        while self.peek() and self.peek().isspace():
            self.pos += 1

    def current_position(self) -> SourcePosition:
        # TODO: Track line and column numbers for better optimized reporting
        before = self.text[: self.pos]
        line = before.count("\n") + 1
        column = len(before.split("\n")[-1]) + 1
        return SourcePosition(line, column)

    def is_eof(self) -> bool:
        return self.pos >= len(self.text)

    def checkpoint(self) -> TextStream:
        checkpoint = TextStream(self.text)
        checkpoint.pos = self.pos
        return checkpoint


class TokenType(Enum):
    IDENTIFIER = auto()
    INT_LITERAL = auto()
    STRING_LITERAL = auto()

    TRUE = auto()
    FALSE = auto()

    KW_INT = auto()
    KW_BOOL = auto()
    KW_VOID = auto()
    KW_STRING = auto()
    KW_IF = auto()
    KW_ELSE = auto()
    KW_WHILE = auto()
    KW_DO = auto()
    KW_FOR = auto()
    KW_RETURN = auto()
    KW_FN = auto()
    KW_VAR = auto()
    KW_CONST = auto()

    LPAREN = auto()
    RPAREN = auto()
    LBRACE = auto()
    RBRACE = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    SEMICOLON = auto()
    COLON = auto()
    ARROW = auto()

    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    PERCENT = auto()
    ASSIGN = auto()
    EQ = auto()
    NEQ = auto()
    LT = auto()
    GT = auto()
    LTE = auto()
    GTE = auto()
    AND = auto()
    OR = auto()
    NOT = auto()

    EOF = auto()


@dataclass(frozen=True)
class Token:
    type: TokenType
    value: str | None
    position: SourcePosition


WELL_KNOWN_KEYWORDS: dict[str, TokenType] = {
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,
    "int": TokenType.KW_INT,
    "bool": TokenType.KW_BOOL,
    "void": TokenType.KW_VOID,
    "string": TokenType.KW_STRING,
    "if": TokenType.KW_IF,
    "else": TokenType.KW_ELSE,
    "while": TokenType.KW_WHILE,
    "do": TokenType.KW_DO,
    "for": TokenType.KW_FOR,
    "return": TokenType.KW_RETURN,
    "fn": TokenType.KW_FN,
    "var": TokenType.KW_VAR,
    "const": TokenType.KW_CONST,
}

WELL_KNOWM_SYMBOLS: dict[str, TokenType] = {
    "(": TokenType.LPAREN,
    ")": TokenType.RPAREN,
    "{": TokenType.LBRACE,
    "}": TokenType.RBRACE,
    "[": TokenType.LBRACKET,
    "]": TokenType.RBRACKET,
    ",": TokenType.COMMA,
    ";": TokenType.SEMICOLON,
    ":": TokenType.COLON,
    "->": TokenType.ARROW,
    "+": TokenType.PLUS,
    "-": TokenType.MINUS,
    "*": TokenType.STAR,
    "/": TokenType.SLASH,
    "%": TokenType.PERCENT,
    "==": TokenType.EQ,
    "!=": TokenType.NEQ,
    "=": TokenType.ASSIGN,
    "<=": TokenType.LTE,
    ">=": TokenType.GTE,
    ">": TokenType.GT,
    "<": TokenType.LT,
    "&&": TokenType.AND,
    "||": TokenType.OR,
    "!": TokenType.NOT,
}


def _parse_string_literal(stream: TextStream) -> str:
    if not stream.match('"'):
        raise ParseException(stream.current_position(), "Expected string literal")

    string_value: str = ""
    while not stream.match('"'):
        if stream.is_eof():
            raise ParseException(stream.current_position(), "Unterminated string literal")
        elif stream.match("\\"):
            if stream.is_eof():
                raise ParseException(stream.current_position(), "Unterminated string literal")
            escape_char = stream.next()
            if escape_char == "n":
                string_value += "\n"
            elif escape_char == "t":
                string_value += "\t"
            elif escape_char == '"':
                string_value += '"'
            elif escape_char == "\\":
                string_value += "\\"
            else:
                raise ParseException(
                    stream.current_position(), f"Invalid escape character: \\{escape_char}"
                )
        elif stream.match("\n"):
            raise ParseException(stream.current_position(), "Unterminated string literal")
        else:
            string_value += stream.next()

    return string_value


class TokenStream:
    def __init__(self, text_stream: TextStream) -> None:
        self._text = text_stream
        self._buffer: list[Token] = []

    def peek(self) -> Token:
        while len(self._buffer) < 1:
            self._buffer.append(self._next_token())
        return self._buffer[0]

    def next(self) -> Token:
        while len(self._buffer) < 1:
            self._buffer.append(self._next_token())
        return self._buffer.pop(0)

    def is_eof(self) -> bool:
        return self.peek().type == TokenType.EOF

    def _next_token(self) -> Token:
        self._text.skip_whitespace()
        pos = self._text.current_position()

        if self._text.is_eof():
            return Token(TokenType.EOF, None, pos)

        # Keywords and identifiers
        if self._text.peek().isalpha() or self._text.peek() == "_":
            identifier = self._text.match_regex(r"[a-zA-Z_][a-zA-Z0-9_]*")

            if identifier is not None:
                if identifier in WELL_KNOWN_KEYWORDS:
                    return Token(WELL_KNOWN_KEYWORDS[identifier], None, pos)
                else:
                    return Token(TokenType.IDENTIFIER, identifier, pos)

        # Integer literals
        if self._text.peek().isdigit():
            int_literal = self._text.match_regex(r"\d+")
            return Token(TokenType.INT_LITERAL, int_literal, pos)

        # String literals
        if self._text.peek() == '"':
            string_literal = _parse_string_literal(self._text)
            return Token(TokenType.STRING_LITERAL, string_literal, pos)

        # Symbols
        for symbol, token_type in sorted(
            WELL_KNOWM_SYMBOLS.items(),
            key=lambda item: -len(item[0]),
        ):
            if self._text.match(symbol):
                return Token(token_type, None, pos)

        raise ParseException(
            self._text.current_position(), f"Unexpected character: {self._text.peek()}"
        )

    def checkpoint(self) -> TokenStream:
        checkpoint = TokenStream(self._text.checkpoint())
        checkpoint._buffer = self._buffer.copy()
        return checkpoint

    def restore(self, checkpoint: TokenStream) -> None:
        self._text = checkpoint._text
        self._buffer = checkpoint._buffer.copy()
