from ..ast.statements.program import Program
from .parts.program import parse_program
from .stream import TextStream, TokenStream


def parse(text: str) -> Program:
    text_stream = TextStream(text)
    token_stream = TokenStream(text_stream)
    return parse_program(token_stream)
