from __future__ import annotations

from typing import TYPE_CHECKING

from ..ast.node import SourcePosition

if TYPE_CHECKING:
    from .stream import Token


class ParseException(Exception):

    def __init__(self, position: SourcePosition, message: str) -> None:
        super().__init__(f"{message} (at position {position})")


class UnexpectedTokenException(ParseException):
    def __init__(self, token: Token, message: str) -> None:
        Exception.__init__(
            self, f"{message} (at line {token.position.line}, column {token.position.column})"
        )
