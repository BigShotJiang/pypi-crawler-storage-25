"""
Test the return workflow using async aexecute / aresume with a real LLM.
Run from repo root: python examples/test_return_async.py
"""
import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # so return_functions is importable

from soprano_sdk import WorkflowTool

YAML_PATH = os.path.join(os.path.dirname(__file__), "return_workflow.yaml")


async def main():
    tool = WorkflowTool(
        yaml_path=YAML_PATH,
        name="return_workflow",
        description="Return processing workflow",
        config={
            "model_config": {
                "model_name": "gpt-4o-mini",
                "api_key": os.environ["OPENAI_API_KEY"],
            },
            "humanization_agent": {"enabled": False},
        },
    )

    thread_id = "async-test-1"
    print("=" * 60)
    print("ASYNC RETURN WORKFLOW TEST")
    print("=" * 60)

    # Turn 1: start workflow — should ask for order ID
    print("\n--- Turn 1: Start workflow ---")
    r1 = await tool.aexecute(thread_id=thread_id, initial_context={})
    print(f"Bot: {r1.text}")
    print(f"  [raw type: {type(r1).__name__}, message length: {len(str(r1))}]")

    # Turn 2: provide order ID
    print("\n--- Turn 2: Provide order ID ---")
    print("User: ORD-12345")
    r2 = await tool.aexecute(thread_id=thread_id, user_message="ORD-12345")
    print(f"Bot: {r2.text}")
    print(f"  [raw type: {type(r2).__name__}]")

    # Check if workflow needs more input (collect_reason) or completed (eligibility failed)
    if "__WORKFLOW_INTERRUPT__" in str(r2):
        # Turn 3: provide return reason
        print("\n--- Turn 3: Provide return reason ---")
        print("User: The item arrived damaged")
        r3 = await tool.aexecute(thread_id=thread_id, user_message="The item arrived damaged")
        print(f"Bot: {r3.text}")
        print(f"  [raw type: {type(r3).__name__}]")
    else:
        print("  (workflow completed — eligibility check returned false)")

    print("\n" + "=" * 60)
    print("ASYNC TEST COMPLETE")
    print("=" * 60)

    # Now run the same workflow SYNC for comparison
    print("\n\n")
    print("=" * 60)
    print("SYNC RETURN WORKFLOW TEST (for comparison)")
    print("=" * 60)

    thread_id_sync = "sync-test-1"

    print("\n--- Turn 1: Start workflow ---")
    s1 = tool.execute(thread_id=thread_id_sync, initial_context={})
    print(f"Bot: {s1.text}")

    print("\n--- Turn 2: Provide order ID ---")
    print("User: ORD-12345")
    s2 = tool.execute(thread_id=thread_id_sync, user_message="ORD-12345")
    print(f"Bot: {s2.text}")

    if "__WORKFLOW_INTERRUPT__" in str(s2):
        print("\n--- Turn 3: Provide return reason ---")
        print("User: The item arrived damaged")
        s3 = tool.execute(thread_id=thread_id_sync, user_message="The item arrived damaged")
        print(f"Bot: {s3.text}")
    else:
        print("  (workflow completed — eligibility check returned false)")

    print("\n" + "=" * 60)
    print("SYNC TEST COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
