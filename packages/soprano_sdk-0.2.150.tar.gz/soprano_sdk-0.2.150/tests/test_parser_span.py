from unittest.mock import MagicMock, patch
from pydantic import BaseModel
from typing import Optional

from soprano_sdk.utils.parser import convert_to_dict
from soprano_sdk.utils.tracing import NullSpan


class SimpleSchema(BaseModel):
    reasoning: Optional[str] = None
    bot_response: Optional[str] = None


def test_convert_to_dict_disable_span_true():
    """Verify that convert_to_dict works correctly when disable_span=True."""
    response = '{"reasoning": "test", "bot_response": "hello"}'
    
    # Use a patch to verify _create_span is NOT called
    with patch("soprano_sdk.utils.parser._create_span") as mock_create_span:
        result = convert_to_dict(response, disable_span=True)
        
        assert result == {"reasoning": "test", "bot_response": "hello"}
        mock_create_span.assert_not_called()


def test_convert_to_dict_disable_span_false():
    """Verify that convert_to_dict calls _create_span by default (or when False)."""
    response = '{"key": "value"}'
    
    with patch("soprano_sdk.utils.parser._create_span") as mock_create_span:
        # Mock _create_span to return a mock context manager
        mock_span = MagicMock()
        mock_span.is_recording.return_value = False
        mock_create_span.return_value.__enter__.return_value = mock_span
        
        result = convert_to_dict(response, disable_span=False)
        
        assert result == {"key": "value"}
        mock_create_span.assert_called_once()


def test_convert_to_dict_with_schema_disable_span():
    """Verify schema-aware repair works with disable_span=True."""
    # Unquoted reasoning
    response = '{"reasoning": The user said No, "bot_response": "Ok"}'
    
    result = convert_to_dict(response, schema=SimpleSchema, disable_span=True)
    
    assert isinstance(result, dict)
    assert result["reasoning"] == "The user said No"
    assert result["bot_response"] == "Ok"


def test_null_span_behavior():
    """Verify NullSpan implements the expected interface."""
    span = NullSpan()
    assert span.is_recording() is False
    # Should not raise any error
    span.set_attribute("key", "value")
    
    with span as s:
        assert s is span
        s.set_attribute("another", "one")
