from unittest.mock import MagicMock, patch
from soprano_sdk.nodes.follow_up import FollowUpStrategy
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.agents.structured_output import FollowUpOutput

def test_follow_up_summary_injection_logic():
    """Unit test to verify that FollowUpStrategy.execute injects summary 
    into LLM context but keeps persistent state clean.
    """
    # 1. Setup mock engine context
    engine_ctx = MagicMock()
    # Mock build_field_details to return something
    engine_ctx.build_field_details.return_value = []
    # Mock humanization config
    engine_ctx.get_config_value.side_effect = lambda k, default=None: default
    
    # 2. Setup strategy
    follow_up_config = {"id": "test_follow_up", "action": "follow_up"}
    strategy = FollowUpStrategy(follow_up_config, engine_ctx, first_step_id="collect_a")
    
    # 3. Setup state
    summary_text = "User wants to check balance."
    # Initialize conversation key in state to prevent early exit and return state
    conv_key = strategy._conversation_key
    state = {
        WorkflowKeys.CONVERSATIONS: {conv_key: []},
        WorkflowKeys.CONVERSATION_SUMMARY: summary_text,
        WorkflowKeys.FOLLOW_UP_PENDING_PROMPT: {"text": "How can I help?"},
        WorkflowKeys.STATUS: "test_follow_up_answering"
    }
    
    # 4. Mock interrupt to simulate user saying "Check balance"
    # and mock _get_agent_response to capture what's sent to LLM
    with patch("soprano_sdk.nodes.follow_up.interrupt", return_value="Check balance"):
        with patch.object(strategy, "_get_agent_response") as mock_agent_call:
            # Return actual FollowUpOutput so model_dump/json.dumps works
            mock_agent_call.return_value = FollowUpOutput(bot_response="OK")
            
            # Execute
            strategy.execute(state)
            
            # Verify injection in LLM conversation
            sent_conv = mock_agent_call.call_args[0][1]
            last_msg = sent_conv[-1]
            
            assert last_msg["role"] == "user"
            assert "[CONTEXT SUMMARY of previous conversation: User wants to check balance.]" in last_msg["content"]
            assert "Check balance" in last_msg["content"]
            
            # 5. Verify persistent state is CLEAN
            conv_key = f"{strategy.step_id}_conversation" # Default key
            history = state[WorkflowKeys.CONVERSATIONS][conv_key]
            
            # The history contains [User message, Assistant response]
            assert len(history) == 2
            
            stored_user_msg = history[-2]
            assert stored_user_msg["role"] == "user"
            assert stored_user_msg["content"] == "Check balance"
            assert "CONTEXT SUMMARY" not in stored_user_msg["content"]
            
            stored_agent_msg = history[-1]
            assert stored_agent_msg["role"] == "assistant"
            
            print("Injection and persistence validation PASSED")
