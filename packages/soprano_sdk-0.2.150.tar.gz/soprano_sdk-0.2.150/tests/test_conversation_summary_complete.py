import uuid
import respx
import json

from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.nodes.collect_input import (
    _build_workflow_context_summary,
    _get_step_patterns,
    _extract_collected_data,
    _aggregate_tagged_messages,
    _format_conversation_history
)
from soprano_sdk.core.constants import WorkflowKeys
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_prompt,
    collector_capture,
    make_tool
)
from soprano_sdk.utils.text_utils import extract_pattern_match

# --- Unit Tests ---

def test_extract_pattern_match_refined():
    patterns = ["NAME_CAPTURED:", "AGE_GIVEN"]
    field_name = "user_name"
    
    # Case 1: Value present (Name Captured)
    res = extract_pattern_match("NAME_CAPTURED: John", patterns, field_name)
    assert res == "(collected User Name): John (Name Captured)"
    
    # Case 2: Value empty (signaled transition)
    res = extract_pattern_match("NAME_CAPTURED:", patterns, field_name)
    assert res == "(signaled transition): Name Captured"
    
    # Case 3: Different pattern (ends in nothing)
    res = extract_pattern_match("AGE_GIVEN", ["AGE_GIVEN"], "age")
    assert res == "(signaled transition): Age Given"

def test_get_step_patterns():
    step_config_map = {
        "step_1": {
            "agent": {"structured_output": {"enabled": False}},
            "transitions": [
                {"pattern": "YES:"},
                {"pattern": ["NO:", "NEIN:"]}
            ]
        },
        "step_so": {
            "agent": {"structured_output": {"enabled": True}},
            "transitions": [{"pattern": "HIDDEN:"}]
        }
    }
    
    assert _get_step_patterns(step_config_map, "step_1") == ["YES:", "NO:", "NEIN:"]
    assert _get_step_patterns(step_config_map, "step_so") == []
    assert _get_step_patterns(None, "step_1") == []
    assert _get_step_patterns(step_config_map, "unknown") == []

def test_extract_collected_data():
    state = {
        "user_name": "Alice",
        "age": 30,
        WorkflowKeys.NODE_EXECUTION_ORDER: ["step_1", "step_2"],
        WorkflowKeys.NODE_FIELD_MAP: {
            "step_1": "user_name",
            "step_2": ["age", "backup_field"]
        }
    }
    
    collected_lines, conv_key_to_info = _extract_collected_data(
        state[WorkflowKeys.NODE_EXECUTION_ORDER],
        state[WorkflowKeys.NODE_FIELD_MAP],
        state
    )
    
    assert "- User Name: Alice" in collected_lines
    assert "- Age: 30" in collected_lines
    assert "user_name_conversation" in conv_key_to_info
    assert conv_key_to_info["user_name_conversation"]["label"] == "Step 1"
    assert "age_conversation" in conv_key_to_info
    assert conv_key_to_info["age_conversation"]["label"] == "Step 2"

def test_aggregate_tagged_messages():
    conversations = {
        "c1": [{"role": "user", "content": "hello", "timestamp": "1"}],
        "c2": [{"role": "assistant", "content": "hi", "timestamp": "2"}]
    }
    conv_key_to_info = {
        "c1": {"label": "Step 1", "field": "f1", "patterns": []},
        "c2": {"label": "Step 2", "field": "f2", "patterns": []}
    }
    
    all_msgs = _aggregate_tagged_messages(conversations, conv_key_to_info)
    
    assert len(all_msgs) == 2
    assert all_msgs[0]["content"] == "hello"
    assert all_msgs[0]["_label"] == "Step 1"
    assert all_msgs[1]["content"] == "hi"
    assert all_msgs[1]["_label"] == "Step 2"

def test_format_conversation_history():
    all_msgs = [
        {"role": "assistant", "content": "Step 1 prompt", "_label": "Step 1", "timestamp": "1"},
        {"role": "user", "content": "Step 1 answer", "_label": "Step 1", "timestamp": "2"},
        {"role": "assistant", "content": "Step 2 prompt", "_label": "Step 2", "timestamp": "3"}
    ]
    
    sections = _format_conversation_history(all_msgs)
    
    expected = [
        "[Step: Step 1]",
        "Agent: Step 1 prompt",
        "User: Step 1 answer",
        "[Step: Step 2]",
        "Agent: Step 2 prompt"
    ]
    assert sections == expected

# --- Functional Tests ---

def test_build_workflow_context_summary_empty():
    assert _build_workflow_context_summary({}) == ""

def test_build_workflow_context_summary_full():
    state = {
        "user_name": "Alice",
        WorkflowKeys.NODE_EXECUTION_ORDER: ["step_1"],
        WorkflowKeys.NODE_FIELD_MAP: {"step_1": "user_name"},
        WorkflowKeys.CONVERSATIONS: {
            "user_name_conversation": [
                {"role": "assistant", "content": "What is your name?", "timestamp": "1"},
                {"role": "user", "content": "I am Alice", "timestamp": "2"}
            ]
        }
    }
    
    summary = _build_workflow_context_summary(state)
    
    assert "<workflow_state>" in summary
    assert "COLLECTED DATA:" in summary
    assert "- User Name: Alice" in summary
    assert "CONVERSATION HISTORY:" in summary
    assert "[Step: Step 1]" in summary
    assert "Agent: What is your name?" in summary
    assert "User: I am Alice" in summary

# --- RESPX Integration Tests ---

@respx.mock
def test_collect_input_prompt_building_with_respx():
    """
    Verify that the actual prompt built during workflow execution reflects
    the new grouped conversation history format.
    """
    # 3 calls: collect_a prompt, ValA capture, then collect_b prompt (where we check history)
    responses = iter([
        collector_prompt("Collect A prompt"),                  # LLM#1: collect_a prompt
        collector_capture("ValA", field="field_a"),           # LLM#2: collect_a capture
        collector_prompt("Collect B prompt"),                  # LLM#3: collect_b prompt
    ])
    
    captured_requests = []
    def _capture(req):
        captured_requests.append(req)
        return next(responses)

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("follow_up_two_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # 1. Start (prompts for A)
    tool.execute(thread_id=tid, user_message="Start", initial_context={})
    
    # 2. Provide A (captured, then prompts for B)
    tool.execute(thread_id=tid, user_message="ValA", initial_context={})
    
    # Verify the third request (prompting for B)
    # It should contain the history of the first step (collect_a)
    assert len(captured_requests) == 3
    last_body = json.loads(captured_requests[2].content)
    # Find system message
    system_msgs = [m for m in last_body.get("messages", []) if m.get("role") == "system"]
    assert len(system_msgs) > 0
    system_msg = system_msgs[0]["content"]
    
    # Check for the new grouping format
    assert "[Step: Collect A]" in system_msg
    assert "Agent: Collect A prompt" in system_msg
    assert "User: ValA" in system_msg
    
    # Verify COLLECTED DATA (appears as dict in structured output mode)
    assert "COLLECTED DATA:" in system_msg
    assert "- Field A:" in system_msg
    assert "ValA" in system_msg
