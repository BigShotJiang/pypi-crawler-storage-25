import json
from soprano_sdk.utils.text_utils import extract_conversational_text, format_field_name

def test_format_field_name():
    assert format_field_name("user_name") == "User Name"
    assert format_field_name("NAME") == "Name"
    assert format_field_name("date_of_birth") == "Date Of Birth"
    assert format_field_name("") == ""

def test_extract_json_basic_text():
    # Test bot_response
    content = json.dumps({"bot_response": "Hello world"})
    assert extract_conversational_text(content) == "Hello world"
    
    # Test text
    content = json.dumps({"text": "Hello world"})
    assert extract_conversational_text(content) == "Hello world"
    
    # Test message (User's latest addition)
    content = json.dumps({"message": "Hello world"})
    assert extract_conversational_text(content) == "Hello world"

def test_extract_json_signals():
    # Intent change
    content = json.dumps({"intent_change": "collect_address", "bot_response": "Sure"})
    assert extract_conversational_text(content) == "(signaled intent change): collect_address"
    
    # Out of scope
    content = json.dumps({"out_of_scope": "Unsupported request", "bot_response": "Sorry"})
    assert extract_conversational_text(content) == "(signaled out of scope): Unsupported request"
    
    # Restart
    content = json.dumps({"restart": True, "bot_response": "Restarting"})
    assert extract_conversational_text(content) == "(signaled restart)"

def test_extract_json_collection():
    # Single field
    content = json.dumps({"name": "John Doe", "bot_response": None})
    assert extract_conversational_text(content) == "(collected Name): John Doe"
    
    # Multi field
    content = json.dumps({"name": "John Doe", "age": 30})
    # Order might depend on dict keys, but usually stable in modern python
    result = extract_conversational_text(content)
    assert "(collected Name): John Doe" in result
    assert "(collected Age): 30" in result
    
    # Collection + Text
    content = json.dumps({"name": "John Doe", "bot_response": "Got it!"})
    assert extract_conversational_text(content) == "(collected Name): John Doe Got it!"

def test_extract_json_metadata_exclusion():
    # Test that metadata keys are not treated as collected fields
    content = json.dumps({
        "bot_response": "Hello",
        "is_selectable": True,
        "timestamp": "2023-01-01",
        "options": [{"text": "Opt1"}]
    })
    result = extract_conversational_text(content)
    assert "(collected" not in result
    assert "Hello" in result
    assert "Options: Opt1" in result

def test_extract_json_options():
    content = json.dumps({
        "bot_response": "Choose one",
        "options": [{"text": "Red"}, {"text": "Blue"}]
    })
    result = extract_conversational_text(content)
    assert "Choose one" in result
    assert "Options: Red, Blue" in result

def test_extract_legacy_signals():
    # Intent change
    assert extract_conversational_text("INTENT_CHANGE: node1") == "(signaled intent change): node1"
    
    # Out of scope
    assert extract_conversational_text("OUT_OF_SCOPE: reason") == "(signaled out of scope): reason"
    
    # Case sensitivity check for legacy signals (should be exact match as per current code)
    assert extract_conversational_text("intent_change: node1") == "intent_change: node1"

def test_extract_plain_text():
    assert extract_conversational_text("Just a regular message") == "Just a regular message"
    assert extract_conversational_text("") == ""
    
    # RESTART is no longer a legacy signal (User removed it)
    assert extract_conversational_text("RESTART") == "RESTART"

def test_malformed_json():
    content = '{"invalid": json'
    assert extract_conversational_text(content) == content

def test_reasoning_excluded_from_collected_fields():
    # reasoning is a metadata key - should not appear as (collected Reasoning)
    content = json.dumps({"reasoning": "I decided to answer X because of Y.", "bot_response": "Here is your answer."})
    result = extract_conversational_text(content)
    assert "(collected Reasoning)" not in result
    assert "Here is your answer." in result

def test_reasoning_only_does_not_produce_collected_marker():
    # A response with only reasoning (no bot_response) should return empty string
    content = json.dumps({"reasoning": "Internal thought process."})
    result = extract_conversational_text(content)
    assert "(collected Reasoning)" not in result
    assert result == ""

def test_reasoning_with_real_collected_field():
    # A real collected field alongside reasoning - only the real field should appear
    content = json.dumps({"reasoning": "User said X.", "name": "Alice", "bot_response": None})
    result = extract_conversational_text(content)
    assert "(collected Reasoning)" not in result
    assert "(collected Name): Alice" in result

def test_reasoning_excluded_alongside_other_metadata():
    # All metadata keys (including reasoning) should be excluded together
    content = json.dumps({
        "bot_response": "Done.",
        "reasoning": "The user asked a follow-up.",
        "is_selectable": True,
        "timestamp": "2024-01-01",
        "options": [{"text": "Yes"}, {"text": "No"}],
    })
    result = extract_conversational_text(content)
    assert "(collected" not in result
    assert "Done." in result
    assert "Options: Yes, No" in result
