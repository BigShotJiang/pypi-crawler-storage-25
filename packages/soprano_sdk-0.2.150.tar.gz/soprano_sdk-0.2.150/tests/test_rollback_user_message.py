"""
Rollback _user_message regression tests.

Verifies that after a rollback, the _user_message in state does not retain
a stale value from a previous step's user input.

Bug: When a snapshot is saved before a node executes, _user_message still holds
the value from the *previous* turn (which completed the prior step). On rollback,
restoring this snapshot reintroduces that stale _user_message. When the target node
re-enters _generate_prompt, it reads this stale value and passes it to the LLM as
if the user just typed it — causing the LLM to see a previous step's input as the
current query.
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType, WorkflowKeys

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    make_tool,
    snap,
)


@respx.mock
def test_rollback_does_not_carry_previous_user_query_cross_step_rollback():
    """After rollback from step 2 to step 1, _user_message should not be step 1's
    previous input.

    Setup: 2-step SO workflow (collect_name → collect_status)

    T1: Initial → step 1 prompts "What is your name?"
    T2: User says "John" → step 1 captures name → step 2 prompts "What is your status?"
        (Snapshot before step 1 was saved with _user_message="" at T1)
    T3: User says "go back" → step 2's agent returns intent_change="collect_name"
        → rollback restores snapshot before step 1
        → step 1 re-enters _generate_prompt with _user_message="go back" (current)

    Regression: Without the fix, the snapshot's _user_message="" would be restored.
    With the fix, the current _user_message="go back" is preserved through rollback.
    Either way it must NOT be "John" (stale value from T2 that appeared in snapshot
    before step 2).

    Expected: _user_message should NOT be "John" after rollback.
    """
    responses = iter([
        # LLM#1: step 1 T1 - generate prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#2: step 1 T2 - capture name
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # LLM#3: step 2 T1 - generate prompt
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#4: step 2 T2 - user says "go back", rolls back to step 1
        llm_structured_response({
            "bot_response": None,
            "captured": False, "status": None,
            "intent_change": "collect_name",
            "options": None, "is_selectable": None,
        }),
        # LLM#5: step 1 re-prompt after rollback
        llm_structured_response({
            "bot_response": "What is your name (again)?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: step 1 initial prompt
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: step 1 captures "John" → advances to step 2 → step 2 prompts
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert InterruptType.USER_INPUT in str(result2)
    assert "What is your status?" in str(result2)

    # T3: user says "go back" → step 2 rolls back to step 1 → step 1 re-prompts
    result3 = tool.execute(thread_id=tid, user_message="go back", initial_context={})
    s3 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)
    assert "again" in str(result3)

    # ── KEY ASSERTION ──
    # After rollback, _user_message must NOT be "John" (the value that was in the
    # snapshot taken before step 2 ran, which captured "John" from T2).
    assert s3.get(WorkflowKeys.USER_MESSAGE) != "John", (
        "Bug: _user_message retains 'John' after rollback. "
        "The re-prompt LLM call received the previous step's query as current user message."
    )

    # Verify the LLM request for the re-prompt (LLM#5, index 4) did not receive
    # "John" as the sole user message.
    llm5_body = json.loads(respx.calls[4].request.content)
    llm5_messages = llm5_body.get("messages", [])
    llm5_user_msgs = [m["content"] for m in llm5_messages if m["role"] == "user"]
    assert not any(msg == "John" for msg in llm5_user_msgs), (
        f"Bug: re-prompt LLM call (LLM#5) received 'John' as user message. "
        f"User messages in request: {llm5_user_msgs}"
    )

    assert respx.calls.call_count == 5


@respx.mock
def test_rollback_cross_step_preserves_current_user_message():
    """Cross-step rollback preserves the current turn's _user_message.

    Setup: 2-step SO workflow (collect_name → collect_status)

    T1: Initial → step 1 prompts "What is your name?"
    T2: User says "John" → step 1 captures → step 2 starts
        → step 2's LLM immediately returns intent_change="collect_name"
        → rollback to step 1 → step 1 re-prompts

    The fix preserves the current _user_message through rollback rather than
    restoring a stale snapshot value. In this case, the current _user_message
    is "John" (from T2). Since the intent change was triggered by step 2's
    LLM on its initial run (not by a separate user query), "John" is the
    most recent user message and is preserved.

    This verifies that the snapshot's stale _user_message="" (from T1) does
    NOT overwrite the current value during rollback.
    """
    responses = iter([
        # LLM#1: step 1 T1 - generate prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#2: step 1 T2 - capture name
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # LLM#3: step 2 T1 - immediately returns intent_change (no prompt)
        llm_structured_response({
            "bot_response": None,
            "captured": False, "status": None,
            "intent_change": "collect_name",
            "options": None, "is_selectable": None,
        }),
        # LLM#4: step 1 T1 re-prompt after rollback
        llm_structured_response({
            "bot_response": "What is your name (again)?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: step 1 initial prompt
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: step 1 captures → step 2 starts → intent_change → rollback to step 1
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s2 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result2)
    assert "again" in str(result2)

    # name should be cleared by rollback
    assert s2.get("name") is None

    # _user_message is "John" — the current turn's message is preserved through
    # rollback. The snapshot before step 1 had _user_message="" (from T1), but
    # our fix overwrites it with the current value.
    assert s2.get(WorkflowKeys.USER_MESSAGE) == "John", (
        f"Expected _user_message='John' (current turn's message preserved through "
        f"rollback), got '{s2.get(WorkflowKeys.USER_MESSAGE)}'."
    )


@respx.mock
def test_rollback_node_n_minus_1_receives_query_from_node_n():
    """Node N-1 should receive the user query that triggered intent change in Node N.

    4-node workflow with a processing step:
      Node 1: collect_name  (collect_input_with_agent)
      Node 2: collect_age   (collect_input_with_agent)
      Node 3: validate_age  (call_function — processing node)
      Node 4: collect_status (collect_input_with_agent)

    Snapshots (only saved by collect_input_with_agent nodes):
      Before Node 1 (collect_name):   _user_message = ""      (initial invoke)
      Before Node 2 (collect_age):    _user_message = "John"   (completed Node 1)
      Before Node 4 (collect_status): _user_message = "25"     (completed Node 2;
                                       Node 3 runs in the same turn with no interrupt)

    Flow:
      T1: Initial → Node 1 prompts "What is your name?"
      T2: User says "John" → Node 1 captures → Node 2 prompts "How old are you?"
      T3: User says "25" → Node 2 captures → Node 3 validates (auto) → Node 4 prompts
      T4: User says "I want to change my age to 30"
          → Node 4 (N) detects intent_change="collect_age"
          → rollback to Node 2 (N-1)
          → Snapshot before Node 2 restored → _user_message = "John"
          → Node 2 re-enters _generate_prompt
          → LLM should see "I want to change my age to 30", NOT "John"

    Bug: Snapshot before Node 2 has _user_message="John" (from T2, which completed
    Node 1). After rollback, Node 2's LLM receives "John" — a completely unrelated
    answer from a different step — instead of the user's current query.
    """
    user_query = "I want to change my age to 30"

    responses = iter([
        # LLM#1: Node 1 T1 - prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#2: Node 1 T2 - capture name
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # LLM#3: Node 2 T1 - prompt
        llm_structured_response({
            "bot_response": "How old are you?",
            "captured": False, "age": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#4: Node 2 T2 - capture age
        # After this, Node 3 (validate_age) runs automatically (no LLM call),
        # then Node 4 starts.
        llm_structured_response({
            "bot_response": None,
            "captured": True, "age": "25",
            "options": None, "is_selectable": None,
        }),
        # LLM#5: Node 4 T1 - prompt (after Node 3 processing completes)
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#6: Node 4 T2 - user triggers intent change to Node 2
        llm_structured_response({
            "bot_response": None,
            "captured": False, "status": None,
            "intent_change": "collect_age",
            "options": None, "is_selectable": None,
        }),
        # LLM#7: Node 2 re-entry after rollback
        # Should see "I want to change my age to 30" and extract age=30
        llm_structured_response({
            "bot_response": None,
            "captured": True, "age": "30",
            "options": None, "is_selectable": None,
        }),
        # LLM#8: Node 4 re-entry after Node 2 recaptures + Node 3 reprocesses
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_three_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: Node 1 prompts
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: Node 1 captures "John" → Node 2 prompts
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert InterruptType.USER_INPUT in str(result2)
    assert "How old are you?" in str(result2)

    # T3: Node 2 captures "25" → Node 3 validates (auto) → Node 4 prompts
    result3 = tool.execute(thread_id=tid, user_message="25", initial_context={})
    assert InterruptType.USER_INPUT in str(result3)
    assert "What is your status?" in str(result3)

    # T4: User says "I want to change my age to 30" at Node 4 (N)
    #     → intent change → rollback to Node 2 (N-1)
    #     → Node 2 re-enters with user's current query
    tool.execute(thread_id=tid, user_message=user_query, initial_context={})
    s4 = snap(tool, tid)

    # ── KEY ASSERTION 1: _user_message is the current query from Node 4 (N) ──
    assert s4.get(WorkflowKeys.USER_MESSAGE) == user_query, (
        f"Expected _user_message to be '{user_query}' (query from Node 4), "
        f"but got '{s4.get(WorkflowKeys.USER_MESSAGE)}'. "
        "Node 2 must receive the user query that triggered intent change in Node 4."
    )

    # ── KEY ASSERTION 2: _user_message is NOT "John" (stale from Node 1's completion) ──
    # The snapshot before Node 2 was saved during T2 when _user_message="John".
    # Rollback must NOT restore this stale value.
    assert s4.get(WorkflowKeys.USER_MESSAGE) != "John", (
        "Bug: _user_message is 'John' (Node 1's answer leaked from snapshot). "
        "Node 2's LLM received a completely unrelated answer from a different step."
    )

    # ── KEY ASSERTION 3: Node 2's re-entry LLM call received the current query ──
    # LLM#7 is Node 2's _generate_prompt after rollback.
    llm7_body = json.loads(respx.calls[6].request.content)
    llm7_messages = llm7_body.get("messages", [])
    llm7_user_msgs = [m["content"] for m in llm7_messages if m["role"] == "user"]
    assert any(user_query in msg for msg in llm7_user_msgs), (
        f"Expected Node 2's LLM to receive '{user_query}' as user message, "
        f"but user messages were: {llm7_user_msgs}. "
        "The rolled-back node must see the query that triggered intent change."
    )
    assert not any(msg == "John" for msg in llm7_user_msgs), (
        f"Bug: Node 2's LLM received 'John' (Node 1's answer) as user message: {llm7_user_msgs}"
    )
