"""
Unit tests for MFACollectInputStrategy

Tests cover:
- Configuration building and initialization
- MFA initiation and state management
- Agent instructions generation
- Transition processing (resend, capture, cancel)
- Max attempts handling
- Attempt counter management
- Conversation management during resend
"""

import pytest
from unittest.mock import Mock, patch
from jinja2 import Environment

from soprano_sdk.nodes.mfa_strategy import MFACollectInputStrategy, compile_values
from soprano_sdk.core.constants import WorkflowKeys, OTP_MAX_ATTEMPTS, MFAConfig


class TestCompileValues:
    """Test the compile_values helper function"""

    def test_compile_values_string_template(self):
        """Test compiling a string template with Jinja2"""
        template_loader = Environment()
        state = {"name": "John", "order_id": "12345"}
        result = compile_values(template_loader, state, "Hello {{name}}, order {{order_id}}")
        assert result == "Hello John, order 12345"

    def test_compile_values_dict(self):
        """Test compiling values in a dictionary"""
        template_loader = Environment()
        state = {"user": "Alice", "amount": "100"}
        values = {
            "message": "User {{user}} paid {{amount}}",
            "status": "active"
        }
        result = compile_values(template_loader, state, values)
        assert result == {
            "message": "User Alice paid 100",
            "status": "active"
        }

    def test_compile_values_list(self):
        """Test compiling values in a list"""
        template_loader = Environment()
        state = {"count": "5"}
        values = ["Item {{count}}", "Plain text", "Total: {{count}}"]
        result = compile_values(template_loader, state, values)
        assert result == ["Item 5", "Plain text", "Total: 5"]

    def test_compile_values_nested_structures(self):
        """Test compiling nested dict and list structures"""
        template_loader = Environment()
        state = {"x": "10", "y": "20"}
        values = {
            "data": ["Value: {{x}}", "Value: {{y}}"],
            "nested": {
                "a": "{{x}}",
                "b": "{{y}}"
            }
        }
        result = compile_values(template_loader, state, values)
        assert result == {
            "data": ["Value: 10", "Value: 20"],
            "nested": {
                "a": "10",
                "b": "20"
            }
        }

    def test_compile_values_non_string(self):
        """Test that non-string values are returned as-is"""
        template_loader = Environment()
        state = {}
        assert compile_values(template_loader, state, 42) == 42
        assert compile_values(template_loader, state, True) is True
        assert compile_values(template_loader, state, None) is None


class TestMFAStrategyInit:
    """Test MFACollectInputStrategy initialization"""

    @pytest.fixture
    def mock_engine_context(self):
        """Create a mock engine context"""
        context = Mock()
        context.mfa_config = MFAConfig(
            generate_token_base_url="http://test.com",
            generate_token_path="/generate",
            initial_message="Enter OTP sent to your phone",
            max_attempts_message="Max attempts reached",
            options=[{"text": "Resend", "subtext": ""}],
            is_selectable=True
        )
        context.get_model_config = Mock(return_value={
            "model_name": "gpt-4o-mini",
            "provider": "openai"
        })
        context.get_config_value = Mock(return_value=Environment())
        return context

    @pytest.fixture
    def basic_step_config(self):
        """Basic step configuration for MFA"""
        return {
            'id': 'verify_payment',
            'action': 'mfa',
            'description': 'Verify payment with OTP',
            'payload': {
                'customerId': '{{customer_id}}',
                'amount': '{{amount}}'
            },
            'transitions': [
                {'pattern': 'SUCCESS:', 'next': 'payment_success'}
            ]
        }

    def test_init_basic_config(self, basic_step_config, mock_engine_context):
        """Test basic initialization with minimal config"""
        strategy = MFACollectInputStrategy(basic_step_config, mock_engine_context)

        assert strategy.step_id == 'verify_payment'
        assert strategy.mfa_payload == basic_step_config['payload']
        assert strategy.mfa_headers == {}
        assert strategy.on_cancel == 'mfa_cancelled'
        assert strategy.mfa_authorize is True

    def test_step_config_transitions(self, basic_step_config, mock_engine_context):
        """Test that init updates step_config with built transitions"""

        # Check that transitions were added to step_config
        assert 'transitions' in basic_step_config
        transitions = basic_step_config['transitions']

        # Should have resend, captured, and cancelled transitions
        patterns = [t['pattern'] for t in transitions]
        assert 'SUCCESS:' in patterns

    def test_mfa_field(self, basic_step_config, mock_engine_context):
        """Test that MFA field name is generated correctly"""
        strategy = MFACollectInputStrategy(basic_step_config, mock_engine_context)

        assert strategy.mfa_field == 'verify_payment_mfa_input'

class TestGetMFAInstructions:
    """Test _get_mfa_instructions method"""

    @pytest.fixture
    def strategy(self):
        """Create a basic MFA strategy instance"""
        engine_context = Mock()
        engine_context.mfa_config = MFAConfig()
        engine_context.get_model_config = Mock(return_value={"model_name": "gpt-4o"})
        engine_context.get_config_value = Mock(return_value=Environment())

        step_config = {
            'id': 'test',
            'action': 'mfa',
            'payload': {},
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }

        return MFACollectInputStrategy(step_config, engine_context)

    def test_instructions_contain_resend_detection(self, strategy):
        """Test that instructions include resend detection"""
        instructions = strategy._get_mfa_instructions()

        assert 'MFA_RESEND:RESEND_REQUEST' in instructions
        assert 'resend' in instructions.lower()
        assert 'RESEND DETECTION' in instructions

    def test_instructions_contain_otp_capture(self, strategy):
        """Test that instructions include OTP capture format"""
        instructions = strategy._get_mfa_instructions()

        assert 'MFA_CAPTURED:' in instructions
        assert 'OTP CAPTURE' in instructions

    def test_instructions_contain_cancellation(self, strategy):
        """Test that instructions include cancellation format"""
        instructions = strategy._get_mfa_instructions()

        assert 'MFA_CANCELLED:' in instructions
        assert 'cancel' in instructions.lower()
        assert 'stop' in instructions.lower()

class TestMFAExecution:
    """Test execute and _initiate_mfa methods"""

    @pytest.fixture
    def mock_engine_context(self):
        context = Mock()
        context.mfa_config = MFAConfig(
            generate_token_base_url="http://test.com",
            generate_token_path="/generate",
            initial_message="Enter OTP"
        )
        context.get_model_config = Mock(return_value={"model_name": "gpt-4o"})
        context.get_config_value = Mock(return_value=Environment())
        context.outcome_map = {}
        return context

    @pytest.fixture
    def strategy(self, mock_engine_context):
        step_config = {
            'id': 'verify',
            'action': 'mfa',
            'payload': {'userId': '{{user_id}}'},
            'max_attempts': 3,
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }
        return MFACollectInputStrategy(step_config, mock_engine_context)

    @patch('soprano_sdk.authenticators.mfa.enforce_mfa_if_required')
    def test_execute_initiates_mfa_first_time(self, mock_enforce, strategy):
        """Test that execute initiates MFA on first call"""
        state = {
            'user_id': '12345',
            WorkflowKeys.CONVERSATIONS: {}
        }

        result = strategy.execute(state)

        # Should set active input field
        assert state['_active_input_field'] == 'verify_mfa_input'

        # Should have called enforce_mfa_if_required
        mock_enforce.assert_called_once()

        # Should set status to collecting
        assert WorkflowKeys.STATUS in result
        assert 'collecting' in result[WorkflowKeys.STATUS]

    @patch('soprano_sdk.authenticators.mfa.enforce_mfa_if_required')
    def test_initiate_mfa_compiles_payload(self, mock_enforce, strategy):
        """Test that _initiate_mfa compiles template values in payload"""
        state = {
            'user_id': 'USER123',
            WorkflowKeys.CONVERSATIONS: {}
        }

        strategy.execute(state)

        # Check that _mfa was initialized
        assert '_mfa' in state
        assert 'post_payload' in state['_mfa']

        # Should have userId compiled from template
        assert state['_mfa']['post_payload']['userId'] == 'USER123'

        # Should have transactionId
        assert 'transactionId' in state['_mfa']['post_payload']

    @patch('soprano_sdk.authenticators.mfa.enforce_mfa_if_required')
    def test_initiate_mfa_with_headers(self, mock_enforce, mock_engine_context):
        """Test that _initiate_mfa compiles headers"""
        step_config = {
            'id': 'verify',
            'action': 'mfa',
            'payload': {},
            'headers': {
                'Authorization': 'Bearer {{auth_token}}',
                'X-User-Id': '{{user_id}}'
            },
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }

        strategy = MFACollectInputStrategy(step_config, mock_engine_context)

        state = {
            'auth_token': 'secret123',
            'user_id': 'USER456',
            WorkflowKeys.CONVERSATIONS: {}
        }

        strategy.execute(state)

        # Check headers were compiled
        assert 'post_headers' in state['_mfa']
        assert state['_mfa']['post_headers']['Authorization'] == 'Bearer secret123'
        assert state['_mfa']['post_headers']['X-User-Id'] == 'USER456'

    @patch('soprano_sdk.authenticators.mfa.enforce_mfa_if_required')
    def test_execute_skips_initiation_if_in_progress(self, mock_enforce, strategy, mock_engine_context):
        """Test that execute skips MFA initiation if already in progress"""
        state = {
            '_mfa': {
                'status': 'IN_PROGRESS',
                'message': 'Enter OTP',
                'retry_count': 0
            },
            '_active_input_field': 'verify_mfa_input',
            'verify_mfa_input': None,
            WorkflowKeys.CONVERSATIONS: {'verify_conversation': []},
            WorkflowKeys.STATUS: 'verify_collecting'
        }

        # Mock parent's execute to avoid complex agent setup
        with patch.object(MFACollectInputStrategy.__bases__[0], 'execute', return_value=state):
            strategy.execute(state)

        # Should NOT call enforce_mfa_if_required again
        mock_enforce.assert_not_called()


class TestMaxAttemptsHandling:
    """Test max attempts logic"""

    @pytest.fixture
    def strategy(self):
        engine_context = Mock()
        engine_context.mfa_config = MFAConfig()
        engine_context.get_model_config = Mock(return_value={"model_name": "gpt-4o"})
        engine_context.get_config_value = Mock(return_value=Environment())

        step_config = {
            'id': 'mfa',
            'action': 'mfa',
            'payload': {},
            'max_attempts': 3,
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }

        return MFACollectInputStrategy(step_config, engine_context)

    def test_max_attempts_not_reached(self, strategy):
        """Test max attempts check when limit not reached"""
        state = {
            '_mfa': {'retry_count': 1},
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 2}
        }

        assert not strategy._max_attempts_reached(state)

    def test_max_attempts_reached_otp_retries(self, strategy):
        """Test max attempts when OTP retry limit reached"""
        state = {
            '_mfa': {'retry_count': OTP_MAX_ATTEMPTS},
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': OTP_MAX_ATTEMPTS}
        }

        assert strategy._max_attempts_reached(state)

    def test_max_attempts_reached_bot_clarify(self, strategy):
        """Test max attempts when bot clarification limit reached"""
        state = {
            '_mfa': {'retry_count': 1},
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 4}  # 4 total, 1 retry = 3 bot clarify
        }

        assert strategy._max_attempts_reached(state)

    def test_max_attempts_calculation(self, strategy):
        """Test the dual max attempts calculation (OTP + bot clarify)"""
        # 2 OTP retries + 2 bot clarify = 4 total attempts
        state = {
            '_mfa': {'retry_count': 2},
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 4}
        }

        # Should be within limits (OTP: 2/3, bot: 2/3)
        assert not strategy._max_attempts_reached(state)

        # Now exceed OTP limit
        state['_mfa']['retry_count'] = 3
        assert strategy._max_attempts_reached(state)


class TestProcessTransitions:
    """Test _process_transitions method"""

    @pytest.fixture
    def strategy(self):
        engine_context = Mock()
        engine_context.mfa_config = MFAConfig(
            initial_message="Enter OTP sent to phone"
        )
        engine_context.get_model_config = Mock(return_value={"model_name": "gpt-4o"})
        engine_context.get_config_value = Mock(return_value=Environment())

        step_config = {
            'id': 'mfa',
            'action': 'mfa',
            'payload': {},
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }

        return MFACollectInputStrategy(step_config, engine_context)

    def test_process_transitions_resend(self, strategy):
        """Test that resend pattern triggers resend handler"""
        state = {
            '_mfa': {
                'status': 'IN_PROGRESS',
                'message': 'Enter OTP',
                'retry_count': 0,
                'post_payload': {'transactionId': '123'}
            },
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 1}
        }
        conversation = [
            {'role': 'user', 'content': 'resend'},
            {'role': 'assistant', 'content': 'MFA_RESEND:RESEND_REQUEST'}
        ]

        with patch('soprano_sdk.authenticators.mfa.mfa_resend_otp') as mock_resend:
            strategy._process_transitions(state, conversation, 'MFA_RESEND:RESEND_REQUEST')

        # Should have called resend handler
        mock_resend.assert_called_once()

        # Should have removed resend messages from conversation
        assert len(conversation) == 1  # Only new message should remain
        assert conversation[0]['role'] == 'assistant'

    def test_process_transitions_captured_increments_retry(self, strategy):
        """Test that MFA_CAPTURED increments retry count"""
        state = {
            '_mfa': {'retry_count': 1}
        }
        conversation = []

        with patch.object(MFACollectInputStrategy.__bases__[0], '_process_transitions', return_value=state):
            strategy._process_transitions(state, conversation, 'MFA_CAPTURED:123456')

        # Should increment retry count
        assert state['_mfa']['retry_count'] == 2


class TestHandleResend:
    """Test _handle_resend method"""

    @pytest.fixture
    def strategy(self):
        engine_context = Mock()
        engine_context.mfa_config = MFAConfig(
            initial_message="OTP sent to {{phone}}",
            resend_token_base_url="http://test.com",
            resend_token_path="/resend"
        )
        engine_context.get_model_config = Mock(return_value={"model_name": "gpt-4o"})
        engine_context.get_config_value = Mock(return_value=Environment())

        step_config = {
            'id': 'mfa',
            'action': 'mfa',
            'payload': {},
            'transitions': [{'pattern': 'SUCCESS:', 'next': 'next'}]
        }

        return MFACollectInputStrategy(step_config, engine_context)

    @patch('soprano_sdk.authenticators.mfa.mfa_resend_otp')
    def test_handle_resend_calls_api(self, mock_resend, strategy):
        """Test that resend calls the resend API"""
        state = {
            '_mfa': {
                'status': 'IN_PROGRESS',
                'message': 'Enter OTP',
                'post_payload': {'transactionId': 'abc123'}
            },
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 2}
        }
        conversation = [
            {'role': 'user', 'content': 'resend'},
            {'role': 'assistant', 'content': 'MFA_RESEND:RESEND_REQUEST'}
        ]

        strategy._handle_resend(state, conversation)

        # Should call resend API
        mock_resend.assert_called_once_with(state, strategy.engine_context.mfa_config)

    @patch('soprano_sdk.authenticators.mfa.mfa_resend_otp')
    def test_handle_resend_decrements_counter(self, mock_resend, strategy):
        """Test that resend decrements attempt counter"""
        state = {
            '_mfa': {
                'status': 'IN_PROGRESS',
                'message': 'OTP sent',
                'post_payload': {}
            },
            WorkflowKeys.ATTEMPT_COUNTS: {'mfa': 3}
        }
        conversation = [
            {'role': 'user', 'content': 'resend'},
            {'role': 'assistant', 'content': 'MFA_RESEND:RESEND_REQUEST'}
        ]

        with patch.object(strategy, '_set_status') as mock_set_status:
            strategy._handle_resend(state, conversation)

        # Should have decremented attempt counter
        assert state[WorkflowKeys.ATTEMPT_COUNTS]['mfa'] == 2
        mock_set_status.assert_called_once_with(state, 'collecting')
