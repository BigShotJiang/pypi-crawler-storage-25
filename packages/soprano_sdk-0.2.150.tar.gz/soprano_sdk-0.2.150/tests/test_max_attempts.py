"""Tests for explicitly validating that max_attempts counters reset appropriately
across complex flow including intent changes, out-of-scope, and resuming.
"""

import uuid
import pytest
import respx
from unittest.mock import MagicMock

from soprano_sdk.core.constants import InterruptType, WorkflowKeys
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_intent_change,
    fu_answer,
    llm_structured_response,
    make_tool,
    snap,
)


def collector_oos(reason: str, text: str):
    """LLM returns out_of_scope instead of capturing or prompting."""
    return llm_structured_response({
        "bot_response": None,
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": False,
    })


# ---------------------------------------------------------------------------
# Attempt counter reset tests
# These tests verify that ATTEMPT_COUNTS[node_id] is correctly reset to 0
# whenever a node is re-entered fresh (via intent change or rollback), so stale
# counts from a previous visit never bleed into a new visit.
# ---------------------------------------------------------------------------

@respx.mock
def test_collector_intent_change_to_prior_node_resets_attempts_on_reentry():
    """Verify that re-entering a collector node via intent change resets its attempt counter.

    Reason: Without an explicit reset on fresh entry, a node's counter would retain its
    previous value across rollbacks. This would cause the node to hit max_attempts
    prematurely on re-entry, terminating a valid user session too early.

    Scenario:
    1. Enter collect_b. Attempts = 0.
    2. User inputs 1 garbage turn. Attempts = 1.
    3. User triggers intent change to collect_a.
    4. Workflow rolls back to collect_a (clearing collect_b state).
    5. User finishes collect_a again, routing back to collect_b.
    6. collect_b attempts must be 0 (freshly entered), NOT the stale 1.
    """
    responses = iter([
        collector_prompt("What is field A?"),                   # LLM#1: collect_a prompt
        collector_capture("val_a"),                             # LLM#2: collect_a captures
        collector_prompt("What is field B?"),                   # LLM#3: collect_b prompt
        llm_structured_response({                               # LLM#4: collect_b complains (attempt 1)
            "bot_response": "I didn't get that. Field B?",
            "field_b": None,
        }),
        llm_structured_response({                               # LLM#5: collect_b triggers intent change to A
            "bot_response": "Sure, redirecting to A.",
            "intent_change": "collect_a",
            "field_b": None,
        }),
        collector_prompt("Please re-enter field A."),           # LLM#6: collect_a re-prompt
        collector_capture("new_val_a"),                         # LLM#7: collect_a captures
        collector_prompt("What is field B?"),                   # LLM#8: collect_b prompt (fresh)
        llm_structured_response({                               # LLM#9: collect_b complains (fresh attempt 1)
            "bot_response": "Still didn't get B.",
            "field_b": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")  # Has collect_a and collect_b
    tid = str(uuid.uuid4())

    # Reach collect_b
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # Garbage input in collect_b -> attempt 1
    tool.execute(thread_id=tid, user_message="garbage", initial_context={})
    s_before_ic = snap(tool, tid)
    assert s_before_ic[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b") == 1

    # Intent change back to A
    tool.execute(thread_id=tid, user_message="Actually, change A", initial_context={})

    # Satisfy A again
    tool.execute(thread_id=tid, user_message="new_val_a", initial_context={})
    s_fresh_b = snap(tool, tid)

    # Back at collect_b. Attempts should be 0 because we freshly entered it.
    assert s_fresh_b[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b", 0) == 0

    # Test an attempt on the fresh collect_b
    tool.execute(thread_id=tid, user_message="garbage 2", initial_context={})
    s_after_garbage = snap(tool, tid)
    assert s_after_garbage[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b") == 1


@respx.mock
def test_follow_up_intent_change_resets_collector_attempts():
    """Verify that an intent change triggered from follow-up resets the target collector's attempt counter.

    Reason: A user may have accumulated attempts in a collector before completing it and
    reaching follow-up. If they then intent-change back to that collector, its old attempt
    count must be cleared so it behaves as a fresh visit, preventing false max-attempt termination.

    Scenario:
    1. collect_a accumulates 1 failed attempt, then succeeds.
    2. Flow reaches follow-up.
    3. follow-up triggers intent change back to collect_a.
    4. collect_a attempt counter must be 0 on re-entry.
    """
    responses = iter([
        collector_prompt("What is field A?"),                   # LLM#1: collect_a prompt
        llm_structured_response({                               # LLM#2: collect_a complains (attempt 1)
            "bot_response": "I didn't get that. Field A?",
            "field_a": None,
        }),
        collector_capture("val_a"),                             # LLM#3: collect_a captures (attempt 2)
        fu_intent_change("collect_a", "Let me help you redo that."), # LLM#4: follow-up intent change
        collector_prompt("Please re-enter field A."),           # LLM#5: collect_a re-prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="garbage", initial_context={})

    # Check attempts for collect_a
    s_collecting = snap(tool, tid)
    assert s_collecting[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1

    # Finish collect_a
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # Trigger intent change from follow_up
    tool.execute(thread_id=tid, user_message="change A", initial_context={})

    s_rolled_back = snap(tool, tid)

    # Back at collect_a, attempts should be 0 on fresh entry after rollback
    assert s_rolled_back[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0


@respx.mock
def test_multiple_intent_changes_resets_repeatedly():
    """Verify that each re-entry via intent change resets the node counter, not just the first time.

    Reason: The reset logic must be idempotent — it should trigger every time a node is entered
    fresh, not just on the first rollback. A bug where reset only runs once would leave the counter
    dirty on subsequent re-entries.

    Scenario: A completes -> B entered -> intent change back to A -> A completes -> B re-entered.
    Both A and B must show 0 attempts each time they are freshly entered.
    """
    responses = iter([
        collector_prompt("A?"), collector_capture("a1"),
        collector_prompt("B?"), fu_intent_change("collect_a", "Back to A"), # B -> A
        collector_prompt("A again?"), collector_capture("a2"),
        collector_prompt("B again?"), collector_capture("b1") # A -> B
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={}) # Enter A
    tool.execute(thread_id=tid, user_message="a1", initial_context={}) # Finish A, Enter B

    # Trigger B -> A
    tool.execute(thread_id=tid, user_message="change to A")
    s_back_to_a = snap(tool, tid)
    assert s_back_to_a[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0

    # Finish A again
    tool.execute(thread_id=tid, user_message="a2")
    s_back_to_b = snap(tool, tid)
    assert s_back_to_b[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b", 0) == 0


@respx.mock
def test_validation_failure_then_intent_change_resets():
    """Verify that a validation failure increments the counter and an intent change then resets it.

    Reason: Ensures the counter tracks validation failures (not just LLM non-captures), and that
    the reset-on-intent-change path works regardless of how the counter was incremented.

    Scenario: collect_b fails validation (attempt 1), user then intent-changes to collect_a.
    collect_b counter must be 0 afterwards.
    """
    responses = iter([
        collector_capture("val_a"),
        collector_prompt("B?"),
        llm_structured_response({"bot_response": "Invalid B.", "field_b": None}), # Fail
        fu_intent_change("collect_a", "Back to A") # Intent Change
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    def fail_validator(value, **kwargs): return False, "Bad B"
    tool = make_tool("follow_up_multi_step.yaml")
    tool.engine.function_repository.load = MagicMock(side_effect=lambda path: fail_validator if "validator" in path else MagicMock())

    tid = str(uuid.uuid4())
    tool.execute(thread_id=tid, initial_context={"collect_a": "val_a"}) # Start at B
    tool.execute(thread_id=tid, user_message="bad_b") # Attempt 1

    s1 = snap(tool, tid)
    assert s1[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b") == 1

    tool.execute(thread_id=tid, user_message="Actually change A")
    s2 = snap(tool, tid)
    assert s2[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b", 0) == 0

@respx.mock
def test_max_attempts_reached_then_intent_change_resets():
    """Verify that a node whose max_attempts was exhausted has its counter reset after intent change re-entry.

    Reason: A node that exhausted attempts routes to follow-up. If the user then intent-changes
    back to that node, it must start fresh at 0 — otherwise the counter would immediately
    re-trigger max-attempts termination on the very next input, making the node unusable.

    LLM call sequence:
    1. collect_a initial prompt (fresh entry, counter=0)
    2. fail 1 processed by collect_a (counter=1, still collecting)
    3. fail 2 processed by collect_a (counter=2=max_attempts → _handle_max_attempts)
    4. follow-up processes "retry A" → fu_intent_change back to collect_a
    5. fresh collect_a re-entry resets counter to 0, asks again
    """
    responses = iter([
        collector_prompt("What is field A?"),                                       # LLM#1: initial collect_a prompt
        llm_structured_response({"bot_response": "First fail", "field_a": None}),  # LLM#2: fail 1
        llm_structured_response({"bot_response": "Second fail", "field_a": None}), # LLM#3: fail 2 → max_attempts
        fu_intent_change("collect_a", "Retrying A"),                                # LLM#4: follow-up IC to collect_a
        collector_prompt("Please re-enter field A."),                               # LLM#5: fresh collect_a prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 2}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail 1", initial_context={})
    tool.execute(thread_id=tid, user_message="fail 2", initial_context={})  # Max attempts reached → follow-up

    s_fu = snap(tool, tid)
    assert s_fu.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is True

    # follow-up processes "retry A" → intent_change to collect_a → fresh re-entry resets counter
    tool.execute(thread_id=tid, user_message="retry A")
    s_retry = snap(tool, tid)
    assert respx.calls.call_count == 5
    assert s_retry[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0
    assert s_retry[WorkflowKeys.STATUS] == "collect_a_collecting"


# ---------------------------------------------------------------------------
# OOS (Out-of-Scope) attempt counting tests
# These tests verify that OOS interrupts correctly consume attempt slots and
# interact properly with the max_attempts termination logic.
# ---------------------------------------------------------------------------

@respx.mock
def test_single_oos_input_increments_node_attempt_count():
    """Verify that a single out-of-scope user input increments the node's attempt counter by 1.

    Reason: OOS inputs must consume an attempt slot just like any other failed input.
    If OOS were not counted, a user could bypass max_attempts indefinitely by sending
    only out-of-scope messages, keeping the node alive forever.
    """
    responses = iter([
        collector_prompt("A?"),
        collector_oos("off topic", "I can't answer A.")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{
            "id": "collect_a",
            "action": "collect_input_with_agent",
            "field": "field_a",
            "agent": {"detect_out_of_scope": True, "structured_output": {"enabled": True}}
        }]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    r_oos = tool.execute(thread_id=tid, user_message="what's the weather?", initial_context={})
    assert InterruptType.OUT_OF_SCOPE in str(r_oos)

    s = snap(tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1


@respx.mock
def test_multiple_oos_inputs_consume_attempts_and_terminate_at_max():
    """Verify that repeated OOS inputs consume attempts and the node terminates when max_attempts is reached.

    Reason: OOS handling involves an interrupt-resume cycle that could bypass the normal
    attempt-increment path. This test ensures the counter is correctly incremented through
    both the OOS interrupt turn and the resume turn, and that the node exits once the
    cumulative attempt count hits max_attempts.

    Scenario:
    1. Enter collector. Attempts=0.
    2. User input -> LLM triggers OOS. Node suspends with interrupt. Attempts = 1.
    3. Resume from OOS ("ack") -> Attempts = 2.
    4. User input -> Another OOS. Attempts = 3 = max_attempts -> routes to follow-up.
    """
    responses = iter([
        collector_prompt("What is field A?"),
        collector_oos("off topic 1", "I can't answer that."),
        collector_oos("off topic 2", "Still can't answer that."),
        llm_structured_response({
            "bot_response": "Finally some garbage.",
            "field_a": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 3, "agent": {"detect_out_of_scope": True}}]
    })

    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    # Turn 1: OOS
    r1 = tool.execute(thread_id=tid, user_message="What is the weather?", initial_context={})
    assert InterruptType.OUT_OF_SCOPE in str(r1)

    s1 = snap(tool, tid)
    assert s1[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1

    # Resume from OOS interrupt (user message "ack" is also a message processed by the node)
    tool.execute(thread_id=tid, user_message="ack", initial_context={})
    s2 = snap(tool, tid)
    # The attempt count is now 2 (1 for weather, 1 for ack)
    assert s2[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 2

    # Turn 2: Another OOS. Attempt 3 = max_attempts -> routes to follow-up.
    tool.execute(thread_id=tid, user_message="Another off topic", initial_context={})
    s3 = snap(tool, tid)
    assert s3[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 3
    # Check that we are no longer collecting for collect_a
    assert s3[WorkflowKeys.STATUS] != "collect_a_collecting"


@respx.mock
def test_consecutive_oos_in_follow_up_increments_and_terminates_at_max():
    """Verify that consecutive OOS inputs in follow-up are tracked and the session terminates at max.

    Reason: follow-up has its own OOS attempt counter (FOLLOW_UP_ATTEMPTS) separate from
    collector node counters. This test guards that the follow-up stage correctly tracks and
    enforces its own max_attempts limit for OOS, preventing infinite OOS loops in follow-up.

    Scenario: 3 OOS in a row in follow-up with max_attempts=2.
    After the 3rd OOS, the workflow must terminate.
    """
    responses = iter([
        fu_answer("Hello"),
        llm_structured_response({"out_of_scope": "oos 1", "bot_response": "I can't answer 1"}),
        llm_structured_response({"out_of_scope": "oos 2", "bot_response": "I can't answer 2"}),
        llm_structured_response({"out_of_scope": "oos 3", "bot_response": "I can't answer 3"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "follow_up": {"max_attempts": 2} # Max 2 OOS allowed
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={"field_a": "val"}) # Reach follow-up
    tool.execute(thread_id=tid, user_message="what's the weather?") # OOS 1
    s1 = snap(tool, tid)
    assert s1[WorkflowKeys.FOLLOW_UP_ATTEMPTS] == 1

    tool.execute(thread_id=tid, user_message="where am I?") # OOS 2
    s2 = snap(tool, tid)
    assert s2[WorkflowKeys.FOLLOW_UP_ATTEMPTS] == 2

    r3 = tool.execute(thread_id=tid, user_message="tell me a joke") # OOS 3 -> should terminate
    assert "Max attempts reached" in str(r3)


# ---------------------------------------------------------------------------
# Baseline and edge case tests
# These tests establish the expected counter behavior at entry and exit points,
# and guard against common edge cases like pre-populated fields and checkpointing.
# ---------------------------------------------------------------------------

@respx.mock
def test_freshly_entered_node_starts_with_zero_attempts():
    """Verify that a node entered for the first time via normal flow starts with 0 attempts.

    Reason: Establishes the baseline expectation. If a fresh node entry doesn't start at 0,
    all downstream attempt-count assertions and max_attempts logic are unreliable.
    """
    responses = iter([
        collector_capture("val_a"),
        collector_prompt("B?")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={"collect_a": "val_a"})
    s = snap(tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b", 0) == 0


@respx.mock
def test_pre_populated_field_skips_collection_without_incrementing_attempts():
    """Verify that a pre-populated field bypasses collection entirely without incrementing attempts.

    Reason: When a field is pre-populated via initial_context, the node should skip directly
    to the next step. Any attempt increment during this skip would be a false positive
    and could cause premature max_attempts termination in later flows.
    """
    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={"field_a": "pre_val"})
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.ATTEMPT_COUNTS, {}).get("collect_a", 0) == 0


@respx.mock
def test_resume_from_checkpoint_persists_attempts():
    """Verify that attempt counts survive a tool reload from a shared checkpointer.

    Reason: Attempt counts are stored in graph state. If state is not correctly persisted
    and reloaded from the checkpointer, a new tool instance would see a stale counter of 0,
    allowing a user to bypass max_attempts enforcement by simply reconnecting.
    """
    responses = iter([
        collector_prompt("A?"),
        llm_structured_response({"bot_response": "Try again", "field_a": None})
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = "persistent-thread"
    checkpointer = tool.graph.checkpointer

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail 1", initial_context={})

    # Create a new tool instance sharing the same checkpointer
    new_tool = make_tool("follow_up_single_step.yaml", checkpointer=checkpointer)
    s = snap(new_tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1


# ---------------------------------------------------------------------------
# Self-loop counter tests
# These tests focus specifically on how ATTEMPT_COUNTS[node_id] increments
# as the node self-loops (STATUS=collecting + PENDING_PROMPT) on each failed
# user input, and that the counter gates max-attempts termination correctly.
# ---------------------------------------------------------------------------

@respx.mock
def test_self_loop_counter_is_zero_before_first_user_input():
    """Verify the counter stays at 0 after the initial prompt, before any user input.

    Reason: The first LLM call generates the opening question but must NOT count as an attempt
    — only actual user turns should increment the counter. If the initial prompt were counted,
    nodes with max_attempts=1 would immediately terminate before the user even responds.
    """
    responses = iter([
        collector_prompt("What is field A?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0
    assert s[WorkflowKeys.STATUS] == "collect_a_collecting"


@respx.mock
@pytest.mark.parametrize("n_failures", [1, 2, 3])
def test_self_loop_counter_matches_failure_count(n_failures):
    """Verify the counter equals exactly N after N consecutive failed self-loop turns.

    Reason: Guards the core increment logic — each failed user turn must add exactly 1
    to the counter, with no double-counting or skipped increments. Parameterised over
    multiple values to catch off-by-one errors that only surface at specific counts.
    """
    responses = iter(
        [collector_prompt("What is field A?")]
        + [
            llm_structured_response({"bot_response": f"Attempt {i} failed.", "field_a": None})
            for i in range(1, n_failures + 1)
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": n_failures + 2}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    for i in range(n_failures):
        tool.execute(thread_id=tid, user_message=f"garbage {i}", initial_context={})

    s = snap(tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == n_failures
    assert s[WorkflowKeys.STATUS] == "collect_a_collecting"


@respx.mock
def test_self_loop_counter_at_max_minus_one_still_collects():
    """Verify that at max_attempts - 1 failures the node is still collecting, not terminated.

    Reason: Guards the off-by-one boundary. The node must only exit at >= max_attempts,
    not before. Terminating one turn early would cut off a valid user attempt.
    """
    max_attempts = 3
    n_failures = max_attempts - 1  # 2 failures

    responses = iter(
        [collector_prompt("What is field A?")]
        + [
            llm_structured_response({"bot_response": f"Attempt {i} failed.", "field_a": None})
            for i in range(1, n_failures + 1)
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": max_attempts}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    for i in range(n_failures):
        tool.execute(thread_id=tid, user_message=f"garbage {i}", initial_context={})

    s = snap(tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == n_failures
    # Node must still be in collecting state — not yet terminated
    assert s[WorkflowKeys.STATUS] == "collect_a_collecting"


@respx.mock
def test_self_loop_counter_at_max_terminates_node():
    """Verify that at exactly max_attempts failures the node exits the self-loop and routes to follow-up.

    Reason: Guards the upper boundary of the off-by-one check. The node must exit on the Nth
    failed turn where N == max_attempts, not linger for an extra turn.
    """
    max_attempts = 3
    responses = iter(
        [collector_prompt("What is field A?")]
        + [
            llm_structured_response({"bot_response": f"Fail {i}.", "field_a": None})
            for i in range(1, max_attempts + 1)
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": max_attempts}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    for i in range(max_attempts):
        tool.execute(thread_id=tid, user_message=f"garbage {i}", initial_context={})

    s = snap(tool, tid)
    assert s[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == max_attempts
    # Must have exited the self-loop
    assert s[WorkflowKeys.STATUS] != "collect_a_collecting"


@respx.mock
def test_self_loop_counter_with_max_attempts_one_terminates_on_first_failure():
    """Verify that with max_attempts=1, the very first failed user input immediately terminates the node.

    Reason: max_attempts=1 is a valid edge case meaning "no retries allowed". The node must
    exit after exactly one failed turn. Any bug where the counter is evaluated before being
    incremented would allow the user an extra (unintended) retry.
    """
    responses = iter([
        collector_prompt("What is field A?"),
        llm_structured_response({"bot_response": "Nope.", "field_a": None}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 1}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    s_before = snap(tool, tid)
    assert s_before[WorkflowKeys.STATUS] == "collect_a_collecting"
    assert s_before[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0

    tool.execute(thread_id=tid, user_message="garbage", initial_context={})
    s_after = snap(tool, tid)

    assert s_after[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1
    assert s_after[WorkflowKeys.STATUS] != "collect_a_collecting"


@respx.mock
def test_self_loop_counter_counts_all_turns_including_successful_capture():
    """Verify that the counter counts all user input turns, including the successful capture turn.

    Reason: The counter tracks total user turns processed by the node (not just failures).
    This matters for audit and analytics purposes. A bug where successful captures reset the
    counter to 0 would make the stored attempt count meaningless for post-session review.

    Pattern: 1 failed turn (counter=1) + 1 successful turn (counter=2).
    """
    responses = iter([
        collector_prompt("What is field A?"),
        llm_structured_response({"bot_response": "Try again.", "field_a": None}),
        collector_capture("good_value"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 5}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="bad value", initial_context={})

    s_mid = snap(tool, tid)
    assert s_mid[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 1

    tool.execute(thread_id=tid, user_message="good_value", initial_context={})
    s_done = snap(tool, tid)

    # Counter is 2: 1 failed turn + 1 successful turn
    assert s_done[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 2
    # Node is no longer collecting
    assert s_done[WorkflowKeys.STATUS] != "collect_a_collecting"


@respx.mock
def test_self_loop_counters_are_independent_across_nodes():
    """Verify that each node tracks its own self-loop counter independently without cross-contamination.

    Reason: All attempt counts are stored in a shared ATTEMPT_COUNTS dict keyed by node_id.
    A bug where the wrong key is read/written could cause one node's failures to affect
    another node's max_attempts enforcement.
    """
    responses = iter([
        collector_prompt("What is field A?"),
        llm_structured_response({"bot_response": "Retry A.", "field_a": None}),  # A: fail 1
        llm_structured_response({"bot_response": "Retry A again.", "field_a": None}),  # A: fail 2
        collector_capture("val_a"),  # A: success (turn 3)
        collector_prompt("What is field B?"),
        llm_structured_response({"bot_response": "Retry B.", "field_b": None}),  # B: fail 1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml", runtime_config={
        "steps": [
            {"id": "collect_a", "max_attempts": 5},
            {"id": "collect_b", "max_attempts": 5},
        ]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="bad_a_1", initial_context={})  # A attempt 1
    tool.execute(thread_id=tid, user_message="bad_a_2", initial_context={})  # A attempt 2
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})    # A attempt 3 (success)

    # Now in collect_b
    s_b_start = snap(tool, tid)
    assert s_b_start[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b", 0) == 0

    tool.execute(thread_id=tid, user_message="bad_b", initial_context={})  # B attempt 1
    s_b_fail = snap(tool, tid)

    # B incremented, A unchanged
    assert s_b_fail[WorkflowKeys.ATTEMPT_COUNTS].get("collect_b") == 1
    assert s_b_fail[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 3


@respx.mock
def test_self_loop_counter_resets_on_fresh_entry_after_completion():
    """Verify that a completed node's counter resets to 0 when it is re-entered via intent change.

    Reason: After a node completes successfully its counter retains the total turn count from
    that run. On intent-change re-entry the node must start fresh at 0; otherwise the leftover
    count from the previous successful run could instantly trigger max_attempts termination
    on re-entry if the previous run took many turns.
    """
    responses = iter([
        collector_prompt("A?"),
        llm_structured_response({"bot_response": "Retry A.", "field_a": None}),  # A fail 1
        collector_capture("val_a"),                                                # A success
        fu_intent_change("collect_a", "Let me redo A."),                          # Follow-up IC
        collector_prompt("A again?"),                                              # Fresh A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 5}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="bad_a", initial_context={})   # attempt 1 (fail)
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})   # attempt 2 (success)

    s_after_a = snap(tool, tid)
    assert s_after_a[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a") == 2  # 1 fail + 1 success

    # Intent change from follow-up back to collect_a
    tool.execute(thread_id=tid, user_message="Actually change A", initial_context={})
    s_reset = snap(tool, tid)

    # On fresh re-entry, counter must be 0
    assert s_reset[WorkflowKeys.ATTEMPT_COUNTS].get("collect_a", 0) == 0
    assert s_reset[WorkflowKeys.STATUS] == "collect_a_collecting"

@respx.mock
def test_max_attempts_adds_to_execution_order():
    """Verify that a node reaching max_attempts is added to node_execution_order."""
    responses = iter([
        collector_prompt("What is field A?"),
        llm_structured_response({"bot_response": "Fail.", "field_a": None}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", runtime_config={
        "steps": [{"id": "collect_a", "max_attempts": 1}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail", initial_context={})

    s = snap(tool, tid)
    assert s[WorkflowKeys.STATUS] == "collect_a_max_attempts"
    assert "collect_a" in s[WorkflowKeys.NODE_EXECUTION_ORDER]

