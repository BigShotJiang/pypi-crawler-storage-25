import uuid
import json
import respx
from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_prompt,
    collector_capture,
    fu_answer,
    fu_intent_change,
    fu_transition,
    make_tool,
    snap,
)

# pytestmark = [pytest.mark.runthis]

@respx.mock
def test_follow_up_transition_forward_jump():
    """Verify that a transition to an unvisited node works correctly."""
    responses = iter([
        collector_prompt("What is your name?"),                          # LLM#1: collect_name
        collector_capture("Alice", field="user_name"),                    # LLM#2: capture
        fu_transition("agent_callback", "Let me connect you."),          # LLM#3: transition to agent_callback
        collector_prompt("Why do you want to talk to an agent?"),        # LLM#4: agent_callback prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_transitions.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Request transition to agent_callback
    result3 = tool.execute(thread_id=tid, user_message="speak to agent", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)
    assert "Why do you want to talk to an agent?" in str(result3)
    assert s.get("user_name") == "Alice"
    assert s.get("_follow_up_active") is None
    assert respx.calls.call_count == 4

@respx.mock
def test_follow_up_prioritizes_intent_change_for_visited_nodes():
    """Verify that a node in both transitions and history is treated as intent_change."""
    responses = iter([
        collector_prompt("What is your name?"),                          # LLM#1: collect_name
        collector_capture("Alice", field="user_name"),                    # LLM#2: capture
        # This should be intent_change because collect_name is visited
        fu_intent_change("collect_name"),     # LLM#3
        collector_prompt("Please re-enter your name."),                  # LLM#4: re-prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    # Add collect_name to transitions in the tool config
    tool = make_tool("follow_up_transitions.yaml", runtime_config={
        "follow_up": {
            "transitions": ["collect_name"]
        }
    }
    )
    
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    result3 = tool.execute(thread_id=tid, user_message="change name", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)
    assert s.get("user_name") is None  # Cleared by rollback
    assert s.get("_follow_up_active") is None
    assert respx.calls.call_count == 4

# @pytest.mark.runthis
@respx.mock
def test_follow_up_auto_description_retrieval():
    """Verify that routing guidance automatically retrieves node descriptions."""
    captured_requests = []
    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("What is your name?"),
        collector_capture("Alice", field="user_name"),
        fu_answer("How can I help further?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_transitions.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    tool.execute(thread_id=tid, user_message="just a question", initial_context={})

    # Check LLM prompt for routing guidance
    print(f"Captured requests: {len(captured_requests)}")
    for i, req in enumerate(captured_requests):
        body = json.loads(req.content)
        print(f"Request {i} prompt: {body['messages'][0]['content'][:100]}...")

    last_req = captured_requests[-1]
    body = json.loads(last_req.content)
    system_prompt = body['messages'][0]['content']

    # Descriptions from YAML:
    # agent_callback -> "Connect with a live agent."
    # feedback_survey -> "A survey for user feedback." (from description)
    assert "agent_callback" in system_prompt
    assert "Connect with a live agent." in system_prompt
    assert "feedback_survey" in system_prompt
    assert "A survey for user feedback." in system_prompt
    assert "AVAILABLE NEXT STEPS" in system_prompt


@respx.mock
def test_follow_up_transition_to_outcome():
    """Verify that a transition to an unvisited outcome node works correctly."""
    responses = iter([
        collector_prompt("What is your name?"),                          # LLM#1: collect_name
        collector_capture("Alice", field="user_name"),                    # LLM#2: capture
        fu_transition("feedback_survey", "Thanks for your help!"),       # LLM#3: transition to outcome
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_transitions.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Request transition to feedback_survey (outcome)
    result3 = tool.execute(thread_id=tid, user_message="quit and survey", initial_context={})
    s = snap(tool, tid)

    assert "Thank you for your feedback!" in str(result3)
    # _follow_up_active is cleared in _handle_transition
    assert not s.get("_follow_up_active")
    assert respx.calls.call_count == 3

@respx.mock
def test_follow_up_rejects_intent_change_to_excluded_node():
    """Verify that an intent change to an excluded node is rejected."""
    responses = iter([
        collector_prompt("What is your name?"),                          # LLM#1
        collector_capture("Alice", field="user_name"),                    # LLM#2
        # Use transition here because we want to test REJECTION of transition/intent signal
        # Actually, if we use fu_intent_change("collect_name"), it will fail validation 
        # because collect_name is excluded and NOT in transitions.
        fu_intent_change("collect_name"),                                 # LLM#3
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    # Exclude collect_name
    tool = make_tool("follow_up_transitions.yaml", runtime_config={
        "follow_up": {
            "excluded_nodes": ["collect_name"]
        }
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Request intent_change for an excluded node.
    # LLM returns fu_intent_change("collect_name"), but collect_name is excluded.
    # Structured output validation fails, falls back to bot_response.
    result3 = tool.execute(thread_id=tid, user_message="change my name", initial_context={})
    s = snap(tool, tid)

    assert s.get("_follow_up_active") is True
    assert s.get("user_name") == "Alice"  # Not rolled back
    # Since validation fails, the guardrail might retry if configured.
    # In this test environment, we just expect it to finish the execution after failure.
    assert InterruptType.FOLLOW_UP in str(result3)

@respx.mock
def test_follow_up_fallback_on_invalid_transition_target():
    """Verify that an invalid transition target falls back to a self-loop."""
    responses = iter([
        collector_prompt("What is your name?"),
        collector_capture("Alice", field="user_name"),
        fu_transition("non_existent_node", "Going nowhere."), # LLM fails on guardrails and retries.
        fu_transition("non_existent_node", "Going nowhere."), # LLM fails on guardrails after retry and exits.
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_transitions.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: LLM returns invalid transition
    result3 = tool.execute(thread_id=tid, user_message="go to space", initial_context={})
    s = snap(tool, tid)

    assert s.get("_follow_up_active") is True
    assert respx.calls.call_count == 4
    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Test failed. Follow-up transitions did not work as expected." in str(result3)

@respx.mock
def test_follow_up_multiple_signals_priority():
    """Verify signal priority: intent_change > transition > out_of_scope > restart."""
    def _priority_effect(req):
        # On the follow-up turn (3rd call), return multiple signals
        if len(respx.calls) == 2:
            return respx.Response(200, json={
                "choices": [{
                    "message": {
                        "role": "assistant",
                        "content": json.dumps({
                            "reasoning": "Prioritizing intent change.",
                            "bot_response": None,
                            "intent_change": "collect_name",
                            "restart": True,
                            "out_of_scope": "don't care"
                        })
                    }
                }]
            })
        return next(responses)

    responses = iter([
        collector_prompt("What is your name?"),
        collector_capture("Alice", field="user_name"),
        collector_prompt("Please re-enter your name."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_priority_effect)

    tool = make_tool("follow_up_transitions.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Mixed signals. Should pick intent_change.
    result3 = tool.execute(thread_id=tid, user_message="actually my name is Bob", initial_context={})
    
    # Check if we landed back at collect_name
    assert "Please re-enter your name." in str(result3)
    assert respx.calls.call_count == 4 # LLM1, LLM2, LLM3 (followup), LLM4 (collect_name re-prompt)

@respx.mock
def test_follow_up_transition_to_call_function():
    """Verify that a transition to a call_function node works correctly."""
    responses = iter([
        collector_prompt("What is your name?"),
        collector_capture("Alice", field="user_name"),
        fu_transition("run_logic", "Recalculating."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_with_func.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Request transition to run_logic (call_function)
    result3 = tool.execute(thread_id=tid, user_message="re-run logic", initial_context={})
    s = snap(tool, tid)

    assert "Success! Name: Alice" in str(result3)
    assert "Computed: computed_set" in str(result3)
    assert s.get("_follow_up_active") is True
    assert respx.calls.call_count == 3


def test_follow_up_get_raw_transition_description_unit():
    """Unit test for the _get_raw_transition_description method."""
    from unittest.mock import MagicMock
    from soprano_sdk.nodes.follow_up import FollowUpStrategy

    mock_engine = MagicMock()
    # Mocking step_map with different action types
    mock_engine.step_map = {
        "collector_step": {
            "action": "collect_input_with_agent",
            "agent": {"description": "Collector description"}
        },
        "plain_step": {
            "action": "other_action",
            "description": "Plain step description"
        }
    }
    # Mocking outcome_map
    mock_engine.outcome_map = {
        "outcome_step": {
            "description": "Outcome description"
        }
    }

    # Initialize strategy with mock engine
    strategy = FollowUpStrategy(
        follow_up_config={"name": "test_follow_up"},
        engine_context=mock_engine,
        first_step_id="start_node"
    )

    # 1. Test COLLECT_INPUT_WITH_AGENT node
    assert strategy._get_raw_transition_description("collector_step") == "Collector description"

    # 2. Test plain step description
    assert strategy._get_raw_transition_description("plain_step") == "Plain step description"

    # 3. Test outcome node description
    assert strategy._get_raw_transition_description("outcome_step") == "Outcome description"

    # 4. Test non-existent node
    assert strategy._get_raw_transition_description("non_existent") == ""


if __name__ == "__main__":
    test_follow_up_prioritizes_intent_change_for_visited_nodes()