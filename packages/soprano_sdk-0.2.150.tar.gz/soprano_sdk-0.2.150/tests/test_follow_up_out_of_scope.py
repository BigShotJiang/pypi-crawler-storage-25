"""Tests for out-of-scope detection in the follow-up node. Covers interrupt payload
structure, attempt counter management, bot_response delivery, options forwarding, conversation
history storage, and the consecutive OOS cap.
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    follow_up_conv_key,
    fu_answer,
    fu_out_of_scope,
    llm_structured_response,
    make_tool,
    snap,
)


def fu_empty_oos(reason: str):
    """Follow-up LLM returns bot_response='' AND out_of_scope set."""
    return llm_structured_response({
        "bot_response": "",
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": False,
    })


def fu_null_bot_oos(reason: str):
    """Follow-up LLM returns bot_response=null AND out_of_scope set."""
    return llm_structured_response({
        "bot_response": None,
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": False,
    })


def fu_oos_with_options(reason: str, text: str, option_texts: list):
    """Follow-up LLM returns OOS with selectable options."""
    return llm_structured_response({
        "bot_response": text,
        "options": [{"text": t, "subtext": None} for t in option_texts],
        "is_selectable": True,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": False,
    })


@respx.mock
def test_out_of_scope_raises_follow_up_oos_interrupt():
    """When the follow-up LLM detects an out-of-scope query, the graph should raise a
    FOLLOW_UP_OUT_OF_SCOPE interrupt and pause rather than ending. The graph being paused
    (not at END) means the user can continue the conversation after the OOS notification.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "I can't help with that."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)
    assert InterruptType.FOLLOW_UP not in str(result3).replace(InterruptType.FOLLOW_UP_OUT_OF_SCOPE, "")

    # Graph is paused (not at END): checkpoint still has a pending interrupt in tasks
    state_obj = tool.graph.get_state({"configurable": {"thread_id": tid}})
    assert state_obj.interrupts  # non-empty means graph has a pending interrupt


@respx.mock
def test_out_of_scope_interrupt_payload_contains_required_fields():
    """The FOLLOW_UP_OUT_OF_SCOPE interrupt payload should contain the reason code and the
    user's original message — matching the same structure as the regular out-of-scope interrupt.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "I can't help with that."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)

    # Result format: __FOLLOW_UP_OUT_OF_SCOPE__|tid|name|{json}
    payload = json.loads(str(result3).split("|", 3)[3])
    assert payload["reason"] == "unrelated_topic"
    assert payload["user_message"] == "unrelated question"
    assert "bot_response" not in payload


@respx.mock
def test_resuming_after_out_of_scope_continues_as_normal_qa():
    """After an out-of-scope interrupt is delivered, the user's next message should be
    processed as a new normal Q&A turn by the follow-up LLM. OOS turns count toward
    max_attempts like any other turn.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "I can't help with that."),  # LLM#3
        fu_answer("Here's what I can help you with."),        # LLM#4: resumes as Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)

    # Resume after out_of_scope — user's message processed as new Q&A turn
    result4 = tool.execute(thread_id=tid, user_message="what about savings?", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "Here's what I can help you with." in str(result4)
    assert s["_follow_up_attempts"] == 2  # OOS (1) + normal Q&A (1)
    assert respx.calls.call_count == 4


@respx.mock
def test_out_of_scope_consumes_follow_up_attempt_slot():
    """An out-of-scope detection counts against max_attempts just like a normal Q&A turn.
    With max_attempts=1, the OOS turn consumes the only available slot so the next message
    terminates the conversation.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "I can't help with that."),  # LLM#3 (attempt 1)
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_max_one_attempt.yaml")  # max_attempts=1
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})  # T3 → OOS interrupt

    # T4: attempt=2 > max_attempts=1 → terminates without calling LLM
    result4 = tool.execute(thread_id=tid, user_message="what about savings?", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result4), (
        f"Session should terminate after OOS consumed the only attempt slot; got: '{str(result4)}'"
    )
    assert respx.calls.call_count == 3  # no extra LLM call at T4


@respx.mock
def test_out_of_scope_with_null_bot_response_still_fires_oos_interrupt():
    """When the follow-up LLM returns bot_response=null alongside an out_of_scope signal,
    the OOS dispatch should still fire correctly. A null bot_response should not cause the
    OOS signal to be dropped or replaced with a fallback that silently discards the dispatch.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_null_bot_oos("unrelated_topic"),  # LLM#3 — follow-up: bot_response=null + out_of_scope set
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE interrupt but got: "
        f"'{str(result3)[:300]}'. "
        f"FollowUpOutput.bot_response is declared as `str` (not Optional[str]). "
        f"When the LLM returns bot_response=null with out_of_scope set, Pydantic raises "
        f"ValidationError at line 127 (None is not a valid str). "
        f"The except block at line 141 rebuilds output with str(raw_response) as "
        f"bot_response, wiping all dispatch signals. "
        f"Fix: change `bot_response: str` to `bot_response: Optional[str] = None` "
        f"and handle None in the N2 guard."
    )


@respx.mock
def test_empty_oos_bot_response_does_not_store_blank_conversation_entry():
    """When the follow-up LLM returns an empty bot_response alongside an out_of_scope
    signal, no blank assistant entry should be stored in the follow-up conversation.
    Blank conversation entries would pollute subsequent LLM calls with empty assistant turns.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_empty_oos("unrelated_topic"),              # LLM#3 — OOS with bot_response=""
        fu_answer("Here is my answer."),     # LLM#4 — resumed after OOS
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    # T3 must be FOLLOW_UP_OUT_OF_SCOPE
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE at T3, got: '{str(result3)[:200]}'"
    )

    result4 = tool.execute(thread_id=tid, user_message="ok continue", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP at T4, got: '{str(result4)[:200]}'"
    )

    # Verify LLM#4 was called (captured_requests index 3)
    assert len(captured_requests) >= 4, (
        f"Expected at least 4 LLM requests but captured {len(captured_requests)}"
    )

    # Parse the follow-up LLM request (LLM#4, index 3)
    follow_up_req_body = json.loads(captured_requests[3].content)
    messages = follow_up_req_body.get("messages", [])

    # Filter out the system message — only check the conversation turns
    non_system_messages = [m for m in messages if m.get("role") != "system"]

    # Assert: no blank assistant entry in the conversation
    blank_assistant_entries = [
        m for m in non_system_messages
        if m.get("role") == "assistant" and m.get("content", "NONEMPTY").strip() == ""
    ]
    assert not blank_assistant_entries, (
        f"LLM#4 request must NOT contain blank assistant conversation entries. "
        f"Non-system messages: {non_system_messages}"
    )


@respx.mock
def test_out_of_scope_bot_response_not_forwarded_in_interrupt_payload():
    """The FOLLOW_UP_OUT_OF_SCOPE interrupt payload contains only reason and user_message,
    mirroring the regular out-of-scope pattern. The bot_response is stored in conversation
    history for future LLM context but is not forwarded in the interrupt payload.
    After the OOS interrupt the conversation is resumable as a normal Q&A turn.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "I cannot help with that topic."),
        fu_answer("Here is my answer after OOS."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})
    result4 = tool.execute(thread_id=tid, user_message="ok continue", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)

    parts = str(result3).split("|", 3)
    oos_payload = json.loads(parts[3])
    assert oos_payload.get("reason") == "unrelated_topic"
    assert oos_payload.get("user_message") == "unrelated question"
    assert "bot_response" not in oos_payload

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "Here is my answer after OOS." in str(result4)
    assert len(captured_requests) >= 4

    s = snap(tool, tid)
    assert s.get("_follow_up_attempts") == 2


@respx.mock
def test_consecutive_out_of_scope_responses_each_consume_an_attempt_slot():
    """Multiple consecutive OOS detections each count toward max_attempts. After 2 OOS
    turns and 1 normal turn the attempt counter should be 3.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "That is outside my scope."),         # LLM#3 — first OOS
        fu_out_of_scope("stocks", "No stocks help either."), # LLM#4 — second OOS
        fu_answer("Here is your real answer."),               # LLM#5 — normal turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE at T3, got: '{str(result3)[:200]}'"
    )

    result4 = tool.execute(thread_id=tid, user_message="ask about stocks", initial_context={})
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result4), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE at T4 (second OOS), got: '{str(result4)[:200]}'"
    )

    result5 = tool.execute(thread_id=tid, user_message="normal question", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result5), (
        f"Expected FOLLOW_UP at T5 (normal turn after 2 OOS), got: '{str(result5)[:200]}'"
    )
    assert "Here is your real answer." in str(result5), (
        f"Normal answer must appear in T5 result. Got: '{str(result5)[:200]}'"
    )

    s5 = snap(tool, tid)
    assert s5.get("_follow_up_attempts") == 3, (
        f"_follow_up_attempts after 2 OOS + 1 normal turn should be 3. "
        f"Got: {s5.get('_follow_up_attempts')!r}"
    )
    assert s5.get("_follow_up_active") is True, (
        f"_follow_up_active must be True after normal turn. Got: {s5.get('_follow_up_active')!r}"
    )


@respx.mock
def test_out_of_scope_bot_response_stored_in_follow_up_conversation():
    """When the follow-up LLM returns a non-empty bot_response alongside an out_of_scope
    signal, the bot_response should be stored as an assistant entry in the follow-up
    conversation so that the next LLM call has full context about the OOS exchange.
    Without this entry the LLM would see two consecutive user messages with no assistant
    response in between.
    """
    OOS_EXPLANATION = "I cannot help with that topic."

    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", OOS_EXPLANATION),            # LLM#3 — OOS with non-empty bot_response
        fu_answer("Here is your answer after the OOS."),       # LLM#4 — normal answer on resume
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE at T3, got: '{str(result3)[:200]}'"
    )

    result4 = tool.execute(thread_id=tid, user_message="ok continue", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP at T4, got: '{str(result4)[:200]}'"
    )

    # LLM#4 is the 4th request (index 3)
    assert len(captured_requests) >= 4, (
        f"Expected at least 4 LLM requests, got {len(captured_requests)}"
    )

    follow_up_req_body = json.loads(captured_requests[3].content)
    messages = follow_up_req_body.get("messages", [])
    non_system = [m for m in messages if m.get("role") != "system"]

    # The OOS explanation must appear as an assistant entry
    oos_in_assistant = any(
        OOS_EXPLANATION in str(m.get("content", ""))
        for m in non_system
        if m.get("role") == "assistant"
    )
    assert oos_in_assistant, (
        f"The OOS explanation '{OOS_EXPLANATION}' is absent "
        f"from the assistant entries in LLM#4's conversation. "
        f"When out_of_scope fires with a non-empty bot_response, the Q3 fix "
        f"(lines 169–175) skips storing any assistant entry for OOS, so the "
        f"follow-up LLM receives no context that an OOS exchange occurred. "
        f"Non-system messages: {non_system}"
    )

    # There must be no two consecutive user messages
    for i in range(len(non_system) - 1):
        assert not (
            non_system[i].get("role") == "user"
            and non_system[i + 1].get("role") == "user"
        ), (
            f"LLM#4 conversation contains consecutive user "
            f"messages at indices {i} and {i+1} with no assistant entry between "
            f"them: {non_system[i]!r} → {non_system[i+1]!r}. "
            f"The non-empty OOS bot_response ('{OOS_EXPLANATION}') is delivered "
            f"to the user via FOLLOW_UP_OUT_OF_SCOPE but is never stored as an "
            f"assistant entry in the follow-up conversation. "
            f"Full non-system messages: {non_system}"
        )


@respx.mock
def test_consecutive_out_of_scope_responses_capped_by_max_attempts():
    """When the follow-up LLM returns out_of_scope on every turn, each OOS turn consumes
    one attempt. After max_attempts OOS turns the graph terminates with the farewell message.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("unrelated_topic", "Cannot help."),   # LLM#3 — OOS turn 1
        fu_out_of_scope("unrelated_topic", "Cannot help."),   # LLM#4 — OOS turn 2
        fu_out_of_scope("unrelated_topic", "Cannot help."),   # LLM#5 — OOS turn 3
        fu_out_of_scope("unrelated_topic", "Cannot help."),   # LLM#6 — only called if bug present
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})     # T3 — OOS#1
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected OOS interrupt at T3, got: '{str(result3)[:200]}'"
    )

    result4 = tool.execute(thread_id=tid, user_message="ok1", initial_context={})    # T4 — OOS#2
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result4), (
        f"Expected OOS interrupt at T4, got: '{str(result4)[:200]}'"
    )

    result5 = tool.execute(thread_id=tid, user_message="ok2", initial_context={})    # T5 — OOS#3
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result5), (
        f"Expected OOS interrupt at T5, got: '{str(result5)[:200]}'"
    )

    # T6: this is the (max_attempts + 1)-th interaction — should terminate
    result6 = tool.execute(thread_id=tid, user_message="ok3", initial_context={})    # T6 — should END

    assert "Max attempts reached. Goodbye." in str(result6), (
        f"Expected 'Max attempts reached. Goodbye.' at T6 "
        f"(4th turn after 3 consecutive OOS turns with max_attempts=3), "
        f"got: '{str(result6)[:300]}'"
    )

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE not in str(result6), (
        f"T6 still returned FOLLOW_UP_OUT_OF_SCOPE — "
        f"the OOS loop continues past max_attempts=3. "
        f"Full result: '{str(result6)[:300]}'"
    )


@respx.mock
def test_oos_exhaustion_clears_both_follow_up_counters():
    """When consecutive OOS attempts exhaust the limit, the terminal checkpoint should
    have both follow-up counters cleared to None. Stale counter values in the terminal
    state would create an inconsistent checkpoint that could mislead downstream systems.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid"),
        fu_out_of_scope("unrelated_topic", "Sorry."), # LLM#3 — OOS #1
        fu_out_of_scope("unrelated_topic", "Sorry."), # LLM#4 — OOS #2
        fu_out_of_scope("unrelated_topic", "Sorry."), # LLM#5 — OOS #3
        fu_out_of_scope("unrelated_topic", "Sorry."), # LLM#6 — OOS #4 (terminates)
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid", initial_context={})
    tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})    # T3 → OOS#1
    tool.execute(thread_id=tid, user_message="unrelated question 2", initial_context={})   # T4 → OOS#2
    tool.execute(thread_id=tid, user_message="unrelated question 3", initial_context={})   # T5 → OOS#3
    result6 = tool.execute(thread_id=tid, user_message="unrelated question 4", initial_context={})  # T6 → exhaustion

    # T6 must terminate the graph
    assert InterruptType.FOLLOW_UP not in str(result6), (
        f"Expected graph to terminate after OOS max_attempts exceeded, "
        f"got FOLLOW_UP interrupt: '{str(result6)[:200]}'"
    )
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE not in str(result6), (
        f"Expected graph to terminate after OOS max_attempts exceeded, "
        f"got FOLLOW_UP_OUT_OF_SCOPE interrupt: '{str(result6)[:200]}'"
    )

    assert "Max attempts reached. Goodbye." in str(result6), (
        f"Expected on_max_attempts_reached message in result, got: '{str(result6)[:200]}'"
    )

    s = snap(tool, tid)

    # Baseline: active flag and payload are correctly cleared
    assert s.get("_follow_up_active") is None, (
        f"_follow_up_active should be None after OOS exhaustion, "
        f"got: {s.get('_follow_up_active')}"
    )
    assert s.get("_follow_up_pending_prompt") is None, (
        f"_follow_up_pending_prompt should be None after OOS exhaustion, "
        f"got: {s.get('_follow_up_pending_prompt')}"
    )

    assert s.get("_follow_up_attempts") is None, (
        f"_follow_up_attempts is {s.get('_follow_up_attempts')!r} "
        f"after OOS exhaustion termination; expected None."
    )


@respx.mock
def test_out_of_scope_options_stored_in_conversation_not_forwarded_to_result():
    """When the follow-up LLM returns an OOS response with selectable options, those options
    are stored in the follow-up conversation entry (for LLM context) but are NOT forwarded
    to the interrupt result — matching the regular out-of-scope pattern.
    """
    OPTION_TEXTS = ["Option A", "Option B"]
    OOS_TEXT = "I can't help with that. Would you like to ask about something else?"
    OOS_REASON = "unrelated_topic"

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_oos_with_options(OOS_REASON, OOS_TEXT, OPTION_TEXTS),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)
    assert result3.options == []
    assert result3.is_selectable is False


@respx.mock
def test_out_of_scope_options_persisted_in_follow_up_conversation():
    """When the follow-up LLM returns an OOS response with selectable options, those
    options should be stored in the follow-up conversation entry so that subsequent LLM
    calls have full context about which interactive options were displayed to the user.
    Without options in the conversation the LLM cannot resolve references like
    'I'll pick the second option'.
    """
    OPTION_TEXTS = ["Option A", "Option B"]
    OOS_TEXT = "I can't help with that. Would you like to ask about something else?"
    OOS_REASON = "unrelated_topic"

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_oos_with_options(OOS_REASON, OOS_TEXT, OPTION_TEXTS),  # LLM#3 — OOS with options
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})             # T3 → OOS

    # Inspect the follow-up conversation stored in state
    state = snap(tool, tid)
    conversation_key = follow_up_conv_key(tool)
    conversations = state.get("_conversations", {})

    assert conversation_key in conversations, (
        f"Follow-up conversation key '{conversation_key}' not found in "
        f"_conversations. Keys: {list(conversations.keys())}"
    )

    fu_conversation = conversations[conversation_key]
    # Find the last assistant entry (the OOS bot_response)
    assistant_entries = [e for e in fu_conversation if e.get("role") == "assistant"]

    assert assistant_entries, (
        f"No assistant entries in follow-up conversation after OOS turn. "
        f"Conversation: {fu_conversation}"
    )

    oos_assistant_entry = assistant_entries[-1]

    # options/is_selectable are serialised into the JSON content by _build_conversation_entry
    content = oos_assistant_entry.get("content", "")
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        parsed = {}

    stored_options = parsed.get("options")
    stored_is_selectable = parsed.get("is_selectable")

    assert stored_options is not None, (
        f"'options' is absent from the OOS assistant conversation entry content. "
        f"Entry content: {content!r}"
    )

    assert stored_is_selectable is True, (
        f"is_selectable in OOS conversation entry should be True, "
        f"got: {stored_is_selectable!r}"
    )

    stored_option_texts = [o.get("text") for o in stored_options]
    for expected_text in OPTION_TEXTS:
        assert expected_text in stored_option_texts, (
            f"Option '{expected_text}' not found in stored conversation "
            f"entry options. Stored options: {stored_options}"
        )


@respx.mock
def test_follow_up_oos_prompt_injection():
    """Verify that the out-of-scope detection block is injected into the 
    follow-up system prompt during an end-to-end execution.
    """
    responses = iter([
        collector_prompt("What is your name?"),  # T1: Start
        collector_capture("Antigravity", "user_name"), # T2: Input
        fu_answer("I am follow-up") # T3: First follow-up turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_oos.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    
    tool.execute(thread_id=tid, user_message="Antigravity")
    

    tool.execute(thread_id=tid, user_message="How are you?")
    

    fu_call = None
    all_system_prompts = []
    for call in respx.calls:
        try:
            body = json.loads(call.request.content)
            messages = body.get("messages", [])
            system_prompt = next((msg["content"] for msg in messages if msg["role"] == "system"), "")
            all_system_prompts.append(system_prompt)
            # Match by some unique markers in FollowUpStrategy._build_core_instructions
            if "RESTART" in system_prompt.upper() and "INTENT_CHANGE" in system_prompt.upper():
                fu_call = call
                break
        except Exception:
            continue
            
    assert fu_call is not None, "Follow-up agent LLM call not found"
    body = json.loads(fu_call.request.content)
    system_prompt = next((msg["content"] for msg in body["messages"] if msg["role"] == "system"), "")
    
    # Assertions
    assert "<out_of_scope_detection>" in system_prompt
    assert "OUT-OF-SCOPE DETECTION:" in system_prompt
    assert "This workflow collects the user's name to say thank you." in system_prompt
    assert "IMPORTANT: If the user's query is COMPLETELY UNRELATED" in system_prompt
    assert "A workflow to test out-of-scope detection in follow-up." not in system_prompt


@respx.mock
def test_follow_up_oos_prompt_injection_workflow_description():
    """Verify that the out-of-scope detection block is injected into the 
    follow-up system prompt during an end-to-end execution.
    """
    responses = iter([
        collector_prompt("What is your name?"),  # T1: Start
        collector_capture("Antigravity", "user_name"), # T2: Input
        fu_answer("I am follow-up") # T3: First follow-up turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_oos.yaml", runtime_config={
        "follow_up": {
            "scope_description": ""
        }
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    
    tool.execute(thread_id=tid, user_message="Antigravity")
    

    tool.execute(thread_id=tid, user_message="How are you?")
    

    fu_call = None
    all_system_prompts = []
    for call in respx.calls:
        try:
            body = json.loads(call.request.content)
            messages = body.get("messages", [])
            system_prompt = next((msg["content"] for msg in messages if msg["role"] == "system"), "")
            all_system_prompts.append(system_prompt)
            # Match by some unique markers in FollowUpStrategy._build_core_instructions
            if "RESTART" in system_prompt.upper() and "INTENT_CHANGE" in system_prompt.upper():
                fu_call = call
                break
        except Exception:
            continue
            
    assert fu_call is not None, "Follow-up agent LLM call not found"
    body = json.loads(fu_call.request.content)
    system_prompt = next((msg["content"] for msg in body["messages"] if msg["role"] == "system"), "")
    
    # Assertions
    assert "<out_of_scope_detection>" in system_prompt
    assert "OUT-OF-SCOPE DETECTION:" in system_prompt
    assert "This workflow collects the user's name to say thank you." not in system_prompt
    assert "A workflow to test out-of-scope detection in follow-up." in system_prompt
    assert "IMPORTANT: If the user's query is COMPLETELY UNRELATED" in system_prompt

@respx.mock
def test_follow_up_triggers_oos_interrupt():
    """Verify that when the LLM returns an out_of_scope signal, the framework
    raises a follow_up_out_of_scope interrupt.
    """
    responses = iter([
        collector_prompt("What is your name?"),
        collector_capture("Antigravity", "user_name"),
        fu_out_of_scope("crypto", "I cannot help with crypto.")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_oos.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Antigravity")
    
    # This call should trigger the OOS response from fake LLM
    res = tool.execute(thread_id=tid, user_message="Buy me some bitcoin")
    
    # Check interrupt type (note: FollowUpStrategy might deliver OOS via a custom flow)
    # The key is that the interrupt reason and message are present.
    assert "Buy me some bitcoin" in res
    assert "crypto" in res



