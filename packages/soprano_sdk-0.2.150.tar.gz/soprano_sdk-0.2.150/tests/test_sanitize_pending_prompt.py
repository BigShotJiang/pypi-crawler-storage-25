"""
Unit tests for CollectInputStrategy._sanitize_pending_prompt.

The function has one job: suppress prompt_data whose text is a TransitionPattern
control signal (INTENT_CHANGE:, OUT_OF_SCOPE:, etc.).

Input can be either:
  - A dict  (normal case, returned by _get_continuation_prompt / _generate_prompt)
  - A str   (raw JSON that arrived without being pre-parsed)

In both cases the function extracts the user-facing text from
bot_response / text / message (in that priority order) and checks it.
Non-control-signal prompts are returned unchanged.
"""

import json
import pytest
from unittest.mock import MagicMock

from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.core.constants import TransitionPattern


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

@pytest.fixture
def strategy():
    step_config = {"field": "test_field", "agent": {"name": "test_agent"}}
    engine_context = MagicMock()
    engine_context.get_config_value.return_value = "history_based"
    return CollectInputStrategy(step_config, engine_context)


# ---------------------------------------------------------------------------
# Dict input — normal prompts (must pass through unchanged)
# ---------------------------------------------------------------------------

class TestDictInputPassThrough:
    def test_normal_text_prompt_passes_through(self, strategy):
        prompt = {"text": "What is your name?", "options": [], "is_selectable": False}
        assert strategy._sanitize_pending_prompt(prompt) is prompt

    def test_bot_response_key_passes_through(self, strategy):
        prompt = {"bot_response": "What is your name?", "options": None, "is_selectable": None}
        assert strategy._sanitize_pending_prompt(prompt) is prompt

    def test_message_key_passes_through(self, strategy):
        prompt = {"message": "What is your name?", "options": [], "is_selectable": False}
        assert strategy._sanitize_pending_prompt(prompt) is prompt

    def test_prompt_with_options_passes_through(self, strategy):
        prompt = {
            "text": "Please select an option",
            "options": [{"text": "Yes", "subtext": ""}, {"text": "No", "subtext": ""}],
            "is_selectable": True,
        }
        assert strategy._sanitize_pending_prompt(prompt) is prompt


# ---------------------------------------------------------------------------
# Dict input — control signal in text key → suppressed
# ---------------------------------------------------------------------------

class TestDictInputControlSignals:
    def test_intent_change_in_text_suppressed(self, strategy):
        prompt = {"text": f"{TransitionPattern.INTENT_CHANGE.value}collect_name", "options": [], "is_selectable": False}
        assert strategy._sanitize_pending_prompt(prompt) is None

    def test_out_of_scope_in_text_suppressed(self, strategy):
        prompt = {"text": f"{TransitionPattern.OUT_OF_SCOPE_PATTERN.value}user asked about weather", "options": [], "is_selectable": False}
        assert strategy._sanitize_pending_prompt(prompt) is None

    def test_intent_change_in_bot_response_suppressed(self, strategy):
        prompt = {"bot_response": f"{TransitionPattern.INTENT_CHANGE.value}collect_age", "options": None, "is_selectable": None}
        assert strategy._sanitize_pending_prompt(prompt) is None

    def test_out_of_scope_in_message_key_suppressed(self, strategy):
        prompt = {"message": f"{TransitionPattern.OUT_OF_SCOPE_PATTERN.value}off-topic query", "options": [], "is_selectable": False}
        assert strategy._sanitize_pending_prompt(prompt) is None

    def test_captured_and_failed_patterns_not_caught(self, strategy):
        # CAPTURED / FAILED use a {field} template: '{field}_CAPTURED:'.
        # text.startswith('{field}_CAPTURED:') never matches 'name_CAPTURED:...'
        # so these pass through — they are handled by _process_transitions, not here.
        assert strategy._sanitize_pending_prompt({"text": "name_CAPTURED:John", "options": [], "is_selectable": False}) is not None
        assert strategy._sanitize_pending_prompt({"text": "name_FAILED:bad", "options": [], "is_selectable": False}) is not None


# ---------------------------------------------------------------------------
# String input (raw JSON) — parsed and checked
# ---------------------------------------------------------------------------

class TestStringInputRawJson:
    def test_raw_json_with_normal_bot_response_passes_through(self, strategy):
        raw = json.dumps({"bot_response": "What is your name?", "options": None, "is_selectable": None})
        result = strategy._sanitize_pending_prompt(raw)
        assert result is raw

    def test_raw_json_with_normal_text_passes_through(self, strategy):
        raw = json.dumps({"text": "What is your age?", "options": [], "is_selectable": False})
        result = strategy._sanitize_pending_prompt(raw)
        assert result is raw

    def test_raw_json_with_intent_change_in_bot_response_suppressed(self, strategy):
        raw = json.dumps({
            "bot_response": f"{TransitionPattern.INTENT_CHANGE.value}collect_name",
            "options": None, "is_selectable": None,
        })
        assert strategy._sanitize_pending_prompt(raw) is None

    def test_raw_json_with_out_of_scope_in_text_suppressed(self, strategy):
        raw = json.dumps({
            "text": f"{TransitionPattern.OUT_OF_SCOPE_PATTERN.value}weather query",
            "options": [], "is_selectable": False,
        })
        assert strategy._sanitize_pending_prompt(raw) is None

    def test_plain_string_non_json_passes_through(self, strategy):
        # Doesn't start with '{' so no JSON parsing attempted
        plain = "What is your name?"
        assert strategy._sanitize_pending_prompt(plain) is plain

    def test_plain_string_control_signal_suppressed(self, strategy):
        signal = f"{TransitionPattern.INTENT_CHANGE.value}collect_status"
        assert strategy._sanitize_pending_prompt(signal) is None


# ---------------------------------------------------------------------------
# Return value identity — original object must be returned unchanged
# ---------------------------------------------------------------------------

class TestReturnIdentity:
    def test_dict_input_returns_same_object(self, strategy):
        prompt = {"text": "Hello", "options": [], "is_selectable": False}
        result = strategy._sanitize_pending_prompt(prompt)
        assert result is prompt  # same object, not a copy

    def test_string_input_returns_same_string(self, strategy):
        raw = json.dumps({"bot_response": "Hello", "options": None, "is_selectable": None})
        result = strategy._sanitize_pending_prompt(raw)
        assert result is raw  # same string object
