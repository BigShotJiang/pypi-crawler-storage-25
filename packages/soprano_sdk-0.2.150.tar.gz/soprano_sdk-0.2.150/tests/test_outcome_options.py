import pytest
from unittest.mock import patch
from soprano_sdk.core.engine import WorkflowEngine
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.models import MessagePayload

class TestOutcomeOptions:
    @pytest.fixture
    def engine(self, tmp_path):
        # Create a dummy yaml file
        yaml_path = tmp_path / "test_workflow.yaml"
        yaml_path.write_text("""
name: Test Workflow
description: Test
version: "1.0"
data:
  - name: result
    type: any
    description: "Dummy result"
steps:
  - id: dummy_step
    action: call_function
    function: math.sqrt
    output: result
    next: outcome_with_options
outcomes:
  - id: outcome_with_options
    type: success
    message: "Success with options"
    options: ["Option 1", "Option 2"]
    is_selectable: true
    humanize: false
  - id: outcome_without_options
    type: success
    message: "Success without options"
    humanize: false
""")
        return WorkflowEngine(str(yaml_path), configs={})

    def test_get_outcome_message_with_static_options(self, engine):
        state = {WorkflowKeys.OUTCOME_ID: "outcome_with_options"}
        payload = engine.get_outcome_message(state)
        
        assert payload.message == "Success with options"
        assert payload.options == [{"text": "Option 1"}, {"text": "Option 2"}]
        assert payload.is_selectable is True

    def test_get_outcome_message_without_options(self, engine):
        state = {WorkflowKeys.OUTCOME_ID: "outcome_without_options"}
        payload = engine.get_outcome_message(state)
        
        assert payload.message == "Success without options"
        assert payload.options is None
        assert payload.is_selectable is False

    @patch.object(WorkflowEngine, '_humanize_message')
    def test_get_outcome_message_with_humanization_passes_options(self, mock_humanize, engine):
        # Enable humanization for this test case
        engine.outcome_map["outcome_with_options"]["humanize"] = True
        engine.config["humanization_agent"] = {"enabled": True}
        
        mock_humanize.return_value = MessagePayload(
            message="Humanized success",
            options=[{"text": "Opt 1", "subtext": "Sub 1"}],
            is_selectable=True
        )
        
        state = {WorkflowKeys.OUTCOME_ID: "outcome_with_options"}
        
        payload = engine.get_outcome_message(state)
        
        assert payload.message == "Humanized success"
        assert payload.options == [{"text": "Opt 1", "subtext": "Sub 1"}]
        assert payload.is_selectable is True
        
        # Verify that normalized options were passed to humanizer
        mock_humanize.assert_called_once_with(
            "Success with options",
            state,
            options=[{"text": "Option 1"}, {"text": "Option 2"}],
            is_selectable=True
        )

    def test_get_outcome_message_with_dynamic_options(self, engine):
        # Add dynamic outcome to map manually for this test
        engine.outcome_map["dynamic_outcome"] = {
            "id": "dynamic_outcome",
            "type": "success",
            "message": "Hello {{ user_name }}",
            "options": ["Help with {{ product }}", {"text": "Stop {{ product }}", "subtext": "Cancel {{ user_name }}"}],
            "is_selectable": False,
            "humanize": False
        }
        
        state = {
            WorkflowKeys.OUTCOME_ID: "dynamic_outcome",
            "user_name": "Alice",
            "product": "Soprano"
        }
        
        payload = engine.get_outcome_message(state)
        
        assert payload.message == "Hello Alice"
        assert payload.options == [
            {"text": "Help with Soprano"},
            {"text": "Stop Soprano", "subtext": "Cancel Alice"}
        ]

    def test_get_outcome_message_with_templated_list_of_strings(self, engine):
        engine.outcome_map["templated_list"] = {
            "id": "templated_list",
            "type": "success",
            "message": "Success",
            "options": "{{ opt_list }}",
            "humanize": False
        }
        state = {
            WorkflowKeys.OUTCOME_ID: "templated_list",
            "opt_list": ["Option A", "Option B"]
        }
        payload = engine.get_outcome_message(state)
        assert payload.options == [{"text": "Option A"}, {"text": "Option B"}]

    def test_get_outcome_message_with_templated_list_of_tuples(self, engine):
        engine.outcome_map["templated_tuples"] = {
            "id": "templated_tuples",
            "type": "success",
            "message": "Success",
            "options": "{{ opt_list }}",
            "humanize": False
        }
        state = {
            WorkflowKeys.OUTCOME_ID: "templated_tuples",
            "opt_list": [("Opt A", "Sub A"), ("Opt B", "Sub B")]
        }
        payload = engine.get_outcome_message(state)
        assert payload.options == [
            {"text": "Opt A", "subtext": "Sub A"},
            {"text": "Opt B", "subtext": "Sub B"}
        ]

    def test_get_outcome_message_with_templated_list_of_dicts(self, engine):
        engine.outcome_map["templated_dicts"] = {
            "id": "templated_dicts",
            "type": "success",
            "message": "Success",
            "options": "{{ opt_list }}",
            "humanize": False
        }
        state = {
            WorkflowKeys.OUTCOME_ID: "templated_dicts",
            "opt_list": [{"text": "Opt A", "subtext": "Sub A"}]
        }
        payload = engine.get_outcome_message(state)
        assert payload.options == [{"text": "Opt A", "subtext": "Sub A"}]
