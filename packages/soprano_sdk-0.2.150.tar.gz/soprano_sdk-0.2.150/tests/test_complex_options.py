import pytest
from jinja2 import Environment
from soprano_sdk.core.engine import WorkflowEngine

class TestComplexOptions:
    @pytest.fixture
    def engine(self, tmp_path):
        yaml_path = tmp_path / "test_workflow.yaml"
        # Minimum valid workflow YAML
        yaml_path.write_text("""
name: Test Workflow
description: Test
version: "1.0"
data:
  - name: result
    type: any
    description: "result"
steps:
  - id: dummy
    action: call_function
    function: math.sqrt
    output: result
    next: outcome
outcomes:
  - id: outcome
    type: success
    message: "msg"
""")
        return WorkflowEngine(str(yaml_path), configs={})

    def test_render_options_with_conditional_jinja(self, engine):
        template_loader = Environment()
        state = {"user_type": "admin"}
        # Complex template with if condition
        options_config = """
        {% if user_type == 'admin' %}
            ["Delete", "Edit"]
        {% else %}
            ["View"]
        {% endif %}
        """
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Delete"}, {"text": "Edit"}]

        state = {"user_type": "guest"}
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "View"}]

    def test_render_options_with_plain_string(self, engine):
        template_loader = Environment()
        state = {}
        options_config = "Just a string"
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Just a string"}]

    def test_render_options_with_whitespace(self, engine):
        template_loader = Environment()
        state = {}
        options_config = "   \n  Stripped String  \n   "
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Stripped String"}]

    def test_render_options_empty_result(self, engine):
        template_loader = Environment()
        state = {"show": False}
        options_config = "{% if show %}Option{% endif %}"
        options = engine._render_options(options_config, state, template_loader)
        assert options is None

    def test_render_options_nested_jinja_in_list_string(self, engine):
        template_loader = Environment()
        state = {"product": "Soprano"}
        options_config = ["Buy {{ product }}", "Try {{ product }}"]
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Buy Soprano"}, {"text": "Try Soprano"}]

    def test_render_options_parsed_list_contains_jinja(self, engine):
        template_loader = Environment()
        state = {"item": "Apple", "list_str": "['Eat {{ item }}']"}
        options_config = "{{ list_str }}"
        # First render makes it "['Eat {{ item }}']"
        # literal_eval makes it ["Eat {{ item }}"]
        # Loop renders each item to "Eat Apple"
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Eat Apple"}]

    def test_render_options_with_jinja_comments(self, engine):
        template_loader = Environment()
        state = {}
        options_config = "{# hidden comment #}['A', 'B']"
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "A"}, {"text": "B"}]

    def test_render_options_with_invalid_python_syntax(self, engine):
        template_loader = Environment()
        state = {}
        # This renders to "[Invalid Syntax]" which is not a valid Python literal (unquoted string)
        options_config = "[Invalid Syntax]"
        options = engine._render_options(options_config, state, template_loader)
        # Should fallback to treating the rendered string as a single option
        assert options == [{"text": "[Invalid Syntax]"}]

    def test_render_options_renders_non_list_literals_as_string(self, engine):
        template_loader = Environment()
        state = {"val": 42}
        options_config = "{{ val }}"
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "42"}]

    def test_render_options_with_mixed_types_in_list(self, engine):
        template_loader = Environment()
        state = {"product": "Soprano"}
        # List containing a string, a tuple, and a dictionary
        options_config = [
            "Buy {{ product }}",
            ("Try {{ product }}", "Free trial"),
            {"text": "Talk to Expert", "subtext": "About {{ product }}"}
        ]
        options = engine._render_options(options_config, state, template_loader)
        assert options == [
            {"text": "Buy Soprano"},
            {"text": "Try Soprano", "subtext": "Free trial"},
            {"text": "Talk to Expert", "subtext": "About Soprano"}
        ]

    def test_render_options_with_deeply_nested_jinja(self, engine):
        template_loader = Environment()
        state = {"item": "Apple", "list_str": "[{'text': 'Eat {{ item }}'}]"}
        options_config = "{{ list_str }}"
        options = engine._render_options(options_config, state, template_loader)
        assert options == [{"text": "Eat Apple"}]
