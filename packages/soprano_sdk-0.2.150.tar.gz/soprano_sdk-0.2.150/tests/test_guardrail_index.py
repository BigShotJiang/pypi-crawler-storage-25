"""
Regression test for the guardrail index misalignment bug.

Bug:
    run_guardrails_parallel() filters out disabled guardrails, so `results[i]`
    maps to the i-th *enabled* guardrail.  But _run_guardrails used
    self.guardrails[failed_idx] — the *unfiltered* list — to look up the failed
    guardrail and its regeneration_feedback.

    With grounding_check disabled at index 0 and StructuredOutputGuardrail
    enabled at index 1:
        filtered results: [GuardrailResult(passed=False)]  ← StructuredOutputGuardrail
        failed_idx = 0
        self.guardrails[0] = GroundingGuardrail  ← WRONG guardrail picked

    The retry message injected into the conversation contained the
    GroundingGuardrail's feedback ("Your previous response contained information
    not supported by...") instead of the StructuredOutputGuardrail's feedback
    ("Your previous response was empty or incomplete...").

Fix:
    Pre-filter self.guardrails → active_guardrails before the retry loop
    and use active_guardrails[failed_idx] for all index lookups.

Test scenario (follow_up_disabled_grounding_guardrail.yaml):
    LLM#1: collector prompt      → "Please provide field_a."
    LLM#2: collector captures    → field_a captured → follow-up entered
    LLM#3: follow-up, 1st try   → plain text (non-JSON) → StructuredOutputGuardrail fires
    LLM#4: follow-up, retry     → valid FollowUpOutput JSON → guardrail passes → self-loop

    Assertion: the retry request (LLM#4) must contain
    StructuredOutputGuardrail's regeneration feedback, NOT
    GroundingGuardrail's regeneration feedback.
"""

import json
import uuid
from unittest.mock import MagicMock

import respx

from soprano_sdk.agents.adaptor import AgentAdapter
from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult, GuardrailViolationError

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_text_response,
    make_tool,
)

# Distinctive substrings from each guardrail's regeneration_feedback.
# Used to assert which guardrail's feedback reached the LLM retry call.
STRUCTURED_OUTPUT_FEEDBACK_MARKER = "empty or incomplete"           # StructuredOutputGuardrail
GROUNDING_FEEDBACK_MARKER = "not supported by"                      # GroundingGuardrail

# A plain-text (non-JSON) follow-up response that StructuredOutputGuardrail
# will reject because it cannot be parsed as a dict.
PLAIN_TEXT_FOLLOW_UP = "Sure, I can help you with that!"


@respx.mock
def test_structured_output_guardrail_feedback_sent_when_grounding_disabled():
    """When grounding_check is disabled and StructuredOutputGuardrail fires in
    follow-up, the retry must inject StructuredOutputGuardrail's regeneration
    feedback — not the GroundingGuardrail's feedback that sits at index 0 in
    the unfiltered guardrail list.

    LLM call sequence
    -----------------
    LLM#1  collector prompt           → asks for field_a
    LLM#2  collector captures value   → follow-up is entered
    LLM#3  follow-up 1st attempt      → plain text (StructuredOutputGuardrail fires, retry queued)
    LLM#4  follow-up retry            → valid JSON (guardrail passes, self-loop interrupt)

    The test inspects the messages array of LLM#4 to verify the injected
    regeneration feedback is from StructuredOutputGuardrail.
    """
    captured_requests: list = []

    def _capture(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please provide field_a."),    # LLM#1
        collector_capture("some_value"),                # LLM#2
        llm_text_response(PLAIN_TEXT_FOLLOW_UP),        # LLM#3 — triggers StructuredOutputGuardrail
        fu_answer("Here is your answer."),              # LLM#4 — retry succeeds
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("follow_up_disabled_grounding_guardrail.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                          # T1 → LLM#1
    tool.execute(thread_id=tid, user_message="some_value", initial_context={})  # T2 → LLM#2
    tool.execute(thread_id=tid, user_message="tell me something", initial_context={})  # T3 → LLM#3 + LLM#4 (retry)

    # LLM#3 triggers a retry — total 4 HTTP calls expected.
    assert len(captured_requests) == 4, (
        f"Expected exactly 4 LLM calls (2 collector + 1 failed follow-up + 1 retry) "
        f"but got {len(captured_requests)}. "
        f"If only 3 calls were made the StructuredOutputGuardrail did not retry, "
        f"meaning the guardrail may not have fired at all."
    )

    # Parse the retry request (LLM#4, index 3).
    retry_req_body = json.loads(captured_requests[3].content)
    retry_messages = retry_req_body.get("messages", [])

    # The regeneration feedback is injected as the last user message before
    # the retry call.  Walk back through the messages to find it.
    user_messages = [m for m in retry_messages if m.get("role") == "user"]
    assert user_messages, "No user messages found in the LLM#4 retry request."
    last_user_content = user_messages[-1].get("content", "")

    # --- Core assertion: correct guardrail feedback was injected ---
    assert STRUCTURED_OUTPUT_FEEDBACK_MARKER in last_user_content, (
        f"Expected the retry message to contain StructuredOutputGuardrail's "
        f"regeneration feedback ('{STRUCTURED_OUTPUT_FEEDBACK_MARKER}') but it did not.\n"
        f"Actual last user message: {last_user_content!r}\n"
        f"This means the wrong guardrail's feedback was used — likely the "
        f"GroundingGuardrail at index 0 in the unfiltered self.guardrails list."
    )

    assert GROUNDING_FEEDBACK_MARKER not in last_user_content, (
        f"The retry message must NOT contain GroundingGuardrail's "
        f"regeneration feedback ('{GROUNDING_FEEDBACK_MARKER}') — that guardrail "
        f"is disabled and should play no part in retry logic.\n"
        f"Actual last user message: {last_user_content!r}\n"
        f"Root cause: failed_idx from the filtered results list was used to index "
        f"into the unfiltered self.guardrails, picking GroundingGuardrail instead "
        f"of StructuredOutputGuardrail."
    )


# ---------------------------------------------------------------------------
# Unit-level tests — _run_guardrails with injected mock guardrails
# These exercise edge cases that are hard to drive through full integration
# tests (all disabled, multiple retries, etc.).
# ---------------------------------------------------------------------------

class _TestAdapter(AgentAdapter):
    """Minimal concrete AgentAdapter for unit-testing _run_guardrails."""

    def __init__(self):
        super().__init__()
        self._call_count = 0
        self._responses: list = []

    def invoke(self, messages):
        return {}

    def _call_agent(self, messages):
        resp = self._responses[self._call_count] if self._call_count < len(self._responses) else "fallback"
        self._call_count += 1
        return resp


def _make_guardrail(
    feedback: str,
    pass_on_attempt: int = 0,
    max_retries: int = 1,
    is_enabled: bool = True,
) -> BaseGuardrail:
    """
    Build a mock BaseGuardrail.

    ``pass_on_attempt`` controls which call (0-indexed) first returns passed=True.
    Before that attempt the guardrail returns passed=False.
    """
    g = MagicMock(spec=BaseGuardrail)
    g.is_enabled = is_enabled
    g.max_retries = max_retries
    g.error_message = "mock error"
    g.regeneration_feedback = feedback

    call_count = {"n": 0}

    def _check(response, **kwargs):
        passed = call_count["n"] >= pass_on_attempt
        result = GuardrailResult(
            passed=passed,
            error_message=None if passed else g.error_message,
        )
        call_count["n"] += 1
        return result

    g.check.side_effect = _check
    return g


class TestRunGuardrailsAllDisabled:
    """When every guardrail in the list is disabled, _run_guardrails must
    return the original response immediately without calling _call_agent."""

    def test_returns_response_immediately(self):
        adapter = _TestAdapter()
        g1 = _make_guardrail("feedback A", is_enabled=False)
        g2 = _make_guardrail("feedback B", is_enabled=False)
        adapter.guardrails = [g1, g2]

        result = adapter._run_guardrails("my response", [])

        assert result == "my response"
        assert adapter._call_count == 0, "No LLM retry should have been made"
        g1.check.assert_not_called()
        g2.check.assert_not_called()

    def test_empty_guardrail_list(self):
        adapter = _TestAdapter()
        adapter.guardrails = []
        result = adapter._run_guardrails("any response", [])
        assert result == "any response"


class TestRunGuardrailsDisabledInMiddle:
    """Guardrail list: [enabled-A, disabled-B, enabled-C].
    If enabled-C fires, the retry message must contain C's feedback, not B's.
    """

    def test_correct_feedback_when_first_enabled_passes_and_second_enabled_fires(self):
        adapter = _TestAdapter()
        adapter._responses = ["final good response"]

        g_enabled_first = _make_guardrail("FEEDBACK_FIRST_ENABLED", pass_on_attempt=0)  # always passes
        g_disabled_middle = _make_guardrail("FEEDBACK_DISABLED_MIDDLE", is_enabled=False)
        g_enabled_last = _make_guardrail("FEEDBACK_LAST_ENABLED", pass_on_attempt=1)  # fails first, then passes

        adapter.guardrails = [g_enabled_first, g_disabled_middle, g_enabled_last]

        messages = [{"role": "user", "content": "hello"}]
        adapter._run_guardrails("bad response", messages)

        # The retry user message must contain the last enabled guardrail's feedback
        retry_messages = messages
        user_contents = [m["content"] for m in retry_messages if m.get("role") == "user"]
        assert any("FEEDBACK_LAST_ENABLED" in c for c in user_contents), (
            f"Expected FEEDBACK_LAST_ENABLED in retry messages. Got: {user_contents}"
        )
        assert not any("FEEDBACK_DISABLED_MIDDLE" in c for c in user_contents), (
            f"FEEDBACK_DISABLED_MIDDLE must never appear. Got: {user_contents}"
        )

    def test_disabled_guardrail_check_never_called(self):
        adapter = _TestAdapter()
        adapter._responses = ["retry response"]

        g_pass = _make_guardrail("PASS_FEEDBACK", pass_on_attempt=0)
        g_disabled = _make_guardrail("DISABLED_FEEDBACK", is_enabled=False)
        g_fail_then_pass = _make_guardrail("FAIL_FEEDBACK", pass_on_attempt=1)

        adapter.guardrails = [g_pass, g_disabled, g_fail_then_pass]
        adapter._run_guardrails("response", [])

        g_disabled.check.assert_not_called()


class TestRunGuardrailsMultipleRetries:
    """A guardrail with max_retries=2 that fails twice then succeeds on the
    third attempt should cause exactly 2 extra _call_agent invocations."""

    def test_two_retries_then_success(self):
        adapter = _TestAdapter()
        adapter._responses = ["retry1", "retry2"]

        # Fails on attempt 0 and 1, passes on attempt 2
        g = _make_guardrail("RETRY_FEEDBACK", pass_on_attempt=2, max_retries=2)
        adapter.guardrails = [g]

        result = adapter._run_guardrails("initial bad", [{"role": "user", "content": "q"}])

        # _call_agent called twice (once per retry)
        assert adapter._call_count == 2, (
            f"Expected 2 retries but _call_agent was called {adapter._call_count} times"
        )
        assert result == "retry2"

    def test_retries_exhausted_raises_violation_error(self):
        import pytest
        adapter = _TestAdapter()
        adapter._responses = ["retry1"]

        # Always fails, max_retries=1 → exactly 1 retry, then raises
        g = _make_guardrail("ALWAYS_FAIL_FEEDBACK", pass_on_attempt=999, max_retries=1)
        g.error_message = "hard failure message"
        adapter.guardrails = [g]

        with pytest.raises(GuardrailViolationError) as exc_info:
            adapter._run_guardrails("bad response", [])

        assert "hard failure message" in exc_info.value.error_message
