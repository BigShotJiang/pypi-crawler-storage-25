import uuid
import respx
import json
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    fu_answer,
    make_tool,
    llm_structured_response,
)

@respx.mock
def test_follow_up_summary_injection_and_persistence():
    """Verify that conversation_summary is injected into the follow-up prompt
    but not persisted in the conversation history.
    """
    summary_text = "User is looking for their savings account balance."
    responses = iter([
        llm_structured_response({"bot_response": "What is field A?", "field_a": None}),
        llm_structured_response({"field_a": "val_a"}),
        fu_answer("Your balance is $1000."),
        fu_answer("You're welcome!")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml") 
    tid = str(uuid.uuid4())

    # Turn 1
    tool.execute(thread_id=tid, initial_context={"conversation_summary": summary_text})
    
    # Turn 2
    tool.execute(thread_id=tid, user_message="val_a", initial_context={"conversation_summary": summary_text})
    
    # Turn 3
    tool.execute(thread_id=tid, user_message="Check balance", initial_context={"conversation_summary": summary_text})
    
    # Turn 4
    tool.execute(thread_id=tid, user_message="Check balance", initial_context={"conversation_summary": summary_text})
    
    # Find the follow-up call
    target_call = None
    for call in reversed(respx.calls):
        req_body = json.loads(call.request.content)
        msgs = req_body["messages"]
        if msgs[-1]["role"] == "user" and "Check balance" in msgs[-1]["content"]:
            target_call = call
            break
            
    assert target_call is not None, f"Could not find LLM call for 'Check balance'. Total calls: {len(respx.calls)}"
    req_body = json.loads(target_call.request.content)
    last_user_msg = req_body["messages"][-1]
    
    
    assert "CONTEXT SUMMARY" in last_user_msg["content"]
    assert summary_text in last_user_msg["content"]
