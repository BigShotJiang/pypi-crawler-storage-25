"""Tests for schema-aware JSON repair in soprano_sdk/utils/parser.py"""
from typing import Optional, List, Dict
from pydantic import BaseModel

from soprano_sdk.utils.parser import _repair_json_string, convert_to_dict


# ── Shared schemas ────────────────────────────────────────────────────────────

class SimpleSchema(BaseModel):
    reasoning: Optional[str] = None
    bot_response: Optional[str] = None
    status: Optional[str] = None


class MixedTypesSchema(BaseModel):
    reasoning: Optional[str] = None
    bot_response: Optional[str] = None
    is_safe: Optional[bool] = None
    count: Optional[int] = None
    score: Optional[float] = None


class FollowUpSchema(BaseModel):
    reasoning: Optional[str] = None
    bot_response: Optional[str] = None
    intent_change: Optional[str] = None
    out_of_scope: Optional[str] = None
    options: Optional[List[Dict]] = None
    is_selectable: Optional[bool] = None
    amount_of_payment: Optional[str] = None
    payment_date: Optional[str] = None
    is_latest_transaction_captured_from_list: Optional[bool] = None


# ── _repair_json_string ───────────────────────────────────────────────────────

class TestUnquotedStringValues:

    def test_single_unquoted_value(self):
        raw = '{"reasoning": A simple reason, "bot_response": "Hello"}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "A simple reason"
        assert parsed["bot_response"] == "Hello"

    def test_unquoted_value_containing_comma(self):
        """Value contains a comma — must not be truncated at the comma."""
        raw = '{"reasoning": The user said No, indicating refusal, "bot_response": "Ok"}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert "No" in parsed["reasoning"]
        assert "indicating refusal" in parsed["reasoning"]
        assert parsed["bot_response"] == "Ok"

    def test_unquoted_value_with_single_quotes(self):
        """Single quotes inside unquoted value are preserved."""
        raw = '{"reasoning": User replied \'No\', "bot_response": "Noted"}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert "No" in parsed["reasoning"]

    def test_multiple_unquoted_values(self):
        raw = '{"reasoning": Some reason here, "bot_response": A bot reply here}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "Some reason here"
        assert parsed["bot_response"] == "A bot reply here"

    def test_unquoted_value_at_end_of_object(self):
        """Unquoted value is the last field — terminated by }."""
        raw = '{"reasoning": "fine", "bot_response": A reply with no closing quote}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["bot_response"] == "A reply with no closing quote"

    def test_multiline_unquoted_value(self):
        """Unquoted value spanning multiple words with newline before next key."""
        raw = '{\n  "reasoning": The user responded with No, indicating they did not select any transaction from the list provided. This means no valid transaction was chosen.\n  "bot_response": "Thank you"\n}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert "No" in parsed["reasoning"]
        assert "no valid transaction" in parsed["reasoning"]
        assert parsed["bot_response"] == "Thank you"


class TestMissingCommas:

    def test_missing_comma_between_string_fields(self):
        raw = '{\n  "reasoning": "A reason"\n  "bot_response": "Hello"\n}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "A reason"
        assert parsed["bot_response"] == "Hello"

    def test_missing_comma_after_unquoted_value(self):
        """The exact real-world case: unquoted reasoning + missing comma."""
        raw = (
            '{\n'
            '  "reasoning": The user responded with \'No\', indicating they did not select any transaction.\n'
            '  "bot_response": "Thank you for confirming."\n'
            '}'
        )
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert "No" in parsed["reasoning"]
        assert parsed["bot_response"] == "Thank you for confirming."

    def test_missing_comma_after_boolean(self):
        raw = '{\n  "is_safe": true\n  "bot_response": "Hello"\n}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["is_safe"] is True
        assert parsed["bot_response"] == "Hello"

    def test_missing_comma_after_null(self):
        raw = '{\n  "reasoning": null\n  "bot_response": "Hi"\n}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] is None
        assert parsed["bot_response"] == "Hi"

    def test_missing_comma_after_number(self):
        raw = '{\n  "count": 42\n  "bot_response": "Done"\n}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["count"] == 42
        assert parsed["bot_response"] == "Done"


class TestSchemaGuidedRepair:

    def test_boolean_true_stays_boolean_for_bool_field(self):
        raw = '{"is_safe": true, "bot_response": "Hi"}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["is_safe"] is True

    def test_boolean_true_gets_quoted_for_str_field(self):
        """'true' for a str-typed field should become the string "true"."""
        raw = '{"reasoning": true, "bot_response": "Hi"}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "true"

    def test_boolean_false_gets_quoted_for_str_field(self):
        raw = '{"reasoning": false, "bot_response": "Hi"}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "false"

    def test_null_never_quoted_even_for_str_field(self):
        """null is always valid for Optional fields — must never be quoted as "null"."""
        raw = '{"reasoning": null, "bot_response": "Hi"}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] is None
        assert parsed["bot_response"] == "Hi"

    def test_number_gets_quoted_for_str_field(self):
        """A numeric value for a str-typed field should be wrapped in quotes."""

        class StrSchema(BaseModel):
            code: Optional[str] = None

        raw = '{"code": 12345}'
        result = _repair_json_string(raw, StrSchema)
        parsed = __import__('json').loads(result)
        assert parsed["code"] == "12345"

    def test_number_stays_number_for_int_field(self):
        raw = '{"count": 7, "bot_response": "Done"}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["count"] == 7

    def test_no_schema_leaves_keywords_alone(self):
        """Without a schema, true/false/null are left as-is."""
        raw = '{"is_safe": true, "reasoning": false}'
        result = _repair_json_string(raw, schema=None)
        parsed = __import__('json').loads(result)
        assert parsed["is_safe"] is True
        assert parsed["reasoning"] is False


class TestRealWorldLLMOutputs:

    def test_exact_failing_example_from_issue(self):
        """The exact JSON that was failing in production."""
        raw = """{
  "reasoning": The user responded with 'No', indicating they did not select any transaction from the list provided. This means no valid transaction was chosen.
  "bot_response": "Thank you for confirming. Since none of the listed transactions match your payment, we'll need to explore other options. Would you like to provide more details about your payment or check for transactions on a different date?",
  "intent_change": null,
  "out_of_scope": null,
  "options": [],
  "is_selectable": false,
  "amount_of_payment": null,
  "payment_date": null,
  "is_latest_transaction_captured_from_list": false
}"""
        result = _repair_json_string(raw, FollowUpSchema)
        parsed = __import__('json').loads(result)
        assert "No" in parsed["reasoning"]
        assert "no valid transaction" in parsed["reasoning"]
        assert "Thank you for confirming" in parsed["bot_response"]
        assert parsed["intent_change"] is None
        assert parsed["out_of_scope"] is None
        assert parsed["options"] == []
        assert parsed["is_selectable"] is False
        assert parsed["amount_of_payment"] is None
        assert parsed["payment_date"] is None
        assert parsed["is_latest_transaction_captured_from_list"] is False

    def test_unquoted_reasoning_only(self):
        raw = '{"reasoning": A reason, "bot_response": "Bot Response"}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "A reason"
        assert parsed["bot_response"] == "Bot Response"

    def test_double_quote_inside_unquoted_value_escaped(self):
        """If the unquoted value itself contains a double quote, it should be escaped."""
        raw = '{"reasoning": User said "hello", "bot_response": "Ok"}'
        result = _repair_json_string(raw, SimpleSchema)
        parsed = __import__('json').loads(result)
        assert 'hello' in parsed["reasoning"]

    def test_already_valid_json_unchanged(self):
        raw = '{"reasoning": "All good", "bot_response": "Hello", "is_safe": true}'
        result = _repair_json_string(raw, MixedTypesSchema)
        parsed = __import__('json').loads(result)
        assert parsed["reasoning"] == "All good"
        assert parsed["bot_response"] == "Hello"
        assert parsed["is_safe"] is True

    def test_nested_object_value_untouched(self):
        """Nested object values should not be modified."""

        class NestedSchema(BaseModel):
            meta: Optional[dict] = None
            bot_response: Optional[str] = None

        raw = '{"meta": {"key": "val"}, "bot_response": "Hi"}'
        result = _repair_json_string(raw, NestedSchema)
        parsed = __import__('json').loads(result)
        assert parsed["meta"] == {"key": "val"}
        assert parsed["bot_response"] == "Hi"


# ── convert_to_dict ───────────────────────────────────────────────────────────

class TestConvertToDict:

    def test_already_a_dict(self):
        d = {"key": "value"}
        assert convert_to_dict(d) == d

    def test_valid_json_string(self):
        result = convert_to_dict('{"key": "value"}')
        assert result == {"key": "value"}

    def test_python_dict_syntax_single_quotes(self):
        result = convert_to_dict("{'key': 'value', 'num': 1}")
        assert result == {"key": "value", "num": 1}

    def test_python_dict_syntax_none(self):
        result = convert_to_dict("{'key': None}")
        assert result == {"key": None}

    def test_repair_fallback_with_schema(self):
        raw = '{"reasoning": An unquoted reason, "bot_response": "Hello"}'
        result = convert_to_dict(raw, schema=SimpleSchema)
        assert isinstance(result, dict)
        assert result["reasoning"] == "An unquoted reason"
        assert result["bot_response"] == "Hello"

    def test_repair_skipped_without_schema(self):
        """Without a schema, repair is skipped and raw string returned on failure."""
        raw = '{"reasoning": An unquoted reason, "bot_response": "Hello"}'
        result = convert_to_dict(raw, schema=None)
        # ast.literal_eval will also fail, so it returns the raw string
        assert isinstance(result, str)

    def test_json_wrapped_in_extra_text(self):
        """Extracts JSON block from surrounding text."""
        raw = 'Here is the result: {"key": "value"} done.'
        result = convert_to_dict(raw)
        assert result == {"key": "value"}

    def test_real_world_production_failure(self):
        """Full convert_to_dict path for the exact production failure case."""
        raw = """{
  "reasoning": The user responded with 'No', indicating they did not select any transaction.
  "bot_response": "Thank you for confirming.",
  "intent_change": null,
  "is_selectable": false
}"""
        result = convert_to_dict(raw, schema=FollowUpSchema)
        assert isinstance(result, dict)
        assert "No" in result["reasoning"]
        assert result["bot_response"] == "Thank you for confirming."
        assert result["intent_change"] is None
        assert result["is_selectable"] is False
