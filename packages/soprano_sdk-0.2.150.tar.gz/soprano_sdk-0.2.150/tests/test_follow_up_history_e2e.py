import json
import uuid
import respx
from soprano_sdk.core.constants import WorkflowKeys, InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    make_tool,
    collector_prompt,
    collector_capture,
    fu_answer,
    fu_intent_change
)

@respx.mock
def test_follow_up_to_collector_rollback_preserves_history_e2e():
    """Verify E2E that when a follow-up node triggers a rollback (intent_change),
    the target collector node can retrieve the triggering user query from the 
    follow-up node's conversation history.
    """
    tid = str(uuid.uuid4())
    tool = make_tool("follow_up_two_step.yaml")
    
    # Define LLM responses for the flow
    # 1. CollectorA prompt
    # 2. CollectorB prompt (after A captures)
    # 3. Follow-up prompt (after B captures)
    # 4. CollectorA prompt (after Follow-up rollback)
    
    ROLLBACK_QUERY = "Wait, I want to change field A to something else"
    
    responses = iter([
        collector_prompt("Please provide field A."),               # LLM#1: CollectorA initial
        collector_capture("val_a"),                                # LLM#2: CollectorA capture val_a
        collector_prompt("Please provide field B."),               # LLM#3: CollectorB initial
        collector_capture("val_b"),                                # LLM#4: CollectorB capture val_b
        fu_intent_change("collect_a", ROLLBACK_QUERY),             # LLM#5: Follow-up triggers rollback to collect_a
        collector_prompt("Ok, what is the new value for field A?") # LLM#6: CollectorA after rollback
    ])
    
    captured_requests = []
    def side_effect(req):
        captured_requests.append(req)
        return next(responses)
        
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=side_effect)
    
    # Step 1: Start workflow -> CollectorA prompt
    res1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please provide field A." in str(res1)
    
    # Step 2: Provide val_a -> CollectorB prompt
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    assert "Please provide field B." in str(res2)
    
    # Step 3: Provide val_b -> FollowUp interrupt
    res3 = tool.execute(thread_id=tid, user_message="val_b", initial_context={})
    assert InterruptType.FOLLOW_UP in str(res3)
    
    # Step 4: Provide rollback query to FollowUp -> CollectorA prompt (resumption)
    # This is the critical step: Follow-up will trigger intent_change="collect_a"
    # Then collect_a.execute will call _generate_prompt, which should see ROLLBACK_QUERY in history.
    tool.execute(thread_id=tid, user_message=ROLLBACK_QUERY, initial_context={})
    
    # Verify that CollectorA was called again (LLM#6)
    assert len(captured_requests) >= 6
    
    # Inspect the 6th request (CollectorA after rollback)
    last_req_body = json.loads(captured_requests[5].content)
    last_user_msg = last_req_body["messages"][-1]["content"]
    
    # If our fix is working, CollectorA should have found ROLLBACK_QUERY in history
    # and enhanced the user message with the system_note because user_msg == last_user_msg.
    assert "system_note" in last_user_msg
    assert ROLLBACK_QUERY in last_user_msg
    assert "The user query is already utilized in a previous" in last_user_msg

@respx.mock
def test_follow_up_multi_turn_qa_perserves_history_e2e():
    """Verify E2E that regular multi-turn Q&A in the follow-up node
    correctly preserves conversation history in the state.
    """
    tid = str(uuid.uuid4())
    tool = make_tool("follow_up_two_step.yaml")
    
    responses = iter([
        collector_prompt("Please provide field A."),               # LLM#1: CollectorA initial
        collector_capture("val_a"),                                # LLM#2: CollectorA capture val_a
        collector_prompt("Please provide field B."),               # LLM#3: CollectorB initial
        collector_capture("val_b"),                                # LLM#4: CollectorB capture val_b
        fu_answer("I can help with that. What else?"),            # LLM#5: Follow-up answer Q1
        fu_answer("Got it! Anything else?"),                       # LLM#6: Follow-up answer Q2
    ])
    
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    # 1. Reach follow-up
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    res3 = tool.execute(thread_id=tid, user_message="val_b", initial_context={})
    assert InterruptType.FOLLOW_UP in str(res3)
    
    # 2. First follow-up question
    res4 = tool.execute(thread_id=tid, user_message="How do I do X?", initial_context={})
    assert "I can help with that" in str(res4)
    
    # 3. Second follow-up question
    res5 = tool.execute(thread_id=tid, user_message="And Y?", initial_context={})
    assert "Got it! Anything else?" in str(res5)
    
    # 4. Inspect state to ensure all turns are in history
    final_state = tool.graph.get_state({"configurable": {"thread_id": tid}}).values
    conv_key = f"{tool.engine.follow_up_node_id}_conversation"
    history = final_state[WorkflowKeys.CONVERSATIONS][conv_key]
    
    # Expected turns: 
    # 1. Assistant: Success message (from entry)
    # 2. User: How do I do X?
    # 3. Assistant: I can help with that...
    # 4. User: And Y?
    # 5. Assistant: Got it! Anything else?
    
    assert len(history) >= 5
    assert history[1]["content"] == "How do I do X?"
    assert history[3]["content"] == "And Y?"

@respx.mock
def test_follow_up_sequential_rollback_history_e2e():
    """Verify E2E that in a sequence A -> B -> Follow-up -> A -> B,
    the final B correctly identifies the follow-up rollback query
    as the last user message, even after A has 'consumed' it.
    """
    tid = str(uuid.uuid4())
    tool = make_tool("follow_up_two_step.yaml")
    
    # We want:
    # 1. CollectorA: provide A1
    # 2. CollectorB: provide B1
    # 3. Follow-up: provide "rollback to collector_a with value A2"
    # 4. CollectorA: should capture A2 automatically and transition to B
    # 5. CollectorB: should see "rollback to collector_a with value A2" as last query
    
    responses = iter([
        collector_prompt("Please provide field A."),               # LLM#1: CollectorA initial
        collector_capture("val_a1"),                               # LLM#2: CollectorA capture val_a1
        collector_prompt("Please provide field B."),               # LLM#3: CollectorB initial
        collector_capture("val_b1"),                               # LLM#4: CollectorB capture val_b1
        fu_intent_change("collect_a", "I want to change A to val_a2"),# LLM#5: Follow-up rollback
        collector_capture("val_a2"),                               # LLM#6: CollectorA capture val_a2 (after rollback)
        collector_prompt("Please provide field B (again)."),       # LLM#7: CollectorB initial (after A->B transition)
    ])
    
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    # 1. Reach follow-up
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a1", initial_context={})
    res3 = tool.execute(thread_id=tid, user_message="val_b1", initial_context={})
    assert InterruptType.FOLLOW_UP in str(res3)
    
    # 2. Trigger rollback
    ROLLBACK_QUERY = "I want to change A to val_a2"
    res4 = tool.execute(thread_id=tid, user_message=ROLLBACK_QUERY, initial_context={})
    
    # After rollback to A:
    # A executes, captures val_a2, transitions to B.
    # B executes, generates prompt.
    
    assert "Please provide field B (again)" in str(res4)
    
    # Check the history seen by the LAST LLM call (CollectorB)
    # The last request sent to the mock LLM should contain the prompt for CollectorB.
    # We want to verify that this prompt contains the system_note for ROLLBACK_QUERY.
    
    # Get last request's body
    last_req = respx.calls.last.request
    last_body = json.loads(last_req.content.decode())
    last_msg = last_body["messages"][-1]["content"]
    
    assert "system_note" in last_msg
    assert ROLLBACK_QUERY in last_msg
    assert "The user query is already utilized in a previous" in last_msg

