from unittest.mock import MagicMock
from soprano_sdk.core.localization import LocalizationRule, LocalizationManager
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.core.constants import WorkflowKeys

class TestLocalizationRuleFields:
    def test_default_display_fields(self):
        """Verify that display_language and display_script default to language and script."""
        rule = LocalizationRule(language="fr", script="latin")
        assert rule.display_language == "fr"
        assert rule.display_script == "latin"

    def test_explicit_display_fields(self):
        """Verify that explicit display_language and display_script are respected."""
        rule = LocalizationRule(
            language="hi", 
            script="latin", 
            display_language="Hindi", 
            display_script="Hinglish (Latin)"
        )
        assert rule.display_language == "Hindi"
        assert rule.display_script == "Hinglish (Latin)"

class TestLocalizationManagerEnforcement:
    def test_registry_rules_have_correct_display_names(self):
        """Verify that the default registry rules have reasonable display names."""
        manager = LocalizationManager()
        
        # Hindi Devanagari
        hi_dev = manager.get_rule("hi", "devanagari")
        assert hi_dev.display_language == "Hindi"
        assert hi_dev.display_script == "Devanagari"
        
        # Hindi Latin
        hi_lat = manager.get_rule("hi", "latin")
        assert hi_lat.display_language == "Hindi"
        assert hi_lat.display_script == "Latin"
        
        # English
        en_lat = manager.get_rule("en", "latin")
        assert en_lat.display_language == "English"
        assert en_lat.display_script == "Latin"

class TestCollectInputEnforcementPrompt:
    def test_system_prompt_includes_language_enforcement(self):
        """Verify that CollectInputStrategy injects the Language/Script enforcement block."""
        engine_context = MagicMock()
        
        # Mock localization rule
        mock_rule = LocalizationRule(
            language="hi",
            script="devanagari",
            display_language="Hindi",
            display_script="Devanagari",
            instructions="HINDI RULES",
            examples="HINDI EXAMPLES",
            wait_phrases=["ruko"]
        )
        engine_context.get_localization_rule.return_value = mock_rule
        engine_context.get_localization_wait_phrases.return_value = ["ruko", "wait"]
        engine_context.get_base_localization_instructions.return_value = "BASE LOCALIZATION"
        
        # Mock other dependencies for CollectInputStrategy.__init__
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "max_retry_limit": 3,
            "rollback_strategy": "history_based"
        }.get(key, default)
        engine_context.workflow_description = "Test Workflow"
        engine_context.mfa_validator_steps = set()
        
        step_config = {
            "id": "test_node",
            "field": "test_field",
            "agent": {
                "name": "TestAgent",
                "instructions": "Collect the field"
            }
        }
        
        strategy = CollectInputStrategy(step_config, engine_context)
        state = {
            WorkflowKeys.NODE_EXECUTION_ORDER: [],
            WorkflowKeys.NODE_FIELD_MAP: {},
            WorkflowKeys.CONVERSATIONS: {}
        }
        
        instructions = strategy._get_instructions(state, {})
        
        # Verify the enforcement section
        assert "Language: Hindi" in instructions
        assert "Script: Devanagari" in instructions
        assert "All user-facing messages MUST be in **Hindi** using **Devanagari** script only." in instructions
        
        # Verify it's inside BOT RESPONSE RULES
        assert "BOT RESPONSE RULES:" in instructions
        
        # Verify wait phrases are present
        assert '"ruko", "wait"' in instructions

    def test_system_prompt_language_enforcement_with_custom_rules(self):
        """Verify that custom bot_response_rules still include lang_enforcement."""
        engine_context = MagicMock()
        mock_rule = LocalizationRule(
            language="hi",
            script="latin",
            display_language="Hinglish",
            display_script="Latin"
        )
        engine_context.get_localization_rule.return_value = mock_rule
        engine_context.get_localization_wait_phrases.return_value = []
        engine_context.get_base_localization_instructions.return_value = ""
        engine_context.get_config_value.return_value = "history_based"
        engine_context.workflow_description = "Test"
        engine_context.mfa_validator_steps = set()
        
        step_config = {
            "id": "test_node",
            "field": "test_field",
            "agent": {
                "instructions": "Collect",
                "bot_response_rules": "CUSTOM RULES HERE"
            }
        }
        
        strategy = CollectInputStrategy(step_config, engine_context)
        # Mock _render_template_string to return inputs as is
        strategy._render_template_string = lambda s, st: s
        
        instructions = strategy._get_instructions({}, {})
        
        assert "Language: Hinglish" in instructions
        assert "Script: Latin" in instructions
        assert "CUSTOM RULES HERE" in instructions
        assert "BOT RESPONSE RULES:" in instructions
