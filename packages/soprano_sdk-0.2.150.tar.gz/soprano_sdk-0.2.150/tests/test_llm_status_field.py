"""Tests for the `status` field and related changes.

Current state:
  - `FollowUpOutput` HAS a `status` field: Literal["collecting", "success", "failed"].
    It appears after `bot_response` so the LLM classifies its reply after composing it.
  - `create_structured_output_model` also injects `status` (after `bot_response`) for collect_input nodes.
  - `WorkflowKeys.LLM_STATUS` constant exists.
  - `status` is persisted to `state[WorkflowKeys.LLM_STATUS]` by both collect_input and follow_up nodes.
  - `_build_conversation_entry` (follow_up) does NOT serialise `status`.
  - `_get_continuation_prompt` reads "bot_response" then falls back to "text".
  - `_to_llm_messages` (follow_up) unwraps "bot_response" or "text".
  - `_get_last_interrupt_payload` (follow_up) backward compat.
  - Humanization system prompt contains PRIORITY ORDER section.
"""

import json
import uuid

import respx

from soprano_sdk.agents.structured_output import (
    FollowUpOutput,
    create_structured_output_model,
)
from soprano_sdk.core.constants import WorkflowKeys

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    make_tool,
    snap,
)


# ── Helper responses ───────────────────────────────────────────────────────────

def fu_answer_with_status(text: str, status: str):
    """Follow-up LLM returns a Q&A answer with a `status` flag."""
    return llm_structured_response({
        "bot_response": text,
        "status": status,
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": None,
        "restart": None,
    })


def collector_with_status(field_value, status: str):
    """Collector LLM: captures a field AND returns a status flag."""
    return llm_structured_response({"bot_response": None, "field_a": field_value, "status": status})


def collector_prompt_with_status(text: str, status: str):
    """Collector LLM: asks a question AND returns a status flag."""
    return llm_structured_response({"bot_response": text, "field_a": None, "status": status})


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Unit tests — FollowUpOutput model (status field present, after bot_response)
# ═══════════════════════════════════════════════════════════════════════════════

class TestFollowUpOutputStatusField:
    """FollowUpOutput does not expose a `status` field — status is only tracked
    by collect_input nodes, not follow-up nodes."""

    def test_status_field_not_present(self):
        output = FollowUpOutput(bot_response="Hello")
        assert not hasattr(output, "status"), (
            "FollowUpOutput must NOT have a 'status' field"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Unit tests — create_structured_output_model injects `status`
# ═══════════════════════════════════════════════════════════════════════════════

class TestCreateStructuredOutputModelStatus:
    """Dynamic models built by create_structured_output_model must include `status`
    (collect_input nodes still use it)."""

    def test_status_field_present_in_generated_model(self):
        fields = [{"name": "order_id", "type": "text", "description": "Order ID"}]
        Model = create_structured_output_model(fields)
        instance = Model(order_id="ORD-123")
        assert hasattr(instance, "status")
        assert instance.status == "collecting"

    def test_status_success_accepted_in_generated_model(self):
        fields = [{"name": "amount", "type": "number", "description": "Amount"}]
        Model = create_structured_output_model(fields)
        instance = Model(amount=100, status="success")
        assert instance.status == "success"

    def test_status_failed_accepted_in_generated_model(self):
        fields = [{"name": "amount", "type": "number", "description": "Amount"}]
        Model = create_structured_output_model(fields)
        instance = Model(amount=100, status="failed")
        assert instance.status == "failed"

    def test_status_field_in_model_dump(self):
        fields = [{"name": "val", "type": "text", "description": "Some value"}]
        Model = create_structured_output_model(fields)
        instance = Model(val="x", status="success")
        d = instance.model_dump()
        assert "status" in d
        assert d["status"] == "success"

    def test_needs_intent_change_still_has_status(self):
        fields = [{"name": "choice", "type": "text", "description": "Choice"}]
        Model = create_structured_output_model(fields, intent_change_nodes=["some_node"])
        instance = Model(status="failed")
        assert instance.status == "failed"
        assert hasattr(instance, "intent_change")


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Unit tests — WorkflowKeys constant
# ═══════════════════════════════════════════════════════════════════════════════

class TestWorkflowKeysLLMStatus:
    def test_llm_status_key_value(self):
        assert WorkflowKeys.LLM_STATUS == "_llm_status"

    def test_llm_status_is_str(self):
        assert isinstance(WorkflowKeys.LLM_STATUS, str)


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Unit tests — _build_conversation_entry (FollowUpNode) without status
# ═══════════════════════════════════════════════════════════════════════════════

def _make_follow_up_strategy(yaml_name="follow_up_single_step.yaml"):
    """Instantiate a FollowUpStrategy directly from an engine built from yaml_name."""
    from soprano_sdk.nodes.follow_up import FollowUpStrategy
    tool = make_tool(yaml_name)
    engine = tool.engine
    return FollowUpStrategy(
        follow_up_config=engine.follow_up_config,
        engine_context=engine,
        first_step_id=engine.steps[0]['id'],
        node_id=engine.follow_up_node_id,
    )


def _make_collect_input_strategy(yaml_name="collect_input_structured_output.yaml"):
    """Instantiate a CollectInputStrategy directly from an engine built from yaml_name."""
    from soprano_sdk.nodes.collect_input import CollectInputStrategy
    tool = make_tool(yaml_name)
    engine = tool.engine
    return CollectInputStrategy(step_config=engine.steps[0], engine_context=engine)


class TestBuildConversationEntryStatus:
    """_build_conversation_entry no longer serialises status — it was removed from
    the follow-up node. Only bot_response/options/is_selectable are serialised."""

    def _make_node(self):
        return _make_follow_up_strategy()

    def test_with_options_serialises_bot_response_without_status(self):
        node = self._make_node()
        entry = node._build_conversation_entry(
            role="assistant", content="Action performed",
            options=[{"text": "Yes"}], is_selectable=True,
        )
        parsed = json.loads(entry["content"])
        assert parsed["bot_response"] == "Action performed"
        assert "status" not in parsed

    def test_no_options_gives_plain_string(self):
        node = self._make_node()
        entry = node._build_conversation_entry(
            role="assistant", content="Just a message",
        )
        assert entry["content"] == "Just a message"

    def test_with_options_does_not_include_status_key(self):
        node = self._make_node()
        entry = node._build_conversation_entry(
            role="assistant",
            content="Pick one",
            options=[{"text": "Yes", "subtext": ""}],
            is_selectable=True,
        )
        parsed = json.loads(entry["content"])
        assert "bot_response" in parsed
        assert "status" not in parsed

    def test_plain_content_no_options_returns_plain_string(self):
        node = self._make_node()
        entry = node._build_conversation_entry(
            role="assistant", content="Hello",
        )
        assert entry["content"] == "Hello"
        # Must NOT be JSON
        try:
            json.loads(entry["content"])
            assert False, "Should not be JSON for plain text with no options"
        except (json.JSONDecodeError, ValueError):
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Unit tests — _to_llm_messages backward compatibility (follow_up)
# ═══════════════════════════════════════════════════════════════════════════════

class TestToLlmMessagesBackwardCompat:
    """_to_llm_messages must unwrap both old 'text' and new 'bot_response' keys."""

    def _get_node(self):
        return _make_follow_up_strategy()

    def test_old_text_key_unwrapped(self):
        node = self._get_node()
        old_format = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": json.dumps({"text": "Old message", "options": None, "is_selectable": None})},
            {"role": "user", "content": "Follow up"},
        ]
        result = node._to_llm_messages(old_format)
        assistant_msgs = [m for m in result if m["role"] == "assistant"]
        assert len(assistant_msgs) == 1
        assert assistant_msgs[0]["content"] == "Old message"

    def test_new_bot_response_key_unwrapped(self):
        node = self._get_node()
        new_format = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": json.dumps({"bot_response": "New message", "options": None, "is_selectable": None})},
            {"role": "user", "content": "Follow up"},
        ]
        result = node._to_llm_messages(new_format)
        assistant_msgs = [m for m in result if m["role"] == "assistant"]
        assert len(assistant_msgs) == 1
        assert assistant_msgs[0]["content"] == "New message"

    def test_both_keys_prefers_bot_response(self):
        node = self._get_node()
        mixed = [
            {"role": "user", "content": "Q"},
            {"role": "assistant", "content": json.dumps({"bot_response": "new_val", "text": "old_val"})},
            {"role": "user", "content": "More"},
        ]
        result = node._to_llm_messages(mixed)
        assistant_msgs = [m for m in result if m["role"] == "assistant"]
        assert assistant_msgs[0]["content"] == "new_val"

    def test_status_field_in_json_does_not_leak_into_llm_content(self):
        node = self._get_node()
        conv = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": json.dumps({
                "bot_response": "Sure thing",
                "status": "success",
                "options": None,
                "is_selectable": None,
            })},
            {"role": "user", "content": "Thanks"},
        ]
        result = node._to_llm_messages(conv)
        assistant_msgs = [m for m in result if m["role"] == "assistant"]
        assert assistant_msgs[0]["content"] == "Sure thing"
        assert "status" not in assistant_msgs[0]["content"]


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Unit tests — _get_last_interrupt_payload backward compatibility
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetLastInterruptPayloadBackwardCompat:
    """_get_last_interrupt_payload must parse both 'text' and 'bot_response' keys."""

    def _get_node(self):
        return _make_follow_up_strategy()

    def test_old_text_key_extracted(self):
        node = self._get_node()
        conv = [
            {"role": "assistant", "content": json.dumps({"text": "Old prompt", "options": None, "is_selectable": None})}
        ]
        payload = node._get_last_interrupt_payload(conv)
        assert payload["text"] == "Old prompt"

    def test_new_bot_response_key_extracted(self):
        node = self._get_node()
        conv = [
            {"role": "assistant", "content": json.dumps({"bot_response": "New prompt", "options": None, "is_selectable": None})}
        ]
        payload = node._get_last_interrupt_payload(conv)
        assert payload["text"] == "New prompt"

    def test_plain_string_content_still_works(self):
        node = self._get_node()
        conv = [{"role": "assistant", "content": "Plain text response"}]
        payload = node._get_last_interrupt_payload(conv)
        assert payload["text"] == "Plain text response"


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Unit tests — _get_continuation_prompt backward compatibility (collect_input)
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetContinuationPromptBackwardCompat:
    """_get_continuation_prompt must read 'bot_response' first, fall back to 'text'."""

    def _get_node(self):
        return _make_collect_input_strategy()

    def test_old_text_key_returned_as_text(self):
        node = self._get_node()
        conv = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": json.dumps({
                "text": "Old style message",
                "options": None,
                "is_selectable": False,
            })},
        ]
        result = node._get_continuation_prompt(conv)
        assert result["text"] == "Old style message"

    def test_new_bot_response_key_returned_as_text(self):
        node = self._get_node()
        conv = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": json.dumps({
                "bot_response": "New style message",
                "options": None,
                "is_selectable": False,
            })},
        ]
        result = node._get_continuation_prompt(conv)
        assert result["text"] == "New style message"

    def test_bot_response_preferred_over_text_when_both_present(self):
        node = self._get_node()
        conv = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": json.dumps({
                "bot_response": "Preferred",
                "text": "Fallback",
                "options": None,
                "is_selectable": False,
            })},
        ]
        result = node._get_continuation_prompt(conv)
        assert result["text"] == "Preferred"

    def test_options_preserved_from_json(self):
        node = self._get_node()
        opts = [{"text": "Yes", "subtext": ""}]
        conv = [
            {"role": "user", "content": "Pick one"},
            {"role": "assistant", "content": json.dumps({
                "bot_response": "Choose:",
                "options": opts,
                "is_selectable": True,
            })},
        ]
        result = node._get_continuation_prompt(conv)
        assert result["options"] == opts
        assert result["is_selectable"] is True


# ═══════════════════════════════════════════════════════════════════════════════
# 8. Integration tests — _llm_status is updated by both collect_input and follow_up
# ═══════════════════════════════════════════════════════════════════════════════



@respx.mock
def test_follow_up_status_collecting_persisted_to_state():
    """After follow-up runs, _llm_status should reflect the collect_input status (success),
    not a status from FollowUpOutput (which no longer has a status field)."""
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Just chatting, no action."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="how are you?", initial_context={})

    s = snap(tool, tid)
    # FollowUpOutput no longer has a status field; _llm_status is set by collect_input
    assert s.get(WorkflowKeys.LLM_STATUS) is not None


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Integration tests — status persisted to state in collect_input node
# ═══════════════════════════════════════════════════════════════════════════════

@respx.mock
def test_collect_input_status_collecting_persisted_to_state():
    """When the collector LLM returns status='collecting' with a bot_response question,
    state['_llm_status'] must be 'collecting' after that turn."""
    responses = iter([
        collector_prompt_with_status("What is your name?", "collecting"),
        collector_capture("valid_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    s = snap(tool, tid)
    assert s.get(WorkflowKeys.LLM_STATUS) == "collecting", (
        f"Expected _llm_status='collecting' from collector, got: {s.get(WorkflowKeys.LLM_STATUS)}"
    )


@respx.mock
def test_collect_input_status_failed_persisted_to_state():
    """When the collector LLM returns status='failed' with a bot_response, state must record it."""
    responses = iter([
        collector_prompt_with_status("Could not process, please provide order ID again.", "failed"),
        collector_capture("valid_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    s = snap(tool, tid)
    assert s.get(WorkflowKeys.LLM_STATUS) == "failed"


# ═══════════════════════════════════════════════════════════════════════════════
# 10. Integration tests — status in conversation history does not corrupt LLM input
# ═══════════════════════════════════════════════════════════════════════════════

@respx.mock
def test_status_in_history_not_sent_as_raw_json_to_llm():
    """When a previous turn stored status in JSON, the follow-up LLM should receive
    clean text (not raw JSON blobs) in its conversation history."""
    captured_messages = []

    def mock_llm(request):
        body = json.loads(request.content)
        messages = body.get("messages", [])
        captured_messages.append(messages)

        context = {"call": getattr(mock_llm, "_call_count", 0)}
        mock_llm._call_count = context["call"] + 1

        if context["call"] == 0:
            return collector_prompt()
        elif context["call"] == 1:
            return collector_capture("valid_val")
        elif context["call"] == 2:
            return fu_answer_with_status("Action done!", "success")
        else:
            return fu_answer("Follow-up to status.")

    mock_llm._call_count = 0
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="do action", initial_context={})
    tool.execute(thread_id=tid, user_message="what happened?", initial_context={})

    assert len(captured_messages) >= 4
    last_call_messages = captured_messages[-1]

    for msg in last_call_messages:
        if msg.get("role") != "assistant":
            continue
        content = msg.get("content", "")
        try:
            parsed = json.loads(content)
            assert not ("status" in parsed and "bot_response" in parsed), (
                f"Raw JSON blob with 'status' leaked into assistant message: {content[:200]}"
            )
        except (json.JSONDecodeError, TypeError):
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# 11. Tests — empty assistant message bug is FIXED
# ═══════════════════════════════════════════════════════════════════════════════

class TestEmptyAssistantMessageBugFixed:
    """
    The empty-assistant-message bug was caused by _build_conversation_entry
    serialising status when bot_response was None/empty, producing a JSON blob
    with an empty 'bot_response' key that some LLM providers reject.

    The bug is fixed by NOT serialising `status` in _build_conversation_entry —
    only bot_response and options are stored in conversation history.
    When content is empty and there are no options, a plain empty string is returned
    (which callers should guard against), but the JSON-with-empty-bot_response path
    no longer exists.
    """

    def test_no_status_parameter_on_build_conversation_entry(self):
        """_build_conversation_entry must not accept a `status` kwarg — status
        belongs on FollowUpOutput, not in serialised conversation history."""
        import inspect
        from soprano_sdk.nodes.follow_up import FollowUpStrategy
        sig = inspect.signature(FollowUpStrategy._build_conversation_entry)
        assert "status" not in sig.parameters, (
            "'status' parameter must not appear in _build_conversation_entry"
        )

    def test_empty_content_no_options_returns_plain_string(self):
        """When content is empty and there are no options, entry content is a plain
        string — not a JSON blob with an empty bot_response."""
        node = _make_follow_up_strategy()
        entry = node._build_conversation_entry(role="assistant", content="")
        # Must be a plain string, not JSON
        assert entry["content"] == ""
        try:
            json.loads(entry["content"])
            assert False, "Empty content should not be serialised to JSON"
        except (json.JSONDecodeError, ValueError):
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# 12. Tests — structured output message key uses "bot_response" not "text"
# ═══════════════════════════════════════════════════════════════════════════════

@respx.mock
def test_collect_input_structured_output_serialises_with_bot_response_key():
    """In structured output mode, the initial prompt must be stored with 'bot_response' key,
    not 'text', so the LLM doesn't learn to output 'text' from its conversation history."""
    captured = []

    def mock_llm(request):
        body = json.loads(request.content)
        captured.append(body.get("messages", []))
        return collector_prompt()

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    s = snap(tool, tid)
    conversations = s.get(WorkflowKeys.CONVERSATIONS, {})
    for conv_key, conv in conversations.items():
        for msg in conv:
            if msg.get("role") == "assistant":
                try:
                    content = json.loads(msg["content"])
                    if isinstance(content, dict):
                        assert "bot_response" in content or "text" not in content, (
                            f"Structured output conversation stored 'text' key instead of 'bot_response': {content}"
                        )
                except (json.JSONDecodeError, TypeError):
                    pass


@respx.mock
def test_guardrail_error_uses_bot_response_key_in_structured_output_mode():
    """When a guardrail fires in structured output mode, the error must be stored
    under 'bot_response' key, not 'text'."""
    import inspect
    from soprano_sdk.nodes import collect_input
    source = inspect.getsource(collect_input)
    assert '"bot_response": gve.error_message' in source or \
           '"bot_response"' in source, (
        "GuardrailViolationError handler must use 'bot_response' key"
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 13. Tests — humanization system prompt priority order
# ═══════════════════════════════════════════════════════════════════════════════

class TestHumanizationPriorityOrder:
    """The humanization system prompt must include a PRIORITY ORDER section."""

    def test_default_humanization_prompt_has_priority_order(self):
        from soprano_sdk.core.constants import DEFAULT_HUMANIZATION_SYSTEM_PROMPT
        assert "PRIORITY ORDER" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT

    def test_reference_message_listed_as_highest_priority(self):
        from soprano_sdk.core.constants import DEFAULT_HUMANIZATION_SYSTEM_PROMPT
        assert "REFERENCE MESSAGE" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT
        assert "highest priority" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT

    def test_conversation_history_listed_as_lower_priority(self):
        from soprano_sdk.core.constants import DEFAULT_HUMANIZATION_SYSTEM_PROMPT
        assert "CONVERSATION HISTORY" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT
        assert "lower priority" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT or \
               "tone and style" in DEFAULT_HUMANIZATION_SYSTEM_PROMPT

    def test_humanization_embeds_history_in_system_prompt_not_messages(self):
        import inspect
        from soprano_sdk.core import engine as engine_module
        source = inspect.getsource(engine_module)
        assert "conversation_history" in source
        assert "history_text" in source or "<conversation_history>" in source


# ═══════════════════════════════════════════════════════════════════════════════
# 14. Tests — COLLECT_INPUT_METADATA_FIELDS does not include "status"
# ═══════════════════════════════════════════════════════════════════════════════

class TestMetadataFieldsNamingConflict:
    """
    POTENTIAL BUG: 'status' is not in COLLECT_INPUT_METADATA_FIELDS.
    If a user defines a SOP field named 'status', it creates a naming conflict
    with the framework-injected 'status' field in create_structured_output_model.
    """

    def test_status_not_in_metadata_fields_exclusion_set(self):
        from soprano_sdk.core.constants import COLLECT_INPUT_METADATA_FIELDS
        assert "status" not in COLLECT_INPUT_METADATA_FIELDS, (
            "If this assertion fails, 'status' was added to COLLECT_INPUT_METADATA_FIELDS "
            "which would fix the naming conflict bug."
        )

    def test_user_field_named_status_conflicts_with_framework_status(self):
        """A user field named 'status' will conflict with the framework 'status' field
        injected by create_structured_output_model."""
        user_fields = [
            {"name": "status", "type": "text", "description": "User's custom status field"}
        ]
        Model = create_structured_output_model(user_fields)
        instance = Model(status="active")
        assert instance.status == "active", (
            "User field 'status' should overwrite framework 'status', but type is now text not bool. "
            "This naming conflict could cause subtle bugs when user defines a field named 'status'."
        )
