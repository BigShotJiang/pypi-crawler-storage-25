"""
Unit tests for create_follow_up_output_model() and FollowUpOutput.get_schema_reminder().

Covers:
- Factory with no nodes → returns base class unchanged
- Factory with one node → Literal[node], invalid values rejected
- Factory with multiple nodes → Literal union, all members accepted, others rejected
- get_schema_reminder() output with Literal annotation (correct formatting)
- isinstance() and model_dump/validate compatibility on the generated subclass
"""

import pytest
from pydantic import ValidationError

from soprano_sdk.agents.structured_output import (
    FollowUpOutput,
    create_follow_up_output_model,
)


# ---------------------------------------------------------------------------
# create_follow_up_output_model — return-value identity
# ---------------------------------------------------------------------------

class TestCreateFollowUpOutputModelIdentity:
    def test_none_returns_base_class(self):
        assert create_follow_up_output_model(None) is FollowUpOutput

    def test_empty_list_returns_base_class(self):
        assert create_follow_up_output_model([]) is FollowUpOutput

    def test_single_node_returns_subclass(self):
        model = create_follow_up_output_model(["collect_a"])
        assert model is not FollowUpOutput
        assert issubclass(model, FollowUpOutput)

    def test_multiple_nodes_returns_subclass(self):
        model = create_follow_up_output_model(["collect_a", "collect_b"])
        assert model is not FollowUpOutput
        assert issubclass(model, FollowUpOutput)


# ---------------------------------------------------------------------------
# create_follow_up_output_model — Pydantic validation
# ---------------------------------------------------------------------------

class TestCreateFollowUpOutputModelValidation:
    def test_single_node_accepts_valid_value(self):
        model = create_follow_up_output_model(["collect_a"])
        instance = model(intent_change="collect_a")
        assert instance.intent_change == "collect_a"

    def test_single_node_rejects_invalid_value(self):
        model = create_follow_up_output_model(["collect_a"])
        with pytest.raises(ValidationError):
            model(intent_change="ghost_node")

    def test_single_node_accepts_null(self):
        model = create_follow_up_output_model(["collect_a"])
        instance = model(intent_change=None)
        assert instance.intent_change is None

    def test_multiple_nodes_each_valid_value_accepted(self):
        nodes = ["collect_a", "collect_b", "collect_c"]
        model = create_follow_up_output_model(nodes)
        for node in nodes:
            instance = model(intent_change=node)
            assert instance.intent_change == node

    def test_multiple_nodes_rejects_non_member(self):
        model = create_follow_up_output_model(["collect_a", "collect_b"])
        for invalid in ["collect_c", "wrong", ""]:
            with pytest.raises(ValidationError):
                model(intent_change=invalid)

    def test_multiple_nodes_accepts_null(self):
        model = create_follow_up_output_model(["collect_a", "collect_b"])
        instance = model(intent_change=None)
        assert instance.intent_change is None

    def test_other_fields_inherited_and_functional(self):
        """All FollowUpOutput fields must still work on the generated subclass."""
        model = create_follow_up_output_model(["collect_a"])
        opts = [{"text": "Yes", "subtext": None}]
        instance = model(
            bot_response="Hello",
            options=opts,
            is_selectable=True,
            intent_change="collect_a",
            out_of_scope=None,
            restart=False,
        )
        assert instance.bot_response == "Hello"
        assert instance.options == opts
        assert instance.is_selectable is True
        assert instance.intent_change == "collect_a"
        assert instance.out_of_scope is None
        assert instance.restart is False


# ---------------------------------------------------------------------------
# isinstance() and serialisation compatibility
# ---------------------------------------------------------------------------

class TestSubclassCompatibility:
    def test_isinstance_base_class(self):
        model = create_follow_up_output_model(["collect_a"])
        instance = model(bot_response="Hi")
        assert isinstance(instance, FollowUpOutput)

    def test_isinstance_generated_class(self):
        model = create_follow_up_output_model(["collect_a"])
        instance = model(bot_response="Hi")
        assert isinstance(instance, model)

    def test_model_dump_round_trips(self):
        model = create_follow_up_output_model(["collect_a"])
        original = model(bot_response="Hi", intent_change="collect_a")
        dumped = original.model_dump()
        restored = model(**dumped)
        assert restored.bot_response == original.bot_response
        assert restored.intent_change == original.intent_change

    def test_model_validate_accepts_dict(self):
        model = create_follow_up_output_model(["collect_a", "collect_b"])
        data = {"bot_response": "Test", "intent_change": "collect_b"}
        instance = model.model_validate(data)
        assert instance.intent_change == "collect_b"

    def test_base_class_instance_not_instanceof_subclass(self):
        model = create_follow_up_output_model(["collect_a"])
        base_instance = FollowUpOutput(bot_response="base")
        assert not isinstance(base_instance, model)


# ---------------------------------------------------------------------------
# get_schema_reminder() — output format
# ---------------------------------------------------------------------------

class TestGetSchemaReminder:

    def test_single_node_schema_shows_literal_value(self):
        model = create_follow_up_output_model(["collect_a"])
        schema = model.get_schema_reminder()
        intent_line = next(line for line in schema.split("\n") if "intent_change" in line)
        assert '"collect_a"' in intent_line

    def test_single_node_schema_includes_null(self):
        model = create_follow_up_output_model(["collect_a"])
        schema = model.get_schema_reminder()
        intent_line = next(line for line in schema.split("\n") if "intent_change" in line)
        assert "null" in intent_line

    def test_multiple_nodes_all_values_present_in_schema(self):
        nodes = ["collect_a", "collect_b", "collect_c"]
        model = create_follow_up_output_model(nodes)
        schema = model.get_schema_reminder()
        intent_line = next(line for line in schema.split("\n") if "intent_change" in line)
        for node in nodes:
            assert f'"{node}"' in intent_line, (
                f'Expected "{node}" in schema intent_change line, got: {intent_line!r}'
            )

    def test_multiple_nodes_pipe_separators_present(self):
        model = create_follow_up_output_model(["node1", "node2"])
        schema = model.get_schema_reminder()
        intent_line = next(line for line in schema.split("\n") if "intent_change" in line)
        assert " | " in intent_line

    def test_schema_is_valid_json_structure(self):
        """The schema reminder must start with { and end with }."""
        model = create_follow_up_output_model(["collect_a"])
        schema = model.get_schema_reminder()
        assert schema.strip().startswith("{")
        assert schema.strip().endswith("}")

    def test_all_followup_fields_present_in_schema(self):
        model = create_follow_up_output_model(["collect_a"])
        schema = model.get_schema_reminder()
        for field in ["reasoning", "bot_response", "options", "is_selectable",
                      "intent_change", "out_of_scope", "restart"]:
            assert field in schema, f"Field '{field}' missing from schema reminder"

    def test_excluded_nodes_not_in_schema(self):
        """Nodes excluded at the _get_output_model level must not appear in the schema."""
        # all_nodes = ["collect_a", "collect_b", "collect_c"]
        included_nodes = ["collect_a", "collect_c"]   # collect_b excluded
        model = create_follow_up_output_model(included_nodes)
        schema = model.get_schema_reminder()
        intent_line = next(line for line in schema.split("\n") if "intent_change" in line)
        assert '"collect_b"' not in intent_line
        assert '"collect_a"' in intent_line
        assert '"collect_c"' in intent_line
