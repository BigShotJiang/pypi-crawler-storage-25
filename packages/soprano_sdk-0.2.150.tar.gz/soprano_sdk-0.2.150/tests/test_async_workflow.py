"""
Tests for async workflow execution (aexecute / aresume).

Validates that the async API produces identical results to the sync API
while running inside an asyncio event loop (as a FastAPI endpoint would).
"""
import asyncio
import uuid
import respx

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    MODEL_CONFIG,
    CapturingCheckpointer,
    collector_prompt,
    llm_structured_response,
    llm_text_response,
    make_tool,
)
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.streaming.streamer import WorkflowStreamer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FIXTURES_DIR = "tests/fixtures"


def _make_tool(yaml_name: str) -> WorkflowTool:
    return make_tool(yaml_name, checkpointer=CapturingCheckpointer())


# ---------------------------------------------------------------------------
# Test: Structured-output collect-input — full async round-trip
# ---------------------------------------------------------------------------

@respx.mock
def test_async_execute_structured_output():
    """aexecute should collect a field via structured output and complete."""
    responses = iter([
        # Turn 1: collector prompts user
        collector_prompt("What is your name?"),
        # Turn 2: collector captures name (must include all required SO fields)
        llm_structured_response({"bot_response": None, "captured_name": True, "name": "Alice", "status": "success"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make_tool("collect_input_structured_output.yaml")
    tid = str(uuid.uuid4())

    async def _run():
        # Turn 1: start workflow — should ask for name
        r1 = await tool.aexecute(thread_id=tid, initial_context={})
        assert "user_input" in str(r1).lower() or "What is your name?" in str(r1), f"Expected prompt, got: {r1}"

        # Turn 2: resume with user's name — should complete
        r2 = await tool.aexecute(thread_id=tid, user_message="Alice")
        assert "Name collected" in str(r2), f"Expected completion, got: {r2}"
        return r2

    result = asyncio.run(_run())
    assert "Name collected" in str(result)


# ---------------------------------------------------------------------------
# Test: Pattern-match collect-input — full async round-trip
# ---------------------------------------------------------------------------

@respx.mock
def test_async_execute_pattern_match():
    """aexecute with pattern matching should complete identically to sync."""
    responses = iter([
        # Turn 1: collector prompts
        llm_text_response("Hi! What's your name?"),
        # Turn 2: collector captures
        llm_text_response("NAME_CAPTURED: Bob"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    async def _run():
        r1 = await tool.aexecute(thread_id=tid, initial_context={})
        assert "user_input" in str(r1).lower() or "name" in str(r1).lower(), f"Unexpected: {r1}"

        r2 = await tool.aexecute(thread_id=tid, user_message="Bob")
        assert "Name collected" in str(r2), f"Expected completion, got: {r2}"
        return r2

    result = asyncio.run(_run())
    assert "Name collected" in str(result)


# ---------------------------------------------------------------------------
# Test: Sync and async produce same result
# ---------------------------------------------------------------------------

@respx.mock
def test_sync_and_async_produce_same_result():
    """Sync execute() and async aexecute() should produce the same outcome."""
    so_capture = llm_structured_response({"bot_response": None, "captured_name": True, "name": "Charlie", "status": "success"})

    # Sync execution
    sync_responses = iter([
        collector_prompt("What is your name?"),
        so_capture,
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(sync_responses))

    tool_sync = _make_tool("collect_input_structured_output.yaml")
    tid_sync = str(uuid.uuid4())

    tool_sync.execute(thread_id=tid_sync, initial_context={})
    r2_sync = tool_sync.execute(thread_id=tid_sync, user_message="Charlie")

    # Reset mock for async
    respx.reset()
    async_responses = iter([
        collector_prompt("What is your name?"),
        so_capture,
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(async_responses))

    tool_async = _make_tool("collect_input_structured_output.yaml")
    tid_async = str(uuid.uuid4())

    async def _run():
        r1 = await tool_async.aexecute(thread_id=tid_async, initial_context={})
        r2 = await tool_async.aexecute(thread_id=tid_async, user_message="Charlie")
        return r1, r2

    r1_async, r2_async = asyncio.run(_run())

    # Both should reach the same outcome
    assert "Name collected" in str(r2_sync), f"Sync failed: {r2_sync}"
    assert "Name collected" in str(r2_async), f"Async failed: {r2_async}"


# ---------------------------------------------------------------------------
# Test: aresume works after aexecute
# ---------------------------------------------------------------------------

@respx.mock
def test_async_resume():
    """aresume() should pick up where aexecute() left off."""
    responses = iter([
        collector_prompt("What is your name?"),
        llm_structured_response({"bot_response": None, "captured_name": True, "name": "Diana", "status": "success"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make_tool("collect_input_structured_output.yaml")
    tid = str(uuid.uuid4())

    async def _run():
        r1 = await tool.aexecute(thread_id=tid, initial_context={})
        assert "user_input" in str(r1).lower() or "name" in str(r1).lower()

        # Use aresume instead of aexecute for the second turn
        r2 = await tool.aresume(thread_id=tid, resume_value="Diana")
        assert "Name collected" in str(r2), f"Expected completion, got: {r2}"
        return r2

    result = asyncio.run(_run())
    assert "Name collected" in str(result)


# ---------------------------------------------------------------------------
# Test: async streaming
# ---------------------------------------------------------------------------

@respx.mock
def test_async_streaming():
    """astream() should yield events and eventually complete."""
    responses = iter([
        collector_prompt("What is your name?"),
        llm_structured_response({"bot_response": None, "captured_name": True, "name": "Eve", "status": "success"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    from soprano_sdk.streaming.events import (
        InterruptEvent,
        CompleteEvent,
    )

    streamer = WorkflowStreamer(
        yaml_path=f"{FIXTURES_DIR}/collect_input_structured_output.yaml",
        name="test",
        config={"model_config": MODEL_CONFIG},
        checkpointer=CapturingCheckpointer(),
    )
    tid = str(uuid.uuid4())

    async def _run():
        # Turn 1: should yield node events + interrupt
        events_t1 = []
        async for event in streamer.astream(thread_id=tid, initial_context={}):
            events_t1.append(event)

        assert any(isinstance(e, InterruptEvent) for e in events_t1), f"Expected InterruptEvent, got: {[type(e).__name__ for e in events_t1]}"

        # Turn 2: resume with name
        events_t2 = []
        async for event in streamer.astream(thread_id=tid, user_message="Eve"):
            events_t2.append(event)

        assert any(isinstance(e, CompleteEvent) for e in events_t2), f"Expected CompleteEvent, got: {[type(e).__name__ for e in events_t2]}"
        return events_t2

    asyncio.run(_run())
