"""
Rollback edge case tests.

Covers:
  1. No snapshot available for the rollback target node — HistoryBasedRollback returns {}
     which base.py treats as a failed rollback. _handle_intent_change raises RuntimeError
     internally; base.py catches it and routes the workflow to the error outcome.

  2. Pattern-matching (PM) node initiates a rollback via "INTENT_CHANGE: <node>" response —
     verifies that the PM path through _handle_special_responses correctly rolls back state
     and re-enters the target node.
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    llm_text_response,
    make_tool,
    snap,
)



# ── Scenario 1: No snapshot available for the target node (PM workflow) ───────

@respx.mock
def test_pm_rollback_no_snapshot_routes_to_error_outcome():
    """When a PM node attempts intent_change to an unvisited node, the workflow
    routes to the error outcome (RuntimeError is caught internally by base.py).

    collect_name fires INTENT_CHANGE: collect_status on T1.
    collect_status has never run so HistoryBasedRollback finds no snapshot.
    _handle_intent_change raises RuntimeError; base.py converts this to an error
    state and the workflow terminates with the error outcome message.
    """
    responses = iter([
        # LLM#1: collect_name T1 — jumps forward to a node that was never visited
        llm_text_response("INTENT_CHANGE: collect_status"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_two_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})

    # The workflow must not interrupt for user input — it must terminate with an error
    assert InterruptType.USER_INPUT not in str(result)

    # The result message must indicate an error relating to the missing snapshot
    result_str = str(result)
    assert "collect_status" in result_str or "Unable to complete" in result_str, (
        f"Expected error referencing 'collect_status' in result, got: {result_str}"
    )

    # Only 1 LLM call was made (no retry into collect_status)
    assert respx.calls.call_count == 1


@respx.mock
def test_so_rollback_no_snapshot_routes_to_error_outcome():
    """When an SO node attempts intent_change to an unvisited node, the workflow
    routes to the error outcome.

    A 3-step workflow is needed because intent_change is only available in the SO
    model once at least one collector node has completed (needs_intent_change depends
    on _collector_nodes being non-empty). collect_status is the 2nd node so
    collect_name is already registered when it runs.

    Timeline:
      T1: collect_name prompts "What is your name?"
      T2: User replies — collect_name captures → collect_status prompts
      T3: User replies — collect_status returns intent_change="collect_other"
          collect_other has never run so no snapshot exists → error outcome.
    """
    responses = iter([
        # LLM#1: collect_name T1 — generate prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#2: collect_name T2 — capture name
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "Alice",
            "options": None, "is_selectable": None,
        }),
        # LLM#3: collect_status T1 — generate prompt
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
        # LLM#4: collect_status T2 — jump forward to unvisited collect_other
        llm_structured_response({
            "bot_response": None,
            "captured": False, "status": None,
            "intent_change": "collect_other",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_three_step_no_snapshot.yaml")
    tid = str(uuid.uuid4())

    # T1: collect_name prompts
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: collect_name captures → collect_status prompts
    result2 = tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    assert InterruptType.USER_INPUT in str(result2)
    assert "What is your status?" in str(result2)

    # T3: collect_status tries intent_change to unvisited collect_other
    result3 = tool.execute(thread_id=tid, user_message="anything", initial_context={})

    # Must NOT re-prompt the user — workflow terminates with error
    assert InterruptType.USER_INPUT not in str(result3)

    result_str = str(result3)
    assert "collect_other" in result_str or "Unable to complete" in result_str, (
        f"Expected error referencing 'collect_other', got: {result_str}"
    )


# ── Scenario 2: PM node rollback to a previously-visited PM node ──────────────

@respx.mock
def test_pm_node_rollback_to_previous_pm_node():
    """PM node can roll back to a previously-visited PM node via INTENT_CHANGE:.

    Setup: 2-step PM workflow (collect_name → collect_status), both nodes use
    plain-text pattern matching (no structured_output).

    T1: collect_name prompts "What is your name?"
    T2: User says "Alice" → collect_name captures → collect_status prompts
    T3: User says "go back" → collect_status LLM returns "INTENT_CHANGE: collect_name"
        → rollback restores snapshot before collect_name
        → collect_name re-prompts

    Verifies:
    - name field is cleared after rollback
    - collect_name re-prompts successfully
    """
    responses = iter([
        # LLM#1: collect_name T1 — ask for name
        llm_text_response("What is your name?"),
        # LLM#2: collect_name T2 — user says "Alice", capture it
        llm_text_response("NAME_CAPTURED: Alice"),
        # LLM#3: collect_status T1 — ask for status
        llm_text_response("What is your status?"),
        # LLM#4: collect_status T2 — user wants to go back, PM intent change
        llm_text_response("INTENT_CHANGE: collect_name"),
        # LLM#5: collect_name re-entry after rollback — re-prompt
        llm_text_response("What is your name?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_two_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: collect_name prompts
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: collect_name captures "Alice" → collect_status prompts
    result2 = tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    s2 = snap(tool, tid)
    assert InterruptType.USER_INPUT in str(result2)
    assert "What is your status?" in str(result2)
    assert s2.get("name") == "Alice"

    # T3: collect_status detects intent change → rollback to collect_name → re-prompt
    result3 = tool.execute(thread_id=tid, user_message="go back", initial_context={})
    s3 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)
    assert "What is your name?" in str(result3)

    # name must be cleared by the rollback
    assert s3.get("name") is None, (
        f"Expected name=None after PM rollback, got '{s3.get('name')}'"
    )

    assert respx.calls.call_count == 5


@respx.mock
def test_pm_node_rollback_clears_subsequent_data():
    """PM rollback clears data from the rolled-back node onwards.

    Verifies that after rollback to collect_name:
    - the name field is cleared (collect_name is the rollback target)
    - status stays None (collect_status was never captured)
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response("NAME_CAPTURED: Bob"),
        llm_text_response("What is your status?"),
        llm_text_response("INTENT_CHANGE: collect_name"),
        llm_text_response("What is your name?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_two_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="Bob", initial_context={})
    tool.execute(thread_id=tid, user_message="go back", initial_context={})

    s = snap(tool, tid)

    assert s.get("name") is None, "name should be cleared after rollback to collect_name"
    assert s.get("status") is None, "status should remain None (never captured)"
