import uuid
import respx
import json

from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    make_tool,
    llm_structured_response,
)


@respx.mock
def test_follow_up_history_and_metadata_preservation():
    """Verify that follow-up LLM sees full history and metadata hints."""
    captured_messages_per_turn = []
    
    context = {"turn": 0}

    def mock_llm(request):
        body = json.loads(request.content)
        messages = body["messages"]
        captured_messages_per_turn.append(messages)
        
        system_prompt = messages[0]["content"]
        
        # Follow-up node identification: use more specific markers than just "CONVERSATION HISTORY:"
        # as collectors now also show history when re-entering or when they have prior context.
        is_follow_up = (
            "post-workflow follow-up assistant" in system_prompt or 
            "RESPONSE FORMAT:" in system_prompt or
            "exactly these fields:" in system_prompt
        )
        
        if is_follow_up:
            return llm_structured_response({
                "bot_response": "Follow-up response",
                "options": [{"text": "Opt1", "subtext": "Sub1"}],
                "is_selectable": True
            })
        else:
            # Collector node (CollectInputNode)
            if context["turn"] == 0:
                context["turn"] += 1
                return llm_structured_response({"bot_response": "Asking for A"})
            else:
                return llm_structured_response({"field_a": "val_a"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    # 1. Start workflow
    tool.execute(thread_id=tid, initial_context={})

    # 2. Complete workflow -> Transition to outcome -> Interrupt (Follow-up)
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # 3. Follow-up Turn 1 (User: "How are you?")
    tool.execute(thread_id=tid, user_message="How are you?", initial_context={})

    # 4. Follow-up Turn 2 (User: "What was the result?")
    tool.execute(thread_id=tid, user_message="What was the result?", initial_context={})
    
    # Analyze Prompt for Turn 3 (last turn)
    messages_turn_3 = captured_messages_per_turn[-1]
    system_prompt = messages_turn_3[0]["content"]
    message_history = messages_turn_3[1:]

    # 1. Check for Outcome Message (it's the first assistant message in follow-up history)
    # The FollowUp node injects the outcome message as the first entry in its local conversation.
    assert "val_a" in message_history[0]["content"], "Outcome message missing from first message history"
    
    # 2. Check for Turn 1 User Message in history list
    assert any("How are you?" in m["content"] for m in message_history), "Previous follow-up turn missing from message history"
    
    # 3. Check for Turn 1 Assistant Message in history list
    assert any("Follow-up response" in m["content"] for m in message_history), "Assistant follow-up response missing from message history"
    
    # 4. Check for Collector History in system prompt (prior to follow-up)
    assert "CONVERSATION HISTORY:" in system_prompt
    assert "Asking for A" in system_prompt
    assert "val_a" in system_prompt

    # 5. Check for Metadata Hint in Assistant message history (Turn 1 response)
    assistant_msg = next((m["content"] for m in reversed(message_history) if m["role"] == "assistant"), "")
    assert "Follow-up response" in assistant_msg
    assert "Options: Opt1" in assistant_msg, "Options metadata hint missing from Assistant message"

    print("Verification passed: History and Metadata are preserved in Follow-up node.")


@respx.mock
def test_follow_up_reasoning_does_not_leak_into_history():
    """Verify that the follow-up node's `reasoning` field is stripped from
    assistant messages stored in conversation history so the LLM never sees
    '(collected Reasoning): ...' in subsequent turns."""
    captured_messages = []

    context = {"turn": 0}

    def mock_llm(request):
        body = json.loads(request.content)
        messages = body["messages"]
        captured_messages.append(messages)

        system_prompt = messages[0]["content"]
        is_follow_up = (
            "post-workflow follow-up assistant" in system_prompt
            or "RESPONSE FORMAT:" in system_prompt
            or "exactly these fields:" in system_prompt
        )

        if is_follow_up:
            # Return a follow-up response that includes a reasoning field
            return llm_structured_response({
                "reasoning": "The user is asking about their order status.",
                "bot_response": "Your order is on the way!",
                "options": None,
                "is_selectable": None,
                "intent_change": None,
                "out_of_scope": None,
                "restart": False,
            })
        else:
            if context["turn"] == 0:
                context["turn"] += 1
                return llm_structured_response({"bot_response": "Asking for A"})
            else:
                return llm_structured_response({"field_a": "val_a"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    # Reach follow-up node
    tool.execute(thread_id=tid, initial_context={})
    res_workflow_complete = tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # Workflow completes and transitions into follow-up — interrupt type must be FOLLOW_UP
    assert InterruptType.FOLLOW_UP in str(res_workflow_complete), (
        "Expected FOLLOW_UP interrupt after workflow completion"
    )

    # First follow-up turn (reasoning field returned by LLM)
    res_fu_turn1 = tool.execute(thread_id=tid, user_message="Where is my order?", initial_context={})

    # Response must still be a follow-up interrupt (node self-loops)
    assert InterruptType.FOLLOW_UP in str(res_fu_turn1), (
        "Expected FOLLOW_UP interrupt after first follow-up turn"
    )

    # Second follow-up turn — inspect what the LLM sees in its message history
    res_fu_turn2 = tool.execute(thread_id=tid, user_message="Any updates?", initial_context={})

    assert InterruptType.FOLLOW_UP in str(res_fu_turn2), (
        "Expected FOLLOW_UP interrupt after second follow-up turn"
    )

    assert "Your order is on the way!" in str(res_fu_turn2), (
        "Expected bot_response from in follow-up turn to be in second turn"
    )

    # There should be exactly 4 LLM calls:
    # collector prompt -> collector capture -> follow-up turn 1 -> follow-up turn 2
    assert len(captured_messages) == 4, (
        f"Expected 4 LLM calls, got {len(captured_messages)}"
    )

    # Verify the last two calls were genuinely handled by the follow-up node
    for fu_turn_idx in (2, 3):
        fu_system_prompt = captured_messages[fu_turn_idx][0]["content"]
        assert "RESPONSE FORMAT:" in fu_system_prompt, (
            f"LLM call {fu_turn_idx} is missing RESPONSE FORMAT — not a follow-up node call"
        )
        assert "CONVERSATION HISTORY:" in fu_system_prompt, (
            f"LLM call {fu_turn_idx} is missing CONVERSATION HISTORY — not a follow-up node call"
        )
        # The FollowUpOutput schema always includes "reasoning" as a field hint
        assert '"reasoning"' in fu_system_prompt, (
            f"LLM call {fu_turn_idx} system prompt missing reasoning field in schema hint"
        )

    # The last LLM call is the second follow-up turn; check message history
    last_messages = captured_messages[-1]
    last_system_prompt = last_messages[0]["content"]
    message_history = last_messages[1:]
    history_contents = " ".join(m["content"] for m in last_messages)

    # Confirm the current user turn is "Any updates?"
    last_user_msg = next(
        (m["content"] for m in reversed(last_messages) if m["role"] == "user"), ""
    )
    assert "Any updates?" in last_user_msg, (
        "Last user message in second follow-up turn should be 'Any updates?'"
    )

    # Turn 1 user message must be in the message history visible to turn 2
    assert any("Where is my order?" in m["content"] for m in message_history), (
        "First follow-up turn user message missing from history in second turn"
    )

    # Turn 1 assistant bot_response must be in message history (not replaced by reasoning)
    assert any("Your order is on the way!" in m["content"] for m in message_history), (
        "First follow-up turn bot_response missing from message history"
    )

    # Prior collector CONVERSATION HISTORY must appear in system prompt
    assert "Asking for A" in last_system_prompt, (
        "Collector conversation history missing from follow-up system prompt"
    )

    # Core: reasoning must NOT leak as a collected-field marker anywhere in the LLM context
    assert "(collected Reasoning)" not in history_contents, (
        "reasoning field leaked as a collected marker into LLM history"
    )
