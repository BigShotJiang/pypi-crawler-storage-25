"""
End-to-end respx tests verifying the dynamic Literal intent_change feature.

These tests intercept HTTP calls to the fake LLM endpoint and inspect the
*request* bodies that the follow-up node sends, ensuring that:

  1. The schema hint injected into the last user message contains the actual
     collector node names (from WorkflowKeys.COLLECTOR_NODES state).
  2. A two-step workflow exposes both collector nodes in the schema hint.
  3. Nodes listed in follow_up.excluded_nodes are absent from the schema hint.
  4. A valid constrained intent_change value routes correctly (rollback succeeds
     without error — the Literal constraint doesn't break normal routing).
  5. The Literal constraint rejects an out-of-range intent_change and the workflow
     stays alive as a FOLLOW_UP self-loop (no crash, session continues).

Fixture inventory
-----------------
follow_up_single_step.yaml     : single collector (collect_a), langgraph
follow_up_two_step.yaml        : two collectors (collect_a, collect_b), langgraph
follow_up_two_step_excluded.yaml : two collectors, collect_b excluded, langgraph
follow_up_disabled_grounding_guardrail.yaml : crewai, grounding disabled at index 1
"""

import json as _json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_intent_change,
    llm_structured_response,
    llm_text_response,
    make_tool,
    snap,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _two_step_b_prompt(text="Please provide field B."):
    return llm_structured_response({"bot_response": text, "field_b": None})


def _two_step_b_capture(value):
    return llm_structured_response({"bot_response": None, "field_b": value})


def _follow_up_request_messages(captured_requests, index: int) -> list[dict]:
    """Parse the messages array from the LLM request at *index*."""
    body = _json.loads(captured_requests[index].content)
    return body.get("messages", [])


def _last_user_content(messages: list[dict]) -> str:
    """Return the content of the last user-role message in *messages*."""
    user_msgs = [m for m in messages if m.get("role") == "user"]
    assert user_msgs, "No user messages found in LLM request"
    return user_msgs[-1].get("content", "")


# ---------------------------------------------------------------------------
# Test 1: single-step — schema hint contains the only collector node
# ---------------------------------------------------------------------------

@respx.mock
def test_follow_up_schema_hint_contains_single_collector_node():
    """After collecting field_a in a single-step workflow, the schema hint
    injected into the follow-up LLM request must reference 'collect_a'.

    Flow:
    T1  execute()        → LLM#1 collect_a prompt
    T2  execute("val_a") → LLM#2 collect_a captures → FOLLOW_UP
    T3  execute("q")     → LLM#3 follow-up call ← inspected
    """
    captured: list = []

    responses = iter([
        collector_prompt("Please provide field A."),   # LLM#1
        collector_capture("val_a"),                    # LLM#2
        fu_answer("Happy to help."),                   # LLM#3 — follow-up
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(
        side_effect=lambda req: (captured.append(req), next(responses))[1]
    )

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="some question", initial_context={})

    assert len(captured) == 3, f"Expected 3 LLM calls, got {len(captured)}"

    # LLM#3 is the follow-up call (index 2)
    msgs = _follow_up_request_messages(captured, 2)
    content = _last_user_content(msgs)

    assert "collect_a" in content, (
        f"Expected 'collect_a' in the schema hint of the follow-up LLM request, "
        f"but it was not found.\nLast user message: {content!r}"
    )


# ---------------------------------------------------------------------------
# Test 2: two-step — schema hint contains both collector nodes
# ---------------------------------------------------------------------------

@respx.mock
def test_follow_up_schema_hint_contains_both_collector_nodes_in_two_step_workflow():
    """After collecting both fields in a two-step workflow, the schema hint
    injected into the follow-up LLM request must reference both 'collect_a'
    and 'collect_b'.

    Flow:
    T1  execute()        → LLM#1 collect_a prompt
    T2  execute("val_a") → LLM#2 collect_a captures + LLM#3 collect_b prompt
    T3  execute("val_b") → LLM#4 collect_b captures → FOLLOW_UP
    T4  execute("q")     → LLM#5 follow-up call ← inspected
    """
    captured: list = []

    responses = iter([
        collector_prompt("Please provide field A."),   # LLM#1
        collector_capture("val_a"),                    # LLM#2
        _two_step_b_prompt("Please provide field B."), # LLM#3
        _two_step_b_capture("val_b"),                  # LLM#4
        fu_answer("Got it, how can I help?"),           # LLM#5 — follow-up
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(
        side_effect=lambda req: (captured.append(req), next(responses))[1]
    )

    tool = make_tool("follow_up_two_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})
    tool.execute(thread_id=tid, user_message="any question", initial_context={})

    assert len(captured) == 5, f"Expected 5 LLM calls, got {len(captured)}"

    msgs = _follow_up_request_messages(captured, 4)
    content = _last_user_content(msgs)

    assert "collect_a" in content, (
        f"Expected 'collect_a' in schema hint but it was absent.\n"
        f"Last user message: {content!r}"
    )
    assert "collect_b" in content, (
        f"Expected 'collect_b' in schema hint but it was absent.\n"
        f"Last user message: {content!r}"
    )


# ---------------------------------------------------------------------------
# Test 3: excluded node absent from schema hint
# ---------------------------------------------------------------------------

@respx.mock
def test_excluded_node_absent_from_follow_up_schema_hint():
    """When follow_up.excluded_nodes lists 'collect_b', the schema hint sent
    to the follow-up LLM must contain 'collect_a' but NOT 'collect_b'.

    Uses follow_up_two_step_excluded.yaml which has excluded_nodes: [collect_b].

    Flow: identical to test 2 (5 LLM calls).
    """
    captured: list = []

    responses = iter([
        collector_prompt("Please provide field A."),   # LLM#1
        collector_capture("val_a"),                    # LLM#2
        _two_step_b_prompt("Please provide field B."), # LLM#3
        _two_step_b_capture("val_b"),                  # LLM#4
        fu_answer("How can I help?"),                  # LLM#5 — follow-up
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(
        side_effect=lambda req: (captured.append(req), next(responses))[1]
    )

    tool = make_tool("follow_up_two_step_excluded.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})
    tool.execute(thread_id=tid, user_message="any question", initial_context={})

    assert len(captured) == 5, f"Expected 5 LLM calls, got {len(captured)}"

    msgs = _follow_up_request_messages(captured, 4)
    content = _last_user_content(msgs)

    assert "collect_a" in content, (
        f"Expected 'collect_a' in schema hint (not excluded).\n"
        f"Last user message: {content!r}"
    )
    assert "collect_b" not in content, (
        f"'collect_b' must be absent from schema hint since it is in excluded_nodes.\n"
        f"Last user message: {content!r}"
    )


# ---------------------------------------------------------------------------
# Test 4: valid constrained intent_change still routes correctly
# ---------------------------------------------------------------------------

@respx.mock
def test_valid_constrained_intent_change_routes_to_collector():
    """A follow-up intent_change whose value is within the Literal constraint
    (collect_a, which IS a real node) must roll back and re-prompt exactly as
    it did before the Literal constraint was introduced.

    This guards against the Literal constraint accidentally breaking valid routing.

    Flow:
    T1  execute()            → LLM#1 collect_a prompt
    T2  execute("val_a")     → LLM#2 collect_a captures → FOLLOW_UP
    T3  execute("change it") → LLM#3 follow-up intent_change("collect_a")
                                LLM#4 collect_a re-prompt after rollback → USER_INPUT
    """
    responses = iter([
        collector_prompt("Please provide field A."),               # LLM#1
        collector_capture("val_a"),                                # LLM#2
        fu_intent_change("collect_a", "Sure, let me redo that."), # LLM#3
        collector_prompt("Please re-enter field A."),              # LLM#4
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    result = tool.execute(thread_id=tid, user_message="change it", initial_context={})

    # Rollback succeeded → back at collector, not in follow-up
    assert InterruptType.USER_INPUT in str(result), (
        f"Expected USER_INPUT interrupt after valid constrained intent_change rollback. "
        f"Got: {str(result)[:200]}"
    )
    assert InterruptType.FOLLOW_UP not in str(result)

    s = snap(tool, tid)
    assert s.get("field_a") is None, "field_a must be cleared after rollback"
    assert s.get("_follow_up_active") is None

    assert respx.calls.call_count == 4


# ---------------------------------------------------------------------------
# Test 5: out-of-range intent_change triggers Pydantic validation error,
#          workflow stays alive as FOLLOW_UP self-loop, session continues
# ---------------------------------------------------------------------------

@respx.mock
def test_out_of_range_intent_change_self_loops_and_session_continues():
    """When the LLM returns an intent_change value outside the Literal
    constraint ('ghost_node_does_not_exist' is not a real collector node),
    Pydantic validation fails.  The follow-up node must:
      - Stay alive as a FOLLOW_UP self-loop (not crash, not reach END)
      - Allow the next normal turn to succeed

    Flow:
    T1  execute()           → LLM#1 collector prompt
    T2  execute("val_a")    → LLM#2 collector captures → FOLLOW_UP
    T3  execute("q1")       → LLM#3 out-of-range intent_change → self-loop
    T4  execute("q2")       → LLM#4 normal answer → FOLLOW_UP continues

    field_a must be preserved throughout (no rollback occurred).
    """
    responses = iter([
        collector_prompt("What is field A?"),                  # LLM#1
        collector_capture("val_a"),                            # LLM#2
        llm_structured_response({                              # LLM#3: invalid node
            "bot_response": None,
            "intent_change": "ghost_node_does_not_exist",
            "out_of_scope": None,
            "restart": None,
        }),
        fu_answer("Happy to continue."),                       # LLM#4: normal turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})

    # Self-loop: still in follow-up, not routed to collector or END
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP self-loop after out-of-range intent_change. "
        f"Got: {str(result3)[:200]}"
    )
    assert InterruptType.USER_INPUT not in str(result3)

    s3 = snap(tool, tid)
    assert s3.get("field_a") is not None and "val_a" in str(s3.get("field_a")), (
        f"field_a must be unchanged after failed intent_change. Got: {s3.get('field_a')!r}"
    )
    assert s3.get("_follow_up_active") is True

    # Session must not be bricked — next turn works normally
    result4 = tool.execute(thread_id=tid, user_message="q2", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP to continue after self-loop recovery. "
        f"Got: {str(result4)[:200]}"
    )
    assert respx.calls.call_count == 4


# ---------------------------------------------------------------------------
# Test 6: schema hint is updated per-turn as conversation progresses
#          (same model each time — nodes don't change mid-session)
# ---------------------------------------------------------------------------

@respx.mock
def test_schema_hint_consistent_across_multiple_follow_up_turns():
    """The schema hint must include the same collector nodes on every follow-up
    turn within a session (COLLECTOR_NODES is written once and doesn't change).

    Flow:
    T1  → LLM#1 prompt
    T2  → LLM#2 capture → FOLLOW_UP
    T3  → LLM#3 first follow-up call   ← must contain 'collect_a'
    T4  → LLM#4 second follow-up call  ← must also contain 'collect_a'
    """
    captured: list = []

    responses = iter([
        collector_prompt("Please provide field A."),  # LLM#1
        collector_capture("val_a"),                   # LLM#2
        fu_answer("First answer."),                   # LLM#3
        fu_answer("Second answer."),                  # LLM#4
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(
        side_effect=lambda req: (captured.append(req), next(responses))[1]
    )

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="turn 1", initial_context={})
    tool.execute(thread_id=tid, user_message="turn 2", initial_context={})

    assert len(captured) == 4

    for follow_up_idx in [2, 3]:
        msgs = _follow_up_request_messages(captured, follow_up_idx)
        content = _last_user_content(msgs)
        assert "collect_a" in content, (
            f"Expected 'collect_a' in schema hint for LLM#{follow_up_idx + 1}, "
            f"but it was absent.\nLast user message: {content!r}"
        )


# ---------------------------------------------------------------------------
# Test 7: guardrail retry in follow-up (disabled grounding, CrewAI)
#          correct guardrail feedback sent across multiple turns
# ---------------------------------------------------------------------------

@respx.mock
def test_follow_up_guardrail_retry_uses_structured_output_feedback_on_second_plain_text():
    """A second consecutive plain-text follow-up response should trigger another
    StructuredOutputGuardrail retry.  The feedback injected must still be
    StructuredOutputGuardrail's ('empty or incomplete'), NOT the disabled
    GroundingGuardrail's feedback.

    This verifies the active_guardrails pre-filtering is consistent across
    successive turns, not just the first guardrail failure.

    Note: StructuredOutputGuardrail has max_retries=1, so after a plain-text
    response the retry fires once.  This test checks TWO separate tool.execute
    calls that each trigger one guardrail retry (each call: plain text → retry).

    Flow:
    T1  execute()             → LLM#1 collector prompt
    T2  execute("val_a")      → LLM#2 collector captures → FOLLOW_UP
    T3  execute("q1")         → LLM#3 plain text (guardrail fires)
                                 LLM#4 retry (valid JSON) → FOLLOW_UP
    T4  execute("q2")         → LLM#5 plain text (guardrail fires again)
                                 LLM#6 retry (valid JSON) → FOLLOW_UP

    Assert for both LLM#4 and LLM#6: feedback = StructuredOutputGuardrail's,
    NOT GroundingGuardrail's.
    """
    STRUCTURED_FEEDBACK = "empty or incomplete"
    GROUNDING_FEEDBACK  = "not supported by"

    captured: list = []

    responses = iter([
        collector_prompt("Please provide field A."),   # LLM#1
        collector_capture("val_a"),                    # LLM#2
        llm_text_response("Sure, happy to help!"),     # LLM#3 — plain text → StructuredOutputGuardrail fires
        fu_answer("First answer."),                    # LLM#4 — retry succeeds
        llm_text_response("Sure, happy to help!"),     # LLM#5 — plain text → StructuredOutputGuardrail fires
        fu_answer("Second answer."),                   # LLM#6 — retry succeeds
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(
        side_effect=lambda req: (captured.append(req), next(responses))[1]
    )

    tool = make_tool("follow_up_disabled_grounding_guardrail.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})  # T3 → LLM#3 + LLM#4
    tool.execute(thread_id=tid, user_message="q2", initial_context={})  # T4 → LLM#5 + LLM#6

    assert len(captured) == 6, (
        f"Expected 6 LLM calls (2 collector + 2 plain-text + 2 retries), "
        f"got {len(captured)}"
    )

    for retry_idx, label in [(3, "LLM#4"), (5, "LLM#6")]:
        msgs = _follow_up_request_messages(captured, retry_idx)
        user_msgs = [m for m in msgs if m.get("role") == "user"]
        retry_content = " ".join(m.get("content", "") for m in user_msgs)

        assert STRUCTURED_FEEDBACK in retry_content, (
            f"{label}: expected StructuredOutputGuardrail feedback ('{STRUCTURED_FEEDBACK}') "
            f"in retry request, but it was absent.\nUser messages: {retry_content!r}"
        )
        assert GROUNDING_FEEDBACK not in retry_content, (
            f"{label}: GroundingGuardrail feedback ('{GROUNDING_FEEDBACK}') must not appear "
            f"since that guardrail is disabled.\nUser messages: {retry_content!r}"
        )
