import pytest
from unittest.mock import Mock, patch
from jinja2 import Environment
from soprano_sdk.core.engine import WorkflowEngine
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.core.models import MessagePayload

class TestCollectorOptions:
    @pytest.fixture
    def engine(self):
        mock_engine = Mock(spec=WorkflowEngine)
        
        def mock_get_config(key, default=None):
            if key == "template_loader":
                return Environment()
            if key == "rollback_strategy":
                return "history_based"
            return default
            
        mock_engine.get_config_value.side_effect = mock_get_config
        mock_engine.workflow_description = "Test Workflow"
        mock_engine._get_humanization_config.return_value = {}
        
        # Mock _render_options based on the implementation in engine.py
        def mock_render(config, state, loader):
            if not config: 
                return None
            if config == "{{ opt_list }}":
                items = state.get("opt_list", [])
                return [{"text": str(i)} for i in items]
            return [{"text": str(i)} for i in config] if isinstance(config, list) else None
        
        mock_engine._render_options = mock_render
        mock_engine._humanize_message.return_value = MessagePayload("Humanized", options=[{"text": "H1"}])
        mock_engine.mfa_validator_steps = []
        return mock_engine

    def test_collect_input_renders_static_options(self, engine):
        step_config = {
            "id": "step1",
            "action": "collect_input_with_agent",
            "field": "test_field",
            "options": ["Opt 1", "Opt 2"],
            "agent": {"name": "test", "instructions": "test"}
        }
        strategy = CollectInputStrategy(step_config, engine)
        state = {}
        
        # In __init__, it just stays as config
        assert strategy.options == ["Opt 1", "Opt 2"]
        
        # Mock minimal parts to allow execute() to run the options rendering
        with patch("soprano_sdk.nodes.collect_input.initialize_state", side_effect=lambda x: x):
            with patch.object(CollectInputStrategy, '_apply_context_value'):
                # Force it to return early after rendering options by mocking a condition
                with patch.object(CollectInputStrategy, '_is_collecting', side_effect=TypeError("Stop here")):
                    try:
                        strategy.execute(state)
                    except TypeError:
                        pass
        
        # After execute (even if it errored later), it should be rendered/normalized
        assert strategy.options == [{"text": "Opt 1"}, {"text": "Opt 2"}]

    def test_collect_input_renders_dynamic_options(self, engine):
        step_config = {
            "id": "step1",
            "action": "collect_input_with_agent",
            "field": "test_field",
            "options": "{{ opt_list }}",
            "agent": {"name": "test", "instructions": "test"}
        }
        strategy = CollectInputStrategy(step_config, engine)
        state = {"opt_list": ["Dynamic A", "Dynamic B"]}
        
        with patch("soprano_sdk.nodes.collect_input.initialize_state", side_effect=lambda x: x):
            with patch.object(CollectInputStrategy, '_apply_context_value'):
                with patch.object(CollectInputStrategy, '_is_collecting', side_effect=TypeError("Stop here")):
                    try:
                        strategy.execute(state)
                    except TypeError:
                        pass
        
        assert strategy.options == [{"text": "Dynamic A"}, {"text": "Dynamic B"}]

    def test_collect_input_re_renders_on_every_execute(self, engine):
        step_config = {
            "id": "step1",
            "action": "collect_input_with_agent",
            "field": "test_field",
            "options": "{{ opt_list }}",
            "agent": {"name": "test", "instructions": "test"}
        }
        strategy = CollectInputStrategy(step_config, engine)
        
        # First turn
        state1 = {"opt_list": ["A"]}
        with patch("soprano_sdk.nodes.collect_input.initialize_state", side_effect=lambda x: x):
            with patch.object(CollectInputStrategy, '_apply_context_value'):
                with patch.object(CollectInputStrategy, '_is_collecting', side_effect=TypeError("Stop here")):
                    try:
                        strategy.execute(state1)
                    except TypeError:
                        pass
        assert strategy.options == [{"text": "A"}]
        
        # Second turn (state changed)
        state2 = {"opt_list": ["B"]}
        with patch("soprano_sdk.nodes.collect_input.initialize_state", side_effect=lambda x: x):
            with patch.object(CollectInputStrategy, '_apply_context_value'):
                with patch.object(CollectInputStrategy, '_is_collecting', side_effect=TypeError("Stop here")):
                    try:
                        strategy.execute(state2)
                    except TypeError:
                        pass
        assert strategy.options == [{"text": "B"}]
