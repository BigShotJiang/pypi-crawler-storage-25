import textwrap
from datetime import date, datetime, timedelta, timezone
from typing import Dict, Any, List, NamedTuple, Optional, Tuple
import json

from pydantic import ValidationError

from langgraph.types import interrupt

from .base import ActionStrategy
from ..agents.factory import AgentFactory, AgentAdapter
from ..utils.text_utils import (
    format_field_name, 
    extract_conversational_text as extract_text,
    filter_metadata,
    extract_pattern_match
)
from ..agents.structured_output import create_structured_output_model, validate_field_definitions, _get_status_population_guidelines
from ..core.constants import (
    COLLECT_INPUT_METADATA_FIELDS,
    build_option_guidelines,
    DEFAULT_OPTION_CHAR_LIMIT_ENABLED,
    OPTION_CHAR_LIMIT_KEY,
    MAX_OPTION_TEXT_LENGTH,
    WorkflowKeys,
    DEFAULT_MAX_ATTEMPTS,
    MAX_ATTEMPTS_MESSAGE,
    TransitionPattern,
    ResponseMarkers
)
from ..core.models import MessagePayload
from ..core.rollback_strategies import (
    RollbackStrategy,
    HistoryBasedRollback,
    DependencyBasedRollback
)
from ..core.state import initialize_state
from ..guardrails import GuardrailViolationError, GuardrailFailureResponse
from ..utils.logger import logger
from ..utils.tracing import trace_node_execution, trace_agent_invocation, trace_validation, add_node_result
from ..utils.parser import convert_to_dict
from ..utils.template import render_template_string

VALIDATION_ERROR_MESSAGE = "validation failed for the provided input, please enter valid input"


class ProcessedUserResponse(NamedTuple):
    """Return type for _process_user_response to signal rollback without polluting state."""
    state: Dict[str, Any]
    is_rollback: bool = False



def _format_options(options: List[Dict]) -> str:
    """Convert options list to a readable string: 'text - subtext'."""
    formatted = []

    for opt in options:
        if isinstance(opt, dict):
            text = opt.get("text", "")
            subtext = opt.get("subtext", "")

            if subtext:
                formatted.append(f"{text} - {subtext}")
            else:
                formatted.append(text)

    return "\n".join(formatted)

def _extract_conversational_text(content: str) -> str:
    """Extract human-readable text from assistant message content.
    
    Standardized wrapper around text_utils.extract_conversational_text.
    """
    return extract_text(content)


def _get_step_patterns(step_config_map: Optional[Dict[str, Any]], node_id: str) -> List[str]:
    """Extract transition patterns for a node from step configuration."""
    if not step_config_map:
        return []

    step = step_config_map.get(node_id, {})
    so_enabled = step.get('agent', {}).get('structured_output', {}).get('enabled', False)
    if so_enabled:
        return []

    patterns = []
    for t in step.get('transitions', []):
        p = t.get('pattern', [])
        if isinstance(p, str):
            patterns.append(p)
        else:
            patterns.extend(p)
    return patterns


def _extract_collected_data(
    node_execution_order: List[str],
    node_field_map: Dict[str, Any],
    state: Dict[str, Any],
    step_config_map: Optional[Dict[str, Any]] = None
) -> Tuple[List[str], Dict[str, Dict]]:
    """Extract confirmed field values and build conversation key mapping."""
    collected_lines = []
    # Map from conversation key to {label, field, patterns} for labeled history
    conv_key_to_info: Dict[str, Dict] = {}

    for node_id in node_execution_order:
        field_or_fields = node_field_map.get(node_id)
        if not field_or_fields:
            continue

        if isinstance(field_or_fields, str):
            fields = [field_or_fields]
            primary_field = field_or_fields
        else:
            fields = field_or_fields
            primary_field = fields[0]

        label = node_id.replace('_', ' ').title()
        patterns = _get_step_patterns(step_config_map, node_id)

        conv_key_to_info[f"{primary_field}_conversation"] = {
            "label": label,
            "field": primary_field,
            "patterns": patterns,
        }

        for field_name in fields:
            value = state.get(field_name)
            if value is not None:
                value = filter_metadata(value, COLLECT_INPUT_METADATA_FIELDS)
                display_name = field_name.replace('_', ' ').title()
                collected_lines.append(f"- {display_name}: {value}")
    
    return collected_lines, conv_key_to_info


def _aggregate_tagged_messages(
    conversations: Dict[str, List[Dict]],
    conv_key_to_info: Dict[str, Dict],
    extra_conv_keys: Optional[List[tuple]] = None
) -> List[Dict]:
    """Aggregate relevant conversation history chronologically with node tags."""
    if extra_conv_keys:
        for key, label in extra_conv_keys:
            conv_key_to_info[key] = {"label": label, "field": "", "patterns": []}

    all_messages = []
    for conv_key, info in conv_key_to_info.items():
        if conv_key in conversations and isinstance(conversations[conv_key], list):
            for msg in conversations[conv_key]:
                # Clone and add node info for sorting/rendering
                tagged_msg = msg.copy()
                tagged_msg["_label"] = info["label"]
                tagged_msg["_field"] = info["field"]
                tagged_msg["_patterns"] = info["patterns"]
                all_messages.append(tagged_msg)

    # Sort all messages by timestamp
    all_messages.sort(key=lambda m: str(m.get("timestamp", "")))
    return all_messages


def _format_conversation_history(all_messages: List[Dict]) -> List[str]:
    """Process tagged messages into readable conversation history sections."""
    conversation_sections = []
    current_label = None
    for msg in all_messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        label = msg.get("_label", "Unknown")
        msg_patterns = msg.get("_patterns", [])
        msg_field = msg.get("_field", "")

        text = None
        if role == "assistant":
            if msg_patterns:
                text = extract_pattern_match(content, msg_patterns, msg_field)
            
            if not text:
                text = _extract_conversational_text(content)
        elif role == "user":
            text = content

        if not text:
            continue

        if label != current_label:
            conversation_sections.append(f"[Step: {label}]")
            current_label = label

        display_role = "Agent" if role == "assistant" else "User"
        conversation_sections.append(f"{display_role}: {text}")
    
    return conversation_sections


def _build_workflow_context_summary(
    state: Dict[str, Any],
    extra_conv_keys: Optional[List[tuple]] = None,
    step_config_map: Optional[Dict[str, Any]] = None,
) -> str:
    """Build a summary of previously collected data and conversation history.

    Uses _node_execution_order, _node_field_map, and _conversations from state
    to construct a context block. Presents collected data as authoritative ground
    truth, with conversation history as supplementary context. Only includes
    conversational assistant messages (JSON-sourced), excluding extraction pattern
    responses to prevent the current agent from mimicking internal patterns.

    *extra_conv_keys* is an optional ordered list of (conv_key, display_label) tuples
    for conversations that are preserved in state but NOT in _node_execution_order.

    *step_config_map* is an optional dict of node_id -> step config dict (from the YAML),
    used to look up transition patterns for pattern-match nodes.

    Returns empty string if no previous data exists (first node in workflow).
    """
    node_execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
    node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
    conversations = state.get(WorkflowKeys.CONVERSATIONS, {})

    if not node_execution_order and not extra_conv_keys:
        return ""

    collected_lines, conv_key_to_info = _extract_collected_data(
        node_execution_order, node_field_map, state, step_config_map
    )
    
    all_messages = _aggregate_tagged_messages(
        conversations, conv_key_to_info, extra_conv_keys
    )
    
    conversation_sections = _format_conversation_history(all_messages)

    if not collected_lines and not conversation_sections:
        return ""

    parts = ["<workflow_state>"]
    if collected_lines:
        parts.append(
            "The following data has been collected and verified by prior workflow steps.\n"
            "Treat these values as ground truth. Do NOT re-ask for any value listed here."
        )
        parts.append("\nCOLLECTED DATA:\n" + "\n".join(collected_lines))

    if conversation_sections:
        parts.append(
            "\nThe following is a history of previous conversational turns and internal workflow transitions.\n"
            "Use this as narrative context to maintain dialogue continuity and understand previous user requests."
        )
        parts.append(
            "\nCONVERSATION HISTORY:\n" + "\n".join(conversation_sections)
        )

    parts.append("</workflow_state>")
    return "\n".join(parts)


INVALID_INPUT_MESSAGE = "Looks like the input is invalid. Please double-check and re-enter it."
COLLECTION_FAILURE_MESSAGE = "I couldn't understand your response. Please try again and provide the required information."



def _wrap_instructions_with_out_of_scope_detection(
    instructions: str,
    scope_description: str,
    with_structured_output: bool
) -> str:
    """Append out-of-scope detection instructions. Backward compatible - works with any scope_description."""
    return f"""{instructions}

<out_of_scope_detection>
OUT-OF-SCOPE DETECTION:
You are working within this context: 
{scope_description}

IMPORTANT: If the user's query is COMPLETELY UNRELATED to the workflow context above:
- {"Set out_of_scope to a brief description of what the user is trying to do" if with_structured_output else "Respond with: OUT_OF_SCOPE: <brief description of user intent>"}
- Do NOT attempt to answer the query or provide information about unrelated topics
- Do NOT confuse this with related questions or intent changes within the workflow

A query is OUT OF SCOPE only if it's about:
- Completely different products, services, or business domains not mentioned in the workflow context
- Actions or requests that have no connection to the workflow purpose
- Topics that are entirely unrelated to what this workflow is designed to handle

A query is IN SCOPE if it:
- Relates to any part of the workflow context described above
- Asks clarifying questions about the current or previous steps
- Requests to change or correct previously collected information (this is an intent change, not out-of-scope)
</out_of_scope_detection>
"""


def _wrap_instructions_with_options_data_guidance(instructions: str, max_chars: Optional[int] = None, compute_available: bool = True) -> str:
    """
    Wrap instructions with OPTIONS_DATA marker guidance for pattern matching mode.
    Only called when NOT using structured output.
    """
    return f"""{instructions}

<options_formatting>
OPTIONS FORMATTING:

{build_option_guidelines(max_chars=max_chars, compute_available=compute_available)}

When presenting options to the user (single question only):
1. Write your message text WITHOUT listing the options — the UI renders them as buttons/list items
2. Place ALL options ONLY in the {ResponseMarkers.OPTIONS_DATA} marker at the end of your response
3. CRITICAL: The {ResponseMarkers.OPTIONS_DATA} value MUST be a single valid JSON object on ONE LINE
4. If the message contains MULTIPLE questions, do NOT use the {ResponseMarkers.OPTIONS_DATA} marker — include all questions directly in the message text

Format:
{ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "...", "subtext": "..."}}, ...], "is_selectable": true/false}}

Examples:
- Selectable options with pricing (single question):
  Please choose your plan:
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Basic", "subtext": "Free"}}, {{"text": "Pro", "subtext": "$9/month"}}, {{"text": "Enterprise", "subtext": "$49/month"}}], "is_selectable": true}}

- Simple yes/no (single question, no subtext):
  Would you like to proceed?
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Yes", "subtext": ""}}, {{"text": "No", "subtext": ""}}], "is_selectable": true}}

- Clickable links (not selectable):
  For more information, visit:
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Help Center", "subtext": "https://example.com/help"}}, {{"text": "Support Portal", "subtext": "https://example.com/support"}}], "is_selectable": false}}

- Multiple questions (NO options marker):
  What is your order ID? And what is the reason for the return?
</options_formatting>

<status_field>
STATUS REPORTING:

You MUST include a {ResponseMarkers.STATUS_FIELD} marker at the end of your response (after any {ResponseMarkers.OPTIONS_DATA} marker if present) to indicate the current collection status.

Format:
{ResponseMarkers.STATUS_FIELD} <status_value>

{_get_status_population_guidelines(mode="pm_prompt")}

Always include this marker. Place it on its own line at the very end of your response.

FORMATTING RULES:
- Do NOT use markdown formatting anywhere in your response: no backticks (`), no code blocks (```), no bold (**), no headers (#)
- The {ResponseMarkers.STATUS_FIELD} line must immediately follow the last line of your response with no separators between them
- Plain text only

Examples:
  What is your order ID?
  {ResponseMarkers.STATUS_FIELD} collecting

  That order ID is invalid. Please provide a valid order ID.
  {ResponseMarkers.STATUS_FIELD} failed

  Thank you! I have everything I need.
  {ResponseMarkers.STATUS_FIELD} success

  AMB charges cover ambient service fees applied monthly to your account.
  {ResponseMarkers.STATUS_FIELD} answering

  Please choose your plan:
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Basic", "subtext": "Free"}}, {{"text": "Pro", "subtext": "$9/month"}}], "is_selectable": true}}
  {ResponseMarkers.STATUS_FIELD} collecting

  CARD_ACTION_CAPTURED: BlockCard
  {ResponseMarkers.STATUS_FIELD} success
</status_field>
"""


def _wrap_instructions_with_intent_detection(
        instructions: str,
        collector_nodes: Dict[str, str],
        with_structured_output: bool
) -> str:
    if not collector_nodes:
        return instructions

    collector_nodes_str = "\n".join(f"{node_name}: {description}" for node_name, description in collector_nodes.items())
    return f"""
{instructions}

<intent_detection>
AVAILABLE CONVERSATION INTENTS:
{collector_nodes_str}

Format: <node_name>: <intent_description>

CRITICAL INTENT DETECTION RULES:
1. ONLY check for intent changes against the EXACT node names listed above
2. The node name MUST appear in the list above to be valid
3. Do NOT infer, guess, or create new intent names
4. Tool calls are NOT intent changes
5. If no intents are listed above, NEVER trigger an intent change
6. If the user's query contains information for an intent that is already present in the COLLECTED DATA section of the workflow state below, do NOT trigger an intent change for that node unless the user is EXPLICITLY asking to change or correct it. Providing information that has already been collected as part of a multi-intent message or a confirmation (e.g. "my name is already John") is NOT an intent change.

Before responding, analyze if the user's query matches a DIFFERENT intent from the list above:

IF the user's query clearly matches a DIFFERENT intent that EXISTS in the list above:
- {"Respond ONLY with: INTENT_CHANGE: <node_name>" if not with_structured_output else "modify intent_change value <node_name>"}
- Use the EXACT node_name from the list above
- Do NOT provide any other response
- Do NOT answer the user's question

IF the user's query continues with the SAME intent OR does not match any intent in the list above:
- Proceed with your normal response
- Do NOT mention intent detection
</intent_detection>
"""

def _wrap_instructions_with_allowed_markers_constraint(
    instructions: str,
    transitions: List[Dict[str, Any]],
    enable_intent_change: bool,
    enable_out_of_scope: bool,
) -> str:
    """Append an explicit constraint block listing every marker the LLM is
    allowed to emit in pattern-matching mode.

    This prevents the model from hallucinating novel markers or mixing up
    pattern-matching signals with free-form text.  The section combines:

    - YAML-defined transition patterns (from the step's ``transitions`` list)
    - Active internal system markers (INTENT_CHANGE:, OPTIONS_DATA:, OUT_OF_SCOPE:)

    Only called when NOT using structured output.
    """
    # Collect YAML-defined transition patterns (flatten single string or list)
    yaml_patterns: List[str] = []
    for t in transitions:
        raw = t.get('pattern', [])
        if isinstance(raw, str):
            yaml_patterns.append(raw)
        else:
            yaml_patterns.extend(raw)

    lines: List[str] = []

    if yaml_patterns:
        lines.append("Data capture markers (defined in this step's configuration):")
        for pat in yaml_patterns:
            lines.append(f"  - {pat} <captured value>")

    separator = "\n" if yaml_patterns else ""
    lines.append(f"{separator}System control markers:")
    lines.append(f"  - {ResponseMarkers.OPTIONS_DATA} {{\"options\": [...], \"is_selectable\": true/false}}  (ONLY when presenting selectable options)")

    if enable_intent_change:
        lines.append(f"  - {TransitionPattern.INTENT_CHANGE.value} <node_name>  (ONLY when the user explicitly wants to change a previously answered topic)")

    if enable_out_of_scope:
        lines.append(f"  - {TransitionPattern.OUT_OF_SCOPE_PATTERN.value} <brief reason>  (ONLY when the request is completely outside this workflow's scope)")

    lines.append(f"- {ResponseMarkers.STATUS_FIELD} collecting|answering|success|failed  (REQUIRED — always the last line)")
    constraint_body = "\n".join(lines)

    return f"""{instructions}

<allowed_response_markers>
FINAL ANSWER FORMAT — ALLOWED MARKERS ONLY:
Your final answer MUST use only the markers listed below. Do NOT invent new markers or alter marker names.
When none of these markers apply, respond with plain conversational text only.
Do NOT use markdown formatting anywhere: no backticks (`), no code blocks (```), no bold (**), no headers (#).

{constraint_body}
  
</allowed_response_markers>
"""


def _create_rollback_strategy(strategy_name: str) -> RollbackStrategy:
    if strategy_name == "dependency_based":
        return DependencyBasedRollback()
    elif strategy_name == "history_based":
        return HistoryBasedRollback()
    else:
        logger.warning(f"Unknown rollback strategy '{strategy_name}', using history_based")
        return HistoryBasedRollback()

class CollectInputStrategy(ActionStrategy):
    def __init__(self, step_config: Dict[str, Any], engine_context: Any):
        super().__init__(step_config, engine_context)

        # Support both single field and multiple fields
        self.field = step_config.get('field')           # legacy single-field
        self.fields = step_config.get('fields', [])     # new multi-field

        if self.fields:
            self.is_multi_field = True
            self.primary_field = self.fields[0]
        elif self.field:
            self.is_multi_field = False
            self.fields = [self.field]
            self.primary_field = self.field
        else:
            raise RuntimeError(f"Step '{self.step_id}' missing 'field' or 'fields'")

        self.agent_config = step_config.get('agent', {})
        max_attempts = step_config.get("max_attempts")

        self.max_attempts = (
            max_attempts
            if max_attempts is not None
            else engine_context.get_config_value("max_retry_limit", DEFAULT_MAX_ATTEMPTS)
        )
        
        self.on_max_attempts_reached = step_config.get('on_max_attempts_reached')
        self.transitions = self._get_transitions()
        self.next_step = self.step_config.get("next", None)
        self.is_structured_output = self.agent_config.get("structured_output", {}).get("enabled", False)

        self.options = step_config.get("options", []) or []
        self.is_selectable = step_config.get("is_selectable", False)

        option_char_limit_enabled = step_config.get(
            OPTION_CHAR_LIMIT_KEY, DEFAULT_OPTION_CHAR_LIMIT_ENABLED
        )
        self.option_max_chars = MAX_OPTION_TEXT_LENGTH if option_char_limit_enabled else None

        # Out-of-scope detection configuration (disabled by default)
        self.enable_out_of_scope = self.agent_config.get("detect_out_of_scope", False)

        if explicit_scope := self.agent_config.get("scope_description"):
            self.scope_description = explicit_scope
        else:
            workflow_desc = engine_context.workflow_description
            fields_label = ", ".join(self.fields)
            agent_desc = self.agent_config.get("description", f"collecting {fields_label}")
            self.scope_description = f"{workflow_desc}. Currently: {agent_desc}"

        # Resolve guardrails by name from the engine's registry (ordered list)
        guardrail_names = self.agent_config.get("guardrails", [])
        guardrail_registry = getattr(engine_context, 'guardrail_registry', {})
        self.output_guardrails = [
            guardrail_registry[name] for name in guardrail_names
            if name in guardrail_registry
        ]
        if self.output_guardrails:
            logger.info(f"Step '{self.step_id}': loaded {len(self.output_guardrails)} guardrail(s)")

        rollback_strategy_name = engine_context.get_config_value("rollback_strategy", "history_based")
        self.rollback_strategy = _create_rollback_strategy(rollback_strategy_name)
        logger.info(f"Using rollback strategy: {self.rollback_strategy.get_strategy_name()}")

        self.field_validators = {}
        if validator_function_path := self.step_config.get("validator"):
            self.field_validators[self.primary_field] = self.engine_context.function_repository.load(validator_function_path)
        if validators_config := step_config.get('validators'):
            for field_name, validator_path in validators_config.items():
                self.field_validators[field_name] = self.engine_context.function_repository.load(validator_path)

        if not self.agent_config:
            raise RuntimeError(f"Step '{self.step_id}' missing required 'agent' configuration")

    @property
    def _conversation_key(self) -> str:
        return f'{self.primary_field}_conversation'

    def pre_execute(self, state: Dict[str, Any]) -> None:
        pass

    @property
    def _formatted_field_name(self) -> str:
        if self.is_multi_field:
            return ', '.join(f.replace('_', ' ').title() for f in self.fields)
        return self.primary_field.replace('_', ' ').title()

    def _trace_node_result(self, span, state: Dict[str, Any]):
        """Add trace results for all fields in this step."""
        status = state.get(WorkflowKeys.STATUS)
        for field_name in self.fields:
            add_node_result(span, field_name, state.get(field_name), status)

    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        with trace_node_execution(
            node_id=self.step_id,
            node_type="collect_input_with_agent",
            output_field=self.primary_field
        ) as span:
            state = initialize_state(state)
            
            # Render and normalize options using current state
            from jinja2 import Environment
            template_loader = self.engine_context.get_config_value("template_loader", Environment())
            self.options = self.engine_context._render_options(
                self.step_config.get("options"), state, template_loader
            )
            
            self._apply_context_value(state, span)

            # Reset attempts counter on fresh entry
            if not self._is_collecting(state):
                self._reset_attempt_counter(state)

            conversation = self._get_or_create_conversation(state)

            # Self-loop with pending prompt: interrupt for user input, then process
            pending_prompt = state.get(WorkflowKeys.PENDING_PROMPT)
            if self._is_collecting(state) and pending_prompt is not None:
                state[WorkflowKeys.PENDING_PROMPT] = None
                user_input = interrupt(pending_prompt)
                conversation.append({"role": "user", "content": user_input})
                span.add_event("user.input_received", {"input_length": len(user_input)})

                self._increment_attempt_counter(state)

                result = self._process_user_response(state, conversation, span=span)
                state = result.state

                # Intent change produced a rollback state —
                # return it directly without adding the current node to execution order.
                if result.is_rollback:
                    return state

                # If still collecting (validation failed, etc.), store next prompt
                if self._is_collecting(state) and not state.get(WorkflowKeys.PENDING_PROMPT):
                    if self._max_attempts_reached(state):
                        return self._handle_max_attempts(state)
                    prompt_data = self._get_continuation_prompt(conversation)
                    if prompt_data:
                        if (special_result := self._handle_special_responses(
                            prompt_data, state, user_message=user_input, span=span)) is not None:
                            return special_result

                        state[WorkflowKeys.PENDING_PROMPT] = self._sanitize_pending_prompt(prompt_data)
                        self._update_conversation(state, conversation)
                        return state

                self._trace_node_result(span, state)
                return self._add_node_to_execution_order(state)

            # First entry
            if not self._is_collecting(state):
                if self.rollback_strategy.should_save_snapshot():
                    self._save_snapshot_before_execution(state)

            if self._is_field_pre_populated(state):
                span.add_event("field.pre_populated", {
                    "fields": str({f: state.get(f) for f in self.fields})
                })
                state = self._handle_pre_populated_field(state, conversation)

                # If validation failed, store next prompt for the self-loop
                if self._is_collecting(state):
                    prompt_data = self._get_continuation_prompt(conversation)
                    if prompt_data:
                        state[WorkflowKeys.PENDING_PROMPT] = prompt_data
                        self._update_conversation(state, conversation)
                        return state

                self._trace_node_result(span, state)
                return self._add_node_to_execution_order(state)

            if self._max_attempts_reached(state):
                span.add_event("max_attempts.reached")
                return self._handle_max_attempts(state)

            agent = self._create_agent(state)

            prompt_data = self._generate_prompt(agent, conversation, state)

            # Persist LLM status from the prompt generation response
            if prompt_data is not None:
                if prompt_data.get("status") is not None:
                    state[WorkflowKeys.LLM_STATUS] = prompt_data["status"]
                else:
                    logger.warning(
                        f"Collector '{self.primary_field}': LLM did not include 'status' in its response — "
                        "LLM_STATUS will not be updated for this turn. Check prompt guidance."
                    )

            # If agent extracted from workflow context, handle as pre-populated
            if prompt_data is None:
                if self._is_field_pre_populated(state):
                    span.add_event("field.extracted_from_context", {
                        "fields": str({f: state.get(f) for f in self.fields})
                    })
                    state = self._handle_pre_populated_field(state, conversation)
                    if not self._is_field_pre_populated(state):  # Validation Failed
                        state[WorkflowKeys.PENDING_PROMPT] = self._get_continuation_prompt(conversation)
                    self._trace_node_result(span, state)
                    return self._add_node_to_execution_order(state)
                else:
                    # Agent returned no prompt and did not extract data - treat as collection failure
                    self._set_status(state, 'collecting')
                    state = self._handle_collection_failure(state, conversation)
                    prompt_data = self._get_continuation_prompt(conversation)
                    if prompt_data:
                        state[WorkflowKeys.PENDING_PROMPT] = self._sanitize_pending_prompt(prompt_data)
                        self._update_conversation(state, conversation)
                        return state

            if prompt_data is not None:
                # Check for out-of-scope / intent change on first entry
                # Done before the text check so structured output intent_change
                # with an empty bot_response is not silently dropped.
                user_msg = state.get(WorkflowKeys.USER_MESSAGE, "")
                if (special_result := self._handle_special_responses(prompt_data, state, user_message=user_msg, span=span)) is not None:
                    return special_result

                if prompt_data.get("text") is not None:
                    # Store prompt in state and return so LangGraph checkpoints
                    # before interrupt() is called on the self-loop re-entry.
                    sanitized = self._sanitize_pending_prompt(prompt_data)
                    state[WorkflowKeys.PENDING_PROMPT] = sanitized
                    self._set_status(state, 'collecting')
                    self._update_conversation(state, conversation)
                    return state

            # No prompt needed — fall through without interrupting
            self._update_conversation(state, conversation)
            self._trace_node_result(span, state)

        return self._add_node_to_execution_order(state)

    def _process_user_response(
        self,
        state: Dict[str, Any],
        conversation: List[Dict[str, str]],
        span=None
    ) -> ProcessedUserResponse:
        """Process user input after interrupt: invoke agent and handle transitions."""
        agent = self._create_agent(state)

        with trace_agent_invocation(
            agent_name=self.agent_config.get('name', self.primary_field),
            model=self.agent_config.get('model', 'default')
        ):
            agent_response = self._get_agent_response(agent, conversation, state)

            self._update_user_message_utilized(state, True)

        # Early exit: guardrail fired — error message already in conversation,
        # stay in collecting state so the user is re-prompted.
        if isinstance(agent_response, GuardrailFailureResponse):
            logger.info(f"Step '{self.step_id}': guardrail failure, staying in collecting state")
            self._update_conversation(state, conversation)
            return ProcessedUserResponse(state)

        user_message = next(
            (msg['content'] for msg in reversed(conversation) if msg['role'] == 'user'),
            ""
        )

        if self.is_structured_output:
            result = self._handle_structured_output_transition(state, conversation, agent_response, user_message, span=span)
            self._update_conversation(result, conversation)
            is_rollback = result is not state
            return ProcessedUserResponse(result, is_rollback=is_rollback)

        if (special_result := self._handle_special_responses(agent_response, state, user_message=user_message, span=span)) is not None:
            return ProcessedUserResponse(special_result, is_rollback=True)

        state = self._process_transitions(state, conversation, agent_response)
        self._update_conversation(state, conversation)
        return ProcessedUserResponse(state)

    def _render_template_string(self, template_str: str, state: Dict[str, Any]) -> str:
        template_loader = self.engine_context.get_config_value('template_loader')
        return render_template_string(template_str, state, template_loader)

    def _should_humanize_prompt(self) -> bool:
        """Determine if initial prompts should be humanized."""
        from ..core.constants import DEFAULT_HUMANIZATION_ENABLED, HumanizationKeys

        # Check workflow-level setting (default: enabled)
        workflow_humanization = self.engine_context._get_humanization_config()
        workflow_enabled = workflow_humanization.get(
            HumanizationKeys.ENABLED,
            DEFAULT_HUMANIZATION_ENABLED
        )

        if not workflow_enabled:
            return False

        return self.agent_config.get('humanize', DEFAULT_HUMANIZATION_ENABLED)

    def _apply_humanization(self, message: str, state: Dict[str, Any]) -> str:
        """Apply template rendering and humanization to a message.

        This is a common helper used by validation failures, collection failures,
        and max attempts messages to ensure consistent localization and humanization.
        """
        # Apply template rendering (for variables like {field})
        message = self._render_template_string(message, state)

        # Apply humanization if enabled
        if self._should_humanize_prompt():
            result = self.engine_context._humanize_message(
                message, state, self.options, self.is_selectable
            )
            message = result.message
            # Update instance variables with humanized options (may have been detected/generated)
            if result.options is not None:
                self.options = result.options
            if result.is_selectable is not None:
                self.is_selectable = result.is_selectable

        return message
    
    def _update_user_message_utilized(self, state: Dict[str, Any], utilized: bool = True) -> None:
        """Set a flag in state to indicate whether the user's message has been utilized by the agent."""
        state[WorkflowKeys.USER_MESSAGE_UTILIZED] = utilized

    def _get_agent_response(self, agent: AgentAdapter, conversation: List[Dict[str, str]], state: Dict[str, Any]) -> Any:
        """Get agent response and add the valid response to conversation.

        Guardrails run inside agent.invoke() via the adapter, which handles all retries
        internally. Once the adapter exhausts its retries it raises GuardrailViolationError;
        this method catches that and returns a GuardrailFailureResponse sentinel so the
        caller stays in collecting state without mutating the stored conversation.
        """
        # Set grounding context so the adapter can forward it to grounding guardrails
        if self.output_guardrails:
            agent.guardrail_context = {
                "grounding_source": self._build_grounding_source(state, agent),
                "query": next(
                    (msg['content'] for msg in reversed(conversation) if msg['role'] == 'user'), ""
                ),
                "function_outputs": self._build_function_outputs(state),
                "node_execution_order": state.get(WorkflowKeys.NODE_EXECUTION_ORDER, []),
            }

        try:
            # Pass a local copy so adapter retry feedback messages don't pollute the stored conversation
            agent_response = agent.invoke(list(conversation))
        except GuardrailViolationError as gve:
            logger.warning(f"Step '{self.step_id}': guardrail retries exhausted — {gve.error_message}")
            message_key = "bot_response" if self.is_structured_output else "text"
            content_data = {
                message_key: gve.error_message,
                "options": self.options,
                "is_selectable": self.is_selectable,
            }
            conversation.append({"role": "assistant", "content": json.dumps(content_data)})
            return GuardrailFailureResponse(gve.error_message)

        logger.info(f"Agent raw response: {agent_response}")
        response_str = str(agent_response)

        if not self.is_structured_output:
            # Storing control signals (INTENT_CHANGE:, OUT_OF_SCOPE:) in history
            # allows subsequent turns to be aware of these events.
            # They are humanized into markers by history extraction utilities.
            conversation.append({"role": "assistant", "content": response_str})
        else:
            content = json.dumps(agent_response) if isinstance(agent_response, dict) else response_str
            conversation.append({"role": "assistant", "content": content})

        return agent_response

    def _build_grounding_source(self, state: Dict[str, Any], agent: AgentAdapter) -> str:
        """Assemble grounding source from agent instructions, workflow state, and tool outputs."""
        parts = []

        collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})
        instructions = self._get_instructions(state, collector_nodes)
        parts.append(f"AGENT INSTRUCTIONS:\n{instructions}")

        extra_conv_keys = self._get_extra_conv_keys(state)
        workflow_context = _build_workflow_context_summary(state, extra_conv_keys=extra_conv_keys, step_config_map=getattr(self.engine_context, 'step_map', None))
        if workflow_context:
            parts.append(f"WORKFLOW DATA:\n{workflow_context}")

        if hasattr(agent, 'last_tool_outputs') and agent.last_tool_outputs:
            tool_text = "\n".join(agent.last_tool_outputs)
            parts.append(f"TOOL OUTPUTS:\n{tool_text}")

        return "\n\n".join(parts)

    def _build_function_outputs(self, state: Dict[str, Any]) -> List[str]:
        """Collect call_function / call_async_function outputs as individual strings."""
        outputs = []
        for field_name in state.get(WorkflowKeys.COMPUTED_FIELDS, []):
            value = state.get(field_name)
            if value is not None:
                outputs.append(f"{field_name}: {value}")
        return outputs

    def _extract_conversational_text(self, agent_response: Any) -> Optional[str]:
        """Extract the conversational text from an agent response for grounding check.

        Returns None if the response is a pure extraction (no user-facing text).
        """
        if self.is_structured_output:
            if isinstance(agent_response, dict):
                bot_response = agent_response.get("bot_response")
                if bot_response and str(bot_response).strip():
                    return str(bot_response)
            return None

        # Pattern matching mode: skip if response matches a transition pattern
        response_str = str(agent_response)
        for transition in self.transitions:
            patterns = transition.get('pattern', [])
            if isinstance(patterns, str):
                patterns = [patterns]
            for pattern in patterns:
                if pattern in response_str:
                    return None  # Extraction-only response

        return response_str if response_str.strip() else None


    def _apply_context_value(self, state: Dict[str, Any], span) -> None:
        for field_name in self.fields:
            context_value = self.engine_context.get_context_value(field_name)
            if context_value is not None:
                logger.info(f"Using context value for '{field_name}': {context_value}")
                state[field_name] = context_value
                span.add_event("context.value_used", {"field": field_name, "value": str(context_value)})

    def _add_node_to_execution_order(self, state):
        if self._is_collecting(state):
            return state

        self._register_node_execution(state)
        self._register_collector_node(state)

        return state

    def _is_collecting(self, state: Dict[str, Any]) -> bool:
        return state.get(WorkflowKeys.STATUS) == f'{self.step_id}_collecting'

    def _get_continuation_prompt(self, conversation: List[Dict[str, str]]) -> Optional[Dict[str, Any]]:
        """Return the last assistant message with conversational text as a prompt dict for the self-loop.

        Used when the node needs another round of user input (validation failed, etc.)
        and the prompt is already in conversation — no LLM call needed.

        Iterates backwards through the conversation to find the most recent assistant
        message that contains a non-null user-facing message. This skips SO responses
        where bot_response is null (data extraction only, no re-prompt intended).
        """
        for msg in reversed(conversation):
            if msg['role'] != 'assistant':
                continue
            try:
                content_data = json.loads(msg['content'])
                # Check "bot_response" first (structured output mode), fall back to "text" for
                # backward compatibility with older conversation histories.
                message_text = content_data.get("bot_response") or content_data.get("text")
                if message_text:
                    return {
                        "text": message_text,
                        "options": content_data.get("options", self.options),
                        "is_selectable": content_data.get("is_selectable", self.is_selectable),
                    }
            except (json.JSONDecodeError, TypeError):
                result = self._extract_options_from_response(msg['content'])
                if result.message:
                    return {
                        "text": result.message,
                        "options": result.options,
                        "is_selectable": result.is_selectable,
                    }
        return None

    def _save_snapshot_before_execution(self, state: Dict[str, Any]):
        state_history = state.get(WorkflowKeys.STATE_HISTORY, [])
        execution_index = len(state_history)
        self.rollback_strategy.save_snapshot(state, self.step_id, execution_index)

    def _register_node_execution(self, state: Dict[str, Any]):
        execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        if self.step_id not in execution_order:
            execution_order.append(self.step_id)
        state[WorkflowKeys.NODE_EXECUTION_ORDER] = execution_order

    def _register_collector_node(self, state: Dict[str, Any]):
        collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})
        raw_description = self.agent_config.get('description', f"Collecting {self.primary_field}")
        description = self._render_template_string(raw_description, state)
        collector_nodes[self.step_id] = description
        state[WorkflowKeys.COLLECTOR_NODES] = collector_nodes

        # Register all fields in the node_field_map
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
        if self.is_multi_field:
            node_field_map[self.step_id] = self.fields  # Store as list
        else:
            node_field_map[self.step_id] = self.primary_field
        state[WorkflowKeys.NODE_FIELD_MAP] = node_field_map

    def _is_field_pre_populated(self, state: Dict[str, Any]) -> bool:
        """Check if ALL fields are already populated."""
        return all(state.get(f) is not None for f in self.fields)

    def _check_context_extraction(self, agent_response: str, state: Dict[str, Any]) -> bool:
        """Check if the agent extracted data from workflow context instead of asking a question.

        When previous workflow context contains the information this node needs,
        the agent may respond with an extraction pattern rather than an opening question.
        This method detects that case and pre-populates the field in state.

        Returns True if extraction succeeded and field(s) are now populated.
        """
        if self.is_structured_output:
            try:
                response_dict = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
                bot_response = response_dict.get("bot_response")
                if bot_response and str(bot_response).strip():
                    return False  # Agent is asking a question, not extracting
                if response_dict.get("intent_change"):
                    return False  # Agent signals intent change, not context extraction
                if response_dict.get("out_of_scope"):
                    return False  # Agent signals out-of-scope, not context extraction

                so_model = self._create_structured_output_model(
                    state.get(WorkflowKeys.COLLECTOR_NODES, {}), state
                )
                validated = so_model.model_validate(response_dict)
                validated_data = validated.model_dump()

                # Check required fields are present (same as _handle_structured_output_transition)
                structured_config = self.agent_config.get('structured_output', {})
                fields_config = structured_config.get('fields', [])
                for field_def in fields_config:
                    field_name = field_def.get("name")
                    is_required = field_def.get("required", True)
                    if field_name in COLLECT_INPUT_METADATA_FIELDS or is_required is False:
                        continue
                    if validated_data.get(field_name) is None:
                        return False

                if self.is_multi_field:
                    self._store_field_values(state, validated_data)
                else:
                    self._store_field_value(state, validated_data)
                    self.engine_context._store_partial_data(state, self.primary_field, validated_data)
                return self._is_field_pre_populated(state)
            except (json.JSONDecodeError, TypeError, ValidationError):
                return False
        else:
            # Pattern matching mode: check if response matches any transition pattern
            result = self._extract_options_from_response(agent_response)
            cleaned_response = result.message
            if result.status is not None:
                state[WorkflowKeys.LLM_STATUS] = result.status
            for transition in self.transitions:
                patterns = transition['pattern']
                if isinstance(patterns, str):
                    patterns = [patterns]
                for pattern in patterns:
                    if pattern in cleaned_response:
                        self._store_field_value(state, cleaned_response)
                        return self._is_field_pre_populated(state)
            return False

    def _get_missing_fields(self, state: Dict[str, Any]) -> List[str]:
        """Return list of fields that are still None."""
        return [f for f in self.fields if state.get(f) is None]

    def _validate_collected_input(self, state: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Validate collected fields using per-field validators."""
        errors = []
        validation_errors = {}
        for field_name in self.fields:
            if field_name in self.field_validators and state.get(field_name) is not None:
                validator = self.field_validators[field_name]
                with trace_validation(self.step_id, field_name) as span:
                    
                    is_valid, error_msg = validator(**state)
                    if span and span.is_recording():
                        span.set_attribute("input.value", str(state))
                        span.set_attribute("output.value", str([is_valid, error_msg]))
                if not is_valid:
                    # Capture the failed value before clearing
                    validation_errors[field_name] = {"value": state[field_name], "error": error_msg}
                    # Clear the invalid field so agent asks again
                    state[field_name] = None
                    if self.is_multi_field:
                        errors.append(f"{field_name}: {error_msg}")
                    else:
                        errors.append(error_msg)

        state[WorkflowKeys.VALIDATION_ERRORS] = validation_errors

        if errors:
            return False, "\n".join(errors)

        return True, None

    def _handle_pre_populated_field(self, state: Dict[str, Any], conversation: List) -> Dict[str, Any]:
        logger.info(f"Fields {self.fields} are populated, skipping collection")

        next_step = None

        # Step 1: Match transitions and clean pattern-prefixed values
        if self.transitions:
            if self.is_structured_output:
                if self.is_multi_field:
                    response_dict = {f: state.get(f) for f in self.fields}
                else:
                    field_value = state.get(self.primary_field)
                    response_dict = field_value if isinstance(field_value, dict) else {}
                next_step = self._find_matching_transition(response_dict)
            else:
                # Pattern matching: strip pattern prefix and re-store the clean value
                field_value = str(state.get(self.primary_field, ''))
                for transition in self.transitions:
                    patterns = transition.get('pattern', [])
                    if isinstance(patterns, str):
                        patterns = [patterns]
                    for pattern in patterns:
                        if pattern in field_value:
                            clean_value = field_value.split(pattern)[1].strip()
                            self._store_field_value(state, clean_value)
                            next_step = transition['next']
                            break
                    if next_step:
                        break

            # Fall back to first transition if no match
            # TODO: remove this behaviour in future release
            if not next_step:
                next_step = self.transitions[0]['next']

        elif self.next_step:
            next_step = self.next_step

        if self.is_structured_output:
            is_valid_input, validator_error_message = self._validate_collected_input(state)
        elif state.get(self.primary_field):  # Pattern Matching
            is_valid_input, validator_error_message = self._validate_collected_input(state)
        else:
            is_valid_input, validator_error_message = True, None

        if not is_valid_input:
            self._set_status(state, "collecting")
            pre_populated_values = {f: state.get(f) for f in self.fields}
            conversation.append({"role": "user", "content": str(pre_populated_values)})
            return self._handle_validation_failure(state, conversation, message=validator_error_message)

        # Step 3: Set status and outcome
        if next_step:
            self._set_status(state, next_step)
            if next_step in self.engine_context.outcome_map:
                self._set_outcome(state, next_step)

        # Record the skip turn before returning to ensure it appears in the history summary
        # (Skip transitions are 'silent' otherwise)
        if is_valid_input:
            if pre_populated_values := {f: state.get(f) for f in self.fields if state.get(f)}:
                if self.is_structured_output:
                    structured_config = self.agent_config.get('structured_output', {}) if self.agent_config else {}
                    fields_config = structured_config.get('fields', [])
                    required_fields = [
                        f.get("name") for f in fields_config
                        if f.get("name") and f.get("name") not in COLLECT_INPUT_METADATA_FIELDS and f.get("required", True) is not False
                    ]
                    all_required_populated = not required_fields or all(
                        state.get(field_name) not in [None, '']
                        for field_name in required_fields
                    )
                    if all_required_populated:
                        state[WorkflowKeys.LLM_STATUS] = "success"
                        content = {"bot_response": None, **pre_populated_values}
                    else:
                        content = pre_populated_values
                else:
                    content = pre_populated_values
                conversation.append({
                    "role": "assistant",
                    "content": json.dumps(content)
                })
                self._update_conversation(state, conversation)

        return state

    def _reset_attempt_counter(self, state: Dict[str, Any]) -> None:
        attempt_counts = state.setdefault(WorkflowKeys.ATTEMPT_COUNTS, {})
        attempt_counts[self.step_id] = 0

    def _increment_attempt_counter(self, state: Dict[str, Any]) -> None:
        attempt_counts = state.setdefault(WorkflowKeys.ATTEMPT_COUNTS, {})
        attempt_counts[self.step_id] = attempt_counts.get(self.step_id, 0) + 1

    def _max_attempts_reached(self, state: Dict[str, Any]) -> bool:
        attempt_counts = state.get(WorkflowKeys.ATTEMPT_COUNTS) or {}
        attempt_count = attempt_counts.get(self.step_id, 0)
        return attempt_count >= self.max_attempts

    def _handle_max_attempts(self, state: Dict[str, Any]) -> Dict[str, Any]:
        logger.warning(f"Max attempts reached for field '{self.primary_field}'")
        self._set_status(state, 'max_attempts')
        state[WorkflowKeys.LLM_STATUS] = "failed"
        if self.on_max_attempts_reached:
            message = self.on_max_attempts_reached
        else:
            message = MAX_ATTEMPTS_MESSAGE.format(field=self.primary_field)

        # Apply template rendering and humanization
        message = self._apply_humanization(message, state)

        state[WorkflowKeys.MESSAGES] = [message]
        state = self._add_node_to_execution_order(state)
        return state

    def _get_or_create_conversation(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})

        if self._conversation_key not in conversations:
            new_conv = []
            initial_user_msg = state.get(WorkflowKeys.USER_MESSAGE)
            if initial_user_msg and str(initial_user_msg).strip() and not conversations:
                current_time = datetime.now(timezone.utc).isoformat(timespec='microseconds').replace("+00:00", "Z")
                new_conv.append({
                    "role": "user", 
                    "content": str(initial_user_msg),
                    "timestamp": current_time
                })

            conversations[self._conversation_key] = new_conv
            state[WorkflowKeys.CONVERSATIONS] = conversations

        return conversations[self._conversation_key]
        
    def _get_extra_conv_keys(self, state: Dict[str, Any]) -> List[Tuple[str, str]]:
        """
        Collect conversation keys that were not part of the main rendered workflow.

        Returns:
            List of tuples: (conversation_key, display_label)
        """
        conversations: Dict[str, Any] = state.get(WorkflowKeys.CONVERSATIONS) or {}
        if not conversations:
            return []

        rendered_node_ids = set(state.get(WorkflowKeys.NODE_EXECUTION_ORDER) or [])

        # Engine-level map is the source of truth
        field_map = getattr(self.engine_context, "collector_node_field_map", {}) or {}

        extra_keys: List[Tuple[str, str]] = []

        for step in getattr(self.engine_context, "steps", []):
            node_id = step.get("id")
            if not node_id:
                continue

            # Skip nodes already rendered
            if node_id in rendered_node_ids:
                continue

            fields = field_map.get(node_id)
            if not fields:
                continue

            primary_field = fields[0] if isinstance(fields, list) else fields
            conv_key = f"{primary_field}_conversation"

            if conv_key in conversations:
                label = self._format_node_label(node_id)
                extra_keys.append((conv_key, label))

        self._append_follow_up_conversation(conversations, extra_keys)

        return extra_keys

    def _format_node_label(self, node_id: str) -> str:
        """Convert node_id into a human-readable label."""
        return node_id.replace("_", " ").title()

    def _append_follow_up_conversation(
        self,
        conversations: Dict[str, Any],
        extra_keys: List[Tuple[str, str]],
    ) -> None:
        """Append follow-up conversation if present."""
        follow_up_key = self._get_follow_up_conv_key()
        if follow_up_key and follow_up_key in conversations:
            extra_keys.append((follow_up_key, "Follow Up"))

    def _get_follow_up_conv_key(self) -> Optional[str]:
        """Return the follow-up conversation key if follow_up is enabled, else None."""
        if getattr(self.engine_context, 'follow_up_enabled', False):
            node_id = getattr(self.engine_context, 'follow_up_node_id', None)
            if node_id:
                return f"{node_id}_conversation"
        return None

    def _get_model_config(self) -> Dict[str, Any]:
        return self.engine_context.get_model_config(self.agent_config)

    def _build_auto_extraction_rule(self) -> str:
        """Build an auto-extraction instruction linking prior conversation history to current fields."""
        field_names = [f.replace('_', ' ').title() for f in self.fields]
        fields_label = ", ".join(field_names)
        return (
            f"<auto_extraction_rule>\n"
            f"You are currently collecting: {fields_label}.\n"
            f"Before asking the user, review the CONVERSATION HISTORY above. "
            f"If the user has already conveyed the information you need to collect "
            f"during a prior step (even if it was not the focus of that step), "
            f"extract and return it immediately using your standard capture/extraction format. "
            f"Do NOT ask the user to repeat information they have already provided.\n"
            f"</auto_extraction_rule>"
        )

    def _get_instructions(self, state: Dict[str, Any], collector_nodes: Dict[str, str]) -> str:
        instructions = self.agent_config.get("instructions", "")
        if instructions:
            instructions = self._render_template_string(instructions, state)

        # Auto-inject conversation summary if available
        if conversation_summary := state.get("conversation_summary", ""):
            if conversation_summary.strip():
                instructions = f"{instructions}\n\nCONVERSATION CONTEXT (Summary of previous conversation):\n{conversation_summary}"

        # Get localized wait phrases
        wait_phrases = self.engine_context.get_localization_wait_phrases(state)
        wait_phrases_str = ", ".join([f'"{phrase}"' for phrase in wait_phrases])

        rule = self.engine_context.get_localization_rule(state)
        lang_enforcement = ""
        if rule.display_language and rule.display_script:
            lang_enforcement = textwrap.dedent(f"""
            Language: {rule.display_language}
            Script: {rule.display_script}
            
            All user-facing messages MUST be in **{rule.display_language}** using **{rule.display_script}** script only.\n
            If the reference message is in a different language or script, it must be translated to **{rule.display_language}** and **{rule.display_script}** script.
            """).strip()

        if custom_bot_response_rules := self.agent_config.get("bot_response_rules"):
            custom_bot_response_rules = self._render_template_string(custom_bot_response_rules, state)
            rules_list = [lang_enforcement, custom_bot_response_rules]
            bot_response_rules = "\nBOT RESPONSE RULES:\n" + "\n".join([r for r in rules_list if r]) + "\n"
        else:
            bot_response_rules = "\nBOT RESPONSE RULES:\n"
            if lang_enforcement:
                bot_response_rules += f"{lang_enforcement}\n"
            bot_response_rules += textwrap.dedent(f"""
            - If the user input is unclear or does not provide enough information, ask for clarification or more details
            - If the user asks to wait, pause, or needs a moment (e.g. {wait_phrases_str}), acknowledge politely and wait for their next message
            """).strip() + "\n"
        
        # Inject localized rules and examples from structured LocalizationRule
        localization_section = ""
        if rule.instructions:
            localization_section += f"\nLOCALIZATION GUIDELINES:\n{rule.instructions}\n"
        if rule.examples:
            localization_section += f"\nLOCALIZATION EXAMPLES:\n{rule.examples}\n"


        is_utilized = state.get(WorkflowKeys.USER_MESSAGE_UTILIZED, False)
        
        relative_numbering_prompt = ""
        if not is_utilized:
            relative_numbering_prompt = """

        NUMERIC / ORDINAL USER INPUT HANDLING : 
        Follow the mentioned steps as a sequence strictly in order. Stop once a condition is satisfied.

        STEP 1: NORMALIZE INPUT
        - Extract number X from digits or words (e.g., "twenty" -> 20 , "05" -> 5)
        - Detect identifier keywords:
        "ending with", "ends with", "with", "last 4 digits", "entity number"
        If a valid identifier keyword is present, go to STEP 2 else SKIP STEP 2.

        STEP 2: IDENTIFIER INTENT (HIGHEST PRIORITY)
        If any identifier keyword is present:
        - Treat as entity reference ONLY (NOT positional)
        Actions:
        1. Match full entity number == X
        2. Match entity ending with X (exact suffix)
        Rules:
        - No positional logic
        - Stop on first match. 
        - If no matches found → FAIL

        STEP 3: POSITIONAL SELECTION (DEFAULT)
        Let N = total items
        If 1 <= X <= N:
        - Select nth item(entity) from the list (1-based index)
        - STOP

        STEP 4: DIRECT ENTITY MATCH (UNAMBIGUOUS)
        If no identifier keywords:
        - Check:
        1. Full entity number == X
        2. Entity ends with X only if user query contains identifiers similar to 'ends with'
        - If EXACTLY ONE match → select it and STOP
        - Else → DO NOT assume entity match, continue to positional
        - If zero or multiple matches → continue

        STEP 5: ENTITY MATCH (FALLBACK)
        - Match in order:
        1. Full Entity number == X
        2. Entity ends with X (exact suffix)
        Rules:
        - "21" must NOT match  "0021"
        - Only exact suffix allowed
        - If multiple matches → FAIL

        STEP 6: FAILURE
        Please ask the user kindly to enter a proper numeber that is within the range of the total items in the list.

        GLOBAL RULES
        - DO NOT use digit length to infer intent
        - Numeric input WITHOUT identifier keywords MUST NOT be treated as an entity(item) reference unless Step 3 finds a UNIQUE match
        - DO NOT mix interpretations
        - Direct match (Step 3) must be UNIQUE
        - Always return one deterministic result
    """
    

        # Wrap base instructions with XML tag
        instructions = f"<agent_instructions>\n{instructions}\n{bot_response_rules}\n{localization_section}\n{relative_numbering_prompt}\n</agent_instructions>"

        # Inject humanization tone into agent instructions
        if self._should_humanize_prompt():
            from ..core.constants import DEFAULT_AGENT_TONE_PROMPT
            instructions = f"{instructions}\n\n<tone>\n{DEFAULT_AGENT_TONE_PROMPT}\n</tone>"

        # Get base localization instruction (e.g., "MUST respond in Hindi")
        localization_instructions = self.engine_context.get_base_localization_instructions(state)
        if localization_instructions:
            localization_block = f"<localization>\n{localization_instructions}\n</localization>"
            instructions = f"{localization_block}\n\n{instructions}"

        extra_conv_keys = self._get_extra_conv_keys(state)
        workflow_context = _build_workflow_context_summary(state, extra_conv_keys=extra_conv_keys, step_config_map=getattr(self.engine_context, 'step_map', None))
        if workflow_context:
            auto_extract_rule = self._build_auto_extraction_rule()
            instructions = f"{instructions}\n\n{workflow_context}\n\n{auto_extract_rule}"

        # Add OPTIONS_DATA guidance for pattern matching mode
        compute_available = self.agent_config.get("default_tools", True)
        if not self.is_structured_output:
            instructions = _wrap_instructions_with_options_data_guidance(instructions, max_chars=self.option_max_chars, compute_available=compute_available)
        else:
            agent_desc = self.agent_config.get("description", "")
            agent_context = f"\nAgent purpose: {agent_desc}" if agent_desc else ""
            structured_config = self.agent_config.get('structured_output', {}) if self.agent_config else {}
            fields_config = structured_config.get('fields', [])
            required_field_names = [
                f.get("name") for f in fields_config
                if f.get("name") and f.get("name") not in COLLECT_INPUT_METADATA_FIELDS and f.get("required", True) is not False
            ]
            _so_status_rules = _get_status_population_guidelines(mode="so_prompt", required_fields=required_field_names or None)

            instructions = f"""{instructions}

STATUS RULES:{agent_context}
{_so_status_rules}"""

        enable_intent_change = False
        if collector_nodes:
            collector_nodes_for_intent_change = {
                node_id: node_desc for node_id, node_desc in collector_nodes.items()
                if node_id not in self.engine_context.mfa_validator_steps
            }
            if collector_nodes_for_intent_change:
                enable_intent_change = True
            instructions = _wrap_instructions_with_intent_detection(instructions, collector_nodes_for_intent_change, self.is_structured_output)

        # Add out-of-scope detection instructions if enabled
        if self.enable_out_of_scope:
            instructions = _wrap_instructions_with_out_of_scope_detection(
                instructions, self.scope_description, self.is_structured_output
            )

        # Summarise all allowed markers for pattern matching mode so the LLM
        # cannot hallucinate novel markers or mix signals with free-form text.
        if not self.is_structured_output:
            instructions = _wrap_instructions_with_allowed_markers_constraint(
                instructions,
                transitions=self.transitions,
                enable_intent_change=enable_intent_change,
                enable_out_of_scope=self.enable_out_of_scope,
            )

        # Inject tool responses from state so the LLM is aware of tool call history
        # Only inject tools if enabled in config and available for this specific node
        if not self.agent_config.get("show_tool_responses", True):
            return instructions

        from ..utils.builtin_tools import MONTY_TOOL_NAME
        available_tools = set(self.agent_config.get("tools", []))
        if self.agent_config.get("default_tools", True):
            available_tools.add(MONTY_TOOL_NAME)

        # Filter out tools that are marked as hidden from prompt
        if available_tools:
            available_tools = self._filter_hidden_tools(available_tools)

        tool_responses = state.get(WorkflowKeys.TOOL_RESPONSES) or {}
        
        if tool_responses:
            tool_entries = []

            MONTY_TOOL_AVAILABLE = MONTY_TOOL_NAME in available_tools
            
            for tool_name in sorted(available_tools):
                if tool_name in tool_responses:
                    tool_data = tool_responses[tool_name]
                    if isinstance(tool_data, dict) and "output" in tool_data:
                        output = tool_data["output"]
                        inputs = tool_data.get("input", {})
                        entry = f"- Tool '{tool_name}':\n    INPUT: {json.dumps(inputs)}\n    OUTPUT: {json.dumps(output)}"

                        if MONTY_TOOL_AVAILABLE:
                            entry += f"\n\n - The output of '{tool_name}' can be accessed in the {MONTY_TOOL_NAME} tool using the variable '{tool_name}_response'."
                        
                        tool_entries.append(entry)

            if tool_entries:
                header = "<tool_responses>\nThe following tools have already been called and returned these results:\n"

                tool_block = header + "\n".join(tool_entries) + "\n</tool_responses>"
                instructions = f"{instructions}\n\n{tool_block}"



        # Current date should always be present for temporal context
        instructions = f"{instructions}\n\nCurrent date: {date.today().isoformat()}"

        return instructions

    def _load_agent_tools(self, state: Dict[str, Any]) -> List:
        from ..utils.builtin_tools import make_compute_tool, MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION
        from ..utils.tool import wrap_state_recording

        raw_tools = [
            self.engine_context.tool_repository.load(tool_name, state)
            for tool_name in self.agent_config.get('tools', [])
        ] if self.agent_config.get('tools') and self.engine_context.tool_repository else []
        
        # Wrap each tool to record its output in state["_tool_responses"]
        tools = [(name, desc, wrap_state_recording(name, state)(func)) for name, desc, func in raw_tools]

        if self.agent_config.get('default_tools', True):
            compute_func = make_compute_tool(state)
            tools.append((MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION, wrap_state_recording(MONTY_TOOL_NAME, state)(compute_func)))

        return tools

    def _create_structured_output_model(self, collector_nodes: Dict[str, str], state: Dict[str, Any] = None) -> Any:
        structured_output_config = self.agent_config.get('structured_output')
        if not structured_output_config or not structured_output_config.get('enabled'):
            return None

        fields = structured_output_config.get('fields', [])
        if not fields:
            return None

        validate_field_definitions(fields)
        model_name = f"{self.primary_field.title().replace('_', '')}StructuredOutput"

        bot_response_rules = self.agent_config.get("bot_response_rules")
        if bot_response_rules and state is not None:
            bot_response_rules = self._render_template_string(bot_response_rules, state)

        return create_structured_output_model(
            fields=fields,
            model_name=model_name,
            intent_change_nodes=list(collector_nodes.keys()),
            enable_out_of_scope=self.enable_out_of_scope,
            bot_response_rules=bot_response_rules,
        )

    def _create_agent(self, state: Dict[str, Any]) -> AgentAdapter:
        try:
            model_config = self._get_model_config()
            agent_tools = self._load_agent_tools(state)
            collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})

            instructions = self._get_instructions(state, collector_nodes)
            structured_output_model = self._create_structured_output_model(collector_nodes, state)
            framework = self.engine_context.get_config_value('agent_framework', 'langgraph')

            tool_config = self.engine_context.config.get('tool_config') or {}
            max_retry_limit = tool_config.get('max_retry_limit')
            failure_message = getattr(self.engine_context, 'failure_message', None)

            structured_output_config = self.agent_config.get('structured_output') or {}
            fields = structured_output_config.get('fields', [])

            required_fields = [
                f["name"] for f in fields if f.get("required", True)
            ]

            return AgentFactory.create_agent(
                framework=framework,
                name=self.agent_config.get('name', f'{self.primary_field}Collector'),
                model_config=model_config,
                tools=agent_tools,
                system_prompt=instructions,
                structured_output_model=structured_output_model,
                guardrails=self.output_guardrails,
                max_retry_limit=max_retry_limit,
                failure_message=failure_message,
                required_fields=required_fields,
            )

        except Exception as e:
            raise RuntimeError(f"Failed to create agent for step '{self.step_id}': {e}")

    def _generate_prompt(
        self,
        agent: AgentAdapter,
        conversation: List[Dict[str, str]],
        state: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Generate the prompt for the user, returning structured prompt data.

        Returns:
            Dict with keys: text (str|None), options (list), is_selectable (bool)
            or None if no prompt is needed.
        """
        # Track if initial_message is from config (static) or agent-generated
        initial_message = self.agent_config.get('initial_message')
        options = self.options
        is_selectable = self.is_selectable
        intent_change = None
        out_of_scope = None
        status = None

        if not (prompt := initial_message):
            # Agent generates the prompt - LLM naturally produces conversational tone
            user_msg = state.get(WorkflowKeys.USER_MESSAGE, "")
            is_utilized = state.get(WorkflowKeys.USER_MESSAGE_UTILIZED, False)

            if is_utilized:
                logger.info(f"User message already utilized, injecting protective system note for step '{self.step_id}'")
                system_note = textwrap.dedent("""
                    <system_note>
                    The user query is already utilized in a previous turn of this conversation. Treat it as a continuation of the conversation rather than a new query.
                    Always check WORKFLOW_STATE, COLLECTED DATA, and CONVERSATION HISTORY before acting. Do NOT trigger a redundant intent change if the user provides info that is already present in the COLLECTED DATA or was already confirmed in prior turns. 
                    An intent change should ONLY be triggered if the user EXPLICITLY asks to change or correct a previously provided value. Providing info that has already been collected as part of a confirmation or multi-intent message is NOT an intent change.
                    If the user provides relative or ordinal references (e.g., "1", "2nd", "last", "that one", "previous option"), do not resolve them implicitly. Instead, ask the user to provide explicit value to avoid ambiguity.
                    </system_note>
                """)
                enhanced_user_msg = f"{system_note}\n<user_query>{user_msg}</user_query>"
            else:
                enhanced_user_msg = user_msg

            initial_conv = [{"role": "user", "content": enhanced_user_msg}]

            agent_response = self._get_agent_response(agent, initial_conv, state)
            logger.info(f"Agent raw response: {agent_response}")

            # Mark utilized after the first agentic processing of this message
            self._update_user_message_utilized(state, utilized=True)

            if isinstance(agent_response, GuardrailFailureResponse):
                message_key = "bot_response" if self.is_structured_output else "text"
                content_data = {
                    message_key: agent_response.error_message,
                    "options": self.options,
                    "is_selectable": self.is_selectable,
                }
                conversation.append({"role": "assistant", "content": json.dumps(content_data)})
                return {"text": agent_response.error_message, "options": self.options, "is_selectable": self.is_selectable}

            # Check if agent extracted data from workflow context instead of asking
            if self._check_context_extraction(agent_response, state):
                logger.info(f"Agent extracted field(s) from workflow context for step '{self.step_id}'")
                return None  # Field pre-populated from context, no prompt needed

            if self.is_structured_output:
                try:
                    response_dict = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
                    bot_response = response_dict.get("bot_response", None)
                    # Treat empty or whitespace-only bot_response as None
                    prompt = bot_response if (bot_response and bot_response.strip()) else None
                    # Preserve intent_change and out_of_scope so execute() can handle them
                    intent_change = response_dict.get("intent_change")
                    out_of_scope = response_dict.get("out_of_scope")
                    status = response_dict.get("status")
                    # Extract dynamic options from agent response
                    if response_dict.get("options") is not None:
                        options = response_dict["options"] or options
                    if response_dict.get("is_selectable") is not None:
                        is_selectable = response_dict["is_selectable"]
                    # Update instance variables for use in self-loop scenarios (structured output mode)
                    self.options = options
                    self.is_selectable = is_selectable
                    # Preserve intent_change/out_of_scope so _handle_special_responses can detect them
                    # (these are stripped when we convert response_dict -> prompt_data below)
                    _so_intent_change = response_dict.get("intent_change")
                    _so_out_of_scope = response_dict.get("out_of_scope")
                except (json.JSONDecodeError, TypeError, ValueError) as e:
                    logger.error(f"Error When Converting Structured Output {agent_response} to JSON {e}")
                    prompt = None
                    _so_intent_change = None
                    _so_out_of_scope = None
            else:
                result = self._extract_options_from_response(agent_response)
                prompt = result.message
                status = result.status
                # Update instance variables for use in self-loop scenarios (pattern matching mode)
                self.options = result.options
                self.is_selectable = result.is_selectable

        if prompt is not None:
            prompt = self._render_template_string(prompt, state)
            if initial_message and self._should_humanize_prompt():
                result = self.engine_context._humanize_message(prompt, state, self.options, self.is_selectable)
                prompt = result.message
                # Update instance variables with humanized options
                self.options = result.options if result.options is not None else self.options
                self.is_selectable = result.is_selectable if result.is_selectable is not None else self.is_selectable

            # Serialize structured data as JSON in content field.
            # In structured output mode use "bot_response" to match the LLM schema so the
            # LLM does not learn to output "text" instead of "bot_response" from its history.
            message_key = "bot_response" if self.is_structured_output else "text"
            content_data = {message_key: prompt, "options": self.options, "is_selectable": self.is_selectable}
            conversation.append({"role": "assistant", "content": json.dumps(content_data)})

        if prompt is not None or intent_change or out_of_scope:
            result_data = {"text": prompt, "options": self.options, "is_selectable": self.is_selectable}
            if intent_change:
                result_data["intent_change"] = intent_change
            if out_of_scope:
                result_data["out_of_scope"] = out_of_scope
            if status is not None:
                result_data["status"] = status
            return result_data
        return None

    def _update_conversation(self, state: Dict[str, Any], conversation: List[Dict[str, str]]):
        current_time = datetime.now(timezone.utc)
        if WorkflowKeys.CONVERSATIONS not in state:
            state[WorkflowKeys.CONVERSATIONS] = {}

        for i, msg in enumerate(conversation):
            if "timestamp" not in msg:
                # Use microseconds and add a small offset for messages in the same list to ensure absolute order
                # even when they are part of the same bulk update.
                msg_time = current_time + timedelta(microseconds=i)
                msg["timestamp"] = msg_time.isoformat(timespec='microseconds').replace("+00:00", "Z")
        state[WorkflowKeys.CONVERSATIONS][self._conversation_key] = conversation

    def _extract_options_from_response(self, agent_response: str) -> MessagePayload:
        """Extract options and status from agent response markers.

        Strips OPTIONS_DATA and STATUS_FIELD markers from the response text,
        returning a MessagePayload with the cleaned message, options, and status.

        Returns:
            MessagePayload containing cleaned message text, extracted options, and status
        """
        status = None
        status_marker = ResponseMarkers.STATUS_FIELD

        # Extract STATUS_FIELD first (it appears at the end, after OPTIONS_DATA)
        if status_marker in agent_response:
            parts = agent_response.split(status_marker, 1)
            agent_response = parts[0].strip()
            status = parts[1].strip() or None
            if status:
                logger.info(f"Extracted status from agent response: {status}")
            # Strip markdown code fence lines the LLM may insert as a visual separator
            # before the STATUS marker (e.g. "CARD_ACTION_CAPTURED:BlockCard\n```\nSTATUS: success")
            cleaned_lines = [line for line in agent_response.split('\n') if not line.strip().startswith('```')]
            agent_response = '\n'.join(cleaned_lines).strip()
        else:
            logger.warning(
                f"Pattern-matching agent did not include '{status_marker}' marker in its response. "
                "LLM_STATUS will not be updated for this turn. Check prompt guidance."
            )

        options_marker = ResponseMarkers.OPTIONS_DATA

        if options_marker not in agent_response:
            return MessagePayload(agent_response, self.options, self.is_selectable, status=status)

        parts = agent_response.split(options_marker, 1)
        conversational_text = parts[0].strip()
        options_text = parts[1].strip()
        options_data = convert_to_dict(options_text)

        if isinstance(options_data, str):
            logger.warning(f"OPTIONS_DATA value is a string: {options_data}")
            return MessagePayload(conversational_text, self.options, self.is_selectable, status=status)

        extracted_options = options_data.get("options", self.options)
        extracted_selectable = options_data.get("is_selectable", self.is_selectable)

        if not isinstance(extracted_options, list):
            logger.warning(f"OPTIONS_DATA 'options' must be a list, got {type(extracted_options)}")
            return MessagePayload(conversational_text, self.options, self.is_selectable, status=status)

        logger.info(f"Extracted {len(extracted_options)} dynamic options from agent response")
        return MessagePayload(conversational_text, extracted_options, extracted_selectable, status=status)

    # Keys that are internal SDK signals and must never surface in _pending_prompt
    # or be passed to interrupt(). They are persisted separately in state.
    _PENDING_PROMPT_STRIP_KEYS = frozenset({"status", "reasoning", "intent_change", "out_of_scope"})

    def _sanitize_pending_prompt(self, prompt_data: Dict[str, Any] | str) -> Optional[Dict[str, Any]]:
        """Sanitize prompt_data before storing in _pending_prompt / passing to interrupt().

        Guards against three leak vectors:
        - PM nodes: control signal responses (INTENT_CHANGE:, OUT_OF_SCOPE:, etc.) that
          were not handled by _handle_special_responses end up as the continuation prompt.
        - SO nodes: raw JSON strings that appear when JSON parsing fails and the fallback
          sets prompt = agent_response (the unparsed JSON blob).
        - SO nodes: internal fields (status, reasoning, intent_change, out_of_scope) that
          the LLM sets alongside bot_response must not be stored in _pending_prompt or
          surfaced to the consumer — they are already persisted in state separately.
        """
        parsed_prompt_data = prompt_data
        if isinstance(prompt_data, str) and prompt_data.startswith("{"):
            parsed_prompt_data = json.loads(prompt_data)

        text = (
            parsed_prompt_data.get("bot_response") or parsed_prompt_data.get("text") or parsed_prompt_data.get("message")
            if isinstance(parsed_prompt_data, dict) else parsed_prompt_data
        )

        if any(text.startswith(p.value) for p in TransitionPattern):
            logger.warning(f"Suppressed control signal in pending prompt for '{self.step_id}': {text[:100]}")
            return None

        # Strip internal-only keys so they don't leak into _pending_prompt or interrupt()
        if isinstance(parsed_prompt_data, dict):
            keys_to_strip = set(parsed_prompt_data.keys()) & self._PENDING_PROMPT_STRIP_KEYS
            if not keys_to_strip:
                return prompt_data  # No keys to strip — return original object unchanged
            cleaned = {k: v for k, v in parsed_prompt_data.items() if k not in self._PENDING_PROMPT_STRIP_KEYS}
            return cleaned

        return prompt_data


    def _handle_intent_change(self, target_node_or_response, state: Dict[str, Any]) -> Dict[str, Any]:
        if isinstance(target_node_or_response, str) and TransitionPattern.INTENT_CHANGE.value in target_node_or_response:
            target_node = target_node_or_response.split(TransitionPattern.INTENT_CHANGE.value)[1].strip()
        else:
            target_node = target_node_or_response

        logger.info(f"Intent change detected: {self.step_id} -> {target_node}")

        rollback_state = self._rollback_state_to_node(state, target_node, preserve_conversations=True)

        if rollback_state is None:
            logger.error(f"Failed to rollback to node '{target_node}' — no snapshot found (node may not have been visited yet)")
            failure_message = getattr(self.engine_context, 'failure_message', None) or "Unable to complete the request."
            state[WorkflowKeys.ERROR] = failure_message
            state[WorkflowKeys.OUTCOME_ID] = WorkflowKeys.ERROR
            state[WorkflowKeys.LLM_STATUS] = "failed"
            self._set_status(state, WorkflowKeys.ERROR)
            return state

        return rollback_state

    def _handle_out_of_scope(self, reason: str, state: Dict[str, Any], user_message: str) -> Dict[str, Any]:
        """Handle out-of-scope user input by signaling to parent orchestrator"""
        if isinstance(reason, str) and TransitionPattern.OUT_OF_SCOPE_PATTERN.value in reason:
            reason = reason.split(TransitionPattern.OUT_OF_SCOPE_PATTERN.value)[1].strip()

        logger.info(f"Out-of-scope detected in step '{self.step_id}': {reason}")

        # Store the out-of-scope reason and interrupt with user message
        state['_out_of_scope_reason'] = reason
        state[WorkflowKeys.PENDING_PROMPT] = {
            "type": "out_of_scope",
            "step_id": self.step_id,
            "reason": reason,
            "user_message": user_message
        }

        self._set_status(state, 'collecting')
        return state

    def _handle_special_responses(
        self,
        agent_response: Any,
        state: Dict[str, Any],
        conversation: Optional[List[Dict[str, str]]] = None,
        user_message: str = "",
        span=None
    ) -> Optional[Dict[str, Any]]:
        """Check for and handle out-of-scope and intent change in agent response.

        Works for both structured output (dict) and pattern matching (str) modes.

        Returns:
            State dict if a special case was handled (intent change rollback),
            or None if no special case was detected.
            Note: out-of-scope handling calls interrupt() which raises GraphInterrupt.
        """
        if not user_message and conversation:
            user_message = next(
                (msg['content'] for msg in reversed(conversation) if msg['role'] == 'user'),
                ""
            )

        if self.is_structured_output:
            if self.enable_out_of_scope and agent_response.get("out_of_scope"):
                logger.info(f"[COLLECT] {self.step_id} | out-of-scope detected | llm_response={agent_response}")
                if span:
                    span.add_event("out_of_scope.detected", {"reason": str(agent_response["out_of_scope"])})
                
                # Persist the user turn before interrupting to avoid data loss
                if conversation is not None:
                    self._update_conversation(state, conversation)
                
                return self._handle_out_of_scope(agent_response["out_of_scope"], state, user_message)
            if agent_response.get("intent_change"):
                logger.info(f"[COLLECT] {self.step_id} | intent change detected -> {agent_response['intent_change']} | llm_response={agent_response}")
                if span:
                    span.add_event("intent_change.detected", {"target": str(agent_response["intent_change"])})
                
                # Persist the user turn before rolling back to avoid data loss
                if conversation is not None:
                    self._update_conversation(state, conversation)
                
                return self._handle_intent_change(agent_response["intent_change"], state)
        else:
            if isinstance(agent_response, dict) and 'text' in agent_response:
                response_str = agent_response['text']
            else:
                response_str = str(agent_response)
            response_str = response_str.strip()

            if self.enable_out_of_scope and response_str.startswith(TransitionPattern.OUT_OF_SCOPE_PATTERN.value):
                logger.info(f"[COLLECT] {self.step_id} | out-of-scope detected | llm_response={response_str[:200]}")
                if span:
                    span.add_event("out_of_scope.detected", {"response": response_str[:200]})
                
                # Persist the user turn before interrupting to avoid data loss
                if conversation is not None:
                    self._update_conversation(state, conversation)
                
                return self._handle_out_of_scope(response_str, state, user_message)
            if response_str.startswith(TransitionPattern.INTENT_CHANGE.value):
                logger.info(f"[COLLECT] {self.step_id} | intent change detected | llm_response={response_str[:200]}")
                if span:
                    span.add_event("intent_change.detected", {"response": response_str[:200]})
                
                # Persist the user turn before rolling back to avoid data loss
                if conversation is not None:
                    self._update_conversation(state, conversation)
                
                return self._handle_intent_change(response_str, state)

        return None

    def _process_transitions(
        self,
        state: Dict[str, Any],
        conversation: List,
        agent_response: str
    ) -> Dict[str, Any]:
        matched = False
        self._set_status(state, 'collecting')

        # Extract dynamic options and status if present (pattern matching mode)
        result = self._extract_options_from_response(agent_response)
        cleaned_response = result.message

        # Update instance variables for use in self-loop scenarios (validation/collection failure)
        self.options = result.options
        self.is_selectable = result.is_selectable

        # Persist LLM status from pattern matching response
        if result.status is not None:
            state[WorkflowKeys.LLM_STATUS] = result.status

        for transition in self.transitions:
            patterns = transition['pattern']
            if isinstance(patterns, str):
                patterns = [patterns]

            matched_pattern = None
            for pattern in patterns:
                if pattern in cleaned_response:
                    matched_pattern = pattern
                    break

            if not matched_pattern:
                continue

            matched = True
            next_step = transition['next']

            logger.info(f"Matched transition: {transition}")

            value = cleaned_response.split(matched_pattern)[1].strip()
            if value:
                self._store_field_value(state, value)
                is_valid_input, validation_error_message = self._validate_collected_input(state)
                if not is_valid_input:
                    return self._handle_validation_failure(state, conversation, message=validation_error_message)
                state[WorkflowKeys.MESSAGES] = [f"✓ {self._formatted_field_name} collected: {value}" ]
            else:
                state[WorkflowKeys.MESSAGES] = []

            self._set_status(state, next_step)

            if next_step in self.engine_context.outcome_map:
                self._set_outcome(state, next_step)

            break

        if not matched:
            logger.info(f"No transition matched for response in step '{self.step_id}', continuing collection")
            state[WorkflowKeys.MESSAGES] = []

        return state

    def _handle_structured_output_transition(self, state: Dict[str, Any], conversation: List, agent_response: Any, user_message: str = "", span=None) -> Dict[str, Any]:

        try:
            agent_response = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

        if (special_result := self._handle_special_responses(agent_response, state, user_message=user_message, span=span)) is not None:
            return special_result

        self._set_status(state, "collecting")

        # If all required fields are already populated, bot_response must be ignored.
        # The LLM sometimes sets both fields and bot_response in the same turn; fields take priority.
        if self.agent_config and self.agent_config.get('structured_output', {}).get('enabled'):
            structured_config = self.agent_config.get('structured_output', {})
            fields_config = structured_config.get('fields', [])
            required_fields = [
                f.get("name") for f in fields_config
                if f.get("name") and f.get("name") not in COLLECT_INPUT_METADATA_FIELDS and f.get("required", True) is not False
            ]
            if required_fields and all(
                agent_response.get(field_name) not in [None, '']
                for field_name in required_fields
            ):
                agent_response = {**agent_response, "bot_response": None}
                state[WorkflowKeys.LLM_STATUS] = "success"

        if bot_response := agent_response.get("bot_response"):
            # Carry options metadata on conversation message for self-loop pickup
            options = agent_response.get("options") or self.options
            is_selectable = agent_response.get("is_selectable") if agent_response.get("is_selectable") is not None else self.is_selectable
            status = agent_response.get("status")

            # Update instance variables for use in self-loop scenarios
            self.options = options
            self.is_selectable = is_selectable

            # Persist status in state so downstream nodes can inspect it
            if status is not None:
                state[WorkflowKeys.LLM_STATUS] = status

            # Serialize structured data as JSON in content field
            # Use "bot_response" key to match the structured output schema the LLM expects,
            # preventing the LLM from imitating "text" in future turns.
            content_data = {
                "bot_response": bot_response,
                "options": options,
                "is_selectable": is_selectable,
                "status": status,
            }
            conversation.append({
                "role": "assistant",
                "content": json.dumps(content_data)
            })

            # Store partial values if multi-field OR if structured output is enabled
            if self.is_multi_field or (self.agent_config and self.agent_config.get('structured_output', {}).get('enabled')):
                if self.is_multi_field:
                    self._store_field_values(state, agent_response)
                else:
                    structured_config = self.agent_config.get('structured_output', {})
                    fields_config = structured_config.get('fields', [])
                    field_values = {}
                    for field_def in fields_config:
                        field_name = field_def.get("name")
                        if field_name and field_name in agent_response:
                            field_values[field_name] = agent_response[field_name]

                    # Store all fields in _partial_data using nested dict format
                    # to preserve partial data for field_details display
                    self.engine_context._store_partial_data(state, self.primary_field, field_values)

            return state

        # If no bot_response (agent intends to submit data), validate that all REQUIRED fields are present
        if self.agent_config and self.agent_config.get('structured_output', {}).get('enabled'):
            structured_config = self.agent_config.get('structured_output', {})
            fields_config = structured_config.get('fields', [])
            
            missing_required_fields = []
            field_values = {}

            for field_def in fields_config:
                field_name = field_def.get("name")
                is_required = field_def.get("required", True)
                field_value = agent_response.get(field_name)

                if field_name and field_name in agent_response:
                    field_values[field_name] = agent_response[field_name]

                # Skip framework metadata fields
                if field_name in COLLECT_INPUT_METADATA_FIELDS or is_required is False:
                    continue

                if field_value is None:
                    missing_required_fields.append(field_name)
                    continue

                # If field is required but missing/None in response
                if is_required and field_value is None:
                    missing_required_fields.append(field_name)

            # to preserve partial data for field_details display
            self.engine_context._store_partial_data(state, self.primary_field, field_values)

            # Update engine context with renamed keys for backward compatibility
            renamed_values = {f"{self.primary_field}_{k}": v for k, v in field_values.items()}
            self.engine_context.update_context(renamed_values)
            if missing_required_fields:
                formatted_fields = [format_field_name(f) for f in missing_required_fields]
                error_msg = f"The following required fields are missing: {', '.join(formatted_fields)}. Please provide the missing fields and submit again."
                logger.warning(f"Structured output missing required fields: {missing_required_fields}")
                # Treat as validation failure to give agent feedback
                return self._handle_validation_failure(state, conversation, message=error_msg)
            self._store_field_value(state, field_values)
            self.engine_context.update_context({self.primary_field: field_values})

        # Validate
        is_valid_input, validation_error_message = self._validate_collected_input(state)
        if not is_valid_input:
            self.engine_context._store_partial_data(state, self.primary_field, None)
            return self._handle_validation_failure(state, conversation, message=validation_error_message)

        # For multi-field, check if all fields are collected
        if self.is_multi_field:
            missing = self._get_missing_fields(state)
            if missing:
                # Still missing fields - continue collecting
                return state

        # Proceed to transition
        if next_node := self._find_matching_transition(agent_response):
            return self._complete_collection(state, next_node, agent_response)

        if self.next_step:
            return self._complete_collection(state, self.next_step, agent_response)

        return self._handle_collection_failure(state, conversation)

    def _handle_validation_failure(self, state: Dict[str, Any], conversation: List, message: Optional[str]=VALIDATION_ERROR_MESSAGE, role="assistant") -> Dict[str, Any]:
        if self.is_multi_field:
            # Only clear fields that are already None (set by _validate_collected_input)
            # Valid fields are preserved so the user doesn't have to re-enter them
            for field_name in self.fields:
                if state.get(field_name) is None:
                    self.engine_context.update_context({field_name: None})
        else:
            self._store_field_value(state, None)
            self.engine_context.update_context({self.primary_field: None})

        # Apply template rendering and humanization
        message = self._apply_humanization(message, state)

        # Serialize structured data as JSON in content field.
        # Use "bot_response" in structured output mode to stay consistent with the LLM schema;
        # use "text" in pattern matching mode to stay consistent with agent prompt entries.
        message_key = "bot_response" if self.is_structured_output else "text"
        content_data = {message_key: message, "options": self.options, "is_selectable": self.is_selectable}
        conversation.append({"role": role, "content": json.dumps(content_data)})
        return state

    def _find_matching_transition(self, agent_response: Any) -> Optional[str]:
        for transition in self.transitions:
            next_node = transition.get("next")
            match_value = transition.get("match")
            ref_field = transition.get("ref")

            if not next_node or not ref_field or match_value is None:
                raise RuntimeError(f"Transition in step '{self.step_id}' missing required properties for structured output routing")

            field_value = agent_response.get(ref_field)
            if isinstance(match_value, list):
                if field_value in match_value:
                    return next_node
            elif field_value == match_value:
                return next_node

        return None

    def _complete_collection(self, state: Dict[str, Any], next_node: str, agent_response: Any) -> Dict[str, Any]:
        self._set_status(state, next_node)
        state[WorkflowKeys.LLM_STATUS] = "success"

        if next_node in self.engine_context.outcome_map:
            self._set_outcome(state, next_node)

        # Build message showing collected fields
        if self.is_multi_field:
            collected = {f: state.get(f) for f in self.fields if state.get(f) is not None}
            state[WorkflowKeys.MESSAGES] = [f"✓ Collected: {collected}"]
        else:
            state[WorkflowKeys.MESSAGES] = [
                f"✓ {self._formatted_field_name} collected: {str(agent_response)}"
            ]

        return state

    def _handle_collection_failure(self, state: Dict[str, Any], conversation: List) -> Dict[str, Any]:
        state[WorkflowKeys.LLM_STATUS] = "failed"
        # Apply template rendering and humanization
        message = self._apply_humanization(COLLECTION_FAILURE_MESSAGE, state)

        # Serialize structured data as JSON in content field.
        # Use "bot_response" in structured output mode to stay consistent with the LLM schema;
        # use "text" in pattern matching mode to stay consistent with agent prompt entries.
        message_key = "bot_response" if self.is_structured_output else "text"
        content_data = {
            message_key: message,
            "options": self.options,
            "is_selectable": self.is_selectable
        }
        conversation.append({"role": "assistant", "content": json.dumps(content_data)})
        self._store_field_value(state, None)
        return state


    def _store_field_value(self, state: Dict[str, Any], value: Any):
        """Store field value(s). For multi-field, value is a dict."""
        if self.is_multi_field and isinstance(value, dict):
            self._store_field_values(state, value)
        elif not self.is_multi_field:
            # Legacy single-field behavior
            field_def = next((f for f in self.engine_context.data_fields if f['name'] == self.primary_field), None)
            if field_def and field_def.get('type') == 'number':
                try:
                    state[self.primary_field] = int(value)
                except (ValueError, TypeError):
                    state[self.primary_field] = value
            else:
                state[self.primary_field] = value

    def _store_field_values(self, state: Dict[str, Any], values: Dict[str, Any], fields: Optional[List[str]] = None):
        """Store multiple field values from structured output."""
        target_fields = fields or self.fields
        
        # Build local type map from structured output config if available
        local_field_map = {}
        if self.agent_config:
             so_fields = self.agent_config.get('structured_output', {}).get('fields', [])
             for f in so_fields:
                 if f_name := f.get('name'):
                     local_field_map[f_name] = f.get('type')

        for field_name in target_fields:
            if field_name in values and values[field_name] is not None:
                value = values[field_name]
                
                # Check global data fields first
                field_def = next((f for f in self.engine_context.data_fields if f['name'] == field_name), None)
                field_type = field_def.get('type') if field_def else None
                
                # Fallback to local structured output config
                if not field_type:
                    field_type = local_field_map.get(field_name)

                if field_type == 'number':
                    try:
                        state[field_name] = int(value)
                    except (ValueError, TypeError):
                        state[field_name] = value
                else:
                    state[field_name] = value

    def _get_last_user_query_from_history(self, state: Dict[str, Any]) -> Optional[str]:
        """Return the most recent user message from workflow conversation history based on timestamp.
        
        Excludes the current node's conversation to avoid self-matching when we just received 
        a new message or transitioned from follow_up.
        """
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})
        
        all_user_messages = []
        for conv_key, conv_messages in conversations.items():
            # Skip current node to find the *previous* actual query context.
            # We include follow-up and other nodes to detect intent-change rollbacks.
            if conv_key == self._conversation_key:
                continue
            for msg in conv_messages:
                if msg.get("role") == "user":
                    all_user_messages.append(msg)
                    
        if not all_user_messages:
            return None
            
        # Sort by timestamp (descending) so the latest is first.
        # Messages without a timestamp default to an empty string.
        all_user_messages.sort(key=lambda m: str(m.get("timestamp", "")), reverse=True)
        return all_user_messages[0].get("content")