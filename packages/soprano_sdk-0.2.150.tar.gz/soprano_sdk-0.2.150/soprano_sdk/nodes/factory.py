from typing import Dict, Any, Type, Callable

from .base import ActionStrategy
from .call_function import CallFunctionStrategy
from .collect_input import CollectInputStrategy
from .async_function import AsyncFunctionStrategy
from .mfa_strategy import MFACollectInputStrategy
from ..core.constants import ActionType
from ..utils.logger import logger


class NodeFactory:
    _strategies: Dict[str, Type[ActionStrategy]] = {}

    @classmethod
    def register(cls, action_type: str, strategy_class: Type[ActionStrategy]):
        if not issubclass(strategy_class, ActionStrategy):
            raise RuntimeError(f"Strategy class {strategy_class.__name__} must inherit from NodeStrategy")

        logger.info(f"Registering node strategy: {action_type} -> {strategy_class.__name__}")
        cls._strategies[action_type] = strategy_class

    @classmethod
    def _create_strategy(cls, step_config: Dict[str, Any], engine_context: Any) -> ActionStrategy:
        action = step_config.get('action')
        if not action:
            raise RuntimeError(f"Step '{step_config.get('id', 'unknown')}' is missing 'action' property")
        if action not in cls._strategies:
            raise RuntimeError(f"Unknown action type: '{action}'.")
        return cls._strategies[action](step_config, engine_context)

    @classmethod
    def create(cls, step_config: Dict[str, Any], engine_context: Any) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
        return cls._create_strategy(step_config, engine_context).get_node_function()

    @classmethod
    def create_async(cls, step_config: Dict[str, Any], engine_context: Any) -> Callable:
        return cls._create_strategy(step_config, engine_context).get_async_node_function()

    @classmethod
    def is_registered(cls, action_type: str) -> bool:
        return action_type in cls._strategies


NodeFactory.register(ActionType.COLLECT_INPUT_WITH_AGENT.value, CollectInputStrategy)
NodeFactory.register(ActionType.CALL_FUNCTION.value, CallFunctionStrategy)
NodeFactory.register(ActionType.CALL_ASYNC_FUNCTION.value, AsyncFunctionStrategy)
NodeFactory.register(ActionType.MFA.value, MFACollectInputStrategy)
