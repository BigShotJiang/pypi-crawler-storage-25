from typing import List, Optional
from dataclasses import dataclass, field

@dataclass
class LocalizationRule:
    """Represents a set of rules for a specific language and script."""
    language: str
    script: str
    instructions: str = ""
    examples: str = ""
    wait_phrases: List[str] = field(default_factory=list)
    display_language: Optional[str] = None
    display_script: Optional[str] = None

    def __post_init__(self):
        if self.display_language is None:
            self.display_language = self.language
        if self.display_script is None:
            self.display_script = self.script

DEFAULT_WAIT_PHRASES = ["hold on", "wait", "give me a sec", "one moment", "1sec"]

DEFAULT_LOCALIZATION_INSTRUCTIONS = """LANGUAGE REQUIREMENT:
You MUST respond in {language} using {script} script only.
- All responses must be in {language} using {script} script
- Make the message natural and conversational in {language} — do NOT translate word-for-word from English
- Do not mix scripts
"""

# Define specific rules
HINDI_DEVANAGARI_RULE = LocalizationRule(
    language="hi",
    script="devanagari",
    instructions="""HINDI STYLE RULES (apply when language is Hindi, in Devanagari script):
Write like a friendly support agent chatting on WhatsApp. Short sentences. Simple words. No textbook Hindi.
""",
    examples="""HINDI EXAMPLES:
GOOD (use this style):
- "आपका रिफंड प्रोसेस हो गया है। 3-5 दिनों में अकाउंट में आ जाएगा।"
- "आपकी शिकायत दर्ज हो गई है। टीम 24 घंटे में जवाब देगी।"
- "माफ़ कीजिए इस दिक्कत के लिए। सीनियर टीम को भेज दिया है।"
- "अपनी डिटेल्स बता दीजिए ताकि हम आगे बढ़ सकें।"
- "अकाउंट वेरिफाई हो गया! अब ट्रांजैक्शन कर सकते हैं।"

BAD (never use this style):
- "कृपया अपनी जानकारी की पुष्टि करें" → instead say "अपनी जानकारी बता दीजिए"
- "सफलतापूर्वक सत्यापित हो गया" → instead say "वेरिफाई हो गया"
- "आपके द्वारा प्रदान किया गया" → instead say "आपने जो दिया"
- "निम्नलिखित प्रक्रिया अंतर्गत" → instead say "ये काम"
""",
    wait_phrases=["ruk", "ruko", "rukh jara", "Sabar karo", "ek minute", "thoda ruko", "baad me"],
    display_language="Hindi",
    display_script="Devanagari"
)

HINDI_LATIN_RULE = LocalizationRule(
    language="hi",
    script="latin",
    instructions="""HINGLISH STYLE RULES (apply when language is Hindi or Hinglish, in Latin script):
Hinglish = Hindi sentence structure with English words naturally mixed in, written ONLY in Roman/Latin script. No Devanagari characters.
""",
    examples="""HINGLISH EXAMPLES:
GOOD (use this style):
- "Aapka refund process ho gaya hai. 3-5 din mein account mein aa jayega."
- "Aapki complaint register ho gayi hai. Team 24 ghante mein reply karegi."
- "Sorry is dikkat ke liye. Senior team ko bhej diya hai."
- "Apni details bata dijiye taaki hum aage badh sakein."
- "Account verify ho gaya! Ab transaction kar sakte hain."

BAD (never use this style):
- "kripya pushti karein" → instead say "bata dijiye"
- "safaltapoorvak satyapit" → instead say "verify ho gaya"
Pure English without Hindi words — always mix Hindi words like aapka, hai, ho gaya, mein, ke liye
""",
    wait_phrases=["ruk", "ruko", "rukh jara", "sabar karo", "ek minute", "thoda ruko", "baad me"],
    display_language="Hindi",
    display_script="Latin"
)

ENGLISH_LATIN_RULE = LocalizationRule(
    language="en",
    script="latin",
    instructions="",
    examples="",
    wait_phrases=[],
    display_language="English",
    display_script="Latin"
)

# Registry for easy lookup
LOCALIZATION_RULES_REGISTRY = [
    HINDI_DEVANAGARI_RULE,
    HINDI_LATIN_RULE,
    ENGLISH_LATIN_RULE
]


class LocalizationManager:
    """Manages language and script specific instructions and wait phrases."""
    
    def __init__(self, custom_rules: Optional[List[LocalizationRule]] = None):
        """Initialize with optional custom rules that override defaults."""
        self.rules = list(LOCALIZATION_RULES_REGISTRY)
        if custom_rules:
            # Create a map to handle overrides (same lang+script)
            rules_map = {
                (rule.language.lower(), rule.script.lower()): rule 
                for rule in self.rules
            }
            for custom_rule in custom_rules:
                key = (custom_rule.language.lower(), custom_rule.script.lower())
                rules_map[key] = custom_rule
            self.rules = list(rules_map.values())

    def _find_rule(self, language: Optional[str], script: Optional[str]) -> Optional[LocalizationRule]:
        target_language = (language or "en").lower()
        target_script = (script or "latin").lower()
        
        # Standardize common names
        if target_language == "hindi": 
            target_language = "hi"
        elif target_language == "english": 
            target_language = "en"
        
        for rule in self.rules:
            if rule.language.lower() == target_language and rule.script.lower() == target_script:
                return rule
        return None

    def get_rule(self, language: Optional[str], script: Optional[str]) -> LocalizationRule:
        """Get the full LocalizationRule object for a language and script."""
        rule = self._find_rule(language, script)
        if rule:
            return rule
        
        # Default rule if none found
        return LocalizationRule(
            language=language or "en",
            script=script or "latin"
        )

    def get_base_instructions(self, language: Optional[str], script: Optional[str]) -> str:
        """Get only the base 'MUST respond in X language' requirement."""
        return DEFAULT_LOCALIZATION_INSTRUCTIONS.format(
            language=language or "English", 
            script=script or "Latin"
        )

    def get_specific_instructions(self, language: Optional[str], script: Optional[str]) -> str:
        """Get only the language/script specific guidelines and examples."""
        rule = self._find_rule(language, script)
        if rule:
            instruction_parts = []
            if rule.instructions:
                instruction_parts.append(rule.instructions)
            if rule.examples:
                instruction_parts.append(rule.examples)
            return "\n".join(instruction_parts)
        return ""

    def get_wait_phrases(self, language: Optional[str], script: Optional[str]) -> List[str]:
        """Get the localized wait phrases for a language and script."""
        wait_phrases = list(DEFAULT_WAIT_PHRASES)
        
        rule = self._find_rule(language, script)
        if rule and rule.wait_phrases:
            # Add localized phrases if they are not already in the list
            for phrase in rule.wait_phrases:
                if phrase not in wait_phrases:
                    wait_phrases.append(phrase)
                
        return wait_phrases
