from typing import Any, Dict, List, Optional, Type, Literal, Union
from pydantic import BaseModel, Field, create_model
from ..core.constants import build_option_guidelines


def _get_status_population_guidelines(
    mode: Literal["field_description", "so_prompt", "pm_prompt"],
    dispatch_signals: Optional[List[str]] = None,
    required_fields: Optional[List[str]] = None,
) -> str:
    """Return status field population guidelines in the requested format.

    Args:
        mode:
            "field_description" — prose string for a Pydantic Field description
                                  (references bot_response, single paragraph).
            "so_prompt"         — bullet block for injecting into a structured-output
                                  system prompt (references bot_response, bullet list).
            "pm_prompt"         — bullet block for injecting into a pattern-matching
                                  system prompt (references "your response", no field name).
        dispatch_signals:
            Optional list of signal names (e.g. ["intent_change", "out_of_scope",
            "restart"]) whose use implies success. Used by FollowUpOutput.
    """
    dispatch_clause = (
        f". Also use this when dispatching {', '.join(dispatch_signals)}"
        if dispatch_signals else ""
    )

    # ------------------------------------------------------------------ #
    # Core definitions — phrased for each mode                            #
    # ------------------------------------------------------------------ #
    fields_clause = (
        f" ({', '.join(f'`{f}`' for f in required_fields)})" if required_fields else ""
    )

    if mode == "pm_prompt":
        ref = "your response"
        collecting = (
            f"{ref} expects the user to provide input (asking for a required field,"
            " prompting re-entry of an invalid value, requesting clarification on a"
            " field, or providing brief clarification necessary for the user to supply"
            " a required field)"
        )
        answering = (
            "use ONLY when providing a response derived from a tool result that"
            " deviates from the main collection goal; required fields are still"
            " pending — do NOT use this to speculatively say things like"
            " 'let me look into this' without an actual tool result"
        )
        success = (
            f"all required fields{fields_clause} are successfully"
            f" captured{dispatch_clause}; set bot_response to null regardless of"
            " whether the user asked a question"
        )
        failed = (
            f"{ref} is a terminal error or failure message; collection cannot"
            " continue (do NOT use this when re-prompting the user to try again)"
        )
    else:
        ref = "your bot_response"
        collecting = (
            f"{ref} expects the user to provide input (asking for a required field,"
            " prompting re-entry of an invalid value, requesting clarification on a"
            " field, or providing brief clarification necessary for the user to supply"
            " a required field)"
        )
        answering = (
            "use ONLY when providing a response derived from a tool result that"
            " deviates from the main collection goal; required fields are still"
            " pending — do NOT use this to speculatively say things like"
            " 'let me look into this' without an actual tool result"
        )
        success = (
            f"all required fields{fields_clause} are successfully"
            f" captured{dispatch_clause}; set bot_response to null regardless of"
            " whether the user asked a question"
        )
        failed = (
            f"{ref} is a terminal error or failure message — collection cannot"
            " continue (do NOT use this when re-prompting the user to try again)"
        )

    # ------------------------------------------------------------------ #
    # Render                                                               #
    # ------------------------------------------------------------------ #
    if mode == "field_description":
        return (
            "Mandatory status of the current interaction. Set this AFTER composing bot_response. "
            f"'collecting': {collecting}. "
            f"'answering': {answering}. "
            f"'success': {success}. "
            f"'failed': {failed}."
        )

    if mode == "so_prompt":
        return (
            "Always populate the `status` field with one of the following values — never omit or null it:\n"
            f'- "collecting": {collecting}.\n'
            f'- "answering": {answering}.\n'
            f'- "success": {success}.\n'
            f'- "failed": {failed}.'
        )

    # pm_prompt
    return (
        "Allowed values:\n"
        f'- "collecting" — {collecting}\n'
        f'- "answering" — {answering}\n'
        f'- "success" — {success}\n'
        f'- "failed" — {failed}'
    )


class FollowUpOutput(BaseModel):
    """Structured output model for the follow-up agent."""

    reasoning: str = Field(
        default="",
        description=(
            "Required brief reasoning (1-2 short sentences) explaining your response. "
            "Never omit or null this field."
        ),
    )

    bot_response: Optional[str] = Field(
        default=None,
        description=(
            "Your conversational reply to the user. "
            "Must be null or omitted when a dispatch signal (intent_change, restart) is used."
        ),
    )

    options: Optional[List[Dict[str, Optional[str]]]] = Field(
        default=None,
        description=(
            "Selectable choices to present alongside bot_response. "
            "Each item must have 'text' (str) and 'subtext' (str or null). "
            "Null when no options are applicable."
        ),
    )

    is_selectable: Optional[bool] = Field(
        default=None,
        description=(
            "True if the user must pick from the provided options rather than type freely. "
            "Null when options is null."
        ),
    )

    out_of_scope: Optional[str] = Field(
        default=None,
        description=(
            "Brief reason when the user's request is unrelated to this workflow. "
            "Use ONLY when the request is outside the workflow. "
            "Null otherwise."
        ),
    )

    restart: Optional[bool] = Field(
        default=None,
        description=(
            "True if the user wants to restart the workflow from the beginning. "
            "Null means no restart."
        ),
    )

    @classmethod
    def get_schema_reminder(cls) -> str:
        """Return a simplified JSON schema string by inspecting model fields."""
        return get_schema_reminder(cls)


def get_schema_reminder(output_schema: Type[BaseModel]) -> str:
    """Return a simplified JSON schema string for any Pydantic model.

    Renders ``status`` as a required enum (no ``| null``) and all other
    optional fields with ``| null``.  Bypasses CrewAI's ``generate_model_description``
    which silently drops Literal values and marks everything as optional.
    """
    from typing import get_origin, get_args, Literal as TypingLiteral

    required_fields = {"status", "reasoning"}
    lines = []
    for name, field in output_schema.model_fields.items():
        optional_suffix = "" if name in required_fields else " | null"
        annotation = field.annotation

        # Unwrap Optional (Union[X, None]) to get the non-None inner type(s)
        origin = get_origin(annotation)
        args = get_args(annotation)
        non_none_args = None
        if origin is Union and type(None) in args:
            non_none_args = [a for a in args if a is not type(None)]
            annotation = non_none_args[0] if len(non_none_args) == 1 else annotation

        inner_origin = get_origin(annotation)
        inner_args = get_args(annotation)

        if name == "options":
            typ = '[{"text": "string", "subtext": "string | null"}]'
            lines.append(f'  "{name}": {typ}{optional_suffix}')
        elif inner_origin is TypingLiteral or str(inner_origin) in ("typing.Literal",):
            values = [str(v) for v in inner_args]
            typ = " | ".join(f'"{v}"' for v in values) if values else '"string"'
            lines.append(f'  "{name}": {typ}{optional_suffix}')
        elif inner_origin is Union:
            # Union of Literals: Optional[Union[Literal[a], Literal[b], ...]] flattens to
            # Union[Literal[a], Literal[b], ..., NoneType] — collect all literal values
            candidates = non_none_args if non_none_args is not None else [a for a in inner_args if a is not type(None)]
            literal_values = []
            for arg in candidates:
                if get_origin(arg) is TypingLiteral:
                    literal_values.extend(str(v) for v in get_args(arg))
            if literal_values and len(literal_values) == len(candidates):
                typ = " | ".join(f'"{v}"' for v in literal_values)
                lines.append(f'  "{name}": {typ}{optional_suffix}')
            else:
                lines.append(f'  "{name}": "<string>"{optional_suffix}')
        elif annotation is bool:
            lines.append(f'  "{name}": boolean{optional_suffix}')
        else:
            lines.append(f'  "{name}": "<string>"{optional_suffix}')

    return "{\n" + ",\n".join(lines) + "\n}"


def build_schema_field_descriptions(
    output_schema: Type[BaseModel],
    required_fields: Optional[List[str]] = None,
) -> str:
    """Build a human-readable field description string from a Pydantic model schema.

    Used by both the agent goal prompt and guardrail regeneration feedback so
    the LLM always sees a consistent, descriptive schema representation.

    Returns a newline-separated list like:
        - field_name: description (allowed values: [...])  // required
    """
    schema_fields = output_schema.model_json_schema().get("properties", {})
    required_fields = required_fields or []

    def _get_enum_values(field_info: Dict[str, Any]) -> Optional[list]:
        if "enum" in field_info:
            return field_info["enum"]
        for sub in field_info.get("anyOf", []):
            if "enum" in sub:
                return sub["enum"]
        return None

    lines = []
    for field_name, field_info in schema_fields.items():
        description = field_info.get("description")
        if not description:
            continue
        line = f"- {field_name}: {description}"
        enum_values = _get_enum_values(field_info)
        if enum_values is not None:
            line += f" (allowed values: {enum_values})"
        if field_name in required_fields:
            line += "  // required"
        lines.append(line)

    return "\n".join(lines)


def create_follow_up_output_model(
    intent_change_nodes: Optional[List[str]] = None,
    transition_nodes: Optional[List[str]] = None,
) -> Type[FollowUpOutput]:
    """Create a FollowUpOutput model with intent_change and transition constrained to valid node IDs.

    When node IDs are provided the corresponding fields are typed as
    Optional[Literal[node1, node2, ...]] so structured-output LLMs are
    constrained to choose only from the declared valid nodes.

    Returns the base FollowUpOutput class unchanged when no nodes are given.
    """
    field_definitions = {}

    if intent_change_nodes:
        lit_type = Union[tuple(Literal[n] for n in intent_change_nodes)]
        node_list = ", ".join(intent_change_nodes)
        description = (
            f"Node ID of the collector that should handle the user's message. "
            f"Must be one of [{node_list}]. Set this when the user's input "
            "maps to data handled by a previously visited collector node."
        )
        field_definitions["intent_change"] = (
            Optional[lit_type],
            Field(None, description=description),
        )
        

    if transition_nodes:
        lit_type = Union[tuple(Literal[n] for n in transition_nodes)]
        node_list = ", ".join(transition_nodes)
        description = (
            f"Node ID of the next target step as defined in transitions. "
            f"Must be one of [{node_list}]. Set this when the user wants "
            "to jump to a new topic or next step."
        )
        field_definitions["transition"] = (
            Optional[lit_type],
            Field(None, description=description),
        )

    if not field_definitions:
        return FollowUpOutput

    return create_model(
        "FollowUpOutput",
        **field_definitions,
        __base__=FollowUpOutput,
    )


TYPE_MAP = {
    "text": str,
    "number": int,
    "double": float,
    "boolean": bool,
    "list": list,
    "dict": dict,
    "literal": Literal,
}


def create_structured_output_model(
    fields: List[Dict[str, Any]],
    model_name: str = "StructuredOutput",
    intent_change_nodes: Optional[List[str]] = None,
    enable_out_of_scope: bool = False,
    bot_response_rules: Optional[str] = None,
) -> Type[BaseModel]:
    if not fields:
        raise ValueError("At least one field definition is required")

    required_fields = {field_def.get("name") for field_def in fields if field_def.get("required", True)}
    bot_response_description_suffix = ""
    if required_fields:
        bot_response_description_suffix = f"IMPORTANT: This value Must always be set as null if {required_fields} {'is' if len(required_fields) == 1 else 'are'} populated."

    if bot_response_rules:
        bot_response_description = f"Rules: {bot_response_rules} {bot_response_description_suffix}"
    else:
        bot_response_description = f"This value set only when the conditions given under BOT_RESPONSE_RULES section are met. {bot_response_description_suffix}"

    field_definitions = {
        "reasoning": (str, Field(
            default="",
            description=(
                "Required brief reasoning (1-2 short sentences) explaining why you chose the status value you set "
                "(e.g. 'User asked a side question; required fields still pending → answering'). "
                "Never omit or null this field."
            ),
        )),
        "bot_response": (Optional[str], Field(None, description=bot_response_description)),
        "status": (Literal["collecting", "answering", "failed", "success"], Field("collecting", description=_get_status_population_guidelines(mode="field_description"))),
    }

    if intent_change_nodes:
        lit_type = Union[tuple(Literal[n] for n in intent_change_nodes)]
        intent_change_type: Any = Optional[lit_type]

        node_list = ", ".join(intent_change_nodes or [])
        field_definitions["intent_change"] = (
            intent_change_type,
            Field(None, description=f"Set to one of [{node_list}] to roll back to a previously-visited node. Leave null if not changing intent.")
        )

    if enable_out_of_scope:
        field_definitions["out_of_scope"] = (Optional[str], Field(None, description="Brief description of what the user is trying to do if their query is completely outside the scope of this workflow"))

    field_definitions["options"] = (Optional[List[Dict[str, Any]]], Field(None, description=build_option_guidelines()))
    field_definitions["is_selectable"] = (Optional[bool], Field(None, description="Set to true if user must select from the provided options, false if user can also type freely."))
    
    for field_def in fields:
        field_name = field_def.get("name")
        field_type = field_def.get("type")
        field_description = field_def.get("description", "")
        
        if not field_name:
            raise ValueError("Field definition missing 'name'")
        
        if not field_type:
            raise ValueError(f"Field '{field_name}' missing 'type'")
        
        python_type = TYPE_MAP.get(field_type)
        if python_type is None:
            raise ValueError(
                f"Unknown type '{field_type}' for field '{field_name}'. "
                f"Supported types: {list(TYPE_MAP.keys())}"
            )

        args = field_def.get("args")
        if args is not None:
            python_type = python_type[tuple(args)]

        # Make ALL fields optional to allow partial LLM outputs (e.g., clarifying questions)
        # We enforce "required" fields in collect_input.py
        python_type = Optional[python_type]
        field_definitions[field_name] = (
            python_type,
            Field(default=None, description=field_description)
        )
    
    try:
        model = create_model(model_name, **field_definitions)
        return model
    except Exception as e:
        raise ValueError(f"Failed to create model '{model_name}': {e}")


def validate_field_definitions(fields: List[Dict[str, Any]]) -> bool:
    if not isinstance(fields, list):
        raise ValueError("Field definitions must be a list")
    
    if not fields:
        raise ValueError("At least one field definition is required")
    
    field_names = set()
    
    for i, field_def in enumerate(fields):
        if not isinstance(field_def, dict):
            raise ValueError(f"Field definition at index {i} must be a dictionary")
        
        required_keys = ["name", "type", "description"]
        for key in required_keys:
            if key not in field_def:
                raise ValueError(f"Field definition at index {i} missing required key '{key}'")
        
        field_name = field_def["name"]
        
        if field_name in field_names:
            raise ValueError(f"Duplicate field name '{field_name}' found")
        field_names.add(field_name)
        
        field_type = field_def["type"]
        if field_type not in TYPE_MAP:
            raise ValueError(
                f"Invalid type '{field_type}' for field '{field_name}'. "
                f"Supported types: {list(TYPE_MAP.keys())}"
            )

        if field_type == "literal":
            args = field_def.get("args")
            if not args or not isinstance(args, list):
                raise ValueError(f"Field '{field_name}' of type 'literal' requires a non-empty 'args' list")
    
    return True
