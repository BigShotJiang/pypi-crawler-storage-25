"""Pydantic models for the Tree-sitter grammar."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, RootModel
from pydantic.config import ConfigDict


class FrozenModel(BaseModel):
    """Base class for all frozen models."""

    model_config = ConfigDict(frozen=True)


class RepeatExpr(FrozenModel):
    type: Literal["REPEAT"]
    content: Expr


class Repeat1Expr(FrozenModel):
    type: Literal["REPEAT1"]
    content: Expr


class ChoiceExpr(FrozenModel):
    type: Literal["CHOICE"]
    members: list[Expr]


class SeqExpr(FrozenModel):
    type: Literal["SEQ"]
    members: list[Expr]


class PrecLeftExpr(FrozenModel):
    type: Literal["PREC_LEFT"]
    value: int
    content: Expr


class PrecRightExpr(FrozenModel):
    type: Literal["PREC_RIGHT"]
    value: int
    content: Expr


class PrecDynamicExpr(FrozenModel):
    type: Literal["PREC_DYNAMIC"]
    value: int
    content: Expr


class FieldExpr(FrozenModel):
    type: Literal["FIELD"]
    name: str
    content: Expr


class TokenExpr(FrozenModel):
    type: Literal["TOKEN"]
    content: Expr


class ImmediateTokenExpr(FrozenModel):
    type: Literal["IMMEDIATE_TOKEN"]
    content: Expr


class AliasExpr(FrozenModel):
    type: Literal["ALIAS"]
    content: Expr
    named: bool
    value: str


class SymbolExpr(FrozenModel):
    type: Literal["SYMBOL"]
    name: str


class StringExpr(FrozenModel):
    type: Literal["STRING"]
    value: str


class PatternExpr(FrozenModel):
    type: Literal["PATTERN"]
    value: str


class BlankExpr(FrozenModel):
    type: Literal["BLANK"]


Expr = Annotated[
    RepeatExpr
    | Repeat1Expr
    | ChoiceExpr
    | SeqExpr
    | PrecLeftExpr
    | PrecRightExpr
    | PrecDynamicExpr
    | FieldExpr
    | TokenExpr
    | ImmediateTokenExpr
    | AliasExpr
    | SymbolExpr
    | StringExpr
    | PatternExpr
    | BlankExpr,
    Field(discriminator="type"),
]


ExtraItem = Annotated[
    StringExpr | SymbolExpr | PatternExpr,
    Field(discriminator="type"),
]


class ExternalSymbol(FrozenModel):
    type: Literal["SYMBOL"]
    name: str


class PrecedenceGroup(FrozenModel):
    items: list[Any] = Field(default_factory=list)


class Rules(RootModel[dict[str, Expr]]): ...


class GrammarRoot(FrozenModel):
    """The root of the grammar definition."""

    name: str
    rules: Rules
    extras: list[ExtraItem] = Field(default_factory=list)
    conflicts: list[list[str]] = Field(default_factory=list)
    precedences: list[PrecedenceGroup] = Field(default_factory=list)
    externals: list[ExternalSymbol] = Field(default_factory=list)
    inline: list[str] = Field(default_factory=list)
    super_types: list[str] = Field(default_factory=list)


def seq(*m: Expr) -> SeqExpr:
    """Seq is just a wrapper around SeqExpr."""
    return SeqExpr(type="SEQ", members=list(m))


def choice(*m: Expr) -> ChoiceExpr:
    """Choice is just a wrapper around ChoiceExpr."""
    return ChoiceExpr(type="CHOICE", members=list(m))


def repeat(c: Expr) -> RepeatExpr:
    """Repeat is just a wrapper around RepeatExpr."""
    return RepeatExpr(type="REPEAT", content=c)


def sym(n: str) -> SymbolExpr:
    return SymbolExpr(type="SYMBOL", name=n)


def string(v: str) -> StringExpr:
    return StringExpr(type="STRING", value=v)


def pat(v: str) -> PatternExpr:
    return PatternExpr(type="PATTERN", value=v)


def repeat1(c: Expr) -> Repeat1Expr:
    return Repeat1Expr(type="REPEAT1", content=c)


def prec_left(value: int, c: Expr) -> PrecLeftExpr:
    return PrecLeftExpr(type="PREC_LEFT", value=value, content=c)


def prec_right(value: int, c: Expr) -> PrecRightExpr:
    return PrecRightExpr(type="PREC_RIGHT", value=value, content=c)


def prec_dynamic(value: int, c: Expr) -> PrecDynamicExpr:
    return PrecDynamicExpr(type="PREC_DYNAMIC", value=value, content=c)


def field(name: str, c: Expr) -> FieldExpr:
    return FieldExpr(type="FIELD", name=name, content=c)


def token(c: Expr) -> TokenExpr:
    return TokenExpr(type="TOKEN", content=c)


def immediate(c: Expr) -> ImmediateTokenExpr:
    return ImmediateTokenExpr(type="IMMEDIATE_TOKEN", content=c)


def alias(c: Expr, value: str, named: bool = True) -> AliasExpr:
    return AliasExpr(type="ALIAS", content=c, value=value, named=named)


def blank() -> BlankExpr:
    return BlankExpr(type="BLANK")


def optional(c: Expr) -> ChoiceExpr:
    return choice(c, blank())


# ruff: noqa: D103 D101
