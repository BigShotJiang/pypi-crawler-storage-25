#pragma once

#include <atomic>
#include <chrono>
#include <filesystem>
#include <functional>
#include <memory>
#include <thread>
#include <vector>

namespace Fond::FileIO {

namespace fs = std::filesystem;

struct WatchEntry {
    fs::path path;
    fs::file_time_type last_write_time;
    std::function<void()> callback;
    std::atomic<bool> stop{false};
};

class FileWatcher {
public:
    FileWatcher() = default;
    ~FileWatcher() { shutdown(); }

    FileWatcher(const FileWatcher&) = delete;
    FileWatcher& operator=(const FileWatcher&) = delete;

    void watch(const fs::path& path, std::function<void()> callback, long interval_ms = 500) {
        auto entry = std::make_shared<WatchEntry>();
        entry->path = path;
        entry->last_write_time = fs::last_write_time(path);
        entry->callback = std::move(callback);

        entries_.push_back(entry);
        threads_.emplace_back([entry, interval_ms]() {
            while (!entry->stop.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
                if (entry->stop.load()) break;
                auto current = fs::last_write_time(entry->path);
                if (current != entry->last_write_time) {
                    entry->last_write_time = current;
                    entry->callback();
                }
            }
        });
    }

    void shutdown() {
        for (auto& entry : entries_)
            entry->stop.store(true);
        for (auto& t : threads_) {
            if (t.joinable()) t.join();
        }
        entries_.clear();
        threads_.clear();
    }

private:
    std::vector<std::shared_ptr<WatchEntry>> entries_;
    std::vector<std::thread> threads_;
};

} // namespace Fond::FileIO
