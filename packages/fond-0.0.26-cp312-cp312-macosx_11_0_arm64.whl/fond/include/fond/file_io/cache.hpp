#pragma once

#include "fond/file_io/watcher.hpp"

#include <fstream>
#include <mutex>
#include <string>
#include <unordered_map>

namespace Fond::FileIO {

class FileCache {
public:
    FileCache() = default;
    ~FileCache() = default;

    FileCache(const FileCache&) = delete;
    FileCache& operator=(const FileCache&) = delete;

    bool load(const fs::path& path) {
        std::lock_guard<std::mutex> lock(mtx_);
        return load_impl(path);
    }

    bool watch(const fs::path& path, std::function<void()> on_reload = nullptr, long interval_ms = 500) {
        {
            std::lock_guard<std::mutex> lock(mtx_);
            if (!load_impl(path)) return false;
        }
        watcher_.watch(path, [this, path, on_reload]() {
            std::lock_guard<std::mutex> lock(mtx_);
            load_impl(path);
            if (on_reload) on_reload();
        }, interval_ms);
        return true;
    }

    const std::string& get(const fs::path& path) const {
        static const std::string empty;
        std::lock_guard<std::mutex> lock(mtx_);
        auto it = cache_.find(path.string());
        if (it == cache_.end()) return empty;
        return it->second.contents;
    }

    bool has(const fs::path& path) const {
        std::lock_guard<std::mutex> lock(mtx_);
        return cache_.contains(path.string());
    }

    void clear() {
        watcher_.shutdown();
        std::lock_guard<std::mutex> lock(mtx_);
        cache_.clear();
    }

private:
    struct CacheEntry {
        std::string contents;
        fs::file_time_type last_modified;
    };

    bool load_impl(const fs::path& path) {
        std::ifstream f(path);
        if (!f.is_open()) return false;
        std::string contents((std::istreambuf_iterator<char>(f)), {});
        cache_[path.string()] = {std::move(contents), fs::last_write_time(path)};
        return true;
    }

    mutable std::mutex mtx_;
    std::unordered_map<std::string, CacheEntry> cache_;
    FileWatcher watcher_;
};

} // namespace Fond::FileIO
