// fond/fs/walk.hpp
// fond: foundation for cooking, foundation for life
//
// Python-style os.walk for C++, built on Fond::generator.
// Yields (directory, subdirs, files) tuples. Modify subdirs
// to prune the traversal — just like Python.
//
// Usage:
//   for (auto& [dir, subdirs, files] : Fond::FileIO::walk("/some/path")) {
//       // remove subdirs you don't want to descend into
//       std::erase_if(subdirs, [](auto& d) {
//           return d.filename() == ".git";
//       });
//       // do stuff with files
//   }

#ifndef FOND_FS_WALK_HPP
#define FOND_FS_WALK_HPP

#include <filesystem>
#include <string>
#include <system_error>
#include <vector>

#include <fond/generator.hpp>

namespace Fond::FileIO {

namespace fs = std::filesystem;
using Paths = std::vector<fs::path>;

// ============================================================================
// walk_entry - what gets yielded each iteration
// ============================================================================

constexpr const char* WNS = "FOND::FileIO::walk";

struct walk_entry {
    fs::path              dir;
    Paths                 subdirs;
    Paths                 files;
};

// ============================================================================
// Error handling policy
// ============================================================================

enum class walk_errors {
    skip,   // silently skip entries that cause errors (default)
    throw_, // let exceptions propagate
};

// ============================================================================
// walk - the main event
// ============================================================================

inline generator<walk_entry> walk(
    const fs::path& root,
    bool topdown = true,
    walk_errors on_error = walk_errors::skip,
    bool follow_symlinks = false)
{
    Paths subdirs;
    Paths files;

    // Iterate the current directory, sorting entries into dirs and files
    {
        std::error_code ec;
        auto dir_options = fs::directory_options::none;
        if (follow_symlinks) dir_options |= fs::directory_options::follow_directory_symlink;
        if (on_error == walk_errors::skip) dir_options |= fs::directory_options::skip_permission_denied;

        auto it = fs::directory_iterator(root, dir_options, ec);
        if (ec) {
            if (on_error == walk_errors::throw_) { throw fs::filesystem_error(WNS, root, ec); }
            co_return;
        }

        for (auto& entry : it) {
            std::error_code entry_ec;
            bool is_dir;
            if (follow_symlinks) {
                is_dir = entry.is_directory(entry_ec);
            } else {
                auto status = fs::symlink_status(entry.path(), entry_ec);
                if (entry_ec) {
                    if (on_error == walk_errors::throw_) {throw fs::filesystem_error(WNS, entry.path(), entry_ec); }
                    continue;
                }
                is_dir = fs::is_directory(status);
            }
            if (is_dir) subdirs.push_back(entry.path());
            else files.push_back(entry.path());
        }
    }

    if (topdown) {
        // Yield BEFORE descending — caller can prune subdirs
        walk_entry entry{root, std::move(subdirs), std::move(files)};
        co_yield entry;

        // Descend into whatever subdirs remain after caller modified them
        for (auto& subdir : entry.subdirs) {
            for (auto&& child : walk(subdir, topdown, on_error, follow_symlinks)) {
                co_yield std::move(child);
            }
        }
    } else {
        // Bottom-up: descend first, yield after
        // Take a copy since we yield subdirs to the caller later
        auto dirs_to_descend = subdirs;

        for (auto& subdir : dirs_to_descend) {
            for (auto&& child : walk(subdir, topdown, on_error, follow_symlinks)) {
                co_yield std::move(child);
            }
        }

        walk_entry entry{root, std::move(subdirs), std::move(files)};
        co_yield entry;
    }
}

// ============================================================================
// Convenience overload: walk with an ignore predicate baked in
// ============================================================================

/// Walk a directory tree, automatically pruning subdirs that match a predicate.
/// The predicate receives a const fs::path& and returns true to skip that dir.
template <class IgnorePredicate> generator<walk_entry> walk_filtered(
    const fs::path& root,
    IgnorePredicate&& should_ignore,
    walk_errors on_error = walk_errors::skip,
    bool follow_symlinks = false)
{
    for (auto&& entry : walk(root, true, on_error, follow_symlinks)) {
        std::erase_if(entry.subdirs, should_ignore);
        co_yield std::move(entry);
    }
}

} // namespace Fond::FileIO

#endif // FOND_FS_WALK_HPP
