#pragma once

#include <stdexcept>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <io.h>
#else
#include <sys/file.h>
#endif

namespace Fond::FileIO {

namespace detail {

#ifdef _WIN32
inline void lock_file(int fd, bool exclusive) {
    HANDLE h = reinterpret_cast<HANDLE>(_get_osfhandle(fd));
    if (h == INVALID_HANDLE_VALUE) throw std::runtime_error("Invalid file handle");
    OVERLAPPED ov{};
    DWORD flags = LOCKFILE_FAIL_IMMEDIATELY;
    if (exclusive) flags |= LOCKFILE_EXCLUSIVE_LOCK;
    if (!LockFileEx(h, flags, 0, MAXDWORD, MAXDWORD, &ov)) throw std::runtime_error("LockFileEx failed");
}

inline void unlock_file(int fd) {
    HANDLE h = reinterpret_cast<HANDLE>(_get_osfhandle(fd));
    if (h == INVALID_HANDLE_VALUE) return;
    OVERLAPPED ov{};
    UnlockFileEx(h, 0, MAXDWORD, MAXDWORD, &ov);
}
#else
inline void lock_file(int fd, bool exclusive) { if (flock(fd, exclusive ? LOCK_EX : LOCK_SH) != 0) throw std::runtime_error("flock failed"); }
inline void unlock_file(int fd) { flock(fd, LOCK_UN); }
#endif

} // namespace detail

class FileLock {
    int fd_;
    bool locked_ = false;

public:
    FileLock(int fd, bool exclusive = true) : fd_(fd) {
        detail::lock_file(fd_, exclusive);
        locked_ = true;
    }

    ~FileLock() { unlock(); }

    FileLock(const FileLock&) = delete;
    FileLock& operator=(const FileLock&) = delete;
    FileLock(FileLock&& other) noexcept : fd_(other.fd_), locked_(other.locked_) { other.locked_ = false; }

    void unlock() {
        if (locked_) {
            detail::unlock_file(fd_);
            locked_ = false;
        }
    }

    bool is_locked() const { return locked_; }
};

class ExclusiveLock : public FileLock {
public:
    explicit ExclusiveLock(int fd) : FileLock(fd, true) {}
};

class SharedLock : public FileLock {
public:
    explicit SharedLock(int fd) : FileLock(fd, false) {}
};

} // namespace Fond::FileIO
