#pragma once

#ifdef ENABLE_IMGUI
#include "palette.hpp"
#include <imgui.h>

namespace Fond {

static inline Color from_imgui(const ImVec4& col) {
    return Color{
        static_cast<uint8_t>(col.x * RGB_MAX),
        static_cast<uint8_t>(col.y * RGB_MAX),
        static_cast<uint8_t>(col.z * RGB_MAX),
        static_cast<uint8_t>(col.w * RGB_MAX)
    };
}

namespace ImGuiColors {
const inline ImVec4 WHITE       = Colors::WHITE.to_imgui();
const inline ImVec4 LIGHT_GRAY  = Colors::LIGHT_GRAY.to_imgui();
const inline ImVec4 GRAY        = Colors::GRAY.to_imgui();
const inline ImVec4 DARK_GRAY   = Colors::DARK_GRAY.to_imgui();
const inline ImVec4 YELLOW      = Colors::YELLOW.to_imgui();
const inline ImVec4 RED         = Colors::RED.to_imgui();
const inline ImVec4 GREEN       = Colors::GREEN.to_imgui();
const inline ImVec4 BLUE        = Colors::BLUE.to_imgui();
const inline ImVec4 DARK_BLUE   = Colors::DARK_BLUE.to_imgui();
const inline ImVec4 CYAN        = Colors::CYAN.to_imgui();
const inline ImVec4 MAGENTA     = Colors::MAGENTA.to_imgui();
const inline ImVec4 PURPLE      = Colors::PURPLE.to_imgui();
const inline ImVec4 ORANGE      = Colors::ORANGE.to_imgui();
const inline ImVec4 TRANSPARENT = {0, 0, 0, 0};

const inline ImU32 WHITE_U32 = Colors::WHITE.to_imgui_u32();
const inline ImU32 DARK_GREY_U32 = Colors::DARK_GRAY.to_imgui_u32();
const inline ImU32 MED_GREY_U32 = Colors::GRAY.to_imgui_u32();
const inline ImU32 YELLOW_U32   = Colors::YELLOW.to_imgui_u32();
const inline ImU32 RED_U32      = Colors::RED.to_imgui_u32();
const inline ImU32 GREEN_U32    = Colors::GREEN.to_imgui_u32();
const inline ImU32 BLUE_U32     = Colors::BLUE.to_imgui_u32();
const inline ImU32 MAGENTA_U32  = Colors::MAGENTA.to_imgui_u32();
const inline ImU32 PURPLE_U32   = Colors::PURPLE.to_imgui_u32();
} // namespace ImGuiColors
} // namespace Fond

#endif // ENABLE_IMGUI
