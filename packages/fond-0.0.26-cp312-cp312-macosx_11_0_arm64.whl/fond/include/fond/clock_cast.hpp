// fond/chrono/clock_cast.h
// fond: foundation for cooking, foundation for life
//
// Ad-hoc clock_cast implementation based on P0355R7 §23.17.7.9
// Polyfill for platforms where libc++ hasn't shipped it yet (*cough* macOS)
//
// This is the slim build: system_clock hub only, no utc_clock dependency.
// Covers the common cases (file_clock, steady_clock, etc.) without requiring
// chrono features Apple hasn't shipped yet.
//
// When utc_clock finally lands on macOS (heat death of the universe, probably),
// the full two-hub version can be restored.

#ifndef FOND_CHRONO_CLOCK_CAST_HPP
#define FOND_CHRONO_CLOCK_CAST_HPP

#include <chrono>
#include <cstdint>
#include <type_traits>

namespace Fond::Chrono {

using namespace std::chrono;

// ============================================================================
// clock_time_conversion - primary template (empty, specializable by users)
// ============================================================================

template <class DestClock, class SourceClock> struct clock_time_conversion {};

// ============================================================================
// Identity conversions
// ============================================================================

template <class Clock> struct clock_time_conversion<Clock, Clock> {
  template <class Duration>
  constexpr auto operator()(const time_point<Clock, Duration> &t) const
      -> time_point<Clock, Duration> {
    return t;
  }
};

// Explicit specialization for system_clock (per spec)
template <> struct clock_time_conversion<system_clock, system_clock> {
  template <class Duration>
  constexpr auto operator()(const sys_time<Duration> &t) const
      -> sys_time<Duration> {
    return t;
  }
};

// ============================================================================
// Clock -> system_clock (via SourceClock::to_sys)
// ============================================================================

template <class SourceClock>
  requires(!std::is_same_v<SourceClock, system_clock>)
struct clock_time_conversion<system_clock, SourceClock> {
  template <class Duration>
    requires requires(const time_point<SourceClock, Duration> &tp) {
      SourceClock::to_sys(tp);
    }
  constexpr auto operator()(const time_point<SourceClock, Duration> &t) const
      -> decltype(SourceClock::to_sys(t)) {
    return SourceClock::to_sys(t);
  }
};

// ============================================================================
// system_clock -> Clock (via DestClock::from_sys)
// ============================================================================

template <class DestClock>
  requires(!std::is_same_v<DestClock, system_clock>)
struct clock_time_conversion<DestClock, system_clock> {
  template <class Duration>
    requires requires(const sys_time<Duration> &tp) { DestClock::from_sys(tp); }
  constexpr auto operator()(const sys_time<Duration> &t) const
      -> decltype(DestClock::from_sys(t)) {
    return DestClock::from_sys(t);
  }
};

// ============================================================================
// Concept helpers for clock_cast routing
// ============================================================================

namespace detail {

template <class Dest, class Source, class Duration>
concept directly_castable = requires(const time_point<Source, Duration> &tp) {
  clock_time_conversion<Dest, Source>{}(tp);
};

template <class Dest, class Source, class Duration>
concept castable_via_sys = requires(const time_point<Source, Duration> &tp) {
  clock_time_conversion<Dest, system_clock>{}(
      clock_time_conversion<system_clock, Source>{}(tp));
};

} // namespace detail

// ============================================================================
// clock_cast
// ============================================================================

// Level 1: Direct conversion
template <class DestClock, class SourceClock, class Duration>
  requires detail::directly_castable<DestClock, SourceClock, Duration>
constexpr auto clock_cast(const time_point<SourceClock, Duration> &t) {
  return clock_time_conversion<DestClock, SourceClock>{}(t);
}

// Level 2: One hop through system_clock
template <class DestClock, class SourceClock, class Duration>
  requires(!detail::directly_castable<DestClock, SourceClock, Duration>) &&
  detail::castable_via_sys<DestClock, SourceClock, Duration>
constexpr auto clock_cast(const time_point<SourceClock, Duration> &t) {
  return clock_time_conversion<DestClock, system_clock>{}(
      clock_time_conversion<system_clock, SourceClock>{}(t));
}

/// Convert any time_point to milliseconds since system_clock epoch
template <class Clock, class Duration>
constexpr auto to_epoch_ms(const time_point<Clock, Duration> &t) -> std::int64_t {
  auto sys_tp = clock_cast<system_clock>(t);
  return duration_cast<milliseconds>(sys_tp.time_since_epoch()).count();
}

/// Convert any time_point to seconds since system_clock epoch
template <class Clock, class Duration>
constexpr auto to_epoch_s(const time_point<Clock, Duration> &t) -> std::int64_t {
  auto sys_tp = clock_cast<system_clock>(t);
  return duration_cast<seconds>(sys_tp.time_since_epoch()).count();
}

/// Convert any time_point to microseconds since system_clock epoch
template <class Clock, class Duration>
constexpr auto to_epoch_us(const time_point<Clock, Duration> &t) -> std::int64_t {
  auto sys_tp = clock_cast<system_clock>(t);
  return duration_cast<microseconds>(sys_tp.time_since_epoch()).count();
}

/// Convert epoch milliseconds back to a system_clock time_point
constexpr auto from_epoch_ms(std::int64_t ms) -> sys_time<milliseconds> {
  return sys_time<milliseconds>{milliseconds{ms}};
}

} // namespace Fond::Chrono

#endif // FOND_CHRONO_CLOCK_CAST_HPP
