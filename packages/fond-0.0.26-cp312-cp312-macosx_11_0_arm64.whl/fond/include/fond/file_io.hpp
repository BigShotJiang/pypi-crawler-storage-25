#pragma once

// file_io.hpp — File I/O operations, locking, caching, watching

#include "file_io/ops.hpp" // IWYU pragma: keep
#include "file_io/lock.hpp" // IWYU pragma: keep
#include "file_io/cache.hpp" // IWYU pragma: keep
#include "file_io/watcher.hpp" // IWYU pragma: keep
#include "file_io/mtime.hpp" // IWYU pragma: keep
