#pragma once

#include "fond/collections/arena.hpp"
#include "fond/collections/bitflag.hpp"
#include <cstdint>
#include <cstddef>
#include <type_traits>
#include <utility>

namespace Fond::Runtime {

struct TypeInfo {
    const char* name;
    size_t size;
    size_t alignment;

    void   (*destructor)(void*);
    bool   (*equality)(const void*, const void*); 
    size_t (*hash)(const void*);
    void   (*copy)(const void* src, void* dst);
    void   (*move)(void* src, void* dst);
};

enum class ObjFlags {
    Marked = 0,    // For GC marking
    Immutable = 1, // Immutable/frozen objects
    Interned = 2,  // Interned strings/symbols
    Builtin = 3,   // Built-in types (optional, for special handling)
    Immortal = 4,  // Objects that should never be freed (e.g. type objects)
};

using ObjectFlags = CollectionsCub::BitFlag<ObjFlags, 8>;

struct ObjHeader {
    uint8_t type_tag;
    ObjectFlags flags;
    uint16_t pad0_; // For future use
    uint16_t pad1_; // For future use
    uint16_t pad2_; // For future use
    TypeInfo *type;
};

// --- Type trait: any struct whose first member is ObjHeader ---

template <typename T>
concept IsObject = requires {
    requires std::is_standard_layout_v<T>;
    requires sizeof(T) >= sizeof(ObjHeader);
    { static_cast<T*>(nullptr)->header } -> std::same_as<ObjHeader&>;
};

// --- Arena-backed object creation ---

template <IsObject T, typename... Args>
T* obj_create(CollectionsCub::Arena& arena, uint8_t tag, TypeInfo* type, Args&&... args) {
    T* obj = arena.create<T>(std::forward<Args>(args)...);
    obj->header = ObjHeader{
        .type_tag = tag,
        .flags = ObjectFlags(),
        .pad0_ = 0,
        .pad1_ = 0,
        .pad2_ = 0,
        .type = type,
    };
    return obj;
}

// --- Casting utilities ---

inline ObjHeader* obj_header(void* ptr) { return static_cast<ObjHeader*>(ptr); }

template <IsObject T>
T* obj_as(ObjHeader* header) { return reinterpret_cast<T*>(header); }

template <IsObject T>
const T* obj_as(const ObjHeader* header) { return reinterpret_cast<const T*>(header); }

// --- ObjPtr: thin wrapper around ObjHeader* with convenience methods ---

struct ObjPtr {
    ObjHeader* ptr = nullptr;

    ObjPtr() = default;
    ObjPtr(ObjHeader* p) : ptr(p) {}

    template <IsObject T> ObjPtr(T* obj) : ptr(&obj->header) {}
    template <IsObject T> T* as() { return obj_as<T>(ptr); }
    template <IsObject T> const T* as() const { return obj_as<T>(ptr); }

    uint8_t tag() const { return ptr->type_tag; }
    TypeInfo* type() const { return ptr->type; }

    void destroy() { if (ptr && ptr->type && ptr->type->destructor) ptr->type->destructor(ptr); }
    bool equals(const ObjPtr& other) const {
        if (ptr == other.ptr) return true;
        if (!ptr || !other.ptr) return false;
        if (ptr->type_tag != other.ptr->type_tag) return false;
        if (ptr->type && ptr->type->equality) return ptr->type->equality(ptr, other.ptr);
        return false;
    }
    size_t hash() const {
        if (ptr && ptr->type && ptr->type->hash) return ptr->type->hash(ptr);
        return std::hash<void*>{}(ptr);
    }

    explicit operator bool() const { return ptr != nullptr; }
    ObjHeader* operator->() { return ptr; }
    const ObjHeader* operator->() const { return ptr; }

    bool operator==(const ObjPtr& other) const { return equals(other); }
    bool operator!=(const ObjPtr& other) const { return !equals(other); }
};

} // namespace Fond::Runtime
