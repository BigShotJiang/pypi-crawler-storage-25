#pragma once

#include <cstdio>

#ifdef LOGGER_ENABLED
#include "fond/logger/logger.hpp"
#define FOND_LOG(...)       Fond::Logging::g_logger.Info(__VA_ARGS__)
#define FOND_LOG_WARN(...)  Fond::Logging::g_logger.Warning(__VA_ARGS__)
#define FOND_LOG_ERR(...)   Fond::Logging::g_logger.Error(__VA_ARGS__)
#else
#define FOND_LOG(fmt, ...)       fprintf(stdout, fmt "\n" __VA_OPT__(,) __VA_ARGS__)
#define FOND_LOG_WARN(fmt, ...)  fprintf(stderr, "[WARN] " fmt "\n" __VA_OPT__(,) __VA_ARGS__)
#define FOND_LOG_ERR(fmt, ...)   fprintf(stderr, "[ERROR] " fmt "\n" __VA_OPT__(,) __VA_ARGS__)
#endif

#ifdef FOND_DEBUG
#define FOND_LOG_DEBUG(...)      FOND_LOG(__VA_ARGS__)
#define FOND_LOG_DEBUG_WARN(...) FOND_LOG_WARN(__VA_ARGS__)
#else
#define FOND_LOG_DEBUG(...)
#define FOND_LOG_DEBUG_WARN(...)
#endif
