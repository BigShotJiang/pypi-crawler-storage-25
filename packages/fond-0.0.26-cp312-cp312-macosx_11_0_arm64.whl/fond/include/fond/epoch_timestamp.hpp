#pragma once

#include <chrono>
#include <cstdint>
#include <format>
#include <string>

namespace Fond::Time {

constexpr const char* DEFAULT_TZ = "UTC";
constexpr int MILLISECONDS_IN_SECOND = 1000;
constexpr int MICROSECONDS_IN_SECOND = 1000000;

namespace SC = std::chrono;

// strftime format — override before including to customize
#ifndef FOND_TS_FMT
#define FOND_TS_FMT "%Y-%m-%d %H:%M:%S"
#endif

static inline struct tm *safe_localtime(const time_t *t, struct tm *out) {
#ifdef _WIN32
  localtime_s(out, t);
  return out;
#else
  return localtime_r(t, out);
#endif
}

static inline const char* get_ord_suffix(uint8_t day) {
    if (day >= 11 && day <= 13) return "th";
    switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
}

enum class TimestampPrecision {
    Seconds,
    Milliseconds,
    Microseconds
};

const TimestampPrecision DEFAULT_PRECISION = TimestampPrecision::Milliseconds;

struct EpochTimestamp {

    uint64_t timestamp;

    const char* tz;
    std::string str;

    uint16_t millisecond;
    uint16_t microsecond;
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    bool is_pm;

    TimestampPrecision precision;

    const char* ampm() const { return is_pm ? "PM" : "AM"; }

    template <TimestampPrecision P>
    static EpochTimestamp now() {
        EpochTimestamp ts = {};
        auto now = SC::system_clock::now();
        auto time_t_now = SC::system_clock::to_time_t(now);
        struct tm time_info;
        safe_localtime(&time_t_now, &time_info);
        auto epoch = now.time_since_epoch();
        ts.year = time_info.tm_year + 1900;
        ts.month = time_info.tm_mon + 1;
        ts.day = time_info.tm_mday;
        ts.hour = time_info.tm_hour;
        ts.is_pm = ts.hour >= 12;
        ts.minute = time_info.tm_min;
        ts.second = time_info.tm_sec;
        ts.millisecond = SC::duration_cast<SC::milliseconds>(epoch).count() % MILLISECONDS_IN_SECOND;
        ts.microsecond = SC::duration_cast<SC::microseconds>(epoch).count() % MICROSECONDS_IN_SECOND;
        ts.tz = time_info.tm_zone ? time_info.tm_zone : DEFAULT_TZ;
        char buf[32];
        strftime(buf, sizeof(buf), FOND_TS_FMT, &time_info);
        std::string time_str(buf);

        if constexpr (P == TimestampPrecision::Seconds) {
            ts.timestamp = SC::duration_cast<SC::seconds>(epoch).count();
            ts.precision = TimestampPrecision::Seconds;
            ts.str = std::format("{} {}", time_str, ts.tz);
        } else if constexpr (P == TimestampPrecision::Milliseconds) {
            ts.timestamp = SC::duration_cast<SC::milliseconds>(epoch).count();
            ts.precision = TimestampPrecision::Milliseconds;
            ts.str = std::format("{}.{:03d} {}", time_str, ts.millisecond, ts.tz);
        } else if constexpr (P == TimestampPrecision::Microseconds) {
            ts.timestamp = SC::duration_cast<SC::microseconds>(epoch).count();
            ts.precision = TimestampPrecision::Microseconds;
            ts.str = std::format("{}.{:06d} {}", time_str, ts.microsecond, ts.tz);
        }
        return ts;
    }

    std::string to_string() const { return str; }
    uint64_t to_int() const { return static_cast<uint64_t>(timestamp); }
    bool same_precision(const EpochTimestamp& other) const { return precision == other.precision; }

    auto operator<=>(const EpochTimestamp& other) const {
        if (!same_precision(other)) throw std::invalid_argument("Cannot compare timestamps with different precision");
        return timestamp <=> other.timestamp;
    }

    uint64_t since(const EpochTimestamp& other) const {
        if (!same_precision(other)) { throw std::invalid_argument("Cannot compare timestamps with different precision"); }
        return timestamp - other.timestamp;
    }
};

// Fast path — just a formatted string, no struct overhead
static inline std::string fast_now() {
    auto now = SC::system_clock::now();
    auto time_t_now = SC::system_clock::to_time_t(now);
    auto ms = SC::duration_cast<SC::milliseconds>(now.time_since_epoch()).count() % MILLISECONDS_IN_SECOND;
    struct tm ti;
    safe_localtime(&time_t_now, &ti);
    char buf[32];
    strftime(buf, sizeof(buf), FOND_TS_FMT, &ti);
    const char* tz = ti.tm_zone ? ti.tm_zone : DEFAULT_TZ;
    return std::format("{}.{:03d} {}", std::string(buf), ms, tz);
}

static inline EpochTimestamp now(TimestampPrecision default_precision = DEFAULT_PRECISION) { return EpochTimestamp::now<DEFAULT_PRECISION>(); }
static inline uint64_t time_since(const EpochTimestamp& start, const EpochTimestamp& end) { return end.since(start); }

} // namespace Fond::Time
