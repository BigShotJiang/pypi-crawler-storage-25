# fond/pygen — Python Code Generator for C++

## Overview
Pure C++ library for generating well-formatted Python source files. Lives in Fond as `fond/pygen/`. No Python/pybind11 dependency — outputs `std::string`.

## Design Principles
- Type-safe: Python types represented as C++ type aliases in `py::` namespace, not strings or enums
- Fluent API with method chaining (return `*this` by reference)
- Move semantics for composing structs (built in-place, moved into Module)
- Idempotent `render()` — safe to call multiple times
- pybind11-inspired `py::` namespace convention

## Python Type System (`types.hpp`)

### Type Aliases (`py::` namespace)
C++ types map to Python type names via `PyTypeName<T>` template specialization:
```cpp
py::str_    // std::string  → "str"
py::int_    // int64_t      → "int"
py::float_  // double       → "float"
py::bool_   // bool         → "bool"
py::None_   // std::nullptr_t → "None"
py::bytes_  // std::vector<uint8_t> → "bytes"
```

### Python Constants
```cpp
py::None      // "None"
py::True      // "True"
py::False     // "False"
py::Ellipsis  // "..."
py::NoneUnion // " | None"
```

### Tag-Dispatch Container Types
```cpp
py::to_<py::List, py::str_, py::int_>()  // "list[str | int]"
py::to_<py::Dict, py::str_, py::int_>()  // "dict[str, int]"
py::to_<py::Set, py::float_>()           // "set[float]"
py::to_<py::Tuple, py::str_, py::int_>() // "tuple[str, int]"
```

Tags carry formatting rules — `List`/`Set` join with ` | `, `Dict`/`Tuple` join with `, `.
Runtime overload accepts strings: `py::to_<py::Dict>(key, val)`.

### TypeHint Builder
```cpp
TypeHint::of<py::str_>()                          // str
TypeHint::optional<py::str_>()                     // str | None
Optional<py::str_>()                               // str | None (free function)
Optional(TypeHint::list_of<py::str_>())            // list[str] | None
TypeHint::list_of<py::str_>()                      // list[str]
TypeHint::dict_of<py::str_, py::int_>()            // dict[str, int]
TypeHint::set_of<py::float_>()                     // set[float]
TypeHint::union_of<py::str_, py::int_, py::bool_>() // str | int | bool
TypeHint::generic("Iterator", TypeHint::of<py::int_>()) // Iterator[int]
TypeHint::raw("MyCustomClass")                     // MyCustomClass
TypeHint::literal("a", "b", "c")                   // Literal["a", "b", "c"] (TODO)
```

### Quoting Helpers (`to_::` namespace)
```cpp
to_::str("hello")   // "\"hello\""
to_::doc("summary")  // "\"\"\"summary\"\"\""
```

## Core Types (`types.hpp`)
```cpp
struct Arg { std::string name; TypeHint type; std::optional<std::string> default_value; };
struct Attribute { std::string name; TypeHint type; std::optional<std::string> default_value; };
struct Decorator { std::string name; std::vector<std::string> args; };
struct Import { std::string module; std::vector<std::string> names; };
```

## Buffer Engine (`buffer.hpp`)
Indentation manager — the core rendering primitive:
- `indent()` / `dedent()` for manual control
- Scoped RAII guard via `scoped_indent()` for auto-dedent
- `line(str)` — writes with current indentation
- `blank()` — empty line
- `raw(str)` — writes without indentation
- `render()` → `std::string`
- `PYGEN_INDENT(level)` macro for standalone indent strings

## Function (`types.hpp`)
```cpp
Function("process_data")
    .arg("data", TypeHint::of<py::str_>())
    .arg("verbose", TypeHint::of<py::bool_>(), py::False)
    .returns(TypeHint::of<py::int_>())
    .decorator(Decorator("staticmethod"))
    .docstring("Process incoming data.")
    .line("result = len(data)")
    .line("if result < 0:")
    .block("raise ValueError(\"invalid\")")
    .line("return result");
```

- `.line()` adds a body line at base indentation
- `.block()` adds a body line indented one level (for `if`/`for`/`try` bodies)
- `.docstring()` renders as triple-quoted string after signature

## Classes (`classes.hpp`)

### PythonClass
```cpp
PythonClass("User")
    .base("BaseModel")
    .docstring("A user in the system.")
    .attr("name", TypeHint::of<py::str_>())
    .attr("age", TypeHint::of<py::int_>(), "0")
    .init_()  // auto-generates __init__ from attributes
    .method(Function("greet")  // auto-inserts self
        .returns(TypeHint::of<py::str_>())
        .line("return self.name"))
    .staticmethod(Function("create")  // no self, adds @staticmethod
        .returns(TypeHint::raw("User"))
        .line("return User()"))
    .classmethod(Function("from_dict")  // auto-inserts cls, adds @classmethod
        .returns(TypeHint::raw("User"))
        .line("return cls()"));
```

### Dataclass (`py::Dataclass`)
```cpp
py::Dataclass user("User");
user.decorators[0].add_arg("slots=True");
user.attr("name", TypeHint::of<py::str_>())
    .attr("age", TypeHint::of<py::int_>(), "0");
```

### PydanticBaseModel (`py::PydanticBaseModel`)
```cpp
py::PydanticBaseModel user("User");
user.attr("name", TypeHint::of<py::str_>());
```

### Enum
Auto-resolves import and base class from mixin string:
```cpp
Enum("Color", "str")   // → class Color(StrEnum), imports StrEnum
Enum("Perm", "flag")   // → class Perm(IntFlag), imports IntFlag
Enum("Status")          // → class Status(Enum), imports Enum
Enum("Code", "int")     // → class Code(IntEnum), imports IntEnum
```
```cpp
Enum color("Color", "str");
color.docstring("Available colors.")
     .value("RED", to_::str("red"))
     .value("BLUE", to_::str("blue"));
```

## Variables and Literals (`variables.hpp`)

### Variable
```cpp
Variable("VERSION", TypeHint::of<py::str_>(), to_::str("1.0.0"));
// VERSION: str = "1.0.0"
```

### Literal
Parameterized builder for list/dict/tuple/set literals:
```cpp
Literal::list_("COLORS")
    .str("red").str("green").str("blue");

Literal::dict_("CONFIG")
    .entry_str("host", "localhost")
    .entry_str("port", 8080)
    .entry_str("verbose", false);

Literal::tuple_("DIMS").item("1920").item("1080");
Literal::set_("TAGS").str("alpha").str("beta");
```

- `.str()` auto-quotes string values
- `.entry_str()` auto-quotes keys, handles string/int/bool values
- `.item()` / `.entry()` for raw unquoted values

## Import (`types.hpp`)
```cpp
Import::bare("os")                              // import os
Import::from("dataclasses", {"dataclass"})      // from dataclasses import dataclass
```

### Pre-built Imports (`py::`)
```cpp
py::annotations  // from __future__ import annotations
py::dataclass    // from dataclasses import dataclass
py::BaseModel    // from pydantic import BaseModel
py::Enum_        // from enum import Enum
py::StrEnum      // from enum import StrEnum
py::IntEnum      // from enum import IntEnum
py::IntFlag      // from enum import IntFlag
```

## Module (`module.hpp`)
Orchestrator that assembles a complete Python file:
```cpp
Module mod;
mod.header("# Auto-generated by Fond::PyGen")
   .docstring("Module description.")
   .import_(py::annotations)
   .import_(py::dataclass)
   .add(user_class)
   .add(helper_function)
   .add(config_literal);

std::string output = mod.render();
```

- Imports from classes with `imports` field are auto-collected via `HasImports` concept
- Header renders first, then docstring, then imports, then items with blank line separation

## File Structure
```
fond/pygen/
├── buffer.hpp      # Indentation engine + PYGEN_INDENT macro
├── types.hpp       # py:: namespace, TypeHint, Arg, Attribute, Decorator, Function, Import
├── classes.hpp     # PythonClass, Enum, py::Dataclass, py::PydanticBaseModel
├── variables.hpp   # Variable, Literal
├── module.hpp      # Module orchestrator + BufferRenderable/HasImports concepts
└── pygen.hpp       # Convenience header that includes everything (TODO)
```

## TODO
- `TypeHint::literal()` — `Literal["a", "b", "c"]` type annotations
- Import deduplication and auto-ordering (`__future__` first, alphabetical rest)
- Full Google-style docstring sections (Args, Returns, Raises, Examples)
- `pygen.hpp` convenience header
- `type_checking` section in Module (for `TYPE_CHECKING` guarded imports)
- Stubgen support (`.pyi` output mode)

## Non-Goals (for now)
- Python bindings (pybind11) — pure C++ only
- Manual section reordering
- Non-Google docstring styles
- AST parsing of existing Python files
- Typed control flow statements (if/for/while as structs)
