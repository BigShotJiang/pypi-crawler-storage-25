#pragma once

#include "fond/pygen/types.hpp"

namespace Fond::PyGen {

struct PythonClass {
    std::string name;
    std::vector<std::string> bases;
    std::vector<Decorator> decorators;
    std::optional<std::string> docstring_;
    std::vector<Attribute> attributes;
    std::vector<Function> methods;

    std::vector<Import> imports;

    explicit PythonClass(std::string name) : name(std::move(name)) {}

    PythonClass& base(std::string b) { bases.push_back(std::move(b)); return *this; }
    PythonClass& decorator(Decorator dec) { decorators.push_back(std::move(dec)); return *this; }
    PythonClass& docstring(std::string doc) { docstring_ = std::move(doc); return *this; }

    PythonClass& method(Function fn) {
        fn.args.insert(fn.args.begin(), Arg(py::self));
        methods.push_back(std::move(fn));
        return *this;
    }
    PythonClass& staticmethod(Function fn) {
        fn.decorators.insert(fn.decorators.begin(), Decorator(py::staticmethod));
        methods.push_back(std::move(fn));
        return *this;
    }
    PythonClass& classmethod(Function fn) {
        fn.decorators.insert(fn.decorators.begin(), Decorator(py::classmethod));
        fn.args.insert(fn.args.begin(), Arg(py::cls));
        methods.push_back(std::move(fn));
        return *this;
    }

    PythonClass& attr(std::string n, TypeHint type) {
        attributes.emplace_back(std::move(n), std::move(type));
        return *this;
    }
    PythonClass& attr(std::string n, TypeHint type, std::string d) {
        attributes.emplace_back(std::move(n), std::move(type), std::move(d));
        return *this;
    }

    PythonClass& init_() {
        Function init("__init__");
        for (const auto& a : attributes) {
            if (a.default_value)
                init.arg(a.name, a.type, *a.default_value);
            else
                init.arg(a.name, a.type);
        }
        for (const auto& a : attributes)
            init.line(std::string(py::self) + "." + a.name + " = " + a.name);
        method(std::move(init));
        return *this;
    }

    void render(Buffer& buf) const {
        for (const auto& dec : decorators) buf.line(dec.render());

        std::string header = "class " + name;
        if (!bases.empty()) {
            header += "(";
            for (size_t i = 0; i < bases.size(); ++i) {
                if (i > 0) header += ", ";
                header += bases[i];
            }
            header += ")";
        }
        header += ":";
        buf.line(header);

        auto g = buf.scoped_indent();
        if (docstring_) buf.line(to_::doc(*docstring_));
        if (attributes.empty() && methods.empty() && !docstring_) { buf.line(py::Ellipsis); return; }
        for (const auto& a : attributes) buf.line(a.render());
        for (const auto& m : methods) { buf.blank(); m.render(buf); }
    }
};

struct Enum : public PythonClass {
    Enum(std::string name, std::string mixin = "")
        : PythonClass(std::move(name)) {
        if (mixin.empty()) {
            imports.push_back(py::Enum_);
            bases.push_back(py::enum_);
        } else if (mixin == "str") {
            imports.push_back(py::StrEnum);
            bases.push_back(py::StrEnum.names[0]);
        } else if (mixin == "int") {
            imports.push_back(py::IntEnum);
            bases.push_back(py::IntEnum.names[0]);
        } else if (mixin == "flag") {
            imports.push_back(py::IntFlag);
            bases.push_back(py::IntFlag.names[0]);
        }
    }

    Enum& docstring(std::string doc) { docstring_ = std::move(doc); return *this; }

    Enum& value(std::string name, std::string val) {
        attributes.emplace_back(std::move(name), TypeHint::raw(""), std::move(val));
        return *this;
    }

    void render(Buffer& buf) const {
        for (const auto& dec : decorators) buf.line(dec.render());

        std::string header = "class " + name + "(";
        for (size_t i = 0; i < bases.size(); ++i) {
            if (i > 0) header += ", ";
            header += bases[i];
        }
        header += "):";
        buf.line(header);

        auto g = buf.scoped_indent();
        if (docstring_) buf.line(to_::doc(*docstring_));
        if (attributes.empty()) { buf.line(py::Ellipsis); return; }
        for (const auto& a : attributes)
            buf.line(a.name + " = " + *a.default_value);
    }
};

namespace py {
struct Dataclass : public PythonClass {
  Dataclass(std::string name) : PythonClass(std::move(name)) {
    decorators.emplace_back("dataclass");
    imports.push_back(py::dataclass);
}
};
struct PydanticBaseModel : public PythonClass {
    PydanticBaseModel(std::string name, bool config = false) : PythonClass(std::move(name)) {
        bases.push_back("BaseModel");
        imports.push_back(config ? py::BaseModel_config : py::BaseModel);
    }
};
} // namespace py

} // namespace Fond::PyGen
