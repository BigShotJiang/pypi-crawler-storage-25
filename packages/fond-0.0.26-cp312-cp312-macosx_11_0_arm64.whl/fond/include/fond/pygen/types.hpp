#pragma once

#include <string>
#include <vector>
#include <optional>
#include <cstdint>

#include "fond/pygen/buffer.hpp"

namespace Fond::PyGen {

template <typename T> struct PyTypeName;
template <> struct PyTypeName<std::string> { static constexpr const char* value = "str"; };
template <> struct PyTypeName<bool> { static constexpr const char* value = "bool"; };
template <> struct PyTypeName<int64_t> { static constexpr const char* value = "int"; };
template <> struct PyTypeName<uint64_t> { static constexpr const char* value = "int"; };
template <> struct PyTypeName<int32_t> { static constexpr const char* value = "int"; };
template <> struct PyTypeName<double> { static constexpr const char* value = "float"; };
template <> struct PyTypeName<float> { static constexpr const char* value = "float"; };
template <> struct PyTypeName<std::nullptr_t> { static constexpr const char* value = "None"; };
template <> struct PyTypeName<std::vector<uint8_t>> { static constexpr const char* value = "bytes"; };

namespace py {
using str_ = std::string;
using None_ = std::nullptr_t;
using bytes_ = std::vector<uint8_t>;
using int_ = int64_t;
using float_ = double;
using bool_ = bool;
constexpr const char* None = "None";
constexpr const char* NoneUnion = " | None";
constexpr const char* True = "True";
constexpr const char* False = "False";
constexpr const char* Any = "Any";
constexpr const char* Ellipsis = "...";
constexpr const char* dict = "dict";
constexpr const char* list = "list";
constexpr const char* set = "set";
constexpr const char* classmethod = "classmethod";
constexpr const char* staticmethod = "staticmethod";
constexpr const char* self = "self";
constexpr const char* cls = "cls";
constexpr const char* class_ = "class";
constexpr const char* enum_ = "Enum";
constexpr const char* multi_line = "\"\"\"";

struct List {
  static constexpr const char *name = "list";
  static constexpr const char *sep = " | ";
};

struct Dict {
  static constexpr const char *name = "dict";
  static constexpr const char *sep = ", ";
};

struct Set {
  static constexpr const char *name = "set";
  static constexpr const char *sep = " | ";
};

struct Tuple {
  static constexpr const char *name = "tuple";
  static constexpr const char *sep = ", ";
};

template <typename Tag, typename... Args>
static inline std::string to_() {
  std::string result = Tag::name;
  if constexpr (sizeof...(Args) == 0) return result;
  result += "[";
  size_t i = 0;
  ((result += (i++ > 0 ? Tag::sep : "") + std::string(PyTypeName<Args>::value)), ...);
  result += "]";
  return result;
}

template <typename Tag, typename... Args>
static inline std::string to_(const Args&... args) {
    std::string result = Tag::name;
    if constexpr (sizeof...(Args) == 0) return result;
    result += "[";
    size_t i = 0;
    ((result += (i++ > 0 ? Tag::sep : "") + args), ...);
    result += "]";
    return result;
}

} // namespace py

namespace to_ { // Literals
static inline std::string str(const std::string &s) { return "\"" + s + "\""; }
static inline std::string doc(const std::string &s) { return py::multi_line + s + py::multi_line; }
}

struct AnyType {};
template <> struct PyTypeName<AnyType> { static constexpr const char* value = py::Any; };

class TypeHint {
    std::string rendered_;

    explicit TypeHint(std::string rendered) : rendered_(std::move(rendered)) {}

public:
    template <typename T>
    static TypeHint of() { return TypeHint(PyTypeName<T>::value); }

    // Raw string escape hatch for custom/user-defined types
    static TypeHint raw(const std::string& name) { return TypeHint(name); }

    template <typename T>
    static TypeHint optional() {
        return TypeHint(std::string(PyTypeName<T>::value) + py::NoneUnion);
    }

    static TypeHint optional(const TypeHint& i) {
        return TypeHint(i.rendered_ + py::NoneUnion);
    }

    template <typename T>
    static TypeHint list_of() { return TypeHint(py::to_<py::List, T>()); }

    static TypeHint list_of(const TypeHint& i) {
        return TypeHint(py::to_<py::List>(i.rendered_));
    }

    template <typename T> static TypeHint tuple_of() { return TypeHint(py::to_<py::Tuple, T>()); }

    static TypeHint tuple_of(const TypeHint& i) {
        return TypeHint(py::to_<py::Tuple>(i.rendered_ + ", ..."));
    }

    template <typename K, typename V>
    static TypeHint dict_of() { return TypeHint(py::to_<py::Dict, K, V>()); }

    static TypeHint dict_of(const TypeHint& key, const TypeHint& val) {
        return TypeHint(py::to_<py::Dict>(key.rendered_, val.rendered_));
    }

    template <typename T>
    static TypeHint set_of() {return TypeHint(py::to_<py::Set, T>()); }

    static TypeHint set_of(const TypeHint& inner) {
        return TypeHint(py::to_<py::Set>(inner.rendered_));
    }

    template <typename... Ts>
    static TypeHint union_of() {
        std::string result;
        const char* names[] = { PyTypeName<Ts>::value... };
        for (size_t i = 0; i < sizeof...(Ts); ++i) {
            if (i > 0) result += " | ";
            result += names[i];
        }
        return TypeHint(result);
    }

    static TypeHint generic(const std::string& base, const TypeHint& param) {
        return TypeHint(base + "[" + param.rendered_ + "]");
    }
    const std::string& render() const { return rendered_; }
};

template <typename T>
TypeHint Optional() { return TypeHint::optional<T>(); }
inline TypeHint Optional(const TypeHint& i) { return TypeHint::optional(i); }

struct Decorator {
    std::string name;
    std::vector<std::string> args;

    explicit Decorator(std::string name) : name(std::move(name)) {}
    Decorator(std::string name, std::vector<std::string> args)
        : name(std::move(name)), args(std::move(args)) {}

    void add_arg(const std::string& arg) { args.push_back(arg); }

    std::string render() const {
        std::string result = "@" + name;
        if (!args.empty()) {
            result += "(";
            for (size_t i = 0; i < args.size(); ++i) {
                if (i > 0) result += ", ";
                result += args[i];
            }
            result += ")";
        }
        return result;
    }
};

struct Arg {
    std::string name;
    std::optional<TypeHint> type;
    std::optional<std::string> default_value;

    explicit Arg(std::string name) : name(std::move(name)) {}
    Arg(std::string name, TypeHint type) : name(std::move(name)), type(std::move(type)) {}
    Arg(std::string name, TypeHint type, std::string d)
        : name(std::move(name)), type(std::move(type)), default_value(std::move(d)) {}

    std::string render() const {
        std::string result = name;
        if (type) result += ": " + type->render();
        if (default_value) result += " = " + *default_value;
        return result;
    }
};

struct Attribute {
    std::string name;
    TypeHint type;
    std::optional<std::string> default_value;

    Attribute(std::string name, TypeHint type)
        : name(std::move(name)), type(std::move(type)) {}
    Attribute(std::string name, TypeHint type, std::string d)
        : name(std::move(name)), type(std::move(type)), default_value(std::move(d)) {}

    std::string render() const {
        auto type_str = type.render();
        std::string result = type_str.empty() ? name : name + ": " + type_str;
        if (default_value) result += " = " + *default_value;
        return result;
    }
};

struct Function {
    std::string name;
    std::vector<Arg> args;
    std::optional<TypeHint> return_type;
    std::vector<Decorator> decorators;
    std::optional<std::string> docstring_;
    std::vector<std::string> body;

    explicit Function(std::string name) : name(std::move(name)) {}

    Function& arg(std::string n) { args.emplace_back(std::move(n)); return *this; }
    Function& arg(std::string n, TypeHint type) { args.emplace_back(std::move(n), std::move(type)); return *this; }
    Function& arg(std::string n, TypeHint type, std::string def) {
        args.emplace_back(std::move(n), std::move(type), std::move(def));
        return *this;
    }
    Function& decorator(Decorator dec) { decorators.push_back(std::move(dec)); return *this; }
    Function& returns(TypeHint type) { return_type = std::move(type); return *this; }
    Function& docstring(std::string doc) { docstring_ = std::move(doc); return *this; }
    Function& line(std::string l) { body.push_back(std::move(l)); return *this; }
    Function& block(std::string l) { body.push_back(PYGEN_INDENT(1) + std::move(l)); return *this; }

    std::string render_signature() const {
        std::string result = "def " + name + "(";
        for (size_t i = 0; i < args.size(); ++i) {
            if (i > 0) result += ", ";
            result += args[i].render();
        }
        result += ")";
        if (return_type) result += " -> " + return_type->render();
        result += ":";
        return result;
    }

    void render(Buffer& buf) const {
        for (const auto& dec : decorators) buf.line(dec.render());
        buf.line(render_signature());
        auto g = buf.scoped_indent();
        if (docstring_) buf.line(to_::doc(*docstring_));
        if (body.empty() && !docstring_) {
            buf.line(py::Ellipsis);
        } else {
            for (const auto& l : body) buf.line(l);
        }
    }
};

struct Import {
    std::string module;
    std::vector<std::string> names;

    Import(std::string module, std::vector<std::string> names)
        : module(std::move(module)), names(std::move(names)) {}

    static Import bare(std::string module) { return Import(std::move(module), {}); }
    static Import from(std::string module, std::vector<std::string> names) {
        return Import(std::move(module), std::move(names));
    }

    void add_name(std::string name) { names.push_back(std::move(name)); }

    bool operator<(const Import& other) const {
        if (module != other.module) return module < other.module;
        return names < other.names;
    }

    bool operator==(const Import& other) const {
        return module == other.module && names == other.names;
    }

    std::string render() const {
        if (names.empty()) return "import " + module;
        std::string result = "from " + module + " import ";
        for (size_t i = 0; i < names.size(); ++i) { if (i > 0) result += ", "; result += names[i]; }
        return result;
    }
};

namespace py {
const inline Import annotations = Import::from("__future__", {"annotations"});
const inline Import dataclass = Import::from("dataclasses", {"dataclass"});
const inline Import BaseModel = Import::from("pydantic", {"BaseModel"});
const inline Import BaseModel_config = Import::from("pydantic", {"BaseModel", "ConfigDict"});
const inline Import Enum_ = Import::from("enum", {"Enum"});
const inline Import PathLib = Import::from("pathlib", {"Path"});
const inline Import StrEnum = Import::from("enum", {"StrEnum"});
const inline Import IntEnum = Import::from("enum", {"IntEnum"});
const inline Import IntFlag = Import::from("enum", {"IntFlag"});

const inline TypeHint Path_ = TypeHint::raw("Path");
const inline TypeHint AnyHint = TypeHint::of<AnyType>();
const inline TypeHint NoneHint = TypeHint::of<py::None_>();
const inline TypeHint NOT_DEFINED = TypeHint::raw("");
template <typename T> const inline TypeHint List_ = TypeHint::list_of<T>() ;
template <typename K, typename V> const inline TypeHint Dict_ = TypeHint::dict_of<K, V>();
template <typename T> const inline TypeHint Set_ = TypeHint::set_of<T>();
const inline TypeHint ListStr = TypeHint::list_of<py::str_>();
const inline TypeHint TupleAny = TypeHint::tuple_of(AnyHint);
} // namespace py

} // namespace Fond::PyGen
