#pragma once

#include "fond/pygen/types.hpp"

namespace Fond::PyGen {

struct Variable {
    std::string name;
    TypeHint type;
    std::string value;

    Variable(std::string name, TypeHint type, std::string value) : name(std::move(name)), type(std::move(type)), value(std::move(value)) {}

    void render(Buffer& buf) const { buf.line(name + ": " + type.render() + " = " + value); }
};

struct Literal {
    std::string name;
    std::string open;
    std::string close;
    TypeHint type;
    std::vector<std::string> items;

    Literal(std::string name, std::string open, std::string close, TypeHint type = py::AnyHint)
    : name(std::move(name)), open(std::move(open)), close(std::move(close)), type(std::move(type)) {}

    template <typename T> static Literal list_(std::string name) { return Literal(std::move(name), "[", "]", py::List_<T>); }
    template <typename K, typename V> static Literal dict_(std::string name) { return Literal(std::move(name), "{", "}", py::Dict_<K, V>); }
    static Literal tuple_(std::string name) { return Literal(std::move(name), "(", ")", py::AnyHint); }
    template <typename T> static Literal set_(std::string name) { return Literal(std::move(name), "{", "}", py::Set_<T>); }

    Literal& item(std::string val) { items.push_back(std::move(val)); return *this; }
    Literal& str(const std::string& val) { items.push_back(to_::str(val)); return *this; }

    Literal& entry(std::string key, std::string val) {
        items.push_back(std::move(key) + ": " + std::move(val));
        return *this;
    }
    Literal& entry_str(const std::string& key, const char* val) {
        items.push_back(to_::str(key) + ": " + to_::str(val));
        return *this;
    }
    Literal& entry_str(const std::string& key, const std::string& val) {
        items.push_back(to_::str(key) + ": " + to_::str(val));
        return *this;
    }
    Literal& entry_str(const std::string& key, int val) {
        items.push_back(to_::str(key) + ": " + std::to_string(val));
        return *this;
    }
    Literal& entry_str(const std::string& key, bool val) {
        items.push_back(to_::str(key) + ": " + (val ? py::True : py::False));
        return *this;
    }

    void render(Buffer& buf) const {
        if (items.empty()) {
            buf.line(name + " = " + open + close);
            return;
        }
        buf.line(name + " = " + open);
        {
            auto g = buf.scoped_indent();
            for (size_t i = 0; i < items.size(); ++i) {
                buf.line(items[i] + ",");
            }
        }
        buf.line(close);
    }
};

template <typename... Args>
Variable PythonDef(const std::string &vname, const TypeHint& type, const std::string& fname, Args ...args) {
    Variable var(vname, type, "");
    std::string value = fname + "(";
    size_t i = 0;
    ((value += (i++ > 0 ? ", " : "") + args), ...);
    value += ")";
    var.value = value;
    return var;
}

} // namespace Fond::PyGen
