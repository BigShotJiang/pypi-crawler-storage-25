#pragma once

#include "fond/pygen/types.hpp"
#include <functional>

namespace Fond::PyGen {

template <typename T>
concept BufferRenderable = requires(const T& t, Buffer& buf) { t.render(buf); };

template <typename T>
concept HasImports = requires(const T& t) { { t.imports } -> std::convertible_to<const std::vector<Import>&>; };

class Module {
    std::vector<Import> imports_;
    std::vector<std::function<void(Buffer&)>> items_;
    std::optional<std::string> header_;
    std::optional<std::string> docstring_;

    void collect_imports(const auto& item) {
        if constexpr (HasImports<std::remove_cvref_t<decltype(item)>>) {
            for (const auto& imp : item.imports) imports_.push_back(imp);
        }
    }

public:
    Module& header(std::string h) { header_ = std::move(h); return *this; }
    Module& docstring(std::string doc) { docstring_ = std::move(doc); return *this; }

    Module& import_(const Import& imp) { imports_.push_back(imp); return *this; }

    template <BufferRenderable T>
    Module& add(const T& item) {
        collect_imports(item);
        items_.push_back([item](Buffer& buf) { item.render(buf); });
        return *this;
    }

    Module& add(const Function& fn) {
        items_.push_back([fn](Buffer& buf) { fn.render(buf); });
        return *this;
    }

    std::string render() const {
        Buffer buf;

        if (header_) buf.raw(*header_);
        if (docstring_) buf.line(to_::doc(*docstring_));

        for (const auto& imp : imports_) buf.line(imp.render());
        if (!imports_.empty() && !items_.empty()) buf.blank();

        for (size_t i = 0; i < items_.size(); ++i) {
            if (i > 0) buf.blank();
            items_[i](buf);
        }

        return buf.render();
    }
};

} // namespace Fond::PyGen
