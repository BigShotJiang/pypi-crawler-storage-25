#pragma once

#include <string>
#include <vector>
#include <cstddef>

#define PYGEN_SPACES_PER_INDENT 4
#define PYGEN_INDENT(level) std::string((level) * PYGEN_SPACES_PER_INDENT, ' ')

namespace Fond::PyGen {

class Buffer {
    std::vector<std::string> lines_;
    size_t indent_ = 0;
    

public:
    void indent() { ++indent_; }
    void dedent() { if (indent_ > 0) --indent_; }

    // RAII guard for scoped indentation
    class IndentGuard {
        Buffer& buf_;
    public:
        explicit IndentGuard(Buffer& buf) : buf_(buf) { buf_.indent(); }
        ~IndentGuard() { buf_.dedent(); }
        IndentGuard(const IndentGuard&) = delete;
        IndentGuard& operator=(const IndentGuard&) = delete;
    };

    IndentGuard scoped_indent() { return IndentGuard(*this); }

    void line(const std::string& text) {
        lines_.push_back(PYGEN_INDENT(indent_) + text);
    }

    void blank() { lines_.emplace_back(); }
    void raw(const std::string& text) { lines_.push_back(text); }
    void lines(const std::vector<std::string>& text) { for (const auto& l : text) line(l); }
    bool empty() const { return lines_.empty(); }

    std::string render() const {
        std::string result;
        size_t total = 0;
        for (const auto& l : lines_) total += l.size() + 1;
        result.reserve(total);
        for (const auto& l : lines_) { result += l; result += '\n'; }
        return result;
    }
};

} // namespace Fond::PyGen
