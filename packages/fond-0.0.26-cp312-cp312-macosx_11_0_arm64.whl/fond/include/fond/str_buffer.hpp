#pragma once

#include <string>
#include <string_view>
#include <cstddef>

namespace Fond {

constexpr const char *INDENT = "    ";

class StrBuffer {
    std::string buf_;
    size_t indent_ = 0;

public:
    StrBuffer() = default;
    explicit StrBuffer(size_t reserve) { buf_.reserve(reserve); }

    StrBuffer& write(std::string_view s) {
        for (size_t i = 0; i < indent_; ++i) buf_ += INDENT;
        buf_.append(s);
        buf_ += '\n';
        return *this;
    }

    template <typename... Args>
        requires (sizeof...(Args) > 1 && (std::convertible_to<Args, std::string_view> && ...))
    StrBuffer& write(Args&&... args) {
        for (size_t i = 0; i < indent_; ++i) buf_ += INDENT;
        (buf_.append(std::string_view(args)), ...);
        buf_ += '\n';
        return *this;
    }

    StrBuffer& write_raw(std::string_view s) {
        buf_.append(s);
        return *this;
    }

    StrBuffer& append(std::string_view s) {
        buf_.append(s);
        return *this;
    }

    StrBuffer& append(char c) {
        buf_ += c;
        return *this;
    }

    StrBuffer& nl() {
        buf_ += '\n';
        return *this;
    }

    StrBuffer& indent() { ++indent_; return *this; }
    StrBuffer& dedent() { if (indent_ > 0) --indent_; return *this; }
    void set_indent(size_t n) { indent_ = n; }

    size_t size() const { return buf_.size(); }
    bool empty() const { return buf_.empty(); }
    void clear() { buf_.clear(); indent_ = 0; }
    void reserve(size_t n) { buf_.reserve(n); }

    std::string_view view() const { return buf_; }
    const std::string& str() const { return buf_; }
    std::string take() { return std::move(buf_); }

    const char* c_str() const { return buf_.c_str(); }
};

static inline std::string wrap(std::string_view open, std::string_view s, std::string_view close) {
    std::string out;
    out.reserve(open.size() + s.size() + close.size());
    out.append(open);
    out.append(s);
    out.append(close);
    return out;
}

static inline std::string wrap_paren(std::string_view s) { return wrap("(", s, ")"); }
static inline std::string wrap_brace(std::string_view s) { return wrap("{", s, "}"); }
static inline std::string wrap_bracket(std::string_view s) { return wrap("[", s, "]"); }
static inline std::string wrap_angle(std::string_view s) { return wrap("<", s, ">"); }
static inline std::string wrap_quote(std::string_view s) { return wrap("\"", s, "\""); }
static inline std::string wrap_single_quote(std::string_view s) { return wrap("'", s, "'"); }

} // namespace Fond
