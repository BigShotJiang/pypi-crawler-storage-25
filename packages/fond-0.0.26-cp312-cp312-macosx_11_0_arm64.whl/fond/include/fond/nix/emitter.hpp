#pragma once

#include "fond/nix/value.hpp"
#include "fond/nix/keyword_check.hpp"
#include "fond/pygen/types.hpp"
#include "fond/str_utils.hpp"
#include "fond/pygen/module.hpp"
#include "fond/pygen/classes.hpp"
#include "fond/pygen/variables.hpp"
#include "fond/file_io.hpp" // IWYU pragma: keep
#include <string>
#include <string_view>
#include <vector>

namespace Fond::Nix {

constexpr const char *EQUOTE = "\"";

using namespace Fond::PyGen;
using namespace Fond::FileIO;

using Fond::Str::to_pascal;
using Fond::Str::to_snake;

static inline std::string keyword_safe_name(std::string_view name) {
    std::string result(name);
    if (!keyword_lookup(name).empty()) result += '_';
    return result;
}

static constexpr std::string_view HOME_PREFIX = "/Users/chaz/";

struct EmittedClass {
    std::string name;
    PythonClass cls;
};

class Emitter {
    std::string home_path_;
    std::string root_class_name_;
    std::string instance_name_;
    std::vector<EmittedClass> classes_;
    bool needs_path_ = false;

    bool is_home_path(std::string_view sv) const { return sv.starts_with(home_path_); }

    bool is_real_path(const ArenaString& s) const {
        auto sv = std::string_view(s.data(), s.size());
        if (sv.empty() || sv[0] != '/') return false;
        return exists(std::string(sv));
    }

    std::string make_path_expr(std::string_view sv) const {
        if (is_home_path(sv)) {
            auto relative = sv.substr(home_path_.size());
            return "HOME /" + std::string(EQUOTE) + std::string(relative) + EQUOTE;
        }
        return "Path(" + std::string(EQUOTE) + std::string(sv) + EQUOTE + ")";
    }

    std::string format_default(const NixValue& val) {
        if (val.is_string()) {
            auto& s = val.as_string();
            if (is_real_path(s)) {
                needs_path_ = true;
                return make_path_expr(std::string_view(s.data(), s.size()));
            }
            return EQUOTE + std::string(s.data(), s.size()) + EQUOTE;
        }
        if (val.is_int()) return std::to_string(val.as_int());
        if (val.is_float()) {
            auto s = std::to_string(val.as_float());
            auto dot = s.find('.');
            if (dot != std::string::npos) {
                auto last = s.find_last_not_of('0');
                if (last > dot) s.erase(last + 1);
                else s.erase(dot + 2);
            }
            return s;
        }
        if (val.is_bool()) return val.as_bool() ? py::True : py::False;
        if (val.is_null()) return py::None;
        if (val.is_array()) {
            auto& arr = val.as_array();
            std::string result = "(";
            for (size_t i = 0; i < arr.size(); ++i) {
                if (i > 0) result += ", ";
                result += format_default(arr[i]);
            }
            result += ")";
            return result;
        }
        return py::None;
    }

    TypeHint type_for(const NixValue& val) {
        if (val.is_string()) {
            auto& s = val.as_string();
            if (is_real_path(s)) { needs_path_ = true; return py::Path_; }
            return TypeHint::of<py::str_>();
        }
        if (val.is_int()) return TypeHint::of<py::int_>();
        if (val.is_float()) return TypeHint::of<py::float_>();
        if (val.is_bool()) return TypeHint::of<py::bool_>();
        if (val.is_array()) {
            auto &arr = val.as_array();
            TypeHint elem_type = type_for(arr.empty() ? NixValue() : arr[0]);
            if (!arr.empty()) return TypeHint::tuple_of(elem_type);
            return py::TupleAny;
        }
        return py::NoneHint;
    }

    std::string emit_attrset(std::string_view name, const nix::attrset& attrs) {
        auto class_name = to_pascal(name);
        PythonClass cls(class_name);
        cls.base("FrozenModel");

        for (const auto& [k, v] : attrs) {
            auto key = std::string(k.data(), k.size());
            auto safe = keyword_safe_name(to_snake(key));

            if (v.is_attrset()) {
                auto nested_class = to_pascal(key);
                emit_attrset(key, v.as_attrset());
                cls.attr(safe, TypeHint::raw(nested_class), nested_class + "()");
            } else {
                cls.attr(safe, type_for(v), format_default(v));
            }
        }

        classes_.push_back({class_name, std::move(cls)});
        return class_name;
    }

public:
    Emitter(std::string home_path = "/Users/chaz",
            std::string root_class = "NixConfig",
            std::string instance = "nix_config")
        : home_path_(std::move(home_path))
        , root_class_name_(std::move(root_class))
        , instance_name_(std::move(instance)) {
        if (!home_path_.ends_with('/')) home_path_ += '/';
    }

    std::string emit(const NixValue& root) {
        if (!root.is_attrset()) throw std::runtime_error("nix emitter: root must be an attrset");

        classes_.clear();
        needs_path_ = false;
        emit_attrset("root", root.as_attrset());

        Module mod;
        mod.docstring("This file is auto-generated from lib.nix - DO NOT EDIT MANUALLY");
        if (needs_path_) mod.import_(py::PathLib);

        if (needs_path_) {
            auto home_no_slash = home_path_.substr(0, home_path_.size() - 1);
            mod.add(PythonDef("HOME", py::Path_, "Path", to_::str(home_no_slash)));
        }

        py::PydanticBaseModel frozen("FrozenModel", true);
        frozen.attr("model_config", py::NOT_DEFINED, "ConfigDict(frozen=True)");
        mod.add(frozen);

        // Emit leaf classes first (they were added first), root class last
        for (auto& [name, cls] : classes_) {
            if (name == "Root") {
                cls.name = root_class_name_;
                cls.docstring_ = "Root model for the entire configuration.";
            }
            mod.add(cls);
        }

        Buffer buf;
        buf.blank();
        PythonDef(instance_name_, TypeHint::raw(root_class_name_), root_class_name_).render(buf);
        buf.blank();
        Literal all = Literal::list_<py::str_>("__all__");
        all.item(to_::str(root_class_name_)).item(to_::str(instance_name_)).render(buf);
        return mod.render() + buf.render();
    }
};

} // namespace Fond::Nix
