#pragma once

#include "fond/nix/value.hpp"
#include "fond/str_utils.hpp"
#include <string>
#include <string_view>
#include <cctype>
#include <cstddef>

namespace Fond::Nix {

struct WriterConfig {
    size_t indent_spaces = 2;
    bool sort_keys = false;
    bool inline_lists = true;
    bool inline_arrays = true;
    size_t max_inline_list = 8;
};

class Writer {
    WriterConfig cfg_;

    std::string indent(size_t depth) const {
        return std::string(cfg_.indent_spaces * depth, ' ');
    }

    bool is_atomic(const NixValue& val) const {
        return val.is_null() || val.is_bool() || val.is_int() || val.is_float() || val.is_string();
    }

    bool should_inline_list(const nix::array& arr) const {
        if (!cfg_.inline_lists) return false;
        if (arr.size() > cfg_.max_inline_list) return false;
        for (const auto& item : arr) {
            if (!is_atomic(item)) return false;
        }
        return true;
    }

    bool should_inline_attrset(const nix::attrset& attrs, bool in_array) const {
        if (!in_array || !cfg_.inline_arrays) return false;
        for (const auto& [k, v] : attrs) {
            if (!is_atomic(v)) return false;
        }
        return true;
    }

    std::string escape_string(std::string_view sv) const { return str::escape_string(sv); }

    std::string emit_value(const NixValue& val, size_t depth, bool in_array = false) const {
        if (val.is_null()) return "null";
        if (val.is_bool()) return val.as_bool() ? "true" : "false";
        if (val.is_int()) return std::to_string(val.as_int());
        if (val.is_float()) {
            auto s = std::to_string(val.as_float());
            auto dot = s.find('.');
            if (dot != std::string::npos) {
                auto last = s.find_last_not_of('0');
                if (last > dot) s.erase(last + 1);
                else s.erase(dot + 2);
            }
            return s;
        }
        if (val.is_string()) {
            auto& str = val.as_string();
            return escape_string(std::string_view(str.data(), str.size()));
        }
        if (val.is_array()) return emit_array(val.as_array(), depth);
        if (val.is_attrset()) return emit_attrset(val.as_attrset(), depth, in_array);
        return "null";
    }

    std::string emit_array(const nix::array& arr, size_t depth) const {
        if (arr.empty()) return "[ ]";

        if (should_inline_list(arr)) {
            std::string out = "[ ";
            for (size_t i = 0; i < arr.size(); ++i) {
                if (i > 0) out += ' ';
                out += emit_value(arr[i], depth + 1, false);
            }
            out += " ]";
            return out;
        }

        std::string out = "[\n";
        for (const auto& item : arr) {
            out += indent(depth + 1) + emit_value(item, depth + 1, true) + "\n";
        }
        out += indent(depth) + "]";
        return out;
    }

    std::string emit_attrset(const nix::attrset& attrs, size_t depth, bool in_array = false) const {
        if (attrs.empty()) return "{ }";

        if (should_inline_attrset(attrs, in_array)) {
            std::string out = "{ ";
            for (const auto& [k, v] : attrs) {
                out += emit_key(k) + " = " + emit_value(v, depth + 1) + "; ";
            }
            out += "}";
            return out;
        }

        std::string out = "{\n";
        for (const auto& [k, v] : attrs) {
            out += indent(depth + 1) + emit_key(k) + " = " + emit_value(v, depth + 1) + ";\n";
        }
        out += indent(depth) + "}";
        return out;
    }

    std::string emit_key(const ArenaString& key) const {
        auto sv = std::string_view(key.data(), key.size());
        if (is_bare_identifier(sv)) return std::string(sv);
        return escape_string(sv);
    }

    static bool is_bare_identifier(std::string_view sv) {
        if (sv.empty()) return false;
        char first = sv[0];
        if (!(std::isalpha(static_cast<unsigned char>(first)) || first == '_')) return false;
        for (size_t i = 1; i < sv.size(); ++i) {
            char c = sv[i];
            if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '-' || c == '\'')) return false;
        }
        return true;
    }

public:
    Writer() = default;
    explicit Writer(WriterConfig cfg) : cfg_(std::move(cfg)) {}

    std::string write(const NixValue& val) const { return emit_value(val, 0) + "\n"; }
};

} // namespace Fond::Nix
