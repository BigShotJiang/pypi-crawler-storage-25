#pragma once

#include <string_view>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace Fond::Nix {

constexpr std::string_view RETURN_SENTINEL = "";

static inline std::string_view keyword_lookup(std::string_view str) {
    const size_t len = str.size();
    if (len < 2 || len > 8) return RETURN_SENTINEL;
    const auto key0 = static_cast<uint8_t>(str[0]);
    switch (key0) {
    case 0x00000061: /* 'a' */
    {
        {
            const auto key1 = static_cast<uint8_t>(str[len - 1]);
            switch (key1) {
            case 0x00000063: /* 'c' */
                if (str == "async") return "async";
                break;
            case 0x00000064: /* 'd' */
                if (str[1] == 'n') return "and";
                break;
            case 0x00000073: /* 's' */
                return "as";
                break;
            case 0x00000074: /* 't' */
                if (str == "assert") return "assert";
                if (str == "await") return "await";
                break;
            }
        }
        break;
    } break;
    case 0x00000062: /* 'b' */
    {
        {
            const auto key2 = static_cast<uint8_t>(str[len - 1]);
            switch (key2) {
            case 0x0000006b: /* 'k' */
                if (str == "break") return "break";
                break;
            case 0x0000006e: /* 'n' */
                if (str[1] == 'i') return "bin";
                break;
            }
        }
        break;
    } break;
    case 0x00000063: /* 'c' */
    {
        {
            const auto key3 = static_cast<uint8_t>(str[len - 1]);
            switch (key3) {
            case 0x00000065: /* 'e' */
                if (str == "continue") return "continue";
                break;
            case 0x00000073: /* 's' */
                if (str == "class") return "class";
                if (str == "cls") return "cls";
                break;
            }
        }
        break;
    } break;
    case 0x00000064: /* 'd' */
    {
        {
            const auto key4 = static_cast<uint8_t>(str[len - 1]);
            switch (key4) {
            case 0x00000066: /* 'f' */
                if (str[1] == 'e') return "def";
                break;
            case 0x0000006c: /* 'l' */
                if (str[1] == 'e') return "del";
                break;
            case 0x00000074: /* 't' */
                if (str == "dict") return "dict";
                break;
            }
        }
        break;
    } break;
    case 0x00000065: /* 'e' */
    {
        {
            const auto key5 = static_cast<uint8_t>(str[len - 1]);
            switch (key5) {
            case 0x00000065: /* 'e' */
                if (str == "else") return "else";
                break;
            case 0x00000066: /* 'f' */
                if (str == "elif") return "elif";
                break;
            case 0x00000074: /* 't' */
                if (str == "except") return "except";
                break;
            }
        }
        break;
    } break;
    case 0x00000066: /* 'f' */
    {
        {
            const auto key6 = static_cast<uint8_t>(str[len - 1]);
            switch (key6) {
            case 0x0000006d: /* 'm' */
                if (str == "from") return "from";
                break;
            case 0x00000072: /* 'r' */
                if (str == "filter") return "filter";
                if (str == "for") return "for";
                break;
            case 0x00000079: /* 'y' */
                if (str == "finally") return "finally";
                break;
            }
        }
        break;
    } break;
    case 0x00000067: /* 'g' */
        if (str == "global") return "global";
        break;
    case 0x00000068: /* 'h' */
        if (str == "hash") return "hash";
        break;
    case 0x00000069: /* 'i' */
    {
        {
            const auto key7 = static_cast<uint8_t>(str[len - 1]);
            switch (key7) {
            case 0x00000064: /* 'd' */
                return "id";
                break;
            case 0x00000066: /* 'f' */
                return "if";
                break;
            case 0x0000006e: /* 'n' */
                return "in";
                break;
            case 0x00000073: /* 's' */
                return "is";
                break;
            case 0x00000074: /* 't' */
                if (str == "import") return "import";
                if (str == "input") return "input";
                break;
            }
        }
        break;
    } break;
    case 0x0000006c: /* 'l' */
    {
        {
            const auto key8 = static_cast<uint8_t>(str[len - 1]);
            switch (key8) {
            case 0x00000061: /* 'a' */
                if (str == "lambda") return "lambda";
                break;
            case 0x00000074: /* 't' */
                if (str == "list") return "list";
                break;
            }
        }
        break;
    } break;
    case 0x0000006d: /* 'm' */
        if (str == "map") return "map";
        break;
    case 0x0000006e: /* 'n' */
    {
        {
            const auto key9 = static_cast<uint8_t>(str[len - 1]);
            switch (key9) {
            case 0x0000006c: /* 'l' */
                if (str == "nonlocal") return "nonlocal";
                break;
            case 0x00000074: /* 't' */
                if (str[1] == 'o') return "not";
                break;
            }
        }
        break;
    } break;
    case 0x0000006f: /* 'o' */
    {
        {
            const auto key10 = static_cast<uint8_t>(str[len - 1]);
            switch (key10) {
            case 0x00000072: /* 'r' */
                return "or";
                break;
            case 0x00000074: /* 't' */
                if (str == "object") return "object";
                break;
            }
        }
        break;
    } break;
    case 0x00000070: /* 'p' */
    {
        {
            const auto key11 = static_cast<uint8_t>(str[len - 1]);
            switch (key11) {
            case 0x00000073: /* 's' */
                if (str == "pass") return "pass";
                break;
            case 0x00000079: /* 'y' */
                if (str == "property") return "property";
                break;
            }
        }
        break;
    } break;
    case 0x00000072: /* 'r' */
    {
        {
            const auto key12 = static_cast<uint8_t>(str[len - 1]);
            switch (key12) {
            case 0x00000065: /* 'e' */
                if (str == "raise") return "raise";
                if (str == "range") return "range";
                break;
            case 0x0000006e: /* 'n' */
                if (str == "return") return "return";
                break;
            }
        }
        break;
    } break;
    case 0x00000073: /* 's' */
    {
        {
            const auto key13 = static_cast<uint8_t>(str[len - 1]);
            switch (key13) {
            case 0x00000072: /* 'r' */
                if (str == "super") return "super";
                break;
            case 0x00000074: /* 't' */
                if (str[1] == 'e') return "set";
                break;
            }
        }
        break;
    } break;
    case 0x00000074: /* 't' */
    {
        {
            const auto key14 = static_cast<uint8_t>(str[len - 1]);
            switch (key14) {
            case 0x00000065: /* 'e' */
                if (str == "type") return "type";
                break;
            case 0x00000079: /* 'y' */
                if (str[1] == 'r') return "try";
                break;
            }
        }
        break;
    } break;
    case 0x00000076: /* 'v' */
        if (str == "vars") return "vars";
        break;
    case 0x00000077: /* 'w' */
    {
        {
            const auto key15 = static_cast<uint8_t>(str[len - 1]);
            switch (key15) {
            case 0x00000065: /* 'e' */
                if (str == "while") return "while";
                break;
            case 0x00000068: /* 'h' */
                if (str == "with") return "with";
                break;
            }
        }
        break;
    } break;
    case 0x00000079: /* 'y' */
        if (str == "yield") return "yield";
        break;
    }
    return RETURN_SENTINEL;
}

} // namespace Fond::Nix
