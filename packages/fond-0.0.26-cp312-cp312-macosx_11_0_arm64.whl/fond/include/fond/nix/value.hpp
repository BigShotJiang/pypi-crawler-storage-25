#pragma once

#include <cstdint>
#include <variant>
#include <vector>

#include "fond/collections/arena.hpp"
#include "fond/collections/maps.hpp" // IWYU pragma: keep

namespace Fond::Nix {

using Arena = CollectionsCub::Arena;

using NixStr = ArenaString;

struct NixValue;

namespace nix {
constexpr const char* True = "true";
constexpr const char* False = "false";
constexpr const char* Null = "null";

using array = std::vector<NixValue, ArenaAlloc<NixValue>>;
using attrset = CollectionsCub::OrderedMap<ArenaString, NixValue,
    ArenaAlloc<std::pair<const ArenaString, NixValue>>>;
} // namespace nix

struct NixNull {
    bool operator==(const NixNull&) const { return true; }
};

struct NixValue {
    std::variant<
        NixNull,
        bool,
        int64_t,
        double,
        NixStr,
        nix::array,
        nix::attrset
    > data;

    NixValue() : data(NixNull{}) {}
    NixValue(NixNull) : data(NixNull{}) {}
    NixValue(bool v) : data(v) {}
    NixValue(int64_t v) : data(v) {}
    NixValue(int v) : data(static_cast<int64_t>(v)) {}
    NixValue(double v) : data(v) {}
    NixValue(NixStr v) : data(std::move(v)) {}
    NixValue(nix::array v) : data(std::move(v)) {}
    NixValue(nix::attrset v) : data(std::move(v)) {}

    // Convenience: construct arena string from std::string_view
    NixValue(std::string_view sv, Arena& arena)
        : data(ArenaString(sv.data(), sv.size(), ArenaAlloc<char>(arena))) {}

    bool is_null() const { return std::holds_alternative<NixNull>(data); }
    bool is_bool() const { return std::holds_alternative<bool>(data); }
    bool is_int() const { return std::holds_alternative<int64_t>(data); }
    bool is_float() const { return std::holds_alternative<double>(data); }
    bool is_string() const { return std::holds_alternative<NixStr>(data); }
    bool is_array() const { return std::holds_alternative<nix::array>(data); }
    bool is_attrset() const { return std::holds_alternative<nix::attrset>(data); }

    bool& as_bool() { return std::get<bool>(data); }
    int64_t& as_int() { return std::get<int64_t>(data); }
    double& as_float() { return std::get<double>(data); }
    NixStr& as_string() { return std::get<NixStr>(data); }
    nix::array& as_array() { return std::get<nix::array>(data); }
    nix::attrset& as_attrset() { return std::get<nix::attrset>(data); }

    const bool& as_bool() const { return std::get<bool>(data); }
    const int64_t& as_int() const { return std::get<int64_t>(data); }
    const double& as_float() const { return std::get<double>(data); }
    const NixStr& as_string() const { return std::get<NixStr>(data); }
    const nix::array& as_array() const { return std::get<nix::array>(data); }
    const nix::attrset& as_attrset() const { return std::get<nix::attrset>(data); }

    template <typename T>
    T get(T fallback = {}) const {
        if constexpr (std::is_same_v<T, bool>) {
            return is_bool() ? as_bool() : fallback;
        } else if constexpr (std::is_same_v<T, int64_t> || std::is_integral_v<T>) {
            return is_int() ? static_cast<T>(as_int()) : fallback;
        } else if constexpr (std::is_same_v<T, double> || std::is_floating_point_v<T>) {
            return is_float() ? static_cast<T>(as_float()) : fallback;
        } else if constexpr (std::is_same_v<T, NixStr>) {
            return is_string() ? as_string() : fallback;
        } else {
            return fallback;
        }
    }

    NixValue& operator[](const NixStr& key) { return as_attrset()[key]; }
    NixValue& operator[](size_t index) { return as_array()[index]; }
};

} // namespace Fond::Nix
