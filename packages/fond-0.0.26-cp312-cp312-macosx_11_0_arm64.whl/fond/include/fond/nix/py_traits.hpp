#pragma once

#include "fond/nix/value.hpp"
#include "fond/py_tools/py_convert.hpp"

namespace Fond::PyTools {

template <>
struct ValueTraits<Fond::Nix::NixValue> {
    using none_type = Fond::Nix::NixNull;
    using array_type = Fond::Nix::nix::array;
    using map_type = Fond::Nix::nix::attrset;
    using string_type = ArenaString;
    using arena_type = CollectionsCub::Arena;
    template <typename T> using alloc_type = ArenaAlloc<T>;
    static constexpr bool has_uint64 = false;
};

} // namespace Fond::PyTools
