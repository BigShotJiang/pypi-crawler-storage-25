# py_tools — Schema-driven binary row serialization

Serialize Python dicts/objects to packed binary rows using a schema definition.
Originally adapted from a vector database project, generalized for any
schema-driven binary storage (databases, network protocols, save files).

## Overview

- **bytes_row.hpp** — Schema, FieldType, BytesRow serializer (pure C++)
- **py_accessors.hpp** — Python dict/object accessors for BytesRow (pybind11)

## Quick start

```cpp
#include <fond/py_tools/bytes_row.hpp>
#include <fond/py_tools/py_accessors.hpp>

using namespace Fond::RowCodec;
using namespace Fond::PyTools;

// Define a schema
auto schema = std::make_shared<Schema>(std::vector<FieldDef>{
    {"id",    FieldType::INT64,  0, int64_t{0}},
    {"name",  FieldType::STRING, 1, std::string{""}},
    {"score", FieldType::FLOAT32, 2, float{0.0f}},
});

// Serialize a Python dict to packed bytes
BytesRow row(schema);
PyDictAccessor accessor(*schema);
std::string packed = row.serialize_template(py_dict, accessor);

// Or from a Python object with attributes
PyObjectAccessor obj_accessor(*schema);
std::string packed = row.serialize_template(py_obj, obj_accessor);
```

## Accessor interface

The `BytesRow::serialize_template` is generic — any type that implements the
accessor interface works. `PyDictAccessor` and `PyObjectAccessor` are provided
for Python interop, but you could write a C++ accessor for native structs.

## Binary format

```
[field_count (1 byte)]
[fixed fields at known offsets (int64=8, uint64=8, float32=4, bool=1)]
[offset pointers for variable fields (4 bytes each)]
[variable region: length-prefixed strings, lists, binary data]
```

Fixed fields use direct offset math (zero parsing). Variable fields require
one pointer chase from the fixed region to the variable tail.
