#pragma once

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <cstdint>
#include <string>
#include <type_traits>
#include <variant>

namespace py = pybind11;

namespace Fond::PyTools {

// Traits — specialize per codec to declare which variant alternatives
// represent arrays, maps, none, and optional extras like bytes/uint64.
template <typename Value> struct ValueTraits;

// Concept: does this trait have a bytes type?
template <typename T>
concept HasBytes = requires { typename ValueTraits<T>::bytes_type; };

// Helper: resolve bytes_type or fallback to void (for safe use in if constexpr)
template <typename Value, bool = HasBytes<Value>>
struct BytesTypeOr { using type = typename ValueTraits<Value>::bytes_type; };
template <typename Value>
struct BytesTypeOr<Value, false> { using type = void; };

// Concept: does this trait have a uint64 type?
template <typename T>
concept HasUint64 = ValueTraits<T>::has_uint64;

// Concept: does this trait need an arena for from_py?
template <typename T>
concept NeedsArena = requires { typename ValueTraits<T>::arena_type; };

// Concept: string-like (has data() and size(), convertible to string_view)
template <typename T>
concept StringLike = requires(const T& s) {
    { s.data() } -> std::convertible_to<const char*>;
    { s.size() } -> std::convertible_to<size_t>;
};

// ════════════════════════════════════════════════════════════════════
// C++ Value → Python object
// ════════════════════════════════════════════════════════════════════

template <typename Value>
static inline py::object to_py(const Value& val) {
    return std::visit([](auto&& arg) -> py::object {
        using T = std::decay_t<decltype(arg)>;
        using Tr = ValueTraits<Value>;

        if constexpr (std::is_same_v<T, typename Tr::none_type>) {
            return py::none();
        } else if constexpr (std::is_same_v<T, bool>) {
            return py::bool_(arg);
        } else if constexpr (std::is_same_v<T, int64_t>) {
            return py::int_(arg);
        } else if constexpr (std::is_same_v<T, double>) {
            return py::float_(arg);
        } else if constexpr (StringLike<T>) {
            return py::str(arg.data(), arg.size());
        } else if constexpr (std::is_same_v<T, typename Tr::array_type>) {
            py::list list(arg.size());
            for (size_t i = 0; i < arg.size(); ++i)
                list[i] = to_py<Value>(arg[i]);
            return list;
        } else if constexpr (std::is_same_v<T, typename Tr::map_type>) {
            py::dict dict;
            for (const auto& [key, value] : arg)
                dict[py::str(key.data(), key.size())] = to_py<Value>(value);
            return dict;
        } else if constexpr (HasBytes<Value> && std::is_same_v<T, typename BytesTypeOr<Value>::type>) {
            return py::bytes(reinterpret_cast<const char*>(arg.data()), arg.size());
        } else if constexpr (std::is_same_v<T, uint64_t>) {
            return py::int_(arg);
        } else {
            return py::none();
        }
    }, val.data);
}

// ════════════════════════════════════════════════════════════════════
// Python object → C++ Value
// ════════════════════════════════════════════════════════════════════

template <typename Value>
static inline Value from_py(const py::object& obj) {
    using Tr = ValueTraits<Value>;

    if (obj.is_none()) return Value{typename Tr::none_type{}};
    if (py::isinstance<py::bool_>(obj)) return Value{obj.cast<bool>()};
    if (py::isinstance<py::int_>(obj)) {
        if constexpr (HasUint64<Value>) {
            try {
                return Value{obj.cast<int64_t>()};
            } catch (const py::cast_error&) {
                return Value{obj.cast<uint64_t>()};
            }
        } else {
            return Value{obj.cast<int64_t>()};
        }
    }

    if (py::isinstance<py::float_>(obj)) return Value{obj.cast<double>()};
    if (py::isinstance<py::str>(obj)) return Value{obj.cast<std::string>()};

    if constexpr (HasBytes<Value>) {
        if (py::isinstance<py::bytes>(obj)) {
            auto s = obj.cast<std::string>();
            return Value{typename Tr::bytes_type(s.begin(), s.end())};
        }
    }

    if (py::isinstance<py::list>(obj) || py::isinstance<py::tuple>(obj)) {
        typename Tr::array_type arr;
        for (auto item : obj)
            arr.push_back(from_py<Value>(py::reinterpret_borrow<py::object>(item)));
        return Value{std::move(arr)};
    }

    if (py::isinstance<py::dict>(obj)) {
        typename Tr::map_type map;
        for (auto item : obj.cast<py::dict>()) {
            auto key = item.first.cast<std::string>();
            auto val = from_py<Value>(py::reinterpret_borrow<py::object>(item.second));
            if constexpr (requires { map[key] = val; }) {
                map[key] = std::move(val);
            } else {
                map.insert(key, std::move(val));
            }
        }
        return Value{std::move(map)};
    }

    throw py::type_error("Unsupported type: " + std::string(py::str(py::type(obj))));
}

// ════════════════════════════════════════════════════════════════════
// Python object → C++ Value (arena-backed variant)
// ════════════════════════════════════════════════════════════════════

template <typename Value>
static inline Value from_py(const py::object& obj, typename ValueTraits<Value>::arena_type& arena) requires NeedsArena<Value> {
    using Tr = ValueTraits<Value>;
    using string_type = typename Tr::string_type;
    using alloc_char = typename Tr::template alloc_type<char>;
    using alloc_value = typename Tr::template alloc_type<Value>;
    using alloc_pair = typename Tr::template alloc_type<std::pair<const string_type, Value>>;

    if (obj.is_none()) return Value{typename Tr::none_type{}};
    if (py::isinstance<py::bool_>(obj)) return Value{obj.cast<bool>()};
    if (py::isinstance<py::int_>(obj)) return Value{obj.cast<int64_t>()};
    if (py::isinstance<py::float_>(obj)) return Value{obj.cast<double>()};

    if (py::isinstance<py::str>(obj)) {
        auto s = obj.cast<std::string>();
        return Value{string_type(s.data(), s.size(), alloc_char(arena))};
    }

    if (py::isinstance<py::list>(obj) || py::isinstance<py::tuple>(obj)) {
        typename Tr::array_type arr{alloc_value(arena)};
        for (auto item : obj)
            arr.push_back(from_py<Value>(py::reinterpret_borrow<py::object>(item), arena));
        return Value{std::move(arr)};
    }

    if (py::isinstance<py::dict>(obj)) {
        typename Tr::map_type map{alloc_pair(arena)};
        for (auto item : obj.cast<py::dict>()) {
            auto key_str = item.first.cast<std::string>();
            string_type key{key_str.data(), key_str.size(), alloc_char(arena)};
            auto val = from_py<Value>(py::reinterpret_borrow<py::object>(item.second), arena);
            map.insert(std::move(key), std::move(val));
        }
        return Value{std::move(map)};
    }

    throw py::type_error("Unsupported type: " + std::string(py::str(py::type(obj))));
}

} // namespace Fond::PyTools
