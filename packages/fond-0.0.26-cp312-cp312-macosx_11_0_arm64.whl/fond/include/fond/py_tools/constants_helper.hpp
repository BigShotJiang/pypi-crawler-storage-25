#pragma once

#include <Python.h>
#include <pybind11/pybind11.h>

#include <stdexcept>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <variant>

namespace py = pybind11;

namespace PyConstantsHelper {

using ConstantValue = std::variant<int, double, bool, std::string>;

struct PyConstants {
    std::unordered_map<std::string, ConstantValue> constants;

    PyConstants() = default;
    ~PyConstants() = default;

    bool has_key(const std::string& name) const { return constants.count(name) > 0; }

    template <typename T>
    bool has_key_of(const std::string& name) const {
        auto it = constants.find(name);
        return it != constants.end() && std::holds_alternative<T>(it->second);
    }

    bool has_int_key(const std::string& name) const { return has_key_of<int>(name); }
    bool has_double_key(const std::string& name) const { return has_key_of<double>(name); }
    bool has_bool_key(const std::string& name) const { return has_key_of<bool>(name); }
    bool has_string_key(const std::string& name) const { return has_key_of<std::string>(name); }

    size_t size() const { return constants.size(); }
    bool empty() const { return constants.empty(); }

    void add_constant(const std::string& name, PyObject* obj) {
        // PyBool_Check before PyLong_Check — bools are a subtype of ints in Python's C API
        if (PyBool_Check(obj)) {
            constants[name] = static_cast<bool>(PyObject_IsTrue(obj));
        } else if (PyLong_Check(obj)) {
            constants[name] = static_cast<int>(PyLong_AsLong(obj));
        } else if (PyFloat_Check(obj)) {
            constants[name] = PyFloat_AsDouble(obj);
        } else if (PyUnicode_Check(obj)) {
            constants[name] = std::string(PyUnicode_AsUTF8(obj));
        } else {
            throw std::invalid_argument("Unsupported constant type");
        }
    }

    template <typename T>
    T get_constant(const std::string& name) const {
        auto it = constants.find(name);
        if (it == constants.end()) throw std::out_of_range("Constant not found: " + name);
        if (!std::holds_alternative<T>(it->second)) throw std::out_of_range("Type mismatch for: " + name);
        return std::get<T>(it->second);
    }

    template <typename T>
    T get_or(const std::string& name, T default_value) const {
        auto it = constants.find(name);
        if (it == constants.end() || !std::holds_alternative<T>(it->second)) return default_value;
        return std::get<T>(it->second);
    }
};

template <typename Module>
inline void bind_py_constants(Module& m) {
    py::class_<PyConstants>(m, "PyConstants")
        .def(py::init<>())
        .def("add", [](PyConstants& self, const std::string& name, py::object obj) -> PyConstants& {
            self.add_constant(name, obj.ptr());
            return self;
        }, py::return_value_policy::reference, py::arg("name"), py::arg("obj"))
        .def("has_key", &PyConstants::has_key, py::arg("name"))
        .def("has_int_key", &PyConstants::has_int_key, py::arg("name"))
        .def("has_double_key", &PyConstants::has_double_key, py::arg("name"))
        .def("has_bool_key", &PyConstants::has_bool_key, py::arg("name"))
        .def("has_string_key", &PyConstants::has_string_key, py::arg("name"))
        .def("size", &PyConstants::size)
        .def("empty", &PyConstants::empty)
        .def("ptr", [](PyConstants& self) {
            return py::capsule(&self, "PyConstantsHelper::PyConstants");
        }, "Get a capsule containing a pointer to this PyConstants instance");
}

template <typename Module>
inline void bind_set_constants(Module& m, PyConstants*& target) {
    m.def("set_constants", [&target](py::capsule cap) {
        void* ptr = PyCapsule_GetPointer(cap.ptr(), "PyConstantsHelper::PyConstants");
        if (!ptr) throw std::runtime_error("Invalid capsule!");
        target = reinterpret_cast<PyConstants*>(ptr);
    }, py::arg("constants"), "Set the constants from a capsule");

    m.def("repr_constants", [&target]() -> std::string {
        if (!target) return "<PyConstants not set>";
        std::string repr = "<PyConstants";
        bool has_any = false;
        for (const auto& [key, val] : target->constants) {
            repr += has_any ? ", " : ": ";
            repr += key;
            repr += " (";
            std::visit([&](auto&& v) {
                using T = std::decay_t<decltype(v)>;
                if constexpr (std::is_same_v<T, int>) repr += "int";
                else if constexpr (std::is_same_v<T, double>) repr += "double";
                else if constexpr (std::is_same_v<T, bool>) repr += "bool";
                else if constexpr (std::is_same_v<T, std::string>) repr += "str";
            }, val);
            repr += ")";
            has_any = true;
        }
        repr += has_any ? ">" : ": none>";
        return repr;
    });
}

}  // namespace PyConstantsHelper
