#pragma once

#include <string>
#include <sstream>
#include <stdexcept>

struct ExitCode {
  enum Value {
    Success = 0,
    Failure = 1,
    MisuseOfShellCommand = 2,
    CommandCannotExecute = 126,
    CommandNotFound = 127,
    InvalidArgumentToExit = 128,
    ScriptTerminatedByControlC = 130,
    ProcessKilledBySigkill = 137,
    SegmentationFault = 139,
    ProcessTerminatedBySigterm = 143,
    ExitStatusOutOfRange = 255
  };

  Value value;
  ExitCode(Value v) : value(v) {}
  ExitCode() : value(Success) {}

  int to_int() const { return static_cast<int>(value); }
  operator Value() const { return value; }
  operator int() const { return to_int(); }
};

enum class VersionParts : int {
    Major = 0,
    Minor = 1,
    Patch = 2
};

struct ProjectVersion {
    int major = 0;
    int minor = 0;
    int patch = 0;

    ProjectVersion() = default;
    constexpr ProjectVersion(int maj, int min, int pat) : major(maj), minor(min), patch(pat) {}

    constexpr ProjectVersion bump(VersionParts part) const {
        switch (part) {
            case VersionParts::Major: return ProjectVersion(major + 1, 0, 0);
            case VersionParts::Minor: return ProjectVersion(major, minor + 1, 0);
            case VersionParts::Patch: return ProjectVersion(major, minor, patch + 1);
        }
        return *this;
    }

    constexpr bool is_default() const { return major == 0 && minor == 0 && patch == 0; }

    static constexpr ProjectVersion as_default() { return ProjectVersion(0, 0, 0); }

    ProjectVersion bump(const std::string& part_name) const {
        if (part_name == "major") return bump(VersionParts::Major);
        if (part_name == "minor") return bump(VersionParts::Minor);
        if (part_name == "patch") return bump(VersionParts::Patch);
        throw std::invalid_argument("Invalid bump type: " + part_name);
    }

    static ProjectVersion from_string(const std::string& version_str) {
        ProjectVersion v;
        std::istringstream ss(version_str);
        char dot;
        ss >> v.major;
        if (ss.peek() == '.') { ss >> dot >> v.minor; }
        if (ss.peek() == '.') { ss >> dot >> v.patch; }
        return v;
    }

    std::string to_string() const { return std::to_string(major) + "." + std::to_string(minor) + "." + std::to_string(patch); }
    bool operator==(const ProjectVersion& other) const { return major == other.major && minor == other.minor && patch == other.patch; }

    bool operator<(const ProjectVersion& other) const {
        if (major != other.major) return major < other.major;
        if (minor != other.minor) return minor < other.minor;
        return patch < other.patch;
    }
};

struct Variable {
    std::string name;
    std::string value;
};
