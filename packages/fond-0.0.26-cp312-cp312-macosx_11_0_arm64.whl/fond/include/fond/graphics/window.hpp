#pragma once

#include "fwd.hpp"

#ifdef FOND_USE_GLFW
#include "fond/log.hpp"
#include "fond/graphics/frame_time.hpp"
#include "fond/graphics/input.hpp"
#ifdef FOND_USE_SHADERS
#include "fond/graphics/primitives.hpp"
#endif

#include <functional>

namespace Fond::Graphics {

static inline bool init_glfw() {
    if (!glfwInit()) return false;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_STENCIL_BITS, 8);
    return true;
}

static inline bool create_window(GLFWwindow*& window, int width, int height, const char* title) {
    window = glfwCreateWindow(width, height, title, NULL, NULL);
    return window != nullptr;
}

static inline bool make_context_current(GLFWwindow* window) {
    if (window) glfwMakeContextCurrent(window);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        FOND_LOG_ERR("Failed to initialize GLAD");
        return false;
    }
    return true;
}

struct KeyInputCallback {
    int key;
    int action = GLFW_PRESS;
    std::function<void()> callback;
};

inline std::vector<KeyInputCallback> g_key_input_callbacks;

static inline void key_callback(GLFWwindow *window, int key, int, int action, int) {
    if (g_key_input_callbacks.empty()) return;

    for (const auto& callback : g_key_input_callbacks) {
        if (key == callback.key && action == callback.action) {
            callback.callback();
        }
    }
}



class GlfwWindow {
public:
    int width, height, fb_width, fb_height;
    bool vsync;
    const char* title;
    GLFWwindow* window;

    GlfwWindow(int width, int height, int fps, const char* title, bool vsync = false)
        : width(width), height(height), fb_width(0), fb_height(0), 
        vsync(vsync), title(title), window(nullptr),
        frame_time_(), fps_target_(static_cast<float>(fps)), mouse_pos_() {}

    ~GlfwWindow() { if (window) { glfwDestroyWindow(window); glfwTerminate(); } }

    GlfwWindow(const GlfwWindow&) = delete;
    GlfwWindow& operator=(const GlfwWindow&) = delete;

    bool initialized_ = false;

    void add_callback(int key, std::function<void()> callback, int action = GLFW_PRESS) {
        g_key_input_callbacks.push_back({key, action, callback});
    }

    bool initialize() {
        if (initialized_) return true;
        if (!init_glfw()) return false;
        if (!create_window(window, width, height, title)) return false;
        if (!make_context_current(window)) return false;
        mouse_pos_.set_window(window);
        set_vsync(vsync);
        glfwSetKeyCallback(window, key_callback);
#ifdef FOND_USE_SHADERS
        prim_batch_.set_values(width, height);
        if (!prim_batch_.init()) {
            FOND_LOG_ERR("Failed to initialize PrimBatch");
            return false;
        }
#endif
        initialized_ = true;
        return true;
    }

    void set_vsync(bool enabled) { glfwSwapInterval(enabled ? 1 : 0); }
    bool should_close() { return glfwWindowShouldClose(window); }

    void process_events() {
        mouse_pos_.update();
        glfwPollEvents();
        frame_time_.tick(fps_target_);
    }

    void setup_frame(float r=1.0f, float g=0.08f, float b=0.58f, float a=1.0f) {
        glfwGetFramebufferSize(window, &fb_width, &fb_height);
        glViewport(0, 0, fb_width, fb_height);
        glDisable(GL_DEPTH_TEST);
        glClearColor(r, g, b, a);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    }

    void swap_buffers() {
        #ifdef FOND_USE_SHADERS
        FlushPrimitives();
        #endif
        glfwSwapBuffers(window);
    }
    void SetTargetFPS(int fps) { fps_target_ = static_cast<float>(fps); }
    FrameTime& frame_time() { return frame_time_; }
    MousePosition& mouse_pos() { return mouse_pos_; }
    float fps() { return frame_time_.GetFPS(); }
    float dt() { return frame_time_.GetFrameTime(); }

#ifdef FOND_USE_SHADERS
    PrimBatch& prim_batch() { return prim_batch_; }
#endif

private:
    FrameTime frame_time_;
    float fps_target_;
    MousePosition mouse_pos_;
#ifdef FOND_USE_SHADERS
    PrimBatch prim_batch_;
#endif
};

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW
