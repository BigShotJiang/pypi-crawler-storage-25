# fond/graphics — Compile-Time Configuration

All graphics functionality is gated behind `#define` flags. Nothing compiles unless you opt in.

## Required Defines

| Define | Description | Without it |
|---|---|---|
| `FOND_USE_GLFW` | Enables all GLFW-based code: window, input, frame timing | All graphics headers are empty |
| `FOND_USE_SHADERS` | Enables shader loading, PrimBatch, draw primitives, text rendering | Window/input/frame timing still work, but no drawing |

**Minimum viable setup:**
```cpp
#define FOND_USE_GLFW
#include "fond/graphics/glfw_helper.hpp"
// Window, input, frame timing — no shaders/drawing
```

**Full setup:**
```cpp
#define FOND_USE_GLFW
#define FOND_USE_SHADERS
#include "fond/graphics/glfw_helper.hpp"
// Everything: window, input, shaders, primitives, text
```

## Optional Defines

| Define | Type | Description |
|---|---|---|
| `FOND_HOT_RELOAD` | flag | Shaders auto-reload when files change (FileWatcher background thread). Without it, shaders load once at init. Use for dev, omit for shipping. |
| `FOND_ARENA_PRIMS` | size (bytes) | Arena-backed vertex buffers in PrimBatch. Set to arena size in bytes (e.g. `65536` for 64KB). Without it, uses standard `std::vector`. Use for variable draw loads with spikes (e.g. minimap with changing sector counts). |
| `FOND_DEBUG` | flag | Enables `FOND_LOG_DEBUG(...)` output. Without it, all debug logs are no-ops. |
| `LOGGER_ENABLED` | flag | Routes `FOND_LOG/WARN/ERR` through Fond's full logger system. Without it, falls back to `fprintf`. |

**Wormhole-wiggles example:**
```cpp
#define FOND_USE_GLFW
#define FOND_USE_SHADERS
#define FOND_HOT_RELOAD          // dev build only
#define FOND_ARENA_PRIMS 65536   // 64KB arena for vert buffers
#define FOND_DEBUG                // debug logging
#define LOGGER_ENABLED           // full logger
```

**Shipping build:**
```cpp
#define FOND_USE_GLFW
#define FOND_USE_SHADERS
// That's it. No hot reload, no arena, no debug logs.
```

## File Structure

```
fond/graphics/
├── fwd.hpp            # Forward declarations, GL/GLFW includes
├── frame_time.hpp     # FrameTime (FPS tracking, frame limiting)
├── input.hpp          # MousePosition, KeyStates, MouseStates
├── window.hpp         # GlfwWindow (init, teardown, frame setup)
├── shaders/
│   └── load_shaders.hpp  # Shader loading (hot/cold via FOND_HOT_RELOAD)
├── primitives.hpp     # PrimBatch, DrawRect/Line/Circle/Pixel (arena via FOND_ARENA_PRIMS)
├── text.hpp           # DrawChar, DrawText, DrawFPS (8x8 bitmap font)
├── 8x8font.hpp        # Font data
└── glfw_helper.hpp    # Convenience include-all + flat API + global state
```

## Dependency Chain

```
fwd.hpp ← frame_time.hpp ← window.hpp ← glfw_helper.hpp
fwd.hpp ← input.hpp      ←─────────────┘
           load_shaders.hpp ← primitives.hpp ← text.hpp
                                      └──────── glfw_helper.hpp (ifdef FOND_USE_SHADERS)
```

## Arena Performance Notes

Benchmarked with 1000 frames:

| Scenario | std::vector | Arena | Winner |
|---|---|---|---|
| Uniform 200 draws/frame | 1.72ms | 2.40ms | std::vector |
| Variable 100-300 + 2000 spikes | 1.35ms | 996µs | Arena (26% faster) |

Arena wins when draw counts vary significantly between frames (map transitions, sector changes). std::vector wins when load is stable (vectors reuse their allocation via `clear()`).
