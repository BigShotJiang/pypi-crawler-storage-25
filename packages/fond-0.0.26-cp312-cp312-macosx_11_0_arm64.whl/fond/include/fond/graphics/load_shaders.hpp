#pragma once

#include "fwd.hpp" // IWYU pragma: keep
#include "../file_io/ops.hpp" // IWYU pragma: keep
#include "../file_io/cache.hpp"
#include "../log.hpp"
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

namespace Fond::Graphics {

inline FileIO::FileCache g_shader_cache;

inline const char* ReadShaderHot(const fs::path& path) {
    if (!g_shader_cache.has(path))
        if (!g_shader_cache.watch(path)) return nullptr;
    return g_shader_cache.get(path).c_str();
}

inline const char* ReadShaderOnce(const fs::path& path) {
    if (!g_shader_cache.has(path))
        if (!g_shader_cache.load(path)) return nullptr;
    return g_shader_cache.get(path).c_str();
}

static inline GLuint CompileShaderStr(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetShaderInfoLog(s, 512, nullptr, log);
        FOND_LOG_ERR("Shader compilation failed:\n%s", log);
    }
    return s;
}

struct Shaders {
    GLuint vert;
    GLuint frag;

    Shaders(const std::string& path, const std::string& name, bool hot_reload = false) {
        auto read = hot_reload ? ReadShaderHot : ReadShaderOnce;
        const char* vert_src = read((fs::path(path) / (name + ".vert")).string());
        const char* frag_src = read((fs::path(path) / (name + ".frag")).string());
        vert = CompileShaderStr(GL_VERTEX_SHADER, vert_src);
        frag = CompileShaderStr(GL_FRAGMENT_SHADER, frag_src);
    }
};

} // namespace Fond::Graphics
