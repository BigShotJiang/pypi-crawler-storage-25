#pragma once


#if defined(FOND_USE_GLFW) && defined(FOND_USE_SHADERS)

#include "primitives.hpp"
#include "frame_time.hpp"
#include "8x8font.hpp"
#include "../colors/palette.hpp"
#include <cstdio>
#include <string>


namespace Fond::Graphics {

static inline void DrawChar(char c, float x, float y, const Fond::Color& color, float scale = 1.0f) {
    if (c < 32 || c > 127) return;
    const uint8_t* glyph = font8x8_basic[(uint8_t)c];
    for (int rows = 0; rows < 8; rows++) {
        for (int cols = 0; cols < 8; cols++) {
            if (glyph[rows] & (1 << cols)) {
                DrawRect(x + cols * scale, y + rows * scale, scale, scale, color);
            }
        }
    }
}

static inline void DrawText(const std::string& text, float x, float y, const Fond::Color& color, float scale = 1.0f) {
    for (size_t i = 0; i < text.size(); i++) {
        DrawChar(text[i], x + i * 8.0f * scale, y, color, scale);
    }
}

static inline char FPSBuffer[16];

static inline void DrawFPS(float x, float y, const FrameTime& ft, float size = 3.0f) {
    snprintf(FPSBuffer, sizeof(FPSBuffer), "FPS: %.2f", ft.GetFPS());
    for (size_t i = 0; FPSBuffer[i]; i++)
        DrawChar(FPSBuffer[i], x + i * 8.0f * size, y, Fond::Colors::WHITE, size);
}

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW && FOND_USE_SHADERS
