#pragma once

#ifdef FOND_USE_GLFW
#ifndef GLAD_GL_INCLUDED
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define GLAD_GL_INCLUDED
#endif
#endif
