#pragma once

#ifdef FOND_USE_GLFW

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <unordered_map>

namespace Fond::Graphics {

using Vec2 = glm::vec2;
using dVec2 = glm::dvec2;
using KeyStates = std::unordered_map<int, bool>;
using MouseStates = std::unordered_map<int, bool>;

struct MousePosition {
    dVec2 pos_;
    Vec2 pos;
    dVec2 last;
    Vec2 delta;
    GLFWwindow* window;

    MousePosition()
        : pos_(0.0, 0.0), pos(0.0f, 0.0f), last(0.0, 0.0), delta(0.0f, 0.0f), window(nullptr) {}

    void set_window(GLFWwindow* win) { window = win; }
    void update() {
        last = pos_;
        glfwGetCursorPos(window, &pos_.x, &pos_.y);
        pos.x = (float)pos_.x;
        pos.y = (float)pos_.y;
        delta.x = (float)(pos_.x - last.x);
        delta.y = (float)(pos_.y - last.y);
    }

    const Vec2& GetMousePos() const { return pos; }
    const Vec2& GetMouseDelta() const { return delta; }
};

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW
