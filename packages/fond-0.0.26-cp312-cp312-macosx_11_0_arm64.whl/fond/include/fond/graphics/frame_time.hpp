#pragma once

#include "fwd.hpp" // IWYU pragma: keep
#ifdef FOND_USE_GLFW
#include <chrono>
#include <thread>

namespace Fond::Graphics {

constexpr int FPS_READINGS = 100;
constexpr float FPS_READINGS_F = static_cast<float>(FPS_READINGS);

struct FrameTime {
    double prev_time;
    float dt;
    float fps_calc;
    float fps_readings[FPS_READINGS];
    float actual_fps;

    FrameTime() : prev_time(glfwGetTime()), dt(0.0f), fps_calc(0.0f), fps_readings{}, actual_fps(0.0f) {}

    void tick(int target_fps) {
        double frame_target = 1.0 / target_fps;
        double now = glfwGetTime();
        double elapsed = now - prev_time;
        if (elapsed < frame_target) {
            double sleep_time = frame_target - elapsed - 0.001;
            std::this_thread::sleep_for(std::chrono::duration<double>(sleep_time));
            while (glfwGetTime() - prev_time < frame_target);
        }
        now = glfwGetTime();
        dt = (float)(now - prev_time);
        prev_time = now;
        fps_calc = 1.0f / dt;
        for (int i = FPS_READINGS - 1; i > 0; i--) fps_readings[i] = fps_readings[i - 1];
        fps_readings[0] = fps_calc;
        float sum = 0.0f;
        for (float f : fps_readings) sum += f;
        actual_fps = sum / FPS_READINGS_F;
    }

    float GetFPS() const { return actual_fps; }
    float GetFrameTime() const { return dt; }
};

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW
