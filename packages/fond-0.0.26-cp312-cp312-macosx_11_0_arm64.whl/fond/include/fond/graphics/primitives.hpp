#pragma once

#include "fwd.hpp" // IWYU pragma: keep

#if defined(FOND_USE_GLFW) && defined(FOND_USE_SHADERS)
#include <vector>
#include <cmath>

#include "fond/log.hpp"
#include "fond/graphics/load_shaders.hpp"
#include "fond/colors/color.hpp"

#ifdef FOND_ARENA_PRIMS
#include "fond/collections/arena.hpp"
#endif

#ifndef FOND_SHADERS_PATH
#define FOND_SHADERS_PATH "common/shaders"
#endif

namespace Fond::Graphics {

#ifdef FOND_ARENA_PRIMS
using VertAlloc = CollectionsCub::ArenaAllocator<float>;
using Verts = std::vector<float, VertAlloc>;
#else
using Verts = std::vector<float>;
#endif

struct PrimBatch {
#ifdef FOND_ARENA_PRIMS
    CollectionsCub::Arena vert_arena_{FOND_ARENA_PRIMS};
    VertAlloc alloc_{vert_arena_};
    Verts pending_point_verts{alloc_};
    Verts pending_line_verts{alloc_};
    Verts pending_tri_verts{alloc_};
    Verts pending_tri_f_verts{alloc_};
#else
    Verts pending_point_verts;
    Verts pending_line_verts;
    Verts pending_tri_verts;
    Verts pending_tri_f_verts;
#endif
    GLuint shader, vao, vbo;
    GLuint loc_screen;
    int width, height;

    PrimBatch() : shader(0), vao(0), vbo(0), loc_screen(0), width(0), height(0) {}
    ~PrimBatch() {
        glDeleteVertexArrays(1, &vao);
        glDeleteBuffers(1, &vbo);
        glDeleteProgram(shader);
    }

    void set_values(int w, int h) { width = w; height = h; }

    bool init() {
        // TODO: These have hardcoded paths and that is considered illegoo.
        #ifdef FOND_HOT_RELOAD
        Shaders shaders_ = Shaders(FOND_SHADERS_PATH, "basic", true);
        #else
        Shaders shaders_ = Shaders(FOND_SHADERS_PATH, "basic");
        #endif

        shader = glCreateProgram();
        glAttachShader(shader, shaders_.vert);
        glAttachShader(shader, shaders_.frag);
        glLinkProgram(shader);
        glDeleteShader(shaders_.vert);
        glDeleteShader(shaders_.frag);

        loc_screen = glGetUniformLocation(shader, "u_screen");

        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);

        constexpr GLsizei stride = 6 * sizeof(float);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(2 * sizeof(float)));
        glBindVertexArray(0);
        return true;
    }

    void draw(GLenum mode, const std::vector<float>& verts) {
        switch (mode) {
            case GL_POINTS: pending_point_verts.insert(pending_point_verts.end(), verts.begin(), verts.end()); break;
            case GL_LINES: pending_line_verts.insert(pending_line_verts.end(), verts.begin(), verts.end()); break;
            case GL_TRIANGLES: pending_tri_verts.insert(pending_tri_verts.end(), verts.begin(), verts.end()); break;
            case GL_TRIANGLE_FAN: pending_tri_f_verts.insert(pending_tri_f_verts.end(), verts.begin(), verts.end()); break;
            default: FOND_LOG_WARN("Unsupported primitive mode"); return;
        }
    }

    void flush(GLenum mode) {
        Verts* pending = nullptr;
        switch (mode) {
            case GL_POINTS: pending = &pending_point_verts; break;
            case GL_LINES: pending = &pending_line_verts; break;
            case GL_TRIANGLES: pending = &pending_tri_verts; break;
            case GL_TRIANGLE_FAN: pending = &pending_tri_f_verts; break;
            default: FOND_LOG_WARN("Unsupported primitive mode"); return;
        }
        if (pending->empty()) return;
        glUseProgram(shader);
        glUniform2f(loc_screen, (float)width, (float)height);
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER,
            (GLsizeiptr)(pending->size() * sizeof(float)), pending->data(), GL_DYNAMIC_DRAW);
        glDrawArrays(mode, 0, (GLsizei)(pending->size() / 6));
        glBindVertexArray(0);
        glUseProgram(0);
        pending->clear();
    }

    void flush_all() {
        flush(GL_POINTS);
        flush(GL_LINES);
        flush(GL_TRIANGLES);
        flush(GL_TRIANGLE_FAN);
#ifdef FOND_ARENA_PRIMS
        vert_arena_.reset();
        pending_point_verts = Verts(alloc_);
        pending_line_verts = Verts(alloc_);
        pending_tri_verts = Verts(alloc_);
        pending_tri_f_verts = Verts(alloc_);
#endif
    }
};

// Global batch — set by the helper on init
inline PrimBatch* g_prim_batch = nullptr;
inline std::vector<float> g_circle_verts;

static inline void DrawPixel(float x, float y, const Fond::Color& c) {
    g_prim_batch->draw(GL_POINTS, {x, y, c.norm_r(), c.norm_g(), c.norm_b(), c.norm_a()});
}

static inline void DrawLine(float x0, float y0, float x1, float y1, const Fond::Color& c, float thickness = 1.0f) {
    float r = c.norm_r(), g = c.norm_g(), b = c.norm_b(), a = c.norm_a();
    // TODO: Add Thickness later, adding it seems complicated
    g_prim_batch->draw(GL_LINES, {x0, y0, r, g, b, a, x1, y1, r, g, b, a});
}

static inline void DrawCircle(float cx, float cy, float radius, const Fond::Color& c, int segments = 32) {
    g_circle_verts.reserve((segments + 2) * 6);
    float r = c.norm_r(), g = c.norm_g(), b = c.norm_b(), a = c.norm_a();
    g_circle_verts.insert(g_circle_verts.end(), {cx, cy, r, g, b, a});
    for (int i = 0; i <= segments; i++) {
        float angle = (float)i / segments * 2.0f * (float)M_PI;
        g_circle_verts.insert(g_circle_verts.end(), {
            cx + std::cos(angle) * radius, cy + std::sin(angle) * radius, r, g, b, a
        });
    }
    g_prim_batch->draw(GL_TRIANGLE_FAN, g_circle_verts);
    g_circle_verts.clear();
}

static inline void DrawTriangle(float x0, float y0, float x1, float y1, float x2, float y2, const Fond::Color& c) {
    float r = c.norm_r(), g = c.norm_g(), b = c.norm_b(), a = c.norm_a();
    g_prim_batch->draw(GL_TRIANGLES, {
        x0, y0, r, g, b, a,
        x1, y1, r, g, b, a,
        x2, y2, r, g, b, a,
    });
}

static inline void DrawRect(float x, float y, float w, float h, const Fond::Color& c) {
    float r = c.norm_r(), g = c.norm_g(), b = c.norm_b(), a = c.norm_a();
    g_prim_batch->draw(GL_TRIANGLES, {
        x,   y,   r, g, b, a,
        x+w, y,   r, g, b, a,
        x+w, y+h, r, g, b, a,
        x,   y,   r, g, b, a,
        x+w, y+h, r, g, b, a,
        x,   y+h, r, g, b, a,
    });
}

static inline void FlushPrimitives() { g_prim_batch->flush_all(); }

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW && FOND_USE_SHADERS
