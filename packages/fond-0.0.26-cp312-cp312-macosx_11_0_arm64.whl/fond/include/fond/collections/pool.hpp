#pragma once

#include <cstddef>
#include <memory>
#include <stdexcept>

#include "arena.hpp"

namespace CollectionsCub {

/**
 * @brief Fixed-size object pool with freelist.
 *
 * Pre-allocates N slots of type T. Alloc pops from freelist, release pushes back.
 * Can optionally use an Arena for its backing memory, or manages its own.
 */
template <typename T>
class Pool {
    union Slot {
        T value;
        Slot* next_free;

        Slot() {}
        ~Slot() {}
    };

    Slot* slots_ = nullptr;
    Slot* freelist_ = nullptr;
    size_t capacity_ = 0;
    size_t in_use_ = 0;

    // Owns memory when no arena is provided
    std::unique_ptr<Slot[]> owned_memory_;

    void build_freelist() {
        freelist_ = &slots_[0];
        for (size_t i = 0; i < capacity_ - 1; ++i) {
            slots_[i].next_free = &slots_[i + 1];
        }
        slots_[capacity_ - 1].next_free = nullptr;
    }

public:
    // Self-managed: pool allocates its own memory
    Pool(size_t capacity) : capacity_(capacity) {
        if (capacity == 0) throw std::invalid_argument("Pool capacity must be > 0");
        owned_memory_ = std::make_unique<Slot[]>(capacity);
        slots_ = owned_memory_.get();
        build_freelist();
    }

    // Arena-backed: pool uses memory from an arena
    Pool(Arena& arena, size_t capacity) : capacity_(capacity) {
        if (capacity == 0) throw std::invalid_argument("Pool capacity must be > 0");
        slots_ = static_cast<Slot*>(arena.alloc(sizeof(Slot) * capacity, alignof(Slot)));
        build_freelist();
    }

    ~Pool() = default;

    Pool(const Pool&) = delete;
    Pool& operator=(const Pool&) = delete;

    // --- Capacity ---

    size_t capacity() const { return capacity_; }
    size_t in_use() const { return in_use_; }
    size_t available() const { return capacity_ - in_use_; }
    bool empty() const { return in_use_ == 0; }
    bool full() const { return freelist_ == nullptr; }

    // --- Allocate ---

    template <typename... Args>
    T* alloc(Args&&... args) {
        if (!freelist_) return nullptr;
        Slot* slot = freelist_;
        freelist_ = slot->next_free;
        T* obj = new (&slot->value) T(std::forward<Args>(args)...);
        ++in_use_;
        return obj;
    }

    // --- Release ---

    void release(T* obj) {
        if (!obj) return;
        obj->~T();
        Slot* slot = reinterpret_cast<Slot*>(obj);
        slot->next_free = freelist_;
        freelist_ = slot;
        --in_use_;
    }

    // --- Reset (return all slots to freelist) ---

    void reset() {
        in_use_ = 0;
        build_freelist();
    }
};

}  // namespace CollectionsCub
