#pragma once

#include <cstddef>
#include <stdexcept>

#include "maps.hpp"

namespace CollectionsCub {

/**
 * @brief Simple LRU cache backed by an OrderedMap.
 *
 * Fixed capacity. On access, items move to the end (most recent).
 * On insert when full, the front (least recent) gets evicted.
 */
template <typename K, typename V, typename Hash = std::hash<K>, typename KeyEqual = std::equal_to<K>>
class LRUCache {
    Map<K, V, Ordered, Hash, KeyEqual> data_;
    size_t capacity_;

public:
    LRUCache(size_t capacity) : capacity_(capacity) { if (capacity == 0) throw std::invalid_argument("LRU capacity must be > 0"); }
    ~LRUCache() = default;
    size_t size() const { return data_.size(); }
    size_t capacity() const { return capacity_; }
    bool empty() const { return data_.empty(); }
    bool full() const { return data_.size() >= capacity_; }
    bool contains(const K& key) const { return data_.contains(key); }
    V* get(const K& key) {
        auto* val = data_.get(key);
        if (!val) return nullptr;
        data_.move_to_end(key);
        return val;
    }

    V get_or(const K& key, const V& default_value) { auto* val = get(key); return val ? *val : default_value; }

    void put(const K& key, V value) {
        if (data_.contains(key)) {
            data_.set(key, std::move(value));
            data_.move_to_end(key);
            return;
        }
        if (full()) data_.pop_front();
        data_.insert(key, std::move(value));
    }

    bool remove(const K& key) { return data_.remove(key); }
    void clear() { data_.clear(); }
    const V* peek(const K& key) const { return data_.get(key); }
    const auto& newest() const { return data_.back(); } // Most recently used
    const auto& oldest() const { return data_.front(); } // Least recently used (next to be evicted)
    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
};

}  // namespace CollectionsCub
