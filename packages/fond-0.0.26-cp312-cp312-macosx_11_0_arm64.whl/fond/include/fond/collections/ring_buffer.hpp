#pragma once

#include <array>
#include <cstddef>
#include <stdexcept>

namespace CollectionsCub {

/**
 * @brief Fixed-size circular buffer that overwrites oldest items when full.
 *
 * Capacity is set at compile time. No heap allocations.
 * Push overwrites the oldest element when the buffer is full.
 */
template <typename T, size_t N> class RingBuffer {
    static_assert(N > 0, "RingBuffer capacity must be greater than 0");

    std::array<T, N> data_;
    size_t head_ = 0;
    size_t tail_ = 0;
    size_t count_ = 0;

public:
    RingBuffer() = default;
    ~RingBuffer() = default;

    // --- Capacity ---

    constexpr size_t capacity() const { return N; }
    size_t size() const { return count_; }
    bool empty() const { return count_ == 0; }
    bool full() const { return count_ == N; }

    // --- Push / Pop ---

    void push(const T& item) {
        data_[tail_] = item;
        tail_ = (tail_ + 1) % N;
        if (count_ == N) {
            head_ = (head_ + 1) % N;
        } else {
            ++count_;
        }
    }

    void push(T&& item) {
        data_[tail_] = std::move(item);
        tail_ = (tail_ + 1) % N;
        if (count_ == N) {
            head_ = (head_ + 1) % N;
        } else {
            ++count_;
        }
    }

    T pop() {
        if (empty()) throw std::out_of_range("RingBuffer is empty");
        T item = std::move(data_[head_]);
        head_ = (head_ + 1) % N;
        --count_;
        return item;
    }

    // --- Access ---

    T& front() { return data_[head_]; }
    const T& front() const { return data_[head_]; }

    T& back() { return data_[(tail_ + N - 1) % N]; }
    const T& back() const { return data_[(tail_ + N - 1) % N]; }

    // Access by index (0 = oldest, size()-1 = newest)
    T& operator[](size_t idx) { return data_[(head_ + idx) % N]; }
    const T& operator[](size_t idx) const { return data_[(head_ + idx) % N]; }

    T& at(size_t idx) {
        if (idx >= count_) throw std::out_of_range("RingBuffer index out of range");
        return data_[(head_ + idx) % N];
    }

    const T& at(size_t idx) const {
        if (idx >= count_) throw std::out_of_range("RingBuffer index out of range");
        return data_[(head_ + idx) % N];
    }

    void clear() {
        head_ = 0;
        tail_ = 0;
        count_ = 0;
    }

    // --- Iterator ---

    class iterator {
        RingBuffer* buf_;
        size_t idx_;
    public:
        iterator(RingBuffer* buf, size_t idx) : buf_(buf), idx_(idx) {}
        T& operator*() { return (*buf_)[idx_]; }
        iterator& operator++() { ++idx_; return *this; }
        bool operator!=(const iterator& other) const { return idx_ != other.idx_; }
    };

    class const_iterator {
        const RingBuffer* buf_;
        size_t idx_;
    public:
        const_iterator(const RingBuffer* buf, size_t idx) : buf_(buf), idx_(idx) {}
        const T& operator*() const { return (*buf_)[idx_]; }
        const_iterator& operator++() { ++idx_; return *this; }
        bool operator!=(const const_iterator& other) const { return idx_ != other.idx_; }
    };

    iterator begin() { return iterator(this, 0); }
    iterator end() { return iterator(this, count_); }
    const_iterator begin() const { return const_iterator(this, 0); }
    const_iterator end() const { return const_iterator(this, count_); }
};

}  // namespace CollectionsCub
