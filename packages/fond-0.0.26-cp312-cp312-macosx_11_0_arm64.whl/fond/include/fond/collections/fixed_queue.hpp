#pragma once

#include <array>
#include <cassert>
#include <cstddef>

namespace CollectionsCub {

/**
 * @brief Fixed-capacity FIFO queue with random access. No heap allocations.
 *
 * Unlike RingBuffer, this does NOT overwrite on overflow — it asserts.
 * Supports indexed access into pending entries, making it suitable for
 * BFS traversals where earlier entries may need to be updated in-place
 * (e.g. widening portal column ranges during sector-in-sector rendering).
 *
 * Usage:
 *   FixedQueue<QueueEntry, 256> queue;
 *   queue.push({sector, x0, x1});
 *   while (!queue.empty()) {
 *       auto& entry = queue.pop();
 *       // process entry...
 *       // look back into pending entries:
 *       queue[some_index].x0 = std::min(queue[some_index].x0, new_x0);
 *   }
 */
template <typename T, size_t N> class FixedQueue {
    static_assert(N > 0, "FixedQueue capacity must be greater than 0");

    std::array<T, N> data_;
    size_t head_ = 0;
    size_t tail_ = 0;

public:
    FixedQueue() = default;
    ~FixedQueue() = default;

    constexpr size_t capacity() const { return N; }
    size_t size() const { return tail_ - head_; }
    bool empty() const { return head_ == tail_; }
    bool full() const { return tail_ == N; }

    T& push(const T& item) {
        assert(!full() && "FixedQueue overflow");
        data_[tail_] = item;
        return data_[tail_++];
    }

    T& push(T&& item) {
        assert(!full() && "FixedQueue overflow");
        data_[tail_] = std::move(item);
        return data_[tail_++];
    }

    // Push default-constructed entry — returns ref so caller can fill it in
    T& push() {
        assert(!full() && "FixedQueue overflow");
        data_[tail_] = T{};
        return data_[tail_++];
    }

    T& pop() {
        assert(!empty() && "FixedQueue underflow");
        return data_[head_++];
    }

    T& front() { return data_[head_]; }
    const T& front() const { return data_[head_]; }

    T& back() { return data_[tail_ - 1]; }
    const T& back() const { return data_[tail_ - 1]; }

    // Absolute index into the backing array — same indices that
    // external bookkeeping (like sector→queue-index maps) stores.
    T& operator[](size_t idx) { return data_[idx]; }
    const T& operator[](size_t idx) const { return data_[idx]; }

    // Head position — useful for checking if an index has been processed
    size_t head() const { return head_; }
    size_t tail() const { return tail_; }

    void clear() {head_ = 0; tail_ = 0; }
};

}  // namespace CollectionsCub
