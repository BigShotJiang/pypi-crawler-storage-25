#pragma once

#include "policies.hpp"
#include <functional>

namespace CollectionsCub {

// ==============================================================================
// Lists ========================================================================
// ==============================================================================

template <
    typename T,
    typename Policy = Ordered, 
    typename Alloc = std::allocator<T>
> class List;

template <
    typename T,
    typename Alloc = std::allocator<T>> using 
Tuple =
List<T, FrozenOrdered, Alloc>;

// ==============================================================================
// Sets =========================================================================
// ==============================================================================

template <
    typename T,
    typename Policy = Default, 
    typename Hash = std::hash<T>, 
    typename KeyEqual = std::equal_to<T>,
    typename Alloc = std::allocator<T>
> class Set;

template <
    typename T,
    typename Alloc = std::allocator<T>> using 
UnorderedSet =
Set<T, Default, std::hash<T>, std::equal_to<T>, Alloc>;

template <
    typename T,
    typename Alloc = std::allocator<T>> using 
OrderedSet =
Set<T, Ordered, std::hash<T>, std::equal_to<T>, Alloc>;

template <
    typename T,
    typename Alloc = std::allocator<T>> using 
FrozenUnorderedSet =
Set<T, Frozen, std::hash<T>, std::equal_to<T>, Alloc>;

template <
    typename T,
    typename Alloc = std::allocator<T>> using 
FrozenOrderedSet =
Set<T, FrozenOrdered, std::hash<T>, std::equal_to<T>, Alloc>;

// ==============================================================================
// Maps =========================================================================
// ==============================================================================

template <
    typename K, typename V,
    typename Policy = Default,
    typename Hash = std::hash<K>,
    typename KeyEqual = std::equal_to<K>,
    typename Alloc = std::allocator<std::pair<const K, V>>
> class Map;

template <
    typename K, typename V,
    typename Alloc = std::allocator<std::pair<const K, V>>> using 
UnorderedMap =
Map<K, V, Default, std::hash<K>, std::equal_to<K>, Alloc>;

template <
    typename K,
    typename V, 
    typename Alloc = std::allocator<std::pair<const K, V>>> using 
OrderedMap =
Map<K, V, Ordered, std::hash<K>, std::equal_to<K>, Alloc>;

template <
    typename K, typename V,
    typename Alloc = std::allocator<std::pair<const K, V>>> using 
FrozenUnorderedMap =
Map<K, V, Frozen, std::hash<K>, std::equal_to<K>, Alloc>;

template <
    typename K, typename V,
    typename Alloc = std::allocator<std::pair<const K, V>>> using 
FrozenOrderedMap =
Map<K, V, FrozenOrdered, std::hash<K>, std::equal_to<K>, Alloc>;

}  // namespace CollectionsCub
