#pragma once

#include <bit>
#include <cstddef>
#include <cstdint>
#include <utility> // IWYU pragma: keep

namespace CollectionsCub {

namespace detail {
template <size_t N> struct SmallestUint;
template <size_t N> requires (N <= 8)  struct SmallestUint<N> { using type = uint8_t; };
template <size_t N> requires (N > 8 && N <= 16)  struct SmallestUint<N> { using type = uint16_t; };
template <size_t N> requires (N > 16 && N <= 32) struct SmallestUint<N> { using type = uint32_t; };
template <size_t N> requires (N > 32 && N <= 64) struct SmallestUint<N> { using type = uint64_t; };
} // namespace detail

/**
 * @brief Type-safe bitflag backed by the smallest integer that fits N bits.
 *
 * Uses an enum as the key type so the compiler catches invalid flag names.
 * BitFlag<E, 8> is 1 byte, BitFlag<E, 16> is 2 bytes, etc.
 *
 * Usage:
 *   enum class Flag : size_t { Visible = 0, Active = 1, Static = 2 };
 *   BitFlag<Flag, 8> flags;
 *   flags.set(Flag::Visible);
 *   flags.test(Flag::Active);
 */
template <typename E, size_t N> class BitFlag {
    using Storage = typename detail::SmallestUint<N>::type;
    Storage bits_ = 0;

    static constexpr Storage bit(E flag) { return static_cast<Storage>(Storage{1} << static_cast<size_t>(flag)); }

public:
    BitFlag() = default;
    ~BitFlag() = default;
    BitFlag(std::initializer_list<E> init) { for (auto f : init) set(f); }

    void set(E flag) { bits_ |= bit(flag); }
    void unset(E flag) { bits_ &= ~bit(flag); }
    void toggle(E flag) { bits_ ^= bit(flag); }
    bool test(E flag) const { return (bits_ & bit(flag)) != 0; }

    void clear() { bits_ = 0; }
    void set_all() { bits_ = static_cast<Storage>(N == sizeof(Storage) * 8 ? ~Storage{0} : (Storage{1} << N) - 1); }

    bool any() const { return bits_ != 0; }
    bool none() const { return bits_ == 0; }
    bool all() const { Storage mask = static_cast<Storage>(N == sizeof(Storage) * 8 ? ~Storage{0} : (Storage{1} << N) - 1); return (bits_ & mask) == mask; }
    size_t count() const { return static_cast<size_t>(std::popcount(bits_)); }
    constexpr size_t size() const { return N; }

    Storage raw() const { return bits_; }

    BitFlag operator&(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ & other.bits_; return r; }
    BitFlag operator|(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ | other.bits_; return r; }
    BitFlag operator^(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ ^ other.bits_; return r; }
    BitFlag operator~() const { BitFlag r; r.bits_ = ~bits_; return r; }
    bool operator==(const BitFlag& other) const { return bits_ == other.bits_; }
    bool operator!=(const BitFlag& other) const { return bits_ != other.bits_; }
};

}  // namespace CollectionsCub
