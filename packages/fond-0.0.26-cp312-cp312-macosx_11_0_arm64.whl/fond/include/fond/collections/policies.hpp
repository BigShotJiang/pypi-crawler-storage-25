#pragma once

/**
 * @file policies.hpp
 * @brief Common policy structs for collections.
 *
 * Defines simple policy structs to control mutability and ordering behavior
 * of collections. These can be used as template parameters to customize
 * collection types without needing separate classes for each combination.
 *
 * Example usage:
 *   - Set<T, OrderedSetPolicy> myOrderedSet;
 *   - Set<T, Freeze<Default>> myFrozenSet;
 */

namespace CollectionsCub {
struct Default        { static constexpr bool immutable = false; static constexpr bool ordered = false; };
struct Ordered        { static constexpr bool immutable = false; static constexpr bool ordered = true; };
struct Frozen         { static constexpr bool immutable = true;  static constexpr bool ordered = false; };
struct FrozenOrdered  { static constexpr bool immutable = true;  static constexpr bool ordered = true; };

template <typename P> struct Freeze   { static constexpr bool immutable = true;  static constexpr bool ordered = P::ordered; };
template <typename P> struct Unfreeze { static constexpr bool immutable = false; static constexpr bool ordered = P::ordered; };

struct EmptyIndex {};

} // namespace CollectionsCub
