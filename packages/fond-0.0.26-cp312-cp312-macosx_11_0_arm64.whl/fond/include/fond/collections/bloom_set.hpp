#pragma once

#include "bloom_filter.hpp"
#include "sets.hpp"

namespace CollectionsCub {

/**
 * @brief Set with a bloom filter for fast negative lookups.
 *
 * Checks the bloom filter first — if it says "definitely not", we skip
 * the real set entirely. Only falls through to the actual set on "maybe."
 *
 * Best for large sets where most lookups are misses.
 *
 * Template params:
 *   T — element type
 *   N — bloom filter bits (more = fewer false positives)
 *   K — bloom filter hash count
 *   SetPolicy — policy for the backing set (Ordered, Frozen, etc.)
 */
template <typename T, size_t N = 1024, size_t K = 3,
          typename SetPolicy = Default,
          typename Hash = std::hash<T>, typename KeyEqual = std::equal_to<T>>
class BloomSet {
    BloomFilter<N, K> bloom_;
    Set<T, SetPolicy, Hash, KeyEqual> data_;
    size_t min_len_ = SIZE_MAX;
    size_t max_len_ = 0;

    static constexpr bool has_size = requires(const T& v) { v.size(); };

    void _update_len_bounds(const T& value) {
        if constexpr (has_size) {
            size_t len = value.size();
            if (len < min_len_) min_len_ = len;
            if (len > max_len_) max_len_ = len;
        }
    }

    bool _out_of_bounds(const T& value) const {
        if constexpr (has_size) {
            size_t len = value.size();
            return len < min_len_ || len > max_len_;
        }
        return false;
    }

    void _bulk_insert(const T& value) {
        _update_len_bounds(value);
        bloom_.insert(value);
    }

    
public:
    BloomSet() = default;
    ~BloomSet() = default;

    BloomSet(std::initializer_list<T> init) {
        for (const auto& item : init) _bulk_insert(item);
        data_._add_items(init);
    }

    BloomSet(const std::vector<T>& values) {
        for (const auto& item : values) _bulk_insert(item);
        data_._add_items(values);
    }

    template <typename Iter>
    BloomSet(Iter first, Iter last) {
        for (auto it = first; it != last; ++it) _bulk_insert(*it);
        data_._add_items(first, last);
    }

    size_t size() const { return data_.size(); }
    bool empty() const { return data_.empty(); }

    // --- The star of the show ---

    bool contains(const T& value) const {
        if (_out_of_bounds(value)) return false;
        if (bloom_.definitely_not(value)) return false;
        return data_.contains(value);
    }

    bool definitely_not(const T& value) const {
        if (_out_of_bounds(value)) return true;
        return bloom_.definitely_not(value);
    }

    // --- Modification (when backing set is mutable) ---

    bool add(const T& value) requires (!SetPolicy::immutable) {
        _update_len_bounds(value);
        bloom_.insert(value);
        return data_.add(value);
    }

    // Note: bloom filters can't "un-insert" — after remove,
    // the bloom may still say "maybe" for removed items.
    // This is safe (just a slower path), not incorrect.
    bool remove(const T& value) requires (!SetPolicy::immutable) { return data_.remove(value); }

    void clear() requires (!SetPolicy::immutable) {
        bloom_.clear();
        data_.clear();
    }

    double false_positive_rate() const { return bloom_.false_positive_rate(); }
    double bloom_fill_ratio() const { return bloom_.fill_ratio(); }

    // --- Iteration (delegates to real set) ---

    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
};

// --- Convenience aliases ---
// Auto-sized bloom filter: bits = expected_count * 10, K = 7 (~1% false positive)

template <typename T, size_t ExpectedCount>
using FastBloomSet = BloomSet<T, ExpectedCount * 10, 7, Default>;

template <typename T, size_t ExpectedCount>
using OrderedBloomSet = BloomSet<T, ExpectedCount * 10, 7, Ordered>;

template <typename T, size_t ExpectedCount>
using FrozenBloomSet = BloomSet<T, ExpectedCount * 10, 7, Frozen>;

}  // namespace CollectionsCub
