#pragma once

// arena.hpp — Bump allocator + typed arena + STL allocator adapter
//
// Three tools, layered:
//
// 1. Arena — raw bump allocator. Pre-allocates blocks, hands out memory by
//    bumping a pointer. No per-object free. reset() reclaims everything.
//    Use create<T>(args...) for typed placement-new.
//
// 2. TypedArena<Types...> — wraps Arena with a compile-time type whitelist.
//    Only the declared types can be allocated. Compile error otherwise.
//    Designed for Bake's runtime: arena.create<BakeValue>(42) works,
//    arena.create<SomeRandomType>() is a constraint failure.
//
//    The motivation: Bake currently uses shared_ptr<BakeValue> for every
//    value in lists/maps/sets (to break the recursive size cycle in the
//    variant). Each shared_ptr is a heap allocation + control block.
//    With TypedArena, those become raw pointers into arena memory:
//      - shared_ptr<BakeValue> (24 bytes + heap alloc) → BakeValue* (8 bytes, arena bump)
//      - One arena per script execution, reset() at the end
//      - No individual frees, no refcounting overhead
//
//    To migrate: swap ValuePtr = shared_ptr<BakeValue> → BakeValue*,
//    swap make_shared<BakeValue>(...) → arena.create<BakeValue>(...),
//    ensure arena outlives all pointers (one arena per bake script run).
//
// 3. ArenaAllocator<T> — std::allocator-compatible adapter. Plugs into
//    std::vector, std::allocate_shared, etc. deallocate() is a no-op.
//
// Also includes DynamicBitset — arena-backed bitset for bloom filters etc.

#include <concepts>
#include <cstddef>
#include <cstring>
#include <memory>
#include <vector>


namespace CollectionsCub {

/**
 * @brief Bump allocator — pre-allocates memory, hands out chunks by bumping a pointer.
 *
 * No per-object deallocation. Reset or destroy frees everything at once.
 * Great for per-frame game allocations, AST nodes, parsers.
 */
class Arena {
    struct Block {
        std::unique_ptr<std::byte[]> data;
        size_t size;
    };

    std::vector<Block> blocks_;
    size_t block_size_;
    size_t offset_ = 0;
    size_t total_allocated_ = 0;

    void add_block(size_t min_size) {
        size_t size = std::max(block_size_, min_size);
        blocks_.push_back({std::make_unique<std::byte[]>(size), size});
        offset_ = 0;
    }

    std::byte* current_block() { return blocks_.back().data.get(); }
    size_t current_capacity() { return blocks_.back().size; }
    static size_t align_up(size_t offset, size_t alignment) { return (offset + alignment - 1) & ~(alignment - 1); }

public:
    Arena(size_t block_size = 4096) : block_size_(block_size) { add_block(block_size); }

    ~Arena() = default;

    // No copying — each arena owns its memory
    Arena(const Arena&) = delete;
    Arena& operator=(const Arena&) = delete;
    Arena(Arena&&) = default;
    Arena& operator=(Arena&&) = default;

    // --- Raw allocation ---

    void* alloc(size_t size, size_t alignment = alignof(std::max_align_t)) {
        offset_ = align_up(offset_, alignment);
        if (offset_ + size > current_capacity()) { add_block(size); }
        void* ptr = current_block() + offset_;
        offset_ += size;
        total_allocated_ += size;
        return ptr;
    }

    // --- Typed allocation ---

    template <typename T, typename... Args>
    T* create(Args&&... args) {
        void* mem = alloc(sizeof(T), alignof(T));
        return new (mem) T(std::forward<Args>(args)...);
    }

    // Allocate an array of T (default constructed)
    template <typename T>
    T* create_array(size_t count) {
        void* mem = alloc(sizeof(T) * count, alignof(T));
        T* arr = static_cast<T*>(mem);
        for (size_t i = 0; i < count; ++i) { new (&arr[i]) T(); }
        return arr;
    }

    // --- Reset (keep memory, reuse it) ---

    void reset() {
        // Keep only the first block, reuse it
        if (blocks_.size() > 1) {
            // Merge into one big block
            size_t total = 0;
            for (auto& b : blocks_) total += b.size;
            blocks_.clear();
            add_block(total);
        }
        offset_ = 0;
        total_allocated_ = 0;
    }

    size_t total_allocated() const { return total_allocated_; }
    size_t block_count() const { return blocks_.size(); }
    size_t block_size() const { return block_size_; }
};

/**
 * @brief Type-constrained arena — only allocates types from a declared set.
 *
 * Wraps Arena with a compile-time type whitelist. Attempting to allocate
 * an undeclared type is a compile error via requires clause.
 *
 * Usage:
 *   TypedArena<BakeValue, BakeList, BakeMap> arena(8192);
 *   auto* val = arena.create<BakeValue>(42);
 *   auto* list = arena.create<BakeList>();
 *   // arena.create<std::string>(); // compile error
 *   arena.reset(); // frees everything
 */
template <typename... AllowedTypes>
class TypedArena {
    Arena arena_;

    template <typename T>
    static constexpr bool is_allowed = (std::same_as<T, AllowedTypes> || ...);

public:
    TypedArena(size_t block_size = 4096) : arena_(block_size) {}

    TypedArena(const TypedArena&) = delete;
    TypedArena& operator=(const TypedArena&) = delete;
    TypedArena(TypedArena&&) = default;
    TypedArena& operator=(TypedArena&&) = default;

    template <typename T, typename... Args>
        requires is_allowed<T>
    T* create(Args&&... args) {
        return arena_.create<T>(std::forward<Args>(args)...);
    }

    template <typename T>
        requires is_allowed<T>
    T* create_array(size_t count) {
        return arena_.create_array<T>(count);
    }

    void reset() { arena_.reset(); }

    Arena& raw() { return arena_; }
    const Arena& raw() const { return arena_; }
    size_t total_allocated() const { return arena_.total_allocated(); }
    size_t block_count() const { return arena_.block_count(); }
};

/**
 * @brief std::allocator-compatible adapter for Arena.
 *
 * Plugs into std::allocate_shared, std::vector, etc. so STL containers
 * can use arena memory without API changes.
 *
 * deallocate() is a no-op — the arena frees everything on reset/destroy.
 */
template <typename T>
class ArenaAllocator {
    Arena* arena_;

public:
    using value_type = T;

    ArenaAllocator(Arena& arena) noexcept : arena_(&arena) {}

    template <typename U>
    ArenaAllocator(const ArenaAllocator<U>& other) noexcept : arena_(other.arena()) {}

    T* allocate(size_t n) { return static_cast<T*>(arena_->alloc(n * sizeof(T), alignof(T))); }
    void deallocate(T*, size_t) noexcept {}  // arena frees everything at once

    Arena* arena() const noexcept { return arena_; }

    template <typename U> bool operator==(const ArenaAllocator<U>& other) const noexcept { return arena_ == other.arena(); }
};

struct DynamicBitset {
    uint64_t* bits;
    size_t n_words;

    DynamicBitset(Arena& arena, size_t n) {
        n_words = (n + 63) / 64;
        bits = arena.create_array<uint64_t>(n_words);
        reset_all();
    }

    void set(size_t i) { bits[i / 64] |= (1ULL << (i % 64)); }
    bool test(size_t i) const { return bits[i / 64] & (1ULL << (i % 64)); }
    void reset_all() { memset(bits, 0, n_words * 8); }
};


} // namespace CollectionsCub

template <typename T>
using ArenaAlloc = CollectionsCub::ArenaAllocator<T>;
using ArenaString = std::basic_string<char, std::char_traits<char>, ArenaAlloc<char>>;

#if defined(GLOBAL_ARENA_UNSAFE) && defined(GLOBAL_ARENA_SIZE)
inline CollectionsCub::Arena g_arena(GLOBAL_ARENA_SIZE);

inline CollectionsCub::Arena* get_global_arena() { return &g_arena; }

inline const char* arena_strdup(std::string_view src) {
    char* buf = static_cast<char*>(g_arena.alloc(src.size() + 1, 1));
    std::memcpy(buf, src.data(), src.size());
    buf[src.size()] = '\0';
    return buf;
}

inline std::string_view arena_str(std::string_view src) {
    const char* data = arena_strdup(src);
    return {data, src.size()};
}

struct Variable {
  const char* str;
  Variable(std::string_view s) : str(arena_strdup(s)) {}
};

#endif
