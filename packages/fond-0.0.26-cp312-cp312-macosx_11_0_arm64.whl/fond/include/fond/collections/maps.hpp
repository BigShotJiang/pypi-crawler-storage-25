#pragma once

#include <stdexcept>
#include <unordered_map>
#include <utility>
#include <vector>

#include "fwd.hpp"

namespace CollectionsCub {

template <typename K, typename V, typename Policy, typename Hash, typename KeyEqual, typename Alloc>
class Map {
public:
    using Entry = std::pair<K, V>;

private:
    using VecAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<Entry>;
    using OrderedStorage = std::vector<Entry, VecAlloc>;
    using UmapAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<std::pair<const K, V>>;
    using UnorderedStorage = std::unordered_map<K, V, Hash, KeyEqual, UmapAlloc>;
    using IdxPair = std::pair<const K, size_t>;
    using IdxAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<IdxPair>;
    using IndexMap = std::unordered_map<K, size_t, Hash, KeyEqual, IdxAlloc>;

    std::conditional_t<Policy::ordered, OrderedStorage, UnorderedStorage> data_;
    std::conditional_t<Policy::ordered, IndexMap, EmptyIndex> index_;

    void _bulk_insert(const K& key, V value) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) {
                data_[it->second].second = std::move(value);
                return;
            }
            index_[key] = data_.size();
            data_.push_back(std::make_pair(key, std::move(value)));
        } else {
            data_.insert_or_assign(key, std::move(value));
        }
    }

public:
    Map() = default;
    ~Map() = default;

    explicit Map(const Alloc& alloc) requires (Policy::ordered)
        : data_(VecAlloc(alloc)), index_(IdxAlloc(alloc)) {}

    explicit Map(const Alloc& alloc) requires (!Policy::ordered)
        : data_(UmapAlloc(alloc)) {}

    Map(std::initializer_list<Entry> init) { for (auto& [k, v] : init) _bulk_insert(k, v); }
    template <typename Iter> Map(Iter first, Iter last) { for (auto it = first; it != last; ++it) _bulk_insert(it->first, it->second); }

    size_t size() const { return data_.size(); }
    bool empty() const { return data_.empty(); }

    bool contains(const K& key) const {
        if constexpr (Policy::ordered) {
            return index_.count(key) > 0;
        } else {
            return data_.count(key) > 0;
        }
    }

    V& at(const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) throw std::out_of_range("Key not found");
            return data_[it->second].second;
        } else {
            return data_.at(key);
        }
    }

    const V& at(const K& key) const {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) throw std::out_of_range("Key not found");
            return data_[it->second].second;
        } else {
            return data_.at(key);
        }
    }

    V& operator[](const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) return data_[it->second].second;
            index_[key] = data_.size();
            data_.push_back(std::make_pair(key, V{}));
            return data_.back().second;
        } else {
            return data_[key];
        }
    }

    void set(const K& key, V value) requires (!Policy::immutable) {
        _bulk_insert(key, std::move(value));
    }

    V* get(const K& key) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return nullptr;
            return &data_[it->second].second;
        } else {
            auto it = data_.find(key);
            if (it == data_.end()) return nullptr;
            return &it->second;
        }
    }

    const V* get(const K& key) const {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return nullptr;
            return &data_[it->second].second;
        } else {
            auto it = data_.find(key);
            if (it == data_.end()) return nullptr;
            return &it->second;
        }
    }

    auto find(const K& key) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return data_.end();
            return data_.begin() + static_cast<ptrdiff_t>(it->second);
        } else {
            return data_.find(key);
        }
    }

    auto find(const K& key) const {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return data_.end();
            return data_.begin() + static_cast<ptrdiff_t>(it->second);
        } else {
            return data_.find(key);
        }
    }

    void insert(const K& key, V value) requires (!Policy::immutable) {
        _bulk_insert(key, std::move(value));
    }

    template <typename... Args>
    V& emplace(const K& key, Args&&... args) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) {
                data_[it->second].second = V(std::forward<Args>(args)...);
                return data_[it->second].second;
            }
            index_[key] = data_.size();
            data_.emplace_back(std::piecewise_construct,
                std::forward_as_tuple(key),
                std::forward_as_tuple(std::forward<Args>(args)...));
            return data_.back().second;
        } else {
            auto [it, _] = data_.try_emplace(key, std::forward<Args>(args)...);
            return it->second;
        }
    }

    bool erase(const K& key) requires (!Policy::immutable) { return remove(key); }

    bool remove(const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return false;
            size_t idx = it->second;
            // Swap with last and pop to avoid shifting
            size_t last = data_.size() - 1;
            if (idx != last) {
                index_[data_[last].first] = idx;
                std::swap(data_[idx], data_[last]);
            }
            data_.pop_back();
            index_.erase(it);
        } else {
            return data_.erase(key) > 0;
        }
        return true;
    }

    void clear() requires (!Policy::immutable) {
        data_.clear();
        if constexpr (Policy::ordered) index_.clear();
    }

    Entry& front() requires (Policy::ordered && !Policy::immutable) { return data_.front(); }
    const Entry& front() const requires (Policy::ordered) { return data_.front(); }

    Entry& back() requires (Policy::ordered && !Policy::immutable) { return data_.back(); }
    const Entry& back() const requires (Policy::ordered) { return data_.back(); }

    void pop_front() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.front().first);
        // Shift indices
        for (auto& [k, idx] : index_) { if (idx > 0) --idx; }
        data_.erase(data_.begin());
    }

    void pop_back() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.back().first);
        data_.pop_back();
    }

    // Note: move_to_end/move_to_front require element shifting with vector backend
    // These are O(n) — if you need fast reordering, use core::OpenMap instead
    bool move_to_end(const K& key) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        size_t idx = it->second;
        Entry entry = std::move(data_[idx]);
        data_.erase(data_.begin() + static_cast<ptrdiff_t>(idx));
        data_.push_back(std::move(entry));
        // Rebuild indices for shifted elements
        for (size_t i = idx; i < data_.size(); ++i) index_[data_[i].first] = i;
        return true;
    }

    bool move_to_front(const K& key) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        size_t idx = it->second;
        Entry entry = std::move(data_[idx]);
        data_.erase(data_.begin() + static_cast<ptrdiff_t>(idx));
        data_.insert(data_.begin(), std::move(entry));
        for (size_t i = 0; i <= idx; ++i) index_[data_[i].first] = i;
        return true;
    }

    std::vector<K> keys() const {
        std::vector<K> result;
        result.reserve(size());
        for (const auto& [k, v] : *this) result.push_back(k);
        return result;
    }

    std::vector<V> values() const {
        std::vector<V> result;
        result.reserve(size());
        for (const auto& [k, v] : *this) result.push_back(v);
        return result;
    }

    std::vector<Entry> items() const { return std::vector<Entry>(begin(), end()); }

    Map<K, V, Freeze<Policy>, Hash, KeyEqual, Alloc> freeze() const requires (!Policy::immutable) { return Map<K, V, Freeze<Policy>, Hash, KeyEqual, Alloc>(begin(), end()); }
    Map<K, V, Unfreeze<Policy>, Hash, KeyEqual, Alloc> unfreeze() const requires (Policy::immutable) { return Map<K, V, Unfreeze<Policy>, Hash, KeyEqual, Alloc>(begin(), end()); }

    bool operator==(const Map& other) const {
        if (size() != other.size()) return false;
        if constexpr (Policy::ordered) {
            for (size_t i = 0; i < data_.size(); ++i) {
                if (data_[i].first != other.data_[i].first || data_[i].second != other.data_[i].second) return false;
            }
        } else {
            for (const auto& [k, v] : data_) {
                auto it = other.data_.find(k);
                if (it == other.data_.end() || it->second != v) return false;
            }
        }
        return true;
    }

    bool operator!=(const Map& other) const { return !(*this == other); }

    auto begin() { return data_.begin(); }
    auto end() { return data_.end(); }
    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
    auto cbegin() const { return data_.cbegin(); }
    auto cend() const { return data_.cend(); }
};

}  // namespace CollectionsCub
