#pragma once

#include <cstddef>
#include <cstring>
#include <functional>
#include <memory>
#include <stdexcept>
#include <utility>

#include "hash_utils.hpp"
#include "intrusive_list.hpp"
#include "node_pool.hpp"

namespace CollectionsCub::core {

/**
 * @brief Open-addressing hash map with tombstones, node pool, and intrusive LRU list.
 *
 * Composable building blocks:
 *   - hash_utils: probing, masking, load factor
 *   - intrusive_list: LRU ordering (optional, free if unused)
 *   - built-in node pool with freelist: zero malloc per operation
 *
 * All operations O(1) amortized. Rehash on high load.
 */
template <typename K, typename V, typename Hash = std::hash<K>, typename KeyEqual = std::equal_to<K>>
class OpenMap {

    struct Node : ListNode {
        size_t hash;
        K key;
        V value;
    };

    struct Bucket {
        enum State : uint8_t { EMPTY, OCCUPIED, TOMBSTONE };
        State state = EMPTY;
        Node* node = nullptr;
    };

    std::unique_ptr<Bucket[]> buckets_;
    size_t num_buckets_ = 0;
    size_t mask_ = 0;

    NodePool<Node> pool_;

    size_t count_ = 0;
    size_t tombstones_ = 0;

    IntrusiveList order_;

    Hash hasher_;
    KeyEqual eq_;

    size_t find_bucket(size_t hash, const K& key) const {
        size_t idx = hash & mask_;
        size_t first_tombstone = EMPTY_SLOT;
        size_t checked = 0;

        while (checked < num_buckets_) {
            const Bucket& b = buckets_[idx];
            if (b.state == Bucket::EMPTY) return (first_tombstone != EMPTY_SLOT) ? first_tombstone : idx;
            if (b.state == Bucket::TOMBSTONE) {
                if (first_tombstone == EMPTY_SLOT) first_tombstone = idx;
            } else if (b.node->hash == hash && eq_(b.node->key, key)) {
                return idx;
            }
            idx = probe_next(idx, mask_);
            ++checked;
        }
        return (first_tombstone != EMPTY_SLOT) ? first_tombstone : 0;
    }

    size_t find_empty_bucket(size_t hash) const {
        size_t idx = hash & mask_;
        while (buckets_[idx].state != Bucket::EMPTY) idx = probe_next(idx, mask_);
        return idx;
    }

    void rehash(size_t new_bucket_count) {
        auto new_buckets = std::make_unique<Bucket[]>(new_bucket_count);
        size_t new_mask = mask_for(new_bucket_count);
        for (auto it = order_.begin(); it != order_.end(); ++it) {
            Node* node = node_cast<Node>(*it);
            size_t idx = node->hash & new_mask;
            while (new_buckets[idx].state == Bucket::OCCUPIED) idx = probe_next(idx, new_mask);
            new_buckets[idx].state = Bucket::OCCUPIED;
            new_buckets[idx].node = node;
        }

        buckets_ = std::move(new_buckets);
        num_buckets_ = new_bucket_count;
        mask_ = new_mask;
        tombstones_ = 0;
    }

    void maybe_grow() {
        if (should_grow(count_, tombstones_, num_buckets_)) {
            rehash(num_buckets_ * 2);
        }
    }

    void maybe_compact() {
        if (should_grow(count_, tombstones_, num_buckets_) && count_ * 4 < num_buckets_) {
            rehash(num_buckets_);  // same size, just clears tombstones
        }
    }

public:
    OpenMap(size_t capacity = 64)
        : pool_(capacity) {
        num_buckets_ = buckets_for_capacity(capacity);
        mask_ = mask_for(num_buckets_);
        buckets_ = std::make_unique<Bucket[]>(num_buckets_);
    }

    ~OpenMap() = default;
    OpenMap(const OpenMap&) = delete;
    OpenMap& operator=(const OpenMap&) = delete;
    OpenMap(OpenMap&&) = default;
    OpenMap& operator=(OpenMap&&) = default;

    size_t size() const { return count_; }
    size_t capacity() const { return pool_.capacity(); }
    bool empty() const { return count_ == 0; }
    bool full() const { return pool_.full(); }
    size_t bucket_count() const { return num_buckets_; }
    size_t tombstone_count() const { return tombstones_; }

    bool contains(const K& key) const {
        size_t h = compute_hash(hasher_(key));
        size_t idx = h & mask_;
        size_t checked = 0;

        while (checked < num_buckets_) {
            const Bucket& b = buckets_[idx];
            if (b.state == Bucket::EMPTY) return false;
            if (b.state == Bucket::OCCUPIED && b.node->hash == h && eq_(b.node->key, key)) return true;
            idx = probe_next(idx, mask_);
            ++checked;
        }
        return false;
    }

    V* get(const K& key) {
        size_t h = compute_hash(hasher_(key));
        size_t idx = h & mask_;
        size_t checked = 0;

        while (checked < num_buckets_) {
            Bucket& b = buckets_[idx];
            if (b.state == Bucket::EMPTY) return nullptr;
            if (b.state == Bucket::OCCUPIED && b.node->hash == h && eq_(b.node->key, key)) {
                return &b.node->value;
            }
            idx = probe_next(idx, mask_);
            ++checked;
        }
        return nullptr;
    }

    const V* get(const K& key) const { return const_cast<OpenMap*>(this)->get(key); }

    V& at(const K& key) {
        V* val = get(key);
        if (!val) throw std::out_of_range("Key not found");
        return *val;
    }

    const V& at(const K& key) const {
        const V* val = get(key);
        if (!val) throw std::out_of_range("Key not found");
        return *val;
    }

    bool insert(const K& key, V value) {
        size_t h = compute_hash(hasher_(key));
        size_t idx = find_bucket(h, key);
        Bucket& b = buckets_[idx];

        if (b.state == Bucket::OCCUPIED && b.node->hash == h && eq_(b.node->key, key)) {
            b.node->value = std::move(value);
            return false;  // updated, not inserted
        }

        if (full()) return false;

        Node* node = pool_.alloc();
        if (!node) return false;

        node->hash = h;
        node->key = key;
        node->value = std::move(value);

        if (b.state == Bucket::TOMBSTONE) --tombstones_;
        b.state = Bucket::OCCUPIED;
        b.node = node;
        order_.push_back(node);
        ++count_;

        maybe_grow();
        return true;
    }

    bool remove(const K& key) {
        size_t h = compute_hash(hasher_(key));
        size_t idx = h & mask_;
        size_t checked = 0;

        while (checked < num_buckets_) {
            Bucket& b = buckets_[idx];
            if (b.state == Bucket::EMPTY) return false;
            if (b.state == Bucket::OCCUPIED && b.node->hash == h && eq_(b.node->key, key)) {
                order_.unlink(b.node);
                pool_.release(b.node);
                b.state = Bucket::TOMBSTONE;
                b.node = nullptr;
                ++tombstones_;
                --count_;
                maybe_compact();
                return true;
            }
            idx = probe_next(idx, mask_);
            ++checked;
        }
        return false;
    }

    void clear() {
        for (size_t i = 0; i < num_buckets_; ++i) {
            if (buckets_[i].state == Bucket::OCCUPIED) {
                pool_.release(buckets_[i].node);
            }
            buckets_[i].state = Bucket::EMPTY;
            buckets_[i].node = nullptr;
        }
        order_.clear();
        count_ = 0;
        tombstones_ = 0;
    }

    void touch(const K& key) {
        size_t h = compute_hash(hasher_(key));
        size_t idx = h & mask_;
        size_t checked = 0;

        while (checked < num_buckets_) {
            Bucket& b = buckets_[idx];
            if (b.state == Bucket::EMPTY) return;
            if (b.state == Bucket::OCCUPIED && b.node->hash == h && eq_(b.node->key, key)) {
                order_.move_to_back(b.node);
                return;
            }
            idx = probe_next(idx, mask_);
            ++checked;
        }
    }

    bool evict_oldest() {
        ListNode* raw = order_.pop_front();
        if (!raw) return false;
        Node* node = node_cast<Node>(raw);

        size_t idx = node->hash & mask_;
        size_t checked = 0;
        while (checked < num_buckets_) {
            Bucket& b = buckets_[idx];
            if (b.state == Bucket::OCCUPIED && b.node == node) {
                b.state = Bucket::TOMBSTONE;
                b.node = nullptr;
                ++tombstones_;
                break;
            }
            idx = probe_next(idx, mask_);
            ++checked;
        }

        pool_.release(node);
        --count_;
        return true;
    }

    std::pair<const K&, V&> oldest() {
        Node* node = node_cast<Node>(order_.head());
        return {node->key, node->value};
    }

    std::pair<const K&, V&> newest() {
        Node* node = node_cast<Node>(order_.tail());
        return {node->key, node->value};
    }

    IntrusiveList& order() { return order_; }
    const IntrusiveList& order() const { return order_; }

    class iterator {
        ListNode* current_;
    public:
        iterator(ListNode* node) : current_(node) {}
        std::pair<const K&, V&> operator*() {
            Node* n = node_cast<Node>(current_);
            return {n->key, n->value};
        }
        iterator& operator++() { current_ = current_->next; return *this; }
        bool operator!=(const iterator& other) const { return current_ != other.current_; }
    };

    class const_iterator {
        const ListNode* current_;
    public:
        const_iterator(const ListNode* node) : current_(node) {}
        std::pair<const K&, const V&> operator*() const {
            const Node* n = static_cast<const Node*>(current_);
            return {n->key, n->value};
        }
        const_iterator& operator++() { current_ = current_->next; return *this; }
        bool operator!=(const const_iterator& other) const { return current_ != other.current_; }
    };

    iterator begin() { return iterator(order_.head()); }
    iterator end() { return iterator(nullptr); }
    const_iterator begin() const { return const_iterator(order_.head()); }
    const_iterator end() const { return const_iterator(nullptr); }
};

}  // namespace CollectionsCub::core
