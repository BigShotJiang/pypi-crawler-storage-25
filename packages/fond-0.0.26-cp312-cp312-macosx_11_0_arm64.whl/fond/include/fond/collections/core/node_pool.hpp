#pragma once

#include <cstddef>
#include <memory>
#include <stdexcept>

#include "intrusive_list.hpp"

namespace CollectionsCub::core {

/**
 * @brief Pre-allocated pool for ListNode-derived types.
 *
 * Allocates a fixed number of nodes upfront. Alloc pops from freelist,
 * release pushes back. Zero malloc per operation.
 *
 * Nodes must inherit from ListNode (or embed it) so they work
 * with IntrusiveList out of the box.
 *
 * Usage:
 *   struct MyNode : ListNode { int key; std::string value; };
 *   NodePool<MyNode> pool(1000);
 *   auto* node = pool.alloc();
 *   node->key = 42;
 *   pool.release(node);
 */
template <typename T>
class NodePool {
    static_assert(std::is_base_of_v<ListNode, T>, "T must inherit from ListNode");

    std::unique_ptr<T[]> storage_;
    T* freelist_ = nullptr;
    size_t capacity_;
    size_t in_use_ = 0;

    void build_freelist() {
        freelist_ = &storage_[0];
        for (size_t i = 0; i < capacity_ - 1; ++i) storage_[i].next = &storage_[i + 1];
        storage_[capacity_ - 1].next = nullptr;
    }

public:
    NodePool(size_t capacity) : capacity_(capacity) {
        if (capacity == 0) throw std::invalid_argument("NodePool capacity must be > 0");
        storage_ = std::make_unique<T[]>(capacity);
        build_freelist();
    }

    ~NodePool() = default;

    NodePool(const NodePool&) = delete;
    NodePool& operator=(const NodePool&) = delete;
    NodePool(NodePool&&) = default;
    NodePool& operator=(NodePool&&) = default;

    size_t capacity() const { return capacity_; }
    size_t in_use() const { return in_use_; }
    size_t available() const { return capacity_ - in_use_; }
    bool empty() const { return in_use_ == 0; }
    bool full() const { return freelist_ == nullptr; }

    T* alloc() {
        if (!freelist_) return nullptr;
        T* node = freelist_;
        freelist_ = node_cast<T>(node->next);
        node->prev = nullptr;
        node->next = nullptr;
        ++in_use_;
        return node;
    }

    void release(T* node) {
        if (!node) return;
        node->prev = nullptr;
        node->next = freelist_;
        freelist_ = node;
        --in_use_;
    }

    void reset() { in_use_ = 0; build_freelist(); }
};

}  // namespace CollectionsCub::core
