#pragma once

#include "policies.hpp"
#include "fwd.hpp"
#include <algorithm>
#include <stdexcept>
#include <vector>
#include <string>


namespace CollectionsCub {

constexpr size_t LIST_NOT_FOUND_ = static_cast<size_t>(-1);

template <typename T, typename Policy, typename Alloc>
class List {
    std::vector<T> data_;
    bool locked = false;

    void _private_insert(const T& value) requires (Policy::immutable) { data_.push_back(value); }

public:
    List() = default;
    ~List() = default;

    List(std::initializer_list<T> init, const Alloc& alloc = Alloc()) : data_(init, alloc) {}
    List(const std::vector<T>& vec, const Alloc& alloc = Alloc()) : data_(vec, alloc) {}
    List(std::vector<T> &&vec, const Alloc &alloc = Alloc()) : data_(std::move(vec), alloc) {}
    explicit List(const Alloc& alloc) : data_(alloc) {}

    template <typename Iter> List(Iter first, Iter last, const Alloc& alloc = Alloc()) : data_(first, last, alloc) {}

    // ==============================================================================
    // Immutable lists can be initialized after creation once but then locked.     //
    // ==============================================================================
    void _add_items(std::initializer_list<T> init) requires (Policy::immutable) {
        if (locked) return; // sry
        for (const auto& item : init) _private_insert(item);
        locked = true;
    }

    void _add_items(const std::vector<T>& values) requires (Policy::immutable) {
        if (locked) return;
        for (const auto& item : values) _private_insert(item);
        locked = true;
    }
    // ==============================================================================

    size_t size() const { return data_.size(); }
    size_t len() const { return data_.size(); }
    bool empty() const { return data_.empty(); }

    bool contains(const T& value) const { return std::find(data_.begin(), data_.end(), value) != data_.end(); }
    bool has(const T& value) const { return std::find(data_.begin(), data_.end(), value) != data_.end(); }

    int index_of(const T& value) const {
        auto it = std::find(data_.begin(), data_.end(), value);
        if (it == data_.end()) return LIST_NOT_FOUND_;
        return static_cast<int>(std::distance(data_.begin(), it));
    }

    size_t count(const T& value) const { return std::count(data_.begin(), data_.end(), value); }

    T& operator[](size_t idx) requires (!Policy::immutable) { return data_[idx]; }
    const T& operator[](size_t idx) const { return data_[idx]; }

    T& at(size_t idx) requires (!Policy::immutable) { return data_.at(idx); }
    const T &at(size_t idx) const { return data_.at(idx); }
    const T &get(size_t idx) const { return data_[idx]; }

    const T& first() const { return data_.front(); }
    const T& last() const { return data_.back(); }

    // --- Mutation (mutable only) ---

    void append(const T& value) requires (!Policy::immutable) { data_.push_back(value); }
    void append(T&& value) requires (!Policy::immutable) { data_.push_back(std::move(value)); }

    void insert_at(size_t idx, const T& value) requires (!Policy::immutable) {
        data_.insert(data_.begin() + idx, value);
    }

    bool remove(const T& value) requires (!Policy::immutable) {
        auto it = std::find(data_.begin(), data_.end(), value);
        if (it == data_.end()) return false;
        data_.erase(it);
        return true;
    }

    void remove_at(size_t idx) requires (!Policy::immutable) { data_.erase(data_.begin() + idx); }

    T pop() requires (!Policy::immutable) {
        if (data_.empty()) throw std::out_of_range("List is empty");
        T val = std::move(data_.back());
        data_.pop_back();
        return val;
    }

    void clear() requires (!Policy::immutable) { data_.clear(); }
    void sort() requires (!Policy::immutable) { std::sort(data_.begin(), data_.end()); }
    void reverse() requires (!Policy::immutable) { std::reverse(data_.begin(), data_.end()); }

    std::string join(const std::string& separator = " ") const {
        std::string result;
        for (size_t i = 0; i < data_.size(); ++i) {
            result += std::to_string(data_[i]);
            if (i < data_.size() - 1) result += separator;
        }
        return result;
    }

    List<T, Policy> sorted() const {
        std::vector<T> copy = data_;
        std::sort(copy.begin(), copy.end());
        return List<T, Policy>(std::move(copy));
    }

    List<T, Policy> reversed() const {
        std::vector<T> copy(data_.rbegin(), data_.rend());
        return List<T, Policy>(std::move(copy));
    }

    List<T, Policy> slice(size_t start, size_t end) const {
        if (start > data_.size()) start = data_.size();
        if (end > data_.size()) end = data_.size();
        return List<T, Policy>(data_.begin() + start, data_.begin() + end);
    }

    const std::vector<T> &items() const { return data_; }

    void push_back(const T& value) requires (!Policy::immutable) { data_.push_back(value); }
    void push_back(T&& value) requires (!Policy::immutable) { data_.push_back(std::move(value)); }

    template <typename Fn>
    auto map(Fn fn) const -> List<decltype(fn(std::declval<T>())), Policy> {
        using R = decltype(fn(std::declval<T>()));
        std::vector<R> result;
        result.reserve(data_.size());
        for (const auto& item : data_) result.push_back(fn(item));
        return List<R, Policy>(std::move(result));
    }

    template <typename Fn>
    List<T, Policy> filter(Fn fn) const {
        std::vector<T> result;
        for (const auto& item : data_) { if (fn(item)) result.push_back(item); }
        return List<T, Policy>(std::move(result));
    }

    template <typename Fn, typename Acc>
    Acc reduce(Fn fn, Acc init) const {
        for (const auto& item : data_) init = fn(init, item);
        return init;
    }

    // --- Conversion ---

    std::vector<T> to_vector() const { return data_; }
    const std::vector<T>& as_vector() const { return data_; }

    List<T, Freeze<Policy>> freeze() const requires (!Policy::immutable) { return List<T, Freeze<Policy>>(data_); }
    List<T, Unfreeze<Policy>> unfreeze() const requires (Policy::immutable) { return List<T, Unfreeze<Policy>>(data_);}

    bool operator==(const List& other) const { return data_ == other.data_; }
    bool operator!=(const List& other) const { return data_ != other.data_; }

    List operator+(const List& other) const {
        std::vector<T> result = data_;
        result.insert(result.end(), other.data_.begin(), other.data_.end());
        return List(std::move(result));
    }

    // --- Iteration ---

    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
    auto cbegin() const { return data_.cbegin(); }
    auto cend() const { return data_.cend(); }
    auto begin() requires (!Policy::immutable) { return data_.begin(); }
    auto end() requires (!Policy::immutable) { return data_.end(); }
};

template <typename T, typename Hash = std::hash<T>, typename KeyEqual = std::equal_to<T>>
static inline Tuple<T> to_tuple(const std::vector<T>& input) { return Tuple<T>(unique_ordered_keys<T, Hash, KeyEqual>(input)); }

}  // namespace CollectionsCub