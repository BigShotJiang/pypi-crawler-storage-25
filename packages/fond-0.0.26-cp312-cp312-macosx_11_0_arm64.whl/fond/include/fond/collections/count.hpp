#pragma once

#include <cstddef>

struct Count {
    size_t value;

    Count() : value(0) {}
    explicit Count(size_t v) : value(v) {}

    void increment() { ++value; }
    void decrement() { if (value > 0) --value; }
    void reset() { value = 0; }

    bool is_zero() const { return value == 0; }
    bool is_nonzero() const { return value != 0; }
};