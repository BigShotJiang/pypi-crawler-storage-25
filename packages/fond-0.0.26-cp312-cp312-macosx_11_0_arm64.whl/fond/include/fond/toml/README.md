# fond/toml — TOML Reader/Writer for C++

Tree-sitter powered TOML codec with `TOML_DEFINE` struct serialization macro.

## Quick Start

```cpp
#include "fond/toml/reader.hpp"
#include "fond/toml/writer.hpp"
#include "fond/toml/define.hpp"
```

## Reading TOML

```cpp
Fond::Toml::Reader reader;

// From string
auto doc = reader.parse(R"(
name = "Bear"
age = 42
active = true
)");

// From file
auto doc = reader.parse_file("config.toml");

// Access values
auto& root = doc.as_table();
root["name"].as_string();    // "Bear"
root["age"].as_int();        // 42
root["active"].as_bool();    // true

// Nested tables
root["server"].as_table()["host"].as_string();

// Type-safe get with fallback
root["missing"].get<int>(99);  // 99
```

## Writing TOML

```cpp
// To string
auto output = Fond::Toml::Writer::dumps(doc);

// To file
Fond::Toml::Writer::dump("output.toml", doc);

// To stream
Fond::Toml::Writer::dump(std::cout, doc);
```

## Building Values Manually

```cpp
using namespace Fond::Toml;

toml::table root;
root.insert("name", TomlValue("Bear"));
root.insert("age", TomlValue(int64_t(42)));
root.insert("score", TomlValue(3.14));
root.insert("active", TomlValue(true));

toml::array tags;
tags.push_back(TomlValue("c++"));
tags.push_back(TomlValue("fond"));
root.insert("tags", TomlValue(std::move(tags)));

Writer::dump("output.toml", TomlValue(std::move(root)));
```

## TOML_DEFINE — Struct Serialization

One macro gives your struct `toml_pack()` and `toml_unpack()`:

```cpp
struct ServerConfig {
    std::string host = "localhost";
    int port = 8080;
    bool active = true;
    double timeout = 30.0;
    TOML_DEFINE(ServerConfig, host, port, active, timeout)
};

// Struct → TOML
ServerConfig cfg{"example.com", 443, true, 15.0};
auto toml_str = Writer::dumps(cfg.toml_pack());
// host = "example.com"
// port = 443
// active = true
// timeout = 15.000000

// TOML → Struct
Reader reader;
auto doc = reader.parse_file("server.toml");
auto cfg = ServerConfig::toml_unpack(doc.as_table());

// Missing fields use defaults from default-constructed instance
auto partial = reader.parse(R"(host = "minimal.com")");
auto cfg2 = ServerConfig::toml_unpack(partial.as_table());
// cfg2.port == 8080 (default)
```

### Nested Structs

`TOML_DEFINE` handles nested structs automatically — inner structs just need their own `TOML_DEFINE`:

```cpp
struct Address {
    std::string street = "";
    std::string city = "";
    TOML_DEFINE(Address, street, city)
};

struct Person {
    std::string name = "";
    int age = 0;
    Address address;
    TOML_DEFINE(Person, name, age, address)
};

Person p{"Bear", 30, {"123 Fond St", "Seattle"}};
auto toml_str = Writer::dumps(p.toml_pack());
// name = "Bear"
// age = 30
//
// [address]
// street = "123 Fond St"
// city = "Seattle"
```

## TomlValue Types

```cpp
val.is_none()    val.is_string()   val.is_int()
val.is_float()   val.is_bool()     val.is_array()
val.is_table()

val.as_string()  val.as_int()      val.as_float()
val.as_bool()    val.as_array()    val.as_table()
```

`toml::None` is `"::None::"` — an explicit null sentinel since TOML spec has no nil type.

## toml:: Namespace

```cpp
toml::True   // "true"
toml::False  // "false"
toml::None   // "::None::"

toml::array  // std::vector<TomlValue>
toml::table  // CollectionsCub::OrderedMap<std::string, TomlValue>
```

## Build

The TOML parser uses tree-sitter. The grammar is defined in Python (`ts_grammar_toml.py`) and generates `parser.c` + `scanner.c` which must be compiled separately:

```bash
mask build-grammar   # Regenerate parser from Python grammar DSL
mask build-toml      # Compile parser.c + scanner.c → .o files
mask test-toml       # Build and run tests
mask bench-toml      # Benchmark read/write performance
```

When linking, you need `parser.o`, `scanner.o`, and `-ltree-sitter`.

## File Structure

```
fond/toml/
├── value.hpp              # TomlValue variant, toml:: namespace
├── reader.hpp             # Tree-sitter CST → TomlValue
├── writer.hpp             # TomlValue → TOML string/file
├── define.hpp             # TOML_DEFINE macro via FOND_FOR_EACH
├── ts_grammar_toml.py     # Python grammar definition (no JS!)
├── __init__.py            # CLI: gen-toml-ts-js
└── src/
    ├── parser.c           # Generated tree-sitter parser
    ├── scanner.c          # External scanner for multiline strings
    ├── grammar.json       # Generated grammar JSON
    ├── node-types.json    # Node type definitions
    └── ast_symbols.hpp    # Auto-generated symbol ID constants
```

## Performance

On the bear-shelf sample database (~1KB):

| Operation | Time |
|---|---|
| Read (parse) | ~180µs |
| Write (dumps) | ~12µs |
| Write (dump to file) | ~230µs |
| Round-trip (read → dumps) | ~112µs |

Read performance is dominated by tree-sitter parsing overhead. A hand-rolled parser targeting <100µs is on the TODO list.
