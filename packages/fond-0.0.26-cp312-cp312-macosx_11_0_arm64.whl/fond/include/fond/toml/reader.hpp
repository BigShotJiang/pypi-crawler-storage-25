#pragma once

#include <dlfcn.h>
#include "fond/cpp_tree_sitter.hpp"
#include "fond/toml/value.hpp"
#include "fond/toml/ast_symbols.hpp"
#include <string>
#include <string_view>
#include <charconv>
#include <fstream>
#include <limits>
#include <filesystem>

namespace Fond::Toml {

static inline ts::Language load_toml_language(const char* so_path = nullptr) {
    using TSLangFn = TSLanguage*(*)();

    auto fn = reinterpret_cast<TSLangFn>(dlsym(RTLD_DEFAULT, "tree_sitter_toml"));
    if (fn) return fn();
    
    #ifdef FOND_TOML_PARSER_SO
    const char *path = so_path ? so_path : FOND_TOML_PARSER_SO;
    #else
    const char *path = so_path ? so_path : std::getenv("FOND_TOML_PARSER_SO");
    #endif
    if (!path) throw std::runtime_error("tree_sitter_toml not found. Set FOND_TOML_PARSER_SO or link toml_parser.o");
    void* lib = dlopen(path, RTLD_LAZY);
    if (!lib) throw std::runtime_error(std::string("dlopen: ") + dlerror());
    fn = reinterpret_cast<TSLangFn>(dlsym(lib, "tree_sitter_toml"));
    if (!fn) throw std::runtime_error(std::string("dlsym: ") + dlerror());
    return fn();
}

class Reader {
    ts::Parser parser_;

    static std::string read_file(const std::string& path) {
        std::ifstream f(path);
        f.seekg(0, std::ios::end);
        auto size = f.tellg();
        f.seekg(0, std::ios::beg);
        std::string content(static_cast<size_t>(size), '\0');
        f.read(content.data(), size);
        return content;
    }

    static std::string read_file(const std::filesystem::path &path) { return read_file(path.string()); }

    static std::string extract_key(ts::Node node, std::string_view source) {
        auto text = std::string(node.getSourceRange(source));
        if (node.getSymbol() == sym::sym_quoted_key && text.size() >= 2) return text.substr(1, text.size() - 2);
        return text;
    }

    static void collect_key_parts(ts::Node node, std::string_view source, std::vector<std::string>& parts) {
        if (node.getSymbol() == sym::sym_dotted_key) {
            for (auto child : ts::Children{node}) {
                if (!child.isNamed()) continue;
                auto s = child.getSymbol();
                if (s == sym::sym_dotted_key) {
                    collect_key_parts(child, source, parts);
                } else if (s == sym::sym_bare_key || s == sym::sym_quoted_key) {
                    parts.push_back(extract_key(child, source));
                }
            }
        } else {
            parts.push_back(extract_key(node, source));
        }
    }

    static std::vector<std::string> get_key_path(ts::Node node, std::string_view source) {
        std::vector<std::string> parts;
        collect_key_parts(node, source, parts);
        return parts;
    }

    static toml::table& ensure_path(toml::table& root, const std::vector<std::string>& path) {
        toml::table* current = &root;
        for (const auto& key : path) {
            auto& val = (*current)[key];
            if (val.is_none()) val = TomlValue(toml::table{});
            current = &val.as_table();
        }
        return *current;
    }

    static TomlValue parse_value(ts::Node node, std::string_view source) {
        auto text = node.getSourceRange(source);

        switch (node.getSymbol()) {
            case sym::sym_string: {
                auto raw = std::string(text);
                if (raw.size() >= 6 && (raw.starts_with("\"\"\"") || raw.starts_with("'''"))) return raw.substr(3, raw.size() - 6);
                if (raw.size() >= 2 && (raw[0] == '"' || raw[0] == '\'')) return raw.substr(1, raw.size() - 2);
                return raw;
            }
            case sym::sym_integer: {
                auto s = std::string(text);
                std::erase(s, '_');
                int64_t val = 0;
                if (s.starts_with("0x") || s.starts_with("0X"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 16);
                else if (s.starts_with("0o") || s.starts_with("0O"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 8);
                else if (s.starts_with("0b") || s.starts_with("0B"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 2);
                else
                    std::from_chars(s.data(), s.data() + s.size(), val);
                return val;
            }
            case sym::sym_float: {
                auto s = std::string(text);
                std::erase(s, '_');
                if (s == "inf" || s == "+inf") return std::numeric_limits<double>::infinity();
                if (s == "-inf") return -std::numeric_limits<double>::infinity();
                if (s == "nan" || s == "+nan" || s == "-nan") return std::numeric_limits<double>::quiet_NaN();
                return std::stod(s);
            }
            case sym::sym_boolean:
                return text == "true";

            case sym::sym_array: {
                toml::array arr;
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed()) continue;
                    arr.push_back(parse_value(child, source));
                }
                return arr;
            }
            case sym::sym_inline_table: {
                toml::table tbl;
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed() || child.getSymbol() != sym::sym_pair) continue;
                    parse_pair(child, source, tbl);
                }
                return tbl;
            }
            case sym::sym_local_date:
            case sym::sym_local_time:
            case sym::sym_local_date_time:
            case sym::sym_offset_date_time:
                return std::string(text);
            default:
                return TomlValue{};
        }
    }

    static void parse_pair(ts::Node node, std::string_view source, toml::table& target) {
        auto key_node = node.getChildByFieldName("key");
        auto val_node = node.getChildByFieldName("value");
        if (key_node.isNull() || val_node.isNull()) return;

        auto path = get_key_path(key_node, source);
        if (path.size() == 1) {
            target.insert(path[0], parse_value(val_node, source));
        } else {
            auto& nested = ensure_path(target, {path.begin(), path.end() - 1});
            nested.insert(path.back(), parse_value(val_node, source));
        }
    }

    static void parse_table(ts::Node node, std::string_view source, toml::table& root) {
        auto name_node = node.getChildByFieldName("name");
        if (name_node.isNull()) return;

        auto path = get_key_path(name_node, source);
        auto& target = ensure_path(root, path);

        for (auto child : ts::Children{node}) {
            if (!child.isNamed() || child.getSymbol() != sym::sym_pair) continue;
            parse_pair(child, source, target);
        }
    }

    static void parse_table_array(ts::Node node, std::string_view source, toml::table& root) {
        auto name_node = node.getChildByFieldName("name");
        if (name_node.isNull()) return;

        auto path = get_key_path(name_node, source);
        if (path.empty()) return;

        auto& parent = path.size() > 1
            ? ensure_path(root, {path.begin(), path.end() - 1})
            : root;

        auto& arr_val = parent[path.back()];
        if (arr_val.is_none()) arr_val = TomlValue(toml::array{});

        toml::table element;
        for (auto child : ts::Children{node}) {
            if (!child.isNamed() || child.getSymbol() != sym::sym_pair) continue;
            parse_pair(child, source, element);
        }
        arr_val.as_array().push_back(TomlValue(std::move(element)));
    }

    TomlValue parse_document(std::string_view source) {
        auto tree = parser_.parseString(source);
        auto root_node = tree.getRootNode();
        toml::table root;

        for (auto child : ts::Children{root_node}) {
            if (!child.isNamed()) continue;
            switch (child.getSymbol()) {
                case sym::sym_pair:
                    parse_pair(child, source, root);
                    break;
                case sym::sym_table:
                    parse_table(child, source, root);
                    break;
                case sym::sym_table_array_element:
                    parse_table_array(child, source, root);
                    break;
                default: break;
            }
        }

        return TomlValue(std::move(root));
    }

public: 
    Reader() : parser_(load_toml_language()) {}

    TomlValue parse(std::string_view source) { return parse_document(source); }

    TomlValue parse_file(const std::string& path) {
        auto content = read_file(path);
        return parse_document(content);
    }
};

} // namespace Fond::Toml
