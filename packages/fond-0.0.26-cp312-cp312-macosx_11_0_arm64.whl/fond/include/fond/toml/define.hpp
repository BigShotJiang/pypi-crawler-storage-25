#pragma once

#include "fond/toml/value.hpp"
#include "fond/macros/for_each.hpp"

#include <string>
#include <type_traits>
#include <vector>

namespace Fond::Toml {

template <typename T> struct is_vector : std::false_type {};
template <typename T> struct is_vector<std::vector<T>> : std::true_type {};

template <typename T>
inline TomlValue toml_to_value(const T& val) {
    if constexpr (std::is_same_v<T, bool>) {
        return TomlValue(val);
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        return TomlValue(static_cast<double>(val));
    } else if constexpr (std::is_same_v<T, std::string>) {
        return TomlValue(val);
    } else if constexpr (std::is_integral_v<T>) {
        return TomlValue(static_cast<int64_t>(val));
    } else if constexpr (is_vector<T>::value) {
        toml::array arr;
        for (const auto& item : val)
            arr.push_back(toml_to_value(item));
        return TomlValue(std::move(arr));
    } else {
        return val.toml_pack();
    }
}

template <typename T>
inline T toml_from_value(const toml::table& tbl, const char* name, const T& fallback) {
    auto it = tbl.find(name);
    if (it == tbl.end()) return fallback;
    const auto& val = it->second;

    if constexpr (std::is_same_v<T, bool>) {
        return val.is_bool() ? val.as_bool() : fallback;
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        if (val.is_float()) return static_cast<T>(val.as_float());
        if (val.is_int()) return static_cast<T>(val.as_int());
        return fallback;
    } else if constexpr (std::is_same_v<T, std::string>) {
        return val.is_string() ? val.as_string() : fallback;
    } else if constexpr (std::is_integral_v<T>) {
        return val.is_int() ? static_cast<T>(val.as_int()) : fallback;
    } else if constexpr (is_vector<T>::value) {
        if (!val.is_array()) return fallback;
        T result;
        for (const auto& item : val.as_array()) {
            using Elem = typename T::value_type;
            if constexpr (std::is_same_v<Elem, std::string>) {
                if (item.is_string()) result.push_back(item.as_string());
            } else if constexpr (std::is_same_v<Elem, bool>) {
                if (item.is_bool()) result.push_back(item.as_bool());
            } else if constexpr (std::is_floating_point_v<Elem>) {
                if (item.is_float()) result.push_back(static_cast<Elem>(item.as_float()));
            } else if constexpr (std::is_integral_v<Elem>) {
                if (item.is_int()) result.push_back(static_cast<Elem>(item.as_int()));
            }
        }
        return result;
    } else {
        if (val.is_table()) return T::toml_unpack(val.as_table());
        return fallback;
    }
}

} // namespace Fond::Toml

#define FOND_TOML_PACK_FIELD(FIELD) tbl_.insert(#FIELD, Fond::Toml::toml_to_value(FIELD));
#define FOND_TOML_UNPACK_FIELD(FIELD) obj.FIELD = Fond::Toml::toml_from_value(tbl_, #FIELD, defaults.FIELD);
#define FOND_TOML_COUNT_FIELD(FIELD) +1

#define TOML_DEFINE(Type, ...)                                                  \
Fond::Toml::TomlValue toml_pack() const {                                       \
    Fond::Toml::toml::table tbl_;                                               \
    FOND_FOR_EACH(FOND_TOML_PACK_FIELD, __VA_ARGS__)                            \
    return Fond::Toml::TomlValue(std::move(tbl_));                              \
}                                                                               \
static Type toml_unpack(const Fond::Toml::toml::table& tbl_) {                  \
    Type obj{};                                                                 \
    const Type defaults{};                                                      \
    FOND_FOR_EACH(FOND_TOML_UNPACK_FIELD, __VA_ARGS__)                          \
    return obj;                                                                 \
}
