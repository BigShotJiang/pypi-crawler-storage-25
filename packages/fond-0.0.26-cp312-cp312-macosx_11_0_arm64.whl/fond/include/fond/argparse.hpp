#pragma once

// argparse.hpp — lightweight command-line argument parser
//
// String-based (simple):
//
//   ArgParser<> parser("my-tool", "Does cool stuff");
//   parser.command("run", "Run the thing")
//       .flag("--verbose", "-v")
//       .arg("--output", "-o");
//   parser.command("clean", "Clean build artifacts");
//
//   auto result = parser.parse(argc, argv);
//   if (result.command == "run") { ... }
//
// Enum-based (switch-friendly):
//
//   enum class Cmd { Help, Run, Clean, Unknown };
//
//   ArgParser<Cmd> parser("my-tool", "Does cool stuff");
//   parser.set_help_id(Cmd::Help);
//   parser.set_unknown_id(Cmd::Unknown);
//   parser.command(Cmd::Run, "run", "Run the thing")
//       .flag("--verbose", "-v")
//       .arg("--output", "-o");
//   parser.command(Cmd::Clean, "clean", "Clean build artifacts");
//
//   auto result = parser.parse(argc, argv);
//   switch (result.command_id) {
//       case Cmd::Run:   { ... } break;
//       case Cmd::Clean: { ... } break;
//       case Cmd::Help:  printf("%s", parser.usage().c_str()); break;
//       case Cmd::Unknown: break;
//   }
//
// API:
//   - command("name", "help")         Register a subcommand (string-only)
//   - command(Enum, "name", "help")   Register with enum id
//   - .flag("--long", "-short")       Boolean switch
//   - .arg("--long", "-short")        Named argument (consumes next token)
//   - parse(argc, argv)               Returns ParsedArgs<CmdEnum>
//   - result.command                  Command name as string
//   - result.command_id               Command as enum value
//   - result.has_flag("--name")       Check boolean flag
//   - result.get("--name", default)   Get named arg with fallback
//   - result.positional_or(i, default) Get positional arg with fallback
//   - usage()                         Auto-generated help text

#include <format>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "collections/maps.hpp"

namespace Fond {

template <typename CmdEnum = int>
struct ParsedArgs {
    std::string command;
    CmdEnum command_id{};
    std::unordered_map<std::string, std::string> args;
    std::unordered_set<std::string> flags;
    std::vector<std::string> positional;

    bool has_flag(const std::string& name) const { return flags.count(name) > 0; }
    bool has_arg(const std::string& name) const { return args.count(name) > 0; }

    std::string get(const std::string& name, const std::string& default_value = "") const {
        auto it = args.find(name);
        return it != args.end() ? it->second : default_value;
    }

    std::string positional_or(size_t idx, const std::string& default_value = "") const {
        return idx < positional.size() ? positional[idx] : default_value;
    }
};

template <typename CmdEnum> class ArgParser;

template <typename CmdEnum = int>
class Command {
    template <typename T> friend class ArgParser;
    std::string name_;
    std::string help_;
    CmdEnum id_{};
    std::unordered_map<std::string, std::string> flag_aliases_;
    std::unordered_set<std::string> known_flags_;
    std::unordered_set<std::string> known_args_;

public:
    Command(const std::string& name, const std::string& help = "", CmdEnum id = {})
        : name_(name), help_(help), id_(id) {}

    Command& flag(const std::string& long_name, const std::string& short_name = "") {
        known_flags_.insert(long_name);
        if (!short_name.empty()) flag_aliases_[short_name] = long_name;
        return *this;
    }

    Command& arg(const std::string& long_name, const std::string& short_name = "") {
        known_args_.insert(long_name);
        if (!short_name.empty()) flag_aliases_[short_name] = long_name;
        return *this;
    }

    const std::string& name() const { return name_; }
    const std::string& help() const { return help_; }
};

template <typename CmdEnum = int>
class ArgParser {
    std::string program_;
    std::string description_;
    CollectionsCub::Map<std::string, Command<CmdEnum>, CollectionsCub::Ordered> commands_;
    CmdEnum help_id_{};
    CmdEnum unknown_id_{};

public:
    ArgParser(const std::string& program, const std::string& description = "")
        : program_(program), description_(description) {}

    void set_help_id(CmdEnum id) { help_id_ = id; }
    void set_unknown_id(CmdEnum id) { unknown_id_ = id; }

    Command<CmdEnum>& command(const std::string& name, const std::string& help = "") {
        commands_.insert(name, Command<CmdEnum>(name, help));
        return commands_.at(name);
    }

    Command<CmdEnum>& command(CmdEnum id, const std::string& name, const std::string& help = "") {
        commands_.insert(name, Command<CmdEnum>(name, help, id));
        return commands_.at(name);
    }

    std::string usage() const {
        std::string out = std::format("Usage: {} <command> [options]\n", program_);
        if (!description_.empty()) out += description_ + "\n";
        out += "\nCommands:\n";
        for (const auto& [name, cmd] : commands_) {
            out += std::format("  {:<20} {}\n", cmd.name(), cmd.help());
        }
        return out;
    }

    ParsedArgs<CmdEnum> parse(int argc, char* argv[]) const {
        ParsedArgs<CmdEnum> result;
        result.command_id = unknown_id_;
        if (argc < 2) {
            result.command = "help";
            result.command_id = help_id_;
            return result;
        }
        std::string first = argv[1];
        if (first == "help" || first == "--help" || first == "-h") {
            result.command = "help";
            result.command_id = help_id_;
            return result;
        }

        result.command = first;
        const Command<CmdEnum>* cmd = commands_.get(first);
        if (cmd) result.command_id = cmd->id_;
        for (int i = 2; i < argc; ++i) {
            std::string token = argv[i];

            std::string resolved = token;
            if (cmd) {
                auto alias_it = cmd->flag_aliases_.find(token);
                if (alias_it != cmd->flag_aliases_.end()) resolved = alias_it->second;
            }

            if (resolved.starts_with("-")) {
                if (cmd && cmd->known_args_.count(resolved) && i + 1 < argc) {
                    result.args[resolved] = argv[++i];
                } else {
                    result.flags.insert(resolved);
                }
            } else {
                result.positional.push_back(token);
            }
        }

        return result;
    }
};

} // namespace Fond
