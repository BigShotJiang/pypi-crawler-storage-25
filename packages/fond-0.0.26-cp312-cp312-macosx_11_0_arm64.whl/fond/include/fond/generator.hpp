// fond/coro/generator.hpp
// fond: foundation for cooking, foundation for life
//
// Minimal std::generator polyfill for C++20 coroutines.
// Based on P2502R2 / the C++23 std::generator spec, but slimmed down
// to what we actually need: a synchronous, single-shot, pull-based generator.
//
// When Apple finally ships std::generator (don't hold your breath),
// this can be swapped out with zero changes to call sites.

#ifndef FOND_CORO_GENERATOR_HPP
#define FOND_CORO_GENERATOR_HPP

#include <coroutine>
#include <exception>
#include <iterator>
#include <utility>

namespace Fond {

template <class T>
class generator {
public:
    // ========================================================================
    // Promise type - the coroutine machinery
    // ========================================================================

    struct promise_type {
        T* current_value_ = nullptr;
        std::exception_ptr exception_ = nullptr;

        generator get_return_object() {
            return generator{std::coroutine_handle<promise_type>::from_promise(*this)};
        }

        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }

        // co_yield expr
        std::suspend_always yield_value(T& value) noexcept {
            current_value_ = std::addressof(value);
            return {};
        }

        // co_yield rvalue
        std::suspend_always yield_value(T&& value) noexcept {
            current_value_ = std::addressof(value);
            return {};
        }

        void return_void() noexcept {}
        void unhandled_exception() noexcept { exception_ = std::current_exception(); }
        void await_transform() = delete; // Disallow co_await inside the generator
    };

    // ========================================================================
    // Iterator - makes generator work in range-for
    // ========================================================================

    class iterator {
    public:
        using iterator_category = std::input_iterator_tag;
        using difference_type = std::ptrdiff_t;
        using value_type = T;
        using reference = T&;
        using pointer = T*;

        iterator() noexcept = default;

        explicit iterator(std::coroutine_handle<promise_type> handle) noexcept : handle_(handle) {}

        reference operator*() const noexcept { return *handle_.promise().current_value_; }
        pointer operator->() const noexcept { return handle_.promise().current_value_; }

        iterator& operator++() {
            handle_.resume();
            if (handle_.done()) {
                // Rethrow if the coroutine ended with an exception
                if (auto& ex = handle_.promise().exception_) std::rethrow_exception(ex);
                handle_ = nullptr;
            }
            return *this;
        }

        // Post-increment: input iterators only need this to be valid,
        // doesn't need to return the old value
        void operator++(int) { ++(*this); }

        friend bool operator==(const iterator& it, std::default_sentinel_t) noexcept {
            return !it.handle_ || it.handle_.done();
        }

        friend bool operator==(std::default_sentinel_t s, const iterator& it) noexcept {
            return it == s;
        }

    private:
        std::coroutine_handle<promise_type> handle_ = nullptr;
    };

    // ========================================================================
    // Generator class itself
    // ========================================================================

    generator() noexcept = default;

    generator(generator&& other) noexcept
        : handle_(std::exchange(other.handle_, nullptr)) {}

    generator& operator=(generator&& other) noexcept {
        if (this != &other) {
            if (handle_) handle_.destroy();
            handle_ = std::exchange(other.handle_, nullptr);
        }
        return *this;
    }

    // No copies - coroutine handles are unique
    generator(const generator&) = delete;
    generator& operator=(const generator&) = delete;

    ~generator() { if (handle_) handle_.destroy(); }

    // Range interface
    iterator begin() {
        if (handle_) {
            handle_.resume();
            if (handle_.done()) {
                if (auto& ex = handle_.promise().exception_) {
                    std::rethrow_exception(ex);
                }
                return iterator{nullptr};
            }
        }
        return iterator{handle_};
    }

    std::default_sentinel_t end() noexcept { return std::default_sentinel; }

private:
    explicit generator(std::coroutine_handle<promise_type> handle) noexcept
        : handle_(handle) {}

    std::coroutine_handle<promise_type> handle_ = nullptr;
};

} // namespace fond

#endif // FOND_CORO_GENERATOR_HPP
