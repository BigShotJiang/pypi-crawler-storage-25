#pragma once

#include <cstdlib>
#include <filesystem>
#include <string>

namespace fs = std::filesystem;

namespace Fond::Config {

class DirectoryManager {
    std::string name_;
    fs::path home_;
    fs::path config_;
    fs::path local_config_;
    fs::path cache_;
    fs::path temp_;

    static fs::path get_home() { const char* h = std::getenv("HOME"); return h ? fs::path(h) : fs::path("/tmp"); }

public:
    DirectoryManager(const std::string& name)
        : name_(name),
          home_(get_home()),
          config_(home_ / ".config" / name),
          local_config_(fs::current_path() / "config" / name),
          cache_(home_ / ".cache" / name),
          temp_(fs::temp_directory_path() / name) {}

    const std::string& name() const { return name_; }
    const fs::path& home() const { return home_; }

    fs::path config(bool mkdir = false) const {
        if (mkdir) fs::create_directories(config_);
        return config_;
    }

    fs::path local_config(bool mkdir = false) const { if (mkdir) fs::create_directories(local_config_); return local_config_; }

    fs::path settings(bool mkdir = false) const {
        auto p = config_ / "settings";
        if (mkdir) fs::create_directories(p);
        return p;
    }

    fs::path cache(bool mkdir = false) const {
        if (mkdir) fs::create_directories(cache_);
        return cache_;
    }

    fs::path temp(bool mkdir = false) const {
        if (mkdir) fs::create_directories(temp_);
        return temp_;
    }

    void clear_temp() const {
        if (fs::exists(temp_)) fs::remove_all(temp_);
    }

    void clear_cache() const {
        if (fs::exists(cache_)) fs::remove_all(cache_);
    }
};

} // namespace Fond::Config
