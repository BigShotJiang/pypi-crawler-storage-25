#pragma once

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include "../byte_buffer.hpp"
#include "constants.hpp"

namespace Fond {

class Unpacker {
   private:
    uint8Buffer buf_;

    // Forward declarations for recursive unpacking
    MsgPackValue unpack_one(); // C++ is dumb
    MsgPackArray unpack_array(size_t length);
    MsgPackMap unpack_map(size_t length);

   public:
    Unpacker(const uint8_t* buf, size_t buf_len) : buf_(buf, buf_len) {}

    MsgPackValue unpack() { return unpack_one(); }
};

inline MsgPackValue Unpacker::unpack_one() {
    uint8_t tag_byte = buf_.eat();

    // Positive fixint: 0x00 - 0x7F
    if ((tag_byte & tag::POS_FIXINT_MASK) == 0) { return MsgPackValue{static_cast<int64_t>(tag_byte)}; }
    // Negative fixint: 0xE0 - 0xFF
    if ((tag_byte & tag::NEG_FIXINT_MASK) == tag::NEG_FIXINT_BASE) { return MsgPackValue{static_cast<int64_t>(static_cast<int8_t>(tag_byte))}; }
    // Fixstr: 0xA0 - 0xBF
    if ((tag_byte & tag::FIXSTR_MASK) == tag::FIXSTR_BASE) {
      size_t length = tag_byte & 0x1F;
      return MsgPackValue{buf_.read_string(length)};
    }
    // Fixarray: 0x90 - 0x9F
    if ((tag_byte & tag::FIXARRAY_MASK) == tag::FIXARRAY_BASE) { size_t length = tag_byte & 0x0F; return MsgPackValue{unpack_array(length)}; }
    // Fixmap: 0x80 - 0x8F
    if ((tag_byte & tag::FIXMAP_MASK) == tag::FIXMAP_BASE) { size_t length = tag_byte & 0x0F; return MsgPackValue{unpack_map(length)}; }

    switch (tag_byte) {
        case tag::NIL:
            return MsgPackValue{nullptr};
        case tag::FALSE:
            return MsgPackValue{false};
        case tag::TRUE:
            return MsgPackValue{true};
        case tag::UINT8:
            return MsgPackValue{static_cast<uint64_t>(buf_.eat())};
        case tag::UINT16:
            return MsgPackValue{static_cast<uint64_t>(buf_.read_uint16())};
        case tag::UINT32:
            return MsgPackValue{static_cast<uint64_t>(buf_.read_uint32())};
        case tag::UINT64:
            return MsgPackValue{buf_.read_uint64()};
        case tag::INT8:
            return MsgPackValue{static_cast<int64_t>(static_cast<int8_t>(buf_.eat()))};
        case tag::INT16:
            return MsgPackValue{static_cast<int64_t>(static_cast<int16_t>(buf_.read_uint16()))};
        case tag::INT32:
            return MsgPackValue{static_cast<int64_t>(static_cast<int32_t>(buf_.read_uint32()))};
        case tag::INT64:
            return MsgPackValue{static_cast<int64_t>(buf_.read_uint64())};
        case tag::FLOAT64:
            return MsgPackValue{buf_.read_float64()};
        case tag::STR8:
            return MsgPackValue{buf_.read_string(buf_.eat())};
        case tag::STR16:
            return MsgPackValue{buf_.read_string(buf_.read_uint16())};
        case tag::STR32:
            return MsgPackValue{buf_.read_string(buf_.read_uint32())};
        case tag::BIN8:
            return MsgPackValue{buf_.read_bytes(buf_.eat())};
        case tag::BIN16:
            return MsgPackValue{buf_.read_bytes(buf_.read_uint16())};
        case tag::BIN32:
          return MsgPackValue{buf_.read_bytes(buf_.read_uint32())};
        case tag::ARRAY16:
            return MsgPackValue{unpack_array(buf_.read_uint16())};
        case tag::ARRAY32:
            return MsgPackValue{unpack_array(buf_.read_uint32())};
        case tag::MAP16:
            return MsgPackValue{unpack_map(buf_.read_uint16())};
        case tag::MAP32:
            return MsgPackValue{unpack_map(buf_.read_uint32())};

        default: {
            char error_msg[64];
            snprintf(error_msg, sizeof(error_msg), "Unknown tag: 0x%02X", tag_byte);
            throw std::runtime_error(error_msg);
        }
    }
}

inline MsgPackArray Unpacker::unpack_array(size_t length) {
    MsgPackArray arr;
    arr.reserve(length);
    for (size_t i = 0; i < length; ++i) arr.push_back(unpack_one());
    return arr;
}

inline MsgPackMap Unpacker::unpack_map(size_t length) {
    MsgPackMap map;
    for (size_t i = 0; i < length; ++i) {
        MsgPackValue key_val = unpack_one();
        std::string key = std::get<std::string>(key_val.data);
        map[key] = unpack_one();
    }
    return map;
}

}  // namespace MsgPackCub
