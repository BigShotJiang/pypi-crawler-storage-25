#pragma once

#include <cstdint>
#include <cstring>
#include <type_traits>
#include "../byte_buffer.hpp"
#include "constants.hpp"

namespace Fond {

class Packer { 
   private:
   uint8Buffer buffer_;
   public:
    Packer() { buffer_.reserve(buffer::MAX_BUFFER_SIZE_); }

    void clear() { buffer_.clear(); }
    const uint8Buffer& get_buffer() const { return buffer_; }
    const uint8_t* data() const { return buffer_.data(); }
    size_t size() const { return buffer_.size(); }

    void pack_nil() { buffer::pack_nil(buffer_);}
    void pack_bool(bool value) { buffer::pack_bool(buffer_, value); }
    void pack_int(int64_t value) { buffer::pack_int(buffer_, value); }
    void pack_uint(uint64_t value) { buffer::pack_uint(buffer_, value); }
    void pack_double(double value) { buffer::pack_double(buffer_, value); }
    void pack_string(const std::string& str) { buffer::pack_string(buffer_, str.c_str(), str.size()); }
    void pack_binary(const std::vector<uint8_t>& data) { buffer::pack_binary(buffer_, data.data(), data.size()); }
    void pack_vector(const std::vector<int>& vec) {
        buffer::pack_array_header(buffer_, vec.size());
        for (int val : vec) buffer::pack_int(buffer_, val);
    }
    void pack_map(const std::unordered_map<std::string, int>& map) {
        buffer::pack_map_header(buffer_, map.size());
        for (const auto& [key, value] : map) {
            pack_string(key);
            buffer::pack_int(buffer_, value);
        }
    }
    void pack(const MsgPackValue& value); // Pack a MsgPackValue (recursive)
};

inline void Packer::pack(const MsgPackValue& value) {
    std::visit([this](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::nullptr_t>) {
            buffer::pack_nil(buffer_);
        } else if constexpr (std::is_same_v<T, bool>) {
            buffer::pack_bool(buffer_, arg);
        } else if constexpr (std::is_same_v<T, int64_t>) {
            buffer::pack_int(buffer_, arg);
        } else if constexpr (std::is_same_v<T, uint64_t>) {
            buffer::pack_uint(buffer_, arg);
        } else if constexpr (std::is_same_v<T, double>) {
            buffer::pack_double(buffer_, arg);
        } else if constexpr (std::is_same_v<T, std::string>) {
            buffer::pack_string(buffer_, arg.c_str(), arg.size());
        } else if constexpr (std::is_same_v<T, std::vector<uint8_t>>) {
            buffer::pack_binary(buffer_, arg.data(), arg.size());
        } else if constexpr (std::is_same_v<T, MsgPackArray>) {
            buffer::pack_array_header(buffer_, arg.size());
            for (const auto& item : arg) pack(item);
        } else if constexpr (std::is_same_v<T, MsgPackMap>) {
            buffer::pack_map_header(buffer_, arg.size());
            for (const auto& [key, val] : arg) { pack_string(key); pack(val); }
        }
    },
    value.data);
}

}  // namespace Fond
