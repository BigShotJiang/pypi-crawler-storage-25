#pragma once

#include "fond/msgpack/constants.hpp"
#include "fond/py_tools/py_convert.hpp"

namespace Fond::PyTools {

template <>
struct ValueTraits<Fond::MsgPackValue> {
    using none_type = std::nullptr_t;
    using array_type = Fond::MsgPackArray;
    using map_type = Fond::MsgPackMap;
    using bytes_type = std::vector<uint8_t>;
    static constexpr bool has_uint64 = true;
};

} // namespace Fond::PyTools
