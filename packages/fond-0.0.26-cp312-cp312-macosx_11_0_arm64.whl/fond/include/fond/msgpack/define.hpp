#pragma once

// Struct serialization macro for MsgPack using FOND_FOR_EACH.
//
// Usage:
//   struct PlayerState {
//       int x, y, health;
//       std::string name;
//       bool alive;
//       MSGPACK_DEFINE(PlayerState, x, y, health, name, alive)
//   };
//
//   // Pack:
//   Fond::Packer p;
//   PlayerState state{10, 20, 100, "Bear", true};
//   state.msgpack_pack(p);
//
//   // Unpack:
//   Fond::Unpacker u(p.data(), p.size());
//   PlayerState loaded = PlayerState::msgpack_unpack(u);

#include "../macros/for_each.hpp"
#include "packer.hpp"
#include "unpacker.hpp" // IWYU pragma: keep 

#include <string>

namespace Fond {

// Helper: pack a single field as a key-value pair into a map
template <typename T> inline void msgpack_pack_field(Packer& p, const char* name, const T& value) {
    p.pack_string(std::string(name));
    if constexpr (std::is_same_v<T, bool>) {
        p.pack_bool(value);
    } else if constexpr (std::is_same_v<T, double>) {
        p.pack_double(value);
    } else if constexpr (std::is_same_v<T, float>) {
        p.pack_double(static_cast<double>(value));
    } else if constexpr (std::is_same_v<T, std::string>) {
        p.pack_string(value);
    } else if constexpr (std::is_same_v<T, uint64_t>) {
        p.pack_uint(value);
    } else if constexpr (std::is_integral_v<T>) {
        p.pack_int(static_cast<int64_t>(value));
    } else {
        value.msgpack_pack(p); // Nested struct — must also have MSGPACK_DEFINE
    }
}

// Helper: extract a typed value from MsgPackValue with fallback
template <typename T> inline T msgpack_extract(const MsgPackValue& v, T fallback) {
    return std::visit([&](auto&& arg) -> T {
        using V = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, bool>) {
            if constexpr (std::is_same_v<V, bool>) return arg;
        } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
            if constexpr (std::is_same_v<V, double>) return static_cast<T>(arg);
            if constexpr (std::is_integral_v<V>) return static_cast<T>(arg);
        } else if constexpr (std::is_integral_v<T>) {
            if constexpr (std::is_same_v<V, int64_t>) return static_cast<T>(arg);
            if constexpr (std::is_same_v<V, uint64_t>) return static_cast<T>(arg);
        } else if constexpr (std::is_same_v<T, std::string>) {
            if constexpr (std::is_same_v<V, std::string>) return arg;
        } return fallback;
    }, v.data);
}

// Helper: read a field from a MsgPackMap with default
template <typename T>
inline T msgpack_read_field(const MsgPackMap& map, const char* name, const T& default_val) {
    auto it = map.find(name);
    if (it == map.end()) return default_val;
    return msgpack_extract<T>(it->second, default_val);
}

}  // namespace Fond

#define FOND_MSGPACK_PACK_FIELD(FIELD) Fond::msgpack_pack_field(p_, #FIELD, FIELD);
#define FOND_MSGPACK_UNPACK_FIELD(FIELD) obj.FIELD = Fond::msgpack_read_field(map_, #FIELD, defaults.FIELD);
#define FOND_MSGPACK_COUNT_FIELD(FIELD) +1

#define MSGPACK_DEFINE(Type, ...)                                               \
void msgpack_pack(Fond::Packer& p_) const {                                     \
    p_.pack_map_header(0 FOND_FOR_EACH(FOND_MSGPACK_COUNT_FIELD, __VA_ARGS__)); \
    FOND_FOR_EACH(FOND_MSGPACK_PACK_FIELD, __VA_ARGS__)                         \
}                                                                               \
static Type msgpack_unpack(Fond::Unpacker& u_) {                                \
    auto val = u_.unpack();                                                     \
    auto& map_ = std::get<Fond::MsgPackMap>(val.data);                          \
    Type obj{};                                                                 \
    const Type defaults{};                                                      \
    FOND_FOR_EACH(FOND_MSGPACK_UNPACK_FIELD, __VA_ARGS__)                       \
    return obj;                                                                 \
}
