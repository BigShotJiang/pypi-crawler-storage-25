#pragma once

#include <Python.h>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include "../byte_buffer.hpp"
#include "constants.hpp"

namespace Fond::Python {
class Unpacker {
private:
    uint8Buffer buf_;

    inline PyObject* read_string(size_t length) {
        if (buf_.pos_ + length > buf_.size()) throw std::runtime_error("Buffer overflow reading string");
        PyObject* bytes_obj = PyBytes_FromStringAndSize(reinterpret_cast<const char*>(&buf_.data()[buf_.pos_]), length);
        if (!bytes_obj) return nullptr;
        buf_.tick(length);
        PyObject* str_obj = PyUnicode_FromEncodedObject(bytes_obj, "utf-8", "strict");
        Py_DECREF(bytes_obj);
        return str_obj;
    }

    inline PyObject* read_bytes(size_t length) {
        if (buf_.pos_ + length > buf_.size()) throw std::runtime_error("Buffer overflow reading bytes");
        PyObject* result = PyBytes_FromStringAndSize( reinterpret_cast<const char*>(&buf_.data()[buf_.pos_]), length );
        buf_.tick(length);
        return result;
    }

    // Forward declaration for recursive unpacking
    PyObject* unpack_one();

    PyObject* unpack_array(size_t length) {
        PyObject* list = PyList_New(length);
        if (!list) return nullptr;

        for (size_t i = 0; i < length; ++i) {
            PyObject* item = unpack_one();
            if (!item) { Py_DECREF(list); return nullptr; }
            PyList_SET_ITEM(list, i, item);  // Steals reference
        }
        return list;
    }

    // Unpack map of given length
    PyObject* unpack_map(size_t length) {
        PyObject* dict = PyDict_New();
        if (!dict) return nullptr;

        for (size_t i = 0; i < length; ++i) {
            PyObject* key = unpack_one();
            if (!key) {Py_DECREF(dict); return nullptr; }
            PyObject* value = unpack_one();
            if (!value) { Py_DECREF(key); Py_DECREF(dict); return nullptr; }
            if (PyDict_SetItem(dict, key, value) < 0) {
              Py_DECREF(key);
              Py_DECREF(value);
              Py_DECREF(dict);
              return nullptr;
            }
            Py_DECREF(key);
            Py_DECREF(value);
        }
        return dict;
    }

public:
    Unpacker(const uint8_t* buf, size_t buf_len) : buf_(buf, buf_len) {}
    PyObject* unpack() { return unpack_one(); }
};

// Implementation of unpack_one (must be after class definition for member access)
inline PyObject* Unpacker::unpack_one() {
    if (buf_.pos_ >= buf_.size()) { PyErr_SetString(PyExc_ValueError, "Unexpected end of buffer"); return nullptr; }

    uint8_t tag_byte = buf_.eat();

    // Positive fixint: 0x00 - 0x7F
    if ((tag_byte & tag::POS_FIXINT_MASK) == 0) { return PyLong_FromLong(tag_byte); }
    // Negative fixint: 0xE0 - 0xFF
    if ((tag_byte & tag::NEG_FIXINT_MASK) == tag::NEG_FIXINT_BASE) { return PyLong_FromLong(static_cast<int8_t>(tag_byte)); }
    // Fixstr: 0xA0 - 0xBF
    if ((tag_byte & tag::FIXSTR_MASK) == tag::FIXSTR_BASE) { return read_string(tag_byte & 0x1F); }
    // Fixarray: 0x90 - 0x9F
    if ((tag_byte & tag::FIXARRAY_MASK) == tag::FIXARRAY_BASE) { return unpack_array(tag_byte & 0x0F); }
    // Fixmap: 0x80 - 0x8F
    if ((tag_byte & tag::FIXMAP_MASK) == tag::FIXMAP_BASE) { return unpack_map(tag_byte & 0x0F); }

    // Literals
    switch (tag_byte) {
        case tag::NIL: Py_RETURN_NONE;
        case tag::FALSE: Py_RETURN_FALSE;
        case tag::TRUE: Py_RETURN_TRUE;

        case tag::UINT8: return PyLong_FromUnsignedLong(buf_.eat());
        case tag::UINT16: return PyLong_FromUnsignedLong(buf_.read_uint16());
        case tag::UINT32: return PyLong_FromUnsignedLong(buf_.read_uint32());
        case tag::UINT64: return PyLong_FromUnsignedLongLong(buf_.read_uint64());

        case tag::INT8: return PyLong_FromLong(static_cast<int8_t>(buf_.eat()));
        case tag::INT16: return PyLong_FromLong(static_cast<int16_t>(buf_.read_uint16()));
        case tag::INT32: return PyLong_FromLong(static_cast<int32_t>(buf_.read_uint32()));
        case tag::INT64: return PyLong_FromLongLong(static_cast<int64_t>(buf_.read_uint64()));

        case tag::FLOAT64: return PyFloat_FromDouble(buf_.read_float64());
        
        case tag::STR8: return read_string(buf_.eat());
        case tag::STR16: return read_string(buf_.read_uint16());
        case tag::STR32: return read_string(buf_.read_uint32());

        case tag::BIN8: return read_bytes(buf_.eat());
        case tag::BIN16: return read_bytes(buf_.read_uint16());
        case tag::BIN32: return read_bytes(buf_.read_uint32());

        case tag::ARRAY16: return unpack_array(buf_.read_uint16());
        case tag::ARRAY32: return unpack_array(buf_.read_uint32());

        case tag::MAP16: return unpack_map(buf_.read_uint16());
        case tag::MAP32: return unpack_map(buf_.read_uint32());

        default: {
            char error_msg[64];
            snprintf(error_msg, sizeof(error_msg), "Unknown tag: 0x%02X", tag_byte);
            PyErr_SetString(PyExc_ValueError, error_msg);
            return nullptr;
        }
    }
}

} // namespace Fond::Python
