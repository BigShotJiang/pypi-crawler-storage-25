# gen-lookup

Generate optimized C++ string lookup functions from a keyword list.

Two strategies: **switch cascade** (pure switches, no hashing) and **gperf** (perfect hash + optional ARM NEON SIMD). Supports CLI, TOML config, and Python Blueprint API.

## Installation

```bash
uv sync
gen-lookup --help
```

Requires `gperf` in PATH for gperf mode (`brew install gperf`).
Optional: `clang-format` for `--format` flag.

## Quick Start

### Bool lookup
```bash
gen-lookup bool --gen-mode switch --input keywords.txt --stdout --levels "len|chunk"
```

### Enum lookup (switch)
```bash
gen-lookup enum --gen-mode switch --input keywords.txt --output lookup.hpp \
  --enum-name rn_fn --prefix fn_ --default-return "rn_fn::sentinel" \
  --levels "pos:0|len|chunk" --create-enum --format
```

### Enum lookup (gperf + NEON)
```bash
gen-lookup enum --gen-mode gperf --input keywords.txt --output lookup.hpp \
  --enum-name rn_fn --prefix fn_ --default-return identifier \
  --string-compare neon_padded --cmov --best-jump
```

### Blueprint (Python API)
```python
from fond.gperf.blueprint import Blueprint
from fond.gperf.helpers import SortedKeywords as Keywords

bp = Blueprint(
    create_enum=True,
    gen_mode="switch",
    comp_mode="enum",
    namespace="bake",
    enum_name="Operator",
    func_name="get_operator",
    default_return="Operator::Sentinel",
    levels="pos:-1|len",
    keywords=Keywords.load({"::": "Definition", "->": "ReturnType"}),
)
bp.generate(output=Path("operators.hpp"))
```

## CLI Reference

```
gen-lookup [--config NAME] <bool|enum> [options]
```

### Common Flags

| Flag | Description |
|------|-------------|
| `--config`, `-c` | Config name (loads TOML, default: `default`) |
| `--gen-mode` | `switch` or `gperf` |
| `--input` | Keyword file path |
| `--output` | Output `.hpp` file path |
| `--stdout` | Print to stdout |
| `--format` | Run clang-format on output |
| `--create-enum` | Generate enum inline in output file |

### Naming

| Flag | Description |
|------|-------------|
| `--func-name` | Generated function name |
| `--namespace` | C++ namespace |
| `--enum-name` | Enum type name |
| `--prefix` | Enum value prefix (e.g. `fn_`) |
| `--default-return` | Sentinel value (required for enum mode) |
| `--include-name` | Include path for type header (gperf two-file output) |

### Switch-Specific

| Flag | Default | Description |
|------|---------|-------------|
| `--levels` | `pos:0\|pos:-1\|pos:-2` | Dispatch levels (pipe-separated) |
| `--threshold` | `3` | Group size for sequential compare fallback |

#### Level Types

| Type | Syntax | Description |
|------|--------|-------------|
| `pos` | `pos:0,1,-1,-2` | Pack chars at positions into key, switch on hex |
| `len` | `len` | Switch on string length |
| `chunk` | `chunk` | Integer compare via memcpy (requires `len` before it) |
| `match` | `match` | Sequential `str ==` comparison |

#### Recommended Levels

| Keywords | Levels | Why |
|----------|--------|-----|
| < 20 | `len\|chunk` | Fastest for small sets (1.20 ns/lookup) |
| 20-50 | `pos:0\|len\|chunk` | First char narrows, chunk finishes |
| 50+ | Use gperf | Perfect hash + NEON wins |

### Gperf-Specific

| Flag | Default | Description |
|------|---------|-------------|
| `--string-compare` | `memcmp` | Compare strategy |
| `--cmov` | off | Branchless ARM csel |
| `--padded` | off | Pad wordlist entries (auto for `neon_padded`) |
| `--jump` | `1` | Gperf jump parameter |
| `--best-jump` | off | Brute-force optimal jump |

#### String Compare Strategies

| Strategy | Platform | Notes |
|----------|----------|-------|
| `memcmp` | Any | Portable baseline |
| `check1memcmp` | Any | First-byte early exit |
| `neon` | ARM | 16-byte bitmask compare |
| `neon_xor` | ARM | XOR + mask + vmaxvq |
| `neon_strcmp` | ARM | Combined asm block |
| **`neon_padded`** | **ARM** | **No mask, padded arrays. Fastest (1.56 ns/lookup)** |

## Input File Format

```
# Comments start with #
keyword
another_keyword

# Mapped mode (key = value):
:: = Definition
-> = ReturnType
= = Assignment
```

## Architecture

```
src/fond/gperf/
├── __init__.py          # main() entry point
├── config.py            # Arguments, CLI parsing, ConfigManager
├── blueprint.py         # Blueprint API for programmatic use
├── gen_switch.py        # Switch cascade generation
├── gen_gperf.py         # Gperf + NEON generation
├── _strings.py          # C++ fragments (NEON intrinsics, csel, etc)
├── operators.py         # Example Blueprint (Bake operators)
├── helpers/
│   ├── __init__.py      # Re-exports
│   ├── _buf.py          # Buffer with block() context manager
│   ├── _extras.py       # Key packing, chunk helpers, clang-format
│   ├── _kws.py          # SortedKeywords, keyword loading
│   └── _gperf_template.py  # .gperf file generation + parsing
├── SPEC.md              # Full specification
├── TODO.md              # Remaining work
└── README.md            # This file
```

Generated C++ uses `LookupEntry<N, EnumType>` from `fond/str_utils.hpp` with fields `str` and `value`.

## For Claudies

- **Use `--stdout`** to inspect output without writing files
- **`--create-enum`** generates the enum inline — no separate header needed for switch mode
- **For gperf**, always use `--best-jump` unless you know the optimal value
- **`neon_padded` with `--cmov`** is the fastest ARM path — requires padded input (calloc source buffer + 32 bytes)
- **`len|chunk`** is the fastest switch path for small keyword sets — no SIMD needed
- **Don't edit generated files** — regenerate from the keyword list
- **Blueprint** is the programmatic API — `generate()` is safe to call multiple times (doesn't mutate keywords)
- **`SortedKeywords`** is a dict wrapper — use `.load(dict)` or `.load(list)`, access via `kw[key].value`

## Benchmark Results (Apple Silicon M1, 100M lookups, 80% miss)

### 200 keywords
| Strategy | ns/lookup |
|----------|-----------|
| unordered_set | 4.31 |
| switch pos:0\|len\|chunk | 1.87 |
| gperf + neon_strcmp | 1.68 |
| **gperf + neon_padded** | **1.56** |

### 15 keywords
| Strategy | ns/lookup |
|----------|-----------|
| unordered_set | 4.00 |
| switch pos:0 | 1.53 |
| **switch len\|chunk** | **1.20** |
