"""Dedicated to helping generate Gperf tables from Python."""

from __future__ import annotations

import sys

from .config import (
    COMP_OUTPUT_MODE,
    GPERF_PATH,
    LEGAL_GEN_MODES,
    LEGAL_OUTPUT_MODES,
    LEGAL_STRING_COMPARES,
    Arguments,
    MainConfig,
    Options,
    get_args,
    get_config,
    parse_levels,
)


def main() -> None:
    """Unified entry point for gen-lookup."""
    a = get_args(sys.argv[1:])
    match a.gen_mode:
        case "switch":
            from .gen_switch import switch_output

            switch_output(a)
        case "gperf":
            if not GPERF_PATH:
                raise FileNotFoundError("gperf not found in PATH (required for gperf mode)")
            from .gen_gperf import gperf_output

            gperf_output(a)


# ruff: noqa: PLC0415

__all__ = [
    "COMP_OUTPUT_MODE",
    "GPERF_PATH",
    "LEGAL_GEN_MODES",
    "LEGAL_OUTPUT_MODES",
    "LEGAL_STRING_COMPARES",
    "Arguments",
    "MainConfig",
    "Options",
    "get_args",
    "get_config",
    "main",
    "parse_levels",
]
