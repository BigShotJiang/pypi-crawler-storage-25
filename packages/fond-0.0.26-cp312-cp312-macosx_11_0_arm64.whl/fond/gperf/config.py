"""Configuration management for gen_gperf.py."""

from __future__ import annotations

from argparse import ArgumentParser, Namespace
from dataclasses import dataclass
from pathlib import Path
from shutil import which
from typing import Any, Literal, cast

from bear_config.manager import ConfigManager
from pydantic import BaseModel, Field, field_serializer

type OrdKey = list[int]

GPERF_PATH: str = which("gperf") or ""
CLANG_FORMAT_PATH: str = which("clang-format") or ""

STRING_COMPARES = Literal["memcmp", "check1memcmp", "neon", "neon_xor", "neon_strcmp", "neon_padded"]
LEGAL_STRING_COMPARES: frozenset[STRING_COMPARES] = frozenset(
    {"memcmp", "check1memcmp", "neon", "neon_xor", "neon_strcmp", "neon_padded"}
)

KEYWORD_MAPPING = Literal["mapping", "list"]
LEGAL_KW_MAPPINGS: frozenset[str] = frozenset({"mapping", "list"})

GEN_MODES = Literal["gperf", "switch"]
LEGAL_GEN_MODES: frozenset[GEN_MODES] = frozenset({"gperf", "switch"})

COMP_OUTPUT_MODE = Literal["enum", "bool", "string"]
LEGAL_OUTPUT_MODES: frozenset[COMP_OUTPUT_MODE] = frozenset({"enum", "bool", "string"})

LEVEL_STRATEGIES = Literal["pos", "len", "match", "chunk"]


@dataclass(slots=True, frozen=True)
class Level:
    """A single dispatch level: strategy + optional positions."""

    strategy: LEVEL_STRATEGIES
    positions: OrdKey | None = None


type Levels = list[Level]

PATH_SENTINEL = Path("NONE")


@dataclass(slots=True, frozen=True)
class Arguments:
    """The arguments for this script."""

    gen_mode: GEN_MODES
    comp_mode: COMP_OUTPUT_MODE
    input: Path

    stdout: bool

    string_compare: STRING_COMPARES
    cmov: bool
    saturate_hash: bool
    jump: int
    best_jump: bool

    prefix: str
    struct_name: str
    namespace: str
    enum_name: str
    func_name: str
    include_name: str
    default_return: str
    extra_constant: str
    string_return: bool

    threshold: int
    levels: Levels

    format: bool
    padded: bool
    create_enum: bool

    output: Path = PATH_SENTINEL

    @property
    def output_enabled(self) -> bool:
        """Whether no output file was specified (i.e. output is the sentinel value)."""
        return self.output != PATH_SENTINEL


def parse_level(level_str: str) -> Level:
    """Parse a single level: 'pos:0,1,-1,-2', 'len', or 'match'."""
    if level_str == "len":
        return Level(strategy="len")
    if level_str == "match":
        return Level(strategy="match")
    if level_str.startswith("pos:"):
        return Level(strategy="pos", positions=[int(p) for p in level_str[4:].split(",")])
    if level_str == "chunk":
        return Level(strategy="chunk")
    raise ValueError(f"invalid level: {level_str!r} (expected 'pos:...', 'len', 'match', or 'chunk')")


def parse_levels(ls: str) -> Levels:
    """Parse 'pos:0|pos:0,1,-1,-2|len' into a list of Level objects."""
    return [parse_level(s.strip()) for s in ls.split("|")]


class Modes(BaseModel):
    """Defines the configuration for gen_gperf.py, including generation mode and comparison mode."""

    gen_mode: GEN_MODES = "switch"
    comp_mode: COMP_OUTPUT_MODE = "enum"


class Options(BaseModel):
    """Defines the options for gen_gperf.py, including string comparison method and other flags."""

    string_compare: STRING_COMPARES = "memcmp"
    cmov: bool = False
    saturate_hash: bool = False
    jump: int = 1
    best_jump: bool = True
    prefix: str = "en_"
    struct_name: str = "struct_entry"
    namespace: str = "bake"
    enum_name: str = "default_enum"
    func_name: str = "string_compare"
    include_name: str = "enum_define.hpp"
    default_return: str = "false"
    extra_constant: str = ""
    string_return: bool = False
    threshold: int = 5
    levels: str = "pos:0|pos:-1|pos:-2"
    format: bool = True


class MainConfig(BaseModel):
    """The main configuration for gen_gperf.py, including input/output paths and modes."""

    input: Path = Field(default=Path("keywords.txt"))
    output: Path = Field(default=PATH_SENTINEL)
    stdout: bool = False

    modes: Modes = Modes()
    options: Options = Options()

    @field_serializer("input", "output")
    @classmethod
    def _serialize_paths(cls, v: Path) -> str:
        """Serialize paths as strings."""
        if v == PATH_SENTINEL:
            return "NONE"
        return str(v)


def get_config_manager(name: str) -> ConfigManager[MainConfig]:
    """Get the configuration manager for gen_gperf.py."""
    return ConfigManager(MainConfig, program_name="gen_lookup", env=name)


def get_config(name: str) -> MainConfig:
    """Get the configuration for gen_gperf.py."""
    return get_config_manager(name).config


def get_attr[T](o: Any, a: str, d: T) -> T:
    """Get an attribute from an object, returning a default if the attribute is None or doesn't exist."""
    v: T | None = getattr(o, a, None)
    return cast("T", v if v is not None else d)


def get_args(a: list[str]) -> Arguments:
    """Parse CLI args with config file backfill.

    Priority: CLI args > config file (TOML/env) > Pydantic defaults.
    """
    parser = ArgumentParser()

    parser.add_argument("--config", "-c", type=str, default="default", help="config name (default: 'default')")
    subparser = parser.add_subparsers(dest="comp_mode", required=False)
    parser.set_defaults(comp_mode=None)
    parsers: dict[COMP_OUTPUT_MODE, ArgumentParser] = {
        mode: subparser.add_parser(mode, help=f"{mode} comparison mode") for mode in LEGAL_OUTPUT_MODES
    }
    for p in parsers.values():
        p.add_argument("--gen-mode", choices=LEGAL_GEN_MODES, default=None)
        p.add_argument("--input", metavar="INPUT", type=Path, default=None)
        p.add_argument("--output", metavar="PATH", type=Path, default=None)
        p.add_argument("--stdout", action="store_true", default=None)
        p.add_argument("--string-compare", default=None, choices=LEGAL_STRING_COMPARES)
        p.add_argument("--cmov", action="store_true", default=None)
        p.add_argument("--saturate-hash", action="store_true", default=None)
        p.add_argument("--jump", type=int, default=None)
        p.add_argument("--best-jump", action="store_true", default=None)
        p.add_argument("--prefix", default=None)
        p.add_argument("--namespace", default=None)
        p.add_argument("--enum-name", default=None)
        p.add_argument("--func-name", default=None)
        p.add_argument("--include-name", default=None)
        p.add_argument("--struct-name", default=None)
        p.add_argument("--format", action="store_true", default=None)
        p.add_argument("--padded", action="store_true", default=None)
        p.add_argument("--create-enum", action="store_true", default=None)
        p.add_argument("--threshold", type=int, default=None)
        p.add_argument("--extra-constant", type=str, default=None, dest="extra_constant")
        p.add_argument("--string-return", action="store_true", default=None)
        p.add_argument("--levels", type=str, default=None)
        p.add_argument("--default-return", default=None)

    ns: Namespace = parser.parse_args(a)
    config_name: str = ns.config or "default"
    cfg: MainConfig = get_config(config_name)
    opts: Options = cfg.options

    include_name: str = "" if ns.comp_mode in {"bool", "string"} else get_attr(ns, "include_name", opts.include_name)
    input_path = get_attr(ns, "input", cfg.input)
    if not input_path or input_path.is_dir():
        raise ValueError("input path must be specified via --input or config file")

    return Arguments(
        gen_mode=get_attr(ns, "gen_mode", cfg.modes.gen_mode),
        comp_mode=get_attr(ns, "comp_mode", cfg.modes.comp_mode),
        input=input_path,
        stdout=get_attr(ns, "stdout", cfg.stdout),
        string_compare=get_attr(ns, "string_compare", opts.string_compare),
        cmov=get_attr(ns, "cmov", opts.cmov),
        saturate_hash=get_attr(ns, "saturate_hash", opts.saturate_hash),
        jump=get_attr(ns, "jump", opts.jump),
        best_jump=get_attr(ns, "best_jump", opts.best_jump),
        prefix=get_attr(ns, "prefix", opts.prefix),
        struct_name=get_attr(ns, "struct_name", opts.struct_name),
        namespace=get_attr(ns, "namespace", opts.namespace),
        enum_name=get_attr(ns, "enum_name", opts.enum_name),
        func_name=get_attr(ns, "func_name", opts.func_name),
        include_name=include_name,
        extra_constant=get_attr(ns, "extra_constant", opts.extra_constant),
        string_return=get_attr(ns, "string_return", opts.string_return),
        default_return=get_attr(ns, "default_return", opts.default_return),
        threshold=get_attr(ns, "threshold", opts.threshold),
        levels=parse_levels(get_attr(ns, "levels", opts.levels)),
        format=get_attr(ns, "format", opts.format),
        padded=get_attr(ns, "padded", d=False),
        create_enum=get_attr(ns, "create_enum", d=False),
        output=get_attr(ns, "output", cfg.output),
    )
