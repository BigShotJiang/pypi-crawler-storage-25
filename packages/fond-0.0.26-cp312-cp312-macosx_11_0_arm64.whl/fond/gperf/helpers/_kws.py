from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

from fond.gperf._strings import CB, OB, QU, SLASH

if TYPE_CHECKING:
    from collections.abc import Generator

    from fond.gperf.config import Arguments


## keywords as enum values
## fn_abs
def keywords_as_enum(sorted_keywords: SortedKeywords, prefix: str = "fn_") -> list[str]:
    """Convert a list of keywords to a list of enum values with a given prefix."""
    enum_values: list[str] = []
    for kw in sorted_keywords.values():
        enum_values.append(f"{prefix}{kw.low}")
    return enum_values


## keywords with with themselves and the enum values for the struct def, NOT in gperf, this is for a header file
## {"abs",                        runtime_func::fn_abs},                        \
def keywords_as_struct_input(
    sorted_keywords: SortedKeywords,
    prefix: str = "fn_",
    enum_name: str = "runtime_func",
) -> list[str]:
    """Convert a list of keywords to a list of struct input lines with the keyword and its corresponding enum value."""
    struct_lines: list[str] = []
    for kw in sorted_keywords.values():
        pad: str = " " * (sorted_keywords.pad_num - kw.size)
        struct_lines.append(f"{OB}{QU}{kw.s}{QU},{pad}{enum_name}::{prefix}{kw.low}{CB},{pad}{SLASH}")
    return struct_lines


@dataclass(slots=True)
class Keywords:
    """A keyword with its original string, lowercase version, length, and optional value."""

    s: str
    low: str
    size: int = 0
    value: str = ""


class SortedKeywords:
    """A dict of Keywords, sorted alphabetically by the lowercase version."""

    def __init__(self) -> None:
        self._data: dict[str, Keywords] = {}
        self._min_len: int = 0
        self._max_len: int = 0
        self._num: int = 0
        self._pad_num: int = 0

    def add(self, kw: str, value: str | None = None) -> None:
        """Add a keyword to the sorted keywords."""
        k = Keywords(kw, kw.lower(), len(kw), value or "")
        self._data[kw] = k

    @classmethod
    def load(cls, inpt: dict[str, str] | Sequence[str]) -> SortedKeywords:
        new = cls()

        if isinstance(inpt, dict):
            for k, v in inpt.items():
                new.add(k, v)  # ty:ignore[invalid-argument-type]
        elif isinstance(inpt, Sequence):
            for k in inpt:
                new.add(k)
        return new

    def set_value(self, key: str, value: str) -> None:
        if key in self._data:
            self._data[key].value = value

    def sort_by_lower(self) -> None:
        self._data = dict(sorted(self._data.items(), key=lambda x: x[1].low))

    def keys(self) -> Generator[str]:
        """Iterate over the original strings in the sorted keywords."""
        yield from self._data.keys()

    def values(self) -> Generator[Keywords]:
        """Iterate over the Keywords in the sorted keywords."""
        yield from self._data.values()

    def items(self) -> Generator[tuple[str, Keywords]]:
        """Iterate over the sorted keywords as tuples of (original string, Keywords)."""
        yield from self._data.items()

    def duplicates(self) -> list[str]:
        """Check for duplicate lowercase keywords."""
        seen: set[str] = set()
        duplicates: list[str] = []
        for v in self._data.values():
            if v.low in seen:
                duplicates.append(v.low)
            else:
                seen.add(v.low)
        return duplicates

    @property
    def min_len(self) -> int:
        if not self._min_len:
            self._min_len = min(len(v.s) for v in self.values())
        return self._min_len

    @property
    def max_len(self) -> int:
        if not self._max_len:
            self._max_len = max(len(v.s) for v in self.values())
        return self._max_len

    @property
    def pad_num(self) -> int:
        if not self._pad_num:
            self._pad_num = self.max_len + 1
        return self._pad_num

    @property
    def num(self) -> int:
        if not self._num:
            self._num = len(self._data)
        return self._num

    def str_iter(self) -> Generator[str]:
        """Iterate over the original strings in the sorted keywords."""
        for v in self.values():
            yield v.s

    def __iter__(self) -> Generator[tuple[str, Keywords]]:
        """Iterate over the sorted keywords as (key, Keywords) pairs."""
        yield from self.items()

    def __getitem__(self, key: str) -> Keywords:
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __len__(self) -> int:
        return len(self._data)


def read_plain_keywords(a: Arguments) -> SortedKeywords:
    """Read a plain keyword file (one keyword per line, # comments, blank lines ignored)."""
    sorted_keywords: SortedKeywords = SortedKeywords()
    lines: list[str] = a.input.read_text().splitlines()
    for line in lines:
        kw: str = line.strip()
        if kw and not kw.startswith("#"):
            if " = " in kw:
                key, _, val = kw.partition(" = ")
                sorted_keywords.add(key.strip(), val.strip())
            else:
                sorted_keywords.add(kw)
    if duplicates := sorted_keywords.duplicates():
        raise ValueError(f"Duplicate keywords found when sorting: {', '.join(duplicates)}")
    sorted_keywords.sort_by_lower()
    return sorted_keywords
