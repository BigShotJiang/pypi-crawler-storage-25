import re
from typing import Self

_DECL_PATTERN = re.compile(r"^\s*(?:\w+\s+)+\w+\s*=")


def _has_declarations(text: str) -> bool:
    """Check if C++ text contains variable declarations."""
    return any(_DECL_PATTERN.match(line) for line in text.splitlines())


class Buffer:
    """Indent-aware buffer for generating C++ source."""

    def __init__(self, indent_str: str = "    ") -> None:
        self._lines: list[str] = []
        self._indent_str = indent_str
        self._depth = 0

    @property
    def prefix(self) -> str:
        return self._indent_str * self._depth

    def nl(self) -> Self:
        self._lines.append("")
        return self

    def write(self, s: str) -> Self:
        for line in s.splitlines():
            if line.strip():
                self._lines.append(f"{self.prefix}{line}")
            else:
                self._lines.append("")
        return self

    def write_raw(self, s: str) -> Self:
        """Write without indentation (for preprocessor directives, etc)."""
        for line in s.splitlines():
            self._lines.append(line)
        return self

    def indent(self) -> Self:
        self._depth += 1
        return self

    def dedent(self) -> Self:
        if self._depth > 0:
            self._depth -= 1
        return self

    def block(self, header: str = "", footer: str = "}") -> _Block:
        """Context manager for indented blocks.

        Usage:
            with buf.block("switch (x) {"):
                buf.write("case 1: return true;")
            # automatically writes "}" and dedents
        """
        return _Block(self, header, footer)

    def capture(self) -> "Buffer":
        """Create a child buffer at the same depth for capturing output."""
        child = Buffer(self._indent_str)
        child._depth = self._depth
        return child

    def absorb(self, other: "Buffer", scope_if_decls: bool = False) -> Self:
        """Absorb lines from another buffer, optionally wrapping in braces if it contains declarations."""
        text = other.join()
        if scope_if_decls and _has_declarations(text):
            self.write("{")
            self._lines.extend(other._lines)
            self.write("} break;")
        else:
            self._lines.extend(other._lines)
        return self

    def join(self, sep: str = "\n") -> str:
        return sep.join(self._lines)

    def __len__(self) -> int:
        return len(self._lines)


class _Block:
    """Context manager for Buffer.block()."""

    def __init__(self, buf: Buffer, header: str, footer: str) -> None:
        self._buf = buf
        self._footer = footer
        if header:
            buf.write(header)

    def __enter__(self) -> Buffer:
        self._buf.indent()
        return self._buf

    def __exit__(self, *_: object) -> None:
        self._buf.dedent()
        if self._footer:
            self._buf.write(self._footer)
