"""Helper functions for working with Gperf output."""

from __future__ import annotations

import subprocess
from typing import TYPE_CHECKING

from lazy_bear import lazy

from fond.gperf._strings import CB, OB
from fond.gperf.config import CLANG_FORMAT_PATH, OrdKey

if TYPE_CHECKING:
    from pathlib import Path
    import re
else:
    re = lazy("re")


def call_clang_format(file_path: Path) -> None:
    """Run clang-format on the given file path."""
    if not CLANG_FORMAT_PATH:
        return
    cmd: list[str] = [CLANG_FORMAT_PATH, "-i", str(file_path)]
    subprocess.check_output(cmd, encoding="utf-8")


FIRST_CHAR: OrdKey = [0]


def _make_key(s: str, p: OrdKey) -> int:
    result = 0
    slen = len(s)
    for i, pos in enumerate(p):
        idx = pos if pos >= 0 else slen + pos
        if 0 <= idx < slen:
            result |= ord(s[idx]) << (8 * i)
    return result


def _quad_hex(s: str, p: OrdKey = FIRST_CHAR) -> str:
    return f"0x{_make_key(s, p):08x}"


def _quad_comment(s: str, p: OrdKey | None = None) -> str:
    if p is None:
        p = FIRST_CHAR
    slen = len(s)
    chars = "".join(s[pos] if (pos >= 0 and pos < slen) or (pos < 0 and abs(pos) <= slen) else "?" for pos in p)
    return f"/* '{chars}' */"


def string_to_chunks(s: str, pad_to: int | None = None) -> list[int]:
    """Convert a string to a list of uint64 chunks (little-endian).

    If pad_to is given, pad the string with null bytes to that length.
    """
    raw = s.encode("ascii")
    if pad_to:
        raw = raw.ljust(pad_to, b"\x00")
    chunks: list[int] = []
    for i in range(0, len(raw), 8):
        chunk = raw[i : i + 8]
        val = int.from_bytes(chunk.ljust(8, b"\x00"), "little")
        chunks.append(val)
    return chunks


def chunk_hex(val: int) -> str:
    """Format a uint64 value as a C++ hex literal."""
    return f"0x{val:016x}ULL"


def string_to_chunk_comment(s: str) -> str:
    """Generate a comment showing the string for a chunk comparison."""
    return f'/* "{s}" */'


SIXTEEN_BYTES = 16
THIRTY_TWO_BYTES = 32


def pad_size(max_len: int) -> int:
    """Round up to the next multiple of 16."""
    if max_len <= SIXTEEN_BYTES:
        return SIXTEEN_BYTES
    if max_len <= THIRTY_TWO_BYTES:
        return THIRTY_TWO_BYTES
    return ((max_len + 15) // 16) * 16


def keyword_to_padded_chars(s: str, pad_to: int) -> str:
    """Convert a keyword to a C++ char array initializer with null + underscore padding.

    "bake_add" with pad_to=16 -> "{'b','a','k','e','_','a','d','d',0,0,0,0,0,0,0,0}"
    The 0 is the null terminator.
    """
    chars: list[str] = [f"'{c}'" for c in s]
    chars.append("0")
    remaining = pad_to - len(s) - 1
    chars.extend(["0"] * remaining)
    return f"{OB}{','.join(chars)}{CB}"


def transform_wordlist_to_padded(wordlist: str, pad_to: int) -> str:
    """Transform gperf wordlist entries from {"keyword", value} to padded char arrays.

    Empty entries {"", static_cast<...>(0)} get all-underscore padding with a null byte.
    """
    lines: list[str] = []
    compiled: re.Pattern[str] = re.compile(r'\s*\{"([^"]*)",\s*(.+?)\s*\}(.*)')
    for line in wordlist.splitlines():
        # Match {"keyword", rest} or {"", rest}
        m: re.Match[str] | None = compiled.match(line)
        if m is not None:
            keyword: str = m.group(1)
            rest: str = m.group(2).rstrip(",")
            trailing: str = m.group(3)
            if keyword:
                padded: str = keyword_to_padded_chars(keyword, pad_to)
                lines.append(f"  {{{padded}, {rest}}}{trailing}")
            else:
                empty_pad = OB + "0" + ",0" * (pad_to - 1) + CB
                lines.append(f"  {{{empty_pad}, {rest}}}{trailing}")
        else:
            lines.append(line)
    return "\n".join(lines)


# ruff: noqa: S603
