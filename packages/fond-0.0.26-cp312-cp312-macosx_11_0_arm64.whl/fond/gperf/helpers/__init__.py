"""Helper functions for GPerf code generation and testing."""

from fond.gperf.config import OrdKey

from ._buf import Buffer
from ._extras import (
    _make_key,
    _quad_comment,
    _quad_hex,
    call_clang_format,
    chunk_hex,
    keyword_to_padded_chars,
    pad_size,
    string_to_chunk_comment,
    string_to_chunks,
    transform_wordlist_to_padded,
)
from ._gperf_template import GPerfTables, call_gperf, find_best_jump, generate_gperf_input, parse_gperf_output
from ._kws import Keywords, SortedKeywords, keywords_as_enum, keywords_as_struct_input, read_plain_keywords

__all__: list[str] = [
    "Buffer",
    "GPerfTables",
    "Keywords",
    "OrdKey",
    "SortedKeywords",
    "_make_key",
    "_quad_comment",
    "_quad_hex",
    "call_clang_format",
    "call_gperf",
    "chunk_hex",
    "find_best_jump",
    "generate_gperf_input",
    "keyword_to_padded_chars",
    "keywords_as_enum",
    "keywords_as_struct_input",
    "pad_size",
    "parse_gperf_output",
    "read_plain_keywords",
    "string_to_chunk_comment",
    "string_to_chunks",
    "transform_wordlist_to_padded",
]
