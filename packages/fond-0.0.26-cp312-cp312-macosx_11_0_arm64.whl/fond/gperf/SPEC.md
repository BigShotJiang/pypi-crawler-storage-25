# gen-lookup: Unified String Lookup Generator

## Purpose

A CLI tool and Python API (Blueprint) that generates optimized C++ string lookup functions from a keyword list. Two strategies: **switch cascade** (pure switches, no hashing) and **gperf** (perfect hash + optional ARM NEON SIMD). Supports configuration via CLI flags, TOML config files, or Python Blueprint objects.

## CLI Interface

```
gen-lookup [--config NAME] <comp-mode> [options]
```

`comp-mode` is a subparser: `bool`, `enum`, or `struct`. All flags live inside the subparser. If no CLI args are provided, defaults are loaded from `ConfigManager` (TOML + env vars + Pydantic defaults).

### Examples

```bash
# Enum lookup with switch cascade
gen-lookup enum --gen-mode switch --input keywords.txt --output lookup.hpp \
  --enum-name rn_fn --prefix fn_ --default-return "rn_fn::sentinel" \
  --levels "pos:0|len|chunk" --create-enum --format

# Gperf + NEON padded (fastest for large keyword sets)
gen-lookup enum --gen-mode gperf --input keywords.txt --output lookup.hpp \
  --enum-name rn_fn --prefix fn_ --default-return "identifier" \
  --string-compare neon_padded --cmov --padded --best-jump

# Bool lookup
gen-lookup bool --gen-mode switch --input kws.txt --stdout --levels "len|chunk"

# Use config file
gen-lookup -c myproject enum --stdout
```

### Common Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--config`, `-c` | `default` | Config name (loads `<name>.toml`) |
| `--gen-mode` | from config | `switch` or `gperf` |
| `--input` | from config | Keyword file path |
| `--output` | none | Output `.hpp` file path |
| `--stdout` | off | Print generated code to stdout |
| `--format` | off | Run clang-format on output |
| `--create-enum` | off | Generate enum definition inline in the output file |

### Naming Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--func-name` | from config | Generated function name |
| `--namespace` | from config | C++ namespace |
| `--enum-name` | from config | Enum type name |
| `--struct-name` | from config | Struct type name (gperf) |
| `--include-name` | from config | Include path for type definitions |
| `--prefix` | from config | Enum value prefix (e.g. `fn_`) |
| `--default-return` | mode-dependent | Sentinel value. Bool: `false`, Enum: required |

### Switch-Specific Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--levels` | `pos:0\|pos:-1\|pos:-2` | Dispatch levels (see below) |
| `--threshold` | `3` | Group size below which sequential compare is used |

### Gperf-Specific Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--string-compare` | `memcmp` | Compare strategy (see below) |
| `--cmov` | off | Branchless ARM csel assembly |
| `--padded` | off | Pad wordlist entries (auto-enabled for `neon_padded`) |
| `--jump` | `1` | Gperf jump parameter |
| `--best-jump` | off | Brute-force optimal jump (tries 1-20) |
| `--saturate-hash` | off | Saturate hash to MAX_HASH_VALUE + 1 |

## Dispatch Levels (Switch Strategy)

`--levels` is a pipe-separated list of dispatch strategies. Each level groups keywords and recurses into the next level for large groups. Below `--threshold`, sequential `str ==` comparison is used.

### Level Types

| Type | Syntax | Description |
|------|--------|-------------|
| `pos` | `pos:0,1,-1,-2` | Pack characters at positions into integer key, switch on hex value |
| `len` | `len` | Switch on string length |
| `chunk` | `chunk` | Load string as uint64 chunks, compare against compile-time constants |
| `match` | `match` | Sequential `str ==` comparison (leaf fallback) |

### Recommended Configurations

| Keywords | Levels | Why |
|----------|--------|-----|
| < 20 | `len\|chunk` | Length switch + integer compare. Fastest for small sets. |
| 20-50 | `pos:0\|len\|chunk` | First char narrows, length disambiguates, chunk finishes. |
| 50-200 | `pos:0\|pos:-1\|len` | Two character switches + length. |
| 200+ | Use gperf instead | Perfect hash + NEON beats switch cascade. |

**Note:** `chunk` requires `len` before it — chunk assumes all strings in a group are the same length.

## String Compare Strategies (Gperf)

| Strategy | Platform | Description |
|----------|----------|-------------|
| `memcmp` | Any | Portable baseline |
| `check1memcmp` | Any | First-byte early exit + memcmp |
| `neon` | ARM | 16-byte NEON compare with bitmask |
| `neon_xor` | ARM | NEON XOR + mask + vmaxvq reduction |
| `neon_strcmp` | ARM | NEON XOR + combined asm block |
| `neon_padded` | ARM | Two-load NEON, no mask, padded arrays. **Fastest.** |

All NEON strategies support `--cmov` for branchless csel.

`neon_padded` requires both the wordlist entries AND the input strings to be zero-padded to 32 bytes. It auto-enables `--padded` for the wordlist. Input padding is the caller's responsibility (e.g. `calloc(1, file_size + 32)` for lexer source buffers).

## Blueprint API (Python)

For programmatic use without the CLI:

```python
from fond.gperf.blueprint import Blueprint
from fond.gperf.helpers import SortedKeywords as Keywords

BLUEPRINT = Blueprint(
    keyword_type="mapping",
    create_enum=True,
    comment_keys=True,
    gen_mode="switch",
    comp_mode="enum",
    namespace="bake",
    enum_name="Operator",
    func_name="get_operator",
    default_return="Operator::Sentinel",
    levels="pos:-1|len",
    keywords=Keywords.load({
        "::": "Definition",
        "->": "ReturnType",
        "=": "Assignment",
    }),
)

result = BLUEPRINT.generate(stdout=True)
BLUEPRINT.generate(output=Path("operators.hpp"))
```

Blueprint does not mutate the original keywords — `generate()` is safe to call multiple times.

## Generated C++ Structure

The tool uses `LookupEntry<N, EnumType>` from `fond/str_utils.hpp`:

```cpp
template <size_t N, typename EnumType>
struct LookupEntry {
    char str[N];
    EnumType value;
};
```

Field names are `str` (keyword string) and `value` (enum value) throughout all generated code.

## Output

- **Switch strategy:** Single `.hpp` file. Optionally includes inline enum definition (`--create-enum`).
- **Gperf strategy:** Two `.hpp` files — type definition (enum + macro table) and lookup (hash table + comparison).

## Configuration

Config files are managed via `ConfigManager` from `bear_config`. The tool looks for `<name>.toml` in the config directory. CLI flags override config values.

```toml
[modes]
gen_mode = "switch"
comp_mode = "enum"

[options]
string_compare = "memcmp"
prefix = "fn_"
namespace = "bake"
enum_name = "runtime_func"
threshold = 3
levels = "pos:0|pos:-1|pos:-2"
```

## Benchmark Results (Apple Silicon M1, 100M lookups, 80% miss rate)

### 200 keywords (runtime functions)

| Strategy | Time | ns/lookup |
|----------|------|-----------|
| unordered_set | 431ms | 4.31 |
| switch pos:0 | 200ms | 2.00 |
| switch pos:0\|pos:-1 | 198ms | 1.98 |
| switch pos:0\|len\|chunk | 187ms | 1.87 |
| gperf + neon_strcmp | 168ms | 1.68 |
| **gperf + neon_padded** | **156ms** | **1.56** |

### 15 keywords (language keywords)

| Strategy | Time | ns/lookup |
|----------|------|-----------|
| unordered_set | 400ms | 4.00 |
| switch pos:0 | 153ms | 1.53 |
| switch pos:0\|len\|chunk | 150ms | 1.50 |
| **switch len\|chunk** | **120ms** | **1.20** |
