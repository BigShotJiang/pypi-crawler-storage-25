# gen-lookup TODO

## Done
- [x] Run `clang-format` on generated files (`--format`)
- [x] Configurable dispatch levels (`--levels`)
- [x] `chunk` strategy (integer compare via memcpy)
- [x] `neon_padded` (decomposed arrays, no mask, fastest gperf path)
- [x] Blueprint API for programmatic use
- [x] ConfigManager integration (TOML + env + CLI backfill)
- [x] `--create-enum` for inline enum generation
- [x] `--padded` for decomposed char array wordlists
- [x] Unified `LookupEntry<N, EnumType>` struct from `fond/str_utils.hpp`
- [x] Unified field names: `entry.str`, `entry.value`
- [x] Removed `neon_2load` (superseded by `neon_padded`)
- [x] Removed `struct` comp mode (return enum, caller indexes array)
- [x] Removed `bench` gen mode (benchmarks done manually)
- [x] `_quad_comment` dynamic based on positions
- [x] Benchmark: 15 keywords, 200 keywords, multiple switch strategies
- [x] `verify_one` strategy: single-char verification for 2-3 char strings when one position remains unchecked
- [x] Fix `direct_return` to require full character verification (all positions checked >= keyword length)
- [x] `--extra-constant` for injecting constants into generated output
- [x] `--string-return` for string-to-string lookup mode

## Remaining
- [ ] Migrate `_strings.py` gperf functions to use Buffer with `block()` instead of manual INDENT constants
- [ ] Clean up gperf output indentation (asso_values/wordlist from gperf raw don't align)
- [ ] x86 SSE2/ptest path for Linux CI
- [ ] `--no-early-bounds-check` for lexer contexts where input buffers are safely over-readable
- [ ] Tests for gperf generation path
- [ ] Tests for chunk strategy correctness
- [ ] Tests for `string` comp mode (no compile tests currently)
- [ ] Tests for `verify_one` and `direct` strategy nodes
- [ ] Tests for `_buf.py` (Buffer, absorb, scope_if_decls)
- [ ] Tests for `_extras.py` pure functions (string_to_chunks, pad_size, etc.)
- [ ] Deduplicate `compare_neon_strcmp` / `compare_neon_xor` non-cmov paths (generate identical code)
- [ ] Remove stale Blueprint/struct references from README.md and SPEC.md
- [ ] Thread `GlobalContext` per-call instead of module-level singleton (if concurrent use ever needed)
