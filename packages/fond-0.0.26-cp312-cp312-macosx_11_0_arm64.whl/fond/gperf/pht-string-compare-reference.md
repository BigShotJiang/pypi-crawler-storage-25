# Perfect Hash Table String Comparison: Complete Reference

*Research notes from strager's perfect-hash-tables repo (quick-lint-js) applied to Bake's runtime function lookup on ARM/NEON.*

---

## The Core Insight: Where Time Actually Goes

In a perfect hash table lookup, the hash is computed, an index is derived, and a single
table slot is probed. There are no collisions. So nearly all remaining time is spent on
the **verification step** — confirming the candidate string at that slot actually matches
the input. The hash only samples a few character positions, so two different strings can
land in the same slot.

Strager's video progression demonstrates this clearly:

1. **Baseline**: `std::unordered_map` — ~12M lookups/sec
2. **gperf (perfect hash)** — fastest off-the-shelf, beats everything prior
3. **Custom hash + first-char check** — beats gperf by 50%
4. **SIMD string compare** — faster still
5. **Branchless (cmov/csel)** — eliminates misprediction overhead
6. **Final: branchless + no length branch + no bounds branch** — ~10x standard libraries

The key takeaway: once you have a perfect hash, **the string comparison strategy and
branch elimination dominate performance**.

---

## String Comparison Strategies (Complete Taxonomy)

### 1. `memcmp` (Baseline, Portable)

```cpp
int comparison = std::memcmp(str, entry.keyword, len);
if (comparison == 0) {
    comparison = entry.keyword[len];  // length check via null terminator
}
```

Simple and portable. libc `memcmp` is heavily optimized, but it's a function call
(potential pipeline stall) and the length check is a separate branch.

### 2. `check1memcmp` (First-Byte Early Exit)

```cpp
if (entry.keyword[0] != str[0]) {
    return identifier;  // fast reject
}
int comparison = std::memcmp(str, entry.keyword, len);
if (comparison == 0) {
    comparison = entry.keyword[len];
}
```

**This beat gperf by 50%.** Most inputs to a lexer/parser are *not* keywords — they're
identifiers like `myVariable`. A single byte comparison rejects the vast majority without
ever touching memcmp. The branch predicts well because it's almost always taken (reject).

### 3. `check2memcmp` (Two-Byte Early Exit)

Same idea, checks two bytes. Diminishing returns — the second byte catches fewer
mismatches that the first didn't already catch.

### 4. `sse2` (x86 SIMD)

```cpp
__m128i entry_v = _mm_lddqu_si128((const __m128i*)entry.keyword);
__m128i str_v   = _mm_lddqu_si128((const __m128i*)str);
// Build length mask: ~(~0u << len) is "much much faster" than (1 << len) - 1
uint32_t inv_mask = ~(uint32_t)0 << len;
uint32_t mask = ~inv_mask;
uint32_t equal_mask = _mm_movemask_epi8(_mm_cmpeq_epi8(entry_v, str_v));
uint32_t not_equal_mask = ~equal_mask;
// Then: (mask & not_equal_mask) != 0 means mismatch
```

Compares all 16 bytes in parallel. The masking handles variable-length strings without
branching on length.

### 5. `ptest` (SSE4.1, x86)

```cpp
__m128i mask = _mm_cmpgt_epi8(_mm_set1_epi8(len), _mm_setr_epi8(0,1,...,15));
__m128i entry_v = _mm_lddqu_si128((const __m128i*)entry.keyword);
__m128i str_v   = _mm_lddqu_si128((const __m128i*)str);
__m128i compared = _mm_xor_si128(entry_v, str_v);
// PTEST sets ZF if (compared AND mask) == 0
```

Trades movemask+test for PTEST. Different instruction mix, can be faster depending on
microarchitecture.

### 6. `cmpestri` (SSE4.2, x86)

Uses `PCMPESTRM` — literally designed for string comparison. Feeds both strings and their
lengths, does masked comparison in one instruction. Very compact but PCMPESTRM has high
latency on some µarchs.

### 7. `chunk84` (Portable, Non-SIMD)

```cpp
// Load first 8 bytes and next 4 bytes as integers
uint64_t entry_first_8, identifier_first_8;
uint32_t entry_last_4, identifier_last_4;
memcpy(&entry_first_8, entry.keyword, 8);
memcpy(&identifier_first_8, str, 8);
memcpy(&entry_last_4, entry.keyword + 8, 4);
memcpy(&identifier_last_4, str + 8, 4);

// Build masks based on length
uint64_t first_8_mask = (size >= 8) ? ~0ULL : ((1ULL << (size*8)) - 1);
uint32_t last_4_mask  = (size <= 8) ? 0 : ((1u << ((size-8)*8)) - 1);

// XOR, mask, OR together — zero means match
uint64_t cmp8 = (identifier_first_8 ^ entry_first_8) & first_8_mask;
uint64_t cmp4 = (identifier_last_4 ^ entry_last_4) & last_4_mask;
// if (cmp8 | cmp4) != 0 → mismatch
```

**Best non-SIMD option.** Covers up to 12-byte strings in two loads. On ARM64,
unaligned loads are fast and `csel` gives you branchless behavior naturally.
Clang generates cmov/csel well here; GCC may not (check your output).

### 8. `neon-mask-test` (ARM NEON)

```cpp
uint8x16_t iota = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
uint8x16_t mask = vcgtq_u8(vdupq_n_u8(size), iota);
uint8x16_t entry_v, str_v;
memcpy(&entry_v, entry_keyword, 16);
memcpy(&str_v, identifier, 16);
uint8x16_t compared = vandq_u8(veorq_u8(entry_v, str_v), mask);
// Check: (vgetq_lane_s64(compared, 0) | vgetq_lane_s64(compared, 1)) == 0
```

ARM equivalent of the SSE approaches. The mask is built with vcgtq, comparison is
XOR + AND, and result is checked via lane extraction.

---

## The `cmov`/`csel` Dimension (Branch Elimination)

Across all SIMD strategies, the `--cmov` variant eliminates mispredictable branches.

**The problem:** After comparison, the code must decide between returning the entry's
token type (match) or `identifier` (mismatch). A branch here mispredicts badly because
the outcome depends on whether the input happens to be a keyword — which is essentially
random from the branch predictor's perspective.

Strager's notes show gperf's `--compare-lengths` bumps misprediction from 6.18% to 9.20%.
That's catastrophic at this scale.

**The solution:** Start with `result = entry.type` and conditionally overwrite with
`identifier` using branchless conditional moves:

**x86 (inline asm, because compilers won't reliably emit cmov):**
```asm
cmpb $0, entry.keyword[len]           ; length check
cmovne token_type_identifier, result   ; branchless

ptest compared, mask                   ; string compare
cmovne token_type_identifier, result   ; branchless
```

**ARM64 (csel — a first-class instruction, often generated naturally):**
```asm
ldrb w8, [entry_ptr, len]   ; load null terminator position
cmp w8, #0
csel w0, w_ident, w0, ne    ; branchless length check

cmp w_maxdiff, #0
csel w0, w_ident, w0, ne    ; branchless content check
```

On ARM64, `csel` is cleaner than x86 `cmov` — the compiler often generates it without
needing inline assembly, though inline asm guarantees it.

---

## Advanced Optimizations

### `--keyword-size-in-entry`

Instead of checking `entry.fn[len] == '\0'` (variable-offset memory load), store the
keyword length in the struct:

```cpp
struct func_entry {
    char fn[MAX_WORD_LENGTH + 1];
    runtime_func func;
    uint8_t fn_len;  // NEW: stored length
};
```

**Why this helps:**
- `entry.fn[len]` requires a load at address `entry_ptr + len` — variable offset,
  depends on input, constrains scheduling
- `entry.fn_len` is at a fixed offset in the struct — predictable, can issue in
  parallel with SIMD work
- The comparison `entry.fn_len == len` is a simple integer `cmp` + `csel`

### `--no-early-bounds-check`

Removes the `if (len > MAX || len < MIN) return identifier;` branch at the top.

**How it's safe:** Out-of-range inputs still produce *some* table index via the hash
function (asso_values covers all 256 byte values). The string comparison at that slot
simply fails naturally, returning `identifier` anyway. You trade a branch for a harmless
extra lookup on rare out-of-range inputs.

**Requirement:** Input buffers must be safely readable up to 16 bytes (for SIMD loads)
even past the actual string end. Lexers working from contiguous source buffers usually
satisfy this naturally.

---

## Bake's Specific Situation

### Current Code (Bear's NEON Implementation)

```cpp
// 202 keywords, max length 26 chars (bake_target_system_include)
// Uses gperf-style hash with asso_values at positions 0, 5, 12, len-1
// Single 16-byte NEON comparison + csel for branchless result
```

### The 16-Byte Problem

Strager's keywords max out at 11 characters — everything fits in one 16-byte NEON
register. Bake's longest keyword is 26 characters. A single NEON load only covers
the first 16 bytes. Several `bake_*` entries exceed 16 chars.

### Recommended: Two-Load NEON (Covers Up to 32 Bytes)

This handles the entire Bake keyword set uniformly with no special cases:

```cpp
runtime_func is_runtime_func(const char* str, std::size_t len) noexcept {
    // ... hash computation, bounds check, table lookup ...

    const func_entry& entry = wordlist[h];

    // === Two-load NEON comparison for strings up to 32 bytes ===

    // Build masks for both halves
    //   First 16 bytes: mask_lo covers min(len, 16) bytes
    //   Next 16 bytes:  mask_hi covers max(len - 16, 0) bytes
    static constexpr uint8_t iota_data[16] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    uint8x16_t iota = vld1q_u8(iota_data);

    // Low mask: all 0xFF if len >= 16 for first 16 positions
    uint8x16_t mask_lo = vcltq_u8(iota, vdupq_n_u8(static_cast<uint8_t>(len < 16 ? len : 16)));

    // High mask: covers positions 16..31, so compare against (len - 16) clamped to 0
    uint8_t hi_len = static_cast<uint8_t>(len > 16 ? len - 16 : 0);
    uint8x16_t mask_hi = vcltq_u8(iota, vdupq_n_u8(hi_len));

    // Load and compare first 16 bytes
    uint8x16_t entry_lo = vld1q_u8(reinterpret_cast<const uint8_t*>(entry.fn));
    uint8x16_t str_lo   = vld1q_u8(reinterpret_cast<const uint8_t*>(str));
    uint8x16_t diff_lo  = vandq_u8(veorq_u8(entry_lo, str_lo), mask_lo);

    // Load and compare bytes 16..31
    // NOTE: entry.fn is 27 bytes (MAX_WORD_LENGTH+1), so entry.fn+16 is always
    // safe to read. For str, the caller must guarantee 32 bytes are readable
    // (typical for lexer source buffers).
    uint8x16_t entry_hi = vld1q_u8(reinterpret_cast<const uint8_t*>(entry.fn + 16));
    uint8x16_t str_hi   = vld1q_u8(reinterpret_cast<const uint8_t*>(str + 16));
    uint8x16_t diff_hi  = vandq_u8(veorq_u8(entry_hi, str_hi), mask_hi);

    // Combine both halves: OR all differences together
    uint8x16_t combined = vorrq_u8(diff_lo, diff_hi);

    // Reduce to scalar: vmaxvq_u8 gives 0 iff all bytes are 0
    // Alternative: (vgetq_lane_s64(combined, 0) | vgetq_lane_s64(combined, 1))
    // vmaxvq_u8 is fast on Apple Silicon; lane extract + OR may be faster on
    // older Cortex cores — benchmark on your target.
    uint8_t max_diff = vmaxvq_u8(combined);

    // Branchless result with csel
    int result = static_cast<int>(entry.func);
    __asm__(
        // Length check: entry.fn[len] must be null terminator
        "ldrb w8, %[entry_fn_at_len]\n"
        "cmp w8, #0\n"
        "csel %w[result], %w[ident], %w[result], ne\n"
        // Content check: combined masked diff must be zero
        "cmp %w[max_diff], #0\n"
        "csel %w[result], %w[ident], %w[result], ne\n"
        : [result]"+r"(result)
        : [entry_fn_at_len]"m"(entry.fn[len]),
          [max_diff]"r"(static_cast<int>(max_diff)),
          [ident]"r"(static_cast<int>(runtime_func::identifier))
        : "cc", "x8"
    );
    return static_cast<runtime_func>(result);
}
```

### With `keyword-size-in-entry` Optimization

Replace the variable-offset null terminator check with a fixed-offset length comparison:

```cpp
struct func_entry {
    char fn[MAX_WORD_LENGTH + 1];     // 27 bytes
    runtime_func func;                 // enum value
    uint8_t fn_len;                    // NEW: pre-stored length
};

// ... in the comparison section, replace the length check:

int result = static_cast<int>(entry.func);
__asm__(
    // Length check: compare stored length against input length
    "ldrb w8, %[entry_len]\n"          // fixed offset — fast, predictable
    "cmp w8, %w[input_len]\n"
    "csel %w[result], %w[ident], %w[result], ne\n"
    // Content check
    "cmp %w[max_diff], #0\n"
    "csel %w[result], %w[ident], %w[result], ne\n"
    : [result]"+r"(result)
    : [entry_len]"m"(entry.fn_len),
      [input_len]"r"(static_cast<int>(len)),
      [max_diff]"r"(static_cast<int>(max_diff)),
      [ident]"r"(static_cast<int>(runtime_func::identifier))
    : "cc", "x8"
);
```

The `ldrb` at a fixed struct offset can issue earlier in the pipeline than one at
`entry.fn + len` (variable offset depending on input).

### Non-SIMD Alternative: `chunk84` Extended to `chunk888`

For contexts where NEON isn't desired (e.g., generic scalar codepath):

```cpp
// Load three 8-byte chunks covering up to 24 bytes, plus entry.fn[len] check
uint64_t e0, e1, e2, s0, s1, s2;
memcpy(&e0, entry.fn,      8);  memcpy(&s0, str,      8);
memcpy(&e1, entry.fn + 8,  8);  memcpy(&s1, str + 8,  8);
memcpy(&e2, entry.fn + 16, 8);  memcpy(&s2, str + 16, 8);

// Build masks per chunk
uint64_t m0 = (len >= 8)  ? ~0ULL : ((1ULL << (len * 8)) - 1);
uint64_t m1 = (len <= 8)  ? 0 : (len >= 16) ? ~0ULL : ((1ULL << ((len-8)*8)) - 1);
uint64_t m2 = (len <= 16) ? 0 : ((1ULL << ((len-16)*8)) - 1);

uint64_t cmp = ((s0 ^ e0) & m0) | ((s1 ^ e1) & m1) | ((s2 ^ e2) & m2);

// cmp == 0 && entry.fn[len] == 0 → match
// Use csel to make it branchless
```

This covers up to 24 bytes in three 64-bit loads with no SIMD at all. For your max
of 26 bytes, you'd extend to a fourth 32-bit load (chunk8884) or just use four 64-bit
loads covering 32 bytes. On ARM64, `ldr x` (64-bit load) is single-cycle.

---

## The `bake_` Prefix Question

Bear asked: "Could we strip the `bake_` prefix, look up the suffix in a smaller table,
and return an `is_bake` flag?"

**Pros:**
- Halves the keyword count (~101 stems instead of 202 entries)
- Smaller, denser table → better cache utilization
- gperf finds better perfect hashes with fewer keywords

**Cons:**
- Prefix check (`if len > 5 && str[0] == 'b' && ...`) is a branch taken ~50% of the
  time — worst case for prediction, and exactly the kind of branch the cmov/csel
  optimization eliminates
- Non-matching `bake_*` inputs (like `bake_xyzzy`) might need two lookups
- Added complexity in the caller

**Better alternative:** Keep a single table. Tag the `runtime_func` enum values with a
bit flag indicating "this is a bake variant." After lookup, extract it with a mask — that's
free at the integer level and keeps the hot path simple:

```cpp
enum class runtime_func : uint16_t {
    identifier = 0,

    // Non-bake functions: values 1..200
    fn_add = 1,
    fn_sub = 2,
    // ...

    // Bake functions: set bit 15 as a flag
    fn_bake_add = 0x8001,  // fn_add | 0x8000
    fn_bake_sub = 0x8002,  // fn_sub | 0x8000
    // ...
};

// After lookup:
bool is_bake = (static_cast<uint16_t>(result) & 0x8000) != 0;
runtime_func base_func = static_cast<runtime_func>(
    static_cast<uint16_t>(result) & 0x7FFF);
```

---

## Reduction Method: `vmaxvq_u8` vs Lane Extract

Bear's code uses `vmaxvq_u8` (UMAXV instruction) to reduce the 16-byte difference
vector to a scalar. Strager's code uses `vgetq_lane_s64(compared, 0) | vgetq_lane_s64(compared, 1)`.

Both produce zero iff the masked diff is all zeros. Performance varies by core:

| Method | Apple Silicon (M1+) | Cortex-A76+ | Cortex-A53/A55 |
|--------|--------------------|-----------|----|
| `vmaxvq_u8` (UMAXV) | ~1 cycle | ~3 cycles | ~5 cycles |
| Lane extract + OR | ~2 cycles | ~2 cycles | ~2 cycles |

**Recommendation:** Benchmark on your target. If primarily Apple Silicon, `vmaxvq_u8` is
fine. If targeting a range of ARM cores, lane extract + OR is safer.

---

## Summary of Recommended Path for Bake

1. **Use two-load NEON** for full 32-byte coverage (handles all 202 keywords uniformly)
2. **Keep csel for branchless results** (you're already doing this correctly)
3. **Consider `keyword-size-in-entry`** to replace the variable-offset null terminator
   check with a fixed-offset integer compare
4. **Consider `no-early-bounds-check`** if your input buffers are safely over-readable
5. **For non-SIMD fallback**, use `chunk888` (three 64-bit loads + masks + XOR + OR)
6. **Don't split on `bake_` prefix** — use enum bit-tagging instead for the bake/non-bake
   distinction
7. **Benchmark `vmaxvq_u8` vs lane-extract-OR** on your actual target hardware
