"""Generate a perfect hash lookup function via gperf."""

from typing import TYPE_CHECKING

from ._strings import (
    CB,
    OB,
    compare_check1memcmp,
    compare_memcmp,
    compare_neon,
    compare_neon_padded,
    compare_neon_strcmp,
    compare_neon_xor,
    comparison_return,
    entry_lookup,
    footer,
    get_header,
    hash_section,
    max_hash_check,
    saturate_hash_check,
    tables_section,
)
from .helpers import (
    Buffer,
    GPerfTables,
    SortedKeywords,
    call_clang_format,
    call_gperf,
    find_best_jump,
    generate_gperf_input,
    keywords_as_enum,
    keywords_as_struct_input,
    pad_size,
    read_plain_keywords,
)

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from . import Arguments

COMPARE_EMITTERS: dict[str, Callable] = {
    "memcmp": lambda a: compare_memcmp(),
    "check1memcmp": lambda a: compare_check1memcmp(a),
    "neon": lambda a: compare_neon(a, a.cmov),
    "neon_xor": lambda a: compare_neon_xor(a, a.cmov),
    "neon_strcmp": lambda a: compare_neon_strcmp(a, a.cmov),
    "neon_padded": lambda a: compare_neon_padded(a, a.cmov),
}

BRANCH_RETURNS: frozenset[str] = frozenset({"memcmp", "check1memcmp"})
NEEDS_PADDED: frozenset[str] = frozenset({"neon_padded"})


def _generate_type_header(
    a: Arguments,
    enum_values: list[str],
    struct_entries: list[str],
    sorted_kw: SortedKeywords,
) -> str:
    """Generate the type definition .hpp file (enum, macro table, struct, function decl)."""
    buf = Buffer()
    buf.write_raw("#pragma once")
    buf.nl()
    buf.write_raw("#include <cstdint>")
    buf.write_raw("#include <string_view>")
    buf.nl()

    with buf.block(f"namespace {a.namespace} {OB}"):
        buf.write(f"constexpr int padding_bytes = {pad_size(sorted_kw.max_len)};")
        buf.nl()

        # enum
        with buf.block(f"enum class {a.enum_name} : uint8_t {OB}", f"{CB};"):
            for val in enum_values:
                buf.write(f"{val},")
            buf.nl()
            buf.write(f"{a.default_return},")
        buf.nl()

        macro_name = f"PHT_{a.enum_name.upper()}_TABLE"
        buf.write(f"#define {macro_name}{' ' * max(1, 60 - len(macro_name) - 8)}\\")
        for entry in struct_entries:
            buf.write_raw(entry)
        buf.nl()

        # func_token struct + constexpr array
        with buf.block(f"struct {a.struct_name}_token {OB}", f"{CB};"):
            buf.write("std::string_view str;")
            buf.write(f"{a.enum_name} value;")
        buf.nl()
        buf.write(f"constexpr {a.struct_name}_token {a.struct_name}_tokens[] = {OB}")
        buf.write(f"    {macro_name}")
        buf.write(f"{CB};")
        buf.nl()

        # function declaration
        buf.write(f"typedef {a.enum_name} look_up_identifier_f(const char* identifier, std::size_t size) noexcept;")
        buf.nl()
        buf.write_raw('extern "C"')
        buf.write_raw('__attribute__((visibility("default")))')
        buf.write("look_up_identifier_f look_up_identifier;")

    buf.nl()
    buf.nl()

    return buf.join() + "\n"


def gperf_output(a: Arguments) -> None:
    """Generate gperf-based lookup from pre-parsed arguments."""
    sorted_kw: SortedKeywords = read_plain_keywords(a)

    enum_values: list[str] = keywords_as_enum(sorted_kw, prefix=a.prefix)
    struct_entries: list[str] = keywords_as_struct_input(sorted_kw, prefix=a.prefix, enum_name=a.enum_name)
    type_header: str = _generate_type_header(a, enum_values, struct_entries, sorted_kw)
    if a.output_enabled:
        type_path: Path = a.output.parent / a.include_name
        type_path.write_text(type_header)
        call_clang_format(type_path)

    gperf_path: Path = generate_gperf_input(
        keywords=sorted_kw,
        enum_name=a.enum_name,
        struct_name=a.struct_name,
        prefix=a.prefix,
        default_return=a.default_return,
        include_name=a.include_name,
        namespace=a.namespace,
    )
    try:
        jump: int = find_best_jump(gperf_path) if a.best_jump else a.jump
        tables: GPerfTables = call_gperf(gperf_path, jump)
    finally:
        gperf_path.unlink(missing_ok=True)

    out = Buffer()

    out.write(get_header(a))

    for name, value in tables.constants.items():
        out.write(f"constexpr int {name} = {value};")

    padded: bool = a.padded or a.string_compare in NEEDS_PADDED
    pad: int = pad_size(sorted_kw.max_len) if padded else 0

    out.nl()
    out.write(tables_section(tables, a, pad_to=pad))

    out.write(hash_section(tables, a))
    out.write(saturate_hash_check() if a.saturate_hash else max_hash_check(a))
    out.nl()
    out.write(entry_lookup(a))
    out.nl()

    out.write(COMPARE_EMITTERS[a.string_compare](a))

    needs_branch_return = not a.cmov or a.string_compare in BRANCH_RETURNS
    if needs_branch_return:
        out.write(comparison_return(a))

    out.write(footer())
    output = out.join()
    if a.stdout:
        print(output)
    if a.output_enabled:
        a.output.write_text(output)
        call_clang_format(a.output)
