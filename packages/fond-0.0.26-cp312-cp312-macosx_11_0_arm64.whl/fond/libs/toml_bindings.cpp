/*
 * pybind11 bindings for Fond's TOML reader/writer.
 * Uses Fond's generic py_convert for Python ↔ C++ value conversion.
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "fond/toml/reader.hpp"
#include "fond/toml/writer.hpp"
#include "fond/toml/py_traits.hpp" // IWYU pragma: keep

namespace py = pybind11;

using namespace Fond::Toml;
using Fond::PyTools::to_py;
using Fond::PyTools::from_py;

static py::object loads(const std::string& source) {
    Reader reader;
    return to_py<TomlValue>(reader.parse(source));
}

static py::object load(const std::string& filepath) {
    Reader reader;
    return to_py<TomlValue>(reader.parse_file(filepath));
}

static std::string dumps(const py::object& obj) {
    return Writer::dumps(from_py<TomlValue>(obj));
}

static void dump(const py::object& obj, const std::string& filepath) {
    Writer::dump(filepath, from_py<TomlValue>(obj));
}

PYBIND11_MODULE(toml_bindings, m) {
    m.doc() = "Fast TOML reader and writer implemented in C++";
    m.def("loads", &loads, "Parse a TOML string and return a Python dict.", py::arg("source"));
    m.def("load", &load, "Parse a TOML file and return a Python dict.", py::arg("filepath"));
    m.def("dumps", &dumps, "Serialize a Python dict to a TOML string.", py::arg("obj"));
    m.def("dump", &dump, "Serialize a Python dict and write to a file.",
          py::arg("obj"), py::arg("filepath"));
}
