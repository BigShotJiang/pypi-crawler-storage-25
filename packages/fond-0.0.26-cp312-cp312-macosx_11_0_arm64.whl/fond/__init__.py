"""Fond Package."""

from os import walk
from pathlib import Path

from fond._internal.cli import main
from fond._internal.info import METADATA

__version__: str = METADATA.version

_PACKAGE_DIR: Path = Path(__file__).parent
_INCLUDE_PATH: Path = _PACKAGE_DIR / "include"
_LIBS_PATH: Path = _PACKAGE_DIR / "libs"


def get_include() -> list[str]:
    """Return path to the C++ header files directory.

    Usage in build systems:
        include_dirs = [fond.get_include(str)]

    Or with compiler flags:
        -I$(python -c "import fond; print(fond.get_include(str))")

    Returns:
        A list of paths to the include directories for the C++ headers.
    """
    return [str(_INCLUDE_PATH.resolve())]


def get_include_paths() -> list[Path]:
    """Return path to the C++ header files directory."""
    return [_INCLUDE_PATH.resolve()]


def get_libs() -> list[str]:
    """Return path to the C++ library files directory."""
    libs: list[str] = []
    for dirpath, _, filenames in walk(_LIBS_PATH):
        for filename in filenames:
            if filename.endswith(".so"):
                libs.append(str(Path(dirpath) / filename))
    return libs


def get_libs_paths() -> list[Path]:
    """Return path to the C++ library files directory."""
    libs: list[Path] = []
    for dirpath, _, filenames in walk(_LIBS_PATH):
        for filename in filenames:
            if filename.endswith(".so"):
                libs.append(Path(dirpath) / filename)
    return libs


__all__: list[str] = [
    "METADATA",
    "__version__",
    "get_include",
    "get_include_paths",
    "get_libs",
    "get_libs_paths",
    "main",
]
