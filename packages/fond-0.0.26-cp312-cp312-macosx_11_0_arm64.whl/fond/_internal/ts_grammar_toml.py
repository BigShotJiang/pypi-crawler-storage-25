"""TOML Grammar for Tree-sitter.

Defines the TOML grammar using the Fond Pydantic DSL.
Export to JSON with: python -c "from ts_grammar_toml import grammar; print(grammar.model_dump_json(indent=2))" > grammar.json
Then: tree-sitter generate
"""

from fond.ts_grammar_rules import (
    ExternalSymbol,
    GrammarRoot,
    Rules,
    alias,
    choice,
    field,
    immediate,
    optional,
    pat,
    repeat,
    repeat1,
    seq,
    string,
    sym,
    token,
)

# Regex patterns ported from the JS grammar
NEWLINE = r"\r?\n"
BARE_KEY = r"[A-Za-z0-9_-]+"
ESCAPE_SEQUENCE = r"\\([btnfr\"\\]|u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8})"
ESCAPE_LINE_ENDING = r"\\\r?\n"

DECIMAL_INTEGER = r"[+-]?(0|[1-9](_?[0-9])*)"
DECIMAL_INTEGER_FLOAT_EXP = r"[+-]?[0-9](_?[0-9])*"
HEX_INTEGER = r"0x[0-9a-fA-F](_?[0-9a-fA-F])*"
OCTAL_INTEGER = r"0o[0-7](_?[0-7])*"
BINARY_INTEGER = r"0b[01](_?[01])*"
FLOAT_FRAC = r"[.][0-9](_?[0-9])*"
FLOAT_SPECIAL = r"[+-]?(inf|nan)"
BOOLEAN = r"true|false"

RFC3339_DATE = r"([0-9]+)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])"
RFC3339_DELIM = r"[ tT]"
RFC3339_TIME = r"([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]|60)([.][0-9]+)?"
RFC3339_OFFSET = r"([zZ])|([+-]([01][0-9]|2[0-3]):[0-5][0-9])"

# Characters allowed in basic strings (inverse of control chars minus tab, plus " and \)
BASIC_STRING_CHAR = r"[^\x00-\x08\x0a-\x1f\x7f\"\\]+"
# Characters allowed in literal strings (inverse of control chars minus tab, plus ')
LITERAL_STRING_CHAR = r"[^\x00-\x08\x0a-\x1f\x7f']+"
COMMENT_CHAR = r"[^\x00-\x08\x0a-\x1f\x7f]*"

grammar = GrammarRoot(
    name="toml",
    rules=Rules(
        {
            # ── Document ──────────────────────────────────────────
            "document": seq(
                repeat(choice(sym("pair"), pat(NEWLINE))),
                repeat(choice(sym("table"), sym("table_array_element"))),
            ),
            # ── Comment ───────────────────────────────────────────
            "comment": token(seq(string("#"), pat(COMMENT_CHAR))),
            # ── Table [key] ───────────────────────────────────────
            "table": seq(
                string("["),
                field("name", choice(sym("dotted_key"), sym("_key"))),
                string("]"),
                sym("_line_ending_or_eof"),
                repeat(choice(sym("pair"), pat(NEWLINE))),
            ),
            # ── Table Array [[key]] ───────────────────────────────
            "table_array_element": seq(
                string("[["),
                field("name", choice(sym("dotted_key"), sym("_key"))),
                string("]]"),
                sym("_line_ending_or_eof"),
                repeat(choice(sym("pair"), pat(NEWLINE))),
            ),
            # ── Key = Value pair ──────────────────────────────────
            "pair": seq(sym("_inline_pair"), sym("_line_ending_or_eof")),
            "_inline_pair": seq(
                field("key", choice(sym("dotted_key"), sym("_key"))),
                string("="),
                field("value", sym("_inline_value")),
            ),
            # ── Keys ──────────────────────────────────────────────
            "_key": choice(sym("bare_key"), sym("quoted_key")),
            "dotted_key": seq(
                choice(sym("dotted_key"), sym("_key")),
                string("."),
                sym("_key"),
            ),
            "bare_key": pat(BARE_KEY),
            "quoted_key": choice(sym("_basic_string"), sym("_literal_string")),
            # ── Values ────────────────────────────────────────────
            "_inline_value": choice(
                sym("string"),
                sym("integer"),
                sym("float"),
                sym("boolean"),
                sym("offset_date_time"),
                sym("local_date_time"),
                sym("local_date"),
                sym("local_time"),
                sym("array"),
                sym("inline_table"),
            ),
            # ── String types ──────────────────────────────────────
            "string": choice(
                sym("_basic_string"),
                sym("_multiline_basic_string"),
                sym("_literal_string"),
                sym("_multiline_literal_string"),
            ),
            "_basic_string": seq(
                string('"'),
                repeat(
                    choice(
                        immediate(repeat1(pat(BASIC_STRING_CHAR))),
                        sym("escape_sequence"),
                    )
                ),
                immediate(string('"')),
            ),
            "_multiline_basic_string": seq(
                string('"""'),
                repeat(
                    choice(
                        immediate(repeat1(pat(BASIC_STRING_CHAR))),
                        sym("_multiline_basic_string_content"),
                        immediate(pat(NEWLINE)),
                        sym("escape_sequence"),
                        alias(sym("_escape_line_ending"), "escape_sequence", named=True),
                    )
                ),
                sym("_multiline_basic_string_end"),
            ),
            "escape_sequence": immediate(pat(ESCAPE_SEQUENCE)),
            "_escape_line_ending": immediate(seq(pat(r"\\"), pat(NEWLINE))),
            "_literal_string": seq(
                string("'"),
                optional(immediate(repeat1(pat(LITERAL_STRING_CHAR)))),
                immediate(string("'")),
            ),
            "_multiline_literal_string": seq(
                string("'''"),
                repeat(
                    choice(
                        immediate(repeat1(pat(LITERAL_STRING_CHAR))),
                        sym("_multiline_literal_string_content"),
                        immediate(pat(NEWLINE)),
                    )
                ),
                sym("_multiline_literal_string_end"),
            ),
            # ── Numbers ───────────────────────────────────────────
            "integer": choice(
                pat(DECIMAL_INTEGER),
                pat(HEX_INTEGER),
                pat(OCTAL_INTEGER),
                pat(BINARY_INTEGER),
            ),
            "float": choice(
                token(
                    seq(
                        pat(DECIMAL_INTEGER),
                        choice(
                            pat(FLOAT_FRAC),
                            seq(optional(pat(FLOAT_FRAC)), seq(pat(r"[eE]"), pat(DECIMAL_INTEGER_FLOAT_EXP))),
                        ),
                    )
                ),
                pat(FLOAT_SPECIAL),
            ),
            # ── Boolean ───────────────────────────────────────────
            "boolean": pat(BOOLEAN),
            # ── DateTime types ────────────────────────────────────
            "offset_date_time": token(
                seq(
                    pat(RFC3339_DATE),
                    pat(RFC3339_DELIM),
                    pat(RFC3339_TIME),
                    pat(RFC3339_OFFSET),
                )
            ),
            "local_date_time": token(
                seq(
                    pat(RFC3339_DATE),
                    pat(RFC3339_DELIM),
                    pat(RFC3339_TIME),
                )
            ),
            "local_date": pat(RFC3339_DATE),
            "local_time": pat(RFC3339_TIME),
            # ── Array ─────────────────────────────────────────────
            "array": seq(
                string("["),
                repeat(pat(NEWLINE)),
                optional(
                    seq(
                        field("element", sym("_inline_value")),
                        repeat(pat(NEWLINE)),
                        repeat(
                            seq(
                                string(","),
                                repeat(pat(NEWLINE)),
                                field("element", sym("_inline_value")),
                                repeat(pat(NEWLINE)),
                            )
                        ),
                        optional(seq(string(","), repeat(pat(NEWLINE)))),
                    )
                ),
                string("]"),
            ),
            # ── Inline Table ─────────────────────────────────────
            "inline_table": seq(
                string("{"),
                optional(
                    seq(
                        alias(sym("_inline_pair"), "pair", named=True),
                        repeat(
                            seq(
                                string(","),
                                alias(sym("_inline_pair"), "pair", named=True),
                            )
                        ),
                    )
                ),
                string("}"),
            ),
        }
    ),
    extras=[pat(r"[ \t]"), sym("comment")],
    externals=[
        ExternalSymbol(type="SYMBOL", name="_line_ending_or_eof"),
        ExternalSymbol(type="SYMBOL", name="_multiline_basic_string_content"),
        ExternalSymbol(type="SYMBOL", name="_multiline_basic_string_end"),
        ExternalSymbol(type="SYMBOL", name="_multiline_literal_string_content"),
        ExternalSymbol(type="SYMBOL", name="_multiline_literal_string_end"),
    ],
    inline=["_key", "_inline_value"],
)

if __name__ == "__main__":
    print(grammar.model_dump_json(indent=2))
