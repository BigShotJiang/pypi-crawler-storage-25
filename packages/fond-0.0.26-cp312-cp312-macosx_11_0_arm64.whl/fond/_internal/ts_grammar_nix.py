"""Nix Grammar for Tree-sitter (data subset).

Defines a restricted Nix grammar using the Fond Pydantic DSL — covers data
structures only: attrsets (nested + dotted paths), strings, integers, floats,
booleans, null, and lists. Expressions, functions, string interpolation, and
let/rec/with/inherit are intentionally unsupported and will produce syntax
errors.

Export to JSON with: `gen-nix-ts-js stdout > src/tree_sitter.json`
Then: `tree-sitter generate`
"""

from fond.ts_grammar_rules import GrammarRoot, Rules, choice, field, pat, repeat, seq, string, sym, token

IDENTIFIER = r"[A-Za-z_][A-Za-z0-9_'-]*"
INTEGER = r"[+-]?[0-9]+"
FLOAT = r"[+-]?(([1-9][0-9]*\.[0-9]*)|(0?\.[0-9]+))([Ee][+-]?[0-9]+)?"
STRING_CHAR = r"[^\"\\]+"
ESCAPE_SEQUENCE = r"\\."
COMMENT = r"#[^\n]*|/\*[^*]*\*+([^/*][^*]*\*+)*/"

grammar = GrammarRoot(
    name="nix",
    rules=Rules(
        {
            # ── Document ──────────────────────────────────────────
            # A nix data document is a single value (almost always an attrset).
            "document": field("value", sym("_value")),
            # ── Values ────────────────────────────────────────────
            "_value": choice(
                sym("attrset"),
                sym("list"),
                sym("string"),
                sym("integer"),
                sym("float"),
                sym("boolean"),
                sym("null"),
            ),
            # ── Attrset { ... } ───────────────────────────────────
            "attrset": seq(
                string("{"),
                repeat(sym("binding")),
                string("}"),
            ),
            # ── Binding: attr_path = value; ───────────────────────
            "binding": seq(
                field("path", sym("attr_path")),
                string("="),
                field("value", sym("_value")),
                string(";"),
            ),
            # ── Attribute paths (dotted or single identifier) ─────
            "attr_path": seq(
                sym("identifier"),
                repeat(seq(string("."), sym("identifier"))),
            ),
            "identifier": pat(IDENTIFIER),
            # ── List [ v v v ] (whitespace-separated, nix-style) ──
            "list": seq(
                string("["),
                repeat(field("element", sym("_value"))),
                string("]"),
            ),
            # ── String "..." (no interpolation) ───────────────────
            "string": seq(
                string('"'),
                repeat(choice(pat(STRING_CHAR), sym("escape_sequence"))),
                string('"'),
            ),
            "escape_sequence": token(pat(ESCAPE_SEQUENCE)),
            # ── Numbers ───────────────────────────────────────────
            "integer": pat(INTEGER),
            "float": token(pat(FLOAT)),
            # ── Boolean / null ────────────────────────────────────
            "boolean": choice(string("true"), string("false")),
            "null": string("null"),
            # ── Comment ───────────────────────────────────────────
            "comment": token(pat(COMMENT)),
        }
    ),
    extras=[pat(r"\s"), sym("comment")],
    inline=["_value"],
)

if __name__ == "__main__":
    print(grammar.model_dump_json(indent=2))
