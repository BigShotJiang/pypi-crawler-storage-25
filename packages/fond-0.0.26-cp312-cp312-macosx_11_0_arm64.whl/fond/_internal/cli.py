from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from .info import ExitCode


def main(args: list[str] | None = None) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `fond` or `python -m fond`.

    If none is passed into main, it is converted to sys.argv[1:] by the args_inject decorator and
    then passed through to get_args to be parsed.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    if args is None:
        args = sys.argv[1:]

    from ._cmds import _ReturnedArgs, get_args
    from .info import ExitCode

    paths: list[Path]
    parsed_args: _ReturnedArgs = get_args(args)

    try:
        match parsed_args.cmd:
            case "includes":
                from fond import get_include_paths

                temp: str = ""
                paths = get_include_paths()
                for include in paths:
                    i: Path = include.resolve()
                    temp += f"-I{i} "
                print(temp)
                return ExitCode.SUCCESS
            case "libs":
                from fond import get_libs_paths

                temp = ""
                paths = get_libs_paths()
                for lib in paths:
                    li: Path = lib.resolve()
                    temp += f"-L{li.parent} -l{li.stem} "
                print(temp)
                return ExitCode.SUCCESS
            case "toml_so":
                from fond import get_libs_paths

                paths = get_libs_paths()
                for lib in paths:
                    li: Path = lib.resolve()
                    if li.name.startswith("toml_parser"):
                        temp = str(li)
                        print(temp)
                        break
                return ExitCode.SUCCESS
            case "nix":
                from ._cmds import dump_nix_grammar_json

                return dump_nix_grammar_json(parsed_args)
            case "toml":
                from ._cmds import dump_toml_grammar_json

                return dump_toml_grammar_json(parsed_args)
            case "version":
                from ._cmds import get_version

                return get_version(version_name=parsed_args.version_name)
            case "bump":
                from ._cmds import bump_version

                return bump_version(b=parsed_args.bump_type)
            case "debug":
                from ._cmds import debug_info

                return debug_info(no_color=parsed_args.no_color)

            case _:
                return ExitCode.FAILURE
    except Exception:
        return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

# ruff: noqa: PLC0415
