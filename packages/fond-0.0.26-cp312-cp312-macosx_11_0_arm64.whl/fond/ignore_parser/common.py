"""Schemas for file operations."""

from __future__ import annotations

from bisect import insort
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self

from pathspec import PathSpec
from pydantic import field_validator

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator

IGNORE_PATTERNS: frozenset[str] = frozenset(
    {
        "**/__pycache__",
        ".git",
        "**/.venv",
        ".env",
        ".vscode",
        ".idea",
        "*.DS_Store*",
        "__pypackages__",
        ".pytest_cache",
        ".coverage",
        ".*.swp",
        ".*.swo",
        "*.lock",
        "dist/",
        "**/.nox",
        "**/.pytest_cache",
        "**/.ruff_cache",
    }
)


def key_by(x: PathObject, key: str = "modified") -> int:
    """Key function to sort PathObjects by modified time.

    Args:
        x: The PathObject to extract the key from
        key: The attribute name to use as the key (default is "modified")
    """
    return getattr(x, key)


class SortedList[T]:
    """A sorted list that maintains order based on a key function."""

    def __init__(
        self,
        iterable: Iterable[T] | None = None,
        key: Callable[[T], Any] = lambda x: x,
        reverse: bool = False,
    ) -> None:
        """A sorted list that maintains order based on a key function."""
        self._key: Callable[[T], Any] = key
        self._reverse: bool = reverse
        self._members: set[T] = set()
        self._sorted: list[T] = []
        if iterable is not None:
            self.extend(iterable)

    def add(self, item: T) -> None:
        """Add an item to the sorted list if it's not already present."""
        if item in self._members:
            return
        self._members.add(item)
        insort(self._sorted, item, key=self._key)

    def extend(self, items: Iterable[T]) -> None:
        """Extend the sorted list with multiple items."""
        self._sorted.extend(item for item in items if item not in self._members)
        self._members.update(items)
        self._sorted.sort(key=self._key, reverse=self._reverse)

    def remove(self, item: T) -> None:
        """Remove an item from the sorted list."""
        if item in self._members:
            self._members.remove(item)
            self._sorted.remove(item)

    def clear(self) -> None:
        """Clear all items from the sorted list."""
        self._members.clear()
        self._sorted.clear()

    @property
    def empty(self) -> bool:
        """Check if the sorted list is empty."""
        return len(self._sorted) == 0

    @property
    def head(self) -> T | None:
        """Get the first item in the sorted list, or None if it's empty."""
        return self._sorted[0] if self._sorted else None

    @property
    def tail(self) -> T | None:
        """Get the last item in the sorted list, or None if it's empty."""
        return self._sorted[-1] if self._sorted else None

    def get(self) -> list[T]:
        """Get a list of all items in the sorted list."""
        return self._sorted

    def __len__(self) -> int:
        """Get the number of items in the sorted list."""
        return len(self._sorted)

    def __bool__(self) -> bool:
        """Check if the sorted list is not empty."""
        return bool(self._sorted)

    def __iter__(self) -> Iterator[T]:
        """Iterate over the items in the sorted list."""
        yield from self._sorted

    def __next__(self) -> T:
        """Get the next item in the sorted list."""
        return next(self.__iter__())

    def __getitem__(self, index: int) -> T:
        """Get an item by index."""
        return self._sorted[index]

    def __delitem__(self, index: int) -> None:
        """Delete an item by index."""
        raise NotImplementedError("Direct item deletion is not supported in SortedList. Use remove() instead.")

    def __setitem__(self, index: int, value: T) -> None:
        """Set an item at a specific index, maintaining sorted order."""
        raise NotImplementedError(
            "Direct item assignment is not supported in SortedList. Use add() or extend() instead."
        )

    def __contains__(self, item: T) -> bool:
        """Check if an item is in the sorted list."""
        return item in self._members


def create_spec(patterns: SortedList[str] | list[str]) -> PathSpec:
    """Create a pathspec from the given patterns.

    Args:
        patterns: List of ignore patterns

    Returns:
        A pathspec object
    """
    if isinstance(patterns, SortedList):
        patterns = patterns._sorted
    return PathSpec.from_lines("gitwildmatch", patterns)


def file_to_patterns(gitignore_path: Path | str) -> list[str]:
    """Read a .gitignore file and return its patterns as a list.

    Args:
        gitignore_path: Path to the .gitignore file
    Returns:
        A list of patterns from the .gitignore file
    """
    path = Path(gitignore_path)
    if not path.exists() or not path.is_file():
        return []
    try:
        lines: list[str] = path.read_text().splitlines()
    except FileNotFoundError, OSError:  # 3.14 has this as valid syntax
        return []
    return [
        line.strip()
        for line in lines
        if line.strip() and not line.strip().startswith("#") and not line.strip().startswith("!") and line
    ]


CONFIG_FIELDS: frozenset[str] = frozenset(
    {
        "directory",
        "verbose",
        "ignore_count",
        "ignore_files",
        "patterns",
        "output_as_absolute",
    }
)


@dataclass(slots=True)
class IgnoreConfig:
    """Configuration for the IgnoreHandler."""

    directory: Path = field(default_factory=Path.cwd)
    verbose: bool = False
    ignore_count: int = 100
    ignore_files: Iterable[Path] = field(default_factory=list)
    patterns: Iterable[str] = field(default_factory=list)
    output_as_absolute: bool = False
    extensions: set[str] = field(default_factory=set)

    def __post_init__(self) -> None:
        """Post-initialization to set default patterns if none are provided."""
        self.patterns = [*IGNORE_PATTERNS, *self.patterns]
        if self.ignore_files is None:
            self.ignore_files = [self.directory / ".gitignore"]

    @field_validator("directory", mode="before")
    @classmethod
    def force_path(cls, v: Path | str) -> Path:
        """Ensure the directory is a Path object."""
        return Path(v).expanduser().resolve()

    def update(self, **kwargs) -> Self:
        """Update the configuration with new values."""
        for key, value in kwargs.items():
            if key in CONFIG_FIELDS:
                setattr(self, key, value)
        return self


@dataclass(slots=True)
class PathObject:
    """Container for a path, a string representation, and an ignore status."""

    _path: Path
    str_path: str = field(init=False)
    created: int = 0
    modified: int = 0
    ignored: bool = False

    @property
    def path(self) -> Path:
        """Get the Path object."""
        return self._path

    def __hash__(self) -> int:
        """Hash the PathObject based on its path."""
        return hash((self._path, self.created, self.modified))

    def __post_init__(self) -> None:
        self.str_path = str(self.path)
        self.created = int(self._path.stat().st_ctime) if self._path.exists() else 0
        self.modified = int(self._path.stat().st_mtime) if self._path.exists() else 0


@dataclass(slots=True)
class PathsContainer:
    """Container for multiple PathContainer objects."""

    root: Path = Path(".")
    sort_by: str = "modified"
    non_ignored: SortedList[PathObject] = field(init=False)
    output_as_absolute: bool = False

    def __post_init__(self) -> None:
        self.non_ignored = SortedList(key=lambda obj: key_by(obj, self.sort_by), reverse=True)

    @property
    def count(self) -> int:
        """Number of files that were processed."""
        return len(self.non_ignored)

    @property
    def non_ignored_paths(self) -> list[Path]:
        """List of non-ignored file paths."""
        if self.output_as_absolute:
            return [self.root / obj.path for obj in self.non_ignored]
        return [obj.path for obj in self.non_ignored]

    @property
    def non_ignored_str_paths(self) -> set[str]:
        """Set of non-ignored file paths as strings."""
        if self.output_as_absolute:
            return {str(self.root / obj.path) for obj in self.non_ignored}
        return {obj.str_path for obj in self.non_ignored}

    @property
    def first_created(self) -> PathObject | None:
        """Get the first created PathObject, or None if there are no files."""
        if not self.non_ignored:
            return None
        return min(self.non_ignored, key=lambda obj: obj.created)

    @property
    def last_modified(self) -> PathObject | None:
        """Get the last modified PathObject, or None if there are no files."""
        if not self.non_ignored:
            return None
        return max(self.non_ignored, key=lambda obj: obj.modified)

    @classmethod
    def create(
        cls, directory: Path | str, spec: PathSpec, absolute: bool, exts: set[str], sort_by: str = "modified"
    ) -> PathsContainer:
        """Create a PathsContainer from a directory and a PathSpec."""
        new: Self = cls(output_as_absolute=absolute, sort_by=sort_by)
        new.root = Path(directory).expanduser().resolve()
        for root, dirs, files in new.root.walk():
            for filename in files:
                path: Path = Path(root) / filename
                if path.suffix not in exts:
                    continue
                obj: PathObject = path_parser(path, new, spec)
                if not obj.ignored:
                    new.non_ignored.add(obj)
            for dirname in list(dirs):
                dir_path: Path = Path(root) / dirname
                rel_dir: Path = dir_path.relative_to(new.root)
                is_dir_ignored: bool = spec.match_file(str(rel_dir) + "/")
                if is_dir_ignored:
                    dirs.remove(dirname)
                else:
                    new.non_ignored.add(PathObject(rel_dir))
        return new


def path_parser(path: Path, cls: PathsContainer, spec: PathSpec) -> PathObject:
    """We will need to run this through the threadpool so we need individual tasks.

    Args:
        path: The file or directory to parse, passed in via threadpool
        cls: The PathsContainer class
        spec: The PathSpec object for ignore patterns
    """
    rel_path: Path = path.relative_to(cls.root)
    obj = PathObject(rel_path)
    obj.ignored = spec.match_file(obj.str_path)
    return obj
