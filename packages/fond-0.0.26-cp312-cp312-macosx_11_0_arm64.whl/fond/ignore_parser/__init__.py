"""A module for file handling utilities in Bear Utils."""

from .common import IGNORE_PATTERNS, create_spec, file_to_patterns
from .ignore_parser import IgnoreHandler

__all__ = ["IGNORE_PATTERNS", "IgnoreHandler", "create_spec", "file_to_patterns"]
