"""A module for handling file ignore patterns and directories in Bear Utils."""

from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING

from fond.ignore_parser.base_class import BaseIgnoreHandler
from fond.ignore_parser.common import IgnoreConfig, PathsContainer

if TYPE_CHECKING:
    from pathspec import PathSpec

EMPTY_LIST = ()


class IgnoreHandler:
    """Handles the logic for ignoring files and directories based on .gitignore-style rules."""

    def __init__(
        self,
        path: Path | str,
        ignore_files: list[Path] | None = None,
        patterns: list[str] | None = None,
        verbose: bool = False,
        scan: bool = False,
        output_as_absolute: bool = False,
        exts: list[str] | tuple[str, ...] | set[str] = EMPTY_LIST,
    ) -> None:
        """Initialize the IgnoreHandler with a directory to search and an optional ignore file.

        Args:
            path: The directory to search
            ignore_file: An optional path to a .gitignore-style file
            scan: Whether to immediately scan the directory upon initialization
        """
        if not isinstance(exts, set):
            exts = set(exts)
        config = IgnoreConfig(
            directory=Path(path),
            verbose=verbose,
            ignore_files=ignore_files or EMPTY_LIST,
            patterns=patterns or EMPTY_LIST,
            output_as_absolute=output_as_absolute,
            extensions=exts,
        )
        self.ih: BaseIgnoreHandler = BaseIgnoreHandler(config=config)
        self.path: Path = Path(path)
        self._files: PathsContainer | None = self.scan_codebase() if scan else None

    @property
    def spec(self) -> PathSpec:
        """Get the current PathSpec object."""
        return self.ih.spec

    @property
    def files(self) -> PathsContainer:
        """Get the PathsContainer object, creating it if it doesn't exist."""
        if self._files is None:
            self._files = PathsContainer.create(
                self.path,
                self.spec,
                self.ih.output_as_absolute,
                self.ih.config.extensions,
            )
        return self._files

    @cached_property
    def non_ignored(self) -> list[Path]:
        """Get a list of non-ignored files.

        Returns:
            List of non-ignored files as Path objects
        """
        return self.files.non_ignored_paths

    def add_pattern(self, pattern: str) -> None:
        """Add a single ignore pattern and update the spec.

        Args:
            pattern: The pattern to add
        """
        self.ih.add_pattern(pattern)
        self._files = None  # Invalidate cached files

    def scan_codebase(self) -> PathsContainer:
        """Generate a report of ignored and non-ignored files in the directory.

        Returns:
            PathsContainer: A container with details about ignored and non-ignored files
        """
        return self.files

    def spot_check(self, path: Path | str) -> bool:
        """Check if a specific path is ignored.

        If you only need to check a few paths, use this method.

        Args:
            path: The path to check
        Returns:
            True if the path is ignored, False otherwise
        """
        return self.spec.match_file(str(path))

    def should_ignore(self, path: Path | str) -> bool:
        """Check if a specific path is ignored.

        You should use this if you intend to check multiple paths, as it uses cached results.

        Args:
            path: The path to check
        Returns:
            True if the path is ignored, False otherwise
        """
        return str(path) not in self.files.non_ignored_str_paths  # fast set lookup
