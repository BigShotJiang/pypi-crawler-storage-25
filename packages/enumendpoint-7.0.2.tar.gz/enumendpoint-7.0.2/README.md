# Website Endpoint Scanner and Rate Limit Tester For Websites (DEPRECATED)

Enumendpoint has been deprecated.
For future updates on the tool, move to endpointscanner.

Link:
https://pypi.org/project/endpointscanner/
