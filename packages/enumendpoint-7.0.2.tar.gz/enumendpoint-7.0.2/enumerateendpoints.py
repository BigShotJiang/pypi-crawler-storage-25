def main(*args, **kwargs):
    print("EnumEndpoint has been retired. It will not receive any further updates, and has been migrated to endpointscanner.\nPlease install endpointscanner to receive the latest updates on this tool.")

if __name__ == '__main__':
    main()