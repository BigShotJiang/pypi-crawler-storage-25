"""AutoResearchGym: Can AI Agents Automate AI Research? — placeholder package, code coming soon."""
__version__ = "0.0.1"
