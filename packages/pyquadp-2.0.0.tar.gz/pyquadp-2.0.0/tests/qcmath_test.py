# SPDX-License-Identifier: GPL-2.0+

import cmath
import decimal
import math
import os
import sys
from pprint import pprint

import numpy as np
import pytest
import scipy.special
from hypothesis import assume, given
from hypothesis.strategies import complex_numbers, floats

import pyquadp.qcmath as qcm
import pyquadp.qmath as qm


class TestQCMathFloat:
    @given(complex_numbers(min_magnitude=0, max_magnitude=1e100))
    def test_cabs(self, x):
        assert float(qcm.cabsq(x)) == pytest.approx(abs(x), nan_ok=True)

    @given(
        floats(min_value=1e-10, max_value=1e300),
        floats(min_value=1e-10, max_value=1e300),
    )
    def test_cargq(self, x, y):
        c = complex(x, y)
        assert float(qcm.cargq(c)) == pytest.approx(cmath.phase(c), nan_ok=True)

    @given(complex_numbers(allow_infinity=False, allow_nan=False))
    def test_cimagq(self, x):
        assert float(qcm.cimagq(x)) == pytest.approx(x.imag, nan_ok=True)

    @given(complex_numbers(allow_infinity=False, allow_nan=False))
    def test_crealq(self, x):
        assert float(qcm.crealq(x)) == pytest.approx(x.real, nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cacoshq(self, x):
        assert complex(qcm.cacoshq(x)) == pytest.approx(cmath.acosh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cacosq(self, x):
        assert complex(qcm.cacosq(x)) == pytest.approx(cmath.acos(x), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_casinhq(self, x, y):
        c = complex(x, y)
        assert complex(qcm.casinhq(c)) == pytest.approx(cmath.asinh(c), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_casinq(self, x):
        assert complex(qcm.casinq(x)) == pytest.approx(cmath.asin(x), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_catanhq(self, x, y):
        c = complex(x, y)
        assert complex(qcm.catanhq(c)) == pytest.approx(cmath.atanh(c), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_catanq(self, x, y):
        c = complex(x, y)
        assert complex(qcm.catanq(c)) == pytest.approx(cmath.atan(c), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ccosq(self, x):
        assert complex(qcm.ccosq(x)) == pytest.approx(cmath.cos(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ccoshq(self, x):
        assert complex(qcm.ccoshq(x)) == pytest.approx(cmath.cosh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cexpq(self, x):
        assert complex(qcm.cexpq(x)) == pytest.approx(cmath.exp(x), nan_ok=True)

    @given(floats(allow_infinity=False, allow_nan=False))
    def test_cexpiq(self, x):
        s = qm.sin(x)
        c = qm.cos(x)

        assert complex(qcm.cexpiq(x)) == pytest.approx(complex(c, s), nan_ok=True)

    @given(complex_numbers(min_magnitude=1, max_magnitude=10))
    def test_clogq(self, x):
        assert complex(qcm.clogq(x)) == pytest.approx(cmath.log(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=1, max_magnitude=10))
    def test_clog10q(self, x):
        assert complex(qcm.clog10q(x)) == pytest.approx(cmath.log10(x), nan_ok=True)

    # @given(complex_numbers(allow_infinity=False,allow_nan=False, min_magnitude=0, max_magnitude=100))
    # def test_conjq(self, x):
    #     assert complex(qcm.conjq(x)) == ~x

    @given(
        complex_numbers(min_magnitude=1, max_magnitude=10),
        complex_numbers(min_magnitude=1, max_magnitude=10),
    )
    def test_cpowq(self, x, y):
        assert complex(qcm.cpowq(x, y)) == pytest.approx(x**y, nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cprojq(self, x):
        assert complex(qcm.cprojq(x)) == x

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csinq(self, x):
        assert complex(qcm.csinq(x)) == pytest.approx(cmath.sin(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csinhq(self, x):
        assert complex(qcm.csinhq(x)) == pytest.approx(cmath.sinh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csqrtq(self, x):
        assert complex(qcm.csqrtq(x)) == pytest.approx(cmath.sqrt(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ctanq(self, x):
        assert complex(qcm.ctanq(x)) == pytest.approx(cmath.tan(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ctanhq(self, x):
        assert complex(qcm.ctanhq(x)) == pytest.approx(cmath.tanh(x), nan_ok=True)


class TestQCMathPy:
    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cacosh(self, x):
        assert complex(qcm.acosh(x)) == pytest.approx(cmath.acosh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cacos(self, x):
        assert complex(qcm.acos(x)) == pytest.approx(cmath.acos(x), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_casinh(self, x, y):
        c = complex(x, y)
        assert complex(qcm.asinh(c)) == pytest.approx(cmath.asinh(c), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_casin(self, x):
        assert complex(qcm.asin(x)) == pytest.approx(cmath.asin(x), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_catanh(self, x, y):
        c = complex(x, y)
        assert complex(qcm.atanh(c)) == pytest.approx(cmath.atanh(c), nan_ok=True)

    @given(
        floats(min_value=1, max_value=100),
        floats(min_value=1, max_value=100),
    )
    def test_catan(self, x, y):
        c = complex(x, y)
        assert complex(qcm.atan(c)) == pytest.approx(cmath.atan(c), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ccos(self, x):
        assert complex(qcm.cos(x)) == pytest.approx(cmath.cos(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ccosh(self, x):
        assert complex(qcm.cosh(x)) == pytest.approx(cmath.cosh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_cexp(self, x):
        assert complex(qcm.exp(x)) == pytest.approx(cmath.exp(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=1, max_magnitude=10))
    def test_clog(self, x):
        assert complex(qcm.log(x)) == pytest.approx(cmath.log(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=1, max_magnitude=10))
    def test_clog10(self, x):
        assert complex(qcm.log10(x)) == pytest.approx(cmath.log10(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csin(self, x):
        assert complex(qcm.sin(x)) == pytest.approx(cmath.sin(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csinh(self, x):
        assert complex(qcm.sinh(x)) == pytest.approx(cmath.sinh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_csqrt(self, x):
        assert complex(qcm.sqrt(x)) == pytest.approx(cmath.sqrt(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ctan(self, x):
        assert complex(qcm.tan(x)) == pytest.approx(cmath.tan(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_ctanh(self, x):
        assert complex(qcm.tanh(x)) == pytest.approx(cmath.tanh(x), nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_polar(self, x):
        r, phi = qcm.polar(x)
        rr, pphi = cmath.polar(x)
        assert float(r) == pytest.approx(rr, nan_ok=True)
        assert float(phi) == pytest.approx(pphi, nan_ok=True)

    @given(complex_numbers(min_magnitude=0, max_magnitude=100))
    def test_phase(self, x):
        z = complex(qcm.phase(x))
        assert z.real == pytest.approx(float(qcm.cargq(x)), nan_ok=True)
        assert z.imag == pytest.approx(0.0, nan_ok=True)

    @given(
        floats(min_value=0, max_value=100),
        floats(min_value=-np.pi, max_value=np.pi),
    )
    def test_rect(self, r, phi):
        assert complex(qcm.rect(r, phi)) == pytest.approx(
            cmath.rect(r, phi), nan_ok=True
        )

    @given(complex_numbers())
    def test_isfinite(self, x):
        assert qcm.isfinite(x) == cmath.isfinite(x)
