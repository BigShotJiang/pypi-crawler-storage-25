<div align="center">
  
[![CI](https://github.com/sr-murthy/continuedfractions/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/sr-murthy/continuedfractions/actions/workflows/ci.yml)
[![CodeQL Analysis](https://github.com/sr-murthy/continuedfractions/actions/workflows/codeql-analysis.yml/badge.svg)](https://github.com/sr-murthy/continuedfractions/actions/workflows/codeql-analysis.yml)
[![Codecov](https://codecov.io/gh/sr-murthy/continuedfractions/graph/badge.svg?token=GWQ08T4P5J)](https://codecov.io/gh/sr-murthy/continuedfractions)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![pdm-managed](https://img.shields.io/badge/pdm-managed-blueviolet)](https://pdm-project.org)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Docs](https://readthedocs.org/projects/continuedfractions/badge/?version=latest)](https://continuedfractions.readthedocs.io/en/latest/?badge=latest)
[![PyPI version](https://img.shields.io/pypi/v/continuedfractions?logo=python&color=41bb13)](https://pypi.org/project/continuedfractions)
[![Downloads](https://img.shields.io/pepy/dt/continuedfractions
)](https://pypi.org/project/continuedfractions/)

</div>

# continuedfractions

A simple extension of the Python [`fractions.Fraction`](https://docs.python.org/3/library/fractions.html#fractions.Fraction) standard library class for working with (finite, simple) [continued fractions](https://en.wikipedia.org/wiki/Continued_fraction) as Python objects.

Install from [PyPI](https://pypi.org/project/continuedfractions/):
```shell
pip install -U continuedfractions
```
or the `main` branch of this repo:
```shell
pip install -U git+https://github.com/sr-murthy/continuedfractions
```

The documentation now consists only of an [API reference](https://continuedfractions.readthedocs.io/sources/api-reference.html). All other previous documentation has been removed to reduce maintenance.

The `continuedfractions` package is aimed at users interested in:

* working with (finite, simple) continued fractions as Python objects, in an intuitive object-oriented way
- making stateful computations involving key properties such as elements/coefficients, convergents, semiconvergents, remainders, and others
* operating on them as rationals and instances of the [`fractions.Fraction`](https://docs.python.org/3/library/fractions.html#fractions.Fraction) standard library class
* testing approximations for irrational numbers
* exploring other related objects such as rational points in the plane, enumerations of rational numbers, mediants, and special sequences of rational numbers such as Farey sequences
