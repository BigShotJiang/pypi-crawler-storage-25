# src/cobra_array/exceptions.py
"""
Exceptions for :pkg:`cobra_array`.
"""


# === WARNING ===
class CobraArrayWarning(Warning):
    """Base warning class for :pkg:`cobra_array`."""


class ParameterIgnoredWarning(CobraArrayWarning):
    """Warning raised when a parameter is ignored."""


# === ERROR ===
class CobraArrayError(Exception):
    """Base error class for :pkg:`cobra_array`."""


class MissingDependencyError(CobraArrayError, ImportError):
    """Raised when a required dependency is missing."""


class ConvertNoneTypeError(CobraArrayError, TypeError):
    """Raised when conversion of `NoneType` is attempted."""


class UnsupportedNamespaceError(CobraArrayError, ValueError):
    """Raised when an unsupported `array namespace` is specified."""


class UnsupportedArrayLibraryNameError(CobraArrayError, ValueError):
    """Raised when an unsupported `array namespace` name is specified."""


class ArrayConversionError(CobraArrayError):
    """Raised when an error occurs during array conversion in an `array namespace`."""


class NumPyConversionError(CobraArrayError):
    """Raised when an error occurs during array conversion in `NumPy`."""


class TorchConversionError(CobraArrayError):
    """Raised when an error occurs during array conversion in `PyTorch`."""


class CUDAUnavailableError(CobraArrayError):
    """Raised when CUDA is not available but a CUDA device is specified."""


class DeviceNotSupportedError(CobraArrayError):
    """Raised when a specified device is not supported by the current array library."""


class NotArrayAPIObjectError(CobraArrayError, ValueError):
    """Raised when an array is not an array API compatible array object."""


class NoArrayInputsError(CobraArrayError, ValueError):
    """Raised when no array inputs are provided."""


class GetArrayNamespaceError(CobraArrayError):
    """Raised when an error occurs while determining the `array namespace`."""


class CompatNamespaceAttributeError(CobraArrayError, AttributeError):
    """Raised when an attribute is not supported in :class:`CompatNamespace`."""


class CompatArrayAttributeError(CobraArrayError, AttributeError):
    """Raised when an attribute is not supported in :class:`CompatArray`."""
