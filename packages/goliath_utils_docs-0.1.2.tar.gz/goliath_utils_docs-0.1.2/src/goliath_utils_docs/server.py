"""MCP server exposing goliath-utils documentation to Claude Code."""

from __future__ import annotations

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .introspect import (
    ModuleDoc,
    extract_all,
    extract_module,
    format_module_docs,
    format_overview,
    search_docs,
    MODULES,
)

app = Server("goliath-utils-docs")

_docs: dict[str, ModuleDoc] | None = None


def _get_docs() -> dict[str, ModuleDoc]:
    global _docs
    if _docs is None:
        _docs = extract_all()
    return _docs


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_available_utils",
            description=(
                "List all available goliath-utils modules, classes, and functions "
                "with a high-level overview. Call this first to understand what "
                "utilities are available."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="get_module_docs",
            description=(
                "Get full API documentation for a specific goliath-utils module. "
                "Returns all classes, methods with signatures and descriptions. "
                "Modules: atrax, s3, sns, secrets, helpers."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "module": {
                        "type": "string",
                        "description": "Module name: atrax, s3, sns, secrets, or helpers",
                        "enum": list(MODULES.keys()),
                    },
                },
                "required": ["module"],
            },
        ),
        Tool(
            name="search_utils",
            description=(
                "Search across all goliath-utils APIs by keyword. "
                "Returns matching methods and functions with their signatures "
                "and descriptions. Useful when you know what you want to do "
                "but not which module or method to use."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search terms (e.g., 'groupby aggregate', 'upload file s3', 'merge join')",
                    },
                },
                "required": ["query"],
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    docs = _get_docs()

    if name == "list_available_utils":
        text = format_overview(docs)
        return [TextContent(type="text", text=text)]

    elif name == "get_module_docs":
        module = arguments.get("module", "")
        if module not in MODULES:
            return [TextContent(
                type="text",
                text=f"Unknown module: {module}. Available: {', '.join(MODULES.keys())}",
            )]
        doc = docs.get(module)
        if doc is None:
            return [TextContent(type="text", text=f"Module {module} could not be loaded.")]
        text = format_module_docs(doc)
        return [TextContent(type="text", text=text)]

    elif name == "search_utils":
        query = arguments.get("query", "")
        if not query.strip():
            return [TextContent(type="text", text="Please provide a search query.")]
        text = search_docs(docs, query)
        return [TextContent(type="text", text=text)]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())
