"""Runtime introspection engine for goliath_utils.

Imports goliath_utils submodules and extracts structured documentation
from type annotations, docstrings, and supplemental descriptions.
"""

from __future__ import annotations

import importlib
import importlib.resources
import inspect
import json
from dataclasses import dataclass, field
from typing import Any

MODULES = {
    "atrax": "goliath_utils.atrax",
    "s3": "goliath_utils.s3",
    "sns": "goliath_utils.sns",
    "secrets": "goliath_utils.secrets",
    "helpers": "goliath_utils.helpers",
}

MODULE_DESCRIPTIONS = {
    "atrax": "Pure-Python pandas alternative (Series, DataSet) with zero external dependencies",
    "s3": "Lightweight S3 client using httpx and AWS SigV4 signing (no boto3)",
    "sns": "Client for the Goliath notification/SNS API",
    "secrets": "Client for the Goliath secrets management API",
    "helpers": "S3 I/O helpers (CSV, JSON, Parquet), event parsing, and database insertion",
}


@dataclass
class ParamDoc:
    name: str
    annotation: str
    default: str | None
    kind: str


@dataclass
class MethodDoc:
    name: str
    signature: str
    docstring: str | None
    params: list[ParamDoc]
    return_annotation: str
    is_property: bool = False


@dataclass
class ClassDoc:
    name: str
    docstring: str | None
    methods: list[MethodDoc]
    bases: list[str]


@dataclass
class FunctionDoc:
    name: str
    signature: str
    docstring: str | None
    params: list[ParamDoc]
    return_annotation: str


@dataclass
class ModuleDoc:
    name: str
    full_path: str
    description: str | None
    docstring: str | None
    classes: list[ClassDoc]
    functions: list[FunctionDoc]


def _load_supplements() -> dict[str, str]:
    """Load supplemental one-liner docs from supplements.json."""
    ref = importlib.resources.files("goliath_utils_docs").joinpath("supplements.json")
    text = ref.read_text(encoding="utf-8")
    return json.loads(text)


def _format_annotation(ann: Any) -> str:
    """Convert a type annotation to a readable string."""
    if ann is inspect.Parameter.empty or ann is inspect.Signature.empty:
        return ""
    if isinstance(ann, str):
        return ann
    if hasattr(ann, "__name__"):
        return ann.__name__
    return str(ann).replace("typing.", "")


def _extract_params(sig: inspect.Signature) -> list[ParamDoc]:
    """Extract parameter documentation from a signature."""
    params = []
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        kind_map = {
            inspect.Parameter.POSITIONAL_ONLY: "positional",
            inspect.Parameter.POSITIONAL_OR_KEYWORD: "keyword",
            inspect.Parameter.KEYWORD_ONLY: "keyword_only",
            inspect.Parameter.VAR_POSITIONAL: "var_positional",
            inspect.Parameter.VAR_KEYWORD: "var_keyword",
        }
        default = None
        if param.default is not inspect.Parameter.empty:
            default = repr(param.default)
        params.append(ParamDoc(
            name=name,
            annotation=_format_annotation(param.annotation),
            default=default,
            kind=kind_map.get(param.kind, "unknown"),
        ))
    return params


def _format_signature(obj: Any) -> str:
    """Get a clean signature string for a callable."""
    try:
        sig = inspect.signature(obj)
        parts = []
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            ann = _format_annotation(param.annotation)
            default = ""
            if param.default is not inspect.Parameter.empty:
                default = f" = {param.default!r}"
            if param.kind == inspect.Parameter.VAR_POSITIONAL:
                part = f"*{name}"
            elif param.kind == inspect.Parameter.VAR_KEYWORD:
                part = f"**{name}"
            elif param.kind == inspect.Parameter.KEYWORD_ONLY:
                part = name
            else:
                part = name
            if ann:
                part = f"{part}: {ann}"
            part += default
            parts.append(part)

        ret = _format_annotation(sig.return_annotation)
        ret_str = f" -> {ret}" if ret else ""
        return f"({', '.join(parts)}){ret_str}"
    except (ValueError, TypeError):
        return "(...)"


def _is_public_method(name: str) -> bool:
    """Check if a name is a public method we should document."""
    if name.startswith("__") and name.endswith("__"):
        return name == "__init__"
    return not name.startswith("_")


def _extract_class(cls: type, supplements: dict[str, str]) -> ClassDoc:
    """Extract documentation for a class."""
    class_name = cls.__name__
    methods = []

    for name in sorted(cls.__dict__):
        if not _is_public_method(name):
            continue

        attr = cls.__dict__[name]
        is_prop = isinstance(attr, property)

        if is_prop:
            docstring = inspect.getdoc(attr.fget) if attr.fget else None
            try:
                sig = inspect.signature(attr.fget) if attr.fget else None
                ret = _format_annotation(sig.return_annotation) if sig else ""
            except (ValueError, TypeError):
                ret = ""
            methods.append(MethodDoc(
                name=name,
                signature=f"-> {ret}" if ret else "(property)",
                docstring=supplements.get(f"{class_name}.{name}") or docstring,
                params=[],
                return_annotation=ret,
                is_property=True,
            ))
        elif callable(attr) or isinstance(attr, (staticmethod, classmethod)):
            actual = attr
            if isinstance(attr, staticmethod):
                actual = attr.__func__
            elif isinstance(attr, classmethod):
                actual = attr.__func__

            # Use getattr on __doc__ directly to avoid inheriting generic docstrings
            raw_doc = getattr(actual, "__doc__", None)
            docstring = inspect.cleandoc(raw_doc) if raw_doc else None
            sig_str = _format_signature(actual)
            try:
                sig = inspect.signature(actual)
                params = _extract_params(sig)
                ret = _format_annotation(sig.return_annotation)
            except (ValueError, TypeError):
                params = []
                ret = ""

            supplement = supplements.get(f"{class_name}.{name}")
            methods.append(MethodDoc(
                name=name,
                signature=sig_str,
                docstring=supplement or docstring,
                params=params,
                return_annotation=ret,
                is_property=False,
            ))

    bases = [b.__name__ for b in cls.__bases__ if b is not object]

    return ClassDoc(
        name=class_name,
        docstring=inspect.getdoc(cls),
        methods=methods,
        bases=bases,
    )


def _extract_function(name: str, func: Any, supplements: dict[str, str]) -> FunctionDoc:
    """Extract documentation for a module-level function."""
    docstring = inspect.getdoc(func)
    sig_str = _format_signature(func)
    try:
        sig = inspect.signature(func)
        params = _extract_params(sig)
        ret = _format_annotation(sig.return_annotation)
    except (ValueError, TypeError):
        params = []
        ret = ""

    return FunctionDoc(
        name=name,
        signature=sig_str,
        docstring=docstring or supplements.get(name),
        params=params,
        return_annotation=ret,
    )


def extract_module(short_name: str) -> ModuleDoc:
    """Extract documentation for a single goliath_utils submodule."""
    full_path = MODULES[short_name]
    mod = importlib.import_module(full_path)
    supplements = _load_supplements()

    exported = getattr(mod, "__all__", None)
    if exported is None:
        exported = [n for n in dir(mod) if not n.startswith("_")]

    classes = []
    functions = []

    for name in exported:
        obj = getattr(mod, name)
        if inspect.isclass(obj):
            # Skip pure exception classes (just document their names)
            if issubclass(obj, Exception) and obj is not Exception:
                classes.append(ClassDoc(
                    name=name,
                    docstring=inspect.getdoc(obj),
                    methods=[],
                    bases=[b.__name__ for b in obj.__bases__ if b is not object],
                ))
            else:
                classes.append(_extract_class(obj, supplements))
        elif inspect.isfunction(obj):
            functions.append(_extract_function(name, obj, supplements))

    return ModuleDoc(
        name=short_name,
        full_path=full_path,
        description=MODULE_DESCRIPTIONS.get(short_name),
        docstring=inspect.getdoc(mod),
        classes=classes,
        functions=functions,
    )


def extract_all() -> dict[str, ModuleDoc]:
    """Extract documentation for all goliath_utils submodules."""
    result = {}
    for short_name in MODULES:
        try:
            result[short_name] = extract_module(short_name)
        except ImportError:
            continue
    return result


def format_module_docs(doc: ModuleDoc) -> str:
    """Format a ModuleDoc into readable markdown."""
    lines = [f"# {doc.name}", ""]
    if doc.description:
        lines.append(doc.description)
        lines.append("")
    if doc.docstring:
        lines.append(doc.docstring)
        lines.append("")
    lines.append(f"**Import**: `from goliath_utils.{doc.name} import ...`")
    lines.append("")

    for cls in doc.classes:
        lines.append(f"## {cls.name}")
        if cls.bases:
            lines.append(f"Inherits from: {', '.join(cls.bases)}")
        if cls.docstring:
            lines.append("")
            lines.append(cls.docstring)
        lines.append("")

        if not cls.methods:
            lines.append("*(Exception class — raise/catch only)*")
            lines.append("")
            continue

        for method in cls.methods:
            if method.is_property:
                lines.append(f"### `{cls.name}.{method.name}` (property)")
                if method.return_annotation:
                    lines.append(f"  Type: `{method.return_annotation}`")
            else:
                lines.append(f"### `{cls.name}.{method.name}{method.signature}`")

            if method.docstring:
                lines.append(f"  {method.docstring}")
            lines.append("")

    for func in doc.functions:
        lines.append(f"## `{func.name}{func.signature}`")
        if func.docstring:
            lines.append("")
            lines.append(func.docstring)
        lines.append("")

    return "\n".join(lines)


def format_overview(docs: dict[str, ModuleDoc]) -> str:
    """Format all modules into a high-level overview."""
    lines = ["# goliath-utils API Overview", ""]
    lines.append("A collection of pure-Python utilities for the Goliath platform.")
    lines.append("")
    lines.append("**Install**: `pip install goliath-utils`")
    lines.append("")

    for name, doc in docs.items():
        lines.append(f"## {name}")
        if doc.description:
            lines.append(doc.description)
        lines.append("")

        for cls in doc.classes:
            method_count = len([m for m in cls.methods if not m.is_property])
            prop_count = len([m for m in cls.methods if m.is_property])
            if cls.methods:
                parts = []
                if method_count:
                    parts.append(f"{method_count} methods")
                if prop_count:
                    parts.append(f"{prop_count} properties")
                lines.append(f"- **{cls.name}** ({', '.join(parts)})")
            else:
                lines.append(f"- **{cls.name}** (exception)")
            if cls.docstring:
                first_line = cls.docstring.split("\n")[0]
                lines.append(f"  {first_line}")

        for func in doc.functions:
            lines.append(f"- **{func.name}()**")
            if func.docstring:
                first_line = func.docstring.split("\n")[0]
                lines.append(f"  {first_line}")

        lines.append("")

    return "\n".join(lines)


def search_docs(docs: dict[str, ModuleDoc], query: str, max_results: int = 10) -> str:
    """Search across all documentation for matching methods/functions."""
    terms = query.lower().split()
    results: list[tuple[float, str]] = []

    for mod_name, doc in docs.items():
        for cls in doc.classes:
            for method in cls.methods:
                score = _score_match(terms, method.name, method.docstring, method.signature)
                if score > 0:
                    desc = method.docstring or "(no description)"
                    if method.is_property:
                        entry = f"**{cls.name}.{method.name}** (property)\n  {desc}"
                    else:
                        entry = f"**{cls.name}.{method.name}**`{method.signature}`\n  {desc}"
                    entry = f"[{mod_name}] {entry}"
                    results.append((score, entry))

        for func in doc.functions:
            score = _score_match(terms, func.name, func.docstring, func.signature)
            if score > 0:
                desc = func.docstring or "(no description)"
                entry = f"[{mod_name}] **{func.name}**`{func.signature}`\n  {desc}"
                results.append((score, entry))

    results.sort(key=lambda x: -x[0])
    top = results[:max_results]

    if not top:
        return f"No results found for: {query}"

    lines = [f"# Search results for: {query}", ""]
    for _, entry in top:
        lines.append(f"- {entry}")
        lines.append("")
    return "\n".join(lines)


def _score_match(terms: list[str], name: str, docstring: str | None, signature: str) -> float:
    """Score how well a method matches search terms."""
    text = f"{name} {docstring or ''} {signature}".lower()
    score = 0.0
    for term in terms:
        if term in name.lower():
            score += 3.0  # name match is strongest
        elif docstring and term in docstring.lower():
            score += 1.5
        elif term in signature.lower():
            score += 1.0
    return score
