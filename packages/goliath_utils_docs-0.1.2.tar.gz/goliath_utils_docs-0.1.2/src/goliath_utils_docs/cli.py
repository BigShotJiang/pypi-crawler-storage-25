"""CLI for installing/uninstalling the MCP server and running it directly."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

SERVER_NAME = "goliath-utils-docs"
MCP_CONFIG = {
    "command": "uvx",
    "args": ["goliath-utils-docs", "serve"],
}


def _global_settings_path() -> Path:
    return Path.home() / ".claude" / "settings.json"


def _project_settings_path() -> Path:
    # Walk up to find a git root
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".git").exists():
            return parent / ".claude" / "settings.json"
    return cwd / ".claude" / "settings.json"


def _read_settings(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def _write_settings(path: Path, settings: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")


def install(project: bool = True) -> None:
    """Register the MCP server in Claude Code settings."""
    path = _project_settings_path() if project else _global_settings_path()
    settings = _read_settings(path)
    settings.setdefault("mcpServers", {})
    settings["mcpServers"][SERVER_NAME] = MCP_CONFIG
    _write_settings(path, settings)
    scope = "project" if project else "global"
    print(f"Installed {SERVER_NAME} in {scope} settings: {path}")
    print("Restart Claude Code to activate.")


def uninstall(project: bool = True) -> None:
    """Remove the MCP server from Claude Code settings."""
    path = _project_settings_path() if project else _global_settings_path()
    settings = _read_settings(path)
    servers = settings.get("mcpServers", {})
    if SERVER_NAME in servers:
        del servers[SERVER_NAME]
        _write_settings(path, settings)
        scope = "project" if project else "global"
        print(f"Removed {SERVER_NAME} from {scope} settings: {path}")
    else:
        print(f"{SERVER_NAME} not found in settings.")


def serve() -> None:
    """Run the MCP server (stdio transport)."""
    from .server import main as server_main
    asyncio.run(server_main())


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print("Usage: goliath-utils-docs <command>")
        print()
        print("Commands:")
        print("  install    Register MCP server in Claude Code settings")
        print("  uninstall  Remove MCP server from Claude Code settings")
        print("  serve      Run the MCP server directly")
        print()
        print("Options:")
        print("  --global   Use global settings instead of project (default: project)")
        return

    command = args[0]
    use_global = "--global" in args

    if command == "install":
        install(project=not use_global)
    elif command == "uninstall":
        uninstall(project=not use_global)
    elif command == "serve":
        serve()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
