# goliath-utils-docs

MCP server that exposes [goliath-utils](https://pypi.org/project/goliath-utils/) API documentation to Claude Code.

When configured, Claude Code gains access to three tools:

- **list_available_utils** — overview of all modules, classes, and functions
- **get_module_docs** — full API reference for a specific module
- **search_utils** — search across all utility APIs by keyword

## Install

```bash
pip install goliath-utils-docs
goliath-utils-docs install
```

This registers the MCP server in your Claude Code settings. Restart Claude Code to activate.

## Uninstall

```bash
goliath-utils-docs uninstall
```

## Manual configuration

Add to `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "goliath-utils-docs": {
      "command": "uvx",
      "args": ["goliath-utils-docs", "serve"]
    }
  }
}
```
