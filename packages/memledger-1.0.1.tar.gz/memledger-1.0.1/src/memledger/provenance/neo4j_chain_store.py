# SPDX-License-Identifier: Apache-2.0
"""Neo4jChainStore — graph-native ChainStore implementation (G1 / v2).

Implements the ChainStore Protocol against a Neo4j 5.x async driver. The
v1 JsonArrayChainStore remains the default; this implementation is
opt-in via Memledger config or kwargs.

Schema:
    (:Memory {id, namespace, confidence, hedged, status, created_by, created_at})
    (child)-[:DERIVED_FROM {hop, created_at}]->(parent)
    (a)-[:CONFLICTS {detected_at, similarity}]->(b)
    (new)-[:SUPERSEDES]->(old)

pgvector remains the source of truth for content/embeddings/metadata. Neo4j
is a graph view over the same memory IDs. Both keyed on memory.id.

The store is read-only on the public surface (matches Protocol). Writes
to Neo4j are mirrored from `Memledger.add()` via the optional
`mirror_write` method called by the SDK when a Neo4j store is active.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal, Optional

from memledger.provenance.chain import MAX_ACTIVE_CHAIN_HOPS
from memledger.provenance.models import AttributionChain, ChainHop

if TYPE_CHECKING:
    from neo4j import AsyncDriver
    from memledger.memledger import Memledger
    from memledger.models import MemoryRecord

logger = logging.getLogger(__name__)


class Neo4jChainStore:
    """Graph-native chain store backed by Neo4j 5.x async driver.

    Constructor takes an existing AsyncDriver (callers manage the driver
    lifecycle so they can share it across other Neo4j-using subsystems).

    Construct via:
        from neo4j import AsyncGraphDatabase
        driver = AsyncGraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "..."))
        store = Neo4jChainStore(driver)
        ml = await Memledger.create(..., chain_store=store)

    Or via the convenience factory:
        store = await Neo4jChainStore.from_uri("bolt://localhost:7687", auth=("neo4j", "..."))
    """

    def __init__(self, driver: "AsyncDriver") -> None:
        self._driver = driver

    @classmethod
    async def from_uri(
        cls,
        uri: str,
        *,
        auth: Optional[tuple[str, str]] = None,
        database: str = "neo4j",
    ) -> "Neo4jChainStore":
        """Convenience: build a driver from a URI.

        Caller still owns driver lifecycle via `store._driver.close()`.
        For demo / single-process use only — production callers should
        manage the driver themselves.
        """
        try:
            from neo4j import AsyncGraphDatabase
        except ImportError as e:
            raise ImportError(
                "neo4j package is required for Neo4jChainStore. "
                "Install with `pip install memledger[neo4j]` or `pip install neo4j>=5.27`."
            ) from e
        driver = AsyncGraphDatabase.driver(uri, auth=auth)
        store = cls(driver)
        store._database = database
        return store

    @property
    def database(self) -> str:
        return getattr(self, "_database", "neo4j")

    async def ensure_schema(self) -> None:
        """Create constraints + indexes idempotently. Call once at startup."""
        async with self._driver.session(database=self.database) as session:
            await session.run(
                "CREATE CONSTRAINT memory_id_unique IF NOT EXISTS "
                "FOR (m:Memory) REQUIRE m.id IS UNIQUE"
            )
            await session.run(
                "CREATE INDEX memory_namespace IF NOT EXISTS "
                "FOR (m:Memory) ON (m.namespace)"
            )
        logger.info("Neo4jChainStore schema ensured")

    # ------------------------------------------------------------------
    # ChainStore Protocol — read API
    # ------------------------------------------------------------------

    async def min_confidence_upstream(
        self,
        memory_id: str,
        *,
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> float:
        """Walk DERIVED_FROM edges upstream; return min confidence.

        Returns 1.0 for an empty/missing chain so it never tightens the
        declared confidence of a memory with no provenance to weaken it.
        """
        # Cypher disallows parameters inside variable-length path bounds;
        # interpolate the int (it's an internal int, not user-supplied).
        query = (
            "MATCH (m:Memory {id: $id})-[:DERIVED_FROM*0..%d]->(a:Memory) "
            "RETURN min(a.confidence) AS min_conf" % int(max_hops)
        )
        async with self._driver.session(database=self.database) as session:
            result = await session.run(query, id=memory_id)
            record = await result.single()
            if record is None or record["min_conf"] is None:
                return 1.0
            return float(record["min_conf"])

    async def build_chain(
        self,
        memory_id: str,
        *,
        direction: Literal["upstream", "downstream", "both"] = "upstream",
        max_hops: int = MAX_ACTIVE_CHAIN_HOPS,
    ) -> AttributionChain:
        """Walk the chain in Neo4j; return AttributionChain.

        Walker behavior matches JsonArrayChainStore:
        - upstream walks DERIVED_FROM
        - downstream walks reverse DERIVED_FROM
        - both: union with shared hop_number ordering
        - truncated=True if a path hit max_hops without termination
        """
        if direction == "upstream":
            cypher = (
                "MATCH path = (m:Memory {id: $id})-[r:DERIVED_FROM*0..%d]->(a:Memory) "
                "RETURN nodes(path) AS nodes, length(path) AS hops "
                "ORDER BY hops" % max_hops
            )
        elif direction == "downstream":
            cypher = (
                "MATCH path = (m:Memory {id: $id})<-[r:DERIVED_FROM*0..%d]-(a:Memory) "
                "RETURN nodes(path) AS nodes, length(path) AS hops "
                "ORDER BY hops" % max_hops
            )
        else:  # both
            cypher = (
                "MATCH path = (m:Memory {id: $id})-[r:DERIVED_FROM*0..%d]-(a:Memory) "
                "RETURN nodes(path) AS nodes, length(path) AS hops "
                "ORDER BY hops" % max_hops
            )

        hops: list[ChainHop] = []
        agents: set[str] = set()
        seen_ids: set[str] = set()
        truncated = False
        min_conf = 1.0

        async with self._driver.session(database=self.database) as session:
            result = await session.run(cypher, id=memory_id)
            async for record in result:
                nodes = record["nodes"]
                hop_count = record["hops"]
                if hop_count >= max_hops:
                    truncated = True
                for idx, node in enumerate(nodes):
                    nid = node["id"]
                    if nid in seen_ids:
                        continue
                    seen_ids.add(nid)
                    conf = float(node.get("confidence", 0.5))
                    agent = node.get("created_by") or "unknown"
                    timestamp = node.get("created_at") or ""
                    if isinstance(timestamp, datetime):
                        timestamp = timestamp.isoformat()
                    action = "origin" if idx == 0 else "derived"
                    hops.append(ChainHop(
                        memory_id=nid,
                        agent_id=agent,
                        confidence=conf,
                        timestamp=str(timestamp),
                        hop_number=idx,
                        action=action,
                    ))
                    agents.add(agent)
                    if conf < min_conf:
                        min_conf = conf

        # Sort hops by hop_number (matches JsonArrayChainStore behavior)
        hops.sort(key=lambda h: h.hop_number)

        return AttributionChain(
            root_memory_id=memory_id,
            chain=hops[:MAX_ACTIVE_CHAIN_HOPS],
            chain_depth=len(hops),
            min_confidence=min_conf if hops else 1.0,
            agents_involved=sorted(agents),
            truncated=truncated,
        )

    # ------------------------------------------------------------------
    # Write mirror — called by Memledger.add() when this store is active
    # ------------------------------------------------------------------

    async def mirror_write(self, record: "MemoryRecord") -> None:
        """Mirror a memory + its DERIVED_FROM edges into Neo4j.

        Called by Memledger.add() after the pgvector write succeeds.
        Idempotent — uses MERGE on memory.id. Safe to call multiple times.
        """
        node_props = {
            "id": record.id,
            "namespace": record.namespace,
            "confidence": float(record.confidence) if record.confidence is not None else 0.5,
            "hedged": bool(record.hedged),
            "status": record.status.value if hasattr(record.status, "value") else str(record.status),
            "created_by": record.created_by or "",
            "created_at": record.created_at.isoformat() if record.created_at else "",
        }
        # Optional supersedes edge
        supersedes_id = getattr(record, "supersedes", None)
        # Optional conflicts (E1)
        conflicts = getattr(record, "conflicts", []) or []
        derived_from = record.derived_from or []

        async with self._driver.session(database=self.database) as session:
            # MERGE the node + parents + edges in one transaction
            await session.execute_write(
                self._mirror_write_tx,
                node_props,
                derived_from,
                supersedes_id,
                conflicts,
            )

    @staticmethod
    async def _mirror_write_tx(
        tx,
        node_props: dict[str, Any],
        derived_from: list[str],
        supersedes_id: Optional[str],
        conflicts: list[Any],
    ) -> None:
        # Upsert the memory node
        await tx.run(
            "MERGE (m:Memory {id: $id}) "
            "SET m.namespace = $namespace, "
            "    m.confidence = $confidence, "
            "    m.hedged = $hedged, "
            "    m.status = $status, "
            "    m.created_by = $created_by, "
            "    m.created_at = $created_at",
            **node_props,
        )

        # DERIVED_FROM edges to parents (parent nodes may not yet exist; MERGE creates stub)
        for hop, parent_id in enumerate(derived_from):
            await tx.run(
                "MERGE (parent:Memory {id: $pid}) "
                "WITH parent "
                "MATCH (child:Memory {id: $cid}) "
                "MERGE (child)-[r:DERIVED_FROM]->(parent) "
                "ON CREATE SET r.hop = $hop, r.created_at = $now",
                pid=parent_id,
                cid=node_props["id"],
                hop=hop,
                now=datetime.utcnow().isoformat(),
            )

        # SUPERSEDES edge
        if supersedes_id:
            await tx.run(
                "MERGE (old:Memory {id: $old_id}) "
                "WITH old "
                "MATCH (new:Memory {id: $new_id}) "
                "MERGE (new)-[:SUPERSEDES]->(old)",
                old_id=supersedes_id,
                new_id=node_props["id"],
            )

        # CONFLICTS edges (E1)
        for c in conflicts:
            existing_id = c.existing_id if hasattr(c, "existing_id") else c.get("existing_id")
            similarity = c.similarity if hasattr(c, "similarity") else c.get("similarity", 0.0)
            if not existing_id:
                continue
            await tx.run(
                "MERGE (other:Memory {id: $oid}) "
                "WITH other "
                "MATCH (new:Memory {id: $nid}) "
                "MERGE (new)-[r:CONFLICTS]->(other) "
                "ON CREATE SET r.detected_at = $now, r.similarity = $sim",
                oid=existing_id,
                nid=node_props["id"],
                now=datetime.utcnow().isoformat(),
                sim=float(similarity),
            )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        await self._driver.close()
