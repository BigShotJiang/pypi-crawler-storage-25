#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""C3 — validate OpenSearch as a first-class memledger backend.

Exercises the OpenSearchBackend end-to-end against a real domain:
  1. Initialize backend (creates index with v1 governance mappings)
  2. Add a small set of records (with derived_from + conflicts + hedged)
  3. Vector search round-trip
  4. Hybrid search (vector + BM25 RRF) round-trip
  5. Cleanup — delete the test index

Env (defaults shown):
  AWS_DEFAULT_REGION        us-west-2
  OPENSEARCH_HOST           required — https://search-...es.amazonaws.com
  OPENSEARCH_INDEX          memledger-validate-<timestamp>
  OPENSEARCH_AUTH_TYPE      aws_sigv4 | basic
  OPENSEARCH_USERNAME       (basic)
  OPENSEARCH_PASSWORD       (basic)
  EMBED_PROVIDER            local | bedrock
"""
from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid


async def main() -> int:
    host = os.environ.get("OPENSEARCH_HOST")
    if not host:
        print("ERROR: set OPENSEARCH_HOST=https://...es.amazonaws.com", file=sys.stderr)
        return 2

    region = os.environ.get("AWS_DEFAULT_REGION", "us-west-2")
    auth_type = os.environ.get("OPENSEARCH_AUTH_TYPE", "aws_sigv4")
    index = os.environ.get(
        "OPENSEARCH_INDEX", f"memledger-validate-{int(time.time())}"
    )
    embed_provider = os.environ.get("EMBED_PROVIDER", "local")

    print("=" * 60)
    print(f"C3 — OpenSearch validation against {host}")
    print(f"  region={region} auth={auth_type} index={index}")
    print("=" * 60)

    from memledger.backends.opensearch import OpenSearchBackend
    from memledger.embeddings import EmbeddingProvider
    from memledger.models import EmbeddingConfig, MemoryRecord, RecordType, MemoryStatus, ConflictRef
    from datetime import datetime, timezone

    if embed_provider == "bedrock":
        embed = EmbeddingConfig(
            provider="bedrock", model="amazon.titan-embed-text-v2:0", dimensions=1024,
        )
        dims = 1024
    else:
        embed = EmbeddingConfig(
            provider="local", model="BAAI/bge-small-en-v1.5", dimensions=384,
        )
        dims = 384

    embedder = EmbeddingProvider(embed)
    backend = OpenSearchBackend()

    init_cfg = {
        "hosts": [host],
        "auth_type": auth_type,
        "index_name": index,
        "dimensions": dims,
        "engine": "faiss",
        "region": region,
    }
    if auth_type == "basic":
        init_cfg["username"] = os.environ.get("OPENSEARCH_USERNAME", "admin")
        init_cfg["password"] = os.environ.get("OPENSEARCH_PASSWORD", "admin")

    print("\n[1/5] initialize + create index ...")
    await backend.initialize(init_cfg)
    print("  PASS — index exists with faiss engine + v1 mappings")

    print("\n[2/5] add 4 records ...")
    parent_id = str(uuid.uuid4())
    child_id = str(uuid.uuid4())
    sample_records = [
        MemoryRecord(
            id=parent_id,
            content="HikariCP pool exhaustion: connections leaking in OrderRepository.",
            namespace="/demo/sre/payment-svc",
            session_id="opensearch-validate",
            embedding=await embedder.embed_single("HikariCP pool exhaustion."),
            confidence=0.45,
            hedged=True,
            created_by="sre-triage",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            status=MemoryStatus.ACTIVE,
            record_type=RecordType.EPISODIC,
        ),
        MemoryRecord(
            id=child_id,
            content="Root cause: leak in finally{} block of OrderRepository.findByMerchant; raise pool to 50.",
            namespace="/demo/sre/payment-svc",
            session_id="opensearch-validate",
            embedding=await embedder.embed_single("OrderRepository finally block leak; raise pool to 50."),
            confidence=0.88,
            derived_from=[parent_id],
            created_by="sre-diagnosis",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            status=MemoryStatus.ACTIVE,
            record_type=RecordType.SEMANTIC,
            conflicts=[ConflictRef(existing_id=parent_id, existing_content="", similarity=0.78)],
        ),
        MemoryRecord(
            id=str(uuid.uuid4()),
            content="Bedrock inference profile: us.anthropic.claude-sonnet-4-6 cross-region.",
            namespace="/demo/runbooks",
            session_id="opensearch-validate",
            embedding=await embedder.embed_single("Bedrock inference profile cross-region Sonnet."),
            confidence=0.95,
            created_by="sre-knowledge-base",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            status=MemoryStatus.ACTIVE,
            record_type=RecordType.PROCEDURAL,
        ),
        MemoryRecord(
            id=str(uuid.uuid4()),
            content="Outdated runbook: max_connections=8 (2019, never load tested).",
            namespace="/demo/sre/payment-svc",
            session_id="opensearch-validate",
            embedding=await embedder.embed_single("Outdated runbook 2019 max_connections."),
            confidence=0.20,
            created_by="sre-research",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            status=MemoryStatus.ACTIVE,
            record_type=RecordType.SEMANTIC,
        ),
    ]
    written = await backend.add(sample_records)
    print(f"  PASS — wrote {len(written)} records")

    print("\n[3/5] vector search ...")
    qvec = await embedder.embed_single("HikariCP leak fix")
    hits = await backend.search_vector(embedding=qvec, top_k=5)
    print(f"  PASS — {len(hits)} hits; top score={hits[0].score if hits else None:.3f}" if hits else "  FAIL — empty hits")
    if hits:
        flag = getattr(hits[0], "confidence_flag", None)
        conf = getattr(hits[0], "confidence", None)
        conflicts = getattr(hits[0], "conflicts", None)
        print(f"  top: id={hits[0].id[:8]} conf={conf} conflicts={len(conflicts) if conflicts else 0}")

    print("\n[4/5] hybrid search (vector + BM25 RRF) ...")
    hybrid = await backend.search_hybrid(query="OrderRepository leak", embedding=qvec, top_k=5)
    print(f"  PASS — {len(hybrid)} hits via RRF")
    for h in hybrid[:3]:
        print(f"    {h.id[:8]} score={h.score:.4f} by={h.created_by}")

    print("\n[5/5] cleanup index ...")
    backend._client.indices.delete(index=index)
    print(f"  PASS — index {index} deleted")
    await backend.close()

    print("\n" + "=" * 60)
    print("PASS — OpenSearch backend validated end-to-end.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
