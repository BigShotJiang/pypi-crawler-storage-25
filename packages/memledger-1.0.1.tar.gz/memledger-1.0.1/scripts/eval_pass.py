#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Run all available MAI evaluator tiers against the seeded dataset.

Used by the Friday demo runbook (`make demo-fresh` in memledger-ui)
right after re-seeding, so Phoenix has fresh evaluator spans whose
`eval.record_ids` match the memories visible in the UI.

Tiers run:
  - deterministic (always)
  - structural (always)
  - RAGAS (only if MEMLEDGER_JUDGE_MODEL is set)

Env:
  MEMLEDGER_PG_DSN          required — Postgres DSN
  OTEL_EXPORTER_OTLP_ENDPOINT  default http://localhost:4317
  PHOENIX_BASE_URL          default http://localhost:6006
  MEMLEDGER_JUDGE_MODEL     optional — enables RAGAS tier
  MEMLEDGER_DEMO_SESSION    default demo-b9-incident-001

Usage:
  python scripts/eval_pass.py
"""
from __future__ import annotations

import asyncio
import os
import sys


async def main() -> int:
    dsn = os.environ.get("MEMLEDGER_PG_DSN")
    if not dsn:
        print("ERROR: set MEMLEDGER_PG_DSN", file=sys.stderr)
        return 2

    os.environ.setdefault("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
    os.environ.setdefault("PHOENIX_BASE_URL", "http://localhost:6006")

    session = os.environ.get("MEMLEDGER_DEMO_SESSION", "demo-b9-incident-001")

    from memledger.telemetry.instrument import setup_engram_telemetry

    setup_engram_telemetry(service_name="memledger-demo", exporter="otlp")

    import asyncpg

    pool = await asyncpg.create_pool(dsn)
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, content, namespace, created_by, confidence, hedged, "
            "session_id, derived_from, record_type "
            "FROM agent_memory WHERE session_id=$1 ORDER BY created_at",
            session,
        )
    await pool.close()
    records = [dict(r) for r in rows]
    if not records:
        print(f"WARN: no records for session {session!r}; nothing to evaluate.")
        return 1

    print(f"loaded {len(records)} records (session={session})")

    from evaluators.attribution_integrity import evaluate_attribution_integrity

    decision_id = next(
        (r["id"] for r in records if r["created_by"] == "sre-remediation"),
        records[0]["id"],
    )
    res_det = evaluate_attribution_integrity(decision_id, records)
    print(f"  deterministic : score={res_det.score} passed={res_det.passed}")

    from evaluators.attribution_integrity_structural import (
        evaluate_from_memory_records,
    )

    res_struct = evaluate_from_memory_records(records)
    print(f"  structural    : score={res_struct.score} passed={res_struct.passed}")

    judge = os.environ.get("MEMLEDGER_JUDGE_MODEL")
    if judge:
        try:
            from evaluators.attribution_integrity_ragas import evaluate_mai_ragas

            res_ragas = evaluate_mai_ragas(records, judge_model=judge)
            print(
                f"  ragas         : score={res_ragas.score} passed={res_ragas.passed} "
                f"(judge={judge})"
            )
        except Exception as e:
            print(f"  ragas         : skipped — {e}")
    else:
        print("  ragas         : skipped (set MEMLEDGER_JUDGE_MODEL to enable)")

    # Force flush so spans land in Phoenix before the runbook's next step.
    try:
        from opentelemetry import trace as _trace

        provider = _trace.get_tracer_provider()
        if hasattr(provider, "force_flush"):
            provider.force_flush()
        if hasattr(provider, "shutdown"):
            provider.shutdown()
    except Exception:
        pass

    print("\nDone. Phoenix has fresh evaluator spans for the current seed.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
