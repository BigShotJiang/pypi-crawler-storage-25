#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Seed the Thursday demo: B9 SRE multi-agent incident with conflicts + chain.

Drives a realistic 5-agent SRE workflow that exercises every UI surface:
- confidence_flag PASS / FLAG / FILTER bands
- quality_score (MQS) spread across 0..100
- conflicts[] populated by the conflict_threshold detector
- DERIVED_FROM, SUPERSEDES, CONFLICTS edges in Neo4j
- a low-confidence memory in the chain (so weakest-link < declared)
- one record we'll RTBF in the demo (`forgettable`)

Env:
    MEMLEDGER_PG_DSN     postgresql:// dsn (required)
    NEO4J_URI            bolt://localhost:7687 (optional; if set, mirrors)
    NEO4J_USER, NEO4J_PASSWORD
    EMBED_PROVIDER       "local" (default) | "bedrock"

Usage:
    python scripts/seed_demo_b9.py
"""
from __future__ import annotations

import asyncio
import os
import sys


async def seed() -> None:
    from memledger import Memledger, RecordType
    from memledger.models import EmbeddingConfig, MemledgerConfig

    dsn = os.environ.get("MEMLEDGER_PG_DSN") or os.environ.get("ENGRAM_PG_URL")
    if not dsn:
        print("ERROR: set MEMLEDGER_PG_DSN", file=sys.stderr)
        sys.exit(1)

    provider = os.environ.get("EMBED_PROVIDER", "local")
    if provider == "bedrock":
        embed = EmbeddingConfig(
            provider="bedrock",
            model="amazon.titan-embed-text-v2:0",
            dimensions=1024,
        )
    else:
        embed = EmbeddingConfig(
            provider="local",
            model="BAAI/bge-small-en-v1.5",
            dimensions=384,
        )

    chain_store = None
    neo4j_uri = os.environ.get("NEO4J_URI")
    if neo4j_uri:
        try:
            from memledger.provenance.neo4j_chain_store import Neo4jChainStore

            chain_store = await Neo4jChainStore.from_uri(
                neo4j_uri,
                auth=(
                    os.environ.get("NEO4J_USER", "neo4j"),
                    os.environ.get("NEO4J_PASSWORD", "memledger-dev"),
                ),
            )
            await chain_store.ensure_schema()
            print(f"Mirroring chain to Neo4j at {neo4j_uri}")
        except Exception as e:
            print(f"WARN: Neo4j unavailable, skipping mirror: {e}", file=sys.stderr)
            chain_store = None

    cfg = MemledgerConfig(
        embeddings=embed,
        default_backend="pgvector",
        # bge-small produces lower similarity scores than Titan; drop the
        # threshold so the intentional duplicate at step 4 actually trips
        # conflict detection on the demo box.
        conflict_threshold=0.55,
    )
    ml = await Memledger.create(
        backend_name="pgvector",
        connection_string=dsn,
        embedding_config=embed,
        engram_config=cfg,
    )
    if chain_store is not None:
        ml._chain_store = chain_store

    NS = "/demo/sre/payment-svc"
    SESSION = "demo-b9-incident-001"
    INCIDENT = "INC-2026-0521-001"

    print(f"\n--- Seeding {INCIDENT} into {NS} ---\n")

    # ── 1. Triage: ambiguous alert. Hedged; low confidence (FLAG band). ──
    triage_id = await ml.add(
        content=(
            "ALERT INC-2026-0521-001: payment-svc HikariCP saturated 4 min, p95 8.2s, "
            "30 timeouts/min. Hypothesis: connection pool leak vs traffic spike vs "
            "upstream DB slowness. Cannot confirm without metrics correlation."
        ),
        record_type=RecordType.EPISODIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-triage",
        confidence=0.45,
        importance=0.45,
        hedged=True,
        triggered_by=f"alert:{INCIDENT}",
        workflow_id=INCIDENT,
        turn_context="step-1-triage",
    )
    print(f"  1. sre-triage          [{triage_id[:8]}] conf=0.45 hedged=True (FLAG)")

    # ── 2. Outdated runbook (low confidence, FILTER band). ──
    bad_runbook_id = await ml.add(
        content=(
            "From 2019 wiki: HikariCP pool exhaustion always means traffic spike. "
            "Recommend doubling maxPoolSize without further investigation."
        ),
        record_type=RecordType.SEMANTIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-research",
        confidence=0.20,
        importance=0.20,
        triggered_by="wiki-search:hikaricp-pool",
        metadata={"source": "wiki-2019", "verified": False},
    )
    print(f"  2. sre-research        [{bad_runbook_id[:8]}] conf=0.20 (FILTER)")

    # ── 3. Diagnosis: derived from triage; high local confidence but
    #     weakest-link will pull effective conf to 0.45. ──
    diagnosis_id = await ml.add(
        content=(
            "Root cause: payment-svc HikariCP leak. JDBC connections not returned "
            "after timeout exception in OrderRepository.findByMerchant. maxPoolSize=10, "
            "leak rate ~2/min. Fix: patch finally{} block + raise pool to 50."
        ),
        record_type=RecordType.SEMANTIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-diagnosis",
        confidence=0.88,
        importance=0.88,
        derived_from=[triage_id],
        workflow_id=INCIDENT,
        turn_context="step-2-diagnose",
    )
    print(f"  3. sre-diagnosis       [{diagnosis_id[:8]}] conf=0.88 derived<-triage (PASS, eff~0.45)")

    # ── 4. A near-duplicate write that triggers conflict detection
    #     against the bad_runbook. The conflicts[] field will populate. ──
    conflicting_id = await ml.add(
        content=(
            "Per 2019 wiki: HikariCP saturation always indicates traffic spike, just "
            "raise maxPoolSize without further investigation needed."
        ),
        record_type=RecordType.SEMANTIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-research",
        confidence=0.25,
        importance=0.25,
        metadata={"source": "wiki-2019-mirror"},
    )
    print(f"  4. sre-research dup    [{conflicting_id[:8]}] conf=0.25 (conflict expected vs runbook)")

    # ── 5. Remediation: fix applied; supersedes the bad runbook.
    #     High confidence, derived from diagnosis. ──
    remediation_id = await ml.add(
        content=(
            "Applied: patched OrderRepository.findByMerchant finally-block + set "
            "maxPoolSize=50. Deployed payment-svc:v2.14.3. Post-deploy: pool steady "
            "at 12/50, p95 240ms, zero timeouts in 30 min observation."
        ),
        record_type=RecordType.EPISODIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-remediation",
        confidence=0.92,
        importance=0.92,
        derived_from=[diagnosis_id],
        supersedes=bad_runbook_id,
        workflow_id=INCIDENT,
        turn_context="step-3-remediate",
    )
    print(f"  5. sre-remediation     [{remediation_id[:8]}] conf=0.92 supersedes bad-runbook (PASS)")
    await ml.record_outcome(
        record_id=remediation_id,
        success=True,
        description="payment-svc stable post-deploy",
    )

    # ── 6. Postmortem runbook (procedural). ──
    runbook_id = await ml.add(
        content=(
            "Runbook v2.0 — HikariCP leak in payment-svc: 1) verify symptom "
            "(active==max, no traffic spike); 2) inspect repository finally{} "
            "blocks; 3) patch leak; 4) raise pool to 50; 5) canary deploy; "
            "6) watch p95 + active connections for 30 min."
        ),
        record_type=RecordType.PROCEDURAL,
        namespace="/demo/runbooks",
        session_id=SESSION,
        created_by="sre-postmortem",
        confidence=0.85,
        importance=0.85,
        derived_from=[remediation_id],
        workflow_id=INCIDENT,
    )
    print(f"  6. sre-postmortem      [{runbook_id[:8]}] conf=0.85 (PASS)")

    # ── 7. PII-bearing record: a customer report referenced by the
    #     triage hypothesis. Cascades will fire on RTBF since the
    #     diagnosis chain transitively derives from this. ──
    pii_id = await ml.add(
        content=(
            "Customer report (PII): customer email john.doe@example.com (acct "
            "12345) reported 502 at checkout 10:23 UTC. Used as initial evidence "
            "for incident severity."
        ),
        record_type=RecordType.EPISODIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-intake",
        confidence=0.70,
        importance=0.70,
        workflow_id=INCIDENT,
        metadata={"contains_pii": True, "rtbf_target": True},
    )
    print(f"  7. PII (RTBF target)   [{pii_id[:8]}] conf=0.70 (forget me on demo)")
    # Re-derive triage from PII so the cascade tree exists
    pii_link_id = await ml.add(
        content="Triage cross-reference: see customer report for severity context.",
        record_type=RecordType.EPISODIC,
        namespace=NS,
        session_id=SESSION,
        created_by="sre-triage",
        confidence=0.50,
        importance=0.50,
        derived_from=[pii_id, triage_id],
        workflow_id=INCIDENT,
        metadata={"links_pii": True},
    )
    print(f"     pii cross-ref       [{pii_link_id[:8]}] derives from PII + triage")

    # ── 8. Multi-agent corroboration: a second diagnosis from a peer agent
    #     (multi-agent bonus in MQS / multi-source story). ──
    corroboration_id = await ml.add(
        content=(
            "Confirmed by jvm-profiler agent: HeapDump analysis shows 40 leaked "
            "HikariProxyConnection instances rooted in OrderRepository. Matches "
            "sre-diagnosis hypothesis."
        ),
        record_type=RecordType.SEMANTIC,
        namespace=NS,
        session_id=SESSION,
        created_by="jvm-profiler",
        confidence=0.90,
        importance=0.90,
        derived_from=[diagnosis_id],
        workflow_id=INCIDENT,
    )
    print(f"  8. jvm-profiler        [{corroboration_id[:8]}] conf=0.90 corroborates diagnosis (PASS)")

    # ── 9. Independent high-confidence reference (no chain back to triage).
    #     Demonstrates a PASS in contrast to the chain-bounded FLAGs. ──
    independent_id = await ml.add(
        content=(
            "Verified runbook (CHANGE-2026-0428): HikariCP leak signatures and "
            "the canonical fix pattern. Reviewed by 2 SREs and tested on staging."
        ),
        record_type=RecordType.PROCEDURAL,
        namespace="/demo/runbooks",
        session_id=SESSION,
        created_by="sre-knowledge-base",
        confidence=0.95,
        importance=0.95,
        metadata={"reviewed_by": ["sre-1", "sre-2"], "verified": True},
    )
    print(f"  9. independent ref     [{independent_id[:8]}] conf=0.95 (PASS, no upstream)")

    # ── Summary search to display flag distribution. ──
    print("\n--- Verification: search across namespace, show flags + MQS ---\n")
    results = await ml.search(
        query="HikariCP pool",
        namespace=None,  # cross-namespace for full demo spread
        top_k=15,
        confidence_policy={"min_threshold": 0.30, "flag_threshold": 0.65},
    )
    flags: dict[str, int] = {"PASS": 0, "FLAG": 0, "FILTER": 0, "?": 0}
    for r in results.records:
        flag = getattr(r, "confidence_flag", None) or "?"
        flags[flag] = flags.get(flag, 0) + 1
        mqs = getattr(r, "quality_score", None)
        conflicts_n = len(getattr(r, "conflicts", []) or [])
        print(
            f"  [{r.id[:8]}] conf={(r.confidence or 0):.2f} "
            f"flag={flag:<6} mqs={mqs} conflicts={conflicts_n} "
            f"by={r.created_by}"
        )
    print(f"\n  flag spread: {flags}")

    await ml.close()
    if chain_store is not None:
        await chain_store.close()

    print(
        f"\nDone. ids exported below for Lane 2:\n"
        f"  triage_id       = {triage_id}\n"
        f"  bad_runbook_id  = {bad_runbook_id}\n"
        f"  diagnosis_id    = {diagnosis_id}\n"
        f"  conflicting_id  = {conflicting_id}\n"
        f"  remediation_id  = {remediation_id}\n"
        f"  runbook_id      = {runbook_id}\n"
        f"  pii_id          = {pii_id}  (RTBF target)\n  pii_link_id     = {pii_link_id}\n"
        f"  corroboration_id= {corroboration_id}\n  independent_id  = {independent_id}\n"
    )


if __name__ == "__main__":
    asyncio.run(seed())
