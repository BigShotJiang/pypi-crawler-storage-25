#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""C4 — validate Bedrock as a first-class memledger backend.

Exercises three Bedrock-coupled memledger surfaces against a real AWS
account (read-only embed + invoke; no storage writes outside a local
pgvector):

  1. EmbeddingProvider with provider="bedrock" → Titan Text v2 (1024 dim)
     via LiteLLM. Confirms boto3 → Bedrock → LiteLLM → memledger embed
     path works end-to-end.
  2. LLMStrategy via litellm with a Bedrock Claude model — a write-policy
     gating call is the cheapest representative LLM-strategy invocation.
  3. RAGAS evaluator with $MEMLEDGER_JUDGE_MODEL pointed at a Bedrock
     Claude Sonnet — confirms the v1 "judge stays vendor-agnostic"
     promise holds when the judge runs on AWS.

Env (defaults shown):
    AWS_PROFILE                default
    AWS_DEFAULT_REGION         us-west-2
    BEDROCK_EMBED_MODEL        amazon.titan-embed-text-v2:0
    BEDROCK_CHAT_MODEL         us.anthropic.claude-sonnet-4-6
                                (cross-region inference-profile ID; Sonnet
                                 4.x is INFERENCE_PROFILE-only on Bedrock)
    MEMLEDGER_PG_DSN           postgresql://memledger:memledger@localhost:5433/memledger

Usage:
    python scripts/validate_bedrock.py
"""
from __future__ import annotations

import asyncio
import os
import sys


async def step1_embed() -> tuple[bool, str]:
    """EmbeddingProvider → Bedrock Titan v2."""
    from memledger.embeddings import EmbeddingProvider
    from memledger.models import EmbeddingConfig

    model = os.environ.get("BEDROCK_EMBED_MODEL", "amazon.titan-embed-text-v2:0")
    cfg = EmbeddingConfig(provider="bedrock", model=model, dimensions=1024)
    p = EmbeddingProvider(cfg)
    vec = await p.embed_single("Bedrock smoke: HikariCP pool exhaustion on payment-svc.")
    if not isinstance(vec, list) or len(vec) != 1024:
        return False, f"unexpected vector shape: type={type(vec)} len={len(vec) if hasattr(vec,'__len__') else '?'}"
    return True, f"Titan v2 → 1024-dim vector, first 3 dims: {vec[:3]}"


async def step2_chat() -> tuple[bool, str]:
    """LiteLLM → Bedrock Claude. One-shot completion."""
    try:
        import litellm
    except ImportError:
        return False, "litellm not installed (pip install memledger[bedrock])"

    model = os.environ.get("BEDROCK_CHAT_MODEL", "us.anthropic.claude-sonnet-4-6")
    prefixed = model if model.startswith("bedrock/") else f"bedrock/{model}"
    region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION") or "us-west-2"
    try:
        resp = await litellm.acompletion(
            model=prefixed,
            messages=[{"role": "user", "content": "Reply with a single word: ok"}],
            max_tokens=10,
            temperature=0.0,
            aws_region_name=region,
        )
        out = (resp.choices[0].message.content or "").strip()
        return True, f"Claude → {out!r} (region={region})"
    except Exception as e:
        return False, f"Bedrock chat failed: {type(e).__name__}: {e}"


async def step3_ragas_judge_smoke() -> tuple[bool, str]:
    """RAGAS evaluator with a Bedrock Claude judge — single record."""
    judge = os.environ.get(
        "MEMLEDGER_JUDGE_MODEL",
        "bedrock/us.anthropic.claude-sonnet-4-6",
    )
    try:
        from evaluators.attribution_integrity_ragas import evaluate_mai_ragas
    except Exception as e:
        return False, f"ragas import failed (need [eval] extra): {e}"

    sample_record = {
        "id": "ragas-smoke-1",
        "content": "Bedrock smoke: well-attributed memory.",
        "namespace": "/smoke",
        "created_by": "smoke-agent",
        "confidence": 0.9,
        "session_id": "bedrock-validate",
        "derived_from": [],
        "hedged": False,
    }
    try:
        res = evaluate_mai_ragas([sample_record], judge_model=judge)
        return True, f"RAGAS judge={judge} → score={res.score} passed={res.passed}"
    except Exception as e:
        return False, f"RAGAS smoke failed (probably model-access related): {type(e).__name__}: {e}"


async def main() -> int:
    print("=" * 64)
    print("C4 — Bedrock first-class validation")
    print("=" * 64)

    region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION") or "us-west-2"
    print(f"region: {region}")
    print(f"profile: {os.environ.get('AWS_PROFILE', '(default)')}")
    print()

    results: list[tuple[str, bool, str]] = []
    for label, fn in [
        ("1. Bedrock Titan v2 embed via memledger.EmbeddingProvider", step1_embed),
        ("2. Bedrock Claude chat via LiteLLM", step2_chat),
        ("3. RAGAS judge via Bedrock Claude (vendor-agnostic check)", step3_ragas_judge_smoke),
    ]:
        print(f"--- {label} ---")
        ok, msg = await fn()
        sym = "PASS" if ok else "FAIL"
        print(f"  [{sym}] {msg}")
        print()
        results.append((label, ok, msg))

    print("=" * 64)
    failed = [r for r in results if not r[1]]
    if failed:
        print(f"FAIL — {len(failed)}/{len(results)} step(s) failed")
        for label, _, msg in failed:
            print(f"  - {label}\n    {msg}")
        return 1
    print(f"PASS — {len(results)}/{len(results)} steps validated against Bedrock.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
