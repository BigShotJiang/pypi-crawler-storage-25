# memledger on AWS Bedrock

memledger is provider-agnostic by design — embeddings and LLM strategies
both go through LiteLLM, which dispatches to whichever Bedrock model the
caller selects. This page documents the AWS-native v2 path.

## Quickstart

```bash
pip install memledger[aws]
```

The `[aws]` extra pulls `boto3`, `asyncpg`, `pgvector`, `opensearch-py`
and the LiteLLM-side bedrock support — the full Aurora + OpenSearch +
DynamoDB + Bedrock surface in one install.

## Embeddings — Titan Text v2

```python
from memledger import Memledger
from memledger.models import EmbeddingConfig

ml = await Memledger.create(
    backend_name="pgvector",
    connection_string="postgresql://...@your-aurora.cluster-xxx.us-west-2.rds.amazonaws.com:5432/memledger",
    embedding_config=EmbeddingConfig(
        provider="bedrock",
        model="amazon.titan-embed-text-v2:0",
        dimensions=1024,
    ),
)
```

Titan v2 is the v2 default. 1024 dims; the pgvector / OpenSearch
backends auto-create their vector column at this width.

## LLM strategies — Claude Sonnet via Bedrock

memledger's strategy layer (write-policy gating, conflict resolution,
LLM-judge eval) accepts any LiteLLM model string. For Bedrock, use
the cross-region inference-profile ID — Sonnet 4.x is
`INFERENCE_PROFILE`-only on Bedrock and cannot be invoked by raw model
ID:

```python
from memledger.strategies import LLMConfig

cfg = LLMConfig(
    model="bedrock/us.anthropic.claude-sonnet-4-6",
    region="us-west-2",
    temperature=0.0,
)
```

The `bedrock/` prefix is the LiteLLM provider hint; the
`us.anthropic.claude-sonnet-4-6` part is Bedrock's cross-region profile
ID for Sonnet 4.6 in the US partition.

## RAGAS LLM-as-judge

The Tier-3 evaluator (`evaluators/attribution_integrity_ragas.py`) reads
`$MEMLEDGER_JUDGE_MODEL`:

```bash
export MEMLEDGER_JUDGE_MODEL=bedrock/us.anthropic.claude-sonnet-4-6
python scripts/eval_pass.py
```

Same string; same dispatch path. The judge stays vendor-agnostic — swap
to `openai/gpt-4o-mini` or `anthropic/claude-...` and nothing else
changes.

## IAM / IRSA

`bedrock:InvokeModel` on the model resource (or `bedrock:InvokeModel*`
across the inference profile and its underlying foundation model). See
[examples/aws/provision-aurora.sh](../examples/aws/provision-aurora.sh)
for the IRSA-ready Aurora role pattern; Bedrock follows the same
template:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["bedrock:InvokeModel"],
    "Resource": [
      "arn:aws:bedrock:us-west-2::foundation-model/amazon.titan-embed-text-v2:0",
      "arn:aws:bedrock:us-west-2:<acct>:inference-profile/us.anthropic.claude-sonnet-4-6",
      "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-6-*",
      "arn:aws:bedrock:us-east-2::foundation-model/anthropic.claude-sonnet-4-6-*"
    ]
  }]
}
```

The cross-region profile fans out across us-east-1 / us-east-2 / us-west-2
under the hood, so the policy needs all three foundation-model ARNs.

## Validation

```bash
python scripts/validate_bedrock.py
```

Three steps:

1. `EmbeddingProvider` → Titan v2 → 1024-dim vector
2. LiteLLM → Bedrock Claude Sonnet → one-token chat completion
3. RAGAS evaluator → Bedrock Sonnet judge → MAI score on a smoke record

All three should print `[PASS]` against an account with Bedrock model
access enabled in `us-west-2`.

## Notes

- `amazon.titan-embed-text-v2:0` is `ON_DEMAND`-supported. No profile
  needed for embeddings.
- Claude 3.x Sonnet models in the account are flagged `LEGACY` and may
  fail with a "not actively used in 30 days" error. Use Sonnet 4.x via
  the cross-region profile.
- Bedrock requires the model to be enabled in the AWS console
  (`Bedrock → Model access → Manage access`) before `InvokeModel` calls
  succeed.
