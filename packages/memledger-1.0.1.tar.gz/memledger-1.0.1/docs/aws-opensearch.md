# memledger on AWS OpenSearch

OpenSearch is memledger's **secondary** backend in the v2 AWS-native
story — Aurora + pgvector remains the primary path. Use OpenSearch
when you need:

- **Hybrid search** out-of-the-box (vector + BM25 + RRF)
- **Multi-AZ HA** without managing a Postgres cluster
- **Cross-account / cross-region** read fan-out

## Quickstart

```bash
pip install memledger[aws]
./examples/aws/provision-opensearch.sh memledger-demo us-west-2
```

The provision script creates a managed OpenSearch 2.13 domain with
fine-grained access tied to your IAM principal, k-NN enabled,
node-to-node + at-rest encryption, and TLS-only access. ~10 min
provisioning time.

## Memledger config

```python
from memledger import Memledger

ml = await Memledger.create(
    backend_name="opensearch",
    backend_config={
        "hosts": ["https://search-memledger-demo-...es.amazonaws.com"],
        "auth_type": "aws_sigv4",
        "region": "us-west-2",
        "index_name": "memledger-memory",
        "engine": "faiss",          # default; nmslib also supported
        "space_type": "l2",         # default with faiss; see note below
        "dimensions": 1024,         # match your embedding model
    },
)
```

### Engine + space_type matrix

| Engine | space_type | Notes |
|---|---|---|
| `faiss` | `l2` (default) | OpenSearch 2.x + Serverless supported. Normalised embeddings rank identically under L2 and cosine, so this is functionally equivalent for Titan/bge-small. |
| `faiss` | `innerproduct` | Strictly proportional to dot product. |
| `nmslib` | `cosinesimil` | Legacy. Not supported on Serverless. Will be removed in a future OpenSearch major. |

If you specifically want cosine arithmetic with faiss, normalise the
embeddings client-side and stick with `l2`. Bedrock Titan v2 and most
sentence-transformers models output normalised vectors by default.

## v1 governance fields in the index

The index mapping declares first-class fields for v1 governance:

- `confidence` (float) — declared confidence at write time
- `confidence_flag` (keyword) — `PASS` / `FLAG` / `FILTER` from the gate
- `quality_score` (integer) — composite MQS 0–100
- `hedged` (boolean) — explicit hedge marker
- `conflicts` (nested) — `{ existing_id, similarity, resolution }` per
  near-duplicate detected at write time
- `derived_from`, `supersedes`, `created_by`, `session_id`,
  `workflow_id`, `triggered_by` — provenance and lineage

These are filterable + aggregatable from the OpenSearch console for
governance reporting.

## IAM policy for SigV4 auth

Attach to the IRSA role used by your agent pods:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["es:ESHttp*"],
    "Resource": "arn:aws:es:us-west-2:<acct>:domain/memledger-demo/*"
  }]
}
```

For fine-grained control, also list the principal in the domain access
policy. The provision script sets that to the script-runner's IAM ARN
by default.

## Validation

```bash
AWS_DEFAULT_REGION=us-west-2 \
OPENSEARCH_HOST=https://search-memledger-demo-...es.amazonaws.com \
OPENSEARCH_AUTH_TYPE=aws_sigv4 \
python scripts/validate_opensearch.py
```

Five-step end-to-end:

1. Initialize + create index with v1 mappings
2. Add 4 records (with `derived_from`, `conflicts`, `hedged`)
3. Vector search round-trip
4. Hybrid search (vector + BM25 RRF) round-trip
5. Cleanup test index

All five should print `PASS` on a domain with k-NN enabled.

## Notes

- Managed domain (not Serverless) is the v2 default. Serverless uses
  a different SigV4 service identifier (`aoss` vs `es`); add it in
  v2.1 once memledger detects + signs against both.
- `t3.small.search` is the cheapest viable instance type
  (~$0.04/hr). Demo + dev only — production should use at least
  `r6g.large.search` or graviton burstable.
- Hybrid search uses Reciprocal Rank Fusion with `k=60`; vector and
  text each fetch `top_k * 3` candidates then merge.
