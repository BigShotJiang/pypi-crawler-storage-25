# SPDX-License-Identifier: Apache-2.0
"""F11 — Code-Based Structural Evaluator (Option B).

Independently evaluates Memory Attribution Integrity by reading OTEL span
attributes directly. No LLM involved. Gives the demo a second, structurally-
independent judge on the same metric.

When Options A (LLM-judge / deterministic) and B (this) agree, the score is
defensible. When they disagree, you've surfaced a genuinely ambiguous case.

Checks (from spec):
  1. Is memledger.memory.confidence populated on every retrieved memory?
  2. Is it >= 0.6?
  3. Is memledger.memory.source_agent_id present?
  4. Is chain depth <= 5?
  5. Are there memories with confidence < 0.4 retrieved without hedged=true?

Reads from:
  - OTEL span attributes (memledger.memory.*)
  - Phoenix trace store export (JSON)
  - CloudWatch OTEL log export (JSON)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class StructuralCheckResult:
    """Result of a single structural check."""
    check_name: str
    passed: bool
    detail: str
    weight: float = 1.0  # How much this check contributes to final score


@dataclass
class StructuralEvalResult:
    """Result of the full structural evaluation."""
    score: float  # 0.0-1.0
    passed: bool  # score >= threshold
    threshold: float = 0.7
    checks: list[StructuralCheckResult] = field(default_factory=list)
    explanation: str = ""
    span_count: int = 0

    def to_dict(self) -> dict:
        return {
            "score": round(self.score, 4),
            "passed": self.passed,
            "threshold": self.threshold,
            "explanation": self.explanation,
            "span_count": self.span_count,
            "checks": [
                {"name": c.check_name, "passed": c.passed, "detail": c.detail, "weight": c.weight}
                for c in self.checks
            ],
        }


def _extract_memory_spans(trace_data: list[dict]) -> list[dict]:
    """Extract memory-related spans from a trace export.

    Works with both Phoenix JSON export and CloudWatch OTEL JSON format.
    A memory span has memledger.memory.* attributes.
    """
    memory_spans = []
    for span in trace_data:
        # Try multiple attribute locations:
        # 1. Nested under "attributes" (OTEL export format)
        # 2. Nested under "resource.attributes"
        # 3. Flat at top level (direct span dict or evaluate_from_memory_records)
        attrs = span.get("attributes", {})
        if not any(k.startswith("memledger.memory.") for k in attrs):
            attrs = span.get("resource", {}).get("attributes", {}) if "resource" in span else {}
        if not any(k.startswith("memledger.memory.") for k in attrs):
            # Check if attributes are at the top level
            if any(k.startswith("memledger.memory.") for k in span):
                attrs = span

        if any(k.startswith("memledger.memory.") for k in attrs):
            memory_spans.append(attrs)
        elif span.get("name", "").startswith("memledger.memory."):
            memory_spans.append(span)

    return memory_spans


def evaluate_structural(
    trace_data: list[dict],
    threshold: float = 0.7,
) -> StructuralEvalResult:
    """Evaluate Memory Attribution Integrity structurally from OTEL spans.

    Args:
        trace_data: List of span dicts from Phoenix/CloudWatch export.
                    Each span should have attributes with memledger.memory.* keys.
        threshold: Pass/fail threshold (default 0.7).

    Returns:
        StructuralEvalResult with score, checks, and explanation.
    """
    spans = _extract_memory_spans(trace_data)

    if not spans:
        return StructuralEvalResult(
            score=0.0,
            passed=False,
            threshold=threshold,
            explanation="No memory spans found in trace data.",
            span_count=0,
        )

    checks: list[StructuralCheckResult] = []
    total_weight = 0.0
    weighted_pass = 0.0

    # --- Check 1: confidence populated on every memory span ---
    conf_populated = sum(
        1 for s in spans
        if s.get("memledger.memory.confidence") is not None
    )
    conf_ratio = conf_populated / len(spans)
    check1 = StructuralCheckResult(
        check_name="confidence_populated",
        passed=conf_ratio >= 0.9,
        detail=f"{conf_populated}/{len(spans)} spans have confidence ({conf_ratio:.0%})",
        weight=2.0,
    )
    checks.append(check1)
    total_weight += check1.weight
    if check1.passed:
        weighted_pass += check1.weight

    # --- Check 2: confidence >= 0.6 on retrieved memories ---
    conf_values = [
        s.get("memledger.memory.confidence", 0.5)
        for s in spans
        if s.get("memledger.memory.operation") in ("search", "recall", "add")
    ]
    if conf_values:
        above_06 = sum(1 for c in conf_values if c >= 0.6)
        above_ratio = above_06 / len(conf_values)
    else:
        above_ratio = 0.0
    check2 = StructuralCheckResult(
        check_name="confidence_above_threshold",
        passed=above_ratio >= 0.7,
        detail=f"{above_ratio:.0%} of memories have confidence >= 0.6",
        weight=2.0,
    )
    checks.append(check2)
    total_weight += check2.weight
    if check2.passed:
        weighted_pass += check2.weight

    # --- Check 3: source_agent_id present ---
    agent_populated = sum(
        1 for s in spans
        if s.get("memledger.memory.source_agent_id") not in (None, "", "unknown")
    )
    agent_ratio = agent_populated / len(spans)
    check3 = StructuralCheckResult(
        check_name="source_agent_present",
        passed=agent_ratio >= 0.9,
        detail=f"{agent_populated}/{len(spans)} spans have source_agent_id ({agent_ratio:.0%})",
        weight=2.0,
    )
    checks.append(check3)
    total_weight += check3.weight
    if check3.passed:
        weighted_pass += check3.weight

    # --- Check 4: chain depth <= 5 ---
    parent_ids_spans = [
        s for s in spans
        if s.get("memledger.memory.parent_ids")
    ]
    max_chain_depth = 0
    for s in parent_ids_spans:
        pids = s.get("memledger.memory.parent_ids", "[]")
        if isinstance(pids, str):
            try:
                pids = json.loads(pids)
            except (json.JSONDecodeError, TypeError):
                pids = []
        max_chain_depth = max(max_chain_depth, len(pids) if isinstance(pids, list) else 0)

    check4 = StructuralCheckResult(
        check_name="chain_depth_bounded",
        passed=max_chain_depth <= 5,
        detail=f"Max observed chain depth: {max_chain_depth} (limit: 5)",
        weight=1.0,
    )
    checks.append(check4)
    total_weight += check4.weight
    if check4.passed:
        weighted_pass += check4.weight

    # --- Check 5: no low-confidence memories without hedging ---
    low_conf_unhedged = 0
    for s in spans:
        conf = s.get("memledger.memory.confidence", 0.5)
        hedged = s.get("memledger.memory.hedged", False)
        op = s.get("memledger.memory.operation", "")
        # Only check retrieved memories (search/recall), not writes
        if op in ("search", "recall") and conf < 0.4 and not hedged:
            low_conf_unhedged += 1

    check5 = StructuralCheckResult(
        check_name="no_low_confidence_unhedged",
        passed=low_conf_unhedged == 0,
        detail=f"{low_conf_unhedged} low-confidence memories retrieved without hedging flag",
        weight=3.0,  # Heaviest weight — this is the critical safety check
    )
    checks.append(check5)
    total_weight += check5.weight
    if check5.passed:
        weighted_pass += check5.weight

    # --- Compute final score ---
    score = weighted_pass / total_weight if total_weight > 0 else 0.0
    score = round(max(0.0, min(1.0, score)), 4)

    # Build explanation
    failed_checks = [c for c in checks if not c.passed]
    passed_checks = [c for c in checks if c.passed]

    explanation_parts = []
    if passed_checks:
        explanation_parts.append(
            f"Passed ({len(passed_checks)}/{len(checks)}): "
            + ", ".join(c.check_name for c in passed_checks)
        )
    if failed_checks:
        explanation_parts.append(
            f"Failed ({len(failed_checks)}/{len(checks)}): "
            + "; ".join(f"{c.check_name} — {c.detail}" for c in failed_checks)
        )

    return StructuralEvalResult(
        score=score,
        passed=score >= threshold,
        threshold=threshold,
        checks=checks,
        explanation=". ".join(explanation_parts),
        span_count=len(spans),
    )


def evaluate_from_file(trace_file: str, threshold: float = 0.7) -> StructuralEvalResult:
    """Load trace data from a JSON file and evaluate."""
    with open(trace_file) as f:
        trace_data = json.load(f)
    if isinstance(trace_data, dict):
        # Handle wrapped formats
        trace_data = trace_data.get("spans", trace_data.get("data", [trace_data]))
    return evaluate_structural(trace_data, threshold)


def evaluate_from_memory_records(
    records: list[dict],
    threshold: float = 0.7,
) -> StructuralEvalResult:
    """Evaluate directly from memory record dicts (for testing without OTEL).

    Converts record dicts to span-like format and runs the structural evaluator.
    """
    spans = []
    for r in records:
        span = {
            "memledger.memory.id": r.get("id", ""),
            "memledger.memory.type": r.get("record_type", "semantic"),
            "memledger.memory.confidence": r.get("confidence", r.get("importance", 0.5)),
            "memledger.memory.source_agent_id": r.get("created_by", ""),
            "memledger.memory.session_id": r.get("session_id", ""),
            "memledger.memory.parent_ids": json.dumps(r.get("derived_from", [])),
            "memledger.memory.namespace": r.get("namespace", "/"),
            "memledger.memory.operation": "search",  # Treat as retrieved memories
            "memledger.memory.hedged": r.get("hedged", False),
        }
        spans.append(span)

    result = evaluate_structural(spans, threshold)

    # Emit a Phoenix EVALUATOR span so the structural tier shows up in the
    # demo dashboard alongside the deterministic and RAGAS tiers.
    try:
        from opentelemetry import trace as _trace
        tracer = _trace.get_tracer("memledger.evaluators")
        with tracer.start_as_current_span("evaluators.mai_structural") as span:
            span.set_attribute("openinference.span.kind", "EVALUATOR")
            span.set_attribute("eval.name", "memory_attribution_integrity_structural")
            span.set_attribute("eval.score", result.score)
            span.set_attribute("eval.passed", result.passed)
            span.set_attribute("eval.outcome", "pass" if result.passed else "fail")
            span.set_attribute("eval.framework", "structural")
            rec_ids = ",".join(r.get("id", "") for r in records if r.get("id"))
            if rec_ids:
                span.set_attribute("eval.record_ids", rec_ids)
            if records:
                sid = records[0].get("session_id")
                if sid:
                    span.set_attribute("session.id", sid)
    except Exception:
        pass

    return result


# CLI entry point
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python attribution_integrity_structural.py <trace_file.json> [threshold]")
        sys.exit(1)

    trace_file = sys.argv[1]
    threshold = float(sys.argv[2]) if len(sys.argv) > 2 else 0.7

    result = evaluate_from_file(trace_file, threshold)
    print(json.dumps(result.to_dict(), indent=2))
    print(f"\nScore: {result.score:.4f} {'PASS' if result.passed else 'FAIL'} (threshold: {threshold})")
