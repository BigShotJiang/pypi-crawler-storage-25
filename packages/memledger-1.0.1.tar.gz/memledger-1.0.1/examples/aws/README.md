# memledger on AWS — Aurora provisioning

`provision-aurora.sh` spins up an Aurora PostgreSQL v15 cluster preconfigured
for memledger (pgvector, IAM auth, IRSA-ready IAM role, K8s Secret stub).

The Thursday demo runs against in-cluster pgvector / open-source Postgres by
default. Run this script when you (or a customer) want to flip the same
deployment to Aurora — no memledger code changes required.

## Quick start

```bash
export AURORA_MASTER_PASSWORD='<16+ chars, no /@" >'
./provision-aurora.sh memledger-demo us-west-2
```

Takes ~10 minutes. Idempotent — re-running against an existing cluster ID is
a no-op for already-created resources.

## What it creates

| Resource | Name |
|---|---|
| DB cluster parameter group | `<cluster-id>-pg` (pgvector preloaded) |
| Aurora cluster | `<cluster-id>` (engine `aurora-postgresql` 15.x, IAM auth on) |
| Writer instance | `<cluster-id>-writer` (`db.r6g.large` default) |
| Security group | `<cluster-id>-sg` (5432 from VPC CIDR) |
| IAM role | `<cluster-id>-irsa` (rds-db:connect for the master user) |
| K8s Secret manifest | `./aurora-dsn-secret.yaml` |

## Switching memledger to Aurora

1. Run the script, capture the endpoint it prints.
2. Connect once and enable the extension:
   ```sql
   CREATE EXTENSION IF NOT EXISTS vector;
   ```
3. Bind the IRSA role to your agent ServiceAccount (update the role's trust
   policy with your cluster's OIDC provider).
4. Update `memledger.yaml`:
   ```yaml
   backend:
     dsn: $AURORA_DSN     # or use iam_auth: true + iam_role: <role-arn>
   ```

## Teardown

Deliberately not automated — the script never deletes anything. Run
`aws rds delete-db-instance` / `delete-db-cluster` /
`delete-db-cluster-parameter-group` manually when you're ready.
