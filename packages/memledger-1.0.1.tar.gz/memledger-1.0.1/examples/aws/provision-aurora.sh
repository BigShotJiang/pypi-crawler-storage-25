#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
#
# provision-aurora.sh — idempotent Aurora PostgreSQL provisioning for memledger.
#
# Creates (or reuses if already present):
#   - DB cluster parameter group with pgvector preloaded
#   - Aurora PostgreSQL v15 cluster with IAM auth enabled
#   - One Aurora writer instance
#   - Security group allowing 5432 from a caller-supplied CIDR (default: VPC CIDR)
#   - IAM role + policy for IRSA / pod-level rds-db:connect
#   - Kubernetes Secret manifest written to ./aurora-dsn-secret.yaml
#
# Usage:
#   ./provision-aurora.sh <cluster-id> <region> [master-username] [allowed-cidr]
#
# Example:
#   ./provision-aurora.sh memledger-demo us-west-2
#
# Required env (one of):
#   AURORA_MASTER_PASSWORD            — master password (preferred)
# OR
#   AWS_SECRETS_MANAGER_PASSWORD_ARN  — Secrets Manager ARN with the password
#
# Pre-reqs: aws CLI v2 logged in, jq, an existing default VPC + subnets.
#
# Demo flow:
#   $ export AURORA_MASTER_PASSWORD='...'   # 16+ chars, no '/@" '
#   $ ./provision-aurora.sh memledger-demo us-west-2
#   ... ~10 min ...
#   $ kubectl apply -f ./aurora-dsn-secret.yaml
#   # update memledger.yaml: backend.dsn_secret_ref: aurora-dsn
#
# To tear down (NOT done by this script — explicit by design):
#   aws rds delete-db-instance      --db-instance-identifier <cluster-id>-writer --skip-final-snapshot
#   aws rds delete-db-cluster       --db-cluster-identifier  <cluster-id>        --skip-final-snapshot
#   aws rds delete-db-cluster-parameter-group --db-cluster-parameter-group-name <cluster-id>-pg

set -euo pipefail

CLUSTER_ID="${1:-}"
REGION="${2:-}"
MASTER_USER="${3:-memledger}"
ALLOWED_CIDR="${4:-}"

if [[ -z "$CLUSTER_ID" || -z "$REGION" ]]; then
  echo "Usage: $0 <cluster-id> <region> [master-username] [allowed-cidr]" >&2
  exit 2
fi

ENGINE_VERSION="${AURORA_ENGINE_VERSION:-15.4}"
INSTANCE_CLASS="${AURORA_INSTANCE_CLASS:-db.r6g.large}"
PG_NAME="${CLUSTER_ID}-pg"
SG_NAME="${CLUSTER_ID}-sg"
ROLE_NAME="${CLUSTER_ID}-irsa"
INSTANCE_ID="${CLUSTER_ID}-writer"

log() { printf '[provision-aurora] %s\n' "$*" >&2; }

# Resolve password
if [[ -n "${AURORA_MASTER_PASSWORD:-}" ]]; then
  MASTER_PW="$AURORA_MASTER_PASSWORD"
elif [[ -n "${AWS_SECRETS_MANAGER_PASSWORD_ARN:-}" ]]; then
  MASTER_PW=$(aws secretsmanager get-secret-value \
    --region "$REGION" \
    --secret-id "$AWS_SECRETS_MANAGER_PASSWORD_ARN" \
    --query SecretString --output text)
else
  echo "Set AURORA_MASTER_PASSWORD or AWS_SECRETS_MANAGER_PASSWORD_ARN." >&2
  exit 2
fi

# 1. Default VPC + CIDR
VPC_ID=$(aws ec2 describe-vpcs --region "$REGION" \
  --filters Name=is-default,Values=true \
  --query 'Vpcs[0].VpcId' --output text)
if [[ "$VPC_ID" == "None" || -z "$VPC_ID" ]]; then
  echo "No default VPC in $REGION. Set one or extend this script." >&2
  exit 1
fi
VPC_CIDR=$(aws ec2 describe-vpcs --region "$REGION" \
  --vpc-ids "$VPC_ID" --query 'Vpcs[0].CidrBlock' --output text)
ALLOWED_CIDR="${ALLOWED_CIDR:-$VPC_CIDR}"
log "VPC=$VPC_ID CIDR=$VPC_CIDR allowed=$ALLOWED_CIDR"

# 2. Cluster parameter group with pgvector
if ! aws rds describe-db-cluster-parameter-groups --region "$REGION" \
      --db-cluster-parameter-group-name "$PG_NAME" >/dev/null 2>&1; then
  log "Creating parameter group $PG_NAME"
  aws rds create-db-cluster-parameter-group --region "$REGION" \
    --db-cluster-parameter-group-name "$PG_NAME" \
    --db-parameter-group-family "aurora-postgresql15" \
    --description "memledger pgvector preload for $CLUSTER_ID" >/dev/null
  aws rds modify-db-cluster-parameter-group --region "$REGION" \
    --db-cluster-parameter-group-name "$PG_NAME" \
    --parameters "ParameterName=shared_preload_libraries,ParameterValue=vector,ApplyMethod=pending-reboot" \
    >/dev/null
else
  log "Parameter group $PG_NAME already exists"
fi

# 3. Security group
SG_ID=$(aws ec2 describe-security-groups --region "$REGION" \
  --filters Name=group-name,Values="$SG_NAME" Name=vpc-id,Values="$VPC_ID" \
  --query 'SecurityGroups[0].GroupId' --output text 2>/dev/null || echo "None")
if [[ "$SG_ID" == "None" || -z "$SG_ID" ]]; then
  log "Creating security group $SG_NAME"
  SG_ID=$(aws ec2 create-security-group --region "$REGION" \
    --group-name "$SG_NAME" --vpc-id "$VPC_ID" \
    --description "memledger Aurora access" \
    --query 'GroupId' --output text)
  aws ec2 authorize-security-group-ingress --region "$REGION" \
    --group-id "$SG_ID" --protocol tcp --port 5432 --cidr "$ALLOWED_CIDR" >/dev/null || true
else
  log "Security group $SG_NAME already exists ($SG_ID)"
fi

# 4. Cluster
if ! aws rds describe-db-clusters --region "$REGION" \
      --db-cluster-identifier "$CLUSTER_ID" >/dev/null 2>&1; then
  log "Creating Aurora cluster $CLUSTER_ID (engine $ENGINE_VERSION) — ~5 min"
  aws rds create-db-cluster --region "$REGION" \
    --db-cluster-identifier "$CLUSTER_ID" \
    --engine aurora-postgresql --engine-version "$ENGINE_VERSION" \
    --master-username "$MASTER_USER" \
    --master-user-password "$MASTER_PW" \
    --db-cluster-parameter-group-name "$PG_NAME" \
    --vpc-security-group-ids "$SG_ID" \
    --enable-iam-database-authentication \
    --storage-encrypted \
    --database-name memledger >/dev/null
else
  log "Cluster $CLUSTER_ID already exists"
fi

# 5. Writer instance
if ! aws rds describe-db-instances --region "$REGION" \
      --db-instance-identifier "$INSTANCE_ID" >/dev/null 2>&1; then
  log "Creating writer instance $INSTANCE_ID ($INSTANCE_CLASS) — ~5 min"
  aws rds create-db-instance --region "$REGION" \
    --db-instance-identifier "$INSTANCE_ID" \
    --db-cluster-identifier "$CLUSTER_ID" \
    --engine aurora-postgresql \
    --db-instance-class "$INSTANCE_CLASS" >/dev/null
else
  log "Instance $INSTANCE_ID already exists"
fi

log "Waiting for cluster + instance to become available…"
aws rds wait db-instance-available --region "$REGION" --db-instance-identifier "$INSTANCE_ID"

ENDPOINT=$(aws rds describe-db-clusters --region "$REGION" \
  --db-cluster-identifier "$CLUSTER_ID" \
  --query 'DBClusters[0].Endpoint' --output text)
RESOURCE_ID=$(aws rds describe-db-clusters --region "$REGION" \
  --db-cluster-identifier "$CLUSTER_ID" \
  --query 'DBClusters[0].DbClusterResourceId' --output text)
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# 6. IAM role/policy for IRSA — rds-db:connect on this resource only
POLICY_DOC=$(cat <<JSON
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": "rds-db:connect",
    "Resource": "arn:aws:rds-db:${REGION}:${ACCOUNT_ID}:dbuser:${RESOURCE_ID}/${MASTER_USER}"
  }]
}
JSON
)

if ! aws iam get-role --role-name "$ROLE_NAME" >/dev/null 2>&1; then
  log "Creating IAM role $ROLE_NAME (trust policy left to caller — IRSA OIDC binding is cluster-specific)"
  TRUST=$(cat <<'JSON'
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"sts.amazonaws.com"},"Action":"sts:AssumeRole"}]}
JSON
)
  aws iam create-role --role-name "$ROLE_NAME" \
    --assume-role-policy-document "$TRUST" \
    --description "memledger Aurora IAM-auth for $CLUSTER_ID" >/dev/null
fi
aws iam put-role-policy --role-name "$ROLE_NAME" \
  --policy-name "${ROLE_NAME}-rds-connect" \
  --policy-document "$POLICY_DOC" >/dev/null
log "IAM role: arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}"
log "  NOTE: update the trust policy with your cluster's OIDC provider for IRSA."

# 7. K8s Secret manifest (DSN with password — for non-IAM-auth dev path)
DSN="postgresql://${MASTER_USER}:REPLACE_WITH_PASSWORD@${ENDPOINT}:5432/memledger?sslmode=require"
B64_DSN=$(printf '%s' "$DSN" | base64 | tr -d '\n')
cat > ./aurora-dsn-secret.yaml <<YAML
# Generated by provision-aurora.sh — DO NOT commit with the real password substituted.
# Replace REPLACE_WITH_PASSWORD before applying, or switch to IAM auth (preferred):
#   memledger.yaml: backend.iam_auth: true, backend.iam_role: ${ROLE_NAME}
apiVersion: v1
kind: Secret
metadata:
  name: aurora-dsn
type: Opaque
data:
  dsn: ${B64_DSN}
YAML

log ""
log "Done."
log "  Cluster endpoint : $ENDPOINT"
log "  Resource ID      : $RESOURCE_ID"
log "  IAM role         : arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}"
log "  K8s Secret stub  : ./aurora-dsn-secret.yaml"
log ""
log "Next: connect once and run: CREATE EXTENSION IF NOT EXISTS vector;"
