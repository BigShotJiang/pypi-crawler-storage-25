# SPDX-License-Identifier: Apache-2.0
"""Neo4jChainStore smoke — needs a running Neo4j 5.x at bolt://localhost:7687.

Quickstart:
    docker run -d --name memledger-neo4j \
        -p 7474:7474 -p 7687:7687 \
        -e NEO4J_AUTH=neo4j/memledger-dev \
        neo4j:5.27

Run:
    pytest tests/test_neo4j_chain_store.py -v -m neo4j

Skipped by default; opt in with `pytest -m neo4j`.
"""

from __future__ import annotations

import os
import uuid

import pytest

pytestmark = [pytest.mark.neo4j, pytest.mark.asyncio]


@pytest.fixture
async def store():
    """Yields a Neo4jChainStore connected to localhost. Cleans namespace after."""
    pytest.importorskip("neo4j")
    from memledger.provenance.neo4j_chain_store import Neo4jChainStore

    uri = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
    user = os.environ.get("NEO4J_USER", "neo4j")
    password = os.environ.get("NEO4J_PASSWORD", "memledger-dev")

    s = await Neo4jChainStore.from_uri(uri, auth=(user, password))
    await s.ensure_schema()

    test_ns = f"/test/neo4j-{uuid.uuid4().hex[:8]}"
    yield s, test_ns

    # Clean up nodes in the test namespace
    async with s._driver.session(database=s.database) as session:
        await session.run(
            "MATCH (m:Memory {namespace: $ns}) DETACH DELETE m",
            ns=test_ns,
        )
    await s.close()


def _record_stub(memory_id, namespace, *, confidence=0.8, derived_from=None, hedged=False, conflicts=None, supersedes=None):
    """Build a stub object that quacks like MemoryRecord enough for mirror_write."""
    from datetime import datetime
    from memledger.models import MemoryStatus

    class Stub:
        pass
    s = Stub()
    s.id = memory_id
    s.namespace = namespace
    s.confidence = confidence
    s.hedged = hedged
    s.status = MemoryStatus.ACTIVE
    s.created_by = "test-agent"
    s.created_at = datetime.utcnow()
    s.derived_from = derived_from or []
    s.supersedes = supersedes
    s.conflicts = conflicts or []
    return s


async def test_min_confidence_upstream_empty_chain(store):
    s, ns = store
    mid = f"orphan-{uuid.uuid4().hex[:8]}"
    await s.mirror_write(_record_stub(mid, ns, confidence=0.7))
    val = await s.min_confidence_upstream(mid)
    # No parents, so the result is the node's own confidence (it's in the path)
    assert val == 0.7


async def test_build_chain_three_hops(store):
    s, ns = store
    a = f"a-{uuid.uuid4().hex[:8]}"
    b = f"b-{uuid.uuid4().hex[:8]}"
    c = f"c-{uuid.uuid4().hex[:8]}"

    await s.mirror_write(_record_stub(a, ns, confidence=0.9))
    await s.mirror_write(_record_stub(b, ns, confidence=0.5, derived_from=[a]))
    await s.mirror_write(_record_stub(c, ns, confidence=0.8, derived_from=[b]))

    chain = await s.build_chain(c, direction="upstream", max_hops=10)
    assert chain.chain_depth >= 3
    assert chain.min_confidence == pytest.approx(0.5, abs=0.01)
    ids_in_chain = {h.memory_id for h in chain.chain}
    assert {a, b, c}.issubset(ids_in_chain)


async def test_min_conf_walks_chain(store):
    s, ns = store
    a = f"a-{uuid.uuid4().hex[:8]}"
    b = f"b-{uuid.uuid4().hex[:8]}"
    c = f"c-{uuid.uuid4().hex[:8]}"

    await s.mirror_write(_record_stub(a, ns, confidence=0.9))
    await s.mirror_write(_record_stub(b, ns, confidence=0.3, derived_from=[a]))  # weakest
    await s.mirror_write(_record_stub(c, ns, confidence=0.85, derived_from=[b]))

    val = await s.min_confidence_upstream(c)
    assert val == pytest.approx(0.3, abs=0.01)


async def test_conflict_edge_persisted(store):
    """E1 conflicts → :CONFLICTS relationship in Neo4j."""
    s, ns = store

    class ConflictStub:
        existing_id: str
        existing_content: str
        similarity: float

    a_id = f"a-{uuid.uuid4().hex[:8]}"
    b_id = f"b-{uuid.uuid4().hex[:8]}"
    await s.mirror_write(_record_stub(a_id, ns))

    c = ConflictStub()
    c.existing_id = a_id
    c.existing_content = "prior content"
    c.similarity = 0.91
    await s.mirror_write(_record_stub(b_id, ns, conflicts=[c]))

    async with s._driver.session(database=s.database) as session:
        result = await session.run(
            "MATCH (b:Memory {id:$bid})-[r:CONFLICTS]->(a:Memory {id:$aid}) RETURN r.similarity AS sim",
            bid=b_id,
            aid=a_id,
        )
        row = await result.single()
        assert row is not None
        assert row["sim"] == pytest.approx(0.91, abs=0.01)
