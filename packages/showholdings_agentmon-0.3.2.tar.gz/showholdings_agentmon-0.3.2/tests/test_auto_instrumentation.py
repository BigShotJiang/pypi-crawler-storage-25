from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Any

import pytest

from showholdings_agentmon import Monitor
from showholdings_agentmon import auto_instrumentation as ai


class DummyOpenAI:
    def create(self, **_kwargs: Any) -> dict[str, Any]:
        return {"id": "ok", "tool_calls": [{"name": "search_docs"}]}


class DummyAnthropic:
    def create(self, **_kwargs: Any) -> dict[str, Any]:
        return {"content": [{"type": "tool_use", "name": "fetch_profile"}]}


@dataclass
class _DummyToolCall:
    type: str
    name: str


@dataclass
class _DummyGeminiResponse:
    output: list[_DummyToolCall]


class DummyGemini:
    def generate_content(self, _prompt: str, **_kwargs: Any) -> _DummyGeminiResponse:
        return _DummyGeminiResponse(output=[_DummyToolCall(type="tool_call", name="rank_items")])


class DummyRequestsSession:
    def request(self, method: str, url: str, **_kwargs: Any) -> dict[str, Any]:
        return {"ok": True, "method": method, "url": url}


class DummyHttpxClient:
    def request(self, _method: str, _url: str, **_kwargs: Any) -> dict[str, Any]:
        raise TimeoutError("request timeout")


@pytest.fixture(autouse=True)
def _reset_auto_instrumentation() -> None:
    ai.reset_auto_instrumentation_for_testing()
    yield
    ai.reset_auto_instrumentation_for_testing()


def _build_monitor_calls(monkeypatch: pytest.MonkeyPatch) -> tuple[Monitor, list[tuple[str, dict[str, Any]]]]:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )
    calls: list[tuple[str, dict[str, Any]]] = []

    def fake_safe_post(path: str, payload: dict[str, Any]):
        calls.append((path, payload.copy()))
        if path == "/api/sdk/runs/start":
            return {"run_id": 200}
        if path == "/api/sdk/steps/start":
            return {"step_id": len([item for item in calls if item[0] == "/api/sdk/steps/start"])}
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)
    return monitor, calls


def test_auto_openai_llm_and_tool_use(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyOpenAI.create",
                kind="llm",
                provider="openai",
                step_name="OpenAI 呼叫",
                step_type="llm_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)
    with monitor.run(agent_name="general-agent"):
        DummyOpenAI().create(model="gpt-4o")

    step_starts = [payload for path, payload in calls if path == "/api/sdk/steps/start"]
    assert any(payload["step_type"] == "llm_call" for payload in step_starts)
    assert any(payload["step_type"] == "tool_call" for payload in step_starts)
    assert any(payload["metadata_json"]["instrumentation_source"] == "auto" for payload in step_starts)
    assert sum(1 for payload in step_starts if payload.get("step_name") == "執行中") == 0
    assert sum(1 for payload in step_starts if payload.get("step_type") == "llm_call") == 1


def test_auto_anthropic_llm_and_tool_use(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyAnthropic.create",
                kind="llm",
                provider="anthropic",
                step_name="Anthropic 呼叫",
                step_type="llm_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)
    with monitor.run(agent_name="general-agent"):
        DummyAnthropic().create(model="claude")

    step_starts = [payload for path, payload in calls if path == "/api/sdk/steps/start"]
    assert any(payload["step_type"] == "llm_call" for payload in step_starts)
    assert any(payload["step_type"] == "tool_call" for payload in step_starts)


def test_auto_gemini_llm_and_tool_use(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyGemini.generate_content",
                kind="llm",
                provider="gemini",
                step_name="Gemini 呼叫",
                step_type="llm_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)
    with monitor.run(agent_name="general-agent"):
        DummyGemini().generate_content("hello")

    step_starts = [payload for path, payload in calls if path == "/api/sdk/steps/start"]
    assert any(payload["step_type"] == "llm_call" for payload in step_starts)
    assert any(payload["step_type"] == "tool_call" for payload in step_starts)


def test_auto_requests_http_call(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyRequestsSession.request",
                kind="http",
                provider="requests",
                step_name="HTTP 呼叫",
                step_type="http_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)
    with monitor.run(agent_name="general-agent"):
        DummyRequestsSession().request("GET", "https://example.com/items")

    step_start = next(
        payload
        for path, payload in calls
        if path == "/api/sdk/steps/start" and payload.get("step_type") == "http_call"
    )
    assert step_start["step_type"] == "http_call"
    assert step_start["metadata_json"]["method"] == "GET"
    assert step_start["metadata_json"]["scheme"] == "https"
    assert step_start["metadata_json"]["host"] == "example.com"


def test_auto_http_timeout_reports_failed_and_reraises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyHttpxClient.request",
                kind="http",
                provider="httpx",
                step_name="HTTP 呼叫",
                step_type="http_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)

    with pytest.raises(TimeoutError):
        with monitor.run(agent_name="general-agent"):
            DummyHttpxClient().request("GET", "https://example.com/slow")

    step_end = next(
        payload
        for path, payload in calls
        if path == "/api/sdk/steps/end" and payload.get("error_message")
    )
    assert step_end["status"] == "failed"
    assert "timeout" in (step_end["error_message"] or "").lower()


def test_auto_sqlite_query_step(monkeypatch: pytest.MonkeyPatch) -> None:
    ai.enable_auto_instrumentation()
    monitor, calls = _build_monitor_calls(monkeypatch)

    with monitor.run(agent_name="general-agent"):
        conn = sqlite3.connect(":memory:")
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.fetchall()
        conn.close()

    step_start = next(
        payload
        for path, payload in calls
        if path == "/api/sdk/steps/start" and payload.get("step_type") == "db_query"
    )
    assert step_start["step_type"] == "db_query"
    assert step_start["metadata_json"]["db_adapter"] == "sqlite3"
    assert step_start["metadata_json"]["operation_type"] == "SELECT"


def test_fallback_step_not_kept_with_auto_step(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        ai,
        "_AUTO_PATCH_TARGETS",
        [
            ai._PatchSpec(
                path=f"{__name__}.DummyRequestsSession.request",
                kind="http",
                provider="requests",
                step_name="HTTP 呼叫",
                step_type="http_call",
            ),
        ],
    )
    ai.enable_auto_instrumentation()

    monitor, calls = _build_monitor_calls(monkeypatch)
    with monitor.run(agent_name="general-agent"):
        DummyRequestsSession().request("GET", "https://example.com/items")

    step_starts = [payload for path, payload in calls if path == "/api/sdk/steps/start"]
    step_ends = [payload for path, payload in calls if path == "/api/sdk/steps/end"]
    assert step_starts[0]["step_name"] == "HTTP 呼叫"
    assert all(payload.get("step_name") != "執行中" for payload in step_starts)
    assert len(step_starts) == len(step_ends)
    assert step_ends[0]["status"] == "success"
