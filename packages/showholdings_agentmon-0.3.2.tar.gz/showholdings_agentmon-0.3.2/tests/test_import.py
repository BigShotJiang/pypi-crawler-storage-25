from showholdings_agentmon import Monitor


def test_import_monitor() -> None:
    assert Monitor is not None
