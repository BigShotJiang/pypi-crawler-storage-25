"""Public monitoring interface."""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from types import TracebackType
from typing import Any

from .auto_instrumentation import (
    enable_auto_instrumentation,
    set_active_monitor,
    suppress_auto_instrumentation,
)
from .client import AgentMonClient
from .exceptions import AgentMonUsageError

logger = logging.getLogger(__name__)


@dataclass
class _RunContext:
    monitor: "Monitor"
    agent_name: str
    session_id: str | None = None
    channel_type: str = "generic"
    input_summary: str | None = None
    metadata_json: Any = None

    external_run_id: str | None = None
    started_monotonic: float | None = None
    run_id: int | None = None

    def __enter__(self) -> "_RunContext":
        self.external_run_id = str(uuid.uuid4())
        self.started_monotonic = time.monotonic()

        payload: dict[str, Any] = {
            "project_name": self.monitor.project_name,
            "agent_name": self.agent_name,
            "external_run_id": self.external_run_id,
            "channel_type": self.channel_type,
            "input_summary": self.input_summary,
            "metadata_json": self.metadata_json,
        }
        if self.session_id:
            payload["session_id"] = self.session_id

        data = self.monitor._safe_post("/api/sdk/runs/start", payload)
        if isinstance(data, dict):
            run_id = data.get("run_id")
            if isinstance(run_id, int):
                self.run_id = run_id

        self.monitor._active_run_context = self
        self.monitor._step_seq_no = 0
        self.monitor._reset_run_state()
        set_active_monitor(self.monitor)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        duration_ms = None
        if self.started_monotonic is not None:
            duration_ms = int((time.monotonic() - self.started_monotonic) * 1000)

        payload: dict[str, Any] = {
            "external_run_id": self.external_run_id,
            "duration_ms": duration_ms,
        }
        if self.run_id is not None:
            payload["run_id"] = self.run_id

        if exc_type is None:
            self.monitor._emit_fallback_step_if_needed()
            payload["status"] = "success"
            self.monitor._safe_post("/api/sdk/runs/end", payload)
            if self.monitor._active_run_context is self:
                self.monitor._active_run_context = None
                self.monitor._step_seq_no = 0
                self.monitor._reset_run_state()
                set_active_monitor(None)
            return False

        payload.update(
            {
                "status": "failed",
                "failure_reason_type": exc_type.__name__,
                "error_count": 1,
            }
        )
        self.monitor._emit_fallback_step_if_needed(exc_type, exc_value, traceback)
        self.monitor._safe_post("/api/sdk/runs/end", payload)
        if self.monitor._active_run_context is self:
            self.monitor._active_run_context = None
            self.monitor._step_seq_no = 0
            self.monitor._reset_run_state()
            set_active_monitor(None)
        return False


@dataclass
class _StepContext:
    monitor: "Monitor"
    step_name: str
    step_type: str = "processing"
    input_summary: str | None = None
    raw_input_masked: str | None = None
    metadata_json: Any = None
    is_fallback: bool = False

    seq_no: int | None = None
    step_id: int | None = None
    started_monotonic: float | None = None

    def __enter__(self) -> "_StepContext":
        run_context = self.monitor._active_run_context
        if run_context is None:
            raise AgentMonUsageError("monitor.step(...) must be used inside monitor.run(...)")

        if not self.is_fallback:
            self.monitor._on_real_step_started()

        self.monitor._step_seq_no += 1
        self.seq_no = self.monitor._step_seq_no
        self.started_monotonic = time.monotonic()

        payload: dict[str, Any] = {
            "external_run_id": run_context.external_run_id,
            "seq_no": self.seq_no,
            "step_name": self.step_name,
            "step_type": self.step_type,
            "input_summary": self.input_summary,
            "raw_input_masked": self.raw_input_masked,
            "metadata_json": self.metadata_json,
        }
        if run_context.run_id is not None:
            payload["run_id"] = run_context.run_id

        data = self.monitor._safe_post("/api/sdk/steps/start", payload)
        if isinstance(data, dict):
            step_id = data.get("step_id")
            if isinstance(step_id, int):
                self.step_id = step_id

        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        run_context = self.monitor._active_run_context
        if run_context is None:
            return False

        duration_ms = None
        if self.started_monotonic is not None:
            duration_ms = int((time.monotonic() - self.started_monotonic) * 1000)

        payload: dict[str, Any] = {
            "external_run_id": run_context.external_run_id,
            "seq_no": self.seq_no,
            "duration_ms": duration_ms,
            "output_summary": None,
            "token_count": None,
            "input_tokens": None,
            "output_tokens": None,
            "estimated_cost_usd": None,
            "metadata_json": self.metadata_json,
        }
        if run_context.run_id is not None:
            payload["run_id"] = run_context.run_id
        if self.step_id is not None:
            payload["step_id"] = self.step_id

        if exc_type is None:
            payload["status"] = "success"
            payload["error_message"] = None
            self.monitor._safe_post("/api/sdk/steps/end", payload)
            return False

        payload["status"] = "failed"
        payload["error_message"] = str(exc_value) if exc_value is not None else exc_type.__name__
        self.monitor._safe_post("/api/sdk/steps/end", payload)
        return False


class Monitor:
    """AgentOps monitoring entry point."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        project_name: str,
        capture_mode: str = "summary_only",
        timeout: int = 10,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if not base_url:
            raise ValueError("base_url is required")
        if not project_name:
            raise ValueError("project_name is required")

        self.api_key = api_key
        self.base_url = base_url
        self.project_name = project_name
        self.capture_mode = capture_mode
        self.timeout = timeout
        self._client = AgentMonClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self._active_run_context: _RunContext | None = None
        self._step_seq_no = 0
        self._real_step_started = False
        enable_auto_instrumentation()

    def run(
        self,
        agent_name: str,
        session_id: str | None = None,
        channel_type: str = "generic",
        input_summary: str | None = None,
        metadata_json: Any = None,
    ) -> _RunContext:
        if not agent_name:
            raise ValueError("agent_name is required")

        return _RunContext(
            monitor=self,
            agent_name=agent_name,
            session_id=session_id,
            channel_type=channel_type,
            input_summary=input_summary,
            metadata_json=metadata_json,
        )

    def step(
        self,
        step_name: str,
        step_type: str = "processing",
        input_summary: str | None = None,
        raw_input_masked: str | None = None,
        metadata_json: Any = None,
    ) -> _StepContext:
        if not step_name:
            raise ValueError("step_name is required")

        return _StepContext(
            monitor=self,
            step_name=step_name,
            step_type=step_type,
            input_summary=input_summary,
            raw_input_masked=raw_input_masked,
            metadata_json=metadata_json,
        )

    def _safe_post(self, path: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        """Best-effort API call; never raises to the caller."""
        try:
            with suppress_auto_instrumentation():
                return self._client.post(path, payload)
        except Exception as exc:  # pragma: no cover
            logger.debug("AgentOps monitoring request failed: %s", exc)
            return None

    def _has_active_run(self) -> bool:
        return self._active_run_context is not None

    def _emit_fallback_step_if_needed(
        self,
        exc_type: type[BaseException] | None = None,
        exc_value: BaseException | None = None,
        traceback: TracebackType | None = None,
    ) -> None:
        if not self._has_active_run() or self._real_step_started:
            return
        fallback_ctx = _StepContext(
            monitor=self,
            step_name="執行中",
            step_type="processing",
            metadata_json={"instrumentation_source": "fallback"},
            is_fallback=True,
        )
        fallback_ctx.__enter__()
        fallback_ctx.__exit__(exc_type, exc_value, traceback)

    def _on_real_step_started(self) -> None:
        self._real_step_started = True

    def _reset_run_state(self) -> None:
        self._real_step_started = False

    @contextmanager
    def _auto_step(
        self,
        step_name: str,
        step_type: str,
        metadata_json: dict[str, Any] | None = None,
    ):
        if not self._has_active_run():
            yield
            return

        merged_metadata: dict[str, Any] = {"instrumentation_source": "auto"}
        if metadata_json:
            merged_metadata.update(metadata_json)

        with self.step(step_name=step_name, step_type=step_type, metadata_json=merged_metadata):
            yield
