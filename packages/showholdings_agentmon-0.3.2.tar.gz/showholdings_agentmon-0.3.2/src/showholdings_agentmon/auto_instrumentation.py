"""Automatic instrumentation for common providers and adapters."""

from __future__ import annotations

import contextvars
import importlib
import inspect
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import urlparse

_ACTIVE_MONITOR: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "showholdings_agentmon_active_monitor",
    default=None,
)
_AUTO_SUPPRESSED: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "showholdings_agentmon_auto_suppressed",
    default=False,
)


@dataclass
class _PatchSpec:
    path: str
    kind: str
    provider: str
    step_name: str
    step_type: str


_AUTO_PATCH_TARGETS: list[_PatchSpec] = [
    _PatchSpec(
        path="openai.resources.chat.completions.completions.Completions.create",
        kind="llm",
        provider="openai",
        step_name="OpenAI 呼叫",
        step_type="llm_call",
    ),
    _PatchSpec(
        path="openai.resources.responses.responses.Responses.create",
        kind="llm",
        provider="openai",
        step_name="OpenAI 呼叫",
        step_type="llm_call",
    ),
    _PatchSpec(
        path="anthropic.resources.messages.messages.Messages.create",
        kind="llm",
        provider="anthropic",
        step_name="Anthropic 呼叫",
        step_type="llm_call",
    ),
    _PatchSpec(
        path="google.generativeai.GenerativeModel.generate_content",
        kind="llm",
        provider="gemini",
        step_name="Gemini 呼叫",
        step_type="llm_call",
    ),
    _PatchSpec(
        path="requests.sessions.Session.request",
        kind="http",
        provider="requests",
        step_name="HTTP 呼叫",
        step_type="http_call",
    ),
    _PatchSpec(
        path="httpx.Client.request",
        kind="http",
        provider="httpx",
        step_name="HTTP 呼叫",
        step_type="http_call",
    ),
    _PatchSpec(
        path="httpx.AsyncClient.request",
        kind="http",
        provider="httpx",
        step_name="HTTP 呼叫",
        step_type="http_call",
    ),
    _PatchSpec(
        path="sqlalchemy.engine.Connection.execute",
        kind="db",
        provider="sqlalchemy",
        step_name="SQLAlchemy query",
        step_type="db_query",
    ),
]


class _SQLiteCursorProxy:
    def __init__(self, cursor: Any) -> None:
        self._cursor = cursor

    def execute(self, statement: Any, parameters: Any = None):
        return _run_db_call(
            adapter="sqlite3",
            statement=statement,
            func=lambda: self._cursor.execute(statement) if parameters is None else self._cursor.execute(statement, parameters),
            cursor_proxy=self,
        )

    def executemany(self, statement: Any, parameters: Any):
        return _run_db_call(
            adapter="sqlite3",
            statement=statement,
            func=lambda: self._cursor.executemany(statement, parameters),
            cursor_proxy=self,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._cursor, name)


class _SQLiteConnectionProxy:
    def __init__(self, connection: Any) -> None:
        self._connection = connection

    def cursor(self, *args: Any, **kwargs: Any) -> _SQLiteCursorProxy:
        return _SQLiteCursorProxy(self._connection.cursor(*args, **kwargs))

    def execute(self, statement: Any, parameters: Any = None):
        return _run_db_call(
            adapter="sqlite3",
            statement=statement,
            func=lambda: self._connection.execute(statement) if parameters is None else self._connection.execute(statement, parameters),
        )

    def executemany(self, statement: Any, parameters: Any):
        return _run_db_call(
            adapter="sqlite3",
            statement=statement,
            func=lambda: self._connection.executemany(statement, parameters),
        )

    def __enter__(self):
        self._connection.__enter__()
        return self

    def __exit__(self, exc_type, exc, tb) -> Any:
        return self._connection.__exit__(exc_type, exc, tb)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._connection, name)


class _AutoInstrumentationManager:
    def __init__(self) -> None:
        self._enabled = False
        self._patched: list[tuple[Any, str, Any]] = []
        self._sqlite_connect_original: Any | None = None

    def enable(self) -> None:
        if self._enabled:
            return
        self._patch_targets()
        self._patch_sqlite3_connect()
        self._enabled = True

    def reset_for_testing(self) -> None:
        while self._patched:
            owner, attr, original = self._patched.pop()
            setattr(owner, attr, original)
        if self._sqlite_connect_original is not None:
            try:
                import sqlite3

                sqlite3.connect = self._sqlite_connect_original
            except Exception:
                pass
            self._sqlite_connect_original = None
        self._enabled = False

    def _patch_targets(self) -> None:
        for spec in _AUTO_PATCH_TARGETS:
            resolved = self._resolve_path(spec.path)
            if resolved is None:
                continue
            owner, attr, original = resolved
            wrapped = self._build_wrapper(spec, original)
            setattr(owner, attr, wrapped)
            self._patched.append((owner, attr, original))

    def _patch_sqlite3_connect(self) -> None:
        try:
            import sqlite3
        except Exception:
            return

        if self._sqlite_connect_original is not None:
            return

        original_connect = sqlite3.connect

        def wrapped_connect(*args: Any, **kwargs: Any):
            connection = original_connect(*args, **kwargs)
            return _SQLiteConnectionProxy(connection)

        sqlite3.connect = wrapped_connect
        self._sqlite_connect_original = original_connect

    def _resolve_path(self, path: str) -> tuple[Any, str, Any] | None:
        parts = path.split(".")
        for split in range(len(parts), 0, -1):
            module_name = ".".join(parts[:split])
            try:
                module = importlib.import_module(module_name)
                attr_parts = parts[split:]
                if not attr_parts:
                    return None
                owner = module
                for name in attr_parts[:-1]:
                    owner = getattr(owner, name)
                attr = attr_parts[-1]
                original = getattr(owner, attr)
                return owner, attr, original
            except Exception:
                continue
        return None

    def _build_wrapper(self, spec: _PatchSpec, original: Any) -> Any:
        if inspect.iscoroutinefunction(original):
            return self._build_async_wrapper(spec, original)
        return self._build_sync_wrapper(spec, original)

    def _build_sync_wrapper(self, spec: _PatchSpec, original: Any) -> Callable[..., Any]:
        def wrapped(*args: Any, **kwargs: Any):
            monitor = _ACTIVE_MONITOR.get()
            if monitor is None or _AUTO_SUPPRESSED.get() or not monitor._has_active_run():
                return original(*args, **kwargs)

            metadata = _build_metadata(spec, args, kwargs)
            with monitor._auto_step(spec.step_name, spec.step_type, metadata_json=metadata):
                result = original(*args, **kwargs)

            if spec.kind == "llm":
                _record_tool_use_if_any(monitor, spec.provider, result)
            return result

        return wrapped

    def _build_async_wrapper(self, spec: _PatchSpec, original: Any) -> Callable[..., Any]:
        async def wrapped(*args: Any, **kwargs: Any):
            monitor = _ACTIVE_MONITOR.get()
            if monitor is None or _AUTO_SUPPRESSED.get() or not monitor._has_active_run():
                return await original(*args, **kwargs)

            metadata = _build_metadata(spec, args, kwargs)
            with monitor._auto_step(spec.step_name, spec.step_type, metadata_json=metadata):
                result = await original(*args, **kwargs)

            if spec.kind == "llm":
                _record_tool_use_if_any(monitor, spec.provider, result)
            return result

        return wrapped


_MANAGER = _AutoInstrumentationManager()


def enable_auto_instrumentation() -> None:
    _MANAGER.enable()


def reset_auto_instrumentation_for_testing() -> None:
    _MANAGER.reset_for_testing()


def set_active_monitor(monitor: Any | None) -> None:
    _ACTIVE_MONITOR.set(monitor)


@contextmanager
def suppress_auto_instrumentation():
    token = _AUTO_SUPPRESSED.set(True)
    try:
        yield
    finally:
        _AUTO_SUPPRESSED.reset(token)


def _truncate(value: Any, limit: int = 180) -> str:
    text = str(value)
    if len(text) <= limit:
        return text
    return f"{text[:limit]}..."


def _extract_model(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    model = kwargs.get("model")
    if isinstance(model, str):
        return model

    if len(args) >= 2 and isinstance(args[1], str):
        return args[1]

    if args and isinstance(args[-1], dict):
        payload_model = args[-1].get("model")
        if isinstance(payload_model, str):
            return payload_model
    return None


def _parse_http_call(args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[str | None, str | None]:
    method = kwargs.get("method")
    url = kwargs.get("url")
    if len(args) >= 2:
        method = args[1]
    if len(args) >= 3:
        url = args[2]
    return (method.upper() if isinstance(method, str) else None), (url if isinstance(url, str) else None)


def _operation_from_statement(statement: Any) -> str | None:
    sql = str(statement).strip()
    if not sql:
        return None
    return sql.split(None, 1)[0].upper()


def _build_metadata(spec: _PatchSpec, args: tuple[Any, ...], kwargs: dict[str, Any]) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "provider": spec.provider,
    }
    if spec.kind == "llm":
        metadata["model"] = _extract_model(args, kwargs)
    elif spec.kind == "http":
        method, url = _parse_http_call(args, kwargs)
        parsed = urlparse(url) if url else None
        metadata.update(
            {
                "method": method,
                "scheme": parsed.scheme if parsed else None,
                "host": parsed.netloc if parsed else None,
                "path_summary": parsed.path if parsed else None,
            }
        )
    elif spec.kind == "db":
        statement = args[1] if len(args) >= 2 else kwargs.get("statement")
        metadata.update(
            {
                "db_adapter": spec.provider,
                "operation_type": _operation_from_statement(statement),
                "statement_summary": _truncate(statement) if statement is not None else None,
            }
        )
    return metadata


def _extract_tool_names(result: Any) -> list[str]:
    names: list[str] = []
    if result is None:
        return names

    def add(candidate: Any) -> None:
        if isinstance(candidate, str) and candidate and candidate not in names:
            names.append(candidate)

    if isinstance(result, dict):
        for item in result.get("tool_calls", []) or []:
            if isinstance(item, dict):
                add(item.get("name") or item.get("function", {}).get("name"))
        for item in result.get("content", []) or []:
            if isinstance(item, dict) and item.get("type") in {"tool_use", "tool_call"}:
                add(item.get("name"))

    output = getattr(result, "output", None)
    if isinstance(output, list):
        for item in output:
            item_type = getattr(item, "type", None)
            if item_type in {"tool_call", "tool_use"}:
                add(getattr(item, "name", None))

    tool_calls_attr = getattr(result, "tool_calls", None)
    if isinstance(tool_calls_attr, list):
        for item in tool_calls_attr:
            add(getattr(item, "name", None))

    return names


def _record_tool_use_if_any(monitor: Any, provider: str, result: Any) -> None:
    tool_names = _extract_tool_names(result)
    if not tool_names:
        return
    with monitor._auto_step(
        step_name=f"{provider} tool use",
        step_type="tool_call",
        metadata_json={"provider": provider, "tool_names": tool_names},
    ):
        pass


def _run_db_call(adapter: str, statement: Any, func: Callable[[], Any], cursor_proxy: Any | None = None):
    monitor = _ACTIVE_MONITOR.get()
    if monitor is None or _AUTO_SUPPRESSED.get() or not monitor._has_active_run():
        result = func()
        if cursor_proxy is not None and result is not None and result is not cursor_proxy:
            return cursor_proxy
        return result

    with monitor._auto_step(
        "SQLite query" if adapter == "sqlite3" else "DB query",
        "db_query",
        metadata_json={
            "db_adapter": adapter,
            "operation_type": _operation_from_statement(statement),
            "statement_summary": _truncate(statement) if statement is not None else None,
        },
    ):
        result = func()
    if cursor_proxy is not None and result is not None and result is not cursor_proxy:
        return cursor_proxy
    return result
