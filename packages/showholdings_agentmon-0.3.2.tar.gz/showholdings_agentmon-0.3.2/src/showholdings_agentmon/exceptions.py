"""Custom exceptions for showholdings-agentmon."""


class AgentMonError(Exception):
    """Base exception for SDK errors."""


class AgentMonAPIError(AgentMonError):
    """Raised when AgentOps API call fails with an HTTP or network error."""


class AgentMonUsageError(AgentMonError):
    """Raised when SDK is used in an invalid context."""
