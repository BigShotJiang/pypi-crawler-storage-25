"""HTTP client for AgentOps ingestion API."""

from __future__ import annotations

from typing import Any

import requests

from .exceptions import AgentMonAPIError


class AgentMonClient:
    """Minimal HTTP client for posting monitoring payloads."""

    def __init__(self, api_key: str, base_url: str, timeout: int = 10) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        """POST JSON payload and return response JSON when possible.

        Raises:
            AgentMonAPIError: On network error or non-2xx response.
        """
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=self.timeout)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise AgentMonAPIError(f"AgentOps API request failed: {exc}") from exc

        if not response.content:
            return None

        try:
            return response.json()
        except ValueError:
            return None
