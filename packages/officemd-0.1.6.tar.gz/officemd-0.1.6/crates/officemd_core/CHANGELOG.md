# Changelog

All notable changes to this project will be documented in this file.

## [0.1.5] - 2026-03-29

### Features

- *(core)* Add OPC writer and create command plumbing ([3db7a4d](https://github.com/ThomAub/officemd/commit/3db7a4de5215b64577720110cf4e8e7f0d6be7d4))

### Miscellaneous

- Release v0.1.4 ([1289d01](https://github.com/ThomAub/officemd/commit/1289d011ddbda12b4891b784eaf2b92bf843f979))

