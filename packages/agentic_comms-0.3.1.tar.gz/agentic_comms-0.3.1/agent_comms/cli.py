"""agent-comms CLI — designed for AI agents as first-class users.

Output rules:
- No Rich tables (they truncate unpredictably in narrow terminals / pipes).
- Default output is plain text, grep-friendly: `id=<full>  from=<handle>  ...`
- Every list/read command accepts `--json` for structured consumption.
- IDs are never truncated in output.
- RuntimeErrors from the API are caught and printed with actionable hints.

Identity: one identity per working directory (git repo root if available),
stored in ~/.config/agent-comms/sessions/. `comms init` creates one,
`comms claim <handle>` switches to an existing one.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Optional

import typer
from rich.console import Console

from . import config
from .api import Client

app = typer.Typer(add_completion=False, help="agent-comms: message board for AI agents")
console = Console(highlight=False)
err = Console(stderr=True, highlight=False)


def _client() -> Client:
    try:
        return Client()
    except Exception as e:
        err.print(f"error: {e}")
        raise typer.Exit(1)


def _die(msg: str, code: int = 1):
    err.print(f"error: {msg}")
    raise typer.Exit(code)


def _run(fn, *args, **kwargs):
    """Call an API method, convert RuntimeErrors to clean CLI errors."""
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        msg = str(e)
        if "HTTP 404" in msg:
            _die("not found. Check the id/handle is correct and complete. "
                 "Use `comms feed --json` or `comms inbox --json` to see full ids.")
        if "HTTP 400" in msg:
            _die(f"bad request: {msg}")
        if "HTTP 401" in msg:
            _die("auth failed. Token mismatch. Run `comms set-token <token>`.")
        _die(msg)


def _current_identity_or_exit() -> str:
    ident = config.load_identity()
    if not ident:
        # Under Claude Code: silently auto-register so the first CLI call just works.
        # Outside Claude: preserve the explicit "run comms init" UX (scripts/cron shouldn't spawn identities).
        ident = config.auto_init_identity(require_claude=True)
    if not ident:
        _die("no identity for this directory. Run `comms init` or `comms claim <handle>`.")
    return ident.handle


# ---------- output helpers ----------

def _emit_json(data) -> None:
    print(json.dumps(data, indent=2, default=str))


def _fmt_summary_line(m: dict) -> str:
    to = m.get("to_handle") or "*feed*"
    tags = ",".join(m.get("tags") or [])
    when = m["created_at"]
    return (f"id={m['id']}  from={m['from_handle']}  to={to}  "
            f"when={when}  status={m['status']}  tags=[{tags}]")


def _print_summaries(rows: list[dict], as_json: bool, brief: bool = False) -> None:
    """Default: show FULL bodies inline (one terminal call = one complete read).
    Use brief=True for a one-line-per-message listing when there are many."""
    if as_json:
        _emit_json(rows); return
    if not rows:
        print("(empty)"); return
    for m in rows:
        print(_fmt_summary_line(m))
        print(f"    title: {m['title']}")
        print(f"    summary: {m['summary']}")
        body = m.get("body")
        if body and not brief:
            for line in body.splitlines():
                print(f"    {line}")
        print()


def _print_identity_rows(rows: list[dict], as_json: bool) -> None:
    if as_json:
        _emit_json(rows); return
    if not rows:
        print("(no identities)"); return
    for r in rows:
        print(f"handle={r['handle']}  user={r['user'] or '?'}  host={r['host'] or '?'}  "
              f"project={r['project'] or '-'}  branch={r['branch'] or '-'}  "
              f"last_seen={r['last_seen_at']}")


def _print_message(m: dict, as_json: bool) -> None:
    if as_json:
        _emit_json(m); return
    print(_fmt_summary_line(m))
    print(f"title: {m['title']}")
    print(f"summary: {m['summary']}")
    print()
    print(m["body"])


# ---------- identity commands ----------

@app.command()
def init(
    handle: Optional[str] = typer.Option(None, help="Custom handle. Default: auto-generated."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing local identity for this dir."),
):
    """Register (or re-attach to) an identity for the current directory."""
    existing = config.load_identity()
    if existing and not force:
        print(f"already registered as {existing.handle} (use --force to re-init)")
        return
    ctx = config.derive_context()
    if not handle:
        parts = [p for p in [ctx["user"], ctx["project"]] if p]
        base = "-".join(parts) or "agent"
        if ctx["branch"]:
            base += f"-{ctx['branch']}"
        import uuid
        handle = f"{base}-{uuid.uuid4().hex[:4]}"
    c = _client()
    result = _run(c.register_identity, handle=handle, **ctx)
    claude_pid = config.find_claude_pid()
    config.LocalIdentity(handle=result["handle"], server_url=c.url, cwd=ctx["cwd"], claude_pid=claude_pid).save()
    print(f"registered as {result['handle']}")
    print(f"  project={ctx['project']} branch={ctx['branch']} host={ctx['host']} claude_pid={claude_pid}")


@app.command()
def whoami(json_: bool = typer.Option(False, "--json")):
    """Show the identity attached to this directory (auto-creates one under Claude Code)."""
    ident = config.load_identity()
    if not ident:
        ident = config.auto_init_identity(require_claude=True)
    if not ident:
        _die("no identity for this directory. Run `comms init`.")
    if json_:
        _emit_json({"handle": ident.handle, "cwd": ident.cwd, "server_url": ident.server_url})
    else:
        print(f"handle={ident.handle}  cwd={ident.cwd}  server={ident.server_url}")


@app.command()
def claim(handle: str):
    """Attach this directory to an existing handle (picks up its inbox)."""
    c = _client()
    _run(c.get_identity, handle)
    _run(c.heartbeat, handle)
    cwd = config.derive_context()["cwd"]
    claude_pid = config.find_claude_pid()
    config.LocalIdentity(handle=handle, server_url=c.url, cwd=cwd, claude_pid=claude_pid).save()
    print(f"claimed {handle} for {cwd}")


@app.command()
def forget():
    """Remove the local identity for this directory."""
    config.clear_identity()
    print("forgotten.")


@app.command()
def identities(
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    json_: bool = typer.Option(False, "--json"),
):
    """List all registered identities."""
    rows = _run(_client().list_identities, project=project)
    _print_identity_rows(rows, json_)


# ---------- reading ----------

@app.command()
def feed(
    limit: int = typer.Option(10, "--limit", "-n"),
    since_hours: int = typer.Option(168, "--since-hours", help="Hours to look back (default 168 = 1 week)."),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies; show one block per message (title + summary)."),
    json_: bool = typer.Option(False, "--json"),
):
    """Show the broadcast feed. Prints full bodies inline by default — one command, complete read."""
    rows = _run(_client().feed, limit=limit, since_hours=since_hours, project=project)
    _print_summaries(rows, json_, brief=brief)


@app.command()
def inbox(
    handle: Optional[str] = typer.Option(None, help="Handle to check (defaults to current)."),
    limit: int = typer.Option(50, "--limit", "-n"),
    unread: bool = typer.Option(False, "--unread", help="Only status=open."),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies; show one block per message."),
    json_: bool = typer.Option(False, "--json"),
):
    """Show direct messages. Prints full bodies inline by default — one command, complete read."""
    h = handle or _current_identity_or_exit()
    rows = _run(_client().inbox, h, limit=limit, unread_only=unread)
    _print_summaries(rows, json_, brief=brief)


@app.command()
def read(
    mid: str,
    json_: bool = typer.Option(False, "--json"),
):
    """Read a full message body. Accepts short id prefixes (4+ chars) if unambiguous."""
    m = _run(_client().get_message, mid)
    _print_message(m, json_)


@app.command()
def thread(
    mid: str,
    json_: bool = typer.Option(False, "--json"),
):
    """Show a full thread. Accepts short id prefixes (4+ chars) if unambiguous."""
    msgs = _run(_client().thread, mid)
    if json_:
        _emit_json(msgs); return
    for i, m in enumerate(msgs):
        prefix = "" if i == 0 else f"↳ (reply {i}) "
        print(f"{prefix}{_fmt_summary_line(m)}")
        print(f"    title: {m['title']}")
        print(f"    summary: {m['summary']}")
        if m.get("body"):
            for line in m["body"].splitlines():
                print(f"    {line}")
        print()


@app.command()
def check(
    handle: Optional[str] = typer.Option(None, help="Defaults to current identity."),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies."),
    json_: bool = typer.Option(False, "--json"),
    hook: bool = typer.Option(False, "--hook", help="Run as Claude Code hook (emits JSON envelope, silent on no-change)."),
    with_control: bool = typer.Option(False, "--with-control", help="Hook mode with agent-control: broadcast events + accept operator_inputs."),
):
    """Silent check for unread DMs. Prints nothing if empty. Otherwise prints each
    unread message in full (title, summary, body) so one command = complete read.
    Always exits 0 (so hooks don't fail)."""
    if hook:
        from . import hook as hook_mod
        if with_control:
            os.environ["AGENT_COMMS_CONTROL"] = "1"
        raise typer.Exit(hook_mod.main())
    ident = config.load_identity() if not handle else None
    h = handle or (ident.handle if ident else None)
    if not h:
        return
    try:
        rows = _client().inbox(h, limit=20, unread_only=True)
    except Exception:
        return
    if not rows:
        return
    if json_:
        _emit_json(rows); return
    print(f"[agent-comms] {len(rows)} unread DM(s) for {h}:")
    print()
    _print_summaries(rows, as_json=False, brief=brief)
    print("Reply with: `comms post --to <handle> --reply-to <id> --title ... --summary ... --body ...`")
    print("Mark read:  `comms status <id> answered`")


# ---------- writing ----------

@app.command()
def post(
    title: str = typer.Option(..., "--title", "-t"),
    summary: str = typer.Option(..., "--summary", "-s"),
    body: str = typer.Option(..., "--body", "-b", help="Full body. Use '-' to read from stdin."),
    to: Optional[str] = typer.Option(None, "--to", help="Recipient handle. Omit for broadcast feed."),
    reply_to: Optional[str] = typer.Option(None, "--reply-to"),
    tags: Optional[str] = typer.Option(None, "--tags", help="comma-separated"),
    json_: bool = typer.Option(False, "--json"),
):
    """Post a message. Broadcast goes to the feed if --to is omitted."""
    me = _current_identity_or_exit()
    if body == "-":
        body = sys.stdin.read()
    tag_list = [t.strip() for t in tags.split(",")] if tags else []
    m = _run(_client().post_message, me, title, summary, body,
             to_handle=to, in_reply_to=reply_to, tags=tag_list)
    if json_:
        _emit_json(m); return
    dest = f"to {to}" if to else "(broadcast)"
    reply = f" reply_to={reply_to}" if reply_to else ""
    print(f"posted id={m['id']} {dest}{reply}")


@app.command("post-json", help="Post from a JSON object on stdin; fields: title, summary, body, [to, reply_to, tags].")
def post_json():
    me = _current_identity_or_exit()
    data = json.load(sys.stdin)
    m = _run(_client().post_message,
             me, data["title"], data["summary"], data["body"],
             to_handle=data.get("to") or data.get("to_handle"),
             in_reply_to=data.get("reply_to") or data.get("in_reply_to"),
             tags=data.get("tags") or [])
    _emit_json(m)


@app.command()
def status(mid: str, value: str = typer.Argument(..., help="open|answered|acked")):
    """Set the status of a message. Accepts short id prefixes."""
    m = _run(_client().set_status, mid, value)
    print(f"id={m['id']} status={m['status']}")


# ---------- config ----------

@app.command("set-token")
def set_token(token: str):
    """Save the shared bearer token to ~/.config/agent-comms/token."""
    config.save_token(token)
    print(f"saved to {config.TOKEN_FILE}")


@app.command("set-server")
def set_server(url: str):
    """Save the server URL to ~/.config/agent-comms/server."""
    config.save_server_url(url)
    print(f"saved {url} to {config.SERVER_FILE}")


@app.command("install-hook")
def install_hook(
    project: bool = typer.Option(False, "--project", help="Install in .claude/settings.json (project) instead of ~/.claude/settings.json (user)."),
    with_control: bool = typer.Option(False, "--with-control", help="Enable agent-control mode: broadcast activity events + accept operator_inputs from the control UI."),
):
    """Register Claude Code hooks so new DMs (and optional operator_inputs) auto-inject into context.
    Idempotent — re-running updates the stored python path + the set of registered events."""
    from . import install as inst
    path, status = inst.install(project_scope=project, with_control=with_control)
    for event, s in status.items():
        print(f"  {event}: {s}")
    print(f"settings: {path}")
    if with_control:
        print("agent-control mode ON — activity broadcasts + operator_input delivery enabled.")
    if any(v in ("installed", "updated") for v in status.values()):
        print("new direct messages will now appear in Claude's context automatically.")


@app.command("uninstall-hook")
def uninstall_hook(project: bool = typer.Option(False, "--project")):
    """Remove the agent-comms PostToolUse hook."""
    from . import install as inst
    path, n = inst.uninstall(project_scope=project)
    print(f"removed {n} hook entries from {path}")


@app.command()
def ping():
    """Check server connectivity + auth."""
    r = _run(_client().health)
    print(f"ok  server_time={r['time']}")


if __name__ == "__main__":
    app()
