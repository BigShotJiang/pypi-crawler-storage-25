from __future__ import annotations

import httpx

from . import config


class Client:
    def __init__(self, server_url: str | None = None, token: str | None = None):
        self.url = (server_url or config.get_server_url()).rstrip("/")
        self.token = token or config.get_token()
        self._h = httpx.Client(
            base_url=self.url,
            headers={"Authorization": f"Bearer {self.token}"},
            timeout=10.0,
        )

    def _check(self, r: httpx.Response):
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text}")
        return r.json()

    def health(self):
        return self._check(self._h.get("/api/health"))

    def register_identity(self, handle: str | None = None, **ctx):
        payload = {"handle": handle, **{k: v for k, v in ctx.items() if v is not None}}
        return self._check(self._h.post("/api/identities", json=payload))

    def heartbeat(self, handle: str):
        return self._check(self._h.post(f"/api/identities/{handle}/heartbeat"))

    def list_identities(self, project: str | None = None):
        params = {"project": project} if project else {}
        return self._check(self._h.get("/api/identities", params=params))

    def get_identity(self, handle: str):
        return self._check(self._h.get(f"/api/identities/{handle}"))

    def post_message(self, from_handle: str, title: str, summary: str, body: str,
                     to_handle: str | None = None, in_reply_to: str | None = None,
                     tags: list[str] | None = None):
        payload = {
            "from_handle": from_handle, "title": title, "summary": summary, "body": body,
            "to_handle": to_handle, "in_reply_to": in_reply_to, "tags": tags or [],
        }
        return self._check(self._h.post("/api/messages", json=payload))

    def feed(self, limit: int = 10, since_hours: int = 168, project: str | None = None):
        params = {"limit": limit, "since_hours": since_hours}
        if project:
            params["project"] = project
        return self._check(self._h.get("/api/messages/feed", params=params))

    def inbox(self, handle: str, limit: int = 50, unread_only: bool = False):
        return self._check(self._h.get("/api/messages/inbox", params={
            "handle": handle, "limit": limit, "unread_only": unread_only,
        }))

    def get_message(self, mid: str):
        return self._check(self._h.get(f"/api/messages/{mid}"))

    def thread(self, mid: str):
        return self._check(self._h.get(f"/api/messages/{mid}/thread"))

    def set_status(self, mid: str, status: str):
        return self._check(self._h.post(f"/api/messages/{mid}/status", params={"status": status}))

    # ---------- control / events ----------
    def post_event(self, **fields):
        return self._check(self._h.post("/api/events", json=fields))

    def post_control(self, to_handle: str, text: str, from_operator: str = "operator"):
        return self._check(self._h.post("/api/control", json={
            "to_handle": to_handle, "text": text, "from_operator": from_operator,
        }))

    def control_pending(self, handle: str, mark_delivered: bool = True):
        return self._check(self._h.get("/api/control/pending", params={
            "handle": handle, "mark_delivered": str(mark_delivered).lower(),
        }))

    def control_history(self, handle: str, since: str | None = None, limit: int = 200, kinds: str | None = None):
        params = {"limit": limit}
        if since:
            params["since"] = since
        if kinds:
            params["kinds"] = kinds
        return self._check(self._h.get(f"/api/control/{handle}/history", params=params))
