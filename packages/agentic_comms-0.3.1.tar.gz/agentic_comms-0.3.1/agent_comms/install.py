"""Install/uninstall the agent-comms Claude Code hook.

Edits ~/.claude/settings.json (or .claude/settings.json with --project) to
register a PostToolUse hook running `comms check --hook`.
"""
from __future__ import annotations

import json
import os
import shlex
import sys
from pathlib import Path

HOOK_TIMEOUT = 5
MARKER_FIELD = "agent_comms_marker"  # embedded in the hook entry so we can find+remove
BASE_EVENTS = ("PostToolUse", "UserPromptSubmit")
CONTROL_EVENTS = ("PostToolUse", "UserPromptSubmit", "Stop", "SessionStart", "SessionEnd")


def _hook_command(control: bool = False) -> str:
    """Absolute python path + module form — works in any shell / PATH."""
    cmd = f"{shlex.quote(sys.executable)} -m agent_comms check --hook"
    if control:
        cmd += " --with-control"
    return cmd


def _settings_path(project_scope: bool) -> Path:
    if project_scope:
        return Path(".claude") / "settings.json"
    claude_home = Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home() / ".claude")))
    return claude_home / "settings.json"


def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text() or "{}")
    except json.JSONDecodeError:
        return {}


def _save(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def install(project_scope: bool = False, with_control: bool = False) -> tuple[Path, dict]:
    """Install hooks. Returns (settings_path, status_by_event).
    Idempotent — existing entries are rewritten with the current command (useful when
    the python path changes due to venv / reinstall, or when toggling --with-control).

    with_control=True extends the registered events (adds Stop, SessionStart, SessionEnd)
    and adds `--with-control` to the hook command so the hook broadcasts activity events
    to /api/events and delivers operator_inputs as user-turn-framed context.
    """
    path = _settings_path(project_scope)
    data = _load(path)
    hooks = data.setdefault("hooks", {})
    command = _hook_command(control=with_control)
    status: dict[str, str] = {}

    events = CONTROL_EVENTS if with_control else BASE_EVENTS

    # When toggling off control, strip any Stop/SessionStart/SessionEnd entries we previously added.
    if not with_control:
        for e in ("Stop", "SessionStart", "SessionEnd"):
            entries = hooks.get(e) or []
            new_entries = []
            for group in entries:
                kept = [h for h in group.get("hooks", []) if not h.get(MARKER_FIELD)]
                if kept:
                    group["hooks"] = kept
                    new_entries.append(group)
            if new_entries:
                hooks[e] = new_entries
            else:
                hooks.pop(e, None)

    for event in events:
        entries = hooks.setdefault(event, [])
        found = None
        for group in entries:
            for h in group.get("hooks", []):
                if h.get(MARKER_FIELD):
                    found = h
                    break
            if found:
                break
        if found:
            if found.get("command") == command and found.get("timeout") == HOOK_TIMEOUT:
                status[event] = "already-installed"
            else:
                found["command"] = command
                found["timeout"] = HOOK_TIMEOUT
                status[event] = "updated"
        else:
            entries.append({
                "matcher": "*",
                "hooks": [{
                    "type": "command",
                    "command": command,
                    "timeout": HOOK_TIMEOUT,
                    MARKER_FIELD: True,
                }],
            })
            status[event] = "installed"

    _save(path, data)
    return path, status


def uninstall(project_scope: bool = False) -> tuple[Path, int]:
    """Remove any agent-comms hook entries across all events. Returns (path, num_removed)."""
    path = _settings_path(project_scope)
    if not path.exists():
        return path, 0
    data = _load(path)
    hooks = (data.get("hooks") or {})
    removed = 0
    for event in list(hooks.keys()):
        entries = hooks.get(event) or []
        new_entries = []
        for group in entries:
            kept = [h for h in group.get("hooks", []) if not h.get(MARKER_FIELD)]
            removed += len(group.get("hooks", [])) - len(kept)
            if kept:
                group["hooks"] = kept
                new_entries.append(group)
        if new_entries:
            hooks[event] = new_entries
        else:
            hooks.pop(event, None)
    if not hooks:
        data.pop("hooks", None)
    if removed:
        _save(path, data)
    return path, removed
