// One-sided Jacobi SVD — single rotation round (v0.6.6 Cut 3).
//
// 한 dispatch = 한 round of chess tournament pairing.  각 workgroup = 한
// pair (i, j) i<j 에 대한 column rotation.  주어진 round 의 pair 들은
// 모두 disjoint 라 inter-workgroup synchronization 불필요.
//
// ## 수학
// Hermitian H = M^H M = [[a, p], [conj(p), b]] (a=||m_i||², b=||m_j||², p=<m_i,m_j>).
// 회전 R = V (2x2 unitary) 가 H 의 off-diag 를 0 으로 만들면 [m_i,m_j]·V
// 의 새 column 도 직교 (∵ (MV)^H (MV) = V^H H V).
//
// 공식 (Cut 3 derive + test 검증):
//   σ = p / |p|         (complex unit, p ≠ 0 가정)
//   τ = (b - a) / (2|p|)
//   t = -sign(τ) / (|τ| + sqrt(1 + τ²))   // smaller-magnitude root of t² - 2τt - 1 = 0
//   c = 1 / sqrt(1 + t²)
//   s = t · c           (real)
// Column update:
//   m_i_new[k] = c · m_i[k] + s · conj(σ) · m_j[k]
//   m_j_new[k] = -s · σ · m_i[k] + c · m_j[k]
// V column 도 같은 rotation 으로 갱신 (M = U Σ V^H 의 V 누적).
//
// ## 메모리 레이아웃
// M: column-major (rows × cols) of vec2<f32> — M[col·rows + row].
// V: column-major (cols × cols) of vec2<f32> — V[col·cols + row].
//
// ## Workgroup
// size = 64.  Phase 1 (parallel reduce → a, b, p), Phase 2 (single thread:
// c, s, σ), Phase 3-4 (parallel: update M, V columns).

struct Params {
    rows: u32,
    cols: u32,
    pair_count: u32,
    skip_tol: f32,   // |p|² < skip_tol · a · b 면 회전 스킵 (이미 직교).
};

@group(0) @binding(0) var<storage, read_write> m_buf: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read_write> v_buf: array<vec2<f32>>;
@group(0) @binding(2) var<uniform> params: Params;
// pair_schedule: 길이 2·pair_count, [i0, j0, i1, j1, ...] (i<j 보장).
@group(0) @binding(3) var<storage, read> pair_schedule: array<u32>;

const WG: u32 = 64u;

var<workgroup> partial_a: array<f32, WG>;
var<workgroup> partial_b: array<f32, WG>;
var<workgroup> partial_p_re: array<f32, WG>;
var<workgroup> partial_p_im: array<f32, WG>;
var<workgroup> c_shared: f32;
var<workgroup> s_shared: f32;
var<workgroup> sigma_re_shared: f32;
var<workgroup> sigma_im_shared: f32;
var<workgroup> skip_flag: u32;

fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
}

@compute @workgroup_size(64)
fn main(
    @builtin(workgroup_id) wid: vec3<u32>,
    @builtin(local_invocation_id) lid: vec3<u32>,
) {
    let pair_idx = wid.x;
    if (pair_idx >= params.pair_count) { return; }
    let i = pair_schedule[pair_idx * 2u];
    let j = pair_schedule[pair_idx * 2u + 1u];
    let rows = params.rows;
    let cols = params.cols;
    let tid = lid.x;

    // ---- Phase 1: parallel reduce → (a, b, p_re, p_im) ----
    var local_a: f32 = 0.0;
    var local_b: f32 = 0.0;
    var local_p_re: f32 = 0.0;
    var local_p_im: f32 = 0.0;
    var k: u32 = tid;
    loop {
        if (k >= rows) { break; }
        let mi = m_buf[i * rows + k];
        let mj = m_buf[j * rows + k];
        // a += |mi|², b += |mj|²
        local_a = local_a + mi.x * mi.x + mi.y * mi.y;
        local_b = local_b + mj.x * mj.x + mj.y * mj.y;
        // p += conj(mi) * mj
        //   conj(mi) = (mi.x, -mi.y)
        //   conj(mi)*mj = (mi.x*mj.x + mi.y*mj.y, mi.x*mj.y - mi.y*mj.x)
        local_p_re = local_p_re + mi.x * mj.x + mi.y * mj.y;
        local_p_im = local_p_im + mi.x * mj.y - mi.y * mj.x;
        k = k + WG;
    }
    partial_a[tid] = local_a;
    partial_b[tid] = local_b;
    partial_p_re[tid] = local_p_re;
    partial_p_im[tid] = local_p_im;
    workgroupBarrier();

    // Tree reduce 64 → 1.
    var stride: u32 = WG / 2u;
    loop {
        if (stride == 0u) { break; }
        if (tid < stride) {
            partial_a[tid] = partial_a[tid] + partial_a[tid + stride];
            partial_b[tid] = partial_b[tid] + partial_b[tid + stride];
            partial_p_re[tid] = partial_p_re[tid] + partial_p_re[tid + stride];
            partial_p_im[tid] = partial_p_im[tid] + partial_p_im[tid + stride];
        }
        workgroupBarrier();
        stride = stride >> 1u;
    }

    // ---- Phase 2: single thread → c, s, σ ----
    if (tid == 0u) {
        let a = partial_a[0];
        let b = partial_b[0];
        let p_re = partial_p_re[0];
        let p_im = partial_p_im[0];
        let abs_p_sq = p_re * p_re + p_im * p_im;
        // Skip when off-diag is already small relative to diagonals.
        if (abs_p_sq <= params.skip_tol * a * b) {
            skip_flag = 1u;
        } else {
            skip_flag = 0u;
            let abs_p = sqrt(abs_p_sq);
            let inv_abs_p = 1.0 / abs_p;
            sigma_re_shared = p_re * inv_abs_p;
            sigma_im_shared = p_im * inv_abs_p;
            let tau = (b - a) * 0.5 * inv_abs_p;
            // t = -sign(τ) / (|τ| + sqrt(1+τ²)).  sign() in WGSL returns -1/0/1.
            let tau_sign = select(-1.0, 1.0, tau >= 0.0);
            // tau == 0 일 때 sign 0 이면 t=0 → c=1, s=0 — 회전 안 함.  여기서는
            // skip_flag 가 잡지 못한 |p|>0 의 corner case 라 select 로 ±1
            // 강제 (어느 쪽이든 |t|=1/(0+1)=1, 같은 회전 각도).
            let t = -tau_sign / (abs(tau) + sqrt(1.0 + tau * tau));
            let c = 1.0 / sqrt(1.0 + t * t);
            c_shared = c;
            s_shared = t * c;
        }
    }
    workgroupBarrier();

    if (skip_flag == 1u) { return; }

    // ---- Phase 3: apply rotation to M columns i, j ----
    let c = c_shared;
    let s = s_shared;
    let sigma = vec2<f32>(sigma_re_shared, sigma_im_shared);
    let conj_sigma = vec2<f32>(sigma_re_shared, -sigma_im_shared);

    k = tid;
    loop {
        if (k >= rows) { break; }
        let mi = m_buf[i * rows + k];
        let mj = m_buf[j * rows + k];
        let cs_mj = cmul(conj_sigma, mj);
        let new_mi = vec2<f32>(c * mi.x + s * cs_mj.x, c * mi.y + s * cs_mj.y);
        let s_mi = cmul(sigma, mi);
        let new_mj = vec2<f32>(-s * s_mi.x + c * mj.x, -s * s_mi.y + c * mj.y);
        m_buf[i * rows + k] = new_mi;
        m_buf[j * rows + k] = new_mj;
        k = k + WG;
    }

    // ---- Phase 4: apply same rotation to V columns i, j (cols × cols) ----
    k = tid;
    loop {
        if (k >= cols) { break; }
        let vi = v_buf[i * cols + k];
        let vj = v_buf[j * cols + k];
        let cs_vj = cmul(conj_sigma, vj);
        let new_vi = vec2<f32>(c * vi.x + s * cs_vj.x, c * vi.y + s * cs_vj.y);
        let s_vi = cmul(sigma, vi);
        let new_vj = vec2<f32>(-s * s_vi.x + c * vj.x, -s * s_vi.y + c * vj.y);
        v_buf[i * cols + k] = new_vi;
        v_buf[j * cols + k] = new_vj;
        k = k + WG;
    }
}
