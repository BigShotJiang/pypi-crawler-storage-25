"""plugin-kit-ai Python wrapper package."""

__version__ = "1.0.5"
