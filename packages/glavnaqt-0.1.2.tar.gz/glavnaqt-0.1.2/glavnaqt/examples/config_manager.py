# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

def all_configurations():
    return [
        [],
        ["left"],
        ["right"],
        ["top"],
        ["bottom"],
        ["left", "right"],
        ["left", "top"],
        ["left", "bottom"],
        ["right", "top"],
        ["right", "bottom"],
        ["top", "bottom"],
        ["left", "right", "top"],
        ["left", "right", "bottom"],
        ["left", "top", "bottom"],
        ["right", "top", "bottom"],
        ["left", "right", "top", "bottom"]
    ]
