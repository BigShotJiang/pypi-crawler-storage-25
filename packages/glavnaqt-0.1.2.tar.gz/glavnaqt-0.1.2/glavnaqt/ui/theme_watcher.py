# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

# theme_watcher.py
import sys
from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot
from PyQt6.QtDBus import QDBusConnection, QDBusInterface, QDBusVariant
from glavnaqt.core import logger, config

class ThemeWatcher(QObject):
    """
    Watches the XDG Portal's SettingChanged signal and invokes
    MainWindow.apply_theme(dark: bool) immediately and on each toggle.
    """
    def __init__(self, window):
        super().__init__(window)
        self.win = window

        if config.theme == 'auto' and sys.platform.startswith('linux'):
            conn = QDBusConnection.sessionBus()

            # 1) Subscribe to the portal's SettingChanged(namespace, key, value) signal
            conn.connect(
                'org.freedesktop.portal.Desktop',
                '/org/freedesktop/portal/desktop',
                'org.freedesktop.portal.Settings',
                'SettingChanged',
                'ssv',
                self.on_setting_changed
            )

            # 2) Do one initial ReadOne to apply the current setting at startup
            iface = QDBusInterface(
                'org.freedesktop.portal.Desktop',
                '/org/freedesktop/portal/desktop',
                'org.freedesktop.portal.Settings',
                conn
            )
            reply = iface.call('ReadOne', 'org.freedesktop.appearance', 'color-scheme')
            val = reply.arguments()[0]  # uint32: 1 = dark, 2 = light
            dark = (val == 1)
            logger.debug(f"Initial system theme read: {'dark' if dark else 'light'}")
            self.win.apply_theme(dark)

    @pyqtSlot(str, str, QDBusVariant)
    def on_setting_changed(self, namespace, key, value):
        """
        Called whenever XDG Portal emits SettingChanged.
        Only act on 'org.freedesktop.appearance' + 'color-scheme'.
        """
        if namespace == 'org.freedesktop.appearance' and key == 'color-scheme':
            dark = (value.variant() == 1)
            logger.debug(f"Got a change from the bus for {key}: {'dark' if dark else 'light'}")
            self.win.apply_theme(dark)

