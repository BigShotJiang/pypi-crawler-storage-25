from PyQt6.QtCore import QObject, QEvent

class LiveFitFilter(QObject):
    """
    An event filter that calls widget._fit(px) on every Resize event.
    """
    def __init__(self, widget, get_px):
        """
        widget: the widget to adjust
        get_px: a callable returning the current global pixel size
        """
        super().__init__(widget)
        self._w    = widget
        self._get_px = get_px

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.Resize and obj is self._w:
            try:
                px = self._get_px()
                self._w._fit(px)
            except Exception:
                pass
        # always return False so normal processing continues
        return False
