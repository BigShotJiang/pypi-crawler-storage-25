# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

"""
Qt‑free application‑wide events.

`EventBus` is the single observer hub.
Other helper modules (e.g. window‑resize hooks) live here too.
"""

from .bus import (
    EventBus,
    create_or_get_shared_event_bus,
    get_shared_event_bus,
)

from .window import (
    setup_event_handling,
    handle_resize_event,
)

