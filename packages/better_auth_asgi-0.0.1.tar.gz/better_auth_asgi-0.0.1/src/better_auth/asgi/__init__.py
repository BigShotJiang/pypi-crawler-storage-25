"""ASGI integration namespace."""
