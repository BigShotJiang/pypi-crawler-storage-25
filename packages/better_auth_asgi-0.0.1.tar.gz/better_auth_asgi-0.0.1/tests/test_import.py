import better_auth.asgi


def test_import():
    assert better_auth.asgi.__name__ == "better_auth.asgi"
