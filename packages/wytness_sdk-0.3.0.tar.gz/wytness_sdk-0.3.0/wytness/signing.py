from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey
)
from cryptography.hazmat.primitives.serialization import (
    Encoding, PublicFormat, PrivateFormat, NoEncryption,
    load_pem_private_key, load_pem_public_key
)
from cryptography.exceptions import InvalidSignature
import base64, json
from pathlib import Path


def generate_keypair():
    private_key = Ed25519PrivateKey.generate()
    return private_key, private_key.public_key()


def save_private_key(key, path):
    pem = key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
    Path(path).write_bytes(pem)


def load_private_key(path):
    pem = Path(path).read_bytes()
    return load_pem_private_key(pem, password=None)


def load_private_key_from_base64(b64_string):
    pem = base64.b64decode(b64_string)
    return load_pem_private_key(pem, password=None)


def sign_event(event_dict, private_key):
    payload = {k: v for k, v in event_dict.items() if k != "signature"}
    message = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    return base64.b64encode(private_key.sign(message)).decode("utf-8")


def verify_event(event_dict, public_key):
    sig_b64 = event_dict.get("signature", "")
    if not sig_b64:
        return False
    payload = {k: v for k, v in event_dict.items() if k != "signature"}
    message = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    try:
        public_key.verify(base64.b64decode(sig_b64), message)
        return True
    except Exception:
        return False
