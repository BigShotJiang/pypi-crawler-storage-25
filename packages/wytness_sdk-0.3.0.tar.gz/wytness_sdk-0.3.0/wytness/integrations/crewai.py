"""Wytness integration for CrewAI.

Provides both LangChain callback support (preferred — captures prompts)
and CrewAI native step_callback/task_callback support.

Usage (LangChain callbacks — recommended):
    from wytness import AuditClient
    from wytness.integrations.crewai import WytnessCrewCallbacks

    client = AuditClient(agent_id="my-crew", http_api_key="aa_live_...")
    wytness_crew = WytnessCrewCallbacks(client)

    agent = Agent(role="...", callbacks=[wytness_crew.langchain_handler])

Usage (CrewAI native callbacks):
    crew = Crew(
        ...,
        step_callback=wytness_crew.step_callback,
        task_callback=wytness_crew.task_callback,
    )
"""

try:
    import crewai as _crewai  # noqa: F401
except ImportError:
    raise ImportError(
        "crewai is required for the CrewAI integration. "
        "Install it with: pip install wytness-sdk[crewai]"
    )

import logging
from typing import Any

from ..decorator import AuditClient, _sanitise, hash_value
from ..models import AuditEvent
from .langchain import WytnessCallbackHandler

logger = logging.getLogger(__name__)


class WytnessCrewCallbacks:
    """Wytness integration for CrewAI.

    Provides a LangChain callback handler (preferred) plus CrewAI native
    step_callback and task_callback. All methods are safe — errors are
    logged, never raised.
    """

    def __init__(self, client: AuditClient, task_id: str = "default"):
        self._client = client
        self._task_id = task_id
        self.langchain_handler = WytnessCallbackHandler(client, task_id)

    def step_callback(self, step_output: Any) -> None:
        """For use as step_callback= in CrewAI Agent or Crew."""
        try:
            tool_name = getattr(step_output, "tool", None) or "unknown"
            tool_input = getattr(step_output, "tool_input", {})
            params = tool_input if isinstance(tool_input, dict) else {"input": str(tool_input)[:500]}
            self._client.record(AuditEvent(
                agent_id=self._client.agent_id,
                agent_version=self._client.agent_version,
                human_operator_id=self._client.human_operator_id,
                task_id=self._task_id,
                session_id=self._client.session_id,
                tool_name=str(tool_name),
                tool_parameters=_sanitise(params),
                inputs_hash=hash_value(params),
                status="success",
            ))
        except Exception as e:
            logger.error(f"wytness: crewai step_callback error: {e}")

    def task_callback(self, task_output: Any) -> None:
        """For use as task_callback= in CrewAI Crew."""
        try:
            output_str = str(task_output)[:2000]
            self._client.record(AuditEvent(
                agent_id=self._client.agent_id,
                agent_version=self._client.agent_version,
                human_operator_id=self._client.human_operator_id,
                task_id=self._task_id,
                session_id=self._client.session_id,
                tool_name="crewai_task_complete",
                tool_parameters=_sanitise({"output": output_str}),
                outputs_hash=hash_value(output_str),
                status="success",
            ))
        except Exception as e:
            logger.error(f"wytness: crewai task_callback error: {e}")
