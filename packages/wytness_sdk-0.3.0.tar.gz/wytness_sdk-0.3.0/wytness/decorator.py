import asyncio, functools, hashlib, json, logging, re, time, inspect, uuid
from datetime import datetime
from .models import AuditEvent
from .signing import sign_event, load_private_key, load_private_key_from_base64, generate_keypair, save_private_key
from .chain import compute_event_hash
from .emitter import http_emit, file_emit
import os
from pathlib import Path

logger = logging.getLogger(__name__)

SECRET_PATTERNS = re.compile(r'(key|secret|token|password|passwd|pwd|credential|auth)', re.IGNORECASE)


def _sanitise(params):
    return {k: "[REDACTED]" if SECRET_PATTERNS.search(str(k)) else str(v)[:500]
            for k, v in params.items()}


def hash_value(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


class AuditClient:
    def __init__(self, agent_id, agent_version="0.1.0", human_operator_id="unknown",
                 signing_key=None, signing_key_path="./keys/signing.key",
                 fallback_log_path="./audit_fallback.jsonl",
                 http_api_key=None, http_endpoint="https://api.wytness.dev"):
        self.agent_id = agent_id
        self.agent_version = agent_version
        self.human_operator_id = human_operator_id
        self._prev_event_hash = ""
        self._session_id = str(uuid.uuid4())
        if signing_key:
            self._private_key = load_private_key_from_base64(signing_key)
        elif not os.path.exists(signing_key_path):
            Path(signing_key_path).parent.mkdir(parents=True, exist_ok=True)
            priv, _ = generate_keypair()
            save_private_key(priv, signing_key_path)
            self._private_key = priv
        else:
            self._private_key = load_private_key(signing_key_path)
        self._pending_requests = []
        if http_api_key:
            self._emit = http_emit(http_endpoint, http_api_key, fallback_log_path)
        else:
            self._emit = file_emit(fallback_log_path)

    @property
    def session_id(self):
        return self._session_id

    def record(self, event):
        """Record an audit event. Never raises — errors are logged and swallowed."""
        try:
            d = event.model_dump(mode="json")
            d["prev_event_hash"] = self._prev_event_hash
            d["signature"] = sign_event(d, self._private_key)
            self._prev_event_hash = compute_event_hash(d)
            self._emit(d)
        except Exception as e:
            logger.error(f"wytness: failed to record event: {e}")

    def flush(self, timeout=5.0):
        """Wait for pending HTTP requests to complete. No-op for file emitter.

        Call this before process exit in serverless/short-lived environments
        to ensure all events are delivered.
        """
        # Python emitter is synchronous (urllib), so nothing to flush.
        # This method exists for API consistency with the TypeScript SDK
        # and as a hook for future async transport.
        pass


def _record_event(client, func, args, kwargs, start, status, error_code, result, task_id):
    sig = inspect.signature(func)
    named = dict(zip(sig.parameters.keys(), args))
    named.update(kwargs)
    client.record(AuditEvent(
        agent_id=client.agent_id, agent_version=client.agent_version,
        human_operator_id=client.human_operator_id, task_id=task_id,
        session_id=client.session_id, tool_name=func.__name__,
        tool_parameters=_sanitise(named),
        inputs_hash=hash_value({"args": args, "kwargs": kwargs}),
        outputs_hash=hash_value(result) if result else "",
        status=status, error_code=error_code,
        duration_ms=int((time.monotonic() - start) * 1000),
    ))


def audit_tool(client, task_id="default"):
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start = time.monotonic()
                status, error_code, result = "success", None, None
                try:
                    result = await func(*args, **kwargs)
                except Exception as e:
                    status, error_code = "failure", type(e).__name__
                    raise
                finally:
                    _record_event(client, func, args, kwargs, start, status, error_code, result, task_id)
                return result
            return async_wrapper
        else:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start = time.monotonic()
                status, error_code, result = "success", None, None
                try:
                    result = func(*args, **kwargs)
                except Exception as e:
                    status, error_code = "failure", type(e).__name__
                    raise
                finally:
                    _record_event(client, func, args, kwargs, start, status, error_code, result, task_id)
                return result
            return wrapper
    return decorator
