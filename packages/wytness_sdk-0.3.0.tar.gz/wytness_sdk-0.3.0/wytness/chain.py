import hashlib, json


def compute_event_hash(event_dict):
    message = json.dumps(event_dict, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(message).hexdigest()


def verify_chain(events):
    for i in range(1, len(events)):
        expected = compute_event_hash(events[i - 1])
        actual = events[i].get("prev_event_hash", "")
        if expected != actual:
            return False, i, f"Chain broken at event {i}"
    return True, -1, "Chain valid"
