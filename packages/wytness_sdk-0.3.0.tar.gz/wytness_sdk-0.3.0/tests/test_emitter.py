import json, os, tempfile, time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from threading import Thread
from unittest.mock import patch
from wytness.emitter import http_emit, _file_emit, _REPLAY_COOLDOWN


class _IngestHandler(BaseHTTPRequestHandler):
    """Minimal HTTP handler that accepts POST /ingest and tracks received events."""
    received = []
    reject = False

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        if self.reject:
            self.send_response(503)
            self.end_headers()
            return
        self.received.append(json.loads(body))
        self.send_response(201)
        self.end_headers()

    def log_message(self, *args):
        pass  # suppress request logs


def _start_server():
    _IngestHandler.received = []
    _IngestHandler.reject = False
    server = HTTPServer(("127.0.0.1", 0), _IngestHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, port


def test_replay_drains_fallback_file():
    """Events buffered during outage are replayed when API recovers."""
    server, port = _start_server()
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            fallback = os.path.join(tmpdir, "fallback.jsonl")
            api_url = f"http://127.0.0.1:{port}"

            # Simulate outage: write 3 events directly to fallback file
            for i in range(3):
                evt = {"event_id": f"old-{i}", "agent_id": "test"}
                _file_emit(fallback, evt)

            assert Path(fallback).exists()
            assert len(Path(fallback).read_text().strip().splitlines()) == 3

            # Create emitter and send a new event (API is up now)
            emit = http_emit(api_url, "test-key", fallback)

            # Reset cooldown so replay triggers immediately
            # (the cooldown is per-closure, need to patch at module level)
            emit({"event_id": "new-1", "agent_id": "test"})

            # Server should have received the new event + 3 replayed
            assert len(_IngestHandler.received) == 4
            ids = [e["event_id"] for e in _IngestHandler.received]
            assert ids[0] == "new-1"
            assert set(ids[1:]) == {"old-0", "old-1", "old-2"}

            # Fallback file should be gone
            assert not Path(fallback).exists()
    finally:
        server.shutdown()


def test_replay_keeps_failures_in_file():
    """Events that fail to replay stay in the fallback file."""
    server, port = _start_server()
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            fallback = os.path.join(tmpdir, "fallback.jsonl")
            api_url = f"http://127.0.0.1:{port}"

            # Buffer 3 events
            for i in range(3):
                _file_emit(fallback, {"event_id": f"old-{i}", "agent_id": "test"})

            emit = http_emit(api_url, "test-key", fallback)

            # Accept the new event, then reject during replay
            original_do_post = _IngestHandler.do_POST
            call_count = [0]

            def selective_reject(handler):
                call_count[0] += 1
                if call_count[0] > 1:
                    # Reject replay events after the first (new event)
                    handler.send_response(503)
                    handler.end_headers()
                    return
                original_do_post(handler)

            _IngestHandler.do_POST = selective_reject
            emit({"event_id": "new-1", "agent_id": "test"})

            # Restore handler
            _IngestHandler.do_POST = original_do_post

            # Fallback file should still have the 3 old events
            assert Path(fallback).exists()
            remaining = Path(fallback).read_text().strip().splitlines()
            assert len(remaining) == 3
    finally:
        server.shutdown()


def test_no_replay_when_no_fallback_file():
    """No errors when there's no fallback file to replay."""
    server, port = _start_server()
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            fallback = os.path.join(tmpdir, "fallback.jsonl")
            api_url = f"http://127.0.0.1:{port}"

            emit = http_emit(api_url, "test-key", fallback)
            emit({"event_id": "e1", "agent_id": "test"})

            assert len(_IngestHandler.received) == 1
            assert not Path(fallback).exists()
    finally:
        server.shutdown()


def test_fallback_on_api_down():
    """Events go to fallback file when API is unreachable."""
    with tempfile.TemporaryDirectory() as tmpdir:
        fallback = os.path.join(tmpdir, "fallback.jsonl")
        emit = http_emit("http://127.0.0.1:1", "test-key", fallback)
        emit({"event_id": "e1", "agent_id": "test"})

        assert Path(fallback).exists()
        events = [json.loads(l) for l in Path(fallback).read_text().strip().splitlines()]
        assert len(events) == 1
        assert events[0]["event_id"] == "e1"
