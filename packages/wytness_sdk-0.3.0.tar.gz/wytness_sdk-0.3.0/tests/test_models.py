import json
from wytness.models import AuditEvent


def test_minimal_event_has_defaults():
    event = AuditEvent(
        agent_id="a1",
        agent_version="0.1.0",
        human_operator_id="u1",
        task_id="t1",
        session_id="s1",
        tool_name="do_thing",
    )
    assert event.status == "success"
    assert event.scope_token_id == "default"
    assert event.granted_by == "system"
    assert event.hitl_approved is False
    assert event.retry_count == 0
    assert event.prev_event_hash == ""
    assert event.signature == ""
    assert event.event_id  # not empty
    assert event.timestamp  # not None


def test_roundtrip_json_serialisation():
    event = AuditEvent(
        agent_id="a1",
        agent_version="0.1.0",
        human_operator_id="u1",
        task_id="t1",
        session_id="s1",
        tool_name="do_thing",
        tool_parameters={"key": "value"},
        scope_permissions=["read", "write"],
    )
    json_str = event.model_dump_json()
    restored = AuditEvent.model_validate_json(json_str)
    assert restored.agent_id == event.agent_id
    assert restored.tool_parameters == event.tool_parameters
    assert restored.scope_permissions == event.scope_permissions
    assert restored.event_id == event.event_id
