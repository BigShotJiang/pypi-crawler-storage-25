from wytness.chain import compute_event_hash, verify_chain
from wytness.models import AuditEvent


def _build_chain(count=5):
    events = []
    prev_hash = ""
    for i in range(count):
        event = AuditEvent(
            agent_id="test-agent",
            agent_version="0.1.0",
            human_operator_id="user-1",
            task_id="task-1",
            session_id="sess-1",
            tool_name=f"tool_{i}",
            prev_event_hash=prev_hash,
        )
        d = event.model_dump(mode="json")
        prev_hash = compute_event_hash(d)
        events.append(d)
    return events


def test_valid_chain_passes():
    events = _build_chain(5)
    valid, idx, msg = verify_chain(events)
    assert valid is True
    assert idx == -1
    assert msg == "Chain valid"


def test_tampered_event_breaks_chain_at_index_3():
    events = _build_chain(5)
    events[2]["tool_name"] = "tampered"
    valid, idx, msg = verify_chain(events)
    assert valid is False
    assert idx == 3
    assert "Chain broken at event 3" in msg
