from wytness.signing import generate_keypair, sign_event, verify_event
from wytness.models import AuditEvent


def _make_event_dict(**overrides):
    event = AuditEvent(
        agent_id="test-agent",
        agent_version="0.1.0",
        human_operator_id="user-1",
        task_id="task-1",
        session_id="sess-1",
        tool_name="test_tool",
        **overrides,
    )
    return event.model_dump(mode="json")


def test_sign_and_verify_roundtrip():
    priv, pub = generate_keypair()
    d = _make_event_dict()
    d["signature"] = sign_event(d, priv)
    assert verify_event(d, pub) is True


def test_tampered_event_fails_verification():
    priv, pub = generate_keypair()
    d = _make_event_dict()
    d["signature"] = sign_event(d, priv)
    d["tool_name"] = "hacked_tool"
    assert verify_event(d, pub) is False


def test_missing_signature_fails():
    _, pub = generate_keypair()
    d = _make_event_dict()
    assert verify_event(d, pub) is False
