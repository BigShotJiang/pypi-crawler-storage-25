import json, os, tempfile
from pathlib import Path
from wytness.decorator import AuditClient, audit_tool


def _make_client(tmpdir):
    key_path = os.path.join(tmpdir, "signing.key")
    log_path = os.path.join(tmpdir, "audit.jsonl")
    client = AuditClient(
        agent_id="test-agent",
        human_operator_id="user-1",
        signing_key_path=key_path,
        fallback_log_path=log_path,
    )
    return client, log_path


def _read_events(log_path):
    lines = Path(log_path).read_text().strip().splitlines()
    return [json.loads(line) for line in lines]


def test_successful_call_recorded():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)

        @audit_tool(client=client)
        def greet(name: str):
            return f"hello {name}"

        result = greet("world")
        assert result == "hello world"
        events = _read_events(log_path)
        assert len(events) == 1
        assert events[0]["tool_name"] == "greet"
        assert events[0]["status"] == "success"


def test_failed_call_records_failure():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)

        @audit_tool(client=client)
        def bad_func():
            raise ValueError("boom")

        try:
            bad_func()
        except ValueError:
            pass
        events = _read_events(log_path)
        assert len(events) == 1
        assert events[0]["status"] == "failure"
        assert events[0]["error_code"] == "ValueError"


def test_api_key_param_is_redacted():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)

        @audit_tool(client=client)
        def call_api(url: str, api_key: str):
            return "ok"

        call_api("https://example.com", api_key="super-secret")
        events = _read_events(log_path)
        assert events[0]["tool_parameters"]["api_key"] == "[REDACTED]"
        assert events[0]["tool_parameters"]["url"] == "https://example.com"


def test_duration_ms_greater_than_zero():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)

        @audit_tool(client=client)
        def slow_func():
            import time
            time.sleep(0.01)
            return "done"

        slow_func()
        events = _read_events(log_path)
        assert events[0]["duration_ms"] >= 0


def test_session_id_property():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, _ = _make_client(tmpdir)
        assert isinstance(client.session_id, str)
        assert len(client.session_id) == 36  # UUID format
        assert client.session_id == client.session_id  # stable


def test_flush_does_not_raise():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, _ = _make_client(tmpdir)
        client.flush()  # should be a no-op, no error


def test_hash_value_exported():
    from wytness import hash_value
    h = hash_value({"test": "data"})
    assert isinstance(h, str)
    assert len(h) == 64  # SHA-256 hex
    assert hash_value({"test": "data"}) == h  # deterministic
