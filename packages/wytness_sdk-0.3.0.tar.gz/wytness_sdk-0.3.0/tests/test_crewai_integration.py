import json, os, tempfile
from pathlib import Path
from wytness.decorator import AuditClient
from wytness.integrations.crewai import WytnessCrewCallbacks
from wytness.integrations.langchain import WytnessCallbackHandler


def _make_client(tmpdir):
    key_path = os.path.join(tmpdir, "signing.key")
    log_path = os.path.join(tmpdir, "audit.jsonl")
    client = AuditClient(
        agent_id="test-crew",
        human_operator_id="user-1",
        signing_key_path=key_path,
        fallback_log_path=log_path,
    )
    return client, log_path


def _read_events(log_path):
    lines = Path(log_path).read_text().strip().splitlines()
    return [json.loads(line) for line in lines]


class FakeStepOutput:
    """Mock CrewAI step output."""
    def __init__(self, tool, tool_input):
        self.tool = tool
        self.tool_input = tool_input


class FakeTaskOutput:
    """Mock CrewAI task output."""
    def __init__(self, result):
        self.result = result

    def __str__(self):
        return self.result


def test_step_callback_records_event():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        step = FakeStepOutput("search_web", {"query": "AI compliance"})
        crew_cb.step_callback(step)

        events = _read_events(log_path)
        assert len(events) == 1
        assert events[0]["tool_name"] == "search_web"
        assert events[0]["status"] == "success"


def test_task_callback_records_event():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        output = FakeTaskOutput("Report generated successfully")
        crew_cb.task_callback(output)

        events = _read_events(log_path)
        assert len(events) == 1
        assert events[0]["tool_name"] == "crewai_task_complete"
        assert events[0]["status"] == "success"


def test_langchain_handler_accessible():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, _ = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        assert isinstance(crew_cb.langchain_handler, WytnessCallbackHandler)


def test_step_callback_never_raises():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, _ = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        # Pass None — should not raise
        crew_cb.step_callback(None)


def test_task_callback_never_raises():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, _ = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        crew_cb.task_callback(None)


def test_step_callback_with_string_input():
    with tempfile.TemporaryDirectory() as tmpdir:
        client, log_path = _make_client(tmpdir)
        crew_cb = WytnessCrewCallbacks(client)

        step = FakeStepOutput("calculate", "2 + 2")
        crew_cb.step_callback(step)

        events = _read_events(log_path)
        assert events[0]["tool_name"] == "calculate"
