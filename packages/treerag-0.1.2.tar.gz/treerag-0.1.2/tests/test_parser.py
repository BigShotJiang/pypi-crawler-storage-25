"""Basic tests for docforest.parser and docforest.hierarchy."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from treerag.parser import parse_sections
from treerag.hierarchy import build_hierarchy, flatten_tree, build_tree_outline


SAMPLE_MD = """
# Introduction
Welcome to docforest.

## Installation
Install via pip.

### Requirements
Python 3.10+

## Usage
Import and call index_document.

# Advanced
More features here.
"""


def test_parse_sections():
    sections = parse_sections(SAMPLE_MD)
    titles = [s["title"] for s in sections]
    assert "Introduction" in titles
    assert "Installation" in titles
    assert "Requirements" in titles
    print(f"  ✓ parse_sections: {len(sections)} sections found")


def test_depths():
    sections = parse_sections(SAMPLE_MD)
    depth_map = {s["title"]: s["depth"] for s in sections}
    assert depth_map["Introduction"] == 1
    assert depth_map["Installation"] == 2
    assert depth_map["Requirements"] == 3
    print("  ✓ depths correct")


def test_build_hierarchy():
    sections = parse_sections(SAMPLE_MD)
    tree = build_hierarchy(sections)
    # Should have 2 root nodes: Introduction, Advanced
    assert len(tree) == 2
    # Introduction should have children
    intro = tree[0]
    assert intro["title"] == "Introduction"
    assert len(intro["nodes"]) >= 1
    print(f"  ✓ build_hierarchy: {len(tree)} root nodes")


def test_flatten_tree():
    sections = parse_sections(SAMPLE_MD)
    tree = build_hierarchy(sections)
    flat = flatten_tree(tree)
    assert len(flat) == len(sections)
    # Every node should have a breadcrumb path
    for nid, node in flat.items():
        assert "path" in node
        assert node["title"] in node["path"]
    print(f"  ✓ flatten_tree: {len(flat)} nodes, all have paths")


def test_tree_outline():
    sections = parse_sections(SAMPLE_MD)
    tree = build_hierarchy(sections)
    outline = build_tree_outline(tree)
    assert "Introduction" in outline
    assert "Installation" in outline
    assert "  -" in outline  # indented children
    print("  ✓ build_tree_outline: outline generated correctly")


def test_fallback_no_headers():
    plain_text = "Hello world. " * 200 + "\n\n" + "Another paragraph. " * 200
    sections = parse_sections(plain_text)
    assert len(sections) >= 1
    assert all(s["title"].startswith("Section") for s in sections)
    print(f"  ✓ fallback chunking: {len(sections)} sections from plain text")


if __name__ == "__main__":
    print("Running docforest tests...\n")
    test_parse_sections()
    test_depths()
    test_build_hierarchy()
    test_flatten_tree()
    test_tree_outline()
    test_fallback_no_headers()
    print("\nAll tests passed ✓")
