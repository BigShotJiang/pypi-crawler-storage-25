"""Tests for docforest.retriever — no OpenAI API calls required."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from treerag.parser import parse_sections
from treerag.hierarchy import build_hierarchy, flatten_tree, build_tree_outline
from treerag.retriever import ask, RetrieverFn


SAMPLE_MD = """
# Introduction
Welcome to docforest. This library helps you index documents.

## Installation
Run pip install docforest to get started.

### Requirements
You need Python 3.10 or higher.

## Usage
Import index_document and call it with your file path.

# Advanced
Advanced features include custom summarizers and retrievers.
"""


def _make_test_document() -> dict:
    """Build a minimal document dict without hitting any API."""
    sections = parse_sections(SAMPLE_MD)
    tree = build_hierarchy(sections)
    return {
        "tree_outline": build_tree_outline(tree),
        "flat_nodes": flatten_tree(tree),
    }


def test_ask_with_custom_retriever():
    """ask() should call the retriever and return its result."""
    doc = _make_test_document()

    def mock_retriever(query: str, tree_outline: str, flat_nodes: dict) -> str:
        assert query == "How do I install?"
        assert "Introduction" in tree_outline
        assert isinstance(flat_nodes, dict)
        return "Install via pip."

    result = ask("How do I install?", doc, mock_retriever, verbose=False)
    assert result == "Install via pip."
    print("  ✓ ask() correctly calls the retriever")


def test_ask_passes_tree_outline():
    """ask() should pass a non-empty tree_outline to the retriever."""
    doc = _make_test_document()
    received = {}

    def capture_retriever(query, tree_outline, flat_nodes):
        received["tree_outline"] = tree_outline
        received["flat_nodes"] = flat_nodes
        return "captured"

    ask("test query", doc, capture_retriever, verbose=False)
    assert "Installation" in received["tree_outline"]
    assert len(received["flat_nodes"]) > 0
    print(f"  ✓ tree_outline passed ({len(received['tree_outline'])} chars), "
          f"flat_nodes has {len(received['flat_nodes'])} nodes")


def test_ask_raises_on_missing_tree_data():
    """ask() should raise ValueError if document is missing tree data."""
    import traceback
    try:
        ask("question", {}, lambda q, t, f: "x", verbose=False)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "tree_outline" in str(e) or "flat_nodes" in str(e)
    print("  ✓ ask() raises ValueError for invalid document")


def test_retriever_fn_type():
    """RetrieverFn type alias should be importable."""
    assert RetrieverFn is not None
    print("  ✓ RetrieverFn type alias importable")


if __name__ == "__main__":
    print("Running retriever tests...\n")
    test_ask_with_custom_retriever()
    test_ask_passes_tree_outline()
    test_ask_raises_on_missing_tree_data()
    test_retriever_fn_type()
    print("\nAll retriever tests passed ✓")
