"""
treerag.retriever
-------------------
Provider-agnostic vectorless RAG Q&A pipeline using LangChain.

Works with any LangChain-compatible LLM:
    - ChatOpenAI, ChatAnthropic, ChatGoogleGenerativeAI, ChatOllama, etc.

Features:
    - Sync and async support
    - Single and multi-document Q&A
    - Streaming responses
    - Document references
    - Raw LangChain response passthrough (default)
      References are attached directly to the AIMessage object.
"""

import json
from typing import Any, AsyncGenerator, Callable, Generator, Union

from langchain_core.messages import HumanMessage, SystemMessage

# Type aliases
RetrieverFn = Callable[[str, str, dict, str, bool, str, bool], Union[dict, Generator]]
AsyncRetrieverFn = Callable[[str, str, dict, str, bool, str, bool], Any]

# ──────────────────────────────────────────────
# Default prompts
# ──────────────────────────────────────────────
DEFAULT_SEARCH_SYSTEM_PROMPT = """You are a document navigation expert.
Your job is to identify which sections of a document are most relevant to answer a user query.
Be thorough — include all sections that might contain useful information."""

DEFAULT_SEARCH_USER_PROMPT = """You are given a user query and a document's section outline.
Each section has an ID in brackets like [0001], a title, and optionally a summary.

Find ALL sections likely to contain the answer.
Return ONLY a JSON object — no markdown, no explanation:

{{"thinking": "your brief reasoning", "node_list": ["0001", "0003"]}}

Query: {query}

Document outline:
{tree_outline}"""

DEFAULT_ANSWER_SYSTEM_PROMPT = """You are a helpful research assistant.
Answer the user's question using ONLY the provided document context.

Rules:
- Cite the section name when relevant.
- ALWAYS include any links/URLs from the context using markdown format: [link text](url).
- If the context contains reference links, list them at the end of your answer.
- If the answer is not in the context, say so clearly."""

MULTI_DOC_SEARCH_SYSTEM_PROMPT = """You are a document navigation expert.
You are searching across MULTIPLE documents simultaneously.
Your job is to identify which sections across all documents are most relevant to answer a user query.
Be thorough — include all sections from any document that might contain useful information."""

MULTI_DOC_SEARCH_USER_PROMPT = """You are given a user query and outlines from MULTIPLE documents.
Each document outline is separated by a header showing the document name.
Each section has an ID in brackets like [doc_index:node_id] e.g. [0:0001], a title, and optionally a summary.

Find ALL sections across ALL documents likely to contain the answer.
Return ONLY a JSON object — no markdown, no explanation:

{{"thinking": "your brief reasoning", "node_list": ["0:0001", "1:0003"]}}

Query: {query}

Document outlines:
{tree_outlines}"""


# ──────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────
def _build_messages(
    query: str,
    contexts: list[dict],
    extra_context: str,
    answer_system_prompt: str,
) -> list:
    """Build messages list for answer generation."""
    context_parts = [
        f"[Section: {ctx['path']} | File: {ctx['file_name']}]\n{ctx['text']}"
        for ctx in contexts
    ]
    combined = "\n\n---\n\n".join(context_parts)

    system = answer_system_prompt
    if extra_context:
        system += f"\n\nAdditional context:\n{extra_context}"

    return [
        SystemMessage(content=system),
        HumanMessage(content=f"Document Context:\n{combined}\n\nQuestion: {query}"),
    ]


def _build_references(contexts: list[dict]) -> list[dict]:
    """Build references list from contexts."""
    return [
        {
            "node_id": ctx["node_id"],
            "title": ctx["title"],
            "path": ctx["path"],
            "file_name": ctx["file_name"],
        }
        for ctx in contexts
    ]


def _get_node_contents(
    node_ids: list[str],
    flat_nodes: dict,
    file_name: str = "",
) -> list[dict]:
    """Fetch full text for each matched node ID."""
    contents = []
    for nid in node_ids:
        node = flat_nodes.get(nid)
        if node and node.get("text"):
            contents.append({
                "node_id": nid,
                "title": node["title"],
                "path": node.get("path", node["title"]),
                "text": node["text"],
                "file_name": file_name,
            })
    return contents


def _parse_node_ids(raw: str) -> list[str]:
    """Parse node IDs from LLM JSON response."""
    cleaned = raw.strip().replace("```json", "").replace("```", "").strip()
    try:
        result = json.loads(cleaned)
        return result.get("node_list", [])
    except json.JSONDecodeError:
        return []


def _enrich_response(response: Any, contexts: list[dict]) -> Any:
    """Attach references directly to a LangChain AIMessage object."""
    response.references = _build_references(contexts)
    return response


# ──────────────────────────────────────────────
# Sync retriever
# ──────────────────────────────────────────────
def make_retriever(
    llm,
    search_llm=None,
    search_system_prompt: str = DEFAULT_SEARCH_SYSTEM_PROMPT,
    search_user_prompt_template: str = DEFAULT_SEARCH_USER_PROMPT,
    answer_system_prompt: str = DEFAULT_ANSWER_SYSTEM_PROMPT,
) -> RetrieverFn:
    """
    Factory that returns a sync LangChain-backed retriever function.

    Args:
        llm:                         LLM for answer generation.
        search_llm:                  LLM for tree search. Defaults to llm if not set.
        search_system_prompt:        System prompt for tree search step.
        search_user_prompt_template: User prompt template. Must have {query} and {tree_outline}.
        answer_system_prompt:        System prompt for answer step.
                                     Override to add document-specific instructions.
                                     Tip: add "Always respond in markdown format." to get
                                     structured markdown responses.

    Returns:
        A RetrieverFn. By default returns enriched LangChain AIMessage with .references attached.
        Pass return_raw=False to get a plain dict with "answer" and "references" keys instead.

    Example:
        from langchain_openai import ChatOpenAI

        retriever = make_retriever(ChatOpenAI(model="gpt-4o"))

        # default — raw AIMessage with references attached
        result = ask("What is this?", doc, retriever)
        print(result.content)     # answer text
        print(result.references)  # sections used

        # plain dict
        result = ask("What is this?", doc, retriever, return_raw=False)
        print(result["answer"])
        print(result["references"])
    """
    _search_llm = search_llm or llm

    def _find_relevant_nodes(query: str, tree_outline: str) -> list[str]:
        user_prompt = search_user_prompt_template.format(
            query=query, tree_outline=tree_outline
        )
        messages = [
            SystemMessage(content=search_system_prompt),
            HumanMessage(content=user_prompt),
        ]
        response = _search_llm.invoke(messages)
        return _parse_node_ids(response.content)

    def _generate_answer(
        query: str,
        contexts: list[dict],
        extra_context: str = "",
        return_raw: bool = True,
    ) -> Union[dict, Any]:
        if not contexts:
            if return_raw:
                from langchain_core.messages import AIMessage
                response = AIMessage(content="No relevant content found in the document.")
                response.references = []
                return response
            return {"answer": "No relevant content found in the document.", "references": []}

        messages = _build_messages(query, contexts, extra_context, answer_system_prompt)
        response = llm.invoke(messages)

        if return_raw:
            return _enrich_response(response, contexts)

        return {
            "answer": response.content,
            "references": _build_references(contexts),
        }

    def _generate_answer_stream(
        query: str,
        contexts: list[dict],
        extra_context: str = "",
    ) -> Generator:
        if not contexts:
            yield "No relevant content found in the document."
            yield {"__references__": []}
            return

        messages = _build_messages(query, contexts, extra_context, answer_system_prompt)
        for chunk in llm.stream(messages):
            if chunk.content:
                yield chunk.content

        # Yield references once after all chunks
        yield {"__references__": _build_references(contexts)}

    def _retrieve(
        query: str,
        tree_outline: str,
        flat_nodes: dict,
        extra_context: str = "",
        stream: bool = False,
        file_name: str = "",
        return_raw: bool = True,
    ) -> Union[dict, Generator, Any]:
        node_ids = _find_relevant_nodes(query, tree_outline)
        contexts = _get_node_contents(node_ids, flat_nodes, file_name)
        if stream:
            return _generate_answer_stream(query, contexts, extra_context)
        return _generate_answer(query, contexts, extra_context, return_raw)

    return _retrieve


# ──────────────────────────────────────────────
# Async retriever
# ──────────────────────────────────────────────
def make_async_retriever(
    llm,
    search_llm=None,
    search_system_prompt: str = DEFAULT_SEARCH_SYSTEM_PROMPT,
    search_user_prompt_template: str = DEFAULT_SEARCH_USER_PROMPT,
    answer_system_prompt: str = DEFAULT_ANSWER_SYSTEM_PROMPT,
) -> AsyncRetrieverFn:
    """
    Factory that returns an async LangChain-backed retriever function.

    Same interface as make_retriever() but uses ainvoke() and astream() internally.
    Use with any async framework — FastAPI, asyncio, LangGraph, etc.

    Example:
        retriever = make_async_retriever(ChatOpenAI(model="gpt-4o"))

        # async default — raw AIMessage with references
        result = await aask("What is this?", doc, retriever)
        print(result.content)
        print(result.references)

        # async streaming
        async for chunk in await aask("What is this?", doc, retriever, stream=True):
            if isinstance(chunk, dict):
                print(chunk["__references__"])
            else:
                print(chunk, end="", flush=True)
    """
    _search_llm = search_llm or llm

    async def _find_relevant_nodes(query: str, tree_outline: str) -> list[str]:
        user_prompt = search_user_prompt_template.format(
            query=query, tree_outline=tree_outline
        )
        messages = [
            SystemMessage(content=search_system_prompt),
            HumanMessage(content=user_prompt),
        ]
        response = await _search_llm.ainvoke(messages)
        return _parse_node_ids(response.content)

    async def _generate_answer(
        query: str,
        contexts: list[dict],
        extra_context: str = "",
        return_raw: bool = True,
    ) -> Union[dict, Any]:
        if not contexts:
            if return_raw:
                from langchain_core.messages import AIMessage
                response = AIMessage(content="No relevant content found in the document.")
                response.references = []
                return response
            return {"answer": "No relevant content found in the document.", "references": []}

        messages = _build_messages(query, contexts, extra_context, answer_system_prompt)
        response = await llm.ainvoke(messages)

        if return_raw:
            return _enrich_response(response, contexts)

        return {
            "answer": response.content,
            "references": _build_references(contexts),
        }

    async def _generate_answer_stream(
        query: str,
        contexts: list[dict],
        extra_context: str = "",
    ) -> AsyncGenerator:
        if not contexts:
            yield "No relevant content found in the document."
            yield {"__references__": []}
            return

        messages = _build_messages(query, contexts, extra_context, answer_system_prompt)
        async for chunk in llm.astream(messages):
            if chunk.content:
                yield chunk.content

        yield {"__references__": _build_references(contexts)}

    async def _retrieve(
        query: str,
        tree_outline: str,
        flat_nodes: dict,
        extra_context: str = "",
        stream: bool = False,
        file_name: str = "",
        return_raw: bool = True,
    ) -> Union[dict, AsyncGenerator, Any]:
        node_ids = await _find_relevant_nodes(query, tree_outline)
        contexts = _get_node_contents(node_ids, flat_nodes, file_name)
        if stream:
            return _generate_answer_stream(query, contexts, extra_context)
        return await _generate_answer(query, contexts, extra_context, return_raw)

    return _retrieve


# ──────────────────────────────────────────────
# Sync ask()
# ──────────────────────────────────────────────
def ask(
    query: str,
    document: dict,
    retriever: RetrieverFn,
    extra_context: str = "",
    stream: bool = False,
    return_raw: bool = True,
    verbose: bool = False,
) -> Union[dict, Generator, Any]:
    """
    Ask a question about a single indexed document (sync).

    Args:
        query:         The question to answer.
        document:      Indexed document dict from get_document() or index_document().
        retriever:     A RetrieverFn from make_retriever().
        extra_context: Optional extra context injected into the answer prompt.
        stream:        If True, returns a Generator yielding chunks then references.
        return_raw:    If True (default), returns enriched LangChain AIMessage with
                       .references attached. If False, returns plain dict.
        verbose:       If True, prints progress. Default False.

    Returns:
        return_raw=True (default):
            LangChain AIMessage with .references attached.
            result.content       → answer text
            result.references    → list of sections used
            result.response_metadata → token usage, model name, etc

        return_raw=False:
            dict {"answer": str, "references": list}

        stream=True:
            Generator yielding str chunks, then {"__references__": list}

    Example:
        # default — raw AIMessage
        result = ask("What is this?", doc, retriever)
        print(result.content)
        print(result.references)
        print(result.response_metadata)

        # plain dict
        result = ask("What is this?", doc, retriever, return_raw=False)
        print(result["answer"])
        print(result["references"])

        # streaming
        for chunk in ask("What is this?", doc, retriever, stream=True):
            if isinstance(chunk, dict):
                print(chunk["__references__"])
            else:
                print(chunk, end="", flush=True)
    """
    tree_outline = document.get("tree_outline")
    flat_nodes = document.get("flat_nodes")
    file_name = document.get("file_name", "")

    if not tree_outline or not flat_nodes:
        raise ValueError(
            "Document is missing 'tree_outline' or 'flat_nodes'. "
            "Re-index with index_document()."
        )

    def log(msg: str):
        if verbose:
            print(msg)

    log("[treerag] Searching document tree...")
    result = retriever(query, tree_outline, flat_nodes, extra_context, stream, file_name, return_raw)
    log("[treerag] Done.\n")
    return result


# ──────────────────────────────────────────────
# Async aask()
# ──────────────────────────────────────────────
async def aask(
    query: str,
    document: dict,
    retriever: AsyncRetrieverFn,
    extra_context: str = "",
    stream: bool = False,
    return_raw: bool = True,
    verbose: bool = False,
) -> Union[dict, AsyncGenerator, Any]:
    """
    Ask a question about a single indexed document (async).

    Same interface as ask() but async. Use with make_async_retriever().

    Example:
        retriever = make_async_retriever(ChatOpenAI(model="gpt-4o"))

        result = await aask("What is this?", doc, retriever)
        print(result.content)
        print(result.references)

        async for chunk in await aask("What is this?", doc, retriever, stream=True):
            if isinstance(chunk, dict):
                print(chunk["__references__"])
            else:
                print(chunk, end="", flush=True)
    """
    tree_outline = document.get("tree_outline")
    flat_nodes = document.get("flat_nodes")
    file_name = document.get("file_name", "")

    if not tree_outline or not flat_nodes:
        raise ValueError(
            "Document is missing 'tree_outline' or 'flat_nodes'. "
            "Re-index with index_document()."
        )

    def log(msg: str):
        if verbose:
            print(msg)

    log("[treerag] Searching document tree...")
    result = await retriever(query, tree_outline, flat_nodes, extra_context, stream, file_name, return_raw)
    log("[treerag] Done.\n")
    return result


# ──────────────────────────────────────────────
# Multi-document ask_multi()
# ──────────────────────────────────────────────
def ask_multi(
    query: str,
    documents: list[dict],
    retriever: RetrieverFn,
    extra_context: str = "",
    stream: bool = False,
    return_raw: bool = True,
    verbose: bool = False,
) -> Union[dict, Generator, Any]:
    """
    Ask a question across multiple indexed documents (sync).

    Searches all documents simultaneously and generates a single unified answer
    with references showing which document and section each piece came from.

    Args:
        query:         The question to answer.
        documents:     List of indexed document dicts. None entries are skipped.
        retriever:     A RetrieverFn from make_retriever().
        extra_context: Optional extra context injected into the answer prompt.
        stream:        If True, returns a Generator yielding chunks then references.
        return_raw:    If True (default), returns enriched AIMessage with .references.
        verbose:       If True, prints progress. Default False.

    Example:
        doc1 = get_document("doc1.md")
        doc2 = get_document("doc2.md")

        retriever = make_retriever(ChatOpenAI(model="gpt-4o"))
        result = ask_multi("What is budget cap?", [doc1, doc2], retriever)
        print(result.content)
        print(result.references)  # shows which file each section came from
    """
    if not documents:
        raise ValueError("documents list is empty.")

    def log(msg: str):
        if verbose:
            print(msg)

    log(f"[treerag] Searching {len(documents)} documents...")

    all_contexts = []
    for i, doc in enumerate(documents):
        if doc is None:
            continue

        tree_outline = doc.get("tree_outline", "")
        flat_nodes = doc.get("flat_nodes", {})
        file_name = doc.get("file_name", f"document_{i}")

        if not tree_outline or not flat_nodes:
            continue

        # Get relevant nodes per doc using return_raw=False to get plain dict
        doc_result = retriever(query, tree_outline, flat_nodes, extra_context, False, file_name, False)
        if isinstance(doc_result, dict) and doc_result.get("references"):
            for ref in doc_result["references"]:
                node = flat_nodes.get(ref["node_id"])
                if node:
                    all_contexts.append({
                        "node_id": ref["node_id"],
                        "title": ref["title"],
                        "path": ref["path"],
                        "text": node["text"],
                        "file_name": file_name,
                    })

    log("[treerag] Done.\n")

    if not all_contexts:
        if return_raw:
            from langchain_core.messages import AIMessage
            response = AIMessage(content="No relevant content found across the documents.")
            response.references = []
            return response
        return {"answer": "No relevant content found across the documents.", "references": []}

    # Build a synthetic flat_nodes from merged contexts
    synthetic_flat = {ctx["node_id"]: ctx for ctx in all_contexts}
    synthetic_outline = "\n".join(
        f"- [{ctx['node_id']}] {ctx['title']} ({ctx['file_name']})"
        for ctx in all_contexts
    )
    node_ids = list(synthetic_flat.keys())

    return retriever(
        query,
        synthetic_outline,
        synthetic_flat,
        extra_context,
        stream,
        "multi-document",
        return_raw,
    )


# ──────────────────────────────────────────────
# Async aask_multi()
# ──────────────────────────────────────────────
async def aask_multi(
    query: str,
    documents: list[dict],
    retriever: AsyncRetrieverFn,
    extra_context: str = "",
    stream: bool = False,
    return_raw: bool = True,
    verbose: bool = False,
) -> Union[dict, AsyncGenerator, Any]:
    """
    Ask a question across multiple indexed documents (async).

    Same as ask_multi() but async. Use with make_async_retriever().

    Example:
        retriever = make_async_retriever(ChatOpenAI(model="gpt-4o"))
        result = await aask_multi("What is budget cap?", [doc1, doc2], retriever)
        print(result.content)
        print(result.references)
    """
    if not documents:
        raise ValueError("documents list is empty.")

    def log(msg: str):
        if verbose:
            print(msg)

    log(f"[treerag] Searching {len(documents)} documents (async)...")

    all_contexts = []
    for i, doc in enumerate(documents):
        if doc is None:
            continue

        tree_outline = doc.get("tree_outline", "")
        flat_nodes = doc.get("flat_nodes", {})
        file_name = doc.get("file_name", f"document_{i}")

        if not tree_outline or not flat_nodes:
            continue

        doc_result = await retriever(query, tree_outline, flat_nodes, extra_context, False, file_name, False)
        if isinstance(doc_result, dict) and doc_result.get("references"):
            for ref in doc_result["references"]:
                node = flat_nodes.get(ref["node_id"])
                if node:
                    all_contexts.append({
                        "node_id": ref["node_id"],
                        "title": ref["title"],
                        "path": ref["path"],
                        "text": node["text"],
                        "file_name": file_name,
                    })

    log("[treerag] Done.\n")

    if not all_contexts:
        if return_raw:
            from langchain_core.messages import AIMessage
            response = AIMessage(content="No relevant content found across the documents.")
            response.references = []
            return response
        return {"answer": "No relevant content found across the documents.", "references": []}

    synthetic_flat = {ctx["node_id"]: ctx for ctx in all_contexts}
    synthetic_outline = "\n".join(
        f"- [{ctx['node_id']}] {ctx['title']} ({ctx['file_name']})"
        for ctx in all_contexts
    )

    return await retriever(
        query,
        synthetic_outline,
        synthetic_flat,
        extra_context,
        stream,
        "multi-document",
        return_raw,
    )