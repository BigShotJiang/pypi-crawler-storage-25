"""
treerag.reader
----------------
Reads .txt, .md, .pdf, .docx files and URLs into raw string content.

Supported inputs:
    - .txt, .md, .markdown  — plain text files
    - .pdf                  — PDF files (requires pymupdf)
    - .docx                 — Word documents (requires python-docx)
    - http:// / https://    — Web URLs (requires requests + beautifulsoup4)
"""

import os


def read_file(file_path: str) -> str:
    """
    Read a file or URL and return its content as a string.

    Supported formats:
        - .txt, .md, .markdown  — plain text, returned as-is
        - .pdf                  — extracted via PyMuPDF
        - .docx                 — extracted via python-docx
        - http:// / https://    — scraped via requests + beautifulsoup4,
                                  HTML headings converted to markdown headers
                                  so parse_sections() can build a proper tree

    Args:
        file_path: Path to the file OR a full URL starting with http/https.

    Returns:
        Raw string content of the file or page.

    Raises:
        FileNotFoundError: If the file does not exist.
        ImportError:       If a required optional package is not installed.
        ValueError:        If the file extension is not supported.

    Examples:
        text = read_file("my_doc.md")
        text = read_file("report.pdf")
        text = read_file("document.docx")
        text = read_file("https://en.wikipedia.org/wiki/Advertising")
    """

    # ── URL ──────────────────────────────────────────────
    if file_path.startswith("http://") or file_path.startswith("https://"):
        return _read_url(file_path)

    # ── File ─────────────────────────────────────────────
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()

    if ext in (".txt", ".md", ".markdown"):
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()

    elif ext == ".pdf":
        return _read_pdf(file_path)

    elif ext == ".docx":
        return _read_docx(file_path)

    else:
        raise ValueError(
            f"Unsupported file type: '{ext}'. "
            "Supported: .txt, .md, .pdf, .docx, or a URL starting with http/https"
        )


# ──────────────────────────────────────────────
# PDF reader
# ──────────────────────────────────────────────
def _read_pdf(file_path: str) -> str:
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise ImportError(
            "PDF support requires PyMuPDF. "
            "Install it with: pip install pymupdf"
        )
    doc = fitz.open(file_path)
    pages = []
    for i, page in enumerate(doc):
        text = page.get_text()
        if text.strip():
            pages.append(f"--- PAGE {i + 1} ---\n{text}")
    doc.close()
    return "\n\n".join(pages)


# ──────────────────────────────────────────────
# DOCX reader
# ──────────────────────────────────────────────
def _read_docx(file_path: str) -> str:
    try:
        import docx
    except ImportError:
        raise ImportError(
            "DOCX support requires python-docx. "
            "Install it with: pip install python-docx"
        )
    doc = docx.Document(file_path)
    paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
    return "\n\n".join(paragraphs)


# ──────────────────────────────────────────────
# URL reader via requests + beautifulsoup4
# ──────────────────────────────────────────────
def _read_url(url: str) -> str:
    """
    Scrape a URL and return clean content as a markdown-like string.

    HTML headings (h1-h6) are converted to markdown headers (#, ##, etc.)
    so that parse_sections() can build a proper hierarchical tree.

    Note: Does not support JS-rendered pages.
    For JS-heavy sites, use crawl4ai manually.
    """
    try:
        import requests
        from bs4 import BeautifulSoup, Tag, NavigableString
    except ImportError:
        raise ImportError(
            "URL support requires requests and beautifulsoup4. "
            "Install with: pip install requests beautifulsoup4"
        )

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    }

    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")

    # Remove noise tags
    for tag in soup(["script", "style", "nav", "footer", "header", "aside", "form"]):
        tag.decompose()

    # Find main content area
    main = (
        soup.find("main")
        or soup.find("article")
        or soup.find(id="content")
        or soup.find(id="main-content")
        or soup.find(class_="content")
        or soup.find(class_="main-content")
        or soup.body
    )

    if not main:
        return soup.get_text(separator="\n", strip=True)

    # Walk the DOM — convert headings to markdown, paragraphs to text
    HEADING_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6"}
    BLOCK_TAGS = {"p", "li", "td", "th", "blockquote", "pre", "code"}
    seen = set()
    lines = []

    for element in main.descendants:
        if not isinstance(element, Tag):
            continue

        # Skip already-processed elements
        if id(element) in seen:
            continue

        if element.name in HEADING_TAGS:
            level = int(element.name[1])
            text = element.get_text(" ", strip=True)
            if text:
                lines.append(f"{'#' * level} {text}")
                # Mark all children as seen
                for child in element.descendants:
                    seen.add(id(child))
                seen.add(id(element))

        elif element.name in BLOCK_TAGS:
            text = element.get_text(" ", strip=True)
            if text:
                lines.append(text)
                for child in element.descendants:
                    seen.add(id(child))
                seen.add(id(element))

    # Remove duplicate blank lines and return
    cleaned = "\n\n".join(line for line in lines if line.strip())
    return cleaned