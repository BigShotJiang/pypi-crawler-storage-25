"""
treerag.summarizer
--------------------
Provider-agnostic summarization layer using LangChain.

Works with any LangChain-compatible LLM:
    - ChatOpenAI, ChatAnthropic, ChatGoogleGenerativeAI, ChatOllama, etc.

Any callable matching SummarizerFn can also be plugged in directly.
"""

import json
from typing import Callable

from langchain_core.messages import HumanMessage, SystemMessage

# Type alias: receives list of sections, returns same list with 'summary' filled
SummarizerFn = Callable[[list[dict]], list[dict]]

DEFAULT_SYSTEM_PROMPT = """You are a document analysis expert.
Your job is to generate concise, accurate summaries of document sections.
Summaries must be clear and capture the key purpose of each section."""

DEFAULT_USER_PROMPT = """Generate a concise summary (max 25 words) AND relevant tags for each section.
Tags must include all named people, places, organizations, events and key terms.

Return ONLY a JSON object mapping node_id to {{summary, tags}}.
No markdown fences, no explanation, no preamble.

Example:
{{
  "0000": {{"summary": "Overview of the main topic and core concepts", "tags": ["topic", "concept", "overview"]}},
  "0001": {{"summary": "Detailed explanation of the process and key steps", "tags": ["process", "steps", "methodology"]}}
}}

Sections:
{section_list}"""


# ──────────────────────────────────────────────
# Built-in: LangChain summarizer
# ──────────────────────────────────────────────
def make_summarizer(
    llm,
    system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    user_prompt_template: str = DEFAULT_USER_PROMPT,
) -> SummarizerFn:
    """
    Factory that returns a LangChain-backed summarizer function.

    Works with any LangChain chat model — OpenAI, Anthropic, Gemini, Ollama, etc.

    Args:
        llm:                  Any LangChain BaseChatModel instance.
        system_prompt:        System-level instruction for the LLM.
                              Override to make it domain-specific.
        user_prompt_template: Template string for the user message.
                              Must contain {section_list} placeholder.

    Returns:
        A SummarizerFn that fills 'summary' on each section dict.

    Examples:
        from langchain_openai import ChatOpenAI
        from langchain_anthropic import ChatAnthropic
        from langchain_ollama import ChatOllama

        # Generic — works for any document
        summarizer = make_summarizer(ChatOpenAI(model="gpt-4o-mini"))

        # Domain-specific prompt
        summarizer = make_summarizer(
            ChatOpenAI(model="gpt-4o-mini"),
            system_prompt=(
                "You are a legal expert. Summarize clauses, obligations, and key terms precisely."
            )
        )
    """

    def _summarize(sections: list[dict]) -> list[dict]:
        section_list = ""
        for sec in sections:
            preview = sec["text"][:250].replace("\n", " ")
            section_list += (
                f"[{sec['node_id']}] (depth={sec['depth']}) {sec['title']}\n"
                f"  Content: {preview}\n\n"
            )

        user_prompt = user_prompt_template.format(section_list=section_list)

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ]

        response = llm.invoke(messages)
        raw = response.content.strip()
        cleaned = raw.replace("```json", "").replace("```", "").strip()

        try:
            summary_map: dict = json.loads(cleaned)
        except json.JSONDecodeError:
            summary_map = {}

        for sec in sections:
            nid = sec["node_id"]
            entry = summary_map.get(nid, {})
            if isinstance(entry, dict):
                sec["summary"] = entry.get("summary", sec["text"][:120].replace("\n", " "))
                sec["tags"] = entry.get("tags", [])
            else:
                # fallback if LLM returned plain string
                sec["summary"] = entry if entry else sec["text"][:120].replace("\n", " ")
                sec["tags"] = []

        return sections

    return _summarize


# ──────────────────────────────────────────────
# Null summarizer (no-op — skips LLM entirely)
# ──────────────────────────────────────────────
def null_summarizer(sections: list[dict]) -> list[dict]:
    """
    A no-op summarizer — uses first 120 chars of text as summary.
    Useful for local dev/testing without any LLM API calls.
    """
    for sec in sections:
        sec["summary"] = sec["text"][:120].replace("\n", " ")
        sec["tags"] = []
    return sections
