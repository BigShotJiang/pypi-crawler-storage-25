"""
treerag 🌳

Lightweight structural RAG library — index documents as hierarchical trees
and query them without a vector database.

Supports:
- .txt, .md, .pdf, .docx, URLs
- Any LangChain-compatible LLM (OpenAI, Anthropic, Gemini, Ollama)

Core flow:
    index_document → ask

Example:
    from treerag import index_document, ask, make_retriever
"""

from .indexer import index_document
from .reader import read_file
from .parser import parse_sections
from .hierarchy import build_hierarchy, flatten_tree, build_tree_outline, print_tree
from .registry import (
    load_registry,
    save_registry,
    list_documents,
    get_document,
    get_document_by_id,
    delete_document,
)
from .summarizer import make_summarizer, null_summarizer, SummarizerFn
from .retriever import (
    make_retriever,
    make_async_retriever,
    ask,
    aask,
    ask_multi,
    aask_multi,
    RetrieverFn,
    AsyncRetrieverFn,
)

__version__ = "0.1.0"

__all__ = [
    # Core API
    "index_document",
    "ask",
    "ask_multi",
    "aask",
    "aask_multi",

    # Pipeline steps
    "read_file",
    "parse_sections",
    "build_hierarchy",
    "flatten_tree",
    "build_tree_outline",
    "print_tree",

    # Registry
    "load_registry",
    "save_registry",
    "list_documents",
    "get_document",
    "get_document_by_id",
    "delete_document",

    # Summarizers
    "make_summarizer",
    "null_summarizer",
    "SummarizerFn",

    # Retrievers
    "make_retriever",
    "make_async_retriever",
    "RetrieverFn",
    "AsyncRetrieverFn",
]