"""
treerag.parser
----------------
Parses raw document text into a flat list of sections
using markdown headers. Falls back to paragraph chunking
if no headers are found.
"""

import re


def parse_sections(text: str, fallback_chunk_words: int = 500) -> list[dict]:
    """
    Parse markdown text into a flat list of sections.

    Each section is a dict with:
        - node_id (str):  zero-padded index, e.g. "0003"
        - title   (str):  header text or auto-generated "Section N"
        - depth   (int):  heading level (1–6), or 1 for fallback chunks
        - text    (str):  content under the header

    Args:
        text:                Raw document string.
        fallback_chunk_words: Word threshold for paragraph-based chunking
                              when no markdown headers are found.

    Returns:
        List of section dicts.
    """
    header_pattern = r"^(#{1,6})\s+(.+)$"
    lines = text.split("\n")
    sections = []
    current_title = "Document Root"
    current_depth = 0
    current_lines: list[str] = []
    found_headers = False

    for line in lines:
        match = re.match(header_pattern, line)
        if match:
            found_headers = True
            content = "\n".join(current_lines).strip()
            if content:
                sections.append(
                    {
                        "title": current_title,
                        "depth": current_depth,
                        "text": content,
                    }
                )
            current_depth = len(match.group(1))
            current_title = match.group(2).strip()
            current_lines = [line]
        else:
            current_lines.append(line)

    # Save last section
    content = "\n".join(current_lines).strip()
    if content:
        sections.append(
            {
                "title": current_title,
                "depth": current_depth,
                "text": content,
            }
        )

    # Fallback: no headers → chunk by paragraphs
    if not found_headers:
        sections = []
        paragraphs = text.split("\n\n")
        chunk: list[str] = []
        chunk_idx = 1

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            chunk.append(para)
            if sum(len(c.split()) for c in chunk) >= fallback_chunk_words:
                sections.append(
                    {
                        "title": f"Section {chunk_idx}",
                        "depth": 1,
                        "text": "\n\n".join(chunk),
                    }
                )
                chunk = []
                chunk_idx += 1

        if chunk:
            sections.append(
                {
                    "title": f"Section {chunk_idx}",
                    "depth": 1,
                    "text": "\n\n".join(chunk),
                }
            )

    # Assign node IDs
    for i, sec in enumerate(sections):
        sec["node_id"] = f"{i:04d}"

    return sections
