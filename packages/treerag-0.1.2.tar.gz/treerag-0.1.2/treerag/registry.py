"""
treerag.registry
------------------
Handles loading and saving the local document registry (indexed_docs.json).
"""

import json
import os

DEFAULT_REGISTRY_FILE = "indexed_docs.json"


def load_registry(registry_path: str = DEFAULT_REGISTRY_FILE) -> dict:
    if os.path.exists(registry_path):
        with open(registry_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_registry(registry: dict, registry_path: str = DEFAULT_REGISTRY_FILE) -> None:
    with open(registry_path, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2, ensure_ascii=False)


def list_documents(registry_path: str = DEFAULT_REGISTRY_FILE) -> list[dict]:
    """
    List all documents currently in the registry.

    Returns:
        List of dicts with keys: name (file_name), doc_id, total_sections, indexed_at.
    """
    registry = load_registry(registry_path)
    return [
        {
            "name": info.get("file_name", doc_id),  # show file_name, fallback to UUID
            "doc_id": doc_id,
            "total_sections": info.get("total_sections", "?"),
            "indexed_at": info.get("indexed_at", "unknown"),
        }
        for doc_id, info in registry.items()
    ]


def get_document(
    file_name: str, registry_path: str = DEFAULT_REGISTRY_FILE
) -> dict | None:
    """
    Retrieve a single indexed document by file name.
    Searches registry values since keys are UUIDs.
    """
    registry = load_registry(registry_path)
    for entry in registry.values():
        if entry.get("file_name") == file_name:
            return entry
    return None


def get_document_by_id(
    doc_id: str, registry_path: str = DEFAULT_REGISTRY_FILE
) -> dict | None:
    """
    Retrieve a single indexed document by its UUID. O(1) lookup.
    """
    registry = load_registry(registry_path)
    return registry.get(doc_id)


def delete_document(
    doc_id: str, registry_path: str = DEFAULT_REGISTRY_FILE
) -> bool:
    """
    Remove a document from the registry by its UUID.

    Returns:
        True if removed, False if not found.
    """
    registry = load_registry(registry_path)
    if doc_id in registry:
        del registry[doc_id]
        save_registry(registry, registry_path)
        return True
    return False
