"""
treerag.hierarchy
-------------------
Builds a parent→child tree from flat sections and provides
utility functions to flatten, outline, and print the tree.
"""


def build_hierarchy(sections: list[dict]) -> list[dict]:
    """
    Convert a flat list of sections (with depth) into a nested tree.

    Each node contains:
        title, node_id, depth, text, summary, nodes (children list)

    Args:
        sections: Flat list from parse_sections(), optionally with summaries.

    Returns:
        List of root-level nodes, each with nested children under 'nodes'.
    """
    nodes = [
        {
            "title": sec["title"],
            "node_id": sec["node_id"],
            "depth": sec["depth"],
            "text": sec["text"],
            "summary": sec.get("summary", ""),
            "tags": sec.get("tags", []),
            "nodes": [],
        }
        for sec in sections
    ]

    root_nodes: list[dict] = []
    stack: list[tuple[int, dict]] = []  # (depth, node)

    for node in nodes:
        while stack and stack[-1][0] >= node["depth"]:
            stack.pop()

        if stack:
            stack[-1][1]["nodes"].append(node)
        else:
            root_nodes.append(node)

        stack.append((node["depth"], node))

    return root_nodes


def flatten_tree(tree: list[dict], parent_path: str = "") -> dict:
    """
    Recursively flatten the tree into a {node_id: {...}} lookup dict.

    Each entry contains:
        title, text, summary, path (breadcrumb string)

    Args:
        tree:        Nested tree from build_hierarchy().
        parent_path: Used internally for recursion. Leave as default.

    Returns:
        Flat dict mapping node_id → node metadata.
    """
    flat: dict = {}
    for node in tree:
        path = f"{parent_path} > {node['title']}" if parent_path else node["title"]
        flat[node["node_id"]] = {
            "title": node["title"],
            "text": node["text"],
            "summary": node.get("summary", ""),
            "tags": node.get("tags", []),
            "path": path,
        }
        if node.get("nodes"):
            flat.update(flatten_tree(node["nodes"], path))
    return flat


def build_tree_outline(tree: list[dict], depth: int = 0) -> str:
    """
    Build an indented text outline of the tree, suitable for LLM context.

    Example output:
        - [0000] Introduction — Overview of the platform
          - [0001] Installation — Steps to install the package

    Args:
        tree:  Nested tree from build_hierarchy().
        depth: Used internally for recursion. Leave as default.

    Returns:
        Multi-line indented string.
    """
    lines = []
    indent = "  " * depth
    for node in tree:
        summary_snippet = node.get("summary", "")[:120]
        line = f"{indent}- [{node['node_id']}] {node['title']}"
        if summary_snippet:
            line += f" — {summary_snippet}"
        tags = node.get("tags", [])
        if tags:
            line += f" | Tags: {', '.join(tags)}"
        lines.append(line)
        if node.get("nodes"):
            lines.append(build_tree_outline(node["nodes"], depth + 1))
    return "\n".join(lines)


def print_tree(tree: list[dict], depth: int = 0) -> None:
    """
    Print the tree to stdout with indentation.

    Args:
        tree:  Nested tree from build_hierarchy().
        depth: Used internally for recursion. Leave as default.
    """
    indent = "  " * depth
    for node in tree:
        children_count = len(node.get("nodes", []))
        suffix = f" [{children_count} children]" if children_count else ""
        print(f"{indent}[{node['node_id']}] {node['title']}{suffix}")
        if node.get("nodes"):
            print_tree(node["nodes"], depth + 1)
