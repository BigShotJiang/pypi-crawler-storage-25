"""
treerag.indexer
-----------------
Main orchestrator. Wires together reader → parser → summarizer
→ hierarchy → registry into a single index_document() call.
"""

import os
import time
import uuid
from urllib.parse import urlparse

from .reader import read_file
from .parser import parse_sections
from .hierarchy import build_hierarchy, flatten_tree, build_tree_outline, print_tree
from .registry import load_registry, save_registry
from .summarizer import SummarizerFn, null_summarizer


def index_document(
    file_path: str,
    summarizer: SummarizerFn = null_summarizer,
    registry_path: str = "indexed_docs.json",
    overwrite: bool = False,
    persist: bool = True,
    verbose: bool = True,
) -> dict:
    """
    Index a document or URL and optionally save it to the local registry.

    Args:
        file_path:     Path to .txt, .md, .pdf, .docx OR a URL (http/https).
        summarizer:    SummarizerFn for generating section summaries.
                       Defaults to null_summarizer (no API calls).
                       Use make_summarizer(llm) for AI summaries.
        registry_path: Path to the registry JSON file.
        overwrite:     If True, re-index even if already indexed.
        persist:       If True (default), saves to indexed_docs.json.
                       If False, just returns the dict — user handles storage.
        verbose:       If True, print progress to stdout.

    Returns:
        The indexed document entry dict with keys:
            doc_id, file_name, file_path, indexed_at,
            tree, tree_outline, flat_nodes, total_sections

    Examples:
        from treerag import index_document, make_summarizer
        from langchain_openai import ChatOpenAI

        llm = ChatOpenAI(model="gpt-4o-mini")
        doc = index_document("my_doc.md", summarizer=make_summarizer(llm))

        # URL
        doc = index_document("https://docs.example.com")

        # Production — skip saving
        doc = index_document("my_doc.md", persist=False)
        db.save(doc)
    """
    is_url = file_path.startswith("http://") or file_path.startswith("https://")

    if not is_url and not os.path.isfile(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    # Derive file_name
    if is_url:
        parsed = urlparse(file_path)
        url_path = parsed.path.rstrip("/").replace("/", "_")
        file_name = f"{parsed.netloc}{url_path}" if url_path else parsed.netloc
    else:
        file_name = os.path.basename(file_path)

    # Check for existing index — search by file_name in registry values
    if persist and not overwrite:
        registry = load_registry(registry_path)
        for entry in registry.values():
            if entry.get("file_name") == file_name:
                raise ValueError(
                    f"'{file_name}' is already indexed. "
                    "Pass overwrite=True to re-index."
                )

    def log(msg: str):
        if verbose:
            print(msg)

    # Step 1: Read
    log(f"[treerag] Reading: {file_path}")
    text = read_file(file_path)
    log(f"  {len(text):,} chars, ~{len(text.split()):,} words")

    # Step 2: Parse
    log("[treerag] Parsing sections...")
    sections = parse_sections(text)
    log(f"  {len(sections)} sections found")

    # Step 3: Summarize
    log("[treerag] Generating summaries...")
    sections = summarizer(sections)

    # Step 4: Build tree
    log("[treerag] Building hierarchy...")
    tree = build_hierarchy(sections)

    # Step 5: Build derived structures
    tree_outline = build_tree_outline(tree)
    flat_nodes = flatten_tree(tree)

    entry = {
        "doc_id": str(uuid.uuid4()),
        "file_name": file_name,
        "file_path": file_path,
        "indexed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "tree": tree,
        "tree_outline": tree_outline,
        "flat_nodes": flat_nodes,
        "total_sections": len(sections),
    }

    # Step 6: Persist
    if persist:
        registry = load_registry(registry_path)
        # If overwrite — remove existing entry with same file_name first
        if overwrite:
            keys_to_delete = [
                k for k, v in registry.items()
                if v.get("file_name") == file_name
            ]
            for k in keys_to_delete:
                del registry[k]
        registry[entry["doc_id"]] = entry
        save_registry(registry, registry_path)
        log(f"\n[treerag] Saved to {registry_path}")
    else:
        log("\n[treerag] persist=False — skipping local save")

    log(f"\n[treerag] Tree ({len(flat_nodes)} nodes):")
    if verbose:
        print_tree(tree)

    return entry
