# Muget

YouTube Music downloader with automatic tagging and cover art.

## Installation

```bash
pip install muget
```

Usage

```bash
muget "https://music.youtube.com/playlist?list=..."
muget -o "./Music" "https://music.youtube.com/album/..."
```

Requirements

· FFmpeg (required)
· aria2c (optional, for faster downloads)

Features

· Download tracks, albums, and playlists
· Automatic metadata tagging
· Cover art embedding
· Synced lyrics support
