from __future__ import annotations

import datetime
import functools
import io
import json
import logging
import re
import shutil
import subprocess
import typing
from pathlib import Path

import requests
from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from mutagen.mp4 import MP4, MP4Cover
from PIL import Image
from yt_dlp import YoutubeDL
from ytmusicapi import YTMusic

from .constants import IMAGE_FILE_EXTENSION_MAP, MP4_TAGS_MAP
from .enums import CoverFormat, DownloadMode

logger = logging.getLogger("muget")


class Downloader:
    def __init__(
        self,
        output_path: Path = Path("./YouTube Music"),
        temp_path: Path = Path("./temp"),
        cookies_path: Path = None,
        browser_json_path: Path = None,
        ffmpeg_path: str = "ffmpeg",
        aria2c_path: str = "aria2c",
        itag: str = "140",
        download_mode: DownloadMode = DownloadMode.YTDLP,
        po_token: str = None,
        cover_size: int = 16383,
        cover_format: CoverFormat = CoverFormat.JPG,
        cover_quality: int = 94,
        template_folder: str = "{album_artist}/{album}",
        template_file: str = "{track:02d} {title}",
        template_date: str = "%Y-%m-%dT%H:%M:%SZ",
        exclude_tags: str = None,
        truncate: int = None,
        silent: bool = False,
    ):
        self.output_path = output_path
        self.temp_path = temp_path
        self.cookies_path = cookies_path
        self.browser_json_path = browser_json_path
        self.ffmpeg_path = ffmpeg_path
        self.aria2c_path = aria2c_path
        self.itag = itag
        self.download_mode = download_mode
        self.po_token = po_token
        self.cover_size = cover_size
        self.cover_format = cover_format
        self.cover_quality = cover_quality
        self.template_folder = template_folder
        self.template_file = template_file
        self.template_date = template_date
        self.exclude_tags = exclude_tags
        self.truncate = truncate
        self.silent = silent
        self._set_ytmusic_instance()
        self._set_ytdlp_options()
        self._set_exclude_tags()
        self._set_truncate()

    def _set_ytmusic_instance(self):
        """Configura la instancia de YTMusic usando browser.json si está disponible."""
        if self.browser_json_path and self.browser_json_path.exists():
            try:
                with open(self.browser_json_path, 'r', encoding='utf-8') as f:
                    json.load(f)  # Validar que es JSON válido
                self.ytmusic = YTMusic(str(self.browser_json_path))
                logger.debug(f"YTMusic autenticado con browser.json desde {self.browser_json_path}")
            except Exception as e:
                logger.warning(f"Error cargando browser.json: {e}. Usando modo anónimo.")
                self.ytmusic = YTMusic()
        else:
            if self.browser_json_path:
                logger.warning(f"browser.json no encontrado en {self.browser_json_path}. Usando modo anónimo.")
            self.ytmusic = YTMusic()

    def _set_ytdlp_options(self):
        """Configura opciones de yt-dlp SOLO para descarga de audio."""
        self.ytdlp_options = {
            "quiet": True,
            "no_warnings": True,
            "noprogress": self.silent,
            "extract_flat": False,
        }
        
        if self.cookies_path is not None or self.po_token is not None:
            self.ytdlp_options["extractor_args"] = {
                "youtube": {
                    "player_client": ["web_music"],
                }
            }
            if self.po_token is not None:
                self.ytdlp_options["extractor_args"]["youtube"]["po_token"] = [
                    f"web_music.gvs+{self.po_token}"
                ]
        
        if self.cookies_path is not None:
            self.ytdlp_options["cookiefile"] = str(self.cookies_path)

    def _set_exclude_tags(self):
        self.exclude_tags = (
            [i.lower() for i in self.exclude_tags.split(",")]
            if self.exclude_tags is not None
            else []
        )

    def _set_truncate(self):
        if self.truncate is not None:
            self.truncate = None if self.truncate < 4 else self.truncate

    def get_download_queue(
        self,
        url: str,
    ) -> typing.Generator[dict, None, None]:
        """Obtiene la cola de descarga usando SOLO ytmusicapi."""
        # Detectar tipo de URL
        if "browse" in url:
            browse_id = url.split("browse/")[-1].split("?")[0]
            yield from self._get_download_queue_from_browse_id(browse_id)
        elif "playlist" in url:
            playlist_id = self._extract_playlist_id(url)
            yield from self._get_download_queue_from_playlist_id(playlist_id)
        elif "watch" in url or "v=" in url:
            video_id = self._extract_video_id(url)
            yield from self._get_download_queue_from_video_id(video_id)
        elif "channel" in url:
            channel_id = self._extract_channel_id(url)
            yield from self._get_download_queue_artist(channel_id)
        else:
            yield from self._get_download_queue_from_browse_id(url)

    def _extract_video_id(self, url: str) -> str:
        if "v=" in url:
            return url.split("v=")[1].split("&")[0]
        return url.split("/")[-1].split("?")[0]

    def _extract_playlist_id(self, url: str) -> str:
        if "list=" in url:
            return url.split("list=")[1].split("&")[0]
        return url.split("/")[-1].split("?")[0]

    def _extract_channel_id(self, url: str) -> str:
        if "channel/" in url:
            return url.split("channel/")[1].split("?")[0]
        return url.split("/")[-1].split("?")[0]

    def _get_download_queue_from_browse_id(
        self,
        browse_id: str,
    ) -> typing.Generator[dict, None, None]:
        """Procesa browse_id como álbum o playlist."""
        # Intentar como álbum
        try:
            album = self.ytmusic.get_album(browse_id)
            if album and album.get("tracks"):
                for track in album["tracks"]:
                    if track.get("videoId"):
                        yield {
                            "id": track["videoId"],
                            "title": track.get("title"),
                            "artists": track.get("artists", []),
                            "album": album,
                        }
                return
        except Exception:
            pass
        
        # Intentar como playlist
        try:
            playlist = self.ytmusic.get_playlist(browse_id, limit=1000)
            if playlist and playlist.get("tracks"):
                for track in playlist["tracks"]:
                    if track.get("videoId"):
                        yield {
                            "id": track["videoId"],
                            "title": track.get("title"),
                            "artists": track.get("artists", []),
                            "playlist": playlist,
                        }
                return
        except Exception as e:
            logger.debug(f"Error procesando browse_id {browse_id}: {e}")

    def _get_download_queue_from_playlist_id(
        self,
        playlist_id: str,
    ) -> typing.Generator[dict, None, None]:
        """Obtiene tracks de una playlist (soporta privadas con browser.json)."""
        try:
            playlist = self.ytmusic.get_playlist(playlist_id, limit=1000)
            if playlist and playlist.get("tracks"):
                for track in playlist["tracks"]:
                    if track.get("videoId"):
                        yield {
                            "id": track["videoId"],
                            "title": track.get("title"),
                            "artists": track.get("artists", []),
                            "playlist": playlist,
                        }
            else:
                logger.warning(f"No se encontraron tracks en la playlist {playlist_id}")
        except Exception as e:
            logger.error(f"Error accediendo a la playlist {playlist_id}: {e}")
            if "private" in str(e).lower():
                logger.error("La playlist puede ser privada. Usa --browser-json-path con autenticación válida.")

    def _get_download_queue_from_video_id(
        self,
        video_id: str,
    ) -> typing.Generator[dict, None, None]:
        yield {
            "id": video_id,
            "title": None,
            "artists": [],
        }

    def _get_download_queue_artist(
        self,
        channel_id: str,
    ) -> typing.Generator[dict, None, None]:
        """Interactúa con el usuario para seleccionar álbumes/singles de un artista."""
        artist = self.ytmusic.get_artist(channel_id)
        media_type = inquirer.select(
            message=f'Select which type to download for artist "{artist["name"]}":',
            choices=[
                Choice(name="Albums", value="albums"),
                Choice(name="Singles", value="singles"),
            ],
            validate=lambda result: artist.get(result, {}).get("results"),
            invalid_message="The artist doesn't have any items of this type",
        ).execute()
        
        artist_items = (
            self.ytmusic.get_artist_albums(
                artist[media_type]["browseId"], artist[media_type]["params"]
            )
            if artist[media_type].get("browseId") and artist[media_type].get("params")
            else artist[media_type]["results"]
        )
        
        choices = [
            Choice(
                name=" | ".join(
                    [
                        item.get("year", "Unknown"),
                        item["title"],
                    ]
                ),
                value=item,
            )
            for item in artist_items
        ]
        
        selected = inquirer.select(
            message="Select which items to download: (Year | Title)",
            choices=choices,
            multiselect=True,
        ).execute()
        
        for item in selected:
            yield from self._get_download_queue_from_browse_id(item["browseId"])

    @staticmethod
    def _get_artist(artist_list: list) -> str:
        if not artist_list:
            return "Unknown Artist"
        if len(artist_list) == 1:
            return artist_list[0]["name"]
        return (
            ", ".join([i["name"] for i in artist_list][:-1])
            + f' & {artist_list[-1]["name"]}'
        )

    def get_ytmusic_watch_playlist(self, video_id: str) -> dict | None:
        """Obtiene watch playlist para un video."""
        try:
            ytmusic_watch_playlist = self.ytmusic.get_watch_playlist(video_id)
            if not ytmusic_watch_playlist or not ytmusic_watch_playlist.get("tracks"):
                return None
            if not ytmusic_watch_playlist["tracks"][0].get("album"):
                return None
            return ytmusic_watch_playlist
        except Exception as e:
            logger.debug(f"Error obteniendo watch playlist para {video_id}: {e}")
            return None

    @functools.lru_cache()
    def get_ytmusic_album(self, browse_id: str) -> dict:
        """Obtiene información de un álbum."""
        try:
            return self.ytmusic.get_album(browse_id)
        except Exception as e:
            logger.debug(f"Error obteniendo álbum {browse_id}: {e}")
            return {}

    @staticmethod
    def _get_datetime_obj(date: str) -> datetime.datetime | None:
        try:
            return datetime.datetime.strptime(date, "%Y")
        except ValueError:
            return None

    def get_tags(self, ytmusic_watch_playlist: dict) -> dict:
        """Extrae tags completas de un track usando ytmusicapi."""
        video_id = ytmusic_watch_playlist["tracks"][0]["videoId"]
        album_info = self.get_ytmusic_album(
            ytmusic_watch_playlist["tracks"][0]["album"]["id"]
        )
        
        track_number = 1
        is_explicit = False
        if album_info and album_info.get("tracks"):
            for idx, track in enumerate(album_info["tracks"], start=1):
                if track.get("videoId") == video_id:
                    track_number = idx
                    is_explicit = track.get("isExplicit", False)
                    break
        
        tags = {
            "album": album_info.get("title", "Unknown Album") if album_info else "Unknown Album",
            "album_artist": self._get_artist(album_info.get("artists", [])) if album_info else "Unknown Artist",
            "artist": self._get_artist(ytmusic_watch_playlist["tracks"][0].get("artists", [])),
            "url": f"https://music.youtube.com/watch?v={video_id}",
            "media_type": 1,
            "title": ytmusic_watch_playlist["tracks"][0].get("title", "Unknown Title"),
            "track_total": album_info.get("trackCount", 0) if album_info else 0,
            "track": track_number,
            "video_id": video_id,
            "rating": 1 if is_explicit else 0,
        }
        
        # Letras no sincronizadas
        if ytmusic_watch_playlist.get("lyrics"):
            try:
                lyrics_data = self.ytmusic.get_lyrics(ytmusic_watch_playlist["lyrics"])
                if lyrics_data and lyrics_data.get("lyrics"):
                    tags["lyrics"] = lyrics_data["lyrics"]
            except Exception as e:
                logger.debug(f"No se pudieron obtener letras: {e}")
        
        # Fecha
        if album_info and album_info.get("year"):
            dt_obj = self._get_datetime_obj(album_info["year"])
            if dt_obj:
                tags["date"] = dt_obj.strftime(self.template_date)
        
        return tags

    def get_synced_lyrics(self, ytmusic_watch_playlist: dict) -> str | None:
        """Obtiene letras sincronizadas usando una instancia anónima."""
        if not ytmusic_watch_playlist.get("lyrics"):
            return None
    
        try:
            # Crear una instancia anónima SOLO para letras
            yt_anonymous = YTMusic()  # Sin autenticación
        
            lyrics_data = yt_anonymous.get_lyrics(
                ytmusic_watch_playlist["lyrics"],
                True  # Con timestamps
            )
        
            if (lyrics_data is not None 
                and lyrics_data.get("lyrics") 
                and lyrics_data.get("hasTimestamps")):
            
                lines = []
                for line in lyrics_data["lyrics"]:
                    timestamp = datetime.datetime.fromtimestamp(
                        line.start_time / 1000.0, 
                        tz=datetime.timezone.utc
                    )
                    lrc_timestamp = timestamp.strftime("%M:%S.%f")[:-4]
                    lines.append(f"[{lrc_timestamp}]{line.text}")
            
                return "\n".join(lines) + "\n"
            
        except Exception as e:
            logger.debug(f"No se pudieron obtener letras sincronizadas: {e}")
    
        return None

    def get_synced_lyrics_path(self, final_path: Path) -> Path:
        return final_path.with_suffix(".lrc")

    def save_synced_lyrics(self, synced_lyrics_path: Path, synced_lyrics: str):
        if synced_lyrics:
            synced_lyrics_path.parent.mkdir(parents=True, exist_ok=True)
            synced_lyrics_path.write_text(synced_lyrics, encoding="utf8")

    def get_sanitized_string(self, dirty_string: str, is_folder: bool) -> str:
        dirty_string = re.sub(r'[\\/:*?"<>|;]', "_", dirty_string)
        if is_folder:
            if self.truncate:
                dirty_string = dirty_string[:self.truncate]
            if dirty_string.endswith("."):
                dirty_string = dirty_string[:-1] + "_"
        else:
            if self.truncate:
                dirty_string = dirty_string[:self.truncate - 4]
        return dirty_string.strip()

    def get_track_temp_path(self, video_id: str) -> Path:
        return self.temp_path / f"{video_id}_temp.m4a"

    def get_remuxed_path(self, video_id: str) -> Path:
        return self.temp_path / f"{video_id}_remuxed.m4a"

    def get_cover_path(self, final_path: Path, file_extension: str) -> Path:
        return final_path.parent / ("Cover" + file_extension)

    def get_final_path(self, tags: dict) -> Path:
        tags_for_filename = tags.copy()
        
        # Asegurar tipos numéricos
        for key in ['track', 'track_total', 'disc', 'disc_total']:
            if key in tags_for_filename:
                value = tags_for_filename[key]
                try:
                    if isinstance(value, str) and '/' in value:
                        value = value.split('/')[0]
                    tags_for_filename[key] = int(value) if value is not None else 0
                except (ValueError, TypeError):
                    tags_for_filename[key] = 0
        
        tags_for_filename.setdefault('track', 0)
        tags_for_filename.setdefault('title', 'Unknown Title')
        tags_for_filename.setdefault('artist', 'Unknown Artist')
        
        folder_parts = self.template_folder.split("/")
        file_parts = self.template_file.split("/")
        
        processed_folders = []
        for part in folder_parts:
            try:
                formatted = part.format(**tags_for_filename)
            except (KeyError, ValueError):
                formatted = part
            processed_folders.append(self.get_sanitized_string(formatted, True))
        
        processed_file_parts = []
        for part in file_parts[:-1]:
            try:
                formatted = part.format(**tags_for_filename)
            except (KeyError, ValueError):
                formatted = part
            processed_file_parts.append(self.get_sanitized_string(formatted, True))
        
        try:
            last_part = file_parts[-1].format(**tags_for_filename)
        except (KeyError, ValueError):
            last_part = file_parts[-1]
        
        final_filename = self.get_sanitized_string(last_part, False) + ".m4a"
        processed_file_parts.append(final_filename)
        
        return self.output_path.joinpath(*processed_folders).joinpath(*processed_file_parts)

    def download(self, video_id: str, temp_path: Path):
        """Descarga SOLO el audio usando yt-dlp."""
        with YoutubeDL(
            {
                **self.ytdlp_options,
                "external_downloader": (
                    {"default": self.aria2c_path} if self.download_mode == DownloadMode.ARIA2C else None
                ),
                "fixup": "never",
                "format": self.itag,
                "outtmpl": str(temp_path),
            }
        ) as ydl:
            ydl.download(f"https://music.youtube.com/watch?v={video_id}")

    def remux(self, temp_path: Path, remuxed_path: Path):
        command = [self.ffmpeg_path, "-loglevel", "error", "-i", temp_path]
        if self.itag not in ("141", "140", "139"):
            command.extend(["-f", "mp4"])
        subprocess.run(
            [
                *command,
                "-movflags",
                "+faststart",
                "-c",
                "copy",
                remuxed_path,
            ],
            check=True,
        )

    @staticmethod
    @functools.lru_cache()
    def get_url_response_bytes(url: str) -> bytes:
        return requests.get(url).content

    def get_cover_url(self, ytmusic_watch_playlist: dict) -> str:
        thumb_url = ytmusic_watch_playlist["tracks"][0]["thumbnail"][0]["url"].split("=")[0]
        if self.cover_format == CoverFormat.RAW:
            return thumb_url + "=d"
        return thumb_url + f'=w{self.cover_size}-l{self.cover_quality}-{"rj" if self.cover_format == CoverFormat.JPG else "rp"}'

    def get_cover_file_extension(self, cover_url: str) -> str:
        img = Image.open(io.BytesIO(self.get_url_response_bytes(cover_url)))
        fmt = img.format.lower()
        return IMAGE_FILE_EXTENSION_MAP.get(fmt, f".{fmt}")

    def apply_tags(self, path: Path, tags: dict, cover_url: str):
        to_apply = [k for k in tags.keys() if k not in self.exclude_tags]
        mp4_tags = {}
        
        for tag in to_apply:
            if tag in ("disc", "disc_total"):
                if "disk" not in mp4_tags:
                    mp4_tags["disk"] = [[0, 0]]
                if tag == "disc":
                    mp4_tags["disk"][0][0] = tags[tag]
                elif tag == "disc_total":
                    mp4_tags["disk"][0][1] = tags[tag]
            elif tag in ("track", "track_total"):
                if "trkn" not in mp4_tags:
                    mp4_tags["trkn"] = [[0, 0]]
                if tag == "track":
                    mp4_tags["trkn"][0][0] = tags[tag]
                elif tag == "track_total":
                    mp4_tags["trkn"][0][1] = tags[tag]
            elif MP4_TAGS_MAP.get(tag) and tags.get(tag) is not None:
                mp4_tags[MP4_TAGS_MAP[tag]] = [tags[tag]]
        
        if "cover" not in self.exclude_tags and self.cover_format != CoverFormat.RAW:
            mp4_tags["covr"] = [
                MP4Cover(
                    self.get_url_response_bytes(cover_url),
                    MP4Cover.FORMAT_JPEG if self.cover_format == CoverFormat.JPG else MP4Cover.FORMAT_PNG,
                )
            ]
        
        mp4 = MP4(path)
        mp4.clear()
        mp4.update(mp4_tags)
        mp4.save()

    def move_to_output_path(self, remuxed_path: Path, final_path: Path):
        final_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(remuxed_path, final_path)

    @functools.lru_cache()
    def save_cover(self, cover_path: Path, cover_url: str):
        cover_path.write_bytes(self.get_url_response_bytes(cover_url))

    def cleanup_temp_path(self):
        if self.temp_path.exists():
            shutil.rmtree(self.temp_path)
