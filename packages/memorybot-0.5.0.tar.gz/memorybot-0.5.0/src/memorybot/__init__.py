"""MemoryBot CLI."""

__version__ = "0.5.0"
