from wbcore.menus import ItemPermission, Menu, MenuItem

WRITER_MENU = Menu(
    label="Writer",
    items=[
        MenuItem(
            label="Article",
            endpoint="wbwriter:article-list",
            add=MenuItem(
                label="Create an article",
                endpoint="wbwriter:article-list",
            ),
            permission=ItemPermission(
                method=lambda request: request.user.is_internal, permissions=["wbwriter.view_article"]
            ),
        ),
        MenuItem(
            label="Articles to review",
            endpoint="wbwriter:review-article-list",
            permission=ItemPermission(
                method=lambda request: request.user.is_internal, permissions=["wbwriter.view_article"]
            ),
        ),
        MenuItem(
            label="Publication",
            endpoint="wbwriter:publication-list",
            permission=ItemPermission(
                method=lambda request: request.user.is_internal, permissions=["wbwriter.view_publication"]
            ),
        ),
    ],
)
