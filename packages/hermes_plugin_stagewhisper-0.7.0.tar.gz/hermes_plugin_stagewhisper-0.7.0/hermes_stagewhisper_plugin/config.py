"""Config helpers for the StageWhisper Hermes plugin."""

from __future__ import annotations

import os
import shlex
from pathlib import Path

_ENV_VARS = [
    "STAGEWHISPER_API_URL",
    "STAGEWHISPER_INTEGRATION_ID",
    "STAGEWHISPER_RELAY_TOKEN",
    "STAGEWHISPER_PLUGIN_SECRET_KEY",
    "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
    "STAGEWHISPER_REASONING_MODEL",
    "OPENAI_API_KEY",
    "OPENAI_BASE_URL",
]

_LOADED_ENV = False


def load_env_file(path: str | Path | None = None) -> None:
    global _LOADED_ENV
    if _LOADED_ENV and path is None:
        return
    if path is None:
        _LOADED_ENV = True

    env_path = Path(path).expanduser() if path else Path.home() / ".hermes" / ".env"
    if not env_path.exists():
        return

    try:
        lines = env_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return

    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        try:
            parts = shlex.split(line, comments=True, posix=True)
        except ValueError:
            parts = [line]
        if not parts or "=" not in parts[0]:
            continue
        key, _, value = parts[0].partition("=")
        key = key.strip()
        if key in _ENV_VARS and value and not os.getenv(key):
            os.environ[key] = value


def is_paired() -> bool:
    return all(
        os.getenv(v)
        for v in [
            "STAGEWHISPER_API_URL",
            "STAGEWHISPER_INTEGRATION_ID",
            "STAGEWHISPER_RELAY_TOKEN",
        ]
    )


def is_byo_ready() -> bool:
    return is_paired() and all(
        os.getenv(v)
        for v in [
            "STAGEWHISPER_PLUGIN_SECRET_KEY",
            "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
        ]
    )


def get_api_url() -> str:
    return os.getenv("STAGEWHISPER_API_URL", "http://127.0.0.1:8000")


def get_integration_id() -> str | None:
    return os.getenv("STAGEWHISPER_INTEGRATION_ID")


def get_relay_token() -> str | None:
    return os.getenv("STAGEWHISPER_RELAY_TOKEN")


load_env_file()
