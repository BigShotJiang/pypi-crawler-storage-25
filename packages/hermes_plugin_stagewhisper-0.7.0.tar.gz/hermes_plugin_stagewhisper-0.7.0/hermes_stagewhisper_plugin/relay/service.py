"""Relay service — subscribes to StageWhisper SSE stream, processes reasoning jobs and tasks.

Equivalent to the OpenClaw plugin's src/service.ts.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Any

import httpx

from .client import StageWhisperClient
from .crypto import (
    IdentityKeypair,
    ReplayGuard,
    open_envelope,
    open_json_checked,
    seal,
    seal_json,
)
from .health import HealthTracker
from .reasoning import execute_reasoning_job, probe_llm

logger = logging.getLogger(__name__)

HEARTBEAT_INTERVAL_S = 30
RECONNECT_BASE_S = 1
RECONNECT_MAX_S = 60


def _load_keypair() -> IdentityKeypair | None:
    secret_b64 = os.getenv("STAGEWHISPER_PLUGIN_SECRET_KEY")
    if not secret_b64:
        return None
    try:
        import base64
        return IdentityKeypair.from_secret_bytes(base64.b64decode(secret_b64))
    except Exception as exc:
        logger.warning("Failed to load plugin keypair: %s", exc)
        return None


def _load_desktop_public_key() -> bytes | None:
    pub_b64 = os.getenv("STAGEWHISPER_DESKTOP_PUBLIC_KEY")
    if not pub_b64:
        return None
    try:
        return IdentityKeypair.public_key_from_base64(pub_b64)
    except Exception as exc:
        logger.warning("Failed to load desktop public key: %s", exc)
        return None


class RelayService:
    def __init__(self) -> None:
        self._running = False
        self._connected = False
        self._reconnect_attempts = 0
        self._abort: asyncio.Event | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._loop_task: asyncio.Task | None = None
        self.health = HealthTracker()
        self._completed_jobs: dict[str, float] = {}
        self._processing_jobs: set[str] = set()
        self._replay_guard = ReplayGuard()

    @property
    def running(self) -> bool:
        return self._running

    def _create_client(self) -> StageWhisperClient:
        api_url = os.getenv("STAGEWHISPER_API_URL", "http://127.0.0.1:8000")
        integration_id = os.getenv("STAGEWHISPER_INTEGRATION_ID", "")
        relay_token = os.getenv("STAGEWHISPER_RELAY_TOKEN", "")

        client = StageWhisperClient(api_url, integration_id, relay_token)

        kp = _load_keypair()
        if kp:
            client.set_plugin_keypair(kp)
        desktop_pub = _load_desktop_public_key()
        if desktop_pub:
            client.set_desktop_public_key(desktop_pub)

        return client

    def _is_configured(self) -> bool:
        return bool(
            os.getenv("STAGEWHISPER_API_URL")
            and os.getenv("STAGEWHISPER_INTEGRATION_ID")
            and os.getenv("STAGEWHISPER_RELAY_TOKEN")
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        if not self._is_configured():
            logger.info(
                "StageWhisper not configured — skipping relay. "
                "Pair first with: stagewhisper-hermes pair --code <CODE>"
            )
            return

        self._running = True
        self._abort = asyncio.Event()

        logger.info("Probing LLM connectivity...")
        probe = await probe_llm()
        if probe["ok"]:
            self.health.record_success()
            if probe["model"]:
                self.health.set_model(probe["model"])
            logger.info("LLM verified — model: %s", probe.get("model", "unknown"))
        else:
            self.health.record_failure(probe.get("error", "probe_failed"))
            logger.warning("LLM probe failed: %s", probe.get("error"))

        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        self._loop_task = asyncio.create_task(self._run_loop())
        logger.info("StageWhisper relay service started")

    async def stop(self) -> None:
        self._running = False
        if self._abort:
            self._abort.set()
        for task in [self._heartbeat_task, self._loop_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._heartbeat_task = None
        self._loop_task = None
        logger.info("StageWhisper relay service stopped")

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    async def _heartbeat_loop(self) -> None:
        client = self._create_client()
        while self._running:
            try:
                await client.heartbeat(self.health.to_heartbeat_payload())
            except Exception as exc:
                logger.warning("Heartbeat failed: %s", exc)
            await asyncio.sleep(HEARTBEAT_INTERVAL_S)

    # ------------------------------------------------------------------
    # SSE stream
    # ------------------------------------------------------------------

    async def _run_loop(self) -> None:
        while self._running:
            try:
                await self._connect_stream()
            except Exception as exc:
                if not self._running:
                    break
                self.health.set_disconnected()
                self._reconnect_attempts += 1
                delay = min(
                    RECONNECT_BASE_S * (2 ** self._reconnect_attempts),
                    RECONNECT_MAX_S,
                )
                delay += (delay * 0.3) * (os.urandom(2)[0] / 255.0)
                logger.warning(
                    "Stream disconnected (attempt %d), reconnecting in %.1fs: %s",
                    self._reconnect_attempts,
                    delay,
                    exc,
                )
                await asyncio.sleep(delay)

    async def _connect_stream(self) -> None:
        client = self._create_client()
        url = client.stream_url()

        logger.info("Connecting to relay stream: %s", url)

        async with httpx.AsyncClient(timeout=httpx.Timeout(None, connect=30)) as http:
            async with http.stream(
                "GET", url, headers=client.stream_headers()
            ) as resp:
                if not resp.is_success:
                    raise RuntimeError(
                        f"Stream connection failed ({resp.status_code})"
                    )

                self._connected = True
                self._reconnect_attempts = 0
                self.health.set_connected()
                logger.info("Connected to StageWhisper relay stream")

                if self.health.get()["status"] != "healthy":
                    logger.info("Re-probing LLM after reconnect...")
                    probe = await probe_llm()
                    if probe["ok"]:
                        self.health.record_success()
                        if probe["model"]:
                            self.health.set_model(probe["model"])
                        logger.info(
                            "LLM verified on reconnect — model: %s",
                            probe.get("model", "unknown"),
                        )
                    else:
                        logger.warning("Reconnect probe failed: %s", probe.get("error"))

                buffer = ""
                async for chunk in resp.aiter_bytes():
                    if not self._running:
                        break
                    buffer += chunk.decode(errors="replace")
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        if line.startswith("data: "):
                            json_str = line[6:].strip()
                            if json_str:
                                try:
                                    envelope = json.loads(json_str)
                                except json.JSONDecodeError:
                                    continue
                                asyncio.create_task(
                                    self._handle_event(envelope, client)
                                )

        self._connected = False
        self.health.set_disconnected()

    # ------------------------------------------------------------------
    # Event dispatch
    # ------------------------------------------------------------------

    async def _handle_event(
        self, envelope: dict[str, Any], client: StageWhisperClient
    ) -> None:
        event_type = envelope.get("event_type")
        if event_type == "reasoning_job":
            await self._handle_reasoning_job(envelope, client)
        else:
            await self._handle_task(envelope, client)

    # ------------------------------------------------------------------
    # Reasoning jobs
    # ------------------------------------------------------------------

    async def _handle_reasoning_job(
        self, job: dict[str, Any], client: StageWhisperClient
    ) -> None:
        job = await self._hydrate_reasoning_job(job, client)
        if not job:
            return

        job_id = job["job_id"]
        correlation_id = job.get("correlation_id")
        logger.info(
            "Reasoning job: %s (purpose: %s, correlation: %s)",
            job_id,
            job.get("purpose"),
            correlation_id or "none",
        )

        if job_id in self._completed_jobs:
            logger.info("Skipping completed reasoning job: %s", job_id)
            return
        if job_id in self._processing_jobs:
            logger.info("Skipping in-flight reasoning job: %s", job_id)
            return
        self._processing_jobs.add(job_id)

        try:
            if job.get("purpose") == "capability_probe":
                await self._handle_capability_probe(job, client)
                self._completed_jobs[job_id] = time.time()
                return

            is_byo = _is_byo_encrypted(job)
            if is_byo:
                await self._handle_byo_encrypted_job(job, client)
                return

            display_model = self.health.get().get("displayModel")
            result = await execute_reasoning_job(job, display_model)

            if result["status"] == "completed":
                self.health.record_success()
            else:
                self.health.record_failure(
                    result.get("error_message", f"reasoning {result['status']}")
                )

            if result.get("model_ref") and result["model_ref"] != display_model:
                self.health.set_model(result["model_ref"])

            await client.post_reasoning_result(job_id, result, correlation_id)
            self._completed_jobs[job_id] = time.time()
            self._evict_completed()
            logger.info(
                "Reasoning job %s completed (status: %s)", job_id, result["status"]
            )
        except Exception as exc:
            logger.error("Reasoning job %s failed: %s", job_id, exc)
            try:
                await client.post_reasoning_result(
                    job_id,
                    {
                        "job_id": job_id,
                        "status": "failed",
                        "provider_run_id": None,
                        "model_ref": self.health.get().get("displayModel"),
                        "usage": None,
                        "output": None,
                        "error_code": "execution_error",
                        "error_message": str(exc),
                    },
                    job.get("correlation_id"),
                )
            except Exception:
                pass
        finally:
            self._processing_jobs.discard(job_id)

    async def _handle_capability_probe(
        self, job: dict[str, Any], client: StageWhisperClient
    ) -> None:
        job_id = job["job_id"]
        correlation_id = job.get("correlation_id")
        display_model = self.health.get().get("displayModel")

        prompt = "Briefly describe your capabilities, personality, tools, expertise, goals, and constraints. Plain text, no JSON."
        payload = job.get("payload", {})
        if isinstance(payload, dict) and payload.get("prompt"):
            prompt = payload["prompt"]

        messages = [{"role": "user", "content": prompt}]
        model = job.get("model") or display_model or os.getenv("STAGEWHISPER_REASONING_MODEL", "gpt-4o")

        try:
            headers = {"Content-Type": "application/json"}
            openai_key = os.getenv("OPENAI_API_KEY", "")
            if openai_key:
                headers["Authorization"] = f"Bearer {openai_key}"

            async with httpx.AsyncClient(timeout=60) as http:
                resp = await http.post(
                    f"{os.getenv('OPENAI_BASE_URL', 'https://api.openai.com/v1')}/chat/completions",
                    headers=headers,
                    json={
                        "model": model,
                        "messages": messages,
                        "max_tokens": 512,
                    },
                )
                if resp.is_success:
                    data = resp.json()
                    reply = data["choices"][0]["message"]["content"]
                else:
                    reply = f"Probe failed: HTTP {resp.status_code}"

            await client.post_reasoning_result(
                job_id,
                {
                    "job_id": job_id,
                    "status": "completed",
                    "provider_run_id": data.get("id") if resp.is_success else None,
                    "model_ref": display_model,
                    "usage": None,
                    "output": {"raw_description": reply[:2000]},
                    "error_code": None,
                    "error_message": None,
                },
                correlation_id,
            )
            logger.info("Capability probe %s completed", job_id)
        except Exception as exc:
            logger.error("Capability probe %s failed: %s", job_id, exc)
            try:
                await client.post_reasoning_result(
                    job_id,
                    {
                        "job_id": job_id,
                        "status": "failed",
                        "provider_run_id": None,
                        "model_ref": display_model,
                        "usage": None,
                        "output": None,
                        "error_code": "execution_error",
                        "error_message": str(exc),
                    },
                    correlation_id,
                )
            except Exception:
                pass

    async def _handle_byo_encrypted_job(
        self, job: dict[str, Any], client: StageWhisperClient
    ) -> None:
        job_id = job["job_id"]
        correlation_id = job.get("correlation_id")
        logger.info("Received BYO encrypted reasoning job: %s", job_id)

        payload = job.get("payload", {})
        envelope = payload.get("envelope") if isinstance(payload, dict) else None
        if not envelope or not envelope.get("ciphertext"):
            logger.error("BYO job %s missing encrypted envelope", job_id)
            await client.post_reasoning_result(
                job_id,
                {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": None,
                    "model_ref": None,
                    "usage": None,
                    "output": None,
                    "error_code": "missing_envelope",
                    "error_message": "No encrypted envelope in BYO reasoning job",
                    "byo_encrypted": True,
                },
                correlation_id,
            )
            return

        kp = client.plugin_keypair
        desktop_pub = client.desktop_public_key
        if not kp or not desktop_pub:
            logger.error("BYO job %s: missing crypto keys", job_id)
            await client.post_reasoning_result(
                job_id,
                {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": None,
                    "model_ref": None,
                    "usage": None,
                    "output": None,
                    "error_code": "missing_keys",
                    "error_message": "Plugin or desktop keys not configured for BYO mode",
                    "byo_encrypted": True,
                },
                correlation_id,
            )
            return

        envelope_key = kp.derive_envelope_key(desktop_pub)
        try:
            decrypted = open_json_checked(envelope_key, envelope, self._replay_guard)
        except Exception as exc:
            logger.error("BYO job %s decryption failed: %s", job_id, exc)
            await client.post_reasoning_result(
                job_id,
                {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": None,
                    "model_ref": None,
                    "usage": None,
                    "output": None,
                    "error_code": "decryption_error",
                    "error_message": str(exc),
                    "byo_encrypted": True,
                },
                correlation_id,
            )
            return

        plain_job = {**job, "payload": decrypted}
        plain_job["response_schema"] = decrypted.get(
            "response_schema", job.get("response_schema", {})
        )

        display_model = self.health.get().get("displayModel")
        try:
            result = await execute_reasoning_job(plain_job, display_model)
        except Exception as exc:
            logger.error("BYO reasoning job %s failed: %s", job_id, exc)
            self.health.record_failure(str(exc))
            await client.post_reasoning_result(
                job_id,
                {
                    "job_id": job_id,
                    "status": "failed",
                    "provider_run_id": None,
                    "model_ref": display_model,
                    "usage": None,
                    "output": None,
                    "error_code": "execution_error",
                    "error_message": str(exc),
                    "byo_encrypted": True,
                },
                correlation_id,
            )
            return

        if result["status"] == "completed":
            self.health.record_success()
        else:
            self.health.record_failure(
                result.get("error_message", f"reasoning {result['status']}")
            )

        try:
            result_json = json.dumps(result.get("output", {}), separators=(",", ":"))
            result_envelope = seal(
                envelope_key,
                "plugin",
                envelope.get("session_id", ""),
                envelope.get("correlation_id", ""),
                "reasoning_output",
                result_json.encode(),
            )

            completion = {
                "status": result["status"],
                "provider_run_id": result["provider_run_id"],
                "model_ref": result["model_ref"],
                "usage": result.get("usage"),
                "output": {
                    "byo_encrypted": True,
                    "envelope": result_envelope,
                    "status": result["status"],
                },
                "error_code": result.get("error_code"),
                "error_message": result.get("error_message"),
            }
        except Exception as exc:
            logger.error("BYO job %s result encryption failed: %s", job_id, exc)
            completion = {
                "status": "failed",
                "provider_run_id": result.get("provider_run_id"),
                "model_ref": result.get("model_ref"),
                "usage": result.get("usage"),
                "output": {
                    "byo_encrypted": True,
                    "status": "failed",
                    "error_code": "encryption_error",
                    "error_message": str(exc),
                },
                "error_code": "encryption_error",
                "error_message": str(exc),
            }

        await client.post_reasoning_result(job_id, completion, correlation_id)
        self._completed_jobs[job_id] = time.time()
        logger.info(
            "BYO reasoning job %s completed (status: %s)", job_id, result["status"]
        )

    # ------------------------------------------------------------------
    # Task handling
    # ------------------------------------------------------------------

    async def _handle_task(
        self, task: dict[str, Any], client: StageWhisperClient
    ) -> None:
        task_id = task.get("id", "unknown")
        logger.info("Received task: %s (%s)", task.get("title", ""), task_id)

        is_test = task.get("action_type") == "connectivity_test"

        if not is_test:
            try:
                await client.update_task_status(task_id, "delivered")
            except Exception as exc:
                logger.warning(
                    "Failed to mark task %s as delivered: %s", task_id, exc
                )
                return

        reply_text = self._build_task_reply(task)
        if not is_test:
            try:
                await client.post_reply(task_id, reply_text)
            except Exception as exc:
                logger.error("Failed to post reply for task %s: %s", task_id, exc)
                await client.update_task_status(task_id, "failed")
                return

            await client.update_task_status(task_id, "completed")
        else:
            try:
                await client.test_reply(task_id, reply_text)
            except Exception as exc:
                logger.error(
                    "Failed to reply to test task %s: %s", task_id, exc
                )

        logger.info("Task %s completed", task_id)

    def _build_task_reply(self, task: dict[str, Any]) -> str:
        lines = [f"**{task.get('title', 'Untitled')}**", "", task.get("request_text", "")]
        evidence = task.get("evidence_payload")
        if evidence:
            if evidence.get("transcript_excerpt"):
                lines.extend(["", f"Context: {evidence['transcript_excerpt']}"])
            if evidence.get("signal_summary"):
                lines.append(f"Signal: {evidence['signal_summary']}")
        lines.extend(
            [
                "",
                f"Action type: {task.get('action_type', 'general')}",
                f"StageWhisper task: {task.get('id', '')}",
                f"Session: {task.get('session_id', '')}",
            ]
        )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _hydrate_reasoning_job(
        self, raw: dict[str, Any], client: StageWhisperClient
    ) -> dict[str, Any] | None:
        payload = raw.get("payload", {})
        if isinstance(payload, dict) and payload.get("_truncated"):
            job_id = raw.get("job_id") or payload.get("job_id") or payload.get("id")
            if not job_id:
                return None
            try:
                return await client.get_reasoning_job(job_id)
            except Exception:
                return None
        return raw

    def _evict_completed(self) -> None:
        cutoff = time.time() - 300
        stale = [k for k, v in self._completed_jobs.items() if v < cutoff]
        for k in stale:
            del self._completed_jobs[k]
        while len(self._completed_jobs) > 5000:
            oldest = next(iter(self._completed_jobs))
            del self._completed_jobs[oldest]


def _is_byo_encrypted(job: dict[str, Any]) -> bool:
    payload = job.get("payload", {})
    return isinstance(payload, dict) and payload.get("byo_encrypted") is True


# Singleton
relay_service = RelayService()
