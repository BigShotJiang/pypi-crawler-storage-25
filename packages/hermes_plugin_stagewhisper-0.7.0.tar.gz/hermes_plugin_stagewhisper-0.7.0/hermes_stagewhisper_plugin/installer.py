from __future__ import annotations

import argparse
import os
import shlex
import shutil
import subprocess
import sys
from importlib import metadata
from pathlib import Path


PACKAGE_NAME = "hermes-plugin-stagewhisper"
MODULE_NAME = "hermes_stagewhisper_plugin"
PLUGIN_NAME = "stagewhisper"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="stagewhisper-hermes-install",
        description="Install the StageWhisper plugin into the active Hermes environment.",
    )
    parser.add_argument("--hermes", help="Path to the hermes executable")
    parser.add_argument(
        "--plugins-dir",
        help="Hermes plugin directory. Defaults to ~/.hermes/plugins.",
    )
    parser.add_argument(
        "--no-install",
        action="store_true",
        help="Only enable an existing ~/.hermes/plugins/stagewhisper directory.",
    )
    parser.add_argument(
        "--no-enable",
        action="store_true",
        help="Skip 'hermes plugins enable stagewhisper'.",
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    try:
        installer = Installer(args)
        installer.run()
    except InstallError as exc:
        print(f"stagewhisper-hermes-install: {exc}", file=sys.stderr)
        return 1
    return 0


class InstallError(RuntimeError):
    pass


class Installer:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.hermes_path = _find_hermes(args.hermes)
        self.plugins_dir = (
            Path(args.plugins_dir).expanduser()
            if args.plugins_dir
            else Path.home() / ".hermes" / "plugins"
        )

    def run(self) -> None:
        self._print(f"Hermes: {self.hermes_path}")
        self._print(f"Plugin directory: {self.plugins_dir}")

        if not self.args.no_install:
            plugin_path = self._source_plugin_path()
            self._install_plugin_directory(plugin_path)
            self._install_cli_wrapper()
        elif not (self.plugins_dir / PLUGIN_NAME).exists():
            raise InstallError(
                f"{self.plugins_dir / PLUGIN_NAME} does not exist. Rerun without --no-install."
            )

        if not self.args.no_enable:
            self._enable_plugin()

        self._print("")
        self._print("StageWhisper Hermes plugin is installed.")
        self._print("Next: stagewhisper-hermes pair --code <CODE> --api-url <URL>")
        self._print("Then restart Hermes gateway if it is already running.")

    def _source_plugin_path(self) -> Path:
        module = __import__(MODULE_NAME)
        return Path(module.__file__).parent

    def _install_plugin_directory(self, plugin_path: Path) -> None:
        install_path = self.plugins_dir / PLUGIN_NAME
        self._print(f"Installing plugin files: {install_path}")
        if self.args.dry_run:
            return
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        if install_path.is_symlink() or install_path.is_file():
            install_path.unlink()
        elif install_path.exists():
            shutil.rmtree(install_path)
        shutil.copytree(
            plugin_path,
            install_path,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )

    def _install_cli_wrapper(self) -> None:
        bin_dir = Path.home() / ".local" / "bin"
        wrapper_path = bin_dir / "stagewhisper-hermes"
        runner = _find_runner()
        version = _package_version()
        spec = f"{PACKAGE_NAME}=={version}" if version else PACKAGE_NAME
        self._print(f"Installing CLI wrapper: {wrapper_path}")
        if self.args.dry_run:
            return
        bin_dir.mkdir(parents=True, exist_ok=True)
        wrapper_path.write_text(
            "#!/bin/sh\n" + _wrapper_command(runner, spec),
            encoding="utf-8",
        )
        wrapper_path.chmod(0o755)

    def _enable_plugin(self) -> None:
        self._run([str(self.hermes_path), "plugins", "enable", PLUGIN_NAME])

    def _run(
        self,
        cmd: list[str],
        *,
        capture_output: bool = False,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        self._print("$ " + " ".join(cmd))
        if self.args.dry_run:
            return subprocess.CompletedProcess(cmd, 0, "", "")
        return _run(cmd, capture_output=capture_output, check=check)

    def _print(self, message: str) -> None:
        print(message)


def _find_hermes(path: str | None) -> Path:
    resolved = path or shutil.which("hermes")
    if not resolved:
        raise InstallError("could not find 'hermes' on PATH. Pass --hermes /path/to/hermes.")
    hermes_path = Path(resolved).expanduser()
    if not hermes_path.exists():
        raise InstallError(f"hermes executable does not exist: {hermes_path}")
    return hermes_path.resolve()


def _find_runner() -> str:
    pipx = shutil.which("pipx")
    if pipx:
        return pipx
    uvx = shutil.which("uvx")
    if uvx:
        return uvx
    raise InstallError("could not find pipx or uvx to create the stagewhisper-hermes wrapper.")


def _wrapper_command(runner: str, spec: str) -> str:
    runner_name = Path(runner).name
    runner_arg = shlex.quote(runner)
    spec_arg = shlex.quote(spec)
    if runner_name == "uvx":
        return f"exec {runner_arg} --from {spec_arg} stagewhisper-hermes \"$@\"\n"
    return f"exec {runner_arg} run --spec {spec_arg} stagewhisper-hermes \"$@\"\n"


def _package_version() -> str | None:
    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        return None


def _run(
    cmd: list[str],
    *,
    capture_output: bool = False,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            cmd,
            check=check,
            text=True,
            capture_output=capture_output,
            env=os.environ.copy(),
        )
    except FileNotFoundError as exc:
        raise InstallError(f"command not found: {cmd[0]}") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        if detail:
            raise InstallError(detail) from exc
        raise InstallError(f"command failed: {' '.join(cmd)}") from exc


if __name__ == "__main__":
    raise SystemExit(main())
