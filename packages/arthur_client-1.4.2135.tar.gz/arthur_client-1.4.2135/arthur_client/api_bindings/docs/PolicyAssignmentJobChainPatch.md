# PolicyAssignmentJobChainPatch

Sparse update from ml-engine to stamp downstream chain jobs.  metrics_calc_job_id is set by the operator at chain submission, so it is not accepted here — only the AlertCheck and CompliancePolicyCheck job IDs are stampable from the executor side.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alerts_check_job_id** | **str** |  | [optional] 
**compliance_job_id** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.policy_assignment_job_chain_patch import PolicyAssignmentJobChainPatch

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAssignmentJobChainPatch from a JSON string
policy_assignment_job_chain_patch_instance = PolicyAssignmentJobChainPatch.from_json(json)
# print the JSON string representation of the object
print(PolicyAssignmentJobChainPatch.to_json())

# convert the object into a dict
policy_assignment_job_chain_patch_dict = policy_assignment_job_chain_patch_instance.to_dict()
# create an instance of PolicyAssignmentJobChainPatch from a dict
policy_assignment_job_chain_patch_from_dict = PolicyAssignmentJobChainPatch.from_dict(policy_assignment_job_chain_patch_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


