# PolicyAssignmentDetail


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**id** | **str** | The ID of the policy assignment. | 
**policy** | [**Policy**](Policy.md) | Full policy details. | 
**model** | [**ModelSummary**](ModelSummary.md) | Summary of the assigned model. | 
**applied_at** | **datetime** | When the policy was applied to the model. | 
**applied_by_user_id** | **str** |  | [optional] 
**enforcement_starts_at** | **datetime** | When enforcement starts. | 
**compliance_status** | [**ComplianceStatusDetail**](ComplianceStatusDetail.md) | Current compliance status. | 
**metrics_calc_job** | [**Job**](Job.md) |  | [optional] 
**alerts_check_job** | [**Job**](Job.md) |  | [optional] 
**compliance_job** | [**Job**](Job.md) |  | [optional] 
**last_violation_notified_at** | **datetime** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.policy_assignment_detail import PolicyAssignmentDetail

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAssignmentDetail from a JSON string
policy_assignment_detail_instance = PolicyAssignmentDetail.from_json(json)
# print the JSON string representation of the object
print(PolicyAssignmentDetail.to_json())

# convert the object into a dict
policy_assignment_detail_dict = policy_assignment_detail_instance.to_dict()
# create an instance of PolicyAssignmentDetail from a dict
policy_assignment_detail_from_dict = PolicyAssignmentDetail.from_dict(policy_assignment_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


