class RequiredClassException(Exception):
    pass
