class OperationalException(Exception):
    pass
