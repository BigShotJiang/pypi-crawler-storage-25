class IncompatibleAdapterException(Exception):
    pass
