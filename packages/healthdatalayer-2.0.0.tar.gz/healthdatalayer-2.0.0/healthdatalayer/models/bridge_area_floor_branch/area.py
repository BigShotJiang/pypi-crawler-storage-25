import uuid
from sqlmodel import Relationship, SQLModel, Field
from typing import TYPE_CHECKING, List, Optional

from healthdatalayer.models.inventory.alert import Alert
from healthdatalayer.models.inventory.internal_requisition import InternalRequisition
from healthdatalayer.models.inventory.stock_area import StockArea
from healthdatalayer.models.inventory.transaction import Transaction

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

class Area(SQLModel, table=True):
    __tablename__ = "area"
    
    area_id:uuid.UUID=Field(default_factory=uuid.uuid4,primary_key=True)

    name:str=Field(nullable=False)

    is_active: bool = Field(default=True)

    branch_id: Optional[uuid.UUID] = Field(default=None, foreign_key="branch.branch_id")
    branch: Optional["Branch"] = Relationship(back_populates="areas")

    stock_areas: List["StockArea"] = Relationship(back_populates="area")
    transactions: List["Transaction"] = Relationship(back_populates="area")
    internal_requisitions: List["InternalRequisition"] = Relationship(back_populates="area")
    alerts: List["Alert"] = Relationship(back_populates="area")
