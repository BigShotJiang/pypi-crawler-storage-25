from datetime import datetime
import uuid
from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship, UniqueConstraint
from sqlalchemy.orm import validates

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.area import Area
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

class StockArea(SQLModel, table=True):
    __tablename__ = "stock_area"
    __table_args__ = (
        UniqueConstraint("area_id", "supply_id", name="uq_stock_area_supply"),
    )

    stock_area_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    area_id: uuid.UUID = Field(foreign_key="area.area_id", index=True, nullable=False)
    current_quantity: int = Field(default=0)
    min_stock: int = Field(default=0)
    max_stock: Optional[int] = Field(default=None)
    
    is_active: bool = Field(default=True)
    
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    
    supply: Optional["Supply"] = Relationship(back_populates="stock_areas")
    area: Optional["Area"] = Relationship(back_populates="stock_areas")
    
    @validates("current_quantity")
    def validate_current_quantity(self, key, value):
        if value < 0:
            raise ValueError("La cantidad actual no puede ser negativa.")
        return value
    
    @property
    def at_least(self) -> bool:
        return self.current_quantity <= self.min_stock
    
    @property
    def at_most(self) -> bool:
        return self.current_quantity >= self.max_stock
