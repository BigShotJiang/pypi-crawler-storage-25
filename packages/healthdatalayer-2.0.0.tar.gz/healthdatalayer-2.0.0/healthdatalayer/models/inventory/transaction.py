import uuid
from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.transaction_reference_type import TransactionReferenceTypeEnum
from healthdatalayer.models.inventory.transaction_type_enum import TransactionTypeEnum

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.lot import Lot
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch
    from healthdatalayer.models.bridge_area_floor_branch.area import Area

class Transaction(SQLModel, table=True):
    __tablename__ = "transaction"

    transaction_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", nullable=False)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", nullable=False)
    area_id: uuid.UUID = Field(foreign_key="area.area_id", nullable=False)
    lot_id: uuid.UUID = Field(foreign_key="lot.lot_id", nullable=True)
    user_id: uuid.UUID = Field(foreign_key="user.user_id", nullable=False)

    quantity: int = Field(nullable=False)
    transaction_type: TransactionTypeEnum = Field(sa_column=Column(SqlEnum(TransactionTypeEnum, native_enum=False), nullable=False))
    
    motive: Optional[str] = Field(default=None, max_length=300)
    reference_id: Optional[uuid.UUID] = Field(default=None)
    reference_type: TransactionReferenceTypeEnum = Field(sa_column=Column(SqlEnum(TransactionReferenceTypeEnum, native_enum=False), nullable=False))
    
    created_at: Optional[datetime] = Field(default_factory=datetime.now)

    is_active: bool = Field(default=True)
    
    supply: Optional["Supply"] = Relationship(back_populates="transactions")
    lot: Optional["Lot"] = Relationship(back_populates="transactions")
    branch: Optional["Branch"] = Relationship(back_populates="transactions")
    area: Optional["Area"] = Relationship(back_populates="transactions")    