from enum import Enum

class StockTypeEnum(str, Enum):
    OPERATIONAL = "OPERACIONAL"
    DISTRIBUTION = "DISTRIBUCION"