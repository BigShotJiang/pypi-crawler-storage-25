import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.lot_status_enum import StatusLotEnum
from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail
from healthdatalayer.models.inventory.alert import Alert

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.supplier import Supplier
    from healthdatalayer.models.inventory.transfer_detail import TransferDetail
    from healthdatalayer.models.inventory.transaction import Transaction
    from healthdatalayer.models.inventory.internal_requisition_detail import InternalRequisitionDetail


class Lot(SQLModel, table=True):
    __tablename__ = "lot"

    lot_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    supplier_id: Optional[uuid.UUID] = Field(default=None, foreign_key="supplier.supplier_id")
    lot_number: str = Field(max_length=100, nullable=False)
    purchase_order_detail_id: Optional[uuid.UUID] = Field(default=None, foreign_key="purchase_order_detail.purchase_order_detail_id")

    # Quantity
    initial_quantity: Optional[int] = Field(default=None)
    current_quantity: Optional[int] = Field(default=None)

    # Dates
    reception_date: Optional[datetime] = Field(default=None)
    opening_date: Optional[datetime] = Field(default=None)
    expiration_date: Optional[datetime] = Field(default=None)

    # Commercial information
    brand: Optional[str] = Field(default=None, max_length=150)
    presentation: Optional[str] = Field(default=None, max_length=150)
    unit_measurement: Optional[str] = Field(default=None, max_length=50)
    unit_cost: Optional[float] = Field(default=None)

    # Storage temperature information
    requires_cooling: bool = Field(default=False)
    temperature_unit: Optional[str] = Field(default=None, max_length=1) 
    storage_temp_min: Optional[float] = Field(default=None)
    storage_temp_max: Optional[float] = Field(default=None)

    # Status and activity
    status_lot: StatusLotEnum = Field(sa_column=Column(SqlEnum(StatusLotEnum, native_enum=False), nullable=False))
    is_active: bool = Field(default=True)

    # Audit fields
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)

    supply: Optional["Supply"] = Relationship(back_populates="lots")
    supplier: Optional["Supplier"] = Relationship(back_populates="lots")
    transfer_details: List["TransferDetail"] = Relationship(back_populates="lot")
    transactions: List["Transaction"] = Relationship(back_populates="lot")
    requisition_details: List["InternalRequisitionDetail"] = Relationship(back_populates="lot")
    purchase_order_details: List["PurchaseOrderDetail"] = Relationship(back_populates="lot")
    alerts: List["Alert"] = Relationship(back_populates="lot")

    @property
    def has_expired(self) -> bool:
        return self.expiration_date is not None and self.expiration_date < datetime.today()

    @property
    def days_remaining(self) -> Optional[int]:
        if self.expiration_date is None:
            return None
        delta = self.expiration_date - datetime.today()
        return delta.days