from enum import Enum

class StatusLotEnum(str, Enum):
    ACTIVE          = "ACTIVO"
    QUARANTINE      = "CUARENTENADO"
    EXPIRED         = "VENCIDO"
    OUT_OF_STOCK    = "AGOTADO"