from enum import Enum

class PurchaseOrderStatusEnum(str, Enum):
    DRAFT   = "BORRADOR"
    SENT    = "ENVIADA"
    PARTIAL    = "PARCIAL"
    RECEIVED   = "RECIBIDA"
    CANCELLED  = "CANCELADA"