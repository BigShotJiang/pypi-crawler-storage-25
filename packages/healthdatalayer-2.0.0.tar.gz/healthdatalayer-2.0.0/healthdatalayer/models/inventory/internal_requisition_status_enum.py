from enum import Enum

class InternalRequisitionStatusEnum(str, Enum):
    PENDING = "PENDIENTE"
    VALIDATED = "VALIDADA"
    DISPATCHED = "DESPACHADA"
    RECEIVED = "RECIBIDA"
    CANCELLED = "CANCELADA"