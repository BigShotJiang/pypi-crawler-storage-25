import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.internal_requisition_status_enum import InternalRequisitionStatusEnum

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch
    from healthdatalayer.models.bridge_area_floor_branch.area import Area
    from healthdatalayer.models.inventory.internal_requisition_detail import InternalRequisitionDetail


class InternalRequisition(SQLModel, table=True):
    __tablename__ = "internal_requisition"

    requisition_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    requisition_number: str = Field(index=True, unique=True, max_length=100)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", nullable=False)
    area_id: uuid.UUID = Field(foreign_key="area.area_id", nullable=False)
    backup_document: Optional[str] = Field(default=None, max_length=300)

    requested_by: uuid.UUID = Field(foreign_key="user.user_id", nullable=False)
    approved_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")
    received_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")

    status: InternalRequisitionStatusEnum = Field(
        sa_column=Column(SqlEnum(InternalRequisitionStatusEnum, native_enum=False), nullable=False,
        default=InternalRequisitionStatusEnum.PENDING)
    )

    request_date: Optional[datetime] = Field(default_factory=datetime.now)
    approval_date: Optional[datetime] = Field(default=None)
    dispatch_date: Optional[datetime] = Field(default=None)
    received_date: Optional[datetime] = Field(default=None)

    notes: Optional[str] = Field(default=None, max_length=500)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    is_active: bool = Field(default=True)

    branch: Optional["Branch"] = Relationship(back_populates="internal_requisitions")
    area: Optional["Area"] = Relationship(back_populates="internal_requisitions")
    details: List["InternalRequisitionDetail"] = Relationship(back_populates="requisition")