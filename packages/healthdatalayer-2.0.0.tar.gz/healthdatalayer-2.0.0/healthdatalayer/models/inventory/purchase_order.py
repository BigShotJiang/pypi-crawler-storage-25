from datetime import datetime
import uuid
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.purchase_order_status_enum import PurchaseOrderStatusEnum

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch
    from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail
    from healthdatalayer.models.inventory.supplier import Supplier

class PurchaseOrder(SQLModel, table=True):
    __tablename__ = "purchase_order"

    purchase_order_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    order_number: str = Field(index=True, unique=True, max_length=100)
    supplier_id: uuid.UUID = Field(foreign_key="supplier.supplier_id", nullable=False)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", nullable=False)
    requested_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")
    backup_document: Optional[str] = Field(default=None, max_length=300)

    status: PurchaseOrderStatusEnum = Field(sa_column=Column(SqlEnum(PurchaseOrderStatusEnum, native_enum=False), nullable=False, default=PurchaseOrderStatusEnum.DRAFT))
    
    presentation: Optional[str] = Field(default=None, max_length=150)

    expected_delivery_date: Optional[datetime] = Field(default=None)
    delivered_date: Optional[datetime] = Field(default=None)
    
    notes: Optional[str] = Field(default=None)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    is_active: bool = Field(default=True)
    
    branch: Optional["Branch"] = Relationship(back_populates="purchase_orders")
    supplier: Optional["Supplier"] = Relationship(back_populates="purchase_orders")
    details: List["PurchaseOrderDetail"] = Relationship(back_populates="purchase_order")

    @property
    def total(self) -> float:
        return sum(d.subtotal for d in self.details if d.subtotal is not None)

    @property
    def total_requested(self) -> int:
        return sum(d.quantity_requested for d in self.details)

    @property
    def total_accepted(self) -> int:
        return sum(d.quantity_accepted for d in self.details if d.quantity_accepted is not None)
    
    @property
    def supplier_lead_time_days(self) -> Optional[int]:
        if self.delivered_date is None or self.created_at is None:
            return None
        delta = self.delivered_date - self.created_at
        return delta.days
