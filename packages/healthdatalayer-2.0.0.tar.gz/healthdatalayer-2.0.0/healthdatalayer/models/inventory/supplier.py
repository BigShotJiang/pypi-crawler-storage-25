from datetime import datetime
import uuid
from typing import List, Optional, TYPE_CHECKING
from sqlmodel import Relationship, SQLModel, Field

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.lot import Lot
    from healthdatalayer.models.inventory.purchase_order import PurchaseOrder

class Supplier(SQLModel, table=True):
    __tablename__ = "supplier"

    supplier_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    
    name: str = Field(nullable=False)
    identification: str = Field(nullable=False)
    contact_name: Optional[str] = Field(nullable=True)
    phone: Optional[str] = Field(nullable=True)
    email: Optional[str] = Field(nullable=True)
    lead_time_days: Optional[int] = Field(default=None, nullable=True)

    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    is_active: bool = Field(default=True)

    purchase_orders: List["PurchaseOrder"] = Relationship(back_populates="supplier")
    lots: List["Lot"] = Relationship(back_populates="supplier")
