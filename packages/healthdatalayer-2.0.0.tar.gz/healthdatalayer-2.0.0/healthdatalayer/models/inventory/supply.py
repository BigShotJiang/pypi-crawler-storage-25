import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.criticality_supply_enum import CriticalitySupplyEnum

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.parent_supply import ParentSupply
    from healthdatalayer.models.inventory.stock_branch import StockBranch
    from healthdatalayer.models.inventory.lot import Lot
    from healthdatalayer.models.inventory.transaction import Transaction
    from healthdatalayer.models.inventory.transfer_detail import TransferDetail
    from healthdatalayer.models.inventory.alert import Alert
    from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail
    from healthdatalayer.models.inventory.stock_area import StockArea
    from healthdatalayer.models.inventory.internal_requisition_detail import InternalRequisitionDetail


class Supply(SQLModel, table=True):
    __tablename__ = "supply"

    supply_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    code: str = Field(index=True, unique=True, max_length=50)
    name: str = Field(max_length=150)
    commercial_name: Optional[str] = Field(default=None, max_length=200)
    description: Optional[str] = Field(default=None, max_length=500)
    
    methodology: Optional[str] = Field(default=None, max_length=200)

    criticality: CriticalitySupplyEnum = Field(sa_column=Column(SqlEnum(CriticalitySupplyEnum, native_enum=False), nullable=False))

    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)

    is_active: bool = Field(default=True)
    
    parent_supply_id: Optional[uuid.UUID] = Field(default=None, foreign_key="parent_supply.parent_supply_id")
    parent_supply: Optional["ParentSupply"] = Relationship(back_populates="supplies")
    
    stock_branches: List["StockBranch"] = Relationship(back_populates="supply")
    stock_areas: List["StockArea"] = Relationship(back_populates="supply")
    lots: List["Lot"] = Relationship(back_populates="supply")
    transactions: List["Transaction"] = Relationship(back_populates="supply")
    transfer_details: List["TransferDetail"] = Relationship(back_populates="supply")
    purchase_order_details: List["PurchaseOrderDetail"] = Relationship(back_populates="supply")
    alerts: List["Alert"] = Relationship(back_populates="supply")
    requisition_details: List["InternalRequisitionDetail"] = Relationship(back_populates="supply")
