from enum import Enum

class TransactionTypeEnum(str, Enum):
    INPUT                   = "ENTRADA"
    OUTPUT                  = "SALIDA"
    ADJUSTMENT_POSITIVE     = "AJUSTE_POSITIVO"
    ADJUSTMENT_NEGATIVE     = "AJUSTE_NEGATIVO"
    TRANSFER_OUTPUT         = "TRASPASO_SALIDA"
    TRANSFER_INPUT          = "TRASPASO_ENTRADA"
    RETURN                  = "DEVOLUCION"
    DECREASE                = "MERMA"