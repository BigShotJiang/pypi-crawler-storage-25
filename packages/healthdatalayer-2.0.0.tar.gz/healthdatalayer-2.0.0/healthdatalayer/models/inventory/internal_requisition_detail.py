import uuid
from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.internal_requisition import InternalRequisition
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.lot import Lot


class InternalRequisitionDetail(SQLModel, table=True):
    __tablename__ = "internal_requisition_detail"

    requisition_detail_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    requisition_id: uuid.UUID = Field(foreign_key="internal_requisition.requisition_id", nullable=False)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", nullable=False)

    lot_id: Optional[uuid.UUID] = Field(default=None, foreign_key="lot.lot_id")

    qty_requested: int = Field(nullable=False)
    qty_dispatched: Optional[int] = Field(default=None)
    qty_received: Optional[int] = Field(default=None)

    is_active: bool = Field(default=True)

    requisition: Optional["InternalRequisition"] = Relationship(back_populates="details")
    supply: Optional["Supply"] = Relationship(back_populates="requisition_details")
    lot: Optional["Lot"] = Relationship(back_populates="requisition_details")