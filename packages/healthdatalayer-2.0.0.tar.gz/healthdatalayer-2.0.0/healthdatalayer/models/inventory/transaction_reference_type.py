from enum import Enum

class TransactionReferenceTypeEnum(str, Enum):
    TRANSFER            = "TRANSFER"
    PURCHASE_ORDER      = "PURCHASE_ORDER"
    REQUISITION         = "REQUISITION"