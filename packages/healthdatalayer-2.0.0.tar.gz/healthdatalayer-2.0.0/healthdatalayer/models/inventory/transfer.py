import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.transfer_status_enum import TransferStatusEnum

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch
    from healthdatalayer.models.inventory.transfer_detail import TransferDetail

class Transfer(SQLModel, table=True):
    __tablename__ = "transfer"

    transfer_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    transfer_number: str = Field(index=True, unique=True, max_length=100)
    from_branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", index=True, nullable=False)
    to_branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", index=True, nullable=False)
    status: TransferStatusEnum = Field(sa_column=Column(SqlEnum(TransferStatusEnum, native_enum=False), nullable=False, default=TransferStatusEnum.REQUEST))
    backup_document: Optional[str] = Field(default=None, max_length=300)
    
    requested_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")
    approved_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")
    dispatched_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")
    received_by: Optional[uuid.UUID] = Field(default=None, foreign_key="user.user_id")

    request_date: Optional[datetime] = Field(default_factory=datetime.now)
    approval_date: Optional[datetime] = Field(default=None)
    dispatch_date: Optional[datetime] = Field(default=None)
    receive_date: Optional[datetime] = Field(default=None)
    
    description: Optional[str] = Field(default=None)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    is_active: bool = Field(default=True)
    
    from_branch: Optional["Branch"] = Relationship(
        sa_relationship_kwargs={"foreign_keys": "[Transfer.from_branch_id]"},
        back_populates="transfers_from"
    )
    to_branch: Optional["Branch"] = Relationship(
        sa_relationship_kwargs={"foreign_keys": "[Transfer.to_branch_id]"},
        back_populates="transfers_to"
    )
    details: List["TransferDetail"] = Relationship(back_populates="transfer")