from datetime import datetime
import uuid
from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship, UniqueConstraint
from sqlalchemy.orm import validates
from sqlalchemy import Column, Enum as SqlEnum

from healthdatalayer.models.inventory.stock_type_enum import StockTypeEnum

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

class StockBranch(SQLModel, table=True):
    __tablename__ = "stock_branch"
    __table_args__ = (
        UniqueConstraint("branch_id", "supply_id", name="uq_stock_branch_supply"),
    )

    stock_branch_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", index=True, nullable=False)
    current_quantity: int = Field(default=0)
    min_stock: int = Field(default=0)
    max_stock: Optional[int] = Field(default=None)

    stock_type: StockTypeEnum = Field(
        sa_column=Column(SqlEnum(StockTypeEnum, native_enum=False), nullable=False,
        default=StockTypeEnum.OPERATIONAL)
    )
    
    is_active: bool = Field(default=True)
    
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    
    supply: Optional["Supply"] = Relationship(back_populates="stock_branches")
    branch: Optional["Branch"] = Relationship(back_populates="stock_branches")
    
    @validates("current_quantity")
    def validate_current_quantity(self, key, value):
        if value < 0:
            raise ValueError("La cantidad actual no puede ser negativa.")
        return value
    
    @property
    def at_least(self) -> bool:
        return self.current_quantity <= self.min_stock
    
    @property
    def at_most(self) -> bool:
        return self.current_quantity >= self.max_stock