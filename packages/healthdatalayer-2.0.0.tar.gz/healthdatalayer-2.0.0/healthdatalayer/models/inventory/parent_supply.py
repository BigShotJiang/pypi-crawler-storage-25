import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.category import Category
    from healthdatalayer.models.inventory.supply import Supply

class ParentSupply(SQLModel, table=True):
    __tablename__ = "parent_supply"

    parent_supply_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    code: str = Field(index=True, unique=True, max_length=50)
    name: str = Field(max_length=150)
    category_id: Optional[uuid.UUID] = Field(default=None, foreign_key="category.category_id")
    description: Optional[str] = Field(default=None, max_length=500)
    is_active: bool = Field(default=True)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)

    category: Optional["Category"] = Relationship(back_populates="parent_supplies")
    supplies: List["Supply"] = Relationship(back_populates="parent_supply")