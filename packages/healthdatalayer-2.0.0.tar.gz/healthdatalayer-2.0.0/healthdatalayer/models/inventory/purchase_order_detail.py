import uuid
from typing import Optional, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Numeric

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.purchase_order import PurchaseOrder
    from healthdatalayer.models.inventory.lot import Lot

class PurchaseOrderDetail(SQLModel, table=True):
    __tablename__ = "purchase_order_detail"

    purchase_order_detail_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    purchase_order_id: uuid.UUID = Field(foreign_key="purchase_order.purchase_order_id", index=True, nullable=False)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    
    quantity_requested: int = Field(nullable=False)
    quantity_received: Optional[int] = Field(default=None)
    quantity_rejected: Optional[int] = Field(default=None)

    unit_price: float = Field(default=0.0, sa_column=Column(Numeric(10, 2), nullable=False))

    purchase_order: Optional["PurchaseOrder"] = Relationship(back_populates="details")
    supply: Optional["Supply"] = Relationship(back_populates="purchase_order_details")
    lot: Optional["Lot"] = Relationship(back_populates="purchase_order_details")
    
    @property
    def quantity_accepted(self) -> Optional[int]:
        if self.quantity_received is None:
            return None
        return self.quantity_received - (self.quantity_rejected or 0)

    @property
    def subtotal(self) -> float:
        return float(self.unit_price) * self.quantity_requested