from enum import Enum

class TransferStatusEnum(str, Enum):
    REQUEST = "SOLICITADO"
    APPROVED   = "APROBADO"
    SHIPPED = "DESPACHADO"
    DELIVERED   = "RECIBIDO"
    REJECTED  = "RECHAZADO"
    CANCELLED  = "CANCELADO"