from typing import List, Optional
from uuid import UUID

from sqlalchemy import and_
from sqlalchemy.orm import joinedload
from sqlmodel import select

from healthdatalayer.models.inventory.alert import Alert
from healthdatalayer.models.inventory.alert_type_enum import AlertTypeEnum
from healthdatalayer.repositories.base_repository import BaseRepository


class AlertRepository(BaseRepository[Alert]):
    def __init__(self, tenant: str):
        """Initialize the repository for Alert entities."""
        super().__init__(tenant, Alert)

    def _detail_options(self):
        return (
            joinedload(Alert.branch),
            joinedload(Alert.area),
            joinedload(Alert.supply),
            joinedload(Alert.lot),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def create_command(self, alert: Alert) -> Optional[Alert]:
        """Create an alert if no unread duplicate exists."""
        with self._get_session() as session:
            existing = session.exec(
                select(Alert).where(
                    and_(
                        Alert.branch_id == alert.branch_id,
                        Alert.area_id == alert.area_id,
                        Alert.supply_id == alert.supply_id,
                        Alert.lot_id == alert.lot_id,
                        Alert.alert_type == alert.alert_type,
                        Alert.is_read == False,
                        Alert.is_active == True,
                    )
                )
            ).first()
            if existing:
                return None

            session.add(alert)
            session.commit()
            session.refresh(alert)
            return alert

    def get_by_id_command(
        self, alert_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Alert]:
        """Get an alert by its id."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.alert_id == alert_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False, limit: Optional[int] = None
    ) -> List[Alert]:
        """Get all alerts."""
        with self._get_session() as session:
            statement = select(Alert)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_type_command(
        self, alert_type: AlertTypeEnum, active_only: bool = True, load_details: bool = False
    ) -> List[Alert]:
        """Get all alerts of a specific type."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.alert_type == alert_type)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_branch_command(
        self,
        branch_id: UUID,
        active_only: bool = True,
        load_details: bool = False,
        limit: Optional[int] = None,
    ) -> List[Alert]:
        """Get all alerts for a specific branch."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Alert]:
        """Get all alerts for a specific supply."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_unread_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Alert]:
        """Get all unread alerts."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.is_read == False, Alert.is_active == True)
            if branch_id:
                statement = statement.where(Alert.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_stock_alerts_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Alert]:
        """Get all stock-related alerts."""
        with self._get_session() as session:
            statement = select(Alert).where(
                Alert.alert_type.in_(
                    [
                        AlertTypeEnum.LOW_STOCK,
                        AlertTypeEnum.STOCK_BREAK,
                        AlertTypeEnum.EXCESS_STOCK,
                    ]
                ),
                Alert.is_active == True,
            )
            if branch_id:
                statement = statement.where(Alert.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_expiry_alerts_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Alert]:
        """Get all expiry-related alerts."""
        with self._get_session() as session:
            statement = select(Alert).where(
                Alert.alert_type.in_(
                    [
                        AlertTypeEnum.EXPIRING_SOON,
                        AlertTypeEnum.EXPIRED,
                    ]
                ),
                Alert.is_active == True,
            )
            if branch_id:
                statement = statement.where(Alert.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def mark_as_read_command(self, alert_id: UUID) -> Alert:
        """Mark an alert as read."""
        with self._get_session() as session:
            alert = session.get(Alert, alert_id)
            if not alert:
                raise ValueError(f"Alert with id {alert_id} does not exist")

            alert.is_read = True
            session.add(alert)
            session.commit()
            session.refresh(alert)
            return alert

    def mark_all_as_read_command(self, branch_id: Optional[UUID] = None) -> int:
        """Mark all alerts as read."""
        with self._get_session() as session:
            statement = select(Alert).where(Alert.is_read == False, Alert.is_active == True)
            if branch_id:
                statement = statement.where(Alert.branch_id == branch_id)

            alerts = session.exec(statement).all()
            for alert in alerts:
                alert.is_read = True
                session.add(alert)

            session.commit()
            return len(alerts)

    def exists_unread_command(
        self,
        branch_id: UUID,
        supply_id: UUID,
        alert_type: AlertTypeEnum,
        area_id: Optional[UUID] = None,
        lot_id: Optional[UUID] = None,
    ) -> bool:
        """Check if an unread alert already exists."""
        with self._get_session() as session:
            result = session.exec(
                select(Alert).where(
                    and_(
                        Alert.branch_id == branch_id,
                        Alert.area_id == area_id,
                        Alert.supply_id == supply_id,
                        Alert.lot_id == lot_id,
                        Alert.alert_type == alert_type,
                        Alert.is_read == False,
                        Alert.is_active == True,
                    )
                )
            ).first()
            return result is not None
