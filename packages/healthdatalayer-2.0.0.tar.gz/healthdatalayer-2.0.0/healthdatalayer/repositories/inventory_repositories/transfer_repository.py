from datetime import datetime
from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import joinedload, selectinload
from sqlmodel import select

from healthdatalayer.models.inventory.transfer import Transfer
from healthdatalayer.models.inventory.transfer_status_enum import TransferStatusEnum
from healthdatalayer.repositories.base_repository import BaseRepository


class TransferRepository(BaseRepository[Transfer]):
    def __init__(self, tenant: str):
        """Initialize the repository for Transfer entities."""
        super().__init__(tenant, Transfer)

    def _detail_options(self):
        return (
            joinedload(Transfer.from_branch),
            joinedload(Transfer.to_branch),
            selectinload(Transfer.details),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def _validate_status_transition(
        self, current_status: TransferStatusEnum, new_status: TransferStatusEnum
    ) -> bool:
        """Validate a transfer status transition."""
        valid_transitions = {
            TransferStatusEnum.REQUEST: [TransferStatusEnum.APPROVED, TransferStatusEnum.REJECTED],
            TransferStatusEnum.APPROVED: [TransferStatusEnum.SHIPPED, TransferStatusEnum.CANCELLED],
            TransferStatusEnum.SHIPPED: [TransferStatusEnum.DELIVERED],
        }
        return new_status in valid_transitions.get(current_status, [])

    def get_by_id_command(
        self, transfer_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Transfer]:
        """Get a transfer by its id."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.transfer_id == transfer_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_transfer_number_command(
        self, transfer_number: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[Transfer]:
        """Get a transfer by its transfer number."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.transfer_number == transfer_number)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers."""
        with self._get_session() as session:
            statement = select(Transfer)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_status_command(
        self, status: TransferStatusEnum, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers with a specific status."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.status == status)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_origin_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers from a specific origin branch."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.from_branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_destination_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers for a specific destination branch."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.to_branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_approval_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending approval."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.REQUEST,
                Transfer.is_active == True,
            )
            if branch_id:
                statement = statement.where(Transfer.from_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_dispatch_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending dispatch."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.APPROVED,
                Transfer.is_active == True,
            )
            if branch_id:
                statement = statement.where(Transfer.from_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_reception_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending reception."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.SHIPPED,
                Transfer.is_active == True,
            )
            if branch_id:
                statement = statement.where(Transfer.to_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(self, transfer_id: UUID, new_status: TransferStatusEnum) -> Transfer:
        """Update the status of a transfer."""
        with self._get_session() as session:
            transfer = session.get(Transfer, transfer_id)
            if not transfer:
                raise ValueError(f"Transfer with id {transfer_id} does not exist")

            if not self._validate_status_transition(transfer.status, new_status):
                raise ValueError(
                    f"Invalid status transition from {transfer.status.value} to {new_status.value}"
                )

            transfer.status = new_status
            transfer.updated_at = datetime.now()
            if new_status == TransferStatusEnum.APPROVED:
                transfer.approval_date = datetime.now()
            elif new_status == TransferStatusEnum.SHIPPED:
                transfer.dispatch_date = datetime.now()
            elif new_status == TransferStatusEnum.DELIVERED:
                transfer.receive_date = datetime.now()

            session.add(transfer)
            session.commit()
            session.refresh(transfer)
            return transfer

    def approve_command(self, transfer_id: UUID) -> Transfer:
        """Approve a transfer."""
        return self.update_status_command(transfer_id, TransferStatusEnum.APPROVED)

    def dispatch_command(self, transfer_id: UUID) -> Transfer:
        """Dispatch a transfer."""
        return self.update_status_command(transfer_id, TransferStatusEnum.SHIPPED)

    def receive_command(self, transfer_id: UUID) -> Transfer:
        """Receive a transfer."""
        return self.update_status_command(transfer_id, TransferStatusEnum.DELIVERED)

    def reject_command(self, transfer_id: UUID) -> Transfer:
        """Reject a transfer."""
        return self.update_status_command(transfer_id, TransferStatusEnum.REJECTED)

    def cancel_command(self, transfer_id: UUID) -> Transfer:
        """Cancel a transfer."""
        return self.update_status_command(transfer_id, TransferStatusEnum.CANCELLED)
