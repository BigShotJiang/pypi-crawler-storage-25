from datetime import datetime
from typing import List, Optional
from uuid import UUID

from sqlalchemy import and_
from sqlalchemy.orm import joinedload, selectinload
from sqlmodel import select

from healthdatalayer.models.inventory.purchase_order import PurchaseOrder
from healthdatalayer.models.inventory.purchase_order_status_enum import PurchaseOrderStatusEnum
from healthdatalayer.repositories.base_repository import BaseRepository


class PurchaseOrderRepository(BaseRepository[PurchaseOrder]):
    def __init__(self, tenant: str):
        """Initialize the repository for PurchaseOrder entities."""
        super().__init__(tenant, PurchaseOrder)

    def _detail_options(self):
        return (
            joinedload(PurchaseOrder.branch),
            joinedload(PurchaseOrder.supplier),
            selectinload(PurchaseOrder.details),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, purchase_order_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[PurchaseOrder]:
        """Get a purchase order by its id."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.purchase_order_id == purchase_order_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_order_number_command(
        self, order_number: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[PurchaseOrder]:
        """Get a purchase order by its order number."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.order_number == order_number)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders."""
        with self._get_session() as session:
            statement = select(PurchaseOrder)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_status_command(
        self,
        status: PurchaseOrderStatusEnum,
        active_only: bool = True,
        load_details: bool = False,
    ) -> List[PurchaseOrder]:
        """Get all purchase orders with a specific status."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.status == status)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders for a specific branch."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supplier_command(
        self, supplier_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders for a specific supplier."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.supplier_id == supplier_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_date_range_command(
        self,
        start_date: datetime,
        end_date: datetime,
        branch_id: Optional[UUID] = None,
        load_details: bool = False,
        active_only: bool = True,
    ) -> List[PurchaseOrder]:
        """Get purchase orders within a date range."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                and_(
                    PurchaseOrder.created_at >= start_date,
                    PurchaseOrder.created_at <= end_date,
                )
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_draft_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all draft purchase orders."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.status == PurchaseOrderStatusEnum.DRAFT,
                PurchaseOrder.is_active == True,
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_reception_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders pending reception."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.status.in_(
                    [
                        PurchaseOrderStatusEnum.SENT,
                        PurchaseOrderStatusEnum.PARTIAL,
                    ]
                ),
                PurchaseOrder.is_active == True,
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(
        self, purchase_order_id: UUID, new_status: PurchaseOrderStatusEnum
    ) -> PurchaseOrder:
        """Update the status of a purchase order."""
        with self._get_session() as session:
            purchase_order = session.get(PurchaseOrder, purchase_order_id)
            if not purchase_order:
                raise ValueError(f"PurchaseOrder with id {purchase_order_id} does not exist")

            purchase_order.status = new_status
            purchase_order.updated_at = datetime.now()
            if new_status == PurchaseOrderStatusEnum.RECEIVED and purchase_order.delivered_date is None:
                purchase_order.delivered_date = datetime.now()

            session.add(purchase_order)
            session.commit()
            session.refresh(purchase_order)
            return purchase_order

    def send_command(self, purchase_order_id: UUID) -> PurchaseOrder:
        """Send a purchase order."""
        return self.update_status_command(purchase_order_id, PurchaseOrderStatusEnum.SENT)

    def cancel_command(self, purchase_order_id: UUID) -> PurchaseOrder:
        """Cancel a purchase order."""
        return self.update_status_command(purchase_order_id, PurchaseOrderStatusEnum.CANCELLED)
