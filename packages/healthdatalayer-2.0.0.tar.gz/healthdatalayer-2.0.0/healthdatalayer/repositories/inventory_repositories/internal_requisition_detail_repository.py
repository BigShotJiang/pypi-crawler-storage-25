from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import joinedload
from sqlmodel import select

from healthdatalayer.models.inventory.internal_requisition_detail import InternalRequisitionDetail
from healthdatalayer.repositories.base_repository import BaseRepository


class InternalRequisitionDetailRepository(BaseRepository[InternalRequisitionDetail]):
    def __init__(self, tenant: str):
        """Initialize the repository for InternalRequisitionDetail entities."""
        super().__init__(tenant, InternalRequisitionDetail)

    def _detail_options(self):
        return (
            joinedload(InternalRequisitionDetail.requisition),
            joinedload(InternalRequisitionDetail.supply),
            joinedload(InternalRequisitionDetail.lot),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, requisition_detail_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[InternalRequisitionDetail]:
        """Get an internal requisition detail by its id."""
        with self._get_session() as session:
            statement = select(InternalRequisitionDetail).where(
                InternalRequisitionDetail.requisition_detail_id == requisition_detail_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisitionDetail]:
        """Get all internal requisition details."""
        with self._get_session() as session:
            statement = select(InternalRequisitionDetail)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_requisition_command(
        self, requisition_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisitionDetail]:
        """Get all details for a specific requisition."""
        with self._get_session() as session:
            statement = select(InternalRequisitionDetail).where(
                InternalRequisitionDetail.requisition_id == requisition_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisitionDetail]:
        """Get all requisition details for a specific supply."""
        with self._get_session() as session:
            statement = select(InternalRequisitionDetail).where(
                InternalRequisitionDetail.supply_id == supply_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_lot_command(
        self, lot_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisitionDetail]:
        """Get all requisition details for a specific lot."""
        with self._get_session() as session:
            statement = select(InternalRequisitionDetail).where(
                InternalRequisitionDetail.lot_id == lot_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_dispatched_quantity_command(
        self, requisition_detail_id: UUID, dispatched_qty: int
    ) -> InternalRequisitionDetail:
        """Update the dispatched quantity of a requisition detail."""
        with self._get_session() as session:
            detail = session.get(InternalRequisitionDetail, requisition_detail_id)
            if not detail:
                raise ValueError(
                    f"InternalRequisitionDetail with id {requisition_detail_id} does not exist"
                )

            detail.qty_dispatched = dispatched_qty
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail

    def update_received_quantity_command(
        self, requisition_detail_id: UUID, received_qty: int
    ) -> InternalRequisitionDetail:
        """Update the received quantity of a requisition detail."""
        with self._get_session() as session:
            detail = session.get(InternalRequisitionDetail, requisition_detail_id)
            if not detail:
                raise ValueError(
                    f"InternalRequisitionDetail with id {requisition_detail_id} does not exist"
                )

            detail.qty_received = received_qty
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail
