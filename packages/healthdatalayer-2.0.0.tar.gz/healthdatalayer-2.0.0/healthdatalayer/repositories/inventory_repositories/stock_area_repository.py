from typing import List, Optional
from uuid import UUID

from sqlalchemy import and_
from sqlalchemy.orm import joinedload
from sqlmodel import select

from healthdatalayer.models.inventory.stock_area import StockArea
from healthdatalayer.repositories.base_repository import BaseRepository


class StockAreaRepository(BaseRepository[StockArea]):
    def __init__(self, tenant: str):
        """Initialize the repository for StockArea entities."""
        super().__init__(tenant, StockArea)

    def _detail_options(self):
        return (
            joinedload(StockArea.supply),
            joinedload(StockArea.area),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, stock_area_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[StockArea]:
        """Get a stock area by its id."""
        with self._get_session() as session:
            statement = select(StockArea).where(StockArea.stock_area_id == stock_area_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_area_and_supply_command(
        self, area_id: UUID, supply_id: UUID, load_details: bool = False
    ) -> Optional[StockArea]:
        """Get stock for a specific area and supply."""
        with self._get_session() as session:
            statement = select(StockArea).where(
                and_(StockArea.area_id == area_id, StockArea.supply_id == supply_id)
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_or_create_command(
        self, area_id: UUID, supply_id: UUID, min_stock: int = 0, max_stock: Optional[int] = None
    ) -> StockArea:
        """Get existing stock or create it if missing."""
        with self._get_session() as session:
            statement = select(StockArea).where(
                and_(StockArea.area_id == area_id, StockArea.supply_id == supply_id)
            )
            existing = session.exec(statement).first()
            if existing:
                return existing

            new_stock = StockArea(
                area_id=area_id,
                supply_id=supply_id,
                min_stock=min_stock,
                max_stock=max_stock,
                current_quantity=0,
            )
            session.add(new_stock)
            session.commit()
            session.refresh(new_stock)
            return new_stock

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[StockArea]:
        """Get all stock area records."""
        with self._get_session() as session:
            statement = select(StockArea)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_area_command(
        self, area_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[StockArea]:
        """Get all stock records for a specific area."""
        with self._get_session() as session:
            statement = select(StockArea).where(StockArea.area_id == area_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[StockArea]:
        """Get all stock area records for a specific supply."""
        with self._get_session() as session:
            statement = select(StockArea).where(StockArea.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_low_stock_command(
        self, area_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[StockArea]:
        """Get all low stock area records."""
        with self._get_session() as session:
            statement = select(StockArea).where(
                StockArea.current_quantity <= StockArea.min_stock,
                StockArea.is_active == True,
            )
            if area_id:
                statement = statement.where(StockArea.area_id == area_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_overstock_command(
        self, area_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[StockArea]:
        """Get all overstock area records."""
        with self._get_session() as session:
            statement = select(StockArea).where(
                StockArea.current_quantity >= StockArea.max_stock,
                StockArea.is_active == True,
                StockArea.max_stock.isnot(None),
            )
            if area_id:
                statement = statement.where(StockArea.area_id == area_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_quantity_command(self, stock_area_id: UUID, new_quantity: int) -> StockArea:
        """Update the quantity of a stock area record."""
        with self._get_session() as session:
            stock = session.get(StockArea, stock_area_id)
            if not stock:
                raise ValueError(f"StockArea with id {stock_area_id} does not exist")

            stock.current_quantity = new_quantity
            session.add(stock)
            session.commit()
            session.refresh(stock)
            return stock

    def adjust_quantity_command(self, stock_area_id: UUID, adjustment: int) -> StockArea:
        """Adjust the quantity of a stock area record."""
        with self._get_session() as session:
            stock = session.get(StockArea, stock_area_id)
            if not stock:
                raise ValueError(f"StockArea with id {stock_area_id} does not exist")

            new_quantity = stock.current_quantity + adjustment
            if new_quantity < 0:
                raise ValueError("Stock cannot go negative")

            stock.current_quantity = new_quantity
            session.add(stock)
            session.commit()
            session.refresh(stock)
            return stock
