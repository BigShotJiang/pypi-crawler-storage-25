from datetime import datetime
from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import joinedload, selectinload
from sqlmodel import select

from healthdatalayer.models.inventory.internal_requisition import InternalRequisition
from healthdatalayer.models.inventory.internal_requisition_detail import InternalRequisitionDetail
from healthdatalayer.models.inventory.internal_requisition_status_enum import (
    InternalRequisitionStatusEnum,
)
from healthdatalayer.repositories.base_repository import BaseRepository


class InternalRequisitionRepository(BaseRepository[InternalRequisition]):
    def __init__(self, tenant: str):
        """Initialize the repository for InternalRequisition entities."""
        super().__init__(tenant, InternalRequisition)

    def _detail_options(self):
        return (
            joinedload(InternalRequisition.branch),
            joinedload(InternalRequisition.area),
            selectinload(InternalRequisition.details).joinedload(InternalRequisitionDetail.supply),
            selectinload(InternalRequisition.details).joinedload(InternalRequisitionDetail.lot),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, requisition_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[InternalRequisition]:
        """Get an internal requisition by its id."""
        with self._get_session() as session:
            statement = select(InternalRequisition).where(
                InternalRequisition.requisition_id == requisition_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_requisition_number_command(
        self, requisition_number: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[InternalRequisition]:
        """Get an internal requisition by its requisition number."""
        with self._get_session() as session:
            statement = select(InternalRequisition).where(
                InternalRequisition.requisition_number == requisition_number
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisition]:
        """Get all internal requisitions."""
        with self._get_session() as session:
            statement = select(InternalRequisition)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisition]:
        """Get all internal requisitions for a specific branch."""
        with self._get_session() as session:
            statement = select(InternalRequisition).where(InternalRequisition.branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_area_command(
        self, area_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[InternalRequisition]:
        """Get all internal requisitions for a specific area."""
        with self._get_session() as session:
            statement = select(InternalRequisition).where(InternalRequisition.area_id == area_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_status_command(
        self,
        status: InternalRequisitionStatusEnum,
        active_only: bool = True,
        load_details: bool = False,
    ) -> List[InternalRequisition]:
        """Get all internal requisitions with a specific status."""
        with self._get_session() as session:
            statement = select(InternalRequisition).where(InternalRequisition.status == status)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(
        self, requisition_id: UUID, new_status: InternalRequisitionStatusEnum
    ) -> InternalRequisition:
        """Update the status of an internal requisition."""
        with self._get_session() as session:
            requisition = session.get(InternalRequisition, requisition_id)
            if not requisition:
                raise ValueError(f"InternalRequisition with id {requisition_id} does not exist")

            requisition.status = new_status
            requisition.updated_at = datetime.now()
            if new_status == InternalRequisitionStatusEnum.VALIDATED:
                requisition.approval_date = datetime.now()
            elif new_status == InternalRequisitionStatusEnum.DISPATCHED:
                requisition.dispatch_date = datetime.now()
            elif new_status == InternalRequisitionStatusEnum.RECEIVED:
                requisition.received_date = datetime.now()

            session.add(requisition)
            session.commit()
            session.refresh(requisition)
            return requisition
