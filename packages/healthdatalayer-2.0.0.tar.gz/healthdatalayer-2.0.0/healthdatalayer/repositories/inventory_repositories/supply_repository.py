from typing import List, Optional
from uuid import UUID

from sqlalchemy import or_
from sqlalchemy.orm import joinedload
from sqlmodel import select

from healthdatalayer.models.inventory.criticality_supply_enum import CriticalitySupplyEnum
from healthdatalayer.models.inventory.supply import Supply
from healthdatalayer.repositories.base_repository import BaseRepository


class SupplyRepository(BaseRepository[Supply]):
    def __init__(self, tenant: str):
        """Initialize the repository for Supply entities."""
        super().__init__(tenant, Supply)

    def _detail_options(self):
        return (
            joinedload(Supply.parent_supply),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, supply_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Supply]:
        """Get a supply by its id."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_code_command(self, code: str, active_only: bool = True) -> Optional[Supply]:
        """Get a supply by its code."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.code == code)
            statement = self._apply_active_filter(statement, active_only)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Get all supplies."""
        with self._get_session() as session:
            statement = select(Supply)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_parent_supply_command(
        self, parent_supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Get all supplies for a specific parent supply."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.parent_supply_id == parent_supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_criticality_command(
        self,
        criticality: CriticalitySupplyEnum,
        active_only: bool = True,
        load_details: bool = False,
    ) -> List[Supply]:
        """Get all supplies with a specific criticality."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.criticality == criticality)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def search_command(
        self, search_term: str, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Search supplies by code, name, commercial name, or description."""
        with self._get_session() as session:
            statement = select(Supply).where(
                or_(
                    Supply.code.ilike(f"%{search_term}%"),
                    Supply.name.ilike(f"%{search_term}%"),
                    Supply.commercial_name.ilike(f"%{search_term}%"),
                    Supply.description.ilike(f"%{search_term}%"),
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
