from typing import List, Optional
from uuid import UUID

from sqlalchemy import or_
from sqlalchemy.orm import joinedload, selectinload
from sqlmodel import select

from healthdatalayer.models.inventory.parent_supply import ParentSupply
from healthdatalayer.repositories.base_repository import BaseRepository


class ParentSupplyRepository(BaseRepository[ParentSupply]):
    def __init__(self, tenant: str):
        """Initialize the repository for ParentSupply entities."""
        super().__init__(tenant, ParentSupply)

    def _detail_options(self):
        return (
            joinedload(ParentSupply.category),
            selectinload(ParentSupply.supplies),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, parent_supply_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[ParentSupply]:
        """Get a parent supply by its id."""
        with self._get_session() as session:
            statement = select(ParentSupply).where(
                ParentSupply.parent_supply_id == parent_supply_id
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_code_command(
        self, code: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[ParentSupply]:
        """Get a parent supply by its code."""
        with self._get_session() as session:
            statement = select(ParentSupply).where(ParentSupply.code == code)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[ParentSupply]:
        """Get all parent supplies."""
        with self._get_session() as session:
            statement = select(ParentSupply)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_category_command(
        self, category_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[ParentSupply]:
        """Get all parent supplies for a specific category."""
        with self._get_session() as session:
            statement = select(ParentSupply).where(ParentSupply.category_id == category_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def search_command(
        self, search_term: str, active_only: bool = True, load_details: bool = False
    ) -> List[ParentSupply]:
        """Search parent supplies by code, name, or description."""
        with self._get_session() as session:
            statement = select(ParentSupply).where(
                or_(
                    ParentSupply.code.ilike(f"%{search_term}%"),
                    ParentSupply.name.ilike(f"%{search_term}%"),
                    ParentSupply.description.ilike(f"%{search_term}%"),
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
