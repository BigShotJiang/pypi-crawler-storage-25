from typing import List, Optional
from uuid import UUID

from sqlalchemy import or_
from sqlalchemy.orm import selectinload
from sqlmodel import select

from healthdatalayer.models.inventory.supplier import Supplier
from healthdatalayer.repositories.base_repository import BaseRepository


class SupplierRepository(BaseRepository[Supplier]):
    def __init__(self, tenant: str):
        """Initialize the repository for Supplier entities."""
        super().__init__(tenant, Supplier)

    def _detail_options(self):
        return (
            selectinload(Supplier.purchase_orders),
            selectinload(Supplier.lots),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, supplier_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Supplier]:
        """Get a supplier by its id."""
        with self._get_session() as session:
            statement = select(Supplier).where(Supplier.supplier_id == supplier_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_identification_command(
        self, identification: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[Supplier]:
        """Get a supplier by its identification."""
        with self._get_session() as session:
            statement = select(Supplier).where(Supplier.identification == identification)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_name_command(
        self, name: str, load_details: bool = False, active_only: bool = True
    ) -> Optional[Supplier]:
        """Get a supplier by its name."""
        with self._get_session() as session:
            statement = select(Supplier).where(Supplier.name == name)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Supplier]:
        """Get all suppliers."""
        with self._get_session() as session:
            statement = select(Supplier)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def search_command(
        self, search_term: str, active_only: bool = True, load_details: bool = False
    ) -> List[Supplier]:
        """Search suppliers by business fields."""
        with self._get_session() as session:
            statement = select(Supplier).where(
                or_(
                    Supplier.name.ilike(f"%{search_term}%"),
                    Supplier.identification.ilike(f"%{search_term}%"),
                    Supplier.contact_name.ilike(f"%{search_term}%"),
                    Supplier.email.ilike(f"%{search_term}%"),
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
