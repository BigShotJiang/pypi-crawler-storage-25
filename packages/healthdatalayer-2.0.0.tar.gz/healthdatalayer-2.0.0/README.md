# health-data-layer

## Resume
Centralized data layer that defines models, repositories, and database interactions for the system.

## Database Versioning (Alembic)
This project uses Alembic to manage database schema changes.

Whenever a model or schema modification is made, follow these steps:

```bash
alembic revision --autogenerate -m "describe change"
alembic upgrade head