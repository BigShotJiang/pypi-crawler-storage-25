"""
bacondecomp.py — Parallel Bacon Decomposition using PyFixest
=============================================================
Implements Goodman-Bacon (2019) decomposition of a TWFE DD estimator
into all constituent 2×2 DD comparisons, with multi-core parallelism.

Parallelisation architecture (following pybdiff patterns):
  Layer 1 — Data slimming: only needed columns, DataFrame → ndarray for pickle
  Layer 2 — Pre-compute shared quantities on main process (FWL residuals, etc.)
  Layer 3 — Task dispatch: joblib Parallel + loky backend + tqdm progress
  Layer 4 — Top-level worker functions (_one_dyad_*) for pickle compatibility

Reference:
    Goodman-Bacon, Andrew. (2019). "Difference-in-Differences with Variation
    in Treatment Timing." NBER Working Paper No. 25018.

License: MIT
"""

import warnings
import time as _time
import numpy as np
import pandas as pd
import pyfixest as pf
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Optional, List, Dict, Tuple

try:
    from joblib import Parallel, delayed
    HAS_JOBLIB = True
except ImportError:
    HAS_JOBLIB = False

try:
    from tqdm.auto import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Result container                                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

@dataclass
class BaconResult:
    """Container for Bacon decomposition results."""
    dd_estimate: float
    two_by_two: pd.DataFrame
    summary: pd.DataFrame
    beta: float
    se: float
    n_obs: int
    n_groups: int
    has_controls: bool = False
    ddetail: bool = False
    has_always: bool = False
    has_never: bool = False
    within_estimate: Optional[float] = None
    within_weight: Optional[float] = None
    elapsed_seconds: float = 0.0
    n_dyads: int = 0

    def __repr__(self):
        lines = [
            "=" * 65,
            "Bacon Decomposition of Two-Way Fixed Effects DD",
            "=" * 65,
            f"Overall DD estimate:  {self.dd_estimate: .6f}",
            f"Std. error:           {self.se: .6f}",
            f"N observations:       {self.n_obs}",
            f"N timing groups:      {self.n_groups}",
        ]
        if self.has_always:
            lines.append("  (includes an always-treated group)")
        if self.has_never:
            lines.append("  (includes a never-treated group)")
        lines += [
            f"N dyad comparisons:   {self.n_dyads}",
            f"Elapsed time:         {self.elapsed_seconds:.2f}s",
            "",
            "-" * 65,
            "Summary by Comparison Type",
            "-" * 65,
        ]
        for _, row in self.summary.iterrows():
            lines.append(
                f"  {row['type']:<35s}  Beta={row['avg_estimate']:>10.6f}"
                f"  Weight={row['total_weight']:>8.6f}"
            )
        lines.append("-" * 65)
        check = (self.two_by_two["weight"] * self.two_by_two["estimate"]).sum()
        lines.append(f"Weighted sum check:   {check: .6f}")
        lines.append("=" * 65)
        return "\n".join(lines)


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Layer 1 — Validation & data preparation                                ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def _validate_panel(df, unit, time, y, tr, x=None):
    """Validate strongly balanced panel, binary monotone treatment."""
    cols = [unit, time, y, tr] + (x or [])
    for c in cols:
        if c not in df.columns:
            raise ValueError(f"Column '{c}' not found.")
    df = df.dropna(subset=cols).copy()
    df[tr] = df[tr].astype(int)

    # Strongly balanced
    counts = df.groupby(unit)[time].nunique()
    if not (counts == df[time].nunique()).all():
        raise ValueError("Panel must be strongly balanced.")

    # Binary {0,1}
    if not set(df[tr].unique()).issubset({0, 1}):
        raise ValueError(f"Treatment '{tr}' must be binary 0/1.")

    # Weakly increasing
    df = df.sort_values([unit, time])
    diffs = df.groupby(unit)[tr].diff().dropna()
    if (diffs < 0).any():
        raise ValueError(f"Treatment '{tr}' must weakly increase (no reversals).")

    return df


def _identify_groups(df, unit, time, tr):
    """Identify timing groups -> adds '_group' column. Returns (df, info_dict)."""
    df = df.sort_values([unit, time]).copy()
    df["_tr_lag"] = df.groupby(unit)[tr].shift(1)
    df["_jump"] = ((df[tr] == 1) & (df["_tr_lag"] == 0)).astype(int)

    onset = df.loc[df["_jump"] == 1, [unit, time]].rename(columns={time: "_onset"})
    df = df.merge(onset, on=unit, how="left")

    first_tr = df.groupby(unit)[tr].first()
    last_tr = df.groupby(unit)[tr].last()
    always_units = set(first_tr[(first_tr == 1) & (last_tr == 1)].index)
    never_units = set(first_tr[(first_tr == 0) & (last_tr == 0)].index)

    timing_mask = ~df[unit].isin(always_units | never_units)
    onset_vals = sorted(df.loc[timing_mask, "_onset"].dropna().unique())
    onset_to_grp = {v: i + 1 for i, v in enumerate(onset_vals)}
    labels = {i + 1: str(int(v)) for i, v in enumerate(onset_vals)}

    gid = len(onset_vals)
    always_grp = never_grp = None
    if always_units:
        gid += 1; always_grp = gid; labels[gid] = "Always"
    if never_units:
        gid += 1; never_grp = gid; labels[gid] = "Never"

    def _assign(row):
        u = row[unit]
        if u in always_units: return always_grp
        if u in never_units:  return never_grp
        o = row["_onset"]
        return onset_to_grp.get(o, np.nan) if not pd.isna(o) else np.nan

    df["_group"] = df.apply(_assign, axis=1)
    df = df.dropna(subset=["_group"])
    df["_group"] = df["_group"].astype(int)
    df.drop(columns=["_tr_lag", "_jump", "_onset"], inplace=True, errors="ignore")

    info = dict(
        n_total_groups=gid, labels=labels,
        always_group=always_grp, never_group=never_grp,
        has_always=bool(always_units), has_never=bool(never_units),
        alwaysnever=int(bool(always_units)) + int(bool(never_units)),
    )
    return df, info


def _slim_data(df, unit, time, y, tr, extra_cols=None):
    """
    Layer-1 data slimming: keep only needed columns, factorize categoricals,
    return (values_ndarray, column_list, col_dtype_dict) for cheap pickling.
    """
    keep = [unit, time, y, tr, "_group"]
    if extra_cols:
        keep += [c for c in extra_cols if c not in keep]
    keep = [c for c in keep if c in df.columns]
    slim = df[keep].copy()

    # Factorize object/string columns -> int (cheaper to pickle)
    dtypes = {}
    for c in slim.columns:
        if slim[c].dtype == object:
            codes, uniques = pd.factorize(slim[c])
            slim[c] = codes
            dtypes[c] = ("factorized", uniques)
        else:
            dtypes[c] = ("numeric", None)

    return slim.values, list(slim.columns), dtypes


def _reconstruct_df(values, columns, dtypes):
    """Reconstruct a DataFrame from slimmed (values, columns, dtypes)."""
    df = pd.DataFrame(values, columns=columns)
    for c, (kind, uniques) in dtypes.items():
        if kind == "factorized" and c in df.columns:
            df[c] = uniques[df[c].astype(int)]
    return df


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Low-level regression helpers                                            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def _feols_fe(df_sub, y_col, x_cols, unit, time, weights=None):
    """Run feols: y ~ x_cols | unit + time.  Returns model or None."""
    rhs = " + ".join(x_cols) if x_cols else "1"
    fml = f"{y_col} ~ {rhs} | {unit} + {time}"
    try:
        return pf.feols(fml, data=df_sub, vcov="iid",
                        weights=weights if weights else None)
    except Exception:
        return None


def _dyad_vd(sub, tr, unit, time, weights=None):
    """Population variance of treatment FE-residual in a dyad subsample."""
    fit = _feols_fe(sub, tr, [], unit, time, weights)
    if fit is None:
        return 0.0
    r = fit.resid()
    return float(np.var(r, ddof=0)) if len(r) > 1 else 0.0


def _dyad_beta(sub, y, tr, unit, time, x=None, weights=None):
    """2x2 DD coefficient from subsample."""
    covs = [tr] + (x or [])
    fit = _feols_fe(sub, y, covs, unit, time, weights)
    if fit is None:
        return np.nan
    try:
        return float(fit.coef()[tr])
    except (KeyError, IndexError):
        return np.nan


def _classify_type(it_label, jt_label, detail_direction=None):
    """Determine comparison-type string."""
    it_sp = it_label in ("Always", "Never")
    jt_sp = jt_label in ("Always", "Never")
    if not it_sp and not jt_sp:
        if detail_direction == "late_v_early":
            return "Late vs Early"
        elif detail_direction == "early_v_late":
            return "Early vs Late"
        return "Timing groups"
    if "Always" in (it_label, jt_label) and "Never" not in (it_label, jt_label):
        return "Always vs timing"
    if "Never" in (it_label, jt_label) and "Always" not in (it_label, jt_label):
        return "Never vs timing"
    return "Always vs never"


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Layer 4 — Top-level worker functions (must be picklable by loky)        ║
# ║                                                                          ║
# ║  DESIGN NOTE: These are module-level functions (not lambdas, not nested  ║
# ║  closures) because loky serialises them via pickle, which requires       ║
# ║  functions to be importable by module path.                              ║
# ║                                                                          ║
# ║  Each worker receives the slimmed numpy array, reconstructs only the     ║
# ║  subsample it needs, runs feols, and returns a lightweight list of       ║
# ║  result dicts.  No shared mutable state.                                 ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def _one_dyad_nocontrol(
    data_values, data_columns, data_dtypes,
    it, jt, it_label, jt_label,
    is_always_never, total_n,
    unit, time, y, tr, weights,
):
    """
    Worker for Branch #1 (no controls, no ddetail).
    Returns list of result dicts (0 or 1 element).
    """
    df = _reconstruct_df(data_values, data_columns, data_dtypes)
    mask = df["_group"].isin([it, jt])
    sub = df.loc[mask].copy()
    w_arr = df[weights].values if weights and weights in df.columns else np.ones(len(df))
    share = w_arr[mask.values].sum() / w_arr.sum()

    if is_always_never:
        return []

    vd = _dyad_vd(sub, tr, unit, time, weights)
    w = share ** 2 * vd
    if w <= 0:
        return []

    beta = _dyad_beta(sub, y, tr, unit, time, weights=weights)
    if np.isnan(beta):
        return []

    ctype = _classify_type(it_label, jt_label)
    return [dict(treated=jt_label, control=it_label, estimate=beta,
                 weight_raw=w, type=ctype)]


def _one_dyad_ddetail(
    data_values, data_columns, data_dtypes,
    it, jt, it_label, jt_label,
    is_always_never, total_n,
    unit, time, y, tr, weights,
):
    """
    Worker for Branch #2 (no controls, ddetail=True).
    Returns list of result dicts (0, 1, or 2 elements).
    """
    df = _reconstruct_df(data_values, data_columns, data_dtypes)
    results = []
    w_arr = df[weights].values if weights and weights in df.columns else np.ones(len(df))
    w_total = w_arr.sum()

    if is_always_never:
        return results

    # Block 1: jt treated, it control -> restrict to it's pre-period
    pre_times = df.loc[(df["_group"] == it) & (df[tr] == 0), time]
    if len(pre_times) > 0:
        tmin, tmax = pre_times.min(), pre_times.max()
        mask1 = df["_group"].isin([it, jt]) & df[time].between(tmin, tmax)
        sub1 = df.loc[mask1].copy()
        share1 = w_arr[mask1.values].sum() / w_total
        if share1 > 0:
            vd1 = _dyad_vd(sub1, tr, unit, time, weights)
            w1 = share1 ** 2 * vd1
            if w1 > 0:
                beta1 = _dyad_beta(sub1, y, tr, unit, time, weights=weights)
                if not np.isnan(beta1):
                    ctype1 = _classify_type(it_label, jt_label, "early_v_late")
                    results.append(dict(treated=jt_label, control=it_label,
                                        estimate=beta1, weight_raw=w1, type=ctype1))

    # Block 2: it treated, jt control -> restrict to jt's post-period
    if it_label not in ("Always", "Never"):
        post_times = df.loc[(df["_group"] == jt) & (df[tr] == 1), time]
        if len(post_times) > 0:
            tmin2, tmax2 = post_times.min(), post_times.max()
            mask2 = df["_group"].isin([it, jt]) & df[time].between(tmin2, tmax2)
            sub2 = df.loc[mask2].copy()
            share2 = w_arr[mask2.values].sum() / w_total
            if share2 > 0:
                vd2 = _dyad_vd(sub2, tr, unit, time, weights)
                w2 = share2 ** 2 * vd2
                if w2 > 0:
                    beta2 = _dyad_beta(sub2, y, tr, unit, time, weights=weights)
                    if not np.isnan(beta2):
                        ctype2 = _classify_type(it_label, jt_label, "late_v_early")
                        results.append(dict(treated=it_label, control=jt_label,
                                            estimate=beta2, weight_raw=w2, type=ctype2))

    return results


def _one_dyad_controlled(
    data_values, data_columns, data_dtypes,
    it, jt, it_label, jt_label,
    is_always_never, total_n,
    unit, time, y, tr, weights,
    gm_x_cols, gm_p_col,
):
    """
    Worker for Branch #3 (with controls, FWL decomposition).
    Returns list of result dicts (0 or 1 element).
    """
    from numpy.linalg import lstsq as np_lstsq

    df = _reconstruct_df(data_values, data_columns, data_dtypes)
    mask = df["_group"].isin([it, jt])
    sub = df.loc[mask].copy()
    w_arr = df[weights].values if weights and weights in df.columns else np.ones(len(df))
    share = w_arr[mask.values].sum() / w_arr.sum()

    if not is_always_never:
        vd = _dyad_vd(sub, tr, unit, time, weights)

        # R-squared from regressing Dtilde on FE-residualized group-mean X's
        # Dtilde = within-dyad FE residual of tr (no X), matching Stata line 526-528
        fit_dt = _feols_fe(sub, tr, [], unit, time, weights)
        Dt = fit_dt.resid() if fit_dt is not None else np.zeros(len(sub))
        xx_resids = []
        for gv in gm_x_cols:
            fit_xx = _feols_fe(sub, gv, [], unit, time, weights)
            xx_resids.append(fit_xx.resid() if fit_xx else np.zeros(len(sub)))

        if xx_resids:
            X_c = np.column_stack([np.ones(len(Dt))] + xx_resids)
            coefs, _, _, _ = np_lstsq(X_c, Dt, rcond=None)
            pgjtilde = X_c @ coefs
            ss_res = np.sum((Dt - pgjtilde) ** 2)
            ss_tot = np.sum((Dt - Dt.mean()) ** 2)
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
        else:
            pgjtilde = Dt.copy()
            r2 = 0.0

        fit_pt = _feols_fe(sub, gm_p_col, [], unit, time, weights)
        ptilde = fit_pt.resid() if fit_pt else np.zeros(len(sub))
        dp = pgjtilde - ptilde
        v_dp = float(np.var(dp, ddof=0)) if len(dp) > 1 else 0.0

        w = share ** 2 * ((1 - r2) * vd + v_dp)
        if w <= 0:
            return []

        beta_d = _dyad_beta(sub, y, tr, unit, time, x=gm_x_cols, weights=weights)
        sub["_dp"] = dp
        beta_b = _dyad_beta(sub, y, "_dp", unit, time, weights=weights)

        denom = (1 - r2) * vd + v_dp
        beta = ((1 - r2) * vd * beta_d + v_dp * beta_b) / denom if denom > 0 else np.nan

    else:
        # Always-vs-never
        fit_pt = _feols_fe(sub, gm_p_col, [], unit, time, weights)
        if fit_pt is None:
            return []
        ptilde = fit_pt.resid()
        v_b = float(np.var(ptilde, ddof=0))
        w = share ** 2 * v_b
        if w <= 0:
            return []
        fit_a = _feols_fe(sub, y, [gm_p_col], unit, time, weights)
        if fit_a is None:
            return []
        try:
            beta = -float(fit_a.coef()[gm_p_col])
        except (KeyError, IndexError):
            return []

    if np.isnan(beta):
        return []

    ctype = _classify_type(it_label, jt_label)
    return [dict(treated=jt_label, control=it_label, estimate=beta,
                 weight_raw=w, type=ctype)]


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Layer 3 — Task generation & parallel dispatch                           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def _generate_dyad_pairs(groups, always_grp, never_grp, alwaysnever):
    """Enumerate all (it, jt) pairs with metadata."""
    pairs = []
    for it in groups:
        for jt in groups:
            if jt >= it:
                continue
            is_an = (alwaysnever > 1 and {it, jt} == {always_grp, never_grp})
            pairs.append((it, jt, is_an))
    return pairs


def _run_chunk(worker_fn, chunk):
    """
    Run a chunk of tasks sequentially within one worker process.
    This amortises the per-process startup cost over multiple dyads.
    Must be a top-level function for pickle compatibility.
    """
    out = []
    for task_args in chunk:
        out.extend(worker_fn(*task_args))
    return out


# Minimum number of dyads to justify spawning processes.
# Below this, loky startup + pickle overhead exceeds computation time.
# Minimum dyads to justify process pool.  loky startup can cost 2-40s
# depending on platform; with feols calls at ~0.05-0.1s per dyad,
# need many tasks to amortise.  Gains are strongest at K > ~15 groups.
_PARALLEL_THRESHOLD = 100

# Target tasks per worker chunk.  Larger chunks = less dispatch overhead,
# but coarser load balancing.  8-16 is a good sweet spot for feols dyads.
_CHUNK_SIZE = 10


def _dispatch_parallel(worker_fn, tasks, n_jobs, verbose, desc="Dyad comparisons"):
    """
    Dispatch tasks via joblib Parallel + loky, with optional tqdm progress.

    Architecture notes:
      - Uses process pool (loky) to bypass Python's GIL — each feols call
        is CPU-bound linear algebra, so threads would not help.
      - Tasks are chunked: instead of one process per dyad, we batch
        ~10 dyads per worker invocation.  This amortises process startup
        and pickle costs (which dominate when individual tasks are fast).
      - Auto-fallback: if n_dyads < threshold, runs sequentially regardless
        of n_jobs, since overhead would exceed savings.

    Falls back to sequential if joblib unavailable or n_jobs == 1.
    """
    n_tasks = len(tasks)

    # ── Auto-fallback for small task counts ──────────────────────────────────
    if n_tasks < _PARALLEL_THRESHOLD and n_jobs != 1:
        if verbose:
            print(f"  {n_tasks} dyads < threshold {_PARALLEL_THRESHOLD}: "
                  f"running sequentially (overhead > savings)")
        n_jobs = 1

    # ── Sequential path ──────────────────────────────────────────────────────
    if n_jobs == 1 or not HAS_JOBLIB:
        results = []
        iterator = tasks
        if verbose and HAS_TQDM:
            iterator = tqdm(tasks, total=n_tasks, desc=desc)
        elif verbose:
            print(f"  Processing {n_tasks} dyads sequentially...")
        for t in iterator:
            results.extend(worker_fn(*t))
        return results

    # ── Parallel path with chunking ──────────────────────────────────────────
    # Split tasks into chunks to reduce per-dispatch overhead
    chunks = [tasks[i:i + _CHUNK_SIZE]
              for i in range(0, n_tasks, _CHUNK_SIZE)]
    n_chunks = len(chunks)

    if verbose:
        actual_jobs = n_jobs if n_jobs > 0 else "all CPUs"
        print(f"  Dispatching {n_tasks} dyads in {n_chunks} chunks "
              f"to {actual_jobs} workers (loky)...")

    def _gen():
        for chunk in chunks:
            yield delayed(_run_chunk)(worker_fn, chunk)

    raw = Parallel(n_jobs=n_jobs, backend="loky")(
        tqdm(_gen(), total=n_chunks, desc=desc,
             disable=not (verbose and HAS_TQDM))
    )
    # raw is list-of-lists; flatten
    results = []
    for batch in raw:
        results.extend(batch)
    return results


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Main entry point                                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def bacondecomp(
    df: pd.DataFrame,
    y: str,
    tr: str,
    unit: str,
    time: str,
    x: Optional[List[str]] = None,
    weights: Optional[str] = None,
    ddetail: bool = False,
    n_jobs: int = 1,
    verbose: bool = True,
) -> BaconResult:
    """
    Bacon Decomposition of a two-way fixed-effects DD estimator.

    Parameters
    ----------
    df : pd.DataFrame
        Strongly balanced panel dataset.
    y : str
        Outcome variable.
    tr : str
        Binary treatment (0/1, weakly increasing over time).
    unit : str
        Panel unit identifier.
    time : str
        Time variable.
    x : list of str, optional
        Control variables -> triggers controlled decomposition (Branch #3)
        with within component.
    weights : str, optional
        Analytic weight variable.
    ddetail : bool, default False
        If True and no controls, split timing-group comparisons into
        "Late vs Early" / "Early vs Late" (Branch #2).
    n_jobs : int, default 1
        Number of parallel workers.  1 = sequential, -1 = all cores.
        Requires ``pip install joblib``.  Uses loky (process pool) backend
        to bypass the GIL.
    verbose : bool, default True
        Print progress and results.

    Returns
    -------
    BaconResult

    Examples
    --------
    >>> res = bacondecomp(panel, "y", "treat", "unit", "time", n_jobs=-1)
    >>> res.two_by_two   # DataFrame of every 2x2 comparison
    >>> res.summary      # aggregated by comparison type
    >>> bacon_plot(res)  # scatter plot
    """
    t0 = _time.perf_counter()
    has_controls = x is not None and len(x) > 0

    # ── 0. Validate & identify groups ────────────────────────────────────────
    data = _validate_panel(df, unit, time, y, tr, x if has_controls else None)
    data, ginfo = _identify_groups(data, unit, time, tr)
    labels = ginfo["labels"]
    n_groups = ginfo["n_total_groups"]
    always_grp = ginfo["always_group"]
    never_grp = ginfo["never_group"]
    alwaysnever = ginfo["alwaysnever"]

    if verbose:
        print(f"Computing decomposition across {n_groups} timing groups")
        parts = []
        if ginfo["has_always"]:  parts.append("an always-treated group")
        if ginfo["has_never"]:   parts.append("a never-treated group")
        if parts:
            print(f"  including {' and '.join(parts)}")

    # ── 1. Overall TWFE estimate (sequential — single regression) ────────────
    covars_all = [tr] + (x if has_controls else [])
    fit_overall = _feols_fe(data, y, covars_all, unit, time, weights)
    dd_est = float(fit_overall.coef()[tr])
    dd_se = float(fit_overall.se()[tr])
    n_obs = int(fit_overall._N)

    # ── 2. Layer 2: Pre-compute shared quantities (main process only) ────────
    groups = sorted(data["_group"].unique())
    total_n = len(data)

    extra_cols = []
    gm_x_cols = []
    gm_p_col = None

    if has_controls:
        # Frisch-Waugh-Lovell: residualise treatment from controls + FE
        x_rhs = " + ".join(x)
        fit_fwl = pf.feols(f"{tr} ~ {x_rhs} | {unit} + {time}", data=data,
                           vcov="iid", weights=weights if weights else None)
        data["_d_resid"] = fit_fwl.resid()
        data["_p_hat"] = fit_fwl.predict()

        # Group x time means (needed for within-dyad FWL correction)
        gt = ["_group", time]
        for v in x + ["_p_hat"]:
            gn = f"_gm_{v}"
            data[gn] = data.groupby(gt)[v].transform("mean")

        gm_x_cols = [f"_gm_{v}" for v in x]
        gm_p_col = "_gm__p_hat"
        extra_cols = ["_d_resid", "_p_hat"] + gm_x_cols + [gm_p_col]

    # ── Layer 1: data slimming ───────────────────────────────────────────────
    # Include weights column so workers can compute weighted share
    if weights and weights not in extra_cols:
        extra_cols = extra_cols + [weights]
    # Strip DataFrame down to needed columns -> numpy array for cheap pickle
    slim_vals, slim_cols, slim_dtypes = _slim_data(
        data, unit, time, y, tr, extra_cols=extra_cols
    )

    if verbose:
        raw_mb = df.memory_usage(deep=True).sum() / 1e6
        slim_mb = slim_vals.nbytes / 1e6
        print(f"  Data slimmed: {raw_mb:.1f} MB -> {slim_mb:.1f} MB "
              f"({len(slim_cols)} cols)")

    # ── 3. Build task list ───────────────────────────────────────────────────
    pairs = _generate_dyad_pairs(groups, always_grp, never_grp, alwaysnever)
    n_dyads = len(pairs)

    if verbose:
        branch = "controlled" if has_controls else ("ddetail" if ddetail else "basic")
        print(f"  Branch: {branch} | {n_dyads} dyad pairs | n_jobs={n_jobs}")

    # ── Layer 3: dispatch ────────────────────────────────────────────────────
    if not has_controls and not ddetail:
        # Branch #1: basic uncontrolled
        tasks = [
            (slim_vals, slim_cols, slim_dtypes,
             it, jt, labels[it], labels[jt],
             is_an, total_n, unit, time, y, tr, weights)
            for it, jt, is_an in pairs
        ]
        results = _dispatch_parallel(
            _one_dyad_nocontrol, tasks, n_jobs, verbose, "Branch1"
        )

    elif not has_controls and ddetail:
        # Branch #2: uncontrolled with early/late detail
        tasks = [
            (slim_vals, slim_cols, slim_dtypes,
             it, jt, labels[it], labels[jt],
             is_an, total_n, unit, time, y, tr, weights)
            for it, jt, is_an in pairs
        ]
        results = _dispatch_parallel(
            _one_dyad_ddetail, tasks, n_jobs, verbose, "Branch2"
        )

    else:
        # Branch #3: controlled (FWL)
        tasks = [
            (slim_vals, slim_cols, slim_dtypes,
             it, jt, labels[it], labels[jt],
             is_an, total_n, unit, time, y, tr, weights,
             gm_x_cols, gm_p_col)
            for it, jt, is_an in pairs
        ]
        results = _dispatch_parallel(
            _one_dyad_controlled, tasks, n_jobs, verbose, "Branch3"
        )

        # Within component: full-dataset regression (stays sequential)
        data["_gt"] = data["_group"].astype(str) + "_" + data[time].astype(str)
        gt_dums = pd.get_dummies(data["_gt"], prefix="_gt", dtype=int)
        gt_cols = list(gt_dums.columns[1:])
        data = pd.concat([data, gt_dums[gt_cols]], axis=1)
        try:
            fml_w = f"{y} ~ {' + '.join(gt_cols)} + _p_hat | {unit}"
            fit_w = pf.feols(fml_w, data=data, vcov="iid",
                             weights=weights if weights else None)
            w_beta = -float(fit_w.coef()["_p_hat"])
        except Exception:
            w_beta = 0.0
        try:
            fml_pw = f"_p_hat ~ {' + '.join(gt_cols)} | {unit}"
            fit_pw = pf.feols(fml_pw, data=data, vcov="iid",
                              weights=weights if weights else None)
            w_var = float(np.var(fit_pw.resid(), ddof=0))
        except Exception:
            w_var = 0.0

        results.append(dict(treated="Within", control="", estimate=w_beta,
                            weight_raw=w_var, type="Within"))
        for c in gt_cols:
            data.drop(columns=c, inplace=True, errors="ignore")

    # ── 4. Assemble ──────────────────────────────────────────────────────────
    if not results:
        raise RuntimeError("No valid 2x2 comparisons produced.")

    df_res = pd.DataFrame(results)
    total_w = df_res["weight_raw"].sum()
    df_res["weight"] = df_res["weight_raw"] / total_w

    # Summary by type
    summ = []
    for ct, grp in df_res.groupby("type"):
        summ.append(dict(type=ct,
                         avg_estimate=np.average(grp["estimate"],
                                                 weights=grp["weight"]),
                         total_weight=grp["weight"].sum()))
    df_summ = pd.DataFrame(summ)
    order = ["Timing groups", "Late vs Early", "Early vs Late",
             "Always vs timing", "Never vs timing", "Always vs never", "Within"]
    df_summ["_o"] = df_summ["type"].map(
        {v: i for i, v in enumerate(order)}
    ).fillna(99)
    df_summ = df_summ.sort_values("_o").drop(columns="_o").reset_index(drop=True)

    two_by_two = df_res[["treated", "control", "estimate", "weight", "type"]
                        ].reset_index(drop=True)

    within_est = within_wt = None
    if has_controls:
        wr = df_res[df_res["type"] == "Within"]
        if len(wr):
            within_est = float(wr["estimate"].iloc[0])
            within_wt = float(wr["weight"].iloc[0])

    elapsed = _time.perf_counter() - t0

    result = BaconResult(
        dd_estimate=dd_est, two_by_two=two_by_two, summary=df_summ,
        beta=dd_est, se=dd_se, n_obs=n_obs, n_groups=n_groups,
        has_controls=has_controls, ddetail=ddetail,
        has_always=ginfo["has_always"], has_never=ginfo["has_never"],
        within_estimate=within_est, within_weight=within_wt,
        elapsed_seconds=elapsed, n_dyads=n_dyads,
    )
    if verbose:
        print(result)
    return result


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Plotting                                                                ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def bacon_plot(result, figsize=(8, 5), show_dd_line=True,
               title="Bacon Decomposition", ax=None):
    """Scatter: 2x2 DD estimates vs. weights, by comparison type."""
    df = result.two_by_two[result.two_by_two["type"] != "Within"].copy()
    styles = {
        "Timing groups":    dict(marker="o", s=60, facecolors="none",
                                 edgecolors="black"),
        "Late vs Early":    dict(marker="o", s=60, facecolors="none",
                                 edgecolors="black"),
        "Early vs Late":    dict(marker="^", color="gray", s=60),
        "Always vs timing": dict(marker="^", color="gray", s=60),
        "Never vs timing":  dict(marker="x", color="black", s=60),
        "Always vs never":  dict(marker="D", s=40, facecolors="none",
                                 edgecolors="black"),
    }
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    for ct in df["type"].unique():
        sub = df[df["type"] == ct]
        ax.scatter(sub["weight"], sub["estimate"], label=ct,
                   **styles.get(ct, dict(marker="o", color="blue", s=50)))
    if show_dd_line:
        ax.axhline(result.dd_estimate, color="black", lw=1.5,
                    label=f"DD = {result.dd_estimate:.4f}")
    ax.set_xlabel("Weight")
    ax.set_ylabel("2x2 DD Estimate")
    ax.set_title(title)
    ax.legend(fontsize=8)
    ax.grid(False)
    fig.tight_layout()
    return fig


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Convenience Stata-like interface                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def bacondecomp_stata(df, formula, unit, time, weights=None,
                      ddetail=False, n_jobs=1, verbose=True):
    """
    Stata syntax:
        bacondecomp_stata(df, "y tr [x1 x2]", unit="i", time="t")
    """
    tokens = formula.strip().split()
    y, tr = tokens[0], tokens[1]
    x = tokens[2:] or None
    return bacondecomp(df, y=y, tr=tr, unit=unit, time=time, x=x,
                       weights=weights, ddetail=ddetail,
                       n_jobs=n_jobs, verbose=verbose)


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  Demo & benchmark                                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

if __name__ == "__main__":

    def _make_panel(n_units=40, n_periods=10, n_timing_groups=2,
                    frac_always=0.25, frac_never=0.25, true_beta=2.0,
                    seed=42):
        """Generate staggered DID panel for testing."""
        rng = np.random.default_rng(seed)
        units = np.repeat(np.arange(1, n_units + 1), n_periods)
        times = np.tile(np.arange(1, n_periods + 1), n_units)

        n_always = int(n_units * frac_always)
        n_never = int(n_units * frac_never)
        n_switch = n_units - n_always - n_never
        group_size = max(1, n_switch // n_timing_groups)

        onsets = np.linspace(2, n_periods - 1, n_timing_groups, dtype=int)
        onset_map = {}
        idx = 1
        for g, onset in enumerate(onsets):
            sz = (group_size if g < n_timing_groups - 1
                  else n_switch - group_size * (n_timing_groups - 1))
            for _ in range(sz):
                onset_map[idx] = int(onset)
                idx += 1
        for _ in range(n_always):
            onset_map[idx] = 0; idx += 1
        for _ in range(n_never):
            onset_map[idx] = 999; idx += 1

        treatment = np.array([
            int(t >= onset_map[u]) if onset_map[u] not in (0, 999)
            else (1 if onset_map[u] == 0 else 0)
            for u, t in zip(units, times)
        ])

        alpha = rng.normal(0, 1, n_units + 1)
        delta = 0.5 * np.arange(n_periods + 1)
        x1 = rng.normal(0, 1, len(units))
        y = np.array([
            alpha[u] + delta[t] + true_beta * d + 0.3 * xv + rng.normal(0, 0.5)
            for u, t, d, xv in zip(units, times, treatment, x1)
        ])

        return pd.DataFrame(dict(unit=units, time=times, y=y,
                                  treat=treatment, x1=x1))

    # ── Correctness checks ───────────────────────────────────────────────────
    panel = _make_panel(n_units=40, n_timing_groups=2)

    print("=" * 70)
    print("DEMO 1: Basic (sequential)")
    print("=" * 70)
    r1 = bacondecomp(panel, "y", "treat", "unit", "time", n_jobs=1)
    print()

    print("=" * 70)
    print("DEMO 2: ddetail (sequential)")
    print("=" * 70)
    r2 = bacondecomp(panel, "y", "treat", "unit", "time",
                     ddetail=True, n_jobs=1)
    print()

    print("=" * 70)
    print("DEMO 3: Controlled (sequential)")
    print("=" * 70)
    r3 = bacondecomp(panel, "y", "treat", "unit", "time",
                     x=["x1"], n_jobs=1)
    print()

    # ── Scaling benchmark: sequential vs parallel ────────────────────────────
    print("=" * 70)
    print("BENCHMARK: Sequential vs Parallel (n_jobs=-1)")
    print("=" * 70)

    for k, nu, np_ in [(4, 200, 20), (10, 500, 30), (15, 800, 30)]:
        panel_big = _make_panel(n_units=nu, n_periods=np_,
                                n_timing_groups=k,
                                frac_always=0.05, frac_never=0.05)

        print(f"\n--- K={k} groups, {nu} units x {np_} periods, "
              f"N={len(panel_big)} obs ---")

        r_seq = bacondecomp(panel_big, "y", "treat", "unit", "time",
                            n_jobs=1, verbose=False)
        print(f"  Sequential:  {r_seq.elapsed_seconds:6.2f}s | "
              f"{r_seq.n_dyads:3d} dyads | DD={r_seq.dd_estimate:.4f}")

        if HAS_JOBLIB:
            r_par = bacondecomp(panel_big, "y", "treat", "unit", "time",
                                n_jobs=-1, verbose=False)
            speedup = r_seq.elapsed_seconds / max(r_par.elapsed_seconds, 0.001)
            print(f"  Parallel:    {r_par.elapsed_seconds:6.2f}s | "
                  f"{r_par.n_dyads:3d} dyads | DD={r_par.dd_estimate:.4f}")
            print(f"  Speedup:     {speedup:.1f}x")

            # Verify identical results
            diff = abs(r_seq.dd_estimate - r_par.dd_estimate)
            assert diff < 1e-10, f"Results differ! {diff}"
            print(f"  Results match: OK (diff={diff:.2e})")
        else:
            print("  (joblib not installed — skipping parallel)")

    # Save plot
    fig = bacon_plot(r1, title="Bacon Decomposition (Branch 1)")
    fig.savefig("/home/claude/bacon_parallel_demo.png", dpi=150)
    print("\nPlot saved.")
