from .bacondecomp import bacondecomp, bacon_plot, bacondecomp_stata, BaconResult

__all__ = ["bacondecomp", "bacon_plot", "bacondecomp_stata", "BaconResult"]
__version__ = "0.1.0"
