"""
smoke_test.py — 验证 pybacondecomp 包安装正确，且三个分支结果与保存的 CSV 一致。
运行方式：
    python tests/smoke_test.py
"""
import sys
import pathlib
import pandas as pd
import numpy as np

ROOT = pathlib.Path(__file__).parent.parent
VERIFY = pathlib.Path(__file__).parent / "stata_verify"

sys.path.insert(0, str(ROOT / "src"))

from pybacondecomp import bacondecomp

ATOL = 1e-6   # 允许误差

def load_csv(name):
    return pd.read_csv(VERIFY / name)

def check_summary(branch_label, result, csv_name):
    expected = load_csv(csv_name).sort_values("type").reset_index(drop=True)
    got = result.summary.sort_values("type").reset_index(drop=True)

    assert set(expected["type"]) == set(got["type"]), \
        f"{branch_label}: comparison types mismatch\n  expected: {set(expected['type'])}\n  got:      {set(got['type'])}"

    for _, row in expected.iterrows():
        g = got.loc[got["type"] == row["type"]].iloc[0]
        for col in ["avg_estimate", "total_weight"]:
            diff = abs(g[col] - row[col])
            assert diff < ATOL, (
                f"{branch_label} [{row['type']}] {col}: "
                f"expected {row[col]:.8f}, got {g[col]:.8f}, diff={diff:.2e}"
            )
    print(f"  {branch_label} summary: OK")

def check_two_by_two(branch_label, result, csv_name):
    expected = (load_csv(csv_name)
                .sort_values(["treated", "control"])
                .reset_index(drop=True))
    got = (result.two_by_two
           .sort_values(["treated", "control"])
           .reset_index(drop=True))

    assert len(expected) == len(got), \
        f"{branch_label}: row count mismatch ({len(expected)} vs {len(got)})"

    for col in ["estimate", "weight"]:
        diffs = (expected[col].values - got[col].values)
        max_diff = np.abs(diffs).max()
        assert max_diff < ATOL, (
            f"{branch_label} two_by_two {col}: max diff={max_diff:.2e}"
        )
    print(f"  {branch_label} two_by_two: OK")


def main():
    panel = pd.read_stata(VERIFY / "castle_panel.dta")

    print("=" * 55)
    print("Branch 1 — basic (no controls, no ddetail)")
    print("=" * 55)
    r1 = bacondecomp(panel, "y", "treat", "state", "time", verbose=False)
    check_summary("B1", r1, "python_summary_b1_basic.csv")
    check_two_by_two("B1", r1, "python_results_b1_basic.csv")

    print("=" * 55)
    print("Branch 2 — ddetail")
    print("=" * 55)
    r2 = bacondecomp(panel, "y", "treat", "state", "time",
                     ddetail=True, verbose=False)
    check_summary("B2", r2, "python_summary_b2_ddetail.csv")
    check_two_by_two("B2", r2, "python_results_b2_ddetail.csv")

    print("=" * 55)
    print("Branch 3 — controlled (x_income, x_ur)")
    print("=" * 55)
    r3 = bacondecomp(panel, "y", "treat", "state", "time",
                     x=["x_income", "x_ur"], verbose=False)
    check_summary("B3", r3, "python_summary_b3_controlled.csv")
    check_two_by_two("B3", r3, "python_results_b3_controlled.csv")

    print()
    print("All smoke tests passed.")


if __name__ == "__main__":
    main()
