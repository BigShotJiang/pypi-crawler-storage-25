"""Parse and build WARP binary files.

Handles reading .warp FlatBuffer files uploaded by the Binary Ninja plugin,
extracting functions/types/symbols/targets, and serializing individual
entities back to standalone FlatBuffer bytes for DB storage.
"""

from __future__ import annotations

import hashlib
import os
import sys
import uuid
import zlib
from dataclasses import dataclass, field

import flatbuffers

# ---------------------------------------------------------------------------
# Ensure the generated FlatBuffer modules are importable.
# ---------------------------------------------------------------------------
_gen_dir = os.path.join(os.path.dirname(__file__), "gen_flatbuffers")
if _gen_dir not in sys.path:
    sys.path.insert(0, _gen_dir)

# -- Warp file-level --
import Warp.File as WarpFileMod
import Warp.FileHeader as FileHeaderMod
import Warp.Chunk as ChunkMod
import Warp.ChunkHeader as ChunkHeaderMod
from Warp.ChunkType import ChunkType
from Warp.CompressionType import CompressionType

# -- Signatures --
import SigBin.SignatureChunk as SigChunkMod
import SigBin.Function as SigFuncMod
import SigBin.Constraint as ConstraintMod
import SigBin.FunctionComment as CommentMod
import SigBin.FunctionVariable as FuncVarMod
import SigBin.FunctionGUID as FuncGUIDMod
import SigBin.ConstraintGUID as ConstraintGUIDMod

# -- Symbols --
import SymbolBin.Symbol as SymbolMod
from SymbolBin.SymbolClass import SymbolClass
from SymbolBin.SymbolModifiers import SymbolModifiers

# -- Targets --
import TargetBin.Target as TargetMod

# -- Types --
import TypeBin.TypeChunk as TypeChunkMod
import TypeBin.ComputedType as ComputedTypeMod
import TypeBin.Type as TypeMod
from TypeBin.TypeClass import TypeClass
import TypeBin.TypeGUID as TypeGUIDMod
import TypeBin.TypeMetadata as TypeMetaMod
import TypeBin.Void as VoidMod
import TypeBin.Boolean as BoolMod
import TypeBin.Integer as IntMod
import TypeBin.Character as CharMod
import TypeBin.Float as FloatMod
import TypeBin.Pointer as PtrMod
import TypeBin.Array as ArrayMod
import TypeBin.Structure as StructMod
import TypeBin.StructureMember as StructMemMod
import TypeBin.Enumeration as EnumMod
import TypeBin.EnumerationMember as EnumMemMod
import TypeBin.Union as UnionMod
import TypeBin.UnionMember as UnionMemMod
import TypeBin.Function as TypeFuncMod
import TypeBin.FunctionMember as FuncMemMod
import TypeBin.CallingConvention as CallingConvMod
import TypeBin.Referrer as ReferrerMod
import TypeBin.BitWidth as BitWidthMod
import TypeBin.BitShift as BitShiftMod
import TypeBin.BitOffset as BitOffsetMod
import TypeBin.UnsignedBitOffset as UBitOffMod
import TypeBin.RegisterLocation as RegLocMod
import TypeBin.StackLocation as StackLocMod
from TypeBin.LocationClass import LocationClass

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NAMESPACE_TYPEBIN = uuid.UUID("01929b90-72e6-73e6-9da1-2b6462e407a6")

#: Rust uses i64::MAX as sentinel for "unrelated" constraint offset.
UNRELATED_OFFSET = (1 << 63) - 1

FILE_VERSION = 1

# ---------------------------------------------------------------------------
# Helper: UUID-v5 from raw bytes
# ---------------------------------------------------------------------------


def _uuid5_bytes(namespace: uuid.UUID, data: bytes) -> uuid.UUID:
    h = hashlib.sha1(namespace.bytes + data, usedforsecurity=False).digest()[:16]
    ba = bytearray(h)
    ba[6] = (ba[6] & 0x0F) | 0x50  # version 5
    ba[8] = (ba[8] & 0x3F) | 0x80  # variant 1
    return uuid.UUID(bytes=bytes(ba))


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ParsedTarget:
    architecture: str | None = None
    platform: str | None = None


@dataclass
class ParsedSymbol:
    name: str = ""
    symbol_class: str = "Function"  # "Function" | "Data" | "Bare"
    modifier: str = "None"  # "None" | "Extern" | "Exported"


@dataclass
class ParsedConstraint:
    guid: uuid.UUID = field(default_factory=uuid.uuid4)
    byte_offset: int | None = None


@dataclass
class ParsedComment:
    byte_offset: int = 0
    text: str = ""


@dataclass
class ParsedFunction:
    guid: uuid.UUID = field(default_factory=uuid.uuid4)
    symbol: ParsedSymbol = field(default_factory=ParsedSymbol)
    constraints: list[ParsedConstraint] = field(default_factory=list)
    comments: list[ParsedComment] = field(default_factory=list)
    type_guid: uuid.UUID | None = None
    data: bytes = b""


@dataclass
class ParsedType:
    guid: uuid.UUID = field(default_factory=uuid.uuid4)
    name: str | None = None
    data: bytes = b""


@dataclass
class ParsedChunk:
    target: ParsedTarget = field(default_factory=ParsedTarget)
    functions: list[ParsedFunction] = field(default_factory=list)
    types: list[ParsedType] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Reading helpers
# ---------------------------------------------------------------------------

_SYMBOL_CLASS_MAP = {
    SymbolClass.Function: "Function",
    SymbolClass.Data: "Data",
    SymbolClass.Bare: "Bare",
}


def _decode_symbol_class(sc: int) -> str:
    return _SYMBOL_CLASS_MAP.get(sc, "Function")


def _decode_modifier(mod: int) -> str:
    if mod & SymbolModifiers.Exported:
        return "Exported"
    if mod & SymbolModifiers.External:
        return "Extern"
    return "None"


def _guid_bytes(guid_obj) -> bytes:
    """Get the 16 raw bytes from a FlatBuffer GUID struct."""
    return bytes(guid_obj.Value())


def _to_uuid(guid_obj) -> uuid.UUID:
    return uuid.UUID(bytes=_guid_bytes(guid_obj))


def _decode_string(val: bytes | None) -> str | None:
    if val is None:
        return None
    return val.decode("utf-8") if isinstance(val, (bytes, bytearray)) else val


# ---------------------------------------------------------------------------
# Type serialization — read from FlatBuffer, write to new Builder
# ---------------------------------------------------------------------------


def _build_type(builder: flatbuffers.Builder, fb_type) -> int:
    """Recursively serialize a TypeBin.Type from a source buffer into *builder*.

    Returns the offset of the newly created Type table in *builder*.
    """
    class_type = fb_type.ClassType()
    union_tab = fb_type.Class()

    # -- Prepare child first (before StartObject) --
    class_offset = _build_type_class(builder, class_type, union_tab)

    # -- Prepare metadata vector --
    metadata_offset = None
    meta_len = fb_type.MetadataLength()
    if meta_len:
        meta_offsets = []
        for i in range(meta_len):
            meta_offsets.append(_build_type_metadata(builder, fb_type.Metadata(i)))
        TypeMetaMod.TypeMetadataStartValueVector  # just checking existence
        TypeMod.TypeStartMetadataVector(builder, meta_len)
        for off in reversed(meta_offsets):
            builder.PrependUOffsetTRelative(off)
        metadata_offset = builder.EndVector()

    # -- Prepare ancestors vector --
    ancestors_offset = None
    anc_len = fb_type.AncestorsLength()
    if anc_len:
        TypeMod.TypeStartAncestorsVector(builder, anc_len)
        for i in range(anc_len - 1, -1, -1):
            anc = fb_type.Ancestors(i)
            TypeGUIDMod.CreateTypeGuid(builder, list(_guid_bytes(anc)))
        ancestors_offset = builder.EndVector()

    # -- Prepare name --
    name = _decode_string(fb_type.Name())
    name_offset = builder.CreateString(name) if name else None

    # -- Build the Type table --
    TypeMod.TypeStart(builder)
    if name_offset is not None:
        TypeMod.TypeAddName(builder, name_offset)
    TypeMod.TypeAddClassType(builder, class_type)
    if class_offset is not None:
        TypeMod.TypeAddClass(builder, class_offset)
    TypeMod.TypeAddConfidence(builder, fb_type.Confidence())
    TypeMod.TypeAddAlignment(builder, fb_type.Alignment())
    TypeMod.TypeAddModifiers(builder, fb_type.Modifiers())
    if metadata_offset is not None:
        TypeMod.TypeAddMetadata(builder, metadata_offset)
    if ancestors_offset is not None:
        TypeMod.TypeAddAncestors(builder, ancestors_offset)
    return TypeMod.TypeEnd(builder)


def _build_type_metadata(builder: flatbuffers.Builder, fb_meta) -> int:
    key = _decode_string(fb_meta.Key())
    key_offset = builder.CreateString(key) if key else None

    value_offset = None
    val_len = fb_meta.ValueLength()
    if val_len:
        TypeMetaMod.TypeMetadataStartValueVector(builder, val_len)
        for i in range(val_len - 1, -1, -1):
            builder.PrependUint8(fb_meta.Value(i))
        value_offset = builder.EndVector()

    TypeMetaMod.TypeMetadataStart(builder)
    if key_offset is not None:
        TypeMetaMod.TypeMetadataAddKey(builder, key_offset)
    TypeMetaMod.TypeMetadataAddValueType(builder, fb_meta.ValueType())
    if value_offset is not None:
        TypeMetaMod.TypeMetadataAddValue(builder, value_offset)
    return TypeMetaMod.TypeMetadataEnd(builder)


def _init_union_as(cls, union_tab):
    """Initialize a generated FlatBuffer class from a generic union Table."""
    obj = cls()
    obj.Init(union_tab.Bytes, union_tab.Pos)
    return obj


def _build_type_class(
    builder: flatbuffers.Builder, class_type: int, union_tab
) -> int | None:
    """Build the TypeClass union value and return its offset."""
    if union_tab is None or class_type == TypeClass.NONE:
        return None

    if class_type == TypeClass.Void:
        VoidMod.VoidStart(builder)
        return VoidMod.VoidEnd(builder)

    if class_type == TypeClass.Boolean:
        fb = _init_union_as(BoolMod.Boolean, union_tab)
        BoolMod.BooleanStart(builder)
        w = fb.Width()
        if w is not None:
            bw = BitWidthMod.CreateBitWidth(builder, w.Value())
            BoolMod.BooleanAddWidth(builder, bw)
        return BoolMod.BooleanEnd(builder)

    if class_type == TypeClass.Integer:
        fb = _init_union_as(IntMod.Integer, union_tab)
        IntMod.IntegerStart(builder)
        w = fb.Width()
        if w is not None:
            bw = BitWidthMod.CreateBitWidth(builder, w.Value())
            IntMod.IntegerAddWidth(builder, bw)
        IntMod.IntegerAddSigned(builder, fb.Signed())
        return IntMod.IntegerEnd(builder)

    if class_type == TypeClass.Character:
        fb = _init_union_as(CharMod.Character, union_tab)
        CharMod.CharacterStart(builder)
        w = fb.Width()
        if w is not None:
            bw = BitWidthMod.CreateBitWidth(builder, w.Value())
            CharMod.CharacterAddWidth(builder, bw)
        return CharMod.CharacterEnd(builder)

    if class_type == TypeClass.Float:
        fb = _init_union_as(FloatMod.Float, union_tab)
        FloatMod.FloatStart(builder)
        w = fb.Width()
        if w is not None:
            bw = BitWidthMod.CreateBitWidth(builder, w.Value())
            FloatMod.FloatAddWidth(builder, bw)
        return FloatMod.FloatEnd(builder)

    if class_type == TypeClass.Pointer:
        return _build_pointer(builder, union_tab)

    if class_type == TypeClass.Array:
        return _build_array(builder, union_tab)

    if class_type == TypeClass.Structure:
        return _build_structure(builder, union_tab)

    if class_type == TypeClass.Enumeration:
        return _build_enumeration(builder, union_tab)

    if class_type == TypeClass.Union:
        return _build_union(builder, union_tab)

    if class_type == TypeClass.Function:
        return _build_type_function(builder, union_tab)

    if class_type == TypeClass.Referrer:
        return _build_referrer(builder, union_tab)

    return None


def _build_pointer(builder, union_tab) -> int:
    fb = _init_union_as(PtrMod.Pointer, union_tab)
    child = fb.Child()
    child_offset = _build_type(builder, child) if child else None

    PtrMod.PointerStart(builder)
    w = fb.Width()
    if w is not None:
        bw = BitWidthMod.CreateBitWidth(builder, w.Value())
        PtrMod.PointerAddWidth(builder, bw)
    s = fb.Shift()
    if s is not None:
        bs = BitShiftMod.CreateBitShift(builder, s.Value())
        PtrMod.PointerAddShift(builder, bs)
    if child_offset is not None:
        PtrMod.PointerAddChild(builder, child_offset)
    PtrMod.PointerAddAddressing(builder, fb.Addressing())
    off = fb.Offset()
    if off is not None:
        bo = BitOffsetMod.CreateBitOffset(builder, off.Value())
        PtrMod.PointerAddOffset(builder, bo)
    return PtrMod.PointerEnd(builder)


def _build_array(builder, union_tab) -> int:
    fb = _init_union_as(ArrayMod.Array, union_tab)
    elem = fb.Type()
    elem_offset = _build_type(builder, elem) if elem else None

    ArrayMod.ArrayStart(builder)
    if elem_offset is not None:
        ArrayMod.ArrayAddType(builder, elem_offset)
    ArrayMod.ArrayAddLength(builder, fb.Length())
    ArrayMod.ArrayAddModifiers(builder, fb.Modifiers())
    return ArrayMod.ArrayEnd(builder)


def _build_structure(builder, union_tab) -> int:
    fb = _init_union_as(StructMod.Structure, union_tab)
    mem_count = fb.MembersLength()
    member_offsets = []
    for i in range(mem_count):
        member_offsets.append(_build_struct_member(builder, fb.Members(i)))

    members_vec = None
    if member_offsets:
        StructMod.StructureStartMembersVector(builder, len(member_offsets))
        for off in reversed(member_offsets):
            builder.PrependUOffsetTRelative(off)
        members_vec = builder.EndVector()

    StructMod.StructureStart(builder)
    if members_vec is not None:
        StructMod.StructureAddMembers(builder, members_vec)
    return StructMod.StructureEnd(builder)


def _build_struct_member(builder, fb_mem) -> int:
    ty = fb_mem.Type()
    type_offset = _build_type(builder, ty) if ty else None
    name = _decode_string(fb_mem.Name())
    name_offset = builder.CreateString(name) if name else None

    StructMemMod.StructureMemberStart(builder)
    if name_offset is not None:
        StructMemMod.StructureMemberAddName(builder, name_offset)
    off = fb_mem.Offset()
    if off is not None:
        ub = UBitOffMod.CreateUnsignedBitOffset(builder, off.Value())
        StructMemMod.StructureMemberAddOffset(builder, ub)
    if type_offset is not None:
        StructMemMod.StructureMemberAddType(builder, type_offset)
    StructMemMod.StructureMemberAddModifiers(builder, fb_mem.Modifiers())
    return StructMemMod.StructureMemberEnd(builder)


def _build_enumeration(builder, union_tab) -> int:
    fb = _init_union_as(EnumMod.Enumeration, union_tab)
    mt = fb.MemberType()
    mt_offset = _build_type(builder, mt) if mt else None

    mem_count = fb.MembersLength()
    member_offsets = []
    for i in range(mem_count):
        member_offsets.append(_build_enum_member(builder, fb.Members(i)))

    members_vec = None
    if member_offsets:
        EnumMod.EnumerationStartMembersVector(builder, len(member_offsets))
        for off in reversed(member_offsets):
            builder.PrependUOffsetTRelative(off)
        members_vec = builder.EndVector()

    EnumMod.EnumerationStart(builder)
    if mt_offset is not None:
        EnumMod.EnumerationAddMemberType(builder, mt_offset)
    if members_vec is not None:
        EnumMod.EnumerationAddMembers(builder, members_vec)
    return EnumMod.EnumerationEnd(builder)


def _build_enum_member(builder, fb_mem) -> int:
    name = _decode_string(fb_mem.Name())
    name_offset = builder.CreateString(name) if name else None
    EnumMemMod.EnumerationMemberStart(builder)
    if name_offset is not None:
        EnumMemMod.EnumerationMemberAddName(builder, name_offset)
    EnumMemMod.EnumerationMemberAddConstant(builder, fb_mem.Constant())
    return EnumMemMod.EnumerationMemberEnd(builder)


def _build_union(builder, union_tab) -> int:
    fb = _init_union_as(UnionMod.Union, union_tab)
    mem_count = fb.MembersLength()
    member_offsets = []
    for i in range(mem_count):
        member_offsets.append(_build_union_member(builder, fb.Members(i)))

    members_vec = None
    if member_offsets:
        UnionMod.UnionStartMembersVector(builder, len(member_offsets))
        for off in reversed(member_offsets):
            builder.PrependUOffsetTRelative(off)
        members_vec = builder.EndVector()

    UnionMod.UnionStart(builder)
    if members_vec is not None:
        UnionMod.UnionAddMembers(builder, members_vec)
    return UnionMod.UnionEnd(builder)


def _build_union_member(builder, fb_mem) -> int:
    ty = fb_mem.Type()
    type_offset = _build_type(builder, ty) if ty else None
    name = _decode_string(fb_mem.Name())
    name_offset = builder.CreateString(name) if name else None
    UnionMemMod.UnionMemberStart(builder)
    if name_offset is not None:
        UnionMemMod.UnionMemberAddName(builder, name_offset)
    if type_offset is not None:
        UnionMemMod.UnionMemberAddType(builder, type_offset)
    return UnionMemMod.UnionMemberEnd(builder)


def _build_type_function(builder, union_tab) -> int:
    fb = _init_union_as(TypeFuncMod.Function, union_tab)

    cc = fb.CallingConvention()
    cc_offset = None
    if cc is not None:
        cc_name = _decode_string(cc.Name())
        cc_name_off = builder.CreateString(cc_name) if cc_name else None
        CallingConvMod.CallingConventionStart(builder)
        if cc_name_off is not None:
            CallingConvMod.CallingConventionAddName(builder, cc_name_off)
        cc_offset = CallingConvMod.CallingConventionEnd(builder)

    in_offsets = [
        _build_func_member(builder, fb.InMembers(i))
        for i in range(fb.InMembersLength())
    ]
    out_offsets = [
        _build_func_member(builder, fb.OutMembers(i))
        for i in range(fb.OutMembersLength())
    ]

    in_vec = None
    if in_offsets:
        TypeFuncMod.FunctionStartInMembersVector(builder, len(in_offsets))
        for off in reversed(in_offsets):
            builder.PrependUOffsetTRelative(off)
        in_vec = builder.EndVector()

    out_vec = None
    if out_offsets:
        TypeFuncMod.FunctionStartOutMembersVector(builder, len(out_offsets))
        for off in reversed(out_offsets):
            builder.PrependUOffsetTRelative(off)
        out_vec = builder.EndVector()

    TypeFuncMod.FunctionStart(builder)
    if cc_offset is not None:
        TypeFuncMod.FunctionAddCallingConvention(builder, cc_offset)
    if in_vec is not None:
        TypeFuncMod.FunctionAddInMembers(builder, in_vec)
    if out_vec is not None:
        TypeFuncMod.FunctionAddOutMembers(builder, out_vec)
    return TypeFuncMod.FunctionEnd(builder)


def _build_func_member(builder, fb_mem) -> int:
    ty = fb_mem.Type()
    type_offset = _build_type(builder, ty) if ty else None
    name = _decode_string(fb_mem.Name())
    name_offset = builder.CreateString(name) if name else None

    # Location union
    loc_type = fb_mem.LocationType()
    loc_offset = None
    if loc_type == LocationClass.RegisterLocation:
        loc_tab = fb_mem.Location()
        fb_reg = _init_union_as(RegLocMod.RegisterLocation, loc_tab)
        RegLocMod.RegisterLocationStart(builder)
        RegLocMod.RegisterLocationAddId(builder, fb_reg.Id())
        loc_offset = RegLocMod.RegisterLocationEnd(builder)
    elif loc_type == LocationClass.StackLocation:
        loc_tab = fb_mem.Location()
        fb_stack = _init_union_as(StackLocMod.StackLocation, loc_tab)
        StackLocMod.StackLocationStart(builder)
        off = fb_stack.Offset()
        if off is not None:
            bo = BitOffsetMod.CreateBitOffset(builder, off.Value())
            StackLocMod.StackLocationAddOffset(builder, bo)
        loc_offset = StackLocMod.StackLocationEnd(builder)

    FuncMemMod.FunctionMemberStart(builder)
    if name_offset is not None:
        FuncMemMod.FunctionMemberAddName(builder, name_offset)
    if type_offset is not None:
        FuncMemMod.FunctionMemberAddType(builder, type_offset)
    if loc_offset is not None:
        FuncMemMod.FunctionMemberAddLocationType(builder, loc_type)
        FuncMemMod.FunctionMemberAddLocation(builder, loc_offset)
    return FuncMemMod.FunctionMemberEnd(builder)


def _build_referrer(builder, union_tab) -> int:
    fb = _init_union_as(ReferrerMod.Referrer, union_tab)
    name = _decode_string(fb.Name())
    name_offset = builder.CreateString(name) if name else None

    ReferrerMod.ReferrerStart(builder)
    g = fb.Guid()
    if g is not None:
        tg = TypeGUIDMod.CreateTypeGuid(builder, list(_guid_bytes(g)))
        ReferrerMod.ReferrerAddGuid(builder, tg)
    if name_offset is not None:
        ReferrerMod.ReferrerAddName(builder, name_offset)
    return ReferrerMod.ReferrerEnd(builder)


# ---------------------------------------------------------------------------
# Serialize a single SigBin.Function → standalone FlatBuffer bytes
# ---------------------------------------------------------------------------


def _build_variable(builder, fb_var) -> int:
    """Copy a FunctionVariable into builder."""
    ty = fb_var.Type()
    type_offset = _build_type(builder, ty) if ty else None
    name = _decode_string(fb_var.Name())
    name_offset = builder.CreateString(name) if name else None

    loc_type = fb_var.LocationType()
    loc_offset = None
    if loc_type == LocationClass.RegisterLocation:
        loc_tab = fb_var.Location()
        fb_reg = _init_union_as(RegLocMod.RegisterLocation, loc_tab)
        RegLocMod.RegisterLocationStart(builder)
        RegLocMod.RegisterLocationAddId(builder, fb_reg.Id())
        loc_offset = RegLocMod.RegisterLocationEnd(builder)
    elif loc_type == LocationClass.StackLocation:
        loc_tab = fb_var.Location()
        fb_stack = _init_union_as(StackLocMod.StackLocation, loc_tab)
        StackLocMod.StackLocationStart(builder)
        off = fb_stack.Offset()
        if off is not None:
            bo = BitOffsetMod.CreateBitOffset(builder, off.Value())
            StackLocMod.StackLocationAddOffset(builder, bo)
        loc_offset = StackLocMod.StackLocationEnd(builder)

    FuncVarMod.FunctionVariableStart(builder)
    FuncVarMod.FunctionVariableAddOffset(builder, fb_var.Offset())
    if name_offset is not None:
        FuncVarMod.FunctionVariableAddName(builder, name_offset)
    if loc_offset is not None:
        FuncVarMod.FunctionVariableAddLocationType(builder, loc_type)
        FuncVarMod.FunctionVariableAddLocation(builder, loc_offset)
    if type_offset is not None:
        FuncVarMod.FunctionVariableAddType(builder, type_offset)
    return FuncVarMod.FunctionVariableEnd(builder)


def serialize_function_fb(fb_func) -> bytes:
    """Serialize a parsed SigBin.Function into a standalone FlatBuffer."""
    builder = flatbuffers.Builder(4096)

    # -- symbol --
    fb_sym = fb_func.Symbol()
    sym_name = _decode_string(fb_sym.Name()) if fb_sym else ""
    sym_name_off = builder.CreateString(sym_name or "")
    SymbolMod.SymbolStart(builder)
    SymbolMod.SymbolAddName(builder, sym_name_off)
    if fb_sym:
        SymbolMod.SymbolAddModifiers(builder, fb_sym.Modifiers())
        SymbolMod.SymbolAddClass(builder, fb_sym.Class())
    symbol_off = SymbolMod.SymbolEnd(builder)

    # -- type (optional, recursive) --
    fb_type = fb_func.Type()
    type_off = _build_type(builder, fb_type) if fb_type else None

    # -- constraints --
    constraint_offsets = []
    for i in range(fb_func.ConstraintsLength()):
        c = fb_func.Constraints(i)
        ConstraintMod.ConstraintStart(builder)
        g = c.Guid()
        if g is not None:
            cg = ConstraintGUIDMod.CreateConstraintGuid(builder, list(_guid_bytes(g)))
            ConstraintMod.ConstraintAddGuid(builder, cg)
        ConstraintMod.ConstraintAddOffset(builder, c.Offset())
        constraint_offsets.append(ConstraintMod.ConstraintEnd(builder))

    constraints_vec = None
    if constraint_offsets:
        SigFuncMod.FunctionStartConstraintsVector(builder, len(constraint_offsets))
        for off in reversed(constraint_offsets):
            builder.PrependUOffsetTRelative(off)
        constraints_vec = builder.EndVector()

    # -- comments --
    comment_offsets = []
    for i in range(fb_func.CommentsLength()):
        c = fb_func.Comments(i)
        text = _decode_string(c.Text()) or ""
        text_off = builder.CreateString(text)
        CommentMod.FunctionCommentStart(builder)
        CommentMod.FunctionCommentAddOffset(builder, c.Offset())
        CommentMod.FunctionCommentAddText(builder, text_off)
        comment_offsets.append(CommentMod.FunctionCommentEnd(builder))

    comments_vec = None
    if comment_offsets:
        SigFuncMod.FunctionStartCommentsVector(builder, len(comment_offsets))
        for off in reversed(comment_offsets):
            builder.PrependUOffsetTRelative(off)
        comments_vec = builder.EndVector()

    # -- variables --
    var_offsets = []
    for i in range(fb_func.VariablesLength()):
        var_offsets.append(_build_variable(builder, fb_func.Variables(i)))

    vars_vec = None
    if var_offsets:
        SigFuncMod.FunctionStartVariablesVector(builder, len(var_offsets))
        for off in reversed(var_offsets):
            builder.PrependUOffsetTRelative(off)
        vars_vec = builder.EndVector()

    # -- function table --
    SigFuncMod.FunctionStart(builder)
    guid_bytes = list(_guid_bytes(fb_func.Guid()))
    fg = FuncGUIDMod.CreateFunctionGuid(builder, guid_bytes)
    SigFuncMod.FunctionAddGuid(builder, fg)
    SigFuncMod.FunctionAddSymbol(builder, symbol_off)
    if type_off is not None:
        SigFuncMod.FunctionAddType(builder, type_off)
    if constraints_vec is not None:
        SigFuncMod.FunctionAddConstraints(builder, constraints_vec)
    if comments_vec is not None:
        SigFuncMod.FunctionAddComments(builder, comments_vec)
    if vars_vec is not None:
        SigFuncMod.FunctionAddVariables(builder, vars_vec)
    func_off = SigFuncMod.FunctionEnd(builder)

    builder.Finish(func_off)
    return bytes(builder.Output())


# ---------------------------------------------------------------------------
# Serialize a single TypeBin.Type → standalone FlatBuffer bytes
# ---------------------------------------------------------------------------


def serialize_type_fb(fb_type) -> bytes:
    """Serialize a parsed TypeBin.Type into a standalone FlatBuffer."""
    builder = flatbuffers.Builder(2048)
    off = _build_type(builder, fb_type)
    builder.Finish(off)
    return bytes(builder.Output())


# ---------------------------------------------------------------------------
# Build a complete WARP file from stored DB data
# ---------------------------------------------------------------------------


def build_warp_file(
    functions_data: list[bytes],
    types_data: list[bytes],
    *,
    platform: str | None = None,
    architecture: str | None = None,
) -> bytes:
    """Build a WARP file from lists of standalone function and type FlatBuffer blobs.

    Used by download endpoints that need to return a valid WarpFile.
    """
    builder = flatbuffers.Builder(
        max(8192, sum(len(d) for d in functions_data + types_data) * 2)
    )

    chunk_offsets: list[int] = []

    # -- Signature chunk --
    if functions_data:
        sig_data = _build_signature_chunk_bytes(functions_data)
        chunk_offsets.append(
            _build_chunk(
                builder, ChunkType.Signatures, sig_data, platform, architecture
            )
        )

    # -- Type chunk --
    if types_data:
        type_data = _build_type_chunk_bytes(types_data)
        chunk_offsets.append(
            _build_chunk(builder, ChunkType.Types, type_data, platform, architecture)
        )

    # -- Chunks vector --
    chunks_vec = None
    if chunk_offsets:
        WarpFileMod.FileStartChunksVector(builder, len(chunk_offsets))
        for off in reversed(chunk_offsets):
            builder.PrependUOffsetTRelative(off)
        chunks_vec = builder.EndVector()

    # -- File header --
    FileHeaderMod.FileHeaderStart(builder)
    FileHeaderMod.FileHeaderAddVersion(builder, FILE_VERSION)
    header_off = FileHeaderMod.FileHeaderEnd(builder)

    # -- File --
    WarpFileMod.FileStart(builder)
    WarpFileMod.FileAddHeader(builder, header_off)
    if chunks_vec is not None:
        WarpFileMod.FileAddChunks(builder, chunks_vec)
    file_off = WarpFileMod.FileEnd(builder)

    builder.Finish(file_off)
    return bytes(builder.Output())


def _build_signature_chunk_bytes(functions_data: list[bytes]) -> bytes:
    """Build a SignatureChunk FlatBuffer from a list of standalone function FlatBuffers."""
    builder = flatbuffers.Builder(max(4096, sum(len(d) for d in functions_data) * 2))

    # Parse each function blob and rebuild in the new builder
    func_offsets = []
    for func_bytes in functions_data:
        fb_func = SigFuncMod.Function.GetRootAs(bytearray(func_bytes))
        func_offsets.append(_rebuild_function_in_builder(builder, fb_func))

    SigChunkMod.SignatureChunkStartFunctionsVector(builder, len(func_offsets))
    for off in reversed(func_offsets):
        builder.PrependUOffsetTRelative(off)
    funcs_vec = builder.EndVector()

    SigChunkMod.SignatureChunkStart(builder)
    SigChunkMod.SignatureChunkAddFunctions(builder, funcs_vec)
    chunk_off = SigChunkMod.SignatureChunkEnd(builder)

    builder.Finish(chunk_off)
    return bytes(builder.Output())


def _build_type_chunk_bytes(types_data: list[bytes]) -> bytes:
    """Build a TypeChunk FlatBuffer from a list of standalone type FlatBuffers."""
    builder = flatbuffers.Builder(max(4096, sum(len(d) for d in types_data) * 2))

    ct_offsets = []
    for type_bytes in types_data:
        fb_type = TypeMod.Type.GetRootAs(bytearray(type_bytes))
        type_off = _build_type(builder, fb_type)
        type_guid = _uuid5_bytes(NAMESPACE_TYPEBIN, type_bytes)

        ComputedTypeMod.ComputedTypeStart(builder)
        tg = TypeGUIDMod.CreateTypeGuid(builder, list(type_guid.bytes))
        ComputedTypeMod.ComputedTypeAddGuid(builder, tg)
        ComputedTypeMod.ComputedTypeAddType(builder, type_off)
        ct_offsets.append(ComputedTypeMod.ComputedTypeEnd(builder))

    TypeChunkMod.TypeChunkStartTypesVector(builder, len(ct_offsets))
    for off in reversed(ct_offsets):
        builder.PrependUOffsetTRelative(off)
    types_vec = builder.EndVector()

    TypeChunkMod.TypeChunkStart(builder)
    TypeChunkMod.TypeChunkAddTypes(builder, types_vec)
    chunk_off = TypeChunkMod.TypeChunkEnd(builder)

    builder.Finish(chunk_off)
    return bytes(builder.Output())


def _rebuild_function_in_builder(builder, fb_func) -> int:
    """Rebuild a SigBin.Function inside an existing builder (for packing into a chunk)."""
    # -- symbol --
    fb_sym = fb_func.Symbol()
    sym_name = _decode_string(fb_sym.Name()) if fb_sym else ""
    sym_name_off = builder.CreateString(sym_name or "")
    SymbolMod.SymbolStart(builder)
    SymbolMod.SymbolAddName(builder, sym_name_off)
    if fb_sym:
        SymbolMod.SymbolAddModifiers(builder, fb_sym.Modifiers())
        SymbolMod.SymbolAddClass(builder, fb_sym.Class())
    symbol_off = SymbolMod.SymbolEnd(builder)

    fb_type = fb_func.Type()
    type_off = _build_type(builder, fb_type) if fb_type else None

    constraint_offsets = []
    for i in range(fb_func.ConstraintsLength()):
        c = fb_func.Constraints(i)
        ConstraintMod.ConstraintStart(builder)
        g = c.Guid()
        if g is not None:
            cg = ConstraintGUIDMod.CreateConstraintGuid(builder, list(_guid_bytes(g)))
            ConstraintMod.ConstraintAddGuid(builder, cg)
        ConstraintMod.ConstraintAddOffset(builder, c.Offset())
        constraint_offsets.append(ConstraintMod.ConstraintEnd(builder))

    constraints_vec = None
    if constraint_offsets:
        SigFuncMod.FunctionStartConstraintsVector(builder, len(constraint_offsets))
        for off in reversed(constraint_offsets):
            builder.PrependUOffsetTRelative(off)
        constraints_vec = builder.EndVector()

    comment_offsets = []
    for i in range(fb_func.CommentsLength()):
        c = fb_func.Comments(i)
        text = _decode_string(c.Text()) or ""
        text_off = builder.CreateString(text)
        CommentMod.FunctionCommentStart(builder)
        CommentMod.FunctionCommentAddOffset(builder, c.Offset())
        CommentMod.FunctionCommentAddText(builder, text_off)
        comment_offsets.append(CommentMod.FunctionCommentEnd(builder))

    comments_vec = None
    if comment_offsets:
        SigFuncMod.FunctionStartCommentsVector(builder, len(comment_offsets))
        for off in reversed(comment_offsets):
            builder.PrependUOffsetTRelative(off)
        comments_vec = builder.EndVector()

    var_offsets = []
    for i in range(fb_func.VariablesLength()):
        var_offsets.append(_build_variable(builder, fb_func.Variables(i)))

    vars_vec = None
    if var_offsets:
        SigFuncMod.FunctionStartVariablesVector(builder, len(var_offsets))
        for off in reversed(var_offsets):
            builder.PrependUOffsetTRelative(off)
        vars_vec = builder.EndVector()

    SigFuncMod.FunctionStart(builder)
    guid_bytes = list(_guid_bytes(fb_func.Guid()))
    fg = FuncGUIDMod.CreateFunctionGuid(builder, guid_bytes)
    SigFuncMod.FunctionAddGuid(builder, fg)
    SigFuncMod.FunctionAddSymbol(builder, symbol_off)
    if type_off is not None:
        SigFuncMod.FunctionAddType(builder, type_off)
    if constraints_vec is not None:
        SigFuncMod.FunctionAddConstraints(builder, constraints_vec)
    if comments_vec is not None:
        SigFuncMod.FunctionAddComments(builder, comments_vec)
    if vars_vec is not None:
        SigFuncMod.FunctionAddVariables(builder, vars_vec)
    return SigFuncMod.FunctionEnd(builder)


def _build_chunk(
    builder: flatbuffers.Builder,
    chunk_type: int,
    chunk_data: bytes,
    platform: str | None,
    architecture: str | None,
) -> int:
    """Build a Warp.Chunk inside *builder* and return its offset."""
    data_vec = builder.CreateByteVector(chunk_data)

    # Target
    plat_off = builder.CreateString(platform) if platform else None
    arch_off = builder.CreateString(architecture) if architecture else None
    TargetMod.TargetStart(builder)
    if arch_off is not None:
        TargetMod.TargetAddArchitecture(builder, arch_off)
    if plat_off is not None:
        TargetMod.TargetAddPlatform(builder, plat_off)
    target_off = TargetMod.TargetEnd(builder)

    # ChunkHeader
    ChunkHeaderMod.ChunkHeaderStart(builder)
    ChunkHeaderMod.ChunkHeaderAddVersion(builder, 0)
    ChunkHeaderMod.ChunkHeaderAddType(builder, chunk_type)
    ChunkHeaderMod.ChunkHeaderAddCompressionType(builder, CompressionType.None_)
    ChunkHeaderMod.ChunkHeaderAddSize(builder, len(chunk_data))
    ChunkHeaderMod.ChunkHeaderAddTarget(builder, target_off)
    header_off = ChunkHeaderMod.ChunkHeaderEnd(builder)

    # Chunk
    ChunkMod.ChunkStart(builder)
    ChunkMod.ChunkAddHeader(builder, header_off)
    ChunkMod.ChunkAddData(builder, data_vec)
    return ChunkMod.ChunkEnd(builder)


# ---------------------------------------------------------------------------
# Main parser: .warp bytes → list[ParsedChunk]
# ---------------------------------------------------------------------------


def parse_warp_file(file_data: bytes) -> list[ParsedChunk]:
    """Parse a .warp binary file and return structured data for DB storage."""
    buf = bytearray(file_data)
    warp_file = WarpFileMod.File.GetRootAs(buf)

    chunks: list[ParsedChunk] = []
    num_chunks = warp_file.ChunksLength()
    for i in range(num_chunks):
        fb_chunk = warp_file.Chunks(i)
        header = fb_chunk.Header()
        if header is None:
            continue

        # Target
        fb_target = header.Target()
        target = ParsedTarget(
            architecture=_decode_string(fb_target.Architecture())
            if fb_target
            else None,
            platform=_decode_string(fb_target.Platform()) if fb_target else None,
        )

        # Decompress chunk data
        raw_data = fb_chunk.DataAsNumpy() if False else None  # numpy not available
        if raw_data is not None:
            raw_bytes = bytes(raw_data)
        else:
            # Read data byte by byte
            data_len = fb_chunk.DataLength()
            if data_len:
                o = flatbuffers.number_types.UOffsetTFlags.py_type(
                    fb_chunk._tab.Offset(6)
                )
                vec_start = fb_chunk._tab.Vector(o)
                raw_bytes = bytes(fb_chunk._tab.Bytes[vec_start : vec_start + data_len])
            else:
                raw_bytes = b""

        compression = header.CompressionType()
        if compression == CompressionType.Zstd:
            raw_bytes = zlib.decompress(raw_bytes)

        chunk = ParsedChunk(target=target)

        chunk_type = header.Type()
        if chunk_type == ChunkType.Signatures:
            _parse_signature_chunk(raw_bytes, chunk)
        elif chunk_type == ChunkType.Types:
            _parse_type_chunk(raw_bytes, chunk)

        chunks.append(chunk)

    return chunks


def _parse_signature_chunk(data: bytes, chunk: ParsedChunk) -> None:
    buf = bytearray(data)
    sig_chunk = SigChunkMod.SignatureChunk.GetRootAs(buf)
    num_funcs = sig_chunk.FunctionsLength()

    for i in range(num_funcs):
        fb_func = sig_chunk.Functions(i)
        if fb_func is None:
            continue

        guid_obj = fb_func.Guid()
        if guid_obj is None:
            continue
        func_guid = _to_uuid(guid_obj)

        # Symbol
        fb_sym = fb_func.Symbol()
        symbol = ParsedSymbol(
            name=_decode_string(fb_sym.Name()) if fb_sym else "",
            symbol_class=_decode_symbol_class(fb_sym.Class()) if fb_sym else "Function",
            modifier=_decode_modifier(fb_sym.Modifiers()) if fb_sym else "None",
        )

        # Constraints
        constraints = []
        for j in range(fb_func.ConstraintsLength()):
            c = fb_func.Constraints(j)
            c_guid_obj = c.Guid()
            if c_guid_obj is None:
                continue
            c_offset = c.Offset()
            constraints.append(
                ParsedConstraint(
                    guid=_to_uuid(c_guid_obj),
                    byte_offset=None if c_offset == UNRELATED_OFFSET else c_offset,
                )
            )

        # Comments
        comments = []
        for j in range(fb_func.CommentsLength()):
            c = fb_func.Comments(j)
            comments.append(
                ParsedComment(
                    byte_offset=c.Offset(),
                    text=_decode_string(c.Text()) or "",
                )
            )

        # Type GUID (if function has a type)
        type_guid = None
        fb_type = fb_func.Type()
        if fb_type is not None:
            type_bytes = serialize_type_fb(fb_type)
            type_guid = _uuid5_bytes(NAMESPACE_TYPEBIN, type_bytes)
            # Also add the type to the chunk's types list
            type_name = _decode_string(fb_type.Name())
            chunk.types.append(
                ParsedType(guid=type_guid, name=type_name, data=type_bytes)
            )

        # Serialize function data
        func_data = serialize_function_fb(fb_func)

        chunk.functions.append(
            ParsedFunction(
                guid=func_guid,
                symbol=symbol,
                constraints=constraints,
                comments=comments,
                type_guid=type_guid,
                data=func_data,
            )
        )


def _parse_type_chunk(data: bytes, chunk: ParsedChunk) -> None:
    buf = bytearray(data)
    type_chunk = TypeChunkMod.TypeChunk.GetRootAs(buf)
    num_types = type_chunk.TypesLength()

    for i in range(num_types):
        fb_ct = type_chunk.Types(i)
        if fb_ct is None:
            continue

        guid_obj = fb_ct.Guid()
        if guid_obj is None:
            continue
        type_guid = _to_uuid(guid_obj)

        fb_type = fb_ct.Type()
        if fb_type is None:
            continue

        type_name = _decode_string(fb_type.Name())
        type_data = serialize_type_fb(fb_type)

        chunk.types.append(ParsedType(guid=type_guid, name=type_name, data=type_data))
