# Generated FlatBuffer code — do not edit manually.
# Regenerate with: flatc --python -o src/warp_server/gen_flatbuffers warp/*.fbs
