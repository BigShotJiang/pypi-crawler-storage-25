from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import Target, User
from warp_server.schemas import TargetMdl, TargetQueryRequest

router = APIRouter(prefix="/api/v1/targets", tags=["targets"])


def _target_mdl(t: Target) -> TargetMdl:
    return TargetMdl(id=t.id, created_at=t.created_at, platform=t.platform, arch=t.arch)


def _build_query(platform: str | None, arch: str | None):
    query = select(Target)
    if platform:
        query = query.where(Target.platform == platform)
    if arch:
        query = query.where(Target.arch == arch)
    return query


@router.get("/query", response_model=list[TargetMdl])
async def get_query_targets(
    platform: str | None = None,
    arch: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    query = _build_query(platform, arch)
    results = await db.execute(query)
    return [_target_mdl(t) for t in results.scalars().all()]


@router.post("/query", response_model=list[TargetMdl])
async def query_targets(
    body: TargetQueryRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    query = _build_query(body.platform, body.arch)
    results = await db.execute(query)
    return [_target_mdl(t) for t in results.scalars().all()]
