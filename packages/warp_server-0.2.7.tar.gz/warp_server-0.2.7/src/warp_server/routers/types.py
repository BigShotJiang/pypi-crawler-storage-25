from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.database import get_db
from warp_server.models import Type
from warp_server.schemas import (
    DataIdsRequest,
    PaginatedResponse,
    TypeMdl,
    TypeQueryRequest,
)
from warp_server.warp_parser import build_warp_file

router = APIRouter(prefix="/api/v1/types", tags=["types"])

DEFAULT_LIMIT = 20


def _type_mdl(t: Type) -> TypeMdl:
    return TypeMdl(
        id=t.id,
        created_at=t.created_at,
        commit_id=t.commit_id,
        source_id=t.source_id,
        name=t.name,
        data=list(t.data) if t.data else [],
    )


@router.post("/query")
async def query_types(body: TypeQueryRequest, db: AsyncSession = Depends(get_db)):
    query = select(Type)
    if body.name:
        if body.exact:
            query = query.where(Type.name == body.name)
        else:
            query = query.where(Type.name.ilike(f"%{body.name}%"))

    if body.format == "flatbuffer":
        results = await db.execute(query)
        types = results.scalars().all()
        type_data = [t.data for t in types if t.data]
        blob = build_warp_file([], type_data)
        return Response(content=blob, media_type="application/octet-stream")

    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(query.offset(offset).limit(limit))
    types = results.scalars().all()
    total_pages = max(1, -(-total // limit))
    return PaginatedResponse(
        items=[_type_mdl(t) for t in types],
        total_pages=total_pages,
        total_results=total,
    )


@router.post("/data")
async def get_type_datas(body: DataIdsRequest, db: AsyncSession = Depends(get_db)):
    if not body.ids:
        return Response(content=b"", media_type="application/octet-stream")
    uuid_ids = [UUID(str(i)) if not isinstance(i, UUID) else i for i in body.ids]
    results = await db.execute(select(Type).where(Type.id.in_(uuid_ids)))
    types = results.scalars().all()
    type_data = [t.data for t in types if t.data]
    blob = build_warp_file([], type_data)
    return Response(content=blob, media_type="application/octet-stream")


@router.get("/{type_id}", response_model=TypeMdl)
async def get_type_by_id(type_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Type).where(Type.id == type_id))
    t = result.scalar_one_or_none()
    if t is None:
        raise HTTPException(status_code=404, detail="Type not found")
    return _type_mdl(t)


@router.get("/{type_id}/data")
async def get_type_data(type_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Type).where(Type.id == type_id))
    t = result.scalar_one_or_none()
    if t is None:
        raise HTTPException(status_code=404, detail="Type not found")
    return Response(content=t.data or b"", media_type="application/octet-stream")
