from fastapi import APIRouter, Depends, Response
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import User
from warp_server.schemas import AuthUrlResponse, NextUrl

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.post("/login", response_model=AuthUrlResponse)
async def login(body: NextUrl):
    # Stub: In production this would redirect to an OAuth provider.
    return AuthUrlResponse(auth_url=f"/oauth/authorize?next={body.next or '/'}")


@router.post("/logout", status_code=204)
async def logout(user: User = Depends(get_current_user)):
    return Response(status_code=204)


@router.get("/o/callback")
async def oauth_callback(code: str, state: str, db: AsyncSession = Depends(get_db)):
    # Stub: In production this would exchange the code for tokens.
    return Response(status_code=302, headers={"Location": "/"})
