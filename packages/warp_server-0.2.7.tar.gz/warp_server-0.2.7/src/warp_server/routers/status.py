from fastapi import APIRouter

from warp_server.schemas import StatusResponse

router = APIRouter(prefix="/api/v1", tags=["status"])


@router.get("/status", response_model=StatusResponse)
async def status_handler():
    return StatusResponse(status="ok")
