from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import Commit, Function, Symbol, User
from warp_server.schemas import PaginatedResponse, SymbolMdl, SymbolQueryRequest

router = APIRouter(prefix="/api/v1/symbols", tags=["symbols"])

DEFAULT_LIMIT = 20


def _escape_like(s: str) -> str:
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _publisher_subq():
    return (
        select(User.username)
        .select_from(Function)
        .join(Commit, Function.commit_id == Commit.id)
        .join(User, Commit.user_id == User.id)
        .where(Function.symbol_id == Symbol.id)
        .order_by(Commit.id.desc())
        .limit(1)
        .correlate(Symbol)
        .scalar_subquery()
        .label("published_by")
    )


def _symbol_mdl(s: Symbol, published_by: str | None = None) -> SymbolMdl:
    return SymbolMdl(
        id=s.id,
        created_at=s.created_at,
        name=s.name,
        **{"class": s.symbol_class},
        modifier=s.modifier,
        published_by=published_by,
    )


@router.post("/query", response_model=PaginatedResponse[SymbolMdl])
async def query_symbols(
    body: SymbolQueryRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    query = select(Symbol)
    if body.name:
        if body.exact:
            query = query.where(Symbol.name == body.name)
        else:
            query = query.where(
                Symbol.name.ilike(f"%{_escape_like(body.name)}%", escape="\\")
            )
    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit

    pub_subq = _publisher_subq()
    results = await db.execute(
        select(Symbol, pub_subq)
        .offset(offset)
        .limit(limit)
        .where(
            Symbol.id.in_(
                query.with_only_columns(Symbol.id).offset(offset).limit(limit)
            )
        )
    )
    rows = results.all()
    total_pages = max(1, -(-total // limit))
    return PaginatedResponse(
        items=[_symbol_mdl(sym, pub) for sym, pub in rows],
        total_pages=total_pages,
        total_results=total,
    )


@router.get("/{symbol_id}", response_model=SymbolMdl)
async def get_symbol_by_id(
    symbol_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    pub_subq = _publisher_subq()
    result = await db.execute(select(Symbol, pub_subq).where(Symbol.id == symbol_id))
    row = result.one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    sym, pub = row
    return _symbol_mdl(sym, pub)
