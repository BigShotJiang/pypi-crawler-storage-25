import hashlib
from datetime import datetime, timedelta, timezone

from fastapi import Depends, HTTPException, Request, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.config import settings
from warp_server.database import get_db
from warp_server.models import ApiKey, LoginAttempt, User

security = HTTPBearer(auto_error=False)


def hash_api_key(raw_key: str) -> str:
    """Compute a hex-encoded SHA-256 hash of a raw API key."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _client_ip(request: Request) -> str:
    """Extract client IP. Only trust X-Forwarded-For from configured trusted proxies."""
    direct_ip = request.client.host if request.client else "unknown"
    if settings.trusted_proxies and direct_ip in settings.trusted_proxies:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return direct_ip


def _is_locked(attempt: LoginAttempt) -> bool:
    """Return True if the attempt record is still within the lockout window."""
    if not attempt.locked:
        return False
    if attempt.locked_at is None:
        return True
    locked_at = attempt.locked_at
    if locked_at.tzinfo is None:
        locked_at = locked_at.replace(tzinfo=timezone.utc)
    unlock_at = locked_at + timedelta(minutes=settings.lockout_duration_minutes)
    if datetime.now(timezone.utc) >= unlock_at:
        # Auto-unlock: lockout window has expired
        attempt.locked = 0
        attempt.failed_count = 0
        attempt.locked_at = None
        return False
    return True


def _is_user_locked(user: User) -> bool:
    """Return True if the user account is still within the lockout window."""
    if not user.locked:
        return False
    if user.locked_at is None:
        return True
    locked_at = user.locked_at
    if locked_at.tzinfo is None:
        locked_at = locked_at.replace(tzinfo=timezone.utc)
    unlock_at = locked_at + timedelta(minutes=settings.lockout_duration_minutes)
    if datetime.now(timezone.utc) >= unlock_at:
        user.locked = 0
        user.failed_login_count = 0
        user.locked_at = None
        return False
    return True


async def _get_attempt(db: AsyncSession, ip: str) -> LoginAttempt:
    """Get or create a LoginAttempt row for the given IP."""
    result = await db.execute(select(LoginAttempt).where(LoginAttempt.ip_address == ip))
    attempt = result.scalar_one_or_none()
    if attempt is None:
        attempt = LoginAttempt(ip_address=ip, failed_count=0, locked=0)
        db.add(attempt)
        await db.flush()
    return attempt


async def _record_failure(db: AsyncSession, ip: str, user: User | None = None) -> None:
    """Increment failed count for IP and optionally the user; lock if threshold reached."""
    now = datetime.now(timezone.utc)
    attempt = await _get_attempt(db, ip)
    attempt.failed_count += 1
    attempt.last_attempt_at = now
    if attempt.failed_count >= settings.max_login_attempts:
        attempt.locked = 1
        attempt.locked_at = now
    if user is not None:
        user.failed_login_count += 1
        if user.failed_login_count >= settings.max_login_attempts:
            user.locked = 1
            user.locked_at = now
    await db.commit()


async def _record_success(db: AsyncSession, ip: str, user: User) -> None:
    """Reset failed counts on successful auth."""
    attempt = await _get_attempt(db, ip)
    dirty = False
    if attempt.failed_count > 0:
        attempt.failed_count = 0
        attempt.last_attempt_at = None
        dirty = True
    if user.failed_login_count > 0:
        user.failed_login_count = 0
        dirty = True
    if dirty:
        await db.commit()


async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Security(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated"
        )

    ip = _client_ip(request)

    # Check if IP is locked (with auto-unlock)
    attempt = await _get_attempt(db, ip)
    if _is_locked(attempt):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Too many failed attempts. IP locked.",
        )

    token = credentials.credentials
    token_hash = hash_api_key(token)
    result = await db.execute(select(ApiKey).where(ApiKey.key == token_hash))
    api_key = result.scalar_one_or_none()
    if api_key is None:
        await _record_failure(db, ip)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key"
        )

    result = await db.execute(select(User).where(User.id == api_key.user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found"
        )

    # Check if user account is locked (with auto-unlock)
    if _is_user_locked(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account locked.",
        )

    if api_key.expires_at:
        expires = api_key.expires_at
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        if expires < datetime.now(timezone.utc):
            await _record_failure(db, ip, user)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="API key expired"
            )

    api_key.last_used_at = datetime.now(timezone.utc)
    await _record_success(db, ip, user)
    return user


async def get_optional_user(
    credentials: HTTPAuthorizationCredentials | None = Security(security),
    db: AsyncSession = Depends(get_db),
) -> User | None:
    if credentials is None:
        return None
    try:
        return await get_current_user(credentials, db)
    except HTTPException:
        return None


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "Admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Admin required"
        )
    return user
