import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.models import Target


@pytest.fixture
async def targets(db_session: AsyncSession):
    t1 = Target(platform="linux", arch="x86_64")
    t2 = Target(platform="linux", arch="aarch64")
    t3 = Target(platform="windows", arch="x86_64")
    db_session.add_all([t1, t2, t3])
    await db_session.commit()
    return [t1, t2, t3]


@pytest.mark.asyncio
async def test_query_targets_get(client: AsyncClient, user_token: str, targets):
    resp = await client.get("/api/v1/targets/query", headers=auth_headers(user_token))
    assert resp.status_code == 200
    assert len(resp.json()) == 3


@pytest.mark.asyncio
async def test_query_targets_filter(client: AsyncClient, user_token: str, targets):
    resp = await client.get(
        "/api/v1/targets/query?platform=linux", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert len(resp.json()) == 2


@pytest.mark.asyncio
async def test_query_targets_post(client: AsyncClient, user_token: str, targets):
    resp = await client.post(
        "/api/v1/targets/query",
        json={"platform": "windows", "arch": "x86_64"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    assert data[0]["platform"] == "windows"
