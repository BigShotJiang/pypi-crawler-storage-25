import uuid

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.models import (
    Commit,
    Function,
    Source,
    SourceUser,
    Symbol,
    Target,
    User,
)


@pytest.fixture
async def searchable_data(db_session: AsyncSession, regular_user: User):
    source = Source(name="search-src")
    db_session.add(source)
    await db_session.flush()
    db_session.add(SourceUser(source_id=source.id, user_id=regular_user.id))

    target = Target(platform="linux", arch="x86_64")
    db_session.add(target)
    await db_session.flush()

    commit = Commit(source_id=source.id, user_id=regular_user.id, name="c1")
    db_session.add(commit)
    await db_session.flush()

    symbol = Symbol(name="search_func", symbol_class="Function", modifier="None")
    db_session.add(symbol)
    await db_session.flush()

    func = Function(
        commit_id=commit.id,
        target_id=target.id,
        source_id=source.id,
        guid=uuid.uuid4(),
        symbol_id=symbol.id,
        data=b"\xde\xad",
    )
    db_session.add(func)
    await db_session.commit()
    return {"source": source, "function": func, "symbol": symbol}


@pytest.mark.asyncio
async def test_search_all(client: AsyncClient, user_token: str, searchable_data):
    resp = await client.get("/api/v1/search", headers=auth_headers(user_token))
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] > 0


@pytest.mark.asyncio
async def test_search_by_kind(client: AsyncClient, user_token: str, searchable_data):
    resp = await client.get(
        "/api/v1/search?kind=source", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    data = resp.json()
    assert all(item["kind"] == "source" for item in data["items"])


@pytest.mark.asyncio
async def test_search_by_query(client: AsyncClient, user_token: str, searchable_data):
    resp = await client.get(
        "/api/v1/search?q=search&kind=source", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["total"] == 1


@pytest.mark.asyncio
async def test_search_functions_by_name(
    client: AsyncClient, user_token: str, searchable_data
):
    resp = await client.get(
        "/api/v1/search?q=search_func&kind=function", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["total"] == 1
