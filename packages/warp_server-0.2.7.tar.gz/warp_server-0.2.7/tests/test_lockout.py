import secrets

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.auth import hash_api_key
from warp_server.models import ApiKey, LoginAttempt, User


@pytest.mark.asyncio
async def test_invalid_key_increments_failed_count(
    client: AsyncClient, db_session: AsyncSession
):
    """Each bad token bumps the counter for that IP."""
    for i in range(1, 4):
        resp = await client.get(
            "/api/v1/users/me", headers={"Authorization": "Bearer bad-key"}
        )
        assert resp.status_code == 401

    from sqlalchemy import select

    result = await db_session.execute(
        select(LoginAttempt).where(LoginAttempt.ip_address == "127.0.0.1")
    )
    attempt = result.scalar_one()
    assert attempt.failed_count == 3
    assert attempt.locked == 0


@pytest.mark.asyncio
async def test_ip_locked_after_max_attempts(
    client: AsyncClient, db_session: AsyncSession
):
    """After 5 failures the IP is locked and gets 403."""
    for _ in range(5):
        resp = await client.get(
            "/api/v1/users/me", headers={"Authorization": "Bearer wrong"}
        )
        assert resp.status_code == 401

    # 6th attempt should be 403
    resp = await client.get(
        "/api/v1/users/me", headers={"Authorization": "Bearer wrong"}
    )
    assert resp.status_code == 403
    assert "locked" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_locked_ip_blocks_valid_token(
    client: AsyncClient, admin_token: str, admin_user: User, db_session: AsyncSession
):
    """Even a valid token is rejected when the IP is locked."""
    for _ in range(5):
        await client.get("/api/v1/users/me", headers={"Authorization": "Bearer wrong"})

    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_successful_auth_resets_counter(
    client: AsyncClient, admin_token: str, admin_user: User, db_session: AsyncSession
):
    """A successful login resets the failed counter so it doesn't accumulate."""
    for _ in range(3):
        await client.get("/api/v1/users/me", headers={"Authorization": "Bearer wrong"})

    # Successful auth
    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 200

    from sqlalchemy import select

    result = await db_session.execute(
        select(LoginAttempt).where(LoginAttempt.ip_address == "127.0.0.1")
    )
    attempt = result.scalar_one()
    assert attempt.failed_count == 0


@pytest.mark.asyncio
async def test_unlock_via_db_allows_access_again(
    client: AsyncClient, admin_token: str, admin_user: User, db_session: AsyncSession
):
    """Simulates what warp-ctl unlock does: reset the row."""
    # Lock the IP
    for _ in range(5):
        await client.get("/api/v1/users/me", headers={"Authorization": "Bearer wrong"})

    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 403

    # Simulate unlock
    from sqlalchemy import select

    result = await db_session.execute(
        select(LoginAttempt).where(LoginAttempt.ip_address == "127.0.0.1")
    )
    attempt = result.scalar_one()
    attempt.locked = 0
    attempt.failed_count = 0
    await db_session.commit()

    # Now valid token works again
    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 200


# ── User-level lockout tests ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_locked_user_rejected_even_with_valid_key(
    client: AsyncClient, db_session: AsyncSession
):
    """A locked user is rejected even when the API key is valid."""
    user = User(email="locked@test.com", username="lockeduser", role="User", locked=1)
    db_session.add(user)
    await db_session.flush()
    raw_key = secrets.token_urlsafe(32)
    db_session.add(ApiKey(user_id=user.id, key=hash_api_key(raw_key), name="k"))
    await db_session.commit()

    resp = await client.get("/api/v1/users/me", headers=auth_headers(raw_key))
    assert resp.status_code == 403
    assert "user account locked" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_expired_key_increments_user_failed_count(
    client: AsyncClient, db_session: AsyncSession
):
    """Using an expired key counts as a per-user failure."""
    from datetime import datetime, timedelta, timezone

    user = User(email="exp@test.com", username="expuser", role="User")
    db_session.add(user)
    await db_session.flush()
    raw_key = secrets.token_urlsafe(32)
    db_session.add(
        ApiKey(
            user_id=user.id,
            key=hash_api_key(raw_key),
            name="expired",
            expires_at=datetime.now(timezone.utc) - timedelta(days=365),
        )
    )
    await db_session.commit()

    for _ in range(3):
        resp = await client.get("/api/v1/users/me", headers=auth_headers(raw_key))
        assert resp.status_code == 401

    await db_session.refresh(user)
    assert user.failed_login_count == 3
    assert user.locked == 0


@pytest.mark.asyncio
async def test_user_locked_after_max_expired_key_attempts(
    client: AsyncClient, db_session: AsyncSession
):
    """User account locks after max_login_attempts with an expired key."""
    from datetime import datetime, timedelta, timezone

    user = User(email="lockme@test.com", username="lockme", role="User")
    db_session.add(user)
    await db_session.flush()
    raw_key = secrets.token_urlsafe(32)
    db_session.add(
        ApiKey(
            user_id=user.id,
            key=hash_api_key(raw_key),
            name="expired",
            expires_at=datetime.now(timezone.utc) - timedelta(days=365),
        )
    )
    await db_session.commit()

    for _ in range(5):
        await client.get("/api/v1/users/me", headers=auth_headers(raw_key))

    await db_session.refresh(user)
    assert user.locked == 1
    assert user.failed_login_count == 5

    # Even with a fresh valid key the user stays locked
    raw_key2 = secrets.token_urlsafe(32)
    db_session.add(ApiKey(user_id=user.id, key=hash_api_key(raw_key2), name="new"))
    await db_session.commit()

    # Unlock IP first so we isolate the user lock check
    result = await db_session.execute(
        select(LoginAttempt).where(LoginAttempt.ip_address == "127.0.0.1")
    )
    attempt = result.scalar_one_or_none()
    if attempt:
        attempt.locked = 0
        attempt.failed_count = 0
        await db_session.commit()

    resp = await client.get("/api/v1/users/me", headers=auth_headers(raw_key2))
    assert resp.status_code == 403
    assert "user account locked" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_successful_auth_resets_user_counter(
    client: AsyncClient, db_session: AsyncSession
):
    """Successful auth resets user failed_login_count."""
    from datetime import datetime, timedelta, timezone

    user = User(email="reset@test.com", username="resetuser", role="User")
    db_session.add(user)
    await db_session.flush()

    # One expired key to accumulate failures
    expired_key = secrets.token_urlsafe(32)
    db_session.add(
        ApiKey(
            user_id=user.id,
            key=hash_api_key(expired_key),
            name="expired",
            expires_at=datetime.now(timezone.utc) - timedelta(days=365),
        )
    )
    # One valid key
    valid_key = secrets.token_urlsafe(32)
    db_session.add(ApiKey(user_id=user.id, key=hash_api_key(valid_key), name="valid"))
    await db_session.commit()

    for _ in range(3):
        await client.get("/api/v1/users/me", headers=auth_headers(expired_key))

    await db_session.refresh(user)
    assert user.failed_login_count == 3

    # Successful auth resets user counter
    resp = await client.get("/api/v1/users/me", headers=auth_headers(valid_key))
    assert resp.status_code == 200

    await db_session.refresh(user)
    assert user.failed_login_count == 0


@pytest.mark.asyncio
async def test_unlock_user_via_db(client: AsyncClient, db_session: AsyncSession):
    """Simulates warp-ctl user unlock: reset user locked state."""
    user = User(
        email="ulk@test.com",
        username="ulkuser",
        role="User",
        locked=1,
        failed_login_count=5,
    )
    db_session.add(user)
    await db_session.flush()
    raw_key = secrets.token_urlsafe(32)
    db_session.add(ApiKey(user_id=user.id, key=hash_api_key(raw_key), name="k"))
    await db_session.commit()

    resp = await client.get("/api/v1/users/me", headers=auth_headers(raw_key))
    assert resp.status_code == 403

    # Unlock
    user.locked = 0
    user.failed_login_count = 0
    user.locked_at = None
    await db_session.commit()

    resp = await client.get("/api/v1/users/me", headers=auth_headers(raw_key))
    assert resp.status_code == 200
