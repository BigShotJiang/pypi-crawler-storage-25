import pytest
from httpx import AsyncClient

from tests.conftest import auth_headers
from warp_server.models import User


@pytest.mark.asyncio
async def test_create_source(client: AsyncClient, user_token: str, regular_user: User):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "my-source", "user_ids": []},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "my-source"
    assert "id" in data


@pytest.mark.asyncio
async def test_get_source(client: AsyncClient, user_token: str, regular_user: User):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "test-src", "user_ids": []},
        headers=auth_headers(user_token),
    )
    source_id = resp.json()["id"]

    resp = await client.get(
        f"/api/v1/sources/{source_id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["name"] == "test-src"


@pytest.mark.asyncio
async def test_query_sources(client: AsyncClient, user_token: str, regular_user: User):
    await client.post(
        "/api/v1/sources",
        json={"name": "alpha", "user_ids": []},
        headers=auth_headers(user_token),
    )
    await client.post(
        "/api/v1/sources",
        json={"name": "beta", "user_ids": []},
        headers=auth_headers(user_token),
    )

    resp = await client.post(
        "/api/v1/sources/query", json={}, headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["total_results"] == 2


@pytest.mark.asyncio
async def test_query_sources_by_user(
    client: AsyncClient, user_token: str, regular_user: User
):
    await client.post(
        "/api/v1/sources",
        json={"name": "owned", "user_ids": []},
        headers=auth_headers(user_token),
    )

    resp = await client.post(
        "/api/v1/sources/query",
        json={"user_id": regular_user.id},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    assert resp.json()["total_results"] == 1


@pytest.mark.asyncio
async def test_update_source(client: AsyncClient, user_token: str, regular_user: User):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "original", "user_ids": []},
        headers=auth_headers(user_token),
    )
    source_id = resp.json()["id"]

    resp = await client.post(
        f"/api/v1/sources/{source_id}/",
        json={"name": "renamed"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200

    resp = await client.get(
        f"/api/v1/sources/{source_id}", headers=auth_headers(user_token)
    )
    assert resp.json()["name"] == "renamed"


@pytest.mark.asyncio
async def test_delete_source(client: AsyncClient, user_token: str, regular_user: User):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "to-delete", "user_ids": []},
        headers=auth_headers(user_token),
    )
    source_id = resp.json()["id"]

    resp = await client.delete(
        f"/api/v1/sources/{source_id}/", headers=auth_headers(user_token)
    )
    assert resp.status_code == 204

    resp = await client.get(
        f"/api/v1/sources/{source_id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_source_users(client: AsyncClient, user_token: str, regular_user: User):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "src-users", "user_ids": []},
        headers=auth_headers(user_token),
    )
    source_id = resp.json()["id"]

    resp = await client.get(
        f"/api/v1/sources/{source_id}/users", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    users = resp.json()
    assert len(users) == 1
    assert users[0]["user_id"] == regular_user.id


@pytest.mark.asyncio
async def test_source_tags(
    client: AsyncClient,
    admin_token: str,
    user_token: str,
    admin_user: User,
    regular_user: User,
):
    resp = await client.post(
        "/api/v1/sources",
        json={"name": "tagged-src", "user_ids": [admin_user.id]},
        headers=auth_headers(user_token),
    )
    source_id = resp.json()["id"]

    resp = await client.post(
        f"/api/v1/sources/{source_id}/",
        json={"tags": ["official", "stable"]},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200

    resp = await client.get(
        f"/api/v1/sources/{source_id}/tags", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    tags = resp.json()
    assert len(tags) == 2
    tag_names = {t["tag"] for t in tags}
    assert tag_names == {"official", "stable"}
