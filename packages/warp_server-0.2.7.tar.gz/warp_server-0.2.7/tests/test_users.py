import secrets

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.models import ApiKey, User


@pytest.mark.asyncio
async def test_get_current_user(
    client: AsyncClient, admin_token: str, admin_user: User
):
    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 200
    data = resp.json()
    assert data["username"] == "admin"
    assert data["role"] == "Admin"


@pytest.mark.asyncio
async def test_get_current_user_unauthorized(client: AsyncClient):
    resp = await client.get("/api/v1/users/me")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_create_user_as_admin(client: AsyncClient, admin_token: str):
    resp = await client.post(
        "/api/v1/users",
        json={"email": "new@test.com", "name": "newuser"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["username"] == "newuser"
    assert data["role"] == "User"


@pytest.mark.asyncio
async def test_create_user_as_non_admin(client: AsyncClient, user_token: str):
    resp = await client.post(
        "/api/v1/users",
        json={"email": "blocked@test.com"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_query_users(
    client: AsyncClient, admin_token: str, admin_user: User, regular_user: User
):
    resp = await client.post(
        "/api/v1/users/query", json={}, headers=auth_headers(admin_token)
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_results"] == 2
    assert len(data["items"]) == 2


@pytest.mark.asyncio
async def test_query_users_by_name(
    client: AsyncClient, admin_token: str, admin_user: User, regular_user: User
):
    resp = await client.post(
        "/api/v1/users/query",
        json={"name": "admin", "exact": True},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_results"] == 1
    assert data["items"][0]["username"] == "admin"


@pytest.mark.asyncio
async def test_get_user_by_id(client: AsyncClient, admin_token: str, admin_user: User):
    resp = await client.get(
        f"/api/v1/users/{admin_user.id}", headers=auth_headers(admin_token)
    )
    assert resp.status_code == 200
    assert resp.json()["username"] == "admin"


@pytest.mark.asyncio
async def test_get_user_not_found(
    client: AsyncClient, admin_token: str, admin_user: User
):
    resp = await client.get("/api/v1/users/9999", headers=auth_headers(admin_token))
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_change_role(client: AsyncClient, admin_token: str, regular_user: User):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/role",
        json={"role": "Admin"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    assert resp.json()["role"] == "Admin"


@pytest.mark.asyncio
async def test_change_username(
    client: AsyncClient, admin_token: str, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/username",
        json={"username": "renamed"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    assert resp.json()["username"] == "renamed"


@pytest.mark.asyncio
async def test_change_username_conflict(
    client: AsyncClient, admin_token: str, admin_user: User, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/username",
        json={"username": "admin"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 409


@pytest.mark.asyncio
async def test_delete_user(
    client: AsyncClient, admin_token: str, regular_user: User, admin_user: User
):
    resp = await client.delete(
        f"/api/v1/users/{regular_user.id}", headers=auth_headers(admin_token)
    )
    assert resp.status_code == 204
    resp = await client.get(
        f"/api/v1/users/{regular_user.id}", headers=auth_headers(admin_token)
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_api_keys_flow(client: AsyncClient, admin_token: str, admin_user: User):
    # List keys (should have the test key)
    resp = await client.get("/api/v1/users/me/keys", headers=auth_headers(admin_token))
    assert resp.status_code == 200
    assert len(resp.json()) == 1

    # Create a new key
    resp = await client.post(
        "/api/v1/users/me/keys",
        json={"name": "new-key"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 201
    new_key = resp.json()
    assert "key" in new_key

    # List again
    resp = await client.get("/api/v1/users/me/keys", headers=auth_headers(admin_token))
    assert len(resp.json()) == 2


# ── Access control tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_query_users_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User
):
    resp = await client.post(
        "/api/v1/users/query", json={}, headers=auth_headers(user_token)
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_query_users_requires_auth(client: AsyncClient):
    resp = await client.post("/api/v1/users/query", json={})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_get_user_by_id_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User, admin_user: User
):
    resp = await client.get(
        f"/api/v1/users/{admin_user.id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_get_user_by_id_requires_auth(client: AsyncClient, admin_user: User):
    resp = await client.get(f"/api/v1/users/{admin_user.id}")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_delete_user_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User, admin_user: User
):
    resp = await client.delete(
        f"/api/v1/users/{admin_user.id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_create_user_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User
):
    resp = await client.post(
        "/api/v1/users",
        json={"email": "hack@test.com"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_change_role_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/role",
        json={"role": "Admin"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_change_username_forbidden_for_non_admin(
    client: AsyncClient, user_token: str, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/username",
        json={"username": "hacked"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 403


# ── Cascade delete tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_deleting_user_cascades_api_keys(
    client: AsyncClient,
    db_session: AsyncSession,
    admin_token: str,
    admin_user: User,
    regular_user: User,
):
    # Create extra API keys for the regular user
    for i in range(3):
        key = ApiKey(
            user_id=regular_user.id,
            key=secrets.token_urlsafe(32),
            name=f"extra-key-{i}",
        )
        db_session.add(key)
    await db_session.commit()

    # Verify keys exist
    result = await db_session.execute(
        select(ApiKey).where(ApiKey.user_id == regular_user.id)
    )
    assert len(result.scalars().all()) == 3  # 3 created above

    # Delete the user
    resp = await client.delete(
        f"/api/v1/users/{regular_user.id}", headers=auth_headers(admin_token)
    )
    assert resp.status_code == 204

    # Verify all API keys are gone
    result = await db_session.execute(
        select(ApiKey).where(ApiKey.user_id == regular_user.id)
    )
    assert len(result.scalars().all()) == 0


# ── Non-admin can still access /me ───────────────────────────────────


@pytest.mark.asyncio
async def test_non_admin_can_access_own_profile(
    client: AsyncClient, user_token: str, regular_user: User
):
    resp = await client.get("/api/v1/users/me", headers=auth_headers(user_token))
    assert resp.status_code == 200
    assert resp.json()["username"] == "testuser"


@pytest.mark.asyncio
async def test_non_admin_can_manage_own_keys(
    client: AsyncClient, user_token: str, regular_user: User
):
    # List own keys
    resp = await client.get("/api/v1/users/me/keys", headers=auth_headers(user_token))
    assert resp.status_code == 200
    assert len(resp.json()) == 1

    # Create a key
    resp = await client.post(
        "/api/v1/users/me/keys",
        json={"name": "my-key"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 201


@pytest.mark.asyncio
async def test_non_admin_cannot_list_other_user_keys(
    client: AsyncClient, user_token: str, regular_user: User, admin_user: User
):
    resp = await client.get(
        f"/api/v1/users/{admin_user.id}/keys", headers=auth_headers(user_token)
    )
    assert resp.status_code == 403
