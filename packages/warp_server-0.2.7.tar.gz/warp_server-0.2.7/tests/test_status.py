import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_status(client: AsyncClient):
    resp = await client.get("/api/v1/status")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
