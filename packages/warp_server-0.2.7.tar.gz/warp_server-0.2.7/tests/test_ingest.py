"""Tests for the warp-ctl ingest CLI command."""

import uuid

import pytest
from click.testing import CliRunner
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from tests.test_warp_parser import _build_test_sig_chunk, _build_test_warp_file
from warp_server.cli import app


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    """Redirect CLI database access to a fresh temp SQLite file per test."""
    db_path = tmp_path / "test.db"
    test_engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}", echo=False)
    test_session = async_sessionmaker(test_engine, expire_on_commit=False)

    import warp_server.cli as cli_mod

    monkeypatch.setattr(cli_mod, "engine", test_engine)
    monkeypatch.setattr(cli_mod, "async_session", test_session)


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def func_guid():
    return uuid.UUID("12345678-1234-5678-1234-567812345678")


@pytest.fixture
def warp_file_bytes(func_guid):
    sig = _build_test_sig_chunk(
        func_guid,
        sym_name="ingested_func",
        comment_text="test comment",
    )
    return _build_test_warp_file(sig_data=sig)


class TestIngestCommand:
    def test_ingest_single_file(self, runner, warp_file_bytes, func_guid, tmp_path):
        """Ingest a .warp file and verify data lands in the DB."""
        warp_path = tmp_path / "test.warp"
        warp_path.write_bytes(warp_file_bytes)

        # Bootstrap a user first
        result = runner.invoke(app, ["bootstrap"])
        assert result.exit_code == 0, result.output

        result = runner.invoke(
            app,
            [
                "ingest",
                str(warp_path),
                "--source",
                "ingest-test",
                "--user-id",
                "1",
                "--name",
                "test-commit",
                "--description",
                "test desc",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "Ingesting test.warp" in result.output
        assert "Committed id=" in result.output

    def test_ingest_creates_source(self, runner, warp_file_bytes, tmp_path):
        """Ingest should auto-create a source if it doesn't exist."""
        warp_path = tmp_path / "new.warp"
        warp_path.write_bytes(warp_file_bytes)

        runner.invoke(app, ["bootstrap"])
        result = runner.invoke(
            app,
            [
                "ingest",
                str(warp_path),
                "--source",
                "brand-new-source",
                "--user-id",
                "1",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "Created source" in result.output

    def test_ingest_multiple_files(self, runner, warp_file_bytes, tmp_path):
        """Ingest multiple .warp files in one invocation."""
        paths = []
        for i in range(3):
            p = tmp_path / f"file{i}.warp"
            p.write_bytes(warp_file_bytes)
            paths.append(str(p))

        runner.invoke(app, ["bootstrap"])
        result = runner.invoke(
            app,
            [
                "ingest",
                *paths,
                "--source",
                "multi-test",
                "--user-id",
                "1",
            ],
        )
        assert result.exit_code == 0, result.output
        assert result.output.count("Committed id=") == 3

    def test_ingest_invalid_user(self, runner, warp_file_bytes, tmp_path):
        """Ingest should fail if user doesn't exist."""
        warp_path = tmp_path / "test.warp"
        warp_path.write_bytes(warp_file_bytes)

        runner.invoke(app, ["bootstrap"])
        result = runner.invoke(
            app,
            [
                "ingest",
                str(warp_path),
                "--source",
                "src",
                "--user-id",
                "999",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output

    def test_ingest_invalid_warp_file(self, runner, tmp_path):
        """Ingest should skip files that can't be parsed."""
        bad = tmp_path / "bad.warp"
        bad.write_bytes(b"not a warp file")

        runner.invoke(app, ["bootstrap"])
        result = runner.invoke(
            app,
            [
                "ingest",
                str(bad),
                "--source",
                "src",
                "--user-id",
                "1",
            ],
        )
        # Should not crash — bad files are skipped
        assert result.exit_code == 0
        assert "Failed to parse" in result.output

    def test_ingest_default_name_is_filename(self, runner, warp_file_bytes, tmp_path):
        """Without --name, commit name defaults to the filename."""
        warp_path = tmp_path / "mylib.warp"
        warp_path.write_bytes(warp_file_bytes)

        runner.invoke(app, ["bootstrap"])
        result = runner.invoke(
            app,
            [
                "ingest",
                str(warp_path),
                "--source",
                "src",
                "--user-id",
                "1",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "Committed id=" in result.output

    def test_ingest_nonexistent_file(self, runner, tmp_path):
        """Click should reject a file path that doesn't exist."""
        result = runner.invoke(
            app,
            [
                "ingest",
                str(tmp_path / "nope.warp"),
                "--source",
                "src",
                "--user-id",
                "1",
            ],
        )
        assert result.exit_code != 0

    def test_ingest_missing_required_options(self, runner, warp_file_bytes, tmp_path):
        """Missing --source or --user-id should fail."""
        warp_path = tmp_path / "test.warp"
        warp_path.write_bytes(warp_file_bytes)

        result = runner.invoke(app, ["ingest", str(warp_path)])
        assert result.exit_code != 0
