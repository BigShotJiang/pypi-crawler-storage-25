import uuid

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.models import (
    Commit,
    Function,
    FunctionComment,
    FunctionConstraint,
    Source,
    SourceUser,
    Symbol,
    Target,
    User,
)


@pytest.fixture
async def populated_db(db_session: AsyncSession, regular_user: User):
    """Create a source, target, commit, symbol, and function for testing."""
    source = Source(name="test-src")
    db_session.add(source)
    await db_session.flush()

    db_session.add(SourceUser(source_id=source.id, user_id=regular_user.id))

    target = Target(platform="linux", arch="x86_64")
    db_session.add(target)
    await db_session.flush()

    commit = Commit(source_id=source.id, user_id=regular_user.id, name="initial")
    db_session.add(commit)
    await db_session.flush()

    symbol = Symbol(name="main", symbol_class="Function", modifier="Exported")
    db_session.add(symbol)
    await db_session.flush()

    func_guid = uuid.uuid4()
    func = Function(
        commit_id=commit.id,
        target_id=target.id,
        source_id=source.id,
        guid=func_guid,
        symbol_id=symbol.id,
        data=b"\x00\x01\x02\x03",
    )
    db_session.add(func)
    await db_session.flush()

    comment = FunctionComment(function_id=func.id, text="entry point", byte_offset=0)
    db_session.add(comment)

    constraint = FunctionConstraint(
        function_id=func.id, guid=uuid.uuid4(), byte_offset=4
    )
    db_session.add(constraint)

    await db_session.commit()
    return {
        "source": source,
        "target": target,
        "commit": commit,
        "symbol": symbol,
        "function": func,
        "func_guid": func_guid,
    }


@pytest.mark.asyncio
async def test_query_functions(client: AsyncClient, user_token: str, populated_db):
    resp = await client.post(
        "/api/v1/functions/query", json={}, headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_results"] == 1
    assert data["items"][0]["guid"] == str(populated_db["func_guid"])


@pytest.mark.asyncio
async def test_query_functions_by_guid(
    client: AsyncClient, user_token: str, populated_db
):
    guid = str(populated_db["func_guid"])
    resp = await client.post(
        "/api/v1/functions/query",
        json={"guids": [guid]},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    assert resp.json()["total_results"] == 1


@pytest.mark.asyncio
async def test_query_functions_source(
    client: AsyncClient, user_token: str, populated_db
):
    guid = str(populated_db["func_guid"])
    resp = await client.post(
        "/api/v1/functions/query/source",
        json={"guids": [guid]},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    data = resp.json()
    source_id = str(populated_db["source"].id)
    assert source_id in data
    assert guid in data[source_id]


@pytest.mark.asyncio
async def test_get_function_by_id(client: AsyncClient, user_token: str, populated_db):
    func_id = populated_db["function"].id
    resp = await client.get(
        f"/api/v1/functions/{func_id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["id"] == func_id


@pytest.mark.asyncio
async def test_get_function_data(client: AsyncClient, user_token: str, populated_db):
    func_id = populated_db["function"].id
    resp = await client.get(
        f"/api/v1/functions/{func_id}/data", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.content == b"\x00\x01\x02\x03"


@pytest.mark.asyncio
async def test_get_function_comments(
    client: AsyncClient, user_token: str, populated_db
):
    func_id = populated_db["function"].id
    resp = await client.get(
        f"/api/v1/functions/{func_id}/comments", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    comments = resp.json()
    assert len(comments) == 1
    assert comments[0]["text"] == "entry point"


@pytest.mark.asyncio
async def test_get_function_constraints(
    client: AsyncClient, user_token: str, populated_db
):
    func_id = populated_db["function"].id
    resp = await client.get(
        f"/api/v1/functions/{func_id}/constraints", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    constraints = resp.json()
    assert len(constraints) == 1
    assert constraints[0]["byte_offset"] == 4


@pytest.mark.asyncio
async def test_get_function_symbol(client: AsyncClient, user_token: str, populated_db):
    func_id = populated_db["function"].id
    resp = await client.get(
        f"/api/v1/functions/{func_id}/symbol", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200
    assert resp.json()["name"] == "main"


@pytest.mark.asyncio
async def test_get_function_not_found(
    client: AsyncClient, user_token: str, populated_db
):
    resp = await client.get("/api/v1/functions/9999", headers=auth_headers(user_token))
    assert resp.status_code == 404
