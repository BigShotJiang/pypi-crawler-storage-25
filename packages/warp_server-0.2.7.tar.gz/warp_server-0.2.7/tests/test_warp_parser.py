"""Tests for warp binary parsing and DB ingestion."""

import base64
import os
import sys
import uuid

import flatbuffers
import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

# Add generated FlatBuffer code to path before importing it.
_gen_dir = os.path.join(
    os.path.dirname(__file__), "..", "src", "warp_server", "gen_flatbuffers"
)
if _gen_dir not in sys.path:
    sys.path.insert(0, _gen_dir)

import SigBin.Constraint as ConstraintMod  # noqa: E402
import SigBin.ConstraintGUID as ConstraintGUIDMod  # noqa: E402
import SigBin.Function as SigFuncMod  # noqa: E402
import SigBin.FunctionComment as CommentMod  # noqa: E402
import SigBin.FunctionGUID as FuncGUIDMod  # noqa: E402
import SigBin.SignatureChunk as SigChunkMod  # noqa: E402
import SymbolBin.Symbol as SymbolMod  # noqa: E402
import TargetBin.Target as TargetMod  # noqa: E402
import TypeBin.BitWidth as BitWidthMod  # noqa: E402
import TypeBin.ComputedType as ComputedTypeMod  # noqa: E402
import TypeBin.Integer as IntMod  # noqa: E402
import TypeBin.Type as TypeMod_  # noqa: E402
import TypeBin.TypeChunk as TypeChunkMod  # noqa: E402
import TypeBin.TypeGUID as TypeGUIDMod  # noqa: E402
import Warp.Chunk as ChunkMod  # noqa: E402
import Warp.ChunkHeader as ChunkHeaderMod  # noqa: E402
import Warp.File as WarpFileMod  # noqa: E402
import Warp.FileHeader as FileHeaderMod  # noqa: E402
from SymbolBin.SymbolClass import SymbolClass  # noqa: E402
from SymbolBin.SymbolModifiers import SymbolModifiers  # noqa: E402
from TypeBin.TypeClass import TypeClass  # noqa: E402
from Warp.ChunkType import ChunkType  # noqa: E402
from Warp.CompressionType import CompressionType  # noqa: E402

from tests.conftest import auth_headers  # noqa: E402
from warp_server.models import (  # noqa: E402
    Commit,
    Function,
    FunctionComment,
    FunctionConstraint,
    Source,
    SourceUser,
    Symbol,
    Target,
    User,
)
from warp_server.models import Type as TypeModel  # noqa: E402
from warp_server.warp_parser import (  # noqa: E402
    build_warp_file,
    parse_warp_file,
)


def _build_test_sig_chunk(
    func_guid: uuid.UUID,
    sym_name: str = "my_func",
    sym_class: int = SymbolClass.Function,
    sym_mod: int = SymbolModifiers.Exported,
    constraint_guid: uuid.UUID | None = None,
    comment_text: str | None = None,
) -> bytes:
    """Build a SignatureChunk FlatBuffer with one function."""
    builder = flatbuffers.Builder(1024)

    # Symbol
    name_off = builder.CreateString(sym_name)
    SymbolMod.SymbolStart(builder)
    SymbolMod.SymbolAddName(builder, name_off)
    SymbolMod.SymbolAddModifiers(builder, sym_mod)
    SymbolMod.SymbolAddClass(builder, sym_class)
    symbol_off = SymbolMod.SymbolEnd(builder)

    # Constraint vector (optional)
    constraints_vec = None
    if constraint_guid is not None:
        ConstraintMod.ConstraintStart(builder)
        cg = ConstraintGUIDMod.CreateConstraintGuid(
            builder, list(constraint_guid.bytes)
        )
        ConstraintMod.ConstraintAddGuid(builder, cg)
        ConstraintMod.ConstraintAddOffset(builder, 42)
        c_off = ConstraintMod.ConstraintEnd(builder)
        SigFuncMod.FunctionStartConstraintsVector(builder, 1)
        builder.PrependUOffsetTRelative(c_off)
        constraints_vec = builder.EndVector()

    # Comment vector (optional)
    comments_vec = None
    if comment_text is not None:
        txt_off = builder.CreateString(comment_text)
        CommentMod.FunctionCommentStart(builder)
        CommentMod.FunctionCommentAddOffset(builder, 0)
        CommentMod.FunctionCommentAddText(builder, txt_off)
        cm_off = CommentMod.FunctionCommentEnd(builder)
        SigFuncMod.FunctionStartCommentsVector(builder, 1)
        builder.PrependUOffsetTRelative(cm_off)
        comments_vec = builder.EndVector()

    # Function
    SigFuncMod.FunctionStart(builder)
    fg = FuncGUIDMod.CreateFunctionGuid(builder, list(func_guid.bytes))
    SigFuncMod.FunctionAddGuid(builder, fg)
    SigFuncMod.FunctionAddSymbol(builder, symbol_off)
    if constraints_vec is not None:
        SigFuncMod.FunctionAddConstraints(builder, constraints_vec)
    if comments_vec is not None:
        SigFuncMod.FunctionAddComments(builder, comments_vec)
    func_off = SigFuncMod.FunctionEnd(builder)

    SigChunkMod.SignatureChunkStartFunctionsVector(builder, 1)
    builder.PrependUOffsetTRelative(func_off)
    funcs_vec = builder.EndVector()

    SigChunkMod.SignatureChunkStart(builder)
    SigChunkMod.SignatureChunkAddFunctions(builder, funcs_vec)
    chunk_off = SigChunkMod.SignatureChunkEnd(builder)

    builder.Finish(chunk_off)
    return bytes(builder.Output())


def _build_test_type_chunk(type_guid: uuid.UUID, type_name: str = "my_int") -> bytes:
    """Build a TypeChunk FlatBuffer with one integer type."""
    builder = flatbuffers.Builder(512)

    # Integer type with 32-bit width
    IntMod.IntegerStart(builder)
    bw = BitWidthMod.CreateBitWidth(builder, 32)
    IntMod.IntegerAddWidth(builder, bw)
    IntMod.IntegerAddSigned(builder, True)
    int_off = IntMod.IntegerEnd(builder)

    name_off = builder.CreateString(type_name)
    TypeMod_.TypeStart(builder)
    TypeMod_.TypeAddName(builder, name_off)
    TypeMod_.TypeAddClassType(builder, TypeClass.Integer)
    TypeMod_.TypeAddClass(builder, int_off)
    TypeMod_.TypeAddConfidence(builder, 255)
    type_off = TypeMod_.TypeEnd(builder)

    ComputedTypeMod.ComputedTypeStart(builder)
    tg = TypeGUIDMod.CreateTypeGuid(builder, list(type_guid.bytes))
    ComputedTypeMod.ComputedTypeAddGuid(builder, tg)
    ComputedTypeMod.ComputedTypeAddType(builder, type_off)
    ct_off = ComputedTypeMod.ComputedTypeEnd(builder)

    TypeChunkMod.TypeChunkStartTypesVector(builder, 1)
    builder.PrependUOffsetTRelative(ct_off)
    types_vec = builder.EndVector()

    TypeChunkMod.TypeChunkStart(builder)
    TypeChunkMod.TypeChunkAddTypes(builder, types_vec)
    tc_off = TypeChunkMod.TypeChunkEnd(builder)

    builder.Finish(tc_off)
    return bytes(builder.Output())


def _build_test_warp_file(
    sig_data: bytes | None = None,
    type_data: bytes | None = None,
    platform: str = "linux",
    arch: str = "x86_64",
) -> bytes:
    """Build a complete Warp File with optional signature and type chunks."""
    builder = flatbuffers.Builder(4096)

    chunk_offsets = []

    for chunk_type, data in [
        (ChunkType.Signatures, sig_data),
        (ChunkType.Types, type_data),
    ]:
        if data is None:
            continue

        data_vec = builder.CreateByteVector(data)

        plat_off = builder.CreateString(platform)
        arch_off = builder.CreateString(arch)
        TargetMod.TargetStart(builder)
        TargetMod.TargetAddArchitecture(builder, arch_off)
        TargetMod.TargetAddPlatform(builder, plat_off)
        target_off = TargetMod.TargetEnd(builder)

        ChunkHeaderMod.ChunkHeaderStart(builder)
        ChunkHeaderMod.ChunkHeaderAddVersion(builder, 0)
        ChunkHeaderMod.ChunkHeaderAddType(builder, chunk_type)
        ChunkHeaderMod.ChunkHeaderAddCompressionType(builder, CompressionType.None_)
        ChunkHeaderMod.ChunkHeaderAddSize(builder, len(data))
        ChunkHeaderMod.ChunkHeaderAddTarget(builder, target_off)
        header_off = ChunkHeaderMod.ChunkHeaderEnd(builder)

        ChunkMod.ChunkStart(builder)
        ChunkMod.ChunkAddHeader(builder, header_off)
        ChunkMod.ChunkAddData(builder, data_vec)
        chunk_offsets.append(ChunkMod.ChunkEnd(builder))

    WarpFileMod.FileStartChunksVector(builder, len(chunk_offsets))
    for off in reversed(chunk_offsets):
        builder.PrependUOffsetTRelative(off)
    chunks_vec = builder.EndVector()

    FileHeaderMod.FileHeaderStart(builder)
    FileHeaderMod.FileHeaderAddVersion(builder, 1)
    fh_off = FileHeaderMod.FileHeaderEnd(builder)

    WarpFileMod.FileStart(builder)
    WarpFileMod.FileAddHeader(builder, fh_off)
    WarpFileMod.FileAddChunks(builder, chunks_vec)
    file_off = WarpFileMod.FileEnd(builder)

    builder.Finish(file_off)
    return bytes(builder.Output())


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def func_guid():
    return uuid.UUID("12345678-1234-5678-1234-567812345678")


@pytest.fixture
def constraint_guid():
    return uuid.UUID("abcdefab-cdef-abcd-efab-cdefabcdefab")


@pytest.fixture
def type_guid():
    return uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")


@pytest.fixture
def warp_sig_only(func_guid, constraint_guid):
    sig = _build_test_sig_chunk(
        func_guid,
        sym_name="test_function",
        constraint_guid=constraint_guid,
        comment_text="entry point",
    )
    return _build_test_warp_file(sig_data=sig)


@pytest.fixture
def warp_type_only(type_guid):
    tc = _build_test_type_chunk(type_guid, type_name="int32_t")
    return _build_test_warp_file(type_data=tc)


@pytest.fixture
def warp_full(func_guid, constraint_guid, type_guid):
    sig = _build_test_sig_chunk(
        func_guid,
        sym_name="main",
        sym_mod=SymbolModifiers.Exported,
        constraint_guid=constraint_guid,
        comment_text="hello",
    )
    tc = _build_test_type_chunk(type_guid, type_name="uint32")
    return _build_test_warp_file(sig_data=sig, type_data=tc)


@pytest.fixture
async def writable_source(db_session: AsyncSession, regular_user: User):
    source = Source(name="warp-src")
    db_session.add(source)
    await db_session.flush()
    db_session.add(SourceUser(source_id=source.id, user_id=regular_user.id))
    await db_session.commit()
    return source


# =====================================================================
# Unit tests — parser
# =====================================================================


class TestParseWarpFile:
    def test_parse_sig_chunk(self, warp_sig_only, func_guid, constraint_guid):
        chunks = parse_warp_file(warp_sig_only)
        assert len(chunks) == 1

        chunk = chunks[0]
        assert chunk.target.platform == "linux"
        assert chunk.target.architecture == "x86_64"
        assert len(chunk.functions) == 1

        fn = chunk.functions[0]
        assert fn.guid == func_guid
        assert fn.symbol.name == "test_function"
        assert fn.symbol.symbol_class == "Function"
        assert fn.symbol.modifier == "Exported"

        assert len(fn.constraints) == 1
        assert fn.constraints[0].guid == constraint_guid
        assert fn.constraints[0].byte_offset == 42

        assert len(fn.comments) == 1
        assert fn.comments[0].text == "entry point"
        assert fn.comments[0].byte_offset == 0

        # data must be non-empty bytes
        assert len(fn.data) > 0

    def test_parse_type_chunk(self, warp_type_only, type_guid):
        chunks = parse_warp_file(warp_type_only)
        assert len(chunks) == 1

        chunk = chunks[0]
        assert len(chunk.types) == 1

        ty = chunk.types[0]
        assert ty.guid == type_guid
        assert ty.name == "int32_t"
        assert len(ty.data) > 0

    def test_parse_full_file(self, warp_full, func_guid, type_guid):
        chunks = parse_warp_file(warp_full)
        assert len(chunks) == 2  # sig + type

        sig_chunk = next(c for c in chunks if c.functions)
        type_chunk = next(c for c in chunks if c.types and not c.functions)

        assert len(sig_chunk.functions) == 1
        assert sig_chunk.functions[0].guid == func_guid

        assert len(type_chunk.types) == 1
        assert type_chunk.types[0].guid == type_guid

    def test_parse_empty_file(self):
        """An empty warp file (no chunks) should return an empty list."""
        builder = flatbuffers.Builder(128)
        FileHeaderMod.FileHeaderStart(builder)
        FileHeaderMod.FileHeaderAddVersion(builder, 1)
        fh = FileHeaderMod.FileHeaderEnd(builder)
        WarpFileMod.FileStart(builder)
        WarpFileMod.FileAddHeader(builder, fh)
        f = WarpFileMod.FileEnd(builder)
        builder.Finish(f)
        data = bytes(builder.Output())

        chunks = parse_warp_file(data)
        assert chunks == []

    def test_function_data_roundtrip(self, warp_sig_only, func_guid):
        """Stored function data should be parseable as a standalone FlatBuffer."""
        chunks = parse_warp_file(warp_sig_only)
        fn = chunks[0].functions[0]

        # Parse the standalone function bytes
        fb_func = SigFuncMod.Function.GetRootAs(bytearray(fn.data))
        assert uuid.UUID(bytes=bytes(fb_func.Guid().Value())) == func_guid
        sym = fb_func.Symbol()
        assert sym.Name().decode("utf-8") == "test_function"

    def test_type_data_roundtrip(self, warp_type_only, type_guid):
        """Stored type data should be parseable as a standalone FlatBuffer."""
        chunks = parse_warp_file(warp_type_only)
        ty = chunks[0].types[0]

        fb_type = TypeMod_.Type.GetRootAs(bytearray(ty.data))
        assert fb_type.Name().decode("utf-8") == "int32_t"
        assert fb_type.ClassType() == TypeClass.Integer


class TestBuildWarpFile:
    def test_build_from_function_data(self, warp_sig_only, func_guid):
        chunks = parse_warp_file(warp_sig_only)
        fn_data = [chunks[0].functions[0].data]

        warp_bytes = build_warp_file(fn_data, [])
        assert len(warp_bytes) > 0

        # Should be parseable as a WarpFile
        wf = WarpFileMod.File.GetRootAs(bytearray(warp_bytes))
        assert wf.ChunksLength() >= 1

    def test_build_empty(self):
        warp_bytes = build_warp_file([], [])
        wf = WarpFileMod.File.GetRootAs(bytearray(warp_bytes))
        assert wf.Header() is not None


# =====================================================================
# Integration tests — file upload with warp parsing
# =====================================================================


class TestFileUploadParsing:
    @pytest.mark.asyncio
    async def test_push_warp_file_creates_function(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_sig_only: bytes,
        func_guid: uuid.UUID,
        db_session: AsyncSession,
    ):
        b64 = base64.b64encode(warp_sig_only).decode()
        resp = await client.post(
            "/api/v1/files/json",
            json={
                "name": "test-commit",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )
        assert resp.status_code == 200
        commit_id = resp.json()["commit_id"]

        # Verify commit
        result = await db_session.execute(select(Commit).where(Commit.id == commit_id))
        commit = result.scalar_one()
        assert commit.name == "test-commit"

        # Verify target was created
        result = await db_session.execute(
            select(Target).where(Target.platform == "linux", Target.arch == "x86_64")
        )
        target = result.scalar_one()
        assert target is not None

        # Verify symbol was created
        result = await db_session.execute(
            select(Symbol).where(Symbol.name == "test_function")
        )
        sym = result.scalar_one()
        assert sym.symbol_class == "Function"
        assert sym.modifier == "Exported"

        # Verify function was created
        result = await db_session.execute(
            select(Function).where(Function.guid == func_guid)
        )
        func = result.scalar_one()
        assert func.commit_id == commit_id
        assert func.source_id == writable_source.id
        assert func.target_id == target.id
        assert func.symbol_id == sym.id
        assert len(func.data) > 0

        # Verify constraints
        result = await db_session.execute(
            select(FunctionConstraint).where(FunctionConstraint.function_id == func.id)
        )
        constraints = result.scalars().all()
        assert len(constraints) == 1
        assert constraints[0].byte_offset == 42

        # Verify comments
        result = await db_session.execute(
            select(FunctionComment).where(FunctionComment.function_id == func.id)
        )
        comments = result.scalars().all()
        assert len(comments) == 1
        assert comments[0].text == "entry point"

    @pytest.mark.asyncio
    async def test_push_warp_file_creates_types(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_type_only: bytes,
        type_guid: uuid.UUID,
        db_session: AsyncSession,
    ):
        b64 = base64.b64encode(warp_type_only).decode()
        resp = await client.post(
            "/api/v1/files/json",
            json={
                "name": "type-commit",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )
        assert resp.status_code == 200

        result = await db_session.execute(
            select(TypeModel).where(TypeModel.id == type_guid)
        )
        ty = result.scalar_one()
        assert ty.name == "int32_t"
        assert len(ty.data) > 0

    @pytest.mark.asyncio
    async def test_push_full_warp_file(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_full: bytes,
        func_guid: uuid.UUID,
        type_guid: uuid.UUID,
        db_session: AsyncSession,
    ):
        b64 = base64.b64encode(warp_full).decode()
        resp = await client.post(
            "/api/v1/files/json",
            json={
                "name": "full-commit",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )
        assert resp.status_code == 200

        # Both function and types should be created
        result = await db_session.execute(
            select(Function).where(Function.guid == func_guid)
        )
        assert result.scalar_one() is not None

        result = await db_session.execute(
            select(TypeModel).where(TypeModel.id == type_guid)
        )
        assert result.scalar_one() is not None

    @pytest.mark.asyncio
    async def test_push_invalid_warp_data(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
    ):
        b64 = base64.b64encode(b"not a warp file").decode()
        resp = await client.post(
            "/api/v1/files/json",
            json={
                "name": "bad-commit",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_function_data_endpoint_after_push(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_sig_only: bytes,
        func_guid: uuid.UUID,
        db_session: AsyncSession,
    ):
        """After pushing a warp file, function data should be retrievable."""
        b64 = base64.b64encode(warp_sig_only).decode()
        await client.post(
            "/api/v1/files/json",
            json={
                "name": "data-test",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )

        # Find the function
        result = await db_session.execute(
            select(Function).where(Function.guid == func_guid)
        )
        func = result.scalar_one()

        # Get data via API
        resp = await client.get(
            f"/api/v1/functions/{func.id}/data", headers=auth_headers(user_token)
        )
        assert resp.status_code == 200
        assert len(resp.content) > 0

        # Data should be a valid function FlatBuffer
        fb_func = SigFuncMod.Function.GetRootAs(bytearray(resp.content))
        assert fb_func.Symbol() is not None

    @pytest.mark.asyncio
    async def test_symbols_queryable_after_push(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_sig_only: bytes,
    ):
        b64 = base64.b64encode(warp_sig_only).decode()
        await client.post(
            "/api/v1/files/json",
            json={
                "name": "sym-test",
                "source": str(writable_source.id),
                "file": b64,
            },
            headers=auth_headers(user_token),
        )

        resp = await client.post(
            "/api/v1/symbols/query",
            json={"name": "test_function", "exact": True},
            headers=auth_headers(user_token),
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_results"] == 1
        assert data["items"][0]["name"] == "test_function"

    @pytest.mark.asyncio
    async def test_duplicate_symbol_reuse(
        self,
        client: AsyncClient,
        user_token: str,
        writable_source: Source,
        warp_sig_only: bytes,
        db_session: AsyncSession,
    ):
        """Pushing the same file twice should reuse existing symbols."""
        b64 = base64.b64encode(warp_sig_only).decode()
        for _ in range(2):
            await client.post(
                "/api/v1/files/json",
                json={
                    "name": "dup-test",
                    "source": str(writable_source.id),
                    "file": b64,
                },
                headers=auth_headers(user_token),
            )

        result = await db_session.execute(
            select(Symbol).where(Symbol.name == "test_function")
        )
        symbols = result.scalars().all()
        assert len(symbols) == 1  # reused, not duplicated
