import base64

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from tests.test_warp_parser import _build_test_sig_chunk, _build_test_warp_file
from warp_server.models import Source, SourceUser, User


@pytest.fixture
async def writable_source(db_session: AsyncSession, regular_user: User):
    source = Source(name="upload-src")
    db_session.add(source)
    await db_session.flush()
    db_session.add(SourceUser(source_id=source.id, user_id=regular_user.id))
    await db_session.commit()
    return source


@pytest.mark.asyncio
async def test_push_file_json(
    client: AsyncClient, user_token: str, writable_source: Source
):
    import uuid

    func_guid = uuid.UUID("12345678-1234-5678-1234-567812345678")
    sig_data = _build_test_sig_chunk(func_guid)
    warp_bytes = _build_test_warp_file(sig_data=sig_data)
    file_data = base64.b64encode(warp_bytes).decode()
    resp = await client.post(
        "/api/v1/files/json",
        json={
            "name": "test-upload",
            "source": str(writable_source.id),
            "file": file_data,
            "description": "test commit",
        },
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "commit_id" in data
    assert isinstance(data["commit_id"], int)


@pytest.mark.asyncio
async def test_push_file_json_unauthorized(
    client: AsyncClient, writable_source: Source
):
    file_data = base64.b64encode(b"data").decode()
    resp = await client.post(
        "/api/v1/files/json",
        json={
            "name": "test",
            "source": str(writable_source.id),
            "file": file_data,
        },
    )
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_push_file_json_bad_base64(
    client: AsyncClient, user_token: str, writable_source: Source
):
    resp = await client.post(
        "/api/v1/files/json",
        json={
            "name": "test",
            "source": str(writable_source.id),
            "file": "not-valid-base64!!!",
        },
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 400
