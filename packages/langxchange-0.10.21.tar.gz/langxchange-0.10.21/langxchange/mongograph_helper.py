import os
import logging
import asyncio
import time
import json
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Union, Any, Tuple
from dataclasses import dataclass, field

try:
    from pymongo import MongoClient, errors, UpdateOne
    from pymongo.collection import Collection
    from pymongo.database import Database
except ImportError:
    raise ImportError("Please install pymongo: pip install pymongo")

from concurrent.futures import ThreadPoolExecutor

try:
    from motor.motor_asyncio import AsyncIOMotorClient
except ImportError:
    # Async support is optional but recommended
    AsyncIOMotorClient = None

@dataclass
class MongoGraphConfig:
    """Configuration class for MongoDB Graph helper."""
    host: str = "127.0.0.1"
    port: int = 27017
    username: str = ""
    password: str = ""
    database: str = "graph_db"
    node_collection: str = "graph_nodes"
    edge_collection: str = "graph_edges"
    uri: Optional[str] = None
    auth_source: Optional[str] = None
    connect_timeout_ms: int = 5000
    socket_timeout_ms: int = 5000
    max_pool_size: int = 50
    enable_caching: bool = True
    cache_ttl: int = 3600
    log_level: str = "INFO"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MongoGraphConfig":
        """Create a config from a dictionary."""
        uri = data.get("uri") or data.get("host_url") or data.get("connection_string")
        host = data.get("host") or "127.0.0.1"
        port = int(data.get("port") or 27017)
        auth_source = data.get("auth_source") or data.get("authSource") or data.get("auth_db")
        
        # Smart default for auth_source
        if not auth_source and (data.get("username") == "admin" or data.get("user") == "admin"):
            auth_source = "admin"

        return cls(
            host=host,
            port=port,
            uri=uri,
            username=data.get("username") or data.get("user") or "",
            password=data.get("password") or data.get("pass") or "",
            database=data.get("database") or data.get("db_name") or "graph_db",
            node_collection=data.get("node_collection") or "graph_nodes",
            edge_collection=data.get("edge_collection") or "graph_edges",
            auth_source=auth_source,
            max_pool_size=data.get("max_pool_size", 50),
        )

@dataclass
class CacheEntry:
    """Cache entry with TTL support."""
    data: Any
    created_at: datetime
    ttl: int

    def is_expired(self) -> bool:
        return datetime.now() > self.created_at + timedelta(seconds=self.ttl)




class MongoGraphHelper:
    """
    MongoDB Graph Helper for LangXchange.
    Implements a property graph model using two MongoDB collections: nodes and edges.
    """

    def __init__(self, config: Optional[MongoGraphConfig] = None):
        self.config = config or MongoGraphConfig()
        self._client: Optional[MongoClient] = None
        self._async_client: Optional[Any] = None
        self._db: Optional[Database] = None
        self._async_db: Optional[Any] = None
        self._setup_logging()
        self._cache: Dict[str, CacheEntry] = {}

    def _setup_logging(self):
        logging.basicConfig(
            level=getattr(logging, self.config.log_level.upper(), logging.INFO),
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )
        self.logger = logging.getLogger(self.__class__.__name__)

    def _get_connection_uri(self) -> str:
        import urllib.parse
        
        # If no base URI, build it from scratch
        if not self.config.uri:
            # Properly URL encode username and password
            user = urllib.parse.quote_plus(self.config.username) if self.config.username else ""
            password = urllib.parse.quote_plus(self.config.password) if self.config.password else ""
            
            if user and password:
                uri = f"mongodb://{user}:{password}@{self.config.host}:{self.config.port}/{self.config.database}"
            else:
                uri = f"mongodb://{self.config.host}:{self.config.port}/{self.config.database}"
                
            if self.config.auth_source:
                separator = "&" if "?" in uri else "?"
                uri += f"{separator}authSource={self.config.auth_source}"
                
            return uri

        # If URI is provided, allow individual fields to override components
        # This is useful when the URI contains placeholders (like from a database record)
        try:
            parsed = urllib.parse.urlparse(self.config.uri)
            if parsed.scheme != "mongodb" and parsed.scheme != "mongodb+srv":
                return self.config.uri # Fallback to raw if not MongoDB

            netloc = parsed.netloc
            # Check for existing user:pass
            current_user = ""
            current_pass = ""
            host_port = netloc
            
            if "@" in netloc:
                auth_part, host_port = netloc.split("@", 1)
                if ":" in auth_part:
                    current_user, current_pass = auth_part.split(":", 1)
                else:
                    current_user = auth_part

            # Override with explicit config if provided
            final_user = urllib.parse.quote_plus(self.config.username) if self.config.username else current_user
            final_pass = urllib.parse.quote_plus(self.config.password) if self.config.password else current_pass
            
            # Reconstruct netloc
            if final_user and final_pass:
                new_netloc = f"{final_user}:{final_pass}@{host_port}"
            elif final_user:
                new_netloc = f"{final_user}@{host_port}"
            else:
                new_netloc = host_port
                
            rebuilt = parsed._replace(netloc=new_netloc)
            uri = urllib.parse.urlunparse(rebuilt)
            
            # Ensure authSource is present if specified
            if self.config.auth_source and "authSource=" not in uri:
                separator = "&" if "?" in uri else "?"
                uri += f"{separator}authSource={self.config.auth_source}"
                
            return uri
        except Exception as e:
            self.logger.warning(f"Error parsing connection URI: {e}. Using raw URI.")
            return self.config.uri

    def connect(self) -> "MongoGraphHelper":
        """Establish synchronous connection to MongoDB."""
        if self._client is None:
            uri = self._get_connection_uri()
            try:
                self._client = MongoClient(
                    uri,
                    connectTimeoutMS=self.config.connect_timeout_ms,
                    socketTimeoutMS=self.config.socket_timeout_ms,
                    maxPoolSize=self.config.max_pool_size
                )
                # Test connection using specific database
                self._client[self.config.database].command('ping')
                self._db = self._client[self.config.database]
                self._setup_indexes()
                self.logger.info(f"Connected to MongoDB Graph at {self.config.host}")
            except Exception as e:
                self.logger.error(f"Failed to connect to MongoDB: {e}")
                raise ConnectionError(f"Failed to connect to MongoDB: {e}")
        return self

    async def connect_async(self) -> "MongoGraphHelper":
        """Establish asynchronous connection to MongoDB."""
        if self._async_client is None:
            if AsyncIOMotorClient is None:
                raise ImportError("motor is required for async support. Install with: pip install motor")
            
            uri = self._get_connection_uri()
            try:
                self._async_client = AsyncIOMotorClient(
                    uri,
                    connectTimeoutMS=self.config.connect_timeout_ms,
                    socketTimeoutMS=self.config.socket_timeout_ms,
                    maxPoolSize=self.config.max_pool_size
                )
                # Test connection using specific database
                await self._async_client[self.config.database].command('ping')
                self._async_db = self._async_client[self.config.database]
                await self._setup_indexes_async()
                self.logger.info(f"Async connected to MongoDB Graph at {self.config.host}")
            except Exception as e:
                self.logger.error(f"Failed to async connect to MongoDB: {e}")
                raise ConnectionError(f"Failed to async connect to MongoDB: {e}")
        return self

    def close(self):
        """Close connections."""
        if self._client:
            self._client.close()
            self._client = None
            self._db = None
        self.logger.info("MongoDB Graph connections closed")

    async def close_async(self):
        """Close async connections."""
        if self._async_client:
            self._async_client.close()
            self._async_client = None
            self._async_db = None
        self.logger.info("Async MongoDB Graph connections closed")

    def _setup_indexes(self):
        """Setup necessary indexes for graph operations with managed naming and conflict resolution."""
        if self._db is not None:
            nodes = self._db[self.config.node_collection]
            edges = self._db[self.config.edge_collection]
            
            def safe_create(collection, keys, name, unique=False, partial_filter=None):
                kwargs = {"unique": unique, "background": True, "name": name}
                if partial_filter:
                    kwargs["partialFilterExpression"] = partial_filter
                try:
                    collection.create_index(keys, **kwargs)
                except errors.OperationFailure as e:
                    if e.code == 85: # IndexOptionsConflict
                        import re
                        match = re.search(r"different name: ([\w\-.]+)", str(e))
                        conflicting_name = match.group(1) if match else None
                        if conflicting_name:
                            try:
                                collection.drop_index(conflicting_name)
                                collection.create_index(keys, **kwargs)
                                return
                            except: pass
                    raise

            # Cleanup legacy unique indexes
            for coll, name in [(nodes, "id_1_label_1"), (edges, "from_id_1_to_id_1_type_1")]:
                try: coll.drop_index(name)
                except: pass

            # Node indexes (Managed names)
            # Use partial filter to handle documents that might have null names (e.g. legacy or DocumentChunks)
            safe_create(
                nodes, 
                [("name", 1), ("company_id", 1), ("label", 1)], 
                name="nodes_name_company_label_unique", 
                unique=True,
                partial_filter={"name": {"$exists": True}}
            )
            safe_create(nodes, "company_id", name="nodes_company_id")
            
            # Edge indexes (Managed names)
            safe_create(edges, "from_id", name="edges_from_id")
            safe_create(edges, "to_id", name="edges_to_id")
            safe_create(edges, "company_id", name="edges_company_id")
            safe_create(edges, [("from_id", 1), ("to_id", 1), ("type", 1), ("company_id", 1)], 
                        name="edges_from_to_type_company_unique", unique=True)

    async def _setup_indexes_async(self):
        """Setup necessary indexes for graph operations asynchronously with managed naming."""
        if self._async_db is not None:
            nodes = self._async_db[self.config.node_collection]
            edges = self._async_db[self.config.edge_collection]
            
            async def safe_create_async(collection, keys, name, unique=False, partial_filter=None):
                kwargs = {"unique": unique, "background": True, "name": name}
                if partial_filter:
                    kwargs["partialFilterExpression"] = partial_filter
                try:
                    await collection.create_index(keys, **kwargs)
                except errors.OperationFailure as e:
                    if e.code == 85:
                        import re
                        match = re.search(r"different name: ([\w\-.]+)", str(e))
                        conflicting_name = match.group(1) if match else None
                        if conflicting_name:
                            try:
                                await collection.drop_index(conflicting_name)
                                await collection.create_index(keys, **kwargs)
                                return
                            except: pass
                    raise

            # Cleanup legacy unique indexes
            try: await nodes.drop_index("id_1_label_1")
            except: pass
            try: await edges.drop_index("from_id_1_to_id_1_type_1")
            except: pass

            # Managed naming consistency
            await safe_create_async(
                nodes, 
                [("name", 1), ("company_id", 1), ("label", 1)], 
                name="nodes_name_company_label_unique", 
                unique=True,
                partial_filter={"name": {"$exists": True}}
            )
            await safe_create_async(edges, "from_id", name="edges_from_id")
            await safe_create_async(edges, "to_id", name="edges_to_id")
            await safe_create_async(edges, "company_id", name="edges_company_id")
            await safe_create_async(edges, [("from_id", 1), ("to_id", 1), ("type", 1), ("company_id", 1)], 
                                    name="edges_from_to_type_company_unique", unique=True)



    # ---------------- Node Operations ----------------

    def merge_node(self, label: str, properties: Dict[str, Any], merge_on: Union[str, List[str]] = "id") -> Dict[str, Any]:
        """Merge a node into the database."""
        if self._db is None: self.connect()
        
        if isinstance(merge_on, str):
            merge_on = [merge_on]
            
        nodes = self._db[self.config.node_collection]
        
        # Build filter query for merging
        filter_query = {
            "label": label,
            "company_id": properties.get("company_id")
        }
        for prop in merge_on:
            val = properties.get(prop)
            if val is not None:
                filter_query[prop] = val
        
        # If 'id' is in the unique index but missing in properties, default it to the first merge field or name
        if "id" not in properties:
             properties["id"] = properties.get(merge_on[0]) or properties.get("name")
        
        update_doc = {
            "$set": {**properties, "label": label, "updated_at": datetime.now()},
            "$setOnInsert": {"created_at": datetime.now()}
        }
        
        nodes.update_one(filter_query, update_doc, upsert=True)
        return properties

    async def merge_node_async(self, label: str, properties: Dict[str, Any], merge_on: Union[str, List[str]] = "id") -> Dict[str, Any]:
        """Merge a node into the database asynchronously."""
        if self._async_db is None: await self.connect_async()
        
        if isinstance(merge_on, str):
            merge_on = [merge_on]
            
        nodes = self._async_db[self.config.node_collection]
        
        # Build filter query for merging
        filter_query = {
            "label": label,
            "company_id": properties.get("company_id")
        }
        for prop in merge_on:
            val = properties.get(prop)
            if val is not None:
                filter_query[prop] = val

        # If 'id' is in the unique index but missing in properties, default it to the first merge field or name
        if "id" not in properties:
             properties["id"] = properties.get(merge_on[0]) or properties.get("name")
        
        update_doc = {
            "$set": {**properties, "label": label, "updated_at": datetime.now()},
            "$setOnInsert": {"created_at": datetime.now()}
        }
        
        await nodes.update_one(filter_query, update_doc, upsert=True)
        return properties

    # ---------------- Relationship Operations ----------------

    def merge_relationship(
        self,
        source_label: str,
        source_match: Dict[str, Any],
        target_label: str,
        target_match: Dict[str, Any],
        rel_type: str,
        rel_properties: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Merge a relationship between two nodes."""
        if self._db is None: self.connect()
        
        edges = self._db[self.config.edge_collection]
        
        # Ensure ID exists in match
        src_id = source_match.get("id") or next(iter(source_match.values()))
        tgt_id = target_match.get("id") or next(iter(target_match.values()))
        
        # We don't necessarily enforce node existence here to match Cypher's MERGE behavior if nodes already exist,
        # but in a property graph on Mongo, we usually want to ensure we have the IDs.
        
        filter_query = {
            "from_id": src_id,
            "to_id": tgt_id,
            "type": rel_type,
            "company_id": (rel_properties or {}).get("company_id") or source_match.get("company_id")
        }
        
        update_doc = {
            "$set": {
                **(rel_properties or {}),
                "from_label": source_label,
                "to_label": target_label,
                "updated_at": datetime.now()
            },
            "$setOnInsert": {"created_at": datetime.now()}
        }
        
        edges.update_one(filter_query, update_doc, upsert=True)
        return {"from_id": src_id, "to_id": tgt_id, "type": rel_type, "properties": rel_properties}

    async def merge_relationship_async(
        self,
        source_label: str,
        source_match: Dict[str, Any],
        target_label: str,
        target_match: Dict[str, Any],
        rel_type: str,
        rel_properties: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Merge a relationship between two nodes asynchronously."""
        if self._async_db is None: await self.connect_async()
        
        edges = self._async_db[self.config.edge_collection]
        
        src_id = source_match.get("id") or next(iter(source_match.values()))
        tgt_id = target_match.get("id") or next(iter(target_match.values()))
        
        filter_query = {
            "from_id": src_id,
            "to_id": tgt_id,
            "type": rel_type,
            "company_id": (rel_properties or {}).get("company_id") or source_match.get("company_id")
        }
        
        update_doc = {
            "$set": {
                **(rel_properties or {}),
                "from_label": source_label,
                "to_label": target_label,
                "updated_at": datetime.now()
            },
            "$setOnInsert": {"created_at": datetime.now()}
        }
        
        await edges.update_one(filter_query, update_doc, upsert=True)
        return {"from_id": src_id, "to_id": tgt_id, "type": rel_type, "properties": rel_properties}

    def query(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Execute a custom aggregation pipeline (acts like a Cypher query)."""
        if self._db is None: self.connect()
        # Default query is against nodes collection
        return list(self._db[self.config.node_collection].aggregate(pipeline))

    async def query_async(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Execute a custom aggregation pipeline asynchronously."""
        if self._async_db is None: await self.connect_async()
        cursor = self._async_db[self.config.node_collection].aggregate(pipeline)
        return await cursor.to_list(length=None)

    def get_neighbors(self, node_id: Any, direction: str = "out", max_depth: int = 1) -> List[Dict[str, Any]]:
        """
        Get neighbors of a node using $graphLookup.
        """
        if self._db is None: self.connect()
        
        # Start from the edges collection
        edges = self._db[self.config.edge_collection]
        
        if direction == "out":
            start_field = "from_id"
            connect_from = "to_id"
            connect_to = "from_id"
        elif direction == "in":
            start_field = "to_id"
            connect_from = "from_id"
            connect_to = "to_id"
        else: # both
            start_field = "from_id"
            connect_from = "to_id"
            connect_to = "from_id"

        pipeline = [
            {"$match": {start_field: node_id}},
            {
                "$graphLookup": {
                    "from": self.config.edge_collection,
                    "startWith": f"${connect_from}",
                    "connectFromField": connect_from,
                    "connectToField": connect_to,
                    "as": "traversed_edges",
                    "maxDepth": max_depth - 1
                }
            }
        ]
        
        return list(edges.aggregate(pipeline))

    def search_similar_by_vector(self, embedding: List[float], top_k: int = 10, index_name: str = "vector_index") -> List[Dict[str, Any]]:
        """
        Search for similar nodes using MongoDB Atlas Vector Search.
        """
        if self._db is None: self.connect()
        pipeline = [{
            "$vectorSearch": {
                "index": index_name,
                "path": "embedding",
                "queryVector": embedding,
                "numCandidates": top_k * 10,
                "limit": top_k
            }
        }]
        return list(self._db[self.config.node_collection].aggregate(pipeline))

    async def search_similar_by_vector_async(self, embedding: List[float], top_k: int = 10, index_name: str = "vector_index") -> List[Dict[str, Any]]:
        """Search similar nodes asynchronously."""
        if self._async_db is None: await self.connect_async()
        pipeline = [{
            "$vectorSearch": {
                "index": index_name,
                "path": "embedding",
                "queryVector": embedding,
                "numCandidates": top_k * 10,
                "limit": top_k
            }
        }]
        cursor = self._async_db[self.config.node_collection].aggregate(pipeline)
        return await cursor.to_list(length=None)

    # ---------------- Bulk & High-Performance Operations ----------------

    def _cache_key(self, prefix: str, payload: Any):
        raw = json.dumps(payload, sort_keys=True)
        return f"{prefix}:{hashlib.md5(raw.encode()).hexdigest()}"

    def _get_cache(self, key):
        if not self.config.enable_caching:
            return None
        entry = self._cache.get(key)
        if entry and not entry.is_expired():
            return entry.data
        return None

    def _set_cache(self, key, value):
        if not self.config.enable_caching:
            return
        self._cache[key] = CacheEntry(value, datetime.now(), self.config.cache_ttl)

    def bulk_merge_nodes(self, nodes: List[Dict]):
        """Bulk merge nodes with company_id support."""
        if self._db is None: self.connect()
        col = self._db[self.config.node_collection]

        ops = []
        for n in nodes:
            n["updated_at"] = datetime.now()
            # Ensure id and company_id are in filter
            node_id = n.get("id") or n.get("name")
            company_id = n.get("company_id")
            label = n.get("label", "Entity")
            
            ops.append(
                UpdateOne(
                    {"id": node_id, "label": label, "company_id": company_id},
                    {"$set": {**n, "id": node_id}, "$setOnInsert": {"created_at": datetime.now()}},
                    upsert=True,
                )
            )
        if ops:
            col.bulk_write(ops, ordered=False)

    async def bulk_merge_nodes_async(self, nodes: List[Dict]):
        """Bulk merge nodes asynchronously with company_id support."""
        if self._async_db is None: await self.connect_async()
        col = self._async_db[self.config.node_collection]

        ops = []
        for n in nodes:
            n["updated_at"] = datetime.now()
            node_id = n.get("id") or n.get("name")
            company_id = n.get("company_id")
            label = n.get("label", "Entity")
            
            ops.append(
                UpdateOne(
                    {"id": node_id, "label": label, "company_id": company_id},
                    {"$set": {**n, "id": node_id}, "$setOnInsert": {"created_at": datetime.now()}},
                    upsert=True,
                )
            )
        if ops:
            await col.bulk_write(ops, ordered=False)

    def bulk_merge_edges(self, edges: List[Dict]):
        """Bulk merge edges with company_id support."""
        if self._db is None: self.connect()
        col = self._db[self.config.edge_collection]

        ops = []
        for e in edges:
            e["updated_at"] = datetime.now()
            company_id = e.get("company_id")
            ops.append(
                UpdateOne(
                    {
                        "from_id": e["from_id"],
                        "to_id": e["to_id"],
                        "type": e["type"],
                        "company_id": company_id
                    },
                    {"$set": e, "$setOnInsert": {"created_at": datetime.now()}},
                    upsert=True,
                )
            )
        if ops:
            col.bulk_write(ops, ordered=False)

    async def bulk_merge_edges_async(self, edges: List[Dict]):
        """Bulk merge edges asynchronously with company_id support."""
        if self._async_db is None: await self.connect_async()
        col = self._async_db[self.config.edge_collection]

        ops = []
        for e in edges:
            e["updated_at"] = datetime.now()
            company_id = e.get("company_id")
            ops.append(
                UpdateOne(
                    {
                        "from_id": e["from_id"],
                        "to_id": e["to_id"],
                        "type": e["type"],
                        "company_id": company_id
                    },
                    {"$set": e, "$setOnInsert": {"created_at": datetime.now()}},
                    upsert=True,
                )
            )
        if ops:
            await col.bulk_write(ops, ordered=False)

    def parallel_bulk_nodes(self, nodes: List[Dict], batch_size=500, workers=4):
        batches = [nodes[i:i+batch_size] for i in range(0, len(nodes), batch_size)]
        def worker(batch):
            self.bulk_merge_nodes(batch)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            executor.map(worker, batches)

    def parallel_bulk_edges(self, edges: List[Dict], batch_size=500, workers=4):
        batches = [edges[i:i+batch_size] for i in range(0, len(edges), batch_size)]
        def worker(batch):
            self.bulk_merge_edges(batch)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            executor.map(worker, batches)

    async def parallel_bulk_nodes_async(self, nodes: List[Dict], batch_size=500):
        batches = [nodes[i:i+batch_size] for i in range(0, len(nodes), batch_size)]
        await asyncio.gather(*[self.bulk_merge_nodes_async(batch) for batch in batches])

    async def parallel_bulk_edges_async(self, edges: List[Dict], batch_size=500):
        batches = [edges[i:i+batch_size] for i in range(0, len(edges), batch_size)]
        await asyncio.gather(*[self.bulk_merge_edges_async(batch) for batch in batches])

    def query_cached(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Query with caching support."""
        key = self._cache_key("query", pipeline)
        cached = self._get_cache(key)
        if cached is not None:
            return cached
        result = self.query(pipeline)
        self._set_cache(key, result)
        return result

    async def query_cached_async(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Async query with caching support."""
        key = self._cache_key("query", pipeline)
        cached = self._get_cache(key)
        if cached is not None:
            return cached
        result = await self.query_async(pipeline)
        self._set_cache(key, result)
        return result

    def vector_search(self, embedding: List[float], top_k=10, index_name="vector_index"):
        """Convenience method for vector search with caching."""
        pipeline = [{
            "$vectorSearch": {
                "index": index_name,
                "path": "embedding",
                "queryVector": embedding,
                "numCandidates": top_k * 10,
                "limit": top_k,
            }
        }]
        return self.query_cached(pipeline)

    async def vector_search_async(self, embedding: List[float], top_k=10, index_name="vector_index"):
        """Async convenience method for vector search with caching."""
        pipeline = [{
            "$vectorSearch": {
                "index": index_name,
                "path": "embedding",
                "queryVector": embedding,
                "numCandidates": top_k * 10,
                "limit": top_k,
            }
        }]
        return await self.query_cached_async(pipeline)

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
