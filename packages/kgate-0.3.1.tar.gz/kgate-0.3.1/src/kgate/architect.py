"""
Architect class and methods to run a KGE model training, testing and inference from end to end.
"""

import csv
import gc
import logging
import os
import platform
import shutil
import warnings
from collections.abc import Callable
from glob import glob
from inspect import signature
from pathlib import Path
from typing import Tuple, Dict, List, Any, Set, Literal, Optional

import pandas as pd
import numpy as np
import tomli_w

from torchkge import KnowledgeGraph
from torchkge.models import Model
import torchkge.sampling as sampling
from torchkge.utils import MarginLoss, BinaryCrossEntropyLoss

from torch_geometric.utils import k_hop_subgraph

import torch
from torch import tensor, Tensor
from torch.nn import Parameter, Module
import torch.optim as optim
from torch.optim import lr_scheduler as learning_rate_scheduler
from torch.utils.data import DataLoader

from ignite.engine import Events, Engine
from ignite.handlers import EarlyStopping, ModelCheckpoint, Checkpoint, DiskSaver, ProgressBar
from ignite.metrics import RunningAverage

from torch_geometric.utils import k_hop_subgraph

from torchkge.utils import MarginLoss, BinaryCrossEntropyLoss

from .data_leakage import permute_tails
from .decoders import *
from .encoders import *
from .evaluators import LinkPredictionEvaluator, TripletClassificationEvaluator
from .inference import NodeInference, EdgeInference
from .knowledgegraph import KnowledgeGraph
from .preprocessing import prepare_knowledge_graph, SUPPORTED_SEPARATORS
from .samplers import NegativeSampler, PositionalNegativeSampler, BernoulliNegativeSampler, UniformNegativeSampler, MixedNegativeSampler
from .utils import parse_config, load_knowledge_graph, set_random_seeds, find_best_model, merge_kg, initialize_embedding, plot_learning_curves, save_config


# Configure logging
logging.captureWarnings(True)
logging_level = logging.INFO
logging.basicConfig(
    level = logging_level,  
    format = "%(asctime)s - %(levelname)s - %(message)s" 
)


class Architect(Module):
    """
    Architect class for knowledge graph embedding training.
    
    The Architect class contains the kg and manages every step from the training to the inference.
    
    Arguments
    ---------
    config_path: str, optional
        Path to the configuration file
    kg: Tuple of KnowledgeGraph or KnowledgeGraph, optional
        Either a knowledge graph that has already been preprocessed by KGATE and split accordingly, or an unprocessed KnowledgeGraph object.
        In the first case, the knowledge graph won't be preprocessed even if `config.run_kg_preprocessing` is set to True.
        In the second case, an error is thrown if the `config.run_kg_preprocessing` is set to False.
        The KnowledgeGraph object can also be a torchKGE KnowledgeGraph if it has been transformed by the kgate.KnowledgeGraph.from_torchkge() method beforehand.
    dataframe: pd.DataFrame, optional
        The knowledge graph as a pandas dataframe containing at least the columns head, tail and edge,
        and where each row corresponds to a triplet.
    metadata: pd.DataFrame, optional
        The metadata as a pandas dataframe, with at least the columns id and type, where id is the name of the node as it is in the
        knowledge graph. If this argument is not provided, the metadata will be read from config.metadata if it exists. If both are absent,
        all nodes will be considered to be the same node type.
    cuddn_benchmark: bool, optional, default to True
        Benchmark different convolution algorithms to chose the optimal one.
        Initialization is slightly longer when it is enabled, and only if cuda is available.
    number_of_cores: int, optional, default to 0
        Set the number of cpu cores used by KGATE. If set to 0, the maximum number of available cores is used.
    kwargs: dict
        Inline configuration parameters. The name of the arguments must match the parameters found in `config_template.toml`.
    
    Attributes
    ----------
    config: dict
        The parsed configuration as a python dictionnary.
    kg_train: KnowledgeGraph
        Train split from the knowledge graph.
    kg_validation: KnowledgeGraph
        Validation split from the knowledge graph.
    kg_test: KnowledgeGraph
        Test split from the knowledge graph.
    metadata: pd.DataFrame
        The metadata dataframe to associate to the knowledge graph.
    node_embedding_dimensions: int
        Dimensions of node embeddings, or both node and edge embeddings if they are confounded.
    edge_embedding_dimensions: int
        Dimensions of edge embeddings.
        For most decoders, node and edge embeddings must be identical.
        If not explicitly different than `node_embedding_dimensions`, it is the same. Most models only support the same value for both hyperparameters.
    node_embeddings: nn.ParameterList
        A list containing all embeddings for each node type.
        keys: node type index
        values: tensors of shape [node_count, node_embedding_dimensions]
    edge_embeddings: nn.Embedding, shape: [edge_type_count, edge_embedding_dimensions]
        Embeddings for each edge type.
    encoder: DefaultEncoder or GNN
        Encoder model of the autoencoder.
        For more details, refer to the `initialize_encoder` function.
    decoder: BilinearDecoder or ConvolutionalDecoder or TranslationalDecoder
        Decoder model of the autoencoder.
        For more details, refer to the `initialize_decoder` function.
    decoder_loss: MarginLoss or BinaryCrossEntropyLoss
        The loss object associated with the proper decoder, but may be overwritten.
        Either `MarginLoss(margin)` or `BinaryCrossEntropyLoss()`.
    sampler: NegativeSampler
        Negative sampler.
        For more details, refer to the `initialize_sampler` function.
    optimizer: optim.Optimizer
        Optimizer.
        For more details, refer to the `initialize_optimizer` function.
    scheduler: learning_rate_scheduler.LRScheduler or None
        Learning rate scheduler of KGATE.
        Modules that alter the learning rate throughout the training.
        For more details, refer to the `initialize_scheduler` function.
    evaluator: LinkPredictionEvaluator or TripletClassificationEvaluator
        The evaluator, either LinkPredictionEvaluator or TripletClassificationEvaluator.
        For more details, refer to the `initialize_evaluator` function.
        GPU is referenced to as Cuda.
    device: torch.device
        Indicate if data should be sent to GPU ("cuda") or CPU ("cpu").
    checkpoints_directory: Path
        Path to the directory containing checkpoint files.
    evaluation_batch_size: int
        Size of an evaluation and inference batch.
    TODO: add_missing_attributes_not_declared_in_init
    
    Raises
    ------
    InvalidColumnName
        Pandas error.
        The metadata dataframe must have columns named "id" and "type".
    ValueError #1
        If the file referenced as `metadata_csv` in the config file exists but cannot be parsed.
    ValueError #2
        The metadata csv file uses a non supported separator.
        Supported separators are comma (,), tabulation (    ) and semi-colon (;).
    ValueError #3
        If the `run_kg_preprocessing` setting in the config file is set to False,
        but the knowledge graph `kg` is given but not as a tuple.
        The knowledge graph must either be preprocessed and given as a tuple (training, validation and test),
        or `run_kg_preprocessing` must be set to True.

    Examples
    --------
    Inline hyperparameter declaration
    >>> model_params = {"node_embedding_dimensions": 100, "decoder": {"name":"DistMult"}}
    >>> sampler_params = {"negative_triplet_count":5}
    >>> run_preprocessing = True
    >>> architect = Architect("/path/to/configuration", model = model_params, sampler = sampler_params, run_kg_preprocessing = run_preprocessing)

    Notes
    -----
    While it is possible to give any part of the configuration as kwargs, even everything, it is strongly recommended
    to use a separated configuration file to ensure reproducibility of training.
    
    """
    def __init__(self,
                config_path: str = "",
                kg: Tuple[KnowledgeGraph, KnowledgeGraph, KnowledgeGraph] 
                        | KnowledgeGraph 
                        | None = None,
                dataframe: pd.DataFrame
                        | None = None,
                metadata: pd.DataFrame
                        | None = None,
                cudnn_benchmark: bool = True,
                number_of_cores: int = 0,
                **kwargs):
        # kg should be of type KnowledgeGraph, if exists use it instead of the one in config
        # dataframe should have columns head, tail and edge
        self.config: dict = parse_config(config_path, kwargs)

        if torch.cuda.is_available():
            # Benchmark convolution algorithms to chose the optimal one.
            # Initialization is slightly longer when it is enabled.
            torch.backends.cudnn.benchmark = cudnn_benchmark

        # If given, restrict the parallelisation to user-defined threads.
        # Otherwise, use all the cores the process has access to.
            
        if platform.system() == "Windows":
            number_of_cores: int = number_of_cores if number_of_cores > 0 else os.cpu_count()
        else:
            number_of_cores: int = number_of_cores if number_of_cores > 0 else len(os.sched_getaffinity(0))
        logging.info(f"Setting number of threads to {number_of_cores}")
        torch.set_num_threads(number_of_cores)

        output_directory: Path = Path(self.config["output_directory"])
        # Create output folder if it doesn't exist
        logging.info(f"Output folder: {output_directory}")
        output_directory.mkdir(parents = True, exist_ok = True)
        self.checkpoints_directory: Path = output_directory.joinpath("checkpoints")

        self.device: torch.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logging.info(f"Detected device: {self.device}")

        set_random_seeds(self.config["seed"])

        self.node_embedding_dimensions: int = self.config["model"]["node_embedding_dimensions"]
        self.edge_embedding_dimensions: int = self.config["model"]["edge_embedding_dimensions"]
        if self.edge_embedding_dimensions == -1:
            self.edge_embedding_dimensions = self.node_embedding_dimensions
        self.evaluation_batch_size: int = self.config["training"]["evaluation_batch_size"]

        self.metadata = None
        if metadata is None:
            metadata = self.config["metadata_csv"] if self.config["metadata_csv"] != "" else None
        self.set_metadata(metadata = metadata)
        
        run_kg_preprocessing: bool = self.config["run_kg_preprocessing"]

        if run_kg_preprocessing:
            logging.info(f"Preparing KG...")
            self.kg_train, self.kg_validation, self.kg_test = prepare_knowledge_graph(self.config, kg, dataframe, self.metadata)
            logging.info("KG preprocessed.")
        else:
            if kg is not None:
                logging.info("Using given KG...")
                if isinstance(kg, tuple):
                    self.kg_train, self.kg_validation, self.kg_test = kg
                else:
                    raise ValueError("The KG needs to be preprocessed and given as a tuple of training, validation and test KG. Otherwise, set `run_kg_preprocessing` to True in the config file.")
            else:
                logging.info("Loading KG...")
                self.kg_train, self.kg_validation, self.kg_test = load_knowledge_graph(Path(self.config["kg_pkl"]))
                logging.info("Done")

        super().__init__()
        # Initialize attributes
        self.encoder: DefaultEncoder | GNN = None
        self.decoder: BilinearDecoder | ConvolutionalDecoder | TranslationalDecoder = None
        self.decoder_loss: MarginLoss | BinaryCrossEntropyLoss = None
        self.optimizer: optim.Optimizer = None
        self.sampler: NegativeSampler = None
        self.scheduler: learning_rate_scheduler.LRScheduler | None = None
        self.evaluator: LinkPredictionEvaluator | TripletClassificationEvaluator = None
        self.node_embeddings: nn.ParameterList
        self.edge_embeddings: nn.Embedding


    @property
    def encoder_node_embedding_dimensions(self) -> int:
        """
        The embedding dimensions in the output of the encoder (or initialized if there is no encoder).

        For most decoders, it is the same as `self.node_embedding_dimensions`. But for decoders which use multiple
        embedding spaces, the latent space has `[embedding_spaces_count] * node_embedding_dimensions` embedding dimensions.

        For example, ComplEx uses two embedding spaces: a real one and an imaginary one. Thus, its methods take as input
        embedding vectors that have `2 * node_embedding_dimensions` embedding dimensions. They are then split and
        handled correctly from within the encoder.

        Returns
        -------
        node_embedding_dimensions: int
            Dimensions of node embeddings in the output of the encoder.
        
        """
        if self.decoder is not None and hasattr(self.decoder, "embedding_spaces"):
            return self.node_embedding_dimensions * self.decoder.embedding_spaces
        
        return self.node_embedding_dimensions


    @property
    def encoder_edge_embedding_dimensions(self) -> int:
        """
        The embedding dimensions in the output of the encoder (or initialized if there is no encoder).

        For most decoders, it is the same as `self.edge_embedding_dimensions`. But for decoders which use multiple
        embedding spaces, the latent space has `[embedding_spaces_count] * edge_embedding_dimensions` embedding dimensions.

        For example, ComplEx uses two embedding spaces: a real one and an imaginary one. Thus, its methods take as input
        embedding vectors that have `2 * edge_embedding_dimensions` embedding dimensions. They are then split and
        handled correctly from within the encoder.

        Returns
        -------
        edge_embedding_dimensions: int
            Dimensions of edge embeddings in the output of the encoder.
        
        """
        if self.decoder is not None and hasattr(self.decoder, "embedding_spaces"):
            return self.edge_embedding_dimensions * self.decoder.embedding_spaces
        
        return self.edge_embedding_dimensions

    def set_metadata(self, metadata: pd.DataFrame | os.PathLike):
        """
        Set the node metadata of the knowledge graph.

        This function accepts either a pandas DataFrame or the path to a CSV file as input.
        It must have at least columns:
        - "id" which uses the same identifiers as the knowledge graph;
        - "type" which records the type of the corresponding node.
        
        In addition, the metadata can have any number of supplementary columns that can be
        used to set the identity of the nodes for the associated :class:`~kgate.knowledgegraph.KnowledgeGraph`.

        If there is no knowledge graph associated with the Architect, the `architect.metadata` property will be used
        to initialize them. If there is already a knowledge graph, it will update the knowledge graph with
        the new metadata.

        Alternatively, you can directly run the :func:`~kgate.knowledgegraph.KnowledgeGraph.add_metadata` method for a
        more fine-grained metadata management.
        
        Arguments
        ---------
        metadata: pd.DataFrame or os.PathLike
            The metadata object, either as a pandas DataFrame or a path to a CSV file.

        Raises
        ------
        pd.errors.InvalidColumnName
            If the columns 'id' and 'type' are not present.
        ValueError
            If the CSV file uses an unsupported separator.
        TypeError
            If the metadata object is not of the correct type.
            
        """
        match type(metadata):
            case pd.DataFrame:
                if not set(["id", "type"]).issubset(metadata.keys()):
                    raise pd.errors.InvalidColumnName("The columns \"id\" and \"type\" must be present in the given metadata dataframe.")
        
                self.metadata = metadata
            case os.PathLike:
                if Path(metadata).exists():
                    # Fuzzy identification of separator.
                    # TODO: find a cleaner way to do it
                    for separator in SUPPORTED_SEPARATORS:
                        try:
                            self.metadata = pd.read_csv(metadata, sep = separator, usecols = ["type", "id"])
                            break
                        except ValueError:
                            continue
                
                    if self.metadata is None:
                        raise ValueError(f"The metadata csv file uses a non supported separator. Supported separators are '{'\', \''.join(SUPPORTED_SEPARATORS)}'.")
            case _:
                return
            
        if self.metadata is not None and hasattr(self, "kg_train"):
            for knowledge_graph in (self.kg_train, self.kg_val, self.kg_test):
                knowledge_graph.add_metadata(self.metadata)
            

    def initialize_encoder( self,
                            encoder_name: Literal["Default", "GCN", "GAT", "Node2Vec", ""] = "",
                            gnn_layers: int = 0
                            ) -> DefaultEncoder | GCNEncoder | GATEncoder:
        """
        Create and initialize the encoder object according to the configuration or arguments.

        The encoder is created from PyG encoding layers. Currently, the implemented encoders 
        are a random initialization, **GCN** [1]_, **GAT** [2]_ and **Node2Vec** [3]_. See the encoder class for a detailed
        explanation of the encoders.

        If both configuration and arguments are given, the arguments take priority.

        References
        ----------
        TODO: proper links to the references
        .. [1] Kipf, Thomas and Max Welling. “Semi-Supervised Classification with Graph Convolutional Networks.” ArXiv abs/1609.02907 (2016): n. pag.
        .. [2] Brody, Shaked et al. “How Attentive are Graph Attention Networks?” ArXiv abs/2105.14491 (2021): n. pag.
        .. [3] TODO: add reference to Node2Vec

        Arguments
        ---------
        encoder_name: {"Default", "GCN", "GAT", "Node2Vec"}, optional
            Name of the encoder.
        gnn_layers: int, optional, default to 0
            Number of hidden layers for the encoder. Only used for deep learning encoders.

        Warns
        -----
        If the provided encoder name is not supported, it will default to a random initialization and warn the user.

        Returns
        -------
        encoder: DefaultEncoder or GCNEncoder or GATEncoder or Node2VecEncoder
            The encoder object.
        
        """
        encoder_config: dict = self.config["model"]["encoder"]
        if encoder_name == "":
            encoder_name = encoder_config["name"]
        
        if gnn_layers == 0:
            gnn_layers = encoder_config["gnn_layer_number"]

        edge_types = self.kg_train.triplet_types

        match encoder_name:
            case "Default":
                encoder = DefaultEncoder()
            case "GCN": 
                encoder = GCNEncoder(edge_types, self.encoder_node_embedding_dimensions, gnn_layers)
            case "GAT":
                encoder = GATEncoder(edge_types, self.encoder_node_embedding_dimensions, gnn_layers)
            case "Node2Vec":
                encoder = Node2VecEncoder(self.kg_train.edge_list, self.encoder_node_embedding_dimensions, device = self.device, **encoder_config["params"])
            case _:
                encoder = DefaultEncoder()
                logging.warning(f"Unrecognized encoder {encoder_name}. Defaulting to a random initialization.")
        
        return encoder


    def initialize_decoder( self,
                            decoder_name: str = "",
                            dissimilarity: Literal["L1", "L2", "torus_L1", "torus_L2", "torus_eL2", ""] = "",
                            margin: int = 0,
                            filter_count: int = 0
                            ) -> Tuple[
                                        BilinearDecoder | ConvolutionalDecoder | TranslationalDecoder,
                                        MarginLoss | BinaryCrossEntropyLoss
                                        ]:
        """
        Create and initialize the decoder object according to the configuration or arguments.

        The decoders are adapted and inherit from torchKGE decoders to be able to handle heterogeneous data.
        Not all torchKGE decoders are already implemented, but all of them and more will eventually be. Currently, 
        the available decoders are **TransE** [1]_, **TransH** [2]_, **TransR** [3]_, **TransD** [4]_, **TorusE** [5]_,
        **RESCAL** [6]_, **DistMult** [7]_, **ComplEx** [8]_ and **ConvKB** [9]_. See the description of decoder classes for details about 
        their implementation, or read their original papers.

        Translational models are used with a `torchkge.MarginLoss` while bilinear models are used with a 
        `torchkge.BinaryCrossEntropyLoss`.

        If both configuration and arguments are given, the arguments take priority.

        References
        ----------
        TODO: proper links to the references
        .. [1] Bordes, Antoine et al. “Translating Embeddings for Modeling Multi-relational Data.” Neural Information Processing Systems (2013).
        .. [2] Wang, Zhen et al. “Knowledge Graph Embedding by Translating on Hyperplanes.” AAAI Conference on Artificial Intelligence (2014).
        .. [3] Lin, Yankai et al. “Learning Entity and Relation Embeddings for Knowledge Graph Completion.” AAAI Conference on Artificial Intelligence (2015).
        .. [4] Ji, Guoliang et al. “Knowledge Graph Embedding via Dynamic Mapping Matrix.” Annual Meeting of the Association for Computational Linguistics (2015).
        .. [5] TODO: add reference to TorusE
        .. [6] Nickel, Maximilian et al. “A Three-Way Model for Collective Learning on Multi-Relational Data.” International Conference on Machine Learning (2011).
        .. [7] Yang, Bishan et al. “Embedding Entities and Relations for Learning and Inference in Knowledge Bases.” International Conference on Learning Representations (2014).
        .. [8] TODO: add reference to ComplEx
        .. [9] Nguyen, Dai Quoc et al. “A Novel Embedding Model for Knowledge Base Completion Based on Convolutional Neural Network.” North American Chapter of the Association for Computational Linguistics (2017).

        Arguments
        ----------
        decoder_name: str, optional
            Name of the decoder.
        dissimilarity: {"L1", "L2"}, optional
            Type of the dissimilarity metric.
        margin: int, optional, default to 0
            Margin to be used with MarginLoss. Unused with bilinear models.
        filter_count: int, optional, default to 0
            Number of convolution filters.

        Raises
        ------
        NotImplementedError
            If the provided decoder name is not supported.

        Returns
        -------
        decoder: BilinearDecoder or ConvolutionalDecoder or TranslationalDecoder
            The decoder object.
        decoder_loss: MarginLoss or BinaryCrossEntropyLoss
            The loss object.
        """
        
        decoder_config: dict = self.config["model"]["decoder"]

        if decoder_name == "":
            decoder_name = decoder_config["name"]
        if dissimilarity == "":
            dissimilarity = decoder_config["dissimilarity"]
        if margin == 0:
            margin = decoder_config["margin"]
        if filter_count == 0:
            filter_count = decoder_config["filter_count"]

        # Translational models
        match decoder_name:
            case "TransE":
                decoder = TransE(dissimilarity_type = dissimilarity)
                decoder_loss = MarginLoss(margin)
            case "TransH":
                decoder = TransH(embedding_dimensions = self.node_embedding_dimensions,
                                node_count = self.kg_train.node_count,
                                edge_count = self.kg_train.edge_count)
                decoder_loss = MarginLoss(margin)
            case "TransR":
                decoder = TransR(node_embedding_dimensions = self.node_embedding_dimensions,
                                edge_embedding_dimensions = self.edge_embedding_dimensions, 
                                node_count = self.kg_train.node_count, 
                                edge_count = self.kg_train.edge_count)
                decoder_loss = MarginLoss(margin)
            case "TransD":
                decoder = TransD(node_embedding_dimensions = self.node_embedding_dimensions,
                                edge_embedding_dimensions = self.edge_embedding_dimensions, 
                                node_count = self.kg_train.node_count, 
                                edge_count = self.kg_train.edge_count)
                decoder_loss = MarginLoss(margin)
            case "TorusE":
                decoder = TorusE(dissimilarity_type = dissimilarity)
                decoder_loss = MarginLoss(margin)
            case "RESCAL":
                decoder = RESCAL(embedding_dimensions = self.node_embedding_dimensions,
                                node_count = self.kg_train.node_count,
                                edge_count = self.kg_train.edge_count)
                decoder_loss = BinaryCrossEntropyLoss()
            case "DistMult":
                decoder = DistMult(embedding_dimensions = self.node_embedding_dimensions,
                                node_count = self.kg_train.node_count,
                                edge_count = self.kg_train.edge_count)
                decoder_loss = BinaryCrossEntropyLoss()
            case "ComplEx":
                decoder = ComplEx(embedding_dimensions = self.node_embedding_dimensions)
                decoder_loss = BinaryCrossEntropyLoss()
            case "ConvKB":
                decoder = ConvKB(embedding_dimensions = self.node_embedding_dimensions, 
                                filter_count = filter_count, 
                                node_count = self.kg_train.node_count, 
                                edge_count = self.kg_train.edge_count)
                decoder_loss = BinaryCrossEntropyLoss()
            case _:
                raise NotImplementedError(f"The requested decoder {decoder_name} is not implemented.")

        return decoder, decoder_loss


    def initialize_optimizer(self) -> optim.Optimizer:
        """
        Initialize the optimizer based on the configuration provided.
        
        Available optimizers are Adam, SGD and RMSprop. See Pytorch.optim 
        documentation for optimizer parameters.

        Raises
        ------
        NotImplementedError
            If the optimizer is not supported.

        Returns
        -------
        optimizer: optim.Optimizer
            Initialized optimizer.
            
        """
        optimizer_name: str = self.config["optimizer"]["name"]

        # Retrieve optimizer parameters, defaulting to an empty dictionnary if not specified
        optimizer_params: dict = self.config["optimizer"]["params"]

        # Mapping of optimizer names to their corresponding PyTorch classes
        optimizer_mapping = {
            "Adam": optim.Adam,
            "SGD": optim.SGD,
            "RMSprop": optim.RMSprop,
            # Add other optimizers here as needed
        }

        # Check if the specified optimizer is supported
        if optimizer_name not in optimizer_mapping:
            raise NotImplementedError(f"Optimizer type '{optimizer_name}' is not supported. Please check the configuration. Supported optimizers are:\n{'\n'.join(optimizer_mapping.keys())}")

        optimizer_class = optimizer_mapping[optimizer_name]
    
        # Initialize the optimizer with given parameters
        optimizer: optim.Optimizer = optimizer_class(self.parameters(), **optimizer_params)

        logging.info(f"Optimizer '{optimizer_name}' initialized with parameters: {optimizer_params}")
        
        return optimizer


    def initialize_negative_sampler(self) -> NegativeSampler:
        """
        Initialize the sampler according to the configuration.
        
        Supported samplers are Positional, Uniform, Bernoulli and Mixed.
        They are adapted from torchKGE's samplers to be compatible with the 
        graphindices format.

        Raises
        ------
        NotImplementedError
            If the name of the sampler is not supported.

        Returns
        -------
        negative_sampler: NegativeSampler
            The initialized sampler.
        
        """
        negative_sampler_config: dict = self.config["sampler"]
        negative_sampler_name: str = negative_sampler_config["name"]
        negative_triplet_count: int = negative_sampler_config["negative_triplet_count"]

        match negative_sampler_name:
            case "Positional":
                negative_sampler = PositionalNegativeSampler(self.kg_train)
            case "Uniform":
                negative_sampler = UniformNegativeSampler(self.kg_train, negative_triplet_count)
            case "Bernoulli":
                negative_sampler = BernoulliNegativeSampler(self.kg_train, negative_triplet_count)
            case "Mixed":
                negative_sampler = MixedNegativeSampler(self.kg_train, negative_triplet_count)
            case _:
                raise NotImplementedError(f"Sampler type '{negative_sampler_name}' is not supported. Please check the configuration.")
            
        return negative_sampler
    
    
    def initialize_learning_rate_scheduler(self) -> learning_rate_scheduler.LRScheduler | None:
        """
        Initializes the learning rate scheduler based on the provided configuration.
        
        Raises
        ------
        ValueError
            If the scheduler type is unsupported or required parameters are missing.
        
        Warns
        -----
        If no learning rate scheduler is specified in the configuration, none will be used.
        
        Returns
        -------
        learning_rate_scheduler: torch.optim.lr_scheduler._LRScheduler or None:
            Instance of the specified scheduler or None if no scheduler is configured.
        
        """
        learning_rate_scheduler_config: dict = self.config["learning_rate_scheduler"]
        
        if learning_rate_scheduler_config["type"] == "":
            warnings.warn("No learning rate scheduler specified in the configuration, none will be used.")
            return None
    
        learning_rate_scheduler_type: str = learning_rate_scheduler_config["type"]
        learning_rate_scheduler_params: dict = learning_rate_scheduler_config["params"]
        
        # Mapping of scheduler names to their corresponding PyTorch classes
        learning_rate_scheduler_mapping = {
            "StepLR": learning_rate_scheduler.StepLR,
            "MultiStepLR": learning_rate_scheduler.MultiStepLR,
            "ExponentialLR": learning_rate_scheduler.ExponentialLR,
            "CosineAnnealingLR": learning_rate_scheduler.CosineAnnealingLR,
            "CosineAnnealingWarmRestarts": learning_rate_scheduler.CosineAnnealingWarmRestarts,
            "ReduceLROnPlateau": learning_rate_scheduler.ReduceLROnPlateau,
            "LambdaLR": learning_rate_scheduler.LambdaLR,
            "OneCycleLR": learning_rate_scheduler.OneCycleLR,
            "CyclicLR": learning_rate_scheduler.CyclicLR,
        }

        # Verify that the scheduler type is supported
        if learning_rate_scheduler_type not in learning_rate_scheduler_mapping:
            raise ValueError(f"Scheduler type '{learning_rate_scheduler_type}' is not supported. Please check the configuration.")
        learning_rate_scheduler_class = learning_rate_scheduler_mapping[learning_rate_scheduler_type]
        
        # Initialize the scheduler based on its type
        try:
            learning_rate_scheduler: learning_rate_scheduler.LRScheduler = learning_rate_scheduler_class(self.optimizer, **learning_rate_scheduler_params)
        except TypeError as e:
            raise ValueError(f"Error initializing '{learning_rate_scheduler_type}': {e}")
        
        logging.info(f"Scheduler '{learning_rate_scheduler_type}' initialized with parameters: {learning_rate_scheduler_params}")
        
        return learning_rate_scheduler


    def initialize_evaluator(self) -> LinkPredictionEvaluator | TripletClassificationEvaluator:
        """
        Set the task for which the model will be evaluated on using the validation set.
        
        Options are Link Prediction or Triplet Classification.
        Link Prediction evaluate the ability of a model to predict correctly the head or tail of a triple given the other 
        node and edge. 
        Triplet Classification evaluate the ability of a model to discriminate between existing and 
        fake triplet in a KG.
        
        Raises
        ------
        NotImplementedError
            If the name of the task is not supported.
            
        Returns
        -------
        evaluator: LinkPredictionEvaluator or TripletClassificationEvaluator
            The initialized evaluator, either LinkPredictionEvaluator or TripletClassificationEvaluator.
        
        """
        match self.config["evaluation"]["objective"]:
            case "Link Prediction":
                full_graphindices = torch.cat([
                    self.kg_train.graphindices,
                    self.kg_train.removed_triplets,
                    self.kg_validation.graphindices,
                    self.kg_validation.removed_triplets,
                    self.kg_test.graphindices,
                    self.kg_test.removed_triplets
                ], dim=1)
                evaluator = LinkPredictionEvaluator(full_graphindices = full_graphindices, embedding_dimensions = self.node_embedding_dimensions)
                self.validation_metric = "MRR"
            case "Triplet Classification":
                evaluator = TripletClassificationEvaluator(architect = self,
                                                        kg_validation = self.kg_validation,
                                                        kg_test = self.kg_test)
                self.validation_metric = "Accuracy"
            case _:
                raise NotImplementedError(f"The requested evaluator {self.config["evaluation"]["objective"]} is not implemented.")
            
        logging.info(f"Using {self.config["evaluation"]["objective"]} evaluator.")
        
        return evaluator
    

    def initialize_model(self,
                        attributes: Dict[str, pd.DataFrame] = {},
                        pretrained: Path | None = None):
        """
        Initialize every component of the model.
        
        This is done automatically by running the `train_model` method.
        
        The initialization is done in this order:
        - Decoder
        - Encoder
        - Node Embeddings (either at random, or using given node features)
        - Edge Embeddings (either at random, or using given edge features)
        - Optimizer
        - Negative Sampler
        - Scheduler
        - Evaluator
        For each of these elements, if something is already set (i.e. the attribute is not None), it is not re-initialized.
        
        Arguments
        ---------
        attributes: dict[str, pd.DataFrame]
            dict(node_type, embedding) containing the embedding for each type of node.
        pretrained: Path, optional
            Path to the pretrained node embeddings.
            TODO: add support for pretrained edge embeddings

        Raises
        ------
        AssertionError #1
            When not using a GNN as encoder, the `node_type` should not be supplied.
        AssertionError #2
            The length of the given attribute must match the number of nodes of this type.
        AssertionError #3
            The node type of each node must correspond to the one registered in the knowledge graph.
        
        """
        # Cannot use short-circuit syntax with tuples
        logging.info("Initializing decoder...")
        if self.decoder is None:
            self.decoder, self.decoder_loss = self.initialize_decoder()
            self.decoder.to(self.device)

        logging.info("Initializing encoder...")
        self.encoder = self.encoder or self.initialize_encoder()

        logging.info("Initializing embeddings...")
        
        # If given a pretrained embedding file (such as the output of a Node2Vec), we use that in priority
        if pretrained is not None and pretrained.exists():
            self.node_embeddings = torch.load(pretrained)
        else:
            assert isinstance(self.encoder, GNN) or len(self.kg_train.node_type_to_index) == 1, "When not using a GNN as encoder, the node_type shouldn't be supplied."

            # create initial embeddings
            self.node_embeddings = nn.ParameterList()
            index_to_node_type = {value: key for key,value in self.kg_train.node_type_to_index.items()}
            for node_type in self.kg_train.node_type_to_global:
                node_count = self.kg_train.node_type_to_global[node_type].size(0)
                if node_type in attributes:
                    # if feature attributes given, initialization based on them
                    current_attribute: pd.DataFrame = attributes[node_type]
                    assert current_attribute.shape[0] == node_count, f"The length of the given attribute ({len(current_attribute)}) must match the number of nodes of this type ({node_count})."
                    input_features = torch.zeros((node_count,current_attribute.shape[1]), dtype = torch.float)
                    for node in current_attribute.index:
                        node_index = self.kg_train.node_to_index[node]
                        node_type_index = self.kg_train.node_types[node_index]
                        local_index = self.kg_train.global_to_local_indices[node_index]
                        assert node_type_index == self.kg_train.node_type_to_index[node_type], f"The node {node} is given as {node_type} but registered as {index_to_node_type[str(node_type_index)]} in the KG."

                        input_features[local_index] = tensor(current_attribute.loc[node], dtype = torch.float)
                    
                    self.node_embeddings.append(Parameter(input_features).to(self.device))
                    
                else:
                    # if no feature attribute given, random initialization
                    node_embedding_dimensions = self.node_embedding_dimensions if isinstance(self.encoder, GNN) else self.encoder_node_embedding_dimensions
                    embeddings = initialize_embedding(node_count, node_embedding_dimensions, self.device)
                    self.node_embeddings.append(embeddings.weight)

            if isinstance(self.encoder, GNN):     
                # The input features are not supposed to change if we use an encoder
                self.node_embeddings.requires_grad_(False)

        self.edge_embeddings = initialize_embedding(self.kg_train.edge_count, self.encoder_edge_embedding_dimensions, self.device)

        logging.info("Initializing optimizer...")
        self.optimizer = self.optimizer or self.initialize_optimizer()

        logging.info("Initializing sampler...")
        self.sampler = self.sampler or self.initialize_negative_sampler()

        logging.info("Initializing learning rate scheduler...")
        self.scheduler = self.scheduler or self.initialize_learning_rate_scheduler()

        logging.info("Initializing evaluator...")
        self.evaluator = self.evaluator or self.initialize_evaluator()


    def train_model(self,
                    checkpoint_file: Path | None = None,
                    attributes: Dict[str, pd.DataFrame] = {},
                    dry_run: bool = False):
        """
        Launch the training procedure of the Architect.
        
        This function runs the whole training from end to end, leaving out only the evaluation on the test set.
        It uses the `initialize_model` function to prepare the autoencoder as well as the optimizer, negative sampler,
        learning rate scheduler and evaluator.
        The training is executed through a `PyTorch Ignite` `Engine` with a collection of events and parameters:
        - `RunningAverage` to compute the running loss across the batches of the same epoch.
        - `EarlyStopping` to stop the training if the validation MRR does not progress after a number of epochs
            set in the configuration parameters.
        - `Checkpoint` save at a configured interval.
        - Evaluation on the validation set at a configured interval.
        - Metrics logging at each epoch, in the `training_metrics.csv` output file.

        Arguments
        ---------
        checkpoint_file: Path, optional
            The path to the checkpoint file to load and resume a previous training. If None, the training will start from scratch.
        attributes: Dict[str, pd.DataFrame]
            dict(node_type, embedding) containing the embedding for each type of node.
        dry_run: bool, optional, default to False
            Initialize every variable and the trainer, but doesn't start the training.

        Notes
        -----
        If there already is a configuration file in the output folder identical to the current configuration, KGATE will
        automatically attempt to restart the training from the most recent checkpoint in the `checkpoints/` folder. Otherwise,
        the output folder will be cleaned and the current configuration will be written as `kgate_config.toml`
        
        """
        train_config: dict = self.config["training"]
        self.max_epochs: int = train_config["max_epochs"]
        self.train_batch_size: int = train_config["train_batch_size"]
        self.patience: int = train_config["patience"]
        self.evaluation_interval: int = train_config["evaluation_interval"]
        self.save_interval: int = train_config["save_interval"]

        match train_config["pretrained_embeddings"]:
            case "auto":
                pretrained = Path(self.config["output_directory"]).joinpath("embeddings.pt")
            case "":
                pretrained = None
            case _:
                pretrained = Path(train_config["pretrained_embeddings"])
                if not pretrained.exists(): pretrained = None
        
        self.initialize_model(attributes = attributes, pretrained = pretrained)

        self.train_metrics_file: Path = Path(self.config["output_directory"], "training_metrics.csv")

        if checkpoint_file is None:
            with open(self.train_metrics_file, mode = "w", newline = "") as file:
                writer = csv.writer(file)
                writer.writerow(["Epoch", "Training Loss", f"Validation {self.validation_metric}", "Learning Rate"])
        
        self.train_losses: List[float] = []
        self.validation_metric_value: List[float] = []
        self.learning_rates: List[float] = []

        data_loader: DataLoader = DataLoader(self.kg_train, self.train_batch_size)
        logging.info(f"Number of training batches: {len(data_loader)}")

        trainer: Engine = Engine(self.process_batch)
        RunningAverage(output_transform = lambda x: x).attach(trainer, "loss_running_average")

        progress_bar = ProgressBar()
        progress_bar.attach(trainer)

        early_stopping: EarlyStopping = EarlyStopping(
            patience = self.patience,
            score_function = self.get_validation_metric,
            trainer = trainer
        )

        # If we find an identical config we resume training from it, otherwise we clean the checkpoints directory.
        existing_config_path: Path = Path(self.config["output_directory"]).joinpath("kgate_config.toml")
        if existing_config_path.exists():
            existing_config = parse_config(str(existing_config_path), {})
            all_checkpoints = glob(f"{self.checkpoints_directory}/checkpoint_*.pt")
            if existing_config == self.config and len(all_checkpoints) > 0:
                checkpoint_file = checkpoint_file or Path(max(all_checkpoints, key = os.path.getctime))
                logging.info("Found previous run with the same configuration in the output folder...")
        elif self.checkpoints_directory.exists() and len(os.listdir(self.checkpoints_directory)) > 0:
            shutil.rmtree(self.checkpoints_directory)

        trainer.add_event_handler(Events.EPOCH_COMPLETED, self.log_metrics_to_csv)
        trainer.add_event_handler(Events.EPOCH_COMPLETED, self.clean_memory)
        trainer.add_event_handler(Events.EPOCH_COMPLETED, self.update_scheduler)

        trainer.add_event_handler(Events.COMPLETED, self.on_training_completed)

        to_save = {
            "edges": self.edge_embeddings,
            "nodes": self.node_embeddings,
            "decoder": self.decoder,
            "optimizer": self.optimizer,
            "trainer": trainer,
        }

        if isinstance(self.encoder, GNN):
            to_save.update({"encoder": self.encoder})
        if self.scheduler is not None:
            to_save.update({"scheduler": self.scheduler})
        
        checkpoint_handler = Checkpoint(
            to_save,   # Dictionnary of objects to save
            DiskSaver(dirname = self.checkpoints_directory,
                    require_empty = False,
                    create_dir = True),   # Save manager
                    n_saved = 2,   # Only keep last 2 checkpoints
                    global_step_transform = lambda *_: trainer.state.epoch   # Include epoch number
        )

        def save_checkpoint_to_cpu(engine: Engine):
            """
            Custom save function to move the model to CPU before saving and back to GPU after.

            Arguments
            ---------
            engine: Engine
                Runner managing the training.

            """
            # Move models to CPU before saving
            if isinstance(self.encoder, GNN):
                self.encoder.to("cpu")
            self.decoder.to("cpu")
            self.edge_embeddings.to("cpu")
            self.node_embeddings.to("cpu")

            # Save the checkpoint
            checkpoint_handler(engine)

            # Move models back to GPU
            if isinstance(self.encoder, GNN):
                self.encoder.to(self.device)
            self.decoder.to(self.device)
            self.edge_embeddings.to(self.device)
            self.node_embeddings.to(self.device)

        # Attach checkpoint handler to trainer and call save_checkpoint_to_cpu
        trainer.add_event_handler(Events.EPOCH_COMPLETED(every = self.save_interval), save_checkpoint_to_cpu)
    
        checkpoint_best_handler: ModelCheckpoint = ModelCheckpoint(
            dirname = self.checkpoints_directory,
            filename_prefix = "best_model",
            n_saved = 1,
            score_function = self.get_validation_metric,
            score_name = "validation_metric_value",
            require_empty = False,
            create_dir = True,
            atomic = True
        )

        trainer.add_event_handler(Events.EPOCH_COMPLETED(every = self.evaluation_interval), self.evaluate)
        trainer.add_event_handler(Events.EPOCH_COMPLETED(every = self.evaluation_interval), early_stopping)
        trainer.add_event_handler(
            Events.EPOCH_COMPLETED(every = self.evaluation_interval),
            checkpoint_best_handler,
            to_save
        )

        save_config(self.config)

        if checkpoint_file is not None:
            if Path(checkpoint_file).is_file():
                logging.info(f"Resuming training from checkpoint: {checkpoint_file}")
                logging.info(f"edge_embeddings size: {self.edge_embeddings.weight.size()}")
                checkpoint = torch.load(checkpoint_file, weights_only = False)
                Checkpoint.load_objects(to_load = to_save, checkpoint = checkpoint)

                logging.info("Checkpoint loaded successfully.")
                with open(self.train_metrics_file, mode = "a", newline = "") as file:
                    writer = csv.writer(file)
                    writer.writerow(["CHECKPOINT RESTART", "CHECKPOINT RESTART", "CHECKPOINT RESTART", "CHECKPOINT RESTART"])

                if trainer.state.epoch < self.max_epochs:
                    logging.info(f"Starting from epoch {trainer.state.epoch}")
                    if not dry_run:
                        trainer.run(data_loader)
                else:
                    logging.info(f"Training already completed. Last epoch is {trainer.state.epoch} and max_epochs is set to {self.max_epochs}")
            else:
                logging.info(f"Checkpoint file {checkpoint_file} does not exist. Starting training from scratch.")
                if not dry_run:
                    trainer.run(data_loader, max_epochs = self.max_epochs)
        else:
            if not dry_run:
                self.normalize_parameters()
                trainer.run(data_loader, max_epochs = self.max_epochs)
    

    def test(self) -> Dict[str, float | Dict[str, float]]:
        """
        Run the test procedure, evaluate the metrics on the test set and return the dictionary of the results.
        
        TODO: will be changed with https://github.com/BAUDOTlab/KGATE/pull/22

        Returns
        -------
        results: Dict[str, float | Dict[str, float]]
            TODO.What_that_variable_is_or_does
        
        """
        torch.cuda.empty_cache()
        gc.collect()

        self.load_best_model()
        self.evaluator = self.initialize_evaluator()

        self.eval()

        target_edges: List[str] = self.config["evaluation"]["target_edges"]
        metrics_file: Path = Path(self.config["output_directory"], "evaluation_metrics.toml")

        target_edges_result = {}

        all_edges: Set[Any] = set(self.kg_test.edge_to_index.keys())
        remaining_edges = all_edges - set(target_edges)
        remaining_edges = list(remaining_edges)
        
        triplet_count_target_edges = 0

        if len(remaining_edges) != len(all_edges):
            metrics_sum_target_edges, triplet_count_target_edges, individual_metrics_target_edges, group_metrics_target_edges = self.calculate_metrics_for_edges(self.kg_test, target_edges)
            
            target_edges_result = {
                "target_edges": {
                    "Global_metrics": metrics_sum_target_edges,
                    "Individual_metrics": individual_metrics_target_edges
                },
            }

        total_metrics_sum_remaining, triplet_count_remaining, individual_metrics_remaining, group_metrics_remaining = self.calculate_metrics_for_edges(self.kg_test, remaining_edges)

        global_metrics = (group_metrics_remaining + total_metrics_sum_remaining) / (triplet_count_target_edges + triplet_count_remaining)

        logging.info(f"Final Test metrics with best model: {global_metrics}")

        results = {
            "Global_metrics": global_metrics,
            **target_edges_result, # if there is no target edges, don't add the block
            "remaining_edges": {
                "Global_metrics": group_metrics_remaining,
                "Individual_metrics": individual_metrics_remaining
            },
            "target_edges_by_frequency": {}  
        }
                
        self.test_results = results
        
        with open(metrics_file, "wb") as file:
            tomli_w.dump(results, file)

        logging.info(f"Evaluation results stored in {metrics_file}")

        return results
    
    
    def infer(self,
            heads: List[str] = [],
            tails: List[str] = [],
            edges: List[str] = [],
            top_k: int = 100):
        """
        Infer missing nodes or edges, depending on the given parameters.
        
        Only two of heads, tails and edges must be given, and the other one will be inferred. For example, when inferring tails,
        for each couple `heads[n]` and `edges[n]`, `top_k` tails will be predicted. The values in those list must correspond to
        the `identity` of the metadata, by default the current identity. If there is no metadata, the node ID is used.
        
        Arguments
        ---------
        heads: List[str], optional
            List of known head nodes.
        tails: List[str], optional
            List of known tail nodes.
        edges: List[str], optional
            List of known edges.
        top_k: int, optional, Default to 100
            Number of prediction to return for each couple in the list.
        
        Raises
        ------
        ValueError
            To infer missing elements, exactly 2 lists must be given between heads, tails or edges.
        
        Returns
        -------
        predictions: pd.DataFrame
            A DataFrame containing the prediction alongside their score.
        
        """
        if not sum([len(arr) > 0 for arr in [heads, edges, tails]]) == 2:
            raise ValueError("To infer missing elements, exactly 2 lists must be given between heads, tails or edges.")
        torch.cuda.empty_cache()
        gc.collect()

        self.load_best_model()

        do_heads_inference, do_tails_inference, do_edges_inference = len(heads) == 0, len(tails) == 0, len(edges) == 0

        full_kg = merge_kg([self.kg_train, self.kg_validation, self.kg_test], True)

        if do_heads_inference:
            first_known_triplet_part = tensor([self.kg_train.node_to_index[tail] for tail in tails]).long()
            second_known_triplet_part = tensor([self.kg_train.edge_to_index[edge] for edge in edges]).long()
            missing_triplet_part = "head"
            inference = NodeInference(full_kg)
        elif do_tails_inference:
            first_known_triplet_part = tensor([self.kg_train.node_to_index[head] for head in heads]).long()
            second_known_triplet_part = tensor([self.kg_train.edge_to_index[edge] for edge in edges]).long()
            missing_triplet_part = "tail"
            inference = NodeInference(full_kg)
        elif do_edges_inference:
            first_known_triplet_part = tensor([self.kg_train.node_to_index[head] for head in heads]).long()
            second_known_triplet_part = tensor([self.kg_train.node_to_index[tail] for tail in tails]).long()
            missing_triplet_part = "edge"
            inference = EdgeInference(full_kg)
            
        predictions, scores = inference.evaluate(
            first_known_triplet_part,
            second_known_triplet_part,
            encoder = self.encoder,
            decoder = self.decoder,
            top_k = top_k,
            missing_triplet_part = missing_triplet_part,
            batch_size = self.evaluation_batch_size,
            node_embeddings = self.node_embeddings,   
            edge_embeddings = self.edge_embeddings
        )

        index_to_node = {value: key for key, value in self.kg_train.node_to_index.items()}
        prediction_index = predictions.reshape(-1)
        prediction_names = np.vectorize(index_to_node.get)(prediction_index)

        scores = scores.reshape(-1)
        
        return pd.DataFrame({"Prediction":prediction_names,"Score":scores})


    def load_checkpoint(self, path: Path) -> dict:
        """
        Parse an Architect checkpoint to ensure it can properly be loaded.
        
        Arguments
        ---------
        path: pathlib.Path
            The path to the checkpoint that will be loaded.
        
        Raises
        ------
        AssertionError #1
            The number of edges must be the same in the checkpoint and in the current configuration.
        AssertionError #2
            The number of node types must be the same in the checkpoint and in the current configuration.
        AssertionError #3
            The number of nodes must be the same in the checkpoint and in the current configuration.
        AssertionError #4
            The convolution layers must be the same in the checkpoint and in the current configuration.
        
        Returns
        -------
        checkpoint: dict
            The loaded checkpoint as a dictionnary.
        
        """
        checkpoint = torch.load(path, map_location = self.device, weights_only = False)

        # Check node and edge dictionnary size
        assert len(checkpoint["edges"]["weight"]) == self.kg_train.edge_count, f"Mismatch between the number of edges in the checkpoint ({len(checkpoint["edges"]["weight"])}) and the current configuration ({self.kg_train.edge_count})!"

        if isinstance(self.encoder, GNN):
            assert len(checkpoint["nodes"]) == len(self.kg_train.node_type_to_index), f"Mismatch between the number of node types in the checkpoint ({len(checkpoint["nodes"])}) and the current configuration ({len(self.kg_train.node_type_to_index)})!"
        else:
            assert len(checkpoint["nodes"]["0"]) == self.kg_train.node_count, f"Mismatch between the number of nodes in the checkpoint ({len(checkpoint["nodes"]["0"])}) and the current configuration ({self.kg_train.node_count})!"

        if "encoder" in checkpoint:
            assert checkpoint["encoder"].keys() == self.encoder.state_dict().keys(), "Mismatch between the checkpoint convolution layers and the current configuration's."

        return checkpoint


    def load_best_model(self):
        """
        Load into memory the checkpoint corresponding to the highest-performing model on the validation set.

        Raises
        ------
        ValueError
            No best model was found in the checkpoint directory.
            Make sure to run the training first and not rename checkpoint files before running evaluation.
        
        """
        self.decoder, _ = self.initialize_decoder()
        self.encoder = self.initialize_encoder()
        self.edge_embeddings = initialize_embedding(self.kg_train.edge_count, self.encoder_edge_embedding_dimensions, self.device)

        logging.info("Loading best model.")
        best_model = find_best_model(self.checkpoints_directory)

        if not best_model:
            raise ValueError(f"No best model was found in {self.checkpoints_directory}. Make sure to run the training first and not rename checkpoint files before running evaluation.")
        
        logging.info(f"Best model is {self.checkpoints_directory.joinpath(best_model)}")
        checkpoint = self.load_checkpoint(self.checkpoints_directory.joinpath(best_model))

        self.node_embeddings = nn.ParameterList()
        for node_type in checkpoint["nodes"]:
            self.node_embeddings.append(checkpoint["nodes"][node_type].to(self.device))
        
        self.edge_embeddings.load_state_dict(checkpoint["edges"])
        self.decoder.load_state_dict(checkpoint["decoder"], strict=False)
        if "encoder" in checkpoint:
            self.encoder.load_state_dict(checkpoint["encoder"])
        
        self.node_embeddings.to(self.device)
        self.edge_embeddings.to(self.device)
        self.decoder.to(self.device)
        self.encoder.to(self.device)
        logging.info("Best model successfully loaded.")


    def forward(self,
                positive_triplets_batch,
                negative_triplets_batch
                ) -> Tuple[Tensor, Tensor]:
        """
        Forward pass of the Architect.

        Arguments
        ---------
        positive_triplets_batch: torch.Tensor, dtype: torch.float, shape: [4, batch_size]
            Tensor containing the integer key of true sampled triplets of
            the edges in the current batch.
        negative_triplets_batch: torch.Tensor, dtype: torch.long, shape: [4, batch_size]
            Tensor containing the integer key of negatively sampled triplets of
            the edges in the current batch.

        Returns
        -------
        positive_triplet: torch.Tensor, dtype: torch.float, shape: [4, batch_size]
            Tensor containing the score of each true triplet within the batch.
        negative_triplet: torch.Tensor, dtype: torch.long, shape: [4, batch_size]
            Tensor containing the score of each negative triplet within the batch.
        
        """
        positive_triplet: Tensor = self.scoring_function(positive_triplets_batch, self.kg_train)
        # The loss function requires the positive and negative tensors to be of the same size,
        # Thus we duplicate the positive tensor as needed to match the negative.
        negative_triplet_count = negative_triplets_batch.size(1) // positive_triplets_batch.size(1)
        positive_triplet = positive_triplet.repeat(negative_triplet_count)

        negative_triplet: Tensor = self.scoring_function(negative_triplets_batch, self.kg_train)

        return positive_triplet, negative_triplet


    def process_batch(self,
                    engine: Engine,
                    batch: Tensor
                    ) -> torch.types.Number:
        """
        Function called by the trainer to run the training loop on a mini-batch.

        TODO: may be merged with the forward function

        Arguments
        ---------
        batch: torch.Tensor, dtype: torch.long, shape: [4, batch_size]
            Tensor containing the integer key of heads, tails, edges and triplets
            of the edges in the current batch.
            Here, batch_size is batch.shape[1].

        Returns
        -------
        loss_value: torch.types.Number
            Training loss value of the model for this epoch.
        
        """
        batch = batch.T.to(self.device)

        batch_count = self.sampler.corrupt_batch(batch)
        batch_count = batch_count.to(self.device)
        
        self.optimizer.zero_grad()

        # Compute loss with positive and negative triplets
        positive_triplet, negative_triplet = self(batch, batch_count)
        loss = self.decoder_loss(positive_triplet, negative_triplet)
        loss.backward()

        self.optimizer.step()

        self.normalize_parameters()

        return loss.item()


    def scoring_function(self,
                        batch: Tensor,
                        kg: KnowledgeGraph
                        ) -> Tensor:
        """
        Runs the encoder and decoder pass on a batch for a given KG.
        
        If the encoder is not a GNN, directly runs and update the embeddings.
        Otherwise, samples a subgraph from the given batch nodes and runs the encoder before.
        
        Arguments
        ---------
        batch: torch.Tensor, shape: [4, batch_size]
            Batch of triplets. The rows correspond to:
            - head_index
            - tail_index
            - edge_index
            - triplet_index
            Here, batch_size is batch.shape[1].
        kg: KnowledgeGraph
            The knowledge graph corresponding to the batch identifiers.
            
        Returns
        -------
        score: torch.Tensor
            The score given by the decoder for the batch.
        
        """
        head_indices, tail_indices, edge_indices = batch[0], batch[1], batch[2]
        
        if isinstance(self.encoder, GNN):
            seed_nodes: Tensor = batch[:2].unique()
            hop_count: int = self.encoder.layer_count
            edge_list: Tensor = kg.edge_list
            
            _,_,_, edge_mask = k_hop_subgraph(
                node_idx = seed_nodes,
                num_hops = hop_count,
                edge_index = edge_list
                )
                
            input = kg.get_encoder_input(kg.graphindices[:, edge_mask].to(self.device), self.node_embeddings)

            encoder_output: Dict[str, Tensor] = self.encoder(input.x_dict, input.edge_list)

            # As I understand it, this tensor is larger than needs to be because it needs to account for every possible
            # idx of the embeddings. It's not a logic problem as only the indices from the batch will be selected for the decoder,
            # which corresponds to the indices that are filled here.
            # TODO: See if making it a sparse tensor can spare memory
            embeddings: torch.Tensor = torch.zeros((kg.node_count, self.encoder_node_embedding_dimensions),
                                                    device = self.device,
                                                    dtype = torch.float)

            for node_type, index in input.mapping.items():
                embeddings[index] = encoder_output[node_type]

        else:
            embeddings = self.node_embeddings[0]
        
        head_embeddings = embeddings[head_indices]
        edge_embeddings = self.edge_embeddings(edge_indices)  # Edges are unchanged
        tail_embeddings = embeddings[tail_indices]

        return self.decoder.score(  head_embeddings = head_embeddings,
                                    tail_embeddings = tail_embeddings,
                                    edge_embeddings = edge_embeddings,
                                    head_indices = head_indices,
                                    tail_indices = tail_indices,
                                    edge_indices = edge_indices)


    def get_embeddings(self) -> Dict[str, Tensor]:
        """
        Returns the embeddings of nodes and edges, as well as decoder-specific embeddings if they exist.

        Returns
        -------
        embedding_dictionnary: Dict[str, Tensor]
            Embeddings of nodes and edges, as well as decoder-specific embeddings.

        """
        self.normalize_parameters()
        
        if isinstance(self.encoder, GNN):
            node_embeddings: torch.Tensor = torch.zeros((self.node_count, self.encoder_node_embedding_dimensions), device="cpu", dtype=torch.float)
            full_kg = merge_kg([self.kg_train, self.kg_val, self.kg_test])

            with torch.no_grad():
                # TODO: use not the whole graphindices but the unique nodes instead
                for i in range(full_kg.graphindices.shape[1] // self.train_batch_size + 1):
                    input = self.kg_train.get_encoder_input(full_kg.graphindices[:, i * self.train_batch_size : (i + 1) * self.train_batch_size].to(self.device), self.node_embeddings)

                    encoder_output: Dict[str, Tensor] = self.encoder(input.x_dict, input.edge_index)

                    for node_type, indices in input.mapping.items():
                        node_embeddings[indices] = encoder_output[node_type].cpu()
        else:
            node_embeddings = self.node_embeddings[0].data.cpu()

        edge_embeddings = self.edge_embeddings.weight.data.cpu()

        decoder_embeddings = self.decoder.get_embeddings()

        embedding_dictionnary = {"nodes": node_embeddings, "edges": edge_embeddings,}

        if decoder_embeddings is not None:
            embedding_dictionnary.update({"decoder": decoder_embeddings})

        return embedding_dictionnary


    def normalize_parameters(self):
        """
        Normalize all parameters of the model.
        
        Each decoder has a specific normalization routine, so this function doesn't do anything by itself,
        except calling the `decoder.normalize_parameters` function if it exists.

        Raises
        ------
        AssertionError
            The `decoder.normalize_params` method should return exactly two elements: the node embedding and the edge embedding.
        
        """
        # Some decoders should not normalize parameters or do so in a different way.
        # In this case, they should implement the function themselves and we return it.
        normalize_function: Callable[..., Tuple[nn.ParameterList, nn.Embedding]] | None = getattr(self.decoder, "normalize_params", None)

        if callable(normalize_function):
            normalized_embeddings = normalize_function(node_embeddings = self.node_embeddings, edge_embeddings = self.edge_embeddings)
            assert len(normalized_embeddings) == 2, "The decoder.normalize_params method should return exactly two elements, the node embedding and the edge embedding."
            self.node_embeddings, self.edge_embeddings = normalized_embeddings
            
        logging.debug(f"Normalized all embeddings.")


    def log_metrics_to_csv(self, engine: Engine):
        """
        Metrics recording in CSV file.

        Arguments
        ---------
        engine: Engine
            Runner managing the training.
            
        """
        epoch = engine.state.epoch
        train_loss = engine.state.metrics["loss_running_average"]
        validation_metric_value = engine.state.metrics.get("validation_metric_value", 0)
        learning_rate = self.optimizer.param_groups[0]["lr"]

        self.train_losses.append(train_loss)
        self.validation_metric_value.append(validation_metric_value)
        self.learning_rates.append(learning_rate)

        with open(self.train_metrics_file, mode = "a", newline = "") as file:
            writer = csv.writer(file)
            writer.writerow([epoch, train_loss, validation_metric_value, learning_rate])

        logging.info(f"Epoch {epoch} - Train Loss: {train_loss}, Validation {self.validation_metric}: {validation_metric_value}, Learning Rate: {learning_rate}")


    def clean_memory(self):
        """
        Memory cleaning.
        
        """
        torch.cuda.empty_cache()
        gc.collect()
        logging.info("Memory cleaned.")


    def evaluate(self, engine:Engine):
        """
        Evaluation on validation set.

        Arguments
        ---------
        engine: Engine
            Runner managing the training.
        
        """
        logging.info(f"Evaluating on validation set at epoch {engine.state.epoch}...")
        self.eval()  # Set the model to evaluation mode
        with torch.no_grad():
            if isinstance(self.evaluator,LinkPredictionEvaluator):
                validation_score = self.link_prediction(self.kg_validation) 
                engine.state.metrics["validation_metric_value"] = validation_score 
                logging.info(f"Validation MRR: {validation_score}")
            elif isinstance(self.evaluator, TripletClassificationEvaluator):
                validation_score = self.triplet_classification(self.kg_validation, self.kg_test)
                engine.state.metrics["validation_metric_value"] = validation_score
                logging.info(f"Validation Accuracy: {validation_score}")
        if self.scheduler and isinstance(self.scheduler, learning_rate_scheduler.ReduceLROnPlateau):
            self.scheduler.step(validation_score)
            logging.info("Stepping scheduler ReduceLROnPlateau.")

        self.train() # Set the model back to training mode

    
    def update_scheduler(self):
        """
        Scheduler update.
            
        """
        if self.scheduler is not None and not isinstance(self.scheduler, learning_rate_scheduler.ReduceLROnPlateau):
            self.scheduler.step()

    
    def get_validation_metric(self, engine: Engine) -> float:
        """
        Early stopping score function & checkpoint best metric.

        Arguments
        ---------
        engine: Engine
            Runner managing the training.

        Returns
        -------
        validation_metric_value: float
            TODO.What_that_variable_is_or_does
        
        """
        return engine.state.metrics.get("validation_metric_value", 0)
    
    
    def on_training_completed(self, engine: Engine):
        """
        Run at the end of the training, even with early stopping.
        
        Plot the training loss and validation MRR curves once the training is over.

        Arguments
        ---------
        engine: Engine
            Runner managing the training.
        
        """
        logging.info(f"Training completed after {engine.state.epoch} epochs.")

        plot_learning_curves(self.train_metrics_file, self.config["output_directory"], self.validation_metric)


    # TODO: create a script to isolate prediction functions. Maybe a Predictor class?
    def categorize_test_nodes(self,
                            edge_name: str,
                            threshold: int
                            ) -> Tuple[List[int], List[int]]:
        """
        Categorizes test triplets with the specified edge in the test set 
        based on whether their nodes have been seen with that edge in the training set,
        and separates them into two groups based on a threshold for occurrences.

        Arguments
        ---------
        edge_name: str
            The name of the edge to check (e.g., "indication").
        threshold: int
            The minimum number of occurrences of the edge for a node to be considered as "frequent".

        Raises
        ------
        ValueError
            An edge from `edge_name` does not exist in the training knowledge graph.

        Returns
        -------
        frequent_indices: List[int]
            Indices of triplets in the test set with the specified edge where
            nodes have been seen more than `threshold` times with that edge in the training set.
        infrequent_indices: List[int]
            Indices of triplets in the test set with the specified edge where
            nodes have been seen fewer than or equal to `threshold` times with that edge in the training set.
        
        """
        # Get the index of the specified edge in the training graph
        if edge_name not in self.kg_train.edge_to_index:
            raise ValueError(f"The edge '{edge_name}' does not exist in the training knowledge graph.")
        edge_index = self.kg_train.edge_to_index[edge_name]

        # Count occurrences of nodes with the specified edge in the training set
        train_node_counts = {}
        for i in range(self.kg_train.triplet_count):
            if self.kg_train.edge_indices[i].item() == edge_index:
                head = self.kg_train.head_indices[i].item()
                tail = self.kg_train.tail_indices[i].item()
                train_node_counts[head] = train_node_counts.get(head, 0) + 1
                train_node_counts[tail] = train_node_counts.get(tail, 0) + 1

        # Separate test triplets with the specified edge based on the threshold
        frequent_indices = []
        infrequent_indices = []
        for i in range(self.kg_test.triplet_count):
            if self.kg_test.edge_indices[i].item() == edge_index:  # Only consider triplets with the specified edge
                head = self.kg_test.head_indices[i].item()
                tail = self.kg_test.tail_indices[i].item()
                head_count = train_node_counts.get(head, 0)
                tail_count = train_node_counts.get(tail, 0)

                # Categorize based on threshold
                if head_count > threshold or tail_count > threshold:
                    frequent_indices.append(i)
                else:
                    infrequent_indices.append(i)

        return frequent_indices, infrequent_indices
    
    
    def calculate_metrics_for_edges(self,
                                        kg: KnowledgeGraph,
                                        edge_indices: List[str]
                                        ) -> Tuple[float, int, Dict[str, float], float]:
        """
        TODO: must be rewritten
        
        Compute the metrics for each individual edge.

        Arguments
        ---------
        kg: KnowledgeGraph
            Knowledge graph on which the metrics will be calculated.
        edge_indices: List[str]
            Indices of edges.

        Returns
        -------
        metrics_sum: float
            Sum of all individual metrics.
        triplet_count: int
            Number of triplets considered.
        individual_metrics: Dict[str, float]
            Metrics computed for a single edge.
        group_metrics: float
            Global metrics computed for the edge group.
        
        Notes
        -----
        The metrics calculated here are only the Mean Reciprocal Rank (MRR).
        More could be implemented in the future.
        
        """
        # Mean Reciprocal Rank (MRR) computed by ponderating for each edge
        metrics_sum = 0.0
        triplet_count = 0
        individual_metrics = {} 

        for edge_name in edge_indices:
            # Get triplets associated with index
            edge_index = kg.edge_to_index.get(edge_name)
            indices_to_keep = torch.nonzero(kg.edge_indices == edge_index, as_tuple = False).squeeze()

            if indices_to_keep.numel() == 0:
                continue  # Skip to next edge if no triplet found
            
            new_kg = kg.keep_triplets(indices_to_keep)

            if isinstance(self.evaluator, LinkPredictionEvaluator):
                test_metrics = self.link_prediction(new_kg)
            elif isinstance(self.evaluator, TripletClassificationEvaluator):
                test_metrics = self.triplet_classification(kg_validation = self.kg_validation, kg_test = new_kg)
            
            # Save each edge's MRR
            individual_metrics[edge_name] = test_metrics
            
            metrics_sum += test_metrics * indices_to_keep.numel()
            triplet_count += indices_to_keep.numel()
        
        # Compute global MRR for the edge group
        group_metrics = metrics_sum / triplet_count if triplet_count > 0 else 0
        
        return metrics_sum, triplet_count, individual_metrics, group_metrics


    def calculate_metrics_for_categories(self,
                                        frequent_indices: List[int],
                                        infrequent_indices: List[int]
                                        ) -> Tuple[float, float]:
        """
        Calculate the MRR for frequent and infrequent categories based on given indices.
        
        Parameters
        ----------
        frequent_indices: List[int]
            Indices of test triplets considered as frequent.
        infrequent_indices: List[int]
            Indices of test triplets considered as infrequent.

        Returns
        -------
        frequent_metrics: float
            MRR for the frequent category.
        infrequent_metrics: float
            MRR for the infrequent category.
        
        """
        # Create subgraph for frequent and infrequent categories
        kg_frequent = self.kg_test.keep_triplets(frequent_indices)
        kg_infrequent = self.kg_test.keep_triplets(infrequent_indices)
        
        # Compute each category's MRR
        if isinstance(self.evaluator, LinkPredictionEvaluator):
            frequent_metrics = self.link_prediction(kg_frequent) if frequent_indices else 0
            infrequent_metrics = self.link_prediction(kg_infrequent) if infrequent_indices else 0
        elif isinstance(self.evaluator, TripletClassificationEvaluator):
            frequent_metrics = self.triplet_classification(self.kg_validation, kg_frequent) if frequent_indices else 0
            infrequent_metrics = self.triplet_classification(self.kg_validation, kg_infrequent) if infrequent_indices else 0
            
        return frequent_metrics, infrequent_metrics


    def link_prediction(self, kg: KnowledgeGraph) -> float:
        """
        Link prediction evaluation on test set, validation set or inference set.

        Arguments
        ---------
        kg: KnowledgeGraph
            Knowledge graph on which the link prediction evaluation will be done.

        Raises
        -----
        ValueError
            Wrong evaluator called.
            The evaluator is initialized beforehand and may be incompatible with link prediction.
            This error is raised when an evaluator incompatible with link prediction is initialized.
            TODO: this may be improved by resetting the evaluator or creating it on the fly, though that may be problematic on some level?

        Returns
        -------
        test_mrr: float
            The filtered MRR resulting from the evaluation on given knowledge graph.
            TODO: might be better to return the Prediction object altogether, and let the calling function deal with it
        
        """
        # Test MRR measure
        if not isinstance(self.evaluator, LinkPredictionEvaluator):
            raise ValueError(f"Wrong evaluator called. Calling Link Prediction method for {type(self.evaluator)} evaluator.")

        head_predictions, tail_predictions = self.evaluator.evaluate(batch_size = self.evaluation_batch_size,
                                encoder = self.encoder,
                                decoder = self.decoder,
                                knowledge_graph = kg,
                                node_embeddings = self.node_embeddings, 
                                edge_embeddings = self.edge_embeddings,
                                verbose = True)
        
        test_mrr = (head_predictions.mrr[1] + tail_predictions.mrr[1]) / 2
        
        return test_mrr
    
    
    def triplet_classification( self,
                                kg_validation: KnowledgeGraph,
                                kg_test: KnowledgeGraph
                                ) -> float:
        """
        Triplet Classification evaluation.

        Arguments
        ---------
        kg_validation: KnowledgeGraph
            Validation split from the knowledge graph.
        kg_test: KnowledgeGraph
            Test split from the knowledge graph.

        Raises
        ------
        ValueError
            Wrong evaluator called.
            TODO.detail

        Returns
        -------
        accuracy: float
            Accuracy of the triplet classification.
        
        """
        if not isinstance(self.evaluator, TripletClassificationEvaluator):
            raise ValueError(f"Wrong evaluator called. Calling Triplet Classification method for {type(self.evaluator)} evaluator.")
        
        self.evaluator.evaluate(batch_size = self.evaluation_batch_size,
                                kg = kg_validation)
        
        return self.evaluator.accuracy( batch_size = self.evaluation_batch_size,
                                        kg_test = kg_test,
                                        kg_validation = kg_validation)


    def run_data_leakage(self, attributes: Dict[str, pd.DataFrame] = {}):
        """
        Data leakage evaluation.
        
        TODO: detail the data leakage procedure
        
        Arguments
        ---------
        attributes: Dict[str, pd.DataFrame], optional
            dict(node_type, embedding) containing the embedding for each type of node.

        Raises
        ------
        ValueError
            An edge was not found in the knowledge graph.
        
        """
        logging.info("Preparing KG for data leakage evaluation procedure...")
        data_leakage_config = self.config["data_leakage"]

        kg = merge_kg([self.kg_train, self.kg_validation, self.kg_test])

        for edge_type in data_leakage_config["permuted_edges"]:
            if edge_type not in self.kg_train.edge_to_index:
                raise ValueError(f"Edge type {edge_type} was not found in the knowledge graph.")
            logging.info(f"Permuting tails of edge type {edge_type}")
            self.kg_train = permute_tails(self.kg_train, edge_type)

        self.kg_train, self.kg_validation, self.kg_test = kg.split_kg(split_proportions = self.config["preprocessing"]["split"])

        self.train_model(attributes = attributes)
