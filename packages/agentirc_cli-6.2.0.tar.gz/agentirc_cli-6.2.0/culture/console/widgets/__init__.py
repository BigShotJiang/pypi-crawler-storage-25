"""Console TUI widgets."""
