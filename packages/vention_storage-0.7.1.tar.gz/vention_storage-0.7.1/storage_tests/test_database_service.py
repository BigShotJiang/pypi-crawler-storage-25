"""Tests for DatabaseService."""

from __future__ import annotations

from datetime import datetime, timezone

from storage.database_service import (
    DatabaseService,
    DependencyError,
    ValidationError,
)
from storage.accessor import ModelAccessor
from storage.auditor import AuditLog
from storage_tests.fixtures import StorageTestCase, TestModel


class TestDatabaseService(StorageTestCase):
    """Tests for DatabaseService."""

    def setUp(self) -> None:
        """Set up test with database service."""
        super().setUp()
        self.service = DatabaseService(
            audit_default_limit=10,
            audit_max_limit=100,
        )
        self.accessor = ModelAccessor(TestModel, "test")

    # ---------------- Health ----------------

    def test_health(self) -> None:
        """health returns ok status."""
        result = self.service.health()
        self.assertEqual(result["status"], "ok")

    # ---------------- Audit Log ----------------

    def test_read_audit(self) -> None:
        """read_audit returns audit log entries."""
        # Create some records to generate audit entries
        self.accessor.insert(TestModel(name="test1"), actor="user1")
        self.accessor.insert(TestModel(name="test2"), actor="user2")

        results = self.service.read_audit()
        self.assertGreaterEqual(len(results), 2)
        self.assertIsInstance(results[0], AuditLog)

    def test_read_audit_filter_by_component(self) -> None:
        """read_audit filters by component."""
        self.accessor.insert(TestModel(name="test1"), actor="user1")

        results = self.service.read_audit(component="test")
        self.assertGreater(len(results), 0)
        for result in results:
            self.assertEqual(result.component, "test")

    def test_read_audit_filter_by_actor(self) -> None:
        """read_audit filters by actor."""
        self.accessor.insert(TestModel(name="test1"), actor="user1")
        self.accessor.insert(TestModel(name="test2"), actor="user2")

        results = self.service.read_audit(actor="user1")
        self.assertGreater(len(results), 0)
        for result in results:
            self.assertEqual(result.actor, "user1")

    def test_read_audit_filter_by_record_id(self) -> None:
        """read_audit filters by record_id."""
        obj = self.accessor.insert(TestModel(name="test"), actor="user1")
        assert obj.id is not None

        results = self.service.read_audit(record_id=obj.id)
        self.assertGreater(len(results), 0)
        for result in results:
            self.assertEqual(result.record_id, obj.id)

    def test_read_audit_limit(self) -> None:
        """read_audit respects limit parameter."""
        # Create multiple records
        for i in range(15):
            self.accessor.insert(TestModel(name=f"test{i}"), actor="user1")

        results = self.service.read_audit(limit=5)
        self.assertEqual(len(results), 5)

    def test_read_audit_default_limit(self) -> None:
        """read_audit uses default limit when not specified."""
        # Create more than default limit
        for i in range(15):
            self.accessor.insert(TestModel(name=f"test{i}"), actor="user1")

        results = self.service.read_audit()
        self.assertLessEqual(len(results), 10)  # Should use default_limit

    def test_read_audit_max_limit(self) -> None:
        """read_audit enforces max_limit."""
        # Create more than max limit
        for i in range(150):
            self.accessor.insert(TestModel(name=f"test{i}"), actor="user1")

        results = self.service.read_audit(limit=200)  # Request more than max
        self.assertLessEqual(len(results), 100)  # Should cap at max_limit

    def test_read_audit_offset(self) -> None:
        """read_audit supports pagination with offset."""
        # Create multiple records
        for i in range(10):
            self.accessor.insert(TestModel(name=f"test{i}"), actor="user1")

        first_page = self.service.read_audit(limit=5, offset=0)
        second_page = self.service.read_audit(limit=5, offset=5)

        self.assertEqual(len(first_page), 5)
        self.assertEqual(len(second_page), 5)
        # Should be different records
        self.assertNotEqual(first_page[0].id, second_page[0].id)

    def test_read_audit_filter_by_since(self) -> None:
        """read_audit filters by since timestamp."""
        # Create record before cutoff
        self.accessor.insert(TestModel(name="old"), actor="user1")

        # Wait a moment and create record after cutoff
        import time

        time.sleep(0.1)
        cutoff = datetime.now(timezone.utc)
        time.sleep(0.1)
        self.accessor.insert(TestModel(name="new"), actor="user1")

        results = self.service.read_audit(since=cutoff)
        # Should only include records after cutoff
        for result in results:
            result_timestamp = result.timestamp
            if result_timestamp.tzinfo is None:
                # If naive, assume UTC
                result_timestamp = result_timestamp.replace(tzinfo=timezone.utc)
            self.assertGreaterEqual(result_timestamp, cutoff)

    # ---------------- Schema Diagram ----------------

    def test_schema_diagram_svg_missing_dependency(self) -> None:
        """schema_diagram_svg raises DependencyError when sqlalchemy-schemadisplay not installed."""
        # This test assumes the dependency might not be installed
        try:
            result = self.service.schema_diagram_svg()
            # If it works, verify it's SVG bytes
            self.assertIsInstance(result, bytes)
            self.assertIn(b"<svg", result.lower() or b"")
        except DependencyError:
            # Expected if dependency not installed
            pass

    # ---------------- Export ZIP ----------------

    def test_export_zip(self) -> None:
        """export_zip creates a ZIP archive."""
        # Create some test data
        self.accessor.insert(TestModel(name="test1"), actor="user1")
        self.accessor.insert(TestModel(name="test2"), actor="user1")

        zip_bytes = self.service.export_zip()
        self.assertIsInstance(zip_bytes, bytes)
        self.assertGreater(len(zip_bytes), 0)
        # Should start with ZIP file signature
        self.assertEqual(zip_bytes[:2], b"PK")

    # ---------------- Backup SQLite ----------------

    def test_backup_sqlite(self) -> None:
        """backup_sqlite creates a backup file."""
        # Create some test data
        self.accessor.insert(TestModel(name="test"), actor="user1")

        result = self.service.backup_sqlite()
        self.assertIn("filename", result)
        self.assertIn("data", result)
        self.assertIsInstance(result["data"], bytes)
        self.assertGreater(len(result["data"]), 0)
        self.assertIn(".sqlite", result["filename"])

    # ---------------- Restore SQLite ----------------

    def test_restore_sqlite_dry_run(self) -> None:
        """restore_sqlite with dry_run=True validates but doesn't restore."""
        # Create some initial data
        self.accessor.insert(TestModel(name="before"), actor="user1")
        initial_count = len(self.accessor.all())

        # Create a backup
        backup = self.service.backup_sqlite()

        # Add more data after backup
        self.accessor.insert(TestModel(name="after"), actor="user1")

        result = self.service.restore_sqlite(
            backup["data"],
            filename=backup["filename"],
            integrity_check=True,
            dry_run=True,
        )

        self.assertEqual(result["status"], "ok")
        self.assertFalse(result["restored"])
        self.assertIn("bytes", result)

        # Database should be unchanged (still has the "after" record)
        records = self.accessor.all()
        self.assertGreater(len(records), initial_count)

    def test_restore_sqlite_invalid_file(self) -> None:
        """restore_sqlite raises ValidationError for invalid SQLite file."""
        invalid_bytes = b"not a sqlite file"

        with self.assertRaises(ValidationError):
            self.service.restore_sqlite(
                invalid_bytes,
                filename="invalid.sqlite",
                integrity_check=True,
                dry_run=False,
            )

    def test_restore_sqlite_actual_restore(self) -> None:
        """restore_sqlite actually restores database when dry_run=False."""
        # Create initial data
        self.accessor.insert(TestModel(name="before"), actor="user1")

        # Create backup
        backup = self.service.backup_sqlite()

        # Modify database
        self.accessor.insert(TestModel(name="after"), actor="user1")

        # Restore from backup
        result = self.service.restore_sqlite(
            backup["data"],
            filename=backup["filename"],
            integrity_check=True,
            dry_run=False,
        )

        self.assertEqual(result["status"], "ok")
        self.assertTrue(result["restored"])

        pass
