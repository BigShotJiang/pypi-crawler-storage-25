"""Tests for CrudService."""

from __future__ import annotations
from typing import List

from storage.accessor import ModelAccessor
from storage.crud_service import (
    CrudService,
    Filter,
    FilterOperation,
    NotFoundError,
    ConflictError,
    ValidationError,
    UnsupportedError,
)
from storage_tests.fixtures import StorageTestCase, SoftDeleteModel, HardDeleteModel


class TestCrudService(StorageTestCase):
    """Tests for CrudService."""

    def setUp(self) -> None:
        """Set up test with accessors and services."""
        super().setUp()
        self.soft_accessor = ModelAccessor(SoftDeleteModel, "softs")
        self.hard_accessor = ModelAccessor(HardDeleteModel, "hards")
        self.soft_crud = CrudService(self.soft_accessor, max_records=5)
        self.hard_crud = CrudService(self.hard_accessor)

    # ---------------- List Records ----------------

    def test_list_records(self) -> None:
        """list_records returns all records."""
        self.soft_accessor.insert(SoftDeleteModel(name="test1"), actor="test")
        self.soft_accessor.insert(SoftDeleteModel(name="test2"), actor="test")

        records: List[SoftDeleteModel] = self.soft_crud.list_records()
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0].name, "test1")
        self.assertEqual(records[1].name, "test2")

    def test_list_records_includes_deleted(self) -> None:
        """list_records with include_deleted=True includes soft-deleted records."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None
        self.soft_accessor.delete(obj.id, actor="test")

        records: List[SoftDeleteModel] = self.soft_crud.list_records(include_deleted=False)
        self.assertEqual(len(records), 0)

        records_with_deleted: List[SoftDeleteModel] = self.soft_crud.list_records(include_deleted=True)
        self.assertEqual(len(records_with_deleted), 1)

    def test_list_records_with_limit(self) -> None:
        """list_records with limit parameter returns limited results."""
        for i in range(5):
            self.soft_crud.create_record({"name": f"test{i}"}, actor="test")

        records: List[SoftDeleteModel] = self.soft_crud.list_records(limit=3)
        self.assertEqual(len(records), 3)

    def test_list_records_with_offset(self) -> None:
        """list_records with offset parameter skips records."""
        for i in range(5):
            self.soft_crud.create_record({"name": f"test{i}"}, actor="test")

        records: List[SoftDeleteModel] = self.soft_crud.list_records(offset=2)
        self.assertEqual(len(records), 3)  # Should get items 2, 3, 4

    def test_list_records_with_pagination(self) -> None:
        """list_records with limit and offset provides pagination."""
        for i in range(10):
            self.soft_accessor.insert(SoftDeleteModel(name=f"test{i}"), actor="test")

        # Page 1
        page1: List[SoftDeleteModel] = self.soft_crud.list_records(limit=3, offset=0)
        self.assertEqual(len(page1), 3)

        # Page 2
        page2: List[SoftDeleteModel] = self.soft_crud.list_records(limit=3, offset=3)
        self.assertEqual(len(page2), 3)

        # Page 3
        page3: List[SoftDeleteModel] = self.soft_crud.list_records(limit=3, offset=6)
        self.assertEqual(len(page3), 3)

        # Page 4
        page4: List[SoftDeleteModel] = self.soft_crud.list_records(limit=3, offset=9)
        self.assertEqual(len(page4), 1)

    def test_list_records_with_sorting(self) -> None:
        """list_records with order_by and order_desc provides sorting."""
        self.soft_crud.create_record({"name": "zebra"}, actor="test")
        self.soft_crud.create_record({"name": "apple"}, actor="test")
        self.soft_crud.create_record({"name": "banana"}, actor="test")

        # Sort ascending
        records_asc: List[SoftDeleteModel] = self.soft_crud.list_records(order_by="name", order_desc=False)
        self.assertEqual(len(records_asc), 3)
        self.assertEqual(records_asc[0].name, "apple")
        self.assertEqual(records_asc[1].name, "banana")
        self.assertEqual(records_asc[2].name, "zebra")

        # Sort descending
        records_desc: List[SoftDeleteModel] = self.soft_crud.list_records(order_by="name", order_desc=True)
        self.assertEqual(len(records_desc), 3)
        self.assertEqual(records_desc[0].name, "zebra")
        self.assertEqual(records_desc[1].name, "banana")
        self.assertEqual(records_desc[2].name, "apple")

    def test_list_records_with_pagination_and_sorting(self) -> None:
        """list_records with pagination and sorting combined."""
        for i in range(10):
            self.soft_accessor.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Get page 1: first 3, sorted by id descending (newest first)
        page1: List[SoftDeleteModel] = self.soft_crud.list_records(
            limit=3,
            offset=0,
            order_by="id",
            order_desc=True,
        )
        self.assertEqual(len(page1), 3)

        # Verify descending order
        page1_ids = [int(r.id) for r in page1 if r.id is not None]
        self.assertEqual(page1_ids, sorted(page1_ids, reverse=True))

    def test_list_records_with_invalid_order_by(self) -> None:
        """list_records raises ValidationError for invalid order_by field."""
        self.soft_crud.create_record({"name": "test"}, actor="test")

        with self.assertRaises(ValidationError) as context:
            self.soft_crud.list_records(order_by="nonexistent_field")
        self.assertIn("Field 'nonexistent_field' not found", str(context.exception))

    # ---------------- Get Record ----------------

    def test_get_record(self) -> None:
        """get_record returns a record by ID."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        result: SoftDeleteModel = self.soft_crud.get_record(obj.id)
        self.assertEqual(result.name, "test")
        self.assertEqual(result.id, obj.id)

    def test_get_record_not_found(self) -> None:
        """get_record raises NotFoundError for missing record."""
        with self.assertRaises(NotFoundError):
            self.soft_crud.get_record(999_999)

    def test_get_record_includes_deleted(self) -> None:
        """get_record with include_deleted=True can retrieve soft-deleted records."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None
        self.soft_accessor.delete(obj.id, actor="test")

        with self.assertRaises(NotFoundError):
            self.soft_crud.get_record(obj.id, include_deleted=False)

        result: SoftDeleteModel = self.soft_crud.get_record(obj.id, include_deleted=True)
        self.assertEqual(result.name, "test")

    # ---------------- Create Record ----------------

    def test_create_record(self) -> None:
        """create_record inserts a new record."""
        result: SoftDeleteModel = self.soft_crud.create_record({"name": "test"}, actor="test")
        self.assertIsNotNone(result.id)
        self.assertEqual(result.name, "test")

    def test_create_record_max_records(self) -> None:
        """create_record raises ConflictError when max_records exceeded."""
        # Create max_records items
        for i in range(5):
            self.soft_crud.create_record({"name": f"test{i}"}, actor="test")

        # Next create should fail
        with self.assertRaises(ConflictError) as context:
            self.soft_crud.create_record({"name": "overflow"}, actor="test")
        self.assertIn("Max 5 records", str(context.exception))

    def test_create_record_validation_error(self) -> None:
        """create_record raises ValidationError on invalid data."""
        # Test with missing required field - name is required for SoftDeleteModel
        try:
            # Try to create with empty dict (missing required 'name' field)
            self.soft_crud.create_record({}, actor="test")
            self.fail("Expected ValidationError, got None")
        except (ValidationError, TypeError, ValueError):
            # Expected - validation should catch missing required fields
            pass

    # ---------------- Update Record ----------------

    def test_update_record(self) -> None:
        """update_record updates an existing record."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="original"), actor="test")
        assert obj.id is not None

        result: SoftDeleteModel = self.soft_crud.update_record(obj.id, {"name": "updated"}, actor="test")
        self.assertEqual(result.name, "updated")
        self.assertEqual(result.id, obj.id)

    def test_update_record_creates_if_not_exists(self) -> None:
        """update_record creates a new record if it doesn't exist."""
        result: SoftDeleteModel = self.soft_crud.update_record(1, {"name": "new"}, actor="test")
        self.assertEqual(result.id, 1)
        self.assertEqual(result.name, "new")

    def test_update_record_not_found_after_creation(self) -> None:
        """update_record raises NotFoundError if record doesn't exist and max_records reached."""
        # Fill up to max
        for i in range(5):
            self.soft_crud.create_record({"name": f"test{i}"}, actor="test")

        # Try to update non-existent record (would create, but max_records prevents it)
        with self.assertRaises(ConflictError):
            self.soft_crud.update_record(999, {"name": "new"}, actor="test")

    # ---------------- Delete Record ----------------

    def test_delete_record(self) -> None:
        """delete_record deletes a record."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        self.soft_crud.delete_record(obj.id, actor="test")

        # Should be soft-deleted
        with self.assertRaises(NotFoundError):
            self.soft_crud.get_record(obj.id, include_deleted=False)

    def test_delete_record_not_found(self) -> None:
        """delete_record raises NotFoundError for missing record."""
        with self.assertRaises(NotFoundError):
            self.soft_crud.delete_record(999_999, actor="test")

    # ---------------- Restore Record ----------------

    def test_restore_record(self) -> None:
        """restore_record restores a soft-deleted record."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None
        self.soft_accessor.delete(obj.id, actor="test")

        result: SoftDeleteModel = self.soft_crud.restore_record(obj.id, actor="test")
        self.assertEqual(result.name, "test")
        self.assertIsNone(result.deleted_at)

        # Should be accessible again
        restored: SoftDeleteModel = self.soft_crud.get_record(obj.id)
        self.assertEqual(restored.name, "test")

    def test_restore_record_already_restored(self) -> None:
        """restore_record returns record as-is if already restored."""
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        # Restore when not deleted should return as-is
        result: SoftDeleteModel = self.soft_crud.restore_record(obj.id, actor="test")
        self.assertEqual(result.name, "test")
        self.assertIsNone(result.deleted_at)

    def test_restore_record_not_found(self) -> None:
        """restore_record raises NotFoundError for missing record."""
        with self.assertRaises(NotFoundError):
            self.soft_crud.restore_record(999_999, actor="test")

    def test_restore_record_unsupported(self) -> None:
        """restore_record raises UnsupportedError for models without soft delete."""
        obj = self.hard_accessor.insert(HardDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        with self.assertRaises(UnsupportedError) as context:
            self.hard_crud.restore_record(obj.id, actor="test")
        self.assertIn("does not support soft delete", str(context.exception))

    # ---------------- Find Records ----------------

    def test_find_records_with_equality_filter(self) -> None:
        """find_records with equality filter returns matching records."""
        self.soft_crud.create_record({"name": "alice"}, actor="test")
        self.soft_crud.create_record({"name": "bob"}, actor="test")
        self.soft_crud.create_record({"name": "charlie"}, actor="test")

        filters: List[Filter] = [{"field": "name", "operation": FilterOperation.EQUALS, "value": "alice"}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "alice")

    def test_find_records_with_multiple_filters(self) -> None:
        """find_records with multiple filters applies AND logic."""
        self.soft_crud.create_record({"name": "alice"}, actor="test")
        self.soft_crud.create_record({"name": "alice"}, actor="test")
        self.soft_crud.create_record({"name": "bob"}, actor="test")

        # Get first alice's ID
        first_alice: SoftDeleteModel = self.soft_crud.find_records(
            [{"field": "name", "operation": FilterOperation.EQUALS, "value": "alice"}]
        )[0]
        assert first_alice.id is not None

        # Find alice with id > first_id
        filters: List[Filter] = [
            {"field": "name", "operation": FilterOperation.EQUALS, "value": "alice"},
            {"field": "id", "operation": FilterOperation.GREATER_THAN, "value": first_alice.id},
        ]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 1)

    def test_find_records_with_in_filter(self) -> None:
        """find_records with IN filter returns matching records."""
        self.soft_crud.create_record({"name": "alice"}, actor="test")
        self.soft_crud.create_record({"name": "bob"}, actor="test")
        self.soft_crud.create_record({"name": "charlie"}, actor="test")

        filters: List[Filter] = [{"field": "name", "operation": FilterOperation.IN, "value": ["alice", "charlie"]}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 2)
        names = {r.name for r in results}
        self.assertEqual(names, {"alice", "charlie"})

    def test_find_records_with_contains_filter(self) -> None:
        """find_records with contains filter for substring search."""
        self.soft_crud.create_record({"name": "alice smith"}, actor="test")
        self.soft_crud.create_record({"name": "bob smith"}, actor="test")
        self.soft_crud.create_record({"name": "charlie jones"}, actor="test")

        filters: List[Filter] = [{"field": "name", "operation": FilterOperation.CONTAINS, "value": "smith"}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 2)
        names = {r.name for r in results}
        self.assertEqual(names, {"alice smith", "bob smith"})

    def test_find_records_with_like_filter(self) -> None:
        """find_records with LIKE pattern filter."""
        self.soft_crud.create_record({"name": "alice@example.com"}, actor="test")
        self.soft_crud.create_record({"name": "bob@example.com"}, actor="test")
        self.soft_crud.create_record({"name": "charlie@other.com"}, actor="test")

        filters: List[Filter] = [{"field": "name", "operation": FilterOperation.LIKE, "value": "%@example.com"}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 2)

    def test_find_records_with_comparison_filters(self) -> None:
        """find_records with comparison operators (gt, gte, lt, lte)."""
        records: List[SoftDeleteModel] = []
        for i in range(5):
            records.append(self.soft_crud.create_record({"name": f"test{i}"}, actor="test"))

        # Get records with id >= 3rd record's id
        third_id = records[2].id
        filters: List[Filter] = [{"field": "id", "operation": FilterOperation.GREATER_THAN_OR_EQUALS, "value": third_id}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 3)  # 3rd, 4th, 5th records

        # Get records with id < 3rd record's id
        filters = [{"field": "id", "operation": FilterOperation.LESS_THAN, "value": third_id}]
        results = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 2)  # 1st, 2nd records

    def test_find_records_with_is_null_filter(self) -> None:
        """find_records with IS NULL filter."""
        self.soft_crud.create_record({"name": "active"}, actor="test")
        obj2: SoftDeleteModel = self.soft_crud.create_record({"name": "deleted"}, actor="test")
        assert obj2.id is not None
        self.soft_crud.delete_record(obj2.id, actor="test")

        # Find records where deleted_at IS NULL
        filters: List[Filter] = [{"field": "deleted_at", "operation": FilterOperation.IS_NULL}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "active")

        # Find records where deleted_at IS NOT NULL
        filters = [{"field": "deleted_at", "operation": FilterOperation.IS_NOT_NULL}]
        results = self.soft_crud.find_records(filters, include_deleted=True)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "deleted")

    def test_find_records_with_pagination(self) -> None:
        """find_records with limit and offset for pagination."""
        # Use accessor directly to bypass max_records limit
        for i in range(10):
            self.soft_accessor.insert(SoftDeleteModel(name=f"test{i}"), actor="test")

        # First page
        results: List[SoftDeleteModel] = self.soft_crud.find_records([], limit=3, offset=0)
        self.assertEqual(len(results), 3)

        # Second page
        results = self.soft_crud.find_records([], limit=3, offset=3)
        self.assertEqual(len(results), 3)

    def test_find_records_with_ordering(self) -> None:
        """find_records with order_by parameter."""
        self.soft_crud.create_record({"name": "zebra"}, actor="test")
        self.soft_crud.create_record({"name": "apple"}, actor="test")
        self.soft_crud.create_record({"name": "banana"}, actor="test")

        # Order by name ascending
        results: List[SoftDeleteModel] = self.soft_crud.find_records([], order_by="name", order_desc=False)
        self.assertEqual(results[0].name, "apple")
        self.assertEqual(results[2].name, "zebra")

        # Order by name descending
        results = self.soft_crud.find_records([], order_by="name", order_desc=True)
        self.assertEqual(results[0].name, "zebra")
        self.assertEqual(results[2].name, "apple")

    def test_find_records_with_combined_options(self) -> None:
        """find_records with filters, pagination, and ordering combined."""
        # Use accessor directly to bypass max_records limit
        for i in range(5):
            self.soft_accessor.insert(SoftDeleteModel(name=f"alice{i}"), actor="test")
        for i in range(5):
            self.soft_accessor.insert(SoftDeleteModel(name=f"bob{i}"), actor="test")

        filters: List[Filter] = [{"field": "name", "operation": FilterOperation.LIKE, "value": "alice%"}]
        results: List[SoftDeleteModel] = self.soft_crud.find_records(filters, order_by="name", order_desc=True, limit=3)
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "alice4")
        self.assertEqual(results[1].name, "alice3")

    def test_find_records_respects_soft_delete(self) -> None:
        """find_records respects soft delete filtering."""
        self.soft_crud.create_record({"name": "active"}, actor="test")
        obj2: SoftDeleteModel = self.soft_crud.create_record({"name": "deleted"}, actor="test")
        assert obj2.id is not None
        self.soft_crud.delete_record(obj2.id, actor="test")

        # By default, soft-deleted excluded
        results: List[SoftDeleteModel] = self.soft_crud.find_records([])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "active")

        # With include_deleted=True
        results = self.soft_crud.find_records([], include_deleted=True)
        self.assertEqual(len(results), 2)

    def test_find_records_invalid_field(self) -> None:
        """find_records raises ValidationError for invalid field."""
        filters: List[Filter] = [{"field": "nonexistent_field", "operation": FilterOperation.EQUALS, "value": "test"}]
        with self.assertRaises(ValidationError) as context:
            self.soft_crud.find_records(filters)
        self.assertIn("Field 'nonexistent_field' not found", str(context.exception))

    def test_find_records_empty_filters(self) -> None:
        """find_records with empty filters returns all records."""
        for i in range(3):
            self.soft_crud.create_record({"name": f"test{i}"}, actor="test")

        results: List[SoftDeleteModel] = self.soft_crud.find_records([])
        self.assertEqual(len(results), 3)
