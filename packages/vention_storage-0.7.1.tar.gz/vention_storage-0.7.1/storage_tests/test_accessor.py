from __future__ import annotations

from typing import List, cast
from sqlmodel import Session, SQLModel, select

from storage import database as db
from storage.accessor import ModelAccessor
from storage.auditor import AuditLog
from storage_tests.fixtures import StorageTestCase, SoftDeleteModel, HardDeleteModel


class TestModelAccessor(StorageTestCase):
    def setUp(self) -> None:
        super().setUp()
        # Accessors under test
        self.soft = ModelAccessor(SoftDeleteModel, "softs")
        self.hard = ModelAccessor(HardDeleteModel, "hards")

    # ----- helpers
    def _count(self, model: type[SQLModel]) -> int:
        with Session(self.engine) as session:
            return len(session.exec(select(model)).all())

    def _audits(self) -> List[AuditLog]:
        with Session(self.engine) as session:
            return cast(
                List[AuditLog],
                session.exec(select(AuditLog).order_by(AuditLog.id)).all(),
            )

    # ----- core CRUD + reads
    def test_insert_and_reads(self) -> None:
        """Tests insert, get, all, and audit creation"""
        thing = self.soft.insert(SoftDeleteModel(name="thing"))
        self.assertIsNotNone(thing.id)
        self.assertEqual(self._count(SoftDeleteModel), 1)

        # get / all
        assert thing.id is not None
        got = self.soft.get(int(thing.id))
        self.assertIsNotNone(got)
        all_rows = self.soft.all()
        self.assertEqual(len(all_rows), 1)

        # get() missing => None (covers branch)
        self.assertIsNone(self.hard.get(999_999))

        # audit created
        audits = self._audits()
        self.assertEqual(len(audits), 1)
        self.assertEqual(audits[0].operation, "create")
        self.assertEqual(audits[0].component, "softs")

    def test_update_and_upsert_alias_and_session_reuse_in_hook(self) -> None:
        """Tests update, upsert alias, and session reuse in hook"""

        @self.soft.before_insert()
        def _spawn_hard(session: Session, instance: SoftDeleteModel) -> None:
            self.hard.insert(HardDeleteModel(name=f"child-{instance.name}"), actor="hook")

        thing = self.soft.insert(SoftDeleteModel(name="parent"))
        self.assertEqual(self._count(SoftDeleteModel), 1)
        self.assertEqual(self._count(HardDeleteModel), 1)

        thing.name = "parent2"
        thing_updated = self.soft.save(thing, actor="tester")
        self.assertEqual(thing_updated.name, "parent2")

        thing_updated_2 = self.soft.save(thing_updated, actor="tester2")
        self.assertEqual(thing_updated_2.name, "parent2")

        operations = [a.operation for a in self._audits()]
        self.assertIn("create", operations)
        self.assertIn("update", operations)

    def test_save_new_with_explicit_id_when_missing(self) -> None:
        """Tests save() with explicit id when missing"""
        thing = SoftDeleteModel(id=123, name="ghost")
        thing_out = self.soft.save(thing)
        self.assertEqual(thing_out.id, 123)
        self.assertEqual(self._count(SoftDeleteModel), 1)

    def test_save_with_none_id_routes_to_insert(self) -> None:
        """Tests save() with None id routes to insert"""
        thing = SoftDeleteModel(name="no-id")
        thing_out = self.soft.save(thing)
        self.assertIsNotNone(thing_out.id)
        self.assertEqual(self._count(SoftDeleteModel), 1)

    def test_delete_soft_and_restore(self) -> None:
        """Tests soft delete and restore"""
        thing = self.soft.insert(SoftDeleteModel(name="victim"))
        thing_id = int(thing.id)  # type: ignore[arg-type]

        # Restore early-return (already active) covers branch
        self.assertTrue(self.soft.restore(thing_id, actor="isaac"))

        # Soft delete
        ok = self.soft.delete(thing_id, actor="isaac")
        self.assertTrue(ok)

        # Default listing excludes soft-deleted
        self.assertEqual(len(self.soft.all()), 0)

        # include_deleted shows it
        included = self.soft.all(include_deleted=True)
        self.assertEqual(len(included), 1)
        self.assertIsNotNone(included[0].deleted_at)

        # get() respects include_deleted
        self.assertIsNone(self.soft.get(thing_id))
        self.assertIsNotNone(self.soft.get(thing_id, include_deleted=True))

        # Restore from soft-delete
        restored = self.soft.restore(thing_id, actor="isaac")
        self.assertTrue(restored)
        self.assertEqual(len(self.soft.all()), 1)
        self.assertIsNone(self.soft.get(thing_id).deleted_at)  # type: ignore[union-attr]

        operations = [audit.operation for audit in self._audits()]
        self.assertIn("soft_delete", operations)
        self.assertIn("restore", operations)

    def test_delete_hard(self) -> None:
        """Tests hard delete"""
        h = self.hard.insert(HardDeleteModel(name="gone"))
        hid = int(h.id)  # type: ignore[arg-type]
        ok = self.hard.delete(hid, actor="x")
        self.assertTrue(ok)
        self.assertEqual(self._count(HardDeleteModel), 0)
        operations = [audit.operation for audit in self._audits()]
        self.assertIn("delete", operations)

    def test_batch_insert_and_delete(self) -> None:
        """Tests batch insert and delete"""
        rows = self.soft.insert_many([SoftDeleteModel(name="a"), SoftDeleteModel(name="b")])
        self.assertEqual(len(rows), 2)
        self.assertEqual(self._count(SoftDeleteModel), 2)

        ids = [int(row.id) for row in rows if row.id is not None]
        # include a bogus id to cover delete_many skip branch
        num_deleted = self.soft.delete_many(ids + [999_999], actor="batch")
        self.assertEqual(num_deleted, len(ids))

        self.assertEqual(len(self.soft.all()), 0)
        self.assertEqual(len(self.soft.all(include_deleted=True)), 2)

    def test_session_reuse_for_reads_and_writes(self) -> None:
        """Tests session reuse for reads and writes"""
        with db.transaction() as session:
            with db.use_session(session):
                # write uses existing session
                thing = self.soft.insert(SoftDeleteModel(name="inside"), actor="x")
                self.assertIsNotNone(thing.id)

                thing.name = "inside2"
                thing_updated = self.soft.save(thing, actor="x")  # still uses existing session
                self.assertEqual(thing_updated.name, "inside2")

                # read uses existing session
                assert thing_updated.id is not None
                self.assertIsNotNone(self.soft.get(int(thing_updated.id)))  # _read_session -> existing
                self.assertEqual(len(self.soft.all()), 1)

                # delete uses existing session
                self.assertIsNotNone(thing_updated.id)
                self.assertTrue(self.soft.delete(int(thing_updated.id), actor="x"))

    def test_hook_decorators_coverage(self) -> None:
        """Tests hook decorators coverage"""
        decorators = [
            self.soft.after_insert,
            self.soft.before_update,
            self.soft.after_update,
            self.soft.before_delete,
            self.soft.after_delete,
        ]
        for decorator in decorators:
            result = decorator()
            self.assertTrue(callable(result))

    def test_read_session_without_existing_session(self) -> None:
        """Tests _read_session creates a new session when CURRENT_SESSION is None"""
        thing = self.soft.insert(SoftDeleteModel(name="test"))
        db.CURRENT_SESSION.set(None)  # ensure clear
        assert thing.id is not None
        result = self.soft.get(int(thing.id))
        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result.name, "test")

    def test_all_with_soft_delete_filtering(self) -> None:
        """Tests all with soft delete filtering"""
        thing = self.soft.insert(SoftDeleteModel(name="deleted"))
        assert thing.id is not None
        self.soft.delete(int(thing.id))
        self.assertEqual(len(self.soft.all()), 0)
        self.assertEqual(len(self.soft.all(include_deleted=True)), 1)

    def test_delete_missing_and_restore_on_non_soft_model(self) -> None:
        """Tests delete missing and restore on non-soft model"""
        # delete: obj is None -> False
        self.assertFalse(self.hard.delete(424242))

        # restore: obj exists but model has no deleted_at -> not hasattr(...) branch
        thing = self.hard.insert(HardDeleteModel(name="thing"))
        assert thing.id is not None
        self.assertFalse(self.hard.restore(int(thing.id)))

    # ----- pagination and sorting tests
    def test_all_with_limit(self) -> None:
        """Tests all() with limit parameter."""
        # Create 5 records
        for i in range(5):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Get first 3
        results = self.soft.all(limit=3)
        self.assertEqual(len(results), 3)

        # Get all without limit
        all_results = self.soft.all()
        self.assertEqual(len(all_results), 5)

    def test_all_with_offset(self) -> None:
        """Tests all() with offset parameter."""
        # Create 5 records
        for i in range(5):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Get records starting from offset 2
        results = self.soft.all(offset=2)
        self.assertEqual(len(results), 3)  # Should get items 2, 3, 4

        # Get records with offset 3
        results = self.soft.all(offset=3)
        self.assertEqual(len(results), 2)  # Should get items 3, 4

    def test_all_with_limit_and_offset(self) -> None:
        """Tests all() with both limit and offset (pagination)."""
        # Create 10 records
        for i in range(10):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Page 1: first 3 records
        page1 = self.soft.all(limit=3, offset=0)
        self.assertEqual(len(page1), 3)

        # Page 2: next 3 records
        page2 = self.soft.all(limit=3, offset=3)
        self.assertEqual(len(page2), 3)

        # Page 3: next 3 records
        page3 = self.soft.all(limit=3, offset=6)
        self.assertEqual(len(page3), 3)

        # Page 4: remaining 1 record
        page4 = self.soft.all(limit=3, offset=9)
        self.assertEqual(len(page4), 1)

    def test_all_with_order_by_ascending(self) -> None:
        """Tests all() with order_by ascending."""
        # Create records with different names
        self.soft.insert(SoftDeleteModel(name="zebra"), actor="test")
        self.soft.insert(SoftDeleteModel(name="apple"), actor="test")
        self.soft.insert(SoftDeleteModel(name="banana"), actor="test")

        # Sort by name ascending
        results = self.soft.all(order_by="name", order_desc=False)
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "apple")
        self.assertEqual(results[1].name, "banana")
        self.assertEqual(results[2].name, "zebra")

    def test_all_with_order_by_descending(self) -> None:
        """Tests all() with order_by descending (most recent first)."""
        # Create records with different names
        self.soft.insert(SoftDeleteModel(name="apple"), actor="test")
        self.soft.insert(SoftDeleteModel(name="zebra"), actor="test")
        self.soft.insert(SoftDeleteModel(name="banana"), actor="test")

        # Sort by name descending
        results = self.soft.all(order_by="name", order_desc=True)
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "zebra")
        self.assertEqual(results[1].name, "banana")
        self.assertEqual(results[2].name, "apple")

    def test_all_with_order_by_id_descending(self) -> None:
        """Tests all() with order_by id descending (newest first, typical for logs)."""
        # Create multiple records
        records = []
        for i in range(5):
            records.append(self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test"))

        # Sort by id descending (newest first)
        results = self.soft.all(order_by="id", order_desc=True)
        self.assertEqual(len(results), 5)

        # Verify descending order (highest ID first)
        ids = [int(r.id) for r in results if r.id is not None]
        self.assertEqual(ids, sorted(ids, reverse=True))

    def test_all_with_pagination_and_sorting(self) -> None:
        """Tests all() with pagination and sorting combined."""
        # Create 10 records
        for i in range(10):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Get page 1: first 3, sorted by id descending (newest first)
        page1 = self.soft.all(limit=3, offset=0, order_by="id", order_desc=True)
        self.assertEqual(len(page1), 3)

        # Verify they're in descending order
        page1_ids = [int(r.id) for r in page1 if r.id is not None]
        self.assertEqual(page1_ids, sorted(page1_ids, reverse=True))

        # Get page 2: next 3
        page2 = self.soft.all(limit=3, offset=3, order_by="id", order_desc=True)
        self.assertEqual(len(page2), 3)

        # Verify page2 IDs are all less than page1 IDs (descending order)
        page2_ids = [int(r.id) for r in page2 if r.id is not None]
        self.assertTrue(all(p2_id < p1_id for p2_id in page2_ids for p1_id in page1_ids))

    def test_all_with_invalid_order_by_field(self) -> None:
        """Tests all() raises ValueError for invalid order_by field."""
        self.soft.insert(SoftDeleteModel(name="test"), actor="test")

        with self.assertRaises(ValueError) as context:
            self.soft.all(order_by="nonexistent_field")
        self.assertIn("Field 'nonexistent_field' not found", str(context.exception))

    def test_all_pagination_with_soft_deleted(self) -> None:
        """Tests pagination respects include_deleted parameter."""
        # Create 5 records
        records = []
        for i in range(5):
            records.append(self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test"))

        # Delete 2 records
        assert records[0].id is not None
        assert records[1].id is not None
        self.soft.delete(int(records[0].id), actor="test")
        self.soft.delete(int(records[1].id), actor="test")

        # Without include_deleted: should get 3 records
        results = self.soft.all(limit=10, include_deleted=False)
        self.assertEqual(len(results), 3)

        # With include_deleted: should get all 5 records
        results = self.soft.all(limit=10, include_deleted=True)
        self.assertEqual(len(results), 5)

    # ----- filtering tests
    def test_find_with_equality_filter(self) -> None:
        """Tests find() with equality filter."""
        self.soft.insert(SoftDeleteModel(name="alice"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob"), actor="test")
        self.soft.insert(SoftDeleteModel(name="charlie"), actor="test")

        results = self.soft.find(self.soft.where.name == "alice")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "alice")

    def test_find_with_not_equal_filter(self) -> None:
        """Tests find() with not-equal filter."""
        self.soft.insert(SoftDeleteModel(name="alice"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob"), actor="test")
        self.soft.insert(SoftDeleteModel(name="charlie"), actor="test")

        results = self.soft.find(self.soft.where.name != "alice")
        self.assertEqual(len(results), 2)
        names = {r.name for r in results}
        self.assertEqual(names, {"bob", "charlie"})

    def test_find_with_multiple_conditions(self) -> None:
        """Tests find() with multiple filter conditions (AND logic)."""
        self.soft.insert(SoftDeleteModel(name="alice"), actor="test")
        self.soft.insert(SoftDeleteModel(name="alice"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob"), actor="test")

        # Find records with name="alice" AND id > first_id
        results = self.soft.find(self.soft.where.name == "alice")
        first_id = results[0].id
        assert first_id is not None

        # Now find alice with id greater than first_id
        filtered = self.soft.find(
            self.soft.where.name == "alice",
            self.soft.where.id > first_id,  # type: ignore[operator]
        )
        self.assertEqual(len(filtered), 1)

    def test_find_with_in_filter(self) -> None:
        """Tests find() with IN filter."""
        self.soft.insert(SoftDeleteModel(name="alice"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob"), actor="test")
        self.soft.insert(SoftDeleteModel(name="charlie"), actor="test")

        # Find names in list
        results = self.soft.find(self.soft.where.name.in_(["alice", "charlie"]))  # type: ignore[attr-defined]
        self.assertEqual(len(results), 2)
        names = {r.name for r in results}
        self.assertEqual(names, {"alice", "charlie"})

    def test_find_with_contains_filter(self) -> None:
        """Tests find() with contains filter (substring search)."""
        self.soft.insert(SoftDeleteModel(name="alice smith"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob smith"), actor="test")
        self.soft.insert(SoftDeleteModel(name="charlie jones"), actor="test")

        # Find names containing "smith"
        results = self.soft.find(self.soft.where.name.contains("smith"))  # type: ignore[attr-defined]
        self.assertEqual(len(results), 2)
        names = {r.name for r in results}
        self.assertEqual(names, {"alice smith", "bob smith"})

    def test_find_with_like_filter(self) -> None:
        """Tests find() with LIKE pattern filter."""
        self.soft.insert(SoftDeleteModel(name="alice@example.com"), actor="test")
        self.soft.insert(SoftDeleteModel(name="bob@example.com"), actor="test")
        self.soft.insert(SoftDeleteModel(name="charlie@other.com"), actor="test")

        # Find emails ending with example.com
        results = self.soft.find(self.soft.where.name.like("%@example.com"))  # type: ignore[attr-defined]
        self.assertEqual(len(results), 2)

    def test_find_with_is_null_filter(self) -> None:
        """Tests find() with IS NULL filter."""
        self.soft.insert(SoftDeleteModel(name="active"), actor="test")
        thing = self.soft.insert(SoftDeleteModel(name="deleted"), actor="test")
        assert thing.id is not None
        self.soft.delete(int(thing.id), actor="test")

        # Find records where deleted_at IS NULL (active records)
        results = self.soft.find(self.soft.where.deleted_at.is_(None))  # type: ignore[union-attr]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "active")

        # Find records where deleted_at IS NOT NULL (deleted records)
        results = self.soft.find(self.soft.where.deleted_at.isnot(None), include_deleted=True)  # type: ignore[union-attr]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "deleted")

    def test_find_with_pagination(self) -> None:
        """Tests find() with limit and offset."""
        for i in range(10):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        # Get first 3
        page1 = self.soft.find(limit=3, offset=0)
        self.assertEqual(len(page1), 3)

        # Get next 3
        page2 = self.soft.find(limit=3, offset=3)
        self.assertEqual(len(page2), 3)

    def test_find_with_ordering(self) -> None:
        """Tests find() with order_by, ascending and descending."""
        self.soft.insert(SoftDeleteModel(name="zebra"), actor="test")
        self.soft.insert(SoftDeleteModel(name="apple"), actor="test")
        self.soft.insert(SoftDeleteModel(name="banana"), actor="test")

        results = self.soft.find(order_by="name", order_desc=False)
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "apple")
        self.assertEqual(results[2].name, "zebra")

        results = self.soft.find(order_by="name", order_desc=True)
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "zebra")
        self.assertEqual(results[2].name, "apple")

    def test_find_with_filter_pagination_and_ordering(self) -> None:
        """Tests find() with filters, pagination, and ordering combined."""
        # Create mix of names
        for i in range(5):
            self.soft.insert(SoftDeleteModel(name=f"alice{i}"), actor="test")
        for i in range(5):
            self.soft.insert(SoftDeleteModel(name=f"bob{i}"), actor="test")

        # Find alice*, order by name desc, get first 3
        results = self.soft.find(
            self.soft.where.name.like("alice%"),  # type: ignore[attr-defined]
            order_by="name",
            order_desc=True,
            limit=3,
        )
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].name, "alice4")
        self.assertEqual(results[1].name, "alice3")
        self.assertEqual(results[2].name, "alice2")

    def test_find_respects_soft_delete(self) -> None:
        """Tests find() respects soft delete filtering."""
        self.soft.insert(SoftDeleteModel(name="active"), actor="test")
        thing2 = self.soft.insert(SoftDeleteModel(name="deleted"), actor="test")
        assert thing2.id is not None
        self.soft.delete(int(thing2.id), actor="test")

        # By default, soft-deleted records are excluded
        results = self.soft.find()
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "active")

        # With include_deleted=True, both are returned
        results = self.soft.find(include_deleted=True)
        self.assertEqual(len(results), 2)

    def test_find_with_invalid_order_by_field(self) -> None:
        """Tests find() raises ValueError for invalid order_by field."""
        self.soft.insert(SoftDeleteModel(name="test"), actor="test")

        with self.assertRaises(ValueError) as context:
            self.soft.find(order_by="nonexistent_field")
        self.assertIn("Field 'nonexistent_field' not found", str(context.exception))

    def test_find_with_no_conditions_returns_all(self) -> None:
        """Tests find() with no conditions returns all records (like all())."""
        for i in range(5):
            self.soft.insert(SoftDeleteModel(name=f"item{i}"), actor="test")

        results = self.soft.find()
        self.assertEqual(len(results), 5)

    def test_where_field_proxy(self) -> None:
        """Tests that accessor.where provides typed access to model fields."""
        # Verify where is the model class
        self.assertEqual(self.soft.where, SoftDeleteModel)

        self.assertTrue(hasattr(self.soft.where, "name"))
        self.assertTrue(hasattr(self.soft.where, "id"))
        self.assertTrue(hasattr(self.soft.where, "deleted_at"))
