"""Tests for vention_communication RPC bundle builder."""

from __future__ import annotations

import asyncio

from communication.entries import RpcBundle
from communication.errors import ConnectError

from storage.vention_communication import build_storage_rpc_bundle
from storage.accessor import ModelAccessor
from storage_tests.fixtures import (
    StorageTestCase,
    SoftDeleteModel,
    HardDeleteModel,
    TestModel,
)


class TestVentionCommunication(StorageTestCase):
    """Tests for build_storage_rpc_bundle."""

    def setUp(self) -> None:
        """Set up test with accessors."""
        super().setUp()
        self.soft_accessor = ModelAccessor(SoftDeleteModel, "softs")
        self.hard_accessor = ModelAccessor(HardDeleteModel, "hards")
        self.test_accessor = ModelAccessor(TestModel, "tests")

    # ---------------- Bundle Structure ----------------

    def test_build_storage_rpc_bundle_creates_bundle(self) -> None:
        """build_storage_rpc_bundle returns an RpcBundle."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        self.assertIsInstance(bundle, RpcBundle)

    def test_build_storage_rpc_bundle_registers_crud_actions(self) -> None:
        """build_storage_rpc_bundle registers CRUD actions for each model."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], max_records_per_model=5)

        # Should have List, Get, Create, Update, Delete, Restore actions
        action_names = [action.name for action in bundle.actions]
        self.assertIn("Softs_ListRecords", action_names)
        self.assertIn("Softs_GetRecord", action_names)
        self.assertIn("Softs_CreateRecord", action_names)
        self.assertIn("Softs_UpdateRecord", action_names)
        self.assertIn("Softs_DeleteRecord", action_names)
        self.assertIn("Softs_RestoreRecord", action_names)

    def test_build_storage_rpc_bundle_multiple_models(self) -> None:
        """build_storage_rpc_bundle registers actions for all models."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor, self.hard_accessor])

        action_names = [action.name for action in bundle.actions]
        # Should have actions for both models
        soft_actions = [name for name in action_names if name.startswith("Softs_")]
        hard_actions = [name for name in action_names if name.startswith("Hards_")]
        self.assertGreater(len(soft_actions), 0)
        self.assertGreater(len(hard_actions), 0)

    def test_build_storage_rpc_bundle_database_actions(self) -> None:
        """build_storage_rpc_bundle includes database actions when enabled."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], enable_db_actions=True)

        action_names = [action.name for action in bundle.actions]
        self.assertIn("Database_Health", action_names)
        self.assertIn("Database_ReadAudit", action_names)
        self.assertIn("Database_ExportZip", action_names)
        self.assertIn("Database_BackupSqlite", action_names)
        self.assertIn("Database_RestoreSqlite", action_names)

    def test_build_storage_rpc_bundle_database_actions_disabled(self) -> None:
        """build_storage_rpc_bundle excludes database actions when disabled."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], enable_db_actions=False)

        action_names = [action.name for action in bundle.actions]
        self.assertNotIn("Database_Health", action_names)
        self.assertNotIn("Database_ReadAudit", action_names)

    # ---------------- Action Execution ----------------

    def test_list_records_action(self) -> None:
        """ListRecords action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_ListRecords")

        # Create some test data
        self.soft_accessor.insert(SoftDeleteModel(name="test1"), actor="test")
        self.soft_accessor.insert(SoftDeleteModel(name="test2"), actor="test")

        # Call the action
        from storage.vention_communication import CrudListRequest

        req = CrudListRequest(include_deleted=False)
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "records"))
        self.assertEqual(len(result.records), 2)

    def test_get_record_action(self) -> None:
        """GetRecord action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_GetRecord")

        # Create test data
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        # Call the action
        from storage.vention_communication import CrudGetRequest

        req = CrudGetRequest(record_id=obj.id, include_deleted=False)
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "record"))
        self.assertEqual(result.record.name, "test")

    def test_get_record_action_not_found(self) -> None:
        """GetRecord action raises ConnectError for not found."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_GetRecord")

        from storage.vention_communication import CrudGetRequest

        req = CrudGetRequest(record_id=999_999, include_deleted=False)

        with self.assertRaises(ConnectError) as context:
            asyncio.run(action.func(req))
        self.assertEqual(context.exception.code, "not_found")

    def test_create_record_action(self) -> None:
        """CreateRecord action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_CreateRecord")

        # Get the CreateRequest type
        create_action = next(a for a in bundle.actions if a.name == "Softs_CreateRecord")
        CreateRequest = create_action.input_type
        assert CreateRequest is not None

        # Create request
        req = CreateRequest(record=SoftDeleteModel(name="new"), actor="test")
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "record"))
        self.assertEqual(result.record.name, "new")

    def test_create_record_action_max_records(self) -> None:
        """CreateRecord action raises ConnectError when max_records exceeded."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], max_records_per_model=2)
        action = next(a for a in bundle.actions if a.name == "Softs_CreateRecord")

        # Fill up to max
        self.soft_accessor.insert(SoftDeleteModel(name="test1"), actor="test")
        self.soft_accessor.insert(SoftDeleteModel(name="test2"), actor="test")

        # Get the CreateRequest type
        CreateRequest = action.input_type
        assert CreateRequest is not None

        # Try to create one more
        req = CreateRequest(record=SoftDeleteModel(name="overflow"), actor="test")

        with self.assertRaises(ConnectError) as context:
            asyncio.run(action.func(req))
        self.assertEqual(context.exception.code, "failed_precondition")

    def test_update_record_action(self) -> None:
        """UpdateRecord action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_UpdateRecord")

        # Create test data
        obj = self.soft_accessor.insert(SoftDeleteModel(name="original"), actor="test")
        assert obj.id is not None

        # Get the UpdateRequest type
        UpdateRequest = action.input_type
        assert UpdateRequest is not None

        # Update request
        req = UpdateRequest(record_id=obj.id, record=SoftDeleteModel(name="updated"), actor="test")
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "record"))
        self.assertEqual(result.record.name, "updated")

    def test_delete_record_action(self) -> None:
        """DeleteRecord action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_DeleteRecord")

        # Create test data
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        # Delete request
        from storage.vention_communication import CrudDeleteRequest

        req = CrudDeleteRequest(record_id=obj.id, actor="test")
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "status"))

        # Verify record is deleted
        with self.assertRaises(ConnectError):
            from storage.vention_communication import CrudGetRequest

            get_action = next(a for a in bundle.actions if a.name == "Softs_GetRecord")
            get_req = CrudGetRequest(record_id=obj.id, include_deleted=False)
            asyncio.run(get_action.func(get_req))

    def test_restore_record_action(self) -> None:
        """RestoreRecord action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor])
        action = next(a for a in bundle.actions if a.name == "Softs_RestoreRecord")

        # Create and delete test data
        obj = self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="test")
        assert obj.id is not None
        self.soft_accessor.delete(obj.id, actor="test")

        # Restore request
        from storage.vention_communication import CrudRestoreRequest

        req = CrudRestoreRequest(record_id=obj.id, actor="test")
        result = asyncio.run(action.func(req))

        # Verify result
        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "record"))
        self.assertEqual(result.record.name, "test")

    def test_restore_record_action_unsupported(self) -> None:
        """RestoreRecord action raises ConnectError for models without soft delete."""
        bundle = build_storage_rpc_bundle(accessors=[self.hard_accessor])
        action = next(a for a in bundle.actions if a.name == "Hards_RestoreRecord")

        # Create test data
        obj = self.hard_accessor.insert(HardDeleteModel(name="test"), actor="test")
        assert obj.id is not None

        from storage.vention_communication import CrudRestoreRequest

        req = CrudRestoreRequest(record_id=obj.id, actor="test")

        with self.assertRaises(ConnectError) as context:
            asyncio.run(action.func(req))
        self.assertEqual(context.exception.code, "failed_precondition")

    # ---------------- Database Actions ----------------

    def test_database_health_action(self) -> None:
        """Database_Health action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], enable_db_actions=True)
        action = next(a for a in bundle.actions if a.name == "Database_Health")

        result = asyncio.run(action.func())

        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "status"))
        self.assertEqual(result.status, "ok")

    def test_database_audit_action(self) -> None:
        """Database_ReadAudit action works correctly."""
        bundle = build_storage_rpc_bundle(accessors=[self.soft_accessor], enable_db_actions=True)
        action = next(a for a in bundle.actions if a.name == "Database_ReadAudit")

        # Create some audit entries
        self.soft_accessor.insert(SoftDeleteModel(name="test"), actor="user1")

        from storage.vention_communication import AuditQueryRequest

        req = AuditQueryRequest(component="softs", limit=10)
        result = asyncio.run(action.func(req))

        self.assertIsNotNone(result)
        self.assertTrue(hasattr(result, "records"))
        self.assertGreater(len(result.records), 0)

    # ---------------- Validation Tests ----------------

    def test_crud_list_request_invalid_limit_zero(self) -> None:
        """CrudListRequest raises ValueError for limit=0."""
        from storage.vention_communication import CrudListRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            CrudListRequest(limit=0)
        errors = context.exception.errors()
        self.assertTrue(any("greater than 0" in str(err.get("msg", "")).lower() for err in errors))

    def test_crud_list_request_invalid_limit_negative(self) -> None:
        """CrudListRequest raises ValueError for negative limit."""
        from storage.vention_communication import CrudListRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            CrudListRequest(limit=-1)
        errors = context.exception.errors()
        self.assertTrue(any("greater than 0" in str(err.get("msg", "")).lower() for err in errors))

    def test_crud_list_request_invalid_offset_negative(self) -> None:
        """CrudListRequest raises ValueError for negative offset."""
        from storage.vention_communication import CrudListRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            CrudListRequest(offset=-1)
        errors = context.exception.errors()
        self.assertTrue(
            any(
                "greater than or equal to 0" in str(err.get("msg", "")).lower() or "ge=0" in str(err.get("msg", "")).lower()
                for err in errors
            )
        )

    def test_audit_query_request_invalid_limit_zero(self) -> None:
        """AuditQueryRequest raises ValueError for limit=0."""
        from storage.vention_communication import AuditQueryRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            AuditQueryRequest(limit=0)
        errors = context.exception.errors()
        self.assertTrue(any("greater than 0" in str(err.get("msg", "")).lower() for err in errors))

    def test_audit_query_request_invalid_limit_negative(self) -> None:
        """AuditQueryRequest raises ValueError for negative limit."""
        from storage.vention_communication import AuditQueryRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            AuditQueryRequest(limit=-1)
        errors = context.exception.errors()
        self.assertTrue(any("greater than 0" in str(err.get("msg", "")).lower() for err in errors))

    def test_audit_query_request_invalid_offset_negative(self) -> None:
        """AuditQueryRequest raises ValueError for negative offset."""
        from storage.vention_communication import AuditQueryRequest
        from pydantic import ValidationError as PydanticValidationError

        with self.assertRaises(PydanticValidationError) as context:
            AuditQueryRequest(offset=-1)
        errors = context.exception.errors()
        self.assertTrue(
            any(
                "greater than or equal to 0" in str(err.get("msg", "")).lower() or "ge=0" in str(err.get("msg", "")).lower()
                for err in errors
            )
        )
