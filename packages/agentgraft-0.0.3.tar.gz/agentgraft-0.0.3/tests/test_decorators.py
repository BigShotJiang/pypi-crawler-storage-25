"""Unit tests for ``@ag.tool``, ``@ag.agent``, ``@ag.user_loader``, ``ag.graft``."""

import agentgraft as ag
import pytest
from agentgraft import get_registry

# ---------------------------------------------------------------------------
# @ag.tool
# ---------------------------------------------------------------------------


class TestToolDecorator:
    def test_bare_decorator_registers(self):
        @ag.tool
        def list_things(user) -> list[dict]:
            """List things."""
            return []

        reg = get_registry()
        assert "list_things" in reg.tools
        assert reg.tools["list_things"].description == "List things."

    def test_with_explicit_description(self):
        @ag.tool(description="Custom desc.")
        def t(user) -> str:
            return ""

        assert get_registry().tools["t"].description == "Custom desc."

    def test_function_name_becomes_tool_name(self):
        @ag.tool
        def my_tool_name(user) -> int:
            """X."""
            return 0

        assert "my_tool_name" in get_registry().tools

    def test_first_param_is_skipped_in_schema(self):
        @ag.tool
        def with_args(user, query: str, limit: int = 5) -> list:
            """Search."""
            return []

        schema = get_registry().tools["with_args"].parameters_schema
        # 'user' must NOT appear in the schema
        assert "user" not in schema["properties"]
        assert set(schema["properties"].keys()) == {"query", "limit"}
        assert "query" in schema["required"]
        assert "limit" not in schema["required"]  # has default

    def test_no_params_raises(self):
        with pytest.raises(ValueError, match="at least one parameter"):

            @ag.tool
            def bad():
                """Bad."""

    def test_missing_docstring_raises(self):
        with pytest.raises(ValueError, match="missing description"):

            @ag.tool
            def bad(user):
                pass

    def test_missing_type_hint_raises(self):
        with pytest.raises(ValueError, match="missing a type hint"):

            @ag.tool
            def bad(user, untyped):
                """Bad."""

    def test_returns_original_function(self):
        @ag.tool
        def round_trip(user) -> int:
            """X."""
            return 42

        # The decorator must return the function so the developer can still
        # call it directly (in tests, in unit tests of the host app).
        assert round_trip.__name__ == "round_trip"

    def test_duplicate_name_raises(self):
        @ag.tool
        def same(user) -> int:
            """X."""
            return 1

        with pytest.raises(ValueError, match="already registered"):

            @ag.tool
            def same(user) -> int:  # noqa: F811
                """Y."""
                return 2


# ---------------------------------------------------------------------------
# @ag.agent
# ---------------------------------------------------------------------------


class TestAgentDecorator:
    def test_basic_registration(self):
        @ag.agent
        def helper():
            """You are the helper agent."""

        reg = get_registry().agents["helper"]
        assert reg.instructions == "You are the helper agent."
        assert reg.is_entry_point is False
        assert reg.model_tier == "auto"

    def test_entry_point_flag(self):
        @ag.agent(entry=True)
        def main():
            """Entry point."""

        assert get_registry().agents["main"].is_entry_point is True

    def test_model_tier(self):
        @ag.agent(model="pro")
        def smart():
            """Smart agent."""

        assert get_registry().agents["smart"].model_tier == "pro"

    def test_tool_refs_resolved_to_names(self):
        @ag.tool
        def tool_a(user) -> int:
            """A."""
            return 1

        @ag.tool
        def tool_b(user) -> int:
            """B."""
            return 2

        @ag.agent(tools=[tool_a, tool_b])
        def consumer():
            """Uses tools."""

        agent_reg = get_registry().agents["consumer"]
        assert agent_reg.tool_names == ["tool_a", "tool_b"]

    def test_handoff_refs_can_be_strings(self):
        @ag.agent(handoffs=["other_agent"])
        def first():
            """X."""

        assert get_registry().agents["first"].handoff_names == ["other_agent"]

    def test_handoff_refs_can_be_callables(self):
        @ag.agent
        def target():
            """T."""

        @ag.agent(handoffs=[target])
        def source():
            """S."""

        assert get_registry().agents["source"].handoff_names == ["target"]

    def test_missing_docstring_raises(self):
        with pytest.raises(ValueError, match="missing docstring"):

            @ag.agent
            def bad():
                pass

    def test_invalid_tool_ref_raises(self):
        with pytest.raises(ValueError, match="reference must be"):

            @ag.agent(tools=[42])
            def bad():
                """X."""

    def test_duplicate_agent_raises(self):
        @ag.agent
        def same():
            """X."""

        with pytest.raises(ValueError, match="already registered"):

            @ag.agent
            def same():  # noqa: F811
                """Y."""


# ---------------------------------------------------------------------------
# @ag.user_loader
# ---------------------------------------------------------------------------


class TestUserLoaderDecorator:
    def test_registers_callback(self):
        @ag.user_loader
        def load(external_id: str):
            return {"id": external_id}

        loader = get_registry().user_loader
        assert loader is not None
        assert loader("42") == {"id": "42"}

    def test_double_registration_raises(self):
        @ag.user_loader
        def load(x: str):
            return x

        with pytest.raises(ValueError, match="already registered"):

            @ag.user_loader
            def load2(x: str):  # noqa: F811
                return x


# ---------------------------------------------------------------------------
# ag.graft(...)
# ---------------------------------------------------------------------------


class TestGraftConfig:
    def test_sets_all_fields(self):
        ag.graft(
            name="MyApp",
            identity="I am here.",
            product_context="We do things.",
            voice="Be concise.",
            scope="Investing only.",
            policies="No advice.",
            webhook_url="https://example.com/wh",
        )
        cfg = get_registry().graft_config
        assert cfg.name == "MyApp"
        assert cfg.identity == "I am here."
        assert cfg.product_context == "We do things."
        assert cfg.voice == "Be concise."
        assert cfg.scope == "Investing only."
        assert cfg.policies == ["No advice."]
        assert cfg.webhook_url == "https://example.com/wh"

    def test_partial_config(self):
        ag.graft(identity="I.", voice="V.")
        cfg = get_registry().graft_config
        assert cfg.identity == "I."
        assert cfg.voice == "V."
        assert cfg.product_context == ""
        assert cfg.scope == ""

    def test_strips_whitespace_from_text_fields(self):
        ag.graft(identity="  \n  Hello.  \n  ")
        assert get_registry().graft_config.identity == "Hello."

    def test_can_be_called_multiple_times(self):
        ag.graft(identity="first")
        ag.graft(identity="second")
        assert get_registry().graft_config.identity == "second"
