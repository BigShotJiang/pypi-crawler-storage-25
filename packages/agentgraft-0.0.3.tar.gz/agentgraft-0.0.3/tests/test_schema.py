"""Unit tests for ``build_parameters_schema``."""

import inspect

import pytest
from agentgraft.schema import build_parameters_schema


def _params(*specs):
    """Helper: build a list of inspect.Parameter from (name, type, default) tuples."""
    out = []
    for spec in specs:
        name, ann = spec[0], spec[1]
        default = spec[2] if len(spec) > 2 else inspect.Parameter.empty
        out.append(
            inspect.Parameter(
                name,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=ann,
                default=default,
            )
        )
    return out


class TestBuildParametersSchema:
    def test_empty_params_yields_empty_object_schema(self):
        schema = build_parameters_schema([])
        assert schema == {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        }

    def test_primitive_str_int_bool(self):
        schema = build_parameters_schema(_params(("name", str), ("count", int), ("active", bool)))
        assert schema["properties"]["name"] == {"type": "string"}
        assert schema["properties"]["count"] == {"type": "integer"}
        assert schema["properties"]["active"] == {"type": "boolean"}
        assert set(schema["required"]) == {"name", "count", "active"}

    def test_float_maps_to_number(self):
        schema = build_parameters_schema(_params(("price", float)))
        assert schema["properties"]["price"] == {"type": "number"}

    def test_optional_makes_param_non_required(self):
        schema = build_parameters_schema(_params(("limit", int | None)))
        assert schema["properties"]["limit"] == {"type": "integer"}
        assert "limit" not in schema["required"]

    def test_default_makes_param_non_required(self):
        schema = build_parameters_schema(_params(("limit", int, 10)))
        assert "limit" not in schema["required"]

    def test_list_of_str(self):
        schema = build_parameters_schema(_params(("tags", list[str])))
        assert schema["properties"]["tags"] == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_bare_list(self):
        schema = build_parameters_schema(_params(("items", list)))
        assert schema["properties"]["items"]["type"] == "array"

    def test_dict_maps_to_object(self):
        schema = build_parameters_schema(_params(("meta", dict)))
        assert schema["properties"]["meta"] == {"type": "object"}

    def test_missing_annotation_raises(self):
        with pytest.raises(ValueError, match="missing a type hint"):
            build_parameters_schema(_params(("name", inspect.Parameter.empty)))

    def test_additional_properties_is_false(self):
        schema = build_parameters_schema(_params(("x", int)))
        assert schema["additionalProperties"] is False

    def test_required_order_matches_param_order(self):
        schema = build_parameters_schema(_params(("a", int), ("b", str), ("c", bool)))
        assert schema["required"] == ["a", "b", "c"]
