"""Generate JSON Schema fragments from Python type hints.

Used by the ``@ag.tool`` decorator to build the ``parameters_schema`` that
gets pushed to AgentGraft and shown to the LLM. Supports the subset of
type hints we expect to see in real-world chat tool signatures:

  - primitives: str, int, float, bool
  - container types: list, list[T], dict
  - Optional[T] / T | None  → makes the parameter non-required
  - default values → make the parameter non-required regardless of type

Anything more exotic (Pydantic models, Literal, Enum, Annotated metadata,
custom typing protocols) is deliberately deferred to v0.2 — they're not
worth the complexity until a real customer asks.
"""

import inspect
import typing
from typing import Any

_PRIMITIVE_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def build_parameters_schema(params: list[inspect.Parameter]) -> dict:
    """Build a JSON Schema ``object`` from a list of inspect parameters.

    Each parameter must carry a type annotation. Parameters without one
    raise ``ValueError`` so the developer fixes their tool signature
    before sync time rather than discovering a runtime crash later.
    """
    properties: dict[str, dict] = {}
    required: list[str] = []

    for param in params:
        if param.annotation is inspect.Parameter.empty:
            raise ValueError(
                f"Tool parameter {param.name!r} is missing a type hint. "
                f"Add one (e.g. `{param.name}: int`) so AgentGraft can "
                "build the JSON schema for the LLM."
            )

        properties[param.name] = _annotation_to_schema(param.annotation)

        # A parameter is required iff (a) it has no default AND (b) the type
        # is not Optional. Optional[X] alone makes it non-required because
        # the LLM is allowed to omit it.
        has_default = param.default is not inspect.Parameter.empty
        is_optional = _is_optional_type(param.annotation)
        if not has_default and not is_optional:
            required.append(param.name)

    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _annotation_to_schema(ann: Any) -> dict:
    """Translate one Python annotation to a JSON Schema fragment."""
    origin = typing.get_origin(ann)
    args = typing.get_args(ann)

    # Optional[X] / Union[X, None] → strip the None and recurse
    if origin is typing.Union:
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _annotation_to_schema(non_none[0])
        # General union → use anyOf
        return {"anyOf": [_annotation_to_schema(a) for a in non_none]}

    # list[T] → array of items
    if origin is list:
        if args:
            return {"type": "array", "items": _annotation_to_schema(args[0])}
        return {"type": "array"}

    # dict[K, V] → object (we don't bother with key/value schemas)
    if origin is dict:
        return {"type": "object"}

    # Primitive type
    if isinstance(ann, type) and ann in _PRIMITIVE_TYPE_MAP:
        return {"type": _PRIMITIVE_TYPE_MAP[ann]}

    # Bare ``list`` or ``dict`` (no parameterisation)
    if ann is list:
        return {"type": "array"}
    if ann is dict:
        return {"type": "object"}

    # Unknown — fall through to ``any``. Better to silently accept than
    # crash sync for an exotic type the developer might have a reason for.
    return {}


def _is_optional_type(ann: Any) -> bool:
    """``True`` if the annotation is ``Optional[X]`` or ``X | None``."""
    origin = typing.get_origin(ann)
    if origin is typing.Union:
        return type(None) in typing.get_args(ann)
    return False
