"""AgentGraft SDK — define your chat config in code.

The PyPI distribution is named ``agentgraft`` (``pip install agentgraft``)
but the Python import path is ``agentgraft`` so it never collides with
a host application's own ``agentgraft/`` Django package.

Typical usage::

    import agentgraft as ag

    @ag.user_loader
    def load_user(external_id: str):
        return User.objects.get(pk=external_id)

    @ag.tool
    def list_datasets(user) -> list[dict]:
        '''List the user's datasets.'''
        return list(user.datasets.values('id', 'name'))

    @ag.agent(entry=True, tools=[list_datasets])
    def helper():
        '''You help users explore their datasets.'''

    ag.graft(
        name="MyApp",
        identity="You are MyApp's assistant.",
        voice="Be concise.",
    )
"""

from .decorators import agent, graft, policy, tool, user_loader
from .registry import (
    DEFAULT_PROFILE,
    AgentRegistration,
    GraftConfig,
    PolicyRef,
    Registry,
    ToolRegistration,
    get_all_profiles,
    get_registry,
    reset_registry,
)
from .webhook import WebhookError, handle_webhook

__version__ = "0.0.3"

__all__ = [
    # Decorators (public DSL)
    "tool",
    "agent",
    "graft",
    "policy",
    "user_loader",
    # Registry introspection (sync command, tests)
    "Registry",
    "ToolRegistration",
    "AgentRegistration",
    "GraftConfig",
    "PolicyRef",
    "get_registry",
    "get_all_profiles",
    "reset_registry",
    "DEFAULT_PROFILE",
    # Webhook handling (Django adapter, third-party adapters)
    "handle_webhook",
    "WebhookError",
    # Version
    "__version__",
]
