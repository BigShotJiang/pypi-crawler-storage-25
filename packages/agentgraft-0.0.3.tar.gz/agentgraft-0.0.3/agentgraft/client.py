"""Tiny stdlib-only HTTP client for the AgentGraft admin API.

The SDK avoids extra dependencies — no ``requests``, no ``httpx``. Sync
operations against the admin API (push config, fetch graft state) happen
through ``urllib`` because they're called from one place (the management
command) and don't need streaming or connection pooling.

Tool dispatch is a separate concern handled by the AgentGraft service, not
the SDK, so this client never has to talk to that path.
"""

import json
import urllib.error
import urllib.parse
import urllib.request


class APIError(Exception):
    """The AgentGraft admin API returned a non-2xx response."""

    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body
        super().__init__(f"HTTP {status_code}: {body[:200]}")


class Client:
    """Minimal Bearer-auth JSON client for the AgentGraft admin API."""

    def __init__(self, *, api_base: str, api_key: str, timeout: int = 30) -> None:
        if not api_base:
            raise ValueError("Client(api_base=...) is required")
        if not api_key:
            raise ValueError("Client(api_key=...) is required")
        self.api_base = api_base.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

    # ── high-level operations ────────────────────────────────────────────

    def sync_graft(self, *, graft_id: str, payload: dict) -> dict:
        """POST a sync payload to ``/api/v1/admin/grafts/{id}/sync/``."""
        url = f"{self.api_base}/api/v1/admin/grafts/{graft_id}/sync/"
        return self._post_json(url, payload)

    def fetch_policy(self, codename: str) -> dict:
        """GET a single Policy Shop entry by codename.

        Used by the sync command to resolve ``ag.policy(...)``
        references into the actual prompt fragment text before push.
        Codenames contain a literal slash (``agentgraft/mermaid-strict``)
        which urllib already handles correctly because the slash is a
        legal path character.

        The endpoint is unauthenticated — the catalogue is global and
        identical for every customer — so we deliberately do NOT send
        the Bearer token here. That keeps the public-API contract
        clean even if a developer runs ``agentgraft_sync`` with a
        bogus API key while debugging the policy reference.

        Raises :class:`APIError` with status 404 if the codename
        doesn't exist in the catalogue.
        """
        # Quote the codename so spaces or other punctuation never
        # break the URL. The slash inside ``agentgraft/foo`` is
        # preserved because we mark it as a safe character.
        safe_codename = urllib.parse.quote(codename, safe="/")
        url = f"{self.api_base}/api/v1/policies/{safe_codename}/"
        return self._get_json(url)

    # ── low-level transport ──────────────────────────────────────────────

    def _post_json(self, url: str, body: dict) -> dict:
        data = json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
            },
            method="POST",
        )
        return self._do_request(request)

    def _get_json(self, url: str) -> dict:
        """GET a JSON resource. No Authorization header — used for
        the unauthenticated public Policy Shop endpoint.
        """
        request = urllib.request.Request(
            url,
            headers={"Accept": "application/json"},
            method="GET",
        )
        return self._do_request(request)

    def _do_request(self, request: urllib.request.Request) -> dict:
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                response_body = response.read()
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            raise APIError(exc.code, error_body) from exc
        except urllib.error.URLError as exc:
            raise APIError(0, f"Network error: {exc.reason}") from exc

        if not response_body:
            return {}
        try:
            return json.loads(response_body)
        except json.JSONDecodeError as exc:
            raise APIError(200, f"Response was not valid JSON: {response_body[:200]!r}") from exc
