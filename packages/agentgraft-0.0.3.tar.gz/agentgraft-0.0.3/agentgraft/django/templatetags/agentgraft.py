"""``{% agentgraft_widget %}`` template tag.

Drops the embed script tag into a Django template, with everything the
widget needs to bootstrap itself: the embed script src, the graft id, a
stable per-visitor ``data-user-id``, an HMAC signature of that id, and a
``data-anonymous`` flag.

The host developer never has to think about identity. The tag inspects
``request.user`` and chooses one of two strategies:

- **Authenticated visitor** → ``data-user-id="user:{user.pk}"``,
  ``data-anonymous="false"``.
- **Anonymous visitor** → the tag ensures a Django session exists,
  reads its session key, and uses ``data-user-id="session:{key}"``
  with ``data-anonymous="true"``. The session key is cookie-backed by
  Django so the same browser keeps the same identity across requests
  (and across refreshes), which means anonymous visitors get persistent
  conversation history without the host writing any extra code.

The HMAC is computed server-side with the matching profile's
``webhook_secret``, so the page render is fully trusted — the widget
never has to mint or sign anything itself.

The tag accepts an optional ``profile`` argument so a single template
can host any number of named widgets (e.g. ``{% agentgraft_widget %}``
on dashboard pages and ``{% agentgraft_widget profile="public" %}`` on
the marketing landing page).
"""

import hashlib
import hmac

from django import template
from django.utils.safestring import mark_safe

from ...registry import DEFAULT_PROFILE
from ..settings_helpers import get_profile_config

register = template.Library()


@register.simple_tag(takes_context=True)
def agentgraft_widget(context, profile: str = DEFAULT_PROFILE) -> str:
    """Render the script tag that boots the AgentGraft widget.

    Reads the per-profile connection details out of the host's
    ``AGENTGRAFT["profiles"]`` settings and emits the exact data
    attributes that ``embed.js`` expects:

    - ``data-public-key``  — the graft's browser-safe ``pk_*`` token
    - ``data-user-id``     — namespaced visitor id (``user:{pk}`` or ``session:{key}``)
    - ``data-user-hmac``   — HMAC-SHA256 of user-id with the webhook secret
    - ``data-api-base``    — base URL of the AgentGraft service
    - ``data-anonymous``   — ``"true"`` for session-keyed visitors, ``"false"`` otherwise
    """
    profile_config = get_profile_config(profile)
    api_base = (profile_config.get("api_base") or "").rstrip("/")
    public_key = profile_config.get("public_key") or ""
    secret = profile_config.get("webhook_secret") or ""

    if not (api_base and public_key and secret):
        return mark_safe(
            f"<!-- agentgraft_widget: profile {profile!r} is missing one of "
            "api_base / public_key / webhook_secret in AGENTGRAFT settings -->"
        )

    request = context.get("request")
    external_id, is_anonymous = _resolve_visitor_identity(request)
    signature = _sign(secret, external_id)

    # The embed bundle is an ES module in BOTH dev and prod:
    #
    # - In dev, ``/embed.js`` redirects to the Vite dev server, which
    #   serves unbundled ES module source.
    # - In prod, ``/embed.js`` is the Vite-built bundle, which uses ES
    #   module ``export`` statements at the top level (Vite's default
    #   library output format).
    #
    # Either way, the browser needs ``type="module"`` to parse it
    # without throwing ``Unexpected token 'export'``. We always emit
    # the attribute. (Earlier versions of this tag conditioned on
    # ``settings.DEBUG`` and broke production silently — see SDK
    # v0.0.1 release notes.)
    return mark_safe(
        f'<script type="module" src="{api_base}/embed.js" '
        f'data-public-key="{public_key}" '
        f'data-user-id="{external_id}" '
        f'data-user-hmac="{signature}" '
        f'data-api-base="{api_base}" '
        f'data-anonymous="{"true" if is_anonymous else "false"}" '
        f"async></script>"
    )


def _resolve_visitor_identity(request) -> tuple[str, bool]:
    """Return ``(external_id, is_anonymous)`` for the current request.

    Authenticated users get ``"user:{pk}"``. Anonymous visitors get
    ``"session:{session_key}"`` after the SDK ensures a session exists.
    The namespacing prefix lets the host's user_loader tell the two
    apart without a parallel "type" parameter.

    If the request object isn't available (template rendered outside an
    HTTP request, e.g. by an offline render command), the tag falls back
    to a static ``"session:offline"`` placeholder so the page still
    renders — but the resulting widget will pin every offline visitor to
    the same conversation, so don't render the tag offline in production.
    """
    if request is None:
        return "session:offline", True

    user = getattr(request, "user", None)
    if user is not None and getattr(user, "is_authenticated", False):
        return f"user:{user.pk}", False

    # Anonymous: ensure a session exists, then use its key.
    session = getattr(request, "session", None)
    if session is None:
        return "session:offline", True

    if not session.session_key:
        # Force Django to mint and persist a new session key. This sets
        # the sessionid cookie on the response, so the same browser will
        # come back with the same key on subsequent requests.
        session.create()

    return f"session:{session.session_key}", True


def _sign(secret: str, external_id: str) -> str:
    return hmac.new(
        secret.encode(),
        external_id.encode(),
        hashlib.sha256,
    ).hexdigest()
