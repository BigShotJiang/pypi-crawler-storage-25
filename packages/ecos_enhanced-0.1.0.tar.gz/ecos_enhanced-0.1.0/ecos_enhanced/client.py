"""한국은행 ECOS API 비동기 클라이언트.

경제 통계 데이터(기준금리, 환율, 소비자물가 등)를 조회합니다.
API 문서: https://ecos.bok.or.kr/api/
"""

import os
from dataclasses import dataclass
from typing import Any

import httpx


BASE_URL = "https://ecos.bok.or.kr/api"


# 주요 통계 코드 레지스트리
STAT_CODES: dict[str, dict[str, str]] = {
    # 금리
    "base_rate": {
        "code": "722Y001",
        "item": "0101000",
        "cycle": "M",
        "name": "한국은행 기준금리",
        "unit": "연%",
    },
    "cd_rate": {
        "code": "817Y002",
        "item": "010502000",
        "cycle": "D",
        "name": "CD(91일) 금리",
        "unit": "연%",
    },
    "treasury_3y": {
        "code": "817Y002",
        "item": "010200000",
        "cycle": "D",
        "name": "국고채(3년) 금리",
        "unit": "연%",
    },
    "treasury_10y": {
        "code": "817Y002",
        "item": "010210000",
        "cycle": "D",
        "name": "국고채(10년) 금리",
        "unit": "연%",
    },
    # 환율
    "usd_krw": {
        "code": "731Y003",
        "item": "0000003",
        "cycle": "D",
        "name": "원/달러 환율(종가)",
        "unit": "원",
    },
    "jpy_krw": {
        "code": "731Y003",
        "item": "0000007",
        "cycle": "D",
        "name": "원/100엔 환율(종가)",
        "unit": "원",
    },
    "eur_krw": {
        "code": "731Y003",
        "item": "0000005",
        "cycle": "D",
        "name": "원/유로 환율(종가)",
        "unit": "원",
    },
    "cny_krw": {
        "code": "731Y003",
        "item": "0000027",
        "cycle": "D",
        "name": "원/위안 환율(종가)",
        "unit": "원",
    },
    # 물가
    "cpi": {
        "code": "901Y009",
        "item": "0",
        "cycle": "M",
        "name": "소비자물가지수(총지수)",
        "unit": "2020=100",
    },
    # 통화
    "m2": {
        "code": "101Y003",
        "item": "BBGA00",
        "cycle": "M",
        "name": "M2(광의통화)",
        "unit": "십억원",
    },
    # GDP
    "gdp": {
        "code": "200Y002",
        "item": "10111",
        "cycle": "Q",
        "name": "실질 국내총생산(GDP)",
        "unit": "십억원",
    },
}


@dataclass
class EcosDataPoint:
    """ECOS 데이터 포인트."""

    stat_code: str
    stat_name: str
    item_name: str
    time: str  # YYYYMM or YYYYMMDD
    value: float
    unit: str


class EcosClient:
    """한국은행 ECOS API 비동기 클라이언트.

    Args:
        api_key: ECOS API 인증키. 미지정 시 환경변수 ``ECOS_API_KEY``에서 읽음.

    Example::

        async with EcosClient(api_key="YOUR_KEY") as client:
            data = await client.get_base_rate("202401", "202412")
            for d in data:
                print(f"{d.time}: {d.value}%")
    """

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.environ.get("ECOS_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "ECOS API 키가 필요합니다. "
                "환경변수 ECOS_API_KEY 또는 생성자에 전달하세요."
            )
        self._client = httpx.AsyncClient(timeout=30.0)

    async def close(self) -> None:
        """HTTP 클라이언트를 종료합니다."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def _request(
        self,
        service: str,
        params: list[str],
    ) -> dict:
        """ECOS API 요청."""
        parts = [BASE_URL, service, self.api_key, "json", "kr"] + params
        url = "/".join(parts)

        resp = await self._client.get(url)
        resp.raise_for_status()
        data = resp.json()

        if "RESULT" in data:
            code = data["RESULT"].get("CODE", "")
            msg = data["RESULT"].get("MESSAGE", "")
            if code == "INFO-200":
                return {"rows": []}  # 데이터 없음
            raise EcosApiError(f"ECOS API 오류: {msg} ({code})", code)

        return data

    # ── 범용 조회 ──

    async def get_statistic(
        self,
        stat_code: str,
        cycle: str,
        start_date: str,
        end_date: str,
        item_code: str,
        start_no: int = 1,
        end_no: int = 1000,
    ) -> list[EcosDataPoint]:
        """통계 데이터를 조회합니다.

        Args:
            stat_code: 통계표 코드
            cycle: 주기 (D=일, M=월, Q=분기, A=연)
            start_date: 시작일 (YYYYMMDD 또는 YYYYMM)
            end_date: 종료일
            item_code: 통계항목 코드
            start_no: 조회 시작 번호
            end_no: 조회 끝 번호

        Returns:
            EcosDataPoint 리스트
        """
        data = await self._request(
            "StatisticSearch",
            [
                str(start_no),
                str(end_no),
                stat_code,
                cycle,
                start_date,
                end_date,
                item_code,
            ],
        )

        rows = data.get("StatisticSearch", {}).get("row", [])
        result = []
        for row in rows:
            val_str = row.get("DATA_VALUE", "")
            try:
                value = float(val_str.replace(",", ""))
            except (ValueError, TypeError):
                continue

            result.append(
                EcosDataPoint(
                    stat_code=row.get("STAT_CODE", ""),
                    stat_name=row.get("STAT_NAME", ""),
                    item_name=row.get("ITEM_NAME1", ""),
                    time=row.get("TIME", ""),
                    value=value,
                    unit=row.get("UNIT_NAME", ""),
                )
            )
        return result

    # ── 레지스트리 기반 편의 메서드 ──

    async def get_by_key(
        self,
        key: str,
        start_date: str,
        end_date: str,
    ) -> list[EcosDataPoint]:
        """STAT_CODES 레지스트리 키로 간편 조회.

        Args:
            key: STAT_CODES 키 (예: ``"base_rate"``, ``"usd_krw"``)
            start_date: 시작일
            end_date: 종료일
        """
        if key not in STAT_CODES:
            raise ValueError(
                f"알 수 없는 키: {key}. 사용 가능: {list(STAT_CODES.keys())}"
            )
        info = STAT_CODES[key]
        return await self.get_statistic(
            stat_code=info["code"],
            cycle=info["cycle"],
            start_date=start_date,
            end_date=end_date,
            item_code=info["item"],
        )

    async def get_base_rate(
        self, start_date: str, end_date: str
    ) -> list[EcosDataPoint]:
        """한국은행 기준금리를 조회합니다."""
        return await self.get_by_key("base_rate", start_date, end_date)

    async def get_exchange_rate(
        self,
        currency: str = "usd",
        start_date: str = "",
        end_date: str = "",
    ) -> list[EcosDataPoint]:
        """환율을 조회합니다.

        Args:
            currency: ``"usd"``, ``"jpy"``, ``"eur"``, ``"cny"``
        """
        key = f"{currency}_krw"
        return await self.get_by_key(key, start_date, end_date)

    async def get_cpi(
        self, start_date: str, end_date: str
    ) -> list[EcosDataPoint]:
        """소비자물가지수를 조회합니다."""
        return await self.get_by_key("cpi", start_date, end_date)

    async def get_treasury_yield(
        self,
        maturity: str = "10y",
        start_date: str = "",
        end_date: str = "",
    ) -> list[EcosDataPoint]:
        """국고채 금리를 조회합니다.

        Args:
            maturity: ``"3y"`` 또는 ``"10y"``
        """
        key = f"treasury_{maturity}"
        return await self.get_by_key(key, start_date, end_date)

    async def get_gdp(
        self, start_date: str, end_date: str
    ) -> list[EcosDataPoint]:
        """실질 GDP를 조회합니다 (분기 데이터)."""
        return await self.get_by_key("gdp", start_date, end_date)

    async def get_available_keys(self) -> list[dict]:
        """사용 가능한 통계 키 목록을 반환합니다."""
        return [
            {"key": k, "name": v["name"], "unit": v["unit"], "cycle": v["cycle"]}
            for k, v in STAT_CODES.items()
        ]


class EcosApiError(Exception):
    """ECOS API 오류."""

    def __init__(self, message: str, code: str = ""):
        super().__init__(message)
        self.code = code
