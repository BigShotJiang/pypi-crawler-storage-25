"""Op^3 Dash application package."""
from .app import create_app, main

__all__ = ["create_app", "main"]
