# Copyright (c) AIoWay Authors - All Rights Reserved

"The expressions represent a table or a view."

import typing
from collections import abc as cabc

from aioway._common import SeqKeysView

from ._common import symbol_dataclass
from .exprs import ColSymbol, TableSymbol

__all__ = ["SourceSymbol", "SelectSymbol", "GetItemSymbol"]


@typing.final
@symbol_dataclass
class SourceSymbol(TableSymbol):
    name: str
    "The table's name. Matches the table names given in the `subs` method."

    columns: cabc.Sequence[str]
    "The columns in the table."

    def __str__(self) -> str:
        return self.name

    def keys(self) -> cabc.KeysView[str]:
        return SeqKeysView(self.columns)


@symbol_dataclass
class SelectSymbol(TableSymbol):
    table: TableSymbol
    "The source to the selection."

    columns: cabc.Sequence[str]
    "The columns to select."

    @typing.override
    def __str__(self) -> str:
        return f"select({self.table!s}, {self.columns!r})"

    @typing.override
    def keys(self) -> cabc.KeysView[str]:
        return SeqKeysView(self.columns)


@symbol_dataclass
class GetItemSymbol(ColSymbol):
    "Perform the `__getitem__` operation. Select one of the keys."

    table: TableSymbol
    """
    The table expression that the column would operate on.
    """

    column: str
    """
    The name of the column.
    """

    @typing.override
    def __str__(self) -> str:
        return f"{self.table!s}.{self.column}"
