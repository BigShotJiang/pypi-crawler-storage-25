# Copyright (c) AIoWay Authors - All Rights Reserved

import contextlib as ctxl
import dataclasses as dcls
import functools
import logging
import typing
from collections import abc as cabc

import torch
from torch import _ops
from torch.utils import _python_dispatch as pyd

from aioway._common.tracking.logging import enable_rich_log
from aioway.ctx import enabled_fake_mode, fake_mode
from aioway.schemas.attrs import attr

from ..fn import Fn, Thunk
from ..guards import TensorFilter, all_tensors, is_aten_op, is_leaf_has_grad, is_prim_op
from .fn import Preview, TorchFn, TorchThunk, find_preview

__all__ = [
    "print_torch_dispatch",
    "log_torch_dispatch",
    "log_and_enable_rich",
    "track_dispatch_fn",
    "fake_dispatch_fn",
    "FnList",
    "TrackDispatchMode",
]

LOGGER = logging.getLogger(__name__)


_CreatePreview = cabc.Callable[..., Preview]
_TorchRouterMode = typing.Literal["dispatch", "function"]


_active_dispatch: Fn | None = None
"The current dispatch."


@typing.runtime_checkable
class TorchRouter(typing.Protocol):
    def __call__(
        self,
        func: _ops.OpOverload,
        types: tuple[type[torch.Tensor], ...],
        args: tuple[typing.Any, ...],
        kwargs: dict[str, typing.Any],
    ) -> torch.Tensor: ...


class TorchRouterFactory(typing.Protocol):
    def __call__(
        self, func: _ops.OpOverload, types: tuple[type[torch.Tensor], ...]
    ) -> _CreatePreview: ...


class _PrintDispatch(pyd.TorchDispatchMode):
    def __torch_dispatch__(
        self,
        func: _ops.OpOverload,
        types: tuple[type[torch.Tensor], ...],
        args: tuple[typing.Any, ...] = (),
        kwargs: dict[str, typing.Any] | None = None,
    ):
        kwargs = kwargs or {}
        invoke = Thunk(func, *args, **kwargs)
        result = invoke()
        print(f"{invoke!s} -> {result!r}")
        return result


print_torch_dispatch = _PrintDispatch
"""
Print the dispatcher.
"""


@dcls.dataclass
class _LogDispatch(pyd.TorchDispatchMode):
    """
    Log every call to dispatch mode.
    """

    level: int
    "The level to log to."

    logger: logging.Logger = LOGGER
    "The logger to log to. Default to the one in the current module."

    def __torch_dispatch__(
        self,
        func: _ops.OpOverload,
        types: tuple[type[torch.Tensor], ...],
        args: tuple[typing.Any, ...] = (),
        kwargs: dict[str, typing.Any] | None = None,
    ):
        kwargs = kwargs or {}
        invoke = Thunk(func, *args, **kwargs)
        result = invoke()
        self.logger.log(self.level, f"%s -> %s", invoke, result)
        return result


log_torch_dispatch = _LogDispatch
"""
Context manager to log the `__torch_dispatch__` calls.

Args:
    logger: The logger to use. Default to the one in this module.
    level: The level to log to. Default to `logging.DEBUG`.
"""


@ctxl.contextmanager
def log_and_enable_rich(level: int, /):
    with enable_rich_log(level) as logger, log_torch_dispatch(level):
        yield logger


def only_route_aten_in_fake(
    func: _ops.OpOverload, types: tuple[type[torch.Tensor], ...]
) -> _CreatePreview:
    if not enabled_fake_mode():
        raise RuntimeError("Only running in fake mode!")

    if is_aten_op(func):
        return aten_ops_preview(func, types)

    assert is_prim_op(func), func
    return NotImplemented


def no_route(*args, **kwargs) -> _CreatePreview:
    return NotImplemented


@dcls.dataclass(frozen=True)
class FnList:
    history: list[TorchFn] = dcls.field(default_factory=list)

    def __len__(self) -> int:
        return len(self.history)

    def __getitem__(self, idx: int) -> Fn:
        return self.history[idx]

    def __iter__(self):
        yield from self.history

    def append(self, item: TorchFn, /):
        self.history.append(item)

    def pop(self):
        return self.history.pop()

    def parameters(self, select: TensorFilter = is_leaf_has_grad, unique: bool = True):
        def data_params():
            for fn in self.history:
                yield from fn.parameters(select)

        params = data_params()

        if unique:
            params = set(data_params())

        yield from params

    def numel(self) -> int:
        return sum(param.numel() for param in self.parameters(all_tensors))

    def memory(self) -> int:
        return sum(attr(param).memory() for param in self.parameters(all_tensors))


@dcls.dataclass
class TrackDispatchMode(pyd.TorchDispatchMode):
    router: TorchRouterFactory
    history: FnList = dcls.field(default_factory=FnList)

    def __torch_dispatch__(
        self,
        func: _ops.OpOverload,
        types: tuple[type[torch.Tensor], ...],
        args: tuple[typing.Any, ...] = (),
        kwargs: dict[str, typing.Any] | None = None,
    ):
        kwargs = kwargs or {}

        # Create a `_ThunkType` and route implemented methods.
        fn_init = self.router(func, types)
        fn: TorchFn

        if (
            False
            # Not ATen operator.
            or fn_init is NotImplemented
            # Fn is not handled.
            or (fn := fn_init(*args, **kwargs)) is NotImplemented
        ):
            fn = TorchThunk(func, types, *args, **kwargs)

        assert isinstance(fn, TorchFn), fn
        self.history.append(fn)

        try:
            # Ensure that only 1 dispatch is running at any given moment.
            with _ensure_single_dispatch(fn):
                return fn()
        except RuntimeError as err:
            fn = TorchThunk(func, types, *args, **kwargs)
            raise ValueError(f"Function call '{fn}' failed.") from err


def aten_ops_preview(
    func: _ops.OpOverload, types: tuple[type[torch.Tensor], ...]
) -> _CreatePreview:
    assert is_aten_op(func), func
    return functools.partial(find_preview, func)


@ctxl.contextmanager
def track_dispatch_fn():
    """
    Track all calls into the torch dispatch mode as `TorchIrFn`.
    """

    with TrackDispatchMode(router=no_route) as sdm:
        yield sdm.history


@ctxl.contextmanager
def fake_dispatch_fn():
    """
    Track all calls into the torch dispatch mode as `TorchIrFn`,
    when fake mode is active.
    """

    with fake_mode(), TrackDispatchMode(router=only_route_aten_in_fake) as sdm:
        yield sdm.history


@ctxl.contextmanager
def _ensure_single_dispatch(fn: Fn):
    "Ensure that only 1 dispatch is running at any given moment."

    global _active_dispatch

    if _active_dispatch is not None:
        raise ValueError("Cannot run 2 dispatches at once.")

    try:
        _active_dispatch = fn
        yield
    finally:
        _active_dispatch = None


def active_dispatch():
    return _active_dispatch
