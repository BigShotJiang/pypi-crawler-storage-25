"""Retenues à la source."""
