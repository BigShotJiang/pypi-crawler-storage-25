"""
token_purveyor.context
~~~~~~~~~~~~~~~~~~~~~~
Context variables and decorators for feature and user tagging.
Both decorator and context-manager forms are provided.
"""

from __future__ import annotations

import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from typing import Callable, Generator, TypeVar

_current_feature: ContextVar[str | None] = ContextVar("tp_feature", default=None)
_current_user: ContextVar[str | None] = ContextVar("tp_user", default=None)

F = TypeVar("F", bound=Callable)


def _make_decorator(var: ContextVar, value: str) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                token = var.set(value)
                try:
                    return await func(*args, **kwargs)
                finally:
                    var.reset(token)

            return async_wrapper  # type: ignore[return-value]
        else:

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                token = var.set(value)
                try:
                    return func(*args, **kwargs)
                finally:
                    var.reset(token)

            return sync_wrapper  # type: ignore[return-value]

    return decorator


def feature_tag(name: str) -> Callable[[F], F]:
    """Decorator: tag all LLM calls inside this function with a feature name."""
    return _make_decorator(_current_feature, name)


def user_tag(user_id: str) -> Callable[[F], F]:
    """Decorator: attribute all LLM calls inside this function to a user ID."""
    return _make_decorator(_current_user, user_id)


@contextmanager
def track_feature(name: str) -> Generator[None, None, None]:
    """Context manager: tag all LLM calls in this block with a feature name."""
    token = _current_feature.set(name)
    try:
        yield
    finally:
        _current_feature.reset(token)


@contextmanager
def track_user(user_id: str) -> Generator[None, None, None]:
    """Context manager: attribute all LLM calls in this block to a user ID."""
    token = _current_user.set(user_id)
    try:
        yield
    finally:
        _current_user.reset(token)


def get_current_feature() -> str | None:
    return _current_feature.get()


def get_current_user() -> str | None:
    return _current_user.get()
