"""
token_purveyor.adapters.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Abstract base class for all provider adapters.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from token_purveyor.tracker import Tracker


class AdapterBase(ABC):
    """
    Subclass this to add a new LLM provider.

    Implement `wrap(base_client, tracker)` to return a proxy object
    whose interface is identical to `base_client`.
    """

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Short identifier, e.g. 'openai', 'anthropic', 'gemini'."""
        ...

    @abstractmethod
    def detect(self, client: Any) -> bool:
        """Return True if this adapter handles the given client object."""
        ...

    @abstractmethod
    def wrap(self, client: Any, tracker: "Tracker") -> Any:
        """Return a proxy object wrapping the client."""
        ...