"""
token_purveyor.adapters.openai
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Intercepts openai.OpenAI and openai.AsyncOpenAI chat.completions.create.

Design:
  - _CompletionsWrapper intercepts .create() only; all else passes through.
  - _ChatWrapper exposes .completions as the wrapper.
  - CostAwareClient.chat falls through to _ChatWrapper.
  - Streaming (stream=True): warn + pass through, never crash.
  - prompt_hash computed from messages before the API call.
  - prompt_text (opt-in) extracted from user-role messages.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from typing import Any, TYPE_CHECKING

from token_purveyor.adapters.base import AdapterBase

if TYPE_CHECKING:
    from token_purveyor.tracker import Tracker

logger = logging.getLogger("token_purveyor")


def _hash_messages(messages: Any) -> str | None:
    """SHA-256 of normalized chat messages. Returns None on any error."""
    if not messages:
        return None
    try:
        normalized = []
        for m in messages:
            if not isinstance(m, dict):
                continue
            role = m.get("role", "")
            content = m.get("content", "") or ""
            if isinstance(content, list):
                # Handle vision-style content: [{"type":"text","text":"..."}]
                texts = [
                    p.get("text", "")
                    for p in content
                    if isinstance(p, dict) and p.get("type") == "text"
                ]
                content = " ".join(texts)
            normalized.append({"role": role, "content": str(content)})
        payload = json.dumps(normalized, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(payload.encode()).hexdigest()
    except Exception:
        return None


def _extract_prompt_text(messages: Any, max_chars: int) -> str | None:
    """Concatenate user-role message text for clustering and compression."""
    if not messages:
        return None
    try:
        parts = []
        for m in messages:
            if not isinstance(m, dict):
                continue
            if m.get("role") != "user":
                continue
            content = m.get("content", "") or ""
            if isinstance(content, list):
                for p in content:
                    if isinstance(p, dict) and p.get("type") == "text":
                        parts.append(p.get("text", ""))
            else:
                parts.append(str(content))
        text = " ".join(parts)
        return text[:max_chars] if text else None
    except Exception:
        return None


def _sync_create(completions: Any, tracker: "Tracker", **kwargs: Any) -> Any:
    messages = kwargs.get("messages")
    prompt_hash = _hash_messages(messages)
    prompt_text = (
        _extract_prompt_text(messages, tracker.config.prompt_storage_max_chars)
        if tracker.config.store_prompts else None
    )
    start = time.perf_counter()
    response = completions.create(**kwargs)
    latency_ms = (time.perf_counter() - start) * 1_000
    try:
        tracker.record_openai(
            response,
            model=kwargs.get("model", ""),
            latency_ms=latency_ms,
            prompt_hash=prompt_hash,
            prompt_text=prompt_text,
        )
    except Exception as exc:
        logger.warning(f"[token_purveyor] Tracker error (non-fatal): {exc}")
    return response


async def _async_create(completions: Any, tracker: "Tracker", **kwargs: Any) -> Any:
    messages = kwargs.get("messages")
    prompt_hash = _hash_messages(messages)
    prompt_text = (
        _extract_prompt_text(messages, tracker.config.prompt_storage_max_chars)
        if tracker.config.store_prompts else None
    )
    start = time.perf_counter()
    response = await completions.create(**kwargs)
    latency_ms = (time.perf_counter() - start) * 1_000
    try:
        tracker.record_openai(
            response,
            model=kwargs.get("model", ""),
            latency_ms=latency_ms,
            prompt_hash=prompt_hash,
            prompt_text=prompt_text,
        )
    except Exception as exc:
        logger.warning(f"[token_purveyor] Tracker error (non-fatal): {exc}")
    return response


class _CompletionsWrapper:
    def __init__(self, completions: Any, tracker: "Tracker") -> None:
        object.__setattr__(self, "_completions", completions)
        object.__setattr__(self, "_tracker", tracker)
        object.__setattr__(
            self,
            "_is_async",
            asyncio.iscoroutinefunction(completions.create),
        )

    def create(self, *args: Any, **kwargs: Any) -> Any:
        completions = object.__getattribute__(self, "_completions")
        tracker     = object.__getattribute__(self, "_tracker")
        is_async    = object.__getattribute__(self, "_is_async")

        if kwargs.get("stream", False):
            if tracker.config.warn_on_stream:
                logger.warning(
                    "[token_purveyor] stream=True — cost tracking skipped for this call. "
                    "Set TokenPurveyorConfig(warn_on_stream=False) to silence."
                )
            return completions.create(*args, **kwargs)

        if is_async:
            return _async_create(completions, tracker, **kwargs)
        return _sync_create(completions, tracker, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_completions"), name)


class _ChatWrapper:
    def __init__(self, chat: Any, tracker: "Tracker") -> None:
        object.__setattr__(self, "_chat", chat)
        object.__setattr__(
            self,
            "_completions_wrapper",
            _CompletionsWrapper(chat.completions, tracker),
        )

    @property
    def completions(self) -> _CompletionsWrapper:
        return object.__getattribute__(self, "_completions_wrapper")

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_chat"), name)


class OpenAIAdapter(AdapterBase):
    @property
    def provider_name(self) -> str:
        return "openai"

    def detect(self, client: Any) -> bool:
        try:
            import openai as _openai
            return isinstance(client, (_openai.OpenAI, _openai.AsyncOpenAI))
        except ImportError:
            pass
        module = getattr(type(client), "__module__", "") or ""
        return module.startswith("openai")

    def wrap(self, client: Any, tracker: "Tracker") -> Any:
        return _ChatWrapper(client.chat, tracker)