"""
token_purveyor.cli
~~~~~~~~~~~~~~~~~~
CLI entry points.

Commands:
  report     — cost breakdown table
  analyze    — full analysis (dedup, batching, recommendations, clusters, compression)
  simulate   — what-if model switch
  update-prices — refresh pricing cache
  reset      — delete all records
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()


# ── Formatters ──────────────────────────────────────────────────────────────

def _fmt_cost(v: float | None, *, color: bool = True) -> str:
    if v is None:
        return "[dim]—[/dim]"
    if v == 0.0:
        return "[dim]$0.00[/dim]"
    s = f"${v:.6f}".rstrip("0").rstrip(".") if v < 0.001 else f"${v:.4f}"
    return f"[green]{s}[/green]" if color else s


def _fmt_tokens(v: int | None) -> str:
    if v is None:
        return "—"
    if v >= 1_000_000:
        return f"{v / 1_000_000:.2f}M"
    if v >= 1_000:
        return f"{v / 1_000:.1f}k"
    return str(v)


def _fmt_latency(ms: float | None) -> str:
    if ms is None:
        return "—"
    return f"{ms / 1000:.2f}s" if ms >= 1000 else f"{ms:.0f}ms"


def _fmt_pct(v: float) -> str:
    color = "green" if v > 0 else "red"
    return f"[{color}]{v:+.1f}%[/{color}]"


def _get_logger(db_path: str):
    from token_purveyor.config import TokenPurveyorConfig
    from token_purveyor.logger import CallLogger
    p = Path(db_path)
    config = TokenPurveyorConfig(
        base_dir=str(p.parent),
        db_filename=p.name,
    )
    return CallLogger(config)


def _get_calc(db_path: str):
    from token_purveyor.config import TokenPurveyorConfig
    from token_purveyor.calculator import CostCalculator
    p = Path(db_path)
    config = TokenPurveyorConfig(base_dir=str(p.parent), db_filename=p.name)
    return CostCalculator(config)


# ── CLI group ────────────────────────────────────────────────────────────────

@click.group()
def cli() -> None:
    """token_purveyor — LLM cost tracker, analyzer, and optimizer."""


# ── report ───────────────────────────────────────────────────────────────────

@cli.command("report")
@click.option("--db", default=".token_purveyor/calls.db", show_default=True)
@click.option("--json", "as_json", is_flag=True, default=False)
def report(db: str, as_json: bool) -> None:
    """Show a full cost breakdown for all tracked calls."""
    if not Path(db).exists():
        console.print(f"[yellow]No data found at {db}. Make at least one tracked call first.[/yellow]")
        sys.exit(0)

    log = _get_logger(db)
    summary = log.query_summary()

    if as_json:
        click.echo(json.dumps(summary, indent=2, default=str))
        return

    totals = summary["totals"]
    if not totals.get("calls"):
        console.print("[dim]No calls recorded yet.[/dim]")
        return

    console.print()
    console.rule("[bold]token_purveyor — cost report[/bold]")
    console.print(
        f"\n  [bold]Calls:[/bold] {totals['calls']}  "
        f"[bold]Tokens:[/bold] {_fmt_tokens(totals['total_tokens'])}  "
        f"[bold]Total cost:[/bold] {_fmt_cost(totals['total_cost'])}\n"
    )

    if summary["by_model"]:
        t = Table(title="By model", box=box.SIMPLE_HEAD, title_style="bold", border_style="dim")
        t.add_column("Model", style="cyan", no_wrap=True)
        t.add_column("Calls", justify="right")
        t.add_column("Tokens", justify="right")
        t.add_column("Avg latency", justify="right")
        t.add_column("Cost (USD)", justify="right")
        for r in summary["by_model"]:
            t.add_row(
                r["model"], str(r["calls"]),
                _fmt_tokens(r["tokens"]), _fmt_latency(r["avg_latency"]),
                _fmt_cost(r["cost"]),
            )
        console.print(t)

    if summary["by_feature"]:
        t2 = Table(title="By feature", box=box.SIMPLE_HEAD, title_style="bold", border_style="dim")
        t2.add_column("Feature", style="magenta")
        t2.add_column("Calls", justify="right")
        t2.add_column("Cost (USD)", justify="right")
        for r in summary["by_feature"]:
            t2.add_row(r["feature_tag"], str(r["calls"]), _fmt_cost(r["cost"]))
        console.print(t2)

    if summary["by_user"]:
        t3 = Table(title="By user", box=box.SIMPLE_HEAD, title_style="bold", border_style="dim")
        t3.add_column("User", style="yellow")
        t3.add_column("Calls", justify="right")
        t3.add_column("Cost (USD)", justify="right")
        for r in summary["by_user"]:
            t3.add_row(r["user_id"], str(r["calls"]), _fmt_cost(r["cost"]))
        console.print(t3)

    if summary["top_expensive"]:
        t4 = Table(title="Top 5 most expensive calls", box=box.SIMPLE_HEAD, title_style="bold", border_style="dim")
        t4.add_column("Model", style="cyan")
        t4.add_column("Feature", style="magenta")
        t4.add_column("User", style="yellow")
        t4.add_column("Prompt tok.", justify="right")
        t4.add_column("Comp. tok.", justify="right")
        t4.add_column("Latency", justify="right")
        t4.add_column("Cost", justify="right")
        for r in summary["top_expensive"]:
            t4.add_row(
                r["model"], r["feature_tag"] or "—", r["user_id"] or "—",
                _fmt_tokens(r["prompt_tokens"]), _fmt_tokens(r["completion_tokens"]),
                _fmt_latency(r["latency_ms"]), _fmt_cost(r["cost_usd"]),
            )
        console.print(t4)
    console.print()


# ── analyze ──────────────────────────────────────────────────────────────────

@cli.command("analyze")
@click.option("--db", default=".token_purveyor/calls.db", show_default=True)
def analyze(db: str) -> None:
    """Run full analysis: dedup, batching, recommendations, clustering, compression."""
    if not Path(db).exists():
        console.print(f"[yellow]No data found at {db}.[/yellow]")
        sys.exit(0)

    log  = _get_logger(db)
    calc = _get_calc(db)

    console.print()
    console.rule("[bold]token_purveyor — analysis report[/bold]")

    # 1. Deduplication
    from token_purveyor.analysis.deduplication import DuplicateAnalyzer
    dup = DuplicateAnalyzer(log).analyze()
    console.print()
    console.print(Panel(
        _render_dedup(dup),
        title="[bold]🔁  Prompt deduplication[/bold]",
        border_style="blue",
    ))

    # 2. Batch optimization
    from token_purveyor.analysis.batch_optimizer import BatchOptimizer
    from token_purveyor.config import TokenPurveyorConfig
    p = Path(db)
    config = TokenPurveyorConfig(base_dir=str(p.parent), db_filename=p.name)
    opps = BatchOptimizer(log, config, calc).find_opportunities()
    console.print(Panel(
        _render_batch(opps),
        title="[bold]📦  Batch optimization[/bold]",
        border_style="blue",
    ))

    # 3. Model recommendations
    from token_purveyor.analysis.recommender import ModelRecommender
    recs = ModelRecommender(log, calc).recommend()
    console.print(Panel(
        _render_recs(recs),
        title="[bold]🤖  Model recommendations[/bold]",
        border_style="blue",
    ))

    # 4. User attribution
    from token_purveyor.analysis.attribution import UserAttributor
    attrs = UserAttributor(log).attribute()
    if attrs:
        console.print(Panel(
            _render_attribution(attrs),
            title="[bold]👤  Per-user attribution[/bold]",
            border_style="blue",
        ))

    # 5. Prompt clustering (opt-in)
    prompts = log.query_prompts_for_clustering()
    if prompts:
        from token_purveyor.analysis.clustering import PromptClusterer
        clusters = PromptClusterer(log).cluster()
        console.print(Panel(
            _render_clusters(clusters),
            title="[bold]🔍  Semantic prompt clusters[/bold]",
            border_style="blue",
        ))
    else:
        console.print(Panel(
            "[dim]Not available — enable with [bold]TokenPurveyorConfig(store_prompts=True)[/bold][/dim]",
            title="[bold]🔍  Semantic prompt clusters[/bold]",
            border_style="dim",
        ))

    # 6. Prompt compression (opt-in)
    prompt_rows = log.query_prompts_for_compression()
    if prompt_rows:
        from token_purveyor.analysis.compression import CompressionAnalyzer
        compressions = CompressionAnalyzer(log, calc).analyze()
        console.print(Panel(
            _render_compression(compressions),
            title="[bold]📉  Prompt compression[/bold]",
            border_style="blue",
        ))
    else:
        console.print(Panel(
            "[dim]Not available — enable with [bold]TokenPurveyorConfig(store_prompts=True)[/bold][/dim]",
            title="[bold]📉  Prompt compression[/bold]",
            border_style="dim",
        ))

    console.print()
    console.print("[dim]Run [bold]token_purveyor simulate --from MODEL --to MODEL[/bold] for detailed what-if analysis.[/dim]")
    console.print()


def _render_dedup(dup) -> str:
    if dup.unique_prompts_repeated == 0:
        return "[green]No duplicate prompts detected.[/green]"
    lines = [
        f"[yellow]{dup.unique_prompts_repeated}[/yellow] unique prompt(s) sent multiple times "
        f"([yellow]{dup.total_duplicate_calls}[/yellow] duplicate calls)",
        f"Wasted: [red]{_fmt_cost(dup.wasted_cost_usd)}[/red]",
    ]
    for d in dup.top_duplicates[:5]:
        lines.append(
            f"  • hash [dim]{d['prompt_hash'][:16]}…[/dim] "
            f"sent [yellow]{d['total_calls']}×[/yellow] — "
            f"wasted [red]{_fmt_cost(d['wasted_cost_usd'])}[/red]"
        )
    return "\n".join(lines)


def _render_batch(opps) -> str:
    if not opps:
        return "[green]No batch opportunities detected in recent history.[/green]"
    lines = [f"Found [yellow]{len(opps)}[/yellow] window(s) with batchable calls:"]
    for o in opps[:5]:
        tag = f"[{o.feature_tag}] " if o.feature_tag else ""
        lines.append(
            f"  • {tag}{o.window_start} — "
            f"[yellow]{o.call_count}[/yellow] small calls "
            f"({_fmt_tokens(o.total_tokens)} total) → "
            f"save ≈ [green]{_fmt_cost(o.estimated_savings_usd)}[/green]"
        )
    return "\n".join(lines)


def _render_recs(recs) -> str:
    if not recs:
        return "[green]No recommendations — your model choices look efficient.[/green]"
    lines = []
    for r in recs[:5]:
        tag = f"[{r.feature_tag}]" if r.feature_tag else ""
        impact_color = {"HIGH": "red", "MEDIUM": "yellow", "LOW": "dim"}.get(r.impact, "dim")
        lines.append(
            f"  [[{impact_color}]{r.impact}[/{impact_color}]] "
            f"[cyan]{r.current_model}[/cyan] → [green]{r.recommended_model}[/green] {tag}"
        )
        lines.append(
            f"    {r.call_count} calls · "
            f"Now: [red]{_fmt_cost(r.current_cost_usd)}[/red] → "
            f"After: [green]{_fmt_cost(r.projected_cost_usd)}[/green] · "
            f"Save: [green]{_fmt_cost(r.savings_usd)}[/green] ([green]{r.savings_pct:.1f}%[/green])"
        )
        lines.append(f"    [dim]{r.rationale}[/dim]")
    return "\n".join(lines)


def _render_attribution(attrs) -> str:
    lines = []
    for a in attrs[:8]:
        lines.append(
            f"  [yellow]{a.user_id}[/yellow]: "
            f"{a.call_count} calls · "
            f"{_fmt_tokens(a.total_tokens)} tokens · "
            f"[red]{_fmt_cost(a.total_cost_usd)}[/red] "
            f"([dim]{a.pct_of_total_cost:.1f}% of total[/dim]) · "
            f"mainly [cyan]{a.most_used_model}[/cyan]"
        )
    return "\n".join(lines)


def _render_clusters(clusters) -> str:
    if not clusters:
        return "[dim]No prompt data for clustering.[/dim]"
    lines = [f"Found [bold]{len(clusters)}[/bold] semantic cluster(s):"]
    for c in clusters[:6]:
        lines.append(
            f"  Cluster {c.cluster_id} ([yellow]{c.size} calls[/yellow], "
            f"avg {_fmt_tokens(int(c.avg_tokens))} tokens, "
            f"cost [green]{_fmt_cost(c.total_cost_usd)}[/green])"
        )
        lines.append(f"    Topics: [dim]{', '.join(c.common_terms[:5])}[/dim]")
        lines.append(f"    Sample: [dim]\"{c.representative_text[:80]}…\"[/dim]")
    return "\n".join(lines)


def _render_compression(reports) -> str:
    if not reports:
        return "[green]No significant compression opportunities found.[/green]"
    lines = [f"Top compressible prompts:"]
    for r in reports[:5]:
        lines.append(
            f"  Call [dim]{r.call_id[:8]}[/dim]: "
            f"{r.original_tokens} → {r.estimated_compressed_tokens} tokens "
            f"([green]{r.compression_ratio*100:.1f}%[/green] reduction) · "
            f"save [green]{_fmt_cost(r.potential_savings_usd)}[/green]"
        )
        for issue in r.issues[:2]:
            lines.append(f"    ↳ [dim]{issue.description}[/dim]")
    return "\n".join(lines)


# ── simulate ─────────────────────────────────────────────────────────────────

@cli.command("simulate")
@click.option("--from", "from_model", required=True, help="Current model to replace.")
@click.option("--to",   "to_model",   required=True, help="Target model to simulate.")
@click.option("--db", default=".token_purveyor/calls.db", show_default=True)
@click.option("--json", "as_json", is_flag=True, default=False)
def simulate(from_model: str, to_model: str, db: str, as_json: bool) -> None:
    """What-if: compute cost if you switched from one model to another."""
    if not Path(db).exists():
        console.print(f"[yellow]No data found at {db}.[/yellow]")
        sys.exit(0)

    log  = _get_logger(db)
    calc = _get_calc(db)

    from token_purveyor.analysis.simulator import WhatIfSimulator
    try:
        result = WhatIfSimulator(log, calc).simulate(from_model, to_model)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        sys.exit(1)

    if result is None:
        console.print(f"[yellow]No calls found for model '{from_model}'.[/yellow]")
        sys.exit(0)

    if as_json:
        click.echo(json.dumps(result.model_dump(), indent=2))
        return

    console.print()
    console.rule(f"[bold]What-if: {result.from_model} → {result.to_model}[/bold]")
    console.print()

    savings_color = "green" if result.savings_usd > 0 else "red"
    quality_str   = {-2: "Significant downgrade", -1: "Moderate downgrade",
                      0: "No change", 1: "Slight improvement", 2: "Significant improvement"}.get(
        result.quality_delta, f"Delta {result.quality_delta:+d}"
    )

    console.print(f"  [bold]Calls affected:[/bold]     {result.calls_affected}")
    console.print(f"  [bold]Actual cost:[/bold]        [red]{_fmt_cost(result.actual_cost_usd, color=False)}[/red]")
    console.print(f"  [bold]Simulated cost:[/bold]     [cyan]{_fmt_cost(result.simulated_cost_usd, color=False)}[/cyan]")
    console.print(
        f"  [bold]Potential savings:[/bold]  "
        f"[{savings_color}]{_fmt_cost(result.savings_usd, color=False)} "
        f"({result.savings_pct:+.1f}%)[/{savings_color}]"
    )
    console.print()
    console.print("  [bold]Compatibility:[/bold]")
    console.print(f"    Quality impact:     {quality_str} (score {_quality_str(result.quality_delta)})")
    console.print(f"    Context window:     {'[green]✓ compatible[/green]' if result.context_compatible else '[red]✗ may truncate long calls[/red]'}")
    console.print(f"    Vision support:     {'[green]✓[/green]' if result.vision_compatible else '[red]✗ target lacks vision[/red]'}")
    console.print(f"    Function calling:   {'[green]✓[/green]' if result.functions_compatible else '[red]✗ target lacks function calling[/red]'}")
    console.print()
    console.print(f"  [bold]Recommendation:[/bold] {result.recommendation}")
    console.print()


def _quality_str(delta: int) -> str:
    return {-2: "[red]5 → 3[/red]", -1: "[yellow]5 → 4[/yellow]",
             0: "[green]unchanged[/green]", 1: "[green]improved[/green]",
             2: "[green]significantly improved[/green]"}.get(delta, str(delta))


# ── update-prices ─────────────────────────────────────────────────────────────

@cli.command("update-prices")
def update_prices() -> None:
    """Force-refresh the model pricing cache from LiteLLM's registry."""
    from token_purveyor.config import TokenPurveyorConfig
    from token_purveyor.pricing import fetch_pricing

    config = TokenPurveyorConfig()
    config.ensure_dirs()

    with console.status("[bold]Fetching pricing from LiteLLM registry…[/bold]"):
        pricing = fetch_pricing(config, force_refresh=True)

    console.print(
        f"[green]✓[/green] Loaded [bold]{len(pricing)}[/bold] models "
        f"→ [dim]{config.pricing_cache_path}[/dim]"
    )


# ── reset ─────────────────────────────────────────────────────────────────────

@cli.command("reset")
@click.option("--db", default=".token_purveyor/calls.db", show_default=True)
@click.confirmation_option(prompt="Delete ALL tracked call records?")
def reset(db: str) -> None:
    """Permanently delete all tracked call records."""
    log = _get_logger(db)
    count = log.clear()
    console.print(f"[green]✓[/green] Deleted {count} records.")