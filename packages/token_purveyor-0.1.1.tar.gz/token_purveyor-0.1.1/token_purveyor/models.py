"""
token_purveyor.models
~~~~~~~~~~~~~~~~~~~~~
All Pydantic models. No business logic.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class CallRecord(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    provider: str
    model: str
    feature_tag: str | None = None
    user_id: str | None = None
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_usd: float | None = None
    latency_ms: float
    prompt_hash: str | None = None
    is_duplicate: bool = False

    model_config = {"frozen": True}


class PricingEntry(BaseModel):
    model: str
    input_cost_per_token: float
    output_cost_per_token: float
    context_window: int
    quality_score: int  # 1–5 reasoning quality
    speed_score: int  # 1–5 (5 = fastest)
    cost_tier: int  # 1–5 (1 = cheapest)
    supports_vision: bool
    supports_functions: bool
    best_for: list[str]

    @property
    def input_per_1m(self) -> float:
        return self.input_cost_per_token * 1_000_000

    @property
    def output_per_1m(self) -> float:
        return self.output_cost_per_token * 1_000_000


class DuplicateReport(BaseModel):
    unique_prompts_repeated: int
    total_duplicate_calls: int
    wasted_cost_usd: float
    top_duplicates: list[dict[str, Any]]


class BatchOpportunity(BaseModel):
    window_start: str
    window_end: str
    call_count: int
    feature_tag: str | None
    user_id: str | None
    total_tokens: int
    estimated_savings_usd: float


class ModelRecommendation(BaseModel):
    current_model: str
    recommended_model: str
    feature_tag: str | None
    call_count: int
    current_cost_usd: float
    projected_cost_usd: float
    savings_usd: float
    savings_pct: float
    rationale: str
    impact: str  # "HIGH" | "MEDIUM" | "LOW"


class SimulationResult(BaseModel):
    from_model: str
    to_model: str
    calls_affected: int
    actual_cost_usd: float
    simulated_cost_usd: float
    savings_usd: float
    savings_pct: float
    quality_delta: int
    context_compatible: bool
    vision_compatible: bool
    functions_compatible: bool
    recommendation: str


class ClusterGroup(BaseModel):
    cluster_id: int
    size: int
    representative_text: str
    common_terms: list[str]
    total_cost_usd: float
    avg_tokens: float


class CompressionIssue(BaseModel):
    issue_type: str
    description: str
    tokens_saveable: int
    example: str


class CompressionReport(BaseModel):
    call_id: str
    original_tokens: int
    estimated_compressed_tokens: int
    compression_ratio: float
    potential_savings_usd: float
    issues: list[CompressionIssue]


class UserAttribution(BaseModel):
    user_id: str
    call_count: int
    total_tokens: int
    total_cost_usd: float
    avg_cost_per_call: float
    most_used_model: str
    pct_of_total_cost: float
