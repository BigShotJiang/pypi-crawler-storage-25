"""
token_purveyor.plugins.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Plugin ABC. Register plugins on CostAwareClient to react to every
recorded call — log to external systems, alert on cost spikes, etc.

Example::

    from token_purveyor.plugins.base import PluginBase
    from token_purveyor.models import CallRecord

    class CostAlertPlugin(PluginBase):
        def on_call_recorded(self, record: CallRecord) -> None:
            if record.cost_usd and record.cost_usd > 0.10:
                print(f"ALERT: single call cost ${record.cost_usd:.4f}")

    client = CostAwareClient(openai.OpenAI())
    client.register_plugin(CostAlertPlugin())
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from token_purveyor.models import CallRecord


class PluginBase(ABC):
    @abstractmethod
    def on_call_recorded(self, record: CallRecord) -> None:
        """Called synchronously after every successful tracked call."""
        ...