"""
token_purveyor.config
~~~~~~~~~~~~~~~~~~~~~
Single immutable config object. Pass once to CostAwareClient.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, computed_field


class TokenPurveyorConfig(BaseModel):
    base_dir: str = ".token_purveyor"
    db_filename: str = "calls.db"
    pricing_cache_filename: str = "pricing_cache.json"

    warn_on_stream: bool = True
    pricing_cache_ttl_hours: int = 24
    project_name: str | None = None

    # Opt-in: stores first N chars of user-role messages for clustering + compression
    store_prompts: bool = False
    prompt_storage_max_chars: int = 1000

    # Analysis windows
    dedup_window_minutes: int = 1440  # 24h window for duplicate detection
    batch_window_seconds: int = 60  # time window for batch detection
    batch_min_calls: int = 3  # minimum calls in window to flag
    batch_max_tokens_per_call: int = 2000  # calls below this are "small"

    # Clustering
    cluster_similarity_threshold: float = 0.40

    model_config = {"frozen": True}

    @computed_field  # type: ignore[misc]
    @property
    def base_path(self) -> Path:
        return Path(self.base_dir)

    @computed_field  # type: ignore[misc]
    @property
    def db_path(self) -> Path:
        return self.base_path / self.db_filename

    @computed_field  # type: ignore[misc]
    @property
    def pricing_cache_path(self) -> Path:
        return self.base_path / self.pricing_cache_filename

    def ensure_dirs(self) -> None:
        self.base_path.mkdir(parents=True, exist_ok=True)
