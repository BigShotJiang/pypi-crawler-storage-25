"""
token_purveyor.analysis.batch_optimizer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Detects windows of small API calls that could be batched into fewer requests.
Works without store_prompts — uses timestamps and token counts only.

Savings estimate: Each batched call saves repeating context. We assume
~15% of prompt tokens are shared context (system prompt / instructions)
that would be deduplicated. This is conservative and realistic.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

from token_purveyor.models import BatchOpportunity

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig
    from token_purveyor.logger import CallLogger

_SHARED_CONTEXT_RATIO = 0.15  # assumed % of prompt tokens = repeated overhead


class BatchOptimizer:
    def __init__(
        self,
        call_logger: "CallLogger",
        config: "TokenPurveyorConfig",
        calculator: Any = None,
    ) -> None:
        from token_purveyor.calculator import CostCalculator
        self._logger = call_logger
        self._config = config
        self._calc = calculator

    def find_opportunities(self) -> list[BatchOpportunity]:
        rows = self._logger.query_for_batch_analysis()
        if not rows:
            return []

        window_sec = self._config.batch_window_seconds
        min_calls  = self._config.batch_min_calls
        max_tok    = self._config.batch_max_tokens_per_call

        # Parse timestamps once
        parsed = []
        for r in rows:
            try:
                ts = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
            except ValueError:
                ts = datetime.now(timezone.utc)
            parsed.append((ts, r))

        opportunities: list[BatchOpportunity] = []
        i = 0
        while i < len(parsed):
            window_start_ts, start_row = parsed[i]
            window = [start_row]

            j = i + 1
            while j < len(parsed):
                delta = (parsed[j][0] - window_start_ts).total_seconds()
                if delta > window_sec:
                    break
                window.append(parsed[j][1])
                j += 1

            # Only flag if enough small calls in the window
            small_calls = [
                r for r in window
                if (r["prompt_tokens"] or 0) <= max_tok
            ]
            if len(small_calls) >= min_calls:
                models = {r["model"] for r in small_calls}
                # Use most common model in window
                primary_model = max(models, key=lambda m: sum(1 for r in small_calls if r["model"] == m))
                total_tokens = sum((r["total_tokens"] or 0) for r in small_calls)
                shared_tokens = sum((r["prompt_tokens"] or 0) for r in small_calls) * _SHARED_CONTEXT_RATIO
                savings_calls = len(small_calls) - 1  # one call vs N calls

                # Estimate savings: saved shared_tokens * (N-1) times
                savings_usd = 0.0
                if self._calc:
                    entry = self._calc.get_entry(primary_model)
                    if entry:
                        savings_usd = (
                            shared_tokens * savings_calls * entry.input_cost_per_token
                        )

                window_end_ts = parsed[j - 1][0] if j > i + 1 else window_start_ts

                feature_tags = list({r["feature_tag"] for r in small_calls if r["feature_tag"]})
                user_ids     = list({r["user_id"]     for r in small_calls if r["user_id"]})

                opportunities.append(BatchOpportunity(
                    window_start=window_start_ts.isoformat()[:19],
                    window_end=window_end_ts.isoformat()[:19],
                    call_count=len(small_calls),
                    feature_tag=feature_tags[0] if len(feature_tags) == 1 else None,
                    user_id=user_ids[0] if len(user_ids) == 1 else None,
                    total_tokens=total_tokens,
                    estimated_savings_usd=round(savings_usd, 6),
                ))

            i = j if j > i + 1 else i + 1

        return sorted(opportunities, key=lambda o: -o.call_count)[:20]


# Fix missing Any import
from typing import Any