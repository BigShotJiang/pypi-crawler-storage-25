"""
token_purveyor.analysis.deduplication
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Detects repeated prompts via SHA-256 hash matching.
Works without store_prompts — hash is always recorded.
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

from token_purveyor.models import DuplicateReport

if TYPE_CHECKING:
    from token_purveyor.logger import CallLogger


class DuplicateAnalyzer:
    def __init__(self, call_logger: "CallLogger") -> None:
        self._logger = call_logger

    def analyze(self) -> DuplicateReport:
        rows = self._logger.query_duplicates()

        top: list[dict[str, Any]] = []
        total_duplicate_calls = 0
        wasted_cost = 0.0

        for row in rows:
            count: int = row["cnt"]
            avg_cost: float = row["avg_cost"] or 0.0
            duplicate_calls = count - 1  # first occurrence is not a duplicate
            wasted = duplicate_calls * avg_cost

            total_duplicate_calls += duplicate_calls
            wasted_cost += wasted

            top.append({
                "prompt_hash":      row["prompt_hash"],
                "total_calls":      count,
                "duplicate_calls":  duplicate_calls,
                "models":           row["models"],
                "wasted_cost_usd":  round(wasted, 6),
                "avg_cost_usd":     round(avg_cost, 6),
            })

        return DuplicateReport(
            unique_prompts_repeated=len(rows),
            total_duplicate_calls=total_duplicate_calls,
            wasted_cost_usd=round(wasted_cost, 6),
            top_duplicates=top[:10],
        )