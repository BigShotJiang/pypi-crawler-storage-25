"""
token_purveyor.analysis.attribution
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Per-user cost attribution.
Requires user IDs to be set via @user_tag or track_user() context manager.
"""
from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

from token_purveyor.models import UserAttribution

if TYPE_CHECKING:
    from token_purveyor.logger import CallLogger


class UserAttributor:
    def __init__(self, call_logger: "CallLogger") -> None:
        self._logger = call_logger

    def attribute(self) -> list[UserAttribution]:
        rows = self._logger.query_for_attribution()
        if not rows:
            return []

        # Aggregate across models per user
        user_data: dict[str, dict] = defaultdict(lambda: {
            "calls": 0,
            "total_tokens": 0,
            "total_cost": 0.0,
            "model_counts": defaultdict(int),
        })

        for row in rows:
            uid = row["user_id"]
            user_data[uid]["calls"]        += row["calls"]
            user_data[uid]["total_tokens"] += row["total_tokens"] or 0
            user_data[uid]["total_cost"]   += row["total_cost"]   or 0.0
            user_data[uid]["model_counts"][row["model"]] += row["calls"]

        grand_total = sum(d["total_cost"] for d in user_data.values()) or 1.0

        result: list[UserAttribution] = []
        for uid, data in user_data.items():
            most_used = max(data["model_counts"], key=lambda m: data["model_counts"][m])
            result.append(UserAttribution(
                user_id=uid,
                call_count=data["calls"],
                total_tokens=data["total_tokens"],
                total_cost_usd=round(data["total_cost"], 6),
                avg_cost_per_call=round(
                    data["total_cost"] / data["calls"] if data["calls"] else 0.0, 6
                ),
                most_used_model=most_used,
                pct_of_total_cost=round(data["total_cost"] / grand_total * 100, 1),
            ))

        return sorted(result, key=lambda u: -u.total_cost_usd)