"""
token_purveyor.analysis.recommender
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Rule-based model recommendation engine.
Uses actual call patterns from the DB and the capability matrix.
100% deterministic.

Rules applied (in priority order):
  R1  Legacy GPT-4 / GPT-4-32k → GPT-4o (better quality, far cheaper)
  R2  GPT-4-Turbo for short calls → GPT-4o (comparable quality, 75% cheaper)
  R3  GPT-4o for small non-vision non-complex calls → GPT-4o-mini (94% cheaper)
  R4  o1 for non-math/non-research → GPT-4o (much cheaper, still top quality)
  R5  o1-preview (deprecated) → o1
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

from token_purveyor.models import ModelRecommendation
from token_purveyor.pricing import resolve_model

if TYPE_CHECKING:
    from token_purveyor.calculator import CostCalculator
    from token_purveyor.logger import CallLogger

_MATH_KEYWORDS   = {"math", "equation", "proof", "theorem", "calculus", "algebra", "geometry", "derive"}
_CODING_KEYWORDS = {"code", "coding", "debug", "function", "script", "program", "bug", "refactor"}
_COMPLEX_KEYWORDS= {"analyze", "research", "reasoning", "explain", "complex", "architecture", "design"}
_VISION_KEYWORDS = {"image", "vision", "photo", "screenshot", "visual", "picture", "diagram"}


def _feature_implies(feature: str | None, keywords: set[str]) -> bool:
    if not feature:
        return False
    return any(k in feature.lower() for k in keywords)


class ModelRecommender:
    def __init__(
        self,
        call_logger: "CallLogger",
        calculator: "CostCalculator",
    ) -> None:
        self._logger = call_logger
        self._calc = calculator

    def recommend(self) -> list[ModelRecommendation]:
        rows = self._logger.query_for_recommendation()
        if not rows:
            return []

        all_cost = sum(r["total_cost"] or 0.0 for r in rows)
        recommendations: list[ModelRecommendation] = []

        for row in rows:
            model       = row["model"]
            canonical   = resolve_model(model)
            feature     = row["feature_tag"]
            calls       = row["calls"]
            avg_prompt  = row["avg_prompt"] or 0
            avg_total   = row["avg_total"] or 0
            total_cost  = row["total_cost"] or 0.0

            rec = self._apply_rules(
                canonical, feature, calls, avg_prompt, avg_total, total_cost
            )
            if rec:
                recommendations.append(rec)

        return sorted(recommendations, key=lambda r: -r.savings_usd)

    def _apply_rules(
        self,
        model: str,
        feature: str | None,
        calls: int,
        avg_prompt: float,
        avg_total: float,
        total_cost: float,
    ) -> ModelRecommendation | None:

        # R1: Legacy GPT-4 or GPT-4-32k → GPT-4o
        if model in ("gpt-4", "gpt-4-32k"):
            target = "gpt-4o"
            return self._make_rec(
                model, target, feature, calls, avg_prompt, avg_total, total_cost,
                rationale="GPT-4 is a legacy model. GPT-4o offers equal quality at ~92% lower cost with a 128k context window.",
                impact="HIGH",
            )

        # R2: GPT-4-Turbo for short calls → GPT-4o
        if model == "gpt-4-turbo" and avg_total < 8_000:
            target = "gpt-4o"
            return self._make_rec(
                model, target, feature, calls, avg_prompt, avg_total, total_cost,
                rationale=f"GPT-4o is comparable in quality to GPT-4-Turbo and 75% cheaper. Avg call size ({avg_total:.0f} tokens) is well within GPT-4o's window.",
                impact="HIGH",
            )

        # R3: GPT-4o for small, non-vision, non-complex → GPT-4o-mini
        if (
            model == "gpt-4o"
            and avg_total < 4_000
            and not _feature_implies(feature, _VISION_KEYWORDS)
            and not _feature_implies(feature, _COMPLEX_KEYWORDS)
        ):
            target = "gpt-4o-mini"
            return self._make_rec(
                model, target, feature, calls, avg_prompt, avg_total, total_cost,
                rationale=(
                    f"Calls are small (avg {avg_total:.0f} tokens) with no vision or complex reasoning. "
                    "GPT-4o-mini handles these tasks at 94% lower cost."
                ),
                impact="HIGH" if total_cost > 0.50 else "MEDIUM",
            )

        # R4: o1 / o1-preview for non-math/non-research → GPT-4o
        if model in ("o1", "o1-preview") and not _feature_implies(feature, _MATH_KEYWORDS):
            target = "gpt-4o"
            return self._make_rec(
                model, target, feature, calls, avg_prompt, avg_total, total_cost,
                rationale=(
                    "o1 is optimized for math and rigorous reasoning. "
                    "GPT-4o delivers top-tier quality at 83% lower cost for general tasks."
                ),
                impact="HIGH",
            )

        # R5: o1-mini for coding → o3-mini
        if model == "o1-mini" and _feature_implies(feature, _CODING_KEYWORDS):
            target = "o3-mini"
            return self._make_rec(
                model, target, feature, calls, avg_prompt, avg_total, total_cost,
                rationale="o3-mini outperforms o1-mini on coding tasks at comparable cost.",
                impact="MEDIUM",
            )

        return None

    def _make_rec(
        self,
        current: str,
        target: str,
        feature: str | None,
        calls: int,
        avg_prompt: float,
        avg_total: float,
        total_cost: float,
        rationale: str,
        impact: str,
    ) -> ModelRecommendation | None:
        target_entry = self._calc.get_entry(target)
        current_entry = self._calc.get_entry(current)
        if not target_entry or not current_entry:
            return None

        # Estimate avg split: 60% prompt, 40% completion (conservative)
        avg_completion = max(0.0, avg_total - avg_prompt)
        proj_cost = calls * (
            avg_prompt     * target_entry.input_cost_per_token
            + avg_completion * target_entry.output_cost_per_token
        )
        savings = total_cost - proj_cost
        if savings <= 0:
            return None

        return ModelRecommendation(
            current_model=current,
            recommended_model=target,
            feature_tag=feature,
            call_count=calls,
            current_cost_usd=round(total_cost, 6),
            projected_cost_usd=round(proj_cost, 6),
            savings_usd=round(savings, 6),
            savings_pct=round(savings / total_cost * 100, 1) if total_cost > 0 else 0.0,
            rationale=rationale,
            impact=impact,
        )