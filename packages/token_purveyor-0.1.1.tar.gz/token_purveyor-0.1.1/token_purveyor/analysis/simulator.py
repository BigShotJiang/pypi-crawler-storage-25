"""
token_purveyor.analysis.simulator
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
What-if cost simulator.

Given your historical call log, compute: if you had used model B
instead of model A, what would the total cost have been?

100% deterministic — pure arithmetic on the call log.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from token_purveyor.models import SimulationResult
from token_purveyor.pricing import resolve_model

if TYPE_CHECKING:
    from token_purveyor.calculator import CostCalculator
    from token_purveyor.logger import CallLogger


class WhatIfSimulator:
    def __init__(
        self,
        call_logger: "CallLogger",
        calculator: "CostCalculator",
    ) -> None:
        self._logger = call_logger
        self._calc = calculator

    def simulate(self, from_model: str, to_model: str) -> SimulationResult | None:
        """
        Compute the cost delta if all calls to `from_model` had used `to_model`.

        Returns None if no calls were made with `from_model`.
        """
        from_canonical = resolve_model(from_model)
        to_canonical   = resolve_model(to_model)

        from_entry = self._calc.get_entry(from_canonical)
        to_entry   = self._calc.get_entry(to_canonical)

        if not from_entry:
            raise ValueError(f"[token_purveyor] Unknown model: {from_model!r}")
        if not to_entry:
            raise ValueError(f"[token_purveyor] Unknown model: {to_model!r}")

        rows = self._logger.query_for_simulation(from_canonical)
        # Also catch date-versioned variants of the from_model
        all_rows = []
        for row in rows:
            if resolve_model(row["model"]) == from_canonical:
                all_rows.append(row)

        if not all_rows:
            return None

        actual_cost    = 0.0
        simulated_cost = 0.0

        for row in all_rows:
            pt = row["prompt_tokens"]     or 0
            ct = row["completion_tokens"] or 0
            actual_cost    += (row["cost_usd"] or (
                pt * from_entry.input_cost_per_token + ct * from_entry.output_cost_per_token
            ))
            simulated_cost += (
                pt * to_entry.input_cost_per_token
                + ct * to_entry.output_cost_per_token
            )

        savings    = actual_cost - simulated_cost
        savings_pct = (savings / actual_cost * 100) if actual_cost > 0 else 0.0

        # Compatibility checks
        context_ok   = to_entry.context_window >= from_entry.context_window
        vision_ok    = (not from_entry.supports_vision) or to_entry.supports_vision
        functions_ok = (not from_entry.supports_functions) or to_entry.supports_functions

        quality_delta = to_entry.quality_score - from_entry.quality_score

        if savings > 0 and quality_delta >= 0:
            recommendation = "RECOMMENDED — saves money with equal or better quality."
        elif savings > 0 and quality_delta == -1:
            recommendation = "FEASIBLE — saves money, minor quality trade-off. Review complex calls."
        elif savings > 0 and quality_delta <= -2:
            recommendation = "CAUTION — significant quality downgrade. Test thoroughly before switching."
        elif savings <= 0:
            recommendation = "NOT RECOMMENDED — no cost saving (target model is more expensive or same cost)."
        else:
            recommendation = "NEUTRAL"

        if not context_ok:
            recommendation += f" WARNING: {to_model} has smaller context window — {len(all_rows)} calls may fail."
        if not vision_ok:
            recommendation += f" WARNING: {to_model} does not support vision."
        if not functions_ok:
            recommendation += f" WARNING: {to_model} does not support function calling."

        return SimulationResult(
            from_model=from_canonical,
            to_model=to_canonical,
            calls_affected=len(all_rows),
            actual_cost_usd=round(actual_cost, 6),
            simulated_cost_usd=round(simulated_cost, 6),
            savings_usd=round(savings, 6),
            savings_pct=round(savings_pct, 1),
            quality_delta=quality_delta,
            context_compatible=context_ok,
            vision_compatible=vision_ok,
            functions_compatible=functions_ok,
            recommendation=recommendation,
        )