"""
token_purveyor.analysis.clustering
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Groups semantically similar prompts using bag-of-words cosine similarity.
100% deterministic — no ML libraries required.
Requires store_prompts=True in config.
"""
from __future__ import annotations

import math
import re
from typing import TYPE_CHECKING

from token_purveyor.models import ClusterGroup

if TYPE_CHECKING:
    from token_purveyor.logger import CallLogger

_STOP_WORDS: frozenset[str] = frozenset({
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
    "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "could", "should", "may", "might", "shall", "can", "this", "that",
    "these", "those", "i", "you", "he", "she", "it", "we", "they", "me",
    "him", "her", "us", "them", "my", "your", "his", "its", "our", "their",
    "what", "which", "who", "when", "where", "why", "how", "all", "any",
    "both", "each", "few", "more", "most", "other", "some", "such", "no",
    "not", "only", "same", "so", "than", "too", "very", "just", "please",
    "as", "if", "then", "because", "about", "also",
})


def _tokenize(text: str) -> dict[str, int]:
    """Lowercase, strip punctuation, remove stop words → term frequency dict."""
    tokens = re.findall(r"[a-z]{2,}", text.lower())
    freq: dict[str, int] = {}
    for tok in tokens:
        if tok not in _STOP_WORDS:
            freq[tok] = freq.get(tok, 0) + 1
    return freq


def _cosine(a: dict[str, int], b: dict[str, int]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(a.get(t, 0) * v for t, v in b.items())
    mag_a = math.sqrt(sum(v * v for v in a.values()))
    mag_b = math.sqrt(sum(v * v for v in b.values()))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def _top_terms(freq: dict[str, int], n: int = 5) -> list[str]:
    return [t for t, _ in sorted(freq.items(), key=lambda x: -x[1])[:n]]


class PromptClusterer:
    def __init__(
        self,
        call_logger: "CallLogger",
        similarity_threshold: float = 0.40,
    ) -> None:
        self._logger = call_logger
        self._threshold = similarity_threshold

    def cluster(self) -> list[ClusterGroup]:
        rows = self._logger.query_prompts_for_clustering()
        if not rows:
            return []

        # Build (row, freq_vector) pairs
        items = [(r, _tokenize(r["prompt_text"])) for r in rows]

        # Greedy single-pass clustering
        clusters: list[list[int]] = []   # list of index groups
        centroids: list[dict[str, int]] = []

        for idx, (_, freq) in enumerate(items):
            best_cluster = -1
            best_sim = self._threshold

            for cid, centroid in enumerate(centroids):
                sim = _cosine(freq, centroid)
                if sim > best_sim:
                    best_sim = sim
                    best_cluster = cid

            if best_cluster == -1:
                clusters.append([idx])
                centroids.append(dict(freq))
            else:
                clusters[best_cluster].append(idx)
                # Update centroid: term-frequency union (additive merge)
                for term, count in freq.items():
                    centroids[best_cluster][term] = (
                        centroids[best_cluster].get(term, 0) + count
                    )

        result: list[ClusterGroup] = []
        for cid, member_indices in enumerate(clusters):
            members = [items[i][0] for i in member_indices]
            all_costs = [m["cost_usd"] or 0.0 for m in members]
            all_tokens = [m["total_tokens"] for m in members]
            representative = members[0]["prompt_text"]

            # Common terms across the cluster
            combined_freq: dict[str, int] = {}
            for i in member_indices:
                for term, count in items[i][1].items():
                    combined_freq[term] = combined_freq.get(term, 0) + count

            result.append(ClusterGroup(
                cluster_id=cid,
                size=len(members),
                representative_text=representative[:120],
                common_terms=_top_terms(combined_freq),
                total_cost_usd=round(sum(all_costs), 6),
                avg_tokens=round(sum(all_tokens) / len(all_tokens), 1),
            ))

        # Sort by cluster size descending
        return sorted(result, key=lambda c: -c.size)