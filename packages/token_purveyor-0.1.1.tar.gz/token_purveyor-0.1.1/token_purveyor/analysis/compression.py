"""
token_purveyor.analysis.compression
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Analyzes stored prompt texts for compressibility.
Requires store_prompts=True.

Detects:
  1. Filler phrases    — "Please", "Could you please", "I would like you to"
  2. Verbose preambles — "In this task you will...", "Your job is to..."
  3. Repeated n-grams  — same trigram appearing 3+ times
  4. Over-specified format requests — excessively detailed formatting instructions
"""
from __future__ import annotations

import re
from collections import Counter
from typing import TYPE_CHECKING

from token_purveyor.models import CompressionIssue, CompressionReport

if TYPE_CHECKING:
    from token_purveyor.calculator import CostCalculator
    from token_purveyor.logger import CallLogger

# (pattern, issue_type, description, estimated_tokens_wasted)
_FILLER_PATTERNS: list[tuple[re.Pattern, str, str, int]] = [
    (re.compile(r"\bplease\b", re.I),
     "filler_word", "Redundant 'please' (LLMs respond regardless)", 1),

    (re.compile(r"\bcould you (please )?(help me |just )?", re.I),
     "filler_phrase", "'Could you' phrasing adds no information", 3),

    (re.compile(r"\bi (would|'d) (like|want|need) (you )?(to )?", re.I),
     "filler_phrase", "'I would like you to' can be replaced with a direct imperative", 5),

    (re.compile(r"\bi need you to\b", re.I),
     "filler_phrase", "Replace 'I need you to' with a direct command", 4),

    (re.compile(r"\bkindly\b", re.I),
     "filler_word", "'Kindly' is filler", 1),

    (re.compile(r"\bas an? (ai|language model|llm|assistant)\b", re.I),
     "role_preamble", "Role preambles ('As an AI...') waste tokens with no benefit", 5),

    (re.compile(r"\bin (this (task|exercise|example)|the following)", re.I),
     "verbose_preamble", "Verbose task introduction; state the task directly", 6),

    (re.compile(r"\byour (job|task|role|goal|objective|purpose) is to\b", re.I),
     "verbose_preamble", "Verbose role definition; skip straight to the instruction", 7),

    (re.compile(r"\bplease (note|be aware|keep in mind) that\b", re.I),
     "filler_phrase", "'Please note that' — just state the constraint directly", 4),

    (re.compile(r"\bwithout further ado\b", re.I),
     "filler_phrase", "Filler phrase", 3),
]

# Approx chars per token for GPT models
_CHARS_PER_TOKEN = 4.0


def _count_repeated_trigrams(text: str) -> tuple[int, list[str]]:
    """Find trigrams repeated 3+ times (strong sign of redundancy)."""
    words = re.findall(r"\b\w+\b", text.lower())
    if len(words) < 3:
        return 0, []
    trigrams = [" ".join(words[i:i+3]) for i in range(len(words) - 2)]
    counts = Counter(trigrams)
    repeated = [(tg, n) for tg, n in counts.items() if n >= 3]
    wasted_tokens = sum((n - 1) * 3 for _, n in repeated)  # (repeats-1) * 3 tokens each
    examples = [tg for tg, _ in repeated[:3]]
    return wasted_tokens, examples


class CompressionAnalyzer:
    def __init__(self, call_logger: "CallLogger", calculator: "CostCalculator") -> None:
        self._logger = call_logger
        self._calc = calculator

    def analyze(self, top_n: int = 20) -> list[CompressionReport]:
        rows = self._logger.query_prompts_for_compression()
        if not rows:
            return []

        reports: list[CompressionReport] = []
        for row in rows[:top_n]:
            text: str = row["prompt_text"] or ""
            if not text:
                continue

            issues: list[CompressionIssue] = []
            tokens_saveable = 0

            # Filler pattern scan
            for pattern, issue_type, description, est_tokens in _FILLER_PATTERNS:
                matches = pattern.findall(text)
                if matches:
                    issues.append(CompressionIssue(
                        issue_type=issue_type,
                        description=description,
                        tokens_saveable=est_tokens * len(matches),
                        example=matches[0] if isinstance(matches[0], str) else str(matches[0]),
                    ))
                    tokens_saveable += est_tokens * len(matches)

            # Repeated trigram scan
            trigram_waste, trigram_examples = _count_repeated_trigrams(text)
            if trigram_waste > 0:
                issues.append(CompressionIssue(
                    issue_type="repeated_content",
                    description=f"Repeated phrases detected: {', '.join(trigram_examples[:2])}",
                    tokens_saveable=trigram_waste,
                    example=trigram_examples[0] if trigram_examples else "",
                ))
                tokens_saveable += trigram_waste

            original_tokens = row["prompt_tokens"]
            estimated_compressed = max(0, original_tokens - tokens_saveable)
            ratio = tokens_saveable / original_tokens if original_tokens > 0 else 0.0

            model = row["model"]
            entry = self._calc.get_entry(model)
            savings_usd = (
                tokens_saveable * entry.input_cost_per_token if entry else 0.0
            )

            if issues:
                reports.append(CompressionReport(
                    call_id=row["id"],
                    original_tokens=original_tokens,
                    estimated_compressed_tokens=estimated_compressed,
                    compression_ratio=round(ratio, 3),
                    potential_savings_usd=round(savings_usd, 6),
                    issues=issues,
                ))

        return sorted(reports, key=lambda r: -r.compression_ratio)