"""
token_purveyor.client
~~~~~~~~~~~~~~~~~~~~~
CostAwareClient — the single public entry point.
"""
from __future__ import annotations

from typing import Any

from token_purveyor.adapters.openai import OpenAIAdapter
from token_purveyor.config import TokenPurveyorConfig
from token_purveyor.plugins.base import PluginBase
from token_purveyor.tracker import Tracker

_ADAPTERS = [OpenAIAdapter()]


class CostAwareClient:
    """
    Drop-in proxy for any supported LLM client.

    Usage::

        import openai
        from token_purveyor import CostAwareClient

        client = CostAwareClient(openai.OpenAI())
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """

    def __init__(
        self,
        base_client: Any,
        *,
        config: TokenPurveyorConfig | None = None,
    ) -> None:
        self._client = base_client
        self._config = config or TokenPurveyorConfig()
        self._tracker = Tracker(self._config)
        self._adapter = self._resolve_adapter()
        self._chat_wrapper = self._adapter.wrap(base_client, self._tracker)

    def _resolve_adapter(self):
        for adapter in _ADAPTERS:
            if adapter.detect(self._client):
                return adapter
        raise ValueError(
            f"[token_purveyor] No adapter found for client type "
            f"'{type(self._client).__name__}'. "
            "Supported: openai.OpenAI, openai.AsyncOpenAI."
        )

    def register_plugin(self, plugin: PluginBase) -> None:
        """Attach a plugin to receive every recorded call."""
        self._tracker.register_plugin(plugin)

    @property
    def chat(self) -> Any:
        return self._chat_wrapper

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)

    def __repr__(self) -> str:
        return (
            f"CostAwareClient("
            f"provider={self._adapter.provider_name!r}, "
            f"db={str(self._config.db_path)!r})"
        )