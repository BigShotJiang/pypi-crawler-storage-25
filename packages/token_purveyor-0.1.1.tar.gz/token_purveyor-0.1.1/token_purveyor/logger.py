"""
token_purveyor.logger
~~~~~~~~~~~~~~~~~~~~~
SQLite-backed persistence layer.
- WAL mode for concurrent write safety
- Separate opt-in prompt_texts table
- All writes are non-fatal (log warning, never raise into user code)
"""
from __future__ import annotations

import logging
import sqlite3
from typing import Any, TYPE_CHECKING

from token_purveyor.models import CallRecord

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig

logger = logging.getLogger("token_purveyor")

_DDL = """
CREATE TABLE IF NOT EXISTS calls (
    id                TEXT PRIMARY KEY,
    timestamp         TEXT NOT NULL,
    provider          TEXT NOT NULL,
    model             TEXT NOT NULL,
    feature_tag       TEXT,
    user_id           TEXT,
    prompt_tokens     INTEGER NOT NULL,
    completion_tokens INTEGER NOT NULL,
    total_tokens      INTEGER NOT NULL,
    cost_usd          REAL,
    latency_ms        REAL NOT NULL,
    prompt_hash       TEXT,
    is_duplicate      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_timestamp   ON calls (timestamp);
CREATE INDEX IF NOT EXISTS idx_model       ON calls (model);
CREATE INDEX IF NOT EXISTS idx_feature_tag ON calls (feature_tag);
CREATE INDEX IF NOT EXISTS idx_user_id     ON calls (user_id);
CREATE INDEX IF NOT EXISTS idx_prompt_hash ON calls (prompt_hash);

CREATE TABLE IF NOT EXISTS prompt_texts (
    call_id     TEXT PRIMARY KEY REFERENCES calls(id),
    prompt_text TEXT NOT NULL
);
"""

_INSERT_CALL = """
INSERT INTO calls
    (id, timestamp, provider, model, feature_tag, user_id,
     prompt_tokens, completion_tokens, total_tokens,
     cost_usd, latency_ms, prompt_hash, is_duplicate)
VALUES
    (:id, :timestamp, :provider, :model, :feature_tag, :user_id,
     :prompt_tokens, :completion_tokens, :total_tokens,
     :cost_usd, :latency_ms, :prompt_hash, :is_duplicate)
"""

_INSERT_PROMPT = "INSERT INTO prompt_texts (call_id, prompt_text) VALUES (?, ?)"


class CallLogger:
    def __init__(self, config: "TokenPurveyorConfig") -> None:
        self._db_path = config.db_path
        config.ensure_dirs()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(_DDL)
            conn.commit()

    # ── Write ──────────────────────────────────────────────────────────────

    def insert(self, record: CallRecord, prompt_text: str | None = None) -> None:
        try:
            with self._connect() as conn:
                conn.execute(_INSERT_CALL, {
                    "id":                record.id,
                    "timestamp":         record.timestamp.isoformat(),
                    "provider":          record.provider,
                    "model":             record.model,
                    "feature_tag":       record.feature_tag,
                    "user_id":           record.user_id,
                    "prompt_tokens":     record.prompt_tokens,
                    "completion_tokens": record.completion_tokens,
                    "total_tokens":      record.total_tokens,
                    "cost_usd":          record.cost_usd,
                    "latency_ms":        record.latency_ms,
                    "prompt_hash":       record.prompt_hash,
                    "is_duplicate":      int(record.is_duplicate),
                })
                if prompt_text:
                    conn.execute(_INSERT_PROMPT, (record.id, prompt_text))
                conn.commit()
        except Exception as exc:
            logger.warning(f"[token_purveyor] DB write failed (non-fatal): {exc}")

    # ── Reads ──────────────────────────────────────────────────────────────

    def get_all_prompt_hashes(self) -> list[str]:
        try:
            with self._connect() as conn:
                rows = conn.execute(
                    "SELECT DISTINCT prompt_hash FROM calls WHERE prompt_hash IS NOT NULL"
                ).fetchall()
            return [r["prompt_hash"] for r in rows]
        except Exception:
            return []

    def query_all(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM calls ORDER BY timestamp DESC").fetchall()
        return [dict(r) for r in rows]

    def query_summary(self) -> dict[str, Any]:
        with self._connect() as conn:
            totals = conn.execute(
                "SELECT COUNT(*) AS calls, SUM(cost_usd) AS total_cost, "
                "SUM(total_tokens) AS total_tokens FROM calls"
            ).fetchone()

            by_model = conn.execute(
                "SELECT model, COUNT(*) AS calls, SUM(cost_usd) AS cost, "
                "SUM(total_tokens) AS tokens, AVG(latency_ms) AS avg_latency "
                "FROM calls GROUP BY model ORDER BY cost DESC NULLS LAST"
            ).fetchall()

            by_feature = conn.execute(
                "SELECT feature_tag, COUNT(*) AS calls, SUM(cost_usd) AS cost "
                "FROM calls WHERE feature_tag IS NOT NULL "
                "GROUP BY feature_tag ORDER BY cost DESC NULLS LAST"
            ).fetchall()

            by_user = conn.execute(
                "SELECT user_id, COUNT(*) AS calls, SUM(cost_usd) AS cost "
                "FROM calls WHERE user_id IS NOT NULL "
                "GROUP BY user_id ORDER BY cost DESC NULLS LAST"
            ).fetchall()

            top_expensive = conn.execute(
                "SELECT model, feature_tag, user_id, cost_usd, prompt_tokens, "
                "completion_tokens, latency_ms, timestamp "
                "FROM calls WHERE cost_usd IS NOT NULL "
                "ORDER BY cost_usd DESC LIMIT 5"
            ).fetchall()

        return {
            "totals":       dict(totals) if totals else {},
            "by_model":     [dict(r) for r in by_model],
            "by_feature":   [dict(r) for r in by_feature],
            "by_user":      [dict(r) for r in by_user],
            "top_expensive":[dict(r) for r in top_expensive],
        }

    def query_duplicates(self) -> list[dict[str, Any]]:
        """Groups by prompt_hash; returns hashes seen more than once."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT prompt_hash, COUNT(*) AS cnt, "
                "SUM(cost_usd) AS total_cost, AVG(cost_usd) AS avg_cost, "
                "GROUP_CONCAT(DISTINCT model) AS models "
                "FROM calls WHERE prompt_hash IS NOT NULL "
                "GROUP BY prompt_hash HAVING cnt > 1 "
                "ORDER BY cnt DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def query_for_batch_analysis(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, timestamp, model, feature_tag, user_id, "
                "prompt_tokens, completion_tokens, total_tokens, cost_usd "
                "FROM calls ORDER BY timestamp ASC"
            ).fetchall()
        return [dict(r) for r in rows]

    def query_for_recommendation(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT model, feature_tag, "
                "COUNT(*) AS calls, "
                "AVG(prompt_tokens) AS avg_prompt, "
                "AVG(total_tokens) AS avg_total, "
                "SUM(cost_usd) AS total_cost "
                "FROM calls "
                "GROUP BY model, feature_tag "
                "ORDER BY total_cost DESC NULLS LAST"
            ).fetchall()
        return [dict(r) for r in rows]

    def query_for_simulation(self, from_model: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, model, prompt_tokens, completion_tokens, cost_usd "
                "FROM calls WHERE model = ? OR model LIKE ?",
                (from_model, from_model + "-%"),
            ).fetchall()
        return [dict(r) for r in rows]

    def query_prompts_for_clustering(self) -> list[dict[str, Any]]:
        """Returns prompt texts joined with call metadata. Requires store_prompts=True."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT c.id, c.model, c.feature_tag, c.cost_usd, c.total_tokens, "
                "pt.prompt_text "
                "FROM calls c JOIN prompt_texts pt ON c.id = pt.call_id "
                "ORDER BY c.timestamp DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def query_prompts_for_compression(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT c.id, c.model, c.prompt_tokens, c.cost_usd, pt.prompt_text "
                "FROM calls c JOIN prompt_texts pt ON c.id = pt.call_id "
                "ORDER BY c.prompt_tokens DESC LIMIT 100"
            ).fetchall()
        return [dict(r) for r in rows]

    def query_for_attribution(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT user_id, model, "
                "COUNT(*) AS calls, "
                "SUM(total_tokens) AS total_tokens, "
                "SUM(cost_usd) AS total_cost "
                "FROM calls WHERE user_id IS NOT NULL "
                "GROUP BY user_id, model ORDER BY total_cost DESC NULLS LAST"
            ).fetchall()
        return [dict(r) for r in rows]

    def clear(self) -> int:
        with self._connect() as conn:
            count = conn.execute("SELECT COUNT(*) FROM calls").fetchone()[0]
            conn.execute("DELETE FROM prompt_texts")
            conn.execute("DELETE FROM calls")
            conn.commit()
        return count