"""
token_purveyor
~~~~~~~~~~~~~~
Drop-in LLM cost tracking, deduplication, clustering, and optimization.

    import openai
    from token_purveyor import CostAwareClient

    client = CostAwareClient(openai.OpenAI())
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from token_purveyor.client import CostAwareClient
from token_purveyor.config import TokenPurveyorConfig
from token_purveyor.context import feature_tag, user_tag, track_feature, track_user

__all__ = [
    "CostAwareClient",
    "TokenPurveyorConfig",
    "feature_tag",
    "user_tag",
    "track_feature",
    "track_user",
]
__version__ = "0.1.0"
