"""
token_purveyor.pricing
~~~~~~~~~~~~~~~~~~~~~~
Fully dynamic pricing from the LiteLLM model registry.

Priority chain (highest → lowest):
  1. In-memory cache       (same process, zero cost)
  2. Fresh disk cache      (< ttl_hours old, no network)
  3. Live LiteLLM fetch    (GitHub raw JSON, always current)
  4. Stale disk cache      (offline fallback, any age)
  5. Hardcoded seed        (absolute last resort, common models only)

Key design decisions:
  - Prices are fetched once per process lifetime unless force_refresh=True
  - Disk cache survives restarts and is shared across all CostAwareClient
    instances in the same project directory
  - The hardcoded seed only covers common models and is never used if
    the user has ever been online
  - All capability metadata (quality_score, context_window etc.) always
    comes from our own registry — LiteLLM only gives us prices
  - fetch_pricing() is safe to call from multiple threads (the GIL
    protects the in-memory _MEMORY_CACHE dict assignment)
"""

from __future__ import annotations

import json
import logging
import re
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from token_purveyor.models import PricingEntry

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig

logger = logging.getLogger("token_purveyor")

# ── Source URL ────────────────────────────────────────────────────────────────
# LiteLLM maintains this file actively and it is the most reliable
# community-sourced OpenAI pricing registry available.
LITELLM_PRICING_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)

# ── In-memory cache (per process) ─────────────────────────────────────────────
# Avoids hitting disk or network on every CostCalculator instantiation.
_MEMORY_CACHE: dict[str, PricingEntry] | None = None
_MEMORY_CACHE_LOCK = threading.Lock()

# ── Capability metadata ────────────────────────────────────────────────────────
# LiteLLM gives us prices. We maintain capability data ourselves because
# it requires human judgment (quality scores, best_for tags, etc.)
# This dict is ONLY used for capability enrichment, never for pricing.
# Pricing always comes from the live source.
_CAPABILITY: dict[str, dict] = {
    "gpt-4o": {
        "context_window": 128_000,
        "quality_score": 5,
        "speed_score": 4,
        "cost_tier": 3,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "vision", "code", "analysis"],
    },
    "gpt-4o-mini": {
        "context_window": 128_000,
        "quality_score": 3,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["simple_qa", "classification", "extraction", "chat"],
    },
    "gpt-4-turbo": {
        "context_window": 128_000,
        "quality_score": 4,
        "speed_score": 3,
        "cost_tier": 4,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "code", "analysis", "vision"],
    },
    "gpt-4": {
        "context_window": 8_192,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "code"],
    },
    "gpt-4-32k": {
        "context_window": 32_768,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["long_document_analysis"],
    },
    "gpt-3.5-turbo": {
        "context_window": 16_385,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["simple_chat", "classification"],
    },
    "gpt-3.5-turbo-instruct": {
        "context_window": 4_096,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["simple_completion", "legacy_apps"],
    },
    "o1": {
        "context_window": 200_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "complex_reasoning", "research", "science"],
    },
    "o1-mini": {
        "context_window": 128_000,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 3,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "coding", "reasoning"],
    },
    "o1-preview": {
        "context_window": 128_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "complex_reasoning"],
    },
    "o3-mini": {
        "context_window": 200_000,
        "quality_score": 4,
        "speed_score": 3,
        "cost_tier": 2,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["coding", "math", "reasoning", "science"],
    },
    "o3": {
        "context_window": 200_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "research", "complex_reasoning"],
    },
    "text-embedding-3-small": {
        "context_window": 8_191,
        "quality_score": 3,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "search", "clustering"],
    },
    "text-embedding-3-large": {
        "context_window": 8_191,
        "quality_score": 5,
        "speed_score": 4,
        "cost_tier": 2,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "semantic_search", "high_accuracy"],
    },
    "text-embedding-ada-002": {
        "context_window": 8_191,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "legacy_apps"],
    },
}

# Default capability for models not in our registry
_DEFAULT_CAPABILITY = {
    "context_window": 128_000,
    "quality_score": 3,
    "speed_score": 3,
    "cost_tier": 3,
    "supports_vision": False,
    "supports_functions": True,
    "best_for": [],
}

# ── Alias map ─────────────────────────────────────────────────────────────────
_CANONICAL_MAP: dict[str, str] = {
    "gpt-4o-2024-11-20": "gpt-4o",
    "gpt-4o-2024-08-06": "gpt-4o",
    "gpt-4o-mini-2024-07-18": "gpt-4o-mini",
    "o1-2024-12-17": "o1",
    "o1-mini-2024-09-12": "o1-mini",
    "o1-preview-2024-09-12": "o1-preview",
    "gpt-4-turbo-2024-04-09": "gpt-4-turbo",
    "gpt-4-turbo-preview": "gpt-4-turbo",
    "gpt-4-0125-preview": "gpt-4-turbo",
    "gpt-4-1106-preview": "gpt-4-turbo",
    "gpt-4-0613": "gpt-4",
    "gpt-4-0314": "gpt-4",
    "gpt-4-32k-0613": "gpt-4-32k",
    "gpt-3.5-turbo-0125": "gpt-3.5-turbo",
    "gpt-3.5-turbo-1106": "gpt-3.5-turbo",
    "gpt-3.5-turbo-0613": "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k": "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k-0613": "gpt-3.5-turbo",
}

_DATE_SUFFIX_RE = re.compile(r"-\d{4}-\d{2}-\d{2}$|-\d{8}$")


def resolve_model(model: str) -> str:
    if model in _CAPABILITY:
        return model
    if model in _CANONICAL_MAP:
        return _CANONICAL_MAP[model]
    stripped = _DATE_SUFFIX_RE.sub("", model)
    if stripped in _CAPABILITY:
        return stripped
    if stripped in _CANONICAL_MAP:
        return _CANONICAL_MAP[stripped]
    return model


def _capability_for(model: str) -> dict:
    canonical = resolve_model(model)
    return _CAPABILITY.get(canonical, _DEFAULT_CAPABILITY)


# ── Hardcoded seed prices ─────────────────────────────────────────────────────
# These are the absolute last resort. They go stale as OpenAI changes prices.
# They are ONLY used when the network is unreachable AND no disk cache exists.
# Prices: OpenAI pricing page, Q1 2025.
_SEED_PRICES: dict[str, tuple[float, float]] = {
    # model: (input_per_token, output_per_token)
    "gpt-4o": (2.50e-6, 10.00e-6),
    "gpt-4o-mini": (0.150e-6, 0.600e-6),
    "gpt-4-turbo": (10.00e-6, 30.00e-6),
    "gpt-4": (30.00e-6, 60.00e-6),
    "gpt-4-32k": (60.00e-6, 120.00e-6),
    "gpt-3.5-turbo": (0.50e-6, 1.50e-6),
    "gpt-3.5-turbo-instruct": (1.50e-6, 2.00e-6),
    "o1": (15.00e-6, 60.00e-6),
    "o1-mini": (3.00e-6, 12.00e-6),
    "o1-preview": (15.00e-6, 60.00e-6),
    "o3-mini": (1.10e-6, 4.40e-6),
    "o3": (10.00e-6, 40.00e-6),
    "text-embedding-3-small": (0.020e-6, 0.0),
    "text-embedding-3-large": (0.130e-6, 0.0),
    "text-embedding-ada-002": (0.100e-6, 0.0),
}


def _build_seed_pricing() -> dict[str, PricingEntry]:
    result: dict[str, PricingEntry] = {}
    for model, (inp, out) in _SEED_PRICES.items():
        cap = _capability_for(model)
        result[model] = PricingEntry(
            model=model,
            input_cost_per_token=inp,
            output_cost_per_token=out,
            **cap,
        )
    return result


# ── LiteLLM response parser ────────────────────────────────────────────────────


def _parse_litellm(raw: dict) -> dict[str, PricingEntry]:
    """
    Parse LiteLLM's model_prices_and_context_window.json.

    The file has one key per model. We extract all OpenAI-provider entries
    and enrich them with our capability metadata.

    LiteLLM format (relevant fields):
    {
      "gpt-4o": {
        "litellm_provider": "openai",
        "input_cost_per_token": 0.0000025,
        "output_cost_per_token": 0.000010,
        "max_tokens": 4096,
        "max_input_tokens": 128000,
        ...
      }
    }
    """
    result: dict[str, PricingEntry] = {}

    for model_id, data in raw.items():
        if not isinstance(data, dict):
            continue

        # Only OpenAI models
        provider = data.get("litellm_provider", "")
        if provider != "openai":
            continue

        inp = data.get("input_cost_per_token")
        out = data.get("output_cost_per_token")

        # Some embedding/audio models have no output cost
        if inp is None:
            continue

        try:
            inp_float = float(inp)
            out_float = float(out) if out is not None else 0.0
        except (ValueError, TypeError):
            continue

        # Skip clearly broken entries (negative or absurdly large)
        if inp_float < 0 or inp_float > 1.0:
            continue

        cap = _capability_for(model_id)

        try:
            result[model_id] = PricingEntry(
                model=model_id,
                input_cost_per_token=inp_float,
                output_cost_per_token=out_float,
                **cap,
            )
        except Exception:
            continue

    return result


# ── Disk cache ─────────────────────────────────────────────────────────────────


def _load_disk_cache(
    cache_path: Path,
    ttl_hours: int,
    *,
    ignore_ttl: bool = False,
) -> dict[str, PricingEntry] | None:
    if not cache_path.exists():
        return None
    try:
        raw = json.loads(cache_path.read_text(encoding="utf-8"))

        # Validate structure
        if "fetched_at" not in raw or "pricing" not in raw:
            return None

        fetched_at = datetime.fromisoformat(raw["fetched_at"])

        if not ignore_ttl:
            age = datetime.now(timezone.utc) - fetched_at
            if age > timedelta(hours=ttl_hours):
                logger.debug(
                    f"[token_purveyor] Pricing cache is {age.total_seconds()/3600:.1f}h old "
                    f"(ttl={ttl_hours}h) — will refresh."
                )
                return None

        pricing = {k: PricingEntry(**v) for k, v in raw["pricing"].items()}
        logger.debug(
            f"[token_purveyor] Loaded {len(pricing)} models from disk cache "
            f"(fetched {fetched_at.strftime('%Y-%m-%d %H:%M UTC')})"
        )
        return pricing

    except Exception as exc:
        logger.warning(f"[token_purveyor] Disk cache unreadable ({exc}) — ignoring.")
        return None


def _save_disk_cache(cache_path: Path, pricing: dict[str, PricingEntry]) -> None:
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "source": LITELLM_PRICING_URL,
            "model_count": len(pricing),
            "pricing": {k: v.model_dump() for k, v in pricing.items()},
        }
        # Write to temp file first, then rename — atomic on all platforms
        tmp = cache_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(cache_path)
        logger.debug(
            f"[token_purveyor] Saved {len(pricing)} models to "
            f"{cache_path} (atomic write)"
        )
    except Exception as exc:
        logger.warning(f"[token_purveyor] Could not save pricing cache: {exc}")


# ── Live network fetch ─────────────────────────────────────────────────────────


def _fetch_live(cache_path: Path) -> dict[str, PricingEntry] | None:
    try:
        import httpx

        logger.info("[token_purveyor] Fetching live pricing from LiteLLM registry…")
        with httpx.Client(timeout=8.0) as http:
            resp = http.get(LITELLM_PRICING_URL)
            resp.raise_for_status()
            raw = resp.json()

        pricing = _parse_litellm(raw)

        if len(pricing) < 5:
            # Something went very wrong with parsing — don't use it
            logger.warning(
                f"[token_purveyor] Live fetch parsed only {len(pricing)} models — "
                "response may be malformed. Skipping."
            )
            return None

        _save_disk_cache(cache_path, pricing)
        logger.info(
            f"[token_purveyor] Pricing refreshed: {len(pricing)} OpenAI models loaded."
        )
        return pricing

    except Exception as exc:
        logger.warning(
            f"[token_purveyor] Live pricing fetch failed ({type(exc).__name__}: {exc}). "
            "Falling back to cache or hardcoded prices."
        )
        return None


# ── Public API ─────────────────────────────────────────────────────────────────


def fetch_pricing(
    config: "TokenPurveyorConfig",
    *,
    force_refresh: bool = False,
) -> dict[str, PricingEntry]:
    """
    Return a pricing dict, sourcing from the fastest available option.

    Priority:
      1. In-memory cache (fastest — same process, zero I/O)
      2. Fresh disk cache (fast — one file read, no network)
      3. Live network fetch (slow — HTTP, but always current)
      4. Stale disk cache (fallback when offline)
      5. Hardcoded seed (absolute last resort)

    Thread-safe. Safe to call from multiple threads simultaneously.
    """
    global _MEMORY_CACHE

    # 1. In-memory cache (unless force_refresh requested)
    if not force_refresh:
        with _MEMORY_CACHE_LOCK:
            if _MEMORY_CACHE is not None:
                logger.debug(
                    f"[token_purveyor] Pricing from memory cache "
                    f"({len(_MEMORY_CACHE)} models)."
                )
                return _MEMORY_CACHE

    # 2. Fresh disk cache
    if not force_refresh:
        disk = _load_disk_cache(
            config.pricing_cache_path, config.pricing_cache_ttl_hours
        )
        if disk:
            with _MEMORY_CACHE_LOCK:
                _MEMORY_CACHE = disk
            return disk

    # 3. Live network fetch
    live = _fetch_live(config.pricing_cache_path)
    if live:
        with _MEMORY_CACHE_LOCK:
            _MEMORY_CACHE = live
        return live

    # 4. Stale disk cache (ignore TTL — better than hardcoded)
    stale = _load_disk_cache(
        config.pricing_cache_path,
        ttl_hours=0,
        ignore_ttl=True,
    )
    if stale:
        logger.warning(
            "[token_purveyor] Using stale pricing cache — "
            "run `token_purveyor update-prices` when online."
        )
        with _MEMORY_CACHE_LOCK:
            _MEMORY_CACHE = stale
        return stale

    # 5. Hardcoded seed — last resort
    logger.warning(
        "[token_purveyor] Using hardcoded fallback pricing. "
        "Prices may be outdated. Run `token_purveyor update-prices` "
        "when you have a network connection."
    )
    seed = _build_seed_pricing()
    with _MEMORY_CACHE_LOCK:
        _MEMORY_CACHE = seed
    return seed


def invalidate_memory_cache() -> None:
    """Force the next fetch_pricing() call to re-read from disk or network."""
    global _MEMORY_CACHE
    with _MEMORY_CACHE_LOCK:
        _MEMORY_CACHE = None
