"""
token_purveyor.calculator
~~~~~~~~~~~~~~~~~~~~~~~~~
Computes USD cost from token counts. Also provides model capability lookups
used by the recommendation and simulation engines.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from token_purveyor.models import PricingEntry
from token_purveyor.pricing import fetch_pricing, resolve_model  # ← module-level import

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig

logger = logging.getLogger("token_purveyor")


class CostCalculator:
    def __init__(self, config: "TokenPurveyorConfig") -> None:
        self._config = config
        self._pricing: dict[str, PricingEntry] = fetch_pricing(config)

    def compute(
        self, model: str, prompt_tokens: int, completion_tokens: int
    ) -> float | None:
        entry = self._get_entry(model)
        if entry is None:
            logger.warning(
                f"[token_purveyor] Model '{model}' not in pricing registry. "
                "Cost stored as NULL. Run `token_purveyor update-prices`."
            )
            return None
        return (
            prompt_tokens * entry.input_cost_per_token
            + completion_tokens * entry.output_cost_per_token
        )

    def get_entry(self, model: str) -> PricingEntry | None:
        return self._get_entry(model)

    def _get_entry(self, model: str) -> PricingEntry | None:
        if model in self._pricing:
            return self._pricing[model]
        canonical = resolve_model(model)
        return self._pricing.get(canonical)

    def refresh(self) -> None:
        self._pricing = fetch_pricing(self._config, force_refresh=True)
        logger.info(f"[token_purveyor] Pricing refreshed: {len(self._pricing)} models.")

    @property
    def all_entries(self) -> dict[str, PricingEntry]:
        return dict(self._pricing)

    @property
    def known_models(self) -> list[str]:
        return sorted(self._pricing.keys())
