"""
token_purveyor.tracker
~~~~~~~~~~~~~~~~~~~~~~
Central coordinator. Holds calculator, logger, plugin list, and
in-memory hash set for O(1) duplicate detection.
"""
from __future__ import annotations

import logging
from typing import Any, TYPE_CHECKING

from token_purveyor.calculator import CostCalculator
from token_purveyor.context import get_current_feature, get_current_user
from token_purveyor.logger import CallLogger
from token_purveyor.models import CallRecord
from token_purveyor.plugins.base import PluginBase

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig

logger = logging.getLogger("token_purveyor")


class Tracker:
    def __init__(self, config: "TokenPurveyorConfig") -> None:
        self.config = config
        self.calculator = CostCalculator(config)
        self.call_logger = CallLogger(config)
        self._plugins: list[PluginBase] = []
        # Pre-populate from DB so duplicate detection survives restarts
        self._seen_hashes: set[str] = set(self.call_logger.get_all_prompt_hashes())

    def register_plugin(self, plugin: PluginBase) -> None:
        self._plugins.append(plugin)

    def record_openai(
        self,
        response: Any,
        model: str,
        latency_ms: float,
        prompt_hash: str | None = None,
        prompt_text: str | None = None,
    ) -> CallRecord | None:
        usage = getattr(response, "usage", None)
        if usage is None:
            logger.warning(
                "[token_purveyor] No usage field in response — call not recorded. "
                "(Streaming calls are not tracked.)"
            )
            return None

        prompt_tokens: int     = getattr(usage, "prompt_tokens", 0) or 0
        completion_tokens: int = getattr(usage, "completion_tokens", 0) or 0
        total_tokens: int      = (
            getattr(usage, "total_tokens", None)
            or (prompt_tokens + completion_tokens)
        )
        actual_model: str = getattr(response, "model", None) or model

        is_duplicate = (prompt_hash in self._seen_hashes) if prompt_hash else False
        if prompt_hash:
            self._seen_hashes.add(prompt_hash)

        cost = self.calculator.compute(actual_model, prompt_tokens, completion_tokens)

        record = CallRecord(
            provider="openai",
            model=actual_model,
            feature_tag=get_current_feature(),
            user_id=get_current_user(),
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cost_usd=cost,
            latency_ms=latency_ms,
            prompt_hash=prompt_hash,
            is_duplicate=is_duplicate,
        )

        stored_prompt = prompt_text if self.config.store_prompts else None
        self.call_logger.insert(record, prompt_text=stored_prompt)

        for plugin in self._plugins:
            try:
                plugin.on_call_recorded(record)
            except Exception as exc:
                logger.warning(f"[token_purveyor] Plugin error ({type(plugin).__name__}): {exc}")

        return record