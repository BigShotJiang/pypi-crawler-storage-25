# token-purveyor

> Drop-in LLM cost tracker, deduplicator, cluster analyzer, and optimizer for OpenAI APIs.

[![PyPI version](https://badge.fury.io/py/token-purveyor.svg)](https://badge.fury.io/py/token-purveyor)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Install
```bash
pip install token-purveyor
```

## One-line setup
```python
import openai
from token_purveyor import CostAwareClient

client = CostAwareClient(openai.OpenAI())

# Use exactly like the real OpenAI client — nothing else changes
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}],
)
