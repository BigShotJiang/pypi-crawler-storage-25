from __future__ import annotations
import pytest
from token_purveyor.logger import CallLogger
from token_purveyor.models import CallRecord
from token_purveyor.analysis.clustering import PromptClusterer, _tokenize, _cosine


class TestTokenize:
    def test_removes_stop_words(self):
        freq = _tokenize("the quick brown fox")
        assert "the" not in freq
        assert "quick" in freq

    def test_lowercases(self):
        freq = _tokenize("Python Python python")
        assert freq.get("python") == 3

    def test_ignores_short_words(self):
        freq = _tokenize("I am a dog")
        # "am" and "dog" both 2+ chars; "I" and "a" should be filtered
        assert "i" not in freq
        assert "a" not in freq


class TestCosine:
    def test_identical_vectors(self):
        v = {"dog": 2, "cat": 1}
        assert abs(_cosine(v, v) - 1.0) < 1e-9

    def test_orthogonal_vectors(self):
        a = {"dog": 1}
        b = {"cat": 1}
        assert _cosine(a, b) == 0.0

    def test_empty_vector(self):
        assert _cosine({}, {"dog": 1}) == 0.0

    def test_partial_overlap(self):
        a = {"dog": 1, "cat": 1}
        b = {"dog": 1, "fish": 1}
        sim = _cosine(a, b)
        assert 0.0 < sim < 1.0


class TestPromptClusterer:
    @pytest.fixture
    def log(self, tmp_config):
        return CallLogger(tmp_config)

    def _insert(self, log, text: str, model="gpt-4o-mini"):
        rec = CallRecord(
            provider="openai", model=model,
            prompt_tokens=50, completion_tokens=20, total_tokens=70,
            cost_usd=0.0001, latency_ms=100.0,
            prompt_hash=None, is_duplicate=False,
        )
        log.insert(rec, prompt_text=text)

    def test_empty_returns_empty(self, log):
        assert PromptClusterer(log).cluster() == []

    def test_single_prompt_one_cluster(self, log):
        self._insert(log, "classify this customer review as positive or negative")
        clusters = PromptClusterer(log).cluster()
        assert len(clusters) == 1
        assert clusters[0].size == 1

    def test_similar_prompts_grouped(self, log):
        self._insert(log, "classify this customer review as positive or negative")
        self._insert(log, "classify the customer feedback as positive or negative")
        self._insert(log, "categorize customer review sentiment positive negative")
        # These three are semantically similar and should cluster together
        clusters = PromptClusterer(log).cluster()
        largest = max(clusters, key=lambda c: c.size)
        assert largest.size >= 2

    def test_dissimilar_prompts_different_clusters(self, log):
        self._insert(log, "translate this english sentence to french language")
        self._insert(log, "write python code to parse json data from file")
        # These are very different — should not cluster together
        clusters = PromptClusterer(log).cluster()
        assert len(clusters) >= 2