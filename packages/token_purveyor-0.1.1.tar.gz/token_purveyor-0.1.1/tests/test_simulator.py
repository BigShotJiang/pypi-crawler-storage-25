from __future__ import annotations
import pytest
from token_purveyor.logger import CallLogger
from token_purveyor.models import CallRecord
from token_purveyor.calculator import CostCalculator
from token_purveyor.analysis.simulator import WhatIfSimulator


def _rec(model: str, prompt: int, completion: int, cost: float | None) -> CallRecord:
    return CallRecord(
        provider="openai", model=model,
        prompt_tokens=prompt, completion_tokens=completion,
        total_tokens=prompt + completion,
        cost_usd=cost, latency_ms=400.0,
        prompt_hash=None, is_duplicate=False,
    )


class TestWhatIfSimulator:
    @pytest.fixture
    def log(self, tmp_config):
        return CallLogger(tmp_config)

    @pytest.fixture
    def calc(self, tmp_config):
        return CostCalculator(tmp_config)

    @pytest.fixture
    def sim(self, log, calc):
        return WhatIfSimulator(log, calc)

    def test_returns_none_when_no_calls(self, sim):
        result = sim.simulate("gpt-4o", "gpt-4o-mini")
        assert result is None

    def test_savings_positive_downgrade(self, log, sim):
        # gpt-4o costs more than gpt-4o-mini
        for _ in range(10):
            cost = 1000 * 2.50e-6 + 500 * 10.00e-6
            log.insert(_rec("gpt-4o", 1000, 500, cost))
        result = sim.simulate("gpt-4o", "gpt-4o-mini")
        assert result is not None
        assert result.savings_usd > 0
        assert result.calls_affected == 10
        assert result.quality_delta < 0  # gpt-4o-mini quality < gpt-4o

    def test_savings_negative_upgrade(self, log, sim):
        # switching from cheap to expensive = negative savings
        for _ in range(5):
            cost = 100 * 0.150e-6 + 50 * 0.600e-6
            log.insert(_rec("gpt-4o-mini", 100, 50, cost))
        result = sim.simulate("gpt-4o-mini", "gpt-4o")
        assert result is not None
        assert result.savings_usd < 0
        assert result.quality_delta > 0

    def test_context_compatible_flag(self, log, sim):
        log.insert(_rec("gpt-4o", 1000, 500, 0.01))
        result = sim.simulate("gpt-4o", "gpt-4o-mini")
        # Both have 128k context window
        assert result.context_compatible is True

    def test_functions_compatible_flag(self, log, sim):
        log.insert(_rec("gpt-4o", 1000, 500, 0.01))
        result = sim.simulate("gpt-4o", "o1")
        # o1 doesn't support function calling
        assert result.functions_compatible is False

    def test_unknown_model_raises(self, sim):
        with pytest.raises(ValueError, match="Unknown model"):
            sim.simulate("gpt-9999", "gpt-4o-mini")

    def test_math_correct(self, log, sim):
        # 1 call: 200 prompt, 100 completion on gpt-4o
        actual_cost = 200 * 2.50e-6 + 100 * 10.00e-6
        log.insert(_rec("gpt-4o", 200, 100, actual_cost))
        result = sim.simulate("gpt-4o", "gpt-4o-mini")
        expected_sim = 200 * 0.150e-6 + 100 * 0.600e-6
        assert abs(result.simulated_cost_usd - expected_sim) < 1e-10
        assert abs(result.actual_cost_usd - actual_cost) < 1e-10