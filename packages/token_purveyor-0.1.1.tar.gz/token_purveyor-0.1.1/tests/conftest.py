from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from token_purveyor.config import TokenPurveyorConfig
from token_purveyor.models import PricingEntry

TEST_PRICING: dict[str, PricingEntry] = {
    "gpt-4o": PricingEntry(
        model="gpt-4o",
        input_cost_per_token=2.50e-6,
        output_cost_per_token=10.00e-6,
        context_window=128_000,
        quality_score=5,
        speed_score=4,
        cost_tier=3,
        supports_vision=True,
        supports_functions=True,
        best_for=["complex_reasoning", "vision"],
    ),
    "gpt-4o-mini": PricingEntry(
        model="gpt-4o-mini",
        input_cost_per_token=0.150e-6,
        output_cost_per_token=0.600e-6,
        context_window=128_000,
        quality_score=3,
        speed_score=5,
        cost_tier=1,
        supports_vision=True,
        supports_functions=True,
        best_for=["simple_qa", "classification"],
    ),
    "gpt-4": PricingEntry(
        model="gpt-4",
        input_cost_per_token=30.00e-6,
        output_cost_per_token=60.00e-6,
        context_window=8_192,
        quality_score=4,
        speed_score=2,
        cost_tier=5,
        supports_vision=False,
        supports_functions=True,
        best_for=["complex_reasoning"],
    ),
    "o1": PricingEntry(
        model="o1",
        input_cost_per_token=15.00e-6,
        output_cost_per_token=60.00e-6,
        context_window=200_000,
        quality_score=5,
        speed_score=1,
        cost_tier=5,
        supports_vision=False,
        supports_functions=False,
        best_for=["math", "research"],
    ),
}


@pytest.fixture(autouse=True)
def mock_fetch_pricing(monkeypatch):
    # Patch at the SOURCE — all importers get the patched version automatically
    monkeypatch.setattr(
        "token_purveyor.pricing.fetch_pricing", lambda *a, **kw: TEST_PRICING
    )


@pytest.fixture
def tmp_config(tmp_path) -> TokenPurveyorConfig:
    return TokenPurveyorConfig(
        base_dir=str(tmp_path / ".token_purveyor"),
        store_prompts=True,
    )


@pytest.fixture
def mock_openai_response():
    def _make(model="gpt-4o-mini", prompt=100, completion=50):
        usage = MagicMock()
        usage.prompt_tokens = prompt
        usage.completion_tokens = completion
        usage.total_tokens = prompt + completion
        r = MagicMock()
        r.model = model
        r.usage = usage
        return r

    return _make
