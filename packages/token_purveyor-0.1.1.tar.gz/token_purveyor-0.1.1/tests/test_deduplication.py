from __future__ import annotations
import pytest
from token_purveyor.logger import CallLogger
from token_purveyor.models import CallRecord
from token_purveyor.analysis.deduplication import DuplicateAnalyzer


def _rec(prompt_hash: str, cost: float = 0.001) -> CallRecord:
    return CallRecord(
        provider="openai", model="gpt-4o-mini",
        prompt_tokens=100, completion_tokens=50, total_tokens=150,
        cost_usd=cost, latency_ms=200.0,
        prompt_hash=prompt_hash, is_duplicate=False,
    )


class TestDuplicateAnalyzer:
    @pytest.fixture
    def log(self, tmp_config):
        return CallLogger(tmp_config)

    def test_no_duplicates(self, log):
        log.insert(_rec("hash1"))
        log.insert(_rec("hash2"))
        report = DuplicateAnalyzer(log).analyze()
        assert report.unique_prompts_repeated == 0
        assert report.total_duplicate_calls == 0
        assert report.wasted_cost_usd == 0.0

    def test_detects_duplicates(self, log):
        for _ in range(4):
            log.insert(_rec("same_hash", cost=0.001))
        report = DuplicateAnalyzer(log).analyze()
        assert report.unique_prompts_repeated == 1
        assert report.total_duplicate_calls == 3
        assert abs(report.wasted_cost_usd - 0.003) < 1e-9

    def test_multiple_duplicate_groups(self, log):
        for _ in range(3):
            log.insert(_rec("group_a", cost=0.002))
        for _ in range(2):
            log.insert(_rec("group_b", cost=0.005))
        report = DuplicateAnalyzer(log).analyze()
        assert report.unique_prompts_repeated == 2
        assert report.total_duplicate_calls == 3  # 2 from A + 1 from B

    def test_top_duplicates_populated(self, log):
        for _ in range(5):
            log.insert(_rec("popular", cost=0.01))
        report = DuplicateAnalyzer(log).analyze()
        assert len(report.top_duplicates) == 1
        assert report.top_duplicates[0]["total_calls"] == 5