from __future__ import annotations
import pytest
from token_purveyor.calculator import CostCalculator
from token_purveyor.pricing import resolve_model, _DATE_SUFFIX_RE


class TestResolveModel:
    def test_canonical_passthrough(self):
        assert resolve_model("gpt-4o") == "gpt-4o"

    def test_alias_map(self):
        assert resolve_model("gpt-4o-2024-11-20") == "gpt-4o"

    def test_strips_date_suffix(self):
        import re
        result = re.sub(r"-\d{4}-\d{2}-\d{2}$|-\d{8}$", "", "gpt-4o-2024-08-06")
        assert result == "gpt-4o"

    def test_mini_not_stripped(self):
        assert resolve_model("gpt-4o-mini") == "gpt-4o-mini"

    def test_unknown_passthrough(self):
        assert resolve_model("gpt-99-ultra") == "gpt-99-ultra"


class TestCostCalculator:
    @pytest.fixture
    def calc(self, tmp_config):
        return CostCalculator(tmp_config)

    def test_known_model(self, calc):
        cost = calc.compute("gpt-4o-mini", 1000, 500)
        expected = 1000 * 0.150e-6 + 500 * 0.600e-6
        assert abs(cost - expected) < 1e-12

    def test_unknown_model_returns_none(self, calc):
        assert calc.compute("gpt-999", 100, 100) is None

    def test_zero_tokens(self, calc):
        assert calc.compute("gpt-4o-mini", 0, 0) == 0.0

    def test_gpt4o_pricing(self, calc):
        cost = calc.compute("gpt-4o", 1000, 500)
        expected = 1000 * 2.50e-6 + 500 * 10.00e-6
        assert abs(cost - expected) < 1e-12

    def test_get_entry_returns_entry(self, calc):
        entry = calc.get_entry("gpt-4o-mini")
        assert entry is not None
        assert entry.model == "gpt-4o-mini"

    def test_known_models_sorted(self, calc):
        models = calc.known_models
        assert models == sorted(models)
        assert "gpt-4o" in models