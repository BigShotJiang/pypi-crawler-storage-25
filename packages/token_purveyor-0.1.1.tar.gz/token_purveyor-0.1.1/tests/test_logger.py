from __future__ import annotations
import pytest
from token_purveyor.logger import CallLogger
from token_purveyor.models import CallRecord


def _rec(**kw) -> CallRecord:
    defaults = dict(
        provider="openai", model="gpt-4o-mini",
        prompt_tokens=100, completion_tokens=50, total_tokens=150,
        cost_usd=0.0000375, latency_ms=312.0,
        prompt_hash="abc123", is_duplicate=False,
    )
    defaults.update(kw)
    return CallRecord(**defaults)


class TestCallLogger:
    @pytest.fixture
    def log(self, tmp_config):
        return CallLogger(tmp_config)

    def test_insert_and_retrieve(self, log):
        log.insert(_rec())
        rows = log.query_all()
        assert len(rows) == 1
        assert rows[0]["model"] == "gpt-4o-mini"

    def test_null_cost_stored(self, log):
        log.insert(_rec(cost_usd=None))
        rows = log.query_all()
        assert rows[0]["cost_usd"] is None

    def test_user_id_stored(self, log):
        log.insert(_rec(user_id="alice"))
        rows = log.query_all()
        assert rows[0]["user_id"] == "alice"

    def test_prompt_hash_stored(self, log):
        log.insert(_rec(prompt_hash="deadbeef"))
        rows = log.query_all()
        assert rows[0]["prompt_hash"] == "deadbeef"

    def test_is_duplicate_stored(self, log):
        log.insert(_rec(is_duplicate=True))
        rows = log.query_all()
        assert bool(rows[0]["is_duplicate"]) is True

    def test_prompt_text_stored_when_provided(self, log):
        rec = _rec()
        log.insert(rec, prompt_text="Hello world")
        prompts = log.query_prompts_for_clustering()
        assert len(prompts) == 1
        assert prompts[0]["prompt_text"] == "Hello world"

    def test_summary_totals(self, log):
        log.insert(_rec(cost_usd=0.01, total_tokens=100))
        log.insert(_rec(cost_usd=0.02, total_tokens=200))
        s = log.query_summary()
        assert s["totals"]["calls"] == 2
        assert abs(s["totals"]["total_cost"] - 0.03) < 1e-9

    def test_clear(self, log):
        for _ in range(5):
            log.insert(_rec())
        count = log.clear()
        assert count == 5
        assert len(log.query_all()) == 0

    def test_get_all_hashes(self, log):
        log.insert(_rec(prompt_hash="hash1"))
        log.insert(_rec(prompt_hash="hash2"))
        hashes = log.get_all_prompt_hashes()
        assert set(hashes) == {"hash1", "hash2"}