"""
examples/quickstart.py
~~~~~~~~~~~~~~~~~~~~~~~
Demonstrates every feature of token_purveyor.
No real OpenAI key needed — uses a mock client for demonstration.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

# ── Build a mock OpenAI client ───────────────────────────────────────────────

def _make_response(model: str, prompt_tok: int, comp_tok: int) -> MagicMock:
    usage = MagicMock()
    usage.prompt_tokens     = prompt_tok
    usage.completion_tokens = comp_tok
    usage.total_tokens      = prompt_tok + comp_tok

    response = MagicMock()
    response.model   = model
    response.usage   = usage
    response.choices = [MagicMock()]
    response.choices[0].message.content = "This is a mock response."
    return response


def _mock_openai() -> MagicMock:
    """Build a mock that looks like openai.OpenAI() to token_purveyor."""
    client = MagicMock()
    type(client).__module__ = "openai._client"

    def create_side_effect(**kwargs):
        time.sleep(0.01)  # simulate latency
        tok = len(" ".join(
            m.get("content", "") for m in kwargs.get("messages", [])
        ).split()) + 50
        return _make_response(kwargs.get("model", "gpt-4o"), tok, tok // 3)

    client.chat.completions.create = MagicMock(side_effect=create_side_effect)
    return client


# ── Main demo ────────────────────────────────────────────────────────────────

def main() -> None:
    import tempfile, pathlib
    from token_purveyor import (
        CostAwareClient,
        TokenPurveyorConfig,
        feature_tag,
        user_tag,
        track_feature,
        track_user,
    )
    from token_purveyor.plugins.base import PluginBase
    from token_purveyor.models import CallRecord

    # Use a temp directory so this example is self-contained
    tmpdir = tempfile.mkdtemp()

    config = TokenPurveyorConfig(
        base_dir=tmpdir,
        store_prompts=True,   # enable clustering + compression analysis
        warn_on_stream=True,
    )

    # ── Custom plugin: alert on expensive calls ──────────────────────────
    class CostAlertPlugin(PluginBase):
        def on_call_recorded(self, record: CallRecord) -> None:
            if record.cost_usd and record.cost_usd > 0.005:
                print(f"  [ALERT] Expensive call: ${record.cost_usd:.6f} ({record.model})")

    openai_mock = _mock_openai()
    client = CostAwareClient(openai_mock, config=config)
    client.register_plugin(CostAlertPlugin())

    print("\n=== token_purveyor quickstart ===\n")

    # ── 1. Basic call ────────────────────────────────────────────────────
    print("1. Basic call (no tags)")
    client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "What is the capital of France?"}],
    )

    # ── 2. Feature-tagged calls ──────────────────────────────────────────
    print("2. Feature-tagged calls")

    @feature_tag("summarization")
    def summarize(text: str) -> str:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": f"Summarize: {text}"}],
        )
        return resp.choices[0].message.content

    for doc in ["A long article about climate change...",
                "Another document about renewable energy..."]:
        summarize(doc)

    # ── 3. User-tagged calls ─────────────────────────────────────────────
    print("3. User-tagged calls")
    for user_id in ["alice", "alice", "bob", "alice"]:
        with track_user(user_id):
            with track_feature("chat"):
                client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": f"Hello from {user_id}!"}],
                )

    # ── 4. Duplicate prompt (intentional) ────────────────────────────────
    print("4. Sending duplicate prompts to demonstrate deduplication")
    duplicate_msg = [{"role": "user", "content": "Translate 'hello' to Spanish."}]
    for _ in range(4):
        client.chat.completions.create(model="gpt-4o", messages=duplicate_msg)

    # ── 5. Simulate rapid small calls (batch opportunity) ─────────────────
    print("5. Simulating rapid small calls for batch detection")
    with track_feature("classification"):
        for i in range(6):
            client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": f"Classify sentence {i}: Is this positive or negative?"}],
            )

    # ── 6. Streaming call (should warn, not crash) ────────────────────────
    print("6. Streaming call (tracked as untracked, warns)")
    openai_mock.chat.completions.create.return_value = MagicMock()
    client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Tell me a story"}],
        stream=True,
    )

    # ── 7. Passthrough: embeddings (falls through to real client) ─────────
    print("7. embeddings.create falls through to real client (not intercepted)")
    _ = client.embeddings  # Just access it — not intercepted

    # ── 8. Print summary ─────────────────────────────────────────────────
    print("\n=== DB summary ===")
    from token_purveyor.logger import CallLogger
    log = CallLogger(config)
    s = log.query_summary()
    t = s["totals"]
    print(f"  Calls: {t['calls']}  |  Tokens: {t['total_tokens']}  |  Cost: ${t['total_cost'] or 0:.6f}")

    print("\n=== Deduplication ===")
    from token_purveyor.analysis.deduplication import DuplicateAnalyzer
    dup = DuplicateAnalyzer(log).analyze()
    print(f"  {dup.unique_prompts_repeated} repeated prompt(s), "
          f"{dup.total_duplicate_calls} duplicate calls, "
          f"${dup.wasted_cost_usd:.6f} wasted")

    print("\n=== Model recommendations ===")
    from token_purveyor.calculator import CostCalculator
    calc = CostCalculator(config)
    from token_purveyor.analysis.recommender import ModelRecommender
    recs = ModelRecommender(log, calc).recommend()
    if recs:
        for r in recs:
            print(f"  [{r.impact}] {r.current_model} → {r.recommended_model}: "
                  f"save ${r.savings_usd:.4f} ({r.savings_pct:.1f}%)")
    else:
        print("  No recommendations.")

    print("\n=== What-if: gpt-4o → gpt-4o-mini ===")
    from token_purveyor.analysis.simulator import WhatIfSimulator
    sim = WhatIfSimulator(log, calc).simulate("gpt-4o", "gpt-4o-mini")
    if sim:
        print(f"  {sim.calls_affected} calls affected")
        print(f"  Actual:    ${sim.actual_cost_usd:.6f}")
        print(f"  Simulated: ${sim.simulated_cost_usd:.6f}")
        print(f"  Savings:   ${sim.savings_usd:.6f} ({sim.savings_pct:+.1f}%)")
        print(f"  → {sim.recommendation}")

    print("\n=== Prompt clusters ===")
    from token_purveyor.analysis.clustering import PromptClusterer
    clusters = PromptClusterer(log).cluster()
    print(f"  {len(clusters)} cluster(s) found")
    for c in clusters[:3]:
        print(f"  Cluster {c.cluster_id} ({c.size} calls): {', '.join(c.common_terms[:4])}")

    print("\n=== Per-user attribution ===")
    from token_purveyor.analysis.attribution import UserAttributor
    attrs = UserAttributor(log).attribute()
    for a in attrs:
        print(f"  {a.user_id}: {a.call_count} calls, ${a.total_cost_usd:.6f} ({a.pct_of_total_cost:.1f}%)")

    print(f"\nDB location: {config.db_path}")
    print("Run `token_purveyor report` and `token_purveyor analyze` in your project.\n")


if __name__ == "__main__":
    main()