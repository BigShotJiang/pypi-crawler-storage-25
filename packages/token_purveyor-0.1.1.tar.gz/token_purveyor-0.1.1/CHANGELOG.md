# Changelog

## [0.1.0] — 2025-01-01

### Added
- `CostAwareClient` — drop-in proxy for `openai.OpenAI` and `openai.AsyncOpenAI`
- Prompt fingerprinting and duplicate detection via SHA-256
- Per-feature and per-user cost tagging (`@feature_tag`, `@user_tag`, `track_feature`, `track_user`)
- SQLite-backed call logger with WAL mode
- Accurate hardcoded OpenAI pricing (2025-Q1) with live-fetch fallback
- Model recommendation engine (rule-based, deterministic)
- What-if model switch simulator
- Semantic prompt clustering (bag-of-words cosine similarity)
- Prompt compression analyzer (filler phrase + trigram detection)
- Batch optimization detector
- Per-user cost attribution
- Plugin system via `PluginBase`
- CLI: `report`, `analyze`, `simulate`, `update-prices`, `reset`