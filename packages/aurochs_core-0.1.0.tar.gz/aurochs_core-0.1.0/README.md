# aurochs-core

Shared infrastructure for the Aurochs agency line plugins. Not user-facing.

Ships the canonical advisory-lockfile classes (`WriteLock`, `MigrateLock`, `LockError`)
and the SQLite connection helper (`db_connect`) used by every plugin in the Aurochs
agency line (`aurochs-recall`, `aurochs-voice`, `aurochs-llm-scrub`, `aurochs-seo-geo`).

Plugins still own their own `MigrationRunner`, types, and schema modules — only the
truly shared substrate lives here.

## Public surface

```python
from aurochs_core import LockError, MigrateLock, WriteLock, db_connect
```

Pragma contract applied by `db_connect()`:

- `foreign_keys = ON`
- `journal_mode = WAL`
- `synchronous = NORMAL`
- `busy_timeout = 30000` (30s)
- `row_factory = sqlite3.Row`

## License

MIT — see [LICENSE](LICENSE).
