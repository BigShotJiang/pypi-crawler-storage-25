"""Shared SQLite connection helper.

Establishes the canonical pragma contract used by every Aurochs plugin:
``foreign_keys=ON``, ``journal_mode=WAL``, ``synchronous=NORMAL``,
``busy_timeout=30000``, ``isolation_level=None`` (autocommit). Row
factory is ``sqlite3.Row``.

The pragmas applied here are not optional — leaving any of them off
changes correctness, not just performance:

* ``foreign_keys = ON`` — SQLite default is OFF. Without this, every
  FK declared in the schema is documentation, not enforcement.
* ``journal_mode = WAL`` — concurrent readers + one writer; required
  for the OS-lockfile concurrency model.
* ``busy_timeout = 30000`` — 30s cap before raising ``database is
  locked``.
* ``synchronous = NORMAL`` — WAL-safe; ``FULL`` is unnecessary with
  WAL and costs roughly 2x on bulk inserts.
* ``isolation_level=None`` — autocommit; the caller manages
  transactions explicitly (BEGIN/COMMIT). Required for plugin
  ``MigrationRunner`` paths that issue ``BEGIN EXCLUSIVE``.

NOTE: Plugins still own their own ``MigrationRunner`` — schema
migration logic varies per-plugin (different migration files,
different ``schema_version`` table ownership). This module ships only
the connection helper.

Connections are NOT thread-safe by default. Multiprocessing workers
MUST call ``db_connect()`` themselves rather than passing a connection
across the process boundary — pickling a sqlite3 Connection is not
supported.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

# Pragmas applied to every connection, in order. Read by tests to
# assert the contract.
_REQUIRED_PRAGMAS: tuple[tuple[str, str], ...] = (
    ("foreign_keys", "ON"),
    ("journal_mode", "WAL"),
    ("synchronous", "NORMAL"),
    ("busy_timeout", "30000"),
)


def db_connect(db_path: Path | str) -> sqlite3.Connection:
    """Open a sqlite3 Connection with the canonical Aurochs pragma contract.

    Creates the database file if it does not exist (and the parent dir
    if needed). The caller owns the connection — close it (or use as a
    context manager) when done.

    Parameters
    ----------
    db_path:
        Path to the database file. ``":memory:"`` is supported for
        tests; pass it as a literal str.

    Returns
    -------
    sqlite3.Connection
        Autocommit connection with ``Row`` row_factory and all required
        pragmas applied. ``isolation_level=None`` so the caller manages
        transactions explicitly (BEGIN/COMMIT) — necessary for the
        EXCLUSIVE migration transactions plugins use.

    Raises
    ------
    RuntimeError
        If ``foreign_keys = ON`` did not take (some sqlite builds ignore
        the pragma inside a transaction; we fail loud rather than silently
        running with FKs off).
    """
    if isinstance(db_path, str) and db_path == ":memory:":
        target: str | Path = ":memory:"
    else:
        target = Path(db_path)
        if isinstance(target, Path):
            target.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(
        str(target),
        isolation_level=None,  # autocommit; we manage transactions manually
        check_same_thread=True,
    )
    conn.row_factory = sqlite3.Row

    for pragma, value in _REQUIRED_PRAGMAS:
        conn.execute(f"PRAGMA {pragma} = {value}")

    # Verify foreign_keys actually took. Some sqlite builds ignore the
    # pragma inside a transaction; fail loud if it didn't.
    enforced = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    if enforced != 1:
        conn.close()
        raise RuntimeError(
            "PRAGMA foreign_keys = ON failed to apply. This sqlite build "
            "may not support FK enforcement; refusing to continue."
        )

    return conn
