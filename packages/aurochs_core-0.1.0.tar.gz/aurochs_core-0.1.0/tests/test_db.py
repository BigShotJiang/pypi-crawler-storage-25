"""Unit tests for db_connect — pragma contract.

The shared db_connect helper applies the canonical Aurochs pragma
contract to every connection. These tests assert each pragma is set
exactly as documented; deviation is a regression that affects every
plugin downstream.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from aurochs_core import db_connect


class TestPragmas:
    def test_foreign_keys_pragma_on(self, tmp_path: Path) -> None:
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            result = conn.execute("PRAGMA foreign_keys").fetchone()[0]
            assert result == 1, "PRAGMA foreign_keys must be ON every connection"
        finally:
            conn.close()

    def test_journal_mode_wal(self, tmp_path: Path) -> None:
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            result = conn.execute("PRAGMA journal_mode").fetchone()[0]
            assert result.lower() == "wal"
        finally:
            conn.close()

    def test_synchronous_normal(self, tmp_path: Path) -> None:
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            # NORMAL = 1 in PRAGMA result.
            result = conn.execute("PRAGMA synchronous").fetchone()[0]
            assert result == 1
        finally:
            conn.close()

    def test_busy_timeout_30s(self, tmp_path: Path) -> None:
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            result = conn.execute("PRAGMA busy_timeout").fetchone()[0]
            assert result == 30000
        finally:
            conn.close()


class TestRowFactory:
    def test_row_factory_is_sqlite_row(self, tmp_path: Path) -> None:
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            assert conn.row_factory is sqlite3.Row
        finally:
            conn.close()

    def test_rows_support_mapping_access(self, tmp_path: Path) -> None:
        """Row factory should let us index columns by name."""
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)")
            conn.execute("INSERT INTO t (name) VALUES (?)", ("alpha",))
            conn.commit()
            row = conn.execute("SELECT id, name FROM t").fetchone()
            assert row["name"] == "alpha"
            assert row["id"] == 1
        finally:
            conn.close()


class TestFkEnforcement:
    def test_fk_actually_enforces(self, tmp_path: Path) -> None:
        """Smoke-test: with FKs ON, violating-row inserts raise IntegrityError."""
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            conn.execute(
                "CREATE TABLE parent (id INTEGER PRIMARY KEY, name TEXT)"
            )
            conn.execute(
                "CREATE TABLE child ("
                "  id INTEGER PRIMARY KEY,"
                "  parent_id INTEGER,"
                "  FOREIGN KEY (parent_id) REFERENCES parent(id)"
                ")"
            )
            conn.commit()
            with pytest.raises(sqlite3.IntegrityError):
                conn.execute(
                    "INSERT INTO child (parent_id) VALUES (?)", (999,)
                )
        finally:
            conn.close()


class TestPathArg:
    def test_path_object_accepted(self, tmp_path: Path) -> None:
        """db_path: Path is the documented signature; pathlib.Path must work."""
        db: Path = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            assert db.exists()
        finally:
            conn.close()

    def test_creates_parent_dir(self, tmp_path: Path) -> None:
        """Fresh install should create the db's parent directory if missing."""
        nested = tmp_path / "nested" / "deeply" / "test.db"
        conn = db_connect(nested)
        try:
            assert nested.parent.exists()
            assert nested.exists()
        finally:
            conn.close()

    def test_memory_db(self) -> None:
        """``:memory:`` must be honored as an in-memory DB, not a file path."""
        conn = db_connect(":memory:")
        try:
            result = conn.execute("PRAGMA foreign_keys").fetchone()[0]
            assert result == 1
        finally:
            conn.close()


class TestAutocommit:
    def test_isolation_level_is_none(self, tmp_path: Path) -> None:
        """Autocommit mode is required for plugin BEGIN EXCLUSIVE migrations."""
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            assert conn.isolation_level is None
        finally:
            conn.close()

    def test_begin_exclusive_works(self, tmp_path: Path) -> None:
        """Plugins issue BEGIN EXCLUSIVE manually; verify the path is open."""
        db = tmp_path / "test.db"
        conn = db_connect(db)
        try:
            conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY)")
            conn.execute("BEGIN EXCLUSIVE")
            conn.execute("INSERT INTO t (id) VALUES (?)", (1,))
            conn.execute("COMMIT")
            row = conn.execute("SELECT COUNT(*) FROM t").fetchone()
            assert row[0] == 1
        finally:
            conn.close()
