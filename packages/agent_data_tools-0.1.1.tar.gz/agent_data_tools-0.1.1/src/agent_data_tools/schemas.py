function_schema = {
    "type": "object",
    "properties": {
        "type": {"const": "function"},
        "function": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "函数名"},
                "description": {"type": "string", "description": "函数说明"},
                "parameters": {
                    "type": "object",
                    "properties": {
                        "type": {"const": "object"},
                        "properties": {"type": "object"},
                    },
                    "required": ["type", "properties"],
                },
            },
            "required": ["name", "description", "parameters"],
        },
    },
    "required": ["type", "function"],
}


function_schema_strict = {
    "type": "object",
    "properties": {
        "type": {"const": "function"},
        "function": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "pattern": "^[a-zA-Z0-9_\\.-]+$",
                    "description": "函数名",
                },
                "description": {"type": "string", "description": "函数说明"},
                "parameters": {
                    "type": "object",
                    "properties": {
                        "type": {"const": "object"},
                        "properties": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "object",
                                "properties": {
                                    "type": {
                                        "type": "string",
                                        "enum": [
                                            "string",
                                            "number",
                                            "integer",
                                            "boolean",
                                            "array",
                                            "object",
                                        ],
                                    },
                                    "description": {"type": "string"},
                                    "enum": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "items": {"$ref": "#/definitions/schema"},
                                    "properties": {
                                        "type": "object",
                                        "additionalProperties": {
                                            "$ref": "#/definitions/schema"
                                        },
                                    },
                                    "required": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                                "required": ["type"],
                            },
                        },
                        "required": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                    "required": ["type", "properties"],
                },
            },
            "required": ["name", "description", "parameters"],
        },
    },
    "required": ["type", "function"],
    "definitions": {
        "schema": {
            "type": "object",
            "properties": {
                "type": {
                    "type": "string",
                    "enum": [
                        "string",
                        "number",
                        "integer",
                        "boolean",
                        "array",
                        "object",
                    ],
                },
                "description": {"type": "string"},
                "enum": {"type": "array", "items": {"type": "string"}},
                "items": {"$ref": "#/definitions/schema"},
                "properties": {
                    "type": "object",
                    "additionalProperties": {"$ref": "#/definitions/schema"},
                },
                "required": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["type"],
        }
    },
}
