from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path
from typing import Any, Sequence

from jinja2 import Environment

from .models import TemplateSpec


DEFAULT_TEMPLATE_WEIGHTS: dict[str, float] = {
    "qwen3.5_35ba3b_think_xml.jinja": 1.0,
    "yaml.jinja": 0.0,
    "toolace.jinja": 0.0,
    "qwen3.5_35ba3b_think.jinja": 0.0,
    "qwen3_modify_v1.5_w_think.jinja": 0.0,
}


def _tojson_no_ascii(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def _raise_exception(message: str) -> None:
    raise ValueError(message)


def create_template_environment() -> Environment:
    env = Environment()
    env.filters["tojson"] = _tojson_no_ascii
    env.globals["raise_exception"] = _raise_exception
    return env


def _builtin_template_root() -> Path:
    return Path(str(files("agent_data_tools").joinpath("builtin_templates")))


def _read_template_file(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")


def _template_spec_from_dict(item: dict[str, Any]) -> TemplateSpec:
    name = item.get("name")
    path = item.get("path")
    content = item.get("content")
    weight = float(item.get("weight", 1.0))
    if content is None and path is None:
        raise ValueError("模板配置至少需要提供 path 或 content")
    if content is None:
        content = _read_template_file(path)
    if name is None:
        name = Path(path).name if path else "inline_template"
    return TemplateSpec(name=name, content=content, weight=weight, source=str(path) if path else "inline")


def _load_config_items(config_path: str | Path) -> list[dict[str, Any]]:
    with Path(config_path).open("r", encoding="utf-8") as file:
        data = json.load(file)

    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        items: list[dict[str, Any]] = []
        for name, value in data.items():
            if not isinstance(value, dict):
                continue
            item = dict(value)
            item.setdefault("name", name)
            items.append(item)
        return items
    raise ValueError("模板配置文件必须是 JSON object 或 JSON array")


def load_builtin_template_specs(template_weights: dict[str, float] | None = None) -> list[TemplateSpec]:
    builtin_dir = _builtin_template_root()
    weights = dict(DEFAULT_TEMPLATE_WEIGHTS)
    if template_weights:
        weights.update(template_weights)

    specs: list[TemplateSpec] = []
    for file_path in sorted(builtin_dir.glob("*.jinja")):
        specs.append(
            TemplateSpec(
                name=file_path.name,
                content=_read_template_file(file_path),
                weight=float(weights.get(file_path.name, 1.0)),
                source=str(file_path),
            )
        )
    return specs


def load_template_specs_from_dir(template_dir: str | Path) -> list[TemplateSpec]:
    specs: list[TemplateSpec] = []
    for file_path in sorted(Path(template_dir).glob("*.jinja")):
        specs.append(
            TemplateSpec(
                name=file_path.name,
                content=_read_template_file(file_path),
                weight=1.0,
                source=str(file_path),
            )
        )
    return specs


def resolve_template_specs(
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    *,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
) -> list[TemplateSpec]:
    resolved: list[TemplateSpec] = []

    if template_config_path is not None:
        resolved.extend(_template_spec_from_dict(item) for item in _load_config_items(template_config_path))

    if template_dir is not None:
        resolved.extend(load_template_specs_from_dir(template_dir))

    if template_specs:
        builtin_root = _builtin_template_root()
        for item in template_specs:
            if isinstance(item, TemplateSpec):
                resolved.append(item)
            elif isinstance(item, dict):
                resolved.append(_template_spec_from_dict(item))
            else:
                candidate = Path(item)
                if candidate.exists():
                    resolved.append(
                        TemplateSpec(
                            name=candidate.name,
                            content=_read_template_file(candidate),
                            weight=1.0,
                            source=str(candidate),
                        )
                    )
                else:
                    builtin_path = builtin_root / str(item)
                    if not builtin_path.exists():
                        raise ValueError(f"模板不存在: {item}")
                    resolved.append(
                        TemplateSpec(
                            name=builtin_path.name,
                            content=_read_template_file(builtin_path),
                            weight=float(DEFAULT_TEMPLATE_WEIGHTS.get(builtin_path.name, 1.0)),
                            source=str(builtin_path),
                        )
                    )

    if use_builtin_templates is None:
        use_builtin_templates = not resolved

    if use_builtin_templates:
        resolved.extend(load_builtin_template_specs())

    if not resolved:
        raise ValueError("未找到可用模板，请提供 template_specs、template_dir 或 template_config_path")
    return resolved


def choose_template(template_specs: Sequence[TemplateSpec], rng: Any) -> TemplateSpec:
    positive_specs = [spec for spec in template_specs if spec.weight > 0]
    if not positive_specs:
        raise ValueError("至少需要一个权重大于 0 的模板")
    if rng is None:
        return positive_specs[0]
    return rng.choices(positive_specs, weights=[spec.weight for spec in positive_specs], k=1)[0]


def render_with_template(
    template_spec: TemplateSpec,
    data: dict[str, Any],
    *,
    env: Environment | None = None,
) -> str:
    template_env = env or create_template_environment()
    template = template_env.from_string(template_spec.content)
    return template.render(data)


def list_builtin_template_names() -> list[str]:
    return [spec.name for spec in load_builtin_template_specs()]
