from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Iterable


def deep_copy_json(data: dict[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(data)


def ensure_json_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        if not isinstance(parsed, dict):
            raise ValueError("arguments 必须是 JSON object")
        return parsed
    raise ValueError("arguments 必须是 dict 或 JSON 字符串")


def resolve_reasoning_content(message: dict[str, Any]) -> str | None:
    reasoning_content = message.get("reasoning_content")
    if isinstance(reasoning_content, str):
        return reasoning_content

    reasoning = message.get("reasoning")
    if isinstance(reasoning, str):
        return reasoning

    return None


def iter_jsonl(path: str | Path) -> Iterable[tuple[int, str]]:
    with Path(path).open("r", encoding="utf-8") as file:
        for line_number, raw_line in enumerate(file, start=0):
            line = raw_line.strip()
            if line:
                yield line_number, line


def ensure_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False)


def format_xml_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, indent=2)


def resolve_media_paths(root: str | None, value: Any) -> list[str]:
    if root is None:
        return []
    if isinstance(value, str):
        return [str(Path(root) / value)]
    if isinstance(value, list):
        return [str(Path(root) / item) for item in value]
    raise TypeError(f"媒体字段必须是 str 或 list，当前为: {type(value)}")
