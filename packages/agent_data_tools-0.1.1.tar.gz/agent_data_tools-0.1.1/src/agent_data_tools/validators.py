from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from math import inf
from pathlib import Path
from typing import Any

from jsonschema import Draft7Validator

from .models import ValidationResult
from .schemas import function_schema, function_schema_strict
from .utils import ensure_json_object, iter_jsonl, resolve_reasoning_content


def validate_function_definition(
    func_def: dict[str, Any],
    *,
    strict: bool = False,
) -> tuple[bool, str]:
    schema = function_schema_strict if strict else function_schema
    validator = Draft7Validator(schema)
    errors = sorted(validator.iter_errors(func_def), key=lambda error: list(error.path))
    if not errors:
        return True, ""

    messages = []
    for error in errors:
        path = "/".join(str(item) for item in error.path)
        messages.append(f"路径 {path or '<root>'}: {error.message}")
    return False, "\n".join(messages)


def _validate_argument_type(expected_type: str, value: Any) -> bool:
    if expected_type in {"string", "str"}:
        return isinstance(value, str) or value is None
    if expected_type in {"integer", "int"}:
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type in {"array", "list"}:
        return isinstance(value, list)
    if expected_type in {"object", "dict"}:
        return isinstance(value, dict)
    return True


def validate_openai_messages_record(
    record: dict[str, Any],
    *,
    strict_tool_schema: bool = False,
) -> ValidationResult:
    result = ValidationResult()
    messages = record.get("messages")
    if not isinstance(messages, list) or not messages:
        result.add_issue("messages 必须是非空列表")
        return result

    tools = record.get("tools", []) or []
    if not isinstance(tools, list):
        result.add_issue("tools 必须是列表")
        return result

    tool_schemas: dict[str, dict[str, Any]] = {}
    for index, tool in enumerate(tools):
        if not isinstance(tool, dict):
            result.add_issue(f"tools[{index}] 必须是对象")
            continue
        valid, error_message = validate_function_definition(tool, strict=strict_tool_schema)
        if not valid:
            result.add_issue(f"tools[{index}] 不合法: {error_message}")
            continue
        tool_name = tool["function"]["name"]
        if tool_name in tool_schemas:
            result.add_issue(f"工具名重复: {tool_name}")
            continue
        tool_schemas[tool_name] = tool["function"]["parameters"]

    allowed_roles = {"system", "user", "assistant", "tool"}
    for index, message in enumerate(messages):
        if not isinstance(message, dict):
            result.add_issue(f"messages[{index}] 必须是对象")
            continue

        role = message.get("role")
        if role not in allowed_roles:
            result.add_issue(f"messages[{index}] role 不支持: {role}")
            continue

        content = message.get("content")
        if role != "assistant" and content is None:
            result.add_issue(f"messages[{index}] 的 content 不能为空")

        if role == "system":
            system_content = content or ""
            if "<tool_call>" in system_content or "</tool_call>" in system_content:
                result.add_issue("system 消息的 content 中不能包含 <tool_call> 标签")

        if role == "assistant":
            reasoning_content = resolve_reasoning_content(message) or ""
            text_content = content or ""
            tool_calls = message.get("tool_calls")
            if not text_content and not tool_calls:
                result.add_issue(f"messages[{index}] assistant 的 content 和 tool_calls 不能同时为空")
            if "<think>" in reasoning_content or "</think>" in reasoning_content:
                result.add_issue(f"messages[{index}] reasoning_content 不能包含 <think> 标签")
            if "<tool_call>" in reasoning_content or "</tool_call>" in reasoning_content:
                result.add_issue(f"messages[{index}] reasoning_content 不能包含 <tool_call> 标签")
            if "<think>" in text_content or "</think>" in text_content:
                result.add_issue(f"messages[{index}] content 不能包含 <think> 标签")
            if "<tool_call>" in text_content or "</tool_call>" in text_content:
                result.add_issue(f"messages[{index}] content 不能包含 <tool_call> 标签")

            if tool_calls is not None:
                if not isinstance(tool_calls, list):
                    result.add_issue(f"messages[{index}] tool_calls 必须是列表")
                else:
                    for call_index, tool_call in enumerate(tool_calls):
                        function = tool_call.get("function", {})
                        tool_name = function.get("name")
                        if tool_name not in tool_schemas:
                            result.add_issue(
                                f"messages[{index}].tool_calls[{call_index}] 引用了未定义工具: {tool_name}"
                            )
                            continue

                        arguments = function.get("arguments")
                        if arguments is None:
                            result.add_issue(
                                f"messages[{index}].tool_calls[{call_index}] 的 arguments 不能为空"
                            )
                            continue

                        try:
                            argument_dict = ensure_json_object(arguments)
                        except Exception as exc:
                            result.add_issue(
                                f"messages[{index}].tool_calls[{call_index}] 的 arguments 非法: {exc}"
                            )
                            continue

                        schema = tool_schemas[tool_name]
                        required = list(schema.get("required", []))
                        properties = schema.get("properties", {})
                        for key, value in argument_dict.items():
                            if key not in properties:
                                result.add_issue(
                                    f"messages[{index}].tool_calls[{call_index}] 存在未定义参数: {key}"
                                )
                                continue
                            if key in required:
                                required.remove(key)
                            expected_type = properties[key].get("type")
                            if expected_type and not _validate_argument_type(expected_type, value):
                                result.add_issue(
                                    f"messages[{index}].tool_calls[{call_index}] 参数 {key} 类型错误，期望 {expected_type}"
                                )

                        if required:
                            result.add_issue(
                                f"messages[{index}].tool_calls[{call_index}] 缺少必填参数: {required}"
                            )

    if messages[-1].get("role") != "assistant":
        result.add_issue("最后一条消息必须是 assistant")

    return result


def validate_openai_messages_file(
    input_file: str | Path,
    *,
    max_errors: float = inf,
    strict_tool_schema: bool = False,
) -> ValidationResult:
    result = ValidationResult(source=str(input_file))
    for line_number, raw_line in iter_jsonl(input_file):
        try:
            record = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            result.add_issue(f"JSON 解析失败: {exc}", line=line_number)
            if result.error_count >= max_errors:
                break
            continue

        line_result = validate_openai_messages_record(
            record,
            strict_tool_schema=strict_tool_schema,
        )
        for issue in line_result.issues:
            result.add_issue(issue.message, line=line_number, payload=record)
            if result.error_count >= max_errors:
                return result

    return result


def validate_meta_file(
    data_list_path: str | Path,
    *,
    max_errors_per_file: float = inf,
    strict_tool_schema: bool = False,
    max_workers: int | None = None,
) -> dict[str, ValidationResult]:
    with Path(data_list_path).open("r", encoding="utf-8") as file:
        datasets = json.load(file)

    entries = [
        (dataset_name, dataset_config)
        for dataset_name, dataset_config in datasets.items()
        if dataset_config.get("annotation")
    ]
    results: dict[str, ValidationResult] = {}

    if max_workers == 1 or len(entries) <= 1:
        for dataset_name, dataset_config in entries:
            results[dataset_name] = validate_openai_messages_file(
                dataset_config["annotation"],
                max_errors=max_errors_per_file,
                strict_tool_schema=strict_tool_schema,
            )
        return results

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(
                validate_openai_messages_file,
                dataset_config["annotation"],
                max_errors=max_errors_per_file,
                strict_tool_schema=strict_tool_schema,
            ): dataset_name
            for dataset_name, dataset_config in entries
        }
        for future in as_completed(future_map):
            dataset_name = future_map[future]
            results[dataset_name] = future.result()
    return results


def write_validation_logs(
    results: dict[str, ValidationResult],
    log_dir: str | Path,
) -> None:
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    for dataset_name, result in results.items():
        if result.is_valid:
            continue
        output = log_path / f"{dataset_name}.log"
        with output.open("w", encoding="utf-8") as file:
            source = result.source or ""
            file.write(f"=== 检查数据集: {dataset_name} ({source}) ===\n")
            for index, issue in enumerate(result.issues, start=0):
                line_text = issue.line if issue.line is not None else "-"
                file.write(
                    f"[错误 {index}] 文件: {source}, 行: {line_text}, 内容: {issue.message}\n"
                )

            file.write(
                f"=== {dataset_name} 检查完成，共发现 {result.error_count} 个错误 ===\n"
            )
