from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ValidationIssue:
	message: str
	line: int | None = None
	dataset: str | None = None
	payload: Any | None = None


@dataclass
class ValidationResult:
	source: str | None = None
	issues: list[ValidationIssue] = field(default_factory=list)

	@property
	def is_valid(self) -> bool:
		return not self.issues

	@property
	def error_count(self) -> int:
		return len(self.issues)

	def add_issue(
		self,
		message: str,
		*,
		line: int | None = None,
		dataset: str | None = None,
		payload: Any | None = None,
	) -> None:
		self.issues.append(
			ValidationIssue(
				message=message,
				line=line,
				dataset=dataset,
				payload=payload,
			)
		)

	def extend(self, other: "ValidationResult") -> None:
		self.issues.extend(other.issues)


@dataclass
class ConversionStats:
	input_path: str
	output_path: str
	total_records: int = 0
	written_records: int = 0
	skipped_records: int = 0
	error_count: int = 0

@dataclass
class TemplateSpec:
	name: str
	content: str
	weight: float = 1.0
	source: str | None = None

