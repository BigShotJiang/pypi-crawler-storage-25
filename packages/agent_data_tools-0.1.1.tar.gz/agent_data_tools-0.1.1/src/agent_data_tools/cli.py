from __future__ import annotations

import argparse
import json

from .converters import batch_convert_from_meta
from .template_loader import list_builtin_template_names
from .validators import validate_meta_file, write_validation_logs


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Agent 数据处理工具")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate-openai", help="校验 openai messages 格式")
    validate_parser.add_argument("--data-list", required=True, help="meta.json 或数据列表文件")
    validate_parser.add_argument("--log-dir", default="logs", help="错误日志输出目录")
    validate_parser.add_argument("--max-errors-per-file", type=int, default=100)
    validate_parser.add_argument("--strict-tool-schema", action="store_true")

    for name, target in (("convert-conversations", "conversations"), ("convert-swift-messages", "swift_messages")):
        convert_parser = subparsers.add_parser(name, help=f"转换为 {target}")
        convert_parser.add_argument("--data-list", required=True, help="meta.json 或数据列表文件")
        convert_parser.add_argument("--output-dir", required=True, help="输出目录")
        convert_parser.add_argument("--max-workers", type=int, default=1)
        convert_parser.add_argument("--max-errors", type=int, default=30)
        convert_parser.add_argument("--shuffle-tools", action="store_true")
        convert_parser.add_argument("--template-dir", help="自定义模板目录，自动加载目录下所有 .jinja 文件")
        convert_parser.add_argument("--template-config", help="模板配置 JSON 文件，支持 path/content/weight")
        convert_parser.add_argument("--template-path", action="append", default=[], help="附加单个模板文件路径，可重复传入")
        convert_parser.add_argument("--no-builtin-templates", action="store_true", help="只使用用户提供模板，不加载内置模板")

    list_parser = subparsers.add_parser("list-templates", help="列出内置模板")
    list_parser.add_argument("--json", action="store_true", help="以 JSON 输出")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "validate-openai":
        results = validate_meta_file(
            args.data_list,
            max_errors_per_file=args.max_errors_per_file,
            strict_tool_schema=args.strict_tool_schema,
        )
        write_validation_logs(results, args.log_dir)
        summary = {
            dataset_name: {
                "valid": result.is_valid,
                "error_count": result.error_count,
            }
            for dataset_name, result in results.items()
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    if args.command == "list-templates":
        templates = list_builtin_template_names()
        if args.json:
            print(json.dumps(templates, ensure_ascii=False, indent=2))
        else:
            for template_name in templates:
                print(template_name)
        return

    target = "conversations" if args.command == "convert-conversations" else "swift_messages"
    meta_output = batch_convert_from_meta(
        args.data_list,
        args.output_dir,
        target=target,
        template_specs=args.template_path or None,
        template_dir=args.template_dir,
        template_config_path=args.template_config,
        use_builtin_templates=not args.no_builtin_templates,
        shuffle_tools=args.shuffle_tools,
        max_errors=args.max_errors,
        max_workers=args.max_workers,
    )
    print(meta_output)


if __name__ == "__main__":
    main()
