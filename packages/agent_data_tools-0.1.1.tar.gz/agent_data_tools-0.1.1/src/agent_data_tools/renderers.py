from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .utils import ensure_text, format_xml_value


@dataclass
class RenderConfig:
    add_tool_instructions: bool = True
    think_tag_name: str = "think"
    tool_call_tag_name: str = "tool_call"
    tool_response_tag_name: str = "tool_response"
    include_empty_think_block: bool = True
    separator: str = "\n\n"
    mark_intermediate_assistant_as_input: bool = True


def build_tool_prompt(tools: list[dict[str, Any]], config: RenderConfig) -> str:
    lines = [
        "# Tools",
        "",
        "You have access to the following functions:",
        "",
        "<tools>",
    ]
    for tool in tools:
        function = tool.get("function", {})
        parameters = function.get("parameters", {}).get("properties", {})
        lines.extend(
            [
                "<function>",
                f"<name>{function.get('name', '')}</name>",
                f"<description>{function.get('description', '')}</description>",
                "<parameters>",
            ]
        )
        for param_name, param_schema in parameters.items():
            lines.extend(
                [
                    "<parameter>",
                    f"<name>{param_name}</name>",
                    f"<type>{param_schema.get('type', 'string')}</type>",
                    f"<description>{param_schema.get('description', '')}</description>",
                    "</parameter>",
                ]
            )
        lines.extend(["</parameters>", "</function>"])

    lines.extend(
        [
            "</tools>",
            "",
            "If you choose to call a function ONLY reply in the following format with NO suffix:",
            "",
            f"<{config.tool_call_tag_name}>",
            "<function=example_function_name>",
            "<parameter=example_parameter_1>",
            "value_1",
            "</parameter>",
            "</function>",
            f"</{config.tool_call_tag_name}>",
        ]
    )
    return "\n".join(lines)


def build_tool_call_xml(tool_call: dict[str, Any], config: RenderConfig) -> str:
    function = tool_call.get("function", {})
    arguments = function.get("arguments", {})
    lines = [
        f"<{config.tool_call_tag_name}>",
        f"<function={function.get('name', '')}>",
    ]
    for key, value in arguments.items():
        lines.extend(
            [
                f"<parameter={key}>",
                format_xml_value(value),
                "</parameter>",
            ]
        )
    lines.extend(["</function>", f"</{config.tool_call_tag_name}>"])
    return "\n".join(lines)


def build_tool_response_text(content: Any, config: RenderConfig) -> str:
    return "\n".join(
        [
            f"<{config.tool_response_tag_name}>",
            ensure_text(content),
            f"</{config.tool_response_tag_name}>",
        ]
    )


def build_assistant_text(message: dict[str, Any], enable_thinking: bool, config: RenderConfig) -> str:
    blocks: list[str] = []
    reasoning_content = ensure_text(message.get("reasoning_content"))
    if enable_thinking:
        if reasoning_content or config.include_empty_think_block:
            blocks.append(
                "\n".join(
                    [
                        f"<{config.think_tag_name}>",
                        reasoning_content,
                        f"</{config.think_tag_name}>",
                    ]
                )
            )

    for tool_call in message.get("tool_calls", []) or []:
        blocks.append(build_tool_call_xml(tool_call, config))

    content = ensure_text(message.get("content"))
    if content:
        blocks.append(content)

    return config.separator.join(block for block in blocks if block)
