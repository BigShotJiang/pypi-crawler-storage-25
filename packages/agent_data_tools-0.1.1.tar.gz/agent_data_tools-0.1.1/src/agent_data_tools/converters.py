from __future__ import annotations

import json
import random
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Literal, Sequence

try:
    from tqdm import tqdm
except ImportError:  # pragma: no cover
    def tqdm(iterable=None, *args, **kwargs):
        return iterable

from .models import ConversionStats, TemplateSpec
from .template_loader import (
    choose_template,
    create_template_environment,
    render_with_template,
    resolve_template_specs,
)
from .utils import deep_copy_json, ensure_json_object, iter_jsonl, resolve_media_paths, resolve_reasoning_content

TargetFormat = Literal["conversations", "swift_messages"]
_CHAT_PATTERN = re.compile(
    r"<\|im_start\|>(?P<role>system|user|assistant)\n(?P<content>.*?)<\|im_end\|>",
    re.DOTALL,
)


def normalize_openai_record(
    record: dict[str, Any],
    *,
    shuffle_tools: bool = False,
    rng: random.Random | None = None,
) -> dict[str, Any]:
    normalized = deep_copy_json(record)
    local_rng = rng or random.Random()
    uses_reasoning = False

    tools = normalized.get("tools", []) or []
    if shuffle_tools and tools:
        for tool in tools:
            properties = tool.get("function", {}).get("parameters", {}).get("properties")
            if isinstance(properties, dict):
                items = list(properties.items())
                local_rng.shuffle(items)
                tool["function"]["parameters"]["properties"] = dict(items)
        local_rng.shuffle(tools)
        normalized["tools"] = tools

    for message in normalized.get("messages", []):
        if message.get("role") == "assistant":
            resolved_reasoning_content = resolve_reasoning_content(message)
            if resolved_reasoning_content is None:
                message.pop("reasoning_content", None)
            else:
                message["reasoning_content"] = resolved_reasoning_content
                uses_reasoning = True

        if "content" not in message or message.get("content") is None:
            message["content"] = ""

        tool_calls = message.get("tool_calls")
        if tool_calls is None:
            message.pop("tool_calls", None)
            continue
        if tool_calls == []:
            message.pop("tool_calls", None)
            continue
        if isinstance(tool_calls, list):
            for tool_call in tool_calls:
                function = tool_call.get("function", {})
                if "arguments" in function:
                    function["arguments"] = ensure_json_object(function["arguments"])

    if normalized.get("tools") == []:
        normalized["tools"] = None
    normalized["enable_thinking"] = bool(normalized.get("enable_thinking", False) or uses_reasoning)
    return normalized


def parse_rendered_messages(input_string: str) -> dict[str, Any]:
    messages: list[dict[str, str]] = []
    for match in _CHAT_PATTERN.finditer(input_string):
        messages.append(
            {
                "role": match.group("role"),
                "content": match.group("content").lstrip(),
            }
        )
    if not messages:
        return {}
    return {"messages": messages}


def organize_conversations(messages: list[dict[str, str]], enable_thinking: bool) -> dict[str, Any]:
    conversations: list[dict[str, Any]] = []
    for message in messages:
        role = message["role"]
        content = message["content"].lstrip()
        if role == "system":
            conversations.append({"from": "system", "value": content})
        elif role == "user":
            conversations.append({"from": "human", "value": content})
        elif role == "assistant":
            if enable_thinking:
                conversations.append(
                    {
                        "from": "gpt",
                        "value": content,
                        "is_input": False,
                        "has_think": "<think>" in content,
                    }
                )
            else:
                conversations.append({"from": "gpt", "value": content})

    if enable_thinking:
        assistant_indices = [index for index, item in enumerate(conversations) if item.get("from") == "gpt"]
        has_think_list = [conversations[index]["has_think"] for index in assistant_indices]
        if has_think_list.count(True) == 1 and has_think_list[-1] is True:
            for index in assistant_indices:
                conversations[index]["is_input"] = True
            conversations[assistant_indices[-1]]["is_input"] = False
        for index in assistant_indices:
            conversations[index].pop("has_think", None)

    if not conversations:
        return {}
    return {"conversations": conversations}


def parse_and_organize_conversations(input_string: str, enable_thinking: bool) -> dict[str, Any]:
    parsed = parse_rendered_messages(input_string)
    if parsed == {}:
        return {}
    return organize_conversations(parsed["messages"], enable_thinking)


def _process_thinking_data(messages: list[dict[str, str]], annotation: str, line_idx: int | None = None) -> None:
    if len(messages) < 2:
        raise ValueError(f"messages 长度不足: {annotation}")

    error_prefix = f"{line_idx}: {annotation}" if line_idx is not None else annotation
    if messages[0]["role"] == "system":
        if len(messages) < 3:
            raise ValueError(f"thinking 数据消息数不足: {error_prefix}")
        target_text = (
            "Reason step by step and place the thought process within the <think></think> tags, "
            "and provide the final conclusion at the end."
        )
        system_content = messages[0]["content"]
        if target_text in system_content:
            index = system_content.find(target_text)
            before_text = system_content[:index]
            after_index = index + len(target_text)
            while after_index < len(system_content) and system_content[after_index] == "\n":
                after_index += 1
            messages[0]["content"] = (before_text + system_content[after_index:]).strip()
            for message in messages:
                if message["role"] == "assistant":
                    if "<think>" not in message["content"] or "</think>" not in message["content"]:
                        raise ValueError(f"assistant 缺少 think 标签: {error_prefix}")
        else:
            for message in messages:
                if message["role"] == "assistant" and "<think>" not in message["content"]:
                    message["content"] = "<think>\n\n</think>\n\n" + message["content"]
    else:
        for message in messages:
            if message["role"] == "assistant" and "<think>" not in message["content"]:
                message["content"] = "<think>\n\n</think>\n\n" + message["content"]


def _resolve_rng(random_seed: int | None = None) -> random.Random:
    return random.Random(random_seed)


def render_record_with_template(
    record: dict[str, Any],
    *,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
) -> tuple[str, TemplateSpec, dict[str, Any]]:
    rng = _resolve_rng(random_seed)
    normalized = normalize_openai_record(record, shuffle_tools=shuffle_tools, rng=rng)
    resolved_specs = resolve_template_specs(
        template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
    )
    selected_template = choose_template(resolved_specs, rng)
    rendered = render_with_template(selected_template, normalized, env=create_template_environment())
    return rendered, selected_template, normalized


def _prepare_rendered_messages(
    record: dict[str, Any],
    *,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
) -> tuple[list[dict[str, str]], TemplateSpec, dict[str, Any]]:
    rendered, selected_template, normalized = render_record_with_template(
        record,
        template_specs=template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
        shuffle_tools=shuffle_tools,
        random_seed=random_seed,
    )
    parsed = parse_rendered_messages(rendered)
    if parsed == {}:
        return [], selected_template, normalized
    messages = parsed["messages"]
    _process_thinking_data(messages, selected_template.name)
    return messages, selected_template, normalized


def render_training_messages(
    record: dict[str, Any],
    *,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
) -> list[dict[str, str]]:
    messages, _selected_template, _normalized = _prepare_rendered_messages(
        record,
        template_specs=template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
        shuffle_tools=shuffle_tools,
        random_seed=random_seed,
    )
    return messages


def convert_record_to_conversations(
    record: dict[str, Any],
    *,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
) -> dict[str, Any]:
    messages, _selected_template, normalized = _prepare_rendered_messages(
        record,
        template_specs=template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
        shuffle_tools=shuffle_tools,
        random_seed=random_seed,
    )
    return organize_conversations(messages, bool(normalized.get("enable_thinking", False)))


def convert_record_to_swift_messages(
    record: dict[str, Any],
    *,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
    media_root: str | None = None,
) -> dict[str, Any]:
    messages, _selected_template, normalized = _prepare_rendered_messages(
        record,
        template_specs=template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
        shuffle_tools=shuffle_tools,
        random_seed=random_seed,
    )
    if not messages:
        return {}
    output: dict[str, Any] = {"messages": messages}
    if media_root is not None:
        if "image" in normalized:
            output["images"] = resolve_media_paths(media_root, normalized["image"])
        if "audio" in normalized:
            output["audios"] = resolve_media_paths(media_root, normalized["audio"])
        if "video" in normalized:
            output["videos"] = resolve_media_paths(media_root, normalized["video"])
    return output


def convert_record(
    record: dict[str, Any],
    *,
    target: TargetFormat,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
    media_root: str | None = None,
) -> dict[str, Any]:
    if target == "conversations":
        return convert_record_to_conversations(
            record,
            template_specs=template_specs,
            template_dir=template_dir,
            template_config_path=template_config_path,
            use_builtin_templates=use_builtin_templates,
            shuffle_tools=shuffle_tools,
            random_seed=random_seed,
        )
    if target == "swift_messages":
        return convert_record_to_swift_messages(
            record,
            template_specs=template_specs,
            template_dir=template_dir,
            template_config_path=template_config_path,
            use_builtin_templates=use_builtin_templates,
            shuffle_tools=shuffle_tools,
            random_seed=random_seed,
            media_root=media_root,
        )
    raise ValueError(f"不支持的 target: {target}")


def convert_jsonl_file(
    input_file: str | Path,
    output_file: str | Path,
    *,
    target: TargetFormat,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
    media_root: str | None = None,
    skip_image_records_without_root: bool = True,
    max_errors: int = 30,
    show_progress: bool = True,
) -> ConversionStats:
    stats = ConversionStats(input_path=str(input_file), output_path=str(output_file))
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    errors = 0
    with output_path.open("w", encoding="utf-8") as output_handle:
        iterator = iter_jsonl(input_file)
        if show_progress:
            iterator = tqdm(iterator, desc=f"convert {Path(input_file).name}", unit="it")
        for line_number, raw_line in iterator:
            stats.total_records += 1
            try:
                record = json.loads(raw_line)
                if skip_image_records_without_root and media_root is None and "image" in record:
                    stats.skipped_records += 1
                    continue
                converted = convert_record(
                    record,
                    target=target,
                    template_specs=template_specs,
                    template_dir=template_dir,
                    template_config_path=template_config_path,
                    use_builtin_templates=use_builtin_templates,
                    shuffle_tools=shuffle_tools,
                    random_seed=None if random_seed is None else random_seed + line_number,
                    media_root=media_root,
                )
                if converted == {}:
                    stats.skipped_records += 1
                    continue
                output_handle.write(json.dumps(converted, ensure_ascii=False))
                output_handle.write("\n")
                stats.written_records += 1
            except Exception:
                errors += 1
                stats.error_count += 1
                if errors > max_errors:
                    raise RuntimeError(f"文件 {input_file} 出错超过 {max_errors} 行，停止处理")
    return stats


def _convert_dataset_entry(
    dataset_name: str,
    dataset_config: dict[str, Any],
    *,
    target: TargetFormat,
    output_dir: str,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None,
    template_dir: str | Path | None,
    template_config_path: str | Path | None,
    use_builtin_templates: bool | None,
    shuffle_tools: bool,
    random_seed: int | None,
    max_errors: int,
    show_progress: bool,
) -> tuple[str, str, int]:
    annotation = dataset_config["annotation"]
    root = dataset_config.get("root")
    output_path = str(Path(output_dir) / Path(annotation).name)
    stats = convert_jsonl_file(
        annotation,
        output_path,
        target=target,
        template_specs=template_specs,
        template_dir=template_dir,
        template_config_path=template_config_path,
        use_builtin_templates=use_builtin_templates,
        shuffle_tools=shuffle_tools,
        random_seed=random_seed,
        media_root=root,
        skip_image_records_without_root=True,
        max_errors=max_errors,
        show_progress=show_progress,
    )
    return dataset_name, output_path, stats.written_records


def batch_convert_from_meta(
    meta_file: str | Path,
    output_dir: str | Path,
    *,
    target: TargetFormat,
    template_specs: Sequence[TemplateSpec | str | Path | dict[str, Any]] | None = None,
    template_dir: str | Path | None = None,
    template_config_path: str | Path | None = None,
    use_builtin_templates: bool | None = None,
    shuffle_tools: bool = False,
    random_seed: int | None = None,
    max_errors: int = 30,
    max_workers: int = 1,
    show_progress: bool = True,
) -> str:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    with Path(meta_file).open("r", encoding="utf-8") as file:
        datasets = json.load(file)

    results: dict[str, tuple[str, int]] = {}
    entries = [
        (name, config_item)
        for name, config_item in datasets.items()
        if config_item.get("annotation") and Path(config_item["annotation"]).exists()
    ]

    if max_workers <= 1:
        entry_iterable = entries
        if show_progress:
            entry_iterable = tqdm(entries, total=len(entries), desc=f"datasets->{target}", unit="dataset")
        for name, dataset_config in entry_iterable:
            dataset_name, converted_path, written_records = _convert_dataset_entry(
                name,
                dataset_config,
                target=target,
                output_dir=str(output_path),
                template_specs=template_specs,
                template_dir=template_dir,
                template_config_path=template_config_path,
                use_builtin_templates=use_builtin_templates,
                shuffle_tools=shuffle_tools,
                random_seed=random_seed,
                max_errors=max_errors,
                show_progress=show_progress,
            )
            results[dataset_name] = (converted_path, written_records)
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_map = {
                executor.submit(
                    _convert_dataset_entry,
                    name,
                    dataset_config,
                    target=target,
                    output_dir=str(output_path),
                    template_specs=template_specs,
                    template_dir=template_dir,
                    template_config_path=template_config_path,
                    use_builtin_templates=use_builtin_templates,
                    shuffle_tools=shuffle_tools,
                    random_seed=random_seed,
                    max_errors=max_errors,
                    show_progress=show_progress,
                ): name
                for name, dataset_config in entries
            }
            future_iterable = as_completed(future_map)
            if show_progress:
                future_iterable = tqdm(future_iterable, total=len(future_map), desc=f"datasets->{target}", unit="dataset")
            for future in future_iterable:
                dataset_name, converted_path, written_records = future.result()
                results[dataset_name] = (converted_path, written_records)

    for dataset_name, dataset_config in datasets.items():
        if dataset_name in results:
            dataset_config["annotation"] = results[dataset_name][0]
            dataset_config["length"] = results[dataset_name][1]

    meta_output = output_path / "meta.json"
    with meta_output.open("w", encoding="utf-8") as file:
        json.dump(datasets, file, indent=2, ensure_ascii=False)
    return str(meta_output)
