import json
import unittest
from pathlib import Path

from agent_data_tools import (
    convert_record_to_conversations,
    convert_record_to_swift_messages,
    list_builtin_template_names,
    resolve_template_specs,
    validate_openai_messages_record,
)


ROOT = Path(__file__).resolve().parent.parent
EXAMPLE_FILE = ROOT / "data_examples" / "data_01_openai_format.jsonl"


class ApiTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with EXAMPLE_FILE.open("r", encoding="utf-8") as file:
            cls.sample = json.loads(file.readline())

    def test_validate_example_record(self):
        result = validate_openai_messages_record(self.sample)
        self.assertTrue(result.is_valid)

    def test_convert_to_conversations(self):
        converted = convert_record_to_conversations(self.sample)
        self.assertIn("conversations", converted)
        self.assertGreater(len(converted["conversations"]), 0)

    def test_convert_to_swift_messages(self):
        converted = convert_record_to_swift_messages(self.sample)
        self.assertIn("messages", converted)
        self.assertGreater(len(converted["messages"]), 0)

    def test_builtin_templates_available(self):
        template_names = list_builtin_template_names()
        self.assertIn("qwen3.5_35ba3b_think_xml.jinja", template_names)

    def test_custom_template_content_supported(self):
        template_specs = resolve_template_specs(
            [
                {
                    "name": "custom.jinja",
                    "content": "<|im_start|>system\ncustom system<|im_end|>\n<|im_start|>user\n{{ messages[1].content }}<|im_end|>\n<|im_start|>assistant\n{{ messages[2].content }}<|im_end|>\n",
                    "weight": 1,
                }
            ],
            use_builtin_templates=False,
        )
        converted = convert_record_to_swift_messages(
            self.sample,
            template_specs=template_specs,
            use_builtin_templates=False,
        )
        self.assertEqual(converted["messages"][0]["content"], "custom system")


if __name__ == "__main__":
    unittest.main()