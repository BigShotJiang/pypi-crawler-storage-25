
import math
from dataclasses import dataclass

@dataclass(frozen=True)
class Star:
	number: int = None
	name: str = None
	constellation: str = None
	ra: float = math.nan
	dec: float = math.nan
	mag: float = math.nan

	def __str__(self):
		""" __str__() """
		if isinstance(self.number, int):
			num = str(self.number)
		else:
			if self.number:
				num = '-'.join([str(v) for v in self.number])
			else:
				num = ''

		if self.name and self.constellation and self.constellation != '':
			name = self.name + ' in ' + self.constellation
		else:
			name = self.name

		if self.ra and not math.isnan(self.ra) or self.dec and not math.isnan(self.dec):
			pos = '[%9.5f,%9.5f]' % (round(math.degrees(self.ra), 5), round(math.degrees(self.dec), 5))
		else:
			pos = '[%9s,%9s]' % ('', '')

		if self.mag and not math.isnan(self.mag):
			mag = '%6.3f' % (self.mag)
		else:
			mag = ''

		if name is None or len(name) == 0:
			r = '%s @ %6s ; %6s' % (pos, mag, num)
		elif name[0] == '"' and name[-1] == '"':
			r = '%s @ %6s ; %6s %s' % (pos, mag, num, name)
		else:
			r = '%s @ %6s ; %6s %s' % (pos, mag, num, '"' + name + '"')

		return r
