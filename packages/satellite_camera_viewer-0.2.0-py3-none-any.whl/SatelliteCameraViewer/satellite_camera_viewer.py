""" satellitecameraviewer """

import sys

from .viewer import viewer

def satellite_camera_viewer(args=None):
	""" satellite_camera_viewer """

	viewer(args)
	sys.exit(0)

def main(args=None):
	""" main """
	satellite_camera_viewer(args)

if __name__ == '__main__':
	main()
