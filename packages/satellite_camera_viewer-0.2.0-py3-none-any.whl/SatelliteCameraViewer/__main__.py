""" satellitecameraviewer """

import sys

from .viewer import viewer

def main(args=None):
	""" main """
	viewer(args)
	sys.exit(0)

if __name__ == '__main__':
	main()
