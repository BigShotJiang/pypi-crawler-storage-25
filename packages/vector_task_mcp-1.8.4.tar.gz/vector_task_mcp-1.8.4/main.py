#!/usr/bin/env -S uv run --script
# -*- coding: utf-8 -*-
# /// script
# dependencies = [
#     "mcp>=0.3.0",
#     "sqlite-vec>=0.1.6",
#     "sentence-transformers>=2.2.2"
# ]
# requires-python = ">=3.8"
# ///

"""
Vector Task MCP Server - Main Entry Point
==========================================

A secure, vector-based task management server using sqlite-vec for semantic search.
Stores and retrieves tasks with vector embeddings for intelligent task retrieval.

Usage:
    python main.py --working-dir /path/to/project

Task database stored in: {working_dir}/memory/tasks.db
"""

import sys
from pathlib import Path
from typing import Any, List
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from mcp.server.fastmcp import FastMCP

# Import our modules
from src.models import Config
from src.security import (
    validate_working_dir,
    validate_task_folder,
    validate_code,
    SecurityError,
    validate_task_list_params,
    validate_tags,
    validate_task_stats_params,
)
from src.task_store import TaskStore
from src.normalization import TagNormalizer


def get_working_dir() -> Path:
    """Get working directory from command line arguments"""
    if "--working-dir" in sys.argv:
        idx = sys.argv.index("--working-dir")
        if idx + 1 < len(sys.argv):
            return validate_working_dir(sys.argv[idx + 1])
    # Default to current directory
    return validate_working_dir(".")


def get_timezone() -> str | None:
    """Get timezone from command line arguments.

    Returns:
        Timezone string (e.g., 'Europe/Kyiv') or None for UTC default.

    Raises:
        SystemExit: If invalid timezone name provided.
    """
    if "--timezone" in sys.argv:
        idx = sys.argv.index("--timezone")
        if idx + 1 < len(sys.argv):
            tz_str = sys.argv[idx + 1]
            try:
                ZoneInfo(tz_str)  # Validate timezone exists
                return tz_str
            except ZoneInfoNotFoundError:
                print(f"Error: Invalid timezone '{tz_str}'. Use IANA timezone names (e.g., 'Europe/Kyiv', 'America/New_York').", file=sys.stderr)
                sys.exit(1)
    return None


def _read_task_folder_from_env(working_dir: Path) -> "str | None":
    """Look up ``TASK_FOLDER`` in ``.brain/.env`` and ``.xbrain/.env``.

    Returns the first non-empty value found (in that order). Empty values,
    missing files, or unreadable files are skipped silently.

    Recognised line formats:
        TASK_FOLDER=value
        TASK_FOLDER='value'
        TASK_FOLDER="value"
        # ... (comments are ignored)
    """
    candidates = (
        working_dir / ".brain" / ".env",
        working_dir / ".xbrain" / ".env",
    )
    for env_file in candidates:
        if not env_file.is_file():
            continue
        try:
            for raw_line in env_file.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                if not line.startswith("TASK_FOLDER="):
                    continue
                value = line.split("=", 1)[1].strip()
                # Strip a single matched pair of surrounding quotes.
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                    value = value[1:-1]
                if value:
                    return value
                # Found but empty → not configured in this file; keep looking.
                break
        except Exception:
            continue
    return None


def get_task_folder() -> "Path | None":
    """Resolve task folder from CLI flag, then ``.env`` fallback.

    Priority order:
    1. ``--task-folder <value>`` CLI flag, only when ``<value>`` is non-empty
       after stripping. An empty value (``--task-folder ""`` or trailing
       whitespace) is NOT considered "enabled" and falls through.
    2. ``TASK_FOLDER`` in ``{working_dir}/.brain/.env``.
    3. ``TASK_FOLDER`` in ``{working_dir}/.xbrain/.env``.
    4. ``None`` (feature disabled).

    For values from ``.env``, relative paths are resolved against
    ``working_dir`` (CLI values keep the historical behaviour of resolving
    against the process CWD via ``Path.resolve``).
    """
    if "--task-folder" in sys.argv:
        idx = sys.argv.index("--task-folder")
        if idx + 1 < len(sys.argv):
            cli_value = sys.argv[idx + 1].strip()
            if cli_value:
                return validate_task_folder(cli_value)
        # Empty/missing value → fall through to .env lookup.

    working_dir = get_working_dir()
    env_value = _read_task_folder_from_env(working_dir)
    if env_value:
        env_path = Path(env_value)
        if not env_path.is_absolute():
            env_path = working_dir / env_path
        return validate_task_folder(str(env_path))

    return None


def _get_task_folders_summary(task_store) -> list[dict]:
    """Build per-root-task folder summary for the project://info resource.

    Returns a list of {code, title, folder_path, files_count, status_suffix}
    for every ROOT task with a code that has a corresponding folder on disk.
    Subtasks, tasks without a code, canceled tasks, and tasks whose folder
    is missing are skipped silently.

    Returns an empty list when the --task-folder feature is disabled
    (folder_mgr is None) or any unexpected error occurs (resource is
    best-effort by design).
    """
    folder_mgr = getattr(task_store, "folder_mgr", None)
    if folder_mgr is None:
        return []

    summary: list[dict] = []
    try:
        task_store._ensure_db_initialized_sync()
        conn = task_store._get_connection()
        try:
            rows = conn.execute(
                "SELECT id, code, title, status FROM tasks "
                "WHERE parent_id IS NULL AND code IS NOT NULL "
                "AND status NOT IN (?)",
                ("canceled",),
            ).fetchall()
        finally:
            conn.close()
    except Exception:
        return []

    for _id, code, title, status in rows:
        try:
            resolved = folder_mgr._resolve_existing_folder(code)
        except Exception:
            continue
        if resolved is None:
            continue

        # Status suffix derived from folder location on disk.
        # Resolution order: {code} (active), {code}-on-review (review),
        # Archive/{code} (done). The done state is distinguished by the
        # parent directory being the top-level shared "Archive/".
        if resolved.name.endswith("-on-review"):
            status_suffix = "-on-review"
        elif resolved.parent.name == "Archive" and resolved.parent.parent == folder_mgr.root:
            status_suffix = "-done"
        else:
            status_suffix = "none"

        # files_count: rglob('*') filtered to files (consistent with
        # TaskFolderManager.list_files).
        try:
            files_count = sum(1 for p in resolved.rglob("*") if p.is_file())
        except Exception:
            files_count = 0

        # folder_path: relative to working_dir when inside, else absolute.
        try:
            folder_path = str(resolved.relative_to(task_store.working_dir))
        except (ValueError, AttributeError):
            folder_path = str(resolved)

        summary.append({
            "code": code,
            "title": title,
            "folder_path": folder_path,
            "files_count": files_count,
            "status_suffix": status_suffix,
        })

    return summary


def create_server() -> FastMCP:
    """Create and configure the MCP server"""

    # Initialize task store (database and embedding model are lazy-loaded on first use)
    try:
        working_dir = get_working_dir()
        timezone = get_timezone()
        task_folder = get_task_folder()
        memory_dir = working_dir / "memory"
        memory_dir.mkdir(parents=True, exist_ok=True)
        task_db_path = memory_dir / "tasks.db"
        task_store = TaskStore(
            task_db_path,
            timezone=timezone,
            task_folder=task_folder,
            working_dir=working_dir,
        )
        print(f"Task database path: {task_db_path} (lazy initialization)", file=sys.stderr)
        if task_folder is not None:
            print(f"Task folder root: {task_folder}", file=sys.stderr)
    except Exception as e:
        print(f"Failed to initialize task store: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Create FastMCP server
    mcp = FastMCP(
        Config.SERVER_NAME,
        instructions="""
╔══════════════════════════════════════════════════════════════════════════════╗
║  CRITICAL: Call cookbook() IMMEDIATELY. Default = init (first read).        ║
║  Without it, you operate BLIND - no workflows, no patterns, no docs.        ║
╚══════════════════════════════════════════════════════════════════════════════╝

YOUR LIFELINE: cookbook() tool - ONE tool, 5 modes:
- cookbook() → init (quick start + resources overview)
- cookbook(include="docs", level=1) → usage guide
- cookbook(include="cases") → all use cases
- cookbook(include="categories") → list case categories
- cookbook(include="all", level=2) → everything

Status propagation (AUTOMATIC, never manual):
- child→pending ⟹ parent→pending (immediate)
- ALL children→finished ⟹ parent→completed (recursive)

NEVER update parent task status. System propagates automatically."""
    )
    
    # ===============================================================================
    # TASK MANAGEMENT TOOLS
    # ===============================================================================

    @mcp.tool()
    async def task_create(
        title: str,
        content: str,
        parent_id: int = None,
        comment: str = None,
        priority: str = None,
        estimate: float | None = None,
        order: int | None = None,
        tags: list[str] = None,
        parallel: bool = False,
        code: str | None = None
    ) -> dict[str, Any]:
        """
        Create new task with vector embedding for semantic search.

        Args:
            title: Task title (max 200 chars)
            content: Task description/details (max 10K chars)
            parent_id: Optional parent task ID for subtasks
            comment: Optional comment/note for the task
            priority: Optional task priority (low, medium, high, critical, default: medium)
            estimate: Optional time estimate in hours
            order: Optional task order/position (auto-assigned if not provided)
            tags: Optional list of tags for organization (max 10)
            parallel: Whether task can be executed in parallel with siblings (default: False)
            code: Optional task code. If not provided, auto-generated as {TYPE}-{N}
                based on task type tag (feature→FEAT, bugfix→FIX, refactor→REFACTOR,
                docs→DOCS, test→TEST, hotfix→HOTFIX, chore→CHORE, research→RESEARCH,
                spike→SPIKE, default→TASK). Examples: FEAT-44, FIX-12, REFACTOR-4,
                DOCS-7. Custom codes accepted (e.g. OLOM-460, JIRA-1234) — must match
                ^[A-Z]+-\\d+$. Codes are NOT required to be unique — multiple tasks
                may share a code to branch work under a single shared folder
                (the on-disk folder is keyed by code, so all tasks with the same
                code see the same folder). AI agents: provide code matching task
                semantics when clear context exists.
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            # Get embedding model asynchronously (lazy loading)
            model = await task_store.get_embedding_model_async()

            result = task_store.create_task(
                title=title,
                content=content,
                parent_id=parent_id,
                comment=comment,
                priority=priority,
                tags=tags,
                estimate=estimate,
                order=order,
                parallel=parallel,
                code=code,
                embedding_model=model
            )
            return result

        except SecurityError as e:
            return {
                "success": False,
                "error": "Security validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Task creation failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_create_bulk(tasks: list[dict]) -> dict[str, Any]:
        """
        Create multiple tasks in bulk with vector embeddings.

        Args:
            tasks: List of task objects with fields:
                - title (required): Task title (max 200 chars)
                - content (required): Task description (max 10K chars)
                - parent_id (optional): Parent task ID for subtasks
                - comment (optional): Comment/note for the task
                - priority (optional): Task priority (low, medium, high, critical)
                - estimate (optional): Time estimate in hours
                - order (optional): Task order/position (auto-assigned if not provided)
                - tags (optional): List of tags for organization (max 10)
                - parallel (optional): Whether task can be executed in parallel with siblings (default: False)
                - code (optional): Task code (PREFIX-N, e.g. FEAT-44). Auto-generated from tags if omitted.

        Example:
            tasks = [
                {"title": "Task 1", "content": "Description", "parent_id": None, "comment": "Note", "priority": "high", "estimate": 3.5, "order": 1, "tags": ["backend", "api"], "parallel": True},
                {"title": "Task 2", "content": "Description", "parent_id": 1, "comment": None, "estimate": 2.0, "order": 2, "tags": ["frontend"], "parallel": True}
            ]
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            # Get embedding model asynchronously (lazy loading)
            model = await task_store.get_embedding_model_async()

            result = task_store.create_tasks_bulk(tasks, embedding_model=model)
            return result

        except SecurityError as e:
            return {
                "success": False,
                "error": "Security validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Bulk task creation failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_update(
        task_id: int,
        title: str | None = None,
        content: str | None = None,
        status: str | None = None,
        parent_id: int | None = None,
        comment: str | None = None,
        start_at: str | None = None,
        finish_at: str | None = None,
        priority: str | None = None,
        estimate: float | None = None,
        order: int | None = None,
        tags: list[str] | None = None,
        append_comment: bool = True,
        add_tag: str | None = None,
        remove_tag: str | None = None,
        parallel: bool | None = None,
        code: str | None = None
    ) -> dict[str, Any]:
        """
        Update task fields by ID.

        Status propagation: child→pending ⟹ parent→pending; ALL children→finished ⟹ parent→completed.

        Args:
            task_id: Task ID to update
            title: Optional new title
            content: Optional new content
            status: Optional new status (draft, pending, in_progress, completed, tested, validated, done, stopped, canceled). `done` is a final status that may be jumped to from completed/tested/validated; transitions from pending/in_progress/draft/stopped/canceled directly to done are rejected.
            parent_id: Optional new parent task ID
            comment: Optional comment to add or replace
            start_at: Optional start timestamp (ISO 8601 format)
            finish_at: Optional finish timestamp (ISO 8601 format)
            priority: Optional new priority (low, medium, high, critical)
            estimate: Optional time estimate in hours
            order: Optional new order/position (triggers sibling reordering)
            tags: Optional list of tags to replace existing tags
            append_comment: Append comment to existing with \\n\\n separator (default True). Set False to replace entirely
            add_tag: Optional single tag to add (validates duplicates and 10-tag limit)
            remove_tag: Optional single tag to remove (case-insensitive, silent if not found)
            parallel: Optional flag for parallel execution with siblings
            code: Optional new task code (must match ^[A-Z]+-\\d+$, max 32 chars).
                Examples: FEAT-44, OLOM-460. Codes are NOT required to be unique —
                multiple tasks may share a code to branch work under a single shared
                folder. For ROOT tasks with --task-folder enabled, the on-disk folder
                is renamed at its current lifecycle position (active / -on-review /
                Archive/). Setting a code on a legacy NULL-code task creates a fresh
                folder (or adopts an existing folder with that code).
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            if not isinstance(task_id, int) or task_id < 1:
                return {
                    "success": False,
                    "error": "Invalid parameter",
                    "message": "task_id must be a positive integer"
                }

            # Handle comment append logic
            if comment is not None and append_comment:
                existing = task_store.get_task_by_id(task_id)
                if existing and existing.comment:
                    comment = existing.comment + "\n\n" + comment

            # Build kwargs from provided parameters
            kwargs = {}

            # Handle add_tag - append single tag with validation
            if add_tag is not None:
                try:
                    sanitized_tags = validate_tags([add_tag])
                    sanitized_tag = sanitized_tags[0]
                except SecurityError as e:
                    return {"success": False, "error": f"Invalid tag: {e}"}

                existing = task_store.get_task_by_id(task_id)
                if not existing:
                    return {"success": False, "error": f"Task {task_id} not found"}

                current_tags = existing.tags or []

                if sanitized_tag in current_tags:
                    return {"success": False, "error": f"Tag '{sanitized_tag}' already exists on task"}

                if len(current_tags) >= 10:
                    return {"success": False, "error": "Maximum 10 tags per task"}

                kwargs["tags"] = current_tags + [sanitized_tag]

            # Handle remove_tag - remove single tag with case-insensitive match
            if remove_tag is not None:
                tag_normalized = remove_tag.lower().strip()
                if tag_normalized:
                    existing = task_store.get_task_by_id(task_id)
                    if existing and existing.tags:
                        updated_tags = [t for t in existing.tags if t != tag_normalized]
                        if len(updated_tags) != len(existing.tags):
                            kwargs["tags"] = updated_tags

            if title is not None:
                kwargs['title'] = title
            if content is not None:
                kwargs['content'] = content
            if status is not None:
                kwargs['status'] = status
            if parent_id is not None:
                kwargs['parent_id'] = parent_id
            if comment is not None:
                kwargs['comment'] = comment
            if start_at is not None:
                kwargs['start_at'] = start_at
            if finish_at is not None:
                kwargs['finish_at'] = finish_at
            if priority is not None:
                kwargs['priority'] = priority
            if estimate is not None:
                kwargs['estimate'] = estimate
            if order is not None:
                kwargs['order'] = order
            if tags is not None:
                kwargs['tags'] = tags
            if parallel is not None:
                kwargs['parallel'] = parallel
            if code is not None:
                kwargs['code'] = code

            # Only load embedding model if title, content, or tags are changing
            embedding_model = None
            if title is not None or content is not None or tags is not None or add_tag is not None or remove_tag is not None:
                embedding_model = await task_store.get_embedding_model_async()

            result = task_store.update_task(task_id, embedding_model=embedding_model, **kwargs)
            return result

        except SecurityError as e:
            return {
                "success": False,
                "error": "Security validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Task update failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_delete(task_id: int) -> dict[str, Any]:
        """
        Delete task by ID (permanent, cannot be undone).

        Args:
            task_id: Task ID to delete
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            if not isinstance(task_id, int) or task_id < 1:
                return {
                    "success": False,
                    "error": "Invalid parameter",
                    "message": "task_id must be a positive integer"
                }

            deleted = task_store.delete_task(task_id)

            if not deleted:
                return {
                    "success": False,
                    "error": "Not found",
                    "message": f"Task with ID {task_id} not found"
                }

            return {
                "success": True,
                "task_id": task_id,
                "message": "Task deleted successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Deletion failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_delete_bulk(task_ids: list[int]) -> dict[str, Any]:
        """
        Delete multiple tasks by IDs (permanent, cannot be undone).

        Args:
            task_ids: List of task IDs to delete
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            result = task_store.delete_tasks_bulk(task_ids)
            return result

        except SecurityError as e:
            return {
                "success": False,
                "error": "Security validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Bulk deletion failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_list(
        query: str = None,
        limit: int = 10,
        offset: int = 0,
        status: str = None,
        parent_id: int = None,
        tags: list[str] = None,
        ids: list[int] = None,
        code: str = None
    ) -> dict[str, Any]:
        """
        List tasks with optional filters and vector semantic search.

        Args:
            query: Optional semantic search query for title/content
            limit: Max results (1-50, default 10)
            offset: Starting position for pagination (default 0)
            status: Optional status filter (draft, pending, in_progress, completed, tested, validated, done, stopped, canceled)
            parent_id: Optional parent task ID filter (for subtasks)
            tags: Optional list of tags to filter by (matches tasks containing ANY of the specified tags)
            ids: Optional list of task IDs to filter by (AND logic with other filters, max 50)
            code: Optional exact-match code filter (must match ^[A-Z]+-\\d+$).
                Returns ALL tasks carrying this exact code (codes may be shared
                across tasks since 1.8.2). Combines with other filters via AND.
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            # Validate parameters
            (limit, offset, status, parent_id, validated_tags,
             validated_ids, validated_code) = validate_task_list_params(
                limit=limit,
                offset=offset,
                status=status,
                parent_id=parent_id,
                tags=tags,
                ids=ids,
                code=code,
            )

            # Only load embedding model if query is provided (semantic search)
            embedding_model = None
            if query:
                embedding_model = await task_store.get_embedding_model_async()

            # Search tasks
            tasks, total = task_store.search_tasks(
                query=query,
                limit=limit,
                offset=offset,
                status=status,
                parent_id=parent_id,
                tags=validated_tags,
                ids=validated_ids,
                code=validated_code,
                embedding_model=embedding_model
            )

            if not tasks:
                return {
                    "success": True,
                    "tasks": [],
                    "total": total,
                    "count": 0,
                    "message": "No tasks found matching filters"
                }

            # Convert Task objects to dictionaries
            task_dicts = [task.to_dict() for task in tasks]

            return {
                "success": True,
                "query": query,
                "tasks": task_dicts,
                "total": total,
                "count": len(task_dicts),
                "message": f"Retrieved {len(task_dicts)} of {total} tasks"
            }

        except SecurityError as e:
            return {
                "success": False,
                "error": "Security validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Task list failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_next() -> dict[str, Any]:
        """
        Get next task to work on (smart selection).

        Returns in_progress task if any exists, otherwise returns
        next pending task after last finished task.

        Task status lifecycle:
        - draft: Task draft (not ready for execution)
        - pending: Task not yet started
        - in_progress: Currently being worked on
        - completed: Task finished (basic completion)
        - tested: Task completed and tested
        - validated: Task completed, tested and validated
        - stopped: Task paused/blocked
        - canceled: Task canceled (will not be done)
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            task = task_store.get_next_task()

            if task is None:
                return {
                    "success": False,
                    "error": "Not found",
                    "message": "No pending or in-progress tasks found"
                }

            return {
                "success": True,
                "task": task.to_dict(),
                "message": f"Next task: {task.status}"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to get next task",
                "message": str(e)
            }

    @mcp.tool()
    async def task_get(task_id: int) -> dict[str, Any]:
        """
        Get task by ID.

        Args:
            task_id: Task ID to retrieve
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            if not isinstance(task_id, int) or task_id < 1:
                return {
                    "success": False,
                    "error": "Invalid parameter",
                    "message": "task_id must be a positive integer"
                }

            task = task_store.get_task_by_id(task_id)

            if task is None:
                return {
                    "success": False,
                    "error": "Not found",
                    "message": f"Task with ID {task_id} not found"
                }

            # Check for subtasks
            subtask_ids = task_store.get_subtask_ids(task_id)

            response = {
                "success": True,
                "task": task.to_dict(),
                "message": "Task retrieved successfully"
            }

            # Add subtask info if task has children
            if subtask_ids:
                response["subtask_ids"] = subtask_ids
                next_child = task_store.get_next_child(task_id)
                if next_child:
                    response["next_child"] = next_child.to_dict()

            # Folder files for ANY task when --task-folder is enabled.
            # Subtasks inherit the ROOT task's folder — task hierarchy shares
            # one folder per root, never per-subtask. We walk up to root and
            # return the root's folder context (with ``root_task_id`` and
            # ``root_code`` so callers can see whose folder it is).
            # Best-effort: any failure leaves the response unchanged.
            folder_mgr = getattr(task_store, "folder_mgr", None)
            if folder_mgr is not None:
                try:
                    if task.parent_id is None:
                        root_task = task
                    else:
                        root_task = task_store.get_root_task(task.id)

                    if root_task is not None and root_task.code:
                        files = folder_mgr.list_files(root_task.code)
                        resolved = folder_mgr._resolve_existing_folder(root_task.code)
                        if resolved is not None:
                            try:
                                folder_path = str(resolved.relative_to(task_store.working_dir))
                            except (ValueError, AttributeError):
                                folder_path = str(resolved)
                            response["folder_path"] = folder_path
                            response["folder_files"] = files if files is not None else []
                            response["root_task_id"] = root_task.id
                            response["root_code"] = root_task.code
                except Exception:
                    # Resource is best-effort — never fail task_get on FS error.
                    pass

            return response

        except Exception as e:
            return {
                "success": False,
                "error": "Retrieval failed",
                "message": str(e)
            }

    @mcp.tool()
    async def task_stats(
        created_after: str = None,
        created_before: str = None,
        start_after: str = None,
        start_before: str = None,
        finish_after: str = None,
        finish_before: str = None,
        status: str = None,
        priority: str = None,
        tags: list[str] = None,
        parent_id: int = None
    ) -> dict[str, Any]:
        """
        Get task statistics (total, completed, tested, validated, pending, in_progress, stopped, next_task_id, etc.).

        Returns comprehensive task statistics including:
        - Total tasks count
        - Count by status (draft, pending, in_progress, completed, tested, validated, done, stopped, canceled)
        - Tasks with subtasks count
        - Next task ID (from smart selection logic)
        - Unique tags across all tasks

        Args:
            created_after: Filter tasks created after this date (ISO 8601 format: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)
            created_before: Filter tasks created before this date (ISO 8601 format)
            start_after: Filter tasks started after this date (ISO 8601 format)
            start_before: Filter tasks started before this date (ISO 8601 format)
            finish_after: Filter tasks finished after this date (ISO 8601 format)
            finish_before: Filter tasks finished before this date (ISO 8601 format)
            status: Filter by task status (draft, pending, in_progress, completed, tested, validated, done, stopped, canceled)
            priority: Filter by priority (low, medium, high, critical)
            tags: Filter by tags (OR logic - matches tasks with ANY specified tag)
            parent_id: Filter for subtasks of specific parent (use 0 for root tasks only)
        """
        try:
            # Ensure database is initialized (lazy loading)
            await task_store._ensure_db_initialized_async()

            # Validate filter parameters
            (
                validated_created_after, validated_created_before,
                validated_start_after, validated_start_before,
                validated_finish_after, validated_finish_before,
                validated_status, validated_priority,
                validated_tags, validated_parent_id
            ) = validate_task_stats_params(
                created_after=created_after,
                created_before=created_before,
                start_after=start_after,
                start_before=start_before,
                finish_after=finish_after,
                finish_before=finish_before,
                status=status,
                priority=priority,
                tags=tags,
                parent_id=parent_id
            )

            # Get stats from TaskStore with filters
            stats = task_store.get_stats(
                created_after=validated_created_after,
                created_before=validated_created_before,
                start_after=validated_start_after,
                start_before=validated_start_before,
                finish_after=validated_finish_after,
                finish_before=validated_finish_before,
                status=validated_status,
                priority=validated_priority,
                tags=validated_tags,
                parent_id=validated_parent_id
            )

            # Get next task ID
            next_task = task_store.get_next_task()
            next_task_id = next_task.id if next_task else None

            # Get unique tags
            unique_tags = task_store.get_all_tags()

            # Build response with stats
            result = stats.to_dict()
            result["success"] = True
            result["next_task_id"] = next_task_id
            result["unique_tags"] = unique_tags

            # Build message based on whether filters are applied
            filters_applied = any([
                validated_created_after, validated_created_before,
                validated_start_after, validated_start_before,
                validated_finish_after, validated_finish_before,
                validated_status, validated_priority,
                validated_tags, validated_parent_id is not None
            ])

            if filters_applied:
                result["message"] = f"Filtered statistics for {result['total_tasks']} tasks, {len(unique_tags)} unique tags"
            else:
                result["message"] = f"Statistics for {result['total_tasks']} tasks, {len(unique_tags)} unique tags"

            return result

        except ValueError as e:
            return {
                "success": False,
                "error": "Validation failed",
                "message": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "Failed to get statistics",
                "message": str(e)
            }

    # ===============================================================================
    # TAG FREQUENCIES / IDF WEIGHTS
    # ===============================================================================

    @mcp.tool()
    async def tag_frequencies() -> dict[str, Any]:
        """
        Get tag frequencies with IDF weights for search ranking.

        IDF (Inverse Document Frequency) weight formula:
            idf_weight = 1 / log(1 + freq)

        - Rare tags (low frequency) → higher weight → stronger signal
        - Common tags (high frequency) → lower weight → weaker signal

        Returns:
            Dict with tag frequencies, counts, and IDF weights
        """
        try:
            await task_store._ensure_db_initialized_async()

            frequencies = task_store.get_tag_frequencies()

            sorted_tags = sorted(frequencies.items(), key=lambda x: x[1]["count"], reverse=True)

            return {
                "success": True,
                "tags": dict(sorted_tags),
                "total_unique_tags": len(frequencies),
                "message": f"Retrieved {len(frequencies)} tags with frequencies and IDF weights"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to get tag frequencies",
                "message": str(e)
            }

    @mcp.tool()
    async def tag_weights() -> dict[str, Any]:
        """
        Get IDF weights for all tags (simplified for ranking).

        Use for search ranking: multiply tag match by idf_weight.
        Rare tags boost relevance more than common tags.

        Returns:
            Dict mapping tag -> idf_weight
        """
        try:
            await task_store._ensure_db_initialized_async()

            weights = task_store.get_tag_weights()

            sorted_weights = sorted(weights.items(), key=lambda x: x[1], reverse=True)

            return {
                "success": True,
                "weights": dict(sorted_weights),
                "total_tags": len(weights),
                "message": f"Retrieved IDF weights for {len(weights)} tags"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to get tag weights",
                "message": str(e)
            }

    @mcp.tool()
    async def tag_classify(tag: str) -> dict[str, Any]:
        """
        Classify a tag by boost level for search ranking.

        Boost levels:
        - high (1.5): Specific tags like vendor:*, module:*, service:*
        - medium (1.0): Facet tags (domain:*, type:*) and specific tags
        - low (0.5): General/common tags (api, backend, test)
        - filter_only (0.1): Filter-only tags (status:*, priority:*)

        Args:
            tag: Tag string to classify

        Returns:
            Dict with level, boost, and reason
        """
        try:
            from src.normalization import TagNormalizer

            normalizer = TagNormalizer(None)
            classification = normalizer.classify_tag(tag)

            return {
                "success": True,
                "tag": tag,
                "level": classification['level'],
                "boost": classification['boost'],
                "reason": classification['reason']
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to classify tag",
                "message": str(e)
            }

    @mcp.tool()
    async def tags_classify_batch(tags: List[str]) -> dict[str, Any]:
        """
        Classify multiple tags by boost level.

        Args:
            tags: List of tag strings

        Returns:
            Dict with tags grouped by boost level
        """
        try:
            from src.normalization import TagNormalizer

            normalizer = TagNormalizer(None)
            classified = normalizer.classify_tags(tags)

            return {
                "success": True,
                "high": classified['high'],
                "medium": classified['medium'],
                "low": classified['low'],
                "filter_only": classified['filter_only'],
                "total_tags": len(tags),
                "message": f"Classified {len(tags)} tags"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to classify tags",
                "message": str(e)
            }

    @mcp.tool()
    async def search_explain(query: str, limit: int = 5) -> dict[str, Any]:
        """
        Search with ranking explanation.

        Shows how IDF weights, tag classification, and tag_variants
        affect search ranking.

        Args:
            query: Search query
            limit: Max results (default 5)

        Returns:
            Dict with results and ranking explanation
        """
        try:
            await task_store._ensure_db_initialized_async()

            model = await task_store.get_embedding_model_async()

            tasks, total = task_store.search_tasks(
                query=query,
                limit=limit,
                embedding_model=model,
                use_idf_rerank=True
            )

            from src.normalization import TagNormalizer
            normalizer = TagNormalizer(None)
            tag_weights = task_store.get_tag_weights()

            explained = []
            for i, task in enumerate(tasks):
                explanation = {
                    "rank": i + 1,
                    "task_id": task.id,
                    "title": task.title,
                    "tags": task.tags,
                    "tag_variants": task.tag_variants,
                    "tag_classifications": [],
                    "variant_boost": len(task.tag_variants) * 0.02 if task.tag_variants else 0
                }

                for tag in task.tags:
                    classification = normalizer.classify_tag(tag)
                    idf = tag_weights.get(tag, 0)
                    explanation["tag_classifications"].append({
                        "tag": tag,
                        "level": classification['level'],
                        "boost": classification['boost'],
                        "idf_weight": round(idf, 3)
                    })

                explained.append(explanation)

            return {
                "success": True,
                "query": query,
                "results": explained,
                "total_matching": total,
                "message": f"Found {total} results, showing top {len(explained)} with ranking explanation"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to search",
                "message": str(e)
            }

    # ===============================================================================
    # TAG NORMALIZATION TOOLS
    # ===============================================================================

    @mcp.tool()
    async def tag_normalize_preview(threshold: float = 0.90, require_predefined: bool = False) -> dict[str, Any]:
        """
        Preview tag normalization suggestions using vector similarity.

        Analyzes all tags and groups semantically similar ones, suggesting canonical forms.
        Does NOT modify any data - use tag_normalize_apply to execute changes.

        Predefined canonical mappings (from canonical_tag_add) take priority over vector grouping.

        Hard Guards (block merging regardless of similarity):
        - Version guard: tags with different versions never merge (v1 vs v2, php8 vs php7)
        - Numeric guard: tags with different numbers never merge (api1 vs api2)

        Substring Boost:
        - If one tag is substring of another AND both have same version context → auto-merge
        - Example: "laravel" ⊂ "laravel framework" → merge (0.8959 boosted to 0.91)

        Drift Prevention:
        - Set require_predefined=True to ONLY see predefined mappings (canonical freeze)

        Args:
            threshold: Similarity threshold for grouping (0.0-1.0, default: 0.90)
                       0.90 = strict merge (recommended for auto-merge)
                       0.85 = suggest only (more aggressive grouping)
            require_predefined: If True, ONLY show predefined canonical mappings (drift prevention)

        Returns:
            Dict with:
                - groups: List of tag groups with canonical form and variants
                - total_tags: Current total unique tags
                - unique_tags_after: Unique tags after normalization
                - tags_to_merge: Number of tags that would be merged
                - predefined_mappings_used: Number of predefined mappings applied
        """
        try:
            await task_store._ensure_db_initialized_async()

            model = await task_store.get_embedding_model_async()

            canonical_mappings = task_store.get_canonical_mappings()

            normalizer = TagNormalizer(model, threshold=threshold, canonical_mappings=canonical_mappings)

            tag_counts = task_store.get_all_tags_with_counts()

            if not tag_counts:
                return {
                    "success": True,
                    "groups": [],
                    "total_tags": 0,
                    "unique_tags_after": 0,
                    "tags_to_merge": 0,
                    "predefined_mappings": len(canonical_mappings),
                    "message": "No tags found in database"
                }

            all_tags = list(tag_counts.keys())
            preview = normalizer.preview_normalization(all_tags, tag_counts)

            if require_predefined:
                preview.groups = [g for g in preview.groups if g.source == "predefined"]
                preview.tags_to_merge = sum(len(g.variants) for g in preview.groups)
                preview.unique_tags_after = preview.total_tags - preview.tags_to_merge

            groups_data = []
            for group in preview.groups:
                groups_data.append({
                    "canonical": group.canonical,
                    "variants": group.variants,
                    "similarity": group.similarity,
                    "source": group.source,
                    "canonical_count": tag_counts.get(group.canonical, 0),
                    "total_count": tag_counts.get(group.canonical, 0) + sum(tag_counts.get(v, 0) for v in group.variants)
                })

            return {
                "success": True,
                "groups": groups_data,
                "total_tags": preview.total_tags,
                "unique_tags_after": preview.unique_tags_after,
                "tags_to_merge": preview.tags_to_merge,
                "predefined_mappings_used": preview.predefined_mappings_used,
                "require_predefined": require_predefined,
                "threshold": threshold,
                "message": f"Found {len(groups_data)} tag groups ({preview.predefined_mappings_used} predefined). {preview.tags_to_merge} tags can be merged (reducing from {preview.total_tags} to {preview.unique_tags_after} unique tags)" + (" (require_predefined=True)" if require_predefined else "")
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to preview normalization",
                "message": str(e)
            }

    @mcp.tool()
    async def tag_normalize_apply(threshold: float = 0.90, dry_run: bool = False, require_predefined: bool = False) -> dict[str, Any]:
        """
        Apply tag normalization using vector similarity.

        Merges semantically similar tags into canonical forms. Use tag_normalize_preview first
        to see what changes will be made.

        Predefined canonical mappings (from canonical_tag_add) take priority over vector grouping.

        Hard Guards (block merging regardless of similarity):
        - Version guard: tags with different versions never merge (v1 vs v2, php8 vs php7)
        - Numeric guard: tags with different numbers never merge (api1 vs api2)

        Substring Boost:
        - If one tag is substring of another AND both have same version context → auto-merge
        - Example: "laravel" ⊂ "laravel framework" → merge (0.8959 boosted to 0.91)

        Drift Prevention:
        - Set require_predefined=True to ONLY apply predefined mappings (canonical freeze)
        - Vector-based grouping will be ignored

        Selection of canonical tag (for vector-grouped tags):
            1. Most frequently used tag in group
            2. Longest tag (if counts equal)

        Args:
            threshold: Similarity threshold for grouping (0.0-1.0, default: 0.90)
                       0.90 = strict merge (recommended for auto-merge)
                       0.85 = suggest only (more aggressive grouping)
            dry_run: If True, preview changes without applying
            require_predefined: If True, ONLY use predefined canonical mappings (drift prevention)

        Returns:
            Dict with:
                - success: True if completed
                - tasks_updated: Number of tasks modified
                - tags_replaced: Number of individual tag replacements
                - mapping: Dict of old_tag -> new_tag
        """
        try:
            await task_store._ensure_db_initialized_async()

            model = await task_store.get_embedding_model_async()

            canonical_mappings = task_store.get_canonical_mappings()

            normalizer = TagNormalizer(model, threshold=threshold, canonical_mappings=canonical_mappings)

            tag_counts = task_store.get_all_tags_with_counts()

            if not tag_counts:
                return {
                    "success": True,
                    "tasks_updated": 0,
                    "tags_replaced": 0,
                    "mapping": {},
                    "dry_run": dry_run,
                    "predefined_mappings_used": 0,
                    "message": "No tags found in database"
                }

            all_tags = list(tag_counts.keys())
            preview = normalizer.preview_normalization(all_tags, tag_counts)

            if require_predefined:
                vector_groups = [g for g in preview.groups if g.source == "vector"]
                if vector_groups:
                    preview.groups = [g for g in preview.groups if g.source == "predefined"]
                    preview.tags_to_merge = sum(len(g.variants) for g in preview.groups)
                    preview.unique_tags_after = preview.total_tags - preview.tags_to_merge

            if preview.tags_to_merge == 0:
                return {
                    "success": True,
                    "tasks_updated": 0,
                    "tags_replaced": 0,
                    "mapping": {},
                    "dry_run": dry_run,
                    "require_predefined": require_predefined,
                    "predefined_mappings_used": preview.predefined_mappings_used,
                    "message": "No tags to merge." + (" (require_predefined=True, only predefined mappings allowed)" if require_predefined else "")
                }

            mapping = normalizer.get_mapping(preview)

            if dry_run:
                return {
                    "success": True,
                    "dry_run": True,
                    "require_predefined": require_predefined,
                    "tasks_updated": 0,
                    "tags_replaced": preview.tags_to_merge,
                    "mapping": mapping,
                    "predefined_mappings_used": preview.predefined_mappings_used,
                    "message": f"DRY RUN: Would merge {preview.tags_to_merge} tags ({preview.predefined_mappings_used} from predefined mappings)" + (" (require_predefined=True)" if require_predefined else "")
                }

            result = task_store.migrate_tags(mapping, embedding_model=model)

            result["dry_run"] = False
            result["require_predefined"] = require_predefined
            result["threshold"] = threshold
            result["unique_tags_before"] = preview.total_tags
            result["unique_tags_after"] = preview.unique_tags_after
            result["predefined_mappings_used"] = preview.predefined_mappings_used

            return result

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to apply normalization",
                "message": str(e)
            }

    @mcp.tool()
    async def canonical_tag_add(canonical_tag: str, variant_tag: str) -> dict[str, Any]:
        """
        Add a canonical tag mapping for tag normalization.

        When tag_normalize_apply is called, variant_tag will be replaced with canonical_tag.

        Args:
            canonical_tag: The canonical (preferred) tag form
            variant_tag: A variant tag to map to the canonical form

        Returns:
            Dict with success status and mapping info
        """
        try:
            await task_store._ensure_db_initialized_async()

            result = task_store.add_canonical_mapping(canonical_tag, variant_tag)
            return result

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to add canonical mapping",
                "message": str(e)
            }

    @mcp.tool()
    async def canonical_tag_remove(variant_tag: str) -> dict[str, Any]:
        """
        Remove a canonical tag mapping.

        Args:
            variant_tag: The variant tag to remove from mappings

        Returns:
            Dict with success status
        """
        try:
            await task_store._ensure_db_initialized_async()

            result = task_store.remove_canonical_mapping(variant_tag)
            return result

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to remove canonical mapping",
                "message": str(e)
            }

    @mcp.tool()
    async def canonical_tag_list() -> dict[str, Any]:
        """
        List all canonical tag mappings.

        Returns:
            Dict with list of canonical tags and their variants
        """
        try:
            await task_store._ensure_db_initialized_async()

            canonical_tags = task_store.get_all_canonical_tags()

            return {
                "success": True,
                "canonical_tags": canonical_tags,
                "total_mappings": sum(len(ct["variants"]) for ct in canonical_tags),
                "total_canonicals": len(canonical_tags),
                "message": f"Found {len(canonical_tags)} canonical tags with {sum(len(ct['variants']) for ct in canonical_tags)} variant mappings"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to list canonical tags",
                "message": str(e)
            }

    @mcp.tool()
    async def tag_similarity(tag1: str, tag2: str) -> dict[str, Any]:
        """
        Calculate semantic similarity between two tags using embeddings.

        Args:
            tag1: First tag
            tag2: Second tag

        Returns:
            Dict with similarity score (0.0 to 1.0)
        """
        try:
            await task_store._ensure_db_initialized_async()

            model = await task_store.get_embedding_model_async()

            similarity = model.similarity(tag1, tag2)

            return {
                "success": True,
                "tag1": tag1,
                "tag2": tag2,
                "similarity": round(similarity, 4),
                "message": f"Similarity between '{tag1}' and '{tag2}': {similarity:.4f}"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to calculate similarity",
                "message": str(e)
            }

    @mcp.tool()
    async def get_canonical_tags() -> dict[str, Any]:
        """
        Get all canonical tags (semantic tag clusters).

        Canonical tags are the normalized form of semantically similar tags.
        Returns list of canonical tags from predefined mappings only.
        """
        try:
            await task_store._ensure_db_initialized_async()

            canonical_tags = task_store.get_all_canonical_tags()

            tags_list = [ct["canonical_tag"] for ct in canonical_tags]

            return {
                "success": True,
                "tags": tags_list,
                "count": len(tags_list),
                "message": f"Retrieved {len(tags_list)} canonical tags"
            }

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to retrieve canonical tags",
                "message": str(e)
            }

    # ===============================================================================
    # COOKBOOK - YOUR LIFELINE FOR THIS MCP
    # ===============================================================================

    @mcp.tool()
    async def cookbook(
        level: int = 0,
        include: str = "init",
        case_category: str = None,
        query: str = None,
        priority: str = None,
        cognitive: str = None,
        strict: str = None,
        limit: int = 10,
        offset: int = 0
    ) -> dict[str, Any]:
        """
        ╔═══════════════════════════════════════════════════════════════════════════╗
        ║  YOUR ESSENTIAL KNOWLEDGE BASE. READ THIS FIRST OR OPERATE BLIND.         ║
        ║  Contains: docs (4 levels), use cases (18 categories), anti-patterns.      ║
        ║  Without cookbook(), you have NO workflows, NO patterns, NO best practices.║
        ╚═══════════════════════════════════════════════════════════════════════════╝

        Contains:
        - Documentation (4 cumulative levels: quick → usage → extended → developer)
        - Use Cases (18 categories with real code examples)
        - Anti-patterns, error handling, parallel execution patterns

        Call cookbook(include="init") FIRST for orientation, then explore as needed.

        Args:
            level: Verbosity level 0-3 for docs (cumulative, default: 0)
                - 0: Quick Reference (tools, limits, status flow)
                - 1: Usage Guide (how it works, patterns, best practices)
                - 2: Extended Docs (tag normalization, IDF, anti-patterns)
                - 3: Developer Reference (full parameters, architecture)
            include: What to return (default: "init")
                - "init": Essential first-read for orientation (ALWAYS call this first)
                - "docs": Documentation by level
                - "cases": Use cases (all or filtered by case_category/query/priority/cognitive/strict)
                - "all": Documentation + use cases combined
                - "categories": List of available case category names
            case_category: Filter by category key(s), comma-separated for OR (e.g., "gates-rules" or "store,search")
            query: Keyword search in content (text-based, no embeddings)
                - Case-insensitive keyword matching
                - Returns sections containing ANY of the keywords
            priority: Filter by priority markers (comma-separated for OR)
                - "critical": Only [CRITICAL] content
                - "high": Only [HIGH] content
                - "critical,high": Both CRITICAL and HIGH
            cognitive: Filter by cognitive level tags (comma-separated for OR)
                - "minimal", "standard", "deep", "exhaustive"
                - Searches for "cognitive:{level}" in content
            strict: Filter by strict level tags (comma-separated for OR)
                - "relaxed", "standard", "strict", "paranoid"
                - Searches for "strict:{level}" in content
            limit: Max results to return (default: 10, max: 50)
            offset: Pagination offset (default: 0)

        Returns:
            Dict with content based on include parameter
        """
        try:
            import importlib.resources
            import re

            level = max(0, min(3, level))
            include = include.lower() if include else "init"
            valid_includes = ("init", "docs", "cases", "all", "categories")
            if include not in valid_includes:
                include = "init"
            
            limit = max(1, min(50, limit))
            offset = max(0, offset)

            result = {
                "success": True,
                "level": level,
                "include": include,
                "case_category": case_category,
                "query": query,
                "priority": priority,
                "cognitive": cognitive,
                "strict": strict,
                "limit": limit,
                "offset": offset
            }

            def parse_csv_filter(value):
                """Parse comma-separated filter values into list of lowercase strings"""
                if not value:
                    return []
                return [v.strip().lower() for v in value.split(',') if v.strip()]

            def filter_by_priority(content, priority_filter):
                """Filter sections by [CRITICAL] or [HIGH] markers"""
                if not priority_filter or not content:
                    return content, 0
                
                priorities = parse_csv_filter(priority_filter)
                if not priorities:
                    return content, 0
                
                sections = re.split(r'\n---+\n', content)
                matching = []
                
                for section in sections:
                    has_critical = '[CRITICAL]' in section or '### [CRITICAL]' in section
                    has_high = '[HIGH]' in section or '### [HIGH]' in section
                    
                    if 'critical' in priorities and has_critical:
                        matching.append(section)
                    elif 'high' in priorities and has_high:
                        matching.append(section)
                
                return "\n\n---\n\n".join(matching) if matching else "", len(matching)

            def filter_by_tag_pattern(content, tag_type, values):
                """Filter sections containing tag patterns like cognitive:* or strict:*"""
                if not values or not content:
                    return content, 0
                
                tags = parse_csv_filter(values)
                if not tags:
                    return content, 0
                
                sections = re.split(r'\n---+\n', content)
                matching = []
                
                for section in sections:
                    for tag in tags:
                        pattern = f"{tag_type}:{tag}"
                        if pattern.lower() in section.lower():
                            matching.append(section)
                            break
                
                return "\n\n---\n\n".join(matching) if matching else "", len(matching)

            def filter_case_category_csv(raw_cases, category_filter):
                """Filter cases by one or more category keys (CSV support)"""
                if not category_filter or not raw_cases:
                    return raw_cases
                
                categories = parse_csv_filter(category_filter)
                if not categories:
                    return raw_cases
                
                all_matches = []
                
                for cat in categories:
                    key_to_title = cat.replace('-', ' ').title()
                    pattern = rf'^## {re.escape(key_to_title)}(?: Scenarios)?(?: \([A-Z]+\))?$\n(?:<!-- description: .+? -->\n)?.*?(?=^## |\Z)'
                    matches = re.findall(pattern, raw_cases, re.MULTILINE | re.DOTALL)
                    
                    if not matches:
                        pattern2 = rf'^## (.*{re.escape(cat.replace("-", " "))}.*) Scenarios$.*?(?=^## .* Scenarios|\Z)'
                        matches = re.findall(pattern2, raw_cases, re.MULTILINE | re.IGNORECASE | re.DOTALL)
                    
                    all_matches.extend(matches)
                
                return "\n\n".join(all_matches) if all_matches else ""

            def load_cases_raw():
                try:
                    import src
                    cases_file = importlib.resources.files(src).joinpath('CASES.md')
                    return cases_file.read_text(encoding='utf-8')
                except (TypeError, FileNotFoundError, AttributeError, ImportError):
                    cases_path = Path(__file__).parent / 'src' / 'CASES.md'
                    if cases_path.exists():
                        return cases_path.read_text(encoding='utf-8')
                    return ""

            def load_docs_raw():
                try:
                    import src
                    docs_file = importlib.resources.files(src).joinpath('README_AGENTS.md')
                    return docs_file.read_text(encoding='utf-8')
                except (TypeError, FileNotFoundError, AttributeError, ImportError):
                    docs_path = Path(__file__).parent / 'src' / 'README_AGENTS.md'
                    if docs_path.exists():
                        return docs_path.read_text(encoding='utf-8')
                    return ""

            def parse_categories(content):
                """Parse categories with keys, names, and descriptions"""
                if not content:
                    return []
                
                categories = []
                # Match: ## Name Scenarios\n<!-- description: ... -->
                pattern = r'^## (.+?)(?: Scenarios)?(?: \([A-Z]+\))?$\n(?:<!-- description: (.+?) -->)?'
                matches = re.findall(pattern, content, re.MULTILINE)
                
                for name, description in matches:
                    # Generate key: kebab-case
                    key = re.sub(r'[^\w\s-]', '', name.lower())
                    key = re.sub(r'[\s_]+', '-', key).strip('-')
                    
                    # Clean name (remove "Scenarios" suffix if present)
                    clean_name = re.sub(r'\s+Scenarios$', '', name)
                    
                    categories.append({
                        "key": key,
                        "name": clean_name,
                        "description": description.strip() if description else ""
                    })
                
                return categories

            def search_in_content(content, query_text):
                """Keyword search in content - returns matching sections"""
                if not query_text or not content:
                    return content, 0
                
                keywords = [kw.strip().lower() for kw in re.split(r'[\s,]+', query_text) if kw.strip()]
                if not keywords:
                    return content, 0
                
                sections = re.split(r'\n---+\n|\n## ', content)
                matching = []
                
                for section in sections:
                    section_lower = section.lower()
                    if any(kw in section_lower for kw in keywords):
                        matching.append(section.strip())
                
                return matching, len(matching)

            def paginate_sections(sections, limit_val, offset_val):
                """Paginate section list"""
                if isinstance(sections, str):
                    return sections, 1, False
                total = len(sections)
                paginated = sections[offset_val:offset_val + limit_val]
                has_more = (offset_val + limit_val) < total
                return paginated, total, has_more

            # INIT: Essential first-read for orientation
            if include == "init":
                raw_cases = load_cases_raw()
                categories = parse_categories(raw_cases)
                category_keys = [c["key"] for c in categories]

                raw_docs = load_docs_raw()
                tools_count = 22
                if raw_docs:
                    tools_match = re.search(r'Total.*?(\d+)\s*tools', raw_docs, re.IGNORECASE)
                    if tools_match:
                        tools_count = int(tools_match.group(1))

                return {
                    "success": True,
                    "include": "init",
                    "warning": "This is your FIRST AID KIT. Read carefully before using other tools.",
                    "essential": {
                        "what_is_this": "Hierarchical task manager with vector-based semantic search",
                        "total_tools": tools_count,
                        "key_tools": {
                            "task_create": "Create task with title, content, estimate, tags",
                            "task_update": "Update status, comment, tags (NEVER on parent)",
                            "task_list": "Search tasks by query/tags/status/parent",
                            "task_next": "Get next task to work on (smart selection)",
                            "cookbook": "This tool - your knowledge base"
                        },
                        "status_flow": {
                            "draft": "Not ready for execution",
                            "pending": "Ready to start",
                            "in_progress": "Currently working",
                            "completed": "Implementation done",
                            "validated": "Passed all quality gates (FINAL)",
                            "stopped": "Paused/blocked (NOT cancelled)",
                            "canceled": "Won't do (FINAL)"
                        },
                        "critical_rules": [
                            "NEVER manually update parent status - auto-propagation",
                            "ALWAYS set estimate when creating task",
                            "Mark parallel=true ONLY if truly independent (no file overlap)",
                            "Use tags: strict:* + cognitive:* for every task"
                        ],
                        "tag_formula": "1 TYPE + 1 DOMAIN + 0-2 WORKFLOW + 1 STRICT + 1 COGNITIVE",
                        "tag_categories": {
                            "type": "feature, bugfix, refactor, research, docs, test, chore, spike, hotfix",
                            "domain": "backend, frontend, database, api, auth, ui, config, infra, ci-cd, migration",
                            "workflow": "decomposed, validation-fix, blocked, stuck, needs-research, parallel-safe, atomic",
                            "strict": "strict:relaxed, strict:standard, strict:strict, strict:paranoid",
                            "cognitive": "cognitive:minimal, cognitive:standard, cognitive:deep, cognitive:exhaustive"
                        },
                        "case_categories": category_keys,
                        "case_categories_full": categories,
                        "safety_escalation": "auth/, payments/, migrations/ auto-escalate to strict:strict"
                    },
                    "cookbook_usage": {
                        "search": 'cookbook(include="cases", query="parallel")',
                        "multi_category": 'cookbook(include="cases", case_category="store,search")',
                        "priority": 'cookbook(include="cases", priority="critical")',
                        "cognitive": 'cookbook(include="cases", cognitive="deep,exhaustive")',
                        "strict": 'cookbook(include="cases", strict="strict,paranoid")',
                        "combined": 'cookbook(include="cases", case_category="gates-rules", priority="critical")',
                        "paginate": 'cookbook(include="cases", limit=5, offset=0)',
                        "full": 'cookbook(include="all", level=2)',
                        "list": 'cookbook(include="categories")'
                    },
                    "next_steps": [
                        "cookbook(level=0, include='docs') - quick reference table",
                        "cookbook(include='cases', case_category='task-decision') - by category",
                        "cookbook(include='cases', priority='critical') - critical rules only",
                        "cookbook(include='cases', query='parallel') - search by keyword",
                        "cookbook(include='cases', cognitive='deep') - cognitive:deep patterns",
                        "cookbook(level=2, include='all') - everything for deep dive"
                    ],
                    "message": f"Init complete. {len(categories)} case categories available."
                }

            # CATEGORIES: List of case categories with keys, names, and descriptions
            if include == "categories":
                raw_cases = load_cases_raw()
                if not raw_cases:
                    return {"success": False, "error": "Cases not found"}

                categories = parse_categories(raw_cases)

                return {
                    "success": True,
                    "include": "categories",
                    "categories": categories,
                    "keys": [c["key"] for c in categories],
                    "total": len(categories),
                    "usage": 'cookbook(include="cases", case_category="{key}")',
                    "message": f"Found {len(categories)} case categories"
                }

            # DOCS, CASES, ALL
            docs_content = ""
            cases_content = ""
            total_matches = 0
            has_more = False

            if include in ("docs", "all"):
                raw_docs = load_docs_raw()
                if raw_docs:
                    pattern = r'<!-- LEVEL:(\d) -->(.*?)<!-- /LEVEL:\d -->'
                    matches = re.findall(pattern, raw_docs, re.DOTALL)

                    levels_content = {}
                    for lvl, text in matches:
                        levels_content[int(lvl)] = text.strip()

                    docs_parts = []
                    for lvl in range(level + 1):
                        if lvl in levels_content:
                            docs_parts.append(f"<!-- LEVEL:{lvl} -->\n{levels_content[lvl]}\n<!-- /LEVEL:{lvl} -->")

                    docs_content = "\n\n".join(docs_parts) if docs_parts else ""
                    
                    # Apply query search to docs
                    if query and docs_content:
                        matching_sections, match_count = search_in_content(docs_content, query)
                        if isinstance(matching_sections, list):
                            paginated, total, has_more_docs = paginate_sections(matching_sections, limit, offset)
                            docs_content = "\n\n---\n\n".join(paginated)
                            total_matches += total
                            has_more = has_more_docs or has_more

            if include in ("cases", "all"):
                raw_cases = load_cases_raw()
                if raw_cases:
                    if case_category:
                        cases_content = filter_case_category_csv(raw_cases, case_category)
                        if not cases_content:
                            categories = parse_categories(raw_cases)
                            available_keys = [c["key"] for c in categories]
                            cases_content = f"No cases found for: '{case_category}'. Available keys: {available_keys}"
                    else:
                        cases_content = raw_cases
                    
                    if not cases_content.startswith("No cases found"):
                        if priority:
                            cases_content, p_count = filter_by_priority(cases_content, priority)
                            if not cases_content:
                                cases_content = f"No content found with priority: {priority}"
                        
                        if cognitive and not cases_content.startswith("No"):
                            cases_content, c_count = filter_by_tag_pattern(cases_content, "cognitive", cognitive)
                            if not cases_content:
                                cases_content = f"No content found with cognitive: {cognitive}"
                        
                        if strict and not cases_content.startswith("No"):
                            cases_content, s_count = filter_by_tag_pattern(cases_content, "strict", strict)
                            if not cases_content:
                                cases_content = f"No content found with strict: {strict}"
                        
                        if query and cases_content and not cases_content.startswith("No"):
                            matching_sections, match_count = search_in_content(cases_content, query)
                            if isinstance(matching_sections, list):
                                paginated, total, has_more_cases = paginate_sections(matching_sections, limit, offset)
                                cases_content = "\n\n---\n\n".join(paginated)
                                total_matches += total
                                has_more = has_more_cases or has_more

            if include == "docs":
                result["content"] = docs_content
                if query:
                    result["message"] = f"Docs level {level} with query '{query}' ({total_matches} matches, showing {limit})"
                else:
                    result["message"] = f"Docs level {level} ({len(docs_content)} chars)"
            elif include == "cases":
                result["content"] = cases_content
                filters = []
                if case_category:
                    filters.append(f"category={case_category}")
                if priority:
                    filters.append(f"priority={priority}")
                if cognitive:
                    filters.append(f"cognitive={cognitive}")
                if strict:
                    filters.append(f"strict={strict}")
                if query:
                    filters.append(f"query={query}")
                
                filter_str = f" [{', '.join(filters)}]" if filters else ""
                result["message"] = f"Cases{filter_str} ({len(cases_content)} chars)"
                if query and total_matches:
                    result["message"] += f" ({total_matches} matches)"
            else:
                result["content"] = f"# Documentation\n\n{docs_content}\n\n# Use Cases\n\n{cases_content}"
                result["message"] = f"Docs level {level} + Cases ({len(result['content'])} chars)"
                if query:
                    result["message"] += f" with query '{query}' ({total_matches} matches)"

            result["content_length"] = len(result.get("content", ""))
            result["total_matches"] = total_matches if query else None
            result["has_more"] = has_more if query else None
            return result

        except Exception as e:
            return {
                "success": False,
                "error": "Failed to get cookbook",
                "message": str(e)
            }

    # ===============================================================================
    # TASK FOLDER READ APIs
    # ===============================================================================

    async def task_folder_files(
        task_id: int | None = None,
        code: str | None = None,
    ) -> dict[str, Any]:
        """
        List files in a task's folder (requires --task-folder).

        Provide EXACTLY one of ``task_id`` or ``code`` — never both, never neither.
        Subtasks share the ROOT task's folder (task hierarchy = one folder per
        root). When a subtask id/code is supplied, the call walks up to the
        root and returns the root's folder. Files are returned recursively
        as ``{path, relative}`` entries (path is relative to ``--working-dir``
        when inside it, otherwise absolute).

        Args:
            task_id: Any task ID (root or subtask). Subtasks are resolved to
                their root automatically.
            code: A task code (e.g. ``FEAT-12``, ``OLOM-460``). When the code
                belongs to a subtask, the call walks to the root code via DB
                lookup. Codes not present in the DB are treated as direct
                folder probes.
        """
        try:
            # Registration is gated on --task-folder below, so folder_mgr is
            # guaranteed to exist when this function is invoked through MCP.
            folder_mgr = task_store.folder_mgr

            if (task_id is None) == (code is None):
                return {
                    "success": False,
                    "error": "Invalid parameter",
                    "message": "Provide exactly one of task_id or code",
                }

            # By-code branch: validate the user-supplied code BEFORE handing it
            # to the filesystem manager — prevents path traversal via `..`,
            # absolute paths, null bytes, lowercase/non-conforming codes, etc.
            if code is not None:
                try:
                    code = validate_code(code)
                except SecurityError as e:
                    return {
                        "success": False,
                        "error": "Invalid parameter",
                        "message": str(e),
                    }

            await task_store._ensure_db_initialized_async()

            root_task_id = None
            if task_id is not None:
                if not isinstance(task_id, int) or task_id < 1:
                    return {
                        "success": False,
                        "error": "Invalid parameter",
                        "message": "task_id must be a positive integer",
                    }
                # Walk up to root regardless of whether the input is root or subtask.
                root_task = task_store.get_root_task(task_id)
                if root_task is None:
                    return {
                        "success": False,
                        "error": "Not found",
                        "message": f"Task with ID {task_id} not found",
                    }
                if not root_task.code:
                    return {
                        "success": False,
                        "error": "Invalid task",
                        "message": "Root task has no code — folder cannot be resolved",
                    }
                try:
                    resolved_code = validate_code(root_task.code)
                except SecurityError:
                    return {
                        "success": False,
                        "error": "Invalid task",
                        "message": "Stored task code does not pass validation",
                    }
                root_task_id = root_task.id
            else:
                # By-code: if the code belongs to a known task, walk to root.
                # If unknown (orphan code passed by user), treat as direct probe.
                resolved_code = code
                task_by_code = task_store.get_task_by_code(code)
                if task_by_code is not None:
                    if task_by_code.parent_id is None:
                        root_task_id = task_by_code.id
                    else:
                        root = task_store.get_root_task(task_by_code.id)
                        if root is not None and root.code:
                            try:
                                resolved_code = validate_code(root.code)
                            except SecurityError:
                                return {
                                    "success": False,
                                    "error": "Invalid task",
                                    "message": "Stored root task code does not pass validation",
                                }
                            root_task_id = root.id

            files = folder_mgr.list_files(resolved_code)
            resolved = folder_mgr._resolve_existing_folder(resolved_code)
            if resolved is None:
                folder_path = None
            else:
                try:
                    folder_path = str(resolved.relative_to(task_store.working_dir))
                except (ValueError, AttributeError):
                    folder_path = str(resolved)

            response: dict[str, Any] = {
                "success": True,
                "code": resolved_code,
                "folder_path": folder_path,
                "files": files if files is not None else [],
                "message": f"Found {len(files) if files else 0} file(s) in folder for {resolved_code}",
            }
            if root_task_id is not None:
                response["root_task_id"] = root_task_id
            return response

        except Exception as e:
            return {
                "success": False,
                "error": "Folder read failed",
                "message": str(e),
            }

    # Register `task_folder_files` ONLY when --task-folder is enabled.
    # When the feature is off, the tool is not advertised by the MCP server —
    # clients see exactly the surface that is meaningful for the configuration.
    if task_folder is not None:
        task_folder_files = mcp.tool()(task_folder_files)  # noqa: F811

    # ===============================================================================
    # MCP RESOURCES
    # ===============================================================================

    @mcp.resource("project://info")
    async def project_info() -> dict:
        """Return project metadata: working_dir, task_folder status, folders summary."""
        feature_on = task_folder is not None
        return {
            "working_dir": str(working_dir),
            "task_folder": str(task_folder) if feature_on else None,
            "task_folder_enabled": feature_on,
            "task_folders": _get_task_folders_summary(task_store) if feature_on else [],
        }

    return mcp


def main():
    """Main entry point"""
    print(f"Starting {Config.SERVER_NAME} v{Config.SERVER_VERSION}", file=sys.stderr)

    try:
        # Get working directory and config
        working_dir = get_working_dir()
        memory_dir = working_dir / "memory"
        task_db_path = memory_dir / "tasks.db"

        print(f"Working directory: {working_dir}", file=sys.stderr)
        print(f"Task database: {task_db_path}", file=sys.stderr)
        print(f"Embedding model: {Config.EMBEDDING_MODEL}", file=sys.stderr)
        print("=" * 50, file=sys.stderr)
        
        # Create and run server
        server = create_server()
        print("Server ready for connections...", file=sys.stderr)
        server.run()
        
    except KeyboardInterrupt:
        print("\nServer stopped by user", file=sys.stderr)
    except Exception as e:
        print(f"Server failed to start: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
