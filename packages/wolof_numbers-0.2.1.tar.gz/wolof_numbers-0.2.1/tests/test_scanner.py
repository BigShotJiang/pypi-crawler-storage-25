"""Tests for extract_amounts transcript scanner.

The scanner must find every parseable Wolof numeral span within a larger
transcript string and return (start, end, matched_text, ParseResult) tuples.
"""

from __future__ import annotations

from wolof_numbers import extract_amounts
from wolof_numbers.models import ScannerHit


def test_extract_single_amount_pure_wolof() -> None:
    """Basic single amount in a Wolof sentence."""
    hits = extract_amounts("jëndeel naa riz ci ñaar junni")
    assert len(hits) >= 1
    values = [h.result.value for h in hits]
    assert 2000 in values


def test_extract_returns_scanner_hit_objects() -> None:
    """Return type is list[ScannerHit]."""
    hits = extract_amounts("benn")
    assert len(hits) >= 1
    assert isinstance(hits[0], ScannerHit)
    assert hits[0].result.value == 1
    assert hits[0].matched_text == "benn"


def test_extract_hit_span_correct() -> None:
    """start_char/end_char must index the matched text within the input."""
    transcript = "total bi dafa am ñaar junni"
    hits = extract_amounts(transcript)
    assert len(hits) >= 1
    hit = next(h for h in hits if h.result.value == 2000)
    assert transcript[hit.start_char : hit.end_char] == hit.matched_text


def test_extract_multiple_amounts() -> None:
    """Multiple numerals in a single transcript are all returned."""
    transcript = "Mamadou jënd na benn sac ak juróom dërëm"
    hits = extract_amounts(transcript)
    values = [h.result.value for h in hits]
    # benn = 1; juróom = 5 (raw number before dërëm handling in scanner)
    assert 1 in values


def test_extract_no_overlap() -> None:
    """Matched spans must not overlap."""
    hits = extract_amounts("ñaar junni ak téeméer")
    for i, a in enumerate(hits):
        for j, b in enumerate(hits):
            if i == j:
                continue
            # ranges [a.start, a.end) and [b.start, b.end) must not overlap
            assert a.end_char <= b.start_char or b.end_char <= a.start_char, (
                f"Overlapping hits: {a!r} and {b!r}"
            )


def test_extract_empty_transcript() -> None:
    """Empty/whitespace-only input returns empty list."""
    assert extract_amounts("") == []
    assert extract_amounts("   ") == []


def test_extract_no_wolof_numbers() -> None:
    """Pure French text with no Wolof numerals returns empty list."""
    result = extract_amounts("j'ai vendu des tomates aujourd'hui")
    # No Wolof numeral tokens present
    assert isinstance(result, list)


def test_extract_fanweer_in_sentence() -> None:
    """fanweer (30) is recognized inside a sentence."""
    hits = extract_amounts("ci fanweer de ci bis bi")
    values = [h.result.value for h in hits]
    assert 30 in values


def test_extract_alfunni_in_sentence() -> None:
    """alfunni (1,000,000) is recognized inside a sentence."""
    hits = extract_amounts("dëkk naa alfunni ci project bi")
    values = [h.result.value for h in hits]
    assert 1000000 in values


def test_extract_hit_confidence_positive() -> None:
    """All returned hits have confidence > 0."""
    hits = extract_amounts("juróom-benn junni")
    assert all(h.result.confidence > 0 for h in hits)
