from pathlib import Path

import yaml

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def load_fixtures(glob_pattern: str) -> list[dict]:
    cases: list[dict] = []
    for f in sorted(FIXTURES_DIR.glob(glob_pattern)):
        loaded = yaml.safe_load(f.read_text(encoding="utf-8")) or []
        cases.extend(c for c in loaded if c.get("skip") is None)
    return cases
