# Test Fixtures

YAML fixture files for the `wolof-numbers` test suite. Loaded via `pytest.mark.parametrize`.

## Schema

Each fixture entry has the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | Unique slug for the test case. Used as pytest test ID. |
| `input` | `str` | The Wolof (or code-switched) text to parse. |
| `expected_value` | `int \| null` | Expected parsed integer value. `null` when an error is expected. |
| `expected_confidence_gte` | `float 0..1` | Minimum acceptable confidence score in the result. |
| `expected_error` | `str \| null` | Exception class name if error expected (e.g. `"UnsupportedNumeralForm"`). `null` if no error. |
| `magnitude_bucket` | `str` | Stratification bucket (see Magnitude Buckets below). |
| `dialect` | `str` | Dialect label (see Dialects below). |
| `skip` | `str \| null` | Version this case is deferred to (e.g. `"v0.2"`), or `null` to include in current suite. |

## Magnitude Buckets

| Value | Range |
|-------|-------|
| `1_10` | 1 – 10 |
| `10_100` | 10 – 100 |
| `100_1k` | 100 – 999 |
| `1k_100k` | 1,000 – 99,999 |
| `100k_1M` | 100,000 – 999,999 |
| `1M_1B` | 1,000,000 – 1,000,000,000 |

## Dialects

| Value | Description |
|-------|-------------|
| `wolof` | Pure canonical Wolof orthography (Guérin 2021) |
| `code-switched` | Wolof numeral + French base word (e.g. `ñaar mille`) |
| `loanword` | Arabic loanword numeral (e.g. `alfu` for 1000) — most cases `skip: v0.2` |

## Skip Semantics

Cases with `skip: v0.2` are loaded by `conftest.py` but filtered out via the
`c.get("skip") is None` check. They serve as documentation of planned v0.2 scope
and are not run in the v0.1.0 test suite.

Cases with `skip: null` (or missing `skip` key) are always included.

## Files

| File | Magnitude | Min Cases |
|------|-----------|-----------|
| `numbers_1_10.yaml` | 1–10 | 30 |
| `numbers_10_100.yaml` | 10–100 | 40 |
| `numbers_100_1k.yaml` | 100–999 | 35 |
| `numbers_1k_100k.yaml` | 1,000–99,999 | 35 |
| `numbers_100k_1M.yaml` | 100,000–999,999 | 30 |
| `numbers_1M_1B.yaml` | 1,000,000–1,000,000,000 | 30 |
| `currency_phrases.yaml` | All | 100 |

Total: ≥200 number cases + ≥100 currency cases = ≥300 parametrized test cases.

## Adding Cases

1. Copy an existing entry.
2. Set a unique `id` slug.
3. Set `skip: null` to include immediately, or `skip: v0.2` to defer.
4. Run `uv run pytest packages/wolof-numbers/tests/ -v` to verify the new case passes.
