"""Canonical Wolof numeral coverage tests.

Source: Guérin, M. (2021). Système de numération en wolof: description et
comparaison avec les autres langues atlantiques. Faits de Langues, 51(2),
121-144. https://shs.hal.science/halshs-03207241v1/document

Covers: special tens (fanweer/nit), millions (alfunni/milyon/tamndareet),
genitive construction (X-i téeméer / X-i junni), dërëm commerce unit,
xaalis currency alias, dialectal variants (yaar/yett per Kobès 1869).
"""

from __future__ import annotations

import pytest
from wolof_numbers import UnsupportedNumeralForm, parse_currency_amount, parse_number

from tests.conftest import load_fixtures

_CANONICAL = load_fixtures("canonical_coverage.yaml")
_NUMBER_CASES = [c for c in _CANONICAL if c.get("type") == "number"]
_CURRENCY_CASES = [c for c in _CANONICAL if c.get("type") == "currency"]


@pytest.mark.parametrize("case", _NUMBER_CASES, ids=[c["id"] for c in _NUMBER_CASES])
def test_canonical_number(case: dict) -> None:
    """Parse number fixture from canonical_coverage.yaml."""
    if case.get("expected_error"):
        with pytest.raises(UnsupportedNumeralForm):
            parse_number(case["input"])
        return

    result = parse_number(case["input"])
    assert result.value == case["expected_value"], (
        f"case {case['id']}: got {result.value}, expected {case['expected_value']}"
        f"\n  notes: {case.get('notes', '')}"
    )
    assert result.confidence >= case["expected_confidence_gte"], (
        f"case {case['id']}: confidence {result.confidence} < {case['expected_confidence_gte']}"
    )
    assert result.raw_input == case["input"]


@pytest.mark.parametrize(
    "case", _CURRENCY_CASES, ids=[c["id"] for c in _CURRENCY_CASES]
)
def test_canonical_currency(case: dict) -> None:
    """Parse currency fixture from canonical_coverage.yaml."""
    result = parse_currency_amount(case["input"])
    assert result.amount == case["expected_amount"], (
        f"case {case['id']}: got {result.amount}, expected {case['expected_amount']}"
        f"\n  notes: {case.get('notes', '')}"
    )
    assert result.currency == case["expected_currency"], (
        f"case {case['id']}: got currency={result.currency!r}, "
        f"expected {case['expected_currency']!r}"
    )
    assert result.confidence >= case["expected_confidence_gte"], (
        f"case {case['id']}: confidence {result.confidence} < {case['expected_confidence_gte']}"
    )
