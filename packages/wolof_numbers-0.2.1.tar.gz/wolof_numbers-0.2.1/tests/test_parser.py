import pytest
from wolof_numbers import UnsupportedNumeralForm, parse_number, parse_strict

from tests.conftest import load_fixtures

NUMBER_CASES = load_fixtures("numbers_*.yaml")


@pytest.mark.parametrize("case", NUMBER_CASES, ids=[c["id"] for c in NUMBER_CASES])
def test_parse_number(case: dict) -> None:
    if case.get("expected_error"):
        with pytest.raises(UnsupportedNumeralForm):
            parse_number(case["input"])
        return
    result = parse_number(case["input"])
    assert result.value == case["expected_value"], (
        f"case {case['id']}: got {result.value}, expected {case['expected_value']}"
    )
    assert result.confidence >= case["expected_confidence_gte"], (
        f"case {case['id']}: confidence {result.confidence} < {case['expected_confidence_gte']}"
    )
    assert result.raw_input == case["input"]


def test_canonical_worked_example() -> None:
    """From PROJECT.md: 'Awa jënd na ñaar junni crédit' implies amount=2000."""
    result = parse_number("ñaar junni")
    assert result.value == 2000
    assert result.confidence == 1.0


def test_parse_strict_returns_int() -> None:
    assert parse_strict("ñaar junni") == 2000
    assert parse_strict("benn") == 1
