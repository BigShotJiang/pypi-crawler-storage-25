from wolof_numbers import normalize


def test_diacritic_insensitive() -> None:
    assert "ñaar" in normalize("naar")


def test_case_insensitive() -> None:
    assert "ñaar" in normalize("NAAR")


def test_alias_table() -> None:
    # "dyuroom" is a known variant of "juróom"
    assert "juróom" in normalize("dyuroom")
