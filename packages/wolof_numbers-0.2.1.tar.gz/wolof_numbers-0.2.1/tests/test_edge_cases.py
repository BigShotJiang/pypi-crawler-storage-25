"""Edge case tests for parse_number.

NOTE on milyon/alfunni:
  The original v0.1.0 had a test asserting milyon raises UnsupportedNumeralForm.
  This was incorrect per Guérin (2021): milyon, milyoŋ, alfunni, and alfun are
  fully-naturalized Wolof loanwords and MUST parse to 1,000,000.
  The test has been removed in plan 02-06. Only alfu/alfii remain rejected
  because they are NOT attested in Guérin 2021 coverage.
"""

import pytest
from wolof_numbers import UnsupportedNumeralForm, parse_number


def test_ordinal_raises() -> None:
    with pytest.raises(UnsupportedNumeralForm) as exc_info:
        parse_number("ñaaréél")
    assert exc_info.value.kind == "ordinal"


def test_fraction_raises() -> None:
    with pytest.raises(UnsupportedNumeralForm) as exc_info:
        parse_number("genn ci ñaar")
    assert exc_info.value.kind == "fraction"


def test_loanword_alfu_raises() -> None:
    """alfu is not in Guérin 2021; remains rejected."""
    with pytest.raises(UnsupportedNumeralForm) as exc_info:
        parse_number("alfu")
    assert exc_info.value.kind == "loanword"


def test_loanword_alfii_raises() -> None:
    """alfii is not in Guérin 2021; remains rejected."""
    with pytest.raises(UnsupportedNumeralForm) as exc_info:
        parse_number("alfii")
    assert exc_info.value.kind == "loanword"
