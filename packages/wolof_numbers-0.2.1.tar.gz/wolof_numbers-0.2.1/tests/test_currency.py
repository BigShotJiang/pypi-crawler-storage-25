import pytest
from wolof_numbers import parse_currency_amount

from tests.conftest import load_fixtures

CURRENCY_CASES = load_fixtures("currency_phrases.yaml")


@pytest.mark.parametrize("case", CURRENCY_CASES, ids=[c["id"] for c in CURRENCY_CASES])
def test_parse_currency_amount(case: dict) -> None:
    result = parse_currency_amount(case["input"])
    assert result.amount == case["expected_value"]
    assert result.currency == "XOF"
    assert result.confidence >= case["expected_confidence_gte"]


def test_canonical_currency_example() -> None:
    result = parse_currency_amount("ñaar junni franc CFA")
    assert result.amount == 2000
    assert result.currency == "XOF"
