"""Typed result models and exceptions for wolof-numbers."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Interpretation(BaseModel):
    value: int
    confidence: float = Field(ge=0.0, le=1.0)
    rationale: str


class ParseResult(BaseModel):
    value: int
    confidence: float = Field(ge=0.0, le=1.0)
    alternatives: list[Interpretation] = Field(default_factory=list)
    raw_input: str


class AmountResult(BaseModel):
    amount: int
    currency: Literal["XOF"] = "XOF"
    confidence: float = Field(ge=0.0, le=1.0)
    alternatives: list[Interpretation] = Field(default_factory=list)
    raw_input: str


class ScannerHit(BaseModel):
    """A numeral span found by extract_amounts() within a larger transcript."""

    start_char: int
    end_char: int
    matched_text: str
    result: ParseResult


class AmbiguityError(Exception):
    """Raised by parse_strict when input has multiple valid interpretations."""

    def __init__(self, raw_input: str, alternatives: list[Interpretation]) -> None:
        self.raw_input = raw_input
        self.alternatives = alternatives
        super().__init__(
            f"Ambiguous Wolof numeral {raw_input!r}: {len(alternatives)} interpretations"
        )


class UnsupportedNumeralForm(Exception):
    """Raised for ordinals, fractions, Arabic loanwords in v0.1.0 scope."""

    def __init__(
        self,
        kind: Literal["ordinal", "fraction", "loanword"],
        raw_input: str,
    ) -> None:
        self.kind = kind
        self.raw_input = raw_input
        super().__init__(f"Unsupported numeral form ({kind}) in v0.1.0: {raw_input!r}")
