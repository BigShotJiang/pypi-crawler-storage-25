"""Alias + diacritic normalization pre-pass."""

from __future__ import annotations

import unicodedata
from pathlib import Path

import yaml

_DATA_DIR = Path(__file__).parent / "data"
_ALIASES: dict[str, str] = {}


def _strip_diacritics(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def _load_aliases() -> None:
    raw = yaml.safe_load((_DATA_DIR / "aliases.yaml").read_text(encoding="utf-8")) or {}
    for canonical, variants in raw.items():
        # canonical also maps to itself under its stripped form
        _ALIASES[_strip_diacritics(canonical.lower())] = canonical
        for v in variants or []:
            _ALIASES[_strip_diacritics(str(v).lower())] = canonical


def normalize(text: str) -> str:
    """Map variant spellings to canonical Wolof orthography.

    - Case-insensitive
    - Diacritic-insensitive matching (naar == ñaar)
    - Preserves token order and whitespace structure
    - Original input available at call site via raw_input argument
    """
    if not _ALIASES:
        _load_aliases()
    # Preserve hyphen boundaries as distinct tokens for compound handling
    # Split on whitespace; then split hyphenated compounds into parts, normalize each
    out_tokens: list[str] = []
    for whitespace_token in text.split():
        # Keep hyphens: normalize each segment but rejoin with hyphens preserved
        segments = whitespace_token.split("-")
        mapped = [_ALIASES.get(_strip_diacritics(seg.lower()), seg.lower()) for seg in segments]
        out_tokens.append("-".join(mapped))
    return " ".join(out_tokens)


_load_aliases()
