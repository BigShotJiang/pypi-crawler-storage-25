"""Wolof numeral and currency phrase parser (range 1 to 1,000,000,000).

Based on: Guérin, M. (2021). Système de numération en wolof: description et
comparaison avec les autres langues atlantiques. Faits de Langues, 51(2),
121-144. https://shs.hal.science/halshs-03207241v1/document
"""

from wolof_numbers.currency import parse_currency_amount
from wolof_numbers.models import (
    AmbiguityError,
    AmountResult,
    Interpretation,
    ParseResult,
    ScannerHit,
    UnsupportedNumeralForm,
)
from wolof_numbers.normalizer import normalize
from wolof_numbers.parser import parse, parse_number, parse_strict
from wolof_numbers.scanner import extract_amounts

__all__ = [
    "parse",
    "parse_strict",
    "parse_number",
    "parse_currency_amount",
    "extract_amounts",
    "normalize",
    "ParseResult",
    "AmountResult",
    "ScannerHit",
    "Interpretation",
    "AmbiguityError",
    "UnsupportedNumeralForm",
]
__version__ = "0.2.0"
