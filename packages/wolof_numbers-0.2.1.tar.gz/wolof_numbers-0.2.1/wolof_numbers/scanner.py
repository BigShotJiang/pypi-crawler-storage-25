"""Transcript scanner: extract all Wolof numeral spans from free text.

extract_amounts(text) finds every contiguous run of Wolof lexicon tokens in
the transcript and returns a list of ScannerHit objects, each with the char
span, matched text, and ParseResult.

Used by Phase 3 audio stream processing to detect amounts in multi-utterance
merchant transcripts (e.g., "jëndeel naa riz ci ñaar junni" → hit at
"ñaar junni", value=2000).
"""

from __future__ import annotations

import re

from wolof_numbers.models import ParseResult, ScannerHit
from wolof_numbers.normalizer import normalize
from wolof_numbers.parser import (
    CONNECTOR,
    MILLIONS,
    MULTIPLIERS,
    ONES,
    SPECIAL_TENS,
    parse_number,
)

# All canonical lexicon tokens (lowercase, no diacritics needed — we'll normalize)
_ALL_CANON_TOKENS: frozenset[str] = frozenset(
    list(ONES) + list(MULTIPLIERS) + list(SPECIAL_TENS) + list(MILLIONS) + [CONNECTOR]
)

# Token boundary: split on whitespace; candidate spans are maximal runs of
# lexicon-known tokens (and CONNECTOR "ak" which links them).
# We also allow hyphenated compounds as single tokens.
_WORD_RE = re.compile(r"[^\s]+")


def _candidate_spans(text: str) -> list[tuple[int, int]]:
    """Return (start, end) char spans of maximal Wolof numeral candidate runs.

    A candidate is a maximal contiguous sequence of whitespace-separated words
    where every word (after normalization) maps to a known lexicon token or is
    a connector ("ak"). Connectors at the start or end of a span are excluded.
    """
    words = list(_WORD_RE.finditer(text))
    if not words:
        return []

    # Normalize each word to its canonical form for lookup
    norm_words: list[str] = []
    for m in words:
        raw_tok = m.group(0)
        canon = normalize(raw_tok)
        # normalize may return multi-token for hyphenated — keep as single token
        norm_words.append(canon)

    known: list[bool] = []
    for nw in norm_words:
        # A token is "known" if, after splitting any hyphens, all sub-parts are
        # in the lexicon OR the whole thing is a known compound.
        def _token_known(t: str) -> bool:
            if t in _ALL_CANON_TOKENS:
                return True
            if "-" in t:
                # hyphenated compound — check by recursive parse
                parts = t.split("-")
                return all(p in _ALL_CANON_TOKENS for p in parts)
            return False

        known.append(_token_known(nw))

    spans: list[tuple[int, int]] = []
    i = 0
    while i < len(words):
        if not known[i]:
            i += 1
            continue
        # Start of a run
        j = i
        while j < len(words) and known[j]:
            j += 1
        # Trim leading/trailing connectors
        lo, hi = i, j
        while lo < hi and norm_words[lo] == CONNECTOR:
            lo += 1
        while hi > lo and norm_words[hi - 1] == CONNECTOR:
            hi -= 1
        if lo < hi:
            start_char = words[lo].start()
            end_char = words[hi - 1].end()
            spans.append((start_char, end_char))
        i = j

    return spans


def extract_amounts(text: str) -> list[ScannerHit]:
    """Scan a transcript for Wolof numeral spans and return all parseable hits.

    Returns a list of ScannerHit objects in document order, sorted by start_char.
    Only spans whose ParseResult.confidence > 0 are included.

    Args:
        text: Free-text transcript (may be Wolof/French code-switched).

    Returns:
        List of ScannerHit(start_char, end_char, matched_text, result).

    Example:
        >>> hits = extract_amounts("jëndeel naa riz ci ñaar junni")
        >>> hits[0].result.value
        2000
    """
    if not text or not text.strip():
        return []

    hits: list[ScannerHit] = []
    for start, end in _candidate_spans(text):
        matched = text[start:end]
        try:
            result = parse_number(matched)
        except Exception:
            # UnsupportedNumeralForm (ordinal, fraction, loanword) — skip span
            result = ParseResult(value=0, confidence=0.0, alternatives=[], raw_input=matched)

        if result.confidence > 0:
            hits.append(
                ScannerHit(
                    start_char=start,
                    end_char=end,
                    matched_text=matched,
                    result=result,
                )
            )

    return hits
