"""Recursive-descent Wolof cardinal numeral parser.

Based on: Guérin, M. (2021). Système de numération en wolof: description et
comparaison avec les autres langues atlantiques. Faits de Langues, 51(2),
121-144. https://shs.hal.science/halshs-03207241v1/document

Key coverage added in v0.2.0 (plan 02-06):
- Special tens: fanweer (30, "jour-lune"), nit (20, archaic)
- Millions: milyoŋ/milyon/tamndareet/alfunni/alfun → 1,000,000
- Genitive construction: X-i téeméer / X-i junni (Guérin §2.2)
- Dialectal variants: yaar/yett (Kobès 1869) handled via aliases
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from wolof_numbers.models import (
    AmbiguityError,
    ParseResult,
    UnsupportedNumeralForm,
)
from wolof_numbers.normalizer import normalize

_DATA_DIR = Path(__file__).parent / "data"

# Load lexicon
_lex = yaml.safe_load((_DATA_DIR / "lexicon.yaml").read_text(encoding="utf-8"))
ONES: dict[str, int] = dict(_lex["ones"])  # canonical: int
MULTIPLIERS: dict[str, int] = dict(_lex["multipliers"])  # fukk/téeméer/junni
SPECIAL_TENS: dict[str, int] = dict(_lex.get("special_tens", {}))  # nit/fanweer
MILLIONS: dict[str, int] = dict(_lex.get("millions", {}))  # milyoŋ/milyon/alfunni/...
CONNECTOR: str = _lex["connector"]  # "ak"

# Known Arabic loanwords rejected in v0.1.0 — only bare alfu/alfii remain.
# milyoŋ, milyon, alfunni, alfun ARE naturalized Wolof per Guérin 2021.
LOANWORDS = {"alfu", "alfii"}

# Ordinal suffix detection: -éél, -eel, -réél
_ORDINAL_RE = re.compile(r".+(réél|éél|eel)$", re.IGNORECASE)
# Fraction particle: "ci" between numbers ("genn ci ñaar" = 1/2)
_FRACTION_RE = re.compile(r"\bci\b", re.IGNORECASE)

# Genitive construction pattern: (multiplier)[-]i (téeméer|junni)
# Handles both fused (ñaari téeméer) and hyphenated (ñaar-i téeméer / juróom-benn-i junni)
# Pattern applied BEFORE tokenization on the normalized string.
_GENITIVE_RE = re.compile(
    r"^([\w]+(?:[-\s][\w]+)*?)-?i\s+(téeméer|teemeer|temeer|témeer|junni|junne|juni)$",
    re.IGNORECASE,
)

# All magnitude-multiplier tokens: keys in MULTIPLIERS union MILLIONS
_ALL_MULTIPLIER_VALUES: frozenset[int] = frozenset(MULTIPLIERS.values()) | frozenset(
    MILLIONS.values()
)


def _tokenize(text: str) -> list[str]:
    """Split normalized text into token stream, preserving compound-hyphens as joined tokens."""
    # Whitespace-separated; hyphenated compounds kept intact for lexicon lookup
    return [t for t in re.split(r"\s+", text.strip()) if t]


def _lookup_atomic(token: str) -> int | None:
    """Look up a single token in ONES, MULTIPLIERS, SPECIAL_TENS, or MILLIONS."""
    if token in ONES:
        return ONES[token]
    if token in MULTIPLIERS:
        return MULTIPLIERS[token]
    if token in SPECIAL_TENS:
        return SPECIAL_TENS[token]
    if token in MILLIONS:
        return MILLIONS[token]
    return None


def _parse_atom(token: str) -> int | None:
    """Parse an atomic token or hyphenated compound of ones/multipliers.

    Handles: 'ñaar' -> 2, 'juróom-benn' -> 6, 'ñaar-fukk' -> 20,
             'juróom-benn-fukk' -> 60.
    """
    direct = _lookup_atomic(token)
    if direct is not None:
        return direct
    # Hyphenated compound — split and compose
    if "-" in token:
        parts = token.split("-")
        # pattern: <ones> 'fukk' → ones*10;
        # pattern: juróom-<1-4> → 5+digit (6-9 already in ONES so direct match above);
        # pattern: <ones>-fukk → ones*10;
        # pattern: juróom-benn-fukk → 6*10=60
        if parts[-1] in MULTIPLIERS:
            multiplier = MULTIPLIERS[parts[-1]]
            head = "-".join(parts[:-1])
            head_val = _parse_atom(head)
            if head_val is not None:
                return head_val * multiplier
        # juróom-<digit> composition (already stored in ONES but fall-through safety)
        if parts[0] == "juróom" and len(parts) == 2:
            tail = _lookup_atomic(parts[1])
            if tail is not None and 1 <= tail <= 4:
                return 5 + tail
    return None


def _parse_genitive(normalized: str) -> int | None:
    """Parse genitive construction: [multiplier]-i [100 or 1000].

    Guérin §2.2: multiples of 100/1000 use genitive suffix -i on the multiplier.
    Examples:
      ñaari téeméer   = 2×100 = 200  (suffix fused with no hyphen)
      ñaar-i téeméer  = 2×100 = 200  (hyphenated)
      juróom-benn-i junni = 6×1000 = 6000

    Handles both the space-separated form (ñaari téeméer where -i is attached to
    the multiplier word) and the hyphenated form (ñaar-i téeméer).
    """
    match = _GENITIVE_RE.match(normalized.strip())
    if not match:
        return None

    multiplier_raw = match.group(1).strip()
    unit_text = match.group(2).lower()

    # multiplier_raw may have trailing -i stripped by regex; just parse as-is
    multiplier_val = _parse_inner(multiplier_raw)
    if multiplier_val is None or multiplier_val == 0:
        return None

    if unit_text in MULTIPLIERS:
        return multiplier_val * MULTIPLIERS[unit_text]
    return None


def _parse_inner(text: str) -> int | None:
    """Parse a normalized Wolof numeral string without genitive/ordinal checks.

    Used internally by _parse_genitive to avoid re-entering the full parse_number
    path (which has loanword checks, etc.).
    """
    tokens = _tokenize(text)
    return _parse_tokens(tokens)


def _parse_tokens(tokens: list[str]) -> int | None:
    """Compose token stream into integer using Wolof composition rules.

    Grammar (additive + multiplicative):
      <expr>      := <term> (CONNECTOR <expr>)?
      <term>      := <atom> (<multiplier>)?  |  <atom> <multiplier> <...>
      <atom>      := ones | hyphenated-compound

    Simplified: scan left-to-right, accumulate with implicit multiplication
    when atom precedes a multiplier token, and explicit addition on CONNECTOR.
    """
    if not tokens:
        return None

    total = 0
    pending: int | None = None  # last parsed atom awaiting multiplier or addition
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok == CONNECTOR:
            # flush pending as added term
            if pending is None:
                return None
            total += pending
            pending = None
            i += 1
            continue

        val = _parse_atom(tok)
        if val is None:
            return None

        if pending is None:
            pending = val
        else:
            # Two atoms in sequence. If current is a magnitude-scale multiplier
            # (fukk/téeméer/junni or milyon-tier), multiply pending by it.
            # Otherwise, treat as implicit add (shouldn't happen in well-formed Wolof).
            if tok in MULTIPLIERS or tok in MILLIONS or (
                val in MULTIPLIERS.values() or val in MILLIONS.values()
            ) and val > 1:
                pending = pending * val
            else:
                # implicit addition
                total += pending
                pending = val
        i += 1

    if pending is not None:
        total += pending
    return total if total > 0 else None


def parse_number(text: str) -> ParseResult:
    """Parse a Wolof cardinal numeral string.

    Based on Guérin (2021) numeral system. Returns ParseResult with value
    always populated. Confidence=1.0 when exactly one interpretation is
    possible from the input text.

    Raises:
        UnsupportedNumeralForm: input is an ordinal, fraction, or known loanword
            (currently only bare 'alfu'/'alfii'; milyon/alfunni are accepted).
    """
    if not text or not text.strip():
        raise UnsupportedNumeralForm(kind="ordinal", raw_input=text)

    raw = text
    # Loanword detection BEFORE normalization (loanwords are not in alias table)
    stripped_lower = text.lower().strip()
    if stripped_lower in LOANWORDS or any(tok in LOANWORDS for tok in stripped_lower.split()):
        raise UnsupportedNumeralForm(kind="loanword", raw_input=raw)

    # Fraction detection: "X ci Y" pattern
    if _FRACTION_RE.search(text):
        # "ci" must be between two numeral-like tokens; sanity-check
        raise UnsupportedNumeralForm(kind="fraction", raw_input=raw)

    # Ordinal detection: suffix
    for tok in stripped_lower.split():
        if (
            _ORDINAL_RE.match(tok)
            and tok not in ONES
            and tok not in MULTIPLIERS
            and not any(tok.startswith(o) and len(tok) == len(o) for o in ONES)
        ):
            raise UnsupportedNumeralForm(kind="ordinal", raw_input=raw)

    normalized = normalize(text)

    # Genitive construction: try BEFORE tokenization (handles fused -i suffix)
    # Applied on normalized form so aliases are already resolved.
    gen_value = _parse_genitive(normalized)
    if gen_value is not None:
        return ParseResult(
            value=gen_value,
            confidence=1.0,
            alternatives=[],
            raw_input=raw,
        )

    tokens = _tokenize(normalized)
    value = _parse_tokens(tokens)

    if value is None:
        # Fallback: can't parse — still return a best-effort ParseResult with low
        # confidence and empty alternatives. Downstream HITL handles this.
        return ParseResult(
            value=0,
            confidence=0.0,
            alternatives=[],
            raw_input=raw,
        )

    return ParseResult(
        value=value,
        confidence=1.0,
        alternatives=[],
        raw_input=raw,
    )


# D-B1: parse is an alias of parse_number for the both-paths API
parse = parse_number


def parse_strict(text: str) -> int:
    """Strict-contract parser: returns int, raises on ambiguity or unsupported forms."""
    result = parse_number(text)
    if result.confidence < 1.0 and result.alternatives:
        raise AmbiguityError(raw_input=text, alternatives=result.alternatives)
    if result.confidence == 0.0:
        raise AmbiguityError(raw_input=text, alternatives=[])
    return result.value
