"""Currency phrase parsing (delegates to parser.py).

dërëm handling (Guérin 2021 §2.6):
  1 dërëm = 5 CFA francs (from Arabic "dirham").
  Commerce prices in informal Senegalese markets are often counted in dërëm.
  "juróom dërëm" (5 dërëm) = 25 XOF.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from wolof_numbers.models import AmountResult
from wolof_numbers.parser import parse_number

_DATA_DIR = Path(__file__).parent / "data"
_CURRENCY_RAW = (
    yaml.safe_load((_DATA_DIR / "currency_aliases.yaml").read_text(encoding="utf-8")) or {}
)

# Flatten: alias_lowercase -> canonical_code
CURRENCY_ALIASES: dict[str, str] = {}
for _code, _variants in _CURRENCY_RAW.items():
    CURRENCY_ALIASES[_code.lower()] = _code
    for _v in _variants or []:
        CURRENCY_ALIASES[str(_v).lower()] = _code

# Longest-first for substring matching
_ALIAS_ORDER = sorted(CURRENCY_ALIASES.keys(), key=len, reverse=True)

# dërëm variants — commerce unit: 1 dërëm = 5 XOF (Guérin 2021 §2.6)
_DEREM_VARIANTS = ("dërëm", "dërem", "derem")


def parse_currency_amount(text: str) -> AmountResult:
    """Parse a Wolof/French-code-switched currency phrase.

    Handles dërëm (×5 CFA multiplier) in addition to standard currency aliases.

    Examples:
        "ñaar junni franc CFA"   -> AmountResult(amount=2000, currency="XOF")
        "ñaar mille francs"      -> AmountResult(amount=2000, currency="XOF")
        "juróom dërëm"           -> AmountResult(amount=25, currency="XOF")
        "ñaar téeméer dërëm"     -> AmountResult(amount=1000, currency="XOF")
        "ñaar junni xaalis"      -> AmountResult(amount=2000, currency="XOF")
    """
    raw = text
    text_lower = text.lower()

    currency = "XOF"  # default in WAEMU / Senegal context
    numeric_portion = text
    derem_multiplier = 1

    # Check for dërëm FIRST (before general currency alias strip).
    # dërëm is a unit, not just a currency label — it multiplies the parsed value by 5.
    for variant in _DEREM_VARIANTS:
        if variant in text_lower:
            idx = text_lower.find(variant)
            numeric_portion = (text[:idx] + text[idx + len(variant) :]).strip()
            derem_multiplier = 5
            currency = "XOF"
            break
    else:
        # No dërëm — try standard currency aliases
        for alias in _ALIAS_ORDER:
            if alias in text_lower:
                currency = CURRENCY_ALIASES[alias]
                idx = text_lower.find(alias)
                numeric_portion = (text[:idx] + text[idx + len(alias) :]).strip()
                break

    number_result = parse_number(numeric_portion.strip())

    return AmountResult(
        amount=number_result.value * derem_multiplier,
        currency=currency,  # type: ignore[arg-type]
        confidence=number_result.confidence,
        alternatives=number_result.alternatives,
        raw_input=raw,
    )
