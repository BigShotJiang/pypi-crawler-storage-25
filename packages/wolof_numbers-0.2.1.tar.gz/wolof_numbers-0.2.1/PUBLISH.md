# wolof-numbers Publication Runbook

This document covers one-time setup and the per-release process for
`wolof-numbers` on PyPI and GitHub.

## One-Time Setup

### 1. Create public GitHub repo

Create an empty public repo at `https://github.com/kuma-labs/wolof-numbers`:

- Visibility: Public
- Initialize: **no** README, **no** .gitignore, **no** license (the subtree provides them)
- Description: "Wolof numeral and currency phrase parser (1 → 1,000,000,000). MIT. Part of Kuma Labs."

### 2. Configure PyPI Trusted Publisher

On PyPI (https://pypi.org):

1. Sign in (or create account).
2. Create a new pending publisher: **Your account → Publishing → Add a new pending publisher**.
3. Fill in the form:
   - **PyPI Project Name:** `wolof-numbers`
   - **Owner:** `kuma-labs`
   - **Repository name:** `kuma-labs` (the monorepo, not the mirror)
   - **Workflow filename:** `publish-wolof-numbers.yml`
   - **Environment name:** `pypi`
4. Confirm. No API tokens needed — OIDC handles auth.

### 3. Create the `pypi` GitHub Actions environment

In the monorepo at https://github.com/kuma-labs/kuma-labs/settings/environments:

1. Click "New environment"
2. Name: `pypi`
3. (Optional) Enable "Required reviewers" for a manual approval gate before each publish

### 4. Add git subtree remote (local, one-time)

```bash
cd /path/to/kuma-labs
git remote add wolof-numbers-public https://github.com/kuma-labs/wolof-numbers.git
```

## Per-Release Process

### 1. Bump CHANGELOG + version

- Update `packages/wolof-numbers/CHANGELOG.md` with the new version and notes.
- Update `version = "X.Y.Z"` in `packages/wolof-numbers/pyproject.toml`.
- Commit: `git commit -m "chore(wolof-numbers): bump to X.Y.Z"`.

### 2. Push subtree to public mirror

```bash
git subtree push --prefix=packages/wolof-numbers wolof-numbers-public main
```

If the subtree has diverged, use `split` first:

```bash
git subtree split --prefix=packages/wolof-numbers --branch wolof-numbers-split
git push wolof-numbers-public wolof-numbers-split:main --force
git branch -D wolof-numbers-split  # cleanup local branch
```

### 3. Tag + push → triggers PyPI publish

```bash
git tag -a wolof-numbers/vX.Y.Z -m "wolof-numbers vX.Y.Z"
git push origin wolof-numbers/vX.Y.Z
```

The `.github/workflows/publish-wolof-numbers.yml` workflow fires:
- Runs full test suite + ruff + mypy against the package
- Builds wheel + sdist via `uv build --package wolof-numbers`
- Publishes to PyPI via OIDC (no secrets)

Monitor the run at: https://github.com/kuma-labs/kuma-labs/actions

### 4. Verify publication

```bash
# In a clean environment
pip install wolof-numbers==X.Y.Z
python -c "import wolof_numbers; print(wolof_numbers.parse_number('benn'))"
# Expected: ParseResult(value=1, confidence=1.0, alternatives=[], raw_input='benn')
```

## Troubleshooting

- **Trusted Publisher rejects OIDC:** Verify environment name in workflow matches PyPI config (`pypi`). Verify workflow filename matches exactly (`publish-wolof-numbers.yml`).
- **Subtree push conflict:** Use `git subtree split --rejoin` pattern or force-push a split branch (see above).
- **Tag already exists on PyPI:** PyPI version numbers are immutable. Bump to X.Y.(Z+1) and retry.
- **`uv publish --trusted-publishing always` fails with 403:** Double-check the pending publisher form — Repository name must be `kuma-labs` (the monorepo slug), not `wolof-numbers`.
