# Changelog

All notable changes to `wolof-numbers` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to semantic versioning per the stability note in README.md.

## [0.2.1] - 2026-04-05

### Fixed
- Build: remove redundant `force-include` in `pyproject.toml` that caused
  duplicate ZIP entries for `data/*.yaml` files, rejected by PyPI. v0.2.0
  tag was created but never published — use 0.2.1.

## [0.2.0] - 2026-04-05 (not published)

### Added
- Canonical coverage port from Guérin (2021), *Système de numération en wolof*
- `fanweer`/`fanwer` → 30 (dominant Senegalese form, "lunar month" etymology)
- `nit` → 20 (archaic form meaning "individu")
- Million lexemes: `milyoŋ`, `milyon`, `tamndareet`, `alfunni`, `alfun` → 1,000,000
- Genitive construction parser: `ñaari téeméer` → 200, `juróom-benn-i junni` → 6000
- `dërëm` commerce unit (×5 CFA per Arabic "dirham"): `juróom dërëm` → 25 XOF
- `xaalis` and `frank` added to XOF currency aliases
- `extract_amounts(text) -> list[ScannerHit]` — transcript scanner for audio streams
- `ScannerHit` typed result model with character spans
- Kobès 1869 dialectal variants: `yaar` → 2, `yett` → 3

### Fixed
- `milyon` / `alfunni` no longer raise `UnsupportedNumeralForm("loanword")` —
  these are fully-naturalized Wolof million-words per Guérin §2.2, not rejected loanwords
- Bare `alfu` / `alfii` still correctly raise `UnsupportedNumeralForm`

### Coverage
- 350 tests passing (up from 310 in v0.1.0)

## [0.1.0] - 2026-04-05

### Added
- Recursive-descent cardinal numeral parser, range 1 to 1,000,000,000
- `parse_number(str) -> ParseResult` and `parse_strict(str) -> int` entrypoints
- `parse_currency_amount(str) -> AmountResult` for XOF/FCFA/CFA phrases
- Orthographic alias table (~100 variants) with diacritic-insensitive matching
- Typed Pydantic result models: `ParseResult`, `AmountResult`, `Interpretation`
- Exception hierarchy: `AmbiguityError`, `UnsupportedNumeralForm`
- Code-switched Wolof↔French currency forms (`ñaar mille francs`)

### Known Limitations (v0.2 targets)
- Ordinals (e.g. `ñaaréél`) raise `UnsupportedNumeralForm(kind="ordinal")`
- Fractions (e.g. `genn ci ñaar`) raise `UnsupportedNumeralForm(kind="fraction")`
- Arabic loanwords (e.g. `alfu`) raise `UnsupportedNumeralForm(kind="loanword")`
