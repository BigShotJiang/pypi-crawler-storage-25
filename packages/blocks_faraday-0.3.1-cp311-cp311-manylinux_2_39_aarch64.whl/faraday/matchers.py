"""Match predicates and helpers used by compiled policy rules."""
from __future__ import annotations

import os
import re
from pathlib import PurePosixPath
from typing import Iterable

_URL_HOST_RE = re.compile(r"\bhttps?://([^\s/:?#]+)", re.IGNORECASE)


def to_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def basename(path: str) -> str:
    return PurePosixPath(path).name


def extract_hosts(strings: Iterable[str]) -> list[str]:
    out: list[str] = []
    for s in strings:
        for m in _URL_HOST_RE.finditer(s):
            out.append(m.group(1).lower())
    return out


def fnmatch_compile(pattern: str) -> re.Pattern[str]:
    """Shell-style glob → regex (full-string match).

    Semantics match git/bash globstar:
      - `*`  matches any chars EXCEPT `/`
      - `**` matches any chars (including `/`)
      - `?`  matches one non-`/` char
      - `[abc]`, `[!abc]` character classes
      - `${VAR}` and `$VAR` are env-expanded at compile time
    """
    pattern = os.path.expandvars(pattern)
    parts: list[str] = []
    i, n = 0, len(pattern)
    while i < n:
        c = pattern[i]
        if c == "*":
            if i + 1 < n and pattern[i + 1] == "*":
                parts.append(".*")
                i += 2
            else:
                parts.append("[^/]*")
                i += 1
        elif c == "?":
            parts.append("[^/]")
            i += 1
        elif c == "[":
            j = pattern.find("]", i + 1)
            if j == -1:
                parts.append(re.escape(c))
                i += 1
            else:
                inner = pattern[i + 1 : j]
                if inner.startswith("!"):
                    inner = "^" + inner[1:]
                parts.append("[" + inner + "]")
                i = j + 1
        else:
            parts.append(re.escape(c))
            i += 1
    return re.compile("".join(parts) + r"\Z")
