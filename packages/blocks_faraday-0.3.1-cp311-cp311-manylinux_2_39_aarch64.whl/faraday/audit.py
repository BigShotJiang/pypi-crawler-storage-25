"""JSONL audit log for verdict events."""
from __future__ import annotations

import json
import time
from pathlib import Path
from threading import Lock
from typing import IO


class AuditLog:
    def __init__(self, path: str | Path | None) -> None:
        self.path = Path(path) if path else None
        self._lock = Lock()
        self._fp: IO[str] | None = None

    def open(self) -> None:
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fp = open(self.path, "a", encoding="utf-8")

    def close(self) -> None:
        if self._fp:
            self._fp.close()
            self._fp = None

    def record(self, event: dict, verdict) -> None:
        if self._fp is None:
            return
        line = {
            "ts": time.time(),
            "event": "execve",
            "pid": event.get("pid"),
            "exe": event.get("exe"),
            "argv": event.get("argv"),
            "cwd": event.get("cwd"),
            "ppid": event.get("ppid"),
            "action": verdict.action,
            "rule_id": verdict.rule_id,
            "reason": verdict.reason,
        }
        encoded = json.dumps(line, separators=(",", ":")) + "\n"
        with self._lock:
            self._fp.write(encoded)
            self._fp.flush()

    def record_sandbox_config(self, fields: dict) -> None:
        """Record a one-shot startup record describing the *requested*
        sandbox configuration.

        ``fields`` is merged with ``{"event": "sandbox_config", "ts": …}``.
        Emitted by the parent CLI before the child installs seccomp +
        Landlock, so it describes intent — not verified enforcement. If the
        child fails to install kernel filters, a separate failure path
        surfaces that; this record is not retracted.
        """
        self.record_typed("sandbox_config", fields)

    def record_typed(self, event_type: str, fields: dict) -> None:
        """Record an arbitrary typed event. Used by the kernel-pin notif
        loop to log per-deny ``net`` entries with sockaddr context."""
        if self._fp is None:
            return
        line = {"ts": time.time(), "event": event_type, **fields}
        encoded = json.dumps(line, separators=(",", ":")) + "\n"
        with self._lock:
            self._fp.write(encoded)
            self._fp.flush()

    def __enter__(self) -> "AuditLog":
        self.open()
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
