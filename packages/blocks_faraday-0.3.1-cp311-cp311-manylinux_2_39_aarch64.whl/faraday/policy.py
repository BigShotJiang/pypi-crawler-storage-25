"""Policy load and verdict evaluation.

Rules are evaluated top-to-bottom; first match wins. Match keys within a rule
are ANDed (all must hit). Missing key = wildcard. Suffix `_not` negates.
"""

from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

from . import matchers

Action = Literal["allow", "deny"]


def _eq_factory(values):
    s = set(matchers.to_list(values))
    return lambda v: v in s


def _basename_factory(values):
    s = set(matchers.to_list(values))
    return lambda exe: matchers.basename(exe) in s


def _glob_factory(values):
    pats = [matchers.fnmatch_compile(p) for p in matchers.to_list(values)]
    return lambda path: any(p.match(path) is not None for p in pats)


def _argv_regex_factory(values):
    pats = [re.compile(p) for p in matchers.to_list(values)]
    return lambda argv: any(p.search(" ".join(argv)) for p in pats)


def _argv_contains_factory(values):
    needles = matchers.to_list(values)
    return lambda argv: any(n in " ".join(argv) for n in needles)


def _argv_host_factory(values):
    allowed = {h.lower() for h in matchers.to_list(values)}
    return lambda argv: any(h in allowed for h in matchers.extract_hosts(argv))


def _uid_factory(values):
    s = {int(v) for v in matchers.to_list(values)}
    return lambda uid: int(uid) in s


# key -> (event_field, factory(values)->predicate)
_MATCH_KEYS: dict[str, tuple[str, Callable[[Any], Callable[[Any], bool]]]] = {
    "exe": ("exe", _eq_factory),
    "exe_basename": ("exe", _basename_factory),
    "exe_glob": ("exe", _glob_factory),
    "argv_regex": ("argv", _argv_regex_factory),
    "argv_contains": ("argv", _argv_contains_factory),
    "argv_host_in": ("argv", _argv_host_factory),
    "cwd_glob": ("cwd", _glob_factory),
    "uid": ("uid", _uid_factory),
    "parent_exe": ("parent_exe", _eq_factory),
    "parent_argv": ("parent_argv", _argv_regex_factory),
}


class PolicyError(Exception):
    """Raised when a policy file is invalid (load-time only)."""


@dataclass(frozen=True)
class Verdict:
    action: Action
    rule_id: str
    reason: str = ""


@dataclass
class _CompiledMatcher:
    field: str
    test: Callable[[Any], bool]
    negated: bool

    def __call__(self, event: dict[str, Any]) -> bool:
        val = event.get(self.field)
        hit = False if val is None else self.test(val)
        return (not hit) if self.negated else hit


@dataclass
class Rule:
    id: str
    action: Action
    reason: str
    matchers: list[_CompiledMatcher] = field(default_factory=list)

    def matches(self, event: dict[str, Any]) -> bool:
        return all(m(event) for m in self.matchers)


@dataclass(frozen=True)
class FilesystemConfig:
    """Parsed ``[filesystem]`` block.
    the Rust child process. Absent block => ``FilesystemConfig()`` (no
    Landlock applied, fully backward-compatible).
    """

    read_globs: tuple[str, ...] = ()
    write_globs: tuple[str, ...] = ()
    allow_globs: tuple[str, ...] = ()
    require_enforced: bool = True
    no_bootstrap_reads: bool = False

    @property
    def is_empty(self) -> bool:
        return not (self.read_globs or self.write_globs or self.allow_globs)


@dataclass(frozen=True)
class EndpointRule:
    method: str
    path: str


@dataclass(frozen=True)
class RouteConfig:
    prefix: str
    upstream: str
    credential_key: str = ""
    inject_mode: str = "header"
    inject_header: str = "Authorization"
    credential_format: str = "Bearer {}"
    env_var: str = ""
    endpoint_rules: tuple[EndpointRule, ...] = ()


@dataclass(frozen=True)
class NetworkConfig:
    """Parsed ``[network]`` block.
    network filtering proxy in the Rust supervisor. Absent block =>
    ``NetworkConfig()`` (no network filtering, fully backward-compatible).
    """

    block_all: bool = False
    allowed_hosts: tuple[str, ...] = ()
    allowed_endpoints: tuple[str, ...] = ()
    routes: tuple[RouteConfig, ...] = ()
    proxy_port: int = 0
    kernel_pin: bool = False
    allowed_local_ports: tuple[int, ...] = ()

    @property
    def is_empty(self) -> bool:
        return not (
            self.block_all
            or self.allowed_hosts
            or self.allowed_endpoints
            or self.routes
            or self.kernel_pin
            or self.allowed_local_ports
        )


@dataclass
class Policy:
    version: int
    default_action: Action
    on_policy_error: Action
    on_supervisor_timeout_ms: int
    rules: list[Rule] = field(default_factory=list)
    filesystem: FilesystemConfig = field(default_factory=FilesystemConfig)
    network: NetworkConfig = field(default_factory=NetworkConfig)

    def verdict(self, event: dict[str, Any]) -> Verdict:
        for rule in self.rules:
            if rule.matches(event):
                return Verdict(rule.action, rule.id, rule.reason)
        return Verdict(self.default_action, "<default>", "no rule matched")


def load_policy(path: str | Path) -> Policy:
    p = Path(path)
    try:
        with open(p, "rb") as f:
            raw = tomllib.load(f)
    except FileNotFoundError:
        raise PolicyError(f"policy file not found: {p}") from None
    except tomllib.TOMLDecodeError as e:
        raise PolicyError(f"policy {p}: TOML parse error: {e}") from e
    return _build_policy(raw, source=str(p))


def load_policy_str(data: str, source: str = "<inline>") -> Policy:
    try:
        raw = tomllib.loads(data)
    except tomllib.TOMLDecodeError as e:
        raise PolicyError(f"policy {source}: TOML parse error: {e}") from e
    return _build_policy(raw, source=source)


def _build_policy(raw: dict[str, Any], *, source: str) -> Policy:
    meta = raw.get("meta") or {}
    version = int(meta.get("version", 1))
    if version != 1:
        raise PolicyError(f"{source}: unsupported policy version: {version}")

    default_action = _coerce_action(
        meta.get("default_action", "deny"), f"{source}: meta.default_action"
    )
    on_policy_error = _coerce_action(
        meta.get("on_policy_error", "deny"), f"{source}: meta.on_policy_error"
    )
    timeout_ms = int(meta.get("on_supervisor_timeout_ms", 250))
    if timeout_ms <= 0:
        raise PolicyError(f"{source}: on_supervisor_timeout_ms must be positive")

    rules: list[Rule] = []
    seen_ids: set[str] = set()
    for i, raw_rule in enumerate(raw.get("rule", [])):
        rule = _compile_rule(raw_rule, i, source)
        if rule.id in seen_ids:
            raise PolicyError(f"{source}: duplicate rule id {rule.id!r}")
        seen_ids.add(rule.id)
        rules.append(rule)

    fs_cfg = _parse_filesystem(raw.get("filesystem"), source)
    net_cfg = _parse_network(raw.get("network"), source)

    return Policy(
        version=version,
        default_action=default_action,
        on_policy_error=on_policy_error,
        on_supervisor_timeout_ms=timeout_ms,
        rules=rules,
        filesystem=fs_cfg,
        network=net_cfg,
    )


_FS_KEYS = frozenset(
    {
        "read_globs",
        "write_globs",
        "allow_globs",
        "require_enforced",
        "no_bootstrap_reads",
    }
)


def _parse_filesystem(raw, source: str) -> FilesystemConfig:
    if raw is None:
        return FilesystemConfig()
    if not isinstance(raw, dict):
        raise PolicyError(f"{source}: [filesystem] must be a table")
    unknown = set(raw.keys()) - _FS_KEYS
    if unknown:
        raise PolicyError(
            f"{source}: unknown key(s) in [filesystem]: {sorted(unknown)!r}"
        )

    def _str_list(key: str) -> tuple[str, ...]:
        v = raw.get(key, [])
        if isinstance(v, str):
            v = [v]
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            raise PolicyError(f"{source}: [filesystem].{key} must be a list of strings")
        return tuple(v)

    require_enforced = raw.get("require_enforced", True)
    if not isinstance(require_enforced, bool):
        raise PolicyError(f"{source}: [filesystem].require_enforced must be bool")
    no_bootstrap_reads = raw.get("no_bootstrap_reads", False)
    if not isinstance(no_bootstrap_reads, bool):
        raise PolicyError(f"{source}: [filesystem].no_bootstrap_reads must be bool")

    return FilesystemConfig(
        read_globs=_str_list("read_globs"),
        write_globs=_str_list("write_globs"),
        allow_globs=_str_list("allow_globs"),
        require_enforced=require_enforced,
        no_bootstrap_reads=no_bootstrap_reads,
    )


_NET_KEYS = frozenset(
    {
        "block_all",
        "allowed_hosts",
        "allowed_endpoints",
        "routes",
        "proxy_port",
        "kernel_pin",
        "allowed_local_ports",
    }
)


def _parse_routes(raw, source: str) -> tuple[RouteConfig, ...]:
    if raw is None:
        return ()
    if not isinstance(raw, dict):
        raise PolicyError(f"{source}: [network].routes must be a table")

    out: list[RouteConfig] = []
    allowed_modes = {"header", "url_path", "query_param", "basic_auth"}

    def _as_str_or_default(value, where: str, default: str) -> str:
        if value is None:
            return default
        if not isinstance(value, str):
            raise PolicyError(f"{where} must be string")
        return value

    for prefix, body in raw.items():
        where = f"{source}: [network.routes.{prefix}]"
        if not isinstance(prefix, str) or not prefix:
            raise PolicyError(
                f"{source}: [network].routes keys must be non-empty strings"
            )
        if not prefix.isascii():
            raise PolicyError(f"{where}: route prefix must be ASCII")
        if "/" in prefix:
            raise PolicyError(f"{where}: route prefix must not contain '/'")
        if not isinstance(body, dict):
            raise PolicyError(f"{where} must be a table")

        upstream = body.get("upstream")
        if not isinstance(upstream, str) or not upstream:
            raise PolicyError(f"{where}.upstream must be a non-empty string")
        if not (upstream.startswith("http://") or upstream.startswith("https://")):
            raise PolicyError(f"{where}.upstream must start with http:// or https://")

        inject_mode = _as_str_or_default(
            body.get("inject_mode"), f"{where}.inject_mode", "header"
        )
        if inject_mode not in allowed_modes:
            raise PolicyError(
                f"{where}.inject_mode must be one of {sorted(allowed_modes)!r}"
            )

        endpoint_rules_raw = body.get("endpoint_rules", [])
        if not isinstance(endpoint_rules_raw, list):
            raise PolicyError(f"{where}.endpoint_rules must be a list")
        endpoint_rules: list[EndpointRule] = []
        for i, rule in enumerate(endpoint_rules_raw):
            if not isinstance(rule, dict):
                raise PolicyError(f"{where}.endpoint_rules[{i}] must be a table")
            method = rule.get("method")
            path = rule.get("path")
            if not isinstance(method, str) or not method:
                raise PolicyError(
                    f"{where}.endpoint_rules[{i}].method must be a non-empty string"
                )
            if not isinstance(path, str) or not path:
                raise PolicyError(
                    f"{where}.endpoint_rules[{i}].path must be a non-empty string"
                )
            endpoint_rules.append(EndpointRule(method=method, path=path))

        out.append(
            RouteConfig(
                prefix=prefix,
                upstream=upstream,
                credential_key=_as_str_or_default(
                    body.get("credential_key"), f"{where}.credential_key", ""
                ),
                inject_mode=inject_mode,
                inject_header=_as_str_or_default(
                    body.get("inject_header"), f"{where}.inject_header", "Authorization"
                ),
                credential_format=_as_str_or_default(
                    body.get("credential_format"),
                    f"{where}.credential_format",
                    "Bearer {}",
                ),
                env_var=_as_str_or_default(body.get("env_var"), f"{where}.env_var", ""),
                endpoint_rules=tuple(endpoint_rules),
            )
        )

    return tuple(sorted(out, key=lambda r: r.prefix))


def _parse_network(raw, source: str) -> NetworkConfig:
    if raw is None:
        return NetworkConfig()
    if not isinstance(raw, dict):
        raise PolicyError(f"{source}: [network] must be a table")
    unknown = set(raw.keys()) - _NET_KEYS
    if unknown:
        raise PolicyError(f"{source}: unknown key(s) in [network]: {sorted(unknown)!r}")

    block_all = raw.get("block_all", False)
    if not isinstance(block_all, bool):
        raise PolicyError(f"{source}: [network].block_all must be bool")

    def _str_list(key: str) -> tuple[str, ...]:
        v = raw.get(key, [])
        if isinstance(v, str):
            v = [v]
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            raise PolicyError(f"{source}: [network].{key} must be a list of strings")
        return tuple(v)

    raw_port = raw.get("proxy_port", 0)
    if isinstance(raw_port, bool) or not isinstance(raw_port, int):
        raise PolicyError(f"{source}: [network].proxy_port must be int")
    if raw_port < 0 or raw_port > 65535:
        raise PolicyError(f"{source}: [network].proxy_port must be 0-65535")
    proxy_port = raw_port

    kernel_pin = raw.get("kernel_pin", False)
    if not isinstance(kernel_pin, bool):
        raise PolicyError(f"{source}: [network].kernel_pin must be bool")

    raw_local_ports = raw.get("allowed_local_ports", [])
    if not isinstance(raw_local_ports, list) or any(
        isinstance(p, bool) or not isinstance(p, int) for p in raw_local_ports
    ):
        raise PolicyError(
            f"{source}: [network].allowed_local_ports must be a list of int"
        )
    for p in raw_local_ports:
        if p < 1 or p > 65535:
            raise PolicyError(
                f"{source}: [network].allowed_local_ports entries must be 1-65535"
            )
    allowed_local_ports = tuple(raw_local_ports)

    if kernel_pin and block_all:
        raise PolicyError(
            f"{source}: [network].kernel_pin cannot be combined with block_all "
            "(no proxy is started in block_all mode)"
        )

    return NetworkConfig(
        block_all=block_all,
        allowed_hosts=_str_list("allowed_hosts"),
        allowed_endpoints=_str_list("allowed_endpoints"),
        routes=_parse_routes(raw.get("routes"), source),
        proxy_port=proxy_port,
        kernel_pin=kernel_pin,
        allowed_local_ports=allowed_local_ports,
    )


def _coerce_action(value, where: str) -> Action:
    if value not in ("allow", "deny"):
        raise PolicyError(f"{where} must be 'allow' or 'deny', got {value!r}")
    return value  # type: ignore[return-value]


_RESERVED = frozenset({"id", "action", "reason"})


def _compile_rule(raw: dict[str, Any], index: int, source: str) -> Rule:
    if not isinstance(raw, dict):
        raise PolicyError(f"{source}: rule[{index}] must be a table")
    if "id" not in raw:
        raise PolicyError(f"{source}: rule[{index}] missing 'id'")
    rule_id = raw["id"]
    if not isinstance(rule_id, str) or not rule_id:
        raise PolicyError(f"{source}: rule[{index}] id must be a non-empty string")
    where = f"{source}: rule[{rule_id}]"

    if "action" not in raw:
        raise PolicyError(f"{where} missing 'action'")
    action = _coerce_action(raw["action"], f"{where}.action")
    reason = str(raw.get("reason", ""))

    compiled: list[_CompiledMatcher] = []
    for key, value in raw.items():
        if key in _RESERVED:
            continue
        negated = key.endswith("_not")
        base_key = key[:-4] if negated else key
        if base_key not in _MATCH_KEYS:
            raise PolicyError(f"{where} unknown match key: {key!r}")
        field_name, factory = _MATCH_KEYS[base_key]
        try:
            test = factory(value)
        except (re.error, TypeError, ValueError) as e:
            raise PolicyError(f"{where} invalid value for {key!r}: {e}") from e
        compiled.append(_CompiledMatcher(field=field_name, test=test, negated=negated))

    return Rule(id=rule_id, action=action, reason=reason, matchers=compiled)
