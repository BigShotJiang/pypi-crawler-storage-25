"""Rust↔Python bridge. The embedded supervisor calls into here per execve.

Public surface:
- init(policy_path, audit_path=None, cli_read=None, cli_write=None, cli_allow=None)
  Load policy, open audit log, and compile the Landlock grant set from the
  TOML ``[filesystem]`` block merged with CLI ``--read/--write/--allow``
  flags. Returns ``{"landlock_grants": [(path, mode), ...], "require_enforced": bool}``
  for the Rust side to consume. Returns ``None``-ish (empty dict) if no
  Landlock grants are configured (backward-compatible).
- reload(policy_path): atomic policy swap; old policy survives parse errors
- evaluate(event_dict) -> Verdict: per-execve hot path, NEVER raises
- default_action() / supervisor_timeout_ms(): startup config queries
"""

from __future__ import annotations

import sys
import traceback
import warnings
from threading import RLock
from typing import Any, Optional, Sequence

from . import fs_grants
from .audit import AuditLog
from .policy import Policy, Verdict, load_policy

_lock = RLock()
_policy: Policy | None = None
_audit: AuditLog | None = None


def init(
    policy_path: str,
    audit_path: Optional[str] = None,
    cli_read: Optional[Sequence[str]] = None,
    cli_write: Optional[Sequence[str]] = None,
    cli_allow: Optional[Sequence[str]] = None,
) -> dict[str, Any]:
    """Initialize policy + audit + compile Landlock grants.

    Returns a dict consumed by the Rust CLI:

    ```python
    {
        "landlock_grants": [("/tmp", "rw"), ("/usr", "read"), ...],
        "require_enforced": True,
    }
    ```

    When no grants are configured (no ``[filesystem]`` block in TOML and no
    ``--read/--write/--allow`` CLI flags), returns ``{"landlock_grants": [],
    "require_enforced": True}`` and Rust skips Landlock entirely — fully
    backward-compatible.
    """
    global _policy, _audit
    with _lock:
        _policy = load_policy(policy_path)
        if _audit is not None:
            _audit.close()
        _audit = AuditLog(audit_path)
        _audit.open()

        fs_cfg = _policy.filesystem
        net_cfg = _policy.network
        read_globs = list(fs_cfg.read_globs) + list(cli_read or ())
        write_globs = list(fs_cfg.write_globs) + list(cli_write or ())
        allow_globs = list(fs_cfg.allow_globs) + list(cli_allow or ())
        # Build base result dict
        result: dict[str, Any] = {
            "landlock_grants": [],
            "require_enforced": fs_cfg.require_enforced,
        }

        # Add network config if present in TOML
        if not net_cfg.is_empty:
            result["network"] = {
                "block_all": net_cfg.block_all,
                "allowed_hosts": list(net_cfg.allowed_hosts),
                "allowed_endpoints": list(net_cfg.allowed_endpoints),
                "routes": [
                    {
                        "prefix": r.prefix,
                        "upstream": r.upstream,
                        "credential_key": r.credential_key,
                        "inject_mode": r.inject_mode,
                        "inject_header": r.inject_header,
                        "credential_format": r.credential_format,
                        "env_var": r.env_var,
                        "endpoint_rules": [
                            {"method": er.method, "path": er.path}
                            for er in r.endpoint_rules
                        ],
                    }
                    for r in net_cfg.routes
                ],
                "proxy_port": net_cfg.proxy_port,
                "kernel_pin": net_cfg.kernel_pin,
                "allowed_local_ports": list(net_cfg.allowed_local_ports),
            }
        if not (read_globs or write_globs or allow_globs):
            return result
        compiled = fs_grants.compile_grants(
            read_globs=read_globs,
            write_globs=write_globs,
            allow_globs=allow_globs,
        )
        # Warn on any widened grants so users don't quietly get more than
        # they asked for.
        for g in compiled:
            if g.widened:
                warnings.warn(
                    f"fs grant for {g.path!r} widened from a sub-component "
                    "glob (e.g. /etc/*.conf \u2192 /etc). Landlock cannot gate "
                    "mid-component patterns; granting the static prefix.",
                    RuntimeWarning,
                    stacklevel=2,
                )
        # Bootstrap reads: needed so the agent binary + dynamic linker can
        # still function. Skipped if user opts out.
        if not fs_cfg.no_bootstrap_reads:
            compiled = fs_grants.minimize_grants(
                compiled + fs_grants.bootstrap_read_grants()
            )

        result["landlock_grants"] = [g.as_tuple() for g in compiled]
        return result


def reload(policy_path: str) -> None:
    global _policy
    new_policy = load_policy(policy_path)
    with _lock:
        _policy = new_policy


def audit_sandbox_config(fields: dict[str, Any]) -> None:
    """Record a one-shot ``sandbox_config`` audit entry. Called once by the
    parent CLI after the proxy has bound but **before** the child installs
    seccomp + Landlock — so the record describes the *requested*
    configuration, not verified enforcement. Never raises into Rust."""
    with _lock:
        audit = _audit
    if audit is None:
        return
    try:
        audit.record_sandbox_config(fields)
    except Exception:  # noqa: BLE001
        traceback.print_exc(file=sys.stderr)


def audit_network_event(fields: dict[str, Any]) -> None:
    """Record a connect/bind seccomp-decision audit entry. Never raises.

    ``fields`` should include at least ``syscall``, ``action``, ``dst_addr``,
    ``dst_port``, and ``rule_id``.
    """
    with _lock:
        audit = _audit
    if audit is None:
        return
    try:
        audit.record_typed("net", fields)
    except Exception:  # noqa: BLE001
        traceback.print_exc(file=sys.stderr)


def evaluate(event: dict[str, Any]) -> Verdict:
    with _lock:
        policy = _policy
        audit = _audit
    if policy is None:
        return Verdict("deny", "<uninitialized>", "policy not loaded")
    try:
        v = policy.verdict(event)
    except Exception:  # noqa: BLE001 — defensive: never raise into Rust
        traceback.print_exc(file=sys.stderr)
        v = Verdict("deny", "<error>", "policy raised; using on_policy_error")
    if audit is not None:
        try:
            audit.record(event, v)
        except Exception:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
    return v


def default_action() -> str:
    with _lock:
        return _policy.default_action if _policy else "deny"


def supervisor_timeout_ms() -> int:
    with _lock:
        return _policy.on_supervisor_timeout_ms if _policy else 250
