"""Filesystem grant compilation for Landlock sealing.

Users specify *globs* in the policy TOML or on the CLI; this module compiles
each glob down to a concrete directory-prefix path that Landlock's
``PathBeneath`` rule can gate. Glob logic lives in Python; the Rust side
(`faraday-core`'s ``landlock.rs``) simply consumes resolved absolute paths.

Widening semantics (documented in the plan and the README):

- ``/tmp/**`` → grant ``/tmp`` subtree. Matches user intent exactly.
- ``${HOME}/project/src/**/*.py`` → grant ``${HOME}/project/src`` subtree.
  **Over-permissive** relative to the glob but safe: always a superset of
  what the glob would match. Callers expecting file-level precision should
  split their globs or use explicit literal paths.
- ``/etc/ssl/cert.pem`` (no glob chars) → grant that single path as a file
  grant. Landlock supports per-file grants.
- ``/etc/*.conf`` (glob mid-path) → grant ``/etc`` (widened). A warning is
  emitted by the caller.
- Any pattern containing ``..`` raises :class:`PolicyError` at load time.
"""
from __future__ import annotations

import os
import pathlib
from dataclasses import dataclass
from typing import Iterable, Literal

from .policy import PolicyError

Mode = Literal["read", "write", "rw"]

_GLOB_CHARS = frozenset("*?[")


@dataclass(frozen=True)
class Grant:
    """A single compiled filesystem grant."""
    path: str
    mode: Mode
    widened: bool = False  # True if the static prefix is broader than the glob

    def as_tuple(self) -> tuple[str, str]:
        return (self.path, self.mode)


def _has_glob(part: str) -> bool:
    return any(c in part for c in _GLOB_CHARS)


def compile_glob(pattern: str) -> Grant:
    """Compile a single glob string into a :class:`Grant` (mode left to caller).

    The ``mode`` field of the returned grant is a placeholder — callers
    overwrite it via :func:`compile_grants`. This exists as its own function
    to make the glob→path mapping testable in isolation.
    """
    if not pattern:
        raise PolicyError("empty glob pattern")
    expanded = os.path.expandvars(os.path.expanduser(pattern))
    pp = pathlib.PurePosixPath(expanded)
    if ".." in pp.parts:
        raise PolicyError(f"glob {pattern!r} contains '..' (ambiguous)")
    if not pp.is_absolute():
        raise PolicyError(
            f"glob {pattern!r} must be absolute after ${{VAR}}/~ expansion "
            f"(got {expanded!r})"
        )

    static_parts: list[str] = []
    widened = False
    for part in pp.parts:
        if _has_glob(part):
            widened = True
            break
        static_parts.append(part)

    if not static_parts or static_parts == ["/"]:
        raise PolicyError(
            f"glob {pattern!r} has no static prefix (would grant '/')"
        )

    # Detect "widened" patterns: a trailing `/**` is the canonical "grant
    # everything under this dir" form; anything else with glob chars in a
    # non-trailing component is a widening (e.g., /etc/*.conf → /etc).
    # The simple rule: if the original glob had any glob chars, AND the
    # first globbed component is not a terminal `**`, it's widened.
    if widened:
        # Find the first globbed component.
        globbed_parts = [p for p in pp.parts if _has_glob(p)]
        # Canonical "/dir/**" is a single `**` as the last component.
        if not (len(globbed_parts) == 1 and pp.parts[-1] == "**"):
            # widened stays True — caller will warn.
            pass
        else:
            widened = False  # Exact-intent match.

    static_path = str(pathlib.PurePosixPath(*static_parts))
    return Grant(path=static_path, mode="read", widened=widened)


def compile_grants(
    read_globs: Iterable[str] = (),
    write_globs: Iterable[str] = (),
    allow_globs: Iterable[str] = (),
) -> list[Grant]:
    """Compile read/write/allow glob lists into a minimized list of grants.

    - ``allow_globs`` is shorthand for read+write.
    - Overlapping grants with different modes are union'd (``read+write → rw``).
    - Nested grants of the same-or-weaker mode are dropped (the parent covers them).
    """
    raw: list[Grant] = []
    for pat in read_globs:
        g = compile_glob(pat)
        raw.append(Grant(path=g.path, mode="read", widened=g.widened))
    for pat in write_globs:
        g = compile_glob(pat)
        raw.append(Grant(path=g.path, mode="write", widened=g.widened))
    for pat in allow_globs:
        g = compile_glob(pat)
        raw.append(Grant(path=g.path, mode="rw", widened=g.widened))
    return minimize_grants(raw)


def _mode_union(a: Mode, b: Mode) -> Mode:
    if a == b:
        return a
    if "rw" in (a, b):
        return "rw"
    # one read, one write → rw
    return "rw"


def _is_ancestor_of(ancestor: str, child: str) -> bool:
    """True if `ancestor` is a strict-or-equal path ancestor of `child`.

    Uses component-wise comparison via :class:`pathlib.PurePosixPath` to
    avoid the ``"/home".startswith("/home")`` → ``"/homeevil"`` class of bug.

    Defense in depth: inputs are syntactically normalized via
    :func:`os.path.normpath` so any stray ``.`` or duplicate-slash segments
    don't break component-wise comparison. ``..`` is rejected upstream in
    :func:`compile_glob`, but :func:`minimize_grants` is public and callers
    could in principle construct :class:`Grant` objects directly. Note we
    deliberately use ``normpath`` (syntactic) rather than ``Path.resolve()``
    (filesystem touch): the authoritative resolution happens on the Rust
    side inside ``PathFd::new`` — duplicating it here would only add a
    TOCTOU window.
    """
    a = pathlib.PurePosixPath(os.path.normpath(ancestor))
    c = pathlib.PurePosixPath(os.path.normpath(child))
    try:
        c.relative_to(a)
        return True
    except ValueError:
        return False


def minimize_grants(grants: list[Grant]) -> list[Grant]:
    """Collapse the grant list:

    1. Union modes for grants on the exact same path.
    2. Drop any grant whose path is a descendant of another grant with a
       mode at least as strong.

    Preserves widened flags (OR across merges).
    """
    # Step 1: group by path, union modes.
    by_path: dict[str, Grant] = {}
    for g in grants:
        prev = by_path.get(g.path)
        if prev is None:
            by_path[g.path] = g
        else:
            by_path[g.path] = Grant(
                path=g.path,
                mode=_mode_union(prev.mode, g.mode),
                widened=prev.widened or g.widened,
            )

    # Step 2: drop descendants whose mode is covered by an ancestor's mode.
    # A grant at /tmp with mode 'rw' dominates one at /tmp/sub with any mode.
    # A grant at /tmp with mode 'read' dominates /tmp/sub with mode 'read',
    # but does NOT dominate /tmp/sub with mode 'write' — keep both there.
    kept: list[Grant] = []
    # Sort shortest path first so ancestors are considered before descendants.
    for g in sorted(by_path.values(), key=lambda x: len(pathlib.PurePosixPath(x.path).parts)):
        dominated = False
        for k in kept:
            if k.path == g.path:
                continue
            if _is_ancestor_of(k.path, g.path) and _mode_dominates(k.mode, g.mode):
                dominated = True
                break
        if not dominated:
            kept.append(g)
    return kept


def _mode_dominates(ancestor: Mode, descendant: Mode) -> bool:
    """True iff an ancestor grant with ``ancestor`` mode covers everything a
    descendant grant with ``descendant`` mode would permit."""
    if ancestor == "rw":
        return True
    return ancestor == descendant


# -- Bootstrap reads -----------------------------------------------------------

# Directories the agent binary + dynamic linker will need. Grant read-only
# unless the caller opts out via [filesystem] no_bootstrap_reads = true.
# These are only added if at least one user grant is present (i.e. Landlock
# is being applied). Missing paths are silently skipped — distros vary.
_BOOTSTRAP_READS = (
    "/usr",
    "/lib",
    "/lib64",
    "/bin",
    "/sbin",
    "/etc/ld.so.cache",
    "/etc/ld.so.conf",
    "/etc/ld.so.conf.d",
    "/proc/self",
    "/dev/null",
    "/dev/urandom",
)


def bootstrap_read_grants() -> list[Grant]:
    """Return the implicit read-only bootstrap grants (existing paths only)."""
    out: list[Grant] = []
    for p in _BOOTSTRAP_READS:
        if os.path.exists(p):
            out.append(Grant(path=p, mode="read"))
    return out
