# ruff: noqa: D100
# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

import sys
import os
import importlib.metadata
from typing import List
import warnings
from packaging.version import Version

from sphinx.application import Sphinx
from sphinx.directives.code import CodeBlock

project = 'sentinel-cpu'
copyright = '2024, William D. Jones'
author = 'William D. Jones'
release = '0.1.0'

# Don't hide DeprecationWarnings:
# https://docs.python.org/3/library/warnings.html#overriding-the-default-filter
warnings.simplefilter("default")

try:
    sent_ver = Version(importlib.metadata.version("sentinel_cpu"))
    am_ver = Version(importlib.metadata.version("amaranth"))
    # riscof_ver = Version(importlib.metadata.version("riscof"))
    importlib.metadata.version("bronzebeard")  # check for -G examples, since
    # we document the attosoc module.
except importlib.metadata.PackageNotFoundError as e:
    msg = "run \"pdm install -G doc -G examples\" before building docs"
    raise RuntimeError(msg) from e

if am_ver.is_devrelease:
    # If I get "(exception: '<' not supported between instances of 'dict' and
    # 'dict')", it's because of this:
    # https://github.com/sphinx-doc/sphinx/issues/11466
    # We'll have to remove the docs manually for now...
    am_ver = "latest"
else:
    am_ver = f"v{am_ver.public}"

# https://github.com/amaranth-lang/amaranth/commit/e356ee2cac1f4b12339cd1a16f328510e6407b87
version = str(sent_ver).replace(".editable", "")
release = sent_ver.public
author = 'William D. Jones'

# Won't be picked up otherwise b/c RTD bypasses PDM and uses a different
# working directory?
on_rtd = os.environ.get("READTHEDOCS") == "True"
if on_rtd:
    sys.path.append(os.path.abspath('../src'))
    sys.path.append(os.path.abspath('..'))
else:
    # And yet locally, docs build just without this, but doc-linkck doesn't
    # find examples module?! I got nothing...
    sys.path.append(os.path.abspath('../src'))
    sys.path.append(os.path.abspath('..'))

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = ["myst_parser",
              "sphinx.ext.autodoc",
              "sphinx.ext.intersphinx",
              "sphinx_rtd_theme",
              "sphinx.ext.doctest",
              "sphinx.ext.napoleon",
              "sphinx.ext.todo",
              "sphinx_prompt",
              "sphinx_inline_tabs"]

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']
suppress_warnings = [
    "ref.term"  # https://github.com/amaranth-lang/amaranth-soc/pull/111
]

intersphinx_mapping = {'python': ('https://docs.python.org/3', None),
                       'amaranth': (f'https://amaranth-lang.org/docs/amaranth/{am_ver}/', None),  # noqa: E501
                       # 'riscof': (f'https://riscof.readthedocs.io/en/{riscof_ver}/', None)}  # noqa: E501
                       'riscof': ('https://riscof.readthedocs.io/en/stable/', None)}  # noqa: E501
autodoc_default_options = {"members": True,
                           "undoc-members": True,
                           "member-order": "bysource"}
todo_include_todos = True
napoleon_custom_sections = ["Registers"]

myst_footnote_transition = False
myst_heading_anchors = 3
myst_enable_extensions = ["deflist", "substitution"]

linkcheck_ignore = [
    # Upsets a rate-limiter.
    r"^https://www.eetimes.com/understanding-clock-domain-crossing-issues/",
    r"^https://github.com/[^/]+/[^/]+/blob/.*",  # Upsets a rate-limiter.
]

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "sphinx_rtd_theme"
html_static_path = ['_static']
html_theme_options = {
    'navigation_depth': 5
}

html_logo = "Transparent.png"

# Dynamic version control in docs

sent_latest_tag = "v0.1.0-beta.2"

if (Version(sent_latest_tag) != sent_ver) and not sent_ver.is_devrelease:
    msg = "you need to increment `sent_latest_tag` so that docs are in sync " \
          "with repo"
    raise RuntimeError(msg)

myst_substitutions = {
    "sent_latest_tag": sent_latest_tag,
}


# Modified from: https://github.com/sphinx-doc/sphinx/issues/2793#issuecomment-437969830
class MystSubstitutionCodeBlock(CodeBlock):  # type: ignore
    """Similar to CodeBlock but replaces placeholders with variables."""

    def run(self) -> List:
        """Replace placeholders with given variables."""  # noqa: DOC201
        app = self.state.document.settings.env.app
        new_content = []
        self.content = self.content  # type: List[str]
        existing_content = self.content
        for item in existing_content:
            for pair in app.config.myst_substitutions.items():
                original, replacement = pair
                item = item.replace(original, replacement)
            new_content.append(item)

        self.content = new_content  # pyright: ignore[reportIncompatibleVariableOverride]
        return list(CodeBlock.run(self))


def setup(app: Sphinx):  # noqa: D103
    app.add_directive('substitution-code-block', MystSubstitutionCodeBlock)
