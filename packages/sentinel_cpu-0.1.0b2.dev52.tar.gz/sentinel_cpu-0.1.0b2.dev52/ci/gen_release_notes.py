"""Bespoke release note generator.

Python normalizes versions internally to a scheme different from my tags and
CHANGELOG.md. Handle the differences here, extract the relevant
CHANGELOG.md entries, and emit release notes with a template header.

Release notes are generated into `release_notes.md` in the top-level
directory. This script also writes key=val variables to the file specified
by the third argument (or stdout, if no third variable is given). Useful
for writing to e.g. $FORGEJO_OUTPUT.

Use as "/path/to/python ci/gen_release_notes.py dist_dir tag_name [var_file]"
"""

from itertools import filterfalse, takewhile
import sys
import string
import re
from pathlib import Path

# from pathlib import Path
from packaging.version import Version  # pyright: ignore[reportMissingImports]

VERSION_RE = re.compile(r"^.*##.*\[(.*)\].*-.*([0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9])")  # noqa: E501
LINK_RE = re.compile(r"^.*\[.*\]: .*$")


def bail(reason, code):  # noqa: D103
    print("Not generating release notes-", reason)
    sys.exit(code)


# Hint: use PDM_BUILD_SCM_VERSION environment variable for testing.
if __name__ == "__main__":
    version = Version(sys.argv[1])

    py_version = version if not version.is_devrelease else \
        bail("current version is a dev release", 0)

    # Should with with $FORGEJO_REF and $FORGEJO_REF_NAME
    ci_tag = sys.argv[2].removeprefix("refs/tags/")

    if py_version != Version(ci_tag):
        bail("CI and Python do not agree on the package version. "
             f"CI: {Version(ci_tag)}, Python: {py_version}", 1)

    ref_links = []
    with open("CHANGELOG.md") as cl:
        tag_minus_v = ci_tag[1:] if ci_tag[0] == "v" else ci_tag

        for line in cl:
            if LINK_RE.match(line):
                ref_links.append(line)

        cl.seek(0)

        cl_anchor = ""
        for line in cl:
            match_ = VERSION_RE.match(line)

            if match_ and (match_[1] == tag_minus_v):
                # This matches how forges generate anchors from headers.
                cl_anchor = match_[1].replace(".", "-") + "-" + match_[2]
                break
        else:
            bail("CHANGELOG.md doesn't have a version match to start "
                 "release notes.", 1)

        with open(Path(__file__).resolve().parent / "release_notes.md.in") as hdr:  # noqa: E501
            header = string.Template(hdr.read()).substitute(
                TAG=ci_tag,
                CHANGELOG_ANCHOR=cl_anchor,
                PYPI_VER=py_version)

        with open("release_notes.md", "w") as rn:
            ref_links_ = set(ref_links)
            rn.write(header)

            curr_release_notes = takewhile(lambda el: not VERSION_RE.match(el),
                                           cl)
            curr_notes_without_refs = filterfalse(lambda el: el in ref_links_,
                                                  curr_release_notes)

            rn.writelines(curr_notes_without_refs)
            rn.writelines(ref_links)

    out_fp = open(sys.argv[3], "a") if len(sys.argv) > 3 else sys.stdout
    is_prerelease = "true" if py_version.is_prerelease else "false"

    out_fp.write(f"is_prerelease={is_prerelease}")
    out_fp.close()
