"""Verilog generation module/script for Sentinel.

This module can be run directly from the command-line as ``__main__``:

::

    python -m sentinel_cpu.gen --help

Individual functions are documented for completeness. Only :func:`cli` should
be treated as public (see :doc:`/development/guidelines`).
"""

import argparse
import sys
from contextlib import contextmanager
from dataclasses import dataclass

from amaranth.back import verilog

from .formal import FormalTop
from .top import Top


@contextmanager
def _file_or_stdout(fn):
    """Context manager to open either a file or stdout if "-" is passed.

    Yields
    ------
    fp
        File-like object representing either stdout or a disk-backed file.
    """
    is_stdout = not fn or fn == "-"

    if not is_stdout:
        fp = open(fn, "w")
    else:
        fp = sys.stdout

    try:
        yield fp
    finally:
        if not is_stdout:
            fp.close()


def _generate_args(parser):
    """Add argparse arguments."""
    parser.add_argument("-o", help="output filename (default: stdout. "
                                   "\"-\" is also stdout)")
    parser.add_argument("-n", help="top-level name (default: \"sentinel\")")
    parser.add_argument("-f", action="store_true", help="add RVFI connections")


@dataclass
class _GenParams:
    outf: str = ""
    top: str = "sentinel"
    formal: bool = False

    @classmethod
    def from_argparse(cls, ns):
        kwargs = {}

        for arg, val in vars(ns).items():
            # Skip unset parameters, so that dataclass' defaults take effect.
            if not val:
                continue

            match arg:
                case "o":
                    kwargs["outf"] = val
                case "n":
                    kwargs["top"] = val
                case "f":
                    kwargs["formal"] = val

        return cls(**kwargs)


def _do_generate(parms):
    """Intended programmatic entry point to generate Sentinel core.

    This function is not yet complete, nor is it stable.
    """
    with _file_or_stdout(parms.outf) as fp:
        if parms.formal:
            m = FormalTop()
        else:
            m = Top()
        v = verilog.convert(m, name=parms.top)
        fp.write(v)


def cli():
    """Scripting entry point to generate Sentinel core.

    This function examines :data:`sys.argv` and then generates a Verilog
    representation of Sentinel.

    .. todo::

        Use `sphinx-argparse <https://sphinx-argparse.readthedocs.io/en/latest/>`_
        to document arguments automatically.

    This function can be called in a number of ways, all of which should be
    equivalent:

    * From within a wrapper Python script:

      .. testcode:: python

         import sentinel_cpu.gen

         if __name__ == "__main__":
            sentinel_cpu.gen.cli()

    ..
      Keep in sync with function names above!

    .. testcode::
        :hide:

        import sys
        from unittest.mock import patch

        import sentinel_cpu.gen

        with patch.object(sys, 'argv', sys.argv[0:1] + ["--help"]):
            sentinel_cpu.gen.cli()

    .. testoutput::
        :hide:

        Traceback (most recent call last):
        ...
        SystemExit: 0
        ```


    * Running the :mod:`~sentinel_cpu.gen` module (as ``__main__``) from a shell
      script:

      .. code-block:: sh

            python -m sentinel_cpu.gen --help


    * From within ``pdm``:

      .. code-block:: toml

         [tool.pdm.scripts]
         gen = { call = "sentinel_cpu.gen:cli", help="generate Sentinel Verilog file" }

      ..
        Note that the ``pdm`` invocation is
        `equivalent to <https://github.com/pdm-project/pdm/blob/2c93d669a05790ef9c7bc3da6e737ea279fb2c15/src/pdm/cli/commands/run.py#L337-L345>`_
        the following command-line::

            python -c "import sentinel_cpu.gen; sys.exit(gen.cli())"
    """  # noqa: E501
    parser = argparse.ArgumentParser(description="Sentinel Verilog cli")

    _generate_args(parser)
    args = parser.parse_args()
    _do_generate(_GenParams.from_argparse(args))


if __name__ == "__main__":
    cli()
