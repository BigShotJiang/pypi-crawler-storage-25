# Nexotype MCP Server

AI-powered biomedical knowledge graph for drug discovery, genomics, and market intelligence.

Connect your AI tools to the Nexotype platform and query the biomedical knowledge graph through conversation.

## Installation

```bash
pip install nexotype-mcp
```

Or with uv:

```bash
uv tool install nexotype-mcp
```

Already installed? Update:

```bash
pip install --upgrade nexotype-mcp
```

## Authentication

```bash
nexotype-cli login
```

Enter your email and password. Credentials are stored securely at `~/.nexotype/credentials.json` (chmod 600).

## Configure Your AI Client

### Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "nexotype": {
      "command": "nexotype-mcp"
    }
  }
}
```

### Claude Code

```bash
claude mcp add nexotype -- nexotype-mcp
```

### VS Code / Cursor

Add to your MCP settings:

```json
{
  "nexotype": {
    "command": "nexotype-mcp"
  }
}
```

Restart the application after saving.

## Tools (28)

### Graph Intelligence (6 tools)

| Tool | Description |
|------|-------------|
| `explore_network` | N-hop neighborhood of any entity |
| `find_path` | Shortest path between two entities |
| `find_similar` | Entities sharing the most relationships |
| `company_deep_dive` | Full portfolio of a pharma/biotech company |
| `drug_discovery` | Targets, pathways, indications for a drug |
| `competitive_landscape` | All drugs and companies targeting a protein |

### AI Query (1 tool)

| Tool | Description |
|------|-------------|
| `ask_knowledge_graph` | Natural language question → grounded answer from graph |

### Search & Browse (2 tools)

| Tool | Description |
|------|-------------|
| `search_entities` | List entities of any of the 61 types |
| `get_entity` | Full details for a specific entity |

### Context (3 tools)

| Tool | Description |
|------|-------------|
| `get_permissions` | Check subscription tier and domain access |
| `list_subjects` | List available biological subjects |
| `set_subject` | Set active subject for personalization tools |

### Personalized Health (10 tools)

| Tool | Description |
|------|-------------|
| `get_user_profile` | Personal info linked to the subject |
| `list_user_variants` | Detected genomic variants |
| `list_biomarker_readings` | Time-series health data |
| `create_biomarker_reading` | Log a new biomarker measurement |
| `list_treatment_logs` | Intervention history |
| `create_treatment_log` | Log a new treatment |
| `list_pathway_scores` | Pathway health scores |
| `list_recommendations` | Personalized treatment suggestions |
| `upload_genomic_file` | Upload VCF/23andMe file for analysis |
| `get_processing_status` | Check genomic file processing progress |

### Commercial Intelligence (6 tools)

| Tool | Description |
|------|-------------|
| `list_market_organizations` | Pharma/biotech companies |
| `get_market_organization` | Full company details |
| `list_patents` | Patent filings and status |
| `list_development_pipelines` | Clinical trial phases |
| `list_regulatory_approvals` | FDA/EMA approvals |
| `list_licensing_agreements` | Commercial partnerships |

## Example Queries

```
"What drugs target EGFR and are in Phase III?"
"Show me Novo Nordisk's full portfolio"
"What variants are associated with Alzheimer's risk?"
"Compare GLP-1 receptor agonists across companies"
"Who else is targeting mTOR?"
"List all therapeutic peptides in the database"
"What are my detected genomic variants?"
```

## CLI Commands

| Command | Description |
|---------|-------------|
| `nexotype-cli login` | Authenticate via browser (OAuth device flow) |
| `nexotype-cli login --basic` | Authenticate with email/password (headless fallback) |
| `nexotype-cli logout` | Delete stored credentials |
| `nexotype-cli status` | Show current auth status |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NEXOTYPE_API_URL` | `http://localhost:8000` | API server URL |
