"""
Graph intelligence tools — knowledge graph traversal via SurrealDB.

6 tools for exploring the biomedical knowledge graph:
- explore_network: N-hop neighborhood of any entity
- find_path: shortest path between two entities
- find_similar: entities sharing the most relationships
- company_deep_dive: full portfolio of a pharma/biotech company
- drug_discovery: targets, pathways, indications for a drug
- competitive_landscape: all drugs and companies targeting a protein

These are the CORE VALUE of the Nexotype MCP — the main reason users install it.
"""

from ..server import mcp
from ..client import nexotype
from .search import EntityType

# Maximum nodes to display before truncating
MAX_DISPLAY_NODES = 100


def _format_node(node: dict) -> str:
    """Format a GraphNode dict as a single line: label (type, id=N)."""
    label = node.get("label", "?")
    node_type = node.get("type", "unknown")
    node_id = node.get("id", 0)
    return f"{label} ({node_type}, id={node_id})"


def _format_node_with_props(node: dict, indent: str = "  ") -> str:
    """Format a GraphNode dict with key properties on separate lines."""
    label = node.get("label", "?")
    node_type = node.get("type", "unknown")
    node_id = node.get("id", 0)
    props = node.get("properties", {})

    lines = [f"{indent}{label} ({node_type}, id={node_id})"]
    # Show a few key properties (skip internal/verbose fields)
    skip_keys = {"created_at", "updated_at", "deleted_at", "deleted_by", "created_by",
                 "updated_by", "is_curated", "organization_id", "sequence_aa", "sequence_na",
                 "smiles", "definition", "method_description"}
    for key, val in props.items():
        if key in skip_keys or val is None:
            continue
        # Truncate long values
        val_str = str(val)
        if len(val_str) > 80:
            val_str = val_str[:77] + "..."
        lines.append(f"{indent}  {key}: {val_str}")
    return "\n".join(lines)


def _group_nodes_by_type(nodes: list[dict]) -> dict[str, list[dict]]:
    """Group GraphNode dicts by their type field."""
    groups: dict[str, list[dict]] = {}
    for node in nodes:
        node_type = node.get("type", "unknown")
        if node_type not in groups:
            groups[node_type] = []
        groups[node_type].append(node)
    return groups


@mcp.tool(annotations={"readOnlyHint": True})
async def explore_network(entity_type: EntityType, entity_id: int, depth: int = 2) -> str:
    """Explore the N-hop neighborhood of any entity in the knowledge graph.
    Returns the center node and all connected nodes/edges within the specified depth.

    Valid entity_type values (snake_case):
      gene, protein, variant, indication, phenotype, biomarker, pathway,
      therapeutic_asset, small_molecule, biologic, therapeutic_peptide, oligonucleotide,
      market_organization, patent, development_pipeline, technology_platform,
      drug_target_mechanism, bio_activity, therapeutic_efficacy, drug_interaction,
      genomic_association, variant_phenotype, pathway_membership, source,
      organism, transcript, exon, protein_domain, peptide_fragment,
      candidate, design_mutation, construct, subject, biospecimen,
      assay_protocol, assay_run, assay_readout, and more.

    Example: explore_network("gene", 1, depth=2) → APOE gene + connected transcripts, proteins, variants"""
    result = await nexotype.get(
        f"/nexotype/graph/network/{entity_type}/{entity_id}",
        params={"depth": depth},
    )

    center = result.get("center")
    nodes = result.get("nodes", [])
    edges = result.get("edges", [])

    if not center:
        return f"No entity found for {entity_type} with id={entity_id}."

    lines = [f"Network for {_format_node(center)} (depth={depth}):\n"]

    # Group nodes by type
    groups = _group_nodes_by_type(nodes)
    total_nodes = len(nodes)

    if total_nodes == 0:
        lines.append("No connected nodes found at this depth.")
    else:
        # Truncation warning
        truncated = total_nodes > MAX_DISPLAY_NODES
        display_count = 0

        lines.append(f"Connected nodes ({total_nodes}):")
        for node_type, type_nodes in sorted(groups.items()):
            lines.append(f"\n  {node_type} ({len(type_nodes)}):")
            for node in type_nodes:
                if display_count >= MAX_DISPLAY_NODES:
                    break
                lines.append(f"    - {_format_node(node)}")
                display_count += 1
            if display_count >= MAX_DISPLAY_NODES:
                break

        if truncated:
            lines.append(f"\n... truncated at {MAX_DISPLAY_NODES} of {total_nodes} nodes. Reduce depth for smaller results.")

    # Edge summary
    if edges:
        edge_counts: dict[str, int] = {}
        for edge in edges:
            key = f"{edge.get('source_type', '?')} → {edge.get('target_type', '?')} ({edge.get('edge_type', '?')})"
            edge_counts[key] = edge_counts.get(key, 0) + 1
        lines.append(f"\nEdges ({len(edges)}):")
        for key, count in sorted(edge_counts.items(), key=lambda x: -x[1]):
            lines.append(f"  {key}: {count}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def find_path(
    from_type: str,
    from_id: int,
    to_type: str,
    to_id: int,
    max_depth: int = 5,
) -> str:
    """Find the shortest path between two entities in the knowledge graph.
    Returns step-by-step path from source to target, or 'No path found'.

    Example: find_path("gene", 1, "indication", 5) → gene → protein → drug → indication"""
    result = await nexotype.get(
        "/nexotype/graph/path",
        params={
            "from_type": from_type,
            "from_id": from_id,
            "to_type": to_type,
            "to_id": to_id,
            "max_depth": max_depth,
        },
    )

    nodes = result.get("nodes", [])
    length = result.get("length", -1)

    if length < 0 or not nodes:
        return (
            f"No path found between {from_type}:{from_id} and {to_type}:{to_id} "
            f"within {max_depth} hops."
        )

    lines = [f"Path found ({length} hop{'s' if length != 1 else ''}):\n"]
    for i, node in enumerate(nodes):
        prefix = "  → " if i > 0 else "  "
        lines.append(f"{prefix}{_format_node(node)}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def find_similar(entity_type: EntityType, entity_id: int, limit: int = 10) -> str:
    """Find entities of the same type that share the most relationships with the target.
    Useful for finding related drugs, similar genes, or comparable companies.

    Example: find_similar("therapeutic_asset", 1, limit=5) → drugs similar to Rapamycin"""
    result = await nexotype.get(
        f"/nexotype/graph/similar/{entity_type}/{entity_id}",
        params={"limit": limit},
    )

    target = result.get("target")
    similar = result.get("similar", [])

    if not target:
        return f"No entity found for {entity_type} with id={entity_id}."

    lines = [f"Similar to {_format_node(target)}:\n"]

    if not similar:
        lines.append("No similar entities found.")
    else:
        for i, node in enumerate(similar, 1):
            shared = node.get("properties", {}).get("shared_connections", 0)
            lines.append(f"  {i}. {_format_node(node)} — {shared} shared connections")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def company_deep_dive(market_org_id: int) -> str:
    """Get the full portfolio of a pharma/biotech company.
    Returns: company info, therapeutic assets, patents, development pipelines, technology platforms.

    Example: company_deep_dive(5) → Pfizer's full portfolio"""
    result = await nexotype.get(f"/nexotype/graph/company/{market_org_id}")

    company = result.get("company")
    assets = result.get("assets", [])
    patents = result.get("patents", [])
    pipelines = result.get("pipelines", [])
    technologies = result.get("technologies", [])

    if not company:
        return f"No company found with id={market_org_id}."

    # Company header
    props = company.get("properties", {})
    lines = [f"Company: {company.get('label', '?')}"]
    org_type = props.get("org_type", "—")
    status = props.get("status", "—")
    hq = props.get("headquarters", "—")
    lines.append(f"  Type: {org_type} | Status: {status} | HQ: {hq}")

    ticker = props.get("ticker_symbol")
    exchange = props.get("primary_exchange")
    isin = props.get("isin")
    if ticker:
        lines.append(f"  Ticker: {ticker} ({exchange or '—'}) | ISIN: {isin or '—'}")

    website = props.get("website")
    if website:
        lines.append(f"  Website: {website}")

    employees = props.get("employee_count")
    revenue = props.get("revenue_usd")
    if employees or revenue:
        parts = []
        if employees:
            parts.append(f"Employees: {employees:,}")
        if revenue:
            parts.append(f"Revenue: ${revenue:,.0f}")
        lines.append(f"  {' | '.join(parts)}")

    # Assets
    lines.append(f"\nTherapeutic Assets ({len(assets)}):")
    if assets:
        for a in assets:
            a_props = a.get("properties", {})
            asset_type = a_props.get("asset_type", "—")
            lines.append(f"  - {a.get('label', '?')} (id={a.get('id')}, type={asset_type})")
    else:
        lines.append("  None found.")

    # Pipelines
    lines.append(f"\nDevelopment Pipeline ({len(pipelines)}):")
    if pipelines:
        for p in pipelines:
            p_props = p.get("properties", {})
            phase = p_props.get("phase", "—")
            p_status = p_props.get("status", "—")
            nct = p_props.get("nct_number", "")
            asset_id = p_props.get("asset_id", "?")
            indication_id = p_props.get("indication_id", "?")
            nct_str = f" | {nct}" if nct else ""
            lines.append(f"  - {phase} | {p_status} | asset={asset_id}, indication={indication_id}{nct_str}")
    else:
        lines.append("  None found.")

    # Patents
    lines.append(f"\nPatents ({len(patents)}):")
    if patents:
        for pat in patents:
            pat_props = pat.get("properties", {})
            jurisdiction = pat_props.get("jurisdiction", "—")
            title = pat_props.get("title", "—")
            if title and len(title) > 60:
                title = title[:57] + "..."
            lines.append(f"  - {jurisdiction} {pat.get('label', '?')} — {title}")
    else:
        lines.append("  None found.")

    # Technologies
    lines.append(f"\nTechnology Platforms ({len(technologies)}):")
    if technologies:
        for t in technologies:
            t_props = t.get("properties", {})
            category = t_props.get("category", "—")
            lines.append(f"  - {t.get('label', '?')} ({category})")
    else:
        lines.append("  None found.")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def drug_discovery(asset_id: int) -> str:
    """Full drug discovery traversal for a therapeutic asset.
    Returns: drug info, protein targets, pathways, indications, and competitor drugs.

    Example: drug_discovery(1) → Rapamycin's targets, pathways, diseases, competitors"""
    result = await nexotype.get(f"/nexotype/graph/drug-discovery/{asset_id}")

    asset = result.get("asset")
    targets = result.get("targets", [])
    pathways = result.get("pathways", [])
    indications = result.get("indications", [])
    competitors = result.get("competitors", [])

    if not asset:
        return f"No therapeutic asset found with id={asset_id}."

    # Asset header
    props = asset.get("properties", {})
    lines = [f"Drug: {asset.get('label', '?')} (id={asset_id})"]
    asset_type = props.get("asset_type", "—")
    category = props.get("category", "—")
    lines.append(f"  Type: {asset_type} | Category: {category}")

    effectiveness = props.get("effectiveness")
    safety = props.get("safety_rating")
    if effectiveness or safety:
        parts = []
        if effectiveness:
            parts.append(f"Effectiveness: {effectiveness}/5")
        if safety:
            parts.append(f"Safety: {safety}/5")
        lines.append(f"  {' | '.join(parts)}")

    # Protein targets
    lines.append(f"\nProtein Targets ({len(targets)}):")
    if targets:
        for t in targets:
            lines.append(f"  - {_format_node(t)}")
    else:
        lines.append("  None found.")

    # Pathways
    lines.append(f"\nPathways ({len(pathways)}):")
    if pathways:
        for p in pathways:
            p_props = p.get("properties", {})
            kegg = p_props.get("kegg_id", "")
            tier = p_props.get("longevity_tier", "")
            suffix = ""
            if kegg:
                suffix += f", KEGG: {kegg}"
            if tier:
                suffix += f", Tier {tier}"
            lines.append(f"  - {p.get('label', '?')} (id={p.get('id')}{suffix})")
    else:
        lines.append("  None found.")

    # Indications
    lines.append(f"\nIndications ({len(indications)}):")
    if indications:
        for ind in indications:
            ind_props = ind.get("properties", {})
            icd10 = ind_props.get("icd_10_code", "")
            suffix = f" — ICD-10: {icd10}" if icd10 else ""
            lines.append(f"  - {ind.get('label', '?')} (id={ind.get('id')}{suffix})")
    else:
        lines.append("  None found.")

    # Competitors
    lines.append(f"\nCompetitor Assets ({len(competitors)}):")
    if competitors:
        for c in competitors:
            c_props = c.get("properties", {})
            c_type = c_props.get("asset_type", "—")
            lines.append(f"  - {c.get('label', '?')} (id={c.get('id')}, type={c_type})")
    else:
        lines.append("  None found.")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def competitive_landscape(protein_id: int) -> str:
    """Get all therapeutic assets and companies targeting a specific protein.
    Useful for competitive analysis — who else is working on this target?

    Example: competitive_landscape(42) → all drugs and companies targeting mTOR"""
    result = await nexotype.get(f"/nexotype/graph/competitive/{protein_id}")

    protein = result.get("protein")
    assets = result.get("assets", [])
    companies = result.get("companies", [])

    if not protein:
        return f"No protein found with id={protein_id}."

    lines = [f"Competitive Landscape for {_format_node(protein)}:\n"]

    # Assets targeting this protein
    lines.append(f"Targeting Assets ({len(assets)}):")
    if assets:
        for a in assets:
            a_props = a.get("properties", {})
            asset_type = a_props.get("asset_type", "—")
            category = a_props.get("category", "—")
            lines.append(f"  - {a.get('label', '?')} (id={a.get('id')}, type={asset_type}, category={category})")
    else:
        lines.append("  None found.")

    # Companies owning those assets
    lines.append(f"\nCompanies ({len(companies)}):")
    if companies:
        for c in companies:
            c_props = c.get("properties", {})
            ticker = c_props.get("ticker_symbol", "")
            hq = c_props.get("headquarters", "—")
            suffix = f", ticker={ticker}" if ticker else ""
            lines.append(f"  - {c.get('label', '?')} (id={c.get('id')}{suffix}, HQ: {hq})")
    else:
        lines.append("  None found.")

    return "\n".join(lines)
