"""
Nexotype MCP Server — Configuration

API base URL is read from NEXOTYPE_API_URL env var.
Defaults to localhost for development, override for production.
"""

import os

# API base URL — override with NEXOTYPE_API_URL env var for production
API_BASE_URL = os.environ.get("NEXOTYPE_API_URL", "https://server.nexotype.com")

# Credentials file path — where JWT + refresh token are stored locally
CREDENTIALS_PATH = os.path.expanduser("~/.nexotype/credentials.json")

# HTTP client timeout (seconds) — standard requests
REQUEST_TIMEOUT = 30.0

# HTTP client timeout (seconds) — file uploads (VCF can be up to 500MB)
UPLOAD_TIMEOUT = 120.0
