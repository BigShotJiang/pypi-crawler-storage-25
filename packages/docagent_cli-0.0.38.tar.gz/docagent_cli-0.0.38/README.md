# DocAgent CLI

[![PyPI - Version](https://img.shields.io/pypi/v/docagent-cli?label=%20)](https://pypi.org/project/docagent-cli/#history)
[![PyPI - License](https://img.shields.io/pypi/l/docagent-cli)](https://opensource.org/licenses/MIT)
[![PyPI - Downloads](https://img.shields.io/pepy/dt/docagent-cli)](https://pypistats.org/packages/docagent-cli)
[![Twitter](https://img.shields.io/twitter/url/https/twitter.com/langchain.svg?style=social&label=Follow%20%40LangChain)](https://x.com/langchain)

<p align="center">
  <img src="https://raw.githubusercontent.com/langchain-ai/docagent/main/libs/cli/images/cli.png" alt="DocAgent CLI" width="600"/>
</p>

## Quick Install

```bash
curl -LsSf https://raw.githubusercontent.com/langchain-ai/docagent/main/libs/cli/scripts/install.sh | bash
```

```bash
# With model provider extras
# OpenAI, Anthropic, and Gemini are included by default
DEEPAGENTS_EXTRAS="nvidia,ollama" curl -LsSf https://raw.githubusercontent.com/langchain-ai/docagent/main/libs/cli/scripts/install.sh | bash
```

Or install directly with `uv`:

```bash
# Install with chosen model providers
uv tool install 'docagent-cli[nvidia,ollama]'
```

Run the CLI:

```bash
docagent
```

## What is DocAgent CLI?

`docagent-cli` is a powerful AI agent in your terminal, purpose-built for document workflows and general coding tasks. Powered by any LLM that supports tool calling, it combines a rich interactive TUI with deep file and document capabilities — one install and you're ready to go.

**Features:**

- **Interactive TUI** — rich terminal interface with streaming responses
- **Document-first tools** — read, write, and edit files with context-aware intelligence
- **Conversation resume** — pick up where you left off across sessions
- **Web search** — ground responses in live information
- **Remote sandboxes** — run code in isolated environments (LangSmith, AgentCore, Daytona, Modal, Runloop, & more)
- **Persistent memory** — agent remembers context across conversations
- **Custom skills** — extend the agent with your own slash commands
- **Headless mode** — run non-interactively for scripting and CI
- **Human-in-the-loop** — approve or reject tool calls before execution

## Resources

- **[CLI Documentation](https://docs.langchain.com/oss/python/docagent/cli/overview)**
- **[Changelog](https://github.com/langchain-ai/docagent/blob/main/libs/cli/CHANGELOG.md)**
- **[Source code](https://github.com/langchain-ai/docagent/tree/main/libs/cli)**
- **[DocAgent SDK](https://github.com/langchain-ai/docagent)** — underlying agent harness

## Releases & Versioning

See our [Releases](https://docs.langchain.com/oss/python/release-policy) and [Versioning](https://docs.langchain.com/oss/python/versioning) policies.

## Contributing

As an open-source project in a rapidly developing field, we are extremely open to contributions, whether it be in the form of a new feature, improved infrastructure, or better documentation.

For detailed information on how to contribute, see the [Contributing Guide](https://docs.langchain.com/oss/python/contributing/overview).
