"""Allow running the CLI as: python -m docagent.cli."""

from docagent_cli.main import cli_main

if __name__ == "__main__":
    cli_main()
