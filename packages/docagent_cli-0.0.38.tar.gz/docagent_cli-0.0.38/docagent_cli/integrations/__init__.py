"""Integrations for external systems used by the docagent CLI."""
