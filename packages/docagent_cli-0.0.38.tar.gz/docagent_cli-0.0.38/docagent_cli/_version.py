"""Version information and lightweight constants for `docagent-cli`."""

__version__ = "0.0.38"  # x-release-please-version

DOCS_URL = "https://docs.langchain.com/oss/python/docagent/cli"
"""URL for `docagent-cli` documentation."""

PYPI_URL = "https://pypi.org/pypi/docagent-cli/json"
"""PyPI JSON API endpoint for version checks."""

CHANGELOG_URL = (
    "https://github.com/langchain-ai/docagent/blob/main/libs/cli/CHANGELOG.md"
)
"""URL for the full changelog."""

USER_AGENT = f"docagent-cli/{__version__} update-check"
"""User-Agent header sent with PyPI requests."""
