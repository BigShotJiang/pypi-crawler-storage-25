# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, TypedDict

__all__ = ["ConversationListParams"]


class ConversationListParams(TypedDict, total=False):
    after: Optional[str]
    """Cursor for pagination (conv ID).

    Returns results relative to this ID in the specified sort order. Expected
    format: 'conv-<uuid4>'
    """

    agent_id: Optional[str]
    """
    The agent ID to list conversations for (optional - returns all conversations if
    not provided)
    """

    archive_status: Literal["unarchived", "archived", "all"]
    """
    Whether to return unarchived conversations only, archived conversations only, or
    all conversations
    """

    limit: int
    """Maximum number of conversations to return"""

    order: Literal["asc", "desc"]
    """Sort order for conversations. 'asc' for oldest first, 'desc' for newest first"""

    order_by: Literal["created_at", "last_run_completion", "last_message_at"]
    """Field to sort by"""

    summary_search: Optional[str]
    """Search for text within conversation summaries"""
