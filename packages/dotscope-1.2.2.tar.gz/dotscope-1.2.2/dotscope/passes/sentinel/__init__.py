"""Architectural enforcement for dotscope."""
