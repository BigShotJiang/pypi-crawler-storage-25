from __future__ import annotations

import base64
import email as email_lib
import json
from email.policy import default as default_policy
from typing import TYPE_CHECKING, Any, Optional

from e2a.models import Attachment, AuthHeaders, SendResult

if TYPE_CHECKING:
    from e2a.async_client import AsyncE2AClient
    from e2a.client import E2AClient


class InboundEmail:
    """An inbound email received via webhook.

    Provides parsed email fields and a ``.reply()`` method for responding
    directly. Created by ``E2AClient.parse()``.

    Attributes:
        message_id: Unique e2a message identifier (used for replying).
        conversation_id: Your opaque thread/conversation ID from a prior reply,
            or ``None`` for first-contact emails.
        sender: Sender email address.
        recipient: Recipient email address (your agent's address).
        subject: Email subject line.
        text_body: Plain-text email body.
        html_body: HTML email body, or ``None`` if not present.
        attachments: List of file attachments parsed from the email.
        auth: Parsed authentication headers (verified status, sender identity, etc.).
        raw_message: Raw RFC 2822 email bytes.
    """

    def __init__(
        self,
        *,
        message_id: str,
        conversation_id: Optional[str],
        sender: str,
        recipient: str,
        subject: str,
        text_body: str,
        html_body: Optional[str],
        attachments: list[Attachment],
        auth: AuthHeaders,
        raw_message: bytes,
        client: E2AClient,
    ) -> None:
        self.message_id = message_id
        self.conversation_id = conversation_id
        self.sender = sender
        self.recipient = recipient
        self.subject = subject
        self.text_body = text_body
        self.html_body = html_body
        self.attachments = attachments
        self.auth = auth
        self.raw_message = raw_message
        self._client = client

    @property
    def is_verified(self) -> bool:
        """Whether the sender's identity has been verified by e2a."""
        return self.auth.verified

    def reply(
        self,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Reply to this email.

        Args:
            body: Plain-text reply body.
            html_body: Optional HTML body for rich replies.
            conversation_id: Optional opaque ID for your conversation/thread.
                When provided, follow-up emails in this thread will include it
                in the webhook payload.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.
        """
        return self._client.reply(
            self.message_id, body, html_body=html_body, conversation_id=conversation_id, attachments=attachments
        )

    def __repr__(self) -> str:
        return (
            f"InboundEmail(message_id={self.message_id!r}, sender={self.sender!r}, "
            f"subject={self.subject!r}, conversation_id={self.conversation_id!r})"
        )


def parse_raw_email(raw: bytes) -> tuple[str, str, Optional[str], list[Attachment]]:
    """Extract subject, text body, HTML body, and attachments from a raw RFC 2822 message.

    Returns:
        A tuple of (subject, text_body, html_body, attachments).
    """
    try:
        msg = email_lib.message_from_bytes(raw, policy=default_policy)
    except Exception:
        return "", "", None, []

    subject = str(msg.get("Subject", ""))

    text_body = ""
    html_body = None
    attachments: list[Attachment] = []

    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            disposition = part.get_content_disposition()

            # Skip multipart containers
            if ct.startswith("multipart/"):
                continue

            # Explicit attachment or inline disposition → treat as attachment
            if disposition in ("attachment", "inline"):
                try:
                    data = part.get_payload(decode=True) or b""
                except Exception:
                    continue
                attachments.append(Attachment(
                    filename=part.get_filename() or "unnamed",
                    content_type=ct,
                    data=data,
                    size=len(data),
                ))
                continue

            # Body parts (no disposition)
            if ct == "text/plain" and not text_body:
                try:
                    text_body = part.get_content()
                except Exception:
                    pass
            elif ct == "text/html" and html_body is None:
                try:
                    html_body = part.get_content()
                except Exception:
                    pass
            elif not ct.startswith("text/"):
                # Non-text part without explicit disposition — treat as attachment
                try:
                    data = part.get_payload(decode=True) or b""
                except Exception:
                    continue
                attachments.append(Attachment(
                    filename=part.get_filename() or "unnamed",
                    content_type=ct,
                    data=data,
                    size=len(data),
                ))
    else:
        try:
            content = msg.get_content()
        except Exception:
            content = ""
        if msg.get_content_type() == "text/html":
            html_body = content
        else:
            text_body = content

    return subject, text_body, html_body, attachments


class AsyncInboundEmail:
    """Async version of :class:`InboundEmail`.

    Identical fields, but ``.reply()`` is an async method. Created by
    ``AsyncE2AClient.parse()``.
    """

    def __init__(
        self,
        *,
        message_id: str,
        conversation_id: Optional[str],
        sender: str,
        recipient: str,
        subject: str,
        text_body: str,
        html_body: Optional[str],
        attachments: list[Attachment],
        auth: AuthHeaders,
        raw_message: bytes,
        client: AsyncE2AClient,
    ) -> None:
        self.message_id = message_id
        self.conversation_id = conversation_id
        self.sender = sender
        self.recipient = recipient
        self.subject = subject
        self.text_body = text_body
        self.html_body = html_body
        self.attachments = attachments
        self.auth = auth
        self.raw_message = raw_message
        self._client = client

    @property
    def is_verified(self) -> bool:
        """Whether the sender's identity has been verified by e2a."""
        return self.auth.verified

    async def reply(
        self,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Reply to this email (async).

        Args:
            body: Plain-text reply body.
            html_body: Optional HTML body for rich replies.
            conversation_id: Optional opaque ID for your conversation/thread.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.
        """
        return await self._client.reply(
            self.message_id, body, html_body=html_body, conversation_id=conversation_id, attachments=attachments
        )

    def __repr__(self) -> str:
        return (
            f"AsyncInboundEmail(message_id={self.message_id!r}, sender={self.sender!r}, "
            f"subject={self.subject!r}, conversation_id={self.conversation_id!r})"
        )


def _decode_raw_message(data: dict[str, Any]) -> bytes:
    raw_message = b""
    if data.get("raw_message"):
        try:
            raw_message = base64.b64decode(data["raw_message"])
        except Exception:
            if isinstance(data["raw_message"], str):
                raw_message = data["raw_message"].encode()
    return raw_message


def build_inbound_email(
    data: dict[str, Any], headers: dict[str, str], client: E2AClient
) -> InboundEmail:
    """Build an InboundEmail from a webhook JSON body and HTTP headers."""
    raw_message = _decode_raw_message(data)
    subject, text_body, html_body, attachments = parse_raw_email(raw_message)
    auth_headers = data.get("auth_headers", {})

    return InboundEmail(
        message_id=data.get("message_id", ""),
        conversation_id=data.get("conversation_id"),
        sender=data.get("from", ""),
        recipient=data.get("to", ""),
        subject=subject,
        text_body=text_body,
        html_body=html_body,
        attachments=attachments,
        auth=AuthHeaders.from_headers(auth_headers),
        raw_message=raw_message,
        client=client,
    )


def build_inbound_email_async(
    data: dict[str, Any], headers: dict[str, str], client: AsyncE2AClient
) -> AsyncInboundEmail:
    """Build an AsyncInboundEmail from a webhook JSON body and HTTP headers."""
    raw_message = _decode_raw_message(data)
    subject, text_body, html_body, attachments = parse_raw_email(raw_message)
    auth_headers = data.get("auth_headers", {})

    return AsyncInboundEmail(
        message_id=data.get("message_id", ""),
        conversation_id=data.get("conversation_id"),
        sender=data.get("from", ""),
        recipient=data.get("to", ""),
        subject=subject,
        text_body=text_body,
        html_body=html_body,
        attachments=attachments,
        auth=AuthHeaders.from_headers(auth_headers),
        raw_message=raw_message,
        client=client,
    )
