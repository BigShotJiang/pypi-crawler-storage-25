"""WebSocket listener for local-mode agents.

Connects to e2a's WebSocket endpoint and yields full InboundEmail objects
as they arrive. Handles reconnection with exponential backoff.

Requires the ``websockets`` package::

    pip install e2a[ws]

Usage::

    import asyncio
    from e2a import AsyncE2AClient

    async def main():
        async with AsyncE2AClient(api_key="e2a_...") as client:
            async for email in client.listen("my-agent@agents.e2a.dev"):
                print(f"From: {email.sender}, Subject: {email.subject}")
                await email.reply("Got it!")

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, AsyncIterator, Optional

if TYPE_CHECKING:
    from e2a.async_client import AsyncE2AClient

logger = logging.getLogger("e2a.websocket")


async def listen(
    client: AsyncE2AClient,
    agent_email: Optional[str] = None,
    reconnect: bool = True,
    max_backoff: float = 30.0,
) -> AsyncIterator:
    """Connect to e2a's WebSocket and yield InboundEmail objects.

    On each WS notification (lightweight metadata), fetches the full message
    via REST and yields it as an AsyncInboundEmail.

    Args:
        client: An AsyncE2AClient instance (provides API key and base URL).
        agent_email: The agent's email address. Falls back to client.agent_email.
        reconnect: Whether to reconnect on disconnect. Defaults to True.
        max_backoff: Maximum reconnect delay in seconds. Defaults to 30.

    Yields:
        AsyncInboundEmail objects as emails arrive.
    """
    try:
        import websockets
    except ImportError:
        raise ImportError(
            "The 'websockets' package is required for listen(). "
            "Install it with: pip install e2a[ws]"
        )

    email = agent_email or client.agent_email
    if not email:
        raise ValueError(
            "agent_email is required. Pass it to listen() or set it on the client."
        )

    ws_url = _build_ws_url(client.base_url, email, client.api_key)
    backoff = 1.0

    while True:
        try:
            async for msg in _connect_and_stream(client, ws_url, email):
                yield msg
                backoff = 1.0  # Reset on successful message
        except (websockets.ConnectionClosed, ConnectionError, OSError) as exc:
            logger.warning("WebSocket disconnected: %s", exc)

        if not reconnect:
            break

        logger.info("Reconnecting in %.1fs...", backoff)
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, max_backoff)


async def _connect_and_stream(
    client: AsyncE2AClient,
    ws_url: str,
    agent_email: str,
) -> AsyncIterator:
    """Connect once and yield messages until disconnect."""
    import websockets

    async with websockets.connect(ws_url) as ws:
        logger.info("Connected to WebSocket for %s", agent_email)

        async for raw in ws:
            try:
                notification = json.loads(raw)
                message_id = notification.get("message_id")
                if not message_id:
                    logger.warning("WS notification missing message_id: %s", raw)
                    continue

                # Fetch full message via REST
                email = await client.get_message(message_id)
                yield email

            except Exception:
                logger.exception("Error processing WS notification")
                continue


def _build_ws_url(base_url: str, agent_email: str, api_key: str) -> str:
    """Build the WebSocket URL from the HTTP base URL."""
    from urllib.parse import urlencode, urlparse, urlunparse

    parsed = urlparse(base_url)
    # Switch http(s) to ws(s)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    path = f"/api/agents/{agent_email}/ws"
    query = urlencode({"token": api_key})
    return urlunparse((scheme, parsed.netloc, path, "", query, ""))
