# Webhook utilities — signing key verification has been removed.
# Auth headers (X-E2A-Auth-*) are verified server-side.
