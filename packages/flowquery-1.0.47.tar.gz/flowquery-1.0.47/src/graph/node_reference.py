from __future__ import annotations

from typing import Any, AsyncIterator, Optional

from ..parsing.ast_node import ASTNode
from .node import Node


class NodeReference(Node):
    """Represents a reference to an existing node variable."""

    def __init__(self, base: Node, reference: ASTNode) -> None:
        super().__init__(base.identifier, base.label)
        self._labels = base.labels
        self._reference: ASTNode = reference
        # Copy properties from base
        self._properties = base._properties
        self._outgoing = base.outgoing
        self._incoming = base.incoming

    @property
    def reference(self) -> ASTNode:
        return self._reference

    # Keep referred as alias for backward compatibility
    @property
    def referred(self) -> ASTNode:
        return self._reference

    def value(self) -> Optional[Any]:
        return self._reference.value() if self._reference else None

    async def next(self) -> AsyncIterator[None]:
        """Process next using the referenced node's value."""
        ref_value = self._reference.value()
        if ref_value is None:
            return
        self.set_value(dict(ref_value))
        if self._outgoing and self._value:
            async for _ in self._outgoing.find(self._value['id']):
                yield
        else:
            yield

    async def find(self, id_: str, hop: int = 0) -> AsyncIterator[None]:
        """Find by ID, only matching if it equals the referenced node's ID."""
        referenced = self._reference.value()
        if referenced is None or id_ != referenced.get('id'):
            return
        self.set_value(dict(referenced))
        if self._outgoing and self._value:
            async for _ in self._outgoing.find(self._value['id'], hop):
                yield
        else:
            yield
