import time

from dbwarden.engine.file_parser import parse_rollback_statements
from dbwarden.engine.version import get_migrations_directory
from dbwarden.logging import get_logger
from dbwarden.repositories import (
    create_lock_table_if_not_exists,
    create_migrations_table_if_not_exists,
    get_latest_versions,
    run_migration,
)


def rollback_cmd(
    count: int | None = None,
    to_version: str | None = None,
    verbose: bool = False,
    database: str | None = None,
) -> None:
    """
    Rollback the last applied migration.

    Args:
        count: Number of migrations to rollback.
        to_version: Rollback to a specific version.
        verbose: Enable verbose logging.
        database: Target database name.
    """
    config = get_database(database)
    actual_db_name = database or config.sqlalchemy_url.split("/")[-1].split("?")[0]
    logger = get_logger(
        verbose=verbose, db_name=actual_db_name, db_type=config.database_type
    )

    if count is not None and to_version is not None:
        raise ValueError("Cannot specify both 'count' and 'to-version'.")

    migrations_dir = get_migrations_directory(database)

    create_migrations_table_if_not_exists(database)
    create_lock_table_if_not_exists(database)

    if count is None and to_version is None:
        count = 1

    latest_versions = get_latest_versions(
        database, limit=count, starting_version=to_version
    )

    if not latest_versions:
        print("Nothing to rollback.")
        return

    versions_to_rollback = _get_versions_to_rollback(
        latest_versions=latest_versions,
        migrations_dir=migrations_dir,
    )

    for version, filepath in reversed(list(versions_to_rollback.items())):
        filename = filepath.split("/")[-1]
        sql_statements = parse_rollback_statements(filepath)

        for sql in sql_statements:
            logger.log_sql_statement(sql)

        start_time = time.time()
        logger.info(f"Rolling back migration: {filename} (version: {version})")

        run_migration(
            sql_statements=sql_statements,
            version=version,
            migration_operation="rollback",
            filename=filename,
            db_name=database,
        )

        duration = time.time() - start_time
        logger.info(f"Rollback completed: {filename} in {duration:.2f}s")

    print(
        f"Rollback completed successfully: {len(versions_to_rollback)} migrations reverted."
    )


def _get_versions_to_rollback(
    latest_versions: list[str],
    migrations_dir: str,
) -> dict[str, str]:
    """Get migration file paths for versions to rollback."""
    from dbwarden.engine.version import get_migration_filepaths_by_version

    if not latest_versions:
        return {}

    filepaths = get_migration_filepaths_by_version(
        directory=migrations_dir,
        version_to_start_from=None,
        end_version=latest_versions[-1],
    )

    return dict(reversed(list(filepaths.items())))
