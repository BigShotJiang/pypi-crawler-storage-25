"""
Kanberoo TUI: Textual terminal application.
"""

__version__ = "0.1.0"
