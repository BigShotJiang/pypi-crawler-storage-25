import unittest

try:
    from odoo.tools import config
    from odoo import release
except ImportError:
    commands = {}
    print("Odoo not installed")

from tests import _decorators
from environ_odoo_config import odoo_utils


@_decorators.SkipUnless.env_odoo
class TestOdooUtilsServerWideModules(unittest.TestCase):

    def setUp(self):
        config['server_wide_modules'] = ""
        config.parse_config()

    def test_is_true(self):
        self.assertIsInstance(odoo_utils.get_server_wide_modules(release.serie), list,
                              "Doit retourner une liste un non un string csv"
                              )
        config['server_wide_modules'] = "module1,module2"
        config.parse_config()
        self.assertEqual(
            odoo_utils.get_server_wide_modules(release.serie),
            ["module1", "module2"],
            msg="Retourne les valeurs fournit en dur sans `base` et `web`"
        )

    def tearDown(self):
        config['server_wide_modules'] = ""
        config.parse_config()
