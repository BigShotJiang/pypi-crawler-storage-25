from unittest import TestCase
from environ_odoo_config.entrypoints import EntryPoints

class TestEntrypointMapper(TestCase):

    def test_load(self):
        self.assertGreaterEqual(len(EntryPoints.mappers), 3, "2 postgrsql + 1 compatibility")
