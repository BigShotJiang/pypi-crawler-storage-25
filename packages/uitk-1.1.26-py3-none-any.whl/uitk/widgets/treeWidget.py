# !/usr/bin/python
# coding=utf-8
from qtpy import QtWidgets, QtGui, QtCore
from typing import Optional, Callable, List, Union, Any, Dict

# From this package:
from uitk.widgets.mixins.convert import ConvertMixin
from uitk.widgets.mixins.attributes import AttributesMixin
from uitk.widgets.mixins.menu_mixin import MenuMixin
from uitk.widgets.mixins.icon_manager import IconManager
from uitk.widgets.mixins.switchboard_slots import Signals
from uitk.widgets.mixins.settings_manager import SettingsManager


class HierarchyIconMixin:
    """Mixin to handle custom hierarchy icons in tree widgets using CSS branch styling."""

    _HIER_START = "/* __HIERARCHY_START__ */"
    _HIER_END = "/* __HIERARCHY_END__ */"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hierarchy_icons_enabled = True
        self._icon_style = "plus_minus"  # Default style
        self._setup_hierarchy_icons()

    def _setup_hierarchy_icons(self):
        """Setup custom hierarchy icons via CSS stylesheet."""
        self._apply_hierarchy_stylesheet()

    def _apply_hierarchy_stylesheet(self):
        """Apply custom stylesheet for hierarchy indicators using SVG images."""
        # Get the icons directory path - use absolute path for CSS
        from pathlib import Path

        icons_dir = Path(__file__).parent.parent / "icons"

        # Use absolute paths for CSS - Qt expects normal file paths
        expand_branch_path = str(icons_dir / "expand_branch.svg").replace("\\", "/")
        expand_end_path = str(icons_dir / "expand_end.svg").replace("\\", "/")
        collapse_branch_path = str(icons_dir / "collapse_branch.svg").replace("\\", "/")
        collapse_end_path = str(icons_dir / "collapse_end.svg").replace("\\", "/")
        tree_branch_path = str(icons_dir / "tree_branch.svg").replace("\\", "/")
        tree_vertical_path = str(icons_dir / "tree_vertical.svg").replace("\\", "/")
        tree_end_path = str(icons_dir / "tree_end.svg").replace("\\", "/")

        style = f"""
            QTreeWidget {{
                outline: none;
                background-color: #393939;
                color: #cccccc;
                selection-background-color: rgba(90, 140, 190, 0.3);
                show-decoration-selected: 1;
                font-size: 12px;
                gridline-color: transparent;
            }}
            
            QTreeWidget::branch {{
                background: transparent;
                border: none;
                width: 16px;
                height: 16px;
                margin: 0px;
                padding: 0px;
                spacing: 0px;
            }}
            
            /* Vertical continuation lines (items that have siblings below them) */
            QTreeWidget::branch:has-siblings:!adjoins-item {{
                background: transparent;
                border-image: none;
                image: url({tree_vertical_path});
            }}
            
            /* T-junction: item with siblings that also has children (branch through) */
            QTreeWidget::branch:has-siblings:adjoins-item {{
                background: transparent;
                border-image: none;
                image: url({tree_branch_path});
            }}
            
            /* L-junction: last item in a group (leaf node) */
            QTreeWidget::branch:!has-children:!has-siblings:adjoins-item {{
                background: transparent;
                border-image: none;
                image: url({tree_end_path});
            }}
            
            /* L-junction: last item in a group that has children but is closed */
            QTreeWidget::branch:has-children:!has-siblings:closed {{
                background: transparent;
                border-image: none;
                image: url({expand_end_path});
            }}
            
            /* L-junction: last item in a group that has children and is open */
            QTreeWidget::branch:has-children:!has-siblings:open {{
                background: transparent;
                border-image: none;
                image: url({collapse_end_path});
            }}
            
            /* T-junction: item with siblings that has children (closed) */
            QTreeWidget::branch:closed:has-children:has-siblings {{
                background: transparent;
                border-image: none;
                image: url({expand_branch_path});
            }}
            
            /* T-junction: item with siblings that has children (open) */
            QTreeWidget::branch:open:has-children:has-siblings {{
                background: transparent;
                border-image: none;
                image: url({collapse_branch_path});
            }}
            
            QTreeWidget::item {{
                padding: 0px 2px;
                border: none;
                min-height: 16px;
                max-height: 16px;
                color: #cccccc;
                background: transparent;
                spacing: 0px;
                margin: 0px;
            }}
            
            QTreeWidget::item:selected {{
                background-color: rgba(90, 140, 190, 0.4);
                color: #ffffff;
                border: none;
            }}
            
            QTreeWidget::item:hover:!selected {{
                background-color: rgba(255, 255, 255, 0.1);
            }}
            
            /* Maya-style indentation and spacing */
            QTreeWidget::item:has-children {{
                font-weight: normal;
            }}
        """

        tagged = f"{self._HIER_START}\n{style}\n{self._HIER_END}"
        current = self.styleSheet()
        start = current.find(self._HIER_START)
        end = current.find(self._HIER_END)
        if start != -1 and end != -1:
            current = current[:start] + current[end + len(self._HIER_END) :]
        self.setStyleSheet(current + tagged)

    def set_icon_style(self, style: str):
        """Set the icon style for hierarchy indicators.

        Available styles:
        - 'plus_minus': Plus and minus signs (default)
        - 'arrows': Triangle arrows pointing right/down
        - 'modern': Clean modern style with subtle indicators
        """
        self._icon_style = style
        if self._hierarchy_icons_enabled:
            self._apply_hierarchy_stylesheet()

    def enable_hierarchy_icons(self, enabled=True):
        """Enable or disable custom hierarchy icons."""
        self._hierarchy_icons_enabled = enabled
        if enabled:
            self._apply_hierarchy_stylesheet()
        else:
            current = self.styleSheet()
            start = current.find(self._HIER_START)
            end = current.find(self._HIER_END)
            if start != -1 and end != -1:
                self.setStyleSheet(
                    current[:start] + current[end + len(self._HIER_END) :]
                )

    def get_available_icon_styles(self) -> list:
        """Get list of available icon styles."""
        return ["plus_minus", "arrows", "modern"]

    def get_current_icon_style(self) -> str:
        """Get the currently active icon style."""
        return self._icon_style


class TreeFormatMixin(ConvertMixin):
    """Generic item/column formatting for QTreeWidget."""

    ACTION_COLOR_MAP = {
        "valid": ("#3C8D3C", "#E6F4EA"),
        "invalid": ("#B97A7A", "#FBEAEA"),
        "warning": ("#B49B5C", "#FFF6DC"),
        "info": ("#6D9BAA", "#E2F3F9"),
        "inactive": ("#AAAAAA", None),
        "reset": (None, None),
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._item_formatters = {}
        self._column_formatters = {}
        self._item_defaults = {}  # {item_id: (fg, bg)}
        self.itemChanged.connect(self._on_item_edited)

    # Public API
    def set_item_formatter(self, item_id, formatter, append=False):
        """Set a formatter for a specific item by ID."""
        if append:
            self._item_formatters.setdefault(item_id, []).append(formatter)
        else:
            self._item_formatters[item_id] = [formatter]

    def set_column_formatter(self, col, formatter, append=False):
        """Set a formatter for a specific column."""
        if append:
            self._column_formatters.setdefault(col, []).append(formatter)
        else:
            self._column_formatters[col] = [formatter]

    def clear_formatters(self):
        """Clear all item and column formatters."""
        self._item_formatters.clear()
        self._column_formatters.clear()
        self._item_defaults.clear()

    def apply_formatting(self):
        """Apply formatting based on the registered formatters."""
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        while iterator.value():
            item = iterator.value()
            for col in range(self.columnCount()):
                for fmt in self._get_formatters(item, col):
                    fmt(
                        item,
                        item.data(col, QtCore.Qt.UserRole) or item.text(col),
                        col,
                        self,
                    )
            iterator += 1

    def ensure_valid_color(self, color, color_type, item, col):
        """Ensure a valid QColor, using fallback if needed."""
        try:
            return self.to_qobject(color, "QColor")
        except Exception:
            pass

        cached = self._get_default_colors(item, col)[0 if color_type == "fg" else 1]
        try:
            return self.to_qobject(cached, "QColor")
        except Exception:
            print(
                f"[WARNING] Invalid {color_type} color: {color!r}, and fallback {cached!r} failed. Using None."
            )
            return None

    def set_action_color(
        self,
        item: QtWidgets.QTreeWidgetItem,
        key: str,
        col: int = 0,
        use_bg: bool = False,
    ):
        """Apply semantic color to a tree item."""
        fg_raw, bg_raw = self.ACTION_COLOR_MAP.get(str(key).lower(), (None, None))

        # Skip entirely if reset and nothing to restore
        if key == "reset" and fg_raw is None and bg_raw is None:
            return

        fg = self.ensure_valid_color(fg_raw, "fg", item, col)
        bg = self.ensure_valid_color(bg_raw, "bg", item, col) if use_bg else None

        default_fg, default_bg = self._get_default_colors(item, col)
        fg = fg or self.to_qobject(default_fg, "QColor")
        if use_bg:
            bg = bg or self.to_qobject(default_bg, "QColor")

        if fg:
            item.setForeground(col, fg)
        if use_bg and bg:
            item.setBackground(col, bg)

    def action_color_formatter(self, item, value, col, *_):
        """Formatter that applies action colors based on item value."""
        key = str(value).lower()
        fg, bg = TreeFormatMixin.ACTION_COLOR_MAP.get(key, (None, None))
        fg = self.ensure_valid_color(fg, "fg", item, col)
        bg = self.ensure_valid_color(bg, "bg", item, col)
        if fg:
            item.setForeground(col, fg)
        if bg:
            item.setBackground(col, bg)

    def make_color_map_formatter(self, color_map: dict):
        """Create a formatter from a color mapping dictionary."""

        def _fmt(item, value, col, *_):
            key = str(value).lower()
            fg_raw, bg_raw = color_map.get(key, (None, None))
            if fg_raw is not None:
                fg = self.ensure_valid_color(fg_raw, "fg", item, col)
                if fg:
                    item.setForeground(col, fg)
            if bg_raw is not None:
                bg = self.ensure_valid_color(bg_raw, "bg", item, col)
                if bg:
                    item.setBackground(col, bg)

        return _fmt

    # Private methods
    def _on_item_edited(self, item, col):
        """Handle item editing to reapply formatting."""
        for fmt in self._get_formatters(item, col):
            fmt(item, item.data(col, QtCore.Qt.UserRole) or item.text(col), col, self)

    def _get_default_colors(self, item, col: int):
        """Get the cached default colors for the item at the given column."""
        item_id = id(item)
        if not hasattr(self, "_item_defaults"):
            self._item_defaults = {}
        key = (item_id, col)
        cache = self._item_defaults
        if key not in cache:
            fg = item.foreground(col).color().name()
            bg = item.background(col).color().name()
            cache[key] = (fg, bg)
        return cache[key]

    def _get_formatters(self, item, col) -> list:
        """Get all formatters that apply to the given item and column."""
        formatters = []
        item_id = id(item)

        # Item-specific formatters
        if item_id in self._item_formatters:
            formatters.extend(self._item_formatters[item_id])

        # Column formatters
        if col in self._column_formatters:
            formatters.extend(self._column_formatters[col])

        return formatters


def _alpha_over(base, overlay):
    """Alpha-composite *overlay* onto an opaque *base*, return opaque QColor.

    Both arguments are ``QColor``.  The result always has alpha 255.
    """
    a = overlay.alphaF()
    r = min(int(base.red() * (1 - a) + overlay.red() * a + 0.5), 255)
    g = min(int(base.green() * (1 - a) + overlay.green() * a + 0.5), 255)
    b = min(int(base.blue() * (1 - a) + overlay.blue() * a + 0.5), 255)
    return QtGui.QColor(r, g, b)


class _RowTintDelegate(QtWidgets.QStyledItemDelegate):
    """Composites column tints, row tints, and per-item colors into a single
    solid opaque background that is immune to Maya's QSS overrides.

    Compositing order (each layer alpha-blends onto the previous):

      1. Base        — widget viewport background (``#393939``)
      2. Column tint — ``tree._column_tints[col]``
      3. Row tint    — ``tree._parent_row_color`` or ``tree._child_row_color``
      4. Item bg     — per-item ``BackgroundRole`` (assessment / status colors)

    The result is an opaque color painted via ``fillRect`` **and** injected into
    ``option.backgroundBrush`` so that ``super().paint()`` cannot override it
    with a QSS-resolved background.
    """

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        # Inject per-item ForegroundRole into the palette so the style engine
        # uses it for text drawing, bypassing QSS ``color:`` rules.
        fg = index.data(QtCore.Qt.ForegroundRole)
        if isinstance(fg, QtGui.QBrush) and fg.color().isValid():
            option.palette.setColor(QtGui.QPalette.Text, fg.color())

    def paint(self, painter, option, index):
        tree = self.parent()
        item = tree.itemFromIndex(index) if tree else None
        col = index.column()

        # Resolve the viewport base color (opaque starting point)
        base = tree.palette().color(QtGui.QPalette.Base)
        if not base.isValid() or base.alpha() == 0:
            base = QtGui.QColor(57, 57, 57)  # #393939 fallback
        bg = QtGui.QColor(base.red(), base.green(), base.blue())

        # Layer 1 — column tint
        tint = tree._column_tints.get(col)
        if tint and tint.isValid() and tint.alpha() > 0:
            bg = _alpha_over(bg, tint)

        # Layer 2 — row tint (parent vs child)
        if item is not None:
            if item.parent() is not None:
                row_color = tree._child_row_color
            else:
                row_color = tree._parent_row_color
            if row_color and row_color.isValid() and row_color.alpha() > 0:
                bg = _alpha_over(bg, row_color)

        # Layer 3 — per-item background (assessment / status)
        item_bg = index.data(QtCore.Qt.BackgroundRole)
        if isinstance(item_bg, QtGui.QBrush) and item_bg.color().isValid():
            c = item_bg.color()
            if c.alpha() == 255:
                bg = QtGui.QColor(c)
            elif c.alpha() > 0:
                bg = _alpha_over(bg, c)

        # Paint the single solid composite and inject it into the option
        # so super().paint() uses it instead of the QSS-resolved background.
        painter.fillRect(option.rect, bg)
        option.backgroundBrush = QtGui.QBrush(bg)

        super().paint(painter, option, index)


class _HeaderActionBar(QtWidgets.QWidget):
    """Right-aligned strip of icon buttons overlaid on a QHeaderView.

    Parented to the header's viewport so it floats over the header without
    requiring a custom QHeaderView subclass.  Repositioned automatically
    when the tree resizes.

    Not intended for direct use — access via ``TreeWidget.header_actions``.
    """

    def __init__(self, tree: "TreeWidget") -> None:
        header = tree.header()
        super().__init__(header.viewport())
        self._tree = tree
        self._buttons: Dict[str, QtWidgets.QToolButton] = {}
        self._layout = QtWidgets.QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 4, 0)
        self._layout.setSpacing(2)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        self.setFocusPolicy(QtCore.Qt.NoFocus)
        self._reposition()

    # -- public API ----------------------------------------------------------

    def add(
        self,
        name: str,
        icon: str,
        tooltip: str = "",
        callback: Optional[Callable] = None,
        toggle: bool = False,
        checked: bool = False,
    ) -> QtWidgets.QToolButton:
        """Add a named icon button to the strip.

        Parameters
        ----------
        name : str
            Unique identifier for the button.
        icon : str
            Icon name resolved by ``IconManager``.
        tooltip : str
            Tooltip text.
        callback : callable, optional
            Connected to ``clicked(bool)`` for toggles or ``clicked()``
            for momentary buttons.
        toggle : bool
            If ``True`` the button is checkable.
        checked : bool
            Initial checked state (only meaningful when *toggle* is True).

        Returns
        -------
        QToolButton
            The created button, for further customization if needed.
        """
        if name in self._buttons:
            self.remove(name)

        btn = QtWidgets.QToolButton(self)
        btn.setAutoRaise(True)
        btn.setFocusPolicy(QtCore.Qt.NoFocus)
        btn.setToolTip(tooltip)

        h = max(self._tree.header().height() - 4, 16)
        btn.setFixedSize(h, h)
        icon_size = max(int(h * 0.7), 10)
        btn.setIconSize(QtCore.QSize(icon_size, icon_size))
        btn.setIcon(IconManager.get(icon, size=(icon_size, icon_size)))
        btn.setObjectName(f"hdr_action_{name}")

        if toggle:
            btn.setCheckable(True)
            btn.setChecked(checked)

        if callback is not None:
            btn.clicked.connect(callback)

        self._buttons[name] = btn
        self._layout.addWidget(btn)
        self._reposition()
        self.show()
        return btn

    def remove(self, name: str) -> None:
        """Remove a button by name."""
        btn = self._buttons.pop(name, None)
        if btn is not None:
            self._layout.removeWidget(btn)
            btn.deleteLater()
            self._reposition()
            if not self._buttons:
                self.hide()

    def get(self, name: str) -> Optional[QtWidgets.QToolButton]:
        """Return the button for *name*, or ``None``."""
        return self._buttons.get(name)

    def set_checked(self, name: str, checked: bool) -> None:
        """Programmatically set a toggle button's checked state."""
        btn = self._buttons.get(name)
        if btn is not None and btn.isCheckable():
            btn.setChecked(checked)

    def is_checked(self, name: str) -> bool:
        """Query a toggle button's checked state."""
        btn = self._buttons.get(name)
        return btn.isChecked() if btn is not None and btn.isCheckable() else False

    def clear(self) -> None:
        """Remove all buttons."""
        for btn in list(self._buttons.values()):
            self._layout.removeWidget(btn)
            btn.deleteLater()
        self._buttons.clear()
        self.hide()

    # -- internal ------------------------------------------------------------

    def _reposition(self) -> None:
        """Right-align self within the header viewport."""
        header = self._tree.header()
        vp = header.viewport()
        hint = self.sizeHint()
        x = vp.width() - hint.width()
        y = (header.height() - hint.height()) // 2
        self.setGeometry(max(x, 0), max(y, 0), hint.width(), hint.height())


class TreeWidget(
    QtWidgets.QTreeWidget,
    MenuMixin,
    AttributesMixin,
    TreeFormatMixin,
    HierarchyIconMixin,
):
    """Enhanced QTreeWidget with flexible data handling, formatting capabilities, and custom hierarchy icons."""

    # Signals
    item_selected = QtCore.Signal(QtWidgets.QTreeWidgetItem)
    item_data_changed = QtCore.Signal(QtWidgets.QTreeWidgetItem, int)

    def __init__(
        self, parent=None, selection_mode="extended", ctrl_toggle=True, **kwargs
    ):
        """
        Initialize TreeWidget.

        Args:
            parent: Parent widget
            selection_mode: Selection mode string. Options:
                - "none": No selection allowed
                - "single": Single item selection only
                - "extended": Ctrl+Click multi-selection (default)
                - "multi": Click to toggle selection
            ctrl_toggle: If True (default), Ctrl+click on a selected item
                deselects it. If False, Ctrl+click only adds to selection.
            **kwargs: Additional attributes to set
        """
        super().__init__(parent)
        TreeFormatMixin.__init__(self)
        HierarchyIconMixin.__init__(self)

        # Default settings
        self.setProperty("class", self.__class__.__name__)
        self.setAlternatingRowColors(False)
        self.setRootIsDecorated(True)
        self.setIndentation(16)  # Match icon width for proper alignment
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)

        # Set selection mode
        self._set_selection_mode(selection_mode)

        # Ctrl+click toggle deselection
        self._ctrl_toggle = ctrl_toggle

        # For custom deselection behavior
        self._last_clicked_item = None
        self._was_selected = False
        self._ctrl_pressed = False
        self._shift_pressed = False
        self._click_timer = QtCore.QTimer()
        self._click_timer.setSingleShot(True)
        self._click_timer.timeout.connect(self._handle_delayed_click)

        # Column stretch support
        self._stretch_column = None

        # Column configuration persistence
        self._column_settings = None  # SettingsManager, set via enable_column_config()

        # Header action bar (lazy — created on first access)
        self._header_actions = None

        # Row and column tinting (composited by _RowTintDelegate)
        self._child_row_color = QtGui.QColor()
        self._parent_row_color = QtGui.QColor()
        self._column_tints = {}  # {col_index: QColor}
        self.setItemDelegate(_RowTintDelegate(self))

        # Connect signals
        self.itemSelectionChanged.connect(self._on_selection_changed)

        self.set_attributes(**kwargs)

    # -- header action bar --------------------------------------------------

    @property
    def header_actions(self) -> _HeaderActionBar:
        """Right-aligned icon-button strip overlaid on the tree header.

        Created lazily on first access.  Use to add filter toggles,
        expand/collapse buttons, or other header-level controls::

            tree.header_actions.add(
                "filter", icon="filter", tooltip="Filter",
                toggle=True, callback=self._on_filter_toggled,
            )
        """
        if self._header_actions is None:
            self._header_actions = _HeaderActionBar(self)
            self._header_actions.hide()  # hidden until buttons are added
        return self._header_actions

    # -- child-row background (styleable via qproperty-childRowColor) ----

    def _get_child_row_color(self):
        return self._child_row_color

    def _set_child_row_color(self, color):
        self._child_row_color = (
            QtGui.QColor(color) if not isinstance(color, QtGui.QColor) else color
        )
        self.viewport().update()

    childRowColor = QtCore.Property(
        QtGui.QColor, _get_child_row_color, _set_child_row_color
    )

    # -- parent-row background (styleable via qproperty-parentRowColor) --

    def _get_parent_row_color(self):
        return self._parent_row_color

    def _set_parent_row_color(self, color):
        self._parent_row_color = (
            QtGui.QColor(color) if not isinstance(color, QtGui.QColor) else color
        )
        self.viewport().update()

    parentRowColor = QtCore.Property(
        QtGui.QColor, _get_parent_row_color, _set_parent_row_color
    )

    # -- column tinting ---------------------------------------------------

    def set_column_tint(self, column: int, color) -> None:
        """Apply a tint overlay to every cell in *column*.

        *color* can be a ``QColor``, hex string, or ``None`` to remove.
        """
        if color is None:
            self._column_tints.pop(column, None)
        else:
            c = QtGui.QColor(color) if not isinstance(color, QtGui.QColor) else color
            if c.isValid():
                self._column_tints[column] = c
            else:
                self._column_tints.pop(column, None)
        self.viewport().update()

    def clear_column_tints(self) -> None:
        """Remove all column tint overlays."""
        self._column_tints.clear()
        self.viewport().update()

    def _set_selection_mode(self, mode_str):
        """Set the selection mode from a string."""
        mode_map = {
            "none": QtWidgets.QAbstractItemView.NoSelection,
            "single": QtWidgets.QAbstractItemView.SingleSelection,
            "extended": QtWidgets.QAbstractItemView.ExtendedSelection,
            "multi": QtWidgets.QAbstractItemView.MultiSelection,
        }

        mode = mode_map.get(
            mode_str.lower(), QtWidgets.QAbstractItemView.ExtendedSelection
        )
        self.setSelectionMode(mode)

    def set_selection_mode(self, mode_str):
        """Change the selection mode after initialization."""
        self._set_selection_mode(mode_str)

    def _on_selection_changed(self):
        """Handle selection changes."""
        current = self.currentItem()
        if current:
            self.item_selected.emit(current)

    @property
    def ctrl_toggle(self):
        """Whether Ctrl+click toggles (deselects) an already-selected item."""
        return self._ctrl_toggle

    @ctrl_toggle.setter
    def ctrl_toggle(self, value):
        self._ctrl_toggle = bool(value)

    def mousePressEvent(self, event):
        """Track pre-click state; defer Ctrl+click toggle to release."""
        # Don't interfere with right-click - let it propagate to menu event filter
        if event.button() == QtCore.Qt.RightButton:
            self._last_clicked_item = None  # prevent stale state in release
            if self.has_menu:
                self.menu.trigger_from_widget(self, button=event.button())
            super().mousePressEvent(event)
            return

        item = self.itemAt(event.pos())
        modifiers = event.modifiers()

        # Store state for toggle handling in mouseReleaseEvent
        self._last_clicked_item = item
        self._was_selected = item.isSelected() if item else False
        self._ctrl_pressed = bool(modifiers & QtCore.Qt.ControlModifier)
        self._shift_pressed = bool(modifiers & QtCore.Qt.ShiftModifier)

        super().mousePressEvent(event)

        # Plain click on the only selected item -> deselect (non-Ctrl)
        if (
            item
            and self._was_selected
            and not self._ctrl_pressed
            and not self._shift_pressed
            and event.button() == QtCore.Qt.LeftButton
        ):
            if self.selectionMode() == QtWidgets.QAbstractItemView.ExtendedSelection:
                if len(self.selectedItems()) == 1:
                    QtCore.QTimer.singleShot(0, lambda: item.setSelected(False))
            elif self.selectionMode() == QtWidgets.QAbstractItemView.MultiSelection:
                item.setSelected(False)

    def mouseReleaseEvent(self, event):
        """Handle Ctrl+click toggle after Qt finalises selection."""
        super().mouseReleaseEvent(event)

        item = self._last_clicked_item
        self._last_clicked_item = None  # consume — one press per release

        if (
            event.button() != QtCore.Qt.LeftButton
            or item is None
            or not self._was_selected
            or self._shift_pressed
            or not self._ctrl_pressed
        ):
            return

        # Verify the release landed on the same item that was pressed
        release_item = self.itemAt(event.pos())
        if release_item is not item:
            return

        if self._ctrl_toggle:
            # Ensure Ctrl+click on a selected item deselects it
            if item.isSelected():
                item.setSelected(False)
        else:
            # Prevent Ctrl+click from deselecting — keep item selected
            if not item.isSelected():
                item.setSelected(True)

    def _handle_delayed_click(self):
        """Handle delayed click processing for deselection."""
        pass

    def create_item(
        self,
        text: Union[str, List[str]],
        data: Any = None,
        parent: QtWidgets.QTreeWidgetItem = None,
    ) -> QtWidgets.QTreeWidgetItem:
        """Create a new tree widget item."""
        if isinstance(text, str):
            text = [text]

        item = QtWidgets.QTreeWidgetItem(parent or self, text)

        if data is not None:
            item.setData(0, QtCore.Qt.UserRole, data)

        # Make item editable if needed
        item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)

        return item

    def item_data(self, item: QtWidgets.QTreeWidgetItem, column: int = 0):
        """Get data from an item."""
        if item is None:
            return None
        data = item.data(column, QtCore.Qt.UserRole)
        return data if data is not None else item.text(column)

    def set_item_data(
        self, item: QtWidgets.QTreeWidgetItem, data: Any, column: int = 0
    ):
        """Set data for an item."""
        if item:
            item.setData(column, QtCore.Qt.UserRole, data)

    def find_item_by_text(
        self, text: str, column: int = 0
    ) -> Optional[QtWidgets.QTreeWidgetItem]:
        """Find an item by its text in the specified column."""
        items = self.findItems(
            text, QtCore.Qt.MatchExactly | QtCore.Qt.MatchRecursive, column
        )
        return items[0] if items else None

    def find_item_by_data(
        self, data: Any, column: int = 0
    ) -> Optional[QtWidgets.QTreeWidgetItem]:
        """Find an item by its user data."""
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        while iterator.value():
            item = iterator.value()
            if item.data(column, QtCore.Qt.UserRole) == data:
                return item
            iterator += 1
        return None

    @Signals.blockSignals
    def add(
        self,
        data: Union[Dict, List, str, Any],
        headers: Optional[List[str]] = None,
        clear: bool = True,
        parent: Optional[QtWidgets.QTreeWidgetItem] = None,
        **kwargs,
    ):
        """Add data to the tree widget with flexible input handling.

        Args:
            data: The data to add. Can be:
                - Dict: Keys become parent items, values become children
                - List of dicts: Each dict becomes a top-level item with key-value children
                - List of strings: Each string becomes a top-level item
                - List of tuples: (text, data) pairs
                - Nested structures: Recursively handled
            headers: Column headers for the tree
            clear: Whether to clear existing items
            parent: Parent item to add under (None for root)
            **kwargs: Additional attributes to set
        """
        self.setUpdatesEnabled(False)
        try:
            if clear and parent is None:
                self.clear()

            # Set headers if provided
            if headers:
                self.setHeaderLabels([str(h) for h in headers])
            elif not self.headerItem() or not self.headerItem().text(0):
                # Set default header if none exists
                self.setHeaderLabels(["Name"])

            self.blockSignals(True)
            self._add_recursive(data, parent)
            self.blockSignals(False)

        finally:
            self.setUpdatesEnabled(True)

        self.set_attributes(**kwargs)
        self.apply_formatting()

    def _add_recursive(
        self, data: Any, parent: Optional[QtWidgets.QTreeWidgetItem] = None
    ):
        """Recursively add data to the tree."""
        if isinstance(data, dict):
            for key, value in data.items():
                item = self.create_item(str(key), key, parent)
                if isinstance(value, (dict, list)):
                    self._add_recursive(value, item)
                else:
                    child_item = self.create_item(str(value), value, item)

        elif isinstance(data, (list, tuple)):
            for item_data in data:
                if isinstance(item_data, dict):
                    # Dict becomes parent with key-value children
                    for key, value in item_data.items():
                        parent_item = self.create_item(str(key), key, parent)
                        if isinstance(value, (dict, list)):
                            self._add_recursive(value, parent_item)
                        else:
                            self.create_item(str(value), value, parent_item)

                elif isinstance(item_data, (tuple, list)) and len(item_data) >= 2:
                    # Tuple/list: (text, data, [children])
                    text, user_data = item_data[0], item_data[1]
                    item = self.create_item(str(text), user_data, parent)

                    # Handle children if present
                    if len(item_data) > 2 and item_data[2]:
                        self._add_recursive(item_data[2], item)

                elif isinstance(item_data, (dict, list)):
                    # Nested structure
                    self._add_recursive(item_data, parent)
                else:
                    # Simple value
                    self.create_item(str(item_data), item_data, parent)
        else:
            # Single value
            self.create_item(str(data), data, parent)

    def selected_item(self) -> Optional[QtWidgets.QTreeWidgetItem]:
        """Get the currently selected item."""
        return self.currentItem()

    def selected_items(self) -> List[QtWidgets.QTreeWidgetItem]:
        """Get all selected items."""
        return self.selectedItems()

    def selected_data(self, column: int = 0) -> Any:
        """Get data from the currently selected item."""
        item = self.selected_item()
        return self.item_data(item, column) if item else None

    def selected_data_list(self, column: int = 0) -> List[Any]:
        """Get data from all selected items."""
        items = self.selected_items()
        return [self.item_data(item, column) for item in items if item]

    def selected_text(self, column: int = 0) -> Optional[str]:
        """Get text from the currently selected item."""
        item = self.selected_item()
        return item.text(column) if item else None

    def selected_text_list(self, column: int = 0) -> List[str]:
        """Get text from all selected items."""
        items = self.selected_items()
        return [item.text(column) for item in items if item]

    def select_items_by_data(self, data_list: List[Any], column: int = 0):
        """Select multiple items by their data values."""
        self.clearSelection()
        for data in data_list:
            item = self.find_item_by_data(data, column)
            if item:
                item.setSelected(True)

    def select_items_by_text(self, text_list: List[str], column: int = 0):
        """Select multiple items by their text values."""
        self.clearSelection()
        for text in text_list:
            item = self.find_item_by_text(text, column)
            if item:
                item.setSelected(True)

    def set_stretch_column(self, col: int):
        """Set a column to automatically stretch to fill available space."""
        self._stretch_column = col
        self.stretch_column_to_fill(col)

    # -- Column configuration (visibility, reorder, persistence) ----------

    def enable_column_config(self, settings=None, settings_key=None):
        """Enable header right-click menu for column visibility and drag reorder.

        Parameters:
            settings: A SettingsManager instance (or any object with
                ``value(key, default)`` / ``setValue(key, value)`` /
                ``sync()``).  If *None*, a module-level SettingsManager
                is created automatically.
            settings_key: Namespace prefix for stored keys.  Defaults to
                the widget's ``objectName()`` or ``"TreeWidget"``.
        """
        key = settings_key or self.objectName() or "TreeWidget"
        if settings is None:
            settings = SettingsManager(org="uitk", app="TreeWidget")
        self._column_settings = settings.branch(key)

        # Enable drag-to-reorder on the header
        header = self.header()
        header.setSectionsMovable(True)
        header.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        header.customContextMenuRequested.connect(self._show_column_menu)
        header.sectionMoved.connect(self._on_column_moved)

    def _show_column_menu(self, pos):
        """Show a context menu on the header to toggle column visibility."""
        header = self.header()
        menu = QtWidgets.QMenu(header)
        col_count = self.columnCount()
        header_item = self.headerItem()

        for logical in range(col_count):
            label = header_item.text(logical) if header_item else f"Column {logical}"
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(not header.isSectionHidden(logical))
            # Prevent hiding the last visible column
            visible = sum(1 for c in range(col_count) if not header.isSectionHidden(c))
            if visible <= 1 and not header.isSectionHidden(logical):
                action.setEnabled(False)
            action.setData(logical)

        chosen = menu.exec_(header.mapToGlobal(pos))
        if chosen is not None:
            col = chosen.data()
            hidden = not chosen.isChecked()
            header.setSectionHidden(col, hidden)
            self._save_column_state()

    def _on_column_moved(self, _logical, _old_visual, _new_visual):
        """Persist column order after the user drags a header section."""
        self._save_column_state()

    def _save_column_state(self):
        """Write current visibility and visual order to settings."""
        s = self._column_settings
        if s is None:
            return
        header = self.header()
        col_count = self.columnCount()

        hidden = [c for c in range(col_count) if header.isSectionHidden(c)]
        order = [header.logicalIndex(v) for v in range(col_count)]

        s.setValue("hidden_columns", hidden)
        s.setValue("column_order", order)
        s.sync()

    def restore_column_state(self):
        """Apply persisted visibility and order.  Call after headers are set."""
        s = self._column_settings
        if s is None:
            return
        header = self.header()
        col_count = self.columnCount()

        hidden = s.value("hidden_columns", [])
        if hidden:
            for c in range(col_count):
                header.setSectionHidden(c, c in hidden)

        order = s.value("column_order", [])
        if order and len(order) == col_count:
            for visual_target, logical in enumerate(order):
                current_visual = header.visualIndex(logical)
                if current_visual != visual_target:
                    header.moveSection(current_visual, visual_target)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._header_actions is not None:
            self._header_actions._reposition()
        if self._stretch_column is not None:
            self.stretch_column_to_fill(self._stretch_column)

    def showEvent(self, event):
        super().showEvent(event)
        if self._header_actions is not None:
            self._header_actions._reposition()

    def stretch_column_to_fill(self, stretch_col: int):
        """Resize one column to fill remaining horizontal space."""
        header = self.header()
        if stretch_col < 0 or stretch_col >= self.columnCount():
            return

        header.setStretchLastSection(False)
        for col in range(self.columnCount()):
            header.setSectionResizeMode(col, QtWidgets.QHeaderView.Interactive)

        total_width = self.viewport().width()
        if total_width <= 0:
            return

        other_cols_width = sum(
            self.columnWidth(c) for c in range(self.columnCount()) if c != stretch_col
        )
        self.setColumnWidth(stretch_col, max(50, total_width - other_cols_width))

    def expand_all_items(self):
        """Expand all items in the tree."""
        self.expandAll()

    def collapse_all_items(self):
        """Collapse all items in the tree."""
        self.collapseAll()

    def get_all_items(self) -> List[QtWidgets.QTreeWidgetItem]:
        """Get all items in the tree."""
        items = []
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        while iterator.value():
            items.append(iterator.value())
            iterator += 1
        return items

    def remove_item(self, item: QtWidgets.QTreeWidgetItem):
        """Remove an item from the tree."""
        if item:
            parent = item.parent()
            if parent:
                parent.removeChild(item)
            else:
                index = self.indexOfTopLevelItem(item)
                if index >= 0:
                    self.takeTopLevelItem(index)

    def set_item_icon(
        self,
        item: QtWidgets.QTreeWidgetItem,
        icon_name: str,
        color: str = None,
    ):
        """Set a custom icon for a specific item."""
        if item and icon_name:
            icon = IconManager.get(icon_name, size=(16, 16), color=color)
            item.setIcon(0, icon)
            # Store icon info for theme updates
            item.setData(
                0,
                QtCore.Qt.UserRole + 100,
                {"icon_name": icon_name, "column": 0, "color": color},
            )

    def set_item_type_icon(
        self,
        item: QtWidgets.QTreeWidgetItem,
        icon_name: str,
        column: int = 0,
        color: str = None,
    ):
        """Set a custom type icon for a specific item (separate from hierarchy indicators).

        This sets an icon in the item itself (next to the text) to indicate object type,
        while leaving the hierarchy indicators (tree lines, +/- boxes) untouched.

        Args:
            item: The tree widget item
            icon_name: Name of the icon (from IconManager)
            column: Column to set the icon in (default 0)
            color: Optional hex color for the icon (e.g. ``"#6EA8DC"``)
        """
        if item and icon_name:
            icon = IconManager.get(icon_name, size=(16, 16), color=color)
            item.setIcon(column, icon)
            # Store icon info for theme updates
            item.setData(
                column,
                QtCore.Qt.UserRole + 100,
                {"icon_name": icon_name, "column": column, "color": color},
            )

    def refresh_item_icons(self, color: str = None):
        """Refresh all item icons with the current theme color.

        Called when theme changes to update tree item icons.

        Args:
            color: Optional color to use. If None, uses IconManager default.
        """

        def refresh_item(item):
            for col in range(item.columnCount()):
                icon_data = item.data(col, QtCore.Qt.UserRole + 100)
                if icon_data and isinstance(icon_data, dict):
                    icon_name = icon_data.get("icon_name")
                    if icon_name:
                        icon_color = icon_data.get("color") or color
                        icon = IconManager.get(
                            icon_name, size=(16, 16), color=icon_color
                        )
                        item.setIcon(col, icon)
            # Recurse to children
            for i in range(item.childCount()):
                refresh_item(item.child(i))

        # Refresh all top-level items and their children
        for i in range(self.topLevelItemCount()):
            refresh_item(self.topLevelItem(i))


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    # return the existing QApplication object, or create a new one if none exists.
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)

    tree = TreeWidget()

    # Test with different data structures
    test_data = {
        "Root 1": {"Child 1": "Value 1", "Child 2": ["Item A", "Item B", "Item C"]},
        "Root 2": [
            ("Node A", "data_a"),
            ("Node B", "data_b", {"Sub1": "SubValue1", "Sub2": "SubValue2"}),
        ],
    }

    tree.add(test_data, headers=["Items", "Data"])
    tree.expand_all_items()

    # Set up some formatting
    tree.set_column_formatter(0, tree.action_color_formatter)

    tree.show()
    sys.exit(app.exec_())


# -----------------------------------------------------------------------------
# Notes
# -----------------------------------------------------------------------------

"""
Promoting a widget in designer to use a custom class:
>   In Qt Designer, select all the widgets you want to replace,
        then right-click them and select 'Promote to...'.

>   In the dialog:
        Base Class:     Class from which you inherit. ie. QWidget
        Promoted Class: Name of the class. ie. "MyWidget"
        Header File:    Path of the file (changing the extension .py to .h)  ie. myfolder.mymodule.mywidget.h

>   Then click "Add", "Promote",
        and you will see the class change from "QWidget" to "MyWidget" in the Object Inspector pane.
"""
