from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PropertyType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROPERTY_TYPE_UNSET: _ClassVar[PropertyType]
    PROPERTY_TYPE_INT32: _ClassVar[PropertyType]
    PROPERTY_TYPE_UINT32: _ClassVar[PropertyType]
    PROPERTY_TYPE_INT64: _ClassVar[PropertyType]
    PROPERTY_TYPE_UINT64: _ClassVar[PropertyType]
    PROPERTY_TYPE_FLOAT: _ClassVar[PropertyType]
    PROPERTY_TYPE_DOUBLE: _ClassVar[PropertyType]
    PROPERTY_TYPE_STRING: _ClassVar[PropertyType]
    PROPERTY_TYPE_DATETIME: _ClassVar[PropertyType]
    PROPERTY_TYPE_TIMESTAMP: _ClassVar[PropertyType]
    PROPERTY_TYPE_TEXT: _ClassVar[PropertyType]
    PROPERTY_TYPE_BLOB: _ClassVar[PropertyType]
    PROPERTY_TYPE_POINT: _ClassVar[PropertyType]
    PROPERTY_TYPE_DECIMAL: _ClassVar[PropertyType]
    PROPERTY_TYPE_LIST: _ClassVar[PropertyType]
    PROPERTY_TYPE_SET: _ClassVar[PropertyType]
    PROPERTY_TYPE_MAP: _ClassVar[PropertyType]
    PROPERTY_TYPE_NULL: _ClassVar[PropertyType]
    PROPERTY_TYPE_BOOL: _ClassVar[PropertyType]
    PROPERTY_TYPE_LOCAL_DATETIME: _ClassVar[PropertyType]
    PROPERTY_TYPE_ZONED_DATETIME: _ClassVar[PropertyType]
    PROPERTY_TYPE_DATE: _ClassVar[PropertyType]
    PROPERTY_TYPE_ZONED_TIME: _ClassVar[PropertyType]
    PROPERTY_TYPE_LOCAL_TIME: _ClassVar[PropertyType]
    PROPERTY_TYPE_YEAR_TO_MONTH: _ClassVar[PropertyType]
    PROPERTY_TYPE_DAY_TO_SECOND: _ClassVar[PropertyType]
    PROPERTY_TYPE_RECORD: _ClassVar[PropertyType]
    PROPERTY_TYPE_POINT3D: _ClassVar[PropertyType]
    PROPERTY_TYPE_VECTOR: _ClassVar[PropertyType]
    PROPERTY_TYPE_TABLE: _ClassVar[PropertyType]
    PROPERTY_TYPE_PATH: _ClassVar[PropertyType]
    PROPERTY_TYPE_ERROR: _ClassVar[PropertyType]
    PROPERTY_TYPE_NODE: _ClassVar[PropertyType]
    PROPERTY_TYPE_EDGE: _ClassVar[PropertyType]

class GraphType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GRAPH_TYPE_OPEN: _ClassVar[GraphType]
    GRAPH_TYPE_CLOSED: _ClassVar[GraphType]
    GRAPH_TYPE_ONTOLOGY: _ClassVar[GraphType]

class HealthStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    HEALTH_STATUS_UNKNOWN: _ClassVar[HealthStatus]
    HEALTH_STATUS_SERVING: _ClassVar[HealthStatus]
    HEALTH_STATUS_NOT_SERVING: _ClassVar[HealthStatus]
    HEALTH_STATUS_SERVICE_UNKNOWN: _ClassVar[HealthStatus]

class CacheType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CACHE_TYPE_ALL: _ClassVar[CacheType]
    CACHE_TYPE_AST: _ClassVar[CacheType]
    CACHE_TYPE_PLAN: _ClassVar[CacheType]
PROPERTY_TYPE_UNSET: PropertyType
PROPERTY_TYPE_INT32: PropertyType
PROPERTY_TYPE_UINT32: PropertyType
PROPERTY_TYPE_INT64: PropertyType
PROPERTY_TYPE_UINT64: PropertyType
PROPERTY_TYPE_FLOAT: PropertyType
PROPERTY_TYPE_DOUBLE: PropertyType
PROPERTY_TYPE_STRING: PropertyType
PROPERTY_TYPE_DATETIME: PropertyType
PROPERTY_TYPE_TIMESTAMP: PropertyType
PROPERTY_TYPE_TEXT: PropertyType
PROPERTY_TYPE_BLOB: PropertyType
PROPERTY_TYPE_POINT: PropertyType
PROPERTY_TYPE_DECIMAL: PropertyType
PROPERTY_TYPE_LIST: PropertyType
PROPERTY_TYPE_SET: PropertyType
PROPERTY_TYPE_MAP: PropertyType
PROPERTY_TYPE_NULL: PropertyType
PROPERTY_TYPE_BOOL: PropertyType
PROPERTY_TYPE_LOCAL_DATETIME: PropertyType
PROPERTY_TYPE_ZONED_DATETIME: PropertyType
PROPERTY_TYPE_DATE: PropertyType
PROPERTY_TYPE_ZONED_TIME: PropertyType
PROPERTY_TYPE_LOCAL_TIME: PropertyType
PROPERTY_TYPE_YEAR_TO_MONTH: PropertyType
PROPERTY_TYPE_DAY_TO_SECOND: PropertyType
PROPERTY_TYPE_RECORD: PropertyType
PROPERTY_TYPE_POINT3D: PropertyType
PROPERTY_TYPE_VECTOR: PropertyType
PROPERTY_TYPE_TABLE: PropertyType
PROPERTY_TYPE_PATH: PropertyType
PROPERTY_TYPE_ERROR: PropertyType
PROPERTY_TYPE_NODE: PropertyType
PROPERTY_TYPE_EDGE: PropertyType
GRAPH_TYPE_OPEN: GraphType
GRAPH_TYPE_CLOSED: GraphType
GRAPH_TYPE_ONTOLOGY: GraphType
HEALTH_STATUS_UNKNOWN: HealthStatus
HEALTH_STATUS_SERVING: HealthStatus
HEALTH_STATUS_NOT_SERVING: HealthStatus
HEALTH_STATUS_SERVICE_UNKNOWN: HealthStatus
CACHE_TYPE_ALL: CacheType
CACHE_TYPE_AST: CacheType
CACHE_TYPE_PLAN: CacheType

class TypedValue(_message.Message):
    __slots__ = ("type", "data", "is_null")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    IS_NULL_FIELD_NUMBER: _ClassVar[int]
    type: PropertyType
    data: bytes
    is_null: bool
    def __init__(self, type: _Optional[_Union[PropertyType, str]] = ..., data: _Optional[bytes] = ..., is_null: bool = ...) -> None: ...

class Parameter(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: TypedValue
    def __init__(self, name: _Optional[str] = ..., value: _Optional[_Union[TypedValue, _Mapping]] = ...) -> None: ...

class Row(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedCompositeFieldContainer[TypedValue]
    def __init__(self, values: _Optional[_Iterable[_Union[TypedValue, _Mapping]]] = ...) -> None: ...

class LoginRequest(_message.Message):
    __slots__ = ("username", "password", "default_graph")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_GRAPH_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    default_graph: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ..., default_graph: _Optional[str] = ...) -> None: ...

class LoginResponse(_message.Message):
    __slots__ = ("session_id", "server_version", "roles", "is_cluster", "cluster_id", "partition_count")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SERVER_VERSION_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    IS_CLUSTER_FIELD_NUMBER: _ClassVar[int]
    CLUSTER_ID_FIELD_NUMBER: _ClassVar[int]
    PARTITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    server_version: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    is_cluster: bool
    cluster_id: str
    partition_count: int
    def __init__(self, session_id: _Optional[int] = ..., server_version: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., is_cluster: bool = ..., cluster_id: _Optional[str] = ..., partition_count: _Optional[int] = ...) -> None: ...

class LogoutRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LogoutResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class PingRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PingResponse(_message.Message):
    __slots__ = ("latency_ns",)
    LATENCY_NS_FIELD_NUMBER: _ClassVar[int]
    latency_ns: int
    def __init__(self, latency_ns: _Optional[int] = ...) -> None: ...

class GqlRequest(_message.Message):
    __slots__ = ("gql", "graph_name", "parameters", "session_id", "transaction_id", "timeout", "read_only", "max_path_results")
    GQL_FIELD_NUMBER: _ClassVar[int]
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    READ_ONLY_FIELD_NUMBER: _ClassVar[int]
    MAX_PATH_RESULTS_FIELD_NUMBER: _ClassVar[int]
    gql: str
    graph_name: str
    parameters: _containers.RepeatedCompositeFieldContainer[Parameter]
    session_id: int
    transaction_id: int
    timeout: int
    read_only: bool
    max_path_results: int
    def __init__(self, gql: _Optional[str] = ..., graph_name: _Optional[str] = ..., parameters: _Optional[_Iterable[_Union[Parameter, _Mapping]]] = ..., session_id: _Optional[int] = ..., transaction_id: _Optional[int] = ..., timeout: _Optional[int] = ..., read_only: bool = ..., max_path_results: _Optional[int] = ...) -> None: ...

class GqlResponse(_message.Message):
    __slots__ = ("columns", "rows", "row_count", "has_more", "warnings", "rows_affected")
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    ROWS_FIELD_NUMBER: _ClassVar[int]
    ROW_COUNT_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    ROWS_AFFECTED_FIELD_NUMBER: _ClassVar[int]
    columns: _containers.RepeatedScalarFieldContainer[str]
    rows: _containers.RepeatedCompositeFieldContainer[Row]
    row_count: int
    has_more: bool
    warnings: _containers.RepeatedScalarFieldContainer[str]
    rows_affected: int
    def __init__(self, columns: _Optional[_Iterable[str]] = ..., rows: _Optional[_Iterable[_Union[Row, _Mapping]]] = ..., row_count: _Optional[int] = ..., has_more: bool = ..., warnings: _Optional[_Iterable[str]] = ..., rows_affected: _Optional[int] = ...) -> None: ...

class ExplainResponse(_message.Message):
    __slots__ = ("plan",)
    PLAN_FIELD_NUMBER: _ClassVar[int]
    plan: str
    def __init__(self, plan: _Optional[str] = ...) -> None: ...

class ProfileResponse(_message.Message):
    __slots__ = ("profile",)
    PROFILE_FIELD_NUMBER: _ClassVar[int]
    profile: str
    def __init__(self, profile: _Optional[str] = ...) -> None: ...

class NodeData(_message.Message):
    __slots__ = ("id", "labels", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: TypedValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[TypedValue, _Mapping]] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    id: str
    labels: _containers.RepeatedScalarFieldContainer[str]
    properties: _containers.MessageMap[str, TypedValue]
    def __init__(self, id: _Optional[str] = ..., labels: _Optional[_Iterable[str]] = ..., properties: _Optional[_Mapping[str, TypedValue]] = ...) -> None: ...

class EdgeData(_message.Message):
    __slots__ = ("label", "from_node_id", "to_node_id", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: TypedValue
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[TypedValue, _Mapping]] = ...) -> None: ...
    LABEL_FIELD_NUMBER: _ClassVar[int]
    FROM_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    TO_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    label: str
    from_node_id: str
    to_node_id: str
    properties: _containers.MessageMap[str, TypedValue]
    def __init__(self, label: _Optional[str] = ..., from_node_id: _Optional[str] = ..., to_node_id: _Optional[str] = ..., properties: _Optional[_Mapping[str, TypedValue]] = ...) -> None: ...

class BulkCreateNodesOptions(_message.Message):
    __slots__ = ("overwrite",)
    OVERWRITE_FIELD_NUMBER: _ClassVar[int]
    overwrite: bool
    def __init__(self, overwrite: bool = ...) -> None: ...

class BulkCreateEdgesOptions(_message.Message):
    __slots__ = ("skip_invalid_nodes",)
    SKIP_INVALID_NODES_FIELD_NUMBER: _ClassVar[int]
    skip_invalid_nodes: bool
    def __init__(self, skip_invalid_nodes: bool = ...) -> None: ...

class InsertNodesRequest(_message.Message):
    __slots__ = ("graph_name", "nodes", "options", "bulk_import_session_id")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    NODES_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    BULK_IMPORT_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    nodes: _containers.RepeatedCompositeFieldContainer[NodeData]
    options: BulkCreateNodesOptions
    bulk_import_session_id: str
    def __init__(self, graph_name: _Optional[str] = ..., nodes: _Optional[_Iterable[_Union[NodeData, _Mapping]]] = ..., options: _Optional[_Union[BulkCreateNodesOptions, _Mapping]] = ..., bulk_import_session_id: _Optional[str] = ...) -> None: ...

class InsertNodesResponse(_message.Message):
    __slots__ = ("success", "node_ids", "node_count", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    NODE_IDS_FIELD_NUMBER: _ClassVar[int]
    NODE_COUNT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    node_ids: _containers.RepeatedScalarFieldContainer[str]
    node_count: int
    message: str
    def __init__(self, success: bool = ..., node_ids: _Optional[_Iterable[str]] = ..., node_count: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class InsertEdgesRequest(_message.Message):
    __slots__ = ("graph_name", "edges", "options", "bulk_import_session_id")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    EDGES_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    BULK_IMPORT_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    edges: _containers.RepeatedCompositeFieldContainer[EdgeData]
    options: BulkCreateEdgesOptions
    bulk_import_session_id: str
    def __init__(self, graph_name: _Optional[str] = ..., edges: _Optional[_Iterable[_Union[EdgeData, _Mapping]]] = ..., options: _Optional[_Union[BulkCreateEdgesOptions, _Mapping]] = ..., bulk_import_session_id: _Optional[str] = ...) -> None: ...

class InsertEdgesResponse(_message.Message):
    __slots__ = ("success", "edge_ids", "edge_count", "message", "skipped_count")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    EDGE_IDS_FIELD_NUMBER: _ClassVar[int]
    EDGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    SKIPPED_COUNT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    edge_ids: _containers.RepeatedScalarFieldContainer[str]
    edge_count: int
    message: str
    skipped_count: int
    def __init__(self, success: bool = ..., edge_ids: _Optional[_Iterable[str]] = ..., edge_count: _Optional[int] = ..., message: _Optional[str] = ..., skipped_count: _Optional[int] = ...) -> None: ...

class DeleteNodesRequest(_message.Message):
    __slots__ = ("graph_name", "node_ids", "labels", "where")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    NODE_IDS_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    WHERE_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    node_ids: _containers.RepeatedScalarFieldContainer[str]
    labels: _containers.RepeatedScalarFieldContainer[str]
    where: str
    def __init__(self, graph_name: _Optional[str] = ..., node_ids: _Optional[_Iterable[str]] = ..., labels: _Optional[_Iterable[str]] = ..., where: _Optional[str] = ...) -> None: ...

class DeleteNodesResponse(_message.Message):
    __slots__ = ("success", "deleted_count", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    DELETED_COUNT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    deleted_count: int
    message: str
    def __init__(self, success: bool = ..., deleted_count: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class DeleteEdgesRequest(_message.Message):
    __slots__ = ("graph_name", "edge_ids", "label", "where")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    EDGE_IDS_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    WHERE_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    edge_ids: _containers.RepeatedScalarFieldContainer[str]
    label: str
    where: str
    def __init__(self, graph_name: _Optional[str] = ..., edge_ids: _Optional[_Iterable[str]] = ..., label: _Optional[str] = ..., where: _Optional[str] = ...) -> None: ...

class DeleteEdgesResponse(_message.Message):
    __slots__ = ("success", "deleted_count", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    DELETED_COUNT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    deleted_count: int
    message: str
    def __init__(self, success: bool = ..., deleted_count: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class ExportRequest(_message.Message):
    __slots__ = ("graph_name", "batch_size", "export_nodes", "export_edges", "node_labels", "edge_labels", "include_metadata")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    BATCH_SIZE_FIELD_NUMBER: _ClassVar[int]
    EXPORT_NODES_FIELD_NUMBER: _ClassVar[int]
    EXPORT_EDGES_FIELD_NUMBER: _ClassVar[int]
    NODE_LABELS_FIELD_NUMBER: _ClassVar[int]
    EDGE_LABELS_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_METADATA_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    batch_size: int
    export_nodes: bool
    export_edges: bool
    node_labels: _containers.RepeatedScalarFieldContainer[str]
    edge_labels: _containers.RepeatedScalarFieldContainer[str]
    include_metadata: bool
    def __init__(self, graph_name: _Optional[str] = ..., batch_size: _Optional[int] = ..., export_nodes: bool = ..., export_edges: bool = ..., node_labels: _Optional[_Iterable[str]] = ..., edge_labels: _Optional[_Iterable[str]] = ..., include_metadata: bool = ...) -> None: ...

class ExportResponse(_message.Message):
    __slots__ = ("data", "is_final", "stats")
    DATA_FIELD_NUMBER: _ClassVar[int]
    IS_FINAL_FIELD_NUMBER: _ClassVar[int]
    STATS_FIELD_NUMBER: _ClassVar[int]
    data: bytes
    is_final: bool
    stats: ExportStats
    def __init__(self, data: _Optional[bytes] = ..., is_final: bool = ..., stats: _Optional[_Union[ExportStats, _Mapping]] = ...) -> None: ...

class ExportStats(_message.Message):
    __slots__ = ("nodes_exported", "edges_exported", "bytes_written", "duration_ms")
    NODES_EXPORTED_FIELD_NUMBER: _ClassVar[int]
    EDGES_EXPORTED_FIELD_NUMBER: _ClassVar[int]
    BYTES_WRITTEN_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    nodes_exported: int
    edges_exported: int
    bytes_written: int
    duration_ms: int
    def __init__(self, nodes_exported: _Optional[int] = ..., edges_exported: _Optional[int] = ..., bytes_written: _Optional[int] = ..., duration_ms: _Optional[int] = ...) -> None: ...

class CreateGraphRequest(_message.Message):
    __slots__ = ("name", "graph_type", "description")
    NAME_FIELD_NUMBER: _ClassVar[int]
    GRAPH_TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    name: str
    graph_type: GraphType
    description: str
    def __init__(self, name: _Optional[str] = ..., graph_type: _Optional[_Union[GraphType, str]] = ..., description: _Optional[str] = ...) -> None: ...

class CreateGraphResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class DropGraphRequest(_message.Message):
    __slots__ = ("name", "if_exists")
    NAME_FIELD_NUMBER: _ClassVar[int]
    IF_EXISTS_FIELD_NUMBER: _ClassVar[int]
    name: str
    if_exists: bool
    def __init__(self, name: _Optional[str] = ..., if_exists: bool = ...) -> None: ...

class DropGraphResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class UseGraphRequest(_message.Message):
    __slots__ = ("name", "session_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    session_id: int
    def __init__(self, name: _Optional[str] = ..., session_id: _Optional[int] = ...) -> None: ...

class UseGraphResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class ListGraphsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListGraphsResponse(_message.Message):
    __slots__ = ("graphs",)
    GRAPHS_FIELD_NUMBER: _ClassVar[int]
    graphs: _containers.RepeatedCompositeFieldContainer[GraphInfo]
    def __init__(self, graphs: _Optional[_Iterable[_Union[GraphInfo, _Mapping]]] = ...) -> None: ...

class GetGraphInfoRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class GetGraphInfoResponse(_message.Message):
    __slots__ = ("info",)
    INFO_FIELD_NUMBER: _ClassVar[int]
    info: GraphInfo
    def __init__(self, info: _Optional[_Union[GraphInfo, _Mapping]] = ...) -> None: ...

class GraphInfo(_message.Message):
    __slots__ = ("name", "graph_type", "node_count", "edge_count", "description")
    NAME_FIELD_NUMBER: _ClassVar[int]
    GRAPH_TYPE_FIELD_NUMBER: _ClassVar[int]
    NODE_COUNT_FIELD_NUMBER: _ClassVar[int]
    EDGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    name: str
    graph_type: GraphType
    node_count: int
    edge_count: int
    description: str
    def __init__(self, name: _Optional[str] = ..., graph_type: _Optional[_Union[GraphType, str]] = ..., node_count: _Optional[int] = ..., edge_count: _Optional[int] = ..., description: _Optional[str] = ...) -> None: ...

class BeginRequest(_message.Message):
    __slots__ = ("session_id", "graph_name", "read_only", "timeout")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    READ_ONLY_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    graph_name: str
    read_only: bool
    timeout: int
    def __init__(self, session_id: _Optional[int] = ..., graph_name: _Optional[str] = ..., read_only: bool = ..., timeout: _Optional[int] = ...) -> None: ...

class BeginResponse(_message.Message):
    __slots__ = ("transaction_id", "message")
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    transaction_id: int
    message: str
    def __init__(self, transaction_id: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class CommitRequest(_message.Message):
    __slots__ = ("session_id", "transaction_id")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    transaction_id: int
    def __init__(self, session_id: _Optional[int] = ..., transaction_id: _Optional[int] = ...) -> None: ...

class CommitResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class RollbackRequest(_message.Message):
    __slots__ = ("session_id", "transaction_id")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    transaction_id: int
    def __init__(self, session_id: _Optional[int] = ..., transaction_id: _Optional[int] = ...) -> None: ...

class RollbackResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class ListTransactionsRequest(_message.Message):
    __slots__ = ("session_id", "all_transactions")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ALL_TRANSACTIONS_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    all_transactions: bool
    def __init__(self, session_id: _Optional[int] = ..., all_transactions: bool = ...) -> None: ...

class ListTransactionsResponse(_message.Message):
    __slots__ = ("transactions",)
    TRANSACTIONS_FIELD_NUMBER: _ClassVar[int]
    transactions: _containers.RepeatedCompositeFieldContainer[TransactionInfo]
    def __init__(self, transactions: _Optional[_Iterable[_Union[TransactionInfo, _Mapping]]] = ...) -> None: ...

class TransactionInfo(_message.Message):
    __slots__ = ("transaction_id", "session_id", "graph_name", "read_only", "created_at", "duration_ms", "internal_tx_id")
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    READ_ONLY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    INTERNAL_TX_ID_FIELD_NUMBER: _ClassVar[int]
    transaction_id: int
    session_id: int
    graph_name: str
    read_only: bool
    created_at: int
    duration_ms: int
    internal_tx_id: str
    def __init__(self, transaction_id: _Optional[int] = ..., session_id: _Optional[int] = ..., graph_name: _Optional[str] = ..., read_only: bool = ..., created_at: _Optional[int] = ..., duration_ms: _Optional[int] = ..., internal_tx_id: _Optional[str] = ...) -> None: ...

class HealthCheckRequest(_message.Message):
    __slots__ = ("service",)
    SERVICE_FIELD_NUMBER: _ClassVar[int]
    service: str
    def __init__(self, service: _Optional[str] = ...) -> None: ...

class HealthCheckResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: HealthStatus
    def __init__(self, status: _Optional[_Union[HealthStatus, str]] = ...) -> None: ...

class WarmupParserRequest(_message.Message):
    __slots__ = ("count",)
    COUNT_FIELD_NUMBER: _ClassVar[int]
    count: int
    def __init__(self, count: _Optional[int] = ...) -> None: ...

class WarmupParserResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class GetCacheStatsRequest(_message.Message):
    __slots__ = ("cache_type",)
    CACHE_TYPE_FIELD_NUMBER: _ClassVar[int]
    cache_type: CacheType
    def __init__(self, cache_type: _Optional[_Union[CacheType, str]] = ...) -> None: ...

class CacheStatsResponse(_message.Message):
    __slots__ = ("ast_stats", "plan_stats")
    AST_STATS_FIELD_NUMBER: _ClassVar[int]
    PLAN_STATS_FIELD_NUMBER: _ClassVar[int]
    ast_stats: ASTCacheStats
    plan_stats: PlanCacheStats
    def __init__(self, ast_stats: _Optional[_Union[ASTCacheStats, _Mapping]] = ..., plan_stats: _Optional[_Union[PlanCacheStats, _Mapping]] = ...) -> None: ...

class ASTCacheStats(_message.Message):
    __slots__ = ("hits", "misses", "evictions", "entries", "hit_rate")
    HITS_FIELD_NUMBER: _ClassVar[int]
    MISSES_FIELD_NUMBER: _ClassVar[int]
    EVICTIONS_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    HIT_RATE_FIELD_NUMBER: _ClassVar[int]
    hits: int
    misses: int
    evictions: int
    entries: int
    hit_rate: float
    def __init__(self, hits: _Optional[int] = ..., misses: _Optional[int] = ..., evictions: _Optional[int] = ..., entries: _Optional[int] = ..., hit_rate: _Optional[float] = ...) -> None: ...

class PlanCacheStats(_message.Message):
    __slots__ = ("size", "capacity", "hits", "misses", "hit_rate")
    SIZE_FIELD_NUMBER: _ClassVar[int]
    CAPACITY_FIELD_NUMBER: _ClassVar[int]
    HITS_FIELD_NUMBER: _ClassVar[int]
    MISSES_FIELD_NUMBER: _ClassVar[int]
    HIT_RATE_FIELD_NUMBER: _ClassVar[int]
    size: int
    capacity: int
    hits: int
    misses: int
    hit_rate: float
    def __init__(self, size: _Optional[int] = ..., capacity: _Optional[int] = ..., hits: _Optional[int] = ..., misses: _Optional[int] = ..., hit_rate: _Optional[float] = ...) -> None: ...

class ClearCacheRequest(_message.Message):
    __slots__ = ("cache_type",)
    CACHE_TYPE_FIELD_NUMBER: _ClassVar[int]
    cache_type: CacheType
    def __init__(self, cache_type: _Optional[_Union[CacheType, str]] = ...) -> None: ...

class ClearCacheResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class GetStatisticsRequest(_message.Message):
    __slots__ = ("graph_name",)
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    def __init__(self, graph_name: _Optional[str] = ...) -> None: ...

class GetStatisticsResponse(_message.Message):
    __slots__ = ("node_count", "edge_count", "label_counts", "edge_label_counts")
    class LabelCountsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    class EdgeLabelCountsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    NODE_COUNT_FIELD_NUMBER: _ClassVar[int]
    EDGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    LABEL_COUNTS_FIELD_NUMBER: _ClassVar[int]
    EDGE_LABEL_COUNTS_FIELD_NUMBER: _ClassVar[int]
    node_count: int
    edge_count: int
    label_counts: _containers.ScalarMap[str, int]
    edge_label_counts: _containers.ScalarMap[str, int]
    def __init__(self, node_count: _Optional[int] = ..., edge_count: _Optional[int] = ..., label_counts: _Optional[_Mapping[str, int]] = ..., edge_label_counts: _Optional[_Mapping[str, int]] = ...) -> None: ...

class InvalidatePermissionCacheRequest(_message.Message):
    __slots__ = ("username",)
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    username: str
    def __init__(self, username: _Optional[str] = ...) -> None: ...

class InvalidatePermissionCacheResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CompactRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CompactResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class WaitForComputeTopologyRequest(_message.Message):
    __slots__ = ("graph_name", "timeout_ms")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    timeout_ms: int
    def __init__(self, graph_name: _Optional[str] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class WaitForComputeTopologyResponse(_message.Message):
    __slots__ = ("ready", "message")
    READY_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ready: bool
    message: str
    def __init__(self, ready: bool = ..., message: _Optional[str] = ...) -> None: ...

class StartBulkImportRequest(_message.Message):
    __slots__ = ("graph_name", "checkpoint_every", "estimated_nodes", "estimated_edges", "memtable_size", "max_memtables")
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_EVERY_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_NODES_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_EDGES_FIELD_NUMBER: _ClassVar[int]
    MEMTABLE_SIZE_FIELD_NUMBER: _ClassVar[int]
    MAX_MEMTABLES_FIELD_NUMBER: _ClassVar[int]
    graph_name: str
    checkpoint_every: int
    estimated_nodes: int
    estimated_edges: int
    memtable_size: int
    max_memtables: int
    def __init__(self, graph_name: _Optional[str] = ..., checkpoint_every: _Optional[int] = ..., estimated_nodes: _Optional[int] = ..., estimated_edges: _Optional[int] = ..., memtable_size: _Optional[int] = ..., max_memtables: _Optional[int] = ...) -> None: ...

class StartBulkImportResponse(_message.Message):
    __slots__ = ("success", "session_id", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    session_id: str
    message: str
    def __init__(self, success: bool = ..., session_id: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class CheckpointRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class CheckpointResponse(_message.Message):
    __slots__ = ("success", "record_count", "last_checkpoint_count", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    RECORD_COUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_CHECKPOINT_COUNT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    record_count: int
    last_checkpoint_count: int
    message: str
    def __init__(self, success: bool = ..., record_count: _Optional[int] = ..., last_checkpoint_count: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class EndBulkImportRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class EndBulkImportResponse(_message.Message):
    __slots__ = ("success", "total_records", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_RECORDS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    total_records: int
    message: str
    def __init__(self, success: bool = ..., total_records: _Optional[int] = ..., message: _Optional[str] = ...) -> None: ...

class AbortBulkImportRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class AbortBulkImportResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class GetBulkImportStatusRequest(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class GetBulkImportStatusResponse(_message.Message):
    __slots__ = ("is_active", "graph_name", "record_count", "last_checkpoint_count", "created_at", "last_activity")
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    GRAPH_NAME_FIELD_NUMBER: _ClassVar[int]
    RECORD_COUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_CHECKPOINT_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    is_active: bool
    graph_name: str
    record_count: int
    last_checkpoint_count: int
    created_at: int
    last_activity: int
    def __init__(self, is_active: bool = ..., graph_name: _Optional[str] = ..., record_count: _Optional[int] = ..., last_checkpoint_count: _Optional[int] = ..., created_at: _Optional[int] = ..., last_activity: _Optional[int] = ...) -> None: ...

class GetSystemMetricsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetSystemMetricsResponse(_message.Message):
    __slots__ = ("cpu", "memory", "disk_io", "storage", "network")
    CPU_FIELD_NUMBER: _ClassVar[int]
    MEMORY_FIELD_NUMBER: _ClassVar[int]
    DISK_IO_FIELD_NUMBER: _ClassVar[int]
    STORAGE_FIELD_NUMBER: _ClassVar[int]
    NETWORK_FIELD_NUMBER: _ClassVar[int]
    cpu: CpuMetrics
    memory: MemoryMetrics
    disk_io: DiskIOMetrics
    storage: StorageMetrics
    network: NetworkMetrics
    def __init__(self, cpu: _Optional[_Union[CpuMetrics, _Mapping]] = ..., memory: _Optional[_Union[MemoryMetrics, _Mapping]] = ..., disk_io: _Optional[_Union[DiskIOMetrics, _Mapping]] = ..., storage: _Optional[_Union[StorageMetrics, _Mapping]] = ..., network: _Optional[_Union[NetworkMetrics, _Mapping]] = ...) -> None: ...

class CpuMetrics(_message.Message):
    __slots__ = ("process_percent", "system_percent", "num_cores")
    PROCESS_PERCENT_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PERCENT_FIELD_NUMBER: _ClassVar[int]
    NUM_CORES_FIELD_NUMBER: _ClassVar[int]
    process_percent: float
    system_percent: float
    num_cores: int
    def __init__(self, process_percent: _Optional[float] = ..., system_percent: _Optional[float] = ..., num_cores: _Optional[int] = ...) -> None: ...

class MemoryMetrics(_message.Message):
    __slots__ = ("process_rss", "heap_alloc", "heap_sys", "stack_in_use", "system_total", "system_available", "system_used", "system_used_percent")
    PROCESS_RSS_FIELD_NUMBER: _ClassVar[int]
    HEAP_ALLOC_FIELD_NUMBER: _ClassVar[int]
    HEAP_SYS_FIELD_NUMBER: _ClassVar[int]
    STACK_IN_USE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_TOTAL_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_USED_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_USED_PERCENT_FIELD_NUMBER: _ClassVar[int]
    process_rss: int
    heap_alloc: int
    heap_sys: int
    stack_in_use: int
    system_total: int
    system_available: int
    system_used: int
    system_used_percent: float
    def __init__(self, process_rss: _Optional[int] = ..., heap_alloc: _Optional[int] = ..., heap_sys: _Optional[int] = ..., stack_in_use: _Optional[int] = ..., system_total: _Optional[int] = ..., system_available: _Optional[int] = ..., system_used: _Optional[int] = ..., system_used_percent: _Optional[float] = ...) -> None: ...

class DiskIOMetrics(_message.Message):
    __slots__ = ("read_bytes", "write_bytes", "read_count", "write_count")
    READ_BYTES_FIELD_NUMBER: _ClassVar[int]
    WRITE_BYTES_FIELD_NUMBER: _ClassVar[int]
    READ_COUNT_FIELD_NUMBER: _ClassVar[int]
    WRITE_COUNT_FIELD_NUMBER: _ClassVar[int]
    read_bytes: int
    write_bytes: int
    read_count: int
    write_count: int
    def __init__(self, read_bytes: _Optional[int] = ..., write_bytes: _Optional[int] = ..., read_count: _Optional[int] = ..., write_count: _Optional[int] = ...) -> None: ...

class StorageMetrics(_message.Message):
    __slots__ = ("db_path", "db_size_bytes", "volume_total", "volume_free", "volume_used")
    DB_PATH_FIELD_NUMBER: _ClassVar[int]
    DB_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    VOLUME_TOTAL_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FREE_FIELD_NUMBER: _ClassVar[int]
    VOLUME_USED_FIELD_NUMBER: _ClassVar[int]
    db_path: str
    db_size_bytes: int
    volume_total: int
    volume_free: int
    volume_used: int
    def __init__(self, db_path: _Optional[str] = ..., db_size_bytes: _Optional[int] = ..., volume_total: _Optional[int] = ..., volume_free: _Optional[int] = ..., volume_used: _Optional[int] = ...) -> None: ...

class NetworkMetrics(_message.Message):
    __slots__ = ("bytes_sent", "bytes_recv", "packets_sent", "packets_recv")
    BYTES_SENT_FIELD_NUMBER: _ClassVar[int]
    BYTES_RECV_FIELD_NUMBER: _ClassVar[int]
    PACKETS_SENT_FIELD_NUMBER: _ClassVar[int]
    PACKETS_RECV_FIELD_NUMBER: _ClassVar[int]
    bytes_sent: int
    bytes_recv: int
    packets_sent: int
    packets_recv: int
    def __init__(self, bytes_sent: _Optional[int] = ..., bytes_recv: _Optional[int] = ..., packets_sent: _Optional[int] = ..., packets_recv: _Optional[int] = ...) -> None: ...
