"""Bulk import types for GQLDB Python driver."""

from dataclasses import dataclass, field
from typing import Optional

@dataclass
class BulkCreateNodesOptions:
    """Options for bulk node creation."""
    overwrite: bool = False


@dataclass
class BulkCreateEdgesOptions:
    """Options for bulk edge creation."""
    skip_invalid_nodes: bool = False


@dataclass
class CompactResult:
    """Result of a compact operation."""
    success: bool = False
    message: str = ""


@dataclass
class BulkImportSession:
    """Bulk import session result."""
    success: bool = False
    session_id: str = ""
    message: str = ""


@dataclass
class CheckpointResult:
    """Result of a checkpoint operation."""
    success: bool = False
    record_count: int = 0
    last_checkpoint_count: int = 0
    message: str = ""


@dataclass
class EndBulkImportResult:
    """Result of ending a bulk import session."""
    success: bool = False
    total_records: int = 0
    message: str = ""


@dataclass
class AbortBulkImportResult:
    """Result of aborting a bulk import session."""
    success: bool = False
    message: str = ""


@dataclass
class BulkImportStatus:
    """Status of a bulk import session."""
    is_active: bool = False
    graph_name: str = ""
    record_count: int = 0
    last_checkpoint_count: int = 0
    created_at: int = 0
    last_activity: int = 0
