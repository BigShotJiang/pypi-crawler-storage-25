"""Graph entity types for GQLDB Python driver."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class GqldbNode:
    """Graph node."""
    id: str = ""
    labels: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GqldbEdge:
    """Graph edge."""
    id: str = ""
    label: str = ""
    from_node_id: str = ""
    to_node_id: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GqldbPath:
    """Graph path consisting of nodes and edges."""
    nodes: List[GqldbNode] = field(default_factory=list)
    edges: List[GqldbEdge] = field(default_factory=list)


@dataclass
class GqldbError:
    """Error value from TRY/CATCH handling."""
    code: int = 0
    message: str = ""


@dataclass
class NodeData:
    """Data for a node to be inserted."""
    labels: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EdgeData:
    """Data for an edge to be inserted."""
    label: str = ""
    from_node_id: str = ""
    to_node_id: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GraphInfo:
    """Information about a graph."""
    name: str
    graph_type: GraphType
    node_count: int
    edge_count: int
    description: str


@dataclass
class TransactionInfo:
    """Information about a transaction."""
    transaction_id: int
    session_id: int
    graph_name: str
    read_only: bool
    created_at: int
    duration_ms: int
    internal_tx_id: str


@dataclass
class ASTCacheStats:
    """AST cache statistics."""
    hits: int
    misses: int
    evictions: int
    entries: int
    hit_rate: float


@dataclass
class PlanCacheStats:
    """Plan cache statistics."""
    size: int
    capacity: int
    hits: int
    misses: int
    hit_rate: float


@dataclass
class CacheStats:
    """Combined cache statistics."""
    ast_stats: Optional[ASTCacheStats] = None
    plan_stats: Optional[PlanCacheStats] = None


@dataclass
class Statistics:
    """Database statistics."""
    node_count: int
    edge_count: int
    label_counts: Dict[str, int] = field(default_factory=dict)
    edge_label_counts: Dict[str, int] = field(default_factory=dict)


@dataclass
class ExportedNode:
    """A node exported from the database."""
    id: str
    labels: List[str]
    properties: Dict[str, Any]


@dataclass
class ExportedEdge:
    """An edge exported from the database."""
    id: str
    label: str
    from_node_id: str
    to_node_id: str
    properties: Dict[str, Any]
