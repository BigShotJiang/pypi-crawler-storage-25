"""Graph Service integration tests."""

import pytest
import time

from gqldb.client import GqldbClient
from gqldb.types import GraphType
from tests.conftest import drop_test_graph


@pytest.mark.integration
class TestGraph:
    """Tests for graph service."""

    def test_list_graphs(self, connected_client: GqldbClient):
        """Test listing available graphs."""
        graphs = connected_client.list_graphs()
        assert isinstance(graphs, list)
        print(f"Found {len(graphs)} graphs:")
        for g in graphs:
            print(f"  - {g.name} (type={g.graph_type}, nodes={g.node_count}, edges={g.edge_count})")

    def test_create_and_drop_graph(self, connected_client: GqldbClient):
        """Test creating and dropping a graph."""
        graph_name = f"test_graph_{int(time.time())}"

        # Create graph
        connected_client.create_graph(graph_name, GraphType.OPEN, "Test graph")
        print(f"Created graph: {graph_name}")

        # Verify graph exists
        graphs = connected_client.list_graphs()
        graph_names = [g.name for g in graphs]
        assert graph_name in graph_names

        # Get graph info
        info = connected_client.get_graph_info(graph_name)
        assert info.name == graph_name
        assert info.graph_type == GraphType.OPEN
        print(f"Graph info: {info}")

        # Drop graph (switch away first)
        drop_test_graph(connected_client, graph_name)
        print(f"Dropped graph: {graph_name}")

        # Verify graph is gone
        graphs = connected_client.list_graphs()
        graph_names = [g.name for g in graphs]
        assert graph_name not in graph_names

    def test_drop_graph_if_exists(self, connected_client: GqldbClient):
        """Test dropping a non-existent graph with if_exists=True."""
        # Should not raise error
        connected_client.drop_graph("non_existent_graph_12345", if_exists=True)

    def test_get_graph_info(self, connected_client: GqldbClient):
        """Test getting graph info for an existing graph."""
        info = connected_client.get_graph_info("miniCircle")
        assert info is not None
        assert info.name == "miniCircle"
        print(f"Graph info for miniCircle: type={info.graph_type}, nodes={info.node_count}, edges={info.edge_count}")
