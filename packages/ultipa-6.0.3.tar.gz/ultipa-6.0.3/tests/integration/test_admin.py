"""AdminService integration tests."""

import pytest

from gqldb.client import GqldbClient
from gqldb.types import CacheType


@pytest.mark.integration
class TestAdminService:
    """Tests for AdminService operations."""

    def test_warmup_parser(self, connected_client: GqldbClient):
        """Test warmup parser."""
        connected_client.warmup_parser(2)

    def test_get_cache_stats(self, connected_client: GqldbClient):
        """Test getting cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.ALL)
        assert stats is not None
        print(f"CacheStats: {stats}")

    def test_get_cache_stats_ast(self, connected_client: GqldbClient):
        """Test getting AST cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.AST)
        assert stats is not None

    def test_get_cache_stats_plan(self, connected_client: GqldbClient):
        """Test getting plan cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.PLAN)
        assert stats is not None

    def test_clear_cache(self, connected_client: GqldbClient):
        """Test clearing all caches."""
        connected_client.clear_cache(CacheType.ALL)

    def test_get_statistics(self, connected_client: GqldbClient):
        """Test getting database statistics."""
        stats = connected_client.get_statistics("miniCircle")
        assert stats is not None
        print(f"Statistics: nodes={stats.node_count}, edges={stats.edge_count}")

    def test_get_statistics_default(self, connected_client: GqldbClient):
        """Test getting statistics with default graph."""
        stats = connected_client.get_statistics("default")
        assert stats is not None

    def test_invalidate_permission_cache(self, connected_client: GqldbClient):
        """Test invalidating permission cache."""
        connected_client.invalidate_permission_cache()

    def test_compact(self, connected_client: GqldbClient):
        """Test manual compaction."""
        result = connected_client.compact()
        assert result is not None
        print(f"Compact: success={result.success}, message={result.message}")

    def test_get_system_metrics(self, connected_client: GqldbClient):
        """Test getting system metrics."""
        metrics = connected_client.get_system_metrics()
        assert metrics is not None

        if metrics.cpu is not None:
            print(f"CPU: process={metrics.cpu.process_percent:.2f}%, "
                  f"system={metrics.cpu.system_percent:.2f}%, cores={metrics.cpu.num_cores}")
        if metrics.memory is not None:
            print(f"Memory: rss={metrics.memory.process_rss}, "
                  f"total={metrics.memory.system_total}")
        if metrics.disk_io is not None:
            print(f"DiskIO: read={metrics.disk_io.read_bytes}, "
                  f"write={metrics.disk_io.write_bytes}")
        if metrics.storage is not None:
            print(f"Storage: path={metrics.storage.db_path}, "
                  f"size={metrics.storage.db_size_bytes}")
        if metrics.network is not None:
            print(f"Network: sent={metrics.network.bytes_sent}, "
                  f"recv={metrics.network.bytes_recv}")
