"""Health Service integration tests."""

import pytest

from gqldb.client import GqldbClient
from gqldb.types import HealthStatus


@pytest.mark.integration
class TestHealth:
    """Tests for health check operations."""

    def test_health_check(self, connected_client: GqldbClient):
        """Test basic health check."""
        status = connected_client.health_check()
        assert status is not None
        assert status in [HealthStatus.SERVING, HealthStatus.UNKNOWN]
        print(f"Health check status: {status}")

    def test_health_check_with_service(self, connected_client: GqldbClient):
        """Test health check for specific service."""
        try:
            status = connected_client.health_check("gqldb")
            print(f"Health check for 'gqldb': {status}")
        except Exception as e:
            print(f"Health check with service name: {e}")
