# mcp-video-preview

An MCP server that lets Claude visually inspect video files — extract frames, check text overlays, karaoke subtitles, background clips, and more.

## Requirements

- Python 3.10+
- [ffmpeg](https://ffmpeg.org/download.html) installed and in your PATH

## Installation

```bash
pip install mcp-video-preview
```

## Setup

Add to your Claude Code config (`~/.claude.json`):

```json
{
  "mcpServers": {
    "video-preview": {
      "command": "mcp-video-preview",
      "args": [],
      "env": {}
    }
  }
}
```

Or for **Claude Desktop** (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "video-preview": {
      "command": "mcp-video-preview"
    }
  }
}
```

Restart Claude after editing the config.

## Tools

### `preview_video(path, n_frames=9)`
Extracts N evenly-spaced frames from a video and returns them as images.  
Claude can then visually check text overlays, subtitles, background images, etc.

### `extract_frame(path, time_s)`
Extracts a single frame at a specific timestamp (in seconds).

### `get_video_info(path)`
Returns video metadata: duration, resolution, fps, file size.

## Example usage

Once installed, just ask Claude:
- *"Preview the video at C:/output/video.mp4"*
- *"Check if the text overlay is readable in this video"*
- *"Extract a frame at 10 seconds from this video"*

## License

MIT
