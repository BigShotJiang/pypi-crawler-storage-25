"""
mcp-video-preview — MCP server that lets Claude inspect video files.

Tools:
  preview_video(path, n_frames=9)  — extract N evenly-spaced frames as images
  get_video_info(path)             — duration, dimensions, fps, file size
  extract_frame(path, time_s)      — single frame at a specific timestamp
"""

import base64
import json
import subprocess
import tempfile
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("video-preview")


def _run_ffprobe(args: list[str]) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "quiet", "-print_format", "json"] + args,
        capture_output=True, text=True
    )
    return json.loads(result.stdout) if result.stdout.strip() else {}


def _frame_to_b64(frame_path: Path) -> str:
    return base64.standard_b64encode(frame_path.read_bytes()).decode()


@mcp.tool()
def get_video_info(path: str) -> str:
    """Get video metadata: duration, dimensions, fps, file size."""
    p = Path(path)
    if not p.exists():
        return f"File not found: {path}"

    info = _run_ffprobe([
        "-show_streams", "-show_format", str(p)
    ])

    size_mb = p.stat().st_size / 1024 / 1024
    fmt = info.get("format", {})
    duration = float(fmt.get("duration", 0))

    video_stream = next(
        (s for s in info.get("streams", []) if s.get("codec_type") == "video"),
        {}
    )
    width  = video_stream.get("width", "?")
    height = video_stream.get("height", "?")
    fps_raw = video_stream.get("r_frame_rate", "0/1")
    try:
        num, den = fps_raw.split("/")
        fps = round(int(num) / int(den), 2)
    except Exception:
        fps = fps_raw

    return (
        f"File: {p.name}\n"
        f"Size: {size_mb:.1f} MB\n"
        f"Duration: {duration:.1f}s ({duration/60:.1f} min)\n"
        f"Resolution: {width}x{height}\n"
        f"FPS: {fps}\n"
        f"Format: {fmt.get('format_long_name', '?')}"
    )


@mcp.tool()
def preview_video(path: str, n_frames: int = 9) -> list:
    """Extract N evenly-spaced frames from a video for visual inspection.
    Returns images showing text overlays, karaoke subtitles, background clips, etc.
    Default 9 frames gives a good overview of the whole video.
    """
    p = Path(path)
    if not p.exists():
        return [{"type": "text", "text": f"File not found: {path}"}]

    # Get duration
    info = _run_ffprobe(["-show_format", str(p)])
    duration = float(info.get("format", {}).get("duration", 0))
    if duration == 0:
        return [{"type": "text", "text": "Could not determine video duration"}]

    n_frames = max(1, min(n_frames, 20))
    interval = duration / (n_frames + 1)

    results = [{"type": "text", "text": f"Video: {p.name} ({duration:.1f}s) — {n_frames} frames"}]

    with tempfile.TemporaryDirectory() as tmpdir:
        for i in range(n_frames):
            t = interval * (i + 1)
            frame_path = Path(tmpdir) / f"frame_{i:02d}.jpg"
            subprocess.run(
                ["ffmpeg", "-y", "-ss", str(t), "-i", str(p),
                 "-vframes", "1", "-q:v", "3", str(frame_path)],
                capture_output=True
            )
            if frame_path.exists():
                results.append({
                    "type": "image",
                    "data": _frame_to_b64(frame_path),
                    "mimeType": "image/jpeg"
                })
                results.append({
                    "type": "text",
                    "text": f"t={t:.1f}s"
                })

    return results


@mcp.tool()
def extract_frame(path: str, time_s: float) -> list:
    """Extract a single frame at a specific timestamp (in seconds) for detailed inspection."""
    p = Path(path)
    if not p.exists():
        return [{"type": "text", "text": f"File not found: {path}"}]

    with tempfile.TemporaryDirectory() as tmpdir:
        frame_path = Path(tmpdir) / "frame.jpg"
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(time_s), "-i", str(p),
             "-vframes", "1", "-q:v", "2", str(frame_path)],
            capture_output=True
        )
        if not frame_path.exists():
            return [{"type": "text", "text": f"Could not extract frame at t={time_s}s"}]

        return [
            {"type": "text", "text": f"{p.name} @ t={time_s}s"},
            {"type": "image", "data": _frame_to_b64(frame_path), "mimeType": "image/jpeg"}
        ]


def main():
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
