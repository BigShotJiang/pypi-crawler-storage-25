# Changelog

All notable changes to the AGLedger Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.7.2] - 2026-05-02

Resolves cross-repo issue agledger-agents#62 (testbed F-524). Type-safety / parity gaps versus TS SDK 0.7.1 with no API change.

### Fixed
- **`agledger.verify.verify_export()` now accepts the typed `RecordAuditExport` model** returned by `client.records.get_audit_export()`. Previously raised `AttributeError` deep in the call stack — customers building the canonical fetch+verify flow had to manually `.model_dump(by_alias=True)` first. Both raw `dict` and Pydantic model inputs are supported.
- **`auth.get_me()` now returns the typed `AccountProfile`** (was raw `dict`). The model was already exported from the package — it just wasn't applied to the deserialization path.
- **`records.bulk_create()` now returns the typed `BulkCreateResult`** with nested `BulkCreateResultItem` and `BulkCreateSummary` (was raw `dict`).
- **`RecordAuditExport.export_metadata` is now a typed `AuditExportMetadata`** sub-model (was raw `dict`). Fields: `record_id`, `enterprise_id`, `type`, `operating_mode`, `export_date`, `total_entries`, `expected_entries`, `chain_integrity`, `chain_integrity_reason`, `export_format_version`, `canonicalization`, `signing_public_key`, `signing_public_keys`.
- **`agledger.verify` raises `ImportError` at import time** when `cryptography` is missing — was a deep `RuntimeError` six frames into `verify_export`. Install message unchanged: `pip install 'agledger[verify]'`.

### Added
- New typed models: `AuditExportMetadata`, `BulkCreateResult`, `BulkCreateResultItem`, `BulkCreateSummary`.

## [0.7.1] - 2026-04-30

Tracks AGLedger API v0.22.13. Adds 10 new routes mirroring the TS SDK 0.7.1: tenant string overrides admin (`AdminStringsResource`), `federation_admin.get_gateway_status()`, `agents.list()` peer directory, `compliance.list_vault_checkpoints()`, and `disputes.withdraw()`.

## [0.7.0] - 2026-04-27

Tracks AGLedger API v0.21.0 — the customer-facing vocabulary rewrite.
Mirrors the TypeScript SDK v0.7.0 release. No production customers; no
backwards-compatibility shims.

### Changed (BREAKING)
- **Mandate → Record rename throughout.** Every `/v1/mandates/*` route is now
  `/v1/records/*`. Resource is `client.records` (was `client.mandates`).
  Path params `{contractType}` are `{type}`. Vocabulary: Record (data model),
  Type (was Contract Type).
- **Type / model renames.**
  - `Mandate` → `RecordRow`
  - `MandateStatus` → `RecordStatus` (adds `RECORDED`)
  - `MandateTransitionAction` → `RecordTransitionAction`
    (`register | propose | activate | cancel`; no `MARK_INVALID` — internal-only)
  - `ContractType` → `RecordType`
- **Record-response fields:** `principal_type` removed; added `category`,
  `outcome`, `correlation_id`, `requested_by`, `vault_receipt`,
  `acceptance_status`, `acceptance_responded_at`,
  `parent_principal_enterprise_matches_performer`, `commission_amount`,
  `self_commitment`, `parent_record_id`, `root_record_id`, `child_record_ids`.
- **Webhook event types** — all `mandate.*` are now `record.*`
  (`record.created`, `record.fulfilled`, `record.delegated`, etc.).
- **Scope constants** `MANDATES_READ`/`MANDATES_WRITE` → `RECORDS_READ`/`RECORDS_WRITE`.
- **Compliance per-Record audit export** is now `client.records.get_audit_export()`
  (the duplicate `compliance.export_mandate()` was removed).
- **Field renames:** `parent_mandate_id` → `parent_record_id`,
  `mandate_id` → `record_id`, `record_id` (in compliance attestation context)
  remains the compliance-record id; clarified per resource.
- **Capabilities body field stays `contractTypes`** — the API kept the legacy
  field name on this endpoint despite the broader Type rename. Pythonic
  `contract_types` kwarg, camelCase to API.
- **Conformance** lives only on `client.discovery.get_conformance()`; the
  duplicate `client.health.conformance()` was removed.
- **Removed dead types:** `AuditChain`, `AccountType`, `MandateStatusSummary`,
  `DashboardSummary`, `DashboardAgent`, `DashboardAlert`, `Project`,
  `EnterpriseAgentRecord`, `ApprovalConfig`. `client.events.get_audit_chain()`
  removed (route does not exist).

### Added
- **`client.records.my_verdict_statistics()`** → `GET /v1/records/me/verdict-statistics`
- **`client.records.list_proposals()`** → `GET /v1/records/agent/proposals`
- **`client.records.batch_get([...])`** → `POST /v1/records/batch`
- **`client.records.bulk_create([...])`** → `POST /v1/records/bulk`
  (per-item idempotency_key supported)
- **`client.records.get_audit_export()`** — canonical per-Record audit export
- **`client.disputes.list(...)`** → `GET /v1/disputes` (tenant-wide)
- **`client.audit.tenant_reads_checkpoints.{list, get, cosign, proof}`** →
  `/v1/audit/tenant-reads/checkpoints/*` (new top-level resource)
- **`client.admin.records.{list, import_}`** →
  `GET /v1/admin/records`, `POST /v1/admin/records/import`
- **`client.admin.vault.{anchors{list, verify}, scan{run, status}, signing_keys{list, rotate}}`**
- **`client.schemas.meta_schema()`, `blank()`, `import_()`, `preview()`,
  `disable()`, `enable()`** → `/v1/schemas/{meta-schema, _blank, import, preview}`
  + disable/enable
- **Record lifecycle module** — `agledger.record_lifecycle` with
  `RECORD_TRANSITIONS`, `TERMINAL_STATUSES`, `can_transition_to()`,
  `get_valid_transitions()`, `is_terminal_status()`. Re-exported from
  `agledger`.
- **Errors** now surface `recovery_hint` and `refresh_url` extension fields
  (RFC 9457). Set on 422 INVALID_ACTION when the API can name a corrective
  step.
- **Top-level `missingScopes`** parsed from RFC 9457 problem+json bodies in
  addition to the legacy `details.missingScopes` location.

### Verify export
- `VerifyExportResult.mandate_id` → `record_id`. Doc strings updated to
  reference `/v1/records/{id}/audit-export`. Reads `recordId` from export
  metadata, falling back to legacy `mandateId` for older exports.

### Technical
- `User-Agent: agledger-python/0.7.0`.
- `keywords` updated `mandates` → `records` in `pyproject.toml`.

## [0.6.0] - 2026-04-23

Tracks AGLedger API v0.20.0 — the pre-launch principal-model rewrite.
Mirrors the TypeScript SDK v0.6.0 release. No production customers; no
migration shims.

### Changed (BREAKING)
- **API key role `enterprise` → `admin`.** `ApiKeyRole` type is now
  `Literal["admin", "agent", "platform"]`.
- **API key prefix `ach_(ent|age|pla)_*` → `agl_(adm|agt|plt)_*`.**
- **Scope profiles renamed and trimmed to 7.** New: `admin-standard`
  (default admin), `admin-observer`, `admin-iac`, `admin-schema`,
  `agent-full` (default agent), `agent-readonly`, `agent-performer-only`.
  Retired: `standard`, `restrictive`, `iac-pipeline`, `schema-manager`,
  `monitor`, `dashboard`, `sidecar`. `ScopeProfile` now exposes
  `allowed_roles`.
- **Scope constants `DASHBOARD_READ` and `AUDIT_ANALYZE` removed.**
  `ADMIN_TRUST` renamed to `ADMIN_BACKFILL`.
- **Principal model collapsed.** Every mandate has `principal_agent_id`
  (one named agent, required). Self-commitment valid. Agent keys default
  principal to themselves; admin keys must name the principal.
- **Unified `POST /v1/mandates`** for admin, agent, and platform callers.
- **Audit route rename `/v1/audit/stream` → `/v1/siem/stream`.**
- **Auth surface trimmed** to `GET /v1/auth/me` and `POST /v1/auth/keys/rotate`.

### Added
- **`AuthResource` / `AsyncAuthResource`** — `client.auth.get_me()` and
  `client.auth.rotate_key()`.
- **`DiscoveryResource` / `AsyncDiscoveryResource`** —
  `client.discovery.get_scope_profiles()`, `get_conformance()`,
  `get_lifecycle()`.
- `default_profile_for(role)` helper mirroring the API.
- `agent-performer-only` scope profile — performer that can deliver
  receipts and read mandates but cannot be a principal.

### Removed
- Resources: `dashboard`, `proxy` (governance sidecar sync), `notarize`
  (OpenClaw legacy), `projects`, `registration`, `enterprises`.
- Types: `DashboardSummary`, `DashboardAgent`, `DashboardAlert`,
  `EnterpriseAgentRecord`, `Project`, `ApprovalConfig`,
  `MandateStatusSummary`, trust-level types.
- Methods: `compliance.analyze()`, `mandates.get_summary()`, trust-level
  admin methods, `/v1/audit/enterprise-report*`.

### Parity test
- `test_parity.py` rewritten as a focused invariant set (critical routes
  present, retired routes absent, shape assertions on POST bodies).
- Shared `routes.json` regenerated from API v0.20.0 OpenAPI (188 routes).

## [0.1.0] - 2026-04-02

### Added
- `AgledgerClient` (sync) and `AsyncAgledgerClient` (async) with 23 resource sub-clients each
- Full error hierarchy: `APIError`, `AuthenticationError`, `PermissionDeniedError` (with `missing_scopes`), `NotFoundError`, `BadRequestError`, `ConflictError`, `UnprocessableError`, `RateLimitError`, `APIConnectionError`, `APITimeoutError`, `SignatureVerificationError`
- `doc_url` and `suggestion` on all API errors
- Auto-pagination via generators (`list_all()` methods)
- Retry with exponential backoff + jitter, respects `Retry-After`
- Auto-generated idempotency keys on mutations
- Webhook signature verification via `agledger.webhooks`
- Context manager support (`with AgledgerClient() as client:`)
- Environment variable fallback (`AGLEDGER_API_KEY`)
- Typed kwargs on core resources (mandates, receipts) with full IDE autocomplete
- 11 Pydantic v2 models: AgentProfile, VerificationStatus, WebhookTestResult, DashboardStats, DashboardAlert, DashboardAgent, Project, AgentCapabilities, ComplianceExport, AiImpactAssessment, EuAiActReport
- `py.typed` marker for PEP 561 compliance
- 101 tests (pytest + respx) with async coverage
- SECURITY.md with CVE disclosure policy

### Technical
- Python >=3.10
- Dependencies: httpx >=0.27.0, pydantic >=2.0.0
- Pydantic v2 models with `populate_by_name=True` and `extra="allow"` for forward compatibility
- Modern union syntax (`X | None`) throughout
