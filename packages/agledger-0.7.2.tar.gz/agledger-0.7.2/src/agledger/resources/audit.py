"""Audit resource — verifiable read-trail surface (SCITT-style tenant-reads checkpoints)."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import TenantReadsCheckpoint, TenantReadsInclusionProof


class TenantReadsCheckpointsResource:
    """Tenant-admin reads checkpoint surface — SCITT-style signed tree heads
    (``/v1/audit/tenant-reads/checkpoints/*``). Each cross-party admin read is
    logged into a per-tenant Merkle log and periodically anchored."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self, *, limit: int | None = None) -> dict[str, Any]:
        """List recent signed checkpoints for the calling tenant."""
        params: dict[str, Any] = {}
        if limit is not None: params["limit"] = limit
        return self._http.get("/v1/audit/tenant-reads/checkpoints", params=params)

    def get(self, checkpoint_id: str) -> TenantReadsCheckpoint:
        """Get a single checkpoint by ID."""
        return TenantReadsCheckpoint.model_validate(
            self._http.get(f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}")
        )

    def cosign(
        self,
        checkpoint_id: str,
        *,
        witness_key_id: str,
        witness_signature: str,
    ) -> TenantReadsCheckpoint:
        """Attach a witness cosignature to a checkpoint. The witness's signature
        format/algorithm is the customer's choice — the API stores the bytes verbatim."""
        return TenantReadsCheckpoint.model_validate(
            self._http.post(
                f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}/cosign",
                json={"witnessKeyId": witness_key_id, "witnessSignature": witness_signature},
            )
        )

    def proof(self, checkpoint_id: str, leaf: str) -> TenantReadsInclusionProof:
        """Get the inclusion proof for a leaf within this checkpoint."""
        return TenantReadsInclusionProof.model_validate(
            self._http.get(
                f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}/proof",
                params={"leaf": leaf},
            )
        )


class AsyncTenantReadsCheckpointsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(self, *, limit: int | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if limit is not None: params["limit"] = limit
        return await self._http.get("/v1/audit/tenant-reads/checkpoints", params=params)

    async def get(self, checkpoint_id: str) -> TenantReadsCheckpoint:
        return TenantReadsCheckpoint.model_validate(
            await self._http.get(f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}")
        )

    async def cosign(
        self,
        checkpoint_id: str,
        *,
        witness_key_id: str,
        witness_signature: str,
    ) -> TenantReadsCheckpoint:
        return TenantReadsCheckpoint.model_validate(
            await self._http.post(
                f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}/cosign",
                json={"witnessKeyId": witness_key_id, "witnessSignature": witness_signature},
            )
        )

    async def proof(self, checkpoint_id: str, leaf: str) -> TenantReadsInclusionProof:
        return TenantReadsInclusionProof.model_validate(
            await self._http.get(
                f"/v1/audit/tenant-reads/checkpoints/{checkpoint_id}/proof",
                params={"leaf": leaf},
            )
        )


class AuditResource:
    """Audit resource — verifiable read-trail surface."""

    def __init__(self, http: HttpClient) -> None:
        self.tenant_reads_checkpoints = TenantReadsCheckpointsResource(http)


class AsyncAuditResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self.tenant_reads_checkpoints = AsyncTenantReadsCheckpointsResource(http)
