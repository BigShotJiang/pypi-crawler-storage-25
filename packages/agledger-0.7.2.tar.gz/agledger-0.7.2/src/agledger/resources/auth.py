"""
Authentication resource — `GET /v1/auth/me` (identity + scopes) and
`POST /v1/auth/keys/rotate` (atomic key rotation). Account provisioning
happens via the admin endpoints.
"""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import AccountProfile


class AuthResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_me(self) -> AccountProfile:
        """Get the authenticated account profile (identity, role, scopes)."""
        return AccountProfile.model_validate(self._http.get("/v1/auth/me"))

    def rotate_key(self) -> dict[str, Any]:
        """Rotate the current API key. Old key is immediately revoked."""
        return self._http.post("/v1/auth/keys/rotate")


class AsyncAuthResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_me(self) -> AccountProfile:
        """Get the authenticated account profile (identity, role, scopes)."""
        return AccountProfile.model_validate(await self._http.get("/v1/auth/me"))

    async def rotate_key(self) -> dict[str, Any]:
        """Rotate the current API key. Old key is immediately revoked."""
        return await self._http.post("/v1/auth/keys/rotate")
