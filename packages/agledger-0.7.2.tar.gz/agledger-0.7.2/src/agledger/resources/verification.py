"""Verification resource."""

from __future__ import annotations
from typing import Any
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import VerificationResult, VerificationStatus


class VerificationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def verify(self, record_id: str, receipt_ids: list[str] | None = None) -> VerificationResult:
        body: dict[str, Any] = {}
        if receipt_ids:
            body["receiptIds"] = receipt_ids
        data = self._http.post(f"/v1/records/{record_id}/verify", json=body)
        return VerificationResult.model_validate(data)

    def get_status(self, record_id: str) -> VerificationStatus:
        """Get the verification status for a Record."""
        return VerificationStatus.model_validate(self._http.get(f"/v1/records/{record_id}/verification-status"))


class AsyncVerificationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def verify(self, record_id: str, receipt_ids: list[str] | None = None) -> VerificationResult:
        body: dict[str, Any] = {}
        if receipt_ids:
            body["receiptIds"] = receipt_ids
        data = await self._http.post(f"/v1/records/{record_id}/verify", json=body)
        return VerificationResult.model_validate(data)

    async def get_status(self, record_id: str) -> VerificationStatus:
        """Get the verification status for a Record."""
        return VerificationStatus.model_validate(await self._http.get(f"/v1/records/{record_id}/verification-status"))
