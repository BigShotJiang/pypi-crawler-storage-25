"""Federation admin resource — platform admin operations."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class FederationAdminResource:
    """Platform admin federation operations (API key auth, admin:system scope)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create_registration_token(
        self,
        *,
        label: str | None = None,
        expires_in_hours: int | None = None,
        metadata: dict[str, Any] | None = None,
        allowed_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a single-use registration token for a new gateway."""
        body: dict[str, Any] = {}
        if label is not None: body["label"] = label
        if expires_in_hours is not None: body["expiresInHours"] = expires_in_hours
        if metadata is not None: body["metadata"] = metadata
        if allowed_types is not None: body["allowedTypes"] = allowed_types
        return self._http.post("/federation/v1/admin/registration-tokens", json=body)

    def list_gateways(self, **params: Any) -> dict[str, Any]:
        """List registered federation gateways."""
        return self._http.get_page("/federation/v1/admin/gateways", params=params)

    def revoke_gateway(self, gateway_id: str, *, reason: str) -> dict[str, Any]:
        """Admin-initiated gateway revocation (irreversible)."""
        return self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/revoke", json={"reason": reason})

    def query_records(self, **params: Any) -> dict[str, Any]:
        """Query federation Records tracked by the hub."""
        mapping = {"gateway_id": "gatewayId", "hub_state": "hubState"}
        mapped = {mapping.get(k, k): v for k, v in params.items()}
        return self._http.get_page("/federation/v1/admin/records", params=mapped)

    def get_audit_log(self, **params: Any) -> dict[str, Any]:
        """Query the federation audit log (hash-chained)."""
        mapping = {"gateway_id": "gatewayId", "entry_type": "entryType", "record_id": "recordId"}
        mapped = {mapping.get(k, k): v for k, v in params.items()}
        return self._http.get_page("/federation/v1/admin/audit-log", params=mapped)

    def get_health(self) -> dict[str, Any]:
        """Get federation health summary."""
        return self._http.get("/federation/v1/admin/health")

    def get_gateway_status(self) -> dict[str, Any]:
        """Gateway-side federation status — this node's view of its hub link.

        Different from ``get_health()`` (the hub's view of all gateways). Useful
        for confirming this gateway is still registered and how deep its
        outbound DLQ has grown.
        """
        return self._http.get("/federation/v1/admin/gateway-status")

    def reset_sequence(self, gateway_id: str, *, new_seq: int | None = None) -> dict[str, Any]:
        """Reset a gateway's sequence counter."""
        body: dict[str, Any] = {}
        if new_seq is not None:
            body["newSeq"] = new_seq
        return self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/reset-seq", json=body)

    def list_dlq(self, **params: Any) -> dict[str, Any]:
        """List outbound DLQ entries."""
        return self._http.get_page("/federation/v1/admin/outbound-dlq", params=params)

    def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Retry a failed outbound federation message."""
        return self._http.post(f"/federation/v1/admin/outbound-dlq/{dlq_id}/retry", json={})

    def delete_dlq(self, dlq_id: str) -> dict[str, Any]:
        """Permanently discard a failed outbound message from the DLQ."""
        return self._http.delete(f"/federation/v1/admin/outbound-dlq/{dlq_id}")

    def rotate_hub_key(self) -> dict[str, Any]:
        """Rotate the federation hub signing key."""
        return self._http.post("/federation/v1/admin/rotate-hub-key", json={})

    def list_hub_keys(self) -> dict[str, Any]:
        """List all hub signing keys."""
        return self._http.get("/federation/v1/admin/hub-keys")

    def activate_hub_key(self, key_id: str) -> dict[str, Any]:
        """Activate a hub signing key."""
        return self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/activate", json={})

    def expire_hub_key(self, key_id: str) -> dict[str, Any]:
        """Expire a hub signing key."""
        return self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/expire", json={})

    def register_peer(self, **params: Any) -> dict[str, Any]:
        """Register a new peer gateway for hub-to-hub federation."""
        return self._http.post("/federation/v1/peer", json=params)

    def list_peers(self) -> dict[str, Any]:
        """List all peer gateways known to this hub."""
        return self._http.get_page("/federation/v1/admin/peers")

    def get_peer(self, hub_id: str) -> dict[str, Any]:
        """Get details for a specific peer gateway."""
        return self._http.get(f"/federation/v1/admin/peers/{hub_id}")

    def revoke_peer(self, hub_id: str) -> dict[str, Any]:
        """Revoke a peer gateway."""
        return self._http.post(f"/federation/v1/admin/peers/{hub_id}/revoke", json={})

    def resync_peer(self, hub_id: str) -> dict[str, Any]:
        """Trigger a full resync with a peer gateway."""
        return self._http.post(f"/federation/v1/admin/peers/{hub_id}/resync", json={})

    def create_peering_token(self) -> dict[str, Any]:
        """Create a single-use peering token for hub-to-hub federation setup."""
        return self._http.post("/federation/v1/admin/peering-tokens", json={})

    def delete_schema_version(self, type: str, version: str) -> dict[str, Any]:
        """Delete a specific version of a federated Type schema."""
        return self._http.delete(f"/federation/v1/admin/schemas/{type}/{version}")

    def list_reputation_contributions(self, agent_id: str) -> dict[str, Any]:
        """List reputation contributions for an agent."""
        return self._http.get(f"/federation/v1/admin/reputation/{agent_id}")

    def reset_reputation(self, agent_id: str) -> dict[str, Any]:
        """Reset an agent's federated reputation (deletes all contributions)."""
        return self._http.delete(f"/federation/v1/admin/reputation/{agent_id}")

    def get_record_criteria_encryption_metadata(self, record_id: str) -> dict[str, Any]:
        """Get encryption metadata for a federated Record's negotiated criteria."""
        return self._http.get(f"/federation/v1/admin/records/{record_id}/criteria-encryption-metadata")


class AsyncFederationAdminResource:
    """Async platform admin federation operations."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create_registration_token(
        self, *, label: str | None = None, expires_in_hours: int | None = None,
        metadata: dict[str, Any] | None = None, allowed_types: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if label is not None: body["label"] = label
        if expires_in_hours is not None: body["expiresInHours"] = expires_in_hours
        if metadata is not None: body["metadata"] = metadata
        if allowed_types is not None: body["allowedTypes"] = allowed_types
        return await self._http.post("/federation/v1/admin/registration-tokens", json=body)

    async def list_gateways(self, **params: Any) -> dict[str, Any]:
        return await self._http.get_page("/federation/v1/admin/gateways", params=params)

    async def revoke_gateway(self, gateway_id: str, *, reason: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/revoke", json={"reason": reason})

    async def query_records(self, **params: Any) -> dict[str, Any]:
        mapping = {"gateway_id": "gatewayId", "hub_state": "hubState"}
        mapped = {mapping.get(k, k): v for k, v in params.items()}
        return await self._http.get_page("/federation/v1/admin/records", params=mapped)

    async def get_audit_log(self, **params: Any) -> dict[str, Any]:
        mapping = {"gateway_id": "gatewayId", "entry_type": "entryType", "record_id": "recordId"}
        mapped = {mapping.get(k, k): v for k, v in params.items()}
        return await self._http.get_page("/federation/v1/admin/audit-log", params=mapped)

    async def get_health(self) -> dict[str, Any]:
        return await self._http.get("/federation/v1/admin/health")

    async def get_gateway_status(self) -> dict[str, Any]:
        """Gateway-side federation status — this node's view of its hub link."""
        return await self._http.get("/federation/v1/admin/gateway-status")

    async def reset_sequence(self, gateway_id: str, *, new_seq: int | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if new_seq is not None:
            body["newSeq"] = new_seq
        return await self._http.post(f"/federation/v1/admin/gateways/{gateway_id}/reset-seq", json=body)

    async def list_dlq(self, **params: Any) -> dict[str, Any]:
        return await self._http.get_page("/federation/v1/admin/outbound-dlq", params=params)

    async def retry_dlq(self, dlq_id: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/outbound-dlq/{dlq_id}/retry", json={})

    async def delete_dlq(self, dlq_id: str) -> dict[str, Any]:
        return await self._http.delete(f"/federation/v1/admin/outbound-dlq/{dlq_id}")

    async def rotate_hub_key(self) -> dict[str, Any]:
        return await self._http.post("/federation/v1/admin/rotate-hub-key", json={})

    async def list_hub_keys(self) -> dict[str, Any]:
        return await self._http.get("/federation/v1/admin/hub-keys")

    async def activate_hub_key(self, key_id: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/activate", json={})

    async def expire_hub_key(self, key_id: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/hub-keys/{key_id}/expire", json={})

    async def register_peer(self, **params: Any) -> dict[str, Any]:
        return await self._http.post("/federation/v1/peer", json=params)

    async def list_peers(self) -> dict[str, Any]:
        return await self._http.get_page("/federation/v1/admin/peers")

    async def get_peer(self, hub_id: str) -> dict[str, Any]:
        return await self._http.get(f"/federation/v1/admin/peers/{hub_id}")

    async def revoke_peer(self, hub_id: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/peers/{hub_id}/revoke", json={})

    async def resync_peer(self, hub_id: str) -> dict[str, Any]:
        return await self._http.post(f"/federation/v1/admin/peers/{hub_id}/resync", json={})

    async def create_peering_token(self) -> dict[str, Any]:
        return await self._http.post("/federation/v1/admin/peering-tokens", json={})

    async def delete_schema_version(self, type: str, version: str) -> dict[str, Any]:
        return await self._http.delete(f"/federation/v1/admin/schemas/{type}/{version}")

    async def list_reputation_contributions(self, agent_id: str) -> dict[str, Any]:
        return await self._http.get(f"/federation/v1/admin/reputation/{agent_id}")

    async def reset_reputation(self, agent_id: str) -> dict[str, Any]:
        return await self._http.delete(f"/federation/v1/admin/reputation/{agent_id}")

    async def get_record_criteria_encryption_metadata(self, record_id: str) -> dict[str, Any]:
        return await self._http.get(f"/federation/v1/admin/records/{record_id}/criteria-encryption-metadata")
