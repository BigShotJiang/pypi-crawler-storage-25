"""
AGLedger SDK — Type definitions.
Mirrors the TypeScript SDK types. All models are Pydantic v2.
"""

from __future__ import annotations

from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field


class NextStep(BaseModel):
    """A suggested next API call — guides agents through the lifecycle."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    action: str
    """What to do next."""
    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"]
    """HTTP method."""
    href: str
    """Relative URL template (substitute {id} placeholders)."""
    description: str
    """Why this step matters."""


RecordType = Literal[
    "ACH-PROC-v1",
    "ACH-DLVR-v1",
    "ACH-DATA-v1",
    "ACH-TXN-v1",
    "ACH-ORCH-v1",
    "ACH-COMM-v1",
    "ACH-AUTH-v1",
    "ACH-INFRA-v1",
    "ACH-DEL-v1",
    "ACH-ANALYZE-v1",
    "ACH-COORD-v1",
    "ACH-MON-v1",
    "ACH-REVIEW-v1",
]


RecordStatus = Literal[
    "CREATED",
    "PROPOSED",
    "ACTIVE",
    "PROCESSING",
    "REVISION_REQUESTED",
    "DISPUTED",
    "FULFILLED",
    "FAILED",
    "REMEDIATED",
    "EXPIRED",
    "PENDING_ARBITRATION",
    "CANCELLED",
    "REJECTED",
    "RECORDED",
]

RecordTransitionAction = Literal["register", "propose", "activate", "cancel"]

OperatingMode = Literal["cleartext", "encrypted"]
VerificationMode = Literal["auto", "principal", "gated"]
RiskClassification = Literal["high", "limited", "minimal", "unclassified"]
ConstraintInheritanceMode = Literal["none", "advisory", "enforced"]

AcceptanceStatus = Literal["PROPOSED", "ACCEPTED", "REJECTED", "COUNTER_PROPOSED"]


class VaultReceipt(BaseModel):
    """Inline tamper-evident receipt for the head of a Record's audit chain."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    chain_position: int = Field(alias="chainPosition")
    """Per-Record monotonic chain position (1-indexed)."""
    leaf_hash: str = Field(alias="leafHash")
    """Hex sha256 over the canonical (RFC 8785) entry payload."""
    previous_hash: str | None = Field(None, alias="previousHash")
    """leafHash of the prior entry (null only on chainPosition === 1)."""
    signature: str | None = None
    """Ed25519 signature over (chainPosition, leafHash, previousHash)."""
    signing_key_id: str | None = Field(None, alias="signingKeyId")
    """Vault signing key id."""
    signed_checkpoint_ref: str | None = Field(None, alias="signedCheckpointRef")
    """Most recent signed checkpoint covering this position, or null."""


class RecordReadReceipt(BaseModel):
    """SCITT-style inclusion-proof receipt for tenant-admin cross-party reads."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    leaf_index: int = Field(alias="leafIndex")
    leaf_hash: str = Field(alias="leafHash")
    signed_checkpoint_ref: str | None = Field(None, alias="signedCheckpointRef")


class RecordRow(BaseModel):
    """A Record — a registered commitment between a principal and a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique Record ID (UUID)."""
    enterprise_id: str = Field(alias="enterpriseId")
    """Enterprise tenant that owns this Record."""
    agent_id: str | None = Field(None, alias="agentId")
    """Agent assigned as performer, or null if unassigned."""
    principal_agent_id: str | None = Field(None, alias="principalAgentId")
    """Agent ID of the principal."""
    created_by_key_id: str | None = Field(None, alias="createdByKeyId")
    """API key that created this Record."""
    type: str
    """Record Type, e.g. 'ACH-PROC-v1'."""
    contract_version: str | None = Field(None, alias="contractVersion")
    """Type schema version."""
    platform: str
    """Platform where this Record operates."""
    platform_ref: str | None = Field(None, alias="platformRef")
    """External reference ID on the platform."""
    status: RecordStatus | str
    """Current lifecycle status."""
    criteria: dict[str, Any]
    """Acceptance criteria — what the performer must deliver."""
    tolerance: dict[str, Any] | None = None
    """Tolerance bands for numeric criteria."""
    deadline: str | None = None
    """ISO 8601 deadline for completion."""
    commission_pct: float | None = Field(None, alias="commissionPct")
    """Commission percentage for the performing agent."""
    commission_amount: float | None = Field(None, alias="commissionAmount")
    """Computed commission amount."""
    operating_mode: OperatingMode | str | None = Field(None, alias="operatingMode")
    """Operating mode: cleartext (default) or encrypted."""
    verification_mode: VerificationMode | str | None = Field(None, alias="verificationMode")
    """Verification mode: auto, principal, or gated."""
    risk_classification: RiskClassification | str | None = Field(None, alias="riskClassification")
    """EU AI Act risk classification."""
    eu_ai_act_domain: str | None = Field(None, alias="euAiActDomain")
    """EU AI Act domain."""
    human_oversight: dict[str, Any] | None = Field(None, alias="humanOversight")
    """Human oversight configuration for EU AI Act compliance."""
    acceptance_status: AcceptanceStatus | str | None = Field(None, alias="acceptanceStatus")
    """Performer's response to a proposed Record."""
    acceptance_responded_at: str | None = Field(None, alias="acceptanceRespondedAt")
    """ISO 8601 timestamp when performer responded to proposal."""
    project_ref: str | None = Field(None, alias="projectRef")
    """Project grouping reference for related Records."""
    parent_record_id: str | None = Field(None, alias="parentRecordId")
    """Parent Record ID in a delegation chain."""
    root_record_id: str | None = Field(None, alias="rootRecordId")
    """Root Record ID at the top of the delegation chain."""
    chain_depth: int | None = Field(None, alias="chainDepth")
    """Depth in the delegation chain (0 = root)."""
    child_record_ids: list[str] | None = Field(None, alias="childRecordIds")
    """IDs of child Records in the delegation chain."""
    parent_principal_enterprise_matches_performer: bool | None = Field(
        None, alias="parentPrincipalEnterpriseMatchesPerformer"
    )
    """Delegation-shell indicator. Informational only."""
    last_transition_reason: str | None = Field(None, alias="lastTransitionReason")
    """Reason provided for the last state transition."""
    last_transition_by: str | None = Field(None, alias="lastTransitionBy")
    """Actor who triggered the last state transition."""
    last_verdict_reason: str | None = Field(None, alias="lastVerdictReason")
    """Reason from the most recent verdict or revision request."""
    last_verdict_at: str | None = Field(None, alias="lastVerdictAt")
    """ISO 8601 timestamp of the most recent verdict."""
    submission_count: int = Field(alias="submissionCount")
    """Number of receipt submissions so far."""
    max_submissions: int | None = Field(None, alias="maxSubmissions")
    """Maximum allowed submissions, or None for unlimited."""
    revision_count: int | None = Field(None, alias="revisionCount")
    """Number of revisions consumed."""
    max_revisions: int | None = Field(None, alias="maxRevisions")
    """Maximum revisions allowed."""
    dispute_count: int | None = Field(None, alias="disputeCount")
    """Number of disputes opened against this Record."""
    max_disputes: int | None = Field(None, alias="maxDisputes")
    """Maximum disputes allowed."""
    past_deadline: bool | None = Field(None, alias="pastDeadline")
    """True iff a deadline is set AND has passed."""
    version: int
    """Optimistic concurrency version."""
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""
    updated_at: str = Field(alias="updatedAt")
    """ISO 8601 last update timestamp."""
    activated_at: str | None = Field(None, alias="activatedAt")
    """ISO 8601 timestamp when activated."""
    fulfilled_at: str | None = Field(None, alias="fulfilledAt")
    """ISO 8601 timestamp when fulfilled."""
    next_actions: list[str] | None = Field(None, alias="nextActions")
    """Valid next actions from current state."""
    valid_transitions: list[str] | None = Field(None, alias="validTransitions")
    """Valid target statuses from current state."""
    receipt_hint: dict[str, Any] | None = Field(None, alias="receiptHint")
    """Hint for receipt evidence fields."""
    advisory_warnings: list[dict[str, Any]] | None = Field(None, alias="advisoryWarnings")
    """Advisory enforcement warnings."""
    schema_url: str | None = Field(None, alias="schemaUrl")
    """URL to the Type schema definition."""
    verification_checks: dict[str, Any] | None = Field(None, alias="verificationChecks")
    """Verification check results."""
    verification_outcome: str | None = Field(None, alias="verificationOutcome")
    """Overall verification outcome: PASS, FAIL, or None."""
    self_commitment: bool | None = Field(None, alias="selfCommitment")
    """True when principal and performer are the same agent at creation."""
    constraint_inheritance: ConstraintInheritanceMode | str | None = Field(
        None, alias="constraintInheritance"
    )
    """Constraint inheritance mode from parent."""
    no_op: bool | None = Field(None, alias="noOp")
    """True when a transition was a no-op."""
    external_task_id: str | None = Field(None, alias="externalTaskId")
    """External task ID from the caller's system."""
    depends_on: list[str] | None = Field(None, alias="dependsOn")
    """Record IDs this Record depends on."""
    enforcement_overrides: dict[str, Any] | None = Field(None, alias="enforcementOverrides")
    """Per-field enforcement overrides."""
    metadata: dict[str, Any] | None = None
    """Arbitrary metadata attached to the Record."""
    category: str | None = None
    """Free-form taxonomy of what kind of artifact this Record represents."""
    outcome: str | None = None
    """Optional free-form outcome (success/failure/denied/partial)."""
    correlation_id: str | None = Field(None, alias="correlationId")
    """Optional grouping ID for related Records."""
    requested_by: str | None = Field(None, alias="requestedBy")
    """Free-form identifier of the human or upstream system that asked for the work."""
    references: list[dict[str, Any]] | None = None
    """External references attached to this Record."""
    next_steps: list[NextStep] | None = Field(None, alias="nextSteps")
    """Suggested next API calls after Record mutations."""
    vault_receipt: VaultReceipt | None = Field(None, alias="vaultReceipt")
    """Inline tamper-evident receipt for the head of this Record's audit chain."""
    record_read: RecordReadReceipt | None = Field(None, alias="recordRead")
    """SCITT-style inclusion-proof receipt for cross-party reads."""


class BulkCreateResultItem(BaseModel):
    """One per-record outcome from POST /v1/records/bulk."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    index: int
    status: int
    data: RecordRow | None = None
    error: str | None = None


class BulkCreateSummary(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    total: int
    succeeded: int
    failed: int


class BulkCreateResult(BaseModel):
    """Response envelope from POST /v1/records/bulk."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    results: list[BulkCreateResultItem] = Field(default_factory=list)
    summary: BulkCreateSummary


class Receipt(BaseModel):
    """A receipt — structured evidence submitted by a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique receipt ID."""
    record_id: str = Field(alias="recordId")
    """Record this receipt is for."""
    agent_id: str = Field(alias="agentId")
    """Agent that submitted the receipt."""
    evidence: dict[str, Any]
    """Evidence of completion."""
    evidence_hash: str | None = Field(None, alias="evidenceHash")
    """SHA-256 hash of the evidence payload."""
    structural_validation: str | None = Field(None, alias="structuralValidation")
    """Structural validation result: ACCEPTED, INVALID, or WARNING."""
    warnings: list[Any] | None = None
    """Validation warnings."""
    record_status: RecordStatus | str | None = Field(None, alias="recordStatus")
    """Record status after receipt submission."""
    validation_errors: list[Any] | None = Field(None, alias="validationErrors")
    """Schema validation errors, if any."""
    idempotency_key: str | None = Field(None, alias="idempotencyKey")
    """Client-supplied idempotency key."""
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""
    next_steps: list[NextStep] | None = Field(None, alias="nextSteps")
    """Suggested next API calls after receipt submission."""


class VerificationResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    record_id: str = Field(alias="recordId")
    receipts: list[dict[str, Any]] = Field(default_factory=list)
    overall_status: str = Field(alias="overallStatus")


DisputeStatus = Literal[
    "OPENED", "TIER_1_REVIEW", "EVIDENCE_WINDOW", "TIER_2_REVIEW",
    "ESCALATED", "TIER_3_ARBITRATION", "RESOLVED", "WITHDRAWN",
]


class Dispute(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    record_id: str = Field(alias="recordId")
    initiated_by_role: str = Field(alias="initiatedByRole")
    initiated_by_id: str = Field(alias="initiatedById")
    grounds: str
    context: str | None = None
    status: DisputeStatus | str
    current_tier: int = Field(alias="currentTier")
    outcome: str | None = None
    resolution_rationale: str | None = Field(None, alias="resolutionRationale")
    fee_charged_to: str | None = Field(None, alias="feeChargedTo")
    fee_amount: float | None = Field(None, alias="feeAmount")
    fee_currency: str | None = Field(None, alias="feeCurrency")
    evidence_window_closes_at: str | None = Field(None, alias="evidenceWindowClosesAt")
    created_at: str = Field(alias="createdAt")
    resolved_at: str | None = Field(None, alias="resolvedAt")
    next_steps: list[NextStep] | None = Field(None, alias="nextSteps")
    """Suggested next API calls after dispute operations."""


class DisputeResponse(BaseModel):
    """Response envelope from GET /v1/records/{id}/dispute — includes both dispute and evidence."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    dispute: Dispute
    evidence: list[dict[str, Any]] = Field(default_factory=list)


WebhookEventType = Literal[
    "record.created",
    "record.receipt_submitted",
    "record.verification_complete",
    "record.fulfilled",
    "record.settled",
    "record.failed",
    "record.expired",
    "record.cancelled",
    "record.proposed",
    "record.proposal_accepted",
    "record.proposal_rejected",
    "record.delegated",
    "signal.emitted",
    "dispute.opened",
    "dispute.resolved",
    "record.revision_requested",
    "federation.record.offered",
    "federation.record.accepted",
    "federation.record.state_changed",
    "federation.settlement.signal",
    "federation.gateway.registered",
    "federation.gateway.revoked",
    "record.reference_added",
    "agent.reference_added",
]


class Webhook(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    url: str
    event_types: list[str] | None = Field(None, alias="eventTypes")
    is_active: bool = Field(alias="isActive")
    is_paused: bool | None = Field(None, alias="isPaused")
    format: str = "standard"
    secret: str | None = None
    created_at: str = Field(alias="createdAt")
    next_steps: list[NextStep] | None = Field(None, alias="nextSteps")
    """Suggested next API calls after webhook creation."""


class OutcomeResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    record_id: str = Field(alias="recordId")
    receipt_id: str = Field(alias="receiptId")
    outcome: str
    signal: str
    reporter_type: str = Field(alias="reporterType")
    reported_at: str = Field(alias="reportedAt")
    next_steps: list[NextStep] | None = Field(None, alias="nextSteps")
    """Suggested next API calls after reporting outcome."""


class VerdictStatistics(BaseModel):
    """Per (principal, performer) verdict statistics surfaced by /v1/records/me/verdict-statistics."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: list[dict[str, Any]]


class ComplianceRecord(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    record_id: str = Field(alias="recordId")
    enterprise_id: str = Field(alias="enterpriseId")
    record_type: str = Field(alias="recordType")
    attestation: dict[str, Any]
    attested_by: str = Field(alias="attestedBy")
    attested_at: str = Field(alias="attestedAt")
    created_at: str = Field(alias="createdAt")


class AuditActor(BaseModel):
    """Actor envelope embedded in canonical audit payloads."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    actor_key_id: str | None = None
    actor_role: str | None = None
    actor_owner_id: str | None = None


class AuditExportEntry(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    position: int
    timestamp: str
    entry_type: str = Field(alias="entryType")
    description: str
    payload: dict[str, Any]
    actor: AuditActor | None = None
    integrity: dict[str, Any]


class AuditExportMetadata(BaseModel):
    """Metadata envelope on a record audit export — mirrors TS RecordAuditExport.exportMetadata."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    record_id: str = Field(alias="recordId")
    enterprise_id: str | None = Field(None, alias="enterpriseId")
    type: str
    """Record Type identifier (e.g., 'ACH-PROC-v1')."""
    operating_mode: Literal["cleartext", "encrypted"] | None = Field(None, alias="operatingMode")
    export_date: str = Field(alias="exportDate")
    total_entries: int = Field(alias="totalEntries")
    expected_entries: int | None = Field(None, alias="expectedEntries")
    chain_integrity: bool = Field(alias="chainIntegrity")
    chain_integrity_reason: (
        Literal[
            "chain_broken_at",
            "audit_vault_row_missing_for_checkpoint",
            "checkpoint_hash_mismatch",
        ]
        | None
    ) = Field(None, alias="chainIntegrityReason")
    export_format_version: str = Field(alias="exportFormatVersion")
    canonicalization: str
    signing_public_key: str | None = Field(None, alias="signingPublicKey")
    signing_public_keys: dict[str, str] | None = Field(None, alias="signingPublicKeys")


class RecordAuditExport(BaseModel):
    """Audit export envelope returned by GET /v1/records/{id}/audit-export."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    export_metadata: AuditExportMetadata = Field(alias="exportMetadata")
    entries: list[AuditExportEntry] = Field(default_factory=list)


class AuditStreamResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    events: list[dict[str, Any]] = Field(default_factory=list)
    cursor: str | None = None
    has_more: bool = Field(False, alias="hasMore")


class TenantReadsCheckpoint(BaseModel):
    """Tenant-admin reads checkpoint (SCITT-style signed tree head)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    enterprise_id: str = Field(alias="enterpriseId")
    tree_size: int = Field(alias="treeSize")
    root_hash: str = Field(alias="rootHash")
    sth_bytes: str | None = Field(None, alias="sthBytes")
    signature: str | None = None
    signing_key_id: str | None = Field(None, alias="signingKeyId")
    created_at: str = Field(alias="createdAt")
    cosignatures: list[dict[str, Any]] | None = None


class TenantReadsInclusionProof(BaseModel):
    """Inclusion-proof response for a leaf within a tenant-reads checkpoint."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    checkpoint_id: str = Field(alias="checkpointId")
    leaf_index: int = Field(alias="leafIndex")
    leaf_hash: str = Field(alias="leafHash")
    proof: list[str]
    root_hash: str = Field(alias="rootHash")


class ReputationScore(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    agent_id: str = Field(alias="agentId")
    type: str
    reliability_score: float = Field(alias="reliabilityScore")
    accuracy_score: float = Field(alias="accuracyScore")
    efficiency_score: float = Field(alias="efficiencyScore")
    composite_score: float = Field(alias="compositeScore")
    confidence_level: str = Field(alias="confidenceLevel")
    formula_version: str = Field(alias="formulaVersion")
    total_records: int = Field(0, alias="totalRecords")
    total_passed: int = Field(0, alias="totalPassed")
    total_verified: int = Field(0, alias="totalVerified")
    last_updated_at: str = Field(alias="lastUpdatedAt")


class Event(BaseModel):
    """A platform event (from /v1/events)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    event_type: str = Field(alias="eventType")
    record_id: str | None = Field(None, alias="recordId")
    agent_id: str | None = Field(None, alias="agentId")
    payload: dict[str, Any] | None = None
    created_at: str = Field(alias="createdAt")


ApiKeyRole = Literal["admin", "agent", "platform"]


class AccountProfile(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    api_key_id: str = Field(alias="apiKeyId")
    role: ApiKeyRole | str
    owner_id: str = Field(alias="ownerId")
    owner_type: str = Field(alias="ownerType")
    scopes: list[str] | None = None
    agent_id: str | None = Field(None, alias="agentId")
    enterprise_id: str | None = Field(None, alias="enterpriseId")
    name: str | None = None
    created_at: str | None = Field(None, alias="createdAt")


T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    """Unified page type for all list endpoints."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: list[T]  # type: ignore[type-var]
    has_more: bool = Field(alias="hasMore")
    next_cursor: str | None = Field(None, alias="nextCursor")
    total: int | None = None


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    status: str
    version: str | None = None
    uptime: float | None = None
    database: str | None = None
    timestamp: str


class StatusComponent(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    status: str
    latency_ms: float | None = Field(None, alias="latencyMs")


class StatusResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    status: str
    components: list[StatusComponent] = []
    active_incidents: list[dict[str, Any]] = Field(default=[], alias="activeIncidents")
    uptime: float
    timestamp: str


class ConformanceResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    protocol_version: str = Field(alias="protocolVersion")
    features: list[str] = []
    types: list[str] = []
    max_batch_size: int | None = Field(None, alias="maxBatchSize")
    rate_limits: dict[str, Any] | None = Field(None, alias="rateLimits")


class AgentCard(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    description: str | None = None
    url: str
    capabilities: dict[str, Any] | None = None
    skills: list[dict[str, Any]] | None = None


class AgentProfile(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    name: str
    slug: str
    agent_class: str | None = Field(None, alias="agentClass")
    owner_ref: str | None = Field(None, alias="ownerRef")
    org_unit: str | None = Field(None, alias="orgUnit")
    description: str | None = None
    enterprise_id: str | None = Field(None, alias="enterpriseId")
    agent_card_url: str | None = Field(None, alias="agentCardUrl")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")


class AgentDirectoryEntry(BaseModel):
    """A row in the tenant agent directory returned by ``GET /v1/agents``.

    Use this for peer discovery; for full agent identity use ``agents.get(id)``.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    enterprise_id: str = Field(alias="enterpriseId")
    display_name: str | None = Field(None, alias="displayName")
    slug: str
    agent_card_url: str | None = Field(None, alias="agentCardUrl")
    agent_class: str = Field(alias="agentClass")
    org_unit: str | None = Field(None, alias="orgUnit")
    description: str | None = None
    is_active: bool = Field(alias="isActive")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")


class VerificationStatus(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    record_id: str = Field(alias="recordId")
    status: str
    outcome: str | None = None
    signal: str | None = None


class WebhookTestResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    success: bool
    status_code: int | None = Field(None, alias="statusCode")
    response_time_ms: int | None = Field(None, alias="responseTimeMs")


class AgentCapabilities(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    agent_id: str = Field(alias="agentId")
    capabilities: list[str] = []


class ComplianceExport(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str | None = None
    export_id: str | None = Field(None, alias="exportId")
    status: str
    format: str | None = None
    created_at: str | None = Field(None, alias="createdAt")
    download_url: str | None = Field(None, alias="downloadUrl")


class AiImpactAssessment(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    record_id: str = Field(alias="recordId")
    risk_level: str = Field(alias="riskLevel")
    domain: str
    human_oversight: bool | None = Field(None, alias="humanOversight")
    created_at: str = Field(alias="createdAt")


class EuAiActReport(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    records_assessed: int = Field(0, alias="recordsAssessed")
    high_risk_count: int = Field(0, alias="highRiskCount")
    generated_at: str = Field(alias="generatedAt")


class VerificationKey(BaseModel):
    """A vault signing public key for independent audit chain verification."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    key_id: str = Field(alias="keyId")
    algorithm: str
    public_key: str = Field(alias="publicKey")
    status: str
    activated_at: str = Field(alias="activatedAt")
    retired_at: str | None = Field(None, alias="retiredAt")


class VerificationKeysResponse(BaseModel):
    """Response from GET /v1/verification-keys."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: list[VerificationKey]
    canonicalization: str
    hash_algorithm: str = Field(alias="hashAlgorithm")
    signature_algorithm: str = Field(alias="signatureAlgorithm")
