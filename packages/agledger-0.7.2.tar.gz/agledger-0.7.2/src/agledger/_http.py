"""
AGLedger SDK — HTTP client with retry, idempotency, and error mapping.
"""

from __future__ import annotations

import asyncio
import os
import random
import time
import uuid
from typing import Any, AsyncIterator, Iterator

import httpx

from agledger._errors import (
    APIConnectionError,
    APIError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableError,
)

DEFAULT_BASE_URL = "https://agledger.example.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
MAX_BACKOFF = 8.0
SDK_VERSION = "0.7.2"

_RETRYABLE_STATUSES = {408, 409, 429, 500, 502, 503, 504}
_ERROR_MAP: dict[int, type[APIError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: UnprocessableError,
    429: RateLimitError,
}


def _resolve_api_key(api_key: str | None) -> str:
    """Resolve API key from argument or AGLEDGER_API_KEY env var."""
    key = api_key or os.environ.get("AGLEDGER_API_KEY")
    if not key:
        raise AuthenticationError(message="No API key provided. Pass api_key or set AGLEDGER_API_KEY.")
    return key


def _parse_error_body(response: httpx.Response) -> dict[str, Any]:
    try:
        return response.json()
    except Exception:
        return {"message": response.text or f"HTTP {response.status_code}"}


def _build_error(response: httpx.Response) -> APIError:
    body = _parse_error_body(response)
    status = response.status_code
    cls = _ERROR_MAP.get(status, APIError)

    kwargs: dict[str, Any] = {
        "message": body.get("message") or body.get("detail") or body.get("title") or f"API error {status}",
        "code": body.get("code") or body.get("error", "unknown"),
        "request_id": body.get("requestId") or response.headers.get("x-request-id"),
        "details": body.get("details"),
        "retryable": body.get("retryable"),
        "suggestion": body.get("suggestion"),
        "doc_url": body.get("docUrl"),
        "recovery_hint": body.get("recoveryHint"),
        "refresh_url": body.get("refreshUrl"),
    }

    if cls is PermissionDeniedError:
        details = body.get("details") or {}
        # RFC 9457 surfaces missingScopes as a top-level extension field;
        # older bodies nested it under details.
        missing = body.get("missingScopes")
        if not isinstance(missing, list):
            missing = details.get("missingScopes", [])
        kwargs["missing_scopes"] = missing
        kwargs["key_scopes"] = details.get("keyScopes")
    elif cls is RateLimitError:
        retry_after = response.headers.get("retry-after")
        kwargs["retry_after"] = float(retry_after) if retry_after else None

    if cls is APIError:
        return cls(status, **kwargs)
    return cls(**kwargs)


def _backoff(attempt: int, retry_after: float | None = None) -> float:
    if retry_after and retry_after > 0:
        return min(retry_after, MAX_BACKOFF)
    base = min(0.5 * (2**attempt), MAX_BACKOFF)
    jitter = random.uniform(0, base * 0.25)
    return base + jitter


def _base_headers(
    api_key: str,
    method: str,
    idempotency_key: str | None = None,
    auth_override: str | None = None,
) -> dict[str, str]:
    headers: dict[str, str] = {
        "Accept": "application/json",
        "User-Agent": f"agledger-python/{SDK_VERSION}",
    }
    # Auth override: "none" omits header; any other string becomes Bearer token
    if auth_override == "none":
        pass  # No Authorization header (federation register / self-revoke)
    elif auth_override:
        headers["Authorization"] = f"Bearer {auth_override}"
    else:
        headers["Authorization"] = f"Bearer {api_key}"
    if method in ("POST", "PUT", "PATCH", "DELETE"):
        headers["Content-Type"] = "application/json"
        headers["Idempotency-Key"] = idempotency_key or str(uuid.uuid4())
    return headers


class HttpClient:
    """Synchronous HTTP client for AGLedger API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = DEFAULT_TIMEOUT,
        idempotency_key_prefix: str = "",
        http_client: httpx.Client | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._timeout = timeout
        self._idempotency_key_prefix = idempotency_key_prefix
        self._client = http_client or httpx.Client(timeout=timeout)
        self._owns_client = http_client is None
        self.last_request_id: str | None = None
        """Request ID from the most recent API response (``X-Request-Id`` header)."""

    def close(self) -> None:
        """Close the underlying HTTP client if we own it."""
        if self._owns_client:
            self._client.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        auth_override: str | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        key = f"{self._idempotency_key_prefix}{idempotency_key}" if idempotency_key else None
        headers = _base_headers(self._api_key, method, key, auth_override=auth_override)
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method,
                    url,
                    headers=headers,
                    json=json,
                    params={k: v for k, v in (params or {}).items() if v is not None},
                    timeout=timeout or self._timeout,
                )

                self.last_request_id = response.headers.get("x-request-id")

                if response.status_code >= 400:
                    error = _build_error(response)
                    if response.status_code in _RETRYABLE_STATUSES and attempt < self._max_retries:
                        retry_after = getattr(error, "retry_after", None)
                        time.sleep(_backoff(attempt, retry_after))
                        last_error = error
                        continue
                    raise error

                if response.status_code == 204:
                    return None
                return response.json()

            except httpx.ConnectError as e:
                last_error = APIConnectionError(str(e))
                if attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_error from e
            except httpx.TimeoutException as e:
                last_error = APITimeoutError(str(e))
                if attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_error from e

        raise last_error or APIError(500, message="Max retries exceeded")

    def get(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> Any:
        return self._request("GET", path, params=params, **kwargs)

    def post(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return self._request("POST", path, json=json, **kwargs)

    def patch(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return self._request("PATCH", path, json=json, **kwargs)

    def put(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return self._request("PUT", path, json=json, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Any:
        return self._request("DELETE", path, **kwargs)

    def get_ndjson(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> dict[str, Any]:
        """Fetch an NDJSON endpoint. Returns {"data": [...], "cursor": "..."}."""
        url = f"{self._base_url}{path}"
        headers = _base_headers(self._api_key, "GET")
        headers["Accept"] = "application/x-ndjson"
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    "GET",
                    url,
                    headers=headers,
                    params={k: v for k, v in (params or {}).items() if v is not None},
                    timeout=kwargs.get("timeout") or self._timeout,
                )

                if response.status_code >= 400:
                    error = _build_error(response)
                    if response.status_code in _RETRYABLE_STATUSES and attempt < self._max_retries:
                        retry_after = getattr(error, "retry_after", None)
                        time.sleep(_backoff(attempt, retry_after))
                        last_error = error
                        continue
                    raise error

                import json as _json
                text = response.text
                lines = [line for line in text.split("\n") if line.strip()]
                data = [_json.loads(line) for line in lines]
                cursor = response.headers.get("x-agledger-stream-cursor")
                return {"data": data, "cursor": cursor}

            except httpx.ConnectError as e:
                last_error = APIConnectionError(str(e))
                if attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_error from e
            except httpx.TimeoutException as e:
                last_error = APITimeoutError(str(e))
                if attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise last_error from e

        raise last_error or APIError(500, message="Max retries exceeded")

    def get_page(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> dict[str, Any]:
        raw = self.get(path, params=params, **kwargs)
        if isinstance(raw, list):
            return {"data": raw, "hasMore": False}
        if isinstance(raw, dict) and "data" in raw:
            return raw
        if isinstance(raw, dict):
            return {"data": [raw], "hasMore": False}
        return {"data": [], "hasMore": False}

    def paginate(self, path: str, *, params: dict[str, Any] | None = None, max_pages: int = 100) -> Iterator[dict[str, Any]]:
        p = dict(params or {})
        for _ in range(max_pages):
            page = self.get_page(path, params=p)
            yield from page.get("data", [])
            if not page.get("hasMore"):
                break
            cursor = page.get("nextCursor") or page.get("next_cursor")
            if not cursor:
                break
            p["cursor"] = cursor


class AsyncHttpClient:
    """Async HTTP client for AGLedger API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = DEFAULT_TIMEOUT,
        idempotency_key_prefix: str = "",
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._timeout = timeout
        self._idempotency_key_prefix = idempotency_key_prefix
        self._client = http_client or httpx.AsyncClient(timeout=timeout)
        self._owns_client = http_client is None
        self.last_request_id: str | None = None
        """Request ID from the most recent API response (``X-Request-Id`` header)."""

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        timeout: float | None = None,
        auth_override: str | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        key = f"{self._idempotency_key_prefix}{idempotency_key}" if idempotency_key else None
        headers = _base_headers(self._api_key, method, key, auth_override=auth_override)
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method,
                    url,
                    headers=headers,
                    json=json,
                    params={k: v for k, v in (params or {}).items() if v is not None},
                    timeout=timeout or self._timeout,
                )

                self.last_request_id = response.headers.get("x-request-id")

                if response.status_code >= 400:
                    error = _build_error(response)
                    if response.status_code in _RETRYABLE_STATUSES and attempt < self._max_retries:
                        retry_after = getattr(error, "retry_after", None)
                        await asyncio.sleep(_backoff(attempt, retry_after))
                        last_error = error
                        continue
                    raise error

                if response.status_code == 204:
                    return None
                return response.json()

            except httpx.ConnectError as e:
                last_error = APIConnectionError(str(e))
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff(attempt))
                    continue
                raise last_error from e
            except httpx.TimeoutException as e:
                last_error = APITimeoutError(str(e))
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff(attempt))
                    continue
                raise last_error from e

        raise last_error or APIError(500, message="Max retries exceeded")

    async def get(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> Any:
        return await self._request("GET", path, params=params, **kwargs)

    async def post(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return await self._request("POST", path, json=json, **kwargs)

    async def patch(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return await self._request("PATCH", path, json=json, **kwargs)

    async def put(self, path: str, *, json: Any | None = None, **kwargs: Any) -> Any:
        return await self._request("PUT", path, json=json, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> Any:
        return await self._request("DELETE", path, **kwargs)

    async def get_ndjson(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> dict[str, Any]:
        """Fetch an NDJSON endpoint. Returns {"data": [...], "cursor": "..."}."""
        url = f"{self._base_url}{path}"
        headers = _base_headers(self._api_key, "GET")
        headers["Accept"] = "application/x-ndjson"
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    "GET",
                    url,
                    headers=headers,
                    params={k: v for k, v in (params or {}).items() if v is not None},
                    timeout=kwargs.get("timeout") or self._timeout,
                )

                if response.status_code >= 400:
                    error = _build_error(response)
                    if response.status_code in _RETRYABLE_STATUSES and attempt < self._max_retries:
                        retry_after = getattr(error, "retry_after", None)
                        await asyncio.sleep(_backoff(attempt, retry_after))
                        last_error = error
                        continue
                    raise error

                import json as _json
                text = response.text
                lines = [line for line in text.split("\n") if line.strip()]
                data = [_json.loads(line) for line in lines]
                cursor = response.headers.get("x-agledger-stream-cursor")
                return {"data": data, "cursor": cursor}

            except httpx.ConnectError as e:
                last_error = APIConnectionError(str(e))
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff(attempt))
                    continue
                raise last_error from e
            except httpx.TimeoutException as e:
                last_error = APITimeoutError(str(e))
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff(attempt))
                    continue
                raise last_error from e

        raise last_error or APIError(500, message="Max retries exceeded")

    async def get_page(self, path: str, *, params: dict[str, Any] | None = None, **kwargs: Any) -> dict[str, Any]:
        raw = await self.get(path, params=params, **kwargs)
        if isinstance(raw, list):
            return {"data": raw, "hasMore": False}
        if isinstance(raw, dict) and "data" in raw:
            return raw
        if isinstance(raw, dict):
            return {"data": [raw], "hasMore": False}
        return {"data": [], "hasMore": False}

    async def paginate(self, path: str, *, params: dict[str, Any] | None = None, max_pages: int = 100) -> AsyncIterator[dict[str, Any]]:
        p = dict(params or {})
        for _ in range(max_pages):
            page = await self.get_page(path, params=p)
            for item in page.get("data", []):
                yield item
            if not page.get("hasMore"):
                break
            cursor = page.get("nextCursor") or page.get("next_cursor")
            if not cursor:
                break
            p["cursor"] = cursor
