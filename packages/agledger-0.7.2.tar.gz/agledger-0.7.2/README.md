# AGLedger Python SDK

The official Python SDK for [AGLedger](https://agledger.ai) — accountability infrastructure for AI agents. Self-hosted. The Layer 3 accountability layer of the agent stack.

**Learn more**

- [agledger.ai](https://agledger.ai) — what AGLedger is and why Layer 3 accountability matters
- [How it works](https://agledger.ai/how-it-works) — the four-endpoint lifecycle: Record, Receipt, Verdict, fulfill
- [Glossary](https://agledger.ai/glossary) — canonical definitions of Record, Receipt, Verdict, Settlement Signal
- [Documentation](https://agledger.ai/docs) — installation, integration guides, API reference
- [Protocol (AOAP)](https://agledger.ai/protocol) — the coordination language behind AGLedger

## Install

```bash
pip install agledger
```

## Quick Start

```python
import os
from agledger import AgledgerClient

client = AgledgerClient(
    api_key=os.environ["AGLEDGER_API_KEY"],
    base_url=os.environ["AGLEDGER_EXTERNAL_URL"],  # your AGLedger instance URL
)

# Create a Record. An agent key defaults the principal to itself; an admin
# key names the principal explicitly via principal_agent_id.
record = client.records.create(
    type="ACH-PROC-v1",
    contract_version="1",
    platform="internal",
    performer_agent_id="agt-123",
    criteria={"item_spec": "widgets", "quantity": {"target": 100}},
)

# Activate it
client.records.transition(record.id, "activate")

# Submit a receipt
receipt = client.receipts.submit(
    record.id,
    evidence={"deliverable": "/out.pdf", "deliverable_type": "file_ref", "quantity_supplied": 95},
)

# Principal verdict
client.records.report_outcome(record.id, receipt_id=receipt.id, outcome="PASS")
```

## Configuration

```python
client = AgledgerClient(
    api_key="agl_agt_...",                              # or set AGLEDGER_API_KEY env var
    base_url="https://agledger.internal.example.com",   # your instance URL
    max_retries=2,                                      # default: 2
    timeout=30.0,                                       # default: 30s
)
```

## Async Support

```python
from agledger import AsyncAgledgerClient

async with AsyncAgledgerClient() as client:
    record = await client.records.get("rec-123")
```

## Resources

`records`, `receipts`, `verification`, `disputes`, `webhooks`, `reputation`,
`events`, `schemas`, `compliance`, `health`, `admin` (with `admin.records` +
`admin.vault` sub-resources), `a2a`, `agents`, `audit` (with
`audit.tenant_reads_checkpoints`), `auth`, `capabilities`, `discovery`,
`references`, `federation`, `federation_admin`, `verification_keys`.

## Offline Audit Export Verification

Verify a Record's hash-chained, Ed25519-signed audit export without calling the API:

```python
from agledger.verify import verify_export

export_data = client.records.get_audit_export("rec-123")
result = verify_export(export_data.model_dump(by_alias=True))

if not result.valid:
    print(f"Broken at position {result.broken_at.position}: {result.broken_at.reason}")
# VerifyExportResult(valid=True, verified_entries=12, total_entries=12, ...)
```

Requires the `cryptography` package for Ed25519 verification:

```bash
pip install 'agledger[verify]'
```

Re-implements the vault's integrity check (RFC 8785 JCS → SHA-256 → Ed25519 over
`{position}:{payloadHash}:{previousHash}`). Pass `public_keys={...}` to override
the export's embedded keys, or `require_key_id="key-id"` to reject exports signed
by an unexpected key.

## Licensing

AGLedger is **free for single-node deployments** (Docker Compose with bundled database). An Enterprise License is required for external database connections, federation, and multi-node deployments.

Full details: [agledger.ai/pricing](https://agledger.ai/pricing) | [License Agreement](https://agledger.ai/license)

## SDK License

Proprietary. Copyright (c) 2026 AGLedger LLC. All rights reserved.
