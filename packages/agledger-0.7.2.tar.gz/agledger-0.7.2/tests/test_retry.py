"""Tests for retry logic, backoff, and connection errors."""

import httpx
import pytest
import respx

from agledger import AgledgerClient
from agledger._errors import APIConnectionError, APITimeoutError, APIError


RECORD_JSON = {
    "id": "rec-123", "enterpriseId": "ent-1", "agentId": None, "principalAgentId": "agt-1",
    "type": "ACH-PROC-v1", "contractVersion": "1", "platform": "test",
    "status": "CREATED", "criteria": {}, "submissionCount": 0, "maxSubmissions": None,
    "version": 1, "createdAt": "2026-04-27T00:00:00Z", "updatedAt": "2026-04-27T00:00:00Z",
}


@respx.mock
def test_retries_on_429():
    route = respx.get("https://agledger.example.com/v1/records/rec-123")
    route.side_effect = [
        httpx.Response(429, json={"message": "Rate limited"}, headers={"retry-after": "0"}),
        httpx.Response(200, json=RECORD_JSON),
    ]
    client = AgledgerClient(api_key="test-key", max_retries=1)
    record = client.records.get("rec-123")
    assert record.id == "rec-123"
    assert len(route.calls) == 2


@respx.mock
def test_retries_on_500():
    route = respx.get("https://agledger.example.com/v1/records/rec-123")
    route.side_effect = [
        httpx.Response(500, json={"message": "Server error"}),
        httpx.Response(200, json=RECORD_JSON),
    ]
    client = AgledgerClient(api_key="test-key", max_retries=1)
    record = client.records.get("rec-123")
    assert record.id == "rec-123"
    assert len(route.calls) == 2


@respx.mock
def test_no_retry_on_400():
    route = respx.post("https://agledger.example.com/v1/records")
    route.mock(return_value=httpx.Response(400, json={"message": "Bad request"}))
    client = AgledgerClient(api_key="test-key", max_retries=2)
    with pytest.raises(APIError):
        client.records.create(type="ACH-PROC-v1", criteria={})
    assert len(route.calls) == 1  # No retries


@respx.mock
def test_no_retry_on_404():
    route = respx.get("https://agledger.example.com/v1/records/x")
    route.mock(return_value=httpx.Response(404, json={"message": "Not found"}))
    client = AgledgerClient(api_key="test-key", max_retries=2)
    with pytest.raises(APIError):
        client.records.get("x")
    assert len(route.calls) == 1


@respx.mock
def test_max_retries_exhausted():
    route = respx.get("https://agledger.example.com/v1/records/rec-123")
    route.side_effect = [
        httpx.Response(500, json={"message": "fail"}),
        httpx.Response(500, json={"message": "fail"}),
        httpx.Response(500, json={"message": "fail"}),
    ]
    client = AgledgerClient(api_key="test-key", max_retries=2)
    with pytest.raises(APIError):
        client.records.get("rec-123")
    assert len(route.calls) == 3  # 1 initial + 2 retries


@respx.mock
def test_zero_retries():
    route = respx.get("https://agledger.example.com/v1/records/rec-123")
    route.mock(return_value=httpx.Response(500, json={"message": "fail"}))
    client = AgledgerClient(api_key="test-key", max_retries=0)
    with pytest.raises(APIError):
        client.records.get("rec-123")
    assert len(route.calls) == 1


@respx.mock
def test_connection_error():
    respx.get("https://agledger.example.com/v1/records/rec-123").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )
    client = AgledgerClient(api_key="test-key", max_retries=0)
    with pytest.raises(APIConnectionError):
        client.records.get("rec-123")


@respx.mock
def test_timeout_error():
    respx.get("https://agledger.example.com/v1/records/rec-123").mock(
        side_effect=httpx.ReadTimeout("Read timed out")
    )
    client = AgledgerClient(api_key="test-key", max_retries=0)
    with pytest.raises(APITimeoutError):
        client.records.get("rec-123")


@respx.mock
def test_204_returns_none():
    respx.delete("https://agledger.example.com/v1/webhooks/wh-1").mock(
        return_value=httpx.Response(204)
    )
    client = AgledgerClient(api_key="test-key")
    client.webhooks.delete("wh-1")  # Should not raise
