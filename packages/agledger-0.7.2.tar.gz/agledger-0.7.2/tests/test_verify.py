"""Tests for the offline audit export verifier."""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
from typing import Any

import pytest

from agledger.verify import verify_export, canonicalize


def _make_keypair() -> tuple[str, Any]:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import (
        Encoding,
        PublicFormat,
    )

    private = Ed25519PrivateKey.generate()
    der = private.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
    return base64.b64encode(der).decode(), private


def _sign_entry(
    private_key: Any,
    key_id: str,
    position: int,
    payload: dict[str, Any],
    previous_hash: str | None,
) -> dict[str, Any]:
    payload_hash = hashlib.sha256(canonicalize(payload).encode()).hexdigest()
    sign_input = f"{position}:{payload_hash}:{previous_hash or 'null'}"
    signature = private_key.sign(sign_input.encode()).hex()
    return {
        "position": position,
        "timestamp": "2026-04-17T00:00:00Z",
        "entryType": "TEST",
        "description": "test",
        "payload": payload,
        "integrity": {
            "payloadHash": payload_hash,
            "hashAlg": "SHA-256",
            "previousHash": previous_hash,
            "signature": signature,
            "signatureAlg": "Ed25519",
            "signingKeyId": key_id,
            "valid": True,
        },
    }


def _make_export(public_key_b64: str, private_key: Any, key_id: str = "vault-key-1") -> dict[str, Any]:
    record_id = "REC-test-001"
    e1 = _sign_entry(private_key, key_id, 1, {"event": "created", "recordId": record_id}, None)
    e2 = _sign_entry(
        private_key, key_id, 2,
        {"event": "activated", "recordId": record_id},
        e1["integrity"]["payloadHash"],
    )
    e3 = _sign_entry(
        private_key, key_id, 3,
        {"event": "receipt", "recordId": record_id, "qty": 100},
        e2["integrity"]["payloadHash"],
    )
    return {
        "exportMetadata": {
            "recordId": record_id,
            "enterpriseId": "ent-001",
            "type": "ACH-PROC-v1",
            "exportDate": "2026-04-17T00:00:00Z",
            "totalEntries": 3,
            "chainIntegrity": True,
            "exportFormatVersion": "1.0",
            "canonicalization": "RFC8785",
            "signingPublicKey": public_key_b64,
            "signingPublicKeys": {key_id: public_key_b64},
        },
        "entries": [e1, e2, e3],
    }


class TestVerifyExport:
    def test_valid_export(self) -> None:
        pub, priv = _make_keypair()
        result = verify_export(_make_export(pub, priv))
        assert result.valid
        assert result.verified_entries == 3
        assert result.total_entries == 3
        assert result.broken_at is None
        assert all(e.valid for e in result.entries)

    def test_tampered_payload(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][1]["payload"]["tampered"] = True
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.position == 2
        assert result.broken_at.reason == "payload_hash_mismatch"

    def test_tampered_signature(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][1]["integrity"]["signature"] = "f" * 128
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.position == 2
        assert result.broken_at.reason == "signature_invalid"

    def test_broken_chain(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][2]["integrity"]["previousHash"] = "a" * 64
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.position == 3
        assert result.broken_at.reason == "chain_break"

    def test_position_gap(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][1]["position"] = 5
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "position_gap"

    def test_unknown_key(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][1]["integrity"]["signingKeyId"] = "unknown-999"
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "unknown_key"

    def test_wrong_override_key(self) -> None:
        pub, priv = _make_keypair()
        wrong_pub, _ = _make_keypair()
        exp = _make_export(pub, priv)
        result = verify_export(exp, public_keys={"vault-key-1": wrong_pub})
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "signature_invalid"

    def test_unsupported_canonicalization(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["exportMetadata"]["canonicalization"] = "custom"
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "unsupported_algorithm"

    def test_unsupported_hash_algorithm(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"][0]["integrity"]["hashAlg"] = "SHA-1"
        result = verify_export(exp)
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "unsupported_algorithm"

    def test_require_key_id(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv, key_id="retired-key")
        result = verify_export(exp, require_key_id="active-key")
        assert not result.valid
        assert result.broken_at is not None
        assert result.broken_at.reason == "unknown_key"

    def test_empty_export(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["entries"] = []
        result = verify_export(exp)
        assert not result.valid
        assert result.total_entries == 0
        assert result.verified_entries == 0

    def test_merges_option_keys_over_embedded(self) -> None:
        pub, priv = _make_keypair()
        exp = _make_export(pub, priv)
        exp["exportMetadata"]["signingPublicKeys"] = {}
        result = verify_export(exp, public_keys={"vault-key-1": pub})
        assert result.valid

    def test_accepts_pydantic_record_audit_export(self) -> None:
        """verify_export accepts the typed model returned by records.get_audit_export().

        Regression: customers building the canonical fetch+verify flow hit
        AttributeError when passing the SDK's own typed return type.
        """
        from agledger import RecordAuditExport

        pub, priv = _make_keypair()
        exp_dict = _make_export(pub, priv)
        exp_model = RecordAuditExport.model_validate(exp_dict)
        result = verify_export(exp_model)
        assert result.valid
        assert result.verified_entries == 3


class TestCanonicalize:
    def test_sorts_object_keys(self) -> None:
        assert canonicalize({"b": 1, "a": 2}) == '{"a":2,"b":1}'

    def test_nested_objects(self) -> None:
        assert canonicalize({"b": {"d": 1, "c": 2}, "a": 3}) == '{"a":3,"b":{"c":2,"d":1}}'

    def test_arrays_preserve_order(self) -> None:
        assert canonicalize([3, 1, 2]) == "[3,1,2]"

    def test_primitives(self) -> None:
        assert canonicalize(None) == "null"
        assert canonicalize(True) == "true"
        assert canonicalize(False) == "false"
        assert canonicalize(42) == "42"
        assert canonicalize("hello") == '"hello"'

    def test_string_escaping(self) -> None:
        assert canonicalize('a"b') == '"a\\"b"'
        assert canonicalize("a\nb") == '"a\\nb"'


class TestSharedVectors:
    """Verifies the Python impl matches TS output against shared test vectors.

    Catches RFC 8785 implementation drift between languages."""

    VECTORS_DIR = Path(__file__).resolve().parents[2] / "testdata" / "verifier"
    MANIFEST = VECTORS_DIR / "manifest.json"

    @pytest.fixture(scope="class")
    def manifest(self) -> dict[str, Any]:
        if not self.MANIFEST.exists():
            pytest.skip(f"vectors not present at {self.MANIFEST}")
        return json.loads(self.MANIFEST.read_text())

    def test_all_vectors_match_expectation(self, manifest: dict[str, Any]) -> None:
        for vector in manifest["vectors"]:
            export_data = json.loads((self.VECTORS_DIR / vector["file"]).read_text())
            result = verify_export(export_data)
            if vector["expected"] == "valid":
                assert result.valid, f"{vector['file']}: expected valid, got {result.broken_at}"
            else:
                assert not result.valid, f"{vector['file']}: expected invalid"
                if "brokenAt" in vector:
                    assert result.broken_at is not None
                    assert result.broken_at.position == vector["brokenAt"], (
                        f"{vector['file']}: expected brokenAt={vector['brokenAt']}, got {result.broken_at.position}"
                    )
                if "reason" in vector:
                    assert result.broken_at is not None
                    assert result.broken_at.reason == vector["reason"], (
                        f"{vector['file']}: expected reason={vector['reason']}, got {result.broken_at.reason}"
                    )
