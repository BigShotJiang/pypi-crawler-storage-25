"""
LuaGame - A pygame-powered engine that runs .lua game files.

Quick start:
    from LuaGame import run_game
    run_game("mygame.lua", width=800, height=600, title="My Game")
"""

from .main import run_game, LuaGameEngine

__version__ = "0.1.0"
__all__ = ["run_game", "LuaGameEngine"]