"""
LuaGame core - a pygame-powered engine that runs .lua game files.
Import from the top-level package:
    from LuaGame import run_game, LuaGameEngine
"""

import os

try:
    import pygame
except ImportError:
    raise ImportError(
        "\n[LuaGame] pygame is not installed!\n"
        "Fix it by running:\n"
        "    pip install pygame\n"
    )

try:
    from lupa import LuaRuntime
except ImportError:
    raise ImportError(
        "\n[LuaGame] lupa is not installed!\n"
        "Fix it by running:\n"
        "    pip install lupa\n"
    )


class LuaGameEngine:
    """
    The LuaGame engine. Loads a .lua file and runs it as a pygame game.

    Your .lua file can use these functions:
        function game_load()             -- called once at start
        function game_update(dt)         -- called every frame
        function game_draw()             -- called every frame after update
        function keypressed(key)         -- called when a key is pressed
        function keyreleased(key)        -- called when a key is released
        function mousepressed(x, y, btn) -- called on mouse click

        clear(r, g, b)
        draw_rect(x, y, w, h, r, g, b)
        draw_circle(x, y, radius, r, g, b)
        draw_line(x1, y1, x2, y2, r, g, b, width)
        draw_text(text, x, y, size, r, g, b)
        draw_image(path, x, y)
        is_key_down(key)
        get_mouse_pos()
        is_mouse_down(button)
        screen_width()
        screen_height()
        get_time()
    """

    def __init__(self, lua_file, width=800, height=600, title="LuaGame", fps=60):
        self.lua_file = lua_file
        self.width = width
        self.height = height
        self.title = title
        self.fps = fps
        self._images = {}
        self._fonts = {}

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption(self.title)
        clock = pygame.time.Clock()
        start_time = pygame.time.get_ticks()

        rt = LuaRuntime(unpack_returned_tuples=True)
        g = rt.globals()

        # ── Drawing functions ────────────────────────────────────────────

        def clear(r=0, g_=0, b=0):
            screen.fill((int(r), int(g_), int(b)))

        def draw_rect(x, y, w, h, r=255, g_=255, b=255):
            pygame.draw.rect(screen, (int(r), int(g_), int(b)), (int(x), int(y), int(w), int(h)))

        def draw_circle(x, y, radius, r=255, g_=255, b=255):
            pygame.draw.circle(screen, (int(r), int(g_), int(b)), (int(x), int(y)), int(radius))

        def draw_line(x1, y1, x2, y2, r=255, g_=255, b=255, width=1):
            pygame.draw.line(screen, (int(r), int(g_), int(b)), (int(x1), int(y1)), (int(x2), int(y2)), int(width))

        def draw_text(text, x, y, size=24, r=255, g_=255, b=255):
            size = int(size)
            if size not in self._fonts:
                self._fonts[size] = pygame.font.SysFont(None, size)
            font = self._fonts[size]
            surface = font.render(str(text), True, (int(r), int(g_), int(b)))
            screen.blit(surface, (int(x), int(y)))

        def draw_image(path, x, y):
            if path not in self._images:
                try:
                    self._images[path] = pygame.image.load(path).convert_alpha()
                except Exception as e:
                    print("[LuaGame] Could not load image '{}': {}".format(path, e))
                    return
            screen.blit(self._images[path], (int(x), int(y)))

        # ── Input functions ──────────────────────────────────────────────

        def is_key_down(key):
            keys = pygame.key.get_pressed()
            try:
                return keys[getattr(pygame, "K_{}".format(key))]
            except AttributeError:
                return False

        def get_mouse_pos():
            x, y = pygame.mouse.get_pos()
            return x, y

        def is_mouse_down(button=1):
            return pygame.mouse.get_pressed()[int(button) - 1]

        # ── Window / utility functions ───────────────────────────────────

        def screen_width():
            return self.width

        def screen_height():
            return self.height

        def get_time():
            return (pygame.time.get_ticks() - start_time) / 1000.0

        # ── Inject all functions into Lua ────────────────────────────────

        g["clear"] = clear
        g["draw_rect"] = draw_rect
        g["draw_circle"] = draw_circle
        g["draw_line"] = draw_line
        g["draw_text"] = draw_text
        g["draw_image"] = draw_image
        g["is_key_down"] = is_key_down
        g["get_mouse_pos"] = get_mouse_pos
        g["is_mouse_down"] = is_mouse_down
        g["screen_width"] = screen_width
        g["screen_height"] = screen_height
        g["get_time"] = get_time

        # ── Load and run the Lua file ────────────────────────────────────

        if not os.path.exists(self.lua_file):
            raise FileNotFoundError(
                "[LuaGame] Could not find Lua file: '{}'".format(self.lua_file)
            )

        with open(self.lua_file, "r", encoding="utf-8") as f:
            lua_code = f.read()

        rt.execute(lua_code)

        # ── Safely grab optional Lua functions ───────────────────────────

        def get_lua_func(name):
            try:
                val = g[name]
                return val if callable(val) else None
            except Exception:
                return None

        lua_load = get_lua_func("game_load")
        lua_update = get_lua_func("game_update")
        lua_draw = get_lua_func("game_draw")
        lua_keypressed = get_lua_func("keypressed")
        lua_keyreleased = get_lua_func("keyreleased")
        lua_mousepressed = get_lua_func("mousepressed")

        if lua_load:
            lua_load()

        # ── Game loop ────────────────────────────────────────────────────

        running = True
        while running:
            dt = clock.tick(self.fps) / 1000.0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.KEYDOWN:
                    key_name = pygame.key.name(event.key)
                    if lua_keypressed:
                        lua_keypressed(key_name)

                elif event.type == pygame.KEYUP:
                    key_name = pygame.key.name(event.key)
                    if lua_keyreleased:
                        lua_keyreleased(key_name)

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    if lua_mousepressed:
                        lua_mousepressed(mx, my, event.button)

            if lua_update:
                lua_update(dt)

            if lua_draw:
                lua_draw()

            pygame.display.flip()

        pygame.quit()


def run_game(lua_file, width=800, height=600, title="LuaGame", fps=60):
    """
    Run a .lua game file with LuaGame.

    Example:
        from LuaGame import run_game
        run_game("mygame.lua", width=800, height=600, title="My Game")
    """
    engine = LuaGameEngine(lua_file, width, height, title, fps)
    engine.run()