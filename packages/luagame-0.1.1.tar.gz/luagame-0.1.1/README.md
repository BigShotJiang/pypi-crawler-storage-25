# LuaGame

A pygame-powered engine that lets you make games in Lua!  
Write your game in a `.lua` file, run it with one Python line.

## Compatibility:
This package uses pygame to run properly.
The python version this was made on is python 3.12, it might run in higher versions

## Installation

```bash
pip install LuaGame
```

## How to Use

**1. Create your game file: `mygame.lua`**

```lua
-- runs once at the start
function load()
    player_x = 400
    player_y = 300
end

-- runs every frame (dt = time since last frame in seconds)
function update(dt)
    if is_key_down("left") then player_x = player_x - 200 * dt end
    if is_key_down("right") then player_x = player_x + 200 * dt end
end

-- draw everything here
function draw()
    clear(30, 30, 40)
    draw_rect(player_x, player_y, 40, 40, 80, 140, 255)
    draw_text("Use arrow keys!", 10, 10, 24, 255, 255, 255)
end
```

**2. Run it with Python:**

```python
from LuaGame import run_game
run_game("mygame.lua", width=800, height=600, title="My Game")
```

That's it!

---

## Lua Functions Reference

### Drawing
| Function | What it does |
|---|---|
| `clear(r, g, b)` | Fill the screen with a color |
| `draw_rect(x, y, w, h, r, g, b)` | Draw a filled rectangle |
| `draw_circle(x, y, radius, r, g, b)` | Draw a filled circle |
| `draw_line(x1, y1, x2, y2, r, g, b, width)` | Draw a line |
| `draw_text(text, x, y, size, r, g, b)` | Draw text on screen |
| `draw_image(path, x, y)` | Draw an image file |

### Input
| Function | What it does |
|---|---|
| `is_key_down("key")` | True if a key is held down (e.g. `"left"`, `"space"`, `"a"`) |
| `get_mouse_pos()` | Returns `x, y` of the mouse |
| `is_mouse_down(button)` | True if mouse button is held (1=left, 2=middle, 3=right) |

### Events (optional functions in your .lua file)
| Function | When it's called |
|---|---|
| `function load()` | Once at the start |
| `function update(dt)` | Every frame — `dt` is seconds since last frame |
| `function draw()` | Every frame after update |
| `function keypressed(key)` | When a key is first pressed |
| `function keyreleased(key)` | When a key is released |
| `function mousepressed(x, y, button)` | When a mouse button is clicked |

### Window & Utility
| Function | What it does |
|---|---|
| `screen_width()` | Returns the window width |
| `screen_height()` | Returns the window height |
| `get_time()` | Returns seconds since the game started |

---

## run_game() Options

```python
run_game(
    "mygame.lua",   # path to your lua file
    width=800,      # window width (default 800)
    height=600,     # window height (default 600)
    title="My Game",# window title (default "LuaGame")
    fps=60          # frames per second (default 60)
)
```