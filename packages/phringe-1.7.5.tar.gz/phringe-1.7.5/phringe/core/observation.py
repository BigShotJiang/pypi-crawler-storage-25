import warnings
from typing import Any, Union

from astropy import units as u
from astropy.units import Quantity
from pydantic import field_validator
from pydantic_core.core_schema import ValidationInfo

from phringe.core.base_entity import BaseEntity
from phringe.io.validation import validate_quantity_units
from phringe.lib.baseline import OptimalNullingBaseline


class Observation(BaseEntity):
    """Class representing the observation mode.

    Parameters
    ----------
    detector_integration_time : str or float or Quantity
        The detector integration time in seconds.
    modulation_period : str or float or Quantity
        The modulation/rotation period of the array in seconds.
    nulling_baseline : str or float or Quantity or OptimalNullingBaseline
        The nulling baseline in meters or an optimized nulling baseline
    solar_ecliptic_latitude : str or float or Quantity
        The solar ecliptic latitude in degrees. Used for the local zodi contribution calculation.
    total_integration_time : str or float or Quantity
        The total integration time in seconds.
    """
    detector_integration_time: Union[str, float, Quantity]
    modulation_period: Union[str, float, Quantity]
    nulling_baseline: Union[str, float, Quantity, OptimalNullingBaseline]
    solar_ecliptic_latitude: Union[str, float, Quantity]
    total_integration_time: Union[str, float, Quantity]

    @field_validator('detector_integration_time')
    def _validate_detector_integration_time(cls, value: Any, info: ValidationInfo) -> float:
        """Validate the detector integration time input.

        Parameters
        ----------
        value : Any
            The value given as input.
        info : ValidationInfo
            The validation information object.

        Returns
        -------
        float
            The detector integration time in units of seconds.
        """
        return validate_quantity_units(value=value, field_name=info.field_name, unit_equivalency=(u.s,))

    @field_validator('modulation_period')
    def _validate_modulation_period(cls, value: Any, info: ValidationInfo) -> float:
        """Validate the modulation period input.

        Parameters
        ----------
        value : Any
            The value given as input.
        info : ValidationInfo
            The validation information object.

        Returns
        -------
        float
            The modulation period in units of seconds.
        """
        return validate_quantity_units(value=value, field_name=info.field_name, unit_equivalency=(u.s,))

    @field_validator('nulling_baseline')
    def _validate_nulling_baseline(cls, value: Any, info: ValidationInfo) -> Union[float, OptimalNullingBaseline]:
        """Validate the nulling baseline input.

        Parameters
        ----------
        value : Any
            The value given as input.
        info : ValidationInfo
            The validation information object.

        Returns
        -------
        float or OptimalNullingBaseline
            The nulling baseline in units of meters, or an optimal nulling baseline object.
        """
        if isinstance(value, OptimalNullingBaseline):
            return value

        return validate_quantity_units(value=value, field_name=info.field_name, unit_equivalency=(u.m,))

    @field_validator('solar_ecliptic_latitude')
    def _validate_solar_ecliptic_latitude(cls, value: Any, info: ValidationInfo) -> float:
        """Validate the solar ecliptic latitude input.

        Parameters
        ----------
        value : Any
            The value given as input.
        info : ValidationInfo
            The validation information object.

        Returns
        -------
        float
            The solar ecliptic latitude in units of degrees.
        """
        return validate_quantity_units(value=value, field_name=info.field_name, unit_equivalency=(u.deg,))

    @field_validator('total_integration_time')
    def _validate_total_integration_time(cls, value: Any, info: ValidationInfo) -> float:
        """Validate the total integration time input.

        Parameters
        ----------
        value : Any
            The value given as input.
        info : ValidationInfo
            The validation information object.

        Returns
        -------
        float
            The total integration time in units of seconds.
        """
        return validate_quantity_units(value=value, field_name=info.field_name, unit_equivalency=(u.s,))

    @property
    def _nulling_baseline(self) -> float:
        nulling_baseline = None

        # Return the nulling baseline value if already a float in meters
        if not isinstance(self.nulling_baseline, OptimalNullingBaseline):
            nulling_baseline = self.nulling_baseline

        # Get optimized nulling baseline value in meters
        else:
            star_habitable_zone_central_angular_radius = self._phringe._scene.star._hz_central_radius_angular \
                if (self._phringe._scene is not None and self._phringe._scene.star is not None) else None
            nulling_baseline = self.nulling_baseline.get_value(
                star_habitable_zone_central_angular_radius,
            )

        # Check min and max nulling baseline limits
        nulling_baseline_min = self._phringe._instrument.nulling_baseline_min
        nulling_baseline_max = self._phringe._instrument.nulling_baseline_max

        if nulling_baseline_min <= nulling_baseline and nulling_baseline <= nulling_baseline_max:
            return nulling_baseline
        elif nulling_baseline < nulling_baseline_max:
            warnings.warn(
                f'Nulling baseline of {nulling_baseline} is below the min allowed baseline of {nulling_baseline_min}. Setting to min baseline.')
            return nulling_baseline_min
        elif nulling_baseline > nulling_baseline_max:
            warnings.warn(
                f"Nulling baseline of {nulling_baseline} is above the max allowed baseline of {nulling_baseline_max}. Setting to max baseline.")
            return nulling_baseline_max
