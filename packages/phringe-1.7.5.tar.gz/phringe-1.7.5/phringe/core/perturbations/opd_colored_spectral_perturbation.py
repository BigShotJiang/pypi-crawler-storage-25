import numpy as np
from torch import Tensor

from phringe.core.perturbations.colored_spectral_perturbation import ColoredSpectralPerturbation


class OPDColoredSpectralPerturbation(ColoredSpectralPerturbation):
    """
    Inherits from ColoredSpectralPerturbation but converts the 
    physical displacement (meters) into phase (radians).
    """

    def _get_time_series(self) -> Tensor:
        # 1. Get the physical displacement from the base class
        self.chromatic_scaling_exponent = 0.0
        self.reference_wavelength = None
        piston_time_series = super()._get_time_series()

        # 2. Get wavelengths for conversion
        wavelengths = self._phringe._instrument.wavelength_bin_centers

        # 3. Apply phase factor: 2 * pi * displacement / lambda
        # We use [None, :, None] to align with (inputs, wavelengths, time)
        phase_time_series = (2 * np.pi * piston_time_series) / wavelengths[None, :, None]

        return phase_time_series
