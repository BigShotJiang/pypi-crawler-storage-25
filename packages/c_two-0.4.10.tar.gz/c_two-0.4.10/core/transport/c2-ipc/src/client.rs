//! Async IPC client — connects to a C-Two IPC server via UDS.
//!
//! Performs handshake, then multiplexes concurrent requests over
//! a single UDS connection using request IDs.

use parking_lot::{Mutex as StdMutex, RwLock};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::UnixStream;
use tokio::sync::{Mutex, oneshot};

use c2_mem::FreeResult;
use c2_wire::buddy::{
    BUDDY_PAYLOAD_SIZE, BuddyPayload, decode_buddy_payload, encode_buddy_payload,
};
use c2_wire::chunk::encode_chunk_header;
use c2_wire::chunk::{ChunkConfig, ChunkRegistry};
use c2_wire::control::{ReplyControl, decode_reply_control, encode_call_control};
use c2_wire::flags;
use c2_wire::frame::{self, DecodeError, FrameHeader, HEADER_SIZE};
use c2_wire::handshake::{
    CAP_CALL_V2, CAP_CHUNKED, CAP_METHOD_IDX, Handshake, MethodEntry, RouteInfo, decode_handshake,
    encode_client_handshake,
};

use c2_mem::config::PoolConfig;
use c2_mem::{MemPool, PoolAllocation};

use crate::response::ResponseData;

pub use c2_config::ClientIpcConfig;

// ── Server pool state ────────────────────────────────────────────────────

/// State for reading server's SHM response data.
/// Mirrors `PeerShmState` in c2-server/connection.rs.
pub struct ServerPoolState {
    prefix: String,
    buddy_segment_size: usize,
    pub pool: MemPool,
}

impl ServerPoolState {
    fn buddy_segment_name(prefix: &str, idx: usize) -> String {
        format!("{}_{}{:04x}", prefix, "b", idx)
    }

    fn dedicated_segment_name(prefix: &str, idx: u32) -> String {
        format!("{}_{}{:04x}", prefix, "d", idx)
    }

    /// Ensure the pool has the buddy segment at `seg_idx` open.
    fn ensure_buddy_segment(&mut self, seg_idx: u16) -> Result<(), String> {
        let idx = seg_idx as usize;
        if idx < self.pool.segment_count() {
            return Ok(());
        }
        for i in self.pool.segment_count()..=idx {
            let name = Self::buddy_segment_name(&self.prefix, i);
            self.pool.open_segment(&name, self.buddy_segment_size)?;
        }
        Ok(())
    }

    /// Ensure a dedicated segment is open at the specific index.
    fn ensure_dedicated_segment(&mut self, seg_idx: u16, min_size: usize) -> Result<(), String> {
        let name = Self::dedicated_segment_name(&self.prefix, seg_idx as u32);
        self.pool.open_dedicated_at(seg_idx as u32, &name, min_size)
    }

    /// Lazy-open the segment for the given coordinates if not yet mapped.
    ///
    /// Called transparently by language binding response buffers before any
    /// SHM access. SDKs do not need to know about segment management; this
    /// keeps it entirely inside Rust.
    pub fn ensure_segment(
        &mut self,
        seg_idx: u16,
        data_size: u32,
        is_dedicated: bool,
    ) -> Result<(), String> {
        if is_dedicated {
            self.ensure_dedicated_segment(seg_idx, data_size as usize)
        } else {
            self.ensure_buddy_segment(seg_idx)
        }
    }

    /// Read data from server SHM and free the allocation.
    pub fn read_and_free(
        &mut self,
        seg_idx: u16,
        offset: u32,
        data_size: u32,
        is_dedicated: bool,
    ) -> Result<(Vec<u8>, FreeResult), String> {
        if is_dedicated {
            self.ensure_dedicated_segment(seg_idx, data_size as usize)?;
        } else {
            self.ensure_buddy_segment(seg_idx)?;
        }

        let ptr = self
            .pool
            .data_ptr_at(seg_idx as u32, offset, is_dedicated)?;
        let data = unsafe { std::slice::from_raw_parts(ptr, data_size as usize) }.to_vec();

        let free_result = match self
            .pool
            .free_at(seg_idx as u32, offset, data_size, is_dedicated)
        {
            Ok(r) => r,
            Err(e) => {
                eprintln!("Warning: server SHM free_at failed: {e}");
                FreeResult::Normal
            }
        };

        Ok((data, free_result))
    }
}

// ── Error type ───────────────────────────────────────────────────────────

/// IPC client error.
#[derive(Debug)]
pub enum IpcError {
    /// I/O error on the UDS connection.
    Io(std::io::Error),
    /// Invalid client configuration or IPC address.
    Config(String),
    /// Wire protocol decoding error.
    Decode(DecodeError),
    /// Handshake failed or incompatible server.
    Handshake(String),
    /// Requested route no longer exists on the connected IPC server.
    RouteNotFound(String),
    /// CRM method returned an error (serialized error bytes).
    CrmError(Vec<u8>),
    /// Client is closed or connection lost.
    Closed,
    /// Pool management error.
    Pool(String),
}

impl std::fmt::Display for IpcError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(e) => write!(f, "IPC I/O error: {e}"),
            Self::Config(msg) => write!(f, "IPC config error: {msg}"),
            Self::Decode(e) => write!(f, "IPC decode error: {e}"),
            Self::Handshake(msg) => write!(f, "IPC handshake failed: {msg}"),
            Self::RouteNotFound(route) => write!(f, "IPC route not found: {route}"),
            Self::CrmError(_) => write!(f, "CRM method error"),
            Self::Closed => write!(f, "IPC client closed"),
            Self::Pool(msg) => write!(f, "Pool error: {msg}"),
        }
    }
}

impl std::error::Error for IpcError {}

impl From<std::io::Error> for IpcError {
    fn from(e: std::io::Error) -> Self {
        Self::Io(e)
    }
}

impl From<DecodeError> for IpcError {
    fn from(e: DecodeError) -> Self {
        Self::Decode(e)
    }
}

impl From<c2_wire::control::EncodeError> for IpcError {
    fn from(e: c2_wire::control::EncodeError) -> Self {
        Self::Handshake(e.to_string())
    }
}

// ── Method table ─────────────────────────────────────────────────────────

/// Per-route method table (name ↔ index).
#[derive(Debug, Clone)]
pub struct MethodTable {
    crm_ns: String,
    crm_name: String,
    crm_ver: String,
    name_to_idx: HashMap<String, u16>,
}

impl MethodTable {
    fn from_route(route: &RouteInfo) -> Self {
        Self::from_entries(
            &route.methods,
            route.crm_ns.clone(),
            route.crm_name.clone(),
            route.crm_ver.clone(),
        )
    }

    fn from_entries(
        entries: &[MethodEntry],
        crm_ns: String,
        crm_name: String,
        crm_ver: String,
    ) -> Self {
        let mut name_to_idx = HashMap::with_capacity(entries.len());
        for e in entries {
            name_to_idx.insert(e.name.clone(), e.index);
        }
        Self {
            crm_ns,
            crm_name,
            crm_ver,
            name_to_idx,
        }
    }

    /// Look up method index by name.
    pub fn index_of(&self, name: &str) -> Option<u16> {
        self.name_to_idx.get(name).copied()
    }

    /// Get all method names.
    pub fn method_names(&self) -> Vec<&str> {
        self.name_to_idx.keys().map(|s| s.as_str()).collect()
    }

    /// CRM namespace advertised for this route in the IPC handshake.
    pub fn crm_ns(&self) -> &str {
        &self.crm_ns
    }

    /// CRM contract class/model name advertised for this route in the IPC handshake.
    pub fn crm_name(&self) -> &str {
        &self.crm_name
    }

    /// CRM version advertised for this route in the IPC handshake.
    pub fn crm_ver(&self) -> &str {
        &self.crm_ver
    }
}

// ── Pending call ─────────────────────────────────────────────────────────

type PendingMap = HashMap<u32, oneshot::Sender<Result<ResponseData, IpcError>>>;

// ── IpcClient ────────────────────────────────────────────────────────────

/// Async IPC client for the C-Two relay.
///
/// Connects to a C-Two IPC server via Unix Domain Socket, performs
/// handshake, and multiplexes concurrent CRM calls.
pub struct IpcClient {
    socket_path: PathBuf,
    address_error: Option<String>,
    writer: Arc<Mutex<Option<tokio::io::WriteHalf<UnixStream>>>>,
    pending: Arc<StdMutex<PendingMap>>,
    rid_counter: AtomicU32,
    pub(crate) route_tables: HashMap<String, MethodTable>,
    server_segments: Vec<(String, u32)>,
    pub(crate) server_identity: Option<c2_wire::handshake::ServerIdentity>,
    /// Server SHM pool state for reading buddy reply responses.
    pub(crate) server_pool: Arc<StdMutex<Option<ServerPoolState>>>,
    recv_handle: Arc<StdMutex<Option<tokio::task::JoinHandle<()>>>>,
    connected: Arc<AtomicBool>,
    pub(crate) pool: Option<Arc<StdMutex<MemPool>>>,
    pub(crate) config: ClientIpcConfig,
    /// Client-side chunk registry for reassembling chunked responses.
    pub(crate) chunk_registry: Arc<ChunkRegistry>,
    /// Unique connection identifier for the chunk registry.
    conn_id: u64,
}

// Compile-time assertion: IpcClient is Send+Sync because all fields are
// Arc-wrapped (Send+Sync), atomic (Send+Sync), or standard collections
// of Send+Sync types. This is required for safe use from language
// bindings that share clients across threads.
const _: () = {
    fn _assert_send<T: Send>() {}
    fn _assert_sync<T: Sync>() {}
    fn _assertions() {
        _assert_send::<IpcClient>();
        _assert_sync::<IpcClient>();
    }
};

/// Monotonic counter so each reassembly MemPool gets a unique SHM prefix.
/// Format: `/cc3a{pid:08x}{counter:08x}` — 32-bit range, 27 chars max.
static REASSEMBLY_POOL_GEN: AtomicU64 = AtomicU64::new(0);

/// Monotonic counter so each IpcClient gets a unique conn_id.
static CLIENT_CONN_COUNTER: AtomicU64 = AtomicU64::new(1);

fn socket_path_from_address(address: &str) -> (PathBuf, Option<String>) {
    match crate::control::socket_path_from_ipc_address(address) {
        Ok(path) => (path, None),
        Err(error) => (
            PathBuf::from("/tmp/c_two_ipc").join("invalid.sock"),
            Some(error.to_string()),
        ),
    }
}

impl IpcClient {
    fn make_chunk_registry(config: &ClientIpcConfig) -> Arc<ChunkRegistry> {
        let seg_size = config.reassembly_segment_size as usize;
        let max_segs = config.reassembly_max_segments as usize;
        let counter = REASSEMBLY_POOL_GEN.fetch_add(1, Ordering::Relaxed) as u32;
        let prefix = format!("/cc3a{:08x}{:08x}", std::process::id(), counter);
        let pool = Arc::new(RwLock::new(MemPool::new_with_prefix(
            PoolConfig {
                segment_size: seg_size,
                max_segments: max_segs,
                ..PoolConfig::default()
            },
            prefix,
        )));
        let chunk_config = ChunkConfig::from_base(config);
        Arc::new(ChunkRegistry::new(pool, chunk_config))
    }

    /// Create a new IPC client targeting the given address.
    ///
    /// The address should be like `ipc://name` — the socket path is
    /// derived as `/tmp/c_two_ipc/{name}.sock`.
    pub fn new(address: &str) -> Self {
        let (socket_path, address_error) = socket_path_from_address(address);

        Self {
            socket_path,
            address_error,
            writer: Arc::new(Mutex::new(None)),
            pending: Arc::new(StdMutex::new(HashMap::new())),
            rid_counter: AtomicU32::new(1),
            route_tables: HashMap::new(),
            server_segments: Vec::new(),
            server_identity: None,
            server_pool: Arc::new(StdMutex::new(None)),
            recv_handle: Arc::new(StdMutex::new(None)),
            connected: Arc::new(AtomicBool::new(false)),
            pool: None,
            config: ClientIpcConfig::default(),
            chunk_registry: Self::make_chunk_registry(&ClientIpcConfig::default()),
            conn_id: CLIENT_CONN_COUNTER.fetch_add(1, Ordering::Relaxed),
        }
    }

    /// Create a new IPC client with a buddy pool for SHM transfers.
    ///
    /// The pool is used for outgoing buddy allocations when data exceeds
    /// `config.shm_threshold`.
    pub fn with_pool(address: &str, pool: Arc<StdMutex<MemPool>>, config: ClientIpcConfig) -> Self {
        let (socket_path, address_error) = socket_path_from_address(address);

        Self {
            socket_path,
            address_error,
            writer: Arc::new(Mutex::new(None)),
            pending: Arc::new(StdMutex::new(HashMap::new())),
            rid_counter: AtomicU32::new(1),
            route_tables: HashMap::new(),
            server_segments: Vec::new(),
            server_identity: None,
            server_pool: Arc::new(StdMutex::new(None)),
            recv_handle: Arc::new(StdMutex::new(None)),
            connected: Arc::new(AtomicBool::new(false)),
            pool: Some(pool),
            chunk_registry: Self::make_chunk_registry(&config),
            conn_id: CLIENT_CONN_COUNTER.fetch_add(1, Ordering::Relaxed),
            config,
        }
    }

    /// Connect and perform handshake.
    pub async fn connect(&mut self) -> Result<(), IpcError> {
        if let Some(error) = self.address_error.clone() {
            return Err(IpcError::Config(error));
        }
        let stream = UnixStream::connect(&self.socket_path).await?;
        let (reader, mut writer) = tokio::io::split(stream);

        // Pre-allocate first SHM segment so handshake announces it.
        if let Some(ref pool_arc) = self.pool {
            let mut pool = pool_arc.lock();
            pool.ensure_ready()
                .map_err(|e| IpcError::Io(std::io::Error::new(std::io::ErrorKind::Other, e)))?;
        }

        // Perform handshake.
        let hs = self.do_handshake(&mut writer, reader).await?;
        let server_identity = hs.server_identity.clone().ok_or_else(|| {
            IpcError::Handshake("server handshake missing server identity".into())
        })?;

        // Store method tables from the handshake response.
        for route in &hs.routes {
            let table = MethodTable::from_route(route);
            self.route_tables.insert(route.name.clone(), table);
        }
        self.server_segments = hs.segments.clone();
        self.server_identity = Some(server_identity);

        // Open server SHM segments into a ServerPoolState for buddy response reads.
        if !hs.segments.is_empty() {
            let buddy_seg_size = hs.segments[0].1 as usize;
            let cfg = c2_mem::config::PoolConfig {
                segment_size: buddy_seg_size,
                min_block_size: 4096,
                max_segments: 16,
                max_dedicated_segments: 8,
                dedicated_crash_timeout_secs: 60.0,
                buddy_idle_decay_secs: 60.0,
                spill_threshold: 1.0,
                spill_dir: std::path::PathBuf::from("/tmp"),
            };
            let mut pool = MemPool::new_with_prefix(cfg, hs.prefix.clone());
            for (name, size) in &hs.segments {
                if let Err(e) = pool.open_segment(name, *size as usize) {
                    eprintln!("Warning: failed to open server SHM segment ({name}): {e}");
                }
            }
            *self.server_pool.lock() = Some(ServerPoolState {
                prefix: hs.prefix.clone(),
                buddy_segment_size: buddy_seg_size,
                pool,
            });
        }

        *self.writer.lock().await = Some(writer);

        self.connected.store(true, Ordering::Release);

        // Spawn the receive loop — replaced below in `do_handshake`.
        // Actually, we need to spawn it with the reader after handshake.
        // The reader was consumed by do_handshake, so we get it back.
        // This is handled inside do_handshake which returns a new reader.

        Ok(())
    }

    async fn do_handshake(
        &self,
        writer: &mut tokio::io::WriteHalf<UnixStream>,
        mut reader: tokio::io::ReadHalf<UnixStream>,
    ) -> Result<Handshake, IpcError> {
        // Build segment list and prefix from pool (if available).
        let (segments, prefix, cap_flags) = if let Some(ref pool_arc) = self.pool {
            let pool = pool_arc.lock();
            let count = pool.segment_count();
            let mut segs = Vec::with_capacity(count);
            for i in 0..count {
                if let (Some(name), Some(seg)) = (pool.segment_name(i), pool.segment(i)) {
                    segs.push((name.to_string(), seg.allocator().data_size() as u32));
                }
            }
            let pfx = pool.prefix().to_string();
            (segs, pfx, CAP_CALL_V2 | CAP_METHOD_IDX | CAP_CHUNKED)
        } else {
            (vec![], String::new(), CAP_CALL_V2 | CAP_METHOD_IDX)
        };

        let payload = encode_client_handshake(&segments, cap_flags, &prefix)
            .map_err(|e| IpcError::Handshake(e.to_string()))?;
        let frame_bytes = frame::encode_frame(0, flags::FLAG_HANDSHAKE, &payload);
        writer.write_all(&frame_bytes).await?;

        // Read handshake response.
        let mut header_buf = [0u8; HEADER_SIZE];
        reader.read_exact(&mut header_buf).await?;
        let (total_len, body_rest) = frame::decode_total_len(&header_buf)?;
        let (hdr, _hdr_payload) = frame::decode_frame_body(body_rest, total_len)?;

        if !hdr.is_handshake() {
            return Err(IpcError::Handshake(
                "Server response is not a handshake frame".into(),
            ));
        }

        let payload_len = hdr.payload_len();
        let mut payload_buf = vec![0u8; payload_len];
        if payload_len > 0 {
            reader.read_exact(&mut payload_buf).await?;
        }

        let hs = decode_handshake(&payload_buf)
            .map_err(|e| IpcError::Handshake(format!("decode: {e}")))?;

        if hs.capability_flags & CAP_CALL_V2 == 0 {
            return Err(IpcError::Handshake(
                "Server does not support v2 call frames".into(),
            ));
        }
        if hs.server_identity.is_none() {
            return Err(IpcError::Handshake(
                "server handshake missing server identity".into(),
            ));
        }

        // Spawn recv loop with the reader.
        let pending = self.pending.clone();
        let server_pool = self.server_pool.clone();
        let writer_clone = self.writer.clone();
        let connected = self.connected.clone();
        let chunk_registry = self.chunk_registry.clone();
        let conn_id = self.conn_id;
        let recv_handle = tokio::spawn(async move {
            recv_loop(
                reader,
                pending,
                server_pool,
                writer_clone,
                chunk_registry,
                conn_id,
            )
            .await;
            connected.store(false, Ordering::Release);
        });
        *self.recv_handle.lock() = Some(recv_handle);

        Ok(hs)
    }

    /// Get a reference to the server SHM pool (for materialising SHM responses).
    pub fn server_pool_arc(&self) -> &Arc<StdMutex<Option<ServerPoolState>>> {
        &self.server_pool
    }

    /// Get a reference to the reassembly pool (for materialising Handle responses).
    pub fn reassembly_pool_arc(&self) -> Arc<RwLock<MemPool>> {
        self.chunk_registry.pool().clone()
    }

    /// Identity announced by the connected IPC server handshake.
    pub fn server_identity(&self) -> Option<&c2_wire::handshake::ServerIdentity> {
        self.server_identity.as_ref()
    }

    /// Stable logical server ID announced by the connected IPC server.
    pub fn server_id(&self) -> Option<&str> {
        self.server_identity
            .as_ref()
            .map(|identity| identity.server_id.as_str())
    }

    /// Per-server-incarnation ID announced by the connected IPC server.
    pub fn server_instance_id(&self) -> Option<&str> {
        self.server_identity
            .as_ref()
            .map(|identity| identity.server_instance_id.as_str())
    }

    /// Send a CRM call and wait for the response (inline path only).
    ///
    /// This is the primary API for the relay: HTTP handler calls this
    /// with the route name, method name, and serialized payload.
    pub async fn call(
        &self,
        route_name: &str,
        method_name: &str,
        data: &[u8],
    ) -> Result<ResponseData, IpcError> {
        let table = self
            .route_tables
            .get(route_name)
            .ok_or_else(|| IpcError::Handshake(format!("unknown route: {route_name}")))?;
        let method_idx = table
            .index_of(method_name)
            .ok_or_else(|| IpcError::Handshake(format!("unknown method: {method_name}")))?;

        self.call_inline(route_name, method_idx, data).await
    }

    /// Send a CRM call with automatic transport path selection.
    ///
    /// Selects the optimal transport based on data size and pool availability:
    /// - Buddy SHM for data above `config.shm_threshold` (when pool available)
    /// - Chunked transfer for data above `config.chunk_size`
    /// - Inline for small payloads
    pub async fn call_full(
        &self,
        route_name: &str,
        method_name: &str,
        data: &[u8],
    ) -> Result<ResponseData, IpcError> {
        let table = self
            .route_tables
            .get(route_name)
            .ok_or_else(|| IpcError::Handshake(format!("unknown route: {route_name}")))?;
        let method_idx = table
            .index_of(method_name)
            .ok_or_else(|| IpcError::Handshake(format!("unknown method: {method_name}")))?;

        // Try buddy SHM for large payloads when pool is available.
        if self.pool.is_some() && data.len() > self.config.shm_threshold as usize {
            match self.call_buddy(route_name, method_idx, data).await {
                Ok(result) => return Ok(result),
                Err(IpcError::Handshake(_)) => {
                    // Pool alloc failed — fall through to chunked/inline.
                }
                Err(e) => return Err(e),
            }
        }

        // Use chunked transfer for data exceeding chunk size.
        if data.len() > self.config.chunk_size as usize {
            return self.call_chunked(route_name, method_idx, data).await;
        }

        // Default: inline.
        self.call_inline(route_name, method_idx, data).await
    }

    /// Inline call path — sends call control + data in a single frame.
    async fn call_inline(
        &self,
        route_name: &str,
        method_idx: u16,
        data: &[u8],
    ) -> Result<ResponseData, IpcError> {
        let rid = self.rid_counter.fetch_add(1, Ordering::Relaxed);

        // Register pending call.
        let (tx, rx) = oneshot::channel();
        {
            self.pending.lock().insert(rid, tx);
        }

        // Build and send the frame.
        // Compute ctrl size: 1 byte name_len + name + 2 bytes method_idx
        let ctrl_len = 1 + route_name.len() + 2;
        let payload_len = ctrl_len + data.len();
        let total_len = (12 + payload_len) as u32;
        let frame_size = frame::HEADER_SIZE + payload_len;

        let send_result: Result<(), IpcError> = async {
            let mut writer_guard = self.writer.lock().await;
            let writer = writer_guard.as_mut().ok_or(IpcError::Closed)?;

            if frame_size <= 1024 {
                // Stack-allocate the entire frame (zero heap, single syscall).
                let mut buf = [0u8; 1024];
                buf[0..4].copy_from_slice(&total_len.to_le_bytes());
                buf[4..12].copy_from_slice(&(rid as u64).to_le_bytes());
                buf[12..16].copy_from_slice(&flags::FLAG_CALL_V2.to_le_bytes());
                let ctrl_written = c2_wire::control::encode_call_control_into(
                    &mut buf,
                    frame::HEADER_SIZE,
                    route_name,
                    method_idx,
                )?;
                let data_off = frame::HEADER_SIZE + ctrl_written;
                buf[data_off..data_off + data.len()].copy_from_slice(data);
                writer.write_all(&buf[..frame_size]).await?;
            } else {
                // Large payload: header+ctrl on stack, data separate write.
                let mut hdr_buf = [0u8; frame::HEADER_SIZE];
                hdr_buf[0..4].copy_from_slice(&total_len.to_le_bytes());
                hdr_buf[4..12].copy_from_slice(&(rid as u64).to_le_bytes());
                hdr_buf[12..16].copy_from_slice(&flags::FLAG_CALL_V2.to_le_bytes());
                let ctrl = encode_call_control(route_name, method_idx)?;
                writer.write_all(&hdr_buf).await?;
                writer.write_all(&ctrl).await?;
                writer.write_all(data).await?;
            }
            Ok(())
        }
        .await;

        if let Err(e) = send_result {
            self.pending.lock().remove(&rid);
            return Err(e);
        }

        // Await response.
        match rx.await {
            Ok(result) => result,
            Err(_) => Err(IpcError::Closed),
        }
    }

    /// Buddy SHM call path — allocates from MemPool and sends buddy frame.
    ///
    /// The server reads data from SHM and frees the allocation.
    async fn call_buddy(
        &self,
        route_name: &str,
        method_idx: u16,
        data: &[u8],
    ) -> Result<ResponseData, IpcError> {
        let pool_arc = self.pool.as_ref().unwrap();

        // Allocate and write data to SHM.
        let alloc = {
            let mut pool = pool_arc.lock();
            pool.alloc(data.len())
                .map_err(|e| IpcError::Handshake(format!("buddy alloc failed: {e}")))?
        };

        // Write data into the SHM region.
        {
            let pool = pool_arc.lock();
            let ptr = match pool.data_ptr(&alloc) {
                Ok(p) => p,
                Err(e) => {
                    drop(pool);
                    let _ = pool_arc.lock().free(&alloc);
                    return Err(IpcError::Handshake(format!("buddy data_ptr failed: {e}")));
                }
            };
            unsafe {
                std::ptr::copy_nonoverlapping(data.as_ptr(), ptr, data.len());
            }
        }

        // Build buddy payload.
        let bp = BuddyPayload {
            seg_idx: alloc.seg_idx as u16,
            offset: alloc.offset,
            data_size: data.len() as u32,
            is_dedicated: alloc.is_dedicated,
        };
        let buddy_bytes = encode_buddy_payload(&bp);

        // Build call control.
        let ctrl = encode_call_control(route_name, method_idx)?;

        // Assemble frame payload: [11B buddy][call_control]
        let payload_len = buddy_bytes.len() + ctrl.len();
        let mut payload = Vec::with_capacity(payload_len);
        payload.extend_from_slice(&buddy_bytes);
        payload.extend_from_slice(&ctrl);

        let rid = self.rid_counter.fetch_add(1, Ordering::Relaxed);

        // Register pending call.
        let (tx, rx) = oneshot::channel();
        {
            self.pending.lock().insert(rid, tx);
        }

        // Send frame — free buddy allocation if send fails.
        let frame_flags = flags::FLAG_CALL_V2 | flags::FLAG_BUDDY;
        let frame_bytes = frame::encode_frame(rid as u64, frame_flags, &payload);
        {
            let mut writer_guard = self.writer.lock().await;
            let writer = match writer_guard.as_mut() {
                Some(w) => w,
                None => {
                    let _ = pool_arc.lock().free(&alloc);
                    self.pending.lock().remove(&rid);
                    return Err(IpcError::Closed);
                }
            };
            if let Err(e) = writer.write_all(&frame_bytes).await {
                let _ = pool_arc.lock().free(&alloc);
                self.pending.lock().remove(&rid);
                return Err(e.into());
            }
        }

        // Await response (server frees the buddy allocation after reading).
        match rx.await {
            Ok(result) => {
                // Free dedicated request allocation — server has read the data
                // and only its local peer pool was freed.  Buddy allocs are
                // freed by the server via cross-process SHM atomics; freeing
                // them again here would corrupt the allocator.
                if alloc.is_dedicated {
                    let mut pool = pool_arc.lock();
                    let _ = pool.free(&alloc);
                }
                result
            }
            Err(_) => Err(IpcError::Closed),
        }
    }

    /// Buddy SHM call path with pre-allocated data — sends buddy frame for
    /// data that was already written to the client's SHM pool.
    ///
    /// Unlike `call_buddy()`, this does NOT alloc or write — the caller
    /// already did that. On send failure, frees the allocation from the pool.
    pub(crate) async fn call_with_prealloc(
        &self,
        route_name: &str,
        method_idx: u16,
        alloc: &PoolAllocation,
        data_size: usize,
    ) -> Result<ResponseData, IpcError> {
        // Build buddy payload from pre-allocated coordinates.
        let bp = BuddyPayload {
            seg_idx: alloc.seg_idx as u16,
            offset: alloc.offset,
            data_size: data_size as u32,
            is_dedicated: alloc.is_dedicated,
        };
        let buddy_bytes = encode_buddy_payload(&bp);

        // Build call control.
        let ctrl = encode_call_control(route_name, method_idx)?;

        // Assemble frame payload: [11B buddy][call_control]
        let payload_len = buddy_bytes.len() + ctrl.len();
        let mut payload = Vec::with_capacity(payload_len);
        payload.extend_from_slice(&buddy_bytes);
        payload.extend_from_slice(&ctrl);

        let rid = self.rid_counter.fetch_add(1, Ordering::Relaxed);

        // Register pending call.
        let (tx, rx) = oneshot::channel();
        {
            self.pending.lock().insert(rid, tx);
        }

        // Send buddy frame.
        let flags = flags::FLAG_CALL_V2 | flags::FLAG_BUDDY;
        let frame = frame::encode_frame(rid as u64, flags, &payload);

        let send_result: Result<(), IpcError> = async {
            let mut writer_guard = self.writer.lock().await;
            let writer = writer_guard.as_mut().ok_or(IpcError::Closed)?;
            writer.write_all(&frame).await?;
            Ok(())
        }
        .await;

        if let Err(e) = send_result {
            // Send failed — server never saw the allocation. Free it.
            // This matches call_buddy() behavior.
            if let Some(ref pool_arc) = self.pool {
                let mut pool = pool_arc.lock();
                let _ = pool.free(alloc);
            }
            self.pending.lock().remove(&rid);
            return Err(e);
        }

        // Await response — server already consumed the SHM allocation.
        // For dedicated segments, the server only freed its local peer-pool
        // copy; the client must also free its own allocation so the dedicated
        // segment can be GC'd and the slot reused.
        match rx.await {
            Ok(result) => {
                if alloc.is_dedicated {
                    if let Some(ref pool_arc) = self.pool {
                        let mut pool = pool_arc.lock();
                        let _ = pool.free(alloc);
                    }
                }
                result
            }
            Err(_) => Err(IpcError::Closed),
        }
    }

    /// Chunked call path — splits data into chunks and sends with FLAG_CHUNKED.
    async fn call_chunked(
        &self,
        route_name: &str,
        method_idx: u16,
        data: &[u8],
    ) -> Result<ResponseData, IpcError> {
        let chunk_size = self.config.chunk_size as usize;
        let total_chunks = (data.len() + chunk_size - 1) / chunk_size;

        let rid = self.rid_counter.fetch_add(1, Ordering::Relaxed);

        // Register pending call ONCE — reply comes after last chunk.
        let (tx, rx) = oneshot::channel();
        {
            self.pending.lock().insert(rid, tx);
        }

        // Build call control (included only in chunk 0).
        let ctrl = encode_call_control(route_name, method_idx)?;

        let send_result: Result<(), IpcError> = async {
            let mut writer_guard = self.writer.lock().await;
            let writer = writer_guard.as_mut().ok_or(IpcError::Closed)?;

            for i in 0..total_chunks {
                let chunk_start = i * chunk_size;
                let chunk_end = std::cmp::min(chunk_start + chunk_size, data.len());
                let chunk_data = &data[chunk_start..chunk_end];

                let is_last = i == total_chunks - 1;
                let mut frame_flags = flags::FLAG_CALL_V2 | flags::FLAG_CHUNKED;
                if is_last {
                    frame_flags |= flags::FLAG_CHUNK_LAST;
                }

                let chunk_hdr = encode_chunk_header(i as u16, total_chunks as u16);

                // Chunk 0 includes call_control; subsequent chunks are data-only.
                let payload_len =
                    chunk_hdr.len() + if i == 0 { ctrl.len() } else { 0 } + chunk_data.len();
                let mut payload = Vec::with_capacity(payload_len);
                payload.extend_from_slice(&chunk_hdr);
                if i == 0 {
                    payload.extend_from_slice(&ctrl);
                }
                payload.extend_from_slice(chunk_data);

                let frame_bytes = frame::encode_frame(rid as u64, frame_flags, &payload);
                writer.write_all(&frame_bytes).await?;
            }
            Ok(())
        }
        .await;

        if let Err(e) = send_result {
            self.pending.lock().remove(&rid);
            return Err(e);
        }

        // Await response.
        match rx.await {
            Ok(result) => result,
            Err(_) => Err(IpcError::Closed),
        }
    }

    /// Get the method table for a route.
    pub fn route_table(&self, name: &str) -> Option<&MethodTable> {
        self.route_tables.get(name)
    }

    /// Whether the handshake route table contains a route.
    pub fn has_route(&self, name: &str) -> bool {
        self.route_tables.contains_key(name)
    }

    /// Validate that the connected route matches the expected CRM contract.
    ///
    /// Empty expected namespace and version mean "no CRM contract expectation",
    /// which keeps low-level transport probes usable without inventing dummy CRM
    /// identities.
    pub fn validate_route_contract(
        &self,
        route_name: &str,
        expected_crm_ns: &str,
        expected_crm_name: &str,
        expected_crm_ver: &str,
    ) -> Result<(), IpcError> {
        if expected_crm_ns.is_empty() && expected_crm_name.is_empty() && expected_crm_ver.is_empty()
        {
            return Ok(());
        }
        let table = self
            .route_tables
            .get(route_name)
            .ok_or_else(|| IpcError::RouteNotFound(route_name.to_string()))?;
        if table.crm_ns() == expected_crm_ns
            && table.crm_name() == expected_crm_name
            && table.crm_ver() == expected_crm_ver
        {
            return Ok(());
        }
        Err(IpcError::Handshake(format!(
            "CRM contract mismatch for route {route_name}: expected {expected_crm_ns}/{expected_crm_name}/{expected_crm_ver}, got {}/{}/{}",
            table.crm_ns(),
            table.crm_name(),
            table.crm_ver(),
        )))
    }

    /// CRM tag advertised by a route, if present.
    pub fn route_contract(&self, route_name: &str) -> Option<(&str, &str, &str)> {
        self.route_tables
            .get(route_name)
            .map(|table| (table.crm_ns(), table.crm_name(), table.crm_ver()))
    }

    /// Get all route names.
    pub fn route_names(&self) -> Vec<&str> {
        self.route_tables.keys().map(|s| s.as_str()).collect()
    }

    /// Whether the client has an active connection.
    pub fn is_connected(&self) -> bool {
        self.connected.load(Ordering::Acquire)
    }

    /// Manually override the connection flag.
    ///
    /// Intended for test scenarios where a real handshake is not
    /// performed.  Production code should rely on [`connect`] / [`close`].
    pub fn force_connected(&self, val: bool) {
        self.connected.store(val, Ordering::Release);
    }

    /// Close the client.
    pub async fn close(&mut self) {
        self.close_shared().await;
    }

    /// Close the client through shared ownership.
    ///
    /// This is intentionally best-effort: it marks the connection closed,
    /// sends a disconnect signal when possible, drops the writer, and wakes
    /// pending callers. It is used by owners that hold an `Arc<IpcClient>` and
    /// cannot prove unique ownership at shutdown time.
    pub async fn close_shared(&self) {
        self.connected.store(false, Ordering::Release);
        // Best-effort: send DISCONNECT signal so the server can clean up
        // immediately instead of waiting for heartbeat timeout.
        {
            let mut guard = self.writer.lock().await;
            if let Some(w) = guard.as_mut() {
                let disconnect_frame =
                    frame::encode_frame(0, flags::FLAG_SIGNAL, &[SIG_DISCONNECT]);
                let _ = w.write_all(&disconnect_frame).await;
            }
        }
        // Brief grace period for the server to reply DISCONNECT_ACK.
        tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        // Drop writer to close the write half.
        *self.writer.lock().await = None;
        // Abort recv task in case the peer does not close promptly.
        if let Some(handle) = self.recv_handle.lock().take() {
            handle.abort();
        }
        // Wake pending callers.
        let mut pending = self.pending.lock();
        for (_, tx) in pending.drain() {
            let _ = tx.send(Err(IpcError::Closed));
        }
    }
}

// ── Recv loop ────────────────────────────────────────────────────────────

/// Signal byte constants from the canonical wire protocol.
const SIG_PING: u8 = 0x01;
const SIG_PONG: u8 = 0x02;
const SIG_DISCONNECT: u8 = 0x08;
const SIG_DISCONNECT_ACK: u8 = 0x09;

async fn recv_loop(
    mut reader: tokio::io::ReadHalf<UnixStream>,
    pending: Arc<StdMutex<PendingMap>>,
    _server_pool: Arc<StdMutex<Option<ServerPoolState>>>,
    writer: Arc<Mutex<Option<tokio::io::WriteHalf<UnixStream>>>>,
    chunk_registry: Arc<ChunkRegistry>,
    conn_id: u64,
) {
    let mut header_buf = [0u8; HEADER_SIZE];
    let mut recv_buf = Vec::with_capacity(4096); // reusable buffer
    loop {
        // Read frame header.
        if reader.read_exact(&mut header_buf).await.is_err() {
            break; // Connection closed.
        }
        let (total_len, body_rest) = match frame::decode_total_len(&header_buf) {
            Ok(v) => v,
            Err(_) => continue,
        };
        let (hdr, _) = match frame::decode_frame_body(body_rest, total_len) {
            Ok(v) => v,
            Err(_) => continue,
        };

        let payload_len = hdr.payload_len();
        // Reuse recv_buf: resize without shrinking allocation.
        recv_buf.clear();
        if payload_len > recv_buf.capacity() {
            recv_buf.reserve(payload_len - recv_buf.capacity());
        }
        recv_buf.resize(payload_len, 0);
        if payload_len > 0 {
            if reader.read_exact(&mut recv_buf).await.is_err() {
                break;
            }
        }

        // Handle signal frames.
        if hdr.is_signal() {
            if recv_buf.len() == 1 {
                match recv_buf[0] {
                    SIG_PING => {
                        let pong = frame::encode_frame(
                            hdr.request_id,
                            flags::FLAG_RESPONSE | flags::FLAG_SIGNAL,
                            &[SIG_PONG],
                        );
                        let mut guard = writer.lock().await;
                        if let Some(w) = guard.as_mut() {
                            let _ = w.write_all(&pong).await;
                        }
                    }
                    SIG_DISCONNECT_ACK => {
                        break; // Server acknowledged disconnect — exit cleanly.
                    }
                    _ => {} // Ignore unknown signals.
                }
            }
            continue; // Don't dispatch signals to pending callers.
        }

        let rid = hdr.request_id as u32;

        // Handle chunked response frames.
        if hdr.is_response() && flags::is_chunked(hdr.flags) {
            use c2_wire::chunk::decode_reply_chunk_meta;

            let (total_size, total_chunks, chunk_idx, meta_consumed) =
                match decode_reply_chunk_meta(&recv_buf, 0) {
                    Ok(v) => v,
                    Err(e) => {
                        eprintln!("Warning: reply chunk meta decode error: {e:?}");
                        continue;
                    }
                };
            let chunk_data = &recv_buf[meta_consumed..];

            // First chunk: create assembler in registry.
            if chunk_idx == 0 {
                let chunk_size = if total_chunks > 1 {
                    chunk_data.len()
                } else {
                    total_size as usize
                };
                if let Err(e) =
                    chunk_registry.insert(conn_id, rid as u64, total_chunks as usize, chunk_size)
                {
                    eprintln!("Warning: reply chunk assembler creation failed: {e}");
                    let tx = pending.lock().remove(&rid);
                    if let Some(tx) = tx {
                        let _ = tx.send(Err(IpcError::Handshake(format!(
                            "chunked reply assembler failed: {e}"
                        ))));
                    }
                    continue;
                }
            }

            // Feed chunk via registry.
            match chunk_registry.feed(conn_id, rid as u64, chunk_idx as usize, chunk_data) {
                Ok(complete) => {
                    if complete {
                        match chunk_registry.finish(conn_id, rid as u64) {
                            Ok(finished) => {
                                let tx = pending.lock().remove(&rid);
                                if let Some(tx) = tx {
                                    let _ = tx.send(Ok(ResponseData::Handle(finished.handle)));
                                }
                            }
                            Err(e) => {
                                let tx = pending.lock().remove(&rid);
                                if let Some(tx) = tx {
                                    let _ = tx.send(Err(IpcError::Handshake(format!(
                                        "chunked reply finish error: {e}"
                                    ))));
                                }
                            }
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Warning: reply chunk feed error: {e}");
                    let tx = pending.lock().remove(&rid);
                    if let Some(tx) = tx {
                        let _ = tx.send(Err(IpcError::Handshake(format!(
                            "chunked reply feed error: {e}"
                        ))));
                    }
                }
            }
            continue; // Don't fall through to decode_response.
        }

        // Decode non-chunked response.
        let result = decode_response(&hdr, &recv_buf);

        // Dispatch to pending caller.
        let tx = { pending.lock().remove(&rid) };
        if let Some(tx) = tx {
            let _ = tx.send(result);
        }
    }

    // Connection lost — cleanup all in-flight assemblies for this connection.
    chunk_registry.cleanup_connection(conn_id);

    // Connection lost — wake all pending callers.
    let mut pending_guard = pending.lock();
    for (_, tx) in pending_guard.drain() {
        let _ = tx.send(Err(IpcError::Closed));
    }
}

fn decode_response(hdr: &FrameHeader, payload: &[u8]) -> Result<ResponseData, IpcError> {
    let is_v2 = hdr.is_reply_v2();
    let is_buddy = hdr.is_buddy();

    if !is_v2 {
        return Ok(ResponseData::Inline(payload.to_vec()));
    }

    if is_buddy {
        if payload.len() < BUDDY_PAYLOAD_SIZE + 1 {
            return Err(IpcError::Decode(DecodeError::BufferTooShort {
                need: BUDDY_PAYLOAD_SIZE + 1,
                have: payload.len(),
            }));
        }
        let (bp, _) = decode_buddy_payload(payload)?;
        let ctrl_start = BUDDY_PAYLOAD_SIZE;
        let (ctrl, _) = decode_reply_control(payload, ctrl_start)?;

        match ctrl {
            ReplyControl::Success => Ok(ResponseData::Shm {
                seg_idx: bp.seg_idx,
                offset: bp.offset,
                data_size: bp.data_size,
                is_dedicated: bp.is_dedicated,
            }),
            ReplyControl::RouteNotFound(route) => Err(IpcError::RouteNotFound(route)),
            ReplyControl::Error(err_data) => Err(IpcError::CrmError(err_data)),
        }
    } else {
        let (ctrl, consumed) = decode_reply_control(payload, 0)?;
        match ctrl {
            ReplyControl::Success => Ok(ResponseData::Inline(payload[consumed..].to_vec())),
            ReplyControl::RouteNotFound(route) => Err(IpcError::RouteNotFound(route)),
            ReplyControl::Error(err_data) => Err(IpcError::CrmError(err_data)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reassembly_pool_unique_prefixes() {
        let cfg = ClientIpcConfig::default();
        let r1 = IpcClient::make_chunk_registry(&cfg);
        let r2 = IpcClient::make_chunk_registry(&cfg);
        let r3 = IpcClient::make_chunk_registry(&cfg);
        let prefix1 = r1.pool().read().prefix().to_string();
        let prefix2 = r2.pool().read().prefix().to_string();
        let prefix3 = r3.pool().read().prefix().to_string();
        assert_ne!(prefix1, prefix2);
        assert_ne!(prefix2, prefix3);
        assert_ne!(prefix1, prefix3);
        assert!(prefix1.starts_with("/cc3a"), "unexpected prefix: {prefix1}");
        assert!(
            prefix1.len() <= 24,
            "prefix exceeds SHM name limit: {}",
            prefix1.len()
        );
    }

    #[test]
    fn client_projects_server_identity() {
        let identity = c2_wire::handshake::ServerIdentity {
            server_id: "identity-server".to_string(),
            server_instance_id: "identity-instance".to_string(),
        };
        let mut client = IpcClient::new("ipc://identity_projection");
        client.server_identity = Some(identity.clone());

        assert_eq!(client.server_identity(), Some(&identity));
        assert_eq!(client.server_id(), Some("identity-server"));
        assert_eq!(client.server_instance_id(), Some("identity-instance"));
    }

    #[test]
    fn client_validates_route_crm_contract_from_handshake_metadata() {
        let mut client = IpcClient::new("ipc://contract_projection");
        let mut methods = HashMap::new();
        methods.insert("ping".to_string(), 0);
        client.route_tables.insert(
            "grid".to_string(),
            MethodTable {
                crm_ns: "test.grid".to_string(),
                crm_name: "Grid".to_string(),
                crm_ver: "0.1.0".to_string(),
                name_to_idx: methods,
            },
        );

        client
            .validate_route_contract("grid", "test.grid", "Grid", "0.1.0")
            .expect("matching CRM contract should be accepted");

        let err = client
            .validate_route_contract("grid", "test.grid", "OtherGrid", "0.1.0")
            .expect_err("mismatched CRM name should be rejected");
        assert!(
            err.to_string().contains("CRM contract mismatch"),
            "unexpected error: {err}"
        );
    }

    #[tokio::test]
    async fn client_rejects_path_like_ipc_region_before_connecting() {
        for address in [
            "ipc://../escape",
            "ipc://bad/name",
            "ipc://bad\\name",
            "ipc://.",
            "ipc://..",
            "ipc:// leading",
            "ipc://trailing ",
            "ipc://bad\nname",
            "tcp://not-ipc",
        ] {
            let mut client = IpcClient::new(address);
            let error = client
                .connect()
                .await
                .expect_err("invalid IPC address should not attempt UDS connect");
            assert!(
                matches!(error, IpcError::Config(_)),
                "expected config error for {address:?}, got {error:?}"
            );
        }
    }
}
