import os
import json
import asyncio
import subprocess
import shutil
import sqlite3
import edge_tts
import re
from pathlib import Path

# --- PHONETIC REPLACEMENT LOGIC ---
def _apply_phonetics(text, db_path):
    if not os.path.exists(db_path): return text
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT term, phonetic FROM terms")
        rows = cursor.fetchall()
        conn.close()
        rows.sort(key=lambda x: len(x[0]), reverse=True)
        for term, phonetic in rows:
            pattern = re.compile(re.escape(term), re.IGNORECASE)
            text = pattern.sub(phonetic, text)
    except: pass
    return text

def _get_audio_duration(file_path):
    cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    try: return float(result.stdout.strip())
    except: return 0.0

async def _text_to_speech(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz"):
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)

def synthesize_text(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz", db_path="glossary.db"):
    processed_text = _apply_phonetics(text, db_path)
    asyncio.run(_text_to_speech(processed_text, output_path, voice, rate, pitch))
    return output_path

def synthesize_transcript(transcript_path, output_file="final_dub.mp3", voice="tr-TR-AhmetNeural", db_path="glossary.db", verbose=False):
    if not os.path.exists(transcript_path): raise FileNotFoundError(f"Transcript not found: {transcript_path}")

    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    temp_dir = Path("temp_audio_segments")
    temp_dir.mkdir(exist_ok=True)
    concat_list_path = temp_dir / "concat.txt"
    
    current_time = 0.0
    if verbose: print(f"[*] Synthesis started for {len(transcript)} segments...")

    with open(concat_list_path, "w", encoding="utf-8") as concat_file:
        for i, entry in enumerate(transcript):
            text = entry['text']
            start_time = entry['start']
            
            # 1. Handle Gaps (Silence)
            gap = start_time - current_time
            if gap > 0.01: # Small threshold
                silence_file = temp_dir / f"silence_{i}.mp3"
                # Generate silence using ffmpeg lavfi
                subprocess.run([
                    "ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono", 
                    "-t", str(gap), str(silence_file)
                ], stderr=subprocess.DEVNULL)
                concat_file.write(f"file '{silence_file.absolute()}'\n")
                current_time += gap

            # 2. Synthesize Segment
            seg_path = temp_dir / f"seg_{i}.mp3"
            synthesize_text(text, str(seg_path), voice=voice, db_path=db_path)
            actual_duration = _get_audio_duration(seg_path)
            
            # 3. Dynamic Speed Adjustment (Limited to 1.5x as per original script)
            if i < len(transcript) - 1:
                next_start = transcript[i+1]['start']
            else:
                next_start = start_time + entry['duration']
            
            allowed_duration = next_start - start_time
            
            if actual_duration > allowed_duration and allowed_duration > 0:
                speed_factor = actual_duration / allowed_duration
                # Cap speed factor at 1.5x (+50%) for quality
                speed_factor = min(speed_factor, 1.5)
                rate_pct = int((speed_factor - 1.0) * 100)
                if rate_pct > 0:
                    rate_str = f"+{rate_pct}%"
                    if verbose: print(f"    [!] Segment {i} sync: {rate_str} ({actual_duration:.2f}s -> {allowed_duration:.2f}s)")
                    synthesize_text(text, str(seg_path), voice=voice, rate=rate_str, db_path=db_path)
                    actual_duration = _get_audio_duration(seg_path)

            concat_file.write(f"file '{seg_path.absolute()}'\n")
            current_time += actual_duration
            if verbose: print(f"    [+] Segment {i} added at {start_time:.2f}s")

    # Final Concat
    if verbose: print(f"[*] Concatenating segments into {output_file}...")
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list_path), 
        "-c", "copy", output_file
    ], stderr=subprocess.DEVNULL)

    # Cleanup
    shutil.rmtree(temp_dir)
    return output_file
