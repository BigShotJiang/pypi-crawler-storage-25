import os
import subprocess
import shutil

def merge_audio_video(video_path, dubbed_audio_path, output_path=None, bg_volume=0.15, verbose=False):
    """
    Module 4: Assembly (Merger)
    Merges original video with dubbed audio while keeping background music at a lower volume.
    
    Args:
        video_path (str): Path to original MP4 video.
        dubbed_audio_path (str): Path to the generated Turkish audio (MP3/WAV).
        output_path (str): Final video path. If None, appends '_tr.mp4'.
        bg_volume (float): Original audio volume (0.0 to 1.0). Default 0.15 (15%).
        verbose (bool): If True, shows FFmpeg output.
    """
    if not os.path.exists(video_path):
        raise FileNotFoundError(f"Original video not found: {video_path}")
    if not os.path.exists(dubbed_audio_path):
        raise FileNotFoundError(f"Dubbed audio not found: {dubbed_audio_path}")

    if output_path is None:
        base, ext = os.path.splitext(video_path)
        output_path = f"{base}_tr{ext}"

    if verbose: print(f"[*] Merging started. Final output will be: {output_path}")

    # FFmpeg Magic Command:
    # 1. Take original video (0)
    # 2. Take dubbed audio (1)
    # 3. Filter: Reduce volume of original audio, mix it with dubbed audio
    # 4. Map: Video from original, mixed audio to output
    
    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-i", dubbed_audio_path,
        "-filter_complex", f"[0:a]volume={bg_volume}[bg];[1:a]volume=1.0[dub];[bg][dub]amix=inputs=2:duration=first[outa]",
        "-map", "0:v:0",
        "-map", "[outa]",
        "-c:v", "copy",       # Keep original video quality (no re-encoding)
        "-c:a", "aac",        # Standard audio codec
        "-strict", "experimental",
        output_path
    ]

    try:
        # Run subprocess. Using PIPE to suppress output unless verbose is on
        result = subprocess.run(cmd, capture_output=not verbose, check=True)
        if verbose: print(f"[+] Merging complete: {output_path}")
    except subprocess.CalledProcessError as e:
        error_log = e.stderr.decode() if e.stderr else "Unknown FFmpeg error"
        print(f"[!] FFmpeg Merge Error: {error_log}")
        raise e

    return output_path
