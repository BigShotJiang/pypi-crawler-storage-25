import os
import json
import sqlite3
import httpx
import re
import shutil
import threading
import time
from pathlib import Path
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed

load_dotenv()
db_lock = threading.Lock()

# --- THE BLOCK-WISE PROMPT ---
DEFAULT_PROMPT = """ROLÜN: Profesyonel bir dublaj senaristi ve çevirmenisin.
VİDEO URL: {video_url}

GÖREVİN: Aşağıdaki mantıksal blokları Türkçe'ye çevir. Her blok için verilen MAX_CHARS sınırına KESİNLİKLE uy.

STRATEJİ:
1. BREVITY: Metni %20-30 oranında kısalt. Türkçe ekleri kullan (Gidince, Yapmalısın).
2. CONTEXT: Bu metinler seslendirilecek. Akıcı ve doğal bir konuşma dili kullan.
3. NO OVERFLOW: Belirtilen `max_chars` sınırını aşarsan ses videoya sığmaz. Sınırı geçme.

ÇIKTI FORMATI:
{{
  "segments": [
    {{
      "block_id": 0,
      "text": "Türkçe çeviri"
    }}
  ],
  "new_terms": {{"Term": "Okunuş"}}
}}

GİRDİ:
{json_data}"""

class Translator:
    def __init__(self, db_path="glossary.db"):
        self.user_db_path = db_path
        self._initialize_db()

    def _initialize_db(self):
        with db_lock:
            if not os.path.exists(self.user_db_path):
                pkg_db = Path(__file__).parent / "data" / "default_glossary.db"
                if pkg_db.exists(): shutil.copy(pkg_db, self.user_db_path)
                else: self._create_empty_db_raw()

    def _create_empty_db_raw(self):
        conn = sqlite3.connect(self.user_db_path)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS terms (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT UNIQUE NOT NULL, phonetic TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
        c.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)", ("system_prompt", DEFAULT_PROMPT))
        conn.commit()
        conn.close()

    def get_terms(self):
        with db_lock:
            conn = sqlite3.connect(self.user_db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT term FROM terms")
            terms = [row[0] for row in cursor.fetchall()]
            conn.close()
            return terms

    def add_new_terms(self, new_terms):
        with db_lock:
            conn = sqlite3.connect(self.user_db_path)
            cursor = conn.cursor()
            added = 0
            for term, phonetic in new_terms.items():
                try:
                    cursor.execute("INSERT INTO terms (term, phonetic) VALUES (?, ?)", (term, phonetic))
                    added += 1
                except: pass
            conn.commit()
            conn.close()
            return added

    def get_prompt(self):
        try:
            with db_lock:
                conn = sqlite3.connect(self.user_db_path)
                cursor = conn.cursor()
                cursor.execute("SELECT value FROM metadata WHERE key = 'system_prompt'")
                row = cursor.fetchone()
                conn.close()
                return row[0] if row else DEFAULT_PROMPT
        except:
            return DEFAULT_PROMPT

    def call_gemini(self, api_key, prompt, model="gemini-2.5-flash"):
        url = f"https://generativelanguage.googleapis.com/v1/models/{model.split('/')[-1]}:generateContent?key={api_key}"
        payload = {"contents": [{"parts": [{"text": prompt}]}]}
        for _ in range(3):
            try:
                with httpx.Client(timeout=120.0) as client:
                    res = client.post(url, json=payload)
                    res.raise_for_status()
                    raw = res.json()['candidates'][0]['content']['parts'][0]['text']
                    match = re.search(r'\{.*\}', raw, re.DOTALL)
                    return json.loads(match.group()) if match else json.loads(raw)
            except: time.sleep(5)
        raise Exception("API Error")

def translate_transcript(transcript_path, api_key=None, model="gemini-2.5-flash", db_path="glossary.db", verbose=False):
    if not api_key: api_key = os.getenv("GEMINI_API_KEY")
    if not api_key: api_key = input("API Key: ").strip()
    
    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    # --- LOGICAL PRE-MERGING ---
    logical_blocks = []
    current_block = {"ids": [], "text": "", "start": 0.0, "duration": 0.0}
    
    for i, item in enumerate(transcript):
        if not current_block["ids"]:
            current_block["start"] = item["start"]
        
        current_block["ids"].append(i)
        current_block["text"] += " " + item["text"]
        
        # Check if we should end the block
        ends_with_punc = item["text"].strip().endswith((".", "?", "!"))
        duration_so_far = item["start"] + item["duration"] - current_block["start"]
        
        if ends_with_punc or duration_so_far > 7.0 or i == len(transcript) - 1:
            # Seal the block
            next_start = transcript[i+1]["start"] if i < len(transcript) - 1 else item["start"] + item["duration"]
            real_gap = next_start - current_block["start"]
            current_block["duration"] = real_gap
            current_block["text"] = current_block["text"].strip()
            logical_blocks.append(current_block)
            current_block = {"ids": [], "text": "", "start": 0.0, "duration": 0.0}

    translator = Translator(db_path)
    chunk_size = 8 # Blocks per AI call

    def process_pass():
        glossary = translator.get_terms()
        pass_found_new = False
        chunks = [(i, logical_blocks[i:i + chunk_size]) for i in range(0, len(logical_blocks), chunk_size)]
        results = {}

        def process_chunk(data):
            idx, chunk = data
            input_list = []
            for j, block in enumerate(chunk):
                # Target CPS = 10
                max_chars = int(max(10, block["duration"] * 10))
                input_list.append({
                    "block_id": idx + j,
                    "english": block["text"],
                    "max_chars": max_chars,
                    "duration_sec": round(block["duration"], 2)
                })

            prompt = translator.get_prompt().replace("{json_data}", json.dumps(input_list, ensure_ascii=False))
            prompt = prompt.replace("{glossary}", ", ".join(glossary))
            prompt = prompt.replace("{video_url}", "YouTube")
            
            return idx, translator.call_gemini(api_key, prompt, model)

        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {executor.submit(process_chunk, c): c for c in chunks}
            for f in as_completed(futures):
                idx, res = f.result()
                if res.get("new_terms"):
                    if translator.add_new_terms(res["new_terms"]) > 0: pass_found_new = True
                results[idx] = res.get("segments", [])

        combined = []
        for i in sorted(results.keys()): combined.extend(results[i])
        return combined, pass_found_new

    if verbose: print(f"[*] Translating {len(logical_blocks)} logical blocks...")
    final_raw, _ = process_pass()
    
    # Map results back
    raw_dict = {}
    for seg in final_raw:
        try:
            b_id = int(seg.get("block_id"))
            raw_dict[b_id] = seg.get("text")
        except: continue

    final_transcript = []
    for i, block in enumerate(logical_blocks):
        txt = raw_dict.get(i)
        if not txt: continue
        final_transcript.append({
            "start": block["start"],
            "duration": block["duration"],
            "text": txt
        })
    
    out = transcript_path.replace(".json", "_tr.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(final_transcript, f, ensure_ascii=False, indent=2)
    
    if verbose: print(f"[+] Logical Blocks Processed: {len(final_transcript)}")
    return final_transcript
