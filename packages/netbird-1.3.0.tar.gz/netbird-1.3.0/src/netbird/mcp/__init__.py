"""NetBird MCP server."""
