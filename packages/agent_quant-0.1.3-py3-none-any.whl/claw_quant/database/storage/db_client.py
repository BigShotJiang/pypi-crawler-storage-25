"""
DuckDB 数据库客户端

通过TCP连接 db_service，提供与 DuckDBManager 完全相同的接口。
所有脚本都用这个客户端来访问数据库，避免DuckDB锁冲突。

使用方式（与 DuckDBManager 完全相同）：
    # 以前：
    # from database import DuckDBManager
    # db = DuckDBManager('data/quant_system.db')
    
    # 现在：
    from database.db_client import DBClient
    db = DBClient()  # 自动连接本地服务
    
    # 接口完全相同
    df = db.get_market_data_daily('000001.SZ', start_date, end_date)
    db.save_market_data_daily(df)
"""

import socket
import struct
import pickle
import logging
import time
from datetime import date
from typing import Optional, List, Dict, Any

import pandas as pd

logger = logging.getLogger(__name__)

# 与 db_service 保持一致
DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9528
HEADER_SIZE = 4
MAX_MSG_SIZE = 256 * 1024 * 1024


def _send_message(sock: socket.socket, data):
    """发送一条消息"""
    payload = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
    header = struct.pack('>I', len(payload))
    sock.sendall(header + payload)


def _recv_exact(sock: socket.socket, n: int) -> Optional[bytes]:
    """精确读取n字节"""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 65536))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


def _recv_message(sock: socket.socket):
    """接收一条消息"""
    header = _recv_exact(sock, HEADER_SIZE)
    if header is None:
        raise ConnectionError("服务端断开连接")
    msg_len = struct.unpack('>I', header)[0]
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    payload = _recv_exact(sock, msg_len)
    if payload is None:
        raise ConnectionError("服务端断开连接")
    return pickle.loads(payload)


class DBClient:
    """
    数据库客户端 - 与 DuckDBManager 接口一致
    
    通过TCP连接 db_service 来执行数据库操作。
    支持自动重连和连接复用。
    """

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
                 timeout: float = 30.0, max_retries: int = 3):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.max_retries = max_retries
        self._sock: Optional[socket.socket] = None
        self._connect()

    def _connect(self):
        """建立TCP连接"""
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(self.timeout)
        self._sock.connect((self.host, self.port))
        logger.debug(f"已连接数据库服务: {self.host}:{self.port}")

    def _call(self, method_name: str, *args, **kwargs):
        """调用远程方法（带自动重连）"""
        last_error = None
        for attempt in range(self.max_retries):
            try:
                if self._sock is None:
                    self._connect()

                request = (method_name, args, kwargs)
                _send_message(self._sock, request)
                response = _recv_message(self._sock)

                if response['ok']:
                    return response['result']
                else:
                    raise RuntimeError(f"数据库操作失败: {response['error']}")

            except (ConnectionError, BrokenPipeError, OSError) as e:
                last_error = e
                logger.warning(f"连接异常 (尝试 {attempt + 1}/{self.max_retries}): {e}")
                self._sock = None
                if attempt < self.max_retries - 1:
                    time.sleep(0.5)

        raise ConnectionError(f"数据库服务连接失败 (已重试{self.max_retries}次): {last_error}")

    def close(self):
        """关闭连接"""
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None

    def ping(self) -> bool:
        """检查服务是否可用"""
        try:
            result = self._call('__ping__')
            return result == 'pong'
        except Exception:
            return False

    # ============================================
    # 以下方法与 DuckDBManager 完全一致
    # ============================================

    def save_stocks(self, df: pd.DataFrame):
        """保存股票基础信息"""
        return self._call('save_stocks', df)

    def get_all_stocks(self) -> pd.DataFrame:
        """获取所有活跃股票"""
        return self._call('get_all_stocks')

    def get_stock_info(self, code: str) -> Optional[Dict]:
        """获取单只股票信息"""
        return self._call('get_stock_info', code)

    def save_market_data_daily(self, df: pd.DataFrame):
        """保存日线数据"""
        return self._call('save_market_data_daily', df)

    def get_market_data_daily(self, code: str, start_date: date,
                              end_date: date) -> pd.DataFrame:
        """获取日线数据"""
        return self._call('get_market_data_daily', code, start_date, end_date)

    def get_market_data_daily_multi(self, codes: List[str], start_date: date,
                                    end_date: date) -> pd.DataFrame:
        """获取多只股票日线数据"""
        return self._call('get_market_data_daily_multi', codes, start_date, end_date)

    def get_latest_trade_date(self) -> Optional[date]:
        """获取最新交易日期"""
        return self._call('get_latest_trade_date')

    def save_realtime_quotes(self, df: pd.DataFrame):
        """保存实时行情快照"""
        return self._call('save_realtime_quotes', df)

    def get_realtime_quotes(self, codes: Optional[List[str]] = None) -> pd.DataFrame:
        """获取实时行情"""
        return self._call('get_realtime_quotes', codes)

    def save_news(self, news_list: List[Dict]):
        """保存新闻"""
        return self._call('save_news', news_list)

    def get_unprocessed_news(self, limit: int = 100) -> pd.DataFrame:
        """获取未处理的新闻"""
        return self._call('get_unprocessed_news', limit)

    def mark_news_processed(self, news_ids: List[int]):
        """标记新闻已处理"""
        return self._call('mark_news_processed', news_ids)

    def get_news_by_code(self, code: str, days: int = 30) -> pd.DataFrame:
        """获取某只股票近期新闻"""
        return self._call('get_news_by_code', code, days)

    def save_factor_values(self, df: pd.DataFrame):
        """保存因子值"""
        return self._call('save_factor_values', df)

    def get_factor_values(self, factor_codes: List[str], calc_date: date,
                          codes: Optional[List[str]] = None) -> pd.DataFrame:
        """获取因子值"""
        return self._call('get_factor_values', factor_codes, calc_date, codes)

    def get_factor_values_range(self, factor_code: str, code: str,
                                start_date: date, end_date: date) -> pd.DataFrame:
        """获取因子历史值"""
        return self._call('get_factor_values_range', factor_code, code, start_date, end_date)

    def save_factor_definition(self, factor: Dict):
        """保存因子定义"""
        return self._call('save_factor_definition', factor)

    def get_factor_definitions(self, category: Optional[str] = None) -> pd.DataFrame:
        """获取因子定义"""
        return self._call('get_factor_definitions', category)

    def save_strategy_signal(self, signal: Dict):
        """保存策略信号"""
        return self._call('save_strategy_signal', signal)

    def get_unexecuted_signals(self, strategy_code: Optional[str] = None) -> pd.DataFrame:
        """获取未执行信号"""
        return self._call('get_unexecuted_signals', strategy_code)

    def mark_signal_executed(self, signal_id: int):
        """标记信号已执行"""
        return self._call('mark_signal_executed', signal_id)

    def save_stock_scores(self, df: pd.DataFrame):
        """保存股票评分"""
        return self._call('save_stock_scores', df)

    def get_stock_scores(self, calc_date: date,
                         min_score: Optional[float] = None) -> pd.DataFrame:
        """获取股票评分"""
        return self._call('get_stock_scores', calc_date, min_score)

    def set_config(self, key: str, value: str, description: str = ""):
        """设置配置"""
        return self._call('set_config', key, value, description)

    def get_config(self, key: str, default: str = "") -> str:
        """获取配置"""
        return self._call('get_config', key, default)

    def log_data_update(self, data_type: str, records_count: int,
                        status: str, message: str = "", duration_ms: int = 0):
        """记录数据更新日志"""
        return self._call('log_data_update', data_type, records_count, status, message, duration_ms)

    def execute_query(self, query: str, params: Optional[List] = None) -> pd.DataFrame:
        """执行自定义查询"""
        return self._call('execute_query', query, params)

    def get_table_info(self, table_name: str) -> pd.DataFrame:
        """获取表信息"""
        return self._call('get_table_info', table_name)

    def get_all_tables(self) -> List[str]:
        """获取所有表名"""
        return self._call('get_all_tables')

    def get_table_count(self, table_name: str) -> int:
        """获取表记录数"""
        return self._call('get_table_count', table_name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
