"""
DuckDB HTTP API 服务器

提供RESTful API访问DuckDB数据库，解决并发访问问题
所有数据库操作通过队列串行化处理

启动: python -m claw_quant.database.db_api_server
访问: http://127.0.0.1:9529
"""
import os
import sys
import json
import logging
import queue
import threading
import time
from datetime import date, datetime
from typing import Any, Optional
from functools import wraps

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 尝试导入Flask
try:
    from flask import Flask, request, jsonify
except ImportError:
    print("Flask not installed, installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "-q"])
    from flask import Flask, request, jsonify

import pandas as pd
from claw_quant.database.storage.db_manager import DuckDBManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('db_api_server')

app = Flask(__name__)

# 配置Flask日志输出到控制台
import logging as flask_logging
werkzeug_logger = flask_logging.getLogger('werkzeug')
werkzeug_logger.setLevel(flask_logging.INFO)

# 添加请求日志
@app.before_request
def log_request():
    """记录每个请求"""
    logger.info(f"[{request.method}] {request.path} - {request.remote_addr}")

# 全局队列和工作线程
request_queue = queue.Queue()
db_worker_thread = None
db_manager = None


class DBRequest:
    """数据库请求对象"""
    def __init__(self, method: str, args: tuple = (), kwargs: dict = None):
        self.method = method
        self.args = args
        self.kwargs = kwargs or {}
        self.response_queue = queue.Queue(maxsize=1)
        self.timestamp = time.time()


def db_worker(db_path: str):
    """数据库工作线程 - 单线程串行处理所有请求"""
    global db_manager
    
    logger.info(f"数据库工作线程启动: {db_path}")
    try:
        db_manager = DuckDBManager(db_path)
        logger.info("数据库连接成功")
    except Exception as e:
        logger.error(f"数据库连接失败: {e}")
        return
    
    while True:
        try:
            req = request_queue.get(timeout=1)
        except queue.Empty:
            continue
        
        # 检查是否是停止信号
        if req.method == '__stop__':
            logger.info("收到停止信号")
            break
        
        try:
            result = execute_db_operation(req.method, req.args, req.kwargs)
            req.response_queue.put({'success': True, 'data': result})
        except Exception as e:
            logger.error(f"执行 {req.method} 失败: {e}")
            req.response_queue.put({'success': False, 'error': str(e)})
    
    # 关闭数据库
    if db_manager:
        db_manager.close()
        logger.info("数据库连接已关闭")


def execute_db_operation(method: str, args: tuple, kwargs: dict) -> Any:
    """执行数据库操作"""
    if method == '__ping__':
        return 'pong'
    
    if not hasattr(db_manager, method):
        raise AttributeError(f"方法不存在: {method}")
    
    if method.startswith('_'):
        raise PermissionError(f"不允许调用私有方法: {method}")
    
    # 特殊处理：大数据保存分批
    if method == 'save_market_data_daily' and args:
        df = args[0]
        if len(df) > 500:
            return save_large_data(df)
    
    method_obj = getattr(db_manager, method)
    return method_obj(*args, **kwargs)


def save_large_data(df: pd.DataFrame) -> dict:
    """分批保存大数据"""
    batch_size = 500
    total = len(df)
    saved = 0
    
    for i in range(0, total, batch_size):
        batch = df.iloc[i:i+batch_size]
        db_manager.save_market_data_daily(batch)
        saved += len(batch)
        logger.debug(f"分批保存: {saved}/{total}")
    
    logger.info(f"大数据分批保存完成: {total} 条")
    return {'saved': total}


def call_db_method(method: str, *args, **kwargs) -> Any:
    """调用数据库方法（通过队列）"""
    req = DBRequest(method, args, kwargs)
    request_queue.put(req)
    
    # 等待响应（带超时）
    try:
        response = req.response_queue.get(timeout=120)
        if response['success']:
            return response['data']
        else:
            raise RuntimeError(response['error'])
    except queue.Empty:
        raise TimeoutError("数据库操作超时")


# ==================== API路由 ====================

@app.route('/ping', methods=['GET'])
def ping():
    """健康检查"""
    try:
        result = call_db_method('__ping__')
        return jsonify({'success': True, 'data': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/stocks', methods=['GET'])
def get_stocks():
    """获取股票列表"""
    try:
        df = call_db_method('get_all_stocks')
        
        # 处理NaT日期，转换为字符串或None
        if not df.empty:
            for col in df.columns:
                if 'date' in col.lower() or 'time' in col.lower():
                    df[col] = df[col].apply(lambda x: x.isoformat() if pd.notna(x) else None)
        
        return jsonify({
            'success': True,
            'data': df.to_dict('records') if not df.empty else [],
            'count': len(df)
        })
    except Exception as e:
        logger.error(f"获取股票列表失败: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/stocks', methods=['POST'])
def save_stocks():
    """保存股票列表"""
    try:
        data = request.get_json()
        df = pd.DataFrame(data)
        call_db_method('save_stocks', df)
        return jsonify({'success': True, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/market_data/daily', methods=['GET'])
def get_market_data():
    """获取日线数据"""
    try:
        code = request.args.get('code')
        codes = request.args.getlist('codes')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'success': False, 'error': '缺少start_date或end_date'}), 400
        
        # 解析日期
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        if codes:
            # 多只股票
            df = call_db_method('get_market_data_daily_multi', codes, start, end)
        elif code:
            # 单只股票
            df = call_db_method('get_market_data_daily', code, start, end)
        else:
            return jsonify({'success': False, 'error': '缺少code或codes参数'}), 400
        
        # DataFrame转JSON
        data = df.to_dict('records') if not df.empty else []
        # 日期格式转换
        for item in data:
            if 'trade_date' in item and isinstance(item['trade_date'], date):
                item['trade_date'] = item['trade_date'].isoformat()
        
        return jsonify({
            'success': True,
            'data': data,
            'count': len(data)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/market_data/daily', methods=['POST'])
def save_market_data():
    """保存日线数据"""
    try:
        data = request.get_json()
        df = pd.DataFrame(data)
        
        # 转换日期格式
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
        
        result = call_db_method('save_market_data_daily', df)
        return jsonify({
            'success': True,
            'message': '保存成功',
            'result': result
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/market_data/latest_date', methods=['GET'])
def get_latest_date():
    """获取最新交易日期"""
    try:
        result = call_db_method('get_latest_trade_date')
        return jsonify({
            'success': True,
            'data': result.isoformat() if result else None
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/factors', methods=['GET'])
def get_factors():
    """获取因子列表"""
    try:
        names = call_db_method('get_factor_names')
        return jsonify({'success': True, 'data': names})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/factors/<factor_name>', methods=['GET'])
def get_factor_data(factor_name: str):
    """获取因子数据"""
    try:
        trade_date = request.args.get('date')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if trade_date:
            # 单日数据
            d = datetime.strptime(trade_date, '%Y-%m-%d').date()
            df = call_db_method('get_factor_data', factor_name, d)
        elif start_date and end_date:
            # 时间序列
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            df = call_db_method('get_factor_data_multi', factor_name, start, end)
        else:
            return jsonify({'success': False, 'error': '缺少date或start_date/end_date'}), 400
        
        data = df.to_dict('records') if not df.empty else []
        for item in data:
            if 'trade_date' in item and isinstance(item['trade_date'], date):
                item['trade_date'] = item['trade_date'].isoformat()
        
        return jsonify({
            'success': True,
            'data': data,
            'count': len(data)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/factors/<factor_name>', methods=['POST'])
def save_factor_data(factor_name: str):
    """保存因子数据"""
    try:
        data = request.get_json()
        df = pd.DataFrame(data)
        
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
        
        call_db_method('save_factor_data', df)
        return jsonify({'success': True, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


def get_default_db_path():
    """Get default database path in system cache directory"""
    import platform
    
    system = platform.system()
    if system == 'Windows':
        base_dir = os.path.expandvars(r'%LOCALAPPDATA%\claw_quant')
    elif system == 'Darwin':  # macOS
        base_dir = os.path.expanduser('~/Library/Caches/claw_quant')
    else:  # Linux and others
        base_dir = os.path.expanduser('~/.cache/claw_quant')
    
    # Ensure directory exists
    os.makedirs(base_dir, exist_ok=True)
    return os.path.join(base_dir, 'quant_system.db')


def main():
    """Main function"""
    import argparse
    parser = argparse.ArgumentParser(description='DuckDB HTTP API Server')
    parser.add_argument('--db-path', type=str, default=get_default_db_path(),
                        help='Database file path (default: system cache directory)')
    parser.add_argument('--host', type=str, default='127.0.0.1')
    parser.add_argument('--port', type=int, default=9529)
    args = parser.parse_args()
    
    # 启动数据库工作线程
    global db_worker_thread
    db_worker_thread = threading.Thread(target=db_worker, args=(args.db_path,), daemon=True)
    db_worker_thread.start()
    
    # 等待数据库连接就绪
    logger.info("等待数据库连接就绪...")
    time.sleep(2)
    
    logger.info(f"=" * 60)
    logger.info(f"DuckDB HTTP API Server")
    logger.info(f"=" * 60)
    logger.info(f"数据库: {args.db_path}")
    logger.info(f"地址: http://{args.host}:{args.port}")
    logger.info(f"=" * 60)
    
    # 启动Flask服务器
    app.run(host=args.host, port=args.port, threaded=True)


if __name__ == '__main__':
    main()
