#!/bin/bash

# DuckDB HTTP API Server Startup Script
# Supports Linux and macOS

# Parse arguments
RUN_BG=0
USE_SYSTEM_PY=0
JSON_OUTPUT=0
DB_PATH=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --bg|--background)
            RUN_BG=1
            shift
            ;;
        --system)
            USE_SYSTEM_PY=1
            shift
            ;;
        --json)
            JSON_OUTPUT=1
            shift
            ;;
        --db-path)
            DB_PATH="$2"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

# Set Python path
if [ $USE_SYSTEM_PY -eq 1 ]; then
    PYTHON_PATH="/usr/local/bin/python3"
else
    PYTHON_PATH="python3"
fi

# Check Python
if ! command -v "$PYTHON_PATH" &> /dev/null; then
    if [ $JSON_OUTPUT -eq 1 ]; then
        echo '{"success": false, "message": "Python not found. Please install Python 3.10+ or use --system flag", "running": false}'
    else
        echo "[ERROR] Python not found!"
        echo "Please check:"
        echo "1. Python is installed"
        echo "2. Python is in system PATH"
        echo "3. Or use --system flag"
    fi
    exit 1
fi

# Check if server already running
if "$PYTHON_PATH" -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',9529)); s.close(); exit(0 if r==0 else 1)" 2>/dev/null; then
    if [ $JSON_OUTPUT -eq 1 ]; then
        echo '{"success": true, "message": "Server is already running", "running": true, "address": "http://127.0.0.1:9529"}'
    else
        echo "[INFO] Server is already running!"
        echo ""
        echo "Address: http://127.0.0.1:9529"
        if [ $RUN_BG -eq 0 ]; then
            read -p "Press Enter to exit..."
        fi
    fi
    exit 0
fi

# Set working directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Build db-path argument
if [ -z "$DB_PATH" ]; then
    DB_PATH_ARG=""
else
    DB_PATH_ARG="--db-path \"$DB_PATH\""
fi

if [ $RUN_BG -eq 1 ]; then
    # Start in background
    if [ -z "$DB_PATH" ]; then
        nohup "$PYTHON_PATH" -B -m claw_quant.database.storage.db_server > /tmp/db_server.log 2>&1 &
    else
        nohup "$PYTHON_PATH" -B -m claw_quant.database.storage.db_server --db-path "$DB_PATH" > /tmp/db_server.log 2>&1 &
    fi
    PID=$!
    sleep 2
    
    # Check if started successfully
    if "$PYTHON_PATH" -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',9529)); s.close(); exit(0 if r==0 else 1)" 2>/dev/null; then
        if [ $JSON_OUTPUT -eq 1 ]; then
            echo "{\"success\": true, \"message\": \"Server started successfully in background\", \"running\": true, \"address\": \"http://127.0.0.1:9529\"}"
        else
            echo "[OK] Server started in background (PID: $PID)"
            echo "Address: http://127.0.0.1:9529"
        fi
        exit 0
    else
        if [ $JSON_OUTPUT -eq 1 ]; then
            echo '{"success": false, "message": "Failed to start server in background", "running": false}'
        else
            echo "[ERROR] Failed to start server!"
        fi
        exit 1
    fi
else
    # Start in foreground
    if [ $JSON_OUTPUT -eq 0 ]; then
        echo "=========================================="
        echo "Start DuckDB HTTP API Server"
        echo "=========================================="
        echo ""
        echo "Server Address: http://127.0.0.1:9529"
        echo ""
        echo "Press Ctrl+C to stop server"
        echo ""
    fi
    
    if [ -z "$DB_PATH" ]; then
        "$PYTHON_PATH" -B -m claw_quant.database.storage.db_server
    else
        "$PYTHON_PATH" -B -m claw_quant.database.storage.db_server --db-path "$DB_PATH"
    fi
    
    if [ $JSON_OUTPUT -eq 0 ]; then
        echo ""
        echo "[WARNING] Server stopped!"
    fi
fi
