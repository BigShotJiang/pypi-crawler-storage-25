# -*- coding: utf-8 -*-
"""
StockClaw CLI 命令行工具

提供命令行接口供Agent调用，封装所有对外API功能。

使用方法:
    # 更新数据
    python -m claw_quant.cli update --codes 000001.SZ --date 2026-04-20
    
    # 查询数据
    python -m claw_quant.cli query --code 000001.SZ --start 2026-04-17 --end 2026-04-20
    
    # 获取最新日期
    python -m claw_quant.cli latest
    
    # 获取股票列表
    python -m claw_quant.cli stocks
    
    # 回测
    python -m claw_quant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
    
    # 多引擎对比回测
    python -m claw_quant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --compare
"""

import argparse
import json
import sys
import io
import os
import subprocess
import signal
from datetime import date, datetime
from typing import Optional, Dict, Any, List

# 设置 stdout 编码为 UTF-8（解决 Windows 中文乱码）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from .database.api import StockAPI


def get_db_server_pid():
    """获取数据库服务器进程ID"""
    import glob
    pid_files = glob.glob(os.path.expanduser('~/.claw_quant/db_server_*.pid'))
    if pid_files:
        try:
            with open(pid_files[0], 'r') as f:
                return int(f.read().strip())
        except:
            pass
    return None


def save_db_server_pid(pid):
    """保存数据库服务器进程ID"""
    pid_dir = os.path.expanduser('~/.claw_quant')
    os.makedirs(pid_dir, exist_ok=True)
    pid_file = os.path.join(pid_dir, f'db_server_{pid}.pid')
    with open(pid_file, 'w') as f:
        f.write(str(pid))


def remove_db_server_pid():
    """删除数据库服务器进程ID文件"""
    import glob
    pid_files = glob.glob(os.path.expanduser('~/.claw_quant/db_server_*.pid'))
    for f in pid_files:
        try:
            os.remove(f)
        except:
            pass


def cmd_db_start(args) -> int:
    """启动数据库服务器命令"""
    # 检查是否已经在运行
    existing_pid = get_db_server_pid()
    if existing_pid:
        try:
            if sys.platform == 'win32':
                import ctypes
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.OpenProcess(1, False, existing_pid)
                if handle:
                    kernel32.CloseHandle(handle)
                    print(format_output({
                        'success': False,
                        'message': f'数据库服务器已在运行 (PID: {existing_pid})',
                        'pid': existing_pid,
                        'status': 'running'
                    }))
                    return 0
            else:
                os.kill(existing_pid, 0)
                print(format_output({
                    'success': False,
                    'message': f'数据库服务器已在运行 (PID: {existing_pid})',
                    'pid': existing_pid,
                    'status': 'running'
                }))
                return 0
        except:
            remove_db_server_pid()
    
    # 启动数据库服务器
    try:
        from .database.storage.db_server import get_default_db_path, create_app
        
        db_path = args.db_path or get_default_db_path()
        host = args.host
        port = args.port
        
        # 确保数据库目录存在
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        print(format_output({
            'success': True,
            'message': '正在启动数据库服务器...',
            'db_path': db_path,
            'host': host,
            'port': port,
            'status': 'starting'
        }))
        
        if args.background:
            # 后台启动
            if sys.platform == 'win32':
                # Windows 使用 subprocess.CREATE_NEW_CONSOLE
                proc = subprocess.Popen(
                    [sys.executable, '-c', 
                     f'from claw_quant.database.storage.db_server import main; main()',
                     '--db-path', db_path, '--host', host, '--port', str(port)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            else:
                # Linux/Mac 使用 nohup
                proc = subprocess.Popen(
                    [sys.executable, '-c',
                     f'from claw_quant.database.storage.db_server import main; main()',
                     '--db-path', db_path, '--host', host, '--port', str(port)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
            
            save_db_server_pid(proc.pid)
            print(format_output({
                'success': True,
                'message': f'数据库服务器已在后台启动 (PID: {proc.pid})',
                'pid': proc.pid,
                'db_path': db_path,
                'host': host,
                'port': port,
                'status': 'running'
            }))
            return 0
        else:
            # 前台启动
            from .database.storage.db_server import main as db_main
            import sys as sys_module
            # 模拟命令行参数
            original_argv = sys_module.argv
            sys_module.argv = ['db_server', '--db-path', db_path, '--host', host, '--port', str(port)]
            try:
                db_main()
            finally:
                sys_module.argv = original_argv
            return 0
            
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'启动数据库服务器失败: {str(e)}',
            'error': str(e),
            'status': 'failed'
        }))
        return 1


def cmd_db_stop(args) -> int:
    """停止数据库服务器命令"""
    pid = get_db_server_pid()
    
    if not pid:
        print(format_output({
            'success': False,
            'message': '未找到运行的数据库服务器',
            'status': 'not_running'
        }))
        return 1
    
    try:
        if sys.platform == 'win32':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(1, False, pid)
            if handle:
                kernel32.TerminateProcess(handle, 0)
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, signal.SIGTERM)
        
        remove_db_server_pid()
        
        print(format_output({
            'success': True,
            'message': f'数据库服务器已停止 (PID: {pid})',
            'pid': pid,
            'status': 'stopped'
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'停止数据库服务器失败: {str(e)}',
            'error': str(e),
            'status': 'error'
        }))
        return 1


def cmd_db_status(args) -> int:
    """检查数据库服务器状态命令"""
    pid = get_db_server_pid()
    
    if not pid:
        print(format_output({
            'success': True,
            'message': '数据库服务器未运行',
            'status': 'not_running',
            'pid': None
        }))
        return 0
    
    try:
        if sys.platform == 'win32':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(1, False, pid)
            if handle:
                kernel32.CloseHandle(handle)
                is_running = True
            else:
                is_running = False
        else:
            os.kill(pid, 0)
            is_running = True
        
        if is_running:
            print(format_output({
                'success': True,
                'message': f'数据库服务器正在运行 (PID: {pid})',
                'status': 'running',
                'pid': pid
            }))
            return 0
        else:
            remove_db_server_pid()
            print(format_output({
                'success': True,
                'message': '数据库服务器未运行',
                'status': 'not_running',
                'pid': None
            }))
            return 0
            
    except:
        remove_db_server_pid()
        print(format_output({
            'success': True,
            'message': '数据库服务器未运行',
            'status': 'not_running',
            'pid': None
        }))
        return 0


def parse_date(date_str: str) -> date:
    """解析日期字符串"""
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        raise argparse.ArgumentTypeError(f'无效的日期格式: {date_str}，请使用 YYYY-MM-DD 格式')


def format_output(data: dict) -> str:
    """格式化输出为JSON"""
    return json.dumps(data, ensure_ascii=False, indent=2)


def cmd_update(args) -> int:
    """更新数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'saved_count': 0,
            'requested_date': args.date.strftime('%Y-%m-%d') if args.date else None,
            'actual_date': None,
            'is_mapping': False
        }))
        return 1
    
    codes = args.codes.split(',') if args.codes else None
    target_date = args.date
    
    result = api.update_daily(codes=codes, target_date=target_date)
    print(format_output(result))
    return 0 if result['success'] else 1


def _convert_to_json_serializable(data: list) -> list:
    """将数据中的date对象转换为字符串"""
    result = []
    for item in data:
        new_item = {}
        for key, value in item.items():
            if isinstance(value, date):
                new_item[key] = value.strftime('%Y-%m-%d')
            else:
                new_item[key] = value
        result.append(new_item)
    return result


def cmd_query(args) -> int:
    """查询数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'data': []
        }))
        return 1
    
    try:
        if args.codes:
            # 批量查询
            codes = args.codes.split(',')
            df = api.get_daily_multi(codes, args.start, args.end)
        else:
            # 单只股票查询
            df = api.get_daily(args.code, args.start, args.end)
        
        # 转换为字典列表，并处理date对象
        raw_data = df.to_dict(orient='records') if not df.empty else []
        data = _convert_to_json_serializable(raw_data)
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(data)} 条记录',
            'count': len(data),
            'data': data
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'data': []
        }))
        return 1


def cmd_latest(args) -> int:
    """获取最新日期命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'latest_date': None
        }))
        return 1
    
    latest = api.get_latest_date()
    
    print(format_output({
        'success': True,
        'message': '查询成功',
        'latest_date': latest.strftime('%Y-%m-%d') if latest else None
    }))
    return 0


def cmd_stocks(args) -> int:
    """获取股票列表命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'count': 0,
            'stocks': []
        }))
        return 1
    
    try:
        df = api.get_all_stocks()
        raw_stocks = df.to_dict(orient='records') if not df.empty else []
        
        # 处理date对象
        stocks = _convert_to_json_serializable(raw_stocks)
        
        # 如果指定了limit，限制返回数量
        if args.limit and len(stocks) > args.limit:
            stocks = stocks[:args.limit]
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(stocks)} 只股票',
            'count': len(stocks),
            'stocks': stocks
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'count': 0,
            'stocks': []
        }))
        return 1


def cmd_factor(args) -> int:
    """因子管理命令 - 根据子命令分发"""
    if args.factor_subcommand == 'list':
        return cmd_factor_list(args)
    elif args.factor_subcommand == 'info':
        return cmd_factor_info(args)
    elif args.factor_subcommand == 'calc':
        return cmd_factor_calc(args)
    elif args.factor_subcommand == 'backtest':
        return cmd_factor_backtest(args)
    else:
        # 默认列出所有因子
        return cmd_factor_list(args)


def cmd_factor_list(args) -> int:
    """列出所有因子"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    factors = api.get_available_factors()
    print(format_output({
        'success': True,
        'count': len(factors),
        'factors': factors
    }))
    return 0


def cmd_factor_info(args) -> int:
    """查看因子详情"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_factor_info(args.name)
    if info:
        # 如果有help文本，优先显示help
        if 'help' in info:
            print(info['help'])
        else:
            print(format_output({
                'success': True,
                'factor': info
            }))
    else:
        print(format_output({
            'success': False,
            'message': f'因子不存在: {args.name}'
        }))
    return 0


def cmd_factor_calc(args) -> int:
    """计算因子值"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    import json
    import re
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    try:
        # 解析股票代码
        codes = args.codes.split(',') if args.codes else ['000001.SZ']
        
        # 解析因子参数
        factor_params = {}
        if args.params:
            params_str = args.params.strip()
            
            # 尝试直接解析JSON
            try:
                factor_params = json.loads(params_str)
            except json.JSONDecodeError:
                # 尝试修复常见的JSON格式问题
                # 1. 将单引号替换为双引号
                params_str = params_str.replace("'", '"')
                # 2. 处理没有引号的key
                params_str = re.sub(r'([{,])\s*(\w+)\s*:', r'\1"\2":', params_str)
                
                try:
                    factor_params = json.loads(params_str)
                except json.JSONDecodeError as e:
                    print(format_output({
                        'success': False,
                        'message': f'参数解析失败: {str(e)}。请使用JSON格式，如: {{"short_window":10,"long_window":30}}'
                    }))
                    return 1
        
        # 计算因子值
        result = api.calculate_factor_values(
            factor_code=args.name,
            codes=codes,
            calc_date=args.date,
            factor_params=factor_params,
            limit=args.limit if args.limit > 0 else None
        )
        
        if not result.get('success', False):
            print(format_output({
                'success': False,
                'message': result.get('message', '计算失败')
            }))
            return 1
        
        print(format_output(result))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'计算失败: {str(e)}'
        }))
        return 1


def cmd_factor_backtest(args) -> int:
    """因子回测"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行因子测试
    try:
        result = api.run_factor_test(
            factor_name=args.name,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            factor_params=factor_params,
            method=args.method
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def cmd_strategy(args) -> int:
    """策略管理命令 - 根据子命令分发"""
    if args.strategy_subcommand == 'list':
        return cmd_strategy_list(args)
    elif args.strategy_subcommand == 'info':
        return cmd_strategy_info(args)
    elif args.strategy_subcommand == 'backtest':
        return cmd_strategy_backtest(args)
    else:
        # 默认列出所有策略
        return cmd_strategy_list(args)


def cmd_strategy_list(args) -> int:
    """列出所有策略"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    strategies = api.list_strategies()
    print(format_output({
        'success': True,
        'count': len(strategies),
        'strategies': strategies
    }))
    return 0


def cmd_strategy_info(args) -> int:
    """查看策略详情"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_strategy_info(args.name)
    if info:
        print(format_output({
            'success': True,
            'strategy': info
        }))
    else:
        print(format_output({
            'success': False,
            'message': f'策略不存在: {args.name}'
        }))
    return 0


def cmd_strategy_backtest(args) -> int:
    """策略回测"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行策略回测
    try:
        result = api.run_strategy_backtest(
            strategy_name=args.name,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            strategy_params=strategy_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def cmd_engines(args) -> int:
    """查看可用回测引擎"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    engines = api.get_available_engines()
    
    print(format_output({
        'success': True,
        'count': len(engines),
        'engines': engines
    }))
    return 0


def cmd_backtest(args) -> int:
    """回测命令 - 支持多引擎"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模式
    if args.compare:
        return _run_compare_backtest(api, args, code, factor_params)
    
    # 单引擎模式
    return _run_single_backtest(api, args, code, factor_params)


def _run_single_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行单引擎回测"""
    try:
        # 运行回测
        result = api.run_backtest(
            factor_name=args.factor,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            factor_params=factor_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def _run_compare_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行多引擎对比回测"""
    # 获取可用引擎
    available_engines = api.get_available_engines()
    engines_to_test = []
    
    for e in available_engines:
        if e['available']:
            engines_to_test.append(e['type'])
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用: {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎对比回测',
        'engines': engines_to_test,
        'factor': args.factor,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'factor_params': factor_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行回测...")
        try:
            result = api.run_backtest(
                factor_name=args.factor,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                factor_params=factor_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  ✓ 成功 - 总收益: {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  ✗ 失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  ✗ 异常 - {e}")
    
    # 输出对比结果
    print("\n" + "=" * 60)
    print("多引擎回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        # 构建对比表格
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        # 详细结果
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        # 汇总统计
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        # 错误信息
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def cmd_factorbacktest(args) -> int:
    """因子回测 - 测试因子预测能力（IC、分层收益）"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    try:
        # 运行因子测试
        result = api.run_factor_test(
            factor_name=args.factor,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            factor_params=factor_params,
            method=args.method
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'因子回测失败: {str(e)}'
        }))
        return 1


def cmd_strategybacktest(args) -> int:
    """策略回测 - 测试策略盈利能力（资金曲线、收益率等）"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模式
    if args.compare:
        return _run_strategy_compare_backtest(api, args, code, strategy_params)
    
    # 单引擎模式
    return _run_single_strategy_backtest(api, args, code, strategy_params)


def _run_single_strategy_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行单引擎策略回测"""
    try:
        result = api.run_strategy_backtest(
            strategy_name=args.strategy,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            strategy_params=strategy_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'策略回测失败: {str(e)}'
        }))
        return 1


def _run_strategy_compare_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行多引擎策略回测对比"""
    available_engines = api.get_available_engines()
    engines_to_test = [e['type'] for e in available_engines if e['available']]
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用: {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎策略回测对比',
        'engines': engines_to_test,
        'strategy': args.strategy,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'strategy_params': strategy_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行策略回测...")
        try:
            result = api.run_strategy_backtest(
                strategy_name=args.strategy,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                strategy_params=strategy_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  ✓ 成功 - 总收益: {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  ✗ 失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  ✗ 异常 - {e}")
    
    print("\n" + "=" * 60)
    print("多引擎策略回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎策略回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def main():
    """主入口"""
    parser = argparse.ArgumentParser(
        description='StockClaw CLI - 股票数据管理与回测工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 更新单只股票数据
  python -m claw_quant.cli update --codes 000001.SZ --date 2026-04-20
  
数据管理命令:
  # 更新数据（从QMT到本地数据库）
  python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01
  python -m claw_quant.cli update --date 2024-06-01  # 更新所有股票
  
  # 查询数据
  python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  python -m claw_quant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01
  
  # 获取最新交易日期
  python -m claw_quant.cli latest
  
  # 获取股票列表
  python -m claw_quant.cli stocks --limit 10

因子管理命令:
  # 查看可用因子
  python -m claw_quant.cli factor list
  
  # 查看因子详情
  python -m claw_quant.cli factor info CROSS
  
  # 计算因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 因子回测（IC测试）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 因子回测（分层收益测试）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

策略管理命令:
  # 查看可用策略
  python -m claw_quant.cli strategy list
  
  # 查看策略详情
  python -m claw_quant.cli strategy info CROSS_STRATEGY
  
  # 策略回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

数据库管理命令:
  # 启动数据库服务器（必须先启动数据库才能使用其他命令）
  python -m claw_quant.cli db start
  
  # 后台启动数据库服务器
  python -m claw_quant.cli db start --background
  
  # 停止数据库服务器
  python -m claw_quant.cli db stop
  
  # 查看数据库服务器状态
  python -m claw_quant.cli db status

其他命令:
  # 查看可用回测引擎
  python -m claw_quant.cli engines

使用说明:
  1. 所有日期格式为 YYYY-MM-DD
  2. 股票代码格式为 000001.SZ（深市）或 600000.SH（沪市）
  3. 使用 --help 查看具体命令的详细参数，如：python -m claw_quant.cli factor backtest --help
  4. 因子是纯数据计算，策略是完整交易系统（包含仓位管理、风控等）
        '''
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令', metavar='COMMAND')
    
    # db 命令（数据库管理）
    db_parser = subparsers.add_parser(
        'db',
        help='数据库服务器管理',
        description='启动、停止和管理DuckDB数据库服务器。',
        epilog='''
数据库服务器管理命令:
  # 启动数据库服务器（前台运行）
  python -m claw_quant.cli db start
  
  # 后台启动数据库服务器
  python -m claw_quant.cli db start --background
  
  # 指定数据库路径启动
  python -m claw_quant.cli db start --db-path /path/to/db
  
  # 停止数据库服务器
  python -m claw_quant.cli db stop
  
  # 查看数据库状态
  python -m claw_quant.cli db status

说明:
  - 数据库服务器提供HTTP API访问DuckDB数据库
  - 默认地址: http://127.0.0.1:9529
  - 数据默认存储在系统缓存目录
  - 必须先启动数据库才能使用其他CLI命令
        '''
    )
    db_subparsers = db_parser.add_subparsers(dest='db_command', help='数据库子命令', metavar='DB_COMMAND')
    
    # db start 命令
    db_start_parser = db_subparsers.add_parser(
        'start',
        help='启动数据库服务器',
        description='启动DuckDB HTTP API服务器。'
    )
    db_start_parser.add_argument(
        '--db-path',
        type=str,
        help='数据库文件路径（默认: 系统缓存目录）'
    )
    db_start_parser.add_argument(
        '--host',
        type=str,
        default='127.0.0.1',
        help='服务器地址（默认: 127.0.0.1）'
    )
    db_start_parser.add_argument(
        '--port',
        type=int,
        default=9529,
        help='服务器端口（默认: 9529）'
    )
    db_start_parser.add_argument(
        '--background', '-b',
        action='store_true',
        help='后台运行模式'
    )
    db_start_parser.set_defaults(func=cmd_db_start)
    
    # db stop 命令
    db_stop_parser = db_subparsers.add_parser(
        'stop',
        help='停止数据库服务器',
        description='停止正在运行的DuckDB HTTP API服务器。'
    )
    db_stop_parser.set_defaults(func=cmd_db_stop)
    
    # db status 命令
    db_status_parser = db_subparsers.add_parser(
        'status',
        help='查看数据库服务器状态',
        description='检查数据库服务器是否正在运行。'
    )
    db_status_parser.set_defaults(func=cmd_db_status)
    
    # update 命令
    update_parser = subparsers.add_parser(
        'update',
        help='从QMT更新数据到数据库',
        description='从QMT获取实时行情数据并保存到本地DuckDB数据库。',
        epilog='''
前提条件:
  1. QMT客户端已登录
  2. QMT已下载所需日期的数据
  3. DuckDB数据库服务已启动

示例:
  # 更新单只股票
  python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01
  
  # 更新多只股票
  python -m claw_quant.cli update --codes 000001.SZ,000002.SZ --date 2024-06-01
  
  # 更新所有股票（不指定--codes）
  python -m claw_quant.cli update --date 2024-06-01
  
  # 更新今日数据（默认日期）
  python -m claw_quant.cli update

注意:
  - 股票代码格式：深市000001.SZ，沪市600000.SH
  - 不指定--codes时会更新所有股票，耗时较长
  - 重复更新同一日期会覆盖已有数据
        '''
    )
    update_parser.add_argument(
        '--codes',
        type=str,
        help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ。不指定则更新所有股票'
    )
    update_parser.add_argument(
        '--date',
        type=parse_date,
        default=date.today(),
        help='目标日期，格式：YYYY-MM-DD，默认为今天'
    )
    update_parser.set_defaults(func=cmd_update)
    
    # query 命令
    query_parser = subparsers.add_parser(
        'query',
        help='查询数据库中的数据',
        description='从本地DuckDB数据库查询股票历史行情数据。',
        epilog='''
前提条件:
  数据已存在于数据库（需先运行update命令更新数据）

示例:
  # 查询单只股票
  python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 查询多只股票
  python -m claw_quant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01

输出字段:
  - trade_date: 交易日期
  - code: 股票代码
  - open: 开盘价
  - high: 最高价
  - low: 最低价
  - close: 收盘价
  - volume: 成交量
  - amount: 成交金额

注意:
  - --code 和 --codes 必须指定其中一个
  - 日期格式：YYYY-MM-DD
  - 查询前确保数据已更新
        '''
    )
    query_group = query_parser.add_mutually_exclusive_group(required=True)
    query_group.add_argument(
        '--code',
        type=str,
        help='单只股票代码，如：000001.SZ'
    )
    query_group.add_argument(
        '--codes',
        type=str,
        help='多只股票代码，用逗号分隔，如：000001.SZ,000002.SZ'
    )
    query_parser.add_argument(
        '--start',
        type=parse_date,
        required=True,
        help='开始日期，格式：YYYY-MM-DD'
    )
    query_parser.add_argument(
        '--end',
        type=parse_date,
        required=True,
        help='结束日期，格式：YYYY-MM-DD'
    )
    query_parser.set_defaults(func=cmd_query)
    
    # latest 命令
    latest_parser = subparsers.add_parser(
        'latest',
        help='获取数据库中最新的交易日期',
        description='查询本地数据库中已存储的最新交易日期。用于确认数据更新状态。'
    )
    latest_parser.set_defaults(func=cmd_latest)
    
    # stocks 命令
    stocks_parser = subparsers.add_parser(
        'stocks',
        help='获取股票列表',
        description='获取系统中的股票列表，包括股票代码和名称。',
        epilog='''
示例:
  # 获取所有股票
  python -m claw_quant.cli stocks
  
  # 只获取前10只
  python -m claw_quant.cli stocks --limit 10

输出字段:
  - code: 股票代码
  - name: 股票名称
  - industry: 所属行业
        '''
    )
    stocks_parser.add_argument(
        '--limit',
        type=int,
        help='限制返回数量，不指定则返回所有股票'
    )
    stocks_parser.set_defaults(func=cmd_stocks)
    
    # factor 命令 - 使用子命令
    factor_parser = subparsers.add_parser(
        'factor',
        help='因子管理',
        description='因子管理命令。因子是纯数据计算，输出信号值。',
        epilog='''
示例:
  # 列出所有可用因子
  python -m claw_quant.cli factor list
  
  # 查看CROSS因子详情
  python -m claw_quant.cli factor info CROSS
  
  # 计算CROSS因子在2024-06-01的值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 对CROSS因子进行IC测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 对CROSS因子进行分层收益测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

说明:
  - factor list: 显示所有可用因子及其参数
  - factor info: 查看因子的详细说明和参数定义
  - factor calc: 计算指定日期的因子值，输出原始值、排名、百分位、Z-score
  - factor backtest: 测试因子的预测能力（IC值或分层收益）
        '''
    )
    factor_subparsers = factor_parser.add_subparsers(dest='factor_subcommand', help='因子子命令', metavar='SUBCOMMAND')
    
    # factor list
    factor_list_parser = factor_subparsers.add_parser(
        'list',
        help='列出所有可用因子',
        description='列出系统中所有可用的因子，包括因子名称、描述和参数。'
    )
    factor_list_parser.set_defaults(func=cmd_factor)
    
    # factor info
    factor_info_parser = factor_subparsers.add_parser(
        'info',
        help='查看因子详情',
        description='查看指定因子的详细信息，包括描述、参数定义和默认值。'
    )
    factor_info_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_info_parser.set_defaults(func=cmd_factor)
    
    # factor calc
    factor_calc_parser = factor_subparsers.add_parser(
        'calc',
        help='计算因子值',
        description='计算指定日期股票的因子值。输出包括原始值、排名、百分位和Z-score。',
        epilog='''
示例:
  # 计算单只股票的因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 计算多只股票的因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ,000002.SZ
  
  # 计算所有股票的因子值，只显示前50条
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --limit 50

输出字段:
  - calc_date: 计算日期
  - code: 股票代码
  - factor_code: 因子代码
  - value: 因子原始值
  - rank_value: 排名（从高到低）
  - percentile: 百分位（0-1）
  - zscore: Z-score标准化值
        '''
    )
    factor_calc_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_calc_parser.add_argument('--date', type=parse_date, required=True, help='计算日期，格式：YYYY-MM-DD')
    factor_calc_parser.add_argument('--codes', type=str, help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ。不指定则计算所有股票')
    factor_calc_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":10,"long_window":30}\'')
    factor_calc_parser.add_argument('--limit', type=int, default=20, help='限制返回结果数量，默认20，设为0返回全部')
    factor_calc_parser.set_defaults(func=cmd_factor)
    
    # factor backtest
    factor_backtest_parser = factor_subparsers.add_parser(
        'backtest',
        help='因子回测（IC测试、分层收益）',
        description='测试因子的预测能力。IC测试计算因子值与未来收益的相关系数；分层测试将股票按因子值分5层，观察各层收益差异。',
        epilog='''
示例:
  # IC测试（默认）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 分层收益测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer
  
  # 带参数的回测
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'

测试方法说明:
  ic: IC测试，计算因子值与未来1日收益的相关系数
      - IC > 0.03: 因子有一定预测能力
      - IC > 0.05: 因子预测能力较强
      - IC绝对值越大，预测能力越强
  
  layer: 分层收益测试，按因子值将股票分为5层
      - 观察各层收益是否单调（L1 < L2 < L3 < L4 < L5）
      - 单调性越好，因子越有效
      - 计算顶层与底层收益差（spread）
        '''
    )
    factor_backtest_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ')
    factor_backtest_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    factor_backtest_parser.add_argument('--method', type=str, choices=['ic', 'layer'], default='ic', help='测试方法：ic=IC测试，layer=分层收益测试')
    factor_backtest_parser.set_defaults(func=cmd_factor)
    
    # strategy 命令 - 使用子命令
    strategy_parser = subparsers.add_parser(
        'strategy',
        help='策略管理',
        description='策略管理命令。策略是完整的交易系统，包含信号生成、仓位管理、风控等。',
        epilog='''
示例:
  # 列出所有可用策略
  python -m claw_quant.cli strategy list
  
  # 查看CROSS_STRATEGY策略详情
  python -m claw_quant.cli strategy info CROSS_STRATEGY
  
  # 对CROSS_STRATEGY进行回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金和参数进行回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000 --params '{"short_window":10,"long_window":30}'

说明:
  - strategy list: 显示所有可用策略及其参数
  - strategy info: 查看策略的详细说明、参数和默认配置
  - strategy backtest: 测试策略的盈利能力，输出资金曲线和各项指标

因子与策略的区别:
  - 因子：纯数据计算，输出信号值（如CROSS因子计算均线差值）
  - 策略：完整交易系统，使用因子生成信号，并执行买卖、仓位管理、风控
        '''
    )
    strategy_subparsers = strategy_parser.add_subparsers(dest='strategy_subcommand', help='策略子命令', metavar='SUBCOMMAND')
    
    # strategy list
    strategy_list_parser = strategy_subparsers.add_parser(
        'list',
        help='列出所有可用策略',
        description='列出系统中所有可用的策略，包括策略名称、类型、描述和可调参数。'
    )
    strategy_list_parser.set_defaults(func=cmd_strategy)
    
    # strategy info
    strategy_info_parser = strategy_subparsers.add_parser(
        'info',
        help='查看策略详情',
        description='查看指定策略的详细信息，包括描述、使用的因子、参数定义、默认配置等。'
    )
    strategy_info_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_info_parser.set_defaults(func=cmd_strategy)
    
    # strategy backtest
    strategy_backtest_parser = strategy_subparsers.add_parser(
        'backtest',
        help='策略回测（资金曲线、收益率等）',
        description='测试策略的盈利能力。输出资金曲线、总收益率、年化收益、最大回撤、夏普比率、交易记录等。',
        epilog='''
示例:
  # 基本回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000
  
  # 自定义策略参数
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'
  
  # 指定回测引擎
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --engine vnpy

输出指标说明:
  - total_return: 总收益率
  - annual_return: 年化收益率
  - max_drawdown: 最大回撤（负数表示亏损）
  - sharpe_ratio: 夏普比率（风险调整后收益，>1较好）
  - total_trades: 总交易次数
  - win_rate: 胜率
  - trades: 详细交易记录（买入/卖出时间、价格、数量、原因）
        '''
    )
    strategy_backtest_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ')
    strategy_backtest_parser.add_argument('--capital', type=float, default=1000000.0, help='初始资金，默认1000000')
    strategy_backtest_parser.add_argument('--params', type=str, help='策略参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    strategy_backtest_parser.add_argument('--engine', type=str, choices=['local', 'cskhquant', 'jqdata', 'vnpy'], help='指定回测引擎：local=本地引擎(默认), cskhquant=CSKhQuant, jqdata=聚宽, vnpy=VNPY')
    strategy_backtest_parser.set_defaults(func=cmd_strategy)
    
    # engines 命令
    engines_parser = subparsers.add_parser(
        'engines',
        help='查看可用回测引擎',
        description='显示所有可用的回测引擎及其状态。'
    )
    engines_parser.set_defaults(func=cmd_engines)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
