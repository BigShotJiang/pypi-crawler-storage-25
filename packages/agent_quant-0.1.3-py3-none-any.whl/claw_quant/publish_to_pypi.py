#!/usr/bin/env python3
"""
Publish script for claw_quant to PyPI

Usage:
    python publish_to_pypi.py                    # Interactive mode (will ask for token)
    python publish_to_pypi.py --token YOUR_TOKEN # Provide token via argument
    python publish_to_pypi.py --test             # Upload to TestPyPI
    python publish_to_pypi.py --build            # Build only

Environment Variables:
    PYPI_TOKEN    - PyPI API token
    TESTPYPI_TOKEN - TestPyPI API token
"""

import subprocess
import sys
import shutil
import os
import getpass


def get_token_from_user(test_mode=False):
    """Get API token from user input securely"""
    repo = "TestPyPI" if test_mode else "PyPI"
    print(f"\n{'='*60}")
    print(f"Please enter your {repo} API token")
    print(f"{'='*60}")
    print(f"You can get your token from: https://pypi.org/manage/account/token/")
    print("(Input will be hidden for security)\n")
    
    token = getpass.getpass(f"{repo} API Token: ")
    
    if not token:
        print("[ERROR] Token cannot be empty!")
        sys.exit(1)
    
    return token


def get_token(args):
    """Get API token from various sources"""
    # Priority: 1. Command line argument 2. Environment variable 3. Interactive input
    
    if args.token:
        return args.token
    
    env_var = 'TESTPYPI_TOKEN' if args.test else 'PYPI_TOKEN'
    token = os.environ.get(env_var)
    if token:
        print(f"[INFO] Using token from environment variable: {env_var}")
        return token
    
    return get_token_from_user(args.test)


def run_command(cmd, description, env=None):
    """Run shell command and print output"""
    print(f"\n{'='*60}")
    print(f"{description}")
    print(f"{'='*60}")
    print(f"Command: {cmd}")
    print()
    
    # Merge environment variables
    run_env = os.environ.copy()
    if env:
        run_env.update(env)
        # Print env vars for debugging (mask password)
        debug_env = {k: v[:10] + '...' if k == 'TWINE_PASSWORD' else v for k, v in env.items()}
        print(f"Environment: {debug_env}")
    
    result = subprocess.run(cmd, shell=True, capture_output=False, text=True, env=run_env)
    if result.returncode != 0:
        print(f"[ERROR] Command failed with exit code {result.returncode}")
        sys.exit(1)
    return result


def clean_build():
    """Clean build artifacts"""
    print("\n" + "="*60)
    print("Cleaning build artifacts...")
    print("="*60)
    
    dirs_to_remove = ['build', 'dist', '*.egg-info']
    for pattern in dirs_to_remove:
        if '*' in pattern:
            import glob
            for path in glob.glob(pattern):
                if os.path.isdir(path):
                    print(f"Removing: {path}")
                    shutil.rmtree(path)
        else:
            if os.path.isdir(pattern):
                print(f"Removing: {pattern}")
                shutil.rmtree(pattern)
    
    print("[OK] Clean completed")


def install_build_tools():
    """Install required build tools"""
    run_command(
        f"{sys.executable} -m pip install --upgrade build twine",
        "Installing build tools (build, twine)"
    )


def build_package():
    """Build the package"""
    run_command(
        f"{sys.executable} -m build",
        "Building package"
    )


def upload_to_testpypi(token):
    """Upload to TestPyPI"""
    env = {
        'TWINE_USERNAME': '__token__',
        'TWINE_PASSWORD': token
    }
    run_command(
        f"{sys.executable} -m twine upload --repository testpypi dist/*",
        "Uploading to TestPyPI",
        env=env
    )


def upload_to_pypi(token):
    """Upload to PyPI"""
    env = {
        'TWINE_USERNAME': '__token__',
        'TWINE_PASSWORD': token
    }
    run_command(
        f"{sys.executable} -m twine upload dist/*",
        "Uploading to PyPI",
        env=env
    )


def check_package():
    """Check package with twine"""
    run_command(
        f"{sys.executable} -m twine check dist/*",
        "Checking package with twine"
    )


def main():
    """Main function"""
    import argparse
    parser = argparse.ArgumentParser(
        description='Publish claw_quant to PyPI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python publish_to_pypi.py                    # Interactive mode
    python publish_to_pypi.py --token TOKEN      # Use provided token
    python publish_to_pypi.py --test             # Upload to TestPyPI
    python publish_to_pypi.py --build            # Build only

Environment Variables:
    PYPI_TOKEN      - PyPI API token
    TESTPYPI_TOKEN  - TestPyPI API token
        """
    )
    parser.add_argument('--token', type=str, help='PyPI API token (will prompt if not provided)')
    parser.add_argument('--test', action='store_true', help='Upload to TestPyPI')
    parser.add_argument('--build', action='store_true', help='Build only, do not upload')
    parser.add_argument('--skip-clean', action='store_true', help='Skip cleaning build artifacts')
    args = parser.parse_args()
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    print("\n" + "="*60)
    print("ClawQuant PyPI Publisher")
    print("="*60)
    print(f"Current directory: {os.getcwd()}")
    print(f"Python: {sys.executable}")
    
    # Clean
    if not args.skip_clean:
        clean_build()
    
    # Install tools
    install_build_tools()
    
    # Build
    build_package()
    
    # Check
    check_package()
    
    # Upload
    if args.build:
        print("\n" + "="*60)
        print("Build completed. Skipping upload.")
        print("="*60)
        print("\nTo upload, run:")
        print("  python publish_to_pypi.py                    # Interactive mode")
        print("  python publish_to_pypi.py --token TOKEN      # With token")
        print("  python publish_to_pypi.py --test             # Upload to TestPyPI")
    else:
        # Get token
        token = get_token(args)
        
        if args.test:
            upload_to_testpypi(token)
            print("\n" + "="*60)
            print("Upload to TestPyPI completed!")
            print("Test installation with:")
            print("  pip install --index-url https://test.pypi.org/simple/ claw_quant")
            print("="*60)
        else:
            upload_to_pypi(token)
            print("\n" + "="*60)
            print("Upload to PyPI completed!")
            print("Installation:")
            print("  pip install claw_quant")
            print("="*60)


if __name__ == '__main__':
    main()
