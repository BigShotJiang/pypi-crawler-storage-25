#!/usr/bin/env python3
"""
Fix package structure for PyPI distribution
Moves all modules into the claw_quant package
"""

import os
import shutil
import sys


def move_to_package(src_dir, dest_dir, package_name):
    """Move directory into package"""
    if not os.path.exists(src_dir):
        print(f"Source does not exist: {src_dir}")
        return
    
    if os.path.exists(dest_dir):
        print(f"Destination already exists: {dest_dir}")
        return
    
    print(f"Moving {src_dir} -> {dest_dir}")
    shutil.move(src_dir, dest_dir)


def update_imports_in_file(filepath, old_import, new_import):
    """Update imports in a file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original = content
        content = content.replace(old_import, new_import)
        
        if content != original:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"  Updated: {filepath}")
    except Exception as e:
        print(f"  Error updating {filepath}: {e}")


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base_dir)
    
    print("="*60)
    print("Fixing package structure for PyPI")
    print("="*60)
    
    # Move directories into claw_quant package
    moves = [
        ("database", "claw_quant/database"),
        ("src", "claw_quant/src"),
        ("tests", "claw_quant/tests"),
        ("skills", "claw_quant/skills"),
        ("examples", "claw_quant/examples"),
        ("docs", "claw_quant/docs"),
    ]
    
    for src, dest in moves:
        src_path = os.path.join(base_dir, src)
        dest_path = os.path.join(base_dir, dest)
        move_to_package(src_path, dest_path, "claw_quant")
    
    # Move root Python files into claw_quant
    root_files = ["cli.py"]
    for filename in root_files:
        src = os.path.join(base_dir, filename)
        dest = os.path.join(base_dir, "claw_quant", filename)
        if os.path.exists(src) and not os.path.exists(dest):
            print(f"Moving {src} -> {dest}")
            shutil.move(src, dest)
    
    print("\n" + "="*60)
    print("Package structure fixed!")
    print("="*60)
    print("\nNew structure:")
    print("  claw_quant/")
    print("    ├── __init__.py")
    print("    ├── cli.py")
    print("    ├── database/")
    print("    ├── src/")
    print("    ├── tests/")
    print("    ├── skills/")
    print("    ├── examples/")
    print("    └── docs/")


if __name__ == '__main__':
    main()
