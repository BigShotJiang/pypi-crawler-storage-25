@echo off
setlocal EnableDelayedExpansion

REM Parse arguments
set RUN_BG=0
set USE_SYSTEM_PY=0
set JSON_OUTPUT=0
set DB_PATH=

:parse_args
if "%~1"=="" goto :done_parse
if /i "%~1"=="--bg" set RUN_BG=1
if /i "%~1"=="--background" set RUN_BG=1
if /i "%~1"=="--system" set USE_SYSTEM_PY=1
if /i "%~1"=="--json" set JSON_OUTPUT=1
if /i "%~1"=="--db-path" (
    set DB_PATH=%~2
    shift
)
shift
goto :parse_args
:done_parse

REM Set Python path
if %USE_SYSTEM_PY%==1 (
    set PYTHON_PATH=C:\Python312\python.exe
) else (
    set PYTHON_PATH=python
)

REM Check Python
"!PYTHON_PATH!" --version >nul 2>&1
if errorlevel 1 (
    if %JSON_OUTPUT%==1 (
        echo {"success": false, "message": "Python not found. Please install Python 3.10+ or use --system flag", "running": false}
    ) else (
        echo [ERROR] Python not found!
        echo.
        echo Please check:
        echo 1. Python is installed
        echo 2. Python is in system PATH
        echo 3. Or use --system flag
        pause
    )
    exit /b 1
)

REM Check if server already running
"!PYTHON_PATH!" -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',9529)); s.close(); exit(0 if r==0 else 1)" 2>nul
if %errorlevel% == 0 (
    if %JSON_OUTPUT%==1 (
        echo {"success": true, "message": "Server is already running", "running": true, "address": "http://127.0.0.1:9529"}
    ) else (
        echo [INFO] Server is already running!
        echo.
        echo Address: http://127.0.0.1:9529
        if %RUN_BG%==0 pause
    )
    exit /b 0
)

REM Set working directory
cd /d "%~dp0"

REM Set database path (use provided path or let server use default)
if "!DB_PATH!"=="" (
    set DB_PATH_ARG=
) else (
    set DB_PATH_ARG=--db-path "!DB_PATH!"
)

if %RUN_BG%==1 (
    REM Start in background
    if "!DB_PATH_ARG!"=="" (
        start /min "" cmd /c "cd /d "%~dp0" && "!PYTHON_PATH!" -B -m claw_quant.database.storage.db_server"
    ) else (
        start /min "" cmd /c "cd /d "%~dp0" && "!PYTHON_PATH!" -B -m claw_quant.database.storage.db_server !DB_PATH_ARG!"
    )
    timeout /t 2 /nobreak >nul
    
    REM Check if started successfully
    "!PYTHON_PATH!" -c "import socket; s=socket.socket(); s.settimeout(2); r=s.connect_ex(('127.0.0.1',9529)); s.close(); exit(0 if r==0 else 1)" 2>nul
    if %errorlevel% == 0 (
        if %JSON_OUTPUT%==1 (
            echo {"success": true, "message": "Server started successfully in background", "running": true, "address": "http://127.0.0.1:9529"}
        ) else (
            echo [OK] Server started in background
            echo Address: http://127.0.0.1:9529
        )
        exit /b 0
    ) else (
        if %JSON_OUTPUT%==1 (
            echo {"success": false, "message": "Failed to start server in background", "running": false}
        ) else (
            echo [ERROR] Failed to start server!
            pause
        )
        exit /b 1
    )
) else (
    REM Start in foreground
    if %JSON_OUTPUT%==0 (
        title DuckDB HTTP API Server
        echo ==========================================
        echo Start DuckDB HTTP API Server
        echo ==========================================
        echo.
        echo Server Address: http://127.0.0.1:9529
        echo.
        echo Press Ctrl+C to stop server
        echo.
    )
    
    if "!DB_PATH_ARG!"=="" (
        "!PYTHON_PATH!" -B -m claw_quant.database.storage.db_server
    ) else (
        "!PYTHON_PATH!" -B -m claw_quant.database.storage.db_server !DB_PATH_ARG!
    )
    
    if %JSON_OUTPUT%==0 (
        echo.
        echo [WARNING] Server stopped!
        pause
    )
)
