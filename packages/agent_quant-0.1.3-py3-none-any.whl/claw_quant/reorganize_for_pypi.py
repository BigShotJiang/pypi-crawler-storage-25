#!/usr/bin/env python3
"""
Reorganize project structure for PyPI distribution
"""

import os
import shutil
import sys


def ensure_init_files(directory):
    """Ensure __init__.py exists in all subdirectories"""
    for root, dirs, files in os.walk(directory):
        # Skip __pycache__ and hidden directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
        
        init_file = os.path.join(root, '__init__.py')
        if not os.path.exists(init_file):
            print(f"Creating: {init_file}")
            with open(init_file, 'w', encoding='utf-8') as f:
                f.write('')


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base_dir)
    
    print("="*60)
    print("Reorganizing for PyPI")
    print("="*60)
    
    # Ensure all subdirectories have __init__.py
    dirs_to_check = ['database', 'src', 'tests', 'skills', 'examples']
    
    for dir_name in dirs_to_check:
        dir_path = os.path.join(base_dir, dir_name)
        if os.path.exists(dir_path):
            print(f"\nChecking: {dir_name}")
            ensure_init_files(dir_path)
    
    print("\n" + "="*60)
    print("Reorganization complete!")
    print("="*60)


if __name__ == '__main__':
    main()
