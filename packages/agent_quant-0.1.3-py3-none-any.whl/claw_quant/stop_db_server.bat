@echo off
title Stop DuckDB HTTP API Server
echo ==========================================
echo Stop DuckDB HTTP API Server
echo ==========================================
echo.

REM Set working directory
cd /d "%~dp0\.."

echo [1/2] Checking Python...
python --version
if errorlevel 1 (
    echo [ERROR] Python not found!
    pause
    exit /b 1
)
echo [OK] Python found
echo.

echo [2/2] Stopping server...
python -c "import socket; s=socket.socket(); s.connect(('127.0.0.1', 9529)); s.send(b'SHUTDOWN'); s.close()" 2>nul
if %errorlevel% == 0 (
    echo [OK] Server stop signal sent
) else (
    echo [INFO] Server may not be running or stopped already
)
echo.

echo ==========================================
echo Done
echo ==========================================
pause
