"""PII type registry — central definition of all PII types."""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Callable

from argus_redact.specs._compliance import gdpr_special_for as _gdpr_special_for
from argus_redact.specs._compliance import hipaa_for as _hipaa_for
from argus_redact.specs._compliance import pipl_articles_for as _pipl_articles_for


@dataclass(frozen=True)
class PIITypeDef:
    """Complete definition of a PII type."""

    # ── Identity ──
    name: str  # "phone", "id_number"
    lang: str  # "zh", "en", "shared"

    # ── Structure ──
    format: str  # "1[3-9]XXXXXXXXX"
    length: int | tuple[int, int] | None = None  # 11 or (16, 19)
    charset: str = "digits"  # "digits", "digits+X", "alnum"
    structure: dict[str, str] = field(default_factory=dict)  # segment descriptions

    # ── Validation ──
    checksum: str | None = None  # "MOD11-2", "Luhn", None
    validate: Callable[[str], bool] | None = None  # runtime validator

    # ── Context ──
    prefixes: tuple[str, ...] = ()  # context words before PII
    suffixes: tuple[str, ...] = ()  # context words after PII
    separators: tuple[str, ...] = ("",)  # allowed in-value separators

    # ── Action ──
    strategy: str = "remove"  # "mask", "pseudonym", "remove", "category"
    label: str = ""  # "[手机号已脱敏]"
    mask_rule: dict[str, int] | None = None  # {"visible_prefix": 3, "visible_suffix": 4}

    # ── Evidence ──
    examples: tuple[str, ...] = ()  # valid instances
    counterexamples: tuple[str, ...] = ()  # should NOT match
    source: str = ""  # authoritative reference

    # ── Pattern generation ──
    _patterns: tuple[dict, ...] = ()  # pre-built pattern dicts (override auto-generation)

    # ── Faker ──
    faker: Callable | None = None  # (rng: random.Random) -> str
    faker_reserved: Callable | None = None  # (value: str, rng: random.Random) -> str — reserved-range or range-noise faker for realistic strategy

    # ── Risk / Compliance ──
    sensitivity: int = 2  # 1=low, 2=medium, 3=high, 4=critical

    # PIPL / GDPR / HIPAA classification — read by `assess_risk()` and
    # exposed in `docs/pii-types.md` so downstream DPIA generators don't
    # need to mirror the rules. (v0.5.9+)
    pipl_articles: tuple[str, ...] = ()  # e.g. ("PIPL Art.13", "PIPL Art.51")
    gdpr_special_category: bool = False  # GDPR Art.9 special category
    hipaa_phi_category: str | None = None  # one of HIPAA Safe Harbor 18

    # ── Description ──
    description: str = ""

    def to_patterns(self) -> list[dict]:
        """Return pattern dict(s) for use with match_patterns().

        If _patterns is set, returns those directly.
        Otherwise, returns an empty list (type needs NER or manual patterns).
        """
        if self._patterns:
            return list(self._patterns)
        return []

    @property
    def is_reversible(self) -> bool:
        """Whether ``replace()→restore()`` recovers the original. Derived
        from ``self.strategy``. Lazy import avoids registry → replacer cycle.
        """
        from argus_redact.pure.replacer import is_strategy_reversible

        return is_strategy_reversible(self.strategy)

    def to_fixtures(self) -> list[dict]:
        """Generate test fixture entries from examples and counterexamples."""
        fixtures = []
        for i, ex in enumerate(self.examples):
            fixtures.append(
                {
                    "id": f"{self.name}_spec_example_{i}",
                    "input": ex,
                    "should_match": True,
                    "type": self.name,
                    "description": f"Spec example for {self.lang}/{self.name}",
                }
            )
        for i, cx in enumerate(self.counterexamples):
            fixtures.append(
                {
                    "id": f"{self.name}_spec_counter_{i}",
                    "input": cx,
                    "should_match": False,
                    "type": self.name,
                    "description": f"Spec counterexample for {self.lang}/{self.name}",
                }
            )
        return fixtures


# ── Global registry ──

_REGISTRY: dict[tuple[str, str], PIITypeDef] = {}


def register(typedef: PIITypeDef) -> PIITypeDef:
    """Register a PII type definition.

    Compliance metadata fields are auto-derived from `name + sensitivity` via
    `specs/_compliance.py` rules. Each field falls back independently — a
    caller can pre-populate `pipl_articles` while still letting `gdpr_*` /
    `hipaa_*` derive from the central rule book.
    """
    pipl = typedef.pipl_articles or _pipl_articles_for(typedef.name, typedef.sensitivity)
    gdpr = typedef.gdpr_special_category or _gdpr_special_for(typedef.name)
    hipaa = typedef.hipaa_phi_category or _hipaa_for(typedef.name)
    if (pipl, gdpr, hipaa) != (
        typedef.pipl_articles,
        typedef.gdpr_special_category,
        typedef.hipaa_phi_category,
    ):
        typedef = dataclasses.replace(
            typedef,
            pipl_articles=pipl,
            gdpr_special_category=gdpr,
            hipaa_phi_category=hipaa,
        )
    key = (typedef.lang, typedef.name)
    _REGISTRY[key] = typedef
    return typedef


def unregister(lang: str, name: str) -> None:
    """Remove a registration. Primarily for tests that inject temporary types."""
    _REGISTRY.pop((lang, name), None)


def get(lang: str, name: str) -> PIITypeDef:
    """Get a PII type definition by language and name."""
    key = (lang, name)
    if key not in _REGISTRY:
        raise KeyError(f"No PII type '{name}' for lang '{lang}'")
    return _REGISTRY[key]


def lookup(name: str) -> list[PIITypeDef]:
    """Find all definitions for a PII type across languages."""
    return [v for (_, n), v in _REGISTRY.items() if n == name]


def list_types(lang: str | None = None) -> list[PIITypeDef]:
    """List all registered PII types, optionally filtered by language."""
    if lang:
        return [v for (l, _), v in _REGISTRY.items() if l == lang]
    return list(_REGISTRY.values())
