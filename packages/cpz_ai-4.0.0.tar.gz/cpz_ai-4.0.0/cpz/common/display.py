"""
Display utilities for polars DataFrames with enhanced formatting.
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    import polars as pl


def display_dataframe_with_sticky_header(
    df: Any,  # pl.DataFrame, lazy-imported at runtime
    max_rows: int = 1000,
    max_height: str = "600px",
    show_index: bool = True,
) -> None:
    """Display a polars DataFrame with a sticky/fixed header.

    Wraps polars' built-in ``_repr_html_()`` in a scrollable container whose
    ``<thead>`` is CSS-sticky, so the header stays visible when scrolling
    through long tables. Works in Jupyter notebooks and other environments
    that render HTML output.

    Args:
        df: The polars DataFrame to display.
        max_rows: Maximum number of rows to display (default: 1000).
        max_height: Maximum height of the container before scrolling.
        show_index: When True, prepend a synthetic 0..n-1 index column.
    """
    try:
        import polars as pl
    except ImportError as e:
        raise ImportError(
            "polars is required for display_dataframe_with_sticky_header. "
            "Install it with: pip install polars"
        ) from e

    if not isinstance(df, pl.DataFrame):
        raise TypeError(f"Expected polars DataFrame, got {type(df)}")

    display_df = df.head(max_rows) if df.height > max_rows else df
    if show_index:
        display_df = display_df.with_row_index(name="#").select(
            ["#", *[c for c in display_df.columns if c != "#"]]
        )

    html_table = display_df._repr_html_()
    html_output = f"""
    <style>
        .cpz-sticky-table-container {{
            max-height: {max_height};
            overflow-y: auto;
            overflow-x: auto;
            border: 1px solid #ddd;
            border-radius: 4px;
        }}
        .cpz-sticky-table-container table {{
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }}
        .cpz-sticky-table-container thead {{
            position: sticky;
            top: 0;
            z-index: 10;
            background-color: #fff;
            box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
        }}
        .cpz-sticky-table-container th {{
            background-color: #f8f9fa;
            font-weight: bold;
            padding: 8px 12px;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
            position: sticky;
            top: 0;
        }}
        .cpz-sticky-table-container td {{
            padding: 6px 12px;
            border-bottom: 1px solid #dee2e6;
        }}
        .cpz-sticky-table-container tr:hover {{
            background-color: #f5f5f5;
        }}
        .cpz-sticky-table-container thead tr:hover {{
            background-color: #f8f9fa;
        }}
    </style>
    <div class="cpz-sticky-table-container">
        {html_table}
    </div>
    """

    try:
        from IPython.display import HTML, display

        display(HTML(html_output))
    except ImportError:
        print(
            "HTML output with sticky header generated. If your environment supports "
            "HTML display, the table should render with a sticky header. Otherwise, "
            "save the HTML to a file."
        )
        print("\nTo save as HTML file:")
        print("  with open('table.html', 'w') as f:")
        print("      f.write(html_output)")
        try:
            import sys

            if hasattr(sys.stdout, "write_html"):
                sys.stdout.write_html(html_output)
            else:
                print(html_output)
        except Exception:
            print("Could not display HTML. Your environment may not support HTML output.")


def display_dataframe_simple(df: "pl.DataFrame", max_rows: int = 100) -> None:
    """Simple display helper that outputs HTML with basic styling.

    Falls back to ``print(df)`` if HTML display is not available.

    Args:
        df: The polars DataFrame to display.
        max_rows: Maximum number of rows to display.
    """
    try:
        import polars as pl
    except ImportError:
        print(df)
        return

    if not isinstance(df, pl.DataFrame):
        print(df)
        return

    display_df = df.head(max_rows) if df.height > max_rows else df

    try:
        from IPython.display import HTML, display

        display(HTML(display_df._repr_html_()))
    except ImportError:
        print(display_df)
