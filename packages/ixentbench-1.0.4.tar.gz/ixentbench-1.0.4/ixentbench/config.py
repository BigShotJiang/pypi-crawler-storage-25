# -*- coding: utf-8 -*-
"""
ixentbench/config.py
Constantes, carga del .env y utilidades de estado.
"""

import os
import pathlib
import click
from dotenv import load_dotenv

# ── Directorios locales ────────────────────────────────────────────────────
IXENT_HOME     = pathlib.Path.home() / "ixentbench"
PROMPTS_DIR    = IXENT_HOME / "prompts"
STRATEGIES_DIR = IXENT_HOME / "strategies"
CREDENTIALS    = IXENT_HOME / "credentials.json"

for _d in [PROMPTS_DIR, STRATEGIES_DIR]:
    _d.mkdir(parents=True, exist_ok=True)

# ── Credenciales de iXentLabs — hardcodeadas en el paquete ────────────────
# Estas son credenciales PÚBLICAS de tipo "Desktop App" en Google Cloud.
# El CLIENT_ID y FIREBASE_API_KEY son identificadores de la aplicación,
# no secretos del usuario. El OAUTH_CLIENT_SECRET de tipo Desktop App
# es seguro hardcodear según el estándar OAuth 2.0 (RFC 8252).
# El usuario NUNCA necesita configurar estos valores.
FIREBASE_API_KEY    = "AIzaSyDXEL47mO93BA8W1TTXHHdWOIK4tFUnamo"
OAUTH_CLIENT_ID     = "874064710861-dds7gf6e1qinl8c4lurs47od9cc5b0ll.apps.googleusercontent.com"
OAUTH_CLIENT_SECRET = "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"

# ── Cargar .env — solo secretos BYOK del usuario ──────────────────────────
load_dotenv()

GOOGLE_API_KEY    = os.getenv("GOOGLE_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY")
LOCAL_MODEL_URL   = os.getenv("LOCAL_MODEL_URL")
IXENT_SDK_URL     = os.getenv("IXENT_SDK_URL",
    "https://ixent-solo-sdk-874064710861.us-central1.run.app")
VISUALIZER_URL    = os.getenv("VISUALIZER_URL",
    "https://project-8b3bc726-e144-49eb-a7e.web.app")


def validate_env():
    """Valida que las credenciales BYOK mínimas estén presentes."""
    # Las credenciales de iXentLabs están hardcodeadas — no hay nada que validar.
    # Solo verificamos que el usuario haya puesto al menos una API Key.
    if not any([GOOGLE_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY, LOCAL_MODEL_URL]):
        click.echo("❌ No API Key found in .env file.", err=True)
        click.echo("   Add at least one of: GOOGLE_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY", err=True)
        click.echo("   Or set LOCAL_MODEL_URL for a local model.", err=True)
        raise SystemExit(1)


def show_status():
    """Muestra el estado actual de credenciales y sesión."""
    click.echo("\n📊 iXentBench Status")
    click.echo("─" * 40)
    click.echo(f"  iXentLabs Auth:    ✅ Integrated")
    click.echo(f"  Google API Key:    {'✅ Set' if GOOGLE_API_KEY    else '— Not set'}")
    click.echo(f"  Anthropic API Key: {'✅ Set' if ANTHROPIC_API_KEY else '— Not set'}")
    click.echo(f"  OpenAI API Key:    {'✅ Set' if OPENAI_API_KEY    else '— Not set'}")
    click.echo(f"  Local Model URL:   {LOCAL_MODEL_URL or '— Not set'}")
    click.echo(f"  Credentials:       {'✅ Saved' if CREDENTIALS.exists() else '⚠️  Run: ixentbench login'}")
    click.echo(f"  SDK URL:           {IXENT_SDK_URL}")
    click.echo(f"  Prompts saved:     {len(list(PROMPTS_DIR.glob('*.txt')))}")
    click.echo(f"  Strategies saved:  {len(list(STRATEGIES_DIR.glob('*.txt')))}")
    click.echo()


def list_prompts():
    """Lista los prompts guardados localmente."""
    files = list(PROMPTS_DIR.glob("*.txt"))
    if not files:
        click.echo("📭 No saved prompts. Use --prompt-file to load one.")
        return
    click.echo(f"\n📄 Saved Prompt Injections ({len(files)}):")
    for f in sorted(files):
        click.echo(f"  → {f.name} ({f.stat().st_size} bytes)")
    click.echo(f"\n  Folder: {PROMPTS_DIR}\n")