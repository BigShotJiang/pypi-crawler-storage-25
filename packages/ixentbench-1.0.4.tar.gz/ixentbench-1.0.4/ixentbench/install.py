# -*- coding: utf-8 -*-
"""
ixentbench/install.py
Lógica de bienvenida — se dispara la primera vez que el usuario
ejecuta cualquier comando ixentbench.
Crea ~/ixentbench/ con .env, README.html y env_configuration.html.
"""

import shutil
import pathlib

ENV_CONTENT = """\
# ─────────────────────────────────────────────────────────────
#  iXentBench — Player Configuration
#  ⚠️  Keep this file ONLY on your local machine.
#  ⚠️  NEVER share it, send it or upload it to anyone.
#  ⚠️  iXentLabs never downloads or accesses this file.
#      Your keys stay on your machine at all times.
#
#  HOW TO OPEN THIS FILE:
#  Mac:     Right click → Open With → TextEdit
#  Windows: Right click → Open With → Notepad
# ─────────────────────────────────────────────────────────────

# ── OPTION A: Cloud AI — BYOK (Bring Your Own Key) ───────────
#  Fill in only the key for the model you want to use.
#
#  Get your Gemini key at:    https://aistudio.google.com
GOOGLE_API_KEY=
#
#  Get your Anthropic key at: https://console.anthropic.com
ANTHROPIC_API_KEY=
#
#  Get your OpenAI key at:    https://platform.openai.com
OPENAI_API_KEY=

# ── OPTION B: Local Open Source Model ────────────────────────
#  Run Ollama, LM Studio or llama.cpp on your machine first.
#  Examples:
#    Ollama:    http://localhost:11434/v1
#    LM Studio: http://localhost:1234/v1
#    llama.cpp: http://localhost:8080/v1
#
LOCAL_MODEL_URL=

# ── OPTION C: Custom Agent Script ────────────────────────────
# Write your own Python agent and run it with:
#   ixentbench play --session IQWUWP --agent-script ./my_agent.py
#
# Your script receives the board state via stdin (JSON)
# and must return a move via stdout (JSON):
#   {"command": "G4@P21(b=0)+90", "reasoning": "..."}
#
# No API Key needed for custom agents.

# ── OPTION D: iXentLabs Sponsored ────────────────────────────
#  If you selected "Use iXentLabs credits" on the web,
#  leave all keys empty. The cloud handles everything.
# ─────────────────────────────────────────────────────────────
"""


def setup_player_folder() -> pathlib.Path:
    ixent_home = pathlib.Path.home() / "ixentbench"

    if ixent_home.exists():
        return ixent_home

    ixent_home.mkdir(parents=True)
    (ixent_home / "prompts").mkdir()
    (ixent_home / "strategies").mkdir()
    (ixent_home / ".env").write_text(ENV_CONTENT, encoding="utf-8")

    # Localizar archivos HTML dentro de la carpeta instalada del paquete
    pkg_dir = pathlib.Path(__file__).parent
    for filename in ["README.html", "env_configuration.html"]:
        src = pkg_dir / filename
        if src.exists():
            shutil.copy(src, ixent_home / filename)

    return ixent_home


def welcome_message(ixent_home: pathlib.Path):
    """Muestra el mensaje de bienvenida en el terminal."""
    print("\n" + "=" * 55)
    print("  ✅ iXentBench installed successfully!")
    print("=" * 55)
    print(f"\n  📁 Player folder:  {ixent_home}")
    print(f"  📖 Manual:         double-click README.html")
    print(f"  🔑 API Key setup:  double-click env_configuration.html")
    print(f"  📄 Config file:    .env  (add your API Key here)")
    print(f"\n  Next steps:")
    print(f"  1. Open your player folder:")
    print(f"     {ixent_home}")
    print(f"  2. Double-click env_configuration.html")
    print(f"  3. Follow the instructions to add your API Key")
    print(f"  4. Run from ANY folder:  ixentbench login")
    print(f"  5. Go to ixentlabs.com to create your session")
    print(f"  6. Run from ANY folder:  ixentbench play --session YOUR_SESSION_ID")
    print(f"\n  iXentLabs never accesses your keys or this folder.")
    print("=" * 55 + "\n")


def first_run_setup():
    """
    Punto de entrada — llamado desde cli.py antes de cualquier comando.
    Solo actúa la primera vez (cuando ~/ixentbench/ no existe).
    """
    ixent_home = pathlib.Path.home() / "ixentbench"
    if not ixent_home.exists():
        folder = setup_player_folder()
        welcome_message(folder)