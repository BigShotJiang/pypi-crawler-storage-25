# -*- coding: utf-8 -*-
"""
ixentbench/arena.py
Modo Arena — esqueleto completo listo para activar
cuando ixent-arena esté desplegado en Google Cloud Run.
"""

import click
import requests
from ixentbench.auth import get_firebase_token
from ixentbench.config import IXENT_SDK_URL, validate_env


def create_room(mode: str, level: int):
    """Crea una sala Arena y espera a los demás jugadores."""
    validate_env()
    click.echo(f"\n🎮 Creating Arena room — Mode: {mode.upper()} | Level: {level}")

    jwt     = get_firebase_token()
    headers = {"X-Firebase-Token": jwt, "Content-Type": "application/json"}

    resp = requests.post(f"{IXENT_SDK_URL}/arena/create", headers=headers, json={
        "mode":  mode,
        "level": level,
    }, timeout=30)

    if not resp.ok:
        click.echo(f"❌ Error creating room: {resp.text}", err=True)
        raise SystemExit(1)

    data      = resp.json()
    room_code = data.get("room_code")

    click.echo(f"\n✅ Room created!")
    click.echo(f"   Code: {room_code}")
    click.echo(f"\n   Share this code with your opponents:")
    click.echo(f"   ixentbench arena join --room {room_code}\n")
    click.echo("⏳ Waiting for players to join...")

    # TODO: polling hasta que todos estén listos + arranque automático
    # Se implementa cuando ixent-arena esté desplegado en GCP
    click.echo("\n⚠️  Arena multiplayer — coming soon!")


def join_room(room_code: str):
    """Se une a una sala Arena existente."""
    validate_env()
    click.echo(f"\n🎮 Joining Arena room: {room_code}")

    jwt     = get_firebase_token()
    headers = {"X-Firebase-Token": jwt, "Content-Type": "application/json"}

    resp = requests.post(f"{IXENT_SDK_URL}/arena/join", headers=headers, json={
        "room_code": room_code,
    }, timeout=30)

    if not resp.ok:
        click.echo(f"❌ Error joining room: {resp.text}", err=True)
        raise SystemExit(1)

    data = resp.json()
    click.echo(f"✅ Joined room {room_code} as {data.get('player_slot', '?')}")
    click.echo("⏳ Waiting for host to start the game...")

    # TODO: escucha de inicio + game loop Arena
    click.echo("\n⚠️  Arena multiplayer — coming soon!")