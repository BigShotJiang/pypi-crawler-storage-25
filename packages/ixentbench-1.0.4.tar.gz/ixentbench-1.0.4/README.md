# iXentBench — The AI Benchmark Beyond Memorization

Causal spatial reasoning at 4×10⁸⁵ scale, powered by **Caps i Caps** — the game that makes memorization impossible. 
Developed by [iXentLabs](https://ixentlabs.com) (iXent Games S.L.)

---

## Installation

```bash
pip install ixentbench
```

---

## Quick Start

**1. Configure your session** at [ixentlabs.com](https://ixentlabs.com)  
Login with Google, select benchmark type, level and AI model.  
Download your `.env` file and add your API Key.

**2. Run your session:**

```bash
ixentbench play --session YOUR_SESSION_ID
```

The visualizer opens automatically in your browser.

---

## Play Modes

There are four ways to play iXentBench, designed for every type of participant — from AI engineers to pure mathematicians and AI enthusiasts.

| Flag | A — BYOK | B — Local Model | C — Custom Agent | D — Sponsored |
|---|---|---|---|---|
| Uses LLM | ✅ Cloud API | ✅ Local | ❌ Pure code | ✅ iXentLabs |
| API Key needed | ✅ Yours | ❌ No | ❌ No | ❌ No |
| `--prompt-file` (optional) | ✅ Yes | ✅ Yes | ❌ No | ✅ Yes |
| `--strategy-file` (optional)| ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |

---

### A — BYOK (Bring Your Own Key)
Use your own API Key from Gemini, Claude, GPT, ...  
Your key **never leaves your machine** — it is read locally and never sent to our servers.

```bash
ixentbench play --session IQWUWP
```

`.env` file:
```
GOOGLE_API_KEY=your_key_here
```

---

### B — Local Open Source Model
Run any open source model (Llama, Mistral, Qwen...) locally using Ollama, LM Studio or llama.cpp.  
No API Key required. Full privacy — no data leaves your machine.  
⚠️ Inference speed metrics are excluded from global leaderboards (hardware-dependent).

```bash
# First start your local model, then:
ixentbench play --session IQWUWP --local-url http://localhost:11434/v1
```

---

### C — Custom Agent Script
For engineers and researchers who want to solve iXentBench using **pure code** — no LLM required.  
Write your own Python script using any algorithm you choose: Minimax, MCTS, A*, heuristics, neural networks trained from scratch — anything goes.

Your script receives the full board state via `stdin` (JSON) and must return a move via `stdout` (JSON). It runs entirely on your machine.

```bash
ixentbench play --session IQWUWP --agent-script ./my_agent.py
```

Your script must output:
```json
{"command": "G4@P21(b=0)+90", "reasoning": "Explanation of your decision"}
```

> 💡 **Tip:** Even if your agent uses pure code, we strongly recommend adding a `--strategy-file` to explain your approach. Top results are presented to AI companies for talent opportunities (see Talent Hub below).

---

### D — iXentLabs Sponsored
Select "Use iXentLabs credits" on the web — we provide the API Key.  
No `.env` file needed. The cloud handles everything.

```bash
ixentbench play --session IQWUWP
```

---

## Arena Mode (Multiplayer)

```bash
# Create a room (you become the host)
ixentbench arena create --mode 4v4 --level 2

# Join an existing room
ixentbench arena join --room IXENT-4X7K
```

Supported modes: `1v1`, `2v2`, `4v4`, `human` (Human vs AI).

---

## Prompt Injection & Strategy Files

### Prompt Injection (`--prompt-file`) — Optional
Inject your own strategic prompt directly into the AI's System Prompt before the game starts.  
Applies to modes **A, B and D** (LLM-based). Not applicable to mode C.

```bash
ixentbench play --session IQWUWP --prompt-file my_prompt.txt
```

> 💡 A well-crafted Prompt Injection can dramatically improve your AI's performance. Experiment freely — your injection is recorded alongside your results.

### Strategy File (`--strategy-file`) — Optional
A written description of your approach — how you designed your agent, what techniques you used, what insights guided your decisions.  
**It is never sent to the AI.** It is stored securely and linked to your results for the Talent Hub.

Applies to **all modes (A, B, C and D)**.

```bash
ixentbench play --session IQWUWP --strategy-file my_strategy.txt
```

> 💡 We strongly recommend always adding a Strategy File, especially for Custom Agents (mode C). It is your opportunity to showcase your thinking to the world's leading AI companies.

---

## 🏆 iXentLabs Talent Hub

iXentBench is more than a benchmark — it is a **talent discovery platform**.

With your explicit prior consent, iXentLabs will present the top results of each benchmark category to leading AI companies and research labs. This includes your performance metrics, your Prompt Injection (if any), and your Strategy File — giving organizations a rare window into the reasoning and engineering skills behind the results.

> Your personal data (name, email, payment details) is always protected and never shared.  
> Only anonymized benchmark data is presented, identified solely by your chosen nickname and avatar, unless you opt in to full visibility.

If you achieve an exceptional result and want your work to be seen by the teams building the future of AI — **iXentBench is your stage**.

---

## Utility Commands

```bash
ixentbench login          # Force Google re-authentication
ixentbench status         # Show credentials and session status
ixentbench prompts list   # List your locally saved prompt files
ixentbench --version      # Show version
```

---

## Security

- API Keys are **always read from your local `.env`** — never passed as arguments
- Google authentication uses **OAuth 2.0** — credentials saved locally in `~/ixentbench/`
- Game data (moves, reasoning, metrics) is stored by iXentLabs per our [Terms of Service](https://ixentlabs.com/terms)
- Personal data (name, email) is protected per [Privacy Policy](https://ixentlabs.com/privacy)

---

## Uninstall

```bash
pip uninstall ixentbench    # removes the SDK
rm -rf ~/ixentbench         # removes your player folder and API Keys
```
---

## License

Proprietary — © 2026 iXentLabs (iXent Games S.L.)  
Contact: contact@ixentlabs.com