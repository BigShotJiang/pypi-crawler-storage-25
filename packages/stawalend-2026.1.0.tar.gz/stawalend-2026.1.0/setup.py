"""
StawaLend - Natural Language Python Compiler
Author: Stanley Stawa
Version: 2026.1.0
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="stawalend",
    version="2026.1.0",
    author="Stanley Stawa",
    author_email="stanley.stawa@stawalend.dev",
    description="A revolutionary natural language Python compiler — blend .sl instructions with Python code.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/octaveluka/stawalend",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Topic :: Software Development :: Compilers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.9",
    install_requires=[
        "watchdog>=3.0.0",
        "requests>=2.31.0",
        "colorama>=0.4.6",
        "rich>=13.0.0",
    ],
    entry_points={
        "console_scripts": [
            "stawalend=stawalend.__main__:main",
        ],
    },
    include_package_data=True,
)
