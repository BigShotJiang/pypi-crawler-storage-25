"""
stawalend/core.py
=================
Compilation engine for StawaLend.

Responsibilities:
  - Parse .sl source files (Python lines + ~ natural-language instructions)
  - Incremental compilation with MD5 cache (only re-translate changed lines)
  - Token Saver: reuse previously translated identical instructions
  - AI translation via the Delfa API endpoint
  - Context injection: give the AI the already-generated code for continuity
  - Self-Healing: run generated code, capture stderr, auto-fix with AI
  - @command routing to stawalend/commands.py

Author : Stanley Stawa
Version: 2026.1.0
"""

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import requests
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text

from stawalend.commands import COMMAND_REGISTRY

# ── Constants ────────────────────────────────────────────────────────────────

CACHE_DIR = ".stawalend_cache"
CACHE_FILE = os.path.join(CACHE_DIR, "line_cache.json")        # MD5 → Python code
TOKEN_CACHE_FILE = os.path.join(CACHE_DIR, "token_cache.json") # Instruction text → Python code
HISTORY_FILE = os.path.join(CACHE_DIR, "history.json")         # Undo stack

API_ENDPOINT = "https://delfaapiai.vercel.app/ai/copilot"
DEFAULT_OUTPUT = "Stawa_output.py"
MAX_HEAL_ATTEMPTS = 3          # Self-Healing retry limit
REQUEST_TIMEOUT = 30           # seconds

console = Console()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _md5(text: str) -> str:
    """Return the MD5 hex-digest of a string."""
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def _load_json(path: str) -> dict:
    """Load a JSON file safely; return empty dict if missing or corrupt."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_json(path: str, data: dict) -> None:
    """Persist a dict to a JSON file."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _strip_markdown(text: str) -> str:
    """
    Remove Markdown code fences and any leading/trailing explanatory prose
    that the AI might accidentally include.
    """
    # Remove ```python ... ``` blocks (keep only the inner code)
    text = re.sub(r"```(?:python)?\n?", "", text)
    text = re.sub(r"```", "", text)
    # Remove lines that look like prose introductions (e.g. "Here is the code:")
    cleaned_lines = []
    for line in text.splitlines():
        if re.match(r"^(here|voici|voilà|below|this|sure|of course|certainly)[,: ]", line.lower()):
            continue
        cleaned_lines.append(line)
    return "\n".join(cleaned_lines).strip()


# ── AI Client ─────────────────────────────────────────────────────────────────

class AIClient:
    """Thin wrapper around the Delfa AI endpoint."""

    def __init__(self, endpoint: str = API_ENDPOINT):
        self.endpoint = endpoint

    def ask(self, prompt: str) -> str:
        """
        Send a prompt to the AI, return the cleaned Python code response.
        Raises RuntimeError if the request fails.
        """
        try:
            response = requests.get(
                self.endpoint,
                params={"message": prompt, "model": "default"},
                timeout=REQUEST_TIMEOUT,
            )
            response.raise_for_status()
            data = response.json()

            # Delfa API returns {"response": "..."} or {"result": "..."}
            raw = (
                data.get("response")
                or data.get("result")
                or data.get("content")
                or str(data)
            )
            return _strip_markdown(raw)

        except requests.RequestException as exc:
            raise RuntimeError(f"[StawaLend] API request failed: {exc}") from exc


# ── Compiler ──────────────────────────────────────────────────────────────────

class StawaCompiler:
    """
    Translates a .sl source file into a clean Stawa_output.py Python file.

    Workflow per save:
      1. Parse each line of the .sl file.
      2. For pure Python lines → pass through as-is.
      3. For `~ instruction` lines:
           a. Check token cache (same instruction text → reuse).
           b. Check MD5 line cache (same hash → reuse).
           c. Otherwise: build context-aware prompt → call AI → cache result.
      4. For `~ @command` lines → dispatch to COMMAND_REGISTRY.
      5. Write Stawa_output.py.
      6. Run Self-Healing: execute output, repair errors up to MAX_HEAL_ATTEMPTS.
    """

    def __init__(self):
        os.makedirs(CACHE_DIR, exist_ok=True)
        self.line_cache = _load_json(CACHE_FILE)
        self.token_cache = _load_json(TOKEN_CACHE_FILE)
        self.history: list[str] = _load_json(HISTORY_FILE) if os.path.exists(HISTORY_FILE) else []
        self.ai = AIClient()

    # ── Public API ────────────────────────────────────────────────────────────

    def compile(self, source_path: str, output_path: str = DEFAULT_OUTPUT) -> str:
        """
        Full compilation pipeline for the given .sl file.
        Returns the output file path.
        """
        # If the source is a .py file, auto-redirect output so we never
        # overwrite the original source file.
        src = Path(source_path)
        if src.suffix == ".py" and output_path == DEFAULT_OUTPUT:
            output_path = str(src.parent / (src.stem + "_stawa_output.py"))

        console.print(Panel(
            f"[bold cyan]⚡ StawaLend Compiler 2026[/bold cyan]\n"
            f"Source : [green]{source_path}[/green]\n"
            f"Output : [yellow]{output_path}[/yellow]",
            border_style="bright_blue",
        ))

        with open(source_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        output_blocks: list[str] = []
        generated_context = ""   # Accumulates all generated Python so far

        for i, raw_line in enumerate(lines, start=1):
            line = raw_line.rstrip("\n")
            stripped = line.strip()

            # ── Blank line or comment ─────────────────────────────────────
            if not stripped or stripped.startswith("#"):
                output_blocks.append(line)
                continue

            # ── StawaLend instruction ─────────────────────────────────────
            if stripped.startswith("~"):
                instruction_body = stripped[1:].strip()  # Everything after ~

                # @command dispatch
                if instruction_body.startswith("@"):
                    cmd_result = self._dispatch_command(
                        instruction_body, generated_context, output_path
                    )
                    if cmd_result:
                        output_blocks.append(f"# [StawaLend @cmd] {instruction_body}\n{cmd_result}")
                    continue

                # Regular natural-language instruction
                python_code = self._translate_instruction(
                    instruction=instruction_body,
                    context=generated_context,
                    line_number=i,
                )
                output_blocks.append(
                    f"# [StawaLend] {instruction_body}\n{python_code}"
                )
                generated_context += f"\n{python_code}"
                console.print(f"  [green]✓[/green] Line {i}: [italic]{instruction_body[:60]}[/italic]")

            # ── Pure Python line ──────────────────────────────────────────
            else:
                output_blocks.append(line)
                generated_context += f"\n{line}"

        # Write output file
        final_code = "\n".join(output_blocks)
        self._write_output(output_path, final_code)

        # Persist caches
        _save_json(CACHE_FILE, self.line_cache)
        _save_json(TOKEN_CACHE_FILE, self.token_cache)
        self._push_history(final_code)

        console.print(f"\n[bold green]✅ Compiled → {output_path}[/bold green]")

        # Self-Healing
        self._self_heal(output_path, lines)

        return output_path

    # ── Translation ───────────────────────────────────────────────────────────

    def _translate_instruction(
        self, instruction: str, context: str, line_number: int
    ) -> str:
        """
        Translate one natural-language instruction to Python.
        Uses token cache → MD5 cache → AI API (in that order).
        """
        line_hash = _md5(instruction)

        # 1. Token cache: exact same instruction text
        if instruction in self.token_cache:
            console.print(f"  [dim]💾 Token cache hit: {instruction[:50]}[/dim]")
            return self.token_cache[instruction]

        # 2. MD5 line cache
        if line_hash in self.line_cache:
            console.print(f"  [dim]📦 MD5 cache hit (line {line_number})[/dim]")
            return self.line_cache[line_hash]

        # 3. Call AI
        console.print(f"  [yellow]🤖 Calling AI for line {line_number}...[/yellow]")
        prompt = self._build_prompt(instruction, context)
        code = self.ai.ask(prompt)

        # Cache results
        self.line_cache[line_hash] = code
        self.token_cache[instruction] = code

        return code

    def _build_prompt(self, instruction: str, context: str) -> str:
        """
        Build a rich, context-aware prompt so the AI generates coherent code.
        """
        ctx_block = (
            f"\n\n# --- Already generated Python code (for context) ---\n{context}\n"
            f"# --- End of context ---\n"
            if context.strip()
            else ""
        )
        return (
            "You are a Python code generator embedded inside the StawaLend compiler. "
            "Rules you MUST follow strictly:\n"
            "1. Reply ONLY with valid, executable Python code.\n"
            "2. Do NOT include any Markdown formatting (no ```python, no ```).\n"
            "3. Do NOT include any explanatory text, comments, or preamble.\n"
            "4. The code must be compatible with the existing variables and functions already defined.\n"
            "5. Optimize for clarity and efficiency.\n"
            f"{ctx_block}"
            f"\nTask: {instruction}"
        )

    # ── @Command Dispatcher ───────────────────────────────────────────────────

    def _dispatch_command(
        self, cmd_string: str, context: str, output_path: str
    ) -> Optional[str]:
        """
        Parse @command_name [args] and route to the COMMAND_REGISTRY.
        Returns a string to inject into the output (or None).
        """
        parts = cmd_string[1:].split(maxsplit=1)   # Strip leading @
        cmd_name = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        handler = COMMAND_REGISTRY.get(cmd_name)
        if handler is None:
            console.print(f"  [red]⚠ Unknown @command: @{cmd_name}[/red]")
            return None

        console.print(f"  [magenta]⚙ Executing @{cmd_name}[/magenta]")
        return handler(
            args=args,
            context=context,
            output_path=output_path,
            ai_client=self.ai,
            compiler=self,
        )

    # ── Self-Healing ──────────────────────────────────────────────────────────

    def _self_heal(self, output_path: str, original_lines: list[str]) -> None:
        """
        Run Stawa_output.py and repair errors automatically.
        Loops up to MAX_HEAL_ATTEMPTS times.
        """
        for attempt in range(1, MAX_HEAL_ATTEMPTS + 1):
            result = subprocess.run(
                [sys.executable, output_path],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                console.print("[bold green]🏥 Self-Healing: No errors detected.[/bold green]")
                return

            stderr = result.stderr.strip()
            console.print(
                Panel(
                    f"[red]💥 Runtime Error (attempt {attempt}/{MAX_HEAL_ATTEMPTS}):[/red]\n{stderr}",
                    border_style="red",
                )
            )

            # Ask the AI to fix the broken code
            with open(output_path, "r", encoding="utf-8") as f:
                broken_code = f.read()

            fix_prompt = (
                "You are a Python debugging expert inside the StawaLend Self-Healing engine.\n"
                "The following Python code produced a runtime error. Fix it.\n"
                "Rules:\n"
                "1. Return ONLY the corrected, complete Python code.\n"
                "2. No Markdown, no explanations, no preamble.\n"
                f"\n# Broken code:\n{broken_code}\n"
                f"\n# Error:\n{stderr}\n"
                "\nFixed code:"
            )

            try:
                fixed_code = self.ai.ask(fix_prompt)
                self._write_output(output_path, fixed_code)
                console.print(f"  [yellow]🔧 Applied AI fix (attempt {attempt})[/yellow]")
            except RuntimeError as exc:
                console.print(f"  [red]AI fix failed: {exc}[/red]")
                return

        console.print("[red]⛔ Self-Healing exhausted — manual fix required.[/red]")

    # ── Undo / History ────────────────────────────────────────────────────────

    def _push_history(self, code: str) -> None:
        """Save the current compiled output to the undo stack."""
        self.history.append(code)
        if len(self.history) > 20:          # Keep last 20 versions
            self.history = self.history[-20:]
        _save_json(HISTORY_FILE, self.history)

    def undo(self, output_path: str = DEFAULT_OUTPUT) -> bool:
        """Restore the previous compiled version. Returns True on success."""
        self.history = _load_json(HISTORY_FILE) if isinstance(_load_json(HISTORY_FILE), list) else []
        if len(self.history) < 2:
            console.print("[yellow]⚠ No previous version to restore.[/yellow]")
            return False
        self.history.pop()                  # Remove current
        previous = self.history[-1]
        self._write_output(output_path, previous)
        _save_json(HISTORY_FILE, self.history)
        console.print(f"[green]↩ Restored previous version → {output_path}[/green]")
        return True

    # ── I/O ───────────────────────────────────────────────────────────────────

    @staticmethod
    def _write_output(path: str, code: str) -> None:
        """Write the final Python code to the output file."""
        header = (
            "# ============================================================\n"
            "# Generated by StawaLend 2026 — Author: Stanley Stawa\n"
            f"# Compiled at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            "# DO NOT EDIT MANUALLY — Edit the .sl source file instead.\n"
            "# ============================================================\n\n"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(header + code)
