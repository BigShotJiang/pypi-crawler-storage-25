"""
StawaLend — Natural Language Python Compiler
Author : Stanley Stawa
Version: 2026.1.0

Usage:
    >>> import stawalend
    >>> stawalend.watch("myfile.sl")   # Live watch mode
    >>> stawalend.compile("myfile.sl") # One-shot compile
"""

from stawalend.core import StawaCompiler
from stawalend.watcher import StawaWatcher

__version__ = "2026.1.0"
__author__ = "Stanley Stawa"
__all__ = ["StawaCompiler", "StawaWatcher", "watch", "compile_file"]


def watch(filepath: str) -> None:
    """Start live-watch mode on a .sl file. Recompiles on every Ctrl+S."""
    watcher = StawaWatcher(filepath)
    watcher.start()


def compile_file(filepath: str, output: str = "Stawa_output.py") -> str:
    """One-shot compile a .sl file to Python. Returns the output path."""
    compiler = StawaCompiler()
    return compiler.compile(filepath, output)
