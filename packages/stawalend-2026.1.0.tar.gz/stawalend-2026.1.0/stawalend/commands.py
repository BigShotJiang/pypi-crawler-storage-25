"""
stawalend/commands.py
=====================
Registry of all 100 StawaLend @commands.

Each command is a callable with the signature:
    handler(args, context, output_path, ai_client, compiler) -> Optional[str]

  args        : Any text following the @command name on the same line
  context     : The Python code generated so far in this compile pass
  output_path : Path to the current Stawa_output.py
  ai_client   : An AIClient instance (from core.py) for AI-powered commands
  compiler    : The StawaCompiler instance (grants access to undo, caches…)

Return a string to inject a comment/code block into the output, or None.

Author : Stanley Stawa
Version: 2026.1.0
"""

from __future__ import annotations

import ast
import keyword
import os
import re
import subprocess
import sys
import textwrap
import time
from typing import TYPE_CHECKING, Callable, Optional

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

if TYPE_CHECKING:
    from stawalend.core import AIClient, StawaCompiler

console = Console()

# Type alias
CommandHandler = Callable[..., Optional[str]]


# ══════════════════════════════════════════════════════════════════════════════
# UTILITY HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _read_output(output_path: str) -> str:
    try:
        with open(output_path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""


def _ai_analyse(prompt: str, ai_client: "AIClient") -> str:
    try:
        return ai_client.ask(prompt)
    except RuntimeError as exc:
        return f"# AI error: {exc}"


def _banner(title: str, content: str, style: str = "cyan") -> None:
    console.print(Panel(content, title=f"[bold]{title}[/bold]", border_style=style))


# ══════════════════════════════════════════════════════════════════════════════
# CORE COMMANDS (Priority: @debug, @fix, @safe, @undo + 96 more)
# ══════════════════════════════════════════════════════════════════════════════

# ── @debug ────────────────────────────────────────────────────────────────────
def cmd_debug(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Analyse current generated code and display an optimisation report."""
    code = _read_output(output_path)
    if not code.strip():
        console.print("[yellow]@debug: No generated code yet.[/yellow]")
        return None

    prompt = (
        "You are a senior Python code reviewer inside StawaLend.\n"
        "Analyse the following code and produce a concise optimisation report.\n"
        "Cover: performance, naming, complexity, unused variables, potential bugs.\n"
        "Format your answer as a numbered list. Use plain text only, no Markdown.\n\n"
        f"Code:\n{code}"
    )
    report = _ai_analyse(prompt, ai_client)
    _banner("🔍 @debug Report", report, style="blue")
    return f"# [StawaLend @debug]\n# {chr(10).join('# ' + l for l in report.splitlines())}"


# ── @fix ──────────────────────────────────────────────────────────────────────
def cmd_fix(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Force the AI to analyse and repair the current generated code block."""
    code = _read_output(output_path)
    prompt = (
        "You are a Python bug-fixer inside StawaLend.\n"
        "The code below may contain bugs, logic errors, or bad practices. Fix everything.\n"
        "Return ONLY the corrected, complete Python code. No Markdown, no explanations.\n\n"
        f"Code:\n{code}"
    )
    fixed = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(fixed)
    console.print("[green]@fix: Code repaired and written to output.[/green]")
    return None


# ── @safe ─────────────────────────────────────────────────────────────────────
DANGEROUS_PATTERNS = [
    r"\bos\.system\b", r"\bsubprocess\.run\b", r"\bsubprocess\.call\b",
    r"\beval\b", r"\bexec\b", r"\b__import__\b", r"\bopen\b.*['\"]w['\"]",
    r"\bshutil\.rmtree\b", r"\bos\.remove\b", r"\bos\.unlink\b",
    r"\bos\.rmdir\b", r"\bsocket\b", r"\bctypes\b", r"\bpickle\.load\b",
]

def cmd_safe(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Sandbox scan: detect dangerous system calls in generated code."""
    code = _read_output(output_path)
    findings = []
    for i, line in enumerate(code.splitlines(), 1):
        for pat in DANGEROUS_PATTERNS:
            if re.search(pat, line):
                findings.append(f"  Line {i:>4}: [{pat}] → {line.strip()}")

    if findings:
        _banner(
            "🚨 @safe — Security Alert",
            "\n".join(findings),
            style="red",
        )
        return f"# [StawaLend @safe] WARNING — dangerous patterns detected:\n" + \
               "\n".join(f"# {f}" for f in findings)
    else:
        console.print("[green]@safe: No dangerous patterns detected. ✅[/green]")
        return "# [StawaLend @safe] PASS — no dangerous patterns detected."


# ── @undo ─────────────────────────────────────────────────────────────────────
def cmd_undo(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Restore the previous compiled version from the cache."""
    compiler.undo(output_path)
    return None


# ── @explain ──────────────────────────────────────────────────────────────────
def cmd_explain(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Ask the AI to explain what the generated code does in plain language."""
    code = context or _read_output(output_path)
    prompt = (
        "Explain the following Python code in simple, clear language. "
        "Be concise. Use bullet points. No Markdown fences.\n\n"
        f"Code:\n{code}"
    )
    explanation = _ai_analyse(prompt, ai_client)
    _banner("📖 @explain", explanation, style="cyan")
    return None


# ── @test ─────────────────────────────────────────────────────────────────────
def cmd_test(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Generate pytest unit tests for the current output code."""
    code = _read_output(output_path)
    prompt = (
        "Write comprehensive pytest unit tests for the following Python code.\n"
        "Return ONLY valid Python test code. No Markdown, no explanations.\n\n"
        f"Code:\n{code}"
    )
    tests = _ai_analyse(prompt, ai_client)
    test_path = output_path.replace(".py", "_test.py")
    with open(test_path, "w", encoding="utf-8") as f:
        f.write(f"# Generated by StawaLend @test\n{tests}")
    console.print(f"[green]@test: Test file written → {test_path}[/green]")
    return None


# ── @run ──────────────────────────────────────────────────────────────────────
def cmd_run(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Execute the current Stawa_output.py and display stdout/stderr."""
    result = subprocess.run(
        [sys.executable, output_path],
        capture_output=True, text=True, timeout=30
    )
    _banner("▶ @run — stdout", result.stdout or "(no output)", style="green")
    if result.stderr:
        _banner("▶ @run — stderr", result.stderr, style="red")
    return None


# ── @lint ─────────────────────────────────────────────────────────────────────
def cmd_lint(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Run syntax validation (ast.parse) on the output file."""
    code = _read_output(output_path)
    try:
        ast.parse(code)
        console.print("[green]@lint: Syntax OK ✅[/green]")
        return "# [StawaLend @lint] Syntax OK"
    except SyntaxError as e:
        msg = f"SyntaxError at line {e.lineno}: {e.msg}"
        console.print(f"[red]@lint: {msg}[/red]")
        return f"# [StawaLend @lint] ERROR: {msg}"


# ── @optimize ─────────────────────────────────────────────────────────────────
def cmd_optimize(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Rewrite the output code for maximum performance."""
    code = _read_output(output_path)
    prompt = (
        "Rewrite the following Python code for maximum performance and Pythonic clarity.\n"
        "Return ONLY the optimised Python code. No Markdown, no explanations.\n\n"
        f"Code:\n{code}"
    )
    optimised = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(optimised)
    console.print("[green]@optimize: Code optimised.[/green]")
    return None


# ── @refactor ─────────────────────────────────────────────────────────────────
def cmd_refactor(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Refactor the code for readability and maintainability."""
    code = _read_output(output_path)
    prompt = (
        "Refactor the following Python code for better readability and maintainability.\n"
        "Apply PEP-8, extract functions where relevant, add type hints.\n"
        "Return ONLY the refactored Python code. No Markdown, no explanations.\n\n"
        f"Code:\n{code}"
    )
    refactored = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(refactored)
    console.print("[green]@refactor: Code refactored.[/green]")
    return None


# ── @docs ─────────────────────────────────────────────────────────────────────
def cmd_docs(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Add Google-style docstrings to every function in the output."""
    code = _read_output(output_path)
    prompt = (
        "Add comprehensive Google-style docstrings to every function and class "
        "in the following Python code. Return ONLY the documented code.\n\n"
        f"Code:\n{code}"
    )
    documented = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(documented)
    console.print("[green]@docs: Docstrings added.[/green]")
    return None


# ── @types ────────────────────────────────────────────────────────────────────
def cmd_types(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Add Python type hints (PEP 484) to all functions."""
    code = _read_output(output_path)
    prompt = (
        "Add complete PEP-484 type annotations to all function signatures "
        "in the following Python code. Return ONLY the typed code.\n\n"
        f"Code:\n{code}"
    )
    typed = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(typed)
    console.print("[green]@types: Type hints added.[/green]")
    return None


# ── @vars ─────────────────────────────────────────────────────────────────────
def cmd_vars(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """List all variables defined in the generated context."""
    code = context or _read_output(output_path)
    try:
        tree = ast.parse(code)
    except SyntaxError:
        console.print("[yellow]@vars: Could not parse code.[/yellow]")
        return None

    names = sorted({
        node.id for node in ast.walk(tree)
        if isinstance(node, ast.Name) and not keyword.iskeyword(node.id)
    })
    table = Table(title="Variables in context", show_lines=True)
    table.add_column("Name", style="cyan")
    for n in names:
        table.add_row(n)
    console.print(table)
    return None


# ── @summary ──────────────────────────────────────────────────────────────────
def cmd_summary(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Print a one-paragraph summary of what the program does."""
    code = _read_output(output_path)
    prompt = (
        "In one paragraph, describe what this Python program does. "
        "Plain text only, no Markdown.\n\nCode:\n" + code
    )
    summary = _ai_analyse(prompt, ai_client)
    _banner("📋 @summary", summary, style="cyan")
    return None


# ── @complexity ───────────────────────────────────────────────────────────────
def cmd_complexity(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Estimate time and space complexity of the main algorithm."""
    code = _read_output(output_path)
    prompt = (
        "Analyse the time and space complexity of the following Python code. "
        "Be precise. Plain text only.\n\nCode:\n" + code
    )
    analysis = _ai_analyse(prompt, ai_client)
    _banner("⏱ @complexity", analysis, style="yellow")
    return None


# ── @translate ────────────────────────────────────────────────────────────────
def cmd_translate(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Translate the code to another language (default: JavaScript)."""
    target_lang = args.strip() or "JavaScript"
    code = _read_output(output_path)
    prompt = (
        f"Translate the following Python code to {target_lang}.\n"
        "Return ONLY the translated code. No Markdown, no explanations.\n\n"
        f"Code:\n{code}"
    )
    translated = _ai_analyse(prompt, ai_client)
    out_path = output_path.replace(".py", f"_{target_lang.lower()}.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(translated)
    console.print(f"[green]@translate: Written → {out_path}[/green]")
    return None


# ── @mock ─────────────────────────────────────────────────────────────────────
def cmd_mock(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Generate mock/stub data for the current functions."""
    code = _read_output(output_path)
    prompt = (
        "Generate realistic mock data and stub implementations for all functions "
        "in the following Python code. Return ONLY Python code.\n\nCode:\n" + code
    )
    mocks = _ai_analyse(prompt, ai_client)
    mock_path = output_path.replace(".py", "_mocks.py")
    with open(mock_path, "w", encoding="utf-8") as f:
        f.write(mocks)
    console.print(f"[green]@mock: Mock file → {mock_path}[/green]")
    return None


# ── @benchmark ────────────────────────────────────────────────────────────────
def cmd_benchmark(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Inject timeit benchmarking around the main logic."""
    code = _read_output(output_path)
    prompt = (
        "Wrap the main logic of the following Python code with timeit benchmarking. "
        "Return ONLY the benchmarked Python code.\n\nCode:\n" + code
    )
    benchmarked = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(benchmarked)
    console.print("[green]@benchmark: Benchmarking injected.[/green]")
    return None


# ── @profile ──────────────────────────────────────────────────────────────────
def cmd_profile(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Run cProfile on the output file and display top 20 entries."""
    import cProfile, pstats, io
    profiler = cProfile.Profile()
    profiler.enable()
    exec(open(output_path).read(), {})
    profiler.disable()
    stream = io.StringIO()
    ps = pstats.Stats(profiler, stream=stream).sort_stats("cumulative")
    ps.print_stats(20)
    _banner("📊 @profile", stream.getvalue(), style="magenta")
    return None


# ── @convert_async ────────────────────────────────────────────────────────────
def cmd_convert_async(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Convert synchronous I/O calls to async/await."""
    code = _read_output(output_path)
    prompt = (
        "Convert all synchronous I/O calls in the following Python code to async/await. "
        "Return ONLY the async Python code.\n\nCode:\n" + code
    )
    async_code = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(async_code)
    console.print("[green]@convert_async: Async conversion done.[/green]")
    return None


# ── @env ──────────────────────────────────────────────────────────────────────
def cmd_env(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Generate a .env.example file from os.getenv() calls in the code."""
    code = _read_output(output_path)
    env_vars = re.findall(r'os\.getenv\(["\'](\w+)["\']', code)
    env_vars += re.findall(r'os\.environ\[["\'](\w+)["\']', code)
    env_vars = sorted(set(env_vars))
    if not env_vars:
        console.print("[yellow]@env: No environment variables found.[/yellow]")
        return None
    content = "\n".join(f"{v}=" for v in env_vars)
    with open(".env.example", "w") as f:
        f.write(content + "\n")
    console.print(f"[green]@env: .env.example written ({len(env_vars)} vars).[/green]")
    return None


# ── @readme ───────────────────────────────────────────────────────────────────
def cmd_readme(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Generate a README.md for the current project."""
    code = _read_output(output_path)
    prompt = (
        "Write a professional README.md in Markdown for a Python project "
        "whose main code is below. Include: description, installation, usage, examples.\n\n"
        f"Code:\n{code}"
    )
    readme = _ai_analyse(prompt, ai_client)
    with open("README_generated.md", "w", encoding="utf-8") as f:
        f.write(readme)
    console.print("[green]@readme: README_generated.md created.[/green]")
    return None


# ── @dataclass ────────────────────────────────────────────────────────────────
def cmd_dataclass(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
    """Convert plain classes into @dataclass versions."""
    code = _read_output(output_path)
    prompt = (
        "Convert all plain classes in the following Python code to use @dataclass. "
        "Return ONLY the converted Python code.\n\nCode:\n" + code
    )
    converted = _ai_analyse(prompt, ai_client)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(converted)
    console.print("[green]@dataclass: Classes converted to @dataclass.[/green]")
    return None


# ── Placeholder factory for remaining commands ────────────────────────────────

def _make_placeholder(name: str, description: str) -> CommandHandler:
    """Generate a generic handler that logs the command and calls the AI."""
    def handler(args, context, output_path, ai_client, compiler, **_) -> Optional[str]:
        console.print(f"[cyan]@{name}[/cyan]: {description}")
        prompt = (
            f"You are inside StawaLend. The user executed the @{name} command.\n"
            f"Description: {description}\n"
            f"Args: {args or 'none'}\n\n"
            f"Current code context:\n{context or _read_output(output_path)}\n\n"
            "Perform the requested action and return ONLY valid Python code, or a plain-text report."
        )
        result = _ai_analyse(prompt, ai_client)
        _banner(f"@{name}", result, style="magenta")
        return f"# [StawaLend @{name}]\n# {result[:200]}"
    handler.__name__ = f"cmd_{name}"
    return handler


# ══════════════════════════════════════════════════════════════════════════════
# COMMAND REGISTRY — 100 commands
# ══════════════════════════════════════════════════════════════════════════════

COMMAND_REGISTRY: dict[str, CommandHandler] = {
    # Priority commands (fully implemented above)
    "debug":         cmd_debug,
    "fix":           cmd_fix,
    "safe":          cmd_safe,
    "undo":          cmd_undo,
    "explain":       cmd_explain,
    "test":          cmd_test,
    "run":           cmd_run,
    "lint":          cmd_lint,
    "optimize":      cmd_optimize,
    "refactor":      cmd_refactor,
    "docs":          cmd_docs,
    "types":         cmd_types,
    "vars":          cmd_vars,
    "summary":       cmd_summary,
    "complexity":    cmd_complexity,
    "translate":     cmd_translate,
    "mock":          cmd_mock,
    "benchmark":     cmd_benchmark,
    "profile":       cmd_profile,
    "convert_async": cmd_convert_async,
    "env":           cmd_env,
    "readme":        cmd_readme,
    "dataclass":     cmd_dataclass,

    # Extended commands (AI-powered via placeholder factory)
    "comment":       _make_placeholder("comment",       "Add inline comments to every logic block"),
    "clean":         _make_placeholder("clean",         "Remove dead code, unused imports, redundant variables"),
    "import_sort":   _make_placeholder("import_sort",   "Sort and deduplicate import statements"),
    "pep8":          _make_placeholder("pep8",          "Auto-format code to PEP-8 standard"),
    "version":       _make_placeholder("version",       "Print the StawaLend version and AI endpoint info"),
    "stats":         _make_placeholder("stats",         "Show line count, function count, class count"),
    "compress":      _make_placeholder("compress",      "Minify the generated Python code"),
    "expand":        _make_placeholder("expand",        "Expand one-liners into readable multi-line code"),
    "log":           _make_placeholder("log",           "Inject logging statements at key points"),
    "exception":     _make_placeholder("exception",     "Add try/except error handling to risky operations"),
    "retry":         _make_placeholder("retry",         "Wrap network/IO calls with exponential backoff retry"),
    "cache_clear":   _make_placeholder("cache_clear",   "Clear the StawaLend MD5 and token caches"),
    "diff":          _make_placeholder("diff",          "Show diff between current output and previous undo version"),
    "snapshot":      _make_placeholder("snapshot",      "Create a named snapshot of the current output"),
    "restore":       _make_placeholder("restore",       "Restore a named snapshot by label"),
    "history":       _make_placeholder("history",       "List all past compiled versions"),
    "export":        _make_placeholder("export",        "Export the .sl source as a Jupyter notebook"),
    "flowchart":     _make_placeholder("flowchart",     "Generate ASCII flowchart of the program logic"),
    "uml":           _make_placeholder("uml",           "Generate PlantUML class diagram from code"),
    "api_mock":      _make_placeholder("api_mock",      "Generate a mock Flask/FastAPI server from functions"),
    "cli":           _make_placeholder("cli",           "Wrap main functions with argparse CLI interface"),
    "gui":           _make_placeholder("gui",           "Generate a Tkinter GUI skeleton for the program"),
    "schema":        _make_placeholder("schema",        "Infer and generate JSON Schema from data structures"),
    "validate":      _make_placeholder("validate",      "Add pydantic/marshmallow input validation"),
    "sql":           _make_placeholder("sql",           "Generate SQL CREATE TABLE from Python class structures"),
    "orm":           _make_placeholder("orm",           "Convert plain SQL calls to SQLAlchemy ORM"),
    "migrate":       _make_placeholder("migrate",       "Generate an Alembic migration script"),
    "seed":          _make_placeholder("seed",          "Generate database seed data from data structures"),
    "docker":        _make_placeholder("docker",        "Generate a Dockerfile for the project"),
    "ci":            _make_placeholder("ci",            "Generate a GitHub Actions CI/CD workflow"),
    "makefile":      _make_placeholder("makefile",      "Generate a Makefile with common dev tasks"),
    "requirements":  _make_placeholder("requirements",  "Infer and write requirements.txt"),
    "venv":          _make_placeholder("venv",          "Print venv setup instructions for this project"),
    "secrets":       _make_placeholder("secrets",       "Detect hardcoded secrets/passwords in the code"),
    "cve":           _make_placeholder("cve",           "Check dependencies for known CVEs"),
    "coverage":      _make_placeholder("coverage",      "Estimate test coverage of the generated code"),
    "fuzz":          _make_placeholder("fuzz",          "Generate fuzz-testing inputs for functions"),
    "contract":      _make_placeholder("contract",      "Add Design-by-Contract assertions (pre/post conditions)"),
    "immutable":     _make_placeholder("immutable",     "Convert mutable structures to frozen/immutable equivalents"),
    "singleton":     _make_placeholder("singleton",     "Apply Singleton design pattern to main class"),
    "observer":      _make_placeholder("observer",      "Inject Observer pattern event hooks"),
    "factory":       _make_placeholder("factory",       "Apply Factory design pattern to constructors"),
    "decorator":     _make_placeholder("decorator",     "Wrap key functions with a timing/logging decorator"),
    "context_mgr":   _make_placeholder("context_mgr",  "Convert resource usage to context managers (with)"),
    "generator":     _make_placeholder("generator",     "Convert list-returning functions to generators"),
    "comprehension": _make_placeholder("comprehension",  "Convert loops to list/dict/set comprehensions"),
    "walrus":        _make_placeholder("walrus",        "Apply Python 3.8+ walrus operator where applicable"),
    "match":         _make_placeholder("match",         "Convert if/elif chains to match/case statements"),
    "f_strings":     _make_placeholder("f_strings",     "Convert .format() and % strings to f-strings"),
    "slots":         _make_placeholder("slots",         "Add __slots__ to all classes for memory efficiency"),
    "abc":           _make_placeholder("abc",           "Convert base classes to ABCs with abstract methods"),
    "protocol":      _make_placeholder("protocol",      "Generate typing.Protocol interfaces from usage"),
    "parallel":      _make_placeholder("parallel",      "Parallelise independent loops with concurrent.futures"),
    "thread":        _make_placeholder("thread",        "Convert blocking code to threading.Thread"),
    "queue":         _make_placeholder("queue",         "Introduce a producer-consumer queue pattern"),
    "chunk":         _make_placeholder("chunk",         "Split large data processing into batched chunks"),
    "stream":        _make_placeholder("stream",        "Refactor to streaming/lazy evaluation"),
    "memory":        _make_placeholder("memory",        "Reduce memory footprint with generators and slots"),
    "serialize":     _make_placeholder("serialize",     "Add JSON/pickle serialisation to main classes"),
    "compress_data": _make_placeholder("compress_data", "Compress output data with gzip/lzma"),
    "encrypt":       _make_placeholder("encrypt",       "Add AES encryption to sensitive data fields"),
    "hash":          _make_placeholder("hash",          "Add SHA-256 hashing to string fields"),
    "base64":        _make_placeholder("base64",        "Encode/decode binary fields with base64"),
    "rate_limit":    _make_placeholder("rate_limit",    "Add rate-limiting decorator to API call functions"),
    "timeout":       _make_placeholder("timeout",       "Add timeout decorator to long-running functions"),
    "circuit":       _make_placeholder("circuit",       "Apply circuit-breaker pattern to external calls"),
    "health":        _make_placeholder("health",        "Add a /health check endpoint if web framework detected"),
    "metrics":       _make_placeholder("metrics",       "Inject Prometheus metrics counters/histograms"),
    "trace":         _make_placeholder("trace",         "Add OpenTelemetry tracing spans"),
    "i18n":          _make_placeholder("i18n",          "Wrap string literals with gettext for internationalisation"),
    "locale":        _make_placeholder("locale",        "Add locale-aware date/number formatting"),
    "config":        _make_placeholder("config",        "Extract magic numbers to a config.py constants file"),
    "feature_flag":  _make_placeholder("feature_flag",  "Wrap features with feature-flag toggles"),
    "ab_test":       _make_placeholder("ab_test",       "Add A/B testing variant selection logic"),
    "audit":         _make_placeholder("audit",         "Inject audit-log calls for state-changing functions"),
    "dry_run":       _make_placeholder("dry_run",       "Add --dry-run flag support to all destructive operations"),
    "verbose":       _make_placeholder("verbose",       "Add --verbose/--quiet logging level control"),
    "pretty_print":  _make_placeholder("pretty_print",  "Replace print() calls with rich/pprint formatting"),
    "progress":      _make_placeholder("progress",      "Add rich progress bars to loop-heavy operations"),
    "table":         _make_placeholder("table",         "Render list/dict data as rich terminal tables"),
    "chart":         _make_placeholder("chart",         "Generate matplotlib charts from numeric data"),
    "csv":           _make_placeholder("csv",           "Add CSV export capability to data-producing functions"),
    "excel":         _make_placeholder("excel",         "Add openpyxl Excel export to data structures"),
    "json_api":      _make_placeholder("json_api",      "Add JSON REST API layer with FastAPI"),
    "graphql":       _make_placeholder("graphql",       "Generate Strawberry GraphQL schema from classes"),
    "grpc":          _make_placeholder("grpc",          "Generate gRPC proto definitions from function signatures"),
    "webhook":       _make_placeholder("webhook",       "Add webhook dispatch on key events"),
    "email":         _make_placeholder("email",         "Add SMTP email notification capability"),
    "sms":           _make_placeholder("sms",           "Add Twilio SMS notification on critical events"),
    "push":          _make_placeholder("push",          "Add FCM push notification support"),
    "s3":            _make_placeholder("s3",            "Add AWS S3 file upload/download capability"),
    "gcs":           _make_placeholder("gcs",           "Add Google Cloud Storage integration"),
    "azure_blob":    _make_placeholder("azure_blob",    "Add Azure Blob Storage integration"),
    "redis":         _make_placeholder("redis",         "Add Redis caching layer to expensive functions"),
    "mongo":         _make_placeholder("mongo",         "Add PyMongo persistence layer"),
    "help":          _make_placeholder("help",          "List all available @commands with descriptions"),
}
