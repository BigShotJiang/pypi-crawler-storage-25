"""
stawalend/__main__.py
=====================
CLI entry point for StawaLend.

Usage:
    stawalend watch myfile.sl              # Live-watch mode (default)
    stawalend compile myfile.sl            # One-shot compile
    stawalend compile myfile.sl -o out.py  # Custom output path
    python -m stawalend watch myfile.sl    # Via python -m

Author : Stanley Stawa
Version: 2026.1.0
"""

import argparse
import sys

from rich.console import Console

console = Console()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="stawalend",
        description=(
            "StawaLend 2026 — Natural Language Python Compiler by Stanley Stawa.\n"
            "Mix Python and natural language instructions in .sl files."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  stawalend watch  program.sl\n"
            "  stawalend compile program.sl\n"
            "  stawalend compile program.sl -o my_output.py\n"
        ),
    )
    parser.add_argument("--version", action="version", version="StawaLend 2026.1.0")

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── watch ──────────────────────────────────────────────────────────────
    watch_parser = subparsers.add_parser(
        "watch", help="Watch a .sl file and recompile on every save (Ctrl+S)."
    )
    watch_parser.add_argument("file", help="Path to the .sl or .py source file")
    watch_parser.add_argument(
        "-o", "--output", default="Stawa_output.py",
        help="Output Python file (default: Stawa_output.py)"
    )

    # ── compile ────────────────────────────────────────────────────────────
    compile_parser = subparsers.add_parser(
        "compile", help="One-shot compile a .sl file to Python."
    )
    compile_parser.add_argument("file", help="Path to the .sl or .py source file")
    compile_parser.add_argument(
        "-o", "--output", default="Stawa_output.py",
        help="Output Python file (default: Stawa_output.py)"
    )

    args = parser.parse_args()

    if args.command == "watch":
        from stawalend.watcher import StawaWatcher
        watcher = StawaWatcher(args.file, args.output)
        watcher.start()

    elif args.command == "compile":
        from stawalend.core import StawaCompiler
        compiler = StawaCompiler()
        out = compiler.compile(args.file, args.output)
        console.print(f"[bold green]Done → {out}[/bold green]")


if __name__ == "__main__":
    main()
