"""
stawalend/watcher.py
====================
Real-time file watcher for StawaLend.

Uses the `watchdog` library to monitor a .sl source file.
On every save (file modification event), the compiler is triggered
automatically — simulating the Ctrl+S → instant feedback loop.

Author : Stanley Stawa
Version: 2026.1.0
"""

import os
import sys
import time
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer
from rich.console import Console
from rich.panel import Panel

from stawalend.core import StawaCompiler

console = Console()


# ── Event Handler ─────────────────────────────────────────────────────────────

class StawaFileHandler(FileSystemEventHandler):
    """
    Handles filesystem events for a specific .sl file.
    Triggers recompilation when the monitored file is modified.
    """

    def __init__(self, filepath: str, output: str = "Stawa_output.py"):
        super().__init__()
        self.filepath = os.path.abspath(filepath)
        self.output = output
        self.compiler = StawaCompiler()
        self._last_trigger = 0.0          # Debounce timestamp
        self._debounce_seconds = 0.5      # Ignore duplicate events within 500ms

    def on_modified(self, event: FileSystemEvent) -> None:
        """Called by watchdog whenever a file in the watched directory changes."""
        if event.is_directory:
            return
        if os.path.abspath(event.src_path) != self.filepath:
            return

        # Debounce: some editors emit 2–3 events per save
        now = time.time()
        if now - self._last_trigger < self._debounce_seconds:
            return
        self._last_trigger = now

        console.print(f"\n[bold cyan]🔄 Change detected → recompiling {Path(self.filepath).name}[/bold cyan]")
        try:
            self.compiler.compile(self.filepath, self.output)
        except Exception as exc:
            console.print(f"[red]Compilation error: {exc}[/red]")


# ── Watcher ───────────────────────────────────────────────────────────────────

class StawaWatcher:
    """
    Starts a background observer thread that watches a .sl file
    and recompiles it on every save.

    Usage:
        watcher = StawaWatcher("myfile.sl")
        watcher.start()       # Blocks forever (Ctrl+C to stop)
    """

    def __init__(self, filepath: str, output: str = "Stawa_output.py"):
        path = Path(filepath)
        if not path.exists():
            console.print(f"[red]⛔ File not found: {filepath}[/red]")
            sys.exit(1)
        if path.suffix not in (".sl", ".py"):
            console.print(f"[yellow]⚠ Warning: expected a .sl or .py file, got '{path.suffix}'[/yellow]")

        self.filepath = str(path.resolve())
        self.output = output
        self.watch_dir = str(path.parent.resolve())

    def start(self) -> None:
        """
        Begin watching the .sl file. Blocks until the user presses Ctrl+C.
        Performs an initial compile immediately on launch.
        """
        console.print(Panel(
            f"[bold green]👁 StawaLend Watcher Active[/bold green]\n"
            f"Watching : [cyan]{self.filepath}[/cyan]\n"
            f"Output   : [yellow]{self.output}[/yellow]\n\n"
            "[dim]Press Ctrl+C to stop.[/dim]",
            border_style="green",
        ))

        handler = StawaFileHandler(self.filepath, self.output)

        # Initial compile on start
        console.print("[dim]⚡ Initial compilation...[/dim]")
        try:
            handler.compiler.compile(self.filepath, self.output)
        except Exception as exc:
            console.print(f"[red]Initial compile error: {exc}[/red]")

        observer = Observer()
        observer.schedule(handler, path=self.watch_dir, recursive=False)
        observer.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            console.print("\n[yellow]👋 Watcher stopped.[/yellow]")
        finally:
            observer.stop()
            observer.join()
