import matplotlib.pyplot as plt
import matplotlib.patches as patches
from cycler import cycler
import os


base_config = {
    'figure': {
        'figsize': (12, 6),
        'dpi': 100,
        'edgecolor': 'white',
        'tight_layout': True,
        'window_title': 'dquant'
    },

    'font': {
        'family': 'DejaVu Sans',
        'size': 11,
        'weight': 'normal',
        'title_size': 14,
        'title_weight': 'bold',
        'label_size': 12,
        'label_weight': 'bold'
    },

    'line_cycle': ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFE194', '#BAA6DD'],

    'lines': {
        'linewidth': 2.5,
        'linestyle': '-',
        'markersize': 6,
        'marker': 'o',
        'markevery': 10,
        'alpha': 1.0
    },

    'legend': {
        'loc': 'best',
        'fontsize': 10,
        'framealpha': 0.9,
        'fancybox': True,
        'shadow': True,
        'borderpad': 0.5,
        'labelcolor': 'text.color'
    },

    'axes': {
        'spines_visible': True,
        'spines_linewidth': 1,
        'tick_direction': 'in',
        'tick_length': 6,
        'tick_width': 1
    },

    'save': {
        'format': 'png',
        'dpi': 300,
        'bbox_inches': 'tight',
        'pad_inches': 0.1,
        'transparent': False,
        'facecolor': 'auto'
    }
}

light_theme = {
    'name': 'light',
    'figure': {
        'facecolor': '#f8f9fa',
    },
    'colors': {
        'primary': '#FF6B6B',
        'secondary': '#4ECDC4',
        'tertiary': '#45B7D1',
        'quaternary': '#96CEB4',
        'background': '#f8f9fa',
        'grid': '#dddddd',
        'text': '#2c3e50',
        'spines': '#2c3e50',
        'brand': '#2c3e50',
        'legend_bg': '#ffffff',
        'legend_edge': '#cccccc'
    },
    'grid': {
        'visible': True,
        'alpha': 0.3,
        'linestyle': '--',
        'linewidth': 0.5,
        'color': '#dddddd',
        'which': 'both'
    }
}

dark_theme = {
    'name': 'dark',
    'figure': {
        'facecolor': '#1a2634',
    },
    'colors': {
        'primary': '#FF6B6B',
        'secondary': '#4ECDC4',
        'tertiary': '#45B7D1',
        'quaternary': '#96CEB4',
        'background': '#2c3e50',
        'grid': '#4a5b6e',
        'text': '#ecf0f1',
        'spines': '#ecf0f1',
        'brand': '#ecf0f1',
        'legend_bg': '#2c3e50',
        'legend_edge': '#4a5b6e'
    },
    'grid': {
        'visible': True,
        'alpha': 0.5,
        'linestyle': '--',
        'linewidth': 0.5,
        'color': '#4a5b6e',
        'which': 'both'
    }
}


class Visualization:

    def __init__(self, theme='light'):
        self.config = self.__create_config(theme)
        self.theme = theme
        self.__apply_config()


    def __create_config(self, theme='light', logo_path=None):
        if theme == 'dark':
            theme_config = dark_theme
        else:
            theme_config = light_theme

        config = base_config.copy()
        config['theme'] = theme_config['name']

        config['figure']['facecolor'] = theme_config['figure']['facecolor']

        config['colors'] = theme_config['colors'].copy()
        config['colors']['line_cycle'] = base_config['line_cycle']

        config['grid'] = theme_config['grid'].copy()

        config['axes']['spines_color'] = theme_config['colors']['spines']

        config['brand'] = {
            'name': 'Dvol',
            'fontsize': 16,
            'fontweight': 'bold',
            'color': theme_config['colors']['brand'],
            'position': (0.02, 0.96),
            'use_logo': logo_path is not None and os.path.exists(logo_path),
            'logo_path': logo_path,
            'logo_size': 0.08
        }

        return config


    def __apply_config(self):
        config = self.config

        plt.rcParams['font.family'] = config['font']['family']
        plt.rcParams['font.size'] = config['font']['size']
        plt.rcParams['font.weight'] = config['font']['weight']
        plt.rcParams['axes.titlesize'] = config['font']['title_size']
        plt.rcParams['axes.titleweight'] = config['font']['title_weight']
        plt.rcParams['axes.labelsize'] = config['font']['label_size']
        plt.rcParams['axes.labelweight'] = config['font']['label_weight']

        plt.rcParams['axes.prop_cycle'] = cycler(color=config['colors']['line_cycle'])
        plt.rcParams['figure.facecolor'] = config['figure']['facecolor']
        plt.rcParams['axes.facecolor'] = config['colors']['background']
        plt.rcParams['text.color'] = config['colors']['text']

        plt.rcParams['lines.linewidth'] = config['lines']['linewidth']
        plt.rcParams['lines.linestyle'] = config['lines']['linestyle']
        plt.rcParams['lines.markersize'] = config['lines']['markersize']
        plt.rcParams['lines.marker'] = config['lines']['marker']

        plt.rcParams['grid.alpha'] = config['grid']['alpha']
        plt.rcParams['grid.linestyle'] = config['grid']['linestyle']
        plt.rcParams['grid.linewidth'] = config['grid']['linewidth']
        plt.rcParams['grid.color'] = config['grid']['color']

        plt.rcParams['axes.linewidth'] = config['axes']['spines_linewidth']
        plt.rcParams['axes.edgecolor'] = config['axes']['spines_color']
        plt.rcParams['xtick.direction'] = config['axes']['tick_direction']
        plt.rcParams['ytick.direction'] = config['axes']['tick_direction']
        plt.rcParams['xtick.major.size'] = config['axes']['tick_length']
        plt.rcParams['ytick.major.size'] = config['axes']['tick_length']
        plt.rcParams['xtick.color'] = config['colors']['text']
        plt.rcParams['ytick.color'] = config['colors']['text']

        plt.rcParams['axes.labelcolor'] = config['colors']['text']
        plt.rcParams['axes.titlecolor'] = config['colors']['text']

        plt.rcParams['legend.facecolor'] = config['colors']['legend_bg']
        plt.rcParams['legend.edgecolor'] = config['colors']['legend_edge']
        plt.rcParams['legend.fontsize'] = config['legend']['fontsize']
        plt.rcParams['legend.framealpha'] = config['legend']['framealpha']
        plt.rcParams['legend.fancybox'] = config['legend']['fancybox']
        plt.rcParams['legend.shadow'] = config['legend']['shadow']
        plt.rcParams['legend.borderpad'] = config['legend']['borderpad']

        plt.rcParams['legend.labelcolor'] = config['colors']['text']

        plt.rcParams['figure.figsize'] = config['figure']['figsize']
        plt.rcParams['figure.dpi'] = config['figure']['dpi']
        plt.rcParams['savefig.facecolor'] = config['figure']['facecolor']
        plt.rcParams['figure.titlesize'] = config['font']['title_size']
        plt.rcParams['figure.titleweight'] = config['font']['title_weight']

        plt.rcParams['toolbar'] = 'toolbar2'


    def __set_theme(self, theme):
        self.config = self.__create_config(theme)
        self.theme = theme
        self.__apply_config()

    def __create_figure(self, *args, **kwargs):
        fig, ax = plt.subplots(*args, **kwargs)

        try:
            fig.canvas.manager.set_window_title(self.config['figure']['window_title'])
        except:
            pass

        fig.patch.set_facecolor(self.config['figure']['facecolor'])
        fig.patch.set_alpha(1.0)

        return fig, ax

    def __style_axes(self, ax):
        for spine in ax.spines.values():
            spine.set_color(self.config['colors']['spines'])
            spine.set_linewidth(self.config['axes']['spines_linewidth'])

        ax.tick_params(colors=self.config['colors']['text'],
                       direction=self.config['axes']['tick_direction'],
                       length=self.config['axes']['tick_length'],
                       width=self.config['axes']['tick_width'])

        ax.xaxis.label.set_color(self.config['colors']['text'])
        ax.yaxis.label.set_color(self.config['colors']['text'])
        ax.title.set_color(self.config['colors']['text'])

    def __style_legend(self, ax):
        legend = ax.legend()
        if legend:
            legend.get_frame().set_facecolor(self.config['colors']['legend_bg'])
            legend.get_frame().set_edgecolor(self.config['colors']['legend_edge'])
            for text in legend.get_texts():
                text.set_color(self.config['colors']['text'])

    def __save_figure(self, fig, filename):
        config = self.config['save']

        save_kwargs = {
            'format': config['format'],
            'dpi': config['dpi'],
            'bbox_inches': config['bbox_inches'],
            'pad_inches': config['pad_inches'],
            'transparent': config['transparent'],
            'facecolor': self.config['figure']['facecolor']
        }

        fig.savefig(filename, **save_kwargs)
        print(f"График сохранен как {filename}")

    def show_vol(self, df, pred, save_path=None):
        fig, ax = self.__create_figure(figsize=(15, 6))

        bottom_y = 0
        max_bar_height = 0

        for i, (idx, row) in enumerate(df.iterrows()):
            if i < len(df)-pred:
                color = self.config['colors']['primary']
            else:
                color = 'green'

            x_pos = i


            ax.plot([x_pos, x_pos], [bottom_y, bottom_y],
                    color=self.config['colors']['text'], linewidth=1)

            bar_height = row['value']
            if bar_height > max_bar_height:
                max_bar_height = bar_height

            rect = patches.Rectangle((x_pos - 0.3, 0), 0.6, bar_height,
                                     linewidth=1, edgecolor=color, facecolor=color, alpha=0.7)
            ax.add_patch(rect)

        ax.set_xlim(-1, len(df))
        ax.set_ylim(0, max_bar_height * 1.3)
        ax.set_xlabel('Время')
        ax.set_ylabel('')
        ax.set_title('Объемный график')

        self.__style_axes(ax)

        plt.xticks(range(len(df)), [d.strftime('%m-%d') for d in df.index], rotation=45)

        plt.tight_layout()

        if save_path:
            self.__save_figure(fig, save_path)

        plt.show()

    def show_errors(self, train_errors, val_errors, train_r2, val_r2, save_path=None):
        # Первый график - MSE Loss
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # Первый график - MSE Loss
        ax1.plot(list(train_errors), label='Train Loss',
                 color=self.config['colors']['primary'])
        ax1.plot(list(val_errors), label='Validation Loss',
                 color=self.config['colors']['secondary'])
        ax1.set_xlabel('Trees')
        ax1.set_ylabel('MSE Loss')
        ax1.set_title('MSE Loss over Trees')
        ax1.grid(True)

        self.__style_axes(ax1)
        self.__style_legend(ax1)

        # Второй график - R² Score
        ax2.plot(list(train_r2), label='Train R²',
                 color=self.config['colors']['primary'])
        ax2.plot(list(val_r2), label='Validation R²',
                 color=self.config['colors']['secondary'])
        ax2.set_xlabel('Trees')
        ax2.set_ylabel('R² Score')
        ax2.set_title('R² Score over Trees')
        ax2.grid(True)

        self.__style_axes(ax2)
        self.__style_legend(ax2)

        plt.tight_layout()

        if save_path:
            self.__save_figure(fig, save_path)

        plt.show()

