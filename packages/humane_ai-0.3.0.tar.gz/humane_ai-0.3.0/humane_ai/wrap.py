"""
One-line integration: wrap any OpenAI-shaped client with Humane behavioral intelligence.

Usage:
    from openai import OpenAI
    from humane_ai import wrap

    client = wrap(OpenAI(api_key="sk-..."), humane_key="hx_...")

    # That's it — every .chat.completions.create() call now:
    #   • logs an interaction into Humane
    #   • runs behavioral analysis (mood/energy/trust/safety)
    #   • can abort delivery if safety blocks
    #   • updates the per-user behavioral profile
    #   • fires webhooks + proactive triggers server-side

    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "I am so stressed"}],
        user="patient_123",  # Humane tracks by `user` — use a stable ID
    )
    print(resp.choices[0].message.content)
    print(resp.humane.user.mood)       # 0.28
    print(resp.humane.safety.action)   # PROCEED / BLOCK / HOLD
    print(resp.humane.analysis.reasons)
"""

from typing import Any, Optional
from humane_ai.client import HumaneClient


class _WrappedCompletions:
    def __init__(self, inner, humane: HumaneClient, default_user: str):
        self._inner = inner
        self._humane = humane
        self._default_user = default_user

    def create(self, *args, **kwargs):
        # Extract user + last user message
        user_id = kwargs.pop("user", None) or self._default_user
        messages = kwargs.get("messages") or []
        last_user_msg = ""
        for m in reversed(messages):
            if (m.get("role") if isinstance(m, dict) else getattr(m, "role", None)) == "user":
                last_user_msg = (m.get("content") if isinstance(m, dict) else getattr(m, "content", "")) or ""
                break

        humane_resp = None
        if last_user_msg and user_id:
            try:
                humane_resp = self._humane.process(
                    user_id=user_id,
                    message=last_user_msg,
                    channel=kwargs.pop("humane_channel", "openai"),
                    remember_conversation=False,  # caller already keeps history
                )
            except Exception:
                humane_resp = None

        # If safety blocked, short-circuit — don't bill the LLM call.
        if humane_resp and humane_resp.safety and humane_resp.safety.action == "BLOCK":
            return _BlockedResponse(humane_resp)

        # Delegate to the real OpenAI client
        resp = self._inner.create(*args, **kwargs)
        # Attach humane metadata onto the response for downstream access
        try:
            resp.humane = humane_resp  # type: ignore[attr-defined]
        except Exception:
            pass
        return resp


class _WrappedChat:
    def __init__(self, inner, humane: HumaneClient, default_user: str):
        self.completions = _WrappedCompletions(inner.completions, humane, default_user)


class _BlockedResponse:
    """Stand-in for an OpenAI response when Humane's safety gate blocked the call."""
    def __init__(self, humane_resp):
        self.humane = humane_resp
        class _Msg:
            content = "[Blocked by Humane safety gate. A human clinician has been notified.]"
            role = "assistant"
        class _Choice:
            message = _Msg()
            finish_reason = "humane_safety_block"
            index = 0
        self.choices = [_Choice()]
        self.id = "humane-blocked"
        self.model = "humane-safety"
        self.object = "chat.completion"


class HumaneWrappedClient:
    """Drop-in wrapper around an OpenAI-shaped client."""
    def __init__(self, inner, humane: HumaneClient, default_user: str = "anonymous"):
        self._inner = inner
        self._humane = humane
        self.chat = _WrappedChat(inner.chat, humane, default_user)

    # Pass through any attribute we don't specifically wrap
    def __getattr__(self, item: str) -> Any:
        return getattr(self._inner, item)


def wrap(
    inner_client: Any,
    humane_key: Optional[str] = None,
    humane_client: Optional[HumaneClient] = None,
    humane_base_url: str = "https://humaneai.vaarak.com/api",
    default_user: str = "anonymous",
) -> HumaneWrappedClient:
    """
    Wrap an existing OpenAI-shaped client with Humane behavioral intelligence.

    Either pass `humane_key=...` (and optional `humane_base_url`) OR pass a
    pre-built `humane_client=HumaneClient(...)`.

    The returned object is a drop-in replacement — everything the original
    client supports continues to work, but calls are routed through the
    Humane engine first.
    """
    if humane_client is None:
        if not humane_key:
            raise ValueError("Provide either humane_key=... or humane_client=...")
        humane_client = HumaneClient(api_key=humane_key, base_url=humane_base_url)
    return HumaneWrappedClient(inner_client, humane_client, default_user)
