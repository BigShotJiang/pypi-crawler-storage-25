"""Response types for the Humane AI SDK."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class UserState:
    """Behavioral state of the end-user."""
    id: str
    energy: float
    mood: float
    trust: float
    sentiment: float
    familiarity: float
    interaction_count: int

    @property
    def is_frustrated(self) -> bool:
        return self.mood < 0.35

    @property
    def is_tired(self) -> bool:
        return self.energy < 0.3

    @property
    def is_trusted(self) -> bool:
        return self.trust > 0.7


@dataclass
class SafetyResult:
    """Safety gate decision."""
    action: str  # PROCEED, HOLD, BLOCK
    risk_score: float
    flags: list[str]

    @property
    def is_blocked(self) -> bool:
        return self.action == "BLOCK"

    @property
    def is_safe(self) -> bool:
        return self.action == "PROCEED"


@dataclass
class TimingResult:
    """Timing engine recommendation."""
    delay_ms: int
    reason: str


@dataclass
class ContextStyle:
    """Recommended response style based on behavioral analysis."""
    tone: str
    empathy: float
    formality: float
    response_length: str


@dataclass
class AnalysisResult:
    """Behavioral analysis details."""
    detected_emotions: list[str]
    intent: str
    confidence: str  # "llm" or "heuristic"


@dataclass
class ProactiveEvent:
    """A proactive trigger that fired during this interaction."""
    trigger: str
    description: str
    suggested_action: str
    end_user_id: str
    timestamp: str


@dataclass
class HumaneResponse:
    """Full response from the Humane AI SDK."""
    response: Optional[str]
    user: UserState
    timing: TimingResult
    safety: SafetyResult
    context: ContextStyle
    analysis: Optional[AnalysisResult] = None
    proactive: list[ProactiveEvent] = field(default_factory=list)
    model: Optional[dict] = None
    memory: Optional[dict] = None
    error: Optional[str] = None
    setup_required: Optional[str] = None
    raw: dict = field(default_factory=dict)
