"""Humane AI SDK — Behavioral Intelligence for your LLM applications.

Quickstart:

    from humane_ai import HumaneClient

    client = HumaneClient(api_key="hx_...")
    response = client.process(user_id="patient_1", message="I feel anxious")
    print(response.response, response.user.mood, response.safety.action)

Or wrap an existing OpenAI client in one line:

    from openai import OpenAI
    from humane_ai import wrap

    client = wrap(OpenAI(api_key="sk-..."), humane_key="hx_...")
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "I feel anxious"}],
        user="patient_1",
    )
    print(resp.humane.user.mood)  # behavioral state attached to every call
"""

from humane_ai.client import HumaneClient
from humane_ai.async_client import AsyncHumaneClient
from humane_ai.types import HumaneResponse, UserState, SafetyResult, TimingResult, ContextStyle
from humane_ai.wrap import wrap, HumaneWrappedClient
from humane_ai.webhook_verify import verify_webhook_signature

__version__ = "0.2.0"
__all__ = [
    "HumaneClient",
    "AsyncHumaneClient",
    "HumaneResponse",
    "UserState",
    "SafetyResult",
    "TimingResult",
    "ContextStyle",
    "wrap",
    "HumaneWrappedClient",
    "verify_webhook_signature",
]
