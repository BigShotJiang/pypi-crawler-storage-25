"""Async variant of HumaneClient for asyncio / FastAPI / anyio users (#18).

API is deliberately identical to HumaneClient — just async.

    from humane_ai import AsyncHumaneClient

    client = AsyncHumaneClient(api_key="hx_...")
    resp = await client.process(user_id="u1", message="hi")
    async for ev in client.stream(user_id="u1", message="..."):
        ...
"""

import json
from typing import AsyncIterator, Optional
import httpx
from humane_ai.types import (
    HumaneResponse, UserState, SafetyResult, TimingResult,
    ContextStyle, AnalysisResult, ProactiveEvent,
)
from humane_ai.client import HumaneError, RateLimitError, AuthError


class AsyncHumaneClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://humaneai.vaarak.com/api",
        timeout: float = 180.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
        self._conversations: dict[str, list[dict]] = {}

    # Managed HTTP client — single pool, reused across calls.
    # NOTE: we deliberately don't pass base_url to httpx. When base_url has
    # a path component (e.g. ".../api") and the request path is absolute
    # (e.g. "/sdk/..."), httpx strips + re-joins in ways that silently drop
    # the path prefix. Using explicit absolute URLs avoids that footgun.
    async def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                headers={"X-API-Key": self.api_key, "Content-Type": "application/json"},
                timeout=self.timeout,
            )
        return self._client

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self):
        await self._http()
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def process(
        self,
        user_id: str,
        message: str,
        channel: str = "api",
        metadata: Optional[dict] = None,
        idempotency_key: Optional[str] = None,
        remember_conversation: bool = True,
    ) -> HumaneResponse:
        """Process one message asynchronously."""
        history = self._conversations.get(user_id, []) if remember_conversation else []
        http = await self._http()
        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        resp = await http.post(
            f"{self.base_url}/sdk/process",
            json={
                "user_id": user_id,
                "message": message,
                "conversation_history": history[-20:],
                "channel": channel,
                "metadata": metadata or {},
            },
            headers=headers,
        )
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded. Max 60 requests/minute.")
        if resp.status_code == 401:
            raise AuthError("Invalid API key.")
        resp.raise_for_status()

        data = resp.json()
        result = _parse_response(data)

        if remember_conversation and result.response:
            self._conversations.setdefault(user_id, [])
            self._conversations[user_id].append({"role": "user", "content": message})
            self._conversations[user_id].append({"role": "assistant", "content": result.response})
            self._conversations[user_id] = self._conversations[user_id][-40:]
        return result

    async def stream(
        self,
        user_id: str,
        message: str,
        channel: str = "api",
    ) -> AsyncIterator[dict]:
        """Server-sent stream. Yields metadata, token, final, and done events."""
        history = self._conversations.get(user_id, [])
        http = await self._http()
        full = ""
        async with http.stream(
            "POST",
            f"{self.base_url}/sdk/process/stream",
            json={
                "user_id": user_id,
                "message": message,
                "conversation_history": history[-20:],
                "channel": channel,
            },
        ) as resp:
            if resp.status_code >= 400:
                raise HumaneError(f"Stream failed: HTTP {resp.status_code}")
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                body = line[6:]
                if body == "[DONE]":
                    yield {"type": "done"}
                    break
                try:
                    ev = json.loads(body)
                    if ev.get("type") == "token":
                        full += ev["data"].get("content", "")
                    yield ev
                except json.JSONDecodeError:
                    pass
        if full:
            self._conversations.setdefault(user_id, [])
            self._conversations[user_id].append({"role": "user", "content": message})
            self._conversations[user_id].append({"role": "assistant", "content": full})
            self._conversations[user_id] = self._conversations[user_id][-40:]

    async def get_history(self, user_id: str, limit: int = 200) -> list[dict]:
        """Durable conversation history from the platform DB."""
        http = await self._http()
        try:
            r = await http.get(f"{self.base_url}/sdk/history/{user_id}", params={"limit": limit})
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return self._conversations.get(user_id, [])

    async def clear_history(self, user_id: str) -> None:
        self._conversations.pop(user_id, None)
        http = await self._http()
        try:
            await http.delete(f"{self.base_url}/sdk/history/{user_id}")
        except Exception:
            pass

    # ── Analytics ────────────────────────────────────────────
    async def behavior_score(self, window_days: int = 7) -> dict:
        """Tenant-level Behavior Score (0–100) with breakdown."""
        http = await self._http()
        r = await http.get(
            f"{self.base_url}/analytics/behavior-score",
            params={"window_days": window_days},
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    async def list_anomalies(
        self,
        *,
        since_hours: int = 168,
        resolved: bool = False,
        limit: int = 100,
    ) -> list[dict]:
        """List anomaly-detection events for the tenant."""
        http = await self._http()
        r = await http.get(
            f"{self.base_url}/anomalies",
            params={
                "since_hours": since_hours,
                "resolved": "true" if resolved else "false",
                "limit": limit,
            },
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json().get("items", [])

    async def resolve_anomaly(self, anomaly_id: str, *, note: Optional[str] = None) -> dict:
        """Mark an anomaly resolved."""
        http = await self._http()
        body: dict = {}
        if note:
            body["note"] = note
        r = await http.post(f"{self.base_url}/anomalies/{anomaly_id}/resolve", json=body)
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    # ── Privacy / GDPR ──────────────────────────────────────
    async def export_user_data(self, user_id: str) -> dict:
        """Return every piece of data the platform holds about ``user_id``."""
        http = await self._http()
        r = await http.get(f"{self.base_url}/privacy/export/{user_id}")
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    async def erase_user_data(self, user_id: str) -> dict:
        """Hard-delete behavioural data for ``user_id`` (right-to-erasure)."""
        http = await self._http()
        r = await http.delete(f"{self.base_url}/privacy/erase/{user_id}")
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()


def _parse_response(data: dict) -> HumaneResponse:
    u = data.get("user", {})
    t = data.get("timing", {})
    s = data.get("safety", {})
    c = data.get("context", {})
    a = data.get("analysis", {})
    p = data.get("proactive", [])
    return HumaneResponse(
        response=data.get("response"),
        user=UserState(
            id=u.get("id", ""),
            energy=u.get("energy", 0.5), mood=u.get("mood", 0.5),
            trust=u.get("trust", 0.4), sentiment=u.get("sentiment", 0.5),
            familiarity=u.get("familiarity", 0.3),
            interaction_count=u.get("interaction_count", 0),
        ),
        timing=TimingResult(delay_ms=t.get("delay_ms", 800), reason=t.get("reason", "")),
        safety=SafetyResult(action=s.get("action", "PROCEED"), risk_score=s.get("risk_score", 0.0), flags=s.get("flags", [])),
        context=ContextStyle(
            tone=c.get("tone", "neutral_professional"),
            empathy=c.get("empathy", 0.5), formality=c.get("formality", 0.5),
            response_length=c.get("response_length", "medium"),
        ),
        analysis=AnalysisResult(
            detected_emotions=a.get("detected_emotions", []),
            intent=a.get("intent", "general"),
            confidence=a.get("confidence", "heuristic"),
        ) if a else None,
        proactive=[
            ProactiveEvent(
                trigger=e.get("trigger", ""),
                description=e.get("description", ""),
                suggested_action=e.get("suggested_action", ""),
                end_user_id=e.get("end_user_id", ""),
                timestamp=e.get("timestamp", ""),
            ) for e in p
        ],
        model=data.get("model"),
        memory=data.get("memory"),
        error=data.get("error"),
        setup_required=data.get("setup_required"),
        raw=data,
    )
