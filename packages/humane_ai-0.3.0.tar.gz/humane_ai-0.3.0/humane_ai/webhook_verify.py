"""Webhook signature verification for receivers.

Use this on your webhook endpoint to reject spoofed or replayed events.

    from fastapi import Request, HTTPException
    from humane_ai import verify_webhook_signature

    @app.post("/webhook")
    async def receive(request: Request):
        raw = await request.body()
        sig = request.headers.get("X-Humane-Signature")
        if not verify_webhook_signature(MY_SIGNING_SECRET, raw, sig):
            raise HTTPException(401, "invalid signature")
        payload = json.loads(raw)
        ...
"""

import hmac
import hashlib
import time
from typing import Optional


def verify_webhook_signature(
    secret: str,
    payload_bytes: bytes,
    signature_header: Optional[str],
    max_age_seconds: int = 300,
) -> bool:
    """
    Verify a Stripe-format X-Humane-Signature header: "t=<unix>,v1=<hex>".
    Returns True on match + within replay window.
    """
    if not signature_header or not secret:
        return False
    try:
        parts = dict(p.split("=", 1) for p in signature_header.split(","))
        ts = int(parts["t"])
        sig = parts["v1"]
    except Exception:
        return False
    if abs(int(time.time()) - ts) > max_age_seconds:
        return False
    expected = hmac.new(secret.encode(), f"{ts}.".encode() + payload_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)
