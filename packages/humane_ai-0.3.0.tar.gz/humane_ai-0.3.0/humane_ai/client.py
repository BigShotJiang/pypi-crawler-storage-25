"""Humane AI SDK Client — One line to add behavioral intelligence to any LLM app."""

import requests
import json
from typing import Optional, Generator
from humane_ai.types import (
    HumaneResponse, UserState, SafetyResult, TimingResult,
    ContextStyle, AnalysisResult, ProactiveEvent,
)


class HumaneClient:
    """
    Client for the Humane AI Behavioral Intelligence SDK.

    Usage:
        from humane_ai import HumaneClient

        client = HumaneClient(api_key="hx_your_key")
        response = client.process("user_123", "I need help with my order")

        print(response.response)        # AI response shaped by behavioral context
        print(response.user.mood)       # 0.35 (frustration detected)
        print(response.context.empathy) # 0.95 (auto-increased for upset user)
        print(response.safety.action)   # PROCEED
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://humaneai.vaarak.com/api",
        timeout: int = 180,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._conversations: dict[str, list[dict]] = {}

    def process(
        self,
        user_id: str,
        message: str,
        channel: str = "api",
        metadata: Optional[dict] = None,
        remember_conversation: bool = True,
    ) -> HumaneResponse:
        """
        Process a message through the Humane AI behavioral intelligence pipeline.

        Args:
            user_id: Unique identifier for the end-user.
            message: The user's message text.
            channel: Channel identifier (api, web, telegram, etc.)
            metadata: Optional metadata dict attached to the interaction.
            remember_conversation: Auto-manage conversation history per user.

        Returns:
            HumaneResponse with AI response + behavioral analysis.
        """
        history = self._conversations.get(user_id, []) if remember_conversation else []

        resp = requests.post(
            f"{self.base_url}/sdk/process",
            headers={"X-API-Key": self.api_key, "Content-Type": "application/json"},
            json={
                "user_id": user_id,
                "message": message,
                "conversation_history": history[-20:],
                "channel": channel,
                "metadata": metadata or {},
            },
            timeout=self.timeout,
        )

        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded. Max 60 requests/minute.")
        if resp.status_code == 401:
            raise AuthError("Invalid API key.")
        resp.raise_for_status()

        data = resp.json()
        result = self._parse_response(data)

        # Auto-manage conversation history
        if remember_conversation and result.response:
            if user_id not in self._conversations:
                self._conversations[user_id] = []
            self._conversations[user_id].append({"role": "user", "content": message})
            self._conversations[user_id].append({"role": "assistant", "content": result.response})
            # Keep last 40 messages (20 turns)
            self._conversations[user_id] = self._conversations[user_id][-40:]

        return result

    def stream(
        self,
        user_id: str,
        message: str,
        channel: str = "api",
    ) -> Generator[dict, None, None]:
        """
        Stream a response via Server-Sent Events.
        Yields dicts with type: 'metadata', 'token', 'blocked', 'error', or 'done'.

        Usage:
            for event in client.stream("user_123", "Hello"):
                if event["type"] == "metadata":
                    print("Behavioral analysis:", event["data"])
                elif event["type"] == "token":
                    print(event["data"]["content"], end="", flush=True)
        """
        history = self._conversations.get(user_id, [])

        resp = requests.post(
            f"{self.base_url}/sdk/process/stream",
            headers={"X-API-Key": self.api_key, "Content-Type": "application/json"},
            json={
                "user_id": user_id,
                "message": message,
                "conversation_history": history[-20:],
                "channel": channel,
            },
            stream=True,
            timeout=self.timeout,
        )
        resp.raise_for_status()

        full_response = ""
        for line in resp.iter_lines():
            if not line:
                continue
            line = line.decode("utf-8")
            if line.startswith("data: "):
                data_str = line[6:]
                if data_str == "[DONE]":
                    yield {"type": "done"}
                    break
                try:
                    event = json.loads(data_str)
                    if event.get("type") == "token":
                        full_response += event["data"]["content"]
                    yield event
                except json.JSONDecodeError:
                    pass

        # Save to conversation history
        if full_response:
            if user_id not in self._conversations:
                self._conversations[user_id] = []
            self._conversations[user_id].append({"role": "user", "content": message})
            self._conversations[user_id].append({"role": "assistant", "content": full_response})
            self._conversations[user_id] = self._conversations[user_id][-40:]

    def get_history(self, user_id: str, limit: int = 200) -> list[dict]:
        """
        Durable conversation history for a user.

        Queries the platform DB so multiple worker processes / devices share
        the same view. Falls back to local in-memory cache only if the
        platform is unreachable.
        """
        try:
            resp = requests.get(
                f"{self.base_url}/sdk/history/{user_id}?limit={limit}",
                headers={"X-API-Key": self.api_key},
                timeout=15,
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        # Fallback to local cache if platform is down
        return self._conversations.get(user_id, [])

    def clear_history(self, user_id: str):
        """Clear conversation history for a user — both locally and on the platform."""
        self._conversations.pop(user_id, None)
        try:
            requests.delete(
                f"{self.base_url}/sdk/history/{user_id}",
                headers={"X-API-Key": self.api_key},
                timeout=15,
            )
        except Exception:
            pass

    # ── Analytics ────────────────────────────────────────────
    def behavior_score(self, window_days: int = 7) -> dict:
        """Tenant-level Behavior Score (0–100) with breakdown."""
        r = requests.get(
            f"{self.base_url}/analytics/behavior-score",
            params={"window_days": window_days},
            headers={"X-API-Key": self.api_key},
            timeout=15,
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    def list_anomalies(
        self,
        *,
        since_hours: int = 168,
        resolved: bool = False,
        limit: int = 100,
    ) -> list[dict]:
        """List anomaly-detection events for the tenant."""
        r = requests.get(
            f"{self.base_url}/anomalies",
            params={
                "since_hours": since_hours,
                "resolved": "true" if resolved else "false",
                "limit": limit,
            },
            headers={"X-API-Key": self.api_key},
            timeout=15,
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json().get("items", [])

    def resolve_anomaly(self, anomaly_id: str, *, note: str | None = None) -> dict:
        """Mark an anomaly resolved."""
        body: dict = {}
        if note:
            body["note"] = note
        r = requests.post(
            f"{self.base_url}/anomalies/{anomaly_id}/resolve",
            json=body,
            headers={"X-API-Key": self.api_key},
            timeout=15,
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    # ── Privacy / GDPR ──────────────────────────────────────
    def export_user_data(self, user_id: str) -> dict:
        """Return every piece of data the platform holds about ``user_id``."""
        r = requests.get(
            f"{self.base_url}/privacy/export/{user_id}",
            headers={"X-API-Key": self.api_key},
            timeout=30,
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    def erase_user_data(self, user_id: str) -> dict:
        """Hard-delete behavioural data for ``user_id`` (right-to-erasure)."""
        r = requests.delete(
            f"{self.base_url}/privacy/erase/{user_id}",
            headers={"X-API-Key": self.api_key},
            timeout=30,
        )
        if r.status_code == 401:
            raise AuthError("Invalid API key")
        r.raise_for_status()
        return r.json()

    def _parse_response(self, data: dict) -> HumaneResponse:
        u = data.get("user", {})
        t = data.get("timing", {})
        s = data.get("safety", {})
        c = data.get("context", {})
        a = data.get("analysis", {})
        p = data.get("proactive", [])

        return HumaneResponse(
            response=data.get("response"),
            user=UserState(
                id=u.get("id", ""),
                energy=u.get("energy", 0.5),
                mood=u.get("mood", 0.5),
                trust=u.get("trust", 0.4),
                sentiment=u.get("sentiment", 0.5),
                familiarity=u.get("familiarity", 0.3),
                interaction_count=u.get("interaction_count", 0),
            ),
            timing=TimingResult(
                delay_ms=t.get("delay_ms", 800),
                reason=t.get("reason", ""),
            ),
            safety=SafetyResult(
                action=s.get("action", "PROCEED"),
                risk_score=s.get("risk_score", 0.0),
                flags=s.get("flags", []),
            ),
            context=ContextStyle(
                tone=c.get("tone", "neutral_professional"),
                empathy=c.get("empathy", 0.5),
                formality=c.get("formality", 0.5),
                response_length=c.get("response_length", "medium"),
            ),
            analysis=AnalysisResult(
                detected_emotions=a.get("detected_emotions", []),
                intent=a.get("intent", "general"),
                confidence=a.get("confidence", "heuristic"),
            ) if a else None,
            proactive=[
                ProactiveEvent(
                    trigger=e.get("trigger", ""),
                    description=e.get("description", ""),
                    suggested_action=e.get("suggested_action", ""),
                    end_user_id=e.get("end_user_id", ""),
                    timestamp=e.get("timestamp", ""),
                ) for e in p
            ],
            model=data.get("model"),
            memory=data.get("memory"),
            error=data.get("error"),
            setup_required=data.get("setup_required"),
            raw=data,
        )


class HumaneError(Exception):
    pass

class RateLimitError(HumaneError):
    pass

class AuthError(HumaneError):
    pass
