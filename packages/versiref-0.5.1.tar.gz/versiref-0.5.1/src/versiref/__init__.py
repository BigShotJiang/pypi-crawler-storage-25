"""versiref can parse, manipulate, and format references to Bible verses.

It is versatile in that it can handle complex references, different
versifications, and it is flexible about the format is parses and the output it
generates.
"""

from versiref.bible_ref import BibleRef, SimpleBibleRef, VerseRange
from versiref.ref_parser import RefParser, Sensitivity
from versiref.ref_style import RefStyle, available_standard_names, standard_names
from versiref.versification import Versification

__path__ = __import__("pkgutil").extend_path(__path__, __name__)

__all__ = [
    "BibleRef",
    "SimpleBibleRef",
    "VerseRange",
    "RefParser",
    "Sensitivity",
    "RefStyle",
    "Versification",
    "available_standard_names",
    "standard_names",
]
