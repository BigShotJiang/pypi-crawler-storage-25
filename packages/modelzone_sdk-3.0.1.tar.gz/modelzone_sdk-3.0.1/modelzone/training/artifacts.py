import pickle
from pathlib import Path

DEFAULT_ARTIFACT_DIR = Path(".models/artifacts")


class Artifact:
    """Base class for model artifacts (e.g. training model) that should follow along
    with the model code. Look in the documentation for the usage of artifacts.
    """

    def save(self, name: str = ".model", artifacts_dir: Path = DEFAULT_ARTIFACT_DIR):
        """Save (pickle) the artifact under the given name.
        The file will be saved next to the file in
        which the inheriting class is defined.

        Args:
            name (str, optional): Name of the artifact. Defaults to ".model".
            artifact_dir (Path, optional): Directory where the artifact should be
                stored. Defaults to DEFAULT_ARTIFACT_DIR.
        """
        artifacts_dir = Path(artifacts_dir)
        with open(artifacts_dir / f"{name}.pkl", "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, name: str = ".model", artifacts_dir: Path = DEFAULT_ARTIFACT_DIR):
        """Load (unpickle) the artifact with the given name.
        The fill will be loaded from next to the file in
        which the inheriting class is defined.

        Args:
            name (str, optional): Name of the artifact. Defaults to ".model".
            artifact_dir (Path, optional): Directory where the artifact is stored.
                Defaults to DEFAULT_ARTIFACT_DIR.

        """
        artifacts_dir = Path(artifacts_dir)
        with open(artifacts_dir / f"{name}.pkl", "rb") as f:
            return pickle.load(f)
