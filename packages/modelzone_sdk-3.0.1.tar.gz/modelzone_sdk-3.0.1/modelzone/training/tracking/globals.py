from modelzone.training.tracking.trackers import ProxyTracker, Tracker

# global tracker, initialized to a proxy tracker by default
# (which will buffer calls until the real tracker is set)
_tracker: Tracker = ProxyTracker()


def set_tracker(tracker: Tracker):
    """Set current global tracker."""
    global _tracker
    _tracker = tracker


def get_tracker() -> Tracker:
    """Get current global tracker."""
    return _tracker
