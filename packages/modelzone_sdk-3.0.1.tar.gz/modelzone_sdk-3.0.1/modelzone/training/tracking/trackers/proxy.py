from typing import Any

import plotly.graph_objects as go

from modelzone.training.artifacts import Artifact


class ProxyTracker:
    """Experiment tracker that proxies calls to the global tracker.
    This is necessary, because your code might reference the tracker
    before it has been configured.

    Raises:
        RuntimeError: Raised when the global tracker is not started.
    """

    @property
    def real_tracker(self):
        from modelzone.training.tracking import globals

        tracker = globals.get_tracker()

        if tracker is None:
            raise RuntimeError(
                "Global tracker is not started. "
                "Use 'with get_tracker()' to start a tracker before using it."
            )

        return tracker

    def log_tag(self, key: str, value: str):
        self.real_tracker.log_tag(key, value)

    def log_file(self, name: str, data: bytes):
        self.real_tracker.log_file(name, data)

    def log_message(self, message: str):
        self.real_tracker.log_message(message)

    def log_artifact(self, name: str, artifact: Artifact):
        self.real_tracker.log_artifact(name, artifact)

    def log_metric(
        self,
        name: str,
        value: float | int | str,
        dimensions: dict[str, Any] | None = None,
    ):
        self.real_tracker.log_metric(name, value, dimensions)

    def log_figure(
        self, name: str, figure: go.Figure, dimensions: dict[str, Any] | None = None
    ):
        self.real_tracker.log_figure(name, figure, dimensions)
