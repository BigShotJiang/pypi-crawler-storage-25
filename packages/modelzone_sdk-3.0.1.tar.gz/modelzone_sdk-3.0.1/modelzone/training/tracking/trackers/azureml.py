import contextlib
import io
import os
from typing import Any

import mlflow
import plotly.graph_objects as go

from modelzone.lifecycle import Experiment
from modelzone.training.artifacts import Artifact
from modelzone.training.tracking.trackers.base import Tracker
from modelzone.training.tracking.trackers.local import LocalTracker


class AzureMLTracker(Tracker):
    def __init__(self, experiment: Experiment, output_dir: str):
        """Experiment tracker logging to an Azure ML run via MLflow.

        Args:
            experiment (Experiment): Experiment
        """
        self.experiment = experiment
        self.local_tracker = LocalTracker(output_dir)
        self.run_id = None

    def __enter__(self):
        # Start an MLflow run in 2 steps:

        # (1) Set the experiment and tracking URI for MLflow

        # Inject a bearer token for the AzureML REST endpoint
        credential = self.experiment.workspace.ml_client._credential
        token = credential.get_token("https://ml.azure.com/.default")
        os.environ["MLFLOW_TRACKING_TOKEN"] = token.token

        mlflow.set_tracking_uri(self.experiment.workspace._tracking_base)

        mlflow.set_experiment(self.experiment.name)

        # (2) Start an MLflow run

        run = mlflow.start_run()

        self.run_id = run.info.run_id

        self.local_tracker.__enter__()

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.local_tracker.__exit__(exc_type, exc_val, exc_tb)

        # End the run, suppressing mlflow's broken API links
        with contextlib.redirect_stdout(io.StringIO()):
            if exc_type is None:
                mlflow.end_run(status="FINISHED")
            else:
                mlflow.end_run(status="FAILED")

    def log_metric(
        self,
        name: str,
        value: float | int | str,
        dimensions: dict[str, Any] | None = None,
    ):
        self.local_tracker.log_metric(name, value, dimensions)
        if dimensions is None:
            mlflow.log_metric(name, value)

    def log_tag(self, key: str, value: str):
        self.local_tracker.log_tag(key, value)
        mlflow.set_tag(key, value)

    def log_file(self, name, data):
        self.local_tracker.log_file(name, data)

    def log_message(self, message):
        self.local_tracker.log_message(message)

    def log_artifact(self, name: str, artifact: Artifact):
        self.local_tracker.log_artifact(name, artifact)

    def log_figure(
        self,
        name: str,
        figure: "go.Figure",
        dimensions: dict[str, Any] | None = None,
    ):
        self.local_tracker.log_figure(name, figure, dimensions)
