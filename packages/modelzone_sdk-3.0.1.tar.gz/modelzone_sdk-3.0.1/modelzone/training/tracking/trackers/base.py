from abc import ABC, abstractmethod
from typing import Any

import plotly.graph_objects as go

from modelzone.training.artifacts import Artifact


class Tracker(ABC):
    @abstractmethod
    def log_tag(self, key: str, value: str):
        """Log a tag for the current run.

        - Local run: Tag is appended to 'results/tags.jsonl' in the run directory.
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section. Also logged as a tag in Azure ML visible in the 'Overview' section.
        Args:
            key (str): Tag key
            value (str): Tag value
        """
        pass

    @abstractmethod
    def log_file(self, name: str, data: bytes):
        """Log a file for the current run.

        - Local run: File is saved to 'results/files/<name>' in the run directory.
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section.

        Args:
            name (str): File name
            data (bytes): File data
        """
        pass

    @abstractmethod
    def log_message(self, message: str):
        """Log a message for the current run.

        - Local run: Message is appended to 'results/logs.log' in the run directory.
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section.

        Args:
            message (str): Message
        """
        pass

    @abstractmethod
    def log_artifact(self, name: str, artifact: Artifact):
        """Log an artifact for the current run.

        - Local run: Artifact is saved to 'artifacts/<name>.<ext>' in the run directory
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section.

        Args:
            name (str): Artifact name
            artifact (Artifact): Artifact instance
        """
        pass

    @abstractmethod
    def log_metric(
        self,
        name: str,
        value: float | int | str,
        dimensions: dict[str, Any] | None = None,
    ):
        """Log a metric for the current run, either (1) a single metric og (2) an entry
        in a multi-metric (see documentation for use case examples).

        - Local run: Metric is saved to 'results/metrics/<name>.html' in the run
            directory.
            (1) For single metrics, file contains a indicator with the provided metric
                value.
            (2) For multi-metrics, file contains a table with all provided metric
                values and dimensions.
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section. Also logged as a metric in Azure ML visible in the 'Metrics'
            section (single metrics only)

        Args:
            name (str): Metric name
            value (float): Metric value
            dimensions (dict[str, Any] | None, optional): Dimension to use for
                multi-metrics. If provided, the metric is logged as an entry in a
                multi-metric with the given dimensions.
        """

    @abstractmethod
    def log_figure(
        self,
        name: str,
        figure: go.Figure,
        dimensions: dict[str, Any] | None = None,
    ):
        """Log a figure for the current run, either (1) a single figure og (2) an entry
        in a multi-figure (see documentation for use case examples).

        - Local run: Figure is saved to 'results/figures/<name>.html' in the run
            directory.
            (1) For single figures, file contains the provided figure.
            (2) For multi-figures, file contains all provided figures with dimensions
                selectable via dropdowns.
        - Azure ML run: Same as for local run, but uploaded to the 'Output + logs'
            section.

        Args:
            name (str): Figure name
            figure (go.Figure): Figure instance
            dimensions (dict[str, Any] | None, optional): Dimension to use for
                multi-figures. If provided, the figure is logged as an entry in a
                multi-figure with the given dimensions.
        """
        pass
