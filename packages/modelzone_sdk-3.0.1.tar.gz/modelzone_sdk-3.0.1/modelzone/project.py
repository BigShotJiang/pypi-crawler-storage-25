from __future__ import annotations

import os
import sys
import tomllib

PYPROJECT = "pyproject.toml"


def get_config() -> dict:
    """Return '[tool.modelzone]' from pyproject.toml."""
    if not os.path.isfile(PYPROJECT):
        print(
            f"Error: {PYPROJECT} not found in {os.getcwd()}",
            file=sys.stderr,
        )
        sys.exit(1)
    with open(PYPROJECT, "rb") as f:
        data = tomllib.load(f)
    mz = data.get("tool", {}).get("modelzone")
    if mz is None:
        print(
            f"Error: [tool.modelzone] section not found in {PYPROJECT}",
            file=sys.stderr,
        )
        sys.exit(1)
    return mz
