from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

from modelzone.lifecycle.experiment import Experiment


class Workspace:
    def __init__(
        self,
        ml_client: MLClient,
    ):
        """Client for interacting with Azure ML Workspace"""
        self.ml_client = ml_client

    @classmethod
    def from_resource_names(
        cls,
        subscription_id: str,
        resource_group: str,
        workspace_name: str,
    ):
        ml_client = MLClient(
            credential=DefaultAzureCredential(),
            subscription_id=subscription_id,
            resource_group_name=resource_group,
            workspace_name=workspace_name,
        )
        return cls(ml_client)

    @property
    def wsid(self) -> str:
        return (
            f"/subscriptions/{self.ml_client.subscription_id}"
            f"/resourceGroups/{self.ml_client.resource_group_name}"
            f"/providers/Microsoft.MachineLearningServices"
            f"/workspaces/{self.ml_client.workspace_name}"
        )

    @property
    def _history_base(self) -> str:
        """Return the AzureML History API base URL for this workspace."""
        return (
            f"https://{self._tracking_base.split('/')[2]}"
            f"/history/v1.0/subscriptions/{self.ml_client.subscription_id}"
            f"/resourceGroups/{self.ml_client.resource_group_name}"
            f"/providers/Microsoft.MachineLearningServices"
            f"/workspaces/{self.ml_client.workspace_name}"
        )

    @property
    def _auth_headers(self) -> dict[str, str]:
        token = self.ml_client._credential.get_token("https://ml.azure.com/.default")
        return {"Authorization": f"Bearer {token.token}"}

    @property
    def _tracking_base(self) -> str:
        tracking_uri = self.ml_client.workspaces.get(
            self.ml_client.workspace_name,
        ).mlflow_tracking_uri

        # Convert azureml:// → https:// so MLflow's REST store can handle it
        if tracking_uri.startswith("azureml://"):
            tracking_uri = "https://" + tracking_uri[len("azureml://") :]

        return tracking_uri

    def get_experiment(self, name: str) -> Experiment:
        return Experiment(self, name)
