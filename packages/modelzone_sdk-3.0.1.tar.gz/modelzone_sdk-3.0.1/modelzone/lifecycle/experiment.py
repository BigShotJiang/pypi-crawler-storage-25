from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from modelzone.lifecycle.workspace import Workspace

from modelzone.lifecycle.run import Run


class Experiment:
    def __init__(
        self,
        workspace: "Workspace",
        name: str,
    ):
        """Client for interacting with a specific Azure ML experiment within a
        workspace.

        Args:
            workspace (Workspace): Workspace
            name (str): Experiment name
        """
        self.workspace = workspace
        self.name = name

    @classmethod
    def from_resource_names(
        cls,
        subscription_id: str,
        resource_group: str,
        workspace_name: str,
        experiment_name: str,
    ):
        from modelzone.lifecycle.workspace import Workspace

        workspace = Workspace.from_resource_names(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )
        return cls(workspace, experiment_name)

    def get_run(self, run_id: str) -> Run:
        return Run(self, run_id)
