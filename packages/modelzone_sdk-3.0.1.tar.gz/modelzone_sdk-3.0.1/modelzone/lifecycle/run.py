from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from modelzone.lifecycle.experiment import Experiment

import os
import posixpath

import requests
from azure.ai.ml.constants import AssetTypes
from azure.ai.ml.entities import Model
from azure.storage.blob import BlobClient


class Run:
    def __init__(
        self,
        experiment: "Experiment",
        run_id: str,
    ):
        """Client for interacting with a specific Azure ML run within an experiment.

        Args:
            experiment (Experiment): Experiment
            run_id (str): Run ID
        """
        self.experiment = experiment
        self.run_id = run_id

    @classmethod
    def from_resource_names(
        cls,
        subscription_id: str,
        resource_group: str,
        workspace_name: str,
        experiment_name: str | None = None,
        run_id: str | None = None,
        model_name: str | None = None,
        version: str | None = None,
    ):
        from modelzone.lifecycle.experiment import Experiment
        from modelzone.lifecycle.workspace import Workspace

        if experiment_name is not None and run_id is not None:
            experiment = Experiment.from_resource_names(
                subscription_id=subscription_id,
                resource_group=resource_group,
                workspace_name=workspace_name,
                experiment_name=experiment_name,
            )
            return cls(experiment, run_id)
        elif model_name is not None and version is not None:
            workspace = Workspace.from_resource_names(
                subscription_id=subscription_id,
                resource_group=resource_group,
                workspace_name=workspace_name,
            )
            model = workspace.ml_client.models.get(model_name, version)
            run_id = model.path.split("/jobs/")[1].split("/outputs/")[0]
            experiment_name = model.path.split("/experiments/")[1].split("/runs/")[0]
            experiment = Experiment(workspace, experiment_name)
            return cls(experiment, run_id)

    @property
    def portal_url(self) -> str:
        return (
            f"https://ml.azure.com/runs/{self.run_id}"
            f"?wsid={self.experiment.workspace.wsid}"
        )

    def register(self) -> str:
        """Register run as a new model version in Azure ML Model Registry.

        Returns:
            str: Registered model version
        """
        try:
            existing_registrations = self.experiment.workspace.ml_client.models.list(
                name=self.experiment.name
            )
            existing_versions = [
                int(reg.version)
                for reg in existing_registrations
                if reg.version.isdigit()
            ]
        except Exception:
            existing_versions = []

        version = str(max(existing_versions) + 1) if existing_versions else "1"

        model = Model(
            name=self.experiment.name,
            version=version,
            path=f"azureml://jobs/{self.run_id}/outputs/artifacts/output",
            type=AssetTypes.CUSTOM_MODEL,
            description=f"Model registered from run {self.run_id}",
        )

        self.experiment.workspace.ml_client.models.create_or_update(model)

        return version

    def upload_folder(self, src_dir: str, dest_dir: str):
        """Upload folder from a local directory to the run artifacts directory.

        Args:
            source_dir (str): Local directory
            dest_dir (str): Remote directory within the run artifacts
        """
        # Azure ML SDK doesn't support uploading artifacts in an easy way
        # (only downloading). Thus, we need to manually do it in multiple steps:

        # (1) Generate list of all files to be uploaded
        src_dir = os.path.abspath(src_dir)
        dest_paths: list[str] = []
        source_paths: list[str] = []

        for root, _, filenames in os.walk(src_dir):
            rel = os.path.relpath(root, src_dir)
            upload_prefix = dest_dir if rel == "." else posixpath.join(dest_dir, rel)
            for fname in filenames:

                dest_paths.append(posixpath.join(upload_prefix, fname))
                source_paths.append(os.path.join(root, fname))

        if not dest_paths:
            return

        # (2) Register artifacts in Azure ML and get SAS blob URIs
        url = (
            f"{self.experiment.workspace._history_base}"
            f"/experiments/{self.experiment.name}"
            f"/runs/{self.run_id}/artifacts/batch/metadata"
        )
        body = {"paths": [{"path": p} for p in dest_paths]}
        resp = requests.post(
            url,
            json=body,
            headers={
                **self.experiment.workspace._auth_headers,
                "Content-Type": "application/json",
            },
        )
        resp.raise_for_status()
        content_info = resp.json()["artifactContentInformation"]

        # (3) Upload files to associated blob storage via SAS URI
        for dest_path, source_path in zip(dest_paths, source_paths):
            sas_url = content_info[dest_path]["contentUri"]
            blob = BlobClient.from_blob_url(sas_url)
            with open(source_path, "rb") as f:
                blob.upload_blob(f, overwrite=True)
