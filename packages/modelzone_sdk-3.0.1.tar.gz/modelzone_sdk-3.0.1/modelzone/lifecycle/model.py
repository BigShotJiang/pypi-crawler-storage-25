from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from modelzone.lifecycle.workspace import Workspace

import os
import shutil
from tempfile import TemporaryDirectory


class Model:
    def __init__(self, workspace: "Workspace", name: str, version: str):
        """Client for interacting with a specific Azure ML model within a workspace.

        Args:
            workspace (Workspace): Workspace
            name (str): Model name
            version (str): Model version
        """
        self.workspace = workspace
        self.name = name
        self.version = version

    @classmethod
    def from_resource_names(
        cls,
        subscription_id: str,
        resource_group: str,
        workspace_name: str,
        model_name: str,
        version: str,
    ):
        from modelzone.lifecycle.workspace import Workspace

        workspace = Workspace.from_resource_names(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )
        return cls(workspace, model_name, version)

    def download_folder(
        self, src_dir: str, dest_dir: str, overwrite: bool = False
    ) -> None:
        """Download folder from the model artifact directory to a local directory.

        Args:
            src_dir (str): Remote directory within the model artifacts
            dest_dir (str): Local directory
            overwrite (bool, optional): Whether to overwrite destination directory,
                if this already exists. Defaults to False.
        """
        # Azure ML SDK only supports downloading the entire artifact folder.
        # To download a subfolder, we need to download the whole thing into a temporary
        # directory, and then move the desired subfolder to the final destination.
        with TemporaryDirectory() as temp_dir:
            self.workspace.ml_client.models.download(
                name=self.name,
                version=self.version,
                download_path=temp_dir,
            )

            if overwrite and os.path.exists(dest_dir):
                shutil.rmtree(dest_dir)

            shutil.copytree(
                src=os.path.join(temp_dir, self.name, src_dir),
                dst=dest_dir,
            )
