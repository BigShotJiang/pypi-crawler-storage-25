"""Modelzone CLI – train, register, and fetch models.

Provides ``modelzone train``, ``modelzone register``, and
``modelzone fetch`` as console entry points.  All commands expect
a ``pyproject.toml`` with a ``[tool.modelzone]`` section.
"""

from __future__ import annotations

import argparse
import datetime as dt
import importlib
import logging
import os
import shutil
import sys
from tempfile import TemporaryDirectory

from modelzone import AzureMLTracker, Experiment, LocalTracker, project
from modelzone.training import tracking

# Supress noisy Azure ML SDK logging
logging.getLogger("azure.ai.ml.operations._model_operations").setLevel(logging.WARNING)
logging.getLogger("azure.ai.ml._utils._experimental").setLevel(logging.ERROR)


SNAPSHOT_IGNORE = shutil.ignore_patterns(
    "__pycache__",
    "*.pyc",
    ".ruff_cache",
    ".mypy_cache",
    "runs",
    ".git",
    "*.egg-info",
    ".venv",
    "node_modules",
    "build",
    "dist",
    ".cache",
    ".runs",
)


def _get_run_code(function_path: str):
    sys.path.append(os.getcwd())
    module_path, func_name = function_path.split(":")
    mod = importlib.import_module(module_path)
    func = getattr(mod, func_name)
    return func


def train(args: argparse.Namespace) -> None:

    config = project.get_config()

    func = _get_run_code(config["function_path"])

    if args.azureml:

        with TemporaryDirectory() as output_dir:

            shutil.copytree(
                src=os.getcwd(),
                dst=os.path.join(output_dir, "package"),
                ignore=SNAPSHOT_IGNORE,
            )

            experiment = Experiment.from_resource_names(
                subscription_id=config["subscription_id"],
                resource_group=config["resource_group"],
                workspace_name=config["workspace_name"],
                experiment_name=config["experiment_name"],
            )

            tracker = AzureMLTracker(experiment, output_dir)

            tracking.set_tracker(tracker)

            with tracking.get_tracker() as started_tracker:
                func()

            run = experiment.get_run(started_tracker.run_id)

            # Upload source code used for the run

            run.upload_folder(
                src_dir=output_dir,
                dest_dir="output",
            )

            print("\nLink to experiment in Azure ML:" f"\n\n{run.portal_url}")

            print(
                "\nRegister run as new model version via:"
                f"\n\nmodelzone register {run.run_id}"
            )

    else:
        output_dir = os.path.join(
            os.getcwd(), ".runs", dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        )

        tracker = LocalTracker(output_dir)

        tracking.set_tracker(tracker)

        with tracking.get_tracker():
            func()


def register(args: argparse.Namespace) -> None:
    from modelzone import Run

    config = project.get_config()

    run = Run.from_resource_names(
        subscription_id=config["subscription_id"],
        resource_group=config["resource_group"],
        workspace_name=config["workspace_name"],
        experiment_name=config["experiment_name"],
        run_id=args.run_id,
    )

    version = run.register()

    print(f"Registered model '{config['experiment_name']}' version {version}")


def fetch(args: argparse.Namespace) -> None:
    from modelzone import Model

    config = project.get_config()

    for model_config in config["models"]:

        print(
            f"Downloading model {model_config['name']} "
            f"version {model_config['version']}..."
        )

        run = Model.from_resource_names(
            subscription_id=config["subscription_id"],
            resource_group=config["resource_group"],
            workspace_name=config["workspace_name"],
            model_name=model_config["name"],
            version=model_config["version"],
        )

        run.download_folder(
            src_dir="output/package",
            dest_dir=f".models/packages/{model_config['name']}",
            overwrite=True,
        )

        run.download_folder(
            src_dir="output/artifacts",
            dest_dir=".models/artifacts",
            overwrite=True,
        )


def main() -> None:
    parser = argparse.ArgumentParser(prog="modelzone", description="Modelzone CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    t = sub.add_parser("train", help="Train a model (runs in current directory)")
    t.add_argument(
        "--azureml", action="store_true", help="Log to AzureML (default: local run)"
    )
    t.add_argument(
        "--quick",
        action="store_true",
        help="Quick run with reduced data (model-defined)",
    )

    r = sub.add_parser("register", help="Register a run as a model version")
    r.add_argument("run_id", help="MLFlow run ID to register")

    sub.add_parser("fetch")

    args = parser.parse_args()
    if args.command == "train":
        train(args)
    elif args.command == "register":
        register(args)
    elif args.command == "fetch":
        fetch(args)
    else:
        raise ValueError(f"Unknown command {args.command}")
