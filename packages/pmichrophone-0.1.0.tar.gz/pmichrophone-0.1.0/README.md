this is a simple utility to grab the michrophones info settings

im cradzy on youtube sub to me

this is a organized ez to use lib

credits to sounddevice lib