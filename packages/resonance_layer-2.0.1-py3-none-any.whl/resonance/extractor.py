# Copyright (c) 2026 William Ferrell. All rights reserved.
# Licensed under the Business Source License 1.1 — see LICENSE for details.
# Resonance — extractor.py
# v3 — ethics safeguards: crisis_detected, sustained_distress, outward_reflection

import os
import json
import re
import contextlib
from dataclasses import dataclass, field
from typing import Optional, List
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from nrclex import NRCLex
from textblob import TextBlob
from empath import Empath
from resonance.perma_lexicon import score_perma
from resonance.emoji_lexicon import get_emoji_emotion
from resonance.sdt_lexicon import score_sdt

MODEL_PATH = Path.home() / ".resonance" / "model_cache"
if not MODEL_PATH.exists():
    _local = Path(__file__).parent / "model"
    if _local.exists():
        MODEL_PATH = _local

ENSEMBLE_THRESHOLD = 0.65

CRISIS_PHRASES = [
    "want to die", "want to kill myself", "kill myself", "end my life",
    "ending my life", "end it all", "suicide", "suicidal",
    "don't want to be here", "don't want to live", "no reason to live",
    "can't go on", "can't do this anymore", "rather be dead",
    "hurting myself", "hurt myself", "cutting myself", "self harm",
    "self-harm", "overdose", "nothing to live for", "better off dead",
    "better off without me", "no point in living", "wish i was dead",
    "wish i were dead",
]

DISTRESS_VALENCE_THRESHOLD  = -0.40
DISTRESS_AROUSAL_THRESHOLD  = 0.55
SUSTAINED_DISTRESS_COUNT    = 3

OUTWARD_VALENCE_THRESHOLD   = -0.30
OUTWARD_SESSION_COUNT       = 5

@dataclass
class EmotionResult:
    valence: float = 0.0
    arousal: float = 0.0
    dominance: float = 0.0
    primary_emotion: str = "neutral"
    secondary_emotion: str = "neutral"
    window_of_tolerance: str = "in"
    wot_triggered_by: str = "none"
    wise_mind_signal: bool = False
    reappraisal_signal: bool = False
    suppression_signal: bool = False
    guilt_type: Optional[str] = None
    confidence: float = 0.0
    alexithymia_flag: bool = False
    modality: str = "text"
    raw_nrc_scores: dict = field(default_factory=dict)
    raw_empath_scores: dict = field(default_factory=dict)
    crisis_detected: bool = False
    sustained_distress: bool = False
    outward_reflection: bool = False
    perma_p: float = 0.0
    perma_e: float = 0.0
    perma_r: float = 0.0
    perma_m: float = 0.0
    perma_a: float = 0.0
    autonomy_signal: float = 0.0
    competence_signal: float = 0.0
    relatedness_signal: float = 0.0
    wot_trajectory: str = "stable"
    reappraisal_score: float = 0.0
    suppression_score: float = 0.0
    wise_mind_score: float = 0.0
    session_trajectory: str = "stable"

    def __str__(self):
        wot_flag = "✓in" if self.window_of_tolerance == "in" else "⚠OUT"
        crisis_flag = " 🚨CRISIS" if self.crisis_detected else ""
        distress_flag = " ⚠DISTRESS" if self.sustained_distress else ""
        return (
            f"EmotionResult(\n"
            f"  primary={self.primary_emotion} / secondary={self.secondary_emotion}{crisis_flag}{distress_flag}\n"
            f"  VAD: valence={self.valence:+.2f}  arousal={self.arousal:.2f}  dominance={self.dominance:.2f}\n"
            f"  WoT={wot_flag} [{self.wot_triggered_by}]\n"
            f"  wise_mind={self.wise_mind_signal}({self.wise_mind_score:.2f})  reappraisal={self.reappraisal_signal}({self.reappraisal_score:.2f})  suppression={self.suppression_signal}({self.suppression_score:.2f})\n"
            f"  confidence={self.confidence:.2f}  alexithymia={self.alexithymia_flag}  modality={self.modality}\n"
            f"  crisis={self.crisis_detected}  sustained_distress={self.sustained_distress}  outward_reflection={self.outward_reflection}\n"
            f"  PERMA: P={self.perma_p:+.2f}  E={self.perma_e:+.2f}  R={self.perma_r:+.2f}  M={self.perma_m:+.2f}  A={self.perma_a:+.2f}\n"
            f"  SDT: autonomy={self.autonomy_signal:.2f}  competence={self.competence_signal:.2f}  relatedness={self.relatedness_signal:.2f}\n"
            f"  WoT trajectory={self.wot_trajectory}  session trajectory={self.session_trajectory}\n"
            f")"
        )

    def to_prompt(self) -> str:
        """
        Returns a plain-English emotional context string ready to inject
        into any LLM system prompt. This is the core developer API.

        Usage:
            context = r.process("I've been so anxious about this")
            llm.chat(system=context.to_prompt(), message=message)
        """
        lines = []
        lines.append("[Resonance Emotional Context]")
        lines.append(f"Current emotion: {self.primary_emotion} (confidence: {self.confidence:.0%})")
        if self.secondary_emotion and self.secondary_emotion != self.primary_emotion:
            lines.append(f"Underlying emotion: {self.secondary_emotion}")
        lines.append(f"Mood (valence): {self.valence:+.2f}  Energy (arousal): {self.arousal:.2f}  Agency (dominance): {self.dominance:.2f}")
        lines.append(f"Window of Tolerance: {self.window_of_tolerance}")
        if self.wise_mind_score > 0.5:
            lines.append(f"Strong wise mind signal ({self.wise_mind_score:.2f}) - person is emotionally integrated and grounded. Match their balanced tone.")
        elif self.wise_mind_score > 0.2:
            lines.append(f"Wise mind signal detected ({self.wise_mind_score:.2f}) - person is moving toward balance.")
        elif self.wise_mind_signal:
            lines.append("Mild wise mind signal - person may be beginning to integrate their emotional and rational experience.")
        if self.reappraisal_score > 0.3:
            lines.append(f"Reappraisal detected ({self.reappraisal_score:.2f}) - person is actively reframing. Support the healthy processing.")
        elif self.reappraisal_signal:
            lines.append("Mild reappraisal signal - person may be beginning to reframe.")
        if self.suppression_score > 0.4:
            lines.append(f"Strong suppression signal ({self.suppression_score:.2f}) - person is holding back feelings. Create space gently.")
        elif self.suppression_score > 0.15:
            lines.append(f"Mild suppression signal ({self.suppression_score:.2f}) - person may be minimising their emotion.")
        elif self.suppression_signal:
            lines.append("Suppression detected - person may be holding back feelings.")
        if self.guilt_type:
            lines.append(f"Guilt type detected: {self.guilt_type}")
        if self.alexithymia_flag:
            lines.append("Low emotional vocabulary detected — person may struggle to name feelings directly.")
        if self.crisis_detected:
            lines.append("CRISIS DETECTED — surface appropriate support immediately.")
        if self.sustained_distress:
            lines.append("Sustained distress pattern detected — prioritise validation and care.")
        if self.perma_p < -0.3:
            lines.append(f"Positive emotion low (P={self.perma_p:+.2f}) - person may be struggling emotionally.")
        if self.perma_r < -0.3:
            lines.append(f"Loneliness or disconnection detected (R={self.perma_r:+.2f}) - prioritise warmth and connection.")
        if self.perma_m < -0.3:
            lines.append(f"Low sense of meaning or purpose (M={self.perma_m:+.2f}) - avoid hollow reassurance.")
        if self.perma_p > 0.3:
            lines.append(f"Positive emotion high (P={self.perma_p:+.2f}) - person is in a good place emotionally.")
        if self.perma_e > 0.3:
            lines.append(f"High engagement or flow detected (E={self.perma_e:+.2f}) - person is absorbed and motivated.")
        if self.perma_r > 0.3:
            lines.append(f"Strong connection or belonging signal (R={self.perma_r:+.2f}).")
        if self.perma_m > 0.3:
            lines.append(f"Strong sense of meaning or purpose (M={self.perma_m:+.2f}).")
        if self.perma_a > 0.3:
            lines.append(f"Accomplishment signal detected (A={self.perma_a:+.2f}) - acknowledge their effort or success.")
        if self.relatedness_signal < 0.1 and self.perma_r < -0.2:
            lines.append(f"Loneliness or isolation signal detected (relatedness={self.relatedness_signal:.2f}) - this person may feel deeply alone.")
        elif self.relatedness_signal > 0.4:
            lines.append(f"Strong social connection signal (relatedness={self.relatedness_signal:.2f}).")
        if self.wot_trajectory == "escalating":
            lines.append(f"WoT trajectory is escalating - person is moving toward dysregulation. Use calm, grounding language.")
        elif self.wot_trajectory == "deescalating":
            lines.append(f"WoT trajectory is deescalating - person is returning to regulation. Gently affirm their stability.")
        if self.session_trajectory == "improving":
            lines.append(f"Overall session trajectory: improving - person is moving in a positive direction. Match and affirm their progress.")
        elif self.session_trajectory == "declining":
            lines.append(f"Overall session trajectory: declining - multiple signals moving in a negative direction. Prioritise care and stability.")
        if self.autonomy_signal > 0.4:
            lines.append(f"High agency and self-direction detected (autonomy={self.autonomy_signal:.2f}).")
        if self.competence_signal > 0.4:
            lines.append(f"Strong mastery or competence signal (competence={self.competence_signal:.2f}) - acknowledge their capability.")
        lines.append("")
        lines.append("Respond to how this person actually feels, not just what they said.")
        lines.append("Validate before problem-solving. Never jump straight to fixing.")
        if self.window_of_tolerance == "hyperarousal":
            lines.append("Use calm, slow language — this person is overwhelmed.")
        elif self.window_of_tolerance == "hypoarousal":
            lines.append("Use warm, gently activating language — this person is withdrawn.")
        return "\n".join(lines)

VAD = {
    "joy":      (0.88, 0.60, 0.75),
    "anger":    (-0.60, 0.85, 0.65),
    "fear":     (-0.70, 0.80, 0.20),
    "sadness":  (-0.75, 0.25, 0.20),
    "surprise": (0.20, 0.75, 0.40),
    "shame":    (-0.65, 0.45, 0.15),
    "neutral":  (0.00, 0.20, 0.50),
}

NRC_TO_CLASS = {
    "anger":        "anger",
    "fear":         "fear",
    "joy":          "joy",
    "sadness":      "sadness",
    "surprise":     "surprise",
    "disgust":      "anger",
    "trust":        "joy",
    "anticipation": "neutral",
}

SECONDARY_MAP = {
    "joy":      ["contentment", "happiness", "pride", "optimism", "enthusiasm", "hope", "relief", "love", "affection", "longing"],
    "anger":    ["frustration", "irritability", "rage", "disgust", "envy", "contempt", "aggression"],
    "fear":     ["anxiety", "worry", "nervousness", "panic", "dread", "apprehension"],
    "sadness":  ["grief", "disappointment", "loneliness", "helplessness", "hopelessness", "regret", "guilt"],
    "surprise": ["amazement", "confusion", "awe", "disbelief"],
    "shame":    ["embarrassment", "humiliation", "remorse", "self-blame", "moral_guilt", "social_guilt"],
    "neutral":  ["neutral"],
}

GUILT_KEYWORDS = {
    "shame":       ["ashamed", "shameful", "humiliated", "disgrace", "embarrassed"],
    "self-blame":  ["my fault", "i failed", "i should have", "i didn't", "blame myself"],
    "moral_guilt": ["wrong", "shouldn't have", "regret", "i hurt", "i caused"],
    "social_guilt":["let down", "disappointed", "failed them", "i owe", "i neglected"],
}

DISTANCING_WORDS = ["one", "people", "they", "someone", "person", "you", "we", "it"]
FIRST_PERSON     = ["i", "me", "my", "myself", "i'm", "i've", "i'll", "i'd"]
NEGATIVE_AFFECT  = ["hate", "angry", "sad", "depressed", "anxious", "scared", "hurt", "upset", "crying", "pain"]

HYPER_WORDS = ["furious", "terrified", "panicking", "overwhelmed", "exploding", "screaming", "raging", "frantic", "desperate"]
HYPO_WORDS  = ["numb", "empty", "shutdown", "frozen", "disconnected", "blank", "nothing", "void", "dissociated"]

REAPPRAISAL_PHRASES = [
    "looking at it", "thinking about it differently", "on the bright side",
    "silver lining", "trying to see", "putting it in perspective",
    "reframing", "it helped me realise", "i can see now", "makes sense now",
    "i understand now", "looking back", "in a way", "in some ways",
    "it is what it is", "could be worse", "at least", "the good news",
    "grateful for", "learning from", "growing from", "moving forward",
    "letting go", "accepting", "i accept",
]

REAPPRAISAL_WORDS = [
    "perspective", "reframe", "accept", "acceptance", "understand",
    "gratitude", "grateful", "growth", "learning", "lesson",
    "silver", "bright", "positive", "opportunity", "forward",
]

SUPPRESSION_PHRASES = [
    "i am fine", "i am okay", "it is fine", "no big deal",
    "does not matter", "whatever", "i do not care", "not a big deal",
    "i should not feel", "i should not be", "stop feeling",
    "i need to get over", "i need to move on", "push through",
    "keep going", "just ignore", "trying not to think",
    "do not want to talk", "rather not say", "never mind",
]

SUPPRESSION_WORDS = [
    "fine", "okay", "whatever", "regardless", "anyway",
    "ignore", "suppress", "hide", "pretend", "mask",
    "bottle", "push down", "bury", "swallow",
]

# Wise Mind detection -- tiered scoring
# Strong phrases: clear balanced/integrated thinking (0.30 each)
WISE_MIND_PHRASES_STRONG = [
    "i see both", "on one hand", "on the other hand",
    "both are true", "i can hold", "i understand and",
    "even though i feel", "and yet i know", "i accept that",
    "i can acknowledge", "it makes sense that", "i can see why",
    "validating my feelings", "i am allowed to feel",
    "my emotions make sense", "i can feel this and still",
]

# Moderate phrases: moving toward integration (0.20 each)
WISE_MIND_PHRASES_MODERATE = [
    "makes sense", "i understand", "i accept", "even though",
    "and yet", "both", "i can see", "at the same time",
    "part of me", "i know that", "in a way", "i recognise",
    "i notice", "i am aware", "stepping back", "taking a breath",
]

# Word signals: grounded, integrated language (0.10 each)
WISE_MIND_WORDS = [
    "balance", "balanced", "grounded", "centred", "centered",
    "integrated", "clarity", "clear", "calm", "aware",
    "mindful", "present", "considered", "thoughtful",
    "reasonable", "rational", "emotional", "both",
]

class Extractor:
    def __init__(self):
        self.empath = Empath()
        self._confidence_profile = {}
        self._load_confidence_profile()
        self._load_model()
        self._load_student_model()

    def _load_confidence_profile(self):
        profile_path = MODEL_PATH / "confidence_profile.json"
        if profile_path.exists():
            try:
                with open(profile_path) as f:
                    self._confidence_profile = json.load(f)
            except Exception:
                self._confidence_profile = {}

    def _get_confidence_floor(self, emotion: str) -> float:
        if emotion in self._confidence_profile:
            return self._confidence_profile[emotion].get("confidence_floor", ENSEMBLE_THRESHOLD)
        return ENSEMBLE_THRESHOLD

    def _load_model(self):
        self._model = None
        self._tokenizer = None
        self._label_map = None
        try:
            label_map_path = MODEL_PATH / "label_map.json"
            if not label_map_path.exists():
                return
            with open(label_map_path) as f:
                self._label_map = {int(k): v for k, v in json.load(f).items()}
            import io
            from contextlib import redirect_stderr
            self._tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH))
            with redirect_stderr(io.StringIO()):
                self._model = AutoModelForSequenceClassification.from_pretrained(
                    str(MODEL_PATH), local_files_only=True
                )
            self._model.eval()
            if torch.cuda.is_available():
                self._model = self._model.cuda()
        except Exception:
            self._model = None

    def _load_student_model(self):
        """Load the v2 student model (DeBERTa-v3-base) for primary emotion detection."""
        self._student_model = None
        self._student_tokenizer = None
        try:
            from resonance.student_model import StudentModel
            from transformers import DebertaV2Model

            # Find model path
            _student_path = Path.home() / ".resonance" / "student_model.pt"
            if not _student_path.exists():
                _student_path = Path(__file__).parent.parent / "models" / "student_deberta_base" / "model_state_averaged.pt"
            if not _student_path.exists():
                import logging
                logging.getLogger("resonance").warning(
                    "[Resonance] Student model not found â€” running in v1 compatibility mode. "
                    "Run `resonance-download-model` or reinstall to get the full model."
                )
                return

            _hf_name = "microsoft/deberta-v3-base"
            self._student_tokenizer = AutoTokenizer.from_pretrained(_hf_name)
            import io
            from contextlib import redirect_stderr
            with redirect_stderr(io.StringIO()):
                _backbone = DebertaV2Model.from_pretrained(_hf_name)
            self._student_model = StudentModel(_backbone)
            _state = torch.load(_student_path, map_location="cpu")
            self._student_model.load_state_dict(_state)
            self._student_model.eval()
            if torch.cuda.is_available():
                self._student_model = self._student_model.cuda()
        except Exception as e:
            import logging
            logging.getLogger("resonance").warning(
                f"[Resonance] Student model failed to load ({e}) â€” running in v1 compatibility mode."
            )
            self._student_model = None
            self._student_tokenizer = None

    def _predict_student(self, text: str):
        """Run student model inference. Returns (emotion, confidence, outputs_dict)."""
        EMOTIONS = ["joy", "anger", "fear", "sadness", "surprise", "shame", "neutral"]
        try:
            enc = self._student_tokenizer(
                text, return_tensors="pt", max_length=256,
                truncation=True, padding="max_length"
            )
            device = next(self._student_model.parameters()).device
            enc = {k: v.to(device) for k, v in enc.items()}
            with torch.no_grad():
                with torch.amp.autocast("cuda", dtype=torch.bfloat16) if torch.cuda.is_available() else contextlib.nullcontext():
                    out = self._student_model(enc["input_ids"], enc["attention_mask"])
            probs = torch.softmax(out["primary"].float(), dim=-1).cpu()[0]
            idx   = probs.argmax().item()
            return EMOTIONS[idx], float(probs[idx]), out
        except Exception:
            return None, 0.0, None

    def _predict_model(self, text: str):
        inputs = self._tokenizer(
            text, return_tensors="pt", truncation=True,
            max_length=128, padding=True
        )
        if torch.cuda.is_available():
            inputs = {k: v.cuda() for k, v in inputs.items()}
        with torch.no_grad():
            logits = self._model(**inputs).logits
            probs  = torch.softmax(logits, dim=1)[0]
            idx    = int(probs.argmax())
        return self._label_map[idx], float(probs[idx])

    def _predict_nrc(self, nrc: dict):
        scores = {e: 0.0 for e in VAD}
        for nrc_emotion, score in nrc.items():
            mapped = NRC_TO_CLASS.get(nrc_emotion)
            if mapped and score > 0:
                scores[mapped] += score
        best = max(scores, key=scores.get)
        best_score = scores[best]
        if best_score == 0:
            return "neutral", 0.30
        return best, min(0.60, best_score / 5.0)

    def _predict_ensemble(self, text: str, nrc: dict):
        # Student model is the primary predictor in v2
        if self._student_model is not None:
            emotion, conf, _ = self._predict_student(text)
            if emotion is not None and conf >= 0.40:
                return emotion, conf
        # Fall back to existing ensemble if student unavailable or low confidence
        if self._model is None:
            return self._predict_nrc(nrc)
        model_emotion, model_conf = self._predict_model(text)
        floor = self._get_confidence_floor(model_emotion)
        if model_conf >= floor:
            return model_emotion, model_conf
        nrc_emotion, nrc_conf = self._predict_nrc(nrc)
        model_weight = model_conf / floor
        nrc_weight   = 1.0 - model_weight
        if model_emotion == nrc_emotion:
            blended_conf = (model_conf * model_weight) + (nrc_conf * nrc_weight)
            return model_emotion, round(blended_conf, 4)
        if (model_conf * model_weight) >= (nrc_conf * nrc_weight):
            return model_emotion, round(model_conf * model_weight, 4)
        else:
            return nrc_emotion, round(nrc_conf * nrc_weight, 4)

    def _detect_emoji_emotion(self, text: str):
        """
        Detect emoji emotion using the MLE-based emoji_lexicon.
        Returns the highest-confidence emotion found, or None.
        Uses confidence scores from Godard & Holtzman (2022) MLE research.
        """
        result = get_emoji_emotion(text)
        if result:
            return result  # returns (emotion, confidence) tuple
        return None

    def _detect_secondary_independent(self, text: str, primary: str, nrc: dict) -> str:
        """
        Detect secondary emotion independently from primary.
        Uses NRC scores and keyword matching to find the strongest
        secondary emotion signal in the text, regardless of primary.
        Primary and secondary can now differ simultaneously.
        """
        lower = text.lower()
        words = lower.split()

        # Score all 7 emotion classes independently from text signals
        scores = {
            "joy":      0.0,
            "anger":    0.0,
            "fear":     0.0,
            "sadness":  0.0,
            "surprise": 0.0,
            "shame":    0.0,
            "neutral":  0.0,
        }

        # Layer 1 -- NRC affect frequencies
        nrc_map = {
            "joy": ["joy", "trust"],
            "anger": ["anger", "disgust"],
            "fear": ["fear"],
            "sadness": ["sadness"],
            "surprise": ["surprise", "anticipation"],
            "shame": [],
            "neutral": [],
        }
        for emotion, nrc_keys in nrc_map.items():
            for key in nrc_keys:
                scores[emotion] += nrc.get(key, 0.0)

        # Layer 2 -- keyword signals per class
        SECONDARY_KEYWORDS = {
            "joy": ["happy", "glad", "pleased", "grateful", "excited", "love", "proud", "relieved", "hopeful"],
            "anger": ["angry", "furious", "annoyed", "frustrated", "rage", "mad", "bitter", "resentful"],
            "fear": ["afraid", "scared", "terrified", "anxious", "worried", "nervous", "dread", "panic"],
            "sadness": ["sad", "grief", "heartbroken", "lonely", "hopeless", "depressed", "devastated", "disappointed"],
            "surprise": ["surprised", "shocked", "amazed", "stunned", "astonished", "unexpected"],
            "shame": ["ashamed", "humiliated", "embarrassed", "guilty", "regret", "remorse", "self-blame"],
        }
        for emotion, keywords in SECONDARY_KEYWORDS.items():
            for kw in keywords:
                if kw in lower:
                    scores[emotion] += 0.3

        # Zero out primary so secondary is always different
        scores[primary] = -1.0

        # Return the highest scoring secondary
        best = max(scores, key=scores.get)
        if scores[best] <= 0.0:
            # No clear secondary signal -- fall back to SECONDARY_MAP defaults
            fallback = SECONDARY_MAP.get(primary, ["neutral"])
            return fallback[0]
        return best

    def _detect_guilt(self, text: str):
        lower = text.lower()
        for guilt_type, keywords in GUILT_KEYWORDS.items():
            if any(kw in lower for kw in keywords):
                return guilt_type
        return None

    def _detect_reappraisal(self, text: str) -> float:
        """
        Score reappraisal signal [0, 1].
        Reappraisal = actively reframing or finding meaning in a situation.
        Higher score = stronger reappraisal signal.
        """
        lower = text.lower()
        words = lower.split()
        n = max(len(words), 1)

        score = 0.0

        # Phrase matches (stronger signal)
        for phrase in REAPPRAISAL_PHRASES:
            if phrase in lower:
                score += 0.25

        # Word matches (weaker signal)
        for word in REAPPRAISAL_WORDS:
            if word in lower:
                score += 0.12

        # Linguistic distancing -- using "one" / "people" / "you" instead of "I"
        # when talking about negative affect = cognitive distancing = reappraisal
        fp   = sum(1 for w in words if w in FIRST_PERSON)
        dist = sum(1 for w in words if w in DISTANCING_WORDS)
        neg  = sum(1 for w in words if w in NEGATIVE_AFFECT)
        if dist > fp and neg > 0 and len(words) > 5:
            score += 0.20

        return round(min(1.0, score), 4)

    def _detect_suppression(self, text: str) -> float:
        """
        Score suppression signal [0, 1].
        Suppression = holding back, minimising, or pushing away emotion.
        Higher score = stronger suppression signal.
        """
        lower = text.lower()
        words = lower.split()
        n = max(len(words), 1)

        score = 0.0

        # Phrase matches (strong signal)
        for phrase in SUPPRESSION_PHRASES:
            if phrase in lower:
                score += 0.30

        # Word matches (weaker signal)
        for word in SUPPRESSION_WORDS:
            if word in lower:
                score += 0.12

        # First person + negative affect without emotional elaboration
        # = emotional experience present but not being processed
        fp  = sum(1 for w in words if w in FIRST_PERSON)
        neg = sum(1 for w in words if w in NEGATIVE_AFFECT)
        if fp >= 2 and neg >= 1:
            score += 0.15

        return round(min(1.0, score), 4)

    def _detect_wot(self, valence: float, arousal: float, text: str):
        lower = text.lower()
        has_hyper_word = any(w in lower for w in HYPER_WORDS)
        has_hypo_word  = any(w in lower for w in HYPO_WORDS)
        if has_hyper_word and arousal > 0.60:
            return "hyperarousal", "hyperarousal_words"
        if has_hypo_word or (valence < -0.60 and arousal < 0.25):
            return "hypoarousal", "hypoarousal_words"
        return "in", "none"

    def _detect_wise_mind(self, text: str) -> float:
        """
        Score Wise Mind signal [0, 1].
        Wise Mind = balanced, integrated thinking that acknowledges both
        emotional experience and rational perspective simultaneously.
        Higher score = stronger wise mind signal.
        """
        lower = text.lower()
        score = 0.0

        # Strong phrases -- clear integrated thinking
        for phrase in WISE_MIND_PHRASES_STRONG:
            if phrase in lower:
                score += 0.30

        # Moderate phrases -- moving toward integration
        for phrase in WISE_MIND_PHRASES_MODERATE:
            if phrase in lower:
                score += 0.20

        # Word signals -- grounded language
        for word in WISE_MIND_WORDS:
            if word in lower:
                score += 0.10

        return round(min(1.0, score), 4)

    def _detect_alexithymia(self, nrc: dict, text: str):
        emotion_word_count = sum(1 for v in nrc.values() if v > 0)
        words = text.split()
        density = emotion_word_count / max(len(words), 1)
        return density < 0.02 and len(words) > 10

    def _detect_crisis(self, text: str) -> bool:
        lower = text.lower()
        return any(phrase in lower for phrase in CRISIS_PHRASES)

    def _detect_sustained_distress(
        self,
        history: List["EmotionResult"],
        suppression_score: float = 0.0,
        wot_trajectory: str = "stable",
    ) -> bool:
        """
        Detect sustained distress across recent messages.

        Two factors lower the trigger threshold beyond raw VAD scores:

        1. High suppression score -- suppressed distress is harder to see
           but no less real. A person saying 'I am fine' while distressed
           scores lower on arousal but the suppression signal reveals what
           the words are hiding.

        2. Escalating WoT trajectory -- if the session is moving toward
           dysregulation, trigger sustained distress sooner. The direction
           of travel matters as much as the current state.

        Threshold adjustments (cumulative):
          suppression >= 0.5:   valence +0.15, arousal -0.15
          wot_trajectory == escalating: valence +0.10, arousal -0.10
          Both active:          valence +0.25, arousal -0.25 (combined)
        """
        if len(history) < SUSTAINED_DISTRESS_COUNT:
            return False
        recent = history[-SUSTAINED_DISTRESS_COUNT:]

        valence_threshold = DISTRESS_VALENCE_THRESHOLD
        arousal_threshold = DISTRESS_AROUSAL_THRESHOLD

        # Factor 1: high suppression -- trust the signal even if muted
        if suppression_score >= 0.5:
            valence_threshold += 0.15
            arousal_threshold -= 0.15

        # Factor 2: escalating WoT trajectory -- session moving toward dysregulation
        if wot_trajectory == "escalating":
            valence_threshold += 0.10
            arousal_threshold -= 0.10

        return all(
            r.valence <= valence_threshold and
            r.arousal >= arousal_threshold
            for r in recent
        )

    def _detect_outward_reflection(self, history: List["EmotionResult"]) -> bool:
        if len(history) < OUTWARD_SESSION_COUNT:
            return False
        recent = history[-OUTWARD_SESSION_COUNT:]
        return all(r.valence <= OUTWARD_VALENCE_THRESHOLD for r in recent)

    def _detect_wot_trajectory(self, history: list, current_wot: str) -> str:
        """
        Detect session-level WoT trajectory across recent messages.
        Returns: "escalating" | "stable" | "deescalating"

        Escalating   = moving toward or deeper into dysregulation (hyper or hypo)
        Deescalating = moving back toward the window of tolerance
        Stable       = no meaningful change
        """
        WOT_SCORE = {"in": 0, "hyperarousal": 1, "hypoarousal": -1}

        if len(history) < 2:
            return "stable"

        # Use last 5 messages for trajectory
        window = history[-5:]
        scores = [WOT_SCORE.get(r.window_of_tolerance, 0) for r in window]
        scores.append(WOT_SCORE.get(current_wot, 0))

        # Count dysregulated vs regulated states
        dysregulated = [s for s in scores if s != 0]
        in_window = [s for s in scores if s == 0]

        if len(scores) < 3:
            return "stable"

        # Look at first half vs second half
        mid = len(scores) // 2
        early = scores[:mid]
        late = scores[mid:]

        early_dysreg = sum(1 for s in early if s != 0)
        late_dysreg = sum(1 for s in late if s != 0)

        if late_dysreg > early_dysreg:
            return "escalating"
        elif early_dysreg > late_dysreg:
            return "deescalating"
        else:
            # Check if current state is dysregulated vs history average
            history_avg_dysreg = sum(1 for s in scores[:-1] if s != 0) / max(len(scores) - 1, 1)
            if scores[-1] != 0 and history_avg_dysreg < 0.3:
                return "escalating"
            elif scores[-1] == 0 and history_avg_dysreg > 0.5:
                return "deescalating"
            return "stable"

    def _detect_session_trajectory(
        self,
        history: list,
        current_valence: float,
        current_perma_p: float,
        wot_trajectory: str,
        suppression_score: float,
    ) -> str:
        """
        Detect overall session trajectory -- direction of travel across all signals.
        Combines: valence trend + WoT trajectory + suppression trend + PERMA-P trend.
        Returns: "improving" | "stable" | "declining"

        Improving = multiple signals moving in a positive direction
        Declining = multiple signals moving in a negative direction
        Stable    = no meaningful change or signals mixed
        """
        if len(history) < 3:
            return "stable"

        # --- Valence trend ---
        valences = [r.valence for r in history[-5:]] + [current_valence]
        mid = len(valences) // 2
        valence_early = sum(valences[:mid]) / max(len(valences[:mid]), 1)
        valence_late  = sum(valences[mid:]) / max(len(valences[mid:]), 1)
        valence_delta = valence_late - valence_early

        # --- PERMA-P trend ---
        perma_values = [getattr(r, "perma_p", 0.0) for r in history[-5:]] + [current_perma_p]
        perma_early = sum(perma_values[:mid]) / max(len(perma_values[:mid]), 1)
        perma_late  = sum(perma_values[mid:]) / max(len(perma_values[mid:]), 1)
        perma_delta = perma_late - perma_early

        # --- Suppression trend ---
        supp_values = [getattr(r, "suppression_score", 0.0) for r in history[-5:]]
        supp_trend = "rising" if len(supp_values) >= 2 and supp_values[-1] > supp_values[0] + 0.2 else "stable"

        # --- Score positive and negative signals ---
        positive = 0
        negative = 0

        # Valence trend
        if valence_delta > 0.10:
            positive += 2
        elif valence_delta < -0.10:
            negative += 2

        # PERMA-P trend
        if perma_delta > 0.15:
            positive += 1
        elif perma_delta < -0.15:
            negative += 1

        # WoT trajectory
        if wot_trajectory == "deescalating":
            positive += 2
        elif wot_trajectory == "escalating":
            negative += 2

        # Suppression trend
        if supp_trend == "rising":
            negative += 1

        # Verdict
        if positive >= 3 and positive > negative:
            return "improving"
        elif negative >= 3 and negative > positive:
            return "declining"
        else:
            return "stable"

    def extract(
        self,
        text: str,
        modality: str = "text",
        history: Optional[List["EmotionResult"]] = None
    ) -> "EmotionResult":
        if history is None:
            history = []

        if not text or not text.strip():
            return EmotionResult(modality=modality)

        nrc_obj = NRCLex(text)
        nrc_obj.load_raw_text(text)
        nrc    = nrc_obj.affect_frequencies
        empath = self.empath.analyze(text, normalize=True) or {}

        emoji_result = self._detect_emoji_emotion(text)
        if emoji_result:
            primary, confidence = emoji_result
            _student_out = None
        else:
            # Try student model first
            if self._student_model is not None:
                _s_emotion, _s_conf, _student_out = self._predict_student(text)
                if _s_emotion is not None and _s_conf >= 0.40:
                    primary, confidence = _s_emotion, _s_conf
                else:
                    primary, confidence = self._predict_ensemble(text, nrc)
                    _student_out = None
            else:
                primary, confidence = self._predict_ensemble(text, nrc)
                _student_out = None

        # Wire student secondary heads if available
        GUILT_TYPES = ["shame_guilt", "self_blame", "moral_guilt", "social_guilt"]
        if _student_out is not None:
            try:
                import torch.nn.functional as F
                # VAD from student
                _vad = _student_out["vad"].float().cpu()[0]
                _s_valence    = float(torch.tanh(_vad[0]))
                _s_arousal    = float(torch.sigmoid(_vad[1]))
                _s_dominance  = float(torch.sigmoid(_vad[2]))
                # Guilt from student
                _guilt_logits = _student_out["guilt"].float().cpu()[0]
                _guilt_probs  = torch.sigmoid(_guilt_logits)
                _guilt_idx    = _guilt_probs.argmax().item()
                _s_guilt_type = GUILT_TYPES[_guilt_idx] if float(_guilt_probs[_guilt_idx]) > 0.3 else None
                # Crisis from student
                _s_crisis     = float(torch.sigmoid(_student_out["crisis"].float().cpu()[0])) > 0.5
                # Reappraisal from student
                _s_reap       = float(torch.sigmoid(_student_out["reappraisal"].float().cpu()[0]))
                # Suppression from student
                _s_supp       = float(torch.sigmoid(_student_out["suppression"].float().cpu()[0]))
                # Alexithymia from student
                _s_alex       = float(torch.sigmoid(_student_out["alexithymia"].float().cpu()[0])) > 0.5
                _use_student_heads = True
            except Exception:
                _use_student_heads = False
        else:
            _use_student_heads = False

        if _use_student_heads:
            valence, arousal, dominance = _s_valence, _s_arousal, _s_dominance
        else:
            valence, arousal, dominance = VAD.get(primary, (0.0, 0.2, 0.5))
            blob_polarity = TextBlob(text).sentiment.polarity
            valence = (valence + blob_polarity) / 2

        secondary        = self._detect_secondary_independent(text, primary, nrc)
        wot, wot_trigger = self._detect_wot(valence, arousal, text)
        wot_trajectory       = self._detect_wot_trajectory(history, wot)
        suppression          = _s_supp if _use_student_heads else self._detect_suppression(text)
        reappraisal          = _s_reap if _use_student_heads else self._detect_reappraisal(text)
        wise_mind        = self._detect_wise_mind(text)
        guilt_type       = _s_guilt_type if _use_student_heads else self._detect_guilt(text)
        alexithymia      = _s_alex if _use_student_heads else self._detect_alexithymia(nrc, text)
        crisis           = (_s_crisis or self._detect_crisis(text)) if _use_student_heads else self._detect_crisis(text)
        sustained        = self._detect_sustained_distress(history, suppression_score=suppression, wot_trajectory=wot_trajectory)
        outward             = self._detect_outward_reflection(history)
        perma               = score_perma(text)
        sdt                 = score_sdt(text)
        session_trajectory  = self._detect_session_trajectory(
            history,
            current_valence=valence,
            current_perma_p=perma["P"],
            wot_trajectory=wot_trajectory,
            suppression_score=suppression,
        )

        return EmotionResult(
            valence=round(valence, 4),
            arousal=round(arousal, 4),
            dominance=round(dominance, 4),
            primary_emotion=primary,
            secondary_emotion=secondary,
            window_of_tolerance=wot,
            wot_triggered_by=wot_trigger,
            wise_mind_signal=bool(wise_mind),
            reappraisal_signal=bool(reappraisal),
            suppression_signal=bool(suppression),
            guilt_type=guilt_type,
            confidence=round(confidence, 4),
            alexithymia_flag=alexithymia,
            modality=modality,
            raw_nrc_scores=dict(nrc),
            raw_empath_scores={k: v for k, v in empath.items() if v and v > 0},
            crisis_detected=crisis,
            sustained_distress=sustained,
            outward_reflection=outward,
            perma_p=round(perma["P"], 4),
            perma_e=round(perma["E"], 4),
            perma_r=round(perma["R"], 4),
            perma_m=round(perma["M"], 4),
            perma_a=round(perma["A"], 4),
            autonomy_signal=round(sdt["autonomy"], 4),
            competence_signal=round(sdt["competence"], 4),
            relatedness_signal=round(sdt["relatedness"], 4),
            wot_trajectory=wot_trajectory,
            reappraisal_score=reappraisal,
            suppression_score=suppression,
            wise_mind_score=wise_mind,
            session_trajectory=session_trajectory,
        )
