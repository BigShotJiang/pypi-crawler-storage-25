"""HTTP(S) proxy that intercepts AI API calls and scans for secrets."""

from __future__ import annotations

import json

from mitmproxy import http, ctx
from mitmproxy.options import Options
from mitmproxy.tools.dump import DumpMaster

from aigate.config import Config
from aigate.logger import log_detection
from aigate.redactor import redact_text, save_to_dotenv
from aigate.scanner import Finding, scan_text


def _extract_prompt_text(body: dict) -> list[tuple[str, str]]:
    """Extract text content from AI API request bodies."""
    texts: list[tuple[str, str]] = []
    messages = body.get("messages", [])

    for i, msg in enumerate(messages):
        content = msg.get("content")
        if isinstance(content, str):
            texts.append((f"messages[{i}].content", content))
        elif isinstance(content, list):
            for j, block in enumerate(content):
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    texts.append((f"messages[{i}].content[{j}].text", block.get("text", "")))
                elif btype == "tool_result":
                    inner = block.get("content", "")
                    if isinstance(inner, str):
                        texts.append((f"messages[{i}].content[{j}].content", inner))
                    elif isinstance(inner, list):
                        for k, sub in enumerate(inner):
                            if isinstance(sub, dict) and sub.get("type") == "text":
                                texts.append((f"messages[{i}].content[{j}].content[{k}].text", sub.get("text", "")))

    system = body.get("system")
    if isinstance(system, str):
        texts.append(("system", system))
    elif isinstance(system, list):
        for i, block in enumerate(system):
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append((f"system[{i}].text", block.get("text", "")))

    if not texts and messages:
        for i, msg in enumerate(messages):
            content = msg.get("content")
            if isinstance(content, str):
                texts.append((f"messages[{i}].content", content))

    prompt = body.get("prompt")
    if isinstance(prompt, str):
        texts.append(("prompt", prompt))
    elif isinstance(prompt, list):
        for i, p in enumerate(prompt):
            if isinstance(p, str):
                texts.append((f"prompt[{i}]", p))

    for i, tool in enumerate(body.get("tools", [])):
        if not isinstance(tool, dict):
            continue
        desc = tool.get("description", "")
        schema = tool.get("input_schema", {})
        if isinstance(schema, dict):
            desc = f"{desc} {json.dumps(schema)}"
        func = tool.get("function", {})
        if isinstance(func, dict):
            desc = f"{desc} {func.get('description', '')}"
        if desc.strip():
            texts.append((f"tools[{i}]", desc))

    return texts


def _build_blocked_response(findings: list[Finding]) -> str:
    rules = sorted({f.rule.replace("_", " ") for f in findings})
    return json.dumps({
        "error": {
            "type": "blocked_by_aigate",
            "message": f"aigate blocked this request: {', '.join(rules)} detected in prompt content",
            "details": [
                {
                    "rule": f.rule,
                    "match": f.redacted,
                    "location": f"{f.location}, offset {f.offset}" if f.location else f"offset {f.offset}",
                }
                for f in findings
            ],
            "action": "Remove the credential from your prompt and retry.",
        }
    })


class AigateAddon:
    """mitmproxy addon that scans AI API requests for secrets."""

    def __init__(self, config: Config):
        self.config = config
        self.provider_hosts = set(config.providers)
        self._seen_secrets: set[str] = set()  # track already-reported secrets

    def request(self, flow: http.HTTPFlow) -> None:
        if flow.request.pretty_host not in self.provider_hosts:
            return
        if flow.request.method != "POST":
            return
        if "json" not in flow.request.headers.get("content-type", ""):
            return

        try:
            body = json.loads(flow.request.get_text())
        except (json.JSONDecodeError, ValueError):
            return

        all_findings: list[Finding] = []
        for location, text in _extract_prompt_text(body):
            for f in scan_text(text, enabled_rules=self.config.rules, allowlist=self.config.allowlist):
                f.location = location
                all_findings.append(f)

        if not all_findings:
            return

        log_detection(
            self.config.log.file,
            provider=flow.request.pretty_host,
            findings=all_findings,
            action=self.config.mode,
            request_url=flow.request.pretty_url,
        )

        if self.config.mode == "redact":
            self._handle_redact(flow, all_findings)
        elif self.config.mode == "block":
            self._log_banner(all_findings, "BLOCKED")
            flow.response = http.Response.make(
                400, _build_blocked_response(all_findings), {"Content-Type": "application/json"},
            )
        elif self.config.mode == "warn":
            self._log_banner(all_findings, "WARNING — forwarded with secrets")
        elif self.config.mode == "audit":
            self._log_banner(all_findings, "AUDIT — logged only")

    @staticmethod
    def _log_banner(findings: list[Finding], action: str) -> None:
        rules = sorted({f.rule for f in findings})
        ctx.log.warn("")
        ctx.log.warn("  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓")
        ctx.log.warn(f"  ┃  🛡️  aigate — {action:<42}┃")
        ctx.log.warn("  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫")
        ctx.log.warn(f"  ┃  Secrets found: {len(findings):<40}┃")
        ctx.log.warn(f"  ┃  Rules:   {', '.join(rules):<47}┃")
        for f in findings:
            ctx.log.warn(f"  ┃    • {f.redacted:<51}┃")
        ctx.log.warn("  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛")
        ctx.log.warn("")

    def _handle_redact(self, flow: http.HTTPFlow, findings: list[Finding]) -> None:
        result = redact_text(flow.request.get_text(), findings)
        flow.request.set_text(result.redacted_text)

        env_actions = save_to_dotenv(result.redactions, env_path=self.config.env_file)

        has_new = any(r.finding.match not in self._seen_secrets for r in result.redactions)
        self._seen_secrets.update(r.finding.match for r in result.redactions)

        if has_new:
            # Full banner for first detection
            ctx.log.warn("")
            ctx.log.warn("  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓")
            ctx.log.warn(f"  ┃  🛡️  aigate — REDACTED {len(findings)} secret(s)               ┃")
            ctx.log.warn("  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫")
            for r in result.redactions:
                ctx.log.warn(f"  ┃  ✂ {r.finding.redacted:<52}┃")
                ctx.log.warn(f"  ┃    → {r.placeholder:<51}┃")
                ctx.log.warn(f"  ┃    → saved as {r.env_var_name:<40}┃")
            ctx.log.warn("  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫")
            ctx.log.warn("  ┃  📁 .env file updated                                  ┃")
            for a in env_actions:
                ctx.log.warn(f"  ┃    {a:<53}┃")
            ctx.log.warn("  ┃                                                        ┃")
            ctx.log.warn("  ┃  📤 Sanitized request forwarded to AI                   ┃")
            ctx.log.warn("  ┃     The AI will never see the real credentials          ┃")
            ctx.log.warn("  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛")
            ctx.log.warn("")
        else:
            # Quiet one-liner for repeat detections (message history)
            ctx.log.info(f"  🛡️  aigate — re-redacted {len(findings)} known secret(s)")

        try:
            redacted_body = json.loads(flow.request.get_text())
        except (json.JSONDecodeError, ValueError):
            return

        instruction = result.system_instruction
        if not instruction:
            return

        existing = redacted_body.get("system")
        if isinstance(existing, str):
            redacted_body["system"] = f"{existing}\n\n{instruction}"
        elif isinstance(existing, list):
            redacted_body["system"].append({"type": "text", "text": instruction})
        else:
            redacted_body["system"] = instruction

        flow.request.set_text(json.dumps(redacted_body))


async def run_proxy(config: Config) -> None:
    opts = Options(listen_host="127.0.0.1", listen_port=config.port, mode=["regular"])
    master = DumpMaster(opts)
    master.addons.add(AigateAddon(config))
    try:
        await master.run()
    except KeyboardInterrupt:
        master.shutdown()
