"""aigate CLI — AI Prompt Secret Scanner."""

from __future__ import annotations

import asyncio
import fnmatch
import json
import sys
from pathlib import Path

import click

from aigate import __version__
from aigate.config import Config, default_config_yaml, DEFAULT_CONFIG_NAME
from aigate.scanner import scan_text


def _line_number(text: str, offset: int) -> int:
    """Convert a character offset to a 1-based line number."""
    return text[:offset].count("\n") + 1


@click.group()
@click.version_option(version=__version__, prog_name="aigate")
def main():
    """aigate — scan and block secrets before they reach AI APIs."""


@main.command()
def setup():
    """One-time setup: install the CA cert so the proxy can inspect HTTPS traffic.

    Requires sudo. After this, just set HTTPS_PROXY and everything works.
    """
    from aigate.cert import install_cert, is_cert_installed

    if is_cert_installed():
        click.echo("CA cert already exists. Reinstalling into trust store...")
    else:
        click.echo("Generating and installing mitmproxy CA certificate...")

    try:
        actions = install_cert()
        click.echo()
        for action in actions:
            click.echo(f"   {action}")
        click.echo("\n✅ Done. The proxy can now inspect HTTPS traffic.")

        # Print export commands so `eval $(aigate setup)` works
        from aigate.cert import MITMPROXY_CA, LINUX_CA_BUNDLE
        import platform
        click.echo("")
        exports = [f'export NODE_EXTRA_CA_CERTS="{MITMPROXY_CA}"']
        if platform.system() == "Linux" and Path(LINUX_CA_BUNDLE).exists():
            exports.append(f'export REQUESTS_CA_BUNDLE="{LINUX_CA_BUNDLE}"')
            exports.append(f'export SSL_CERT_FILE="{LINUX_CA_BUNDLE}"')
        else:
            exports.append(f'export SSL_CERT_FILE="{MITMPROXY_CA}"')

        click.echo("   Apply env vars now (copy-paste this, or use eval):")
        click.echo("")
        for exp in exports:
            click.echo(f"   {exp}")
        click.echo("")
    except Exception as e:
        click.echo(f"\nError: {e}", err=True)
        click.echo("You may need to run: sudo aigate setup", err=True)
        sys.exit(1)


@main.command()
@click.option("--port", "-p", type=int, default=None, help="Proxy port (default: 8080)")
@click.option("--mode", "-m", type=click.Choice(["block", "redact", "warn", "audit"]), default=None)
@click.option("--config", "-c", "config_path", type=click.Path(), default=None)
def start(port: int | None, mode: str | None, config_path: str | None):
    """Start the aigate proxy."""
    from aigate.cert import is_cert_installed

    config = Config.load(config_path)
    if port is not None:
        config.port = port
    if mode is not None:
        config.mode = mode

    Path(config.log.file).expanduser().parent.mkdir(parents=True, exist_ok=True)

    if not is_cert_installed():
        click.echo("CA cert not found. Installing for HTTPS interception...")
        click.echo("(This requires sudo — one-time only)\n")
        from aigate.cert import install_cert
        try:
            for action in install_cert():
                click.echo(f"   {action}")
            click.echo()
        except Exception as e:
            click.echo(f"   Failed: {e}", err=True)
            click.echo("   Run 'sudo aigate setup' manually.\n", err=True)

    # Check if cert env vars are loaded in the current shell
    import os
    if is_cert_installed() and not os.environ.get("NODE_EXTRA_CA_CERTS"):
        click.echo("⚠️  NODE_EXTRA_CA_CERTS is not set in this shell.")
        click.echo("   Claude Code / Node.js won't trust the proxy yet.")
        click.echo("")
        click.echo("   Run this in the terminal where you use Claude Code:")
        click.echo("     source ~/.bashrc")
        click.echo("")

    click.echo(f"🛡️  aigate v{__version__}")
    click.echo(f"   Mode:      {config.mode}")
    click.echo(f"   Proxy:     http://127.0.0.1:{config.port}")
    click.echo(f"   Providers: {', '.join(config.providers)}")
    click.echo(f"   Log:       {config.log.file}")
    click.echo()
    click.echo("Point your AI tool at aigate:")
    click.echo(f"   export HTTPS_PROXY=http://127.0.0.1:{config.port}")
    click.echo(f"   export HTTP_PROXY=http://127.0.0.1:{config.port}")
    click.echo()

    from aigate.proxy import run_proxy
    asyncio.run(run_proxy(config))


@main.command()
@click.argument("target", default="-")
@click.option("--config", "-c", "config_path", type=click.Path(), default=None)
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.option("--redact", "-r", is_flag=True, help="Redact secrets and save to .env")
def scan(target: str, config_path: str | None, json_output: bool, redact: bool):
    """Scan a file or stdin for secrets."""
    config = Config.load(config_path)

    if target == "-":
        text = sys.stdin.read()
        source = "<stdin>"
    else:
        path = Path(target)
        if not path.exists():
            click.echo(f"Error: file not found: {target}", err=True)
            sys.exit(1)
        try:
            text = path.read_text()
        except (UnicodeDecodeError, ValueError):
            click.echo(f"Error: cannot scan binary file: {target}", err=True)
            sys.exit(1)
        source = str(path)

    findings = scan_text(text, enabled_rules=config.rules, allowlist=config.allowlist)

    if not findings:
        if json_output:
            click.echo(json.dumps({"source": source, "findings": [], "clean": True,
                                    **({"redacted_text": text} if redact else {})}))
        else:
            click.echo(f"✅ No secrets found in {source}")
        sys.exit(0)

    if redact:
        from aigate.redactor import redact_text, save_to_dotenv

        result = redact_text(text, findings)
        env_actions = save_to_dotenv(result.redactions, env_path=config.env_file)

        if json_output:
            click.echo(json.dumps({
                "source": source,
                "clean": False,
                "redacted_text": result.redacted_text,
                "redactions": [
                    {"rule": r.finding.rule, "env_var": r.env_var_name,
                     "placeholder": r.placeholder, "match_redacted": r.finding.redacted}
                    for r in result.redactions
                ],
            }))
        else:
            click.echo(f"🛡️  Redacted {len(result.redactions)} secret(s) in {source}:\n")
            for r in result.redactions:
                click.echo(f"  {r.finding.redacted} → {r.placeholder}")
            click.echo()
            for a in env_actions:
                click.echo(f"  {a}")
        sys.exit(0)

    if json_output:
        click.echo(json.dumps({
            "source": source,
            "clean": False,
            "findings": [{"rule": f.rule, "match_redacted": f.redacted, "offset": f.offset} for f in findings],
        }, indent=2))
    else:
        click.echo(f"🚨 {len(findings)} secret(s) found in {source}:\n")
        for f in findings:
            click.echo(f"  [{f.rule}] {f.redacted} (offset {f.offset})")
        click.echo()

    sys.exit(1)


@main.command()
@click.option("--path", "-p", "output_path", default=DEFAULT_CONFIG_NAME)
def init(output_path: str):
    """Create a default .aigate.yml config file."""
    path = Path(output_path)
    if path.exists():
        click.echo(f"Config already exists: {path}")
        sys.exit(1)
    path.write_text(f"# aigate configuration\n{default_config_yaml()}")
    click.echo(f"✅ Created {path}")


@main.command("install-hook")
def install_hook():
    """Install aigate as a Claude Code hook (recommended)."""
    from aigate.hooks import install_hooks

    actions = install_hooks()
    click.echo("🛡️  aigate Claude Code integration installed:\n")
    for action in actions:
        click.echo(f"   {action}")
    click.echo("\nDone. All prompts and tool inputs are now scanned automatically.")
    click.echo("To uninstall: aigate uninstall-hook")


@main.command("uninstall-hook")
def uninstall_hook():
    """Remove aigate Claude Code hooks."""
    from aigate.hooks import uninstall_hooks

    actions = uninstall_hooks()
    if actions:
        click.echo("Removed aigate from Claude Code:\n")
        for action in actions:
            click.echo(f"   {action}")
    else:
        click.echo("aigate hooks were not installed.")


@main.command()
@click.option("--tail", "-n", "num_lines", type=int, default=20, help="Number of entries to show")
@click.option("--follow", "-f", is_flag=True, help="Follow log output in real time")
def logs(num_lines: int, follow: bool):
    """View aigate scan logs."""
    log_file = Path.home() / ".aigate" / "scan.log"
    if not log_file.exists():
        click.echo("No logs yet.")
        return

    if follow:
        import subprocess
        subprocess.run(["tail", "-f", str(log_file)])
        return

    lines = log_file.read_text().strip().split("\n")
    for line in lines[-num_lines:]:
        try:
            e = json.loads(line)
            ts = e.get("timestamp", "?")
            action = e.get("action", "?")
            event = e.get("event", e.get("provider", "proxy"))
            tool = e.get("tool", "")
            rules = ", ".join(f.get("rule", "?") for f in e.get("findings", []))
            redacted = ", ".join(f.get("match_redacted", "?") for f in e.get("findings", []))
            label = f"{event}/{tool}" if tool else event
            click.echo(f"  {ts}  [{action.upper()}]  {label}  {rules}  {redacted}")
        except json.JSONDecodeError:
            click.echo(f"  {line}")


@main.group()
def allowlist():
    """Manage the allowlist for false positive suppression."""


@main.command("scan-dir")
@click.argument("directory", default=".")
@click.option("--config", "-c", "config_path", type=click.Path(), default=None)
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.option("--fix", is_flag=True, help="Replace secrets with env var references and save to .env")
@click.option("--dry-run", is_flag=True, help="With --fix, show what would change without modifying files")
@click.option("--ignore", multiple=True, help="Glob patterns to ignore (e.g. 'test/**')")
def scan_dir(directory: str, config_path: str | None, json_output: bool, fix: bool, dry_run: bool, ignore: tuple):
    """Scan a directory recursively for hardcoded secrets."""
    from aigate.redactor import redact_text, save_to_dotenv

    config = Config.load(config_path)
    root = Path(directory).resolve()

    if not root.is_dir():
        click.echo(f"Error: not a directory: {directory}", err=True)
        sys.exit(1)

    gitignore_patterns = _load_gitignore(root)
    ignore_patterns = list(ignore) + gitignore_patterns

    all_findings = []
    files_scanned = 0
    files_with_secrets = 0

    for filepath in _walk_files(root, ignore_patterns):
        try:
            text = filepath.read_text()
        except (UnicodeDecodeError, PermissionError):
            continue

        findings = scan_text(text, enabled_rules=config.rules, allowlist=config.allowlist)
        files_scanned += 1

        if not findings:
            continue

        files_with_secrets += 1
        rel_path = str(filepath.relative_to(root))

        if fix:
            result = redact_text(text, findings)

            if not dry_run:
                filepath.write_text(result.redacted_text)
                save_to_dotenv(result.redactions, env_path=config.env_file)

            for r in result.redactions:
                all_findings.append({
                    "file": rel_path,
                    "line": _line_number(text, r.finding.offset),
                    "rule": r.finding.rule,
                    "match_redacted": r.finding.redacted,
                    "env_var": r.env_var_name,
                    "action": "would_replace" if dry_run else "replaced",
                })
        else:
            for f in findings:
                all_findings.append({
                    "file": rel_path,
                    "line": _line_number(text, f.offset),
                    "rule": f.rule,
                    "match_redacted": f.redacted,
                })

    # Output results
    if json_output:
        click.echo(json.dumps({
            "directory": str(root),
            "files_scanned": files_scanned,
            "files_with_secrets": files_with_secrets,
            "total_findings": len(all_findings),
            "clean": len(all_findings) == 0,
            "findings": all_findings,
        }, indent=2))
    else:
        if not all_findings:
            click.echo(f"✅ No secrets found in {files_scanned} files under {directory}")
            sys.exit(0)

        action_label = "would fix" if dry_run else ("fixed" if fix else "found")
        click.echo(f"🚨 {len(all_findings)} secret(s) {action_label} in {files_with_secrets} file(s) ({files_scanned} scanned):\n")

        current_file = None
        for item in all_findings:
            if item["file"] != current_file:
                current_file = item["file"]
                click.echo(f"  {current_file}:")
            if fix or dry_run:
                action = "→" if not dry_run else "would →"
                click.echo(f"    L{item['line']}  [{item['rule']}] {item['match_redacted']} {action} ${item['env_var']}")
            else:
                click.echo(f"    L{item['line']}  [{item['rule']}] {item['match_redacted']}")
        click.echo()

    if all_findings:
        sys.exit(1)


def _load_gitignore(root: Path) -> list[str]:
    """Load .gitignore patterns from the root directory."""
    gitignore = root / ".gitignore"
    if not gitignore.exists():
        return []
    patterns = []
    for line in gitignore.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns


_SKIP_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".bmp", ".tiff", ".webp",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".pdf", ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar",
    ".exe", ".dll", ".so", ".dylib", ".o", ".a",
    ".pyc", ".pyo", ".class", ".jar",
    ".sqlite", ".db", ".sqlite3",
    ".mp3", ".mp4", ".wav", ".avi", ".mov", ".mkv",
    ".DS_Store",
}

_SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
    ".eggs", ".egg-info", "test-venv",
}


def _walk_files(root: Path, ignore_patterns: list[str]) -> list[Path]:
    """Walk directory tree, skipping binary files, hidden dirs, and ignore patterns."""
    files = []
    for item in sorted(root.rglob("*")):
        if not item.is_file():
            continue

        parts = item.relative_to(root).parts
        if any(part in _SKIP_DIRS for part in parts[:-1]):
            continue

        if item.suffix.lower() in _SKIP_EXTENSIONS:
            continue

        rel = str(item.relative_to(root))
        if any(fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(item.name, pat) for pat in ignore_patterns):
            continue

        files.append(item)
    return files


@main.command("serve")
@click.option("--config", "-c", "config_path", type=click.Path(), default=None)
def serve(config_path: str | None):
    """Start the AiGate MCP server (stdio transport).

    This exposes aigate_scan_code, aigate_store_secret, and aigate_scan_file
    as MCP tools that any compatible agent can call.
    """
    from aigate.mcp_server import run_mcp_server

    click.echo("🛡️  aigate MCP server starting (stdio)...", err=True)
    run_mcp_server(config_path)


@main.command("setup-all")
@click.option("--port", "-p", type=int, default=8080, help="Proxy port (default: 8080)")
def setup_all(port: int):
    """One-command setup: proxy + hook + MCP server.

    Installs everything needed for full secret protection:
    - CA cert for HTTPS interception
    - Proxy running in background (redact mode)
    - PostToolUse hook to scan files after Write/Edit
    - MCP server registered with Claude Code

    Usage: pip install aigate && aigate setup-all
    """
    import os
    import platform
    import shutil
    import subprocess

    from aigate.cert import install_cert, is_cert_installed, MITMPROXY_CA, LINUX_CA_BUNDLE, _shell_profile, ENV_MARKER
    from aigate.hooks import install_hooks

    errors: list[str] = []

    click.echo("Setting up aigate...\n")
    click.echo("[1/5] CA certificate")
    if is_cert_installed():
        click.echo("   Already installed")
    else:
        try:
            cert_actions = install_cert()
            for a in cert_actions:
                click.echo(f"   {a}")
        except Exception as e:
            errors.append(f"Cert install failed: {e}. Run 'sudo aigate setup' manually.")
            click.echo(f"   Failed: {e}", err=True)

    # --- Step 2: Shell env vars (proxy + cert) ---
    click.echo("[2/5] Shell environment")
    profile = _shell_profile()
    profile_content = profile.read_text() if profile.exists() else ""

    proxy_marker = "# aigate: proxy env vars"
    new_lines: list[str] = []

    if proxy_marker not in profile_content:
        new_lines.append(proxy_marker)
        new_lines.append(f'export HTTPS_PROXY="http://127.0.0.1:{port}"')
        new_lines.append(f'export HTTP_PROXY="http://127.0.0.1:{port}"')

    if ENV_MARKER not in profile_content:
        new_lines.append(ENV_MARKER)
        new_lines.append(f'export NODE_EXTRA_CA_CERTS="{MITMPROXY_CA}"')
        system = platform.system()
        if system == "Linux" and Path(LINUX_CA_BUNDLE).exists():
            new_lines.append(f'export REQUESTS_CA_BUNDLE="{LINUX_CA_BUNDLE}"')
            new_lines.append(f'export SSL_CERT_FILE="{LINUX_CA_BUNDLE}"')
        else:
            new_lines.append(f'export SSL_CERT_FILE="{MITMPROXY_CA}"')

    if new_lines:
        with open(profile, "a") as f:
            f.write("\n" + "\n".join(new_lines) + "\n")
        click.echo(f"   Added env vars to {profile.name}")
    else:
        click.echo(f"   Already configured in {profile.name}")

    # Also set them in the current process so the proxy can start
    os.environ["HTTPS_PROXY"] = f"http://127.0.0.1:{port}"
    os.environ["HTTP_PROXY"] = f"http://127.0.0.1:{port}"
    os.environ.setdefault("NODE_EXTRA_CA_CERTS", str(MITMPROXY_CA))

    # --- Step 3: Start proxy as background daemon ---
    click.echo("[3/5] Proxy (redact mode)")
    pid_file = Path.home() / ".aigate" / "proxy.pid"
    pid_file.parent.mkdir(parents=True, exist_ok=True)

    # Check if proxy is already running
    proxy_running = False
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)  # Check if process exists
            proxy_running = True
        except (ValueError, ProcessLookupError, PermissionError):
            pid_file.unlink(missing_ok=True)

    if proxy_running:
        click.echo(f"   Already running (pid {pid})")
    else:
        aigate_bin = shutil.which("aigate")
        if aigate_bin:
            proxy_cmd = [aigate_bin, "start", "-m", "redact", "-p", str(port)]
        else:
            proxy_cmd = [sys.executable, "-m", "aigate.cli", "start", "-m", "redact", "-p", str(port)]

        log_file = Path.home() / ".aigate" / "proxy.log"
        with open(log_file, "a") as log_f:
            proc = subprocess.Popen(
                proxy_cmd,
                stdout=log_f,
                stderr=log_f,
                start_new_session=True,
            )
        pid_file.write_text(str(proc.pid))
        click.echo(f"   Started on port {port} (pid {proc.pid})")
        click.echo(f"   Log: {log_file}")

    # --- Step 4: PostToolUse hook only (proxy handles prompt/tool input scanning) ---
    click.echo("[4/5] PostToolUse hook")
    hook_actions = install_hooks(only_events={"PostToolUse"})
    for a in hook_actions:
        click.echo(f"   {a}")

    # --- Step 5: Register MCP server with Claude Code ---
    click.echo("[5/5] MCP server")
    claude_bin = shutil.which("claude")
    aigate_mcp_bin = shutil.which("aigate-mcp")
    if claude_bin and aigate_mcp_bin:
        result = subprocess.run(
            [claude_bin, "mcp", "add", "aigate", aigate_mcp_bin],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            click.echo("   Registered aigate MCP server with Claude Code")
        else:
            # May already be registered
            click.echo(f"   {result.stderr.strip() or result.stdout.strip() or 'Registered'}")
    elif claude_bin:
        result = subprocess.run(
            [claude_bin, "mcp", "add", "aigate", "--", sys.executable, "-m", "aigate.mcp_server"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            click.echo("   Registered aigate MCP server with Claude Code")
        else:
            click.echo(f"   {result.stderr.strip() or result.stdout.strip() or 'Registered'}")
    else:
        click.echo("   Claude Code CLI not found — install it, then run:")
        click.echo("   claude mcp add aigate aigate-mcp")

    # --- Done ---
    click.echo(f"\naigate v{__version__} is active.")
    click.echo(f"   Proxy:     http://127.0.0.1:{port} (redact mode)")
    click.echo(f"   Hook:      PostToolUse (scans files after Write/Edit)")
    click.echo(f"   MCP:       3 tools available to agents")
    click.echo(f"\nRun 'source {profile.name}' or open a new terminal to apply env vars.")

    if errors:
        click.echo("\nWarnings:", err=True)
        for e in errors:
            click.echo(f"   {e}", err=True)


@main.command("stop-proxy")
def stop_proxy():
    """Stop the background aigate proxy."""
    import os
    import signal

    pid_file = Path.home() / ".aigate" / "proxy.pid"
    if not pid_file.exists():
        click.echo("Proxy is not running (no pid file)")
        return

    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, signal.SIGTERM)
        pid_file.unlink()
        click.echo(f"Stopped proxy (pid {pid})")
    except (ValueError, ProcessLookupError):
        pid_file.unlink(missing_ok=True)
        click.echo("Proxy was not running (stale pid file removed)")
    except PermissionError:
        click.echo(f"Cannot stop proxy (pid {pid}) — permission denied", err=True)


@allowlist.command("add")
@click.argument("pattern")
@click.option("--config", "-c", "config_path", type=click.Path(), default=None)
def allowlist_add(pattern: str, config_path: str | None):
    """Add a pattern to the allowlist."""
    import yaml

    config_file = Path(config_path) if config_path else Path(DEFAULT_CONFIG_NAME)
    if not config_file.exists():
        click.echo(f"No config found at {config_file}. Run 'aigate init' first.", err=True)
        sys.exit(1)

    with open(config_file) as f:
        data = yaml.safe_load(f) or {}

    al = data.setdefault("allowlist", [])
    if pattern in al:
        click.echo(f"Pattern already in allowlist: {pattern}")
        return

    al.append(pattern)
    with open(config_file, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    click.echo(f"✅ Added to allowlist: {pattern}")
