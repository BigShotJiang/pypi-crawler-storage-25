# aigate

Local secret scanner that intercepts AI API calls and prevents credentials from leaking to LLMs.

## Install

```bash
pip install aigate
```

Requires Python 3.11+ and `jq` (for Claude Code hooks).

## Quick start

### Claude Code (hooks — no proxy needed)

```bash
aigate install-hook
```

All prompts and tool calls are scanned automatically:

- **Prompts** — blocked if secrets are detected (you fix and resend)
- **Tool inputs** (Bash, Write, Edit, etc.) — secrets are redacted with env var placeholders and the tool runs with sanitized values. Real credentials are saved to `.env` automatically.

### Any AI tool (proxy mode)

**Terminal 1 — proxy:**
```bash
aigate setup                         # one-time: installs CA cert (needs sudo)
aigate start --mode redact           # start the proxy
```

**Terminal 2 — your AI tool:**
```bash
source ~/.bashrc                     # load cert env vars (or open a new terminal)
export HTTPS_PROXY=http://127.0.0.1:8080
export HTTP_PROXY=http://127.0.0.1:8080
claude                               # or any other AI tool
```

`aigate setup` installs the mitmproxy CA cert into the system trust store and adds `NODE_EXTRA_CA_CERTS` to `~/.bashrc` so Claude Code / Node.js trusts the proxy.

### Scan a file directly

```bash
aigate scan .env
cat prompt.txt | aigate scan -
aigate scan .env --redact          # redact secrets and save to .env
```

## Modes

```bash
aigate start --mode block    # reject requests containing secrets (default)
aigate start --mode redact   # replace secrets with env var placeholders
aigate start --mode warn     # forward but log a warning
aigate start --mode audit    # forward silently, log only
```

### Redact mode

Instead of blocking, redact mode rewrites the request before it reaches the AI:

1. Detects secrets in your prompt (AWS keys, API tokens, database URLs, private keys, etc.)
2. Replaces them with placeholders like `[REDACTED_ANTHROPIC_API_KEY]`
3. Saves the real credentials to a local `.env` file
4. Injects a system instruction telling the AI to use `os.environ[]` and load from `.env`
5. Forwards the sanitized request — the AI never sees the real credentials

The AI acknowledges the redaction, then writes secure code using environment variables automatically. Token prefixes are mapped to conventional env var names:

| Token | Env var |
|-------|---------|
| `sk-ant-*` | `ANTHROPIC_API_KEY` |
| `sk-*`, `sk-proj-*` | `OPENAI_API_KEY` |
| `ghp_*`, `github_pat_*` | `GITHUB_TOKEN` |
| `glpat-*` | `GITLAB_TOKEN` |
| `xoxb-*` | `SLACK_BOT_TOKEN` |
| `SG.*` | `SENDGRID_API_KEY` |
| `AKIA*` | `AWS_ACCESS_KEY_ID` |

## Detection rules

- **AWS keys** — `AKIA` access key IDs
- **API tokens** — OpenAI, Anthropic, GitHub, GitLab, Slack, SendGrid, Square
- **Database URLs** — postgres, mysql, mongodb, redis, amqp, mssql with credentials
- **Private keys** — RSA, EC, DSA, OPENSSH, PGP
- **Environment files** — `SECRET_KEY=value`, `DATABASE_URL=value`, etc.
- **GCP service accounts** — JSON with `type: service_account` and `private_key`
- **Tailscale keys** — `tskey-auth-*`, `tskey-api-*`
- **High-entropy secrets** — password/token/secret fields with entropy > 3.5 bits

## Logs

```bash
aigate logs          # last 20 entries
aigate logs -n 50    # last 50 entries
aigate logs -f       # live tail
```

Log file: `~/.aigate/scan.log`

## Uninstall

### Remove hooks

```bash
aigate uninstall-hook
```

### Remove proxy certificates

**macOS:**
```bash
sudo security delete-certificate -c mitmproxy /Library/Keychains/System.keychain
```

**Linux (Debian/Ubuntu):**
```bash
sudo rm /usr/local/share/ca-certificates/mitmproxy-aigate.crt
sudo update-ca-certificates --fresh
```

**Linux (RHEL/Fedora):**
```bash
sudo rm /etc/pki/ca-trust/source/anchors/mitmproxy-aigate.pem
sudo update-ca-trust
```

Then remove the generated certs and env vars:
```bash
rm -rf ~/.mitmproxy
```

Remove the cert env vars that `aigate setup` added to your shell profile (`~/.bashrc` or `~/.zshrc`) — delete the lines after `# aigate: trust mitmproxy CA`.

### Remove aigate entirely

```bash
pip uninstall aigate
rm -rf ~/.aigate              # logs
```
