"""Local kafka-light Python SDK."""

from __future__ import annotations

from .client import KafkaLightConsumerAdapter, KafkaLightProducerAdapter, _target
from .config import KafkaLightConfig
from .interfaces import EventConsumerRebalanceListener
from .models import PublishAck, ReceivedMessage, TopicPartition

KafkaLightConsumer = KafkaLightConsumerAdapter
KafkaLightProducer = KafkaLightProducerAdapter

__all__ = [
    "EventConsumerRebalanceListener",
    "KafkaLightConfig",
    "KafkaLightConsumer",
    "KafkaLightConsumerAdapter",
    "KafkaLightProducer",
    "KafkaLightProducerAdapter",
    "PublishAck",
    "ReceivedMessage",
    "TopicPartition",
    "_target",
]
