"""Shared configuration models for kafka-light clients."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class KafkaLightConfig:
    brokers: list[str] = field(default_factory=lambda: ["127.0.0.1:7171"])
