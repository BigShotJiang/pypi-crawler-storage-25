"""Shared kafka-light producer and consumer models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class TopicPartition:
    topic: str
    partition: int = 0


@dataclass(frozen=True)
class PublishAck:
    topic: str
    partition: int
    offset: int


@dataclass
class ReceivedMessage:
    topic: str
    partition: int
    offset: int
    value: Any
    headers: list[tuple[str, bytes]] = field(default_factory=list)
    key: str | None = None
