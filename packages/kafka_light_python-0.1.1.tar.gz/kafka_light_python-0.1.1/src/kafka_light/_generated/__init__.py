"""Generated protobuf bindings for kafka-light."""

from __future__ import annotations
