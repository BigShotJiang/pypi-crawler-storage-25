# kafka-light-python

`kafka-light-python` is a small Python SDK for producing and consuming events through the `kafka-light` gRPC transport.

## Requirements

- Python `3.13+`
- A reachable `kafka-light` server endpoint

## Installation

```bash
pip install kafka-light-python
```

## Quick Start

```python
import asyncio

from kafka_light import KafkaLightConfig, KafkaLightConsumer, KafkaLightProducer, TopicPartition


async def main() -> None:
    config = KafkaLightConfig(brokers=["127.0.0.1:7171"])

    producer = KafkaLightProducer(config)
    await producer.start()
    await producer.send_and_wait("events", value={"message": "hello"})
    await producer.stop()

    consumer = KafkaLightConsumer(config, group_id="example-group", topics=["events"])
    await consumer.start()

    message = await consumer.__anext__()
    print(message.value)

    await consumer.commit({TopicPartition("events"): message.offset + 1})
    await consumer.stop()


asyncio.run(main())
```

## Public API

- `KafkaLightConfig`: broker endpoint configuration
- `KafkaLightProducer`: async producer adapter
- `KafkaLightConsumer`: async consumer adapter
- `PublishAck`, `ReceivedMessage`, `TopicPartition`: shared transport models

## Notes

- The current client uses only the first configured broker endpoint.
- Consumer support is currently limited to partition `0`.
- `auto_offset_reset` currently supports committed offsets or `"earliest"`.

## License

MIT
