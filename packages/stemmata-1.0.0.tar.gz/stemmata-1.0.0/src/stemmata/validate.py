"""``stemmata validate`` — schema validation for prompt files."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from stemmata.abstracts import (
    annotation_lookup,
    validate_abstract_coupling,
    validate_schema_type_consistency,
)
from stemmata.errors import AbstractUnfilledError, AggregatedError, PromptCliError, SchemaError
from stemmata.interp import (
    DeclaredAbstract,
    Layer,
    collect_placeholder_errors,
    collect_unfilled_declared_abstracts,
    interpolate,
    validate_resolved_abstract_types,
)
from stemmata.merge import merge_namespaces
from stemmata.prompt_doc import RESERVED_KEYS, parse_prompt
from stemmata.resolver import (
    Session,
    layer_order,
    resolve_from_document,
    resolve_graph,
)
from stemmata.resource_resolve import build_resource_binding
from stemmata.schema_check import (
    SchemaCheckOptions,
    fetch_schema,
    fetch_schema_with_errors,
    resolve_schema_uri,
    validate_against_schema,
)
from stemmata.yaml_loader import _ScalarStr, load_all_with_positions


# ---------------------------------------------------------------------------
# file discovery
# ---------------------------------------------------------------------------

def discover_files(target: str) -> list[Path]:
    p = Path(target)
    if p.is_file():
        return [p.resolve()]
    if not p.is_dir():
        raise SchemaError(f"validate target does not exist: {target}",
                          file=target, field_name="target", reason="not_found")
    found: list[Path] = []
    for pat in ("**/*.yaml", "**/*.yml", "**/*.json"):
        found.extend(p.glob(pat))
    return sorted({f.resolve() for f in found})


# ---------------------------------------------------------------------------
# resolve → merge → interpolate (shared by single-doc YAML & multi-doc)
# ---------------------------------------------------------------------------

@dataclass
class _PipelineResult:
    resolved: Any | None
    position_ns: Any
    abstracts: list[AbstractUnfilledError] = field(default_factory=list)
    placeholder_errors: list[PromptCliError] = field(default_factory=list)
    abstract_errors: list[PromptCliError] = field(default_factory=list)
    annotations: dict[str, Any] = field(default_factory=dict)


def _resolve_pipeline(graph, session, schema_opts: SchemaCheckOptions) -> _PipelineResult:
    order = layer_order(graph)
    layers_data = [graph.nodes[nid].doc.namespace for nid in order]
    provenance = [(nid.canonical, graph.nodes[nid].file) for nid in order]
    merged = merge_namespaces(layers_data, provenance=provenance)
    layers = [Layer(canonical_id=nid.canonical, data=graph.nodes[nid].doc.namespace)
              for nid in order]
    root_file = graph.nodes[graph.root_id].file
    position_ns = merged

    abstract_errors: list[PromptCliError] = list(validate_abstract_coupling(graph))
    for nid in graph.nodes:
        doc = graph.nodes[nid].doc
        if not doc.abstracts or not doc.schema_uri:
            continue
        doc_schema_uri = resolve_schema_uri(doc.schema_uri, doc.disk_file)
        doc_schema = fetch_schema(doc_schema_uri, schema_opts)
        if doc_schema is not None:
            abstract_errors.extend(validate_schema_type_consistency(doc, doc_schema))

    annotations = annotation_lookup([graph.nodes[nid].doc for nid in order])

    diagnostics: list[Any] = []
    collect_placeholder_errors(
        merged, merged, layers,
        parent_is_list=False, root_file=root_file, out=diagnostics,
    )
    flagged_paths = {
        e.details.get("placeholder") for e in diagnostics
        if isinstance(e, AbstractUnfilledError)
    }
    declared = [
        DeclaredAbstract(path=path, file=graph.nodes[nid].file,
                         line=ann.line, column=ann.column,
                         annotation_type=ann.type)
        for nid in graph.order
        for path, ann in graph.nodes[nid].doc.abstracts.items()
    ]
    collect_unfilled_declared_abstracts(
        merged, layers, declared, diagnostics, already_flagged=flagged_paths,
    )
    abstracts = [e for e in diagnostics if isinstance(e, AbstractUnfilledError)]
    others = [e for e in diagnostics if not isinstance(e, AbstractUnfilledError)]

    resources = build_resource_binding(graph, session)

    if abstracts or others or abstract_errors:
        return _PipelineResult(
            resolved=None, position_ns=position_ns,
            abstracts=abstracts, placeholder_errors=others,
            abstract_errors=abstract_errors, annotations=annotations,
        )
    resolved = interpolate(
        merged, layers, root_file=root_file, resources=resources,
        annotations=annotations,
    )
    type_diags = validate_resolved_abstract_types(resolved, declared)
    if type_diags:
        return _PipelineResult(
            resolved=None, position_ns=position_ns,
            abstracts=[], placeholder_errors=type_diags,
            abstract_errors=abstract_errors, annotations=annotations,
        )
    return _PipelineResult(
        resolved=resolved, position_ns=position_ns, annotations=annotations,
    )


def _abstracts_payload(
    file_str: str,
    abstracts: list[AbstractUnfilledError],
    annotations: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    annotations = annotations or {}
    out: list[dict[str, Any]] = []
    for a in abstracts:
        loc = a.location if isinstance(a.location, dict) else {}
        path = a.details.get("placeholder")
        entry: dict[str, Any] = {
            "file": loc.get("file") or file_str,
            "path": path,
            "line": loc.get("line"),
            "column": loc.get("column"),
            "reason": a.details.get("reason"),
        }
        ann = annotations.get(path)
        if ann is not None:
            payload = {"description": ann.description, "type": ann.type}
            if ann.has_example:
                payload["example"] = ann.example
            entry["annotation"] = payload
        out.append(entry)
    return out


# ---------------------------------------------------------------------------
# per-file validation
# ---------------------------------------------------------------------------

def _validate_yaml_file(
    path: Path,
    session_factory,
    schema_opts: SchemaCheckOptions,
) -> tuple[int, list[PromptCliError], list[dict[str, Any]]]:
    file_str = str(path)
    text = path.read_text(encoding="utf-8")

    try:
        docs = load_all_with_positions(text, file=file_str, strict=False)
    except PromptCliError as e:
        return 0, [e], []

    if not docs:
        return 0, [], []

    if len(docs) == 1:
        data, _ = docs[0]
        if not isinstance(data, dict):
            return 1, [], []
        raw_uri = data.get("$schema")
        has_schema = isinstance(raw_uri, str) and bool(raw_uri)
        try:
            session = session_factory()
            graph = resolve_graph(file_str, session)
            pipe = _resolve_pipeline(graph, session, schema_opts)
        except PromptCliError as e:
            return 1, [e], []
        errors: list[PromptCliError] = list(pipe.abstract_errors)
        errors.extend(pipe.placeholder_errors)
        abstracts_out = _abstracts_payload(file_str, pipe.abstracts, pipe.annotations)
        if not has_schema:
            return 1, errors, abstracts_out
        schema_uri = resolve_schema_uri(raw_uri, file_str)
        if pipe.resolved is None:
            _, fetch_errors = fetch_schema_with_errors(schema_uri, schema_opts, file=file_str)
            errors.extend(fetch_errors)
            return 1, errors, abstracts_out
        errors.extend(validate_against_schema(
            pipe.resolved, schema_uri, file=file_str, opts=schema_opts,
            position_instance=pipe.position_ns,
        ))
        return 1, errors, abstracts_out

    all_errors: list[PromptCliError] = []
    all_abstracts: list[dict[str, Any]] = []
    for doc_idx, (data, start_line) in enumerate(docs, 1):
        if not isinstance(data, dict):
            continue
        raw_uri = data.get("$schema")
        has_schema = isinstance(raw_uri, str) and bool(raw_uri)

        try:
            doc = parse_prompt(_dump_for_reparse(data), file=file_str,
                               strict=False, validate_paths=False)
        except PromptCliError as e:
            _tag_document(e, doc_idx)
            all_errors.append(e)
            continue

        position_ns = {k: v for k, v in data.items() if k not in RESERVED_KEYS}
        try:
            session = session_factory()
            graph = resolve_from_document(doc, file_str, session)
            pipe = _resolve_pipeline(graph, session, schema_opts)
        except PromptCliError as e:
            _tag_document(e, doc_idx)
            all_errors.append(e)
            continue

        for e in pipe.abstract_errors:
            _tag_document(e, doc_idx)
            all_errors.append(e)
        for e in pipe.placeholder_errors:
            _tag_document(e, doc_idx)
            all_errors.append(e)
        for a in _abstracts_payload(file_str, pipe.abstracts, pipe.annotations):
            a["document"] = doc_idx
            all_abstracts.append(a)
        if not has_schema:
            continue

        schema_uri = resolve_schema_uri(raw_uri, file_str)
        if pipe.resolved is None:
            _, fetch_errors = fetch_schema_with_errors(schema_uri, schema_opts, file=file_str)
            for e in fetch_errors:
                _tag_document(e, doc_idx)
            all_errors.extend(fetch_errors)
            continue
        combined_position_ns = dict(position_ns)
        for k, v in (pipe.position_ns or {}).items():
            if k not in combined_position_ns:
                combined_position_ns[k] = v
        errs = validate_against_schema(
            pipe.resolved, schema_uri, file=file_str, opts=schema_opts,
            position_instance=combined_position_ns,
        )
        for e in errs:
            _tag_document(e, doc_idx)
        all_errors.extend(errs)

    return len(docs), all_errors, all_abstracts


def _validate_json_file(
    path: Path,
    session_factory,
    schema_opts: SchemaCheckOptions,
) -> tuple[int, list[PromptCliError], list[dict[str, Any]]]:
    file_str = str(path)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as e:
        return 0, [SchemaError(f"cannot read {file_str}: {e}",
                               file=file_str, field_name="<io>", reason="io_error")], []

    try:
        doc = parse_prompt(text, file=file_str, strict=False, validate_paths=False)
    except SchemaError as e:
        if e.details.get("reason") == "not_mapping":
            return 1, [], []
        return 1, [e], []
    except PromptCliError as e:
        return 1, [e], []

    raw_uri = doc.data.get("$schema")
    has_schema = isinstance(raw_uri, str) and bool(raw_uri)

    try:
        session = session_factory()
        graph = resolve_graph(file_str, session)
        pipe = _resolve_pipeline(graph, session, schema_opts)
    except PromptCliError as e:
        return 1, [e], []

    errors: list[PromptCliError] = list(pipe.abstract_errors)
    errors.extend(pipe.placeholder_errors)
    abstracts_out = _abstracts_payload(file_str, pipe.abstracts, pipe.annotations)
    if not has_schema:
        return 1, errors, abstracts_out
    schema_uri = resolve_schema_uri(raw_uri, file_str)
    if pipe.resolved is None:
        _, fetch_errors = fetch_schema_with_errors(schema_uri, schema_opts, file=file_str)
        errors.extend(fetch_errors)
        return 1, errors, abstracts_out
    errors.extend(validate_against_schema(
        pipe.resolved, schema_uri, file=file_str, opts=schema_opts,
        position_instance=pipe.position_ns,
    ))
    return 1, errors, abstracts_out


# ---------------------------------------------------------------------------
# orchestrator
# ---------------------------------------------------------------------------

def run_validate(
    target: str,
    session_factory,    # () -> Session  (fresh session per prompt)
    schema_opts: SchemaCheckOptions,
) -> dict[str, int]:
    """Validate *target* and raise ``AggregatedError`` on violations.

    Returns ``{"files_checked": …, "documents_checked": …, "violations_found": 0}``
    on success.
    """
    files = discover_files(target)
    if not files:
        return {"files_checked": 0, "documents_checked": 0, "violations_found": 0}

    total_files = 0
    total_docs = 0
    all_errors: list[PromptCliError] = []
    all_abstracts: list[dict[str, Any]] = []
    for fpath in files:
        ext = fpath.suffix.lower()
        if ext in (".yaml", ".yml"):
            docs, errs, abstracts = _validate_yaml_file(fpath, session_factory, schema_opts)
        elif ext == ".json":
            docs, errs, abstracts = _validate_json_file(fpath, session_factory, schema_opts)
        else:
            continue
        total_files += 1
        total_docs += docs
        all_errors.extend(errs)
        all_abstracts.extend(abstracts)

    if all_errors:
        raise AggregatedError(all_errors, command="validate")
    return {"files_checked": total_files, "documents_checked": total_docs,
            "violations_found": 0,
            "abstracts_found": len(all_abstracts),
            "abstracts": all_abstracts}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _dump_for_reparse(data: dict[str, Any]) -> str:
    class _D(yaml.SafeDumper):
        pass
    _D.add_representer(_ScalarStr,
        lambda d, v: d.represent_scalar("tag:yaml.org,2002:str", str(v)))
    return yaml.dump(data, Dumper=_D, default_flow_style=False, sort_keys=False)


def _tag_document(err: PromptCliError, doc_idx: int) -> None:
    if isinstance(err.location, dict):
        err.location["document"] = doc_idx
    elif err.location is None:
        err.location = {"document": doc_idx}
