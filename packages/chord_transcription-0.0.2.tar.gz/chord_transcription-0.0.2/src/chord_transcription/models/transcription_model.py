import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint
import einops
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple, List


from .spec_augment import SpecAugment
from .cqt import RecursiveCQT
from .transformer import RMSNorm, Transformer


class AudioFeatureExtractor(nn.Module):
    """
    音声波形から特徴量(CQTスペクトログラム)を抽出するクラス。
    SpecAugmentや標準化も行う。
    """

    def __init__(
        self,
        sampling_rate: int,
        n_fft: int,
        hop_length: int,
        bins_per_octave: int = 12 * 3,
        n_bins: int = 12 * 3 * 7,
        spec_augment_params: Optional[Dict[str, Any]] = None,
    ):
        super().__init__()
        self.sampling_rate = sampling_rate
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.num_audio_channels = 2

        self.bins_per_octave = int(bins_per_octave)
        self.n_bins = int(n_bins)
        if self.bins_per_octave <= 0 or self.bins_per_octave % 12 != 0:
            raise ValueError("bins_per_octave must be a positive multiple of 12")
        if self.n_bins <= 0:
            raise ValueError("n_bins must be positive")
        self.cqt = RecursiveCQT(
            sr=sampling_rate,
            hop_length=hop_length,
            n_bins=self.n_bins,
            bins_per_octave=self.bins_per_octave,
            filter_scale=0.4375,
        )

        self.spec_augment = SpecAugment(**spec_augment_params) if spec_augment_params else None

    def forward(self, waveform: torch.Tensor) -> "BackboneContext":
        # center=True の STFT を想定しているため、ラベルと一致するようにクロップする
        crop_length = (waveform.shape[-1] - self.n_fft) // self.hop_length + 1

        batch_size = waveform.shape[0]
        waveform_flat = einops.rearrange(waveform, "b c t -> (b c) t")
        spec = self.cqt(waveform_flat.float(), return_complex=False)
        spec = einops.rearrange(spec, "(b c) f t -> b c f t", b=batch_size, c=self.num_audio_channels).contiguous()

        # 標準化(バッチ単位の全体平均/分散)
        mean = spec.mean(dim=(2, 3), keepdim=True)
        std = spec.std(dim=(2, 3), keepdim=True) + 1e-8
        spec = (spec - mean) / std

        if self.training and self.spec_augment is not None:
            spec, _ = self.spec_augment(spec)

        spec = spec.to(waveform.dtype)

        spec = einops.rearrange(spec, "b c f t -> b c t f").contiguous()

        return BackboneContext(
            spec=spec,
            crop_length=crop_length,
        )


@dataclass
class BackboneContext:
    spec: torch.Tensor
    crop_length: int


def _choose_gn_groups(channels: int, max_groups: int = 8) -> int:
    for groups in reversed(range(1, max_groups + 1)):
        if channels % groups == 0:
            return groups
    return 1


class StemConv(nn.Module):
    """
    入力:
        x: [B, in_ch, T, F]

    出力:
        y: [B, 4 * base_ch, T/8, F]
    """

    def __init__(
        self,
        in_ch: int,
        base_ch: int,
        kernel_size: int = 3,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        pad = kernel_size // 2
        block1_groups = _choose_gn_groups(base_ch)
        block2_groups = _choose_gn_groups(base_ch * 2)
        block3_groups = _choose_gn_groups(base_ch * 4)

        self.block1 = nn.Sequential(
            nn.Conv2d(
                in_channels=in_ch,
                out_channels=base_ch,
                kernel_size=(kernel_size, kernel_size),
                stride=(2, 1),
                padding=(pad, pad),
            ),
            nn.GroupNorm(block1_groups, base_ch),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(
                in_channels=base_ch,
                out_channels=base_ch * 2,
                kernel_size=(kernel_size, kernel_size),
                stride=(2, 1),
                padding=(pad, pad),
            ),
            nn.GroupNorm(block2_groups, base_ch * 2),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.block3 = nn.Sequential(
            nn.Conv2d(
                in_channels=base_ch * 2,
                out_channels=base_ch * 4,
                kernel_size=(kernel_size, kernel_size),
                stride=(2, 1),
                padding=(pad, pad),
            ),
            nn.GroupNorm(block3_groups, base_ch * 4),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.out_ch = base_ch * 4

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)
        return x


class BandTokenizer(nn.Module):
    """
    周波数方向だけ unfold して band token を作る。
    """

    def __init__(
        self,
        in_ch: int,
        freq_bins: int,
        token_dim: int,
        patch_size: int = 3,
        patch_stride: int = 3,
    ) -> None:
        super().__init__()

        if patch_size <= 0 or patch_stride <= 0:
            raise ValueError("patch_size and patch_stride must be positive.")
        if patch_size > freq_bins:
            raise ValueError("patch_size must be <= freq_bins.")

        self.in_ch = in_ch
        self.freq_bins = freq_bins
        self.patch_size = patch_size
        self.patch_stride = patch_stride
        self.token_dim = token_dim

        self.n_band = 1 + (freq_bins - patch_size) // patch_stride
        if self.n_band <= 0:
            raise ValueError("Invalid tokenizer setting: n_band <= 0.")

        self.proj = nn.Linear(in_ch * patch_size, token_dim)
        self.band_embed = nn.Embedding(self.n_band, token_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 4:
            raise ValueError(f"Expected 4D input [B, C, T, F], got {tuple(x.shape)}")

        batch_size, channels, time_steps, freq_bins = x.shape
        if channels != self.in_ch:
            raise ValueError(f"Expected in_ch={self.in_ch}, got {channels}")
        if freq_bins != self.freq_bins:
            raise ValueError(f"Expected freq_bins={self.freq_bins}, got {freq_bins}")

        # 周波数方向だけ sliding window で patch 化する。
        x = x.unfold(dimension=3, size=self.patch_size, step=self.patch_stride)
        # Linear に入れやすいよう [C, patch] を最後に寄せる。
        x = x.permute(0, 2, 3, 1, 4).contiguous()
        x = x.view(batch_size, time_steps, self.n_band, channels * self.patch_size)
        x = self.proj(x)

        # band index の埋め込みを足して、同じ patch 内容でも位置を区別できるようにする。
        band_ids = torch.arange(self.n_band, device=x.device)
        x = x + self.band_embed(band_ids)[None, None, :, :]
        return x


class Backbone(nn.Module):
    def __init__(
        self,
        feature_extractor: AudioFeatureExtractor,
        hidden_size: int,
        base_ch: int,
        output_dim: Optional[int] = None,
        num_layers: int = 1,
        dropout: float = 0.0,
        use_gradient_checkpoint: bool = True,
        band_merge_hidden_size: Optional[int] = None,
    ):
        super().__init__()
        if hidden_size <= 0:
            raise ValueError("hidden_size must be positive")
        if base_ch <= 0:
            raise ValueError("base_ch must be positive")
        if num_layers < 0:
            raise ValueError("num_layers must be non-negative")

        self.feature_extractor = feature_extractor
        self.hidden_size = hidden_size
        self.base_ch = base_ch
        self.output_dim = output_dim if output_dim is not None else hidden_size
        self.use_gradient_checkpoint = use_gradient_checkpoint

        self.num_audio_channels = feature_extractor.num_audio_channels
        self.n_bins = feature_extractor.n_bins
        self.model_dim = hidden_size
        self.band_merge_hidden_size = (
            int(band_merge_hidden_size)
            if band_merge_hidden_size is not None
            else max(32, self.model_dim // 4)
        )
        if self.band_merge_hidden_size <= 0:
            raise ValueError("band_merge_hidden_size must be positive")

        gn_groups = _choose_gn_groups(self.model_dim)

        self.stem = StemConv(
            in_ch=self.num_audio_channels,
            base_ch=base_ch,
            dropout=dropout,
        )
        # Stem は時間方向だけ 1/8 に圧縮し、周波数方向は保持する。
        self.tokenizer = BandTokenizer(
            in_ch=self.stem.out_ch,
            freq_bins=self.n_bins,
            token_dim=self.model_dim,
        )
        self.band_merge_input_dim = self.tokenizer.n_band * self.band_merge_hidden_size
        # tokenizer 以降は hidden_size 次元で統一して扱う。
        self.axial_transformer_blocks = nn.ModuleList(
            [
                nn.ModuleList(
                    [
                        # 各 block は time 軸 → band 軸の順で文脈化する。
                        Transformer(
                            input_dim=self.model_dim,
                            head_dim=self.model_dim // 8,
                            num_layers=1,
                            num_heads=8,
                            ffn_hidden_size_factor=2,
                            dropout=dropout,
                        ),
                        Transformer(
                            input_dim=self.model_dim,
                            head_dim=self.model_dim // 8,
                            num_layers=1,
                            num_heads=8,
                            ffn_hidden_size_factor=2,
                            dropout=dropout,
                        ),
                    ]
                )
                for _ in range(num_layers)
            ]
        )
        # まず各 band token の次元 D を小さい次元へ圧縮してから、
        # band 軸ごとに並べて 1 本の時間特徴へ統合する。
        self.band_reduce = nn.Sequential(
            nn.Linear(self.model_dim, self.band_merge_hidden_size),
            RMSNorm(self.band_merge_hidden_size),
            nn.GELU(),
        )
        self.band_merge = nn.Sequential(
            nn.Linear(self.band_merge_input_dim, self.model_dim),
            RMSNorm(self.model_dim),
            nn.GELU(),
        )
        self.context_post = nn.Sequential(
            nn.Linear(self.model_dim, self.model_dim),
            RMSNorm(self.model_dim),
            nn.GELU(),
        )
        self.context_up_time = nn.Sequential(
            nn.ConvTranspose1d(self.model_dim, self.model_dim, kernel_size=8, stride=8),
            nn.GroupNorm(gn_groups, self.model_dim),
            nn.GELU(),
        )
        self.output_proj = nn.Sequential(
            nn.Linear(self.model_dim, self.output_dim),
            RMSNorm(self.output_dim),
            nn.GELU(),
        )

    @staticmethod
    def _match_time_length(x: torch.Tensor, target_T: int) -> torch.Tensor:
        if x.shape[1] < target_T:
            return F.pad(x, (0, 0, 0, target_T - x.shape[1]))
        return x[:, :target_T]

    def _run_axial_transformers(
        self, x: torch.Tensor, use_checkpoint: bool
    ) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        intermediates: List[torch.Tensor] = []
        for time_transformer, band_transformer in self.axial_transformer_blocks:
            batch_size, time_steps, num_bands, _ = x.shape

            # 各 band を独立系列として時間文脈を見る。
            time_x = einops.rearrange(x, "b t n d -> (b n) t d")
            if use_checkpoint:
                time_x = torch.utils.checkpoint.checkpoint(
                    time_transformer,
                    time_x,
                    use_reentrant=False,
                )
            else:
                time_x = time_transformer(time_x)
            x = einops.rearrange(time_x, "(b n) t d -> b t n d", b=batch_size, n=num_bands)

            # 次に各時刻ごとに band 間の関係を見る。
            band_x = einops.rearrange(x, "b t n d -> (b t) n d")
            if use_checkpoint:
                band_x = torch.utils.checkpoint.checkpoint(
                    band_transformer,
                    band_x,
                    use_reentrant=False,
                )
            else:
                band_x = band_transformer(band_x)
            x = einops.rearrange(band_x, "(b t) n d -> b t n d", b=batch_size, t=time_steps)
            intermediates.append(x)

        return x, intermediates

    def forward(
        self,
        waveform: torch.Tensor,
        context: Optional[BackboneContext] = None,
    ) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        if context is None:
            context = self.feature_extractor(waveform)

        use_checkpoint = self.use_gradient_checkpoint and self.training and torch.is_grad_enabled()

        # CQT を stem で時間圧縮し、周波数方向は band token に切る。
        x = self.stem(context.spec)  # [B, D_stem, T/8, F]
        tokens = self.tokenizer(x)  # [B, T/8, N_band, D]

        # Axial Transformer で time / band の両軸文脈を付与する。
        context_x, intermediates = self._run_axial_transformers(tokens, use_checkpoint)
        # band ごとの特徴を捨てずに使うため、
        # D を一度細くしてから [N_band, d_small] を結合して 1 本へまとめる。
        context_x = self.band_reduce(context_x)
        context_x = einops.rearrange(context_x, "b t n d -> b t (n d)")
        context_x = self.band_merge(context_x)
        context_x = self.context_post(context_x)

        # coarse な時間解像度から元のフレーム解像度へ戻す。
        context_x = einops.rearrange(context_x, "b t d -> b d t")
        context_x = self.context_up_time(context_x)
        context_x = einops.rearrange(context_x, "b d t -> b t d")

        target_T = context.crop_length
        # STFT/CQT の center 処理に合わせて最終長をラベル側に揃える。
        context_x = self._match_time_length(context_x, target_T)
        return self.output_proj(context_x), intermediates


class IterativeBiLSTM(nn.Module):
    """
    chord25_raw を K 回 BiLSTM に通して平滑化する。
    各イテレーション後の出力に Tversky loss をかけることで深層監視を行う。
    """

    def __init__(self, input_dim: int = 25, hidden_dim: int = 256, num_iterations: int = 2):
        super().__init__()
        self.num_iterations = num_iterations
        self.bilstm = nn.LSTM(input_dim, hidden_dim // 2, batch_first=True, bidirectional=True)
        self.proj = nn.Linear(hidden_dim, input_dim)

    def forward(self, chord25: torch.Tensor) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        """
        Args:
            chord25: (B, T, input_dim)
        Returns:
            chord25_smooth: 最終イテレーション後の出力 (B, T, input_dim)
            intermediates: 各イテレーション後の出力リスト（深層監視用）
        """
        intermediates: List[torch.Tensor] = []
        self.bilstm.flatten_parameters()
        for _ in range(self.num_iterations):
            h, _ = self.bilstm(chord25)
            chord25 = torch.clamp(torch.relu(self.proj(h) + chord25), max=1.0)
            intermediates.append(chord25)
        return chord25, intermediates


class BaseTranscriptionModel(nn.Module):
    def __init__(
        self,
        backbone: Backbone,
        hidden_size: int,
        num_quality_classes: int,
        num_bass_classes: int,
        num_key_classes: int,
        dropout_probability: float = 0.0,
        use_layer_norm: bool = True,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        self.hidden_size = hidden_size
        self.detach_label_heads = True
        self.norm = RMSNorm(hidden_size) if use_layer_norm else nn.Identity()
        self.dropout = nn.Dropout(dropout_probability) if dropout_probability > 0.0 else nn.Identity()

        self.num_root_quality_classes = (num_quality_classes - 1) * 12 + 1

        # Stage 1: backbone 特徴量から各属性を予測するヘッド
        # chord25 は音検出に専念（key/boundary/root/bass とは勾配経路を分ける）
        chord25_hidden = 25 + 12
        self.chord25_head = nn.Sequential(nn.Linear(hidden_size, chord25_hidden))
        self.boundary_head = nn.Linear(hidden_size, 1)
        self.beat_head = nn.Linear(hidden_size, 1)
        self.downbeat_head = nn.Linear(hidden_size, 1)
        self.key_boundary_head = nn.Linear(hidden_size, 1)
        self.key_head = nn.Linear(hidden_size, num_key_classes)
        self.root_chord_head = nn.Linear(hidden_size, self.num_root_quality_classes)
        self.bass_head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            RMSNorm(hidden_size // 2),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_size // 2, num_bass_classes),
        )

        # Stage 2: chord25 の反復 BiLSTM 平滑化
        self.iterative_bilstm = IterativeBiLSTM(
            input_dim=chord25_hidden,
            hidden_dim=256,
            num_iterations=1,
        )

    def set_label_head_detach(self, enabled: bool) -> None:
        self.detach_label_heads = bool(enabled)

    def _compute_heads(self, features: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Stage 1: backbone 特徴量から各属性を予測する。"""
        normed = self.norm(features)
        features = self.dropout(normed)

        # Boundary と Key は features から直接予測
        boundary_logits = self.boundary_head(features)
        downbeat_logits = self.downbeat_head(features)
        beat_logits = self.beat_head(features) + downbeat_logits
        key_logits = self.key_head(features)
        key_boundary_logits = self.key_boundary_head(features)

        # chord25: 純粋な音検出ヘッド
        chord25_logits = self.chord25_head(features)  # (B, T, 37)
        chord25_logits = torch.clamp(torch.relu(chord25_logits), max=1.0)

        return {
            "initial_chord25_logits": chord25_logits[..., :25],
            "initial_chord25_original": chord25_logits,
            "initial_key_logits": key_logits,
            "initial_boundary_logits": boundary_logits,
            "initial_beat_logits": beat_logits,
            "initial_downbeat_logits": downbeat_logits,
            "initial_key_boundary_logits": key_boundary_logits,
            "initial_features": features,  # CRF 等の外部モジュールが使用
        }

    def _compute_label_heads(self, features: torch.Tensor) -> Dict[str, torch.Tensor]:
        if self.detach_label_heads:
            features = features.detach()
        return {
            "initial_root_chord_logits": self.root_chord_head(features),
            "initial_bass_logits": self.bass_head(features),
        }

    def forward(
        self,
        waveform: torch.Tensor,
    ) -> Dict[str, Any]:
        # --- Stage 1: Backbone + heads ---
        features, backbone_intermediates = self.backbone(waveform)
        outputs = self._compute_heads(features)
        outputs["backbone_intermediates"] = backbone_intermediates

        # --- Stage 2: IterativeBiLSTM 平滑化 ---
        chord25_raw = outputs["initial_chord25_original"]  # (B, T, 37)
        chord25_smooth, bilstm_intermediates = self.iterative_bilstm(chord25_raw)
        outputs["chord25_smooth"] = chord25_smooth
        outputs["bilstm_intermediates"] = bilstm_intermediates  # 深層監視用

        # root_chord / bass は epoch に応じて detach の有無を切り替える。
        # repeat 有効化前は head のみ更新し、以降は backbone まで伝播させる。
        outputs.update(self._compute_label_heads(outputs["initial_features"]))

        return outputs
