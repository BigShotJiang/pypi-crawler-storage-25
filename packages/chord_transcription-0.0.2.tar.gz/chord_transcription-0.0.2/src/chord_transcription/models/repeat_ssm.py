from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .cqt import RecursiveCQT


class StemChromaFeatureExtractor(nn.Module):
    """
    harmonic stem ごとの CQT から chroma を作り、stem 単位で集約する。

    可視化スクリプトで試した `stem_chroma` を、そのまま学習時に GPU 上で
    使えるように切り出した最小版。
    """

    def __init__(
        self,
        sampling_rate: int,
        hop_length: int,
        cqt_bins_per_octave: int = 36,
        cqt_n_bins: int = 36 * 7,
        n_chroma: int = 12,
        stem_energy_threshold: float = 1e-4,
        eps: float = 1e-8,
    ) -> None:
        super().__init__()
        if cqt_bins_per_octave <= 0 or cqt_bins_per_octave % n_chroma != 0:
            raise ValueError("cqt_bins_per_octave must be a positive multiple of n_chroma")
        if cqt_n_bins <= 0:
            raise ValueError("cqt_n_bins must be positive")
        if n_chroma != 12:
            raise ValueError("StemChromaFeatureExtractor currently supports only 12 chroma bins")

        self.sampling_rate = int(sampling_rate)
        self.hop_length = int(hop_length)
        self.cqt_bins_per_octave = int(cqt_bins_per_octave)
        self.cqt_n_bins = int(cqt_n_bins)
        self.n_chroma = int(n_chroma)
        self.stem_energy_threshold = float(stem_energy_threshold)
        self.eps = float(eps)

        self.cqt = RecursiveCQT(
            sr=self.sampling_rate,
            hop_length=self.hop_length,
            n_bins=self.cqt_n_bins,
            bins_per_octave=self.cqt_bins_per_octave,
            filter_scale=0.4375,
        )

    def forward(self, stem_waveforms: torch.Tensor, num_frames: int) -> torch.Tensor:
        """
        Args:
            stem_waveforms:
                shape `(B, N, C, S)` の stem 波形。
            num_frames:
                学習ラベルと揃えるための目標フレーム数。

        Returns:
            shape `(B, T, 12)` の stem 集約 chroma 特徴。
        """
        if stem_waveforms.dim() != 4:
            raise ValueError("stem_waveforms must have shape (B, N, C, S)")
        if num_frames <= 0:
            raise ValueError("num_frames must be positive")

        batch_size, num_stems, _, _ = stem_waveforms.shape
        # stereo を stem ごとに先に mono mix してから CQT を回し、計算本数を減らす。
        stem_mono_waveforms = stem_waveforms.float().mean(dim=2)
        flat_waveforms = stem_mono_waveforms.reshape(batch_size * num_stems, -1)
        cqt_spec = self.cqt(flat_waveforms, return_complex=False)
        chroma = self._fold_cqt_to_chroma(cqt_spec)
        chroma = chroma.reshape(batch_size, num_stems, self.n_chroma, chroma.shape[-1])
        chroma = self._match_num_frames(chroma, num_frames)

        # stem ごとに chroma を正規化し、後段の平均集約で音量差に引っ張られにくくする。
        stem_features = chroma / chroma.sum(dim=2, keepdim=True).clamp_min(self.eps)
        stem_features = stem_features.permute(0, 1, 3, 2).contiguous()

        stem_energy = stem_waveforms.float().pow(2).mean(dim=(2, 3)).sqrt()
        active_mask = stem_energy > self.stem_energy_threshold
        fallback_mask = ~active_mask.any(dim=1, keepdim=True)
        active_mask = torch.where(fallback_mask, torch.ones_like(active_mask), active_mask)

        weights = active_mask.to(stem_features.dtype)
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1.0)
        aggregated = (stem_features * weights[:, :, None, None]).sum(dim=1)
        return self._zscore_feature_tensor(aggregated)

    def _fold_cqt_to_chroma(self, cqt_spec: torch.Tensor) -> torch.Tensor:
        bins_per_pitch_class = self.cqt_bins_per_octave // self.n_chroma
        usable_bins = (cqt_spec.shape[1] // self.cqt_bins_per_octave) * self.cqt_bins_per_octave
        if usable_bins == 0:
            raise ValueError("Not enough CQT bins to fold into chroma")

        cqt_spec = cqt_spec[:, :usable_bins]
        num_octaves = usable_bins // self.cqt_bins_per_octave
        cqt_spec = cqt_spec.reshape(
            cqt_spec.shape[0],
            num_octaves,
            self.n_chroma,
            bins_per_pitch_class,
            cqt_spec.shape[-1],
        )
        chroma = cqt_spec.mean(dim=3).mean(dim=1)
        return chroma / chroma.sum(dim=1, keepdim=True).clamp_min(self.eps)

    def _match_num_frames(self, chroma: torch.Tensor, num_frames: int) -> torch.Tensor:
        current_frames = chroma.shape[-1]
        if current_frames == num_frames:
            return chroma
        if current_frames > num_frames:
            return chroma[..., :num_frames]
        return F.pad(chroma, (0, num_frames - current_frames))

    def _zscore_feature_tensor(self, features: torch.Tensor) -> torch.Tensor:
        mean = features.mean(dim=(1, 2), keepdim=True)
        std = features.std(dim=(1, 2), keepdim=True).clamp_min(self.eps)
        return (features - mean) / std


@dataclass
class ChordWindowSSMOutput:
    """
    複数コード窓ベースの SSM 計算結果。

    `similarity` / `candidate_mask` は固定長 window のデバッグ用 SSM 情報。
    学習側で repeat 区間を使う場合は、GT 完全一致で可変長に伸ばした
    dense 行列と sparse pair list の両方を返す。
    """

    segment_features: torch.Tensor
    segment_labels: torch.Tensor
    segment_starts: torch.Tensor
    segment_ends: torch.Tensor
    segment_mask: torch.Tensor
    segment_counts: torch.Tensor
    window_features: torch.Tensor
    window_labels: torch.Tensor
    window_segment_starts: torch.Tensor
    window_segment_ends: torch.Tensor
    window_frame_starts: torch.Tensor
    window_frame_ends: torch.Tensor
    window_mask: torch.Tensor
    window_counts: torch.Tensor
    similarity: torch.Tensor
    pair_mask: torch.Tensor
    candidate_mask: torch.Tensor
    repeat_pair_mask: torch.Tensor
    repeat_pair_lengths: torch.Tensor
    repeat_pair_similarity: torch.Tensor
    repeat_pair_span_ratio: torch.Tensor
    repeat_pairs_segment_starts: torch.Tensor
    repeat_pairs_segment_ends: torch.Tensor
    repeat_pairs_frame_starts: torch.Tensor
    repeat_pairs_frame_ends: torch.Tensor
    repeat_pairs_lengths: torch.Tensor
    repeat_pairs_similarity: torch.Tensor
    repeat_pairs_span_ratio: torch.Tensor
    repeat_pair_counts: torch.Tensor


@dataclass
class RepeatPairBatchOutput:
    """
    学習時の repeat consistency loss に必要な最小限の repeat 候補情報。

    audio feature は持たず、GT ラベル列だけから CPU で exact repeat を作る。
    """

    segment_labels: torch.Tensor
    segment_starts: torch.Tensor
    segment_ends: torch.Tensor
    segment_counts: torch.Tensor
    repeat_pairs_segment_starts: torch.Tensor
    repeat_pairs_segment_ends: torch.Tensor
    repeat_pairs_frame_starts: torch.Tensor
    repeat_pairs_frame_ends: torch.Tensor
    repeat_pairs_lengths: torch.Tensor
    repeat_pairs_span_ratio: torch.Tensor
    repeat_pair_counts: torch.Tensor
    repeat_pairs_similarity: Optional[torch.Tensor] = None

    def to(self, device: torch.device | str) -> "RepeatPairBatchOutput":
        repeat_pairs_similarity = None
        if self.repeat_pairs_similarity is not None:
            repeat_pairs_similarity = self.repeat_pairs_similarity.to(device)
        return RepeatPairBatchOutput(
            segment_labels=self.segment_labels.to(device),
            segment_starts=self.segment_starts.to(device),
            segment_ends=self.segment_ends.to(device),
            segment_counts=self.segment_counts.to(device),
            repeat_pairs_segment_starts=self.repeat_pairs_segment_starts.to(device),
            repeat_pairs_segment_ends=self.repeat_pairs_segment_ends.to(device),
            repeat_pairs_frame_starts=self.repeat_pairs_frame_starts.to(device),
            repeat_pairs_frame_ends=self.repeat_pairs_frame_ends.to(device),
            repeat_pairs_lengths=self.repeat_pairs_lengths.to(device),
            repeat_pairs_span_ratio=self.repeat_pairs_span_ratio.to(device),
            repeat_pair_counts=self.repeat_pair_counts.to(device),
            repeat_pairs_similarity=repeat_pairs_similarity,
        )


class RepeatPairBuilderCPU(nn.Module):
    """
    GT コード列だけから exact repeat 候補を作る CPU 用 builder。

    学習では repeat 候補の位置さえ分かれば十分なので、audio feature や fixed-window SSM は
    使わずにこちらで軽く作る。
    """

    def __init__(
        self,
        window_size: int = 4,
        max_span_ratio: float = 1.5,
        ignore_index: int = -100,
    ) -> None:
        super().__init__()
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if max_span_ratio < 1.0:
            raise ValueError("max_span_ratio must be >= 1.0")
        self.window_size = int(window_size)
        self.max_span_ratio = float(max_span_ratio)
        self.ignore_index = int(ignore_index)

    def forward(
        self,
        chord_labels: torch.Tensor,
        frame_mask: Optional[torch.Tensor] = None,
    ) -> RepeatPairBatchOutput:
        if chord_labels.dim() != 2:
            raise ValueError("chord_labels must have shape (B, T)")
        if frame_mask is not None and frame_mask.shape != chord_labels.shape:
            raise ValueError("frame_mask must have shape (B, T)")

        target_device = chord_labels.device
        chord_labels_cpu = chord_labels.detach().to(device="cpu", dtype=torch.long)
        valid_mask_cpu = chord_labels_cpu != self.ignore_index
        if frame_mask is not None:
            valid_mask_cpu &= frame_mask.detach().to(device="cpu").bool()

        batch_size = chord_labels_cpu.shape[0]
        sample_segments = []
        sample_pairs = []
        max_segments = 0
        max_pairs = 0

        for batch_idx in range(batch_size):
            segment_starts, segment_ends, segment_labels = self._extract_segments_one(
                chord_labels=chord_labels_cpu[batch_idx],
                valid_mask=valid_mask_cpu[batch_idx],
            )
            (
                pair_segment_starts,
                pair_segment_ends,
                pair_frame_starts,
                pair_frame_ends,
                pair_lengths,
                pair_span_ratio,
            ) = self._build_repeat_pairs_one(
                segment_labels=segment_labels,
                segment_starts=segment_starts,
                segment_ends=segment_ends,
            )
            sample_segments.append((segment_labels, segment_starts, segment_ends))
            sample_pairs.append(
                (
                    pair_segment_starts,
                    pair_segment_ends,
                    pair_frame_starts,
                    pair_frame_ends,
                    pair_lengths,
                    pair_span_ratio,
                )
            )
            max_segments = max(max_segments, int(segment_labels.shape[0]))
            max_pairs = max(max_pairs, int(pair_lengths.shape[0]))

        segment_labels = chord_labels_cpu.new_full((batch_size, max_segments), self.ignore_index)
        segment_starts = chord_labels_cpu.new_zeros((batch_size, max_segments))
        segment_ends = chord_labels_cpu.new_zeros((batch_size, max_segments))
        segment_counts = torch.zeros((batch_size,), dtype=torch.long)

        repeat_pairs_segment_starts = chord_labels_cpu.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_segment_ends = chord_labels_cpu.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_frame_starts = chord_labels_cpu.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_frame_ends = chord_labels_cpu.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_lengths = chord_labels_cpu.new_zeros((batch_size, max_pairs))
        repeat_pairs_span_ratio = torch.zeros((batch_size, max_pairs), dtype=torch.float32)
        repeat_pair_counts = torch.zeros((batch_size,), dtype=torch.long)

        for batch_idx, ((labels_one, starts_one, ends_one), pair_info) in enumerate(zip(sample_segments, sample_pairs)):
            segment_count = int(labels_one.shape[0])
            if segment_count > 0:
                segment_labels[batch_idx, :segment_count] = labels_one
                segment_starts[batch_idx, :segment_count] = starts_one
                segment_ends[batch_idx, :segment_count] = ends_one
                segment_counts[batch_idx] = segment_count

            (
                pair_segment_starts,
                pair_segment_ends,
                pair_frame_starts,
                pair_frame_ends,
                pair_lengths,
                pair_span_ratio,
            ) = pair_info
            pair_count = int(pair_lengths.shape[0])
            if pair_count == 0:
                continue
            repeat_pairs_segment_starts[batch_idx, :pair_count] = pair_segment_starts
            repeat_pairs_segment_ends[batch_idx, :pair_count] = pair_segment_ends
            repeat_pairs_frame_starts[batch_idx, :pair_count] = pair_frame_starts
            repeat_pairs_frame_ends[batch_idx, :pair_count] = pair_frame_ends
            repeat_pairs_lengths[batch_idx, :pair_count] = pair_lengths
            repeat_pairs_span_ratio[batch_idx, :pair_count] = pair_span_ratio
            repeat_pair_counts[batch_idx] = pair_count

        return RepeatPairBatchOutput(
            segment_labels=segment_labels,
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            segment_counts=segment_counts,
            repeat_pairs_segment_starts=repeat_pairs_segment_starts,
            repeat_pairs_segment_ends=repeat_pairs_segment_ends,
            repeat_pairs_frame_starts=repeat_pairs_frame_starts,
            repeat_pairs_frame_ends=repeat_pairs_frame_ends,
            repeat_pairs_lengths=repeat_pairs_lengths,
            repeat_pairs_span_ratio=repeat_pairs_span_ratio,
            repeat_pair_counts=repeat_pair_counts,
            repeat_pairs_similarity=None,
        ).to(target_device)

    def _extract_segments_one(
        self,
        chord_labels: torch.Tensor,
        valid_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """無効領域も考慮しつつ、連続する同一ラベル区間を vectorized に切り出す。"""
        if chord_labels.dim() != 1 or valid_mask.dim() != 1:
            raise ValueError("_extract_segments_one expects 1D tensors")
        if chord_labels.shape != valid_mask.shape:
            raise ValueError("chord_labels and valid_mask must have the same shape")
        if not bool(valid_mask.any()):
            empty = torch.zeros((0,), dtype=torch.long)
            return empty, empty, empty

        prev_valid = torch.zeros_like(valid_mask)
        prev_valid[1:] = valid_mask[:-1]
        prev_label = torch.empty_like(chord_labels)
        prev_label[0] = chord_labels[0]
        prev_label[1:] = chord_labels[:-1]
        start_mask = valid_mask & (~prev_valid | (chord_labels != prev_label))

        next_valid = torch.zeros_like(valid_mask)
        next_valid[:-1] = valid_mask[1:]
        next_label = torch.empty_like(chord_labels)
        next_label[-1] = chord_labels[-1]
        next_label[:-1] = chord_labels[1:]
        end_mask = valid_mask & (~next_valid | (chord_labels != next_label))

        segment_starts = torch.nonzero(start_mask, as_tuple=False).squeeze(-1).to(torch.long)
        segment_ends = torch.nonzero(end_mask, as_tuple=False).squeeze(-1).to(torch.long) + 1
        segment_labels = chord_labels[segment_starts].to(torch.long)
        return segment_starts, segment_ends, segment_labels

    def _build_repeat_pairs_one(
        self,
        segment_labels: torch.Tensor,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """1 サンプル分の exact repeat を sparse pair list として返す。"""
        num_segments = int(segment_labels.shape[0])
        empty_pair = segment_labels.new_zeros((0, 2))
        empty_length = segment_labels.new_zeros((0,))
        empty_ratio = torch.zeros((0,), dtype=torch.float32)
        if num_segments < self.window_size:
            return empty_pair, empty_pair, empty_pair, empty_pair, empty_length, empty_ratio

        exact_match_lengths = torch.zeros((num_segments + 1, num_segments + 1), dtype=torch.long)
        zeros = exact_match_lengths.new_zeros((num_segments,))
        for start_i in range(num_segments - 1, -1, -1):
            label_matches = segment_labels == segment_labels[start_i]
            exact_match_lengths[start_i, :num_segments] = torch.where(
                label_matches,
                exact_match_lengths[start_i + 1, 1 : num_segments + 1] + 1,
                zeros,
            )

        segment_indices = torch.arange(num_segments, dtype=torch.long)
        start_i = segment_indices[:, None]
        start_j = segment_indices[None, :]
        non_overlap_length = (start_j - start_i).clamp_min(0)
        exact_lengths = exact_match_lengths[:num_segments, :num_segments]
        match_lengths = torch.minimum(exact_lengths, non_overlap_length)

        candidate_mask = (start_j - start_i) >= self.window_size
        candidate_mask &= match_lengths >= self.window_size

        left_extend_mask = torch.zeros_like(candidate_mask)
        if num_segments > 1:
            prev_label_matches = segment_labels[:-1, None] == segment_labels[None, :-1]
            left_extend_mask[1:, 1:] = prev_label_matches
        can_extend_mask = match_lengths < non_overlap_length
        left_extend_mask &= can_extend_mask

        right_extend_mask = torch.zeros_like(candidate_mask)
        next_i = start_i + match_lengths
        next_j = start_j + match_lengths
        right_valid_mask = candidate_mask & can_extend_mask & (next_i < num_segments) & (next_j < num_segments)
        if bool(right_valid_mask.any()):
            right_i = next_i[right_valid_mask]
            right_j = next_j[right_valid_mask]
            right_extend_mask[right_valid_mask] = segment_labels[right_i] == segment_labels[right_j]

        maximal_mask = candidate_mask & ~left_extend_mask & ~right_extend_mask
        if not bool(maximal_mask.any()):
            return empty_pair, empty_pair, empty_pair, empty_pair, empty_length, empty_ratio

        candidate_indices = torch.nonzero(maximal_mask, as_tuple=False)
        start_i_vec = candidate_indices[:, 0]
        start_j_vec = candidate_indices[:, 1]
        length_vec = match_lengths[start_i_vec, start_j_vec]

        span_ratio_vec = self._compute_span_ratio_for_pairs(
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            start_i=start_i_vec,
            start_j=start_j_vec,
            length=length_vec,
        )
        keep_mask = span_ratio_vec <= self.max_span_ratio
        if not bool(keep_mask.any()):
            return empty_pair, empty_pair, empty_pair, empty_pair, empty_length, empty_ratio

        start_i_vec = start_i_vec[keep_mask]
        start_j_vec = start_j_vec[keep_mask]
        length_vec = length_vec[keep_mask]
        span_ratio_vec = span_ratio_vec[keep_mask]

        segment_end_i = start_i_vec + length_vec
        segment_end_j = start_j_vec + length_vec
        frame_start_i = segment_starts[start_i_vec]
        frame_start_j = segment_starts[start_j_vec]
        frame_end_i = segment_ends[segment_end_i - 1]
        frame_end_j = segment_ends[segment_end_j - 1]

        pair_segment_starts = torch.stack([start_i_vec, start_j_vec], dim=-1)
        pair_segment_ends = torch.stack([segment_end_i, segment_end_j], dim=-1)
        pair_frame_starts = torch.stack([frame_start_i, frame_start_j], dim=-1)
        pair_frame_ends = torch.stack([frame_end_i, frame_end_j], dim=-1)
        return (
            pair_segment_starts,
            pair_segment_ends,
            pair_frame_starts,
            pair_frame_ends,
            length_vec,
            span_ratio_vec,
        )

    def _compute_span_ratio_for_pairs(
        self,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        start_i: torch.Tensor,
        start_j: torch.Tensor,
        length: torch.Tensor,
    ) -> torch.Tensor:
        end_i = start_i + length - 1
        end_j = start_j + length - 1
        frame_length_i = (segment_ends[end_i] - segment_starts[start_i]).to(dtype=torch.float32)
        frame_length_j = (segment_ends[end_j] - segment_starts[start_j]).to(dtype=torch.float32)
        shorter = torch.minimum(frame_length_i, frame_length_j).clamp_min(1.0)
        longer = torch.maximum(frame_length_i, frame_length_j)
        return longer / shorter


class ChordWindowSSM(nn.Module):
    """
    GT のコードセグメントでフレーム特徴を区切り、複数コード窓で自己類似行列を作る。

    想定用途:
      1. `initial_features` などのフレーム特徴を入力する
      2. GT のコードラベル列から連続セグメントを抽出する
      3. `window_size` 個の連続コードを 1 窓として埋め込み化し、SSM を作る
      4. それとは別に、GT ラベルが `window_size` 以上で完全一致する区間を
         可変長に伸ばし、学習で使う repeat 候補として返す

    まずは train-time の補助モジュールとして使う想定なので、パラメータは持たない。
    """

    def __init__(
        self,
        window_size: int = 4,
        window_hop: int = 1,
        compute_fixed_window_debug: bool = True,
        segment_pooling: str = "mean",
        similarity: str = "cosine",
        min_segment_frames: int = 1,
        min_window_frames: int = 1,
        max_span_ratio: float = 1.5,
        exclude_neighbor_windows: Optional[int] = None,
        similarity_threshold: Optional[float] = None,
        topk: Optional[int] = 5,
        append_duration_features: bool = False,
        ignore_index: int = -100,
        eps: float = 1e-8,
    ) -> None:
        super().__init__()
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if window_hop <= 0:
            raise ValueError("window_hop must be positive")
        if min_segment_frames <= 0:
            raise ValueError("min_segment_frames must be positive")
        if min_window_frames <= 0:
            raise ValueError("min_window_frames must be positive")
        if max_span_ratio < 1.0:
            raise ValueError("max_span_ratio must be >= 1.0")
        if segment_pooling not in {"mean", "max"}:
            raise ValueError("segment_pooling must be either 'mean' or 'max'")
        if similarity not in {"cosine", "dot", "negative_l2"}:
            raise ValueError("similarity must be one of {'cosine', 'dot', 'negative_l2'}")
        if topk is not None and topk <= 0:
            raise ValueError("topk must be positive when specified")

        self.window_size = int(window_size)
        self.window_hop = int(window_hop)
        self.compute_fixed_window_debug = bool(compute_fixed_window_debug)
        self.segment_pooling = segment_pooling
        self.similarity = similarity
        self.min_segment_frames = int(min_segment_frames)
        self.min_window_frames = int(min_window_frames)
        self.max_span_ratio = float(max_span_ratio)
        if exclude_neighbor_windows is None:
            exclude_neighbor_windows = math.ceil((self.window_size - 1) / self.window_hop)
        if exclude_neighbor_windows < 0:
            raise ValueError("exclude_neighbor_windows must be non-negative")
        self.exclude_neighbor_windows = int(exclude_neighbor_windows)
        self.similarity_threshold = similarity_threshold
        self.topk = topk
        self.append_duration_features = bool(append_duration_features)
        self.ignore_index = int(ignore_index)
        self.eps = float(eps)

    def forward(
        self,
        frame_features: torch.Tensor,
        chord_labels: torch.Tensor,
        frame_mask: Optional[torch.Tensor] = None,
    ) -> ChordWindowSSMOutput:
        """
        Args:
            frame_features:
                shape `(B, T, D)` のフレーム特徴。
            chord_labels:
                shape `(B, T)` の GT コードラベル。
                連続する同一ラベルを 1 コードセグメントとみなす。
            frame_mask:
                shape `(B, T)` の bool mask。padding 無効化用。省略時は
                `chord_labels != ignore_index` を有効フレームとみなす。
        """
        if frame_features.dim() != 3:
            raise ValueError("frame_features must have shape (B, T, D)")
        if chord_labels.dim() != 2:
            raise ValueError("chord_labels must have shape (B, T)")
        if frame_features.shape[:2] != chord_labels.shape:
            raise ValueError("frame_features and chord_labels must share batch/time dimensions")
        if frame_mask is not None and frame_mask.shape != chord_labels.shape:
            raise ValueError("frame_mask must have shape (B, T)")

        _, _, feature_dim = frame_features.shape
        # padding などの無効フレームは最初に落としておく。
        # 以降の segment 化では、この mask が切れた場所でもセグメントを分断する。
        valid_mask = chord_labels != self.ignore_index
        if frame_mask is not None:
            valid_mask = valid_mask & frame_mask.bool()

        # 1. GT の連続コードラベルから可変長のコードセグメント列を作る。
        (
            segment_features,
            segment_labels,
            segment_starts,
            segment_ends,
            segment_mask,
            segment_counts,
        ) = self._build_segment_batch(frame_features, chord_labels, valid_mask)

        if self.compute_fixed_window_debug:
            # 2. 連続する複数コードを 1 窓にまとめ、repeat 検索に使う埋め込みへ変換する。
            (
                window_features,
                window_labels,
                window_segment_starts,
                window_segment_ends,
                window_frame_starts,
                window_frame_ends,
                window_mask,
                window_counts,
            ) = self._build_window_batch(
                segment_features=segment_features,
                segment_labels=segment_labels,
                segment_starts=segment_starts,
                segment_ends=segment_ends,
                segment_mask=segment_mask,
                segment_counts=segment_counts,
                feature_dim=feature_dim,
            )

            # 3. 窓同士の自己類似行列を作り、近傍対角を除いた候補ペアを絞る。
            similarity = self._compute_similarity_batch(window_features, window_counts)
            pair_mask = self._build_pair_mask(window_mask)
            candidate_mask = self._build_candidate_mask(similarity, pair_mask, window_counts)
        else:
            (
                window_features,
                window_labels,
                window_segment_starts,
                window_segment_ends,
                window_frame_starts,
                window_frame_ends,
                window_mask,
                window_counts,
                similarity,
                pair_mask,
                candidate_mask,
            ) = self._build_empty_window_outputs(
                batch_size=frame_features.shape[0],
                feature_dim=feature_dim,
                device=frame_features.device,
                feature_dtype=frame_features.dtype,
                label_dtype=chord_labels.dtype,
            )

        # 4. 実際に学習へ渡す repeat 候補は、GT ラベル完全一致の可変長区間で作る。
        #    fixed window SSM はあくまで診断用に残し、本命の区間抽出はここで行う。
        (
            repeat_pair_mask,
            repeat_pair_lengths,
            repeat_pair_similarity,
            repeat_pair_span_ratio,
            repeat_pair_counts,
        ) = self._build_repeat_pair_batch(
            segment_features=segment_features,
            segment_labels=segment_labels,
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            segment_counts=segment_counts,
        )
        (
            repeat_pairs_segment_starts,
            repeat_pairs_segment_ends,
            repeat_pairs_frame_starts,
            repeat_pairs_frame_ends,
            repeat_pairs_lengths,
            repeat_pairs_similarity,
            repeat_pairs_span_ratio,
        ) = self._build_repeat_pair_list_batch(
            repeat_pair_mask=repeat_pair_mask,
            repeat_pair_lengths=repeat_pair_lengths,
            repeat_pair_similarity=repeat_pair_similarity,
            repeat_pair_span_ratio=repeat_pair_span_ratio,
            repeat_pair_counts=repeat_pair_counts,
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            segment_counts=segment_counts,
        )

        return ChordWindowSSMOutput(
            segment_features=segment_features,
            segment_labels=segment_labels,
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            segment_mask=segment_mask,
            segment_counts=segment_counts,
            window_features=window_features,
            window_labels=window_labels,
            window_segment_starts=window_segment_starts,
            window_segment_ends=window_segment_ends,
            window_frame_starts=window_frame_starts,
            window_frame_ends=window_frame_ends,
            window_mask=window_mask,
            window_counts=window_counts,
            similarity=similarity,
            pair_mask=pair_mask,
            candidate_mask=candidate_mask,
            repeat_pair_mask=repeat_pair_mask,
            repeat_pair_lengths=repeat_pair_lengths,
            repeat_pair_similarity=repeat_pair_similarity,
            repeat_pair_span_ratio=repeat_pair_span_ratio,
            repeat_pairs_segment_starts=repeat_pairs_segment_starts,
            repeat_pairs_segment_ends=repeat_pairs_segment_ends,
            repeat_pairs_frame_starts=repeat_pairs_frame_starts,
            repeat_pairs_frame_ends=repeat_pairs_frame_ends,
            repeat_pairs_lengths=repeat_pairs_lengths,
            repeat_pairs_similarity=repeat_pairs_similarity,
            repeat_pairs_span_ratio=repeat_pairs_span_ratio,
            repeat_pair_counts=repeat_pair_counts,
        )

    def _build_empty_window_outputs(
        self,
        batch_size: int,
        feature_dim: int,
        device: torch.device,
        feature_dtype: torch.dtype,
        label_dtype: torch.dtype,
    ) -> Tuple[
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
    ]:
        """学習時に fixed-window デバッグ経路を省くための空テンソル群を返す。"""
        window_feature_dim = feature_dim * self.window_size + (self.window_size if self.append_duration_features else 0)
        window_features = torch.zeros((batch_size, 0, window_feature_dim), dtype=feature_dtype, device=device)
        window_labels = torch.full((batch_size, 0, self.window_size), self.ignore_index, dtype=label_dtype, device=device)
        window_segment_starts = torch.zeros((batch_size, 0), dtype=label_dtype, device=device)
        window_segment_ends = torch.zeros((batch_size, 0), dtype=label_dtype, device=device)
        window_frame_starts = torch.zeros((batch_size, 0), dtype=label_dtype, device=device)
        window_frame_ends = torch.zeros((batch_size, 0), dtype=label_dtype, device=device)
        window_mask = torch.zeros((batch_size, 0), dtype=torch.bool, device=device)
        window_counts = torch.zeros((batch_size,), dtype=torch.long, device=device)
        similarity = torch.zeros((batch_size, 0, 0), dtype=feature_dtype, device=device)
        pair_mask = torch.zeros((batch_size, 0, 0), dtype=torch.bool, device=device)
        candidate_mask = torch.zeros((batch_size, 0, 0), dtype=torch.bool, device=device)
        return (
            window_features,
            window_labels,
            window_segment_starts,
            window_segment_ends,
            window_frame_starts,
            window_frame_ends,
            window_mask,
            window_counts,
            similarity,
            pair_mask,
            candidate_mask,
        )

    def _build_segment_batch(
        self,
        frame_features: torch.Tensor,
        chord_labels: torch.Tensor,
        valid_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """各サンプルの可変長セグメント列を作り、batch 用に pad して返す。"""
        batch_size, _, feature_dim = frame_features.shape

        per_sample_segments = []
        max_segments = 0
        for batch_idx in range(batch_size):
            starts, ends, labels = self._extract_segments_one(
                chord_labels=chord_labels[batch_idx],
                valid_mask=valid_mask[batch_idx],
            )
            # フレーム特徴はコード区間ごとに 1 ベクトルへ圧縮する。
            pooled = self._pool_segments_one(frame_features[batch_idx], starts, ends)
            per_sample_segments.append((pooled, starts, ends, labels))
            max_segments = max(max_segments, len(starts))

        segment_features = frame_features.new_zeros((batch_size, max_segments, feature_dim))
        segment_labels = chord_labels.new_full((batch_size, max_segments), self.ignore_index)
        segment_starts = chord_labels.new_zeros((batch_size, max_segments))
        segment_ends = chord_labels.new_zeros((batch_size, max_segments))
        segment_mask = torch.zeros((batch_size, max_segments), dtype=torch.bool, device=frame_features.device)
        segment_counts = torch.zeros((batch_size,), dtype=torch.long, device=frame_features.device)

        for batch_idx, (pooled, starts, ends, labels) in enumerate(per_sample_segments):
            count = len(starts)
            segment_counts[batch_idx] = count
            if count == 0:
                continue
            segment_features[batch_idx, :count] = pooled
            segment_labels[batch_idx, :count] = torch.tensor(
                labels, device=chord_labels.device, dtype=chord_labels.dtype
            )
            segment_starts[batch_idx, :count] = torch.tensor(
                starts, device=chord_labels.device, dtype=chord_labels.dtype
            )
            segment_ends[batch_idx, :count] = torch.tensor(ends, device=chord_labels.device, dtype=chord_labels.dtype)
            segment_mask[batch_idx, :count] = True

        return segment_features, segment_labels, segment_starts, segment_ends, segment_mask, segment_counts

    def _build_window_batch(
        self,
        segment_features: torch.Tensor,
        segment_labels: torch.Tensor,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        segment_mask: torch.Tensor,
        segment_counts: torch.Tensor,
        feature_dim: int,
    ) -> Tuple[
        torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor
    ]:
        """
        セグメント列から複数コード窓を作る。

        1 窓の埋め込みは、`window_size` 個のセグメント特徴を単純連結したもの。
        必要なら各セグメントの相対 duration も末尾に追加する。
        """
        batch_size = segment_features.shape[0]
        extra_dim = self.window_size if self.append_duration_features else 0
        window_feature_dim = feature_dim * self.window_size + extra_dim

        max_windows = 0
        window_counts_list = []
        for count in segment_counts.tolist():
            if count < self.window_size:
                window_counts_list.append(0)
            else:
                window_counts_list.append(1 + (count - self.window_size) // self.window_hop)
            max_windows = max(max_windows, window_counts_list[-1])

        window_features = segment_features.new_zeros((batch_size, max_windows, window_feature_dim))
        window_labels = segment_labels.new_full((batch_size, max_windows, self.window_size), self.ignore_index)
        window_segment_starts = segment_labels.new_zeros((batch_size, max_windows))
        window_segment_ends = segment_labels.new_zeros((batch_size, max_windows))
        window_frame_starts = segment_labels.new_zeros((batch_size, max_windows))
        window_frame_ends = segment_labels.new_zeros((batch_size, max_windows))
        window_mask = torch.zeros((batch_size, max_windows), dtype=torch.bool, device=segment_features.device)
        window_counts = torch.tensor(window_counts_list, dtype=torch.long, device=segment_features.device)

        for batch_idx in range(batch_size):
            num_windows = int(window_counts[batch_idx].item())
            if num_windows == 0:
                continue

            for window_idx in range(num_windows):
                # window_hop ごとに開始位置をずらしながら、連続する複数コードを切り出す。
                seg_start = window_idx * self.window_hop
                seg_end = seg_start + self.window_size
                seg_slice = slice(seg_start, seg_end)

                durations = segment_ends[batch_idx, seg_slice] - segment_starts[batch_idx, seg_slice]
                # 極端に短いセグメントや窓は後段の候補から除外できるように mask 化しておく。
                is_valid = bool(segment_mask[batch_idx, seg_slice].all().item())
                is_valid = is_valid and bool((durations >= self.min_segment_frames).all().item())
                is_valid = is_valid and bool(durations.sum().item() >= self.min_window_frames)

                embedding = self._build_window_embedding(
                    segment_features=segment_features[batch_idx, seg_slice],
                    durations=durations,
                )

                window_features[batch_idx, window_idx] = embedding
                window_labels[batch_idx, window_idx] = segment_labels[batch_idx, seg_slice]
                window_segment_starts[batch_idx, window_idx] = seg_start
                window_segment_ends[batch_idx, window_idx] = seg_end
                window_frame_starts[batch_idx, window_idx] = segment_starts[batch_idx, seg_start]
                window_frame_ends[batch_idx, window_idx] = segment_ends[batch_idx, seg_end - 1]
                window_mask[batch_idx, window_idx] = is_valid

        return (
            window_features,
            window_labels,
            window_segment_starts,
            window_segment_ends,
            window_frame_starts,
            window_frame_ends,
            window_mask,
            window_counts,
        )

    def _extract_segments_one(
        self,
        chord_labels: torch.Tensor,
        valid_mask: torch.Tensor,
    ) -> Tuple[list[int], list[int], list[int]]:
        """1 サンプル分のラベル列を、連続する同一ラベルごとの区間へ変換する。"""
        starts: list[int] = []
        ends: list[int] = []
        labels: list[int] = []

        time_steps = chord_labels.shape[0]
        time_idx = 0
        while time_idx < time_steps:
            if not bool(valid_mask[time_idx].item()):
                time_idx += 1
                continue

            start = time_idx
            current_label = int(chord_labels[time_idx].item())
            time_idx += 1
            while time_idx < time_steps:
                # 無効領域に入った時点でもセグメントを切る。
                if not bool(valid_mask[time_idx].item()):
                    break
                if int(chord_labels[time_idx].item()) != current_label:
                    break
                time_idx += 1

            starts.append(start)
            ends.append(time_idx)
            labels.append(current_label)

        return starts, ends, labels

    def _pool_segments_one(
        self,
        frame_features: torch.Tensor,
        starts: list[int],
        ends: list[int],
    ) -> torch.Tensor:
        """各コード区間のフレーム特徴を 1 ベクトルへ集約する。"""
        if not starts:
            return frame_features.new_zeros((0, frame_features.shape[-1]))

        pooled_segments = []
        for start, end in zip(starts, ends):
            segment = frame_features[start:end]
            if self.segment_pooling == "mean":
                pooled = segment.mean(dim=0)
            else:
                pooled = segment.max(dim=0).values
            pooled_segments.append(pooled)

        return torch.stack(pooled_segments, dim=0)

    def _build_window_embedding(
        self,
        segment_features: torch.Tensor,
        durations: torch.Tensor,
    ) -> torch.Tensor:
        """複数コード窓を 1 本のベクトルに並べ直す。"""
        embedding = segment_features.reshape(-1)
        if not self.append_duration_features:
            return embedding

        duration_features = durations.to(dtype=segment_features.dtype)
        duration_features = duration_features / duration_features.sum().clamp_min(1)
        return torch.cat([embedding, duration_features], dim=0)

    def _compute_similarity_batch(
        self,
        window_features: torch.Tensor,
        window_counts: torch.Tensor,
    ) -> torch.Tensor:
        """有効窓数ぶんだけ各サンプルの SSM を計算し、残りは 0 pad のままにする。"""
        batch_size, max_windows, _ = window_features.shape
        similarity = window_features.new_zeros((batch_size, max_windows, max_windows))

        for batch_idx in range(batch_size):
            num_windows = int(window_counts[batch_idx].item())
            if num_windows == 0:
                continue
            similarity[batch_idx, :num_windows, :num_windows] = self._compute_similarity_matrix(
                window_features[batch_idx, :num_windows]
            )

        return similarity

    def _compute_similarity_matrix(self, window_features: torch.Tensor) -> torch.Tensor:
        """1 サンプル分の窓埋め込みから類似度行列を作る。"""
        if self.similarity == "cosine":
            normalized = F.normalize(window_features, p=2, dim=-1, eps=self.eps)
            return normalized @ normalized.transpose(0, 1)
        if self.similarity == "dot":
            return window_features @ window_features.transpose(0, 1)

        distances = torch.cdist(window_features, window_features, p=2)
        return -distances

    def _build_pair_mask(self, window_mask: torch.Tensor) -> torch.Tensor:
        """
        比較してよい窓ペアだけを残す mask を作る。

        自己比較や、対角付近の trivially similar な近傍窓は除外する。
        """
        pair_mask = window_mask[:, :, None] & window_mask[:, None, :]
        if window_mask.shape[1] == 0:
            return pair_mask

        indices = torch.arange(window_mask.shape[1], device=window_mask.device)
        distance = (indices[:, None] - indices[None, :]).abs()
        pair_mask &= distance.unsqueeze(0) > self.exclude_neighbor_windows
        return pair_mask

    def _build_candidate_mask(
        self,
        similarity: torch.Tensor,
        pair_mask: torch.Tensor,
        window_counts: torch.Tensor,
    ) -> torch.Tensor:
        """
        類似度閾値と top-k を適用して、repeat 候補ペアをさらに絞る。

        top-k 適用後は片側だけ残るのを避けるため、最後に対称化する。
        """
        candidate_mask = pair_mask.clone()
        if self.similarity_threshold is not None:
            candidate_mask &= similarity >= self.similarity_threshold

        if self.topk is None:
            return candidate_mask

        topk_mask = torch.zeros_like(candidate_mask)
        batch_size = similarity.shape[0]
        for batch_idx in range(batch_size):
            num_windows = int(window_counts[batch_idx].item())
            if num_windows == 0:
                continue

            for window_idx in range(num_windows):
                row_mask = candidate_mask[batch_idx, window_idx, :num_windows]
                valid_count = int(row_mask.sum().item())
                if valid_count == 0:
                    continue

                k = min(self.topk, valid_count)
                row_scores = similarity[batch_idx, window_idx, :num_windows].masked_fill(~row_mask, float("-inf"))
                top_indices = row_scores.topk(k=k, dim=-1).indices
                topk_mask[batch_idx, window_idx, top_indices] = True

        topk_mask = (topk_mask | topk_mask.transpose(1, 2)) & pair_mask
        return topk_mask

    def _build_repeat_pair_batch(
        self,
        segment_features: torch.Tensor,
        segment_labels: torch.Tensor,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        segment_counts: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        GT ラベル完全一致の repeat 区間を、セグメント開始位置どうしの行列で返す。

        ここでの `window_size` は fixed window 長というより、
        「repeat とみなす最小一致コード数」として扱う。
        """
        batch_size, max_segments, _ = segment_features.shape
        repeat_pair_mask = torch.zeros(
            (batch_size, max_segments, max_segments), dtype=torch.bool, device=segment_features.device
        )
        repeat_pair_lengths = torch.zeros(
            (batch_size, max_segments, max_segments), dtype=torch.long, device=segment_features.device
        )
        repeat_pair_similarity = segment_features.new_zeros((batch_size, max_segments, max_segments))
        repeat_pair_span_ratio = segment_features.new_zeros((batch_size, max_segments, max_segments))
        repeat_pair_counts = torch.zeros((batch_size,), dtype=torch.long, device=segment_features.device)

        for batch_idx in range(batch_size):
            num_segments = int(segment_counts[batch_idx].item())
            if num_segments < self.window_size:
                continue

            mask_one, lengths_one, similarity_one, span_ratio_one = self._build_repeat_pair_one(
                segment_features=segment_features[batch_idx, :num_segments],
                segment_labels=segment_labels[batch_idx, :num_segments],
                segment_starts=segment_starts[batch_idx, :num_segments],
                segment_ends=segment_ends[batch_idx, :num_segments],
            )
            repeat_pair_mask[batch_idx, :num_segments, :num_segments] = mask_one
            repeat_pair_lengths[batch_idx, :num_segments, :num_segments] = lengths_one
            repeat_pair_similarity[batch_idx, :num_segments, :num_segments] = similarity_one
            repeat_pair_span_ratio[batch_idx, :num_segments, :num_segments] = span_ratio_one
            repeat_pair_counts[batch_idx] = mask_one.sum()

        return repeat_pair_mask, repeat_pair_lengths, repeat_pair_similarity, repeat_pair_span_ratio, repeat_pair_counts

    def _build_repeat_pair_list_batch(
        self,
        repeat_pair_mask: torch.Tensor,
        repeat_pair_lengths: torch.Tensor,
        repeat_pair_similarity: torch.Tensor,
        repeat_pair_span_ratio: torch.Tensor,
        repeat_pair_counts: torch.Tensor,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        segment_counts: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        dense な repeat 行列を、後段で直接使いやすい sparse pair list に変換する。

        返す segment/frame span は `(B, P, 2)` で、最後の次元が pair の 1 本目 / 2 本目を表す。
        """
        batch_size = repeat_pair_mask.shape[0]
        max_pairs = int(repeat_pair_counts.max().item()) if repeat_pair_counts.numel() > 0 else 0

        repeat_pairs_segment_starts = segment_starts.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_segment_ends = segment_starts.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_frame_starts = segment_starts.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_frame_ends = segment_starts.new_zeros((batch_size, max_pairs, 2))
        repeat_pairs_lengths = repeat_pair_lengths.new_zeros((batch_size, max_pairs))
        repeat_pairs_similarity = repeat_pair_similarity.new_zeros((batch_size, max_pairs))
        repeat_pairs_span_ratio = repeat_pair_span_ratio.new_zeros((batch_size, max_pairs))

        for batch_idx in range(batch_size):
            num_segments = int(segment_counts[batch_idx].item())
            num_pairs = int(repeat_pair_counts[batch_idx].item())
            if num_segments == 0 or num_pairs == 0:
                continue

            pair_indices = torch.nonzero(
                repeat_pair_mask[batch_idx, :num_segments, :num_segments],
                as_tuple=False,
            )
            if pair_indices.shape[0] != num_pairs:
                raise RuntimeError("repeat_pair_counts is inconsistent with repeat_pair_mask")

            segment_start_i = pair_indices[:, 0]
            segment_start_j = pair_indices[:, 1]
            lengths = repeat_pair_lengths[batch_idx, segment_start_i, segment_start_j]
            segment_end_i = segment_start_i + lengths
            segment_end_j = segment_start_j + lengths

            frame_start_i = segment_starts[batch_idx, segment_start_i]
            frame_start_j = segment_starts[batch_idx, segment_start_j]
            frame_end_i = segment_ends[batch_idx, segment_end_i - 1]
            frame_end_j = segment_ends[batch_idx, segment_end_j - 1]

            repeat_pairs_segment_starts[batch_idx, :num_pairs] = torch.stack([segment_start_i, segment_start_j], dim=-1)
            repeat_pairs_segment_ends[batch_idx, :num_pairs] = torch.stack([segment_end_i, segment_end_j], dim=-1)
            repeat_pairs_frame_starts[batch_idx, :num_pairs] = torch.stack([frame_start_i, frame_start_j], dim=-1)
            repeat_pairs_frame_ends[batch_idx, :num_pairs] = torch.stack([frame_end_i, frame_end_j], dim=-1)
            repeat_pairs_lengths[batch_idx, :num_pairs] = lengths
            repeat_pairs_similarity[batch_idx, :num_pairs] = repeat_pair_similarity[batch_idx, segment_start_i, segment_start_j]
            repeat_pairs_span_ratio[batch_idx, :num_pairs] = repeat_pair_span_ratio[batch_idx, segment_start_i, segment_start_j]

        return (
            repeat_pairs_segment_starts,
            repeat_pairs_segment_ends,
            repeat_pairs_frame_starts,
            repeat_pairs_frame_ends,
            repeat_pairs_lengths,
            repeat_pairs_similarity,
            repeat_pairs_span_ratio,
        )

    def _build_repeat_pair_one(
        self,
        segment_features: torch.Tensor,
        segment_labels: torch.Tensor,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        1 サンプル分の exact repeat を抽出する。

        `repeat_pair_mask[i, j] = True` は、
        セグメント i と j から始まる 2 区間が `window_size` 以上で完全一致し、
        かつ左右どちらにもこれ以上伸ばせない最大一致であることを表す。
        返す行列は重複を避けるため upper triangle (`i < j`) だけを使う。
        """
        num_segments = int(segment_labels.shape[0])
        repeat_pair_mask = torch.zeros((num_segments, num_segments), dtype=torch.bool, device=segment_labels.device)
        repeat_pair_lengths = torch.zeros((num_segments, num_segments), dtype=torch.long, device=segment_labels.device)
        repeat_pair_similarity = segment_features.new_zeros((num_segments, num_segments))
        repeat_pair_span_ratio = segment_features.new_zeros((num_segments, num_segments))

        # DP で「各開始位置ペアが何コード先まで完全一致するか」を前計算する。
        exact_match_lengths = torch.zeros(
            (num_segments + 1, num_segments + 1),
            dtype=torch.long,
            device=segment_labels.device,
        )
        zeros = exact_match_lengths.new_zeros((num_segments,))
        for start_i in range(num_segments - 1, -1, -1):
            label_matches = segment_labels == segment_labels[start_i]
            exact_match_lengths[start_i, :num_segments] = torch.where(
                label_matches,
                exact_match_lengths[start_i + 1, 1 : num_segments + 1] + 1,
                zeros,
            )

        segment_indices = torch.arange(num_segments, device=segment_labels.device)
        start_i = segment_indices[:, None]
        start_j = segment_indices[None, :]
        non_overlap_length = (start_j - start_i).clamp_min(0)
        exact_lengths = exact_match_lengths[:num_segments, :num_segments]
        match_lengths = torch.minimum(exact_lengths, non_overlap_length)

        candidate_mask = (start_j - start_i) >= self.window_size
        candidate_mask &= match_lengths >= self.window_size

        # 左へ伸ばせる候補は最大一致ではないので落とす。
        left_extend_mask = torch.zeros_like(candidate_mask)
        if num_segments > 1:
            prev_label_matches = segment_labels[:-1, None] == segment_labels[None, :-1]
            left_extend_mask[1:, 1:] = prev_label_matches
        can_extend_mask = match_lengths < non_overlap_length
        left_extend_mask &= can_extend_mask

        # 右側の 1 セグメント先も一致するなら、まだ最大一致ではない。
        right_extend_mask = torch.zeros_like(candidate_mask)
        next_i = start_i + match_lengths
        next_j = start_j + match_lengths
        right_valid_mask = candidate_mask & can_extend_mask & (next_i < num_segments) & (next_j < num_segments)
        if bool(right_valid_mask.any().item()):
            right_i = next_i[right_valid_mask]
            right_j = next_j[right_valid_mask]
            right_extend_mask[right_valid_mask] = segment_labels[right_i] == segment_labels[right_j]

        maximal_mask = candidate_mask & ~left_extend_mask & ~right_extend_mask
        if not bool(maximal_mask.any().item()):
            return repeat_pair_mask, repeat_pair_lengths, repeat_pair_similarity, repeat_pair_span_ratio

        candidate_indices = torch.nonzero(maximal_mask, as_tuple=False)
        start_i_vec = candidate_indices[:, 0]
        start_j_vec = candidate_indices[:, 1]
        length_vec = match_lengths[start_i_vec, start_j_vec]

        span_ratio_vec = self._compute_span_ratio_for_pairs(
            segment_starts=segment_starts,
            segment_ends=segment_ends,
            start_i=start_i_vec,
            start_j=start_j_vec,
            length=length_vec,
        )
        keep_mask = span_ratio_vec <= self.max_span_ratio
        if not bool(keep_mask.any().item()):
            return repeat_pair_mask, repeat_pair_lengths, repeat_pair_similarity, repeat_pair_span_ratio

        start_i_vec = start_i_vec[keep_mask]
        start_j_vec = start_j_vec[keep_mask]
        length_vec = length_vec[keep_mask]
        span_ratio_vec = span_ratio_vec[keep_mask]

        repeat_pair_mask[start_i_vec, start_j_vec] = True
        repeat_pair_lengths[start_i_vec, start_j_vec] = length_vec
        repeat_pair_span_ratio[start_i_vec, start_j_vec] = span_ratio_vec

        for pair_idx in range(start_i_vec.shape[0]):
            start_i_int = int(start_i_vec[pair_idx])
            start_j_int = int(start_j_vec[pair_idx])
            length_int = int(length_vec[pair_idx])
            repeat_pair_similarity[start_i_int, start_j_int] = self._compute_sequence_similarity(
                segment_features=segment_features,
                start_i=start_i_int,
                start_j=start_j_int,
                length=length_int,
            )

        return repeat_pair_mask, repeat_pair_lengths, repeat_pair_similarity, repeat_pair_span_ratio

    def _compute_sequence_similarity(
        self,
        segment_features: torch.Tensor,
        start_i: int,
        start_j: int,
        length: int,
    ) -> torch.Tensor:
        """可変長 repeat 区間全体を連結し、その系列どうしの cosine 類似度を返す。"""
        sequence_i = segment_features[start_i : start_i + length].reshape(1, -1)
        sequence_j = segment_features[start_j : start_j + length].reshape(1, -1)
        return F.cosine_similarity(sequence_i, sequence_j, dim=-1, eps=self.eps).squeeze(0)

    def _compute_span_ratio(
        self,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        start_i: int,
        start_j: int,
        length: int,
    ) -> torch.Tensor:
        """repeat 2 区間の総フレーム長比を返す。1.0 に近いほど長さが揃っている。"""
        frame_length_i = (segment_ends[start_i + length - 1] - segment_starts[start_i]).to(dtype=torch.float32)
        frame_length_j = (segment_ends[start_j + length - 1] - segment_starts[start_j]).to(dtype=torch.float32)
        shorter = torch.minimum(frame_length_i, frame_length_j).clamp_min(1.0)
        longer = torch.maximum(frame_length_i, frame_length_j)
        return longer / shorter

    def _compute_span_ratio_for_pairs(
        self,
        segment_starts: torch.Tensor,
        segment_ends: torch.Tensor,
        start_i: torch.Tensor,
        start_j: torch.Tensor,
        length: torch.Tensor,
    ) -> torch.Tensor:
        """複数 pair ぶんの総フレーム長比をまとめて計算する。"""
        end_i = start_i + length - 1
        end_j = start_j + length - 1
        frame_length_i = (segment_ends[end_i] - segment_starts[start_i]).to(dtype=torch.float32)
        frame_length_j = (segment_ends[end_j] - segment_starts[start_j]).to(dtype=torch.float32)
        shorter = torch.minimum(frame_length_i, frame_length_j).clamp_min(1.0)
        longer = torch.maximum(frame_length_i, frame_length_j)
        return longer / shorter
