"""Constants used by Kwikset Halo API.

This module contains all constant values used throughout the library,
including AWS Cognito configuration, API endpoints, and HTTP headers.
"""

import logging
from typing import Final

# Logger configuration
LOGGER: logging.Logger = logging.getLogger(__name__)

# AWS Cognito Configuration
POOL_ID: Final[str] = "us-east-1_6B3uo6uKN"
CLIENT_ID: Final[str] = "5eu1cdkjp1itd1fi7b91m6g79s"
POOL_REGION: Final[str] = "us-east-1"

# API Base URL
API_BASE_URL: Final[str] = "https://ynk95r1v52.execute-api.us-east-1.amazonaws.com"

# User Endpoints
GET_USER_URL: Final[str] = f"{API_BASE_URL}/prod_v1/users/me"
GET_HOMES_URL: Final[str] = f"{API_BASE_URL}/prod_v1/users/me/homes?top=200"

# Device Endpoints
GET_HOME_DEVICES_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/devices"
GET_DEVICE_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices_v2/%s"
GET_DEVICE_HISTORY_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices_v4/%s/history_v4"

# Device Command Endpoints
LOCK_COMMAND_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/status"
ACCESSORY_COMMAND_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/%s"
AUTOLOCK_COMMAND_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/autolock"

# Auto-lock delay (seconds). The Kwikset mobile app exposes a fixed set of
# choices; the API itself accepts integer seconds but unsupported values may
# be rejected by firmware.
AUTOLOCK_DELAY_15S: Final[int] = 15
AUTOLOCK_DELAY_30S: Final[int] = 30
AUTOLOCK_DELAY_1M: Final[int] = 60
AUTOLOCK_DELAY_3M: Final[int] = 180
AUTOLOCK_DELAY_5M: Final[int] = 300
AUTOLOCK_DELAY_10M: Final[int] = 600
AUTOLOCK_DELAY_25M: Final[int] = 1500
AUTOLOCK_DELAY_DEFAULT: Final[int] = AUTOLOCK_DELAY_30S
AUTOLOCK_DELAY_VALID: Final[tuple[int, ...]] = (
    AUTOLOCK_DELAY_15S,
    AUTOLOCK_DELAY_30S,
    AUTOLOCK_DELAY_1M,
    AUTOLOCK_DELAY_3M,
    AUTOLOCK_DELAY_5M,
    AUTOLOCK_DELAY_10M,
    AUTOLOCK_DELAY_25M,
)

# Home User Endpoints
GET_HOME_USERS_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/sharedusers"
INVITE_HOME_USER_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/sharedusers_v2"
UPDATE_HOME_USER_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/sharedusers_v2/%s"
DELETE_HOME_USER_URL: Final[str] = f"{API_BASE_URL}/prod_v1/homes/%s/sharedusers/%s"

# Access Code Endpoints
ACCESS_CODE_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/accesscode"
ACCESS_CODE_SYNC_URL: Final[str] = f"{API_BASE_URL}/prod_v1/devices/%s/accesscode/%s"

# Access Code Validation
MIN_ACCESS_CODES: Final[int] = 1

# HTTP Headers
LOGIN_HEADER_USER_AGENT: Final[str] = (
    "aws-sdk-kotlin/1.3.81 ua/2.1 api/cognito-identity-provider#1.3.81"
)
DEFAULT_HEADER_USER_AGENT: Final[str] = "okhttp/5.0.0-alpha.14"
DEFAULT_HEADER_ACCEPT_ENCODING: Final[str] = "gzip"

# Request Configuration
DEFAULT_TIMEOUT: Final[int] = 30  # seconds
MAX_RETRIES: Final[int] = 3
RETRY_DELAY: Final[float] = 1.0  # seconds

# AWS Cognito (botocore) network configuration.
#
# The AWS SDK's defaults (60s connect, 60s read, 5 retries) can cause the
# library to block for many minutes when AWS Cognito is slow or a network
# path is broken. The values below cap a worst-case authentication attempt
# at roughly (BOTO_CONNECT_TIMEOUT + BOTO_READ_TIMEOUT) * BOTO_MAX_ATTEMPTS
# seconds while still tolerating transient hiccups.
BOTO_CONNECT_TIMEOUT: Final[float] = 10.0  # seconds
BOTO_READ_TIMEOUT: Final[float] = 15.0  # seconds
BOTO_MAX_ATTEMPTS: Final[int] = 2  # total attempts (initial + 1 retry)

# Custom Challenge Configuration
CUSTOM_CHALLENGE_GENERATE_ANSWER: Final[str] = "answerType:generateCode,medium:%s,codeType:login"

# ============================================================================
# AppSync WebSocket Configuration
# ============================================================================

# Core API AppSync endpoints
CORE_APPSYNC_API_HOST: Final[str] = "mnlxsdywfvhoxh627qfakupckm.appsync-api.us-east-1.amazonaws.com"
CORE_APPSYNC_REALTIME_HOST: Final[str] = (
    "mnlxsdywfvhoxh627qfakupckm.appsync-realtime-api.us-east-1.amazonaws.com"
)

# Halo V API AppSync endpoints
HALOV_APPSYNC_API_HOST: Final[str] = (
    "axcsjbhnx5f77f5ftbgehsk4ky.appsync-api.us-east-1.amazonaws.com"
)
HALOV_APPSYNC_REALTIME_HOST: Final[str] = (
    "axcsjbhnx5f77f5ftbgehsk4ky.appsync-realtime-api.us-east-1.amazonaws.com"
)

# WebSocket connection configuration
WS_CONNECTION_TIMEOUT: Final[float] = 10.0  # seconds to wait for connection_ack
WS_START_ACK_TIMEOUT: Final[float] = 10.0  # seconds to wait for start_ack
WS_MIN_RECONNECT_DELAY: Final[float] = 1.0  # initial reconnect backoff seconds
WS_MAX_RECONNECT_DELAY: Final[float] = 60.0  # max reconnect backoff seconds
WS_KA_TIMEOUT_MULTIPLIER: Final[float] = 1.5  # multiplier for ka timeout

# ============================================================================
# GraphQL Subscription Queries — Core API
# ============================================================================

GQL_ON_MANAGE_DEVICE: Final[str] = (
    "subscription deviceSubscription($email: String!) {"
    "  onManageDevice(email: $email) {"
    "    __typename email operationtype deviceid devicename"
    "    batterypercentage firmwareversion devicestatus batterystate"
    "    issyncsuccess failurereason autolockstate autolockdelay"
    "    audiostatus devicetimezone doubletapstatus sku"
    "    securemodeenabled securemodeactive productfamily"
    "    securescreenstatus locktamperstate lockmqresponse ledstatus"
    "    modelnumber eventtype connectivitystatus lastupdatestatus"
    "    isdoorstatusenabled doorstatusfrequency accesscodecrc"
    "    accesscodesixtyfour accesscodeeight accesscodebyindex"
    "    doorsettings doorposition dooropenedtime lockopmode"
    "    lockopstate lockopmodehex lockopstatehex batterystatushex"
    "    batterytypehex proxyeventstatushex"
    "  }"
    "}"
)

GQL_ON_MANAGE_USER: Final[str] = (
    "subscription userSubscription($email: String!) {"
    "  onManageUser(email: $email) {"
    "    __typename email operationtype firstname lastname"
    "    phonenumber accountenabled brandname mfaenabled phoneactive"
    "  }"
    "}"
)

GQL_ON_MANAGE_HOME: Final[str] = (
    "subscription homeSubscription($email: String!) {"
    "  onManageHome(email: $email) {"
    "    __typename email operationtype homeid homename isshared"
    "    ownerhome sharedbyname useraccesslevel useraccesslevelstatus"
    "    shareddate sharedwith updatesharedbyname updateshareddate"
    "    deleteshareddate disableshareddate acceptrejectdate"
    "    acceptreject enableshareddate"
    "  }"
    "}"
)

# ============================================================================
# GraphQL Subscription Queries — Halo V API
# ============================================================================

GQL_ON_UPDATE_HAV_DEVICE_STATUS: Final[str] = (
    "subscription OnUpdateHavDeviceStatus($email: String!) {"
    "  onUpdateHavDeviceStatus(email: $email) {"
    "    __typename deviceId deviceStatus fwTimeStamp"
    "    manualMatterCode version email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_DEVICE: Final[str] = (
    "subscription OnUpdateHavDevice($email: String!) {"
    "  onUpdateHavDevice(email: $email) {"
    "    __typename deviceId deviceName ownerEmail ownerUserId"
    "    activationState activationDate serialNumber thingName"
    "    modelNumber deviceTimeZone firmwareUpdateStatus fwForceUpdate"
    "    firmwareVersion deviceConnectionStatus enableWifi connectedAC"
    "    autoCloseDelay autoCloseDelaySetting createdDate lastModified"
    "    deleted email manualMatterCode factoryReset timeStamp"
    "    clearedEventHistory clearedEventHistoryTimeStamp"
    "    lcuFwUpdateStatus lcuFwVersion lcuFwForceUpdate"
    "    rebootTimeStamp enableMatter"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_LED_STATUS: Final[str] = (
    "subscription OnUpdateHavLedStatus($email: String!) {"
    "  onUpdateHavLedStatus(email: $email) {"
    "    __typename deviceId ledStatus version fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_PERCENTAGE: Final[str] = (
    "subscription OnUpdateHavPercentage($email: String!) {"
    "  onUpdateHavPercentage(email: $email) {"
    "    __typename deviceId percentage fwTimeStamp"
    "    manualMatterCode version email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_VACATION_MODE: Final[str] = (
    "subscription OnUpdateHavVacationMode($email: String!) {"
    "  onUpdateHavVacationMode(email: $email) {"
    "    __typename deviceId vacationMode fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_AUTO_CLOSE_SCHEDULE: Final[str] = (
    "subscription OnUpdateHavAutoCloseSchedule($email: String!) {"
    "  onUpdateHavAutoCloseSchedule(email: $email) {"
    "    __typename deviceId updateSchedule manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_EVENT: Final[str] = (
    "subscription OnUpdateHavEvent($email: String!) {"
    "  onUpdateHavEvent(email: $email) {"
    "    __typename id deviceId deviceName recordId recordStatus"
    "    eventBy eventGroupId operationEvent garageState"
    "    garagePercentage batteryVoltage dcVoltage user timeStamp"
    "    manualMatterCode ssidWifi email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_WIFI_SIGNAL: Final[str] = (
    "subscription OnUpdateHavWifiSignal($email: String!) {"
    "  onUpdateHavWifiSignal(email: $email) {"
    "    __typename deviceId wifiSignal fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_BATTERY_VOLTAGE: Final[str] = (
    "subscription OnUpdateHavBatteryVoltage($email: String!) {"
    "  onUpdateHavBatteryVoltage(email: $email) {"
    "    __typename deviceId batteryVoltage fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_CYCLES: Final[str] = (
    "subscription OnUpdateHavCycles($email: String!) {"
    "  onUpdateHavCycles(email: $email) {"
    "    __typename deviceId cycles fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_TEMPORARY_KEY: Final[str] = (
    "subscription OnUpdateHavTemporaryKey($email: String!) {"
    "  onUpdateHavTemporaryKey(email: $email) {"
    "    __typename deviceId temporaryKey manualMatterCode"
    "    userHash email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_SENSOR: Final[str] = (
    "subscription OnUpdateHavSensor($email: String!) {"
    "  onUpdateHavSensor(email: $email) {"
    "    __typename deviceId alignSensor alarmMI alarmOD alarmOE"
    "    alarmOG alarmOF closeAttemptCounter manualMatterCode"
    "    fwTimeStamp alignSensorVersion email"
    "  }"
    "}"
)

GQL_ON_UPDATE_HAV_BRIGHTNESS_LEVEL: Final[str] = (
    "subscription OnUpdateHavBrightnessLevel($email: String!) {"
    "  onUpdateHavBrightnessLevel(email: $email) {"
    "    __typename deviceId brightnessLevel fwTimeStamp"
    "    manualMatterCode email"
    "  }"
    "}"
)
