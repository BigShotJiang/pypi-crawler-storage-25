from pathlib import Path

from quietplace.demo_scene import create_demo_scene
from quietplace.pipeline import run_pipeline


def test_synthetic_demo_pipeline(tmp_path: Path):
    scene = create_demo_scene(tmp_path / "scene")
    run = run_pipeline(scene["audio"], tmp_path / "run", events_json=scene["events"], backend="mock")
    assert Path(run["files"]["suppressed_audio"]).exists()
    assert run["summary_metrics"]["duration_sec"] > 0
    assert "calm_zone_noise_reduction_db" in run["summary_metrics"]
