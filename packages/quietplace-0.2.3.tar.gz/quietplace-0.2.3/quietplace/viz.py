from __future__ import annotations

from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal

from .audio import Event


def mel_like_db(y: np.ndarray, sr: int, nperseg: int = 1024, noverlap: int = 768) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    freqs, times, Z = signal.stft(y, fs=sr, nperseg=nperseg, noverlap=noverlap)
    mag = np.abs(Z) ** 2
    db = 10.0 * np.log10(mag + 1e-12)
    db -= float(np.max(db)) if db.size else 0.0
    return times, freqs, db


def plot_spectrogram(y: np.ndarray, sr: int, title: str, events: Iterable[Event] | None = None, ax=None):
    if ax is None:
        _, ax = plt.subplots(figsize=(14, 4))
    times, freqs, db = mel_like_db(y, sr)
    im = ax.imshow(
        db,
        origin="lower",
        aspect="auto",
        extent=(times.min() if len(times) else 0, times.max() if len(times) else 0, freqs.min() if len(freqs) else 0, freqs.max() if len(freqs) else sr / 2),
        vmin=-80,
        vmax=0,
    )
    ax.set_ylim(0, min(5000, int(sr / 2)))
    ax.set_xlabel("time (s)")
    ax.set_ylabel("frequency (Hz)")
    ax.set_title(title)
    if events:
        for e in events:
            linestyle = "--" if e.policy_hint == "preserve" else "-"
            ax.axvspan(e.start, e.end, alpha=0.18 if e.policy_hint == "preserve" else 0.11, linestyle=linestyle)
            ax.text(e.start, ax.get_ylim()[1] * 0.92, f"{e.label}\n{e.policy_hint}", fontsize=8, va="top")
    return im


def plot_before_after_spectrograms(y0: np.ndarray, y1: np.ndarray, sr: int, events: list[Event] | None = None, out: str | Path | None = None):
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), constrained_layout=True)
    im0 = plot_spectrogram(y0, sr, "Original soundscape: nuisance + protected sounds", events=events, ax=axes[0])
    im1 = plot_spectrogram(y1, sr, "quiteplace output: calm zones reduced, safety segments retained", events=events, ax=axes[1])
    fig.colorbar(im1, ax=axes, shrink=0.8, label="relative power (dB)")
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=180, bbox_inches="tight")
    return fig


def plot_waveforms(y0: np.ndarray, y1: np.ndarray, sr: int, events: list[Event] | None = None, out: str | Path | None = None):
    t = np.arange(len(y0)) / sr
    fig, ax = plt.subplots(figsize=(14, 3.5))
    ax.plot(t, y0, linewidth=0.8, label="original", alpha=0.7)
    ax.plot(t[: len(y1)], y1, linewidth=0.8, label="suppressed", alpha=0.7)
    if events:
        for e in events:
            ax.axvspan(e.start, e.end, alpha=0.08 if e.policy_hint == "preserve" else 0.05)
    ax.set_xlabel("time (s)")
    ax.set_ylabel("amplitude")
    ax.set_title("Waveform A/B")
    ax.legend(loc="upper right")
    fig.tight_layout()
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=180, bbox_inches="tight")
    return fig


def plot_segment_metrics(metrics: pd.DataFrame, out: str | Path | None = None):
    fig, ax = plt.subplots(figsize=(12, 4))
    if metrics.empty:
        ax.text(0.5, 0.5, "No segment metrics", ha="center", va="center")
    else:
        labels = [f"{r.label}\n{r.start:.1f}-{r.end:.1f}s" for r in metrics.itertuples()]
        ax.bar(labels, metrics["reduction_db"])
        ax.set_ylabel("RMS reduction (dB)")
        ax.set_title("Segment-by-segment advantage: suppressible segments should drop; protected segments should not")
        ax.tick_params(axis="x", labelrotation=30)
    fig.tight_layout()
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=180, bbox_inches="tight")
    return fig


def plot_bandpower_metrics(bands: pd.DataFrame, out: str | Path | None = None):
    fig, ax = plt.subplots(figsize=(10, 4))
    if bands.empty:
        ax.text(0.5, 0.5, "No band metrics", ha="center", va="center")
    else:
        ax.bar(bands["band"], bands["reduction_db"])
        ax.set_ylabel("band energy reduction (dB)")
        ax.set_title("Frequency advantage: hum/rumble bands should shrink most")
        ax.tick_params(axis="x", labelrotation=20)
    fig.tight_layout()
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=180, bbox_inches="tight")
    return fig


def save_all_charts(run: dict, out_dir: str | Path) -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    y0, y1, sr = run["original_audio"], run["suppressed_audio_array"], run["sr"]
    events = run["events"]
    paths = {
        "spectrogram_before_after": str(out / "01_before_after_spectrograms.png"),
        "waveform_ab": str(out / "02_waveform_ab.png"),
        "segment_metrics": str(out / "03_segment_metrics.png"),
        "bandpower_metrics": str(out / "04_bandpower_metrics.png"),
    }
    plot_before_after_spectrograms(y0, y1, sr, events, paths["spectrogram_before_after"])
    plot_waveforms(y0, y1, sr, events, paths["waveform_ab"])
    plot_segment_metrics(run["segment_metrics"], paths["segment_metrics"])
    plot_bandpower_metrics(run["bandpower_metrics"], paths["bandpower_metrics"])
    plt.close("all")
    return paths
