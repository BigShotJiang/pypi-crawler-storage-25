from __future__ import annotations

from typing import Any, Iterable

import numpy as np
from scipy import signal

from .audio import normalize, protected_mask, segment_mask
from .config import SR


def apply_notch(y: np.ndarray, sr: int, freqs: Iterable[float], q: float = 35.0) -> np.ndarray:
    out = np.asarray(y, dtype=np.float32).copy()
    for f0 in freqs:
        f0 = float(f0)
        if 20.0 <= f0 < sr / 2.0 - 100.0:
            b, a = signal.iirnotch(w0=f0, Q=float(q), fs=sr)
            out = signal.filtfilt(b, a, out).astype(np.float32)
    return out.astype(np.float32)


def semantic_spectral_gate(y: np.ndarray, sr: int = SR, reduction_db: float = 14.0) -> np.ndarray:
    y = np.asarray(y, dtype=np.float32)
    if y.size < 256:
        return y.copy()
    nperseg = min(1024, max(256, len(y) // 8))
    noverlap = nperseg // 2
    freqs, times, Z = signal.stft(y, fs=sr, nperseg=nperseg, noverlap=noverlap)
    mag = np.abs(Z)
    phase = np.exp(1j * np.angle(Z))

    # A gentle, deterministic spectral gate: keep bins clearly above local noise,
    # attenuate stable background bins. No model magic happens here.
    noise_profile = np.percentile(mag, 35, axis=1, keepdims=True)
    floor = 10 ** (-abs(float(reduction_db)) / 20.0)
    soft_mask = np.where(mag > noise_profile * 1.55, 1.0, floor)
    soft_mask = signal.medfilt2d(soft_mask, kernel_size=(3, 3))
    _, out = signal.istft(mag * soft_mask * phase, fs=sr, nperseg=nperseg, noverlap=noverlap)
    return out[: len(y)].astype(np.float32)


def crossfade_copy(original: np.ndarray, processed: np.ndarray, sr: int, preserve: Iterable[tuple[float, float] | list[float]], fade_ms: float = 20.0) -> np.ndarray:
    original = np.asarray(original, dtype=np.float32)
    processed = np.asarray(processed, dtype=np.float32).copy()
    n = len(original)
    fade = max(1, int(sr * fade_ms / 1000.0))
    for start, end in preserve:
        a = max(0, min(n, int(round(float(start) * sr))))
        b = max(0, min(n, int(round(float(end) * sr))))
        if b <= a:
            continue
        processed[a:b] = original[a:b]
        if a > 0:
            lo = max(0, a - fade)
            w = np.linspace(0.0, 1.0, a - lo, endpoint=False, dtype=np.float32)
            processed[lo:a] = processed[lo:a] * (1.0 - w) + original[lo:a] * w
        if b < n:
            hi = min(n, b + fade)
            w = np.linspace(1.0, 0.0, hi - b, endpoint=False, dtype=np.float32)
            processed[b:hi] = processed[b:hi] * (1.0 - w) + original[b:hi] * w
    return processed.astype(np.float32)


def execute_plan(y: np.ndarray, sr: int, plan: dict[str, Any]) -> np.ndarray:
    original = np.asarray(y, dtype=np.float32)
    out = original.copy()
    preserve = [tuple(x) for x in plan.get("preserve_segments_sec", [])]

    for action in plan.get("actions", []):
        fn = action.get("function") or action.get("name")
        args = action.get("args", {}) or {}
        target_segments = args.get("target_segments_sec") or plan.get("suppress_segments_sec") or []
        target = segment_mask(len(out), sr, target_segments) if target_segments else np.ones(len(out), dtype=bool)

        if fn == "apply_notch":
            processed = apply_notch(out, sr, args.get("frequencies_hz", []), args.get("quality_factor", 35.0))
            out[target] = processed[target]
        elif fn in {"apply_semantic_spectral_gate", "apply_spectral_gate"}:
            processed = semantic_spectral_gate(out, sr, args.get("reduction_db", 14.0))
            out[target] = processed[target]
        elif fn == "copy_original_for_segments":
            preserve = [tuple(x) for x in args.get("preserve_segments_sec", preserve)]

    # Non-negotiable safety copy-back: protected intervals stay original even if the LLM forgets.
    out = crossfade_copy(original, out, sr, preserve)
    m = protected_mask(len(original), sr, preserve)
    out[m] = original[m]
    return normalize(out, peak=0.98)
