from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .audio import Event, infer_policy, load_audio, normalize_label
from .config import AST_WEIGHTS_DIR, SR

DEFAULT_POLICY_MAP = {
    "siren": "preserve",
    "alarm": "preserve",
    "fire_alarm": "preserve",
    "speech": "preserve",
    "human_voice": "preserve",
    "baby_cry": "preserve",
    "crying_baby": "preserve",
    "knock": "preserve",
    "traffic_noise": "suppress",
    "roadway_noise": "suppress",
    "engine_idling": "suppress",
    "engine": "suppress",
    "fan_hum": "suppress",
    "air_conditioner": "suppress",
    "drilling": "suppress",
    "jackhammer": "suppress",
    "generator_hum": "suppress",
    "machine_noise": "suppress",
}


class AudioPolicyClassifier:
    """Inference wrapper for the already-trained AST classifier.

    The training/export step should save a Hugging Face-compatible directory at
    ``quiteplace.config.AST_WEIGHTS_DIR``. The notebook uses this hard-coded
    pointer by default, as requested, so the demo path does not expose a training
    cell or accidental retraining path.
    """

    def __init__(self, weights_dir: str | Path = AST_WEIGHTS_DIR, device: str | None = None):
        self.weights_dir = Path(weights_dir)
        self.device = device
        self.policy_map = dict(DEFAULT_POLICY_MAP)
        policy_path = self.weights_dir / "policy_map.json"
        if policy_path.exists():
            self.policy_map.update(json.loads(policy_path.read_text()))
        self._processor = None
        self._model = None
        self._id2label: dict[int, str] = {}

    def _lazy_load(self) -> None:
        if self._model is not None:
            return
        if not self.weights_dir.exists():
            raise FileNotFoundError(
                f"AST classifier weights not found at {self.weights_dir}. "
                "Place the exported save_pretrained directory there or edit quiteplace/config.py."
            )
        import torch
        from transformers import AutoFeatureExtractor, AutoModelForAudioClassification

        self._processor = AutoFeatureExtractor.from_pretrained(str(self.weights_dir))
        self._model = AutoModelForAudioClassification.from_pretrained(str(self.weights_dir))
        self.device = self.device or ("cuda" if torch.cuda.is_available() else "cpu")
        self._model.to(self.device)
        self._model.eval()
        cfg = getattr(self._model, "config", None)
        raw_id2label = getattr(cfg, "id2label", {}) or {}
        self._id2label = {int(k): normalize_label(v) for k, v in raw_id2label.items()}

    def predict_clip(self, audio: np.ndarray, sr: int = SR) -> tuple[str, float, str]:
        self._lazy_load()
        import torch

        assert self._processor is not None and self._model is not None
        inputs = self._processor(audio, sampling_rate=sr, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.no_grad():
            logits = self._model(**inputs).logits[0]
            probs = torch.softmax(logits, dim=-1).detach().cpu().numpy()
        idx = int(np.argmax(probs))
        label = self._id2label.get(idx, str(idx))
        conf = float(probs[idx])
        policy = self.policy_map.get(label, infer_policy(label))
        return label, conf, policy

    def predict_windows(
        self,
        audio_path: str | Path,
        window_sec: float = 2.0,
        hop_sec: float = 1.0,
        min_confidence: float = 0.25,
        merge_gap_sec: float = 0.25,
    ) -> list[Event]:
        y, sr = load_audio(audio_path, sr=SR)
        n = len(y)
        win = max(1, int(window_sec * sr))
        hop = max(1, int(hop_sec * sr))
        rows: list[Event] = []
        if n == 0:
            return rows
        for start in range(0, max(1, n - win + 1), hop):
            end = min(n, start + win)
            clip = y[start:end]
            label, conf, policy = self.predict_clip(clip, sr)
            if conf < min_confidence:
                policy = "uncertain"
            rows.append(Event(label, start / sr, end / sr, conf, policy, "ast"))
        if not rows:
            label, conf, policy = self.predict_clip(y, sr)
            rows.append(Event(label, 0.0, n / sr, conf, policy, "ast"))
        return merge_events(rows, merge_gap_sec=merge_gap_sec)


def merge_events(events: list[Event], merge_gap_sec: float = 0.25) -> list[Event]:
    if not events:
        return []
    merged: list[Event] = []
    for e in sorted(events, key=lambda x: (x.start, x.end)):
        if (
            merged
            and merged[-1].label == e.label
            and merged[-1].policy_hint == e.policy_hint
            and e.start - merged[-1].end <= merge_gap_sec
        ):
            prev = merged[-1]
            total = max(1e-6, (prev.end - prev.start) + (e.end - e.start))
            conf = ((prev.end - prev.start) * prev.confidence + (e.end - e.start) * e.confidence) / total
            merged[-1] = Event(prev.label, prev.start, max(prev.end, e.end), conf, prev.policy_hint, prev.source)
        else:
            merged.append(e)
    return merged
