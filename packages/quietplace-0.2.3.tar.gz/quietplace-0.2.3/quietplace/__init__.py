"""quiteplace: notebook-first semantic noise suppression."""

from .audio import Event
from .pipeline import run_pipeline

__all__ = ["Event", "run_pipeline"]
__version__ = "0.2.0"
