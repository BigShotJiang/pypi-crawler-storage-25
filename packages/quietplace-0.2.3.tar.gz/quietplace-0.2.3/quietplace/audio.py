from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import soundfile as sf
from scipy import signal

from .config import PROTECTED_LABELS, SR, SUPPRESSIBLE_LABELS


@dataclass(slots=True)
class Event:
    label: str
    start: float
    end: float
    confidence: float
    policy_hint: str = "uncertain"
    source: str = "classifier"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "Event":
        return cls(
            label=str(row.get("label", "unknown")),
            start=float(row.get("start", 0.0)),
            end=float(row.get("end", 0.0)),
            confidence=float(row.get("confidence", 0.0)),
            policy_hint=infer_policy(str(row.get("label", "unknown")), str(row.get("policy_hint", row.get("policy", "uncertain")))),
            source=str(row.get("source", "json")),
        )


def infer_policy(label: str, fallback: str = "uncertain") -> str:
    normalized = normalize_label(label)
    if normalized in PROTECTED_LABELS:
        return "preserve"
    if normalized in SUPPRESSIBLE_LABELS:
        return "suppress"
    return fallback if fallback in {"preserve", "suppress", "uncertain"} else "uncertain"


def normalize_label(label: str) -> str:
    return "_".join(str(label).strip().lower().replace("/", " ").replace("-", " ").split())


def normalize(y: np.ndarray, peak: float = 0.98) -> np.ndarray:
    y = np.asarray(y, dtype=np.float32).reshape(-1)
    m = float(np.max(np.abs(y))) if y.size else 0.0
    if m <= 1e-9:
        return y.astype(np.float32)
    return (y / m * float(peak)).astype(np.float32)


def to_mono(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=np.float32)
    if y.ndim == 1:
        return y
    return y.mean(axis=1).astype(np.float32)


def resample_audio(y: np.ndarray, sr: int, target_sr: int = SR) -> np.ndarray:
    if int(sr) == int(target_sr):
        return y.astype(np.float32)
    g = math.gcd(int(sr), int(target_sr))
    up = int(target_sr) // g
    down = int(sr) // g
    return signal.resample_poly(y, up, down).astype(np.float32)


def load_audio(path: str | Path, sr: int = SR, peak: float | None = None) -> tuple[np.ndarray, int]:
    y, source_sr = sf.read(str(path), always_2d=False)
    y = to_mono(y)
    y = resample_audio(y, int(source_sr), sr)
    if peak is not None:
        y = normalize(y, peak=peak)
    return y.astype(np.float32), sr


def write_audio(path: str | Path, y: np.ndarray, sr: int = SR) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), np.asarray(y, dtype=np.float32), sr)


def fit_audio(y: np.ndarray, n_samples: int) -> np.ndarray:
    y = np.asarray(y, dtype=np.float32).reshape(-1)
    if y.size >= n_samples:
        return y[:n_samples]
    return np.pad(y, (0, n_samples - y.size)).astype(np.float32)


def paste_clip(base: np.ndarray, clip: np.ndarray, sr: int, start_sec: float, gain: float = 1.0) -> np.ndarray:
    out = np.asarray(base, dtype=np.float32).copy()
    start = max(0, int(round(float(start_sec) * sr)))
    if start >= len(out):
        return out
    end = min(len(out), start + len(clip))
    out[start:end] += float(gain) * clip[: end - start]
    return out.astype(np.float32)


def read_events_json(path: str | Path) -> list[Event]:
    data = json.loads(Path(path).read_text())
    if isinstance(data, dict) and "events" in data:
        data = data["events"]
    return [Event.from_dict(row) for row in data]


def write_events_json(path: str | Path, events: Iterable[Event]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps([e.as_dict() for e in events], indent=2))


def dominant_freqs(y: np.ndarray, sr: int = SR, max_count: int = 6) -> list[float]:
    y = np.asarray(y, dtype=np.float32)
    if y.size < 64:
        return []
    nperseg = min(4096, max(256, len(y)))
    freqs, psd = signal.welch(y, fs=sr, nperseg=nperseg)
    band = (freqs >= 40) & (freqs <= 1000)
    if not np.any(band):
        return []
    bf = freqs[band]
    bp = psd[band]
    distance = max(1, int(35 / (bf[1] - bf[0]))) if len(bf) > 1 else 1
    peaks, props = signal.find_peaks(bp, distance=distance, prominence=np.max(bp) * 0.02 if len(bp) else 0.0)
    if len(peaks) == 0:
        idx = np.argsort(bp)[-max_count:]
    else:
        idx = peaks[np.argsort(bp[peaks])[-max_count:]]
    vals = sorted(float(round(bf[i], 1)) for i in idx)
    return vals


def band_energy(y: np.ndarray, sr: int, low_hz: float, high_hz: float) -> float:
    y = np.asarray(y, dtype=np.float32)
    if y.size < 64:
        return 0.0
    freqs, psd = signal.welch(y, fs=sr, nperseg=min(4096, len(y)))
    mask = (freqs >= float(low_hz)) & (freqs <= float(high_hz))
    return float(psd[mask].sum() + 1e-12)


def spectral_features(y: np.ndarray, sr: int = SR) -> dict[str, Any]:
    y = np.asarray(y, dtype=np.float32)
    if y.size == 0:
        return {"duration_sec": 0.0, "rms": 0.0, "peak": 0.0, "dominant_freqs_hz": []}
    freqs, psd = signal.welch(y, fs=sr, nperseg=min(4096, len(y)))
    total = float(psd.sum() + 1e-12)
    low = float(psd[(freqs >= 40) & (freqs <= 300)].sum() / total)
    mid = float(psd[(freqs > 300) & (freqs <= 2000)].sum() / total)
    high = float(psd[freqs > 2000].sum() / total)
    rms = float(np.sqrt(np.mean(y * y) + 1e-12))
    return {
        "duration_sec": round(len(y) / sr, 3),
        "rms": round(rms, 6),
        "peak": round(float(np.max(np.abs(y))), 6),
        "low_band_energy_share_40_300hz": round(low, 4),
        "mid_band_energy_share_300_2000hz": round(mid, 4),
        "high_band_energy_share_2000hz_plus": round(high, 4),
        "dominant_freqs_hz": dominant_freqs(y, sr),
    }


def protected_mask(n_samples: int, sr: int, protected: Iterable[tuple[float, float] | list[float]]) -> np.ndarray:
    mask = np.zeros(int(n_samples), dtype=bool)
    for start, end in protected:
        a = max(0, min(int(n_samples), int(round(float(start) * sr))))
        b = max(0, min(int(n_samples), int(round(float(end) * sr))))
        if b > a:
            mask[a:b] = True
    return mask


def segment_mask(n_samples: int, sr: int, segments: Iterable[tuple[float, float] | list[float]]) -> np.ndarray:
    mask = np.zeros(int(n_samples), dtype=bool)
    for start, end in segments:
        a = max(0, min(int(n_samples), int(round(float(start) * sr))))
        b = max(0, min(int(n_samples), int(round(float(end) * sr))))
        if b > a:
            mask[a:b] = True
    return mask
