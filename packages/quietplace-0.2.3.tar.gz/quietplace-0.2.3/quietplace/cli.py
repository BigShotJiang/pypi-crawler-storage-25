from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import DEFAULT_GOAL, DEFAULT_VLLM_API_KEY, DEFAULT_VLLM_BASE_URL, DEFAULT_VLLM_MODEL
from .demo_scene import create_demo_scene
from .pipeline import run_pipeline
from .viz import save_all_charts


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("quiteplace", description="Notebook-first semantic noise suppression controlled by vLLM/Gemma.")
    sub = p.add_subparsers(dest="cmd", required=True)

    demo = sub.add_parser("make-demo-scene", help="build a realistic mixed demo scene from held-out clips or synthetic fallbacks")
    demo.add_argument("--out", default="data/demo_scene")
    demo.add_argument("--traffic-path", help="held-out FSD50K/DEMAND traffic wav")
    demo.add_argument("--siren-path", help="held-out UrbanSound8K siren wav")
    demo.add_argument("--speech-path", help="consented or held-out speech/help wav")
    demo.add_argument("--duration-sec", type=float, default=14.0)

    run = sub.add_parser("run", help="classify, ask vLLM for a controller plan, suppress, and write metrics")
    run.add_argument("audio")
    run.add_argument("--events-json", help="optional precomputed event table JSON; bypasses classifier")
    run.add_argument("--out", default="runs/quiteplace_demo")
    run.add_argument("--goal", default=DEFAULT_GOAL)
    run.add_argument("--backend", choices=["auto", "vllm", "mock"], default="auto")
    run.add_argument("--vllm-base-url", default=DEFAULT_VLLM_BASE_URL)
    run.add_argument("--vllm-api-key", default=DEFAULT_VLLM_API_KEY)
    run.add_argument("--vllm-model", default=DEFAULT_VLLM_MODEL)
    run.add_argument("--no-classifier", action="store_true", help="do not load the hard-coded AST classifier when no events JSON is supplied")
    run.add_argument("--window-sec", type=float, default=2.0)
    run.add_argument("--hop-sec", type=float, default=1.0)

    charts = sub.add_parser("charts", help="re-run pipeline and save notebook-style charts")
    charts.add_argument("audio")
    charts.add_argument("--events-json")
    charts.add_argument("--out", default="runs/quiteplace_demo")
    charts.add_argument("--charts-out", default="runs/quiteplace_demo/charts")
    charts.add_argument("--backend", choices=["auto", "vllm", "mock"], default="auto")
    charts.add_argument("--vllm-base-url", default=DEFAULT_VLLM_BASE_URL)
    charts.add_argument("--vllm-api-key", default=DEFAULT_VLLM_API_KEY)
    charts.add_argument("--vllm-model", default=DEFAULT_VLLM_MODEL)

    chapters = sub.add_parser("chapters", help="create markdown chapters for the Kaggle writeup/video script from a run directory")
    chapters.add_argument("--run-dir", default="runs/quiteplace_demo")
    chapters.add_argument("--out", default="reports/chapters")

    return p


def create_chapters(run_dir: str | Path, out_dir: str | Path) -> dict[str, str]:
    run = Path(run_dir)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    summary = json.loads((run / "metrics_summary.json").read_text()) if (run / "metrics_summary.json").exists() else {}
    plan = json.loads((run / "controller_policy.json").read_text()) if (run / "controller_policy.json").exists() else {}
    files = {
        "01_problem.md": "# Chapter 1 — The problem\n\nShared shelters, hospital wards, classrooms, and roadside waiting areas can be loud. Blind cancellation is unsafe because sirens, speech, baby cries, and alarms must remain audible.\n",
        "02_architecture.md": "# Chapter 2 — Architecture\n\nquiteplace uses an already-trained AST classifier for event segments, Gemma/Gemma-compatible inference through vLLM for policy and function-call planning, and deterministic DSP for execution.\n\n```json\n" + json.dumps(plan, indent=2) + "\n```\n",
        "03_results.md": "# Chapter 3 — Results\n\nKey demo metrics:\n\n```json\n" + json.dumps(summary, indent=2) + "\n```\n\nUse the generated charts in the notebook or `runs/.../charts` as the media gallery.\n",
        "04_demo_script.md": "# Chapter 4 — Demo script\n\n1. Play original audio.\n2. Show event map: traffic/fan suppressed; siren/speech preserved.\n3. Show the vLLM controller plan.\n4. Play suppressed output.\n5. Point to calm-zone reduction and protected-sound retention.\n",
    }
    written = {}
    for name, text in files.items():
        path = out / name
        path.write_text(text)
        written[name] = str(path)
    return written


def main() -> None:
    args = build_parser().parse_args()
    if args.cmd == "make-demo-scene":
        result = create_demo_scene(args.out, args.traffic_path, args.siren_path, args.speech_path, args.duration_sec)
        print(json.dumps({k: v for k, v in result.items() if k != "event_objects"}, indent=2))
    elif args.cmd == "run":
        result = run_pipeline(
            args.audio,
            args.out,
            events_json=args.events_json,
            user_goal=args.goal,
            backend=args.backend,
            vllm_base_url=args.vllm_base_url,
            vllm_api_key=args.vllm_api_key,
            vllm_model=args.vllm_model,
            use_classifier=not args.no_classifier,
            window_sec=args.window_sec,
            hop_sec=args.hop_sec,
        )
        print(json.dumps({"files": result["files"], "summary_metrics": result["summary_metrics"]}, indent=2))
    elif args.cmd == "charts":
        result = run_pipeline(
            args.audio,
            args.out,
            events_json=args.events_json,
            backend=args.backend,
            vllm_base_url=args.vllm_base_url,
            vllm_api_key=args.vllm_api_key,
            vllm_model=args.vllm_model,
        )
        print(json.dumps(save_all_charts(result, args.charts_out), indent=2))
    elif args.cmd == "chapters":
        print(json.dumps(create_chapters(args.run_dir, args.out), indent=2))


if __name__ == "__main__":
    main()
