from __future__ import annotations

from pathlib import Path

SR = 16_000

# Hard-coded trained classifier pointer requested for the demo.
# Put the exported AST save_pretrained directory here in Kaggle/Colab/local envs.
AST_WEIGHTS_DIR = Path("/kaggle/input/quiteplace-policy-ast/quiteplace_policy_ast")

DEFAULT_GOAL = "sleep in a shared shelter while preserving safety-critical sounds"
DEFAULT_VLLM_BASE_URL = "http://localhost:8000/v1"
DEFAULT_VLLM_API_KEY = "EMPTY"
DEFAULT_VLLM_MODEL = "google/gemma-4-e2b-it"

PROTECTED_LABELS = {
    "siren", "alarm", "fire_alarm", "smoke_alarm", "speech", "human_voice",
    "baby_cry", "crying_baby", "knock", "help_signal", "shout", "emergency_vehicle",
}

SUPPRESSIBLE_LABELS = {
    "traffic_noise", "roadway_noise", "engine_idling", "engine", "fan_hum", "fan",
    "air_conditioner", "drilling", "jackhammer", "generator_hum", "machine_noise",
    "vacuum_cleaner", "rumble", "hvac",
}

