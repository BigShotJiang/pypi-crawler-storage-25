from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .audio import Event, load_audio, read_events_json, spectral_features, write_audio, write_events_json
from .classifier import AudioPolicyClassifier
from .config import AST_WEIGHTS_DIR, DEFAULT_GOAL, DEFAULT_TRANSFORMERS_MODEL, DEFAULT_VLLM_API_KEY, DEFAULT_VLLM_BASE_URL, DEFAULT_VLLM_MODEL
from .controller import get_controller_plan, save_plan
from .dsp import execute_plan
from .metrics import bandpower_metrics, segment_metrics, summary_metrics


def run_pipeline(
    input_audio: str | Path,
    out_dir: str | Path,
    events_json: str | Path | None = None,
    user_goal: str = DEFAULT_GOAL,
    backend: str = "auto",
    vllm_base_url: str = DEFAULT_VLLM_BASE_URL,
    vllm_api_key: str = DEFAULT_VLLM_API_KEY,
    vllm_model: str = DEFAULT_VLLM_MODEL,
    transformers_model: str = DEFAULT_TRANSFORMERS_MODEL,
    classifier_weights_dir: str | Path = AST_WEIGHTS_DIR,
    use_classifier: bool = True,
    window_sec: float = 2.0,
    hop_sec: float = 1.0,
) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    y, sr = load_audio(input_audio)
    features = spectral_features(y, sr)

    if events_json:
        events = read_events_json(events_json)
    elif use_classifier:
        events = AudioPolicyClassifier(classifier_weights_dir).predict_windows(input_audio, window_sec=window_sec, hop_sec=hop_sec)
    else:
        events = [Event("unknown_soundscape", 0.0, features["duration_sec"], 0.2, "uncertain", "fallback")]

    plan = get_controller_plan(
        user_goal,
        events,
        features,
        backend=backend,
        base_url=vllm_base_url,
        api_key=vllm_api_key,
        model=transformers_model if backend == "transformers" else vllm_model,
    )
    y_out = execute_plan(y, sr, plan)

    original_path = out / "original.wav"
    suppressed_path = out / "suppressed.wav"
    events_path = out / "events.json"
    plan_path = out / "controller_policy.json"
    features_path = out / "features.json"
    segment_metrics_path = out / "segment_metrics.csv"
    bandpower_metrics_path = out / "bandpower_metrics.csv"
    summary_path = out / "metrics_summary.json"

    write_audio(original_path, y, sr)
    write_audio(suppressed_path, y_out, sr)
    write_events_json(events_path, events)
    save_plan(plan_path, plan)
    features_path.write_text(json.dumps(features, indent=2))

    seg = segment_metrics(y, y_out, sr, events)
    band = bandpower_metrics(y, y_out, sr)
    summary = summary_metrics(y, y_out, sr, events, plan)
    seg.to_csv(segment_metrics_path, index=False)
    band.to_csv(bandpower_metrics_path, index=False)
    summary_path.write_text(json.dumps(summary, indent=2))

    return {
        "out_dir": str(out),
        "sr": sr,
        "original_audio": y,
        "suppressed_audio_array": y_out,
        "events": events,
        "features": features,
        "plan": plan,
        "segment_metrics": seg,
        "bandpower_metrics": band,
        "summary_metrics": summary,
        "files": {
            "original_audio": str(original_path),
            "suppressed_audio": str(suppressed_path),
            "events": str(events_path),
            "policy": str(plan_path),
            "features": str(features_path),
            "segment_metrics": str(segment_metrics_path),
            "bandpower_metrics": str(bandpower_metrics_path),
            "summary": str(summary_path),
        },
    }

