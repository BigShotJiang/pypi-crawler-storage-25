from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd

from .audio import Event, band_energy, segment_mask


def rms(y: np.ndarray) -> float:
    y = np.asarray(y, dtype=np.float32)
    return float(np.sqrt(np.mean(y * y) + 1e-12)) if y.size else 0.0


def db_ratio(after: float, before: float) -> float:
    return 20.0 * math.log10((after + 1e-12) / (before + 1e-12))


def segment_metrics(y0: np.ndarray, y1: np.ndarray, sr: int, events: list[Event]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for e in events:
        a = max(0, min(len(y0), int(round(e.start * sr))))
        b = max(0, min(len(y0), int(round(e.end * sr))))
        if b <= a:
            continue
        before = rms(y0[a:b])
        after = rms(y1[a:b])
        rows.append(
            {
                "label": e.label,
                "policy_hint": e.policy_hint,
                "start": round(e.start, 3),
                "end": round(e.end, 3),
                "duration": round(e.end - e.start, 3),
                "before_rms": before,
                "after_rms": after,
                "delta_db": db_ratio(after, before),
                "reduction_db": max(0.0, -db_ratio(after, before)),
                "retention_pct": 100.0 * after / (before + 1e-12),
            }
        )
    return pd.DataFrame(rows)


def bandpower_metrics(y0: np.ndarray, y1: np.ndarray, sr: int) -> pd.DataFrame:
    bands = [
        ("rumble_40_120hz", 40, 120),
        ("hum_120_380hz", 120, 380),
        ("voice_safety_300_3000hz", 300, 3000),
        ("air_hiss_3000_7600hz", 3000, min(7600, int(sr / 2 - 1))),
    ]
    rows = []
    for name, lo, hi in bands:
        before = band_energy(y0, sr, lo, hi)
        after = band_energy(y1, sr, lo, hi)
        delta = 10.0 * math.log10((after + 1e-12) / (before + 1e-12))
        rows.append({"band": name, "low_hz": lo, "high_hz": hi, "delta_db": delta, "reduction_db": max(0.0, -delta)})
    return pd.DataFrame(rows)


def summary_metrics(y0: np.ndarray, y1: np.ndarray, sr: int, events: list[Event], plan: dict[str, Any]) -> dict[str, Any]:
    seg = segment_metrics(y0, y1, sr, events)
    band = bandpower_metrics(y0, y1, sr)
    suppress = seg[seg["policy_hint"].eq("suppress")] if not seg.empty else pd.DataFrame()
    preserve = seg[seg["policy_hint"].eq("preserve")] if not seg.empty else pd.DataFrame()

    suppress_segments = plan.get("suppress_segments_sec") or [[e.start, e.end] for e in events if e.policy_hint == "suppress"]
    calm = segment_mask(len(y0), sr, suppress_segments)
    if calm.any():
        calm_before = rms(y0[calm])
        calm_after = rms(y1[calm])
        calm_delta = db_ratio(calm_after, calm_before)
    else:
        calm_delta = db_ratio(rms(y1), rms(y0))

    def mean_or_none(frame: pd.DataFrame, col: str) -> float | None:
        if frame.empty or col not in frame:
            return None
        return round(float(frame[col].mean()), 3)

    protected_retention = mean_or_none(preserve, "retention_pct")
    low_band = band[band["band"].eq("hum_120_380hz")]
    low_reduction = None if low_band.empty else round(float(low_band["reduction_db"].iloc[0]), 3)
    return {
        "duration_sec": round(len(y0) / sr, 3),
        "overall_rms_reduction_db": round(max(0.0, -db_ratio(rms(y1), rms(y0))), 3),
        "calm_zone_noise_reduction_db": round(max(0.0, -calm_delta), 3),
        "mean_suppressible_segment_reduction_db": mean_or_none(suppress, "reduction_db"),
        "protected_audio_retention_pct": None if protected_retention is None else round(protected_retention, 1),
        "hum_band_reduction_db": low_reduction,
        "protected_segments_count": int(len(preserve)) if not preserve.empty else 0,
        "suppressed_segments_count": int(len(suppress)) if not suppress.empty else 0,
        "safety_note": "Protected segments should stay near 100% retention; nuisance/calm zones should show positive dB reduction.",
    }
