from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy import signal

from .audio import Event, fit_audio, load_audio, normalize, paste_clip, write_audio, write_events_json
from .config import SR


def _fade(y: np.ndarray, sr: int, ms: float = 30.0) -> np.ndarray:
    y = np.asarray(y, dtype=np.float32).copy()
    n = min(len(y) // 2, max(1, int(sr * ms / 1000.0)))
    if n > 1:
        ramp = np.linspace(0.0, 1.0, n, dtype=np.float32)
        y[:n] *= ramp
        y[-n:] *= ramp[::-1]
    return y


def synthetic_traffic(duration_sec: float, sr: int = SR, seed: int = 7) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = int(duration_sec * sr)
    noise = rng.standard_normal(n).astype(np.float32)
    sos = signal.butter(4, [40, 1600], btype="bandpass", fs=sr, output="sos")
    traffic = signal.sosfilt(sos, noise).astype(np.float32)
    t = np.arange(n, dtype=np.float32) / sr
    envelope = 0.65 + 0.18 * np.sin(2 * np.pi * 0.12 * t + 0.4) + 0.08 * np.sin(2 * np.pi * 0.31 * t)
    return normalize(traffic * envelope, peak=0.28)


def synthetic_hum(duration_sec: float, sr: int = SR) -> np.ndarray:
    n = int(duration_sec * sr)
    t = np.arange(n, dtype=np.float32) / sr
    return (0.13 * np.sin(2 * np.pi * 120 * t) + 0.07 * np.sin(2 * np.pi * 240 * t + 0.4) + 0.035 * np.sin(2 * np.pi * 360 * t + 1.2)).astype(np.float32)


def synthetic_siren(duration_sec: float = 1.9, sr: int = SR) -> np.ndarray:
    n = int(duration_sec * sr)
    t = np.arange(n, dtype=np.float32) / sr
    sweep = 900 + 420 * np.sin(2 * np.pi * 0.9 * t)
    phase = 2 * np.pi * np.cumsum(sweep) / sr
    siren = 0.45 * np.sin(phase) + 0.18 * np.sin(2 * phase)
    return _fade(normalize(siren, peak=0.65), sr)


def synthetic_speech_like(duration_sec: float = 1.5, sr: int = SR) -> np.ndarray:
    n = int(duration_sec * sr)
    t = np.arange(n, dtype=np.float32) / sr
    carrier = (
        0.18 * np.sin(2 * np.pi * 180 * t)
        + 0.12 * np.sin(2 * np.pi * 360 * t + 0.2)
        + 0.08 * np.sin(2 * np.pi * 720 * t + 0.8)
        + 0.04 * np.sin(2 * np.pi * 1440 * t + 1.5)
    )
    syllables = (np.sin(2 * np.pi * 3.2 * t) > -0.25).astype(np.float32)
    formant = signal.sosfilt(signal.butter(3, [250, 2800], btype="bandpass", fs=sr, output="sos"), carrier)
    return _fade(normalize(formant * (0.25 + 0.75 * syllables), peak=0.5), sr)


def load_or_synthetic(path: str | Path | None, kind: str, duration_sec: float, sr: int = SR) -> tuple[np.ndarray, str]:
    if path:
        y, _ = load_audio(path, sr=sr, peak=0.75)
        return fit_audio(y, int(duration_sec * sr)), str(path)
    if kind == "traffic":
        return synthetic_traffic(duration_sec, sr), "synthetic_traffic_fallback"
    if kind == "siren":
        return fit_audio(synthetic_siren(duration_sec, sr), int(duration_sec * sr)), "synthetic_siren_fallback"
    if kind == "speech":
        return fit_audio(synthetic_speech_like(duration_sec, sr), int(duration_sec * sr)), "synthetic_speech_like_fallback"
    raise ValueError(kind)


def create_demo_scene(
    out_dir: str | Path,
    traffic_path: str | Path | None = None,
    siren_path: str | Path | None = None,
    speech_path: str | Path | None = None,
    duration_sec: float = 14.0,
    sr: int = SR,
) -> dict:
    """Create a reproducible A/B demo scene.

    For the realistic competition version, pass held-out dataset clips:
    - traffic_path: FSD50K traffic/roadway or DEMAND traffic background
    - siren_path: UrbanSound8K siren sample from a held-out fold
    - speech_path: your own consented recording or a held-out speech/help sample

    The synthetic fallback is included so the notebook runs without bundling large
    or license-sensitive audio files.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    n = int(duration_sec * sr)

    traffic, traffic_source = load_or_synthetic(traffic_path, "traffic", duration_sec, sr)
    scene = fit_audio(traffic, n)
    scene += synthetic_hum(duration_sec, sr)

    siren, siren_source = load_or_synthetic(siren_path, "siren", 1.9, sr)
    speech, speech_source = load_or_synthetic(speech_path, "speech", 1.5, sr)
    scene = paste_clip(scene, siren, sr, start_sec=6.2, gain=0.9)
    scene = paste_clip(scene, speech, sr, start_sec=10.5, gain=0.8)
    scene = normalize(scene, peak=0.98)

    events = [
        Event("traffic_noise", 0.0, duration_sec, 0.93, "suppress", traffic_source),
        Event("fan_hum", 0.0, duration_sec, 0.88, "suppress", "synthetic_120_240_360hz_hum"),
        Event("siren", 6.2, 8.1, 0.92, "preserve", siren_source),
        Event("speech", 10.5, 12.0, 0.82, "preserve", speech_source),
    ]
    audio_path = out / "quiteplace_realistic_demo_scene.wav"
    events_path = out / "events_demo.json"
    manifest_path = out / "scene_manifest.json"
    write_audio(audio_path, scene, sr)
    write_events_json(events_path, events)
    manifest = {
        "audio": str(audio_path),
        "events": str(events_path),
        "sample_rate": sr,
        "duration_sec": duration_sec,
        "sources": {
            "traffic": traffic_source,
            "hum": "synthetic_120_240_360hz",
            "siren": siren_source,
            "speech": speech_source,
        },
        "dataset_guidance": "Use held-out clips from FSD50K/DEMAND for traffic, UrbanSound8K for siren, and consented or held-out speech. Do not benchmark on clips that trained the AST classifier.",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2))
    return {"audio": str(audio_path), "events": str(events_path), "manifest": str(manifest_path), "event_objects": events}
