# Maude - Autonomous Agent Framework
# Copyright (c) 2026 John Broadway
# Licensed under the Apache License, Version 2.0

"""Tests for BriefingGenerator — template-based cross-room summaries."""

from unittest.mock import AsyncMock

import pytest

from maude.coordination.briefing import BriefingGenerator
from maude.coordination.cross_room_memory import CrossRoomMemory
from maude.healing.dependencies import DependencyGraph


@pytest.fixture
def mock_memory() -> AsyncMock:
    memory = AsyncMock(spec=CrossRoomMemory)
    memory.all_rooms_summary = AsyncMock(return_value=[])
    memory.recent_incidents = AsyncMock(return_value=[])
    memory.recent_escalations = AsyncMock(return_value=[])
    memory.recent_restarts = AsyncMock(return_value=[])
    memory.recent_remediations = AsyncMock(return_value=[])
    return memory


@pytest.fixture
def deps(tmp_path) -> DependencyGraph:
    yaml_file = tmp_path / "deps.yaml"
    yaml_file.write_text(
        "rooms:\n"
        "  site-a:\n"
        "    postgresql:\n"
        "      depends_on: []\n"
        "      repo: infrastructure/postgresql\n"
        "    my-service:\n"
        "      depends_on: [postgresql]\n"
        "      repo: infrastructure/my-service\n"
        "    monitoring:\n"
        "      depends_on: [postgresql]\n"
        "      repo: infrastructure/monitoring\n"
        "    panel:\n"
        "      depends_on: [postgresql, my-service]\n"
        "      repo: industrial/panel\n"
    )
    return DependencyGraph(yaml_path=yaml_file)


@pytest.fixture
def briefing(mock_memory: AsyncMock, deps: DependencyGraph) -> BriefingGenerator:
    return BriefingGenerator(memory=mock_memory, deps=deps)


# ── Empty hotel ───────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_empty_briefing(briefing: BriefingGenerator):
    """No activity should produce a clean briefing."""
    output = await briefing.generate()
    assert "Maude Briefing" in output
    assert "UNHEALTHY ROOMS: none" in output
    assert "INCIDENTS:" in output
    assert "ESCALATIONS:" in output
    assert "none" in output


# ── Healthy rooms ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_healthy_rooms_listed(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "postgresql",
            "total_runs": 5,
            "resolved": 2,
            "failed": 0,
            "escalated": 0,
            "no_action": 3,
            "last_activity": "2026-02-01T10:00:00",
        },
        {
            "project": "my-service",
            "total_runs": 3,
            "resolved": 1,
            "failed": 0,
            "escalated": 0,
            "no_action": 2,
            "last_activity": "2026-02-01T10:05:00",
        },
    ]
    output = await briefing.generate()
    assert "ALL CLEAR:" in output
    assert "postgresql" in output
    assert "my-service" in output


# ── Unhealthy rooms ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_unhealthy_rooms_highlighted(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "my-service",
            "total_runs": 5,
            "resolved": 1,
            "failed": 2,
            "escalated": 0,
            "no_action": 2,
            "last_activity": "2026-02-01T10:00:00",
        },
    ]
    output = await briefing.generate()
    assert "UNHEALTHY ROOMS:" in output
    assert "my-service" in output
    assert "2 failed" in output


# ── Incidents in output ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_incidents_displayed(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.recent_incidents.return_value = [
        {
            "project": "monitoring",
            "summary": "Datasource connection refused",
            "outcome": "resolved",
            "created_at": "2026-02-01T14:30:00+00:00",
        },
    ]
    output = await briefing.generate()
    assert "monitoring" in output
    assert "Datasource connection refused" in output


# ── Scoped to single room ────────────────────────────────────────


@pytest.mark.asyncio
async def test_scoped_to_single_room(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "my-service",
            "total_runs": 3,
            "resolved": 1,
            "failed": 0,
            "escalated": 0,
            "no_action": 2,
        },
        {
            "project": "monitoring",
            "total_runs": 2,
            "resolved": 1,
            "failed": 1,
            "escalated": 0,
            "no_action": 0,
        },
    ]
    output = await briefing.generate(scope="room:my-service")
    # Only my-service should appear in room-scoped output
    assert "DEPENDENCIES FOR my-service" in output


# ── Dependencies at risk ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_dependencies_at_risk(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "postgresql",
            "total_runs": 5,
            "resolved": 0,
            "failed": 3,
            "escalated": 0,
            "no_action": 2,
        },
    ]
    output = await briefing.generate()
    assert "DEPENDENCIES AT RISK:" in output
    assert "postgresql" in output
    # postgresql affects my-service, monitoring, panel
    assert "my-service" in output


# ── Room status grid ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_room_status_grid(briefing: BriefingGenerator, mock_memory: AsyncMock):
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "postgresql",
            "total_runs": 5,
            "resolved": 2,
            "failed": 0,
            "escalated": 0,
            "no_action": 3,
        },
    ]
    output = await briefing.room_status()
    assert "ROOM STATUS GRID" in output
    assert "postgresql" in output
    assert "ok" in output


# ── _format_time ──────────────────────────────────────────────────


def test_format_time_iso_string():
    result = BriefingGenerator._format_time("2026-02-01T14:30:00+00:00")
    assert result == "14:30"


def test_format_time_empty():
    result = BriefingGenerator._format_time("")
    assert result == "??:??"


def test_format_time_none():
    result = BriefingGenerator._format_time(None)
    assert result == "??:??"


# ── Custom minutes window ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_custom_minutes(briefing: BriefingGenerator, mock_memory: AsyncMock):
    await briefing.generate(minutes=480)
    assert "480" in str(mock_memory.all_rooms_summary.call_args)


# ── Unhealthy rooms with escalations and restarts (lines 77, 80) ──


@pytest.mark.asyncio
async def test_unhealthy_room_with_escalations_and_restarts(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """Unhealthy room showing escalated count and restart count."""
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "my-service",
            "total_runs": 5,
            "resolved": 0,
            "failed": 1,
            "escalated": 2,
            "no_action": 2,
        },
    ]
    mock_memory.recent_restarts.return_value = [
        {"project": "my-service", "tool": "service_restart", "created_at": "2026-02-01T10:00:00"},
        {"project": "my-service", "tool": "service_restart", "created_at": "2026-02-01T10:05:00"},
    ]
    output = await briefing.generate()
    assert "2 escalated" in output
    assert "2 restart(s)" in output
    assert "1 failed" in output


# ── Escalation formatting (lines 118-122) ────────────────────────


@pytest.mark.asyncio
async def test_escalations_displayed(briefing: BriefingGenerator, mock_memory: AsyncMock):
    """Escalations should be formatted with timestamp and room name."""
    mock_memory.recent_escalations.return_value = [
        {
            "project": "monitoring",
            "summary": "Datasource timeout after 3 retries",
            "created_at": "2026-02-01T15:45:00+00:00",
        },
    ]
    output = await briefing.generate()
    assert "monitoring" in output
    assert "Datasource timeout" in output
    assert "15:45" in output


# ── Dependency for target_room (line 138) ─────────────────────────


@pytest.mark.asyncio
async def test_scoped_room_no_dependencies(mock_memory: AsyncMock):
    """A room with no dependencies should say 'No dependencies'."""
    # Use a DependencyGraph with no deps for the target room
    deps = DependencyGraph()
    briefing = BriefingGenerator(memory=mock_memory, deps=deps)
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "ollama",
            "total_runs": 1,
            "resolved": 1,
            "failed": 0,
            "escalated": 0,
            "no_action": 0,
        },
    ]
    output = await briefing.generate(scope="room:ollama")
    assert "No dependencies" in output


# ── affected_by with no downstream deps (line 149) ───────────────


@pytest.mark.asyncio
async def test_unhealthy_room_no_downstream_deps(mock_memory: AsyncMock):
    """Unhealthy room with no downstream dependencies."""
    deps = DependencyGraph()
    briefing = BriefingGenerator(memory=mock_memory, deps=deps)
    # hmi has no depended_by in default graph
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "hmi",
            "total_runs": 3,
            "resolved": 0,
            "failed": 2,
            "escalated": 0,
            "no_action": 1,
        },
    ]
    output = await briefing.generate()
    assert "hmi" in output
    assert "no downstream dependencies" in output


# ── room_status ATTENTION line (line 166) ─────────────────────────


@pytest.mark.asyncio
async def test_room_status_attention(briefing: BriefingGenerator, mock_memory: AsyncMock):
    """Rooms with failures should show ATTENTION in status grid."""
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "my-service",
            "total_runs": 5,
            "resolved": 1,
            "failed": 2,
            "escalated": 1,
            "no_action": 1,
        },
    ]
    output = await briefing.room_status()
    assert "ATTENTION" in output
    assert "failed=2" in output
    assert "escalated=1" in output


# ── _format_time with bad string (lines 186-187) ─────────────────


def test_format_time_bad_string():
    """Non-ISO string should return first 5 chars."""
    result = BriefingGenerator._format_time("not-a-date-at-all")
    assert result == "not-a"


# ── _format_time with datetime object (line 189) ─────────────────


def test_format_time_datetime_object():
    """datetime object should format as HH:MM."""
    from datetime import datetime

    dt = datetime(2026, 2, 1, 14, 30, 0)
    result = BriefingGenerator._format_time(dt)
    assert result == "14:30"


# ── Autonomous fixes section ─────────────────────────────────────


@pytest.mark.asyncio
async def test_briefing_autonomous_fixes_section(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """AUTONOMOUS FIXES section appears in briefing."""
    mock_memory.recent_remediations.return_value = [
        {
            "project": "prometheus",
            "summary": "Restarted prometheus, health check passed",
            "created_at": "2026-02-01T16:00:00+00:00",
        },
    ]
    output = await briefing.generate()
    assert "AUTONOMOUS FIXES:" in output
    assert "prometheus" in output
    assert "Restarted prometheus" in output
    assert "16:00" in output


@pytest.mark.asyncio
async def test_briefing_autonomous_fixes_empty(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """AUTONOMOUS FIXES section shows 'none' when no remediations."""
    output = await briefing.generate()
    assert "AUTONOMOUS FIXES:" in output
    # The "none" under AUTONOMOUS FIXES
    lines = output.split("\n")
    fixes_idx = next(i for i, line in enumerate(lines) if "AUTONOMOUS FIXES:" in line)
    assert "none" in lines[fixes_idx + 1]


@pytest.mark.asyncio
async def test_briefing_section_order(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """Sections appear in correct order: INCIDENTS → AUTONOMOUS FIXES → ESCALATIONS."""
    output = await briefing.generate()
    incidents_pos = output.index("INCIDENTS:")
    fixes_pos = output.index("AUTONOMOUS FIXES:")
    escalations_pos = output.index("ESCALATIONS:")
    assert incidents_pos < fixes_pos < escalations_pos


@pytest.mark.asyncio
async def test_briefing_remediations_scoped_to_room(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """Room-scoped briefing filters remediations."""
    mock_memory.recent_remediations.return_value = [
        {
            "project": "prometheus",
            "summary": "Fixed prometheus",
            "created_at": "2026-02-01T16:00:00",
        },
        {
            "project": "monitoring",
            "summary": "Fixed monitoring",
            "created_at": "2026-02-01T16:05:00",
        },
    ]
    output = await briefing.generate(scope="room:prometheus")
    assert "Fixed prometheus" in output
    assert "Fixed monitoring" not in output


# ── Room status grid with remediated count ───────────────────────


@pytest.mark.asyncio
async def test_room_status_shows_remediated_count(
    briefing: BriefingGenerator,
    mock_memory: AsyncMock,
):
    """Room status grid includes remediated count when > 0."""
    mock_memory.all_rooms_summary.return_value = [
        {
            "project": "site-a/postgresql",
            "total_runs": 10,
            "resolved": 3,
            "failed": 0,
            "escalated": 0,
            "no_action": 5,
            "remediated": 2,
        },
    ]
    output = await briefing.room_status()
    assert "remediated=2" in output
