# Maude - Autonomous Agent Framework
# Copyright (c) 2026 John Broadway
# Licensed under the Apache License, Version 2.0

"""Shared test fixtures for Room Agent component tests."""

from unittest.mock import AsyncMock, MagicMock

import pytest


def pytest_collection_modifyitems(config, items):
    """Auto-mark tests in tests/integration/ as integration tests."""
    for item in items:
        if "/integration/" in str(item.fspath):
            item.add_marker(pytest.mark.integration)


@pytest.fixture(autouse=True)
def _global_rate_limit_reset(monkeypatch):
    """Give every test a fresh rate limit state via monkeypatch."""
    import maude.daemon.guards as guards

    monkeypatch.setattr(guards, "_rate_limit_state", {})
    monkeypatch.setattr(guards, "_rate_limit_locks", {})
    monkeypatch.setattr(guards, "_redis_client", None)


@pytest.fixture
def mock_audit() -> AsyncMock:
    """Mock AuditLogger that records calls."""
    audit = AsyncMock()
    audit.log_tool_call = AsyncMock()
    return audit


@pytest.fixture
def mock_executor() -> AsyncMock:
    """Mock SSH executor that returns configurable results."""
    executor = AsyncMock()

    result = MagicMock()
    result.stdout = "active\n"
    result.ok = True
    executor.run = AsyncMock(return_value=result)

    return executor
