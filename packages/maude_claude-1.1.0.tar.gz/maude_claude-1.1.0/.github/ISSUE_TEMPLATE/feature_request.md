<!-- Version: 1.0 -->
<!-- Created: 2026-03-28 MST -->
<!-- Authors: John Broadway, Claude (Anthropic) -->
---
name: Feature Request
about: What do you need? The Sommelier will recommend the right tool.
title: "[Feature] "
labels: enhancement
assignees: ''
---

## What problem does this solve?

Describe the problem or need. What are you trying to accomplish?

## Proposed solution

How do you think it should work?

## Alternatives considered

What else did you consider? Why didn't it work?

## Which module does this affect?

- [ ] Charon (Room daemon toolkit)
- [ ] Winston (Governance)
- [ ] Bowery King (Memory)
- [ ] The Doctor (Self-healing)
- [ ] Front Desk (Coordination)
- [ ] Maude (Configuration)
- [ ] Other / New module

## Additional context

Anything else. Diagrams, examples, references.

---
*"What do you need?"* — The Sommelier
