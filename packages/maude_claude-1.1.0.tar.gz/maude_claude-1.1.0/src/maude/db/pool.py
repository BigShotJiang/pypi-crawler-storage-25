# Maude - Autonomous Agent Framework
# Copyright (c) 2026 John Broadway
# Licensed under the Apache License, Version 2.0

# Maude DB — Lazy Connection Pool
#          Claude (Anthropic) <noreply@anthropic.com>
"""Lazy-initialized asyncpg connection pool.

Replaces the duplicated ``_ensure_pool()`` pattern across 9 modules.
Two modes: strict (propagates errors) and lenient (returns None).
"""

import asyncio
import logging
import time

try:
    import asyncpg
except ImportError:
    asyncpg = None  # type: ignore[assignment]

from maude.daemon.common import pg_pool_kwargs

logger = logging.getLogger(__name__)


class LazyPool:
    """Lazy-initialized asyncpg connection pool.

    Args:
        database: PostgreSQL database name.
        db_host: Override host. Empty resolves via ``resolve_db_host()``.
        min_size: Minimum pool connections.
        max_size: Maximum pool connections.
        suppress_errors: If True, log and return None on connection failure.
            If False, propagate the exception (strict mode).
        retry_cooldown: Seconds to wait after a failed connection before
            retrying. Prevents hammering a down PG every health loop cycle.
    """

    def __init__(
        self,
        database: str = "agent",
        db_host: str = "",
        min_size: int = 1,
        max_size: int = 3,
        *,
        suppress_errors: bool = True,
        retry_cooldown: float = 30.0,
    ) -> None:
        self._database = database
        self._db_host = db_host
        self._min_size = min_size
        self._max_size = max_size
        self._suppress_errors = suppress_errors
        self._retry_cooldown = retry_cooldown
        self._last_failure: float = 0.0
        self._pool: "asyncpg.Pool | None" = None
        self._lock = asyncio.Lock()

    async def get(self) -> "asyncpg.Pool | None":
        """Get the connection pool, creating it lazily.

        Returns:
            The pool, or None if ``suppress_errors`` is True and creation failed.

        Raises:
            Exception: If ``suppress_errors`` is False and pool creation fails.
        """
        if asyncpg is None:
            raise ImportError(
                "asyncpg is required for PostgreSQL connections. "
                "Install with: pip install the-maude[memory]"
            )
        if self._pool is not None:
            return self._pool
        async with self._lock:
            # Double-check after acquiring lock
            if self._pool is not None:
                return self._pool
            elapsed = time.monotonic() - self._last_failure
            if self._last_failure and elapsed < self._retry_cooldown:
                return None
            try:
                kwargs = pg_pool_kwargs(
                    db_host=self._db_host,
                    database=self._database,
                    min_size=self._min_size,
                    max_size=self._max_size,
                )
                self._pool = await asyncpg.create_pool(**kwargs)
                self._last_failure = 0.0
                return self._pool
            except Exception:
                self._last_failure = time.monotonic()
                if not self._suppress_errors:
                    raise
                logger.warning(
                    "LazyPool(%s): PostgreSQL unavailable",
                    self._database,
                    exc_info=True,
                )
                return None

    async def close(self) -> None:
        """Close the connection pool."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
