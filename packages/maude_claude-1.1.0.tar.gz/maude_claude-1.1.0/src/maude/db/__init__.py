# Maude - Autonomous Agent Framework
# Copyright (c) 2026 John Broadway
# Licensed under the Apache License, Version 2.0

# Maude DB — Shared Database Patterns
#          Claude (Anthropic) <noreply@anthropic.com>
"""Shared database utilities: lazy pool management and JSON formatting."""

from maude.db.formatting import format_json

try:
    from maude.db.pool import LazyPool
except ImportError:
    LazyPool = None  # type: ignore[assignment,misc]

__all__ = ["LazyPool", "format_json"]
