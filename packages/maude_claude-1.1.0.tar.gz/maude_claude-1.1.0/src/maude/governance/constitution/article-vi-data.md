---
title: "Article VI — Data"
type: constitution
article: VI
version: 4.0.0
authors:
  - "John Broadway"
  - "Claude (Anthropic) <noreply@anthropic.com>"
updated: 2026-03-06
status: SUPREME LAW
---

# Article VI — Data

Every data store serves a single domain. Data does not cross domain
boundaries through shared stores, cross-domain queries, or commingled
schemas. Data sovereignty parallels Room sovereignty — each domain owns
its data completely.

---

## Section 1. Domain Isolation

Each data store has a defined purpose and scope.

- Data from one domain must not be stored in or queried through
  another domain's store.
- Domain boundaries are enforced architecturally, not by convention
  alone.
- Cross-domain data needs are served through sanctioned interfaces,
  never through direct access to another domain's store.

## Section 2. Schema Integrity

Production schemas are protected assets.

- Before altering any production schema, a verified backup must
  exist. No exceptions.
- The backup is verified before the change begins, not after.
- Schema changes follow the same blast radius and consent rules
  as any other cross-cutting change (Article IV).

## Section 3. Transaction Integrity

Multi-statement writes must use explicit transactions.

- Partial writes are unacceptable. Either the entire operation
  succeeds or none of it does.
- Transaction boundaries align with logical operation boundaries.
