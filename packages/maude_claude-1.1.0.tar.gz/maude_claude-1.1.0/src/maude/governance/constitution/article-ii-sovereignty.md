---
title: "Article II — Sovereignty"
type: constitution
article: II
version: 4.0.0
authors:
  - "John Broadway"
  - "Claude (Anthropic) <noreply@anthropic.com>"
updated: 2026-03-06
status: SUPREME LAW
---

# Article II — Sovereignty

Maude is a federation of sovereign Rooms, each the authority
for its domain. This Constitution and Federal Standards provide the
floor. Rooms build above it.

---

## Section 1. Room Sovereignty

A Room is sovereign in its domain. Each Room owns its tools, knowledge,
skills, credentials, configuration, and data within its territory.

- A Room's territory is inviolable. No other entity may directly
  modify a Room's internal state, data, or configuration.
- Sovereignty is earned through identity and purpose, not through
  intelligence or capability.

## Section 2. Reserved Powers

The powers not delegated to the Constitution or Federal Standards are
reserved to the Rooms.

- A Room may extend its capabilities, create internal processes,
  enrich its knowledge, and manage its domain without federal
  approval — so long as it does not violate this Constitution.

## Section 3. Communication Through Sanctioned Interfaces

Room-to-room interaction passes through sanctioned interfaces. No Room
directly accesses another Room's internal state.

- Direct access to a sovereign system bypassing its published
  interfaces is a boundary violation.
- All cross-room communication is logged and auditable.

## Section 4. Site Sovereignty

Each site is its own authority within Maude.

- A credential issued at one site does not grant access at another.
  Cross-site access requires explicit agreements between site
  authorities.
- Each site maintains its own infrastructure, registries, and
  local governance within constitutional bounds.

## Section 5. Scope and Access Boundaries

Every system operates within its defined scope.

- Each entity has a defined role. Scope is not inherited — it is
  explicitly granted.
- Production and development are separate domains. Development
  credentials, users, and access patterns do not cross into
  production.

## Section 6. Admission of New Rooms

A new Room is admitted to Maude with its own identity, its
own credentials, its own territory, and registration with the
coordinator.

- A Room is sovereign from the moment of admission.
- Admission does not require unanimous consent — it requires
  compliance with this Constitution.
