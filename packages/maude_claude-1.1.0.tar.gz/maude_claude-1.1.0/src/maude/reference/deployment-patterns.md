# Multi-Site Deployment Patterns

Extracted from completed plans (2026-02-20 sweep). Referenced from MEMORY.md.

## SSCNN Numbering Standard

`SS × 100 + C × 10 + NN` where:
- **SS** = Site code (10=SLC, 20=PA, 30=AIM, 40=SBM, 50=DO)
- **C** = Category (0=infra, 1=data, 2=observability, 3=apps, 4=OT, 5=security, 6=network, 9=maude)
- **NN** = Instance (01-99)

Example: PA PostgreSQL = 2010, PA Redis = 2011, PA Grafana = 2020, PA Assay = 2040.

## Full Site Package (Minimum per Location)

9 core LXCs: PostgreSQL, Redis, Grafana, Prometheus, Loki, Uptime Kuma, Gitea, Maude, Authentik
3 OT LXCs: Chronicle (collector), Panel (HMI), Assay (lab MES)
= 12 minimum. Additional: InfluxDB, Qdrant, Forge (as needed).

## PA-First Deployment Strategy

1. PA goes live FIRST as safety net
2. PA runs independently (WAN-down = ops continue)
3. Only THEN apply SLC Maude rename
4. Validates multi-site code before touching production SLC

## Deploy-Fleet Multi-Site

- `deploy-fleet.sh --site site-b` for per-site deploys
- `dependencies.yaml` has `site:` field per room
- `DependencyGraph.site_rooms()` + `DependencyGraph.sites()` methods in maude

## WAN-Down Degradation

| Service | Behavior When WAN Down |
|---------|----------------------|
| PLC/SCADA | Unaffected (local) |
| HMI | Unaffected (local) |
| Assay | Unaffected (local) |
| Room Agents | Health-loop-only (no LLM) |
| Gitea | Read from local push mirror |
| DNS | Local Technitium serves cached |
| Monitoring | Local Prometheus/Grafana |
| Cross-site queries | Unavailable |

## PA Deployment Lessons (2026-02-23)

**VPN connection throttling:** SSH from JW to PA LXCs over Site Magic VPN gets throttled after 4-5 parallel connections. TCP state exhaustion at the WireGuard level. Fix: use ONE PA LXC as a jump host (mux connection), stage artifacts there, distribute via local PA network.

**Jump host pattern:** `ssh -o ControlMaster=yes -o ControlPath=/tmp/ssh-mux/host -o ControlPersist=600 -fN target` → single TCP tunnel, unlimited multiplexed commands. Then `scp -o ControlPath=...` for file transfer. Stage JW key temporarily for local distribution, clean up after.

**Pre-start checklist (MANDATORY before `systemctl start maude@*`):**
1. ReadWritePaths dirs exist: `/app/{project}/.maude`, `/app/{project}/knowledge`, `/var/lib/maude-agents/{project}` — status 226/NAMESPACE if missing
2. `maude.env` has correct `MAUDE_MODULE` — check `src/{module}/server.py` path, NOT project name
3. `config-local.yaml` exists at `/app/{project}/config-local.yaml` with correct site IPs
4. `pyproject.toml` + `README.md` at `/app/maude/` — pip install fails without README.md (hatchling)
5. Aurum subprojects (chronicle, panel, forge) have `mcp/` subdirectories with `src/{module}/` layout — need separate pip install

**MAUDE_MODULE naming:** Almost always `{project}_mcp.server`. Exceptions:
- `uptimekuma_mcp.server` (no underscore between uptime/kuma)
- `maude.front_desk.mcp` (Maude)
- Aurum: `chronicle_mcp.server`, `hmi_mcp.server`, `forge_mcp.server` (in `mcp/` subdir)

**Config-local.yaml site overrides:** CTID (20xx), IP (10.0.1.x), events.db_host (PA PostgreSQL), heartbeat_url (PA Uptime Kuma). Room agents disabled initially, enable after validation.

## Gitea One-Way Model

SLC is source of truth. Sites have read-only push mirrors for emergency manual deploys. No bidirectional sync.

## DNS-Network Coupling (Critical Blocker)

SLC re-addressing touches 200-300 code refs across 50 files (secrets.yaml, sites.py, Grafana datasources, Gitea remotes, DNS records). CANNOT proceed without DNS fully operational. Dependency chain:
1. DNS SLC disk cleanup + drift fix (zesty-singing-lightning Phase 1)
2. DNS PA deployment (Phase 2)
3. PA network standardization (async-seeking-dongarra)
4. SLC re-addressing (cheerful-percolating-hopper Phase 5)

## VLAN Elimination Pattern (from SBM/DO)

When removing a VLAN from a site:
1. GET full `port_overrides` array from switch
2. Replace only the target port entry (preserve all others)
3. PUT back complete array
4. If device has static IP (not DHCP), it goes offline — revert immediately, flag for on-site
5. Verify connectivity after each device move
