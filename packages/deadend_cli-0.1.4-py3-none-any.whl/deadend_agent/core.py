# Copyright (C) 2025 Yassine Bargach
# Licensed under the GNU Affero General Public License v3
# See LICENSE file for full license information.

"""Core initialization and setup functions for the security research framework.

This module provides core initialization functions for setting up configuration,
database connections, sandbox environments, and model registries required
for the security research framework to operate.
"""

from pathlib import Path
import hashlib
import platform
import subprocess
import requests
from deadend_agent.config.settings import Config
from deadend_agent.models.registry import ModelRegistry
from deadend_agent.sandbox.sandbox_manager import SandboxManager
from deadend_agent.rag.session_manager import RagSessionManager


# Platform-specific sandbox binary configurations
SANDBOX_CONFIGS = {
    "Linux": {
        "name": "python-sandbox-tool-linux",
        "url": "https://github.com/xoxruns/simple-python-interpreter-sandbox/releases/download/v0.0.3/python-sandbox-tool-linux",
        "sha256": "74b8a80709a912028600f39b9953889c011278a80acf066af5bd6979366455f4",
    },
    "Darwin": {
        "name": "python-sandbox-tool-macos",
        "url": "https://github.com/xoxruns/simple-python-interpreter-sandbox/releases/download/v0.0.3/python-sandbox-tool-macos",
        "sha256": "9dc49652b1314978544e3e56eef67610d10a2fbb51ecaf06bc10f9c27ad75d7c",
    },
}


def get_sandbox_config():
    """Get the sandbox configuration for the current platform."""
    system = platform.system()
    if system not in SANDBOX_CONFIGS:
        raise RuntimeError(
            f"Unsupported platform: {system}. Supported platforms: {', '.join(SANDBOX_CONFIGS.keys())}"
        )
    return SANDBOX_CONFIGS[system]

def config_setup() -> Config:
    """Setup config"""
    config = Config()
    config.configure()
    # Populates the providers from the config.toml
    config.populate_providers()
    return config

def init_rag_session_manager(
    storage_root: str | Path | None = None,
) -> RagSessionManager:
    """Create a ``RagSessionManager`` backed by SQLite files.

    Args:
        storage_root: Root directory for agent session databases.
            Defaults to ``~/.cache/deadend/agents``.
    """
    root = Path(storage_root) if storage_root else Path.home() / ".cache" / "deadend" / "agents"
    root.mkdir(parents=True, exist_ok=True)
    return RagSessionManager(storage_root=root)

def sandbox_setup() -> SandboxManager:
    """Setup Sandbox manager"""
    # Sandbox Manager
    sandbox_manager = SandboxManager()
    return sandbox_manager

def setup_model_registry(config: Config) -> ModelRegistry:
    """Setup Model registry"""
    model_registry = ModelRegistry(config=config)
    return model_registry

def _file_matches_sha256(path: Path, expected_hash: str) -> bool:
    """Return True if the file exists and matches the expected SHA-256 hash."""
    if not path.exists():
        return False

    digest = hashlib.sha256()
    with open(path, "rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest() == expected_hash


def download_python_sandbox(
    destination_dir: Path | None = None,
) -> Path:
    """Download the Python sandbox binary to the local cache if missing or outdated.

    Args:
        destination_dir: Optional directory to store the sandbox binary. Defaults
            to ~/.cache/deadend/python/.

    Returns:
        Path to the downloaded (or existing) sandbox binary.
    """
    config = get_sandbox_config()
    cache_dir = destination_dir or Path.home() / ".cache" / "deadend" / "python"
    cache_dir.mkdir(parents=True, exist_ok=True)
    sandbox_path = cache_dir / config["name"]

    if _file_matches_sha256(sandbox_path, config["sha256"]):
        return sandbox_path

    if sandbox_path.exists():
        sandbox_path.unlink()

    response = requests.get(config["url"], stream=True, timeout=120)
    response.raise_for_status()
    with open(sandbox_path, "wb") as fd:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                fd.write(chunk)

    if not _file_matches_sha256(sandbox_path, config["sha256"]):
        sandbox_path.unlink(missing_ok=True)
        raise RuntimeError(
            "Downloaded Python sandbox binary failed checksum verification."
        )

    sandbox_path.chmod(0o744)
    return sandbox_path


def start_python_sandbox(
    cache_dir: Path | None = None,
) -> subprocess.Popen[bytes]:
    """Ensure the sandbox binary exists and start it in the background.

    Args:
        cache_dir: Optional override for the sandbox cache directory.

    Returns:
        subprocess.Popen: Handle to the running sandbox process.
    """
    cache_dir = cache_dir or Path.home() / ".cache" / "deadend" / "python"
    sandbox_path = download_python_sandbox(destination_dir=cache_dir)
    process = subprocess.Popen(
        [str(sandbox_path)],
        cwd=str(cache_dir),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return process

def stop_python_sandbox(
    process: subprocess.Popen[bytes],
    timeout: float = 5.0,
) -> None:
    """Stop the Python sandbox process gracefully, then forcefully if needed.
    
    Args:
        process: The subprocess handle to stop.
        timeout: Seconds to wait for graceful termination before killing.
                 Defaults to 5.0 seconds.
    
    The function:
    1. Checks if process is still running (poll() is None)
    2. Sends SIGTERM for graceful shutdown
    3. Waits up to `timeout` seconds for process to exit
    4. If still running, sends SIGKILL and waits for completion
    """
    if process.poll() is not None:
        # Process already dead
        return
    
    try:
        process.terminate()
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Process didn't terminate gracefully, force kill
            process.kill()
            process.wait()  # Wait for kill to complete
    except (ProcessLookupError, ValueError):
        # Process already dead or invalid handle
        pass
