from __future__ import annotations

import os
from collections.abc import Mapping, MutableMapping
from typing import Any

from openai import AsyncOpenAI as _AsyncOpenAI
from openai import OpenAI as _OpenAI

DEFAULT_GATEWAY_BASE_URL = "https://llm-gateway.internal.evalops.dev/v1"

ProviderRef = dict[str, str]


def _first_value(*values: str | None) -> str | None:
    return next((value for value in values if value and value.strip()), None)


def build_evalops_headers(
    *,
    organization_id: str | None = None,
    principal: str | None = None,
    trace_id: str | None = None,
    default_headers: Mapping[str, str] | None = None,
) -> dict[str, str]:
    org_id = _first_value(
        organization_id,
        os.getenv("EVALOPS_ORGANIZATION_ID"),
        os.getenv("EVALOPS_WORKSPACE_ID"),
    )
    if not org_id:
        raise ValueError("EVALOPS_ORGANIZATION_ID or organization_id is required")

    headers = dict(default_headers or {})
    headers["X-Organization-ID"] = org_id
    headers["X-EvalOps-Organization-ID"] = org_id

    resolved_principal = _first_value(principal, os.getenv("EVALOPS_PRINCIPAL"))
    if resolved_principal:
        headers["X-EvalOps-Principal"] = resolved_principal

    resolved_trace_id = _first_value(trace_id, os.getenv("EVALOPS_TRACE_ID"))
    if resolved_trace_id:
        headers["X-EvalOps-Trace-ID"] = resolved_trace_id

    return headers


def build_provider_ref(provider_ref: Mapping[str, str] | None = None) -> ProviderRef:
    provider_ref = provider_ref or {}
    result: ProviderRef = {
        "provider": provider_ref.get("provider") or "openai",
        "environment": provider_ref.get("environment")
        or os.getenv("EVALOPS_PROVIDER_ENVIRONMENT")
        or "prod",
    }
    credential_name = provider_ref.get("credential_name") or os.getenv(
        "EVALOPS_PROVIDER_CREDENTIAL_NAME"
    )
    if credential_name:
        result["credential_name"] = credential_name
    team_id = provider_ref.get("team_id") or os.getenv("EVALOPS_PROVIDER_TEAM_ID")
    if team_id:
        result["team_id"] = team_id
    return result


class _EvalOpsMixin:
    evalops_provider_ref: ProviderRef

    def with_provider_ref(self, body: Mapping[str, Any]) -> dict[str, Any]:
        next_body = dict(body)
        next_body.setdefault("provider_ref", self.evalops_provider_ref)
        return next_body


class OpenAI(_EvalOpsMixin, _OpenAI):
    def __init__(
        self,
        *,
        organization_id: str | None = None,
        principal: str | None = None,
        trace_id: str | None = None,
        evalops_base_url: str | None = None,
        provider_ref: Mapping[str, str] | None = None,
        default_headers: MutableMapping[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> None:
        self.evalops_provider_ref = build_provider_ref(provider_ref)
        super().__init__(
            api_key=api_key or os.getenv("EVALOPS_API_KEY") or os.getenv("OPENAI_API_KEY"),
            base_url=evalops_base_url
            or os.getenv("EVALOPS_LLM_GATEWAY_URL")
            or DEFAULT_GATEWAY_BASE_URL,
            default_headers=build_evalops_headers(
                organization_id=organization_id,
                principal=principal,
                trace_id=trace_id,
                default_headers=default_headers,
            ),
            **kwargs,
        )


class AsyncOpenAI(_EvalOpsMixin, _AsyncOpenAI):
    def __init__(
        self,
        *,
        organization_id: str | None = None,
        principal: str | None = None,
        trace_id: str | None = None,
        evalops_base_url: str | None = None,
        provider_ref: Mapping[str, str] | None = None,
        default_headers: MutableMapping[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> None:
        self.evalops_provider_ref = build_provider_ref(provider_ref)
        super().__init__(
            api_key=api_key or os.getenv("EVALOPS_API_KEY") or os.getenv("OPENAI_API_KEY"),
            base_url=evalops_base_url
            or os.getenv("EVALOPS_LLM_GATEWAY_URL")
            or DEFAULT_GATEWAY_BASE_URL,
            default_headers=build_evalops_headers(
                organization_id=organization_id,
                principal=principal,
                trace_id=trace_id,
                default_headers=default_headers,
            ),
            **kwargs,
        )


__all__ = [
    "AsyncOpenAI",
    "DEFAULT_GATEWAY_BASE_URL",
    "OpenAI",
    "build_evalops_headers",
    "build_provider_ref",
]

