import OpenAIBase, { type ClientOptions } from "openai";

export const DEFAULT_GATEWAY_BASE_URL = "https://llm-gateway.internal.evalops.dev/v1";

export type ProviderRef = {
  provider: "openai" | string;
  environment: string;
  credential_name?: string;
  team_id?: string;
};

export type EvalOpsHeaderOptions = {
  organizationId?: string;
  principal?: string;
  traceId?: string;
  defaultHeaders?: Record<string, string>;
};

export type EvalOpsOpenAIOptions = Omit<ClientOptions, "defaultHeaders"> &
  EvalOpsHeaderOptions & {
    evalopsApiKey?: string;
    evalopsBaseURL?: string;
    providerRef?: ProviderRef;
    defaultHeaders?: Record<string, string>;
  };

function readEnv(name: string): string | undefined {
  return typeof process === "undefined" ? undefined : process.env[name];
}

function firstValue(...values: Array<string | null | undefined>): string | undefined {
  return values.find((value) => value != null && value.trim() !== "") ?? undefined;
}

export function buildEvalOpsHeaders(options: EvalOpsHeaderOptions = {}): Record<string, string> {
  const organizationId = firstValue(
    options.organizationId,
    readEnv("EVALOPS_ORGANIZATION_ID"),
    readEnv("EVALOPS_WORKSPACE_ID"),
  );

  if (!organizationId) {
    throw new Error("EVALOPS_ORGANIZATION_ID or organizationId is required");
  }

  const headers: Record<string, string> = { ...(options.defaultHeaders ?? {}) };
  headers["X-Organization-ID"] = organizationId;
  headers["X-EvalOps-Organization-ID"] = organizationId;

  const principal = firstValue(options.principal, readEnv("EVALOPS_PRINCIPAL"));
  if (principal) {
    headers["X-EvalOps-Principal"] = principal;
  }

  const traceId = firstValue(options.traceId, readEnv("EVALOPS_TRACE_ID"));
  if (traceId) {
    headers["X-EvalOps-Trace-ID"] = traceId;
  }

  return headers;
}

export function buildProviderRef(providerRef?: Partial<ProviderRef>): ProviderRef {
  return {
    provider: providerRef?.provider ?? "openai",
    environment:
      providerRef?.environment ?? firstValue(readEnv("EVALOPS_PROVIDER_ENVIRONMENT"), "prod")!,
    credential_name:
      providerRef?.credential_name ?? firstValue(readEnv("EVALOPS_PROVIDER_CREDENTIAL_NAME")),
    team_id: providerRef?.team_id ?? firstValue(readEnv("EVALOPS_PROVIDER_TEAM_ID")),
  };
}

export class EvalOpsOpenAI extends OpenAIBase {
  readonly evalopsProviderRef: ProviderRef;

  constructor(options: EvalOpsOpenAIOptions = {}) {
    const {
      organizationId,
      principal,
      traceId,
      evalopsApiKey,
      evalopsBaseURL,
      providerRef: providerRefOption,
      defaultHeaders: defaultHeaderOption,
      ...clientOptions
    } = options;
    const apiKey = firstValue(clientOptions.apiKey, evalopsApiKey, readEnv("EVALOPS_API_KEY"), readEnv("OPENAI_API_KEY"));
    const baseURL = firstValue(clientOptions.baseURL, evalopsBaseURL, readEnv("EVALOPS_LLM_GATEWAY_URL"), DEFAULT_GATEWAY_BASE_URL);
    const defaultHeaders = buildEvalOpsHeaders({
      organizationId,
      principal,
      traceId,
      defaultHeaders: defaultHeaderOption,
    });
    const providerRef = buildProviderRef(providerRefOption);

    super({
      ...clientOptions,
      apiKey,
      baseURL,
      defaultHeaders,
    });

    this.evalopsProviderRef = providerRef;
  }

  withProviderRef<TBody extends Record<string, unknown>>(body: TBody): TBody & { provider_ref: ProviderRef } {
    return {
      ...body,
      provider_ref: (body.provider_ref as ProviderRef | undefined) ?? this.evalopsProviderRef,
    };
  }
}

export { EvalOpsOpenAI as OpenAI };
export default EvalOpsOpenAI;
