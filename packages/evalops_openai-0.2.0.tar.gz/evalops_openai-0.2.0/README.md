# evalops-openai

Drop-in OpenAI SDK shim for routing OpenAI-compatible requests through EvalOps
`llm-gateway` with organization scope, principal attribution, audit, metering,
and governance hooks.

This package is the first G1 wedge from
`evalops/platform#1133`. It deliberately wraps the official OpenAI SDKs instead
of reimplementing OpenAI wire formats.

## Python

```bash
pip install evalops-openai
```

```python
from evalops_openai import OpenAI

client = OpenAI(
    organization_id="org_123",
    principal="user:ada@example.com",
)

response = client.chat.completions.create(
    **client.with_provider_ref(
        {
            "model": "gpt-4.1-mini",
            "messages": [{"role": "user", "content": "hello"}],
        }
    )
)
```

## Node

```bash
npm install @evalops/openai
```

```ts
import { OpenAI } from "@evalops/openai";

const client = new OpenAI({
  organizationId: "org_123",
  principal: "user:ada@example.com",
});

const response = await client.chat.completions.create(
  client.withProviderRef({
    model: "gpt-4.1-mini",
    messages: [{ role: "user", content: "hello" }],
  }),
);
```

## Environment

- `EVALOPS_API_KEY` or `OPENAI_API_KEY`: Platform-issued bearer token.
- `EVALOPS_ORGANIZATION_ID`: organization scope stamped into gateway requests.
- `EVALOPS_PRINCIPAL`: optional actor string for audit attribution.
- `EVALOPS_TRACE_ID`: optional trace correlation ID.
- `EVALOPS_LLM_GATEWAY_URL`: defaults to `https://llm-gateway.internal.evalops.dev/v1`.
- `EVALOPS_PROVIDER_ENVIRONMENT`: defaults to `prod`.
- `EVALOPS_PROVIDER_CREDENTIAL_NAME`: optional provider ref credential name.
- `EVALOPS_PROVIDER_TEAM_ID`: optional provider ref team ID.

## Current Gateway Constraint

The current `llm-gateway` contract requires `provider_ref` in the JSON body for
`/v1/chat/completions` and `/v1/responses`. The helpers above inject that field
while preserving the vendor SDK surface. Once the gateway can infer a default
provider ref from the authenticated principal, the helper call can disappear and
the package becomes import-only migration.

