# Changelog

## [0.2.0](https://github.com/evalops/evalops-openai/compare/openai-v0.1.0...openai-v0.2.0) (2026-04-29)


### Features

* add registry publish workflow ([d4667f0](https://github.com/evalops/evalops-openai/commit/d4667f0f0b08b1068850819bbf8e8bec28090294))


### Bug Fixes

* use bot token for release PRs ([2cbf617](https://github.com/evalops/evalops-openai/commit/2cbf61708cc955048571b40760c3de2b0d1bb6b2))
