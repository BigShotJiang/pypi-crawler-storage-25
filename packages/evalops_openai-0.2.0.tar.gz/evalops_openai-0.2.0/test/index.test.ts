import { describe, expect, it, vi } from "vitest";
import { buildEvalOpsHeaders, buildProviderRef, OpenAI } from "../src/index";

describe("evalops-openai", () => {
  it("stamps both current and future org headers", () => {
    expect(buildEvalOpsHeaders({ organizationId: "org_123", principal: "user:ada" })).toMatchObject({
      "X-Organization-ID": "org_123",
      "X-EvalOps-Organization-ID": "org_123",
      "X-EvalOps-Principal": "user:ada",
    });
  });

  it("builds the default OpenAI provider ref", () => {
    expect(buildProviderRef()).toMatchObject({
      provider: "openai",
      environment: "prod",
    });
  });

  it("injects provider_ref without mutating request body", () => {
    vi.stubEnv("EVALOPS_API_KEY", "token");
    const client = new OpenAI({ organizationId: "org_123" });
    const body = { model: "gpt-4.1-mini", messages: [{ role: "user", content: "hello" }] };

    expect(client.withProviderRef(body)).toMatchObject({
      ...body,
      provider_ref: { provider: "openai", environment: "prod" },
    });
    expect(body).not.toHaveProperty("provider_ref");
  });
});

