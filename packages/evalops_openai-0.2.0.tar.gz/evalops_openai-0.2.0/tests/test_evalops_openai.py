import pytest

from evalops_openai import OpenAI, build_evalops_headers, build_provider_ref


def test_headers_stamp_org_and_principal() -> None:
    assert build_evalops_headers(
        organization_id="org_123",
        principal="user:ada",
    ) == {
        "X-Organization-ID": "org_123",
        "X-EvalOps-Organization-ID": "org_123",
        "X-EvalOps-Principal": "user:ada",
    }


def test_headers_require_org() -> None:
    with pytest.raises(ValueError):
        build_evalops_headers()


def test_default_provider_ref() -> None:
    assert build_provider_ref() == {"provider": "openai", "environment": "prod"}


def test_with_provider_ref_does_not_mutate_input(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("EVALOPS_API_KEY", "token")
    client = OpenAI(organization_id="org_123")
    body = {"model": "gpt-4.1-mini", "messages": [{"role": "user", "content": "hello"}]}

    assert client.with_provider_ref(body)["provider_ref"] == {
        "provider": "openai",
        "environment": "prod",
    }
    assert "provider_ref" not in body

