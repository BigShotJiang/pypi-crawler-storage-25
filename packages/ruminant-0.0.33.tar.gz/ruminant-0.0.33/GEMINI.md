kill yourself
