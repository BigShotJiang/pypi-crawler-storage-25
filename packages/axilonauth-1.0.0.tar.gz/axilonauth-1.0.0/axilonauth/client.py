"""
AxilonClient — unified license verification + version management + auto-update.

Integrates with the AxilonAuth API:
  - POST /api/verify           — license verification (returns version_info)
  - GET  /api/version/{product} — version check
  - POST /api/version/download  — generate download token for updates
"""

import time
import hmac
import hashlib
from dataclasses import dataclass, field
from typing import Optional
from packaging.version import parse as parse_version

import requests

from .hwid import generate_hwid
from .storage import SecureStorage


@dataclass
class StartupResult:
    """Result of AxilonClient.startup() — all info needed to decide what to do."""

    licensed: bool = False
    error: str = ""
    discord_id: str = ""
    expires_at: str = ""
    total_requests: int = 0

    # Version info (populated from /api/verify response)
    update_available: bool = False
    force_update: bool = False
    latest_version: str = ""
    changelog: str = ""
    download_available: bool = False

    # Maintenance
    maintenance: bool = False
    maintenance_message: str = ""


class AxilonClient:
    """
    Unified client for Axilon license verification and version management.

    Args:
        product_name:    Product name as configured in the admin dashboard.
        current_version: This tool's version string (e.g., "3.0.0").
        api_url:         Base URL of AxilonAuth (default: https://auth.axilon.app).
        api_key:         API key for authentication.
        timeout:         HTTP request timeout in seconds.
    """

    def __init__(
        self,
        product_name: str,
        current_version: str,
        api_url: str = "https://auth.axilon.app",
        api_key: str = "",
        timeout: int = 15,
    ):
        self.product_name = product_name
        self.current_version = current_version
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

        # Generate HWID with per-product salt
        self.hwid = generate_hwid(product_salt=product_name)

        # Encrypted local cache
        self._storage = SecureStorage(product_name, self.hwid)
        self._session = requests.Session()

    def _headers(self) -> dict:
        """Build request headers with API key and request signing."""
        ts = str(int(time.time()))
        # HMAC signature: prevents simple replay — server can optionally validate
        sig = hmac.new(
            self.api_key.encode("utf-8"),
            f"{ts}:{self.hwid}".encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        return {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "x-timestamp": ts,
            "x-signature": sig,
        }

    def startup(self, license_key: str) -> StartupResult:
        """
        One-call startup: verify license + check version + check maintenance.

        This is the main method your tool should call at startup.

        Returns a StartupResult with all the info needed to decide:
        - Is the license valid?
        - Is there an update available?
        - Is the tool in maintenance mode?
        """
        result = StartupResult()

        # --- Step 1: Verify license with the API ---
        try:
            resp = self._session.post(
                f"{self.api_url}/api/verify",
                headers=self._headers(),
                json={
                    "licensekey": license_key,
                    "product": self.product_name,
                    "hwid": self.hwid,
                    "client_version": self.current_version,
                },
                timeout=self.timeout,
            )

            data = resp.json()
        except requests.ConnectionError:
            # Offline: try cached license
            cached = self._storage.load()
            if cached and cached.get("valid"):
                result.licensed = True
                result.discord_id = cached.get("discord_id", "")
                result.expires_at = cached.get("expires_at", "")
                result.error = "Offline mode — using cached license"
                return result
            result.error = "Cannot connect to license server"
            return result
        except Exception as e:
            result.error = f"License verification failed: {str(e)}"
            return result

        # --- Step 2: Parse license response ---
        if data.get("status_overview") == "success":
            result.licensed = True
            result.discord_id = data.get("discord_id", "")
            result.expires_at = data.get("expires_at", "")
            result.total_requests = data.get("total_requests", 0)

            # Cache for offline use
            self._storage.save({
                "valid": True,
                "key": license_key,
                "discord_id": result.discord_id,
                "expires_at": result.expires_at,
                "hwid": self.hwid,
                "validated_at": time.time(),
                "product": self.product_name,
            })
        else:
            result.licensed = False
            result.error = data.get("status_msg", "Unknown error")
            self._storage.clear()
            return result

        # --- Step 3: Parse version info (included in verify response) ---
        version_info = data.get("version_info")
        if version_info:
            latest = version_info.get("current_version", "")
            minimum = version_info.get("minimum_version", "")
            result.latest_version = latest
            result.download_available = version_info.get("download_available", False)

            # Maintenance check
            if version_info.get("maintenance_mode"):
                result.maintenance = True
                result.maintenance_message = version_info.get("maintenance_message", "Tool is under maintenance.")
                return result

            # Version comparison
            if latest and self.current_version:
                try:
                    if parse_version(latest) > parse_version(self.current_version):
                        result.update_available = True
                except Exception:
                    pass

            # Force-update check (below minimum version)
            if minimum and self.current_version:
                try:
                    if parse_version(self.current_version) < parse_version(minimum):
                        result.force_update = True
                        result.update_available = True
                except Exception:
                    pass

        return result

    def check_version(self) -> dict:
        """
        Standalone version check (without license verification).
        Returns raw version info dict from the server.
        """
        try:
            resp = self._session.get(
                f"{self.api_url}/api/version/{requests.utils.quote(self.product_name)}",
                headers=self._headers(),
                timeout=self.timeout,
            )
            if resp.status_code == 200:
                return resp.json()
            return {"error": resp.json().get("error", "Version check failed")}
        except Exception as e:
            return {"error": str(e)}

    def download_update(self, license_key: str, save_dir: str = "./update") -> Optional[str]:
        """
        Download the latest version update.

        1. Calls /api/version/download to get a single-use download token
        2. Downloads the file via the token URL
        3. Saves to save_dir

        Args:
            license_key: The user's license key (needed for auth).
            save_dir: Directory to save the downloaded file.

        Returns:
            File path on success, None on failure.
        """
        import os

        # Step 1: Get download token
        try:
            resp = self._session.post(
                f"{self.api_url}/api/version/download",
                headers=self._headers(),
                json={
                    "licensekey": license_key,
                    "product": self.product_name,
                },
                timeout=self.timeout,
            )

            if resp.status_code != 200:
                data = resp.json()
                print(f"[Axilon] Download error: {data.get('error', 'Unknown')}")
                return None

            data = resp.json()
            download_url = data.get("downloadUrl")
            version = data.get("version", "unknown")

            if not download_url:
                print("[Axilon] No download URL returned")
                return None

        except Exception as e:
            print(f"[Axilon] Failed to get download token: {e}")
            return None

        # Step 2: Download the file
        try:
            os.makedirs(save_dir, exist_ok=True)
            file_resp = self._session.get(download_url, stream=True, timeout=60, allow_redirects=True)
            file_resp.raise_for_status()

            # Determine filename from content-disposition or URL
            filename = f"{self.product_name}-v{version}.zip"
            cd = file_resp.headers.get("content-disposition", "")
            if "filename=" in cd:
                filename = cd.split("filename=")[1].strip('"').strip("'")

            filepath = os.path.join(save_dir, filename)

            total = int(file_resp.headers.get("content-length", 0))
            downloaded = 0

            with open(filepath, "wb") as f:
                for chunk in file_resp.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = (downloaded / total) * 100
                        print(f"\r[Axilon] Downloading: {pct:.1f}%", end="", flush=True)

            print(f"\n[Axilon] Downloaded: {filepath}")
            return filepath

        except Exception as e:
            print(f"\n[Axilon] Download failed: {e}")
            return None

    def deactivate(self) -> None:
        """Clear the local license cache (logout)."""
        self._storage.clear()

    def get_hwid(self) -> str:
        """Return this machine's HWID for the current product."""
        return self.hwid
