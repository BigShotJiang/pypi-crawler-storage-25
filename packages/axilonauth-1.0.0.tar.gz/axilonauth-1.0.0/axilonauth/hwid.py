"""
Hardware ID generation — collects machine-specific identifiers and hashes them.
Per-product salt ensures different products get different HWIDs for the same machine.
"""

import hashlib
import platform
import subprocess
import os


def _run_cmd(cmd: str, shell: bool = True) -> str:
    """Run a shell command and return stripped stdout, or empty string on failure."""
    try:
        result = subprocess.run(
            cmd, shell=shell, capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _get_cpu_serial() -> str:
    if platform.system() == "Windows":
        out = _run_cmd(
            'powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).ProcessorId"'
        )
        if not out:
            out = _run_cmd("wmic cpu get ProcessorId /value")
            for line in out.splitlines():
                if "ProcessorId=" in line:
                    return line.split("=", 1)[1].strip()
        return out
    else:
        try:
            with open("/proc/cpuinfo", "r") as f:
                for line in f:
                    if "Serial" in line or "serial" in line:
                        return line.split(":")[1].strip()
        except Exception:
            pass
    return ""


def _get_machine_uuid() -> str:
    if platform.system() == "Windows":
        out = _run_cmd(
            'powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystemProduct).UUID"'
        )
        return out
    else:
        try:
            with open("/etc/machine-id", "r") as f:
                return f.read().strip()
        except Exception:
            return ""


def _get_disk_serial() -> str:
    if platform.system() == "Windows":
        out = _run_cmd(
            'powershell -NoProfile -Command "(Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber"'
        )
        return out.strip()
    else:
        out = _run_cmd("lsblk -ndo SERIAL /dev/sda 2>/dev/null")
        return out


def _get_motherboard_serial() -> str:
    if platform.system() == "Windows":
        out = _run_cmd(
            'powershell -NoProfile -Command "(Get-CimInstance Win32_BaseBoard).SerialNumber"'
        )
        return out.strip()
    return ""


def generate_hwid(product_salt: str = "") -> str:
    """
    Generate a deterministic hardware ID from machine components.

    Args:
        product_salt: Per-product salt so the same machine produces different
                      HWIDs for different products. Prevents cross-product
                      HWID correlation by crackers.

    Returns:
        SHA-256 hex digest string.
    """
    components = []

    cpu = _get_cpu_serial()
    if cpu:
        components.append(cpu)

    uuid = _get_machine_uuid()
    if uuid:
        components.append(uuid)

    disk = _get_disk_serial()
    if disk:
        components.append(disk)

    mobo = _get_motherboard_serial()
    if mobo:
        components.append(mobo)

    # Fallback: basic system info
    if not components:
        components = [
            platform.system(),
            platform.node(),
            platform.machine(),
            platform.processor(),
            os.getenv("COMPUTERNAME", os.getenv("HOSTNAME", "")),
        ]

    raw = "|".join(components)
    if product_salt:
        raw = f"{product_salt}:{raw}"

    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
