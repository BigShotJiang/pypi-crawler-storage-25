"""
Encrypted local license cache — stores validated license data using AES-256-GCM.
The encryption key is derived from the HWID (machine-specific) so the cache
cannot be copied to another machine.
"""

import hashlib
import json
import os
from pathlib import Path

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False


class SecureStorage:
    """Encrypted file-based license cache."""

    def __init__(self, product_name: str, hwid: str):
        cache_dir = Path.home() / ".axilon_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)

        # Per-product cache file
        safe_name = "".join(c if c.isalnum() else "_" for c in product_name.lower())
        self._path = cache_dir / f".{safe_name}.lic"
        self._key = self._derive_key(hwid, product_name)

    def _derive_key(self, hwid: str, product_name: str) -> bytes:
        """Derive a 256-bit AES key from HWID + product name."""
        if HAS_CRYPTO:
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=f"axilon:{product_name}".encode("utf-8"),
                iterations=100_000,
            )
            return kdf.derive(hwid.encode("utf-8"))
        else:
            # Fallback: simple PBKDF2 via hashlib
            return hashlib.pbkdf2_hmac(
                "sha256",
                hwid.encode("utf-8"),
                f"axilon:{product_name}".encode("utf-8"),
                100_000,
            )

    def save(self, data: dict) -> bool:
        """Encrypt and save license data to disk."""
        if not HAS_CRYPTO:
            return False
        try:
            plaintext = json.dumps(data).encode("utf-8")
            nonce = os.urandom(12)
            aesgcm = AESGCM(self._key)
            ciphertext = aesgcm.encrypt(nonce, plaintext, None)
            self._path.write_bytes(nonce + ciphertext)
            return True
        except Exception:
            return False

    def load(self) -> dict | None:
        """Load and decrypt cached license data. Returns None if missing/corrupt."""
        if not HAS_CRYPTO or not self._path.exists():
            return None
        try:
            raw = self._path.read_bytes()
            if len(raw) < 13:
                return None
            nonce = raw[:12]
            ciphertext = raw[12:]
            aesgcm = AESGCM(self._key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
            return json.loads(plaintext.decode("utf-8"))
        except Exception:
            return None

    def clear(self) -> None:
        """Delete the cache file."""
        try:
            self._path.unlink(missing_ok=True)
        except Exception:
            pass
