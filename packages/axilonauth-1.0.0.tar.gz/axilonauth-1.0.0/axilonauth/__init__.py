"""
AxilonAuth — Unified license verification, version management, and auto-update client.

Usage:
    from axilon_sdk import AxilonClient

    client = AxilonClient(
        product_name="MS-Fetcher",
        current_version="3.0.0",
        api_url="https://auth.axilon.app",
        api_key="your-api-key"
    )

    result = client.startup(license_key="ABCD-1234-EFGH-5678")
"""

from .client import AxilonClient, StartupResult

__version__ = "1.0.0"
__all__ = ["AxilonClient", "StartupResult"]
