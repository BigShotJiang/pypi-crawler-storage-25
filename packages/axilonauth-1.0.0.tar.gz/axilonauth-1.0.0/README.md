<h1 align="center">AxilonAuth</h1>
<p align="center">
  <b>License verification, version management & auto-updates for your tools</b><br>
  <i>Verify · Update · Protect · One line to secure your app</i>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#methods">Methods</a>
</p>

---

## Features

- **License Verification** - IP/HWID tracking, encrypted local cache
- **Auto Updates** - Detect new versions, force-update support
- **Maintenance Mode** - Block your tool remotely from the dashboard
- **Secure Downloads** - Single-use 24h download tokens
- **Offline Mode** - Works without internet using cached license

## Quick Start

```bash
# 1. Install the package
pip install axilonauth

# 2. Import and use
```

```python
from axilonauth import AxilonClient

client = AxilonClient(
    product_name="My-Tool",
    current_version="1.0.0",
    api_url="https://auth.axilon.app",
    api_key="your-api-key"
)

result = client.startup(license_key="ABCD-1234-EFGH-5678")

if not result.licensed:
    print(result.error)
    exit()

if result.force_update:
    client.download_update(license_key="ABCD-1234-EFGH-5678")
    exit()

# Your tool runs here
print("Licensed and ready!")
```

## Methods

- `client.startup(key)` - Verify license + check version
- `client.download_update(key)` - Download latest version
- `client.check_version()` - Check for updates
- `client.deactivate()` - Clear license cache
- `client.get_hwid()` - Get machine HWID
