"""
AzerAI DateTime Plugin Prompts
Tarix və zaman sorğuları üçün AI təlimatları
"""

PLUGIN_PROMPT = """
DateTime Plugin Capability:
You can provide current date and time information.

Available functions:
- get_datetime() - Returns current date and time in readable format

When users ask about time, date, or datetime related questions, use this function to provide accurate information.

Examples:
- "Saat neçədir?" -> Use get_datetime()
- "Bugün tarix neçədir?" -> Use get_datetime()
- "Havadan xəbər var, bu gün həftənin neçənci günüdür?" -> Use get_datetime()

The function returns date and time in English format with basic information.

Always provide responses in Azerbaijani language unless specifically asked otherwise.
"""
