"""
Tarix və Zaman Alətləri - LiveKit Agent Funksiyaları
Cari tarix və zaman sorğuları üçün alətlər
"""
import logging
from livekit.agents import function_tool, RunContext
from datetime import datetime

logger = logging.getLogger("datetime-tools")

@function_tool()
async def get_datetime(
    ctx: RunContext,  # type: ignore
) -> str:
    """
    Cari tarix və zamanı al.
    Oxunaqlı formatda cari tarix və zamanı qaytarır.
    """
    try:
        now = datetime.now()
        date_time_str = now.strftime("%Y-%m-%d %H:%M:%S")
        date_str = now.strftime("%B %d, %Y")
        time_str = now.strftime("%H:%M:%S")
        logging.info(f"Cari tarix və zaman: {date_time_str}")
        return f"Cari tarix və zaman: {date_str} saat {time_str}"
    except Exception as e:
        logging.error(f"Tarix və zaman alınarkən xəta: {e}")
        return f"Tarix və zaman alınarkən xəta baş verdi."
