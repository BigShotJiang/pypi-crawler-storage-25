"""
AzerAI DateTime Plugin - Tarix və zaman sorğuları üçün plugin
"""

from .main import get_datetime

__all__ = [
    "get_datetime"
]
