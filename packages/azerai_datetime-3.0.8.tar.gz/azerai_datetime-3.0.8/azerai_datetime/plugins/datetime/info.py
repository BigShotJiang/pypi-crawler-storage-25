"""
AzerAI DateTime Plugin Info
Plugin haqqında məlumatlar və metadata
"""

__version__ = "3.0.8"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"
__description__ = "AzerAI DateTime Plugin - Tarix və zaman sorğuları üçün plugin"

PLUGIN_INFO = {
    "name": "azerai-datetime",
    "version": __version__,
    "author": __author__,
    "email": __email__,
    "description": __description__,
    "category": "utility",
    "language": "az",
    "timezone": "UTC+4",
    "functions": [
        "get_datetime"
    ],
    "capabilities": [
        "Cari tarix və zamanı İngilis formatında qaytarır",
        "Oxunaqlı tarix formatı (Buna görə də, 2025)",
        "24 saat formatında vaxt (HH:MM:SS)",
        "Əsas datetime funksiyaları"
    ],
    "dependencies": [
        "livekit-agents"
    ],
    "tags": ["azerai", "plugin", "datetime", "time", "date", "ai", "azerbaijani"]
}

def get_plugin_info():
    """Plugin məlumatlarını qaytarır"""
    return PLUGIN_INFO

def get_plugin_version():
    """Plugin versiyasını qaytarır"""
    return __version__

def get_plugin_description():
    """Plugin təsvirini qaytarır"""
    return __description__
