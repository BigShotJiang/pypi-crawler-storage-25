"""Tests for sub-workflow node tracking in the parent's execution context."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import gtm_admin.decorator as dec
from gtm_admin.decorator import make_workflow_wrapper
from gtm_admin.models import Workflow, WorkflowRun, WorkflowStatus


def _mock_session_local(cfg: Workflow | None, running_count: int = 0):
    mock_exec_result = MagicMock()
    mock_exec_result.first = MagicMock(return_value=cfg)

    mock_count_result = MagicMock()
    mock_count_result.scalar_one = MagicMock(return_value=running_count)

    _id_counter = [0]

    async def _refresh(obj):
        if hasattr(obj, "id") and obj.id is None:
            _id_counter[0] += 1
            obj.id = _id_counter[0]

    session = AsyncMock()
    session.exec = AsyncMock(return_value=mock_exec_result)
    session.execute = AsyncMock(return_value=mock_count_result)
    session.add = MagicMock()
    session.get = AsyncMock(return_value=None)
    session.refresh = _refresh

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)
    return MagicMock(return_value=cm)


@pytest.fixture(autouse=True)
def _patch_broadcast():
    mock_manager = MagicMock()
    mock_manager.broadcast = AsyncMock()
    with patch("gtm_admin.broadcast.manager", mock_manager):
        with patch("gtm_admin.decorator._ensure_drain_task"):
            with patch("gtm_admin.decorator._notify_drain"):
                yield


@pytest.mark.asyncio
async def test_sub_workflow_appends_workflow_node_to_parent_ctx():
    """When a workflow runs inside another, a type='workflow' node is appended to the parent ctx."""
    cfg = Workflow(id=1, name="child_wf", max_concurrent_runs=None)
    mock_sl = _mock_session_local(cfg)

    async def child_fn(inputs: dict):
        return {"result": "child_done"}

    child_wrapper = make_workflow_wrapper(child_fn)
    child_wrapper.__name__ = "child_fn"

    with patch("gtm_admin.decorator._SessionLocal", mock_sl):
        parent_ctx: dict = {"actions": [], "plan": [], "logs": [], "run_id": 99, "_action_counter": 0}
        token = dec._active_run_ctx.set(parent_ctx)
        try:
            await child_wrapper({"x": 1})
        finally:
            dec._active_run_ctx.reset(token)

    assert len(parent_ctx["actions"]) == 1
    node = parent_ctx["actions"][0]
    assert node["type"] == "workflow"
    assert node["name"] == "child_fn"
    assert node["inputs"] == {"x": 1}
    assert node["outputs"] == {"result": "child_done"}
    assert node["status"] == WorkflowStatus.success.value
    assert isinstance(node["child_run_id"], int)
    assert node["child_run_id"] is not None


@pytest.mark.asyncio
async def test_sub_workflow_node_has_sequential_id_after_regular_nodes():
    """Sub-workflow node id follows on from existing nodes in the parent ctx."""
    cfg = Workflow(id=1, name="child_wf", max_concurrent_runs=None)
    mock_sl = _mock_session_local(cfg)

    async def child_fn(inputs: dict):
        return {}

    child_wrapper = make_workflow_wrapper(child_fn)
    child_wrapper.__name__ = "child_fn"

    with patch("gtm_admin.decorator._SessionLocal", mock_sl):
        parent_ctx: dict = {
            "actions": [
                {"id": 1, "name": "first_node", "status": "success"},
                {"id": 2, "name": "second_node", "status": "success"},
            ],
            "plan": [],
            "logs": [],
            "run_id": 99,
            "_action_counter": 2,
        }
        token = dec._active_run_ctx.set(parent_ctx)
        try:
            await child_wrapper({})
        finally:
            dec._active_run_ctx.reset(token)

    assert len(parent_ctx["actions"]) == 3
    assert parent_ctx["actions"][2]["id"] == 3
    assert parent_ctx["actions"][2]["type"] == "workflow"


@pytest.mark.asyncio
async def test_no_sub_workflow_node_when_not_inside_parent():
    """When called as a top-level workflow (no parent ctx), no node is appended anywhere."""
    cfg = Workflow(id=1, name="standalone_wf", max_concurrent_runs=None)
    mock_sl = _mock_session_local(cfg)

    async def standalone_fn(inputs: dict):
        return {"done": True}

    wrapper = make_workflow_wrapper(standalone_fn)
    wrapper.__name__ = "standalone_fn"

    # No active context set
    assert dec._active_run_ctx.get() is None

    with patch("gtm_admin.decorator._SessionLocal", mock_sl):
        result = await wrapper({"y": 2})

    # Just verify it ran successfully with no crash
    assert result == {"done": True}


@pytest.mark.asyncio
async def test_sub_workflow_node_status_reflects_failure():
    """A failing sub-workflow appends a type='workflow' node with status='failed'."""
    cfg = Workflow(id=1, name="failing_child", max_concurrent_runs=None)
    mock_sl = _mock_session_local(cfg)

    async def failing_fn(inputs: dict):
        raise RuntimeError("boom")

    child_wrapper = make_workflow_wrapper(failing_fn)
    child_wrapper.__name__ = "failing_fn"

    with patch("gtm_admin.decorator._SessionLocal", mock_sl):
        parent_ctx: dict = {"actions": [], "plan": [], "logs": [], "run_id": 99, "_action_counter": 0}
        token = dec._active_run_ctx.set(parent_ctx)
        try:
            with pytest.raises(RuntimeError, match="boom"):
                await child_wrapper({})
        finally:
            dec._active_run_ctx.reset(token)

    assert len(parent_ctx["actions"]) == 1
    node = parent_ctx["actions"][0]
    assert node["type"] == "workflow"
    assert node["status"] == WorkflowStatus.failed.value
    assert node["name"] == "failing_fn"


@pytest.mark.asyncio
async def test_sub_workflow_node_child_run_id_matches():
    """The child_run_id in the parent node matches the WorkflowRun id created for the child."""
    cfg = Workflow(id=1, name="child_wf", max_concurrent_runs=None)
    mock_sl = _mock_session_local(cfg)

    captured_run_ids: list[int] = []

    async def child_fn(inputs: dict):
        ctx = dec._active_run_ctx.get()
        if ctx:
            captured_run_ids.append(ctx["run_id"])
        return {}

    child_wrapper = make_workflow_wrapper(child_fn)
    child_wrapper.__name__ = "child_fn"

    with patch("gtm_admin.decorator._SessionLocal", mock_sl):
        parent_ctx: dict = {"actions": [], "plan": [], "logs": [], "run_id": 99, "_action_counter": 0}
        token = dec._active_run_ctx.set(parent_ctx)
        try:
            await child_wrapper({})
        finally:
            dec._active_run_ctx.reset(token)

    assert len(parent_ctx["actions"]) == 1
    node = parent_ctx["actions"][0]
    assert len(captured_run_ids) == 1
    assert node["child_run_id"] == captured_run_ids[0]
