# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.1.dev1] — 2026-04-30

### Added
- :class:`Estimator` API for assembling calibration / bundle adjustment
  problems: cameras, SE(3) frames, and 3D-to-2D observations.
- Projection models: :class:`BrownConrady`, :class:`KannalaBrandt`,
  :class:`Division`, :class:`Rational` — each exposes a ``Param`` enum
  for per-parameter fixing.
- Lie group types :class:`SE3` and :class:`SO3` with rotation /
  translation accessors.
- :class:`Submanifold` bitflag for selecting which DOFs of a frame are
  optimized (full SE(3), translation-only, rotation-only, or arbitrary
  per-axis combinations).
- :class:`LossFunction` enum: pure L2, Huber, Cauchy, Soft-L1.
- :class:`ReprojectionPenalty` enum for out-of-bounds projection handling.
- :class:`SolveResult` dataclass capturing convergence, RMS, iterations,
  wall time.
- CI workflow: lint (ruff) + test (pytest) on Python 3.10–3.14.
- Release workflow: tag-triggered PyPI publish via trusted publishing.
- Apache-2.0 license.
