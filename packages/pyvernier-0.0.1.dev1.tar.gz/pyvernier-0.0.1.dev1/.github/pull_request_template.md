## Summary
<!-- What does this PR do? -->

## Changes
- 

## Testing
- [ ] Tests pass (`pytest tests/ -v`)
- [ ] Lint clean (`ruff check .`)
- [ ] Format clean (`ruff format --check .`)

## Notes
<!-- Any additional context -->
