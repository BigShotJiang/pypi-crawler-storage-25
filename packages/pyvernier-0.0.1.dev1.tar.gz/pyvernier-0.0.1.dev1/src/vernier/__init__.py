# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""vernier — geometric calibration toolkit.

Bundle adjustment, camera calibration, and multi-sensor extrinsic
optimization. The optimization core wraps Ceres Solver and Sophus through
a clean Python API.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _get_version

try:
    __version__ = _get_version("vernier")
except PackageNotFoundError:  # pragma: no cover - editable install fallback
    __version__ = "unknown"

from vernier import _vernier as _native  # noqa: F401
from vernier._core import (
    SE3,
    SO3,
    BrownConrady,
    Division,
    KannalaBrandt,
    LossFunction,
    Rational,
    ReprojectionPenalty,
    SolveResult,
    Submanifold,
)
from vernier.estimator import Estimator

__all__ = [
    # Estimator
    "Estimator",
    # Lie groups
    "SE3",
    "SO3",
    # Projection models
    "BrownConrady",
    "Division",
    "KannalaBrandt",
    "Rational",
    # Configuration
    "LossFunction",
    "ReprojectionPenalty",
    "Submanifold",
    # Results
    "SolveResult",
    # Metadata
    "__version__",
]
