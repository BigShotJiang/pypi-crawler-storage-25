# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Bundle adjustment estimator — Pythonic API."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from enum import IntEnum
from typing import TYPE_CHECKING, Any

import numpy as np

from vernier._core import (
    SE3,
    LossFunction,
    SolveResult,
    Submanifold,
    _ProjectionModel,
    resolve_loss,
    resolve_model,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


__all__ = ["Estimator"]


@dataclass
class _CameraBlock:
    uuid: uuid.UUID
    model: type[_ProjectionModel]
    intrinsics: np.ndarray
    distortion: np.ndarray
    fixed: tuple[str, ...]


@dataclass
class _FrameBlock:
    uuid: uuid.UUID
    pose: SE3
    submanifold: Submanifold


@dataclass
class _Observation:
    camera: uuid.UUID
    frame: uuid.UUID
    point_3d: np.ndarray
    pixel_2d: np.ndarray
    loss: LossFunction
    loss_scale: float


def _normalize_fixed(value: Any) -> str:
    if isinstance(value, IntEnum):
        return value.name.lower()
    return str(value).lower()


class Estimator:
    """Non-linear least-squares estimator for camera calibration and bundle adjustment.

    An :class:`Estimator` accumulates *cameras*, *frames*, and *observations*,
    then runs a Levenberg-Marquardt optimization to recover the underlying
    parameters. Cameras carry intrinsics and distortion; frames carry SE(3)
    poses; each observation links a 3D world point to a 2D pixel measurement
    through a (camera, frame) pair.

    Args:
        loss: Default robust loss for new observations. One of
            ``"none"``, ``"huber"``, ``"cauchy"``, ``"soft_l1"`` — or a
            :class:`LossFunction` value. Defaults to ``"huber"``.
        loss_scale: Default loss scale (in pixels). Defaults to ``1.0``.
    """

    def __init__(
        self,
        loss: str | LossFunction = "huber",
        loss_scale: float = 1.0,
    ) -> None:
        self._default_loss = resolve_loss(loss)
        self._default_loss_scale = float(loss_scale)
        self._cameras: dict[uuid.UUID, _CameraBlock] = {}
        self._frames: dict[uuid.UUID, _FrameBlock] = {}
        self._observations: list[_Observation] = []

    # ── Problem construction ────────────────────────────────────────────

    def add_camera(
        self,
        model: str | type[_ProjectionModel],
        K: NDArray[np.float64],
        distortion: NDArray[np.float64],
        fixed: tuple[Any, ...] | list[Any] = (),
    ) -> uuid.UUID:
        """Register a camera and return its handle.

        Args:
            model: Projection model — class (e.g. :class:`BrownConrady`)
                or its string name (``"brown_conrady"``).
            K: 3×3 intrinsic matrix.
            distortion: Distortion vector. Length depends on ``model``.
            fixed: Parameter names to hold constant during optimization.
                Accepts strings (``"k3"``, ``"fx"``) or
                :class:`Param` enum values.

        Returns:
            UUID handle for the newly registered camera.
        """
        K_arr = np.asarray(K, dtype=np.float64)
        dist_arr = np.asarray(distortion, dtype=np.float64)
        if K_arr.shape != (3, 3):
            raise ValueError(f"K must be 3x3, got {K_arr.shape}")
        camera_id = uuid.uuid4()
        self._cameras[camera_id] = _CameraBlock(
            uuid=camera_id,
            model=resolve_model(model),
            intrinsics=K_arr,
            distortion=dist_arr,
            fixed=tuple(_normalize_fixed(f) for f in fixed),
        )
        return camera_id

    def add_frame(
        self,
        pose: SE3,
        submanifold: Submanifold = Submanifold.SE3,
    ) -> uuid.UUID:
        """Register a frame (an SE(3) pose) and return its handle.

        Args:
            pose: Initial SE(3) pose.
            submanifold: Which DOFs to optimize. Defaults to
                :attr:`Submanifold.SE3` (full 6-DOF).

        Returns:
            UUID handle for the newly registered frame.
        """
        if not isinstance(pose, SE3):
            raise TypeError(f"pose must be SE3, got {type(pose).__name__}")
        if not isinstance(submanifold, Submanifold):
            raise TypeError(
                f"submanifold must be a Submanifold flag, got {type(submanifold).__name__}"
            )
        frame_id = uuid.uuid4()
        self._frames[frame_id] = _FrameBlock(uuid=frame_id, pose=pose, submanifold=submanifold)
        return frame_id

    def add_observation(
        self,
        camera: uuid.UUID,
        frame: uuid.UUID,
        point_3d: NDArray[np.float64],
        pixel_2d: NDArray[np.float64],
        loss: str | LossFunction | None = None,
        loss_scale: float | None = None,
    ) -> None:
        """Register a 3D-to-2D observation linking a camera and a frame.

        Args:
            camera: Camera handle (from :meth:`add_camera`).
            frame: Frame handle (from :meth:`add_frame`).
            point_3d: 3D world point ``(x, y, z)``.
            pixel_2d: 2D pixel measurement ``(u, v)``.
            loss: Override the estimator-wide default loss for this
                observation only.
            loss_scale: Override the estimator-wide default loss scale
                for this observation only.
        """
        if camera not in self._cameras:
            raise KeyError(f"unknown camera id: {camera}")
        if frame not in self._frames:
            raise KeyError(f"unknown frame id: {frame}")
        p3 = np.asarray(point_3d, dtype=np.float64)
        p2 = np.asarray(pixel_2d, dtype=np.float64)
        if p3.shape != (3,):
            raise ValueError(f"point_3d must have shape (3,), got {p3.shape}")
        if p2.shape != (2,):
            raise ValueError(f"pixel_2d must have shape (2,), got {p2.shape}")
        self._observations.append(
            _Observation(
                camera=camera,
                frame=frame,
                point_3d=p3,
                pixel_2d=p2,
                loss=resolve_loss(loss) if loss is not None else self._default_loss,
                loss_scale=(
                    float(loss_scale) if loss_scale is not None else self._default_loss_scale
                ),
            )
        )

    # ── Solving ─────────────────────────────────────────────────────────

    def solve(self, max_iterations: int = 200) -> SolveResult:
        """Run the optimization and return a :class:`SolveResult`.

        Args:
            max_iterations: Cap on solver iterations. Defaults to ``200``.
        """
        raise NotImplementedError("Estimator.solve is not yet implemented.")

    # ── Accessors ───────────────────────────────────────────────────────

    def get_camera_matrix(self, camera: uuid.UUID) -> NDArray[np.float64]:
        """Return the current 3×3 intrinsic matrix for ``camera``."""
        return self._cameras[camera].intrinsics.copy()

    def get_dist_coefficients(self, camera: uuid.UUID) -> NDArray[np.float64]:
        """Return the current distortion vector for ``camera``."""
        return self._cameras[camera].distortion.copy()

    def get_frame_pose(self, frame: uuid.UUID) -> SE3:
        """Return the current SE(3) pose for ``frame``."""
        return self._frames[frame].pose

    @property
    def num_cameras(self) -> int:
        """Number of registered cameras."""
        return len(self._cameras)

    @property
    def num_frames(self) -> int:
        """Number of registered frames."""
        return len(self._frames)

    @property
    def num_observations(self) -> int:
        """Number of registered observations."""
        return len(self._observations)

    def __repr__(self) -> str:
        return (
            f"Estimator(cameras={self.num_cameras}, "
            f"frames={self.num_frames}, "
            f"observations={self.num_observations})"
        )
