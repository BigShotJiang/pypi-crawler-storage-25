# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Core types: Lie groups, projection models, submanifold flags, loss enums."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Flag, IntEnum, auto

import numpy as np

# ── Lie groups ──────────────────────────────────────────────────────────


class SE3:
    """Rigid 3D transform — element of the Special Euclidean group SE(3).

    Backed by a 4×4 homogeneous matrix. Tangent-space operations
    (:meth:`exp`, :meth:`log`, :meth:`box_plus`) are provided by the
    native backend in a subsequent release.

    Args:
        matrix: 4×4 homogeneous transform. Defaults to identity.
    """

    __slots__ = ("_matrix",)

    def __init__(self, matrix: np.ndarray | None = None) -> None:
        if matrix is None:
            matrix = np.eye(4, dtype=np.float64)
        else:
            matrix = np.asarray(matrix, dtype=np.float64)
            if matrix.shape != (4, 4):
                raise ValueError(f"SE3 expects a 4x4 matrix, got shape {matrix.shape}")
        self._matrix = matrix

    @classmethod
    def identity(cls) -> SE3:
        """Construct the identity transform."""
        return cls()

    def matrix(self) -> np.ndarray:
        """Return a copy of the underlying 4×4 homogeneous matrix."""
        return self._matrix.copy()

    @property
    def rotation(self) -> np.ndarray:
        """3×3 rotation block."""
        return self._matrix[:3, :3].copy()

    @property
    def translation(self) -> np.ndarray:
        """Translation vector (3,)."""
        return self._matrix[:3, 3].copy()

    def __repr__(self) -> str:
        return f"SE3(translation={self.translation.tolist()})"


class SO3:
    """3D rotation — element of the Special Orthogonal group SO(3).

    Backed by a 3×3 orthonormal matrix.

    Args:
        matrix: 3×3 rotation matrix. Defaults to identity.
    """

    __slots__ = ("_matrix",)

    def __init__(self, matrix: np.ndarray | None = None) -> None:
        if matrix is None:
            matrix = np.eye(3, dtype=np.float64)
        else:
            matrix = np.asarray(matrix, dtype=np.float64)
            if matrix.shape != (3, 3):
                raise ValueError(f"SO3 expects a 3x3 matrix, got shape {matrix.shape}")
        self._matrix = matrix

    @classmethod
    def identity(cls) -> SO3:
        """Construct the identity rotation."""
        return cls()

    def matrix(self) -> np.ndarray:
        """Return a copy of the underlying 3×3 rotation matrix."""
        return self._matrix.copy()

    def __repr__(self) -> str:
        return f"SO3(matrix=\n{self._matrix})"


# ── Projection models ───────────────────────────────────────────────────


class _ProjectionModel:
    """Marker base class for projection-model trait objects."""

    name: str

    def __repr__(self) -> str:
        return f"<vernier.{type(self).__name__}>"


class BrownConrady(_ProjectionModel):
    """Brown-Conrady projection — the OpenCV-default radial-tangential model.

    Distortion vector: ``[k1, k2, p1, p2, k3]``.
    """

    name = "brown_conrady"

    class Param(IntEnum):
        """Parameter index for use with the ``fixed`` argument of
        :meth:`Estimator.add_camera`."""

        FX = 0
        FY = 1
        CX = 2
        CY = 3
        K1 = 4
        K2 = 5
        P1 = 6
        P2 = 7
        K3 = 8


class KannalaBrandt(_ProjectionModel):
    """Kannala-Brandt fisheye projection.

    Distortion vector: ``[k1, k2, k3, k4]``.
    """

    name = "kannala_brandt"

    class Param(IntEnum):
        FX = 0
        FY = 1
        CX = 2
        CY = 3
        K1 = 4
        K2 = 5
        K3 = 6
        K4 = 7


class Division(_ProjectionModel):
    """Single-parameter division model — lightweight radial distortion.

    Distortion vector: ``[k1, k2]``.
    """

    name = "division"

    class Param(IntEnum):
        FX = 0
        FY = 1
        CX = 2
        CY = 3
        K1 = 4
        K2 = 5


class Rational(_ProjectionModel):
    """Rational polynomial projection — handles complex optics.

    Distortion vector: ``[k1, k2, k3, k4, k5, k6, p1, p2]``.
    """

    name = "rational"

    class Param(IntEnum):
        FX = 0
        FY = 1
        CX = 2
        CY = 3
        K1 = 4
        K2 = 5
        K3 = 6
        K4 = 7
        K5 = 8
        K6 = 9
        P1 = 10
        P2 = 11


_MODEL_BY_NAME: dict[str, type[_ProjectionModel]] = {
    BrownConrady.name: BrownConrady,
    KannalaBrandt.name: KannalaBrandt,
    Division.name: Division,
    Rational.name: Rational,
}


def resolve_model(model: str | type[_ProjectionModel]) -> type[_ProjectionModel]:
    """Map a string or class to a projection-model class."""
    if isinstance(model, type) and issubclass(model, _ProjectionModel):
        return model
    if isinstance(model, str):
        try:
            return _MODEL_BY_NAME[model]
        except KeyError as exc:
            raise ValueError(
                f"unknown projection model: {model!r} (valid: {sorted(_MODEL_BY_NAME)})"
            ) from exc
    raise TypeError(
        f"model must be a projection class or its string name, got {type(model).__name__}"
    )


# ── Submanifold + loss enums ────────────────────────────────────────────


class Submanifold(Flag):
    """Bitflag selecting which DOFs of an :class:`SE3` frame are optimized."""

    NONE = 0
    X = auto()
    Y = auto()
    Z = auto()
    WX = auto()
    WY = auto()
    WZ = auto()
    TRANSLATION = X | Y | Z
    ROTATION = WX | WY | WZ
    SE3 = TRANSLATION | ROTATION


class LossFunction(IntEnum):
    """Robust loss applied to residuals during optimization."""

    NONE = 0
    HUBER = 1
    CAUCHY = 2
    SOFT_L1 = 3


class ReprojectionPenalty(IntEnum):
    """Strategy for handling out-of-image-bounds projections."""

    NONE = 0
    CLAMP = 1
    REJECT = 2


_LOSS_BY_NAME: dict[str, LossFunction] = {
    "none": LossFunction.NONE,
    "huber": LossFunction.HUBER,
    "cauchy": LossFunction.CAUCHY,
    "soft_l1": LossFunction.SOFT_L1,
}


def resolve_loss(loss: str | LossFunction) -> LossFunction:
    """Map a string or :class:`LossFunction` to a :class:`LossFunction`."""
    if isinstance(loss, LossFunction):
        return loss
    if isinstance(loss, str):
        try:
            return _LOSS_BY_NAME[loss.lower()]
        except KeyError as exc:
            raise ValueError(f"unknown loss: {loss!r} (valid: {sorted(_LOSS_BY_NAME)})") from exc
    raise TypeError(f"loss must be a LossFunction or string name, got {type(loss).__name__}")


# ── Result type ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SolveResult:
    """Outcome of a call to :meth:`Estimator.solve`.

    Attributes:
        converged: Whether the solver met its convergence criteria.
        rms: Root-mean-square reprojection error in pixels.
        iterations: Number of solver iterations executed.
        time: Wall-clock time spent in :meth:`solve`, in seconds.
    """

    converged: bool = False
    rms: float = float("nan")
    iterations: int = 0
    time: float = 0.0
