// Copyright (c) 2026 Vistralis Labs. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#include <nanobind/nanobind.h>

namespace nb = nanobind;

NB_MODULE(_vernier, m) {
  m.doc() = "Vernier native module.";
  m.attr("__abi_version__") = 0;
}
