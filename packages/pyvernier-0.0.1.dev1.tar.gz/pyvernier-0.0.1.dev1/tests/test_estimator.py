# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for the Estimator API: cameras, frames, observations, accessors."""

import numpy as np
import pytest

import vernier


@pytest.fixture
def K() -> np.ndarray:
    return np.array(
        [[1400.0, 0.0, 960.0], [0.0, 1400.0, 540.0], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )


def test_estimator_default_construction() -> None:
    estimator = vernier.Estimator()
    assert estimator.num_cameras == 0
    assert estimator.num_frames == 0
    assert estimator.num_observations == 0


def test_estimator_loss_options() -> None:
    vernier.Estimator(loss="huber", loss_scale=1.0)
    vernier.Estimator(loss="cauchy", loss_scale=0.5)
    vernier.Estimator(loss=vernier.LossFunction.SOFT_L1, loss_scale=2.0)


def test_unknown_loss_raises() -> None:
    with pytest.raises(ValueError, match="unknown loss"):
        vernier.Estimator(loss="not_a_loss")


def test_add_camera_string_model(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    camera = estimator.add_camera("brown_conrady", K, np.zeros(5), fixed=["k3"])
    assert estimator.num_cameras == 1
    assert np.allclose(estimator.get_camera_matrix(camera), K)
    assert estimator.get_dist_coefficients(camera).shape == (5,)


def test_add_camera_class_model(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    estimator.add_camera(
        vernier.BrownConrady,
        K,
        np.zeros(5),
        fixed=[vernier.BrownConrady.Param.K3],
    )
    assert estimator.num_cameras == 1


def test_unknown_model_raises(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    with pytest.raises(ValueError, match="unknown projection model"):
        estimator.add_camera("not_a_model", K, np.zeros(5))


def test_add_frame_default_submanifold() -> None:
    estimator = vernier.Estimator()
    frame = estimator.add_frame(vernier.SE3())
    assert estimator.num_frames == 1
    assert isinstance(estimator.get_frame_pose(frame), vernier.SE3)


def test_add_frame_translation_only_submanifold() -> None:
    estimator = vernier.Estimator()
    estimator.add_frame(vernier.SE3(), vernier.Submanifold.TRANSLATION)
    assert estimator.num_frames == 1


def test_add_frame_rejects_non_se3() -> None:
    estimator = vernier.Estimator()
    with pytest.raises(TypeError, match="SE3"):
        estimator.add_frame("not a pose")  # type: ignore[arg-type]


def test_add_observation_links_camera_and_frame(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    camera = estimator.add_camera("brown_conrady", K, np.zeros(5))
    frame = estimator.add_frame(vernier.SE3())
    estimator.add_observation(camera, frame, np.array([0.0, 0.0, 5.0]), np.array([960.0, 540.0]))
    assert estimator.num_observations == 1


def test_add_observation_validates_shapes(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    camera = estimator.add_camera("brown_conrady", K, np.zeros(5))
    frame = estimator.add_frame(vernier.SE3())
    with pytest.raises(ValueError, match=r"point_3d"):
        estimator.add_observation(camera, frame, np.array([0.0, 0.0]), np.array([960.0, 540.0]))


def test_add_observation_rejects_unknown_handles() -> None:
    import uuid

    estimator = vernier.Estimator()
    with pytest.raises(KeyError, match="unknown camera"):
        estimator.add_observation(uuid.uuid4(), uuid.uuid4(), np.zeros(3), np.zeros(2))


def test_repr_contains_problem_size(K: np.ndarray) -> None:
    estimator = vernier.Estimator()
    estimator.add_camera("brown_conrady", K, np.zeros(5))
    estimator.add_frame(vernier.SE3())
    rep = repr(estimator)
    assert "cameras=1" in rep
    assert "frames=1" in rep
