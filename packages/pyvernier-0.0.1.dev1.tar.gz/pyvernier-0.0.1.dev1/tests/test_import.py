# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Smoke tests — verify the package imports and is well-formed."""


def test_import() -> None:
    import vernier

    assert hasattr(vernier, "__version__")


def test_version_format() -> None:
    import vernier

    # Either set by importlib.metadata, or "unknown" in editable installs
    # without metadata. Both are acceptable.
    assert isinstance(vernier.__version__, str)
    assert len(vernier.__version__) > 0


def test_public_api_complete() -> None:
    """Every name in __all__ is importable from the top-level package."""
    import vernier

    for name in vernier.__all__:
        assert hasattr(vernier, name), f"vernier.__all__ promises {name!r} but it is not exported"


def test_native_extension_loads() -> None:
    """The compiled _vernier module must be importable — proves the wheel built."""
    from vernier import _vernier

    assert _vernier.__abi_version__ == 0
