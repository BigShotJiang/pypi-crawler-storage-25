# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for core types — Lie groups, projection models, enums."""

import numpy as np
import pytest

import vernier

# ── SE3 ─────────────────────────────────────────────────────────────────


def test_se3_default_is_identity() -> None:
    pose = vernier.SE3()
    assert np.allclose(pose.matrix(), np.eye(4))


def test_se3_identity_classmethod() -> None:
    assert np.allclose(vernier.SE3.identity().matrix(), np.eye(4))


def test_se3_rejects_wrong_shape() -> None:
    with pytest.raises(ValueError, match="4x4"):
        vernier.SE3(np.zeros((3, 3)))


def test_se3_translation_and_rotation_accessors() -> None:
    matrix = np.eye(4)
    matrix[:3, 3] = [1.0, 2.0, 3.0]
    pose = vernier.SE3(matrix)
    assert np.allclose(pose.translation, [1.0, 2.0, 3.0])
    assert np.allclose(pose.rotation, np.eye(3))


# ── SO3 ─────────────────────────────────────────────────────────────────


def test_so3_default_is_identity() -> None:
    rot = vernier.SO3.identity()
    assert np.allclose(rot.matrix(), np.eye(3))


def test_so3_rejects_wrong_shape() -> None:
    with pytest.raises(ValueError, match="3x3"):
        vernier.SO3(np.zeros((4, 4)))


# ── Submanifold ─────────────────────────────────────────────────────────


def test_submanifold_se3_is_translation_or_rotation() -> None:
    assert vernier.Submanifold.SE3 == (
        vernier.Submanifold.TRANSLATION | vernier.Submanifold.ROTATION
    )


def test_submanifold_arbitrary_axis_combinations() -> None:
    custom = vernier.Submanifold.X | vernier.Submanifold.Y | vernier.Submanifold.WZ
    assert vernier.Submanifold.X in custom
    assert vernier.Submanifold.Y in custom
    assert vernier.Submanifold.WZ in custom
    assert vernier.Submanifold.WX not in custom


# ── Projection models ───────────────────────────────────────────────────


def test_projection_model_param_indices() -> None:
    assert vernier.BrownConrady.Param.K3 == 8
    assert vernier.KannalaBrandt.Param.K4 == 7
    assert vernier.Division.Param.K2 == 5
    assert vernier.Rational.Param.P2 == 11


def test_projection_model_string_names() -> None:
    assert vernier.BrownConrady.name == "brown_conrady"
    assert vernier.KannalaBrandt.name == "kannala_brandt"
    assert vernier.Division.name == "division"
    assert vernier.Rational.name == "rational"


# ── Loss + penalty enums ────────────────────────────────────────────────


def test_loss_function_members_present() -> None:
    assert vernier.LossFunction.HUBER != vernier.LossFunction.CAUCHY
    assert vernier.LossFunction.NONE.value == 0


def test_reprojection_penalty_members_present() -> None:
    assert vernier.ReprojectionPenalty.CLAMP != vernier.ReprojectionPenalty.REJECT


# ── SolveResult ─────────────────────────────────────────────────────────


def test_solve_result_dataclass() -> None:
    result = vernier.SolveResult(converged=True, rms=0.31, iterations=8, time=0.076)
    assert result.converged
    assert result.iterations == 8
    assert result.rms == pytest.approx(0.31)
