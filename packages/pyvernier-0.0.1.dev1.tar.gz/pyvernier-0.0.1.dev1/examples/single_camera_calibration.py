# Copyright (c) 2026 Vistralis Labs. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Single-camera intrinsic calibration from a synthetic checkerboard sequence.

Builds a problem with one Brown-Conrady camera observing a planar pattern
across multiple frames. Each frame contributes one SE(3) pose to optimize
together with the shared intrinsics.
"""

from __future__ import annotations

import numpy as np

import vernier


def make_checkerboard(rows: int = 6, cols: int = 9, square: float = 0.025) -> np.ndarray:
    """Return a (rows*cols, 3) array of 3D points on a planar checkerboard."""
    xs = np.arange(cols) * square
    ys = np.arange(rows) * square
    grid = np.stack(np.meshgrid(xs, ys, indexing="xy"), axis=-1).reshape(-1, 2)
    return np.column_stack([grid, np.zeros(len(grid))])


def main() -> None:
    K = np.array(
        [[1400.0, 0.0, 960.0], [0.0, 1400.0, 540.0], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    distortion = np.zeros(5)

    estimator = vernier.Estimator(loss="huber", loss_scale=1.0)
    camera = estimator.add_camera(
        vernier.BrownConrady,
        K,
        distortion,
        fixed=[vernier.BrownConrady.Param.K3],
    )

    points_3d = make_checkerboard()
    n_frames = 12
    rng = np.random.default_rng(seed=0)

    for _ in range(n_frames):
        frame = estimator.add_frame(vernier.SE3(), vernier.Submanifold.SE3)
        for p3 in points_3d:
            # Synthetic 2D measurement; the real projection runs in solve().
            p2 = rng.uniform([0.0, 0.0], [1920.0, 1080.0])
            estimator.add_observation(camera, frame, p3, p2)

    print(estimator)
    print(f"  cameras:      {estimator.num_cameras}")
    print(f"  frames:       {estimator.num_frames}")
    print(f"  observations: {estimator.num_observations}")


if __name__ == "__main__":
    main()
