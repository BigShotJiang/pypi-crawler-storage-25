# Architecture

Vernier is split into a small set of orthogonal layers.

## Public API

```
src/vernier/
├── __init__.py        Public re-exports + version metadata
├── _core.py           Core types: SE3 / SO3, projection models,
│                      submanifold flags, loss + penalty enums,
│                      SolveResult dataclass.
└── estimator.py       Estimator — Pythonic problem-construction API
                       (add_camera, add_frame, add_observation, solve).
```

## Optimization core

Non-linear least squares is delegated to **Ceres Solver** with the autodiff
cost-function machinery. SE(3) / SO(3) manifold operations are provided by
**Sophus**.

### Projection-model dispatch

Each projection model is a stateless trait struct (`BrownConrady`,
`KannalaBrandt`, `Division`, `Rational`) with a templated `project<T>()`
function compatible with Ceres autodiff. Cameras are stored as
`std::variant<CameraBlock<Model>...>` — runtime model selection with
compile-time cost-functor instantiation. `std::visit` dispatches to the
correct `ReprojectionCost<Model>` in `AddResidualBlock`.

### Subset constraints

* **Per-parameter fixing** uses `ceres::SubsetManifold` to hold any
  subset of intrinsic parameters constant.
* **Submanifold pose constraints** use a custom manifold derived from the
  `Submanifold` bitflag — full SE(3), translation-only, rotation-only,
  or arbitrary per-axis combinations.

## Robust loss

Per-observation loss for outlier handling. Default Huber with 1.0 px
scale matches the standard in bundle adjustment. Cauchy and Soft-L1 are
also available for noisier data.
