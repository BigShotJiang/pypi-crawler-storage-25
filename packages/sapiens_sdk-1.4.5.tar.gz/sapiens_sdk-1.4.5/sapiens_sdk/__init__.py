"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_sdk import *
"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
