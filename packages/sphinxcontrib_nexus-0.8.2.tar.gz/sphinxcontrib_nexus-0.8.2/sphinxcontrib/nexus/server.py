"""MCP server for sphinxcontrib-nexus knowledge graph.

Exposes the full GraphQuery API as MCP tools, making the knowledge
graph queryable by Claude and other MCP clients.

Usage:
    nexus serve --db _nexus/graph.db
    # or via MCP config: command = "nexus", args = ["serve", "--db", "path/to/graph.db"]
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from sphinxcontrib.nexus._serialize import (
    assemble_communities,
    assemble_context,
    assemble_neighbors,
    assemble_processes,
    assemble_shortest_path,
    assemble_verification_coverage,
    to_dict,
    to_json,
)
from sphinxcontrib.nexus.export import load_sqlite
from sphinxcontrib.nexus.graph import KnowledgeGraph
from sphinxcontrib.nexus.query import GraphQuery

logger = logging.getLogger(__name__)

_mcp = FastMCP("nexus", instructions=(
    "Knowledge graph server for code and documentation. "
    "Query relationships between functions, classes, equations, "
    "theory pages, and external dependencies."
))

# Module-level state set by serve()
_query: GraphQuery | None = None
_db_path: Path | None = None
_project_root: Path | None = None
_db_mtime: float = 0.0


def _reload_if_stale() -> None:
    """Re-read the graph DB if it was modified since last load."""
    global _query, _db_mtime
    if _db_path is None:
        return
    try:
        current_mtime = _db_path.stat().st_mtime
    except OSError:
        return
    if current_mtime > _db_mtime:
        kg = load_sqlite(_db_path)
        _query = GraphQuery(kg)
        _db_mtime = current_mtime
        logger.info(
            "Reloaded graph: %d nodes, %d edges (db changed on disk)",
            kg.node_count, kg.edge_count,
        )


def _get_query() -> GraphQuery:
    if _query is None:
        raise RuntimeError("Graph not loaded. Call serve() first.")
    _reload_if_stale()
    return _query


# ------------------------------------------------------------------
# MCP Tools
# ------------------------------------------------------------------


@_mcp.tool()
def query(text: str, node_types: str = "", limit: int = 20) -> str:
    """Search the knowledge graph by keyword.

    Searches node names and display names. Returns nodes sorted by
    degree (most connected first).

    Args:
        text: Search text (case-insensitive substring match).
        node_types: Comma-separated node types to filter (e.g., "function,class").
                    Empty string means all types.
        limit: Maximum number of results (default 20).
    """
    q = _get_query()
    types = [t.strip() for t in node_types.split(",") if t.strip()] or None
    results = q.query(text, node_types=types, limit=limit)
    return to_json(to_dict(results))


@_mcp.tool()
def context(node_id: str) -> str:
    """Get a 360-degree view of a node: its attributes and all connections.

    Shows the node's properties plus all incoming and outgoing edges
    grouped by type. This is the primary tool for understanding a symbol.

    Args:
        node_id: Node ID (e.g., "py:function:sn_solver.solve_sn").
    """
    q = _get_query()
    return to_json(assemble_context(q, node_id))


@_mcp.tool()
def impact(
    target: str,
    direction: str = "upstream",
    max_depth: int = 3,
    edge_types: str = "",
) -> str:
    """Analyze blast radius: what depends on this symbol (upstream)
    or what this symbol depends on (downstream).

    Results are grouped by depth:
    - depth=1: WILL BREAK — direct callers/importers
    - depth=2: LIKELY AFFECTED — indirect dependents
    - depth=3: MAY NEED TESTING — transitive

    Args:
        target: Node ID of the symbol to analyze.
        direction: "upstream" (what depends on this) or "downstream" (what this depends on).
        max_depth: Maximum traversal depth (default 3).
        edge_types: Comma-separated edge types to follow (e.g., "calls,imports").
                    Empty means all edge types.
    """
    q = _get_query()
    types = [t.strip() for t in edge_types.split(",") if t.strip()] or None
    result = q.impact(target, direction=direction, max_depth=max_depth, edge_types=types)
    return to_json(to_dict(result))


@_mcp.tool()
def shortest_path(source: str, target: str, max_hops: int = 8) -> str:
    """Find the shortest path between two nodes.

    Useful for understanding how concepts connect:
    "How does theory/collision_probability relate to scipy.special.expn?"

    Args:
        source: Source node ID.
        target: Target node ID.
        max_hops: Maximum path length (default 8).
    """
    q = _get_query()
    return to_json(assemble_shortest_path(q, source, target, max_hops=max_hops))


@_mcp.tool()
def neighbors(
    node_id: str,
    direction: str = "both",
    edge_types: str = "",
) -> str:
    """Get direct connections of a node.

    Args:
        node_id: Node ID to query.
        direction: "in" (incoming), "out" (outgoing), or "both".
        edge_types: Comma-separated edge types to filter (e.g., "calls,contains").
    """
    q = _get_query()
    types = [t.strip() for t in edge_types.split(",") if t.strip()] or None
    return to_json(assemble_neighbors(q, node_id, direction=direction, edge_types=types))


@_mcp.tool()
def god_nodes(top_n: int = 10) -> str:
    """Get the most connected nodes in the graph.

    These are the central concepts/symbols with the most relationships.

    Args:
        top_n: Number of nodes to return (default 10).
    """
    q = _get_query()
    results = q.god_nodes(top_n=top_n)
    return to_json(to_dict(results))


@_mcp.tool()
def stats() -> str:
    """Get graph-level statistics: node/edge counts by type, density, etc."""
    q = _get_query()
    return to_json(to_dict(q.stats()))


@_mcp.tool()
def communities(min_size: int = 3) -> str:
    """Detect functional communities (groups of tightly connected symbols).

    Uses greedy modularity optimization to find natural groupings.

    Args:
        min_size: Minimum community size to include (default 3).
    """
    q = _get_query()
    return to_json(assemble_communities(q, min_size=min_size))


@_mcp.tool()
def detect_changes(scope: str = "all") -> str:
    """Detect which symbols changed in git and what they affect.

    Maps git changes to graph symbols and computes upstream impact.

    Args:
        scope: "staged", "unstaged", "all", or "branch" (diff vs main).
    """
    q = _get_query()
    if _project_root is None:
        return to_json({"error": "project_root not set"})
    result = q.detect_changes(_project_root, scope=scope)
    return to_json(to_dict(result))


@_mcp.tool()
def rename(old_name: str, new_name: str, dry_run: bool = True) -> str:
    """Analyze or execute a safe rename across the codebase.

    Finds all references via graph (high confidence) and regex (medium confidence).
    Set dry_run=False to apply the changes.

    Args:
        old_name: Current symbol name (e.g., "solve_sn").
        new_name: New name (e.g., "solve_discrete_ordinates").
        dry_run: If True, preview changes. If False, apply them.
    """
    q = _get_query()
    result = q.rename(
        old_name, new_name,
        project_root=_project_root,
        dry_run=dry_run,
    )
    return to_json(to_dict(result))


@_mcp.tool()
def provenance_chain(node_id: str) -> str:
    """Trace the full citation → equation → code chain for a symbol.

    Given a code function, shows which equations it implements and which
    literature citations those equations come from. The complete
    mathematical provenance.

    Args:
        node_id: Node ID of a code symbol or equation.
    """
    q = _get_query()
    return to_json(to_dict(q.provenance_chain(node_id)))


@_mcp.tool()
def verification_coverage(
    status_filter: str = "",
    limit: int = 0,
    offset: int = 0,
) -> str:
    """Map verification coverage: equation → code → test chains.

    Shows which equations are verified (have code + tests), which are
    implemented but untested, which are documented but unimplemented.

    Args:
        status_filter: Filter by status: "verified", "tested", "implemented",
                      "documented", "orphan_code". Empty = all.
        limit: Max number of entries to return. ``0`` (default) means
            no limit — return every matching entry. Use with ``offset``
            to page through very large result sets.
        offset: Number of entries to skip from the start of the list.
    """
    q = _get_query()
    filt = status_filter if status_filter else None
    return to_json(
        assemble_verification_coverage(
            q,
            status_filter=filt,
            limit=limit if limit > 0 else None,
            offset=offset,
        )
    )


@_mcp.tool()
def staleness() -> str:
    """Detect documentation pages that drifted from code.

    Compares git timestamps: if code was modified after its documentation
    page, the doc is flagged as stale. Only works with git and project_root set.
    """
    q = _get_query()
    result = q.staleness(_project_root)
    return to_json(to_dict(result))


@_mcp.tool()
def session_briefing() -> str:
    """Generate a structured briefing for starting a new session.

    Combines: graph stats, most connected nodes, stale docs,
    verification gaps, recent changes, and unresolved references.
    """
    q = _get_query()
    result = q.session_briefing(_project_root)
    return to_json(to_dict(result))


@_mcp.tool()
def retest(scope: str = "all") -> str:
    """Compute the minimum set of tests to re-run after changes.

    Uses git diff to find changed symbols, then traces upstream through
    the call graph to find all test functions that depend on them.

    Args:
        scope: "staged", "unstaged", "all", or "branch".
    """
    q = _get_query()
    if _project_root is None:
        return to_json({"error": "project_root not set"})
    result = q.retest(_project_root, scope=scope)
    return to_json(to_dict(result))


@_mcp.tool()
def trace_error(test_node_id: str) -> str:
    """Trace from a failing test back to the equations on its call path.

    Follows CALLS edges from the test function through the solver chain,
    collecting every equation and citation along the way. Helps diagnose
    which equation might be wrong when a test fails.

    Args:
        test_node_id: Node ID of the failing test function.
    """
    q = _get_query()
    result = q.trace_error(test_node_id)
    return to_json(to_dict(result))


@_mcp.tool()
def migration_plan(from_dep: str, to_dep: str = "") -> str:
    """Plan a dependency migration (e.g., numpy → jax).

    Finds all functions that use the dependency, groups them into phases
    by blast radius (leaf first, core last), and identifies documentation
    pages that need updating.

    Args:
        from_dep: Package to migrate from (e.g., "numpy", "scipy.special").
        to_dep: Package to migrate to (e.g., "jax.numpy"). Optional.
    """
    q = _get_query()
    result = q.migration_plan(from_dep, to_dep)
    return to_json(to_dict(result))


@_mcp.tool()
def processes(
    min_length: int = 3,
    limit: int = 0,
    offset: int = 0,
) -> str:
    """Detect execution flows: maximal call chains from entry points.

    Returns named sequences showing how functions call each other
    from entry point to leaf. Useful for understanding how code executes.

    Args:
        min_length: Minimum chain length to include (default 3).
        limit: Max number of chains to return. ``0`` (default) means
            no limit — return every chain meeting ``min_length``.
        offset: Number of chains to skip from the start of the list.
    """
    q = _get_query()
    return to_json(
        assemble_processes(
            q,
            min_length=min_length,
            limit=limit if limit > 0 else None,
            offset=offset,
        )
    )


@_mcp.tool()
def graph_query(pattern: str, limit: int = 50) -> str:
    """Execute a structured graph traversal query.

    Mini query language for finding edges matching a pattern.

    Syntax:
        source_type -edge_type-> target_type [WHERE field=value]

    Examples:
        "function -calls-> function" — all function-to-function calls
        "file -contains-> equation" — all equations in doc pages
        "* -implements-> equation" — code implementing equations
        "function -type_uses-> external WHERE name=numpy*" — numpy usage
        "* -cites-> *" — all citation edges

    Wildcards: * matches any type. name=prefix* for prefix match.

    Args:
        pattern: Query pattern (see examples above).
        limit: Maximum results (default 50).
    """
    q = _get_query()
    results = q.graph_query(pattern, limit=limit)
    return to_json(results)


@_mcp.tool()
def ingest(file_path: str, llm_command: str = "") -> str:
    """Ingest a document (PDF, paper, text) into the knowledge graph.

    Uses an LLM to extract concepts, equations, relationships, and
    citations from the document and adds them as graph nodes/edges.

    Args:
        file_path: Path to the document (PDF, txt, md, rst, tex).
        llm_command: Shell command for LLM (default: 'claude -p').
    """
    from sphinxcontrib.nexus.ingest import ingest_file

    q = _get_query()
    # Get the KnowledgeGraph from the query's internal graph
    from sphinxcontrib.nexus.graph import KnowledgeGraph
    kg = KnowledgeGraph()
    kg._graph = q._g

    p = Path(file_path)
    if not p.is_absolute() and _project_root:
        p = _project_root / p

    result = ingest_file(p, kg, llm_command=llm_command or None)
    return to_json({
        "source_file": result.source_file,
        "concepts_added": result.concepts_added,
        "equations_added": result.equations_added,
        "relationships_added": result.relationships_added,
        "citations_added": result.citations_added,
    })


@_mcp.tool()
def bridges(top_n: int = 10) -> str:
    """Find bridge nodes connecting separate communities.

    These are architectural hotspots with high betweenness centrality.
    Changing them has outsized impact across the codebase.

    Args:
        top_n: Number of bridges to return (default 10).
    """
    q = _get_query()
    results = q.bridges(top_n=top_n)
    return to_json(to_dict(results))


@_mcp.tool()
def callers(node_id: str, transitive: bool = False, max_depth: int = 3) -> str:
    """Get functions that call this symbol.

    Returns a clean list of caller nodes. Set transitive=True to walk
    the call graph up to max_depth.

    Args:
        node_id: Node ID of the function to query.
        transitive: If True, include indirect callers (depth 2+).
        max_depth: Maximum depth for transitive search (default 3).
    """
    q = _get_query()
    return to_json(to_dict(q.callers(node_id, transitive=transitive, max_depth=max_depth)))


@_mcp.tool()
def callees(node_id: str, transitive: bool = False, max_depth: int = 3) -> str:
    """Get functions that this symbol calls.

    Returns a clean list of callee nodes. Set transitive=True to walk
    the call graph down to max_depth.

    Args:
        node_id: Node ID of the function to query.
        transitive: If True, include indirect callees (depth 2+).
        max_depth: Maximum depth for transitive search (default 3).
    """
    q = _get_query()
    return to_json(to_dict(q.callees(node_id, transitive=transitive, max_depth=max_depth)))


@_mcp.tool()
def verification_audit(
    group_by: str = "",
    include_tests: bool = False,
) -> str:
    """Complete V&V audit in a single call.

    Combines verification_coverage + staleness into one actionable report.
    Returns: summary counts by status, prioritized gap list (equations
    without full verification chain), and optionally a ``grouped`` view
    bucketing those gaps by a chosen dimension.

    Args:
        group_by: Optional bucket dimension. One of ``"level"`` (by
            V&V level of the nearest test), ``"module"`` (by top-level
            Python package of the nearest implementing code node), or
            ``"equation"`` (by equation id). Empty string (default) —
            no grouping, flat ``gaps`` list only.
        include_tests: When True, the ``summary`` also reports
            ``tests_declared`` and ``tests_inferred`` counts so the
            caller can weigh how much of the "verified" total rides
            on explicit (marker/directive/registry) vs. heuristic
            evidence.
    """
    q = _get_query()
    result = q.verification_audit(
        _project_root,
        group_by=group_by or None,
        include_tests=include_tests,
    )
    return to_json(to_dict(result))


@_mcp.tool()
def verification_gaps(
    module: str = "",
    level: str = "",
) -> str:
    """Surface per-bucket V&V gaps for this project.

    Returns three lists: untagged tests (no ``vv_level`` marker),
    unverified equations (no incoming TESTS edge), and missing
    error-catcher tags (only populated when a consumer supplies an
    error catalog via a future config path).

    Args:
        module: Optional top-level Python package filter
            (e.g. ``"orpheus"``). Empty = no module filter.
        level: Optional V&V level filter, one of ``"L0"`` / ``"L1"``
            / ``"L2"`` / ``"L3"``. Empty = no level filter.
    """
    q = _get_query()
    result = q.verification_gaps(
        module=module or None,
        level=level or None,
    )
    return to_json(to_dict(result))


# ------------------------------------------------------------------
# MCP Resources
# ------------------------------------------------------------------


@_mcp.resource("nexus://graph/stats")
def resource_stats() -> str:
    """Graph overview: node/edge counts, types, density."""
    q = _get_query()
    return to_json(to_dict(q.stats()))


@_mcp.resource("nexus://graph/communities")
def resource_communities() -> str:
    """All detected functional communities."""
    q = _get_query()
    results = q.communities(min_size=2)
    summaries = []
    for c in results:
        member_names = [m.name for m in sorted(c.members, key=lambda n: n.degree, reverse=True)[:10]]
        summaries.append({"id": c.id, "label": c.label, "size": c.size, "top_members": member_names})
    return to_json(summaries)


@_mcp.resource("nexus://briefing")
def resource_briefing() -> str:
    """Session briefing: what you need to know right now."""
    q = _get_query()
    result = q.session_briefing(_project_root)
    return to_json(to_dict(result))


@_mcp.resource("nexus://graph/schema")
def resource_schema() -> str:
    """Graph schema: available node types and edge types."""
    from sphinxcontrib.nexus.graph import EdgeType, NodeType
    return to_json({
        "node_types": [t.value for t in NodeType],
        "edge_types": [t.value for t in EdgeType],
        "node_id_format": "<domain>:<type>:<qualified_name>",
        "examples": {
            "function": "py:function:sn_solver.solve_sn",
            "class": "py:class:collision_probability.CPMesh",
            "equation": "math:equation:diffusion-eq",
            "document": "doc:theory/discrete_ordinates",
            "external": "py:class:numpy.ndarray",
        },
    })


# ------------------------------------------------------------------
# Server entry point
# ------------------------------------------------------------------


def serve(
    db_path: Path,
    project_root: Path | None = None,
) -> None:
    """Load the graph and start the MCP server."""
    global _query, _db_path, _project_root, _db_mtime

    _db_path = db_path
    _project_root = project_root

    kg = load_sqlite(db_path)
    _query = GraphQuery(kg)
    _db_mtime = db_path.stat().st_mtime

    logger.info(
        "Loaded graph: %d nodes, %d edges from %s",
        kg.node_count, kg.edge_count, db_path,
    )

    _mcp.run()
