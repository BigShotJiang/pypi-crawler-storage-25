# RCA MCP Server

Enterprise-grade MCP server for Resource Central Agent (RCA), built with FastMCP.

## Install from PyPI

Project page: https://pypi.org/project/rca-mcp-server/

```bash
pip install rca-mcp-server
```

Verify installation:

```bash
rca-mcp --help
```

## Claude Desktop (STDIO) Configuration

Add this to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "rca-mcp-server": {
      "command": "rca-mcp"
    }
  }
}
```

## Optional: Inline Environment Variables

```json
{
  "mcpServers": {
    "rca-mcp-server": {
      "command": "rca-mcp",
      "env": {
        "RCA_API_KEY": "rca-cust-alpha-7788",
        "ORGANIZER": "your-email@company.com",
        "ENABLE_PROMPTS": "false",
        "LOG_LEVEL": "INFO",
        "LOG_FORMAT": "json"
      }
    }
  }
}
```

Notes:
- Keep JSON env values as strings (for example `"false"`).
- `ORGANIZER` is used as a fallback booking organizer in STDIO mode.

## Additional Documentation

- `docs/USER_INSTALLATION_AND_ENV.md`
- `docs/CUSTOMER_DEPLOYMENT.md`
- `docs/OPERATIONS.md`
