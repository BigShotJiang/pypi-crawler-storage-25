import os

import fastmcp
from fastmcp import FastMCP, Context
from rca_mcp.core.config import settings
from rca_mcp.core.auth import require_api_key
from rca_mcp.core.logger import setup_logging, logger

# Import modular components
from rca_mcp.tools.booking import register_booking_tools
from rca_mcp.resources.status import register_status_resources
from rca_mcp.prompts.receptionist import register_prompts

# Initialize FastMCP
mcp = FastMCP(
    settings.APP_NAME,
    version=settings.APP_VERSION,
    instructions="Enterprise MCP server for Resource Central Agent",
)

# Register Tools, Resources & Prompts
register_booking_tools(mcp)
register_status_resources(mcp)
if settings.ENABLE_PROMPTS:
    register_prompts(mcp)

# Setup Logging
setup_logging()

@mcp.tool()
@require_api_key
async def health_check(ctx: Context) -> str:
    """Check the health status of the MCP server and its connections."""
    logger.info("Health check triggered")
    return "OK"


# ASGI app for Uvicorn (SSE). Run from repo root: see README.
app = mcp.http_app(transport="sse")


def run():
    """Entry point for the server."""
    transport = os.getenv("MCP_TRANSPORT", "stdio").lower()

    if transport == "sse":
        # FastMCP binds from fastmcp.settings; some versions reject port= on run().
        port = int(os.getenv("PORT") or os.getenv("FASTMCP_PORT") or "8210")
        fastmcp.settings.port = port
        logger.info("Starting RCA MCP Server (SSE)", port=port)
        mcp.run(transport="sse")
    else:
        logger.info("Starting RCA MCP Server (stdio)")
        mcp.run(transport="stdio")

if __name__ == "__main__":
    run()
