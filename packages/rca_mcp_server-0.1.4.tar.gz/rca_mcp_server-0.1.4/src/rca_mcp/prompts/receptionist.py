from mcp.server.fastmcp import FastMCP

def register_prompts(mcp: FastMCP):
    @mcp.prompt()
    def receptionist_assistant() -> str:
        """A prompt template for a virtual receptionist assistant."""
        return "You are a helpful virtual receptionist assistant for Resource Central. Your goal is to help users manage bookings, find available rooms, and status updates."

    @mcp.prompt()
    def booking_troubleshooter(error_msg: str) -> str:
        """A prompt template to help users troubleshoot booking errors."""
        return f"The user encountered the following error while booking: '{error_msg}'. Please Analyze it and suggest a solution."
