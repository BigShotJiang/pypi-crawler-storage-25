import httpx
from typing import Optional
from fastmcp import FastMCP, Context
from rca_mcp.core.auth import require_api_key
from rca_mcp.core.logger import logger
from rca_mcp.core.config import settings

# Helper for calling the gateway
async def call_gateway(endpoint: str, method: str = "GET", data: Optional[dict] = None, params: Optional[dict] = None):
    url = f"{settings.GATEWAY_URL}/{endpoint}"
    async with httpx.AsyncClient() as client:
        if method == "POST":
            response = await client.post(url, json=data)
        else:
            response = await client.get(url, params=params)
        
        response.raise_for_status()
        return response.json()

def register_booking_tools(mcp: FastMCP):
    @mcp.tool()
    @require_api_key
    async def get_room_availability(room_id: str, date: str, ctx: Context) -> str:
        """Check availability for a specific room on a given date."""
        logger.info("Room availability check requested", room_id=room_id, date=date)
        
        try:
            result = await call_gateway("booking/availability", params={"roomId": room_id, "date": date})
            slots = ", ".join([f"{s['start']}-{s['end']}" for s in result['availableSlots']])
            return f"Room {result['roomName']} is available on {date} during these slots: {slots}."
        except Exception as e:
            logger.error("Failed to fetch availability", error=str(e))
            return f"Error: Could not fetch availability for room {room_id}. {str(e)}"

    @mcp.tool()
    @require_api_key
    async def create_room_booking(
        room_id: str, 
        start_time: str, 
        end_time: str, 
        subject: str,
        organizer: Optional[str] = None,
        ctx: Context = None
    ) -> str:
        """Create a new room booking in Resource Central."""
        logger.info("New booking requested", room_id=room_id, subject=subject)
        
        booking_data = {
            "roomId": room_id,
            "startTime": start_time,
            "endTime": end_time,
            "subject": subject,
            "organizer": organizer
        }

        try:
            result = await call_gateway("booking/create", method="POST", data=booking_data)
            return f"{result['message']} (ID: {result['bookingId']})"
        except Exception as e:
            logger.error("Failed to create booking", error=str(e))
            return f"Error: Failed to create booking for '{subject}'. {str(e)}"
