import json
from mcp.server.fastmcp import FastMCP
from rca_mcp.core.logger import logger

def register_status_resources(mcp: FastMCP):
    @mcp.resource("system://status")
    def get_system_status() -> str:
        """Get the current status of the MCP server and Resource Central connection."""
        logger.info("System status resource requested")
        status_data = {
            "status": "healthy",
            "connection": "connected",
            "service": "RCA MCP Server",
            "version": "0.1.0"
        }
        return json.dumps(status_data, indent=2)
