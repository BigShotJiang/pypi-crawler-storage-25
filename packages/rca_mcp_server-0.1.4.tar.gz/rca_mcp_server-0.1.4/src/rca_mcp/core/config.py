from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # App config
    APP_NAME: str = "RCA-MCP-Server"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    
    # Logging config
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"  # "json" or "text"
    
    # Security config
    ENABLE_PROMPTS: bool = True
    
    # MCA-Specific Config (Placeholders)
    GATEWAY_URL: str = "http://localhost:5039/api"
    # RC_API_BASE_URL: str = "http://localhost:8080/api"
    # RC_API_KEY: str = ""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = Settings()
