import functools
import inspect
import os

from mcp.shared.exceptions import McpError
from mcp.types import ErrorData
from fastmcp import Context

from rca_mcp.core.logger import logger


# Note: In FastMCP, Middleware can be implemented via decorators or 
# custom wrappers if the specific framework version supports global hooks.
# For stdio, we can implement a guard function/decorator.

# Mock Customer Secret Database (Enterprise Simulation)
MOCK_CUSTOMER_DATABASE = {
    "rca-cust-alpha-7788": {"name": "Customer Alpha", "tier": "premium"},
    "rca-cust-beta-9911": {"name": "Customer Beta", "tier": "standard"},
    "rca-cust-dev-0000": {"name": "Internal Developer", "tier": "admin"},
}

def validate_customer_key(api_key: str) -> dict:
    """
    Validates the provided API key against the mock database.
    Returns customer info if valid, raises McpError otherwise.
    """
    if not api_key:
        raise McpError(
            ErrorData(
                code=-32001,
                message="Unauthorized: Missing API Key. (For SSE: provide API-KEY header or api_key query param)",
            )
        )
    
    customer = MOCK_CUSTOMER_DATABASE.get(api_key)
    if not customer:
        logger.error("Invalid API Key used", provided_key=api_key)
        raise McpError(
            ErrorData(
                code=-32001,
                message=f"Unauthorized: The provided API key '{api_key}' is invalid or inactive.",
            )
        )
    
    logger.info("Customer authorized", customer=customer["name"], tier=customer["tier"])
    return customer

def require_api_key(func):
    """
    Decorator to enforce multi-customer API key check.
    API key sources priority: headers -> query params -> tool arg -> env.
    """
    sig = inspect.signature(func)
    accepts_organizer = "organizer" in sig.parameters

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # 1. Access Request Context (if available)
        ctx = next((a for a in args if isinstance(a, Context)), kwargs.get("ctx"))
        api_key = None
        organizer = None

        if ctx and hasattr(ctx, "request"):
            # A. Try HTTP Headers (Most secure - requested by user)
            # Normalizing header names (some clients use API-KEY, some X-API-KEY)
            api_key = ctx.request.headers.get("API-KEY") or ctx.request.headers.get("X-API-KEY")
            organizer = ctx.request.headers.get("organizer")
            
            # B. Try Query Parameters (Fallback)
            if not api_key:
                api_key = ctx.request.query_params.get("api_key")

        # 2. Backward compatibility for old clients sending api_key as tool arg
        if not api_key:
            api_key = kwargs.get("api_key")

        # 3. Fallback for stdio/local runs where no HTTP request exists
        if not api_key:
            api_key = os.getenv("RCA_API_KEY")

        # 4. Validate the API Key
        validate_customer_key(api_key)
        
        # 5. Fallback organizer for stdio/local runs
        if not organizer:
            organizer = os.getenv("ORGANIZER")

        # 6. Inject organizer into kwargs if found and missing in call
        if accepts_organizer and organizer and "organizer" not in kwargs:
            kwargs["organizer"] = organizer
            logger.info("Injected organizer", source="header_or_env", email=organizer)

        # Remove auth-only arg so wrapped tools don't need api_key in signature.
        kwargs.pop("api_key", None)

        return await func(*args, **kwargs)

    return wrapper
