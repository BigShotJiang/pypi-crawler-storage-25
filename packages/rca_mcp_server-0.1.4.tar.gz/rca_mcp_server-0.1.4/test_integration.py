import asyncio
import os
import sys

# Add src to path
sys.path.append(os.path.join(os.getcwd(), 'src'))

# Mock API key for testing
os.environ["RCA_API_KEY"] = "rca-cust-dev-0000"

from src.rca_mcp.main import mcp

async def test_tools():
    print("--- Testing get_room_availability ---")
    availability_result = await mcp.call_tool("get_room_availability", {"room_id": "Grand Hall", "date": "2024-04-10"})
    print(f"Result: {availability_result}")
    
    print("\n--- Testing create_room_booking ---")
    booking_result = await mcp.call_tool("create_room_booking", {
        "room_id": "Conference A", 
        "start_time": "2024-04-10T10:00:00", 
        "end_time": "2024-04-10T11:00:00", 
        "subject": "Integration Test Meeting"
    })
    print(f"Result: {booking_result}")

if __name__ == "__main__":
    asyncio.run(test_tools())
