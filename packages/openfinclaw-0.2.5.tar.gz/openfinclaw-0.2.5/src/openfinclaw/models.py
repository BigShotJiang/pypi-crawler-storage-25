"""Data models returned by the SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Thread:
    id: str
    status: str = "idle"
    title: str = ""
    total_turns: int = 0
    created_at: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> Thread:
        return cls(
            id=d["id"],
            status=d.get("status", "idle"),
            title=d.get("title", ""),
            total_turns=d.get("total_turns", 0),
            created_at=d.get("created_at"),
        )


@dataclass
class Run:
    id: str
    status: str = "pending"
    duration_ms: int | None = None
    num_turns: int = 0
    cost_usd: float = 0.0
    created_at: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> Run:
        return cls(
            id=d["id"],
            status=d.get("status", "pending"),
            duration_ms=d.get("duration_ms"),
            num_turns=d.get("num_turns", 0),
            cost_usd=d.get("cost_usd", 0.0) or 0.0,
            created_at=d.get("created_at"),
        )


@dataclass
class Message:
    role: str
    content: str

    @classmethod
    def from_dict(cls, d: dict) -> Message:
        return cls(role=d.get("role", "unknown"), content=d.get("content", ""))


@dataclass
class Event:
    """A single SSE event from the agent stream."""

    type: str  # TEXT_DELTA, TOOL_START, TOOL_DONE, AGENT_HANDOFF, RUN_FINISHED, ERROR, etc.
    data: dict = field(default_factory=dict)

    @property
    def text(self) -> str:
        """Shortcut for TEXT_DELTA content."""
        return self.data.get("delta", "")

    @property
    def tool_name(self) -> str:
        return self.data.get("toolName", "")

    @property
    def agent_name(self) -> str:
        return self.data.get("agentName", "")

    @property
    def error(self) -> str:
        return self.data.get("error", "")

    @property
    def is_error(self) -> bool:
        return self.type == "ERROR" or self.data.get("isError", False)
