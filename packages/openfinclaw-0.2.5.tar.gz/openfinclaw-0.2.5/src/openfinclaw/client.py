"""OpenFinClaw Python SDK — stateless HTTP client for the DeepAgent API."""

from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import date
from pathlib import Path

import httpx
from httpx_sse import connect_sse

from .exceptions import (
    AuthError,
    BudgetExhaustedError,
    ConflictError,
    ConnectionError,
    OpenFinClawError,
    RateLimitError,
)
from .models import Event, Message, Run, Thread

DEFAULT_BASE_URL = "https://api.openfinclaw.ai/agent"
DEFAULT_API_KEY = "79a29a66b189ec09"  # Built-in beta key (expires 2026-04-07)

# ── Built-in limits ─────────────────────────────────────────────────────────
_EXPIRE_DATE = date(2026, 4, 7)  # SDK stops working after this date
_DAILY_LIMIT = 500  # Max runs per day (client-side)
_USAGE_DIR = Path.home() / ".openfinclaw"
_USAGE_FILE = _USAGE_DIR / "usage.json"
_ACTIVATION_FILE = _USAGE_DIR / "activated.json"

# Valid activation codes (distribute these to testers)
_VALID_CODES = frozenset(
    {
        "OFC-8BA9-2FFD-593F",
        "OFC-2D12-3492-AB13",
        "OFC-D8FD-43E6-9FC4",
        "OFC-DA97-61E0-87E7",
        "OFC-A1C6-2FBA-E65B",
        "OFC-F73B-5790-301A",
        "OFC-BA41-42AB-6B83",
        "OFC-2E28-A5EC-7924",
        "OFC-3FAC-2806-036C",
        "OFC-D7AE-BE2D-8699",
    }
)


def _check_expiry() -> None:
    if date.today() > _EXPIRE_DATE:
        raise OpenFinClawError(
            f"This SDK has expired ({_EXPIRE_DATE}). Please contact support for a new version."
        )


def _check_activation() -> None:
    """Verify SDK is activated. Prompt for code on first use."""
    _USAGE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(_ACTIVATION_FILE.read_text())
        if data.get("activated"):
            return
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    # Not activated — prompt user
    print("=" * 50)
    print("  OpenFinClaw SDK — Activation Required")
    print("=" * 50)
    for attempt in range(3):
        code = input("  Enter activation code: ").strip().upper()
        if code in _VALID_CODES:
            _ACTIVATION_FILE.write_text(
                json.dumps({"activated": True, "code": code, "date": date.today().isoformat()})
            )
            print("  Activated successfully!\n")
            return
        remaining = 2 - attempt
        if remaining > 0:
            print(f"  Invalid code. {remaining} attempts remaining.")
        else:
            print("  Activation failed.")
    raise OpenFinClawError(
        "Invalid activation code. Please contact support to obtain a valid code."
    )


def _load_usage() -> dict:
    try:
        return json.loads(_USAGE_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_usage(data: dict) -> None:
    _USAGE_DIR.mkdir(parents=True, exist_ok=True)
    _USAGE_FILE.write_text(json.dumps(data))


def _check_and_increment_daily() -> int:
    """Check daily usage, increment counter, return current count. Raises on limit."""
    today = date.today().isoformat()
    usage = _load_usage()
    if usage.get("date") != today:
        usage = {"date": today, "count": 0}
    count = usage["count"]
    if count >= _DAILY_LIMIT:
        raise RateLimitError(f"Daily limit reached: {count}/{_DAILY_LIMIT}")
    usage["count"] = count + 1
    _save_usage(usage)
    return count + 1


class OpenFinClawClient:
    """Synchronous client for the OpenFinClaw DeepAgent API.

    Usage::

        from openfinclaw import OpenFinClawClient

        client = OpenFinClawClient(api_key="your-key")
        thread = client.create_thread()
        for event in client.stream(thread.id, "分析茅台"):
            if event.type == "TEXT_DELTA":
                print(event.text, end="", flush=True)
    """

    def __init__(
        self,
        api_key: str = DEFAULT_API_KEY,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        _check_expiry()
        _check_activation()
        headers: dict[str, str] = {"X-API-Key": api_key}
        self._http = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
            proxy=None,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> OpenFinClawClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # ── API methods ─────────────────────────────────────────────────────

    def health(self) -> dict:
        return self._get("/api/health")

    def create_thread(self, title: str = "SDK Session") -> Thread:
        data = self._post("/api/threads", json={"title": title})
        return Thread.from_dict(data)

    def list_threads(self) -> list[Thread]:
        data = self._get("/api/threads")
        return [Thread.from_dict(t) for t in data]

    def list_messages(self, thread_id: str, limit: int = 20) -> list[Message]:
        data = self._get(f"/api/threads/{thread_id}/messages", params={"limit": limit})
        return [Message.from_dict(m) for m in data]

    def list_runs(self, thread_id: str) -> list[Run]:
        data = self._get(f"/api/threads/{thread_id}/runs")
        return [Run.from_dict(r) for r in data]

    def cancel_run(self, thread_id: str, run_id: str) -> bool:
        resp = self._http.post(f"/api/threads/{thread_id}/runs/{run_id}/cancel")
        return resp.status_code == 200

    def stream(
        self,
        thread_id: str,
        message: str,
        *,
        stream_timeout: float = 600.0,
    ) -> Iterator[Event]:
        """Send a message and yield SSE events as they arrive.

        Raises:
            ConflictError: Thread is already running.
            RateLimitError: Daily limit or budget exhausted.
            AuthError: Invalid or missing API key.
        """
        _check_expiry()
        _check_and_increment_daily()

        try:
            with connect_sse(
                self._http,
                "POST",
                f"/api/threads/{thread_id}/runs",
                json={"message": message},
                headers={"Accept": "text/event-stream"},
                timeout=httpx.Timeout(timeout=stream_timeout, connect=30.0),
            ) as sse:
                status = sse.response.status_code
                if status in (401, 403, 409, 429):
                    # Must read() before accessing .text on a streaming response
                    sse.response.read()
                    detail = sse.response.text
                    if status == 409:
                        raise ConflictError("Thread is already running")
                    if status == 429:
                        if "Daily limit" in detail:
                            raise RateLimitError(detail)
                        raise BudgetExhaustedError(detail)
                    raise AuthError(detail)
                sse.response.raise_for_status()

                for event in sse.iter_sse():
                    try:
                        data = json.loads(event.data)
                    except (json.JSONDecodeError, TypeError):
                        continue
                    yield Event(type=event.event, data=data)
        except (httpx.RemoteProtocolError, httpx.ReadError):
            yield Event(
                type="ERROR",
                data={"error": "Server closed connection unexpectedly. The backend may be down."},
            )
        except httpx.ReadTimeout:
            yield Event(
                type="ERROR",
                data={"error": "Request timed out waiting for server response."},
            )

    # ── Internal helpers ────────────────────────────────────────────────

    def _get(self, path: str, **kwargs: object) -> object:
        try:
            resp = self._http.get(path, **kwargs)
        except httpx.ConnectError as e:
            raise ConnectionError(str(e)) from e
        self._check_response(resp)
        return resp.json()

    def _post(self, path: str, **kwargs: object) -> object:
        try:
            resp = self._http.post(path, **kwargs)
        except httpx.ConnectError as e:
            raise ConnectionError(str(e)) from e
        self._check_response(resp)
        return resp.json()

    @staticmethod
    def _check_response(resp: httpx.Response) -> None:
        if resp.status_code in (401, 403):
            raise AuthError(resp.text)
        if resp.status_code == 429:
            detail = resp.text
            if "Daily limit" in detail:
                raise RateLimitError(detail)
            raise BudgetExhaustedError(detail)
        resp.raise_for_status()
