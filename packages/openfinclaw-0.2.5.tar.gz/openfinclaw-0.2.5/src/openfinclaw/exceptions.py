"""SDK exceptions."""


class OpenFinClawError(Exception):
    """Base exception for all SDK errors."""


class AuthError(OpenFinClawError):
    """Missing or invalid API key (401/403)."""


class RateLimitError(OpenFinClawError):
    """Daily request limit exceeded (429)."""

    def __init__(self, detail: str = "Daily limit reached"):
        super().__init__(detail)
        self.detail = detail


class BudgetExhaustedError(OpenFinClawError):
    """Thread budget exhausted (429)."""


class ConflictError(OpenFinClawError):
    """Thread is already running (409)."""


class ConnectionError(OpenFinClawError):  # noqa: A001
    """Cannot connect to server."""
