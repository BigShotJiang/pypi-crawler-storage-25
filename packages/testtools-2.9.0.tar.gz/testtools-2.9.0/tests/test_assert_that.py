from collections.abc import Callable
from doctest import ELLIPSIS
from typing import Any

from testtools import (
    TestCase,
)
from testtools.assertions import (
    assert_that,
)
from testtools.content import (
    TracebackContent,
)
from testtools.matchers import (
    Annotate,
    DocTestMatches,
    Equals,
)
from testtools.matchers import (
    Matcher as BaseMatcher,
)
from testtools.matchers import (
    Mismatch as BaseMismatch,
)


class AssertThatTests:
    """A mixin containing shared tests for assertThat and assert_that."""

    # These are provided by TestCase when mixed in
    assertRaises: Callable[..., Any]
    assertEqual: Callable[..., Any]
    assertFalse: Callable[..., Any]
    failureException: Any  # Inherited from TestCase

    def assert_that_callable(self, *args, **kwargs):
        raise NotImplementedError

    def assertFails(self, message, function, *args, **kwargs):
        """Assert that function raises a failure with the given message."""
        failure = self.assertRaises(self.failureException, function, *args, **kwargs)
        self.assert_that_callable(failure, DocTestMatches(message, ELLIPSIS))

    def test_assertThat_matches_clean(self):
        class Matcher(BaseMatcher[str]):
            def match(self, foo: str) -> None:
                return None

        self.assert_that_callable("foo", Matcher())

    def test_assertThat_mismatch_raises_description(self):
        calls = []

        class Mismatch(BaseMismatch):
            def __init__(self, thing: str) -> None:
                self.thing = thing

            def describe(self) -> str:
                calls.append(("describe_diff", self.thing))
                return "object is not a thing"

            def get_details(self):
                return {}

        class Matcher(BaseMatcher[str]):
            def match(self, thing: str) -> Mismatch | None:
                calls.append(("match", thing))
                return Mismatch(thing)

            def __str__(self) -> str:
                calls.append(("__str__", None))
                return "a description"

        # Create a test class that inherits from the actual test class
        test_self = self

        class Test(test_self.__class__):
            def test(self):
                test_self.assert_that_callable("foo", Matcher())

        result = Test("test").run()
        self.assertEqual(
            [
                ("match", "foo"),
                ("describe_diff", "foo"),
            ],
            calls,
        )
        self.assertFalse(result.wasSuccessful())

    def test_assertThat_output(self):
        matchee = "foo"
        matcher = Equals("bar")
        mismatch = matcher.match(matchee)
        assert mismatch is not None
        expected = mismatch.describe()
        self.assertFails(expected, self.assert_that_callable, matchee, matcher)

    def test_assertThat_message_is_annotated(self):
        matchee = "foo"
        matcher = Equals("bar")
        mismatch = Annotate("woo", matcher).match(matchee)
        assert mismatch is not None
        expected = mismatch.describe()
        self.assertFails(expected, self.assert_that_callable, matchee, matcher, "woo")

    def test_assertThat_verbose_output(self):
        matchee = "foo"
        matcher = Equals("bar")
        mismatch = matcher.match(matchee)
        assert mismatch is not None
        expected = (
            f"Match failed. Matchee: {matchee!r}\nMatcher: {matcher}\n"
            f"Difference: {mismatch.describe()}\n"
        )
        self.assertFails(
            expected, self.assert_that_callable, matchee, matcher, verbose=True
        )

    def get_error_string(self, e):
        """Get the string showing how 'e' would be formatted in test output.

        This is a little bit hacky, since it's designed to give consistent
        output regardless of Python version.

        In testtools, TestResult._exc_info_to_unicode is the point of dispatch
        between various different implementations of methods that format
        exceptions, so that's what we have to call. However, that method cares
        about stack traces and formats the exception class. We don't care
        about either of these, so we take its output and parse it a little.
        """
        error = TracebackContent((e.__class__, e, None), self).as_text()
        # We aren't at all interested in the traceback.
        if error.startswith("Traceback (most recent call last):\n"):
            lines = error.splitlines(True)[1:]
            for i, line in enumerate(lines):
                if not line.startswith(" "):
                    break
            error = "".join(lines[i:])
        # We aren't interested in how the exception type is formatted.
        _exc_class, error = error.split(": ", 1)
        return error

    def test_assertThat_verbose_unicode(self):
        # When assertThat is given matchees or matchers that contain non-ASCII
        # unicode strings, we can still provide a meaningful error.
        matchee = "\xa7"
        matcher = Equals("a")
        mismatch = matcher.match(matchee)
        assert mismatch is not None
        expected = "Match failed. Matchee: {}\nMatcher: {}\nDifference: {}\n\n".format(
            repr(matchee).replace("\\xa7", matchee),
            matcher,
            mismatch.describe(),
        )
        e = self.assertRaises(
            self.failureException,
            self.assert_that_callable,
            matchee,
            matcher,
            verbose=True,
        )
        self.assertEqual(expected, self.get_error_string(e))


class TestAssertThatFunction(AssertThatTests, TestCase):
    def assert_that_callable(self, *args, **kwargs):
        return assert_that(*args, **kwargs)


class TestAssertThatMethod(AssertThatTests, TestCase):
    def assert_that_callable(self, *args, **kwargs):
        return self.assertThat(*args, **kwargs)


def test_suite():
    from unittest import TestLoader

    return TestLoader().loadTestsFromName(__name__)
