// probe_vercel.js —— 0.11.9m 乾坤镜 Vercel AI SDK 适配层
// 职责：在 Vercel AI SDK LLM 调用和 Stream 分块中注入乾坤镜探针调用
// 依赖：_js_base.js, probe_node.js（零 npm 依赖）

const crypto = require('crypto');
const { makeAdapterInit, intercept } = require('./_js_base');
const probe = require('../probe_node');

function _computeHash(text) {
  if (!text) return null;
  return crypto.createHash('sha256').update(String(text)).digest('hex').substring(0, 16);
}

function _getContentMaxLen() {
  const val = process.env.MING_CONTENT_MAX_LEN;
  if (val === undefined || val === '') return 2000;
  const v = parseInt(val, 10);
  if (isNaN(v)) return 2000;
  return v === 0 ? 0 : v;
}

function truncate(s, maxLen) {
  if (maxLen === undefined || maxLen === null) maxLen = _getContentMaxLen();
  if (maxLen === 0) return s;
  const str = String(s);
  if (str.length > maxLen) return str.substring(0, maxLen) + '...';
  return str;
}

function _patch(probe) {
  if (typeof globalThis.ai === 'undefined') return;
  const ai = globalThis.ai;

    // 1. generateText - 添加 llm_output
    const origGenerateText = ai.generateText;
    ai.generateText = async function(...args) {
      const start = Date.now();
      const result = await origGenerateText.apply(this, args);
      const latencyMs = Date.now() - start;

      // 发射 llm_invoke 事件
      probe.emit('llm_invoke', {
        layer_agent: { step_id: 'generateText', session_id: 'unknown', agent_name: 'vercel-ai' },
        layer_llm: { model: result.model || 'unknown', input_tokens: result.usage?.promptTokens || 0, output_tokens: result.usage?.completionTokens || 0, latency_ms: latencyMs, cache_hit: false },
        layer_network: { target_host: 'llm_api', status_code: 200 }
      });

      // 发射 llm_output 事件
      const outputText = result && (result.text || result.content);
      if (outputText) {
        probe.emit('llm_output', {
          layer_agent: { step_id: 'generateText', session_id: 'unknown', agent_name: 'vercel-ai' },
          layer_llm: {
            output_text: truncate(outputText),
            output_text_hash: _computeHash(outputText)
          },
          layer_network: { target_host: 'llm_api' }
        });
      }

      return result;
    };

    // 2. streamText - 添加 llm_output（在流结束时）
    const origStreamText = ai.streamText;
    ai.streamText = async function(...args) {
      const stream = await origStreamText.apply(this, args);
      
      // 包装流以在结束时发射事件
      const origOnFinal = stream.onFinal;
      stream.onFinal = async function(callback) {
        return origOnFinal.call(this, async (result) => {
          // 发射 llm_invoke 事件
          probe.emit('llm_invoke', {
            layer_agent: { step_id: 'streamText', session_id: 'unknown', agent_name: 'vercel-ai' },
            layer_llm: { model: result.model || 'unknown', input_tokens: result.usage?.promptTokens || 0, output_tokens: result.usage?.completionTokens || 0, latency_ms: 0, cache_hit: false },
            layer_network: { target_host: 'llm_api', status_code: 200 }
          });

          // 发射 llm_output 事件
          const outputText = result && (result.text || result.content);
          if (outputText) {
            probe.emit('llm_output', {
              layer_agent: { step_id: 'streamText', session_id: 'unknown', agent_name: 'vercel-ai' },
              layer_llm: {
                output_text: truncate(outputText),
                output_text_hash: _computeHash(outputText)
              },
              layer_network: { target_host: 'llm_api' }
            });
          }

          return callback ? callback(result) : result;
        });
      };

      return stream;
    };
  }

module.exports = { initVercelProbe: makeAdapterInit('vercel-ai', _patch) };
