// probe_langchain_go.go —— v0.9.3 乾坤镜 LangChainGo 适配层
// 职责：在 LangChainGo LLM 调用和 Tool 执行中注入乾坤镜探针调用
// 依赖：_go_builders.go, probe_go.go（零第三方依赖）

package probe

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"strconv"
	"time"
)

type LangChainGoProbe struct{ *Probe }

func NewLangChainGoProbe(system, mode string) *LangChainGoProbe {
	return &LangChainGoProbe{Probe: New(system, mode)}
}

func _computeHash(text string) string {
	if text == "" {
		return ""
	}
	hash := sha256.Sum256([]byte(text))
	return hex.EncodeToString(hash[:])[:16]
}

func getContentMaxLen() int {
	val := os.Getenv("MING_CONTENT_MAX_LEN")
	if val == "" {
		return 2000
	}
	v, err := strconv.Atoi(val)
	if err != nil {
		return 2000
	}
	if v == 0 {
		return 0
	}
	return v
}

func truncate(s string, maxLen int) string {
	if maxLen == 0 {
		return s
	}
	if len(s) > maxLen {
		return s[:maxLen] + "..."
	}
	return s
}

func (p *LangChainGoProbe) EmitLLMInvoke(model string, inputTokens, outputTokens int, latencyMs float64, err error) {
	if err != nil {
		p.Probe.Emit("error", BuildErrorEvent("llm", "unknown", "langchain-go", err.Error(), err.Error()))
		return
	}
	p.Probe.Emit("llm_invoke", BuildLLMEvent("llm", "unknown", "langchain-go", model, latencyMs, inputTokens, outputTokens))
}

func (p *LangChainGoProbe) EmitLLMOutput(outputText, sessionID string) {
	if outputText == "" {
		return
	}
	p.Probe.Emit("llm_output", map[string]interface{}{
		"layer_agent": map[string]interface{}{
			"step_id":    "llm",
			"session_id": sessionID,
			"agent_name": "langchain-go",
		},
		"layer_llm": map[string]interface{}{
			"output_text":      truncate(outputText, getContentMaxLen()),
			"output_text_hash": _computeHash(outputText),
		},
		"layer_network": map[string]interface{}{
			"target_host": "llm_api",
		},
	})
}

func (p *LangChainGoProbe) EmitToolCall(toolName string, args map[string]interface{}, result string, executionMs float64, err error) {
	if err != nil {
		p.Probe.Emit("error", BuildErrorEvent("tool", "unknown", "langchain-go", err.Error(), err.Error()))
		return
	}
	p.Probe.Emit("tool_call", BuildToolEvent("tool", "unknown", "langchain-go", toolName, executionMs, args, result))
}

func (p *LangChainGoProbe) EmitMemoryRetrieve(query string, resultsCount int, latencyMs float64, err error) {
	if err != nil {
		p.Probe.Emit("error", BuildErrorEvent("retrieve", "unknown", "langchain-go", err.Error(), err.Error()))
		return
	}
	p.Probe.Emit("memory_retrieve", BuildMemoryEvent("retrieve", "unknown", "langchain-go", "vector_index", latencyMs, query, resultsCount))
}

func (p *LangChainGoProbe) EmitStepStart(stepID, sessionID string) {
	p.Probe.Emit("agent_step_start", map[string]interface{}{
		"layer_agent": map[string]interface{}{
			"step_id":     stepID,
			"session_id":  sessionID,
			"agent_name":  "langchain-go",
			"step_status": "start",
		},
		"layer_network": map[string]interface{}{
			"target_host": "local",
		},
	})
}

func (p *LangChainGoProbe) EmitStepFinish(stepID, sessionID string) {
	p.Probe.Emit("agent_step_finish", map[string]interface{}{
		"layer_agent": map[string]interface{}{
			"step_id":     stepID,
			"session_id":  sessionID,
			"agent_name":  "langchain-go",
			"step_status": "finish",
		},
		"layer_network": map[string]interface{}{
			"target_host": "local",
		},
	})
}

func (p *LangChainGoProbe) WrapLLMGenerate(fn func() (string, int, int, error)) (string, error) {
	start := time.Now()
	result, inTok, outTok, err := fn()
	latencyMs := float64(time.Since(start).Milliseconds())
	
	p.EmitLLMInvoke("unknown", inTok, outTok, latencyMs, err)
	if err == nil && result != "" {
		p.EmitLLMOutput(result, "unknown")
	}
	return result, err
}

func (p *LangChainGoProbe) WrapToolExecute(toolName string, args map[string]interface{}, fn func() (string, error)) (string, error) {
	start := time.Now()
	result, err := fn()
	p.EmitToolCall(toolName, args, result, float64(time.Since(start).Milliseconds()), err)
	return result, err
}

func (p *LangChainGoProbe) WrapChainCall(fn func() (string, error)) (string, error) {
	stepID := "chain"
	sessionID := "unknown"
	
	p.EmitStepStart(stepID, sessionID)
	result, err := fn()
	p.EmitStepFinish(stepID, sessionID)
	
	return result, err
}
