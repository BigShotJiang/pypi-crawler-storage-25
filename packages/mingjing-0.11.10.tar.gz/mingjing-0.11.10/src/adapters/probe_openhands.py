# probe_openhands.py —— v0.11.9m 乾坤镜 OpenHands 适配层
# 职责：在 OpenHands 文件/Shell/浏览器操作中注入乾坤镜探针调用
# 依赖：_python_base.py, _payload_builders.py（零第三方依赖）

from adapters._python_base import make_adapter_init, instrumented
from adapters._payload_builders import (
    build_llm_event,
    build_llm_output_event,
    build_tool_event,
    build_step_event,
    build_step_start_event,
    build_step_finish_event,
    _extract_tokens,
    _extract_finish_reason,
)
import os


def _get_content_max_len():
    val = os.environ.get("MING_CONTENT_MAX_LEN")
    if val is None:
        return 2000
    try:
        v = int(val)
        return 0 if v == 0 else v
    except ValueError:
        return 2000


def truncate(s, max_len=None):
    if max_len is None:
        max_len = _get_content_max_len()
    if max_len == 0:
        return s
    if s and len(s) > max_len:
        return s[:max_len] + f"...[truncated {len(s) - max_len} chars]"
    return s


def _extract_oh_tokens(response):
    """OpenHands LLM 返回通常是 dict 或 ChatCompletion"""
    if response is None:
        return None, None
    if isinstance(response, dict):
        usage = response.get("usage")
        if usage:
            return (usage.get("prompt_tokens"), usage.get("completion_tokens"))
    usage = getattr(response, "usage", None)
    if usage:
        return (
            getattr(usage, "prompt_tokens", None),
            getattr(usage, "completion_tokens", None),
        )
    return None, None


def _monkey_patch(probe):
    try:
        from openhands.controller.agent_controller import AgentController

        original_step = AgentController.step

        def patched_step(self, *args, **kwargs):
            probe.emit(
                "agent_step_start",
                build_step_start_event(
                    step_id="step",
                    session_id=getattr(self, "sid", None),
                    agent_name="openhands",
                    target_host="local",
                ),
            )
            try:
                result = original_step(self, *args, **kwargs)
                probe.emit(
                    "agent_step_finish",
                    build_step_finish_event(
                        step_id="step",
                        session_id=getattr(self, "sid", None),
                        agent_name="openhands",
                        target_host="local",
                    ),
                )
                return result
            except Exception:
                probe.emit(
                    "agent_step_finish",
                    build_step_finish_event(
                        step_id="step",
                        session_id=getattr(self, "sid", None),
                        agent_name="openhands",
                        target_host="local",
                    ),
                )
                raise

        AgentController.step = patched_step

        from openhands.llm.llm import LLM

        original_completion = LLM.completion

        def patched_completion(self, *args, **kwargs):
            # 发射 llm_invoke 事件（原有逻辑）
            import time

            start = time.time()
            result = original_completion(self, *args, **kwargs)
            latency_ms = (time.time() - start) * 1000

            probe.emit(
                "llm_invoke",
                build_llm_event(
                    step_id="llm",
                    agent_name="openhands",
                    model=getattr(self, "model", None),
                    latency_ms=latency_ms,
                    response=result,
                    kwargs={
                        "input_tokens": _extract_oh_tokens(result)[0],
                        "output_tokens": _extract_oh_tokens(result)[1],
                        "finish_reason": _extract_finish_reason(result, kwargs),
                    },
                ),
            )

            # 发射 llm_output 事件
            output_text = None
            if result:
                if isinstance(result, dict):
                    output_text = result.get("content") or result.get("text")
                elif hasattr(result, "content"):
                    output_text = result.content
                elif hasattr(result, "text"):
                    output_text = result.text

            if output_text:
                probe.emit(
                    "llm_output",
                    build_llm_output_event(
                        step_id="llm",
                        agent_name="openhands",
                        output_text=truncate(output_text),
                        target_host="local",
                    ),
                )
            return result

        LLM.completion = patched_completion

        from openhands.runtime.base import Runtime

        Runtime.run = instrumented(
            probe,
            "tool_call",
            lambda s, r, lat, a, k: build_tool_event(
                tool_name=k.get("tool_name") or a[0] if a else "shell",
                execution_ms=lat,
                tool_args={"command": str(a[0])[:200] if a else ""},
                tool_result=r,
                target_host="local",
                success=r is not None and not isinstance(r, Exception),
            ),
            {"layer_agent": {"agent_name": "openhands"}},
        )(Runtime.run)

    except ImportError:
        pass


init_openhands_probe = make_adapter_init(_monkey_patch, "openhands")
