# lit_crossval.py —— 0.11.9m 交叉验证器
# 职责：在诊断主循环后，对同一系统被≥2个独立规则同时命中的症状提升置信度至1.0
# 原理：两个规则依赖的事件类型集合不相交 → 独立观测 → 交叉验证通过 → 100% 置信
# 策略：原地修改 diagnoses 列表中的条目（不产生重复 JSONL），调用方统一输出
from __future__ import annotations


def apply_cross_validation(
    diagnoses: list[dict],
    disease_map: dict[str, dict],
) -> int:
    """
    检查同一系统的诊断是否被独立规则交叉验证。
    若两个规则 event_types 集合不相交且均命中，原地升级为 1.0 置信度。
    返回升级的条目数。
    """
    promoted = 0

    per_system: dict[str, list[dict]] = {}
    for dx in diagnoses:
        per_system.setdefault(dx["system"], []).append(dx)

    for system, hits in per_system.items():
        if len(hits) < 2:
            continue

        for i, a in enumerate(hits):
            a_dep = _get_event_types(disease_map, a["rule_id"])

            corroborating = []
            for j, b in enumerate(hits):
                if i == j:
                    continue
                b_dep = _get_event_types(disease_map, b["rule_id"])
                if a_dep and b_dep and not (a_dep & b_dep):
                    corroborating.append(b["rule_id"])

            if corroborating:
                a["confidence"] = 1.0
                a["cross_validated_by"] = corroborating
                promoted += 1

    return promoted


def _get_event_types(disease_map: dict, rule_id: str) -> set[str]:
    """从 rules.yaml 定义的 depends 中提取 event_types 集合"""
    rule = disease_map.get(rule_id, {})
    depends = rule.get("depends", {})
    return set(depends.get("event_types", []))
