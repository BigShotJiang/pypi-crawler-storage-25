# test_probe_autogpt_mock.py —— 乾坤镜 AutoGPT 适配器 Mock 测试

import sys
import types
import unittest
from pathlib import Path

_src = Path(__file__).parent.parent / "src"
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

_captured_events = []


def _setup_autogpt_modules():
    class FakeAgent:
        def __init__(self):
            self.session_id = "sess_001"
            self.name = "autogpt_agent"

        def step(self, *args, **kwargs):
            return {"action": "next"}

    class FakeApiManager:
        @staticmethod
        def create_chat_completion(*args, **kwargs):
            return {"choices": [{"message": {"content": "ok"}}]}

    fake_agent = types.ModuleType("autogpt")
    fake_agent.agent = types.ModuleType("autogpt.agent")
    fake_agent.agent.agent = types.ModuleType("autogpt.agent.agent")
    fake_agent.agent.agent.Agent = FakeAgent
    fake_llm = types.ModuleType("autogpt.llm")
    fake_llm.api_manager = types.ModuleType("autogpt.llm.api_manager")
    fake_llm.api_manager.ApiManager = FakeApiManager

    sys.modules["autogpt"] = types.ModuleType("autogpt")
    sys.modules["autogpt.agent"] = fake_agent.agent
    sys.modules["autogpt.agent.agent"] = fake_agent.agent.agent
    sys.modules["autogpt.llm"] = fake_llm
    sys.modules["autogpt.llm.api_manager"] = fake_llm.api_manager


class TestAutoGPTAdapter(unittest.TestCase):
    def setUp(self):
        global _captured_events
        _captured_events.clear()
        _setup_autogpt_modules()
        from probe_uni import ProbeUni

        self._orig_emit = ProbeUni.emit

        def capture_emit(self, event_type, payload):
            _captured_events.append({"event_type": event_type, "payload": payload})

        ProbeUni.emit = capture_emit

    def tearDown(self):
        from probe_uni import ProbeUni

        ProbeUni.emit = self._orig_emit
        for mod in list(sys.modules.keys()):
            if mod.startswith("autogpt"):
                del sys.modules[mod]

    def test_adapter_imports_without_error(self):
        from adapters.probe_autogpt import init_autogpt_probe

        self.assertTrue(callable(init_autogpt_probe))

    def test_monkey_patch_applies_to_step(self):
        from adapters.probe_autogpt import init_autogpt_probe

        probe = init_autogpt_probe()
        from autogpt.agent.agent import Agent

        self.assertNotEqual(Agent.step.__name__, "step")

    def test_monkey_patch_applies_to_completion(self):
        from adapters.probe_autogpt import init_autogpt_probe

        probe = init_autogpt_probe()
        from autogpt.llm.api_manager import ApiManager

        self.assertNotEqual(
            ApiManager.create_chat_completion.__name__, "create_chat_completion"
        )

    def test_emit_on_step(self):
        from adapters.probe_autogpt import init_autogpt_probe

        probe = init_autogpt_probe()
        from autogpt.agent.agent import Agent

        agent = Agent()
        agent.step()
        events = [e for e in _captured_events if e["event_type"] == "agent_step_start"]
        self.assertTrue(len(events) > 0)
        self.assertEqual(
            events[0]["payload"]["layer_agent"]["agent_name"], "autogpt_agent"
        )

    def test_emit_on_llm_invoke(self):
        from adapters.probe_autogpt import init_autogpt_probe

        probe = init_autogpt_probe()
        from autogpt.llm.api_manager import ApiManager

        api = ApiManager()
        api.create_chat_completion(model="gpt-4")
        events = [e for e in _captured_events if e["event_type"] == "llm_invoke"]
        self.assertTrue(len(events) > 0)
        self.assertIn("layer_llm", events[0]["payload"])


if __name__ == "__main__":
    unittest.main()
