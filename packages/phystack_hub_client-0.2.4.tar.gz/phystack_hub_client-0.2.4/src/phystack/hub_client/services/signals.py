"""
Signals Service

Analytics/signals tracking service matching the Node.js hub-client SignalsService.
Handles events, sessions, client info, commerce, and custom tracking.

Socket events:
- sendEventSignal: EVENT, CHECKOUT, PURCHASE types
- sendSessionSignal: SESSION type
- sendClientSignal: CLIENT type
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from phystack.hub_client.client import PhyHubClient


# =============================================================================
# Enums
# =============================================================================


class DataRequestTypeEnum(str, Enum):
    SESSION = "SESSION"
    CLIENT = "CLIENT"
    EVENT = "EVENT"
    CHECKOUT = "CHECKOUT"
    PURCHASE = "PURCHASE"


class DataResidencyEnum(str, Enum):
    EU = "EU"
    US = "US"
    UAE = "UAE"
    AU = "AU"
    IN_ = "IN"
    QA = "QA"
    DEV = "DEV"


class EventTypeEnum(str, Enum):
    APP_START = "APP_START"
    APP_ONLINE = "APP_ONLINE"
    APP_OFFLINE = "APP_OFFLINE"
    CATEGORY_VIEW = "CATEGORY_VIEW"
    PRODUCT_VIEW = "PRODUCT_VIEW"
    CART_ADD = "CART_ADD"
    CART_VIEW = "CART_VIEW"
    CART_REMOVE = "CART_REMOVE"
    CART_CLEAR = "CART_CLEAR"
    SEARCH = "SEARCH"
    SEARCH_CLEAR = "SEARCH_CLEAR"
    CHECKOUT = "CHECKOUT"
    PURCHASE = "PURCHASE"
    CHECKOUT_PRODUCT = "CHECKOUT_PRODUCT"
    PURCHASE_PRODUCT = "PURCHASE_PRODUCT"
    QR_RUN = "QR_RUN"
    RATING = "RATING"
    FEEDBACK = "FEEDBACK"
    ORDER_ITEM = "ORDER_ITEM"
    PROCESS_ORDER_START = "PROCESS_ORDER_START"
    PROCESS_ORDER_END = "PROCESS_ORDER_END"
    PROCESS_ORDER_SUCCESS = "PROCESS_ORDER_SUCCESS"
    PROCESS_ORDER_FAILED = "PROCESS_ORDER_FAILED"
    PROCESS_ORDER_ITEM_DELIVERED = "PROCESS_ORDER_ITEM_DELIVERED"
    PROCESS_ORDER_ITEM_FAILED = "PROCESS_ORDER_ITEM_FAILED"
    AUTHENTICATION_SUCCESS = "AUTHENTICATION_SUCCESS"
    AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
    SCAN_BARCODE = "SCAN_BARCODE"
    MEDIA_FINISHED = "MEDIA_FINISHED"


# =============================================================================
# Key shortening map (matches Node.js hub-client for protocol compatibility)
# =============================================================================

_SHORTEN_KEYS: dict[str, str] = {
    "captureId": "a",
    "sessionId": "b",
    "tenantId": "c",
    "sessionCreated": "d",
    "ip": "e",
    "environment": "f",
    "dataResidency": "g",
    "spaceId": "h",
    "appId": "i",
    "appVersion": "j",
    "installationId": "k",
    "installationVersion": "l",
    "country": "m",
    "locationAccuracy": "n",
    "latitude": "o",
    "longitude": "p",
    "deviceId": "q",
    "clientId": "r",
    "eventType": "s",
    "eventTime": "t",
    "interaction": "u",
    "productId": "v",
    "categoryId": "w",
    "int1": "x",
    "int2": "y",
    "int3": "z",
    "int4": "aa",
    "int5": "ab",
    "str1": "ac",
    "str2": "ad",
    "str3": "ae",
    "str4": "af",
    "str5": "ag",
    "clientCreated": "ah",
    "clientIp": "ai",
    "clientUserAgent": "aj",
    "clientDeviceVendor": "ak",
    "clientDeviceModel": "al",
    "clientDeviceType": "am",
    "clientOsName": "an",
    "clientOsVersion": "ao",
    "clientBrowserName": "ap",
    "clientBrowserVersion": "aq",
    "clientBrowserMajor": "ar",
    "clientBrowserEngine": "as",
    "clientBrowserEngineVersion": "at",
    "clientCpuArchitecture": "au",
    "clientScreenWidth": "av",
    "clientScreenHeight": "aw",
    "clientScreenColorDepth": "ax",
    "clientScreenPixelDepth": "ay",
    "stateful": "ba",
    "public": "bb",
    "currency": "bc",
    "revenue": "bd",
    "products": "be",
    "transactionId": "bf",
    "affiliation": "bg",
    "shipping": "bh",
    "tax": "bi",
    "coupon": "bj",
}


def _shorten_keys(data: dict[str, Any]) -> dict[str, Any]:
    """Shorten field names for bandwidth optimization (matches Node.js)."""
    result: dict[str, Any] = {}
    for key, value in data.items():
        short = _SHORTEN_KEYS.get(key, key)
        if isinstance(value, list):
            result[short] = [
                _shorten_keys(item) if isinstance(item, dict) else item
                for item in value
            ]
        elif isinstance(value, dict):
            result[short] = _shorten_keys(value)
        else:
            result[short] = value
    return result


def _now_iso() -> str:
    """Current UTC time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


# =============================================================================
# Data types
# =============================================================================


@dataclass
class InitSignalPayload:
    """Parameters for initializing the signals service."""

    tenant_id: str = ""
    environment: str = ""
    data_residency: str = ""
    country: str = ""
    space_id: str = ""
    app_id: str = ""
    app_version: str = ""
    installation_id: str = ""
    installation_version: str = ""
    device_id: Optional[str] = None
    session_id: Optional[str] = None
    client_id: Optional[str] = None
    ip: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    location_accuracy: Optional[float] = None
    create_new_session_after_last_activity_mins: int = 30


@dataclass
class CheckoutProduct:
    """Product in a checkout/purchase transaction."""

    id: str = ""
    name: str = ""
    category_id: str = ""
    space_id: str = ""
    quantity: int = 0
    price: float = 0.0
    affiliation: Optional[str] = None
    coupon: Optional[str] = None
    discount: Optional[float] = None


@dataclass
class CheckoutProps:
    """Checkout transaction data."""

    transaction_id: str = ""
    currency: str = ""
    revenue: float = 0.0
    products: list[CheckoutProduct] = field(default_factory=list)
    affiliation: Optional[str] = None
    shipping: Optional[float] = None
    tax: Optional[float] = None
    coupon: Optional[str] = None


# PurchaseProps is identical to CheckoutProps
PurchaseProps = CheckoutProps


# =============================================================================
# Signals Service
# =============================================================================


class SignalsService:
    """Analytics/signals tracking service.

    Usage:
        signals = await client.initialize_signals(InitSignalPayload(
            tenant_id="...", environment="production", data_residency="EU",
            country="SE", app_id="my-app", installation_id="...",
        ))
        signals.send_app_online()
        signals.send_product_view(product_id="prod-123")
    """

    # Socket event names
    EVENT_SIGNAL = "sendEventSignal"
    SESSION_SIGNAL = "sendSessionSignal"
    CLIENT_SIGNAL = "sendClientSignal"

    _REQUIRED_PARAMS = [
        "tenant_id", "environment", "data_residency",
        "country", "app_id", "installation_id",
    ]

    def __init__(self, hub_client: "PhyHubClient", params: InitSignalPayload) -> None:
        self._client = hub_client
        self._params = params

        # Instance state
        self._tenant_id = params.tenant_id
        self._environment = params.environment
        self._data_residency = params.data_residency
        self._country = params.country
        self._space_id = params.space_id
        self._app_id = params.app_id
        self._app_version = params.app_version
        self._installation_id = params.installation_id
        self._installation_version = params.installation_version
        self._device_id = params.device_id
        self._ip = params.ip
        self._latitude = params.latitude
        self._longitude = params.longitude
        self._location_accuracy = params.location_accuracy

        # Session state
        self._session_id = params.session_id or str(uuid.uuid4())
        self._session_created = _now_iso()
        self._client_id = params.client_id or str(uuid.uuid4())
        self._client_created = _now_iso()
        self._last_activity = _now_iso()

        self._initialized = False

    async def initialize(self) -> None:
        """Initialize the signals service — sends session, app start, and client data."""
        self._validate_required_params()

        # Send initial session
        await self._send_session()

        # Send app start event
        await self.send_app_start()

        # Send client info
        await self._send_client()

        self._initialized = True
        print(f"[SignalsService] Initialized (session={self._session_id[:8]}...)")

    def _validate_required_params(self) -> None:
        """Validate required initialization parameters."""
        for param in self._REQUIRED_PARAMS:
            if not getattr(self._params, param, None):
                raise ValueError(
                    f"[SignalsService] Required parameter '{param}' is missing"
                )

    def get_instance_props(self) -> dict[str, Any]:
        """Get current signal instance state."""
        return {
            "tenantId": self._tenant_id,
            "environment": self._environment,
            "dataResidency": self._data_residency,
            "country": self._country,
            "spaceId": self._space_id,
            "appId": self._app_id,
            "appVersion": self._app_version,
            "installationId": self._installation_id,
            "installationVersion": self._installation_version,
            "deviceId": self._device_id,
            "sessionId": self._session_id,
            "clientId": self._client_id,
            "ip": self._ip,
        }

    # =========================================================================
    # Session management
    # =========================================================================

    async def create_session(self) -> None:
        """Create a new session."""
        self._session_id = str(uuid.uuid4())
        self._session_created = _now_iso()
        self._last_activity = _now_iso()
        await self._send_session()

    def _build_session_data(self) -> dict[str, Any]:
        """Build session payload."""
        data: dict[str, Any] = {
            "sessionId": self._session_id,
            "sessionCreated": self._session_created,
            "tenantId": self._tenant_id,
            "environment": self._environment,
            "dataResidency": self._data_residency,
            "country": self._country,
            "spaceId": self._space_id,
            "appId": self._app_id,
            "appVersion": self._app_version,
            "installationId": self._installation_id,
            "installationVersion": self._installation_version,
        }
        if self._device_id:
            data["deviceId"] = self._device_id
        if self._client_id:
            data["clientId"] = self._client_id
        if self._ip:
            data["ip"] = self._ip
        if self._latitude is not None:
            data["latitude"] = self._latitude
        if self._longitude is not None:
            data["longitude"] = self._longitude
        if self._location_accuracy is not None:
            data["locationAccuracy"] = self._location_accuracy
        return data

    async def _send_session(self) -> Any:
        """Send session data."""
        data = self._build_session_data()
        return await self._send(DataRequestTypeEnum.SESSION, data)

    # =========================================================================
    # Client info
    # =========================================================================

    async def _send_client(self) -> Any:
        """Send client info."""
        data: dict[str, Any] = {
            "clientId": self._client_id,
            "clientCreated": self._client_created,
            "tenantId": self._tenant_id,
            "dataResidency": self._data_residency,
        }
        if self._country:
            data["country"] = self._country
        if self._ip:
            data["clientIp"] = self._ip
        if self._latitude is not None:
            data["latitude"] = self._latitude
        if self._longitude is not None:
            data["longitude"] = self._longitude
        if self._location_accuracy is not None:
            data["locationAccuracy"] = self._location_accuracy
        return await self._send(DataRequestTypeEnum.CLIENT, data)

    # =========================================================================
    # Core event methods
    # =========================================================================

    async def send_event(self, event_type: str, interaction: bool = True,
                         **kwargs: Any) -> Any:
        """Send a generic event.

        Args:
            event_type: Event type string (e.g. EventTypeEnum value).
            interaction: Whether this is a user interaction.
            **kwargs: Additional TrackEvent fields (product_id, category_id,
                      int1-5, str1-5, stateful, public, capture_id).
        """
        self._last_activity = _now_iso()

        data: dict[str, Any] = {
            "sessionId": self._session_id,
            "tenantId": self._tenant_id,
            "dataResidency": self._data_residency,
            "spaceId": self._space_id,
            "eventType": event_type,
            "eventTime": _now_iso(),
            "interaction": interaction,
        }
        if self._client_id:
            data["clientId"] = self._client_id
        if self._ip:
            data["ip"] = self._ip

        # Map snake_case kwargs to camelCase
        _kwarg_map = {
            "product_id": "productId",
            "category_id": "categoryId",
            "capture_id": "captureId",
        }
        for key, value in kwargs.items():
            if value is not None:
                camel = _kwarg_map.get(key, key)
                data[camel] = value

        return await self._send(DataRequestTypeEnum.EVENT, data)

    async def send_custom_event(self, event_type: str, interaction: bool = True,
                                **kwargs: Any) -> Any:
        """Send a custom event (alias for send_event)."""
        return await self.send_event(event_type, interaction, **kwargs)

    # =========================================================================
    # App lifecycle
    # =========================================================================

    async def send_app_start(self) -> Any:
        return await self.send_event(EventTypeEnum.APP_START, interaction=False)

    async def send_app_online(self, message: Optional[str] = None) -> Any:
        return await self.send_event(
            EventTypeEnum.APP_ONLINE, interaction=False,
            str1=message,
        )

    async def send_app_offline(self, message: Optional[str] = None) -> Any:
        return await self.send_event(
            EventTypeEnum.APP_OFFLINE, interaction=False,
            str1=message,
        )

    # =========================================================================
    # Order processing
    # =========================================================================

    async def send_process_order_start(self) -> Any:
        return await self.send_event(EventTypeEnum.PROCESS_ORDER_START)

    async def send_process_order_end(self) -> Any:
        return await self.send_event(EventTypeEnum.PROCESS_ORDER_END)

    async def send_process_order_success(self) -> Any:
        return await self.send_event(EventTypeEnum.PROCESS_ORDER_SUCCESS)

    async def send_process_order_failed(self) -> Any:
        return await self.send_event(EventTypeEnum.PROCESS_ORDER_FAILED)

    async def send_order_item(self, order_id: str, item_id: str,
                              item_type: str = "") -> Any:
        return await self.send_event(
            EventTypeEnum.ORDER_ITEM,
            str1=order_id, str2=item_id, str3=item_type,
        )

    async def send_process_order_item_delivered(self, order_id: str,
                                                 item_id: str) -> Any:
        return await self.send_event(
            EventTypeEnum.PROCESS_ORDER_ITEM_DELIVERED,
            str1=order_id, str2=item_id,
        )

    async def send_process_order_item_failed(self, order_id: str,
                                              item_id: str) -> Any:
        return await self.send_event(
            EventTypeEnum.PROCESS_ORDER_ITEM_FAILED,
            str1=order_id, str2=item_id,
        )

    # =========================================================================
    # Authentication
    # =========================================================================

    async def send_authentication_success(self) -> Any:
        return await self.send_event(EventTypeEnum.AUTHENTICATION_SUCCESS)

    async def send_authentication_failed(self) -> Any:
        return await self.send_event(EventTypeEnum.AUTHENTICATION_FAILED)

    # =========================================================================
    # Barcode / QR
    # =========================================================================

    async def send_scan_barcode(self, barcode: str) -> Any:
        return await self.send_event(EventTypeEnum.SCAN_BARCODE, str1=barcode)

    async def send_qr_scan(self) -> Any:
        return await self.send_event(EventTypeEnum.QR_RUN)

    # =========================================================================
    # Cart
    # =========================================================================

    async def send_cart_add(self, product_id: str, quantity: int = 1) -> Any:
        return await self.send_event(
            EventTypeEnum.CART_ADD,
            product_id=product_id, int1=quantity,
        )

    async def send_cart_view(self) -> Any:
        return await self.send_event(EventTypeEnum.CART_VIEW)

    async def send_cart_remove(self, product_id: str, quantity: int = 1) -> Any:
        return await self.send_event(
            EventTypeEnum.CART_REMOVE,
            product_id=product_id, int1=quantity,
        )

    async def send_cart_clear(self) -> Any:
        return await self.send_event(EventTypeEnum.CART_CLEAR)

    # =========================================================================
    # Product / Category browsing
    # =========================================================================

    async def send_category_view(self, category_id: str) -> Any:
        return await self.send_event(
            EventTypeEnum.CATEGORY_VIEW, category_id=category_id,
        )

    async def send_product_view(self, product_id: str) -> Any:
        return await self.send_event(
            EventTypeEnum.PRODUCT_VIEW, product_id=product_id,
        )

    # =========================================================================
    # Search
    # =========================================================================

    async def send_search(self, query: str) -> Any:
        return await self.send_event(EventTypeEnum.SEARCH, str1=query)

    async def send_search_clear(self) -> Any:
        return await self.send_event(EventTypeEnum.SEARCH_CLEAR)

    # =========================================================================
    # Media
    # =========================================================================

    async def send_media_finished(self, media_id: str, media_type: str,
                                   name: str, duration: int,
                                   tags: Optional[str] = None) -> Any:
        return await self.send_event(
            EventTypeEnum.MEDIA_FINISHED,
            str1=media_id, str2=media_type, str3=name,
            int1=duration, str4=tags,
        )

    # =========================================================================
    # User feedback
    # =========================================================================

    async def send_rating(self, rating: int, interaction_delay: Optional[int] = None,
                          comment: Optional[str] = None) -> Any:
        return await self.send_event(
            EventTypeEnum.RATING,
            int1=rating, int2=interaction_delay, str1=comment,
        )

    async def send_feedback(self, feedback: str,
                            rating: Optional[int] = None) -> Any:
        return await self.send_event(
            EventTypeEnum.FEEDBACK,
            str1=feedback, int1=rating,
        )

    # =========================================================================
    # Commerce
    # =========================================================================

    async def send_checkout(self, props: CheckoutProps) -> Any:
        """Send checkout transaction."""
        data = self._build_commerce_data(EventTypeEnum.CHECKOUT, props)
        return await self._send(DataRequestTypeEnum.EVENT, data)

    async def send_purchase(self, props: PurchaseProps) -> Any:
        """Send purchase transaction."""
        data = self._build_commerce_data(EventTypeEnum.PURCHASE, props)
        return await self._send(DataRequestTypeEnum.EVENT, data)

    def _build_commerce_data(self, event_type: str,
                             props: CheckoutProps) -> dict[str, Any]:
        """Build commerce event payload."""
        self._last_activity = _now_iso()

        data: dict[str, Any] = {
            "sessionId": self._session_id,
            "tenantId": self._tenant_id,
            "dataResidency": self._data_residency,
            "spaceId": self._space_id,
            "eventType": event_type,
            "eventTime": _now_iso(),
            "interaction": True,
            "transactionId": props.transaction_id,
            "currency": props.currency,
            "revenue": props.revenue,
        }
        if self._client_id:
            data["clientId"] = self._client_id
        if self._ip:
            data["ip"] = self._ip
        if props.affiliation:
            data["affiliation"] = props.affiliation
        if props.shipping is not None:
            data["shipping"] = props.shipping
        if props.tax is not None:
            data["tax"] = props.tax
        if props.coupon:
            data["coupon"] = props.coupon

        data["products"] = [
            {
                k: v for k, v in {
                    "id": p.id,
                    "name": p.name,
                    "categoryId": p.category_id,
                    "spaceId": p.space_id,
                    "quantity": p.quantity,
                    "price": p.price,
                    "affiliation": p.affiliation,
                    "coupon": p.coupon,
                    "discount": p.discount,
                }.items() if v is not None
            }
            for p in props.products
        ]

        return data

    # =========================================================================
    # State management
    # =========================================================================

    async def set_state(self, key: str, value: Any,
                        expiry_duration: Optional[int] = None) -> Any:
        """Store a stateful event with key/value and optional expiry.

        Args:
            key: State key.
            value: State value.
            expiry_duration: Expiry in seconds (optional).
        """
        return await self.send_event(
            key,
            interaction=False,
            stateful=True,
            str1=str(value) if not isinstance(value, str) else value,
            int1=expiry_duration,
        )

    # =========================================================================
    # Internal
    # =========================================================================

    async def _send(self, data_type: DataRequestTypeEnum,
                    data: dict[str, Any]) -> Any:
        """Send signal data with key shortening."""
        shortened = _shorten_keys(data)
        return await self._client.send_signal(data_type, shortened)
