# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "web_recruitment_sdk"
__version__ = "0.1.0-alpha.26"  # x-release-please-version
