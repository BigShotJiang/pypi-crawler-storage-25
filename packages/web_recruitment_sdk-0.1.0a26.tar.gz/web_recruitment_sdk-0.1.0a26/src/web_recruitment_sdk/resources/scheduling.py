# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import scheduling_list_calendar_configs_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.scheduling_list_providers_response import SchedulingListProvidersResponse
from ..types.scheduling_list_calendar_configs_response import SchedulingListCalendarConfigsResponse

__all__ = ["SchedulingResource", "AsyncSchedulingResource"]


class SchedulingResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SchedulingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return SchedulingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SchedulingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return SchedulingResourceWithStreamingResponse(self)

    def list_calendar_configs(
        self,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListCalendarConfigsResponse:
        """
        List calendar configs for admin appointment configuration.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/scheduling/calendar-configs",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"is_active": is_active},
                    scheduling_list_calendar_configs_params.SchedulingListCalendarConfigsParams,
                ),
            ),
            cast_to=SchedulingListCalendarConfigsResponse,
        )

    def list_providers(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListProvidersResponse:
        """
        Return available scheduling providers for the tenant with config status.

        Used by the admin appointment config editor to dynamically populate the provider
        selector. Each provider's configuration UI fetches its own data through
        dedicated endpoints.
        """
        return self._get(
            "/scheduling/providers",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SchedulingListProvidersResponse,
        )


class AsyncSchedulingResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSchedulingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSchedulingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSchedulingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncSchedulingResourceWithStreamingResponse(self)

    async def list_calendar_configs(
        self,
        *,
        is_active: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListCalendarConfigsResponse:
        """
        List calendar configs for admin appointment configuration.

        Args:
          is_active: Filter by active status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/scheduling/calendar-configs",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"is_active": is_active},
                    scheduling_list_calendar_configs_params.SchedulingListCalendarConfigsParams,
                ),
            ),
            cast_to=SchedulingListCalendarConfigsResponse,
        )

    async def list_providers(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListProvidersResponse:
        """
        Return available scheduling providers for the tenant with config status.

        Used by the admin appointment config editor to dynamically populate the provider
        selector. Each provider's configuration UI fetches its own data through
        dedicated endpoints.
        """
        return await self._get(
            "/scheduling/providers",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SchedulingListProvidersResponse,
        )


class SchedulingResourceWithRawResponse:
    def __init__(self, scheduling: SchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_calendar_configs = to_raw_response_wrapper(
            scheduling.list_calendar_configs,
        )
        self.list_providers = to_raw_response_wrapper(
            scheduling.list_providers,
        )


class AsyncSchedulingResourceWithRawResponse:
    def __init__(self, scheduling: AsyncSchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_calendar_configs = async_to_raw_response_wrapper(
            scheduling.list_calendar_configs,
        )
        self.list_providers = async_to_raw_response_wrapper(
            scheduling.list_providers,
        )


class SchedulingResourceWithStreamingResponse:
    def __init__(self, scheduling: SchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_calendar_configs = to_streamed_response_wrapper(
            scheduling.list_calendar_configs,
        )
        self.list_providers = to_streamed_response_wrapper(
            scheduling.list_providers,
        )


class AsyncSchedulingResourceWithStreamingResponse:
    def __init__(self, scheduling: AsyncSchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_calendar_configs = async_to_streamed_response_wrapper(
            scheduling.list_calendar_configs,
        )
        self.list_providers = async_to_streamed_response_wrapper(
            scheduling.list_providers,
        )
