# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .pages import (
    PagesResource,
    AsyncPagesResource,
    PagesResourceWithRawResponse,
    AsyncPagesResourceWithRawResponse,
    PagesResourceWithStreamingResponse,
    AsyncPagesResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from .form_mappings import (
    FormMappingsResource,
    AsyncFormMappingsResource,
    FormMappingsResourceWithRawResponse,
    AsyncFormMappingsResourceWithRawResponse,
    FormMappingsResourceWithStreamingResponse,
    AsyncFormMappingsResourceWithStreamingResponse,
)
from .connect.connect import (
    ConnectResource,
    AsyncConnectResource,
    ConnectResourceWithRawResponse,
    AsyncConnectResourceWithRawResponse,
    ConnectResourceWithStreamingResponse,
    AsyncConnectResourceWithStreamingResponse,
)

__all__ = ["FacebookResource", "AsyncFacebookResource"]


class FacebookResource(SyncAPIResource):
    @cached_property
    def pages(self) -> PagesResource:
        return PagesResource(self._client)

    @cached_property
    def form_mappings(self) -> FormMappingsResource:
        return FormMappingsResource(self._client)

    @cached_property
    def connect(self) -> ConnectResource:
        return ConnectResource(self._client)

    @cached_property
    def with_raw_response(self) -> FacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return FacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return FacebookResourceWithStreamingResponse(self)


class AsyncFacebookResource(AsyncAPIResource):
    @cached_property
    def pages(self) -> AsyncPagesResource:
        return AsyncPagesResource(self._client)

    @cached_property
    def form_mappings(self) -> AsyncFormMappingsResource:
        return AsyncFormMappingsResource(self._client)

    @cached_property
    def connect(self) -> AsyncConnectResource:
        return AsyncConnectResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncFacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncFacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncFacebookResourceWithStreamingResponse(self)


class FacebookResourceWithRawResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def pages(self) -> PagesResourceWithRawResponse:
        return PagesResourceWithRawResponse(self._facebook.pages)

    @cached_property
    def form_mappings(self) -> FormMappingsResourceWithRawResponse:
        return FormMappingsResourceWithRawResponse(self._facebook.form_mappings)

    @cached_property
    def connect(self) -> ConnectResourceWithRawResponse:
        return ConnectResourceWithRawResponse(self._facebook.connect)


class AsyncFacebookResourceWithRawResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def pages(self) -> AsyncPagesResourceWithRawResponse:
        return AsyncPagesResourceWithRawResponse(self._facebook.pages)

    @cached_property
    def form_mappings(self) -> AsyncFormMappingsResourceWithRawResponse:
        return AsyncFormMappingsResourceWithRawResponse(self._facebook.form_mappings)

    @cached_property
    def connect(self) -> AsyncConnectResourceWithRawResponse:
        return AsyncConnectResourceWithRawResponse(self._facebook.connect)


class FacebookResourceWithStreamingResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def pages(self) -> PagesResourceWithStreamingResponse:
        return PagesResourceWithStreamingResponse(self._facebook.pages)

    @cached_property
    def form_mappings(self) -> FormMappingsResourceWithStreamingResponse:
        return FormMappingsResourceWithStreamingResponse(self._facebook.form_mappings)

    @cached_property
    def connect(self) -> ConnectResourceWithStreamingResponse:
        return ConnectResourceWithStreamingResponse(self._facebook.connect)


class AsyncFacebookResourceWithStreamingResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def pages(self) -> AsyncPagesResourceWithStreamingResponse:
        return AsyncPagesResourceWithStreamingResponse(self._facebook.pages)

    @cached_property
    def form_mappings(self) -> AsyncFormMappingsResourceWithStreamingResponse:
        return AsyncFormMappingsResourceWithStreamingResponse(self._facebook.form_mappings)

    @cached_property
    def connect(self) -> AsyncConnectResourceWithStreamingResponse:
        return AsyncConnectResourceWithStreamingResponse(self._facebook.connect)
