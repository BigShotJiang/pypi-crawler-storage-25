# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.facebook import page_create_config_params, page_update_config_params
from ...types.facebook.page_list_forms_response import PageListFormsResponse
from ...types.facebook.page_list_configs_response import PageListConfigsResponse
from ...types.facebook.page_create_config_response import PageCreateConfigResponse
from ...types.facebook.page_update_config_response import PageUpdateConfigResponse
from ...types.facebook.page_retrieve_config_response import PageRetrieveConfigResponse

__all__ = ["PagesResource", "AsyncPagesResource"]


class PagesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return PagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return PagesResourceWithStreamingResponse(self)

    def create_config(
        self,
        *,
        fb_page_id: str,
        page_access_token: str,
        is_active: bool | Omit = omit,
        page_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageCreateConfigResponse:
        """
        Create a new Facebook page configuration.

        Stores the page access token (encrypted) for accessing Facebook Graph API. This
        is typically called after completing the Facebook OAuth flow.

        Args: config: The page config data (fb_page_id, page_access_token)

        Returns: FacebookPageConfigRead: The created page config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/facebook/pages",
            body=maybe_transform(
                {
                    "fb_page_id": fb_page_id,
                    "page_access_token": page_access_token,
                    "is_active": is_active,
                    "page_name": page_name,
                },
                page_create_config_params.PageCreateConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageCreateConfigResponse,
        )

    def delete_config(
        self,
        config_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Facebook page configuration.

        Args: config_id: The config ID to delete

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/facebook/pages/{config_id}", config_id=config_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_configs(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageListConfigsResponse:
        """
        List all Facebook page configurations for the tenant.

        Returns: list[FacebookPageConfigRead]: All page configs (excludes tokens)
        """
        return self._get(
            "/facebook/pages",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageListConfigsResponse,
        )

    def list_forms(
        self,
        page_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageListFormsResponse:
        """
        Fetch lead forms for a configured Facebook page.

        Uses the tenant page access token to fetch available lead forms from the
        Facebook Graph API.

        Args: page_id: The Facebook Page ID

        Returns: FacebookLeadFormsResponse: List of lead forms for the page

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return self._get(
            path_template("/facebook/pages/{page_id}/forms", page_id=page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageListFormsResponse,
        )

    def retrieve_config(
        self,
        page_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageRetrieveConfigResponse:
        """
        Get a specific Facebook page configuration.

        Args: page_id: The Facebook Page ID

        Returns: FacebookPageConfigRead: The page config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return self._get(
            path_template("/facebook/pages/{page_id}", page_id=page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageRetrieveConfigResponse,
        )

    def update_config(
        self,
        config_id: int,
        *,
        is_active: Optional[bool] | Omit = omit,
        page_access_token: Optional[str] | Omit = omit,
        page_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageUpdateConfigResponse:
        """
        Update a Facebook page configuration.

        Can be used to update the page access token or deactivate the config.

        Args: config_id: The config ID to update update: The update data

        Returns: FacebookPageConfigRead: The updated config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            path_template("/facebook/pages/{config_id}", config_id=config_id),
            body=maybe_transform(
                {
                    "is_active": is_active,
                    "page_access_token": page_access_token,
                    "page_name": page_name,
                },
                page_update_config_params.PageUpdateConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageUpdateConfigResponse,
        )


class AsyncPagesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncPagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncPagesResourceWithStreamingResponse(self)

    async def create_config(
        self,
        *,
        fb_page_id: str,
        page_access_token: str,
        is_active: bool | Omit = omit,
        page_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageCreateConfigResponse:
        """
        Create a new Facebook page configuration.

        Stores the page access token (encrypted) for accessing Facebook Graph API. This
        is typically called after completing the Facebook OAuth flow.

        Args: config: The page config data (fb_page_id, page_access_token)

        Returns: FacebookPageConfigRead: The created page config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/facebook/pages",
            body=await async_maybe_transform(
                {
                    "fb_page_id": fb_page_id,
                    "page_access_token": page_access_token,
                    "is_active": is_active,
                    "page_name": page_name,
                },
                page_create_config_params.PageCreateConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageCreateConfigResponse,
        )

    async def delete_config(
        self,
        config_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a Facebook page configuration.

        Args: config_id: The config ID to delete

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/facebook/pages/{config_id}", config_id=config_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def list_configs(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageListConfigsResponse:
        """
        List all Facebook page configurations for the tenant.

        Returns: list[FacebookPageConfigRead]: All page configs (excludes tokens)
        """
        return await self._get(
            "/facebook/pages",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageListConfigsResponse,
        )

    async def list_forms(
        self,
        page_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageListFormsResponse:
        """
        Fetch lead forms for a configured Facebook page.

        Uses the tenant page access token to fetch available lead forms from the
        Facebook Graph API.

        Args: page_id: The Facebook Page ID

        Returns: FacebookLeadFormsResponse: List of lead forms for the page

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return await self._get(
            path_template("/facebook/pages/{page_id}/forms", page_id=page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageListFormsResponse,
        )

    async def retrieve_config(
        self,
        page_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageRetrieveConfigResponse:
        """
        Get a specific Facebook page configuration.

        Args: page_id: The Facebook Page ID

        Returns: FacebookPageConfigRead: The page config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not page_id:
            raise ValueError(f"Expected a non-empty value for `page_id` but received {page_id!r}")
        return await self._get(
            path_template("/facebook/pages/{page_id}", page_id=page_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageRetrieveConfigResponse,
        )

    async def update_config(
        self,
        config_id: int,
        *,
        is_active: Optional[bool] | Omit = omit,
        page_access_token: Optional[str] | Omit = omit,
        page_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PageUpdateConfigResponse:
        """
        Update a Facebook page configuration.

        Can be used to update the page access token or deactivate the config.

        Args: config_id: The config ID to update update: The update data

        Returns: FacebookPageConfigRead: The updated config (excludes token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            path_template("/facebook/pages/{config_id}", config_id=config_id),
            body=await async_maybe_transform(
                {
                    "is_active": is_active,
                    "page_access_token": page_access_token,
                    "page_name": page_name,
                },
                page_update_config_params.PageUpdateConfigParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PageUpdateConfigResponse,
        )


class PagesResourceWithRawResponse:
    def __init__(self, pages: PagesResource) -> None:
        self._pages = pages

        self.create_config = to_raw_response_wrapper(
            pages.create_config,
        )
        self.delete_config = to_raw_response_wrapper(
            pages.delete_config,
        )
        self.list_configs = to_raw_response_wrapper(
            pages.list_configs,
        )
        self.list_forms = to_raw_response_wrapper(
            pages.list_forms,
        )
        self.retrieve_config = to_raw_response_wrapper(
            pages.retrieve_config,
        )
        self.update_config = to_raw_response_wrapper(
            pages.update_config,
        )


class AsyncPagesResourceWithRawResponse:
    def __init__(self, pages: AsyncPagesResource) -> None:
        self._pages = pages

        self.create_config = async_to_raw_response_wrapper(
            pages.create_config,
        )
        self.delete_config = async_to_raw_response_wrapper(
            pages.delete_config,
        )
        self.list_configs = async_to_raw_response_wrapper(
            pages.list_configs,
        )
        self.list_forms = async_to_raw_response_wrapper(
            pages.list_forms,
        )
        self.retrieve_config = async_to_raw_response_wrapper(
            pages.retrieve_config,
        )
        self.update_config = async_to_raw_response_wrapper(
            pages.update_config,
        )


class PagesResourceWithStreamingResponse:
    def __init__(self, pages: PagesResource) -> None:
        self._pages = pages

        self.create_config = to_streamed_response_wrapper(
            pages.create_config,
        )
        self.delete_config = to_streamed_response_wrapper(
            pages.delete_config,
        )
        self.list_configs = to_streamed_response_wrapper(
            pages.list_configs,
        )
        self.list_forms = to_streamed_response_wrapper(
            pages.list_forms,
        )
        self.retrieve_config = to_streamed_response_wrapper(
            pages.retrieve_config,
        )
        self.update_config = to_streamed_response_wrapper(
            pages.update_config,
        )


class AsyncPagesResourceWithStreamingResponse:
    def __init__(self, pages: AsyncPagesResource) -> None:
        self._pages = pages

        self.create_config = async_to_streamed_response_wrapper(
            pages.create_config,
        )
        self.delete_config = async_to_streamed_response_wrapper(
            pages.delete_config,
        )
        self.list_configs = async_to_streamed_response_wrapper(
            pages.list_configs,
        )
        self.list_forms = async_to_streamed_response_wrapper(
            pages.list_forms,
        )
        self.retrieve_config = async_to_streamed_response_wrapper(
            pages.retrieve_config,
        )
        self.update_config = async_to_streamed_response_wrapper(
            pages.update_config,
        )
