# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.facebook import form_mapping_create_mapping_params
from ...types.facebook.form_mapping_list_mappings_response import FormMappingListMappingsResponse
from ...types.facebook.form_mapping_create_mapping_response import FormMappingCreateMappingResponse

__all__ = ["FormMappingsResource", "AsyncFormMappingsResource"]


class FormMappingsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> FormMappingsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return FormMappingsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FormMappingsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return FormMappingsResourceWithStreamingResponse(self)

    def create_mapping(
        self,
        *,
        campaign_id: int,
        fb_form_id: str,
        fb_page_id: str,
        is_active: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FormMappingCreateMappingResponse:
        """
        Create a new form-to-campaign mapping.

        Maps a Facebook lead form to an internal outreach campaign. Leads from this form
        will be routed to the specified campaign. A PersonSource is automatically
        created for lead attribution.

        Args: body: The mapping data (fb_form_id, fb_page_id, campaign_id)

        Returns: FacebookFormCampaignMappingRead: The created mapping

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/facebook/form-mappings",
            body=maybe_transform(
                {
                    "campaign_id": campaign_id,
                    "fb_form_id": fb_form_id,
                    "fb_page_id": fb_page_id,
                    "is_active": is_active,
                },
                form_mapping_create_mapping_params.FormMappingCreateMappingParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FormMappingCreateMappingResponse,
        )

    def delete_mapping(
        self,
        mapping_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a form-campaign mapping.

        Args: mapping_id: The mapping ID to delete

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/facebook/form-mappings/{mapping_id}", mapping_id=mapping_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list_mappings(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FormMappingListMappingsResponse:
        """
        List all form-campaign mappings for the tenant.

        Returns: list[FacebookFormCampaignMappingRead]: All form mappings
        """
        return self._get(
            "/facebook/form-mappings",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FormMappingListMappingsResponse,
        )


class AsyncFormMappingsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncFormMappingsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncFormMappingsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFormMappingsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncFormMappingsResourceWithStreamingResponse(self)

    async def create_mapping(
        self,
        *,
        campaign_id: int,
        fb_form_id: str,
        fb_page_id: str,
        is_active: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FormMappingCreateMappingResponse:
        """
        Create a new form-to-campaign mapping.

        Maps a Facebook lead form to an internal outreach campaign. Leads from this form
        will be routed to the specified campaign. A PersonSource is automatically
        created for lead attribution.

        Args: body: The mapping data (fb_form_id, fb_page_id, campaign_id)

        Returns: FacebookFormCampaignMappingRead: The created mapping

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/facebook/form-mappings",
            body=await async_maybe_transform(
                {
                    "campaign_id": campaign_id,
                    "fb_form_id": fb_form_id,
                    "fb_page_id": fb_page_id,
                    "is_active": is_active,
                },
                form_mapping_create_mapping_params.FormMappingCreateMappingParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FormMappingCreateMappingResponse,
        )

    async def delete_mapping(
        self,
        mapping_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a form-campaign mapping.

        Args: mapping_id: The mapping ID to delete

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/facebook/form-mappings/{mapping_id}", mapping_id=mapping_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def list_mappings(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FormMappingListMappingsResponse:
        """
        List all form-campaign mappings for the tenant.

        Returns: list[FacebookFormCampaignMappingRead]: All form mappings
        """
        return await self._get(
            "/facebook/form-mappings",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FormMappingListMappingsResponse,
        )


class FormMappingsResourceWithRawResponse:
    def __init__(self, form_mappings: FormMappingsResource) -> None:
        self._form_mappings = form_mappings

        self.create_mapping = to_raw_response_wrapper(
            form_mappings.create_mapping,
        )
        self.delete_mapping = to_raw_response_wrapper(
            form_mappings.delete_mapping,
        )
        self.list_mappings = to_raw_response_wrapper(
            form_mappings.list_mappings,
        )


class AsyncFormMappingsResourceWithRawResponse:
    def __init__(self, form_mappings: AsyncFormMappingsResource) -> None:
        self._form_mappings = form_mappings

        self.create_mapping = async_to_raw_response_wrapper(
            form_mappings.create_mapping,
        )
        self.delete_mapping = async_to_raw_response_wrapper(
            form_mappings.delete_mapping,
        )
        self.list_mappings = async_to_raw_response_wrapper(
            form_mappings.list_mappings,
        )


class FormMappingsResourceWithStreamingResponse:
    def __init__(self, form_mappings: FormMappingsResource) -> None:
        self._form_mappings = form_mappings

        self.create_mapping = to_streamed_response_wrapper(
            form_mappings.create_mapping,
        )
        self.delete_mapping = to_streamed_response_wrapper(
            form_mappings.delete_mapping,
        )
        self.list_mappings = to_streamed_response_wrapper(
            form_mappings.list_mappings,
        )


class AsyncFormMappingsResourceWithStreamingResponse:
    def __init__(self, form_mappings: AsyncFormMappingsResource) -> None:
        self._form_mappings = form_mappings

        self.create_mapping = async_to_streamed_response_wrapper(
            form_mappings.create_mapping,
        )
        self.delete_mapping = async_to_streamed_response_wrapper(
            form_mappings.delete_mapping,
        )
        self.list_mappings = async_to_streamed_response_wrapper(
            form_mappings.list_mappings,
        )
