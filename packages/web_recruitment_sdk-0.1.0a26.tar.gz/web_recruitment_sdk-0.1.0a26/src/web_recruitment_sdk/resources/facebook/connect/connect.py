# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from .pages import (
    PagesResource,
    AsyncPagesResource,
    PagesResourceWithRawResponse,
    AsyncPagesResourceWithRawResponse,
    PagesResourceWithStreamingResponse,
    AsyncPagesResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.facebook import connect_finalize_oauth_params, connect_handle_callback_params
from ....types.facebook.connect_start_oauth_response import ConnectStartOAuthResponse
from ....types.facebook.connect_finalize_oauth_response import ConnectFinalizeOAuthResponse

__all__ = ["ConnectResource", "AsyncConnectResource"]


class ConnectResource(SyncAPIResource):
    @cached_property
    def pages(self) -> PagesResource:
        return PagesResource(self._client)

    @cached_property
    def with_raw_response(self) -> ConnectResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return ConnectResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ConnectResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return ConnectResourceWithStreamingResponse(self)

    def finalize_oauth(
        self,
        *,
        page_ids: SequenceNotStr[str],
        state: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConnectFinalizeOAuthResponse:
        """
        Persist selected pages: store per-page token, create admin mapping, and
        subscribe webhooks.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/facebook/connect/finalize",
            body=maybe_transform(
                {
                    "page_ids": page_ids,
                    "state": state,
                },
                connect_finalize_oauth_params.ConnectFinalizeOAuthParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ConnectFinalizeOAuthResponse,
        )

    def handle_callback(
        self,
        *,
        code: Optional[str] | Omit = omit,
        error: Optional[str] | Omit = omit,
        error_description: Optional[str] | Omit = omit,
        error_reason: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Backend OAuth callback that exchanges code -> token and caches page list +
        tokens.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/facebook/connect/callback",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "code": code,
                        "error": error,
                        "error_description": error_description,
                        "error_reason": error_reason,
                        "state": state,
                    },
                    connect_handle_callback_params.ConnectHandleCallbackParams,
                ),
            ),
            cast_to=object,
        )

    def start_oauth(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConnectStartOAuthResponse:
        """
        Start Facebook OAuth flow by creating a short-lived state and returning the auth
        URL.
        """
        return self._get(
            "/facebook/connect/start",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ConnectStartOAuthResponse,
        )


class AsyncConnectResource(AsyncAPIResource):
    @cached_property
    def pages(self) -> AsyncPagesResource:
        return AsyncPagesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncConnectResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncConnectResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncConnectResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncConnectResourceWithStreamingResponse(self)

    async def finalize_oauth(
        self,
        *,
        page_ids: SequenceNotStr[str],
        state: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConnectFinalizeOAuthResponse:
        """
        Persist selected pages: store per-page token, create admin mapping, and
        subscribe webhooks.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/facebook/connect/finalize",
            body=await async_maybe_transform(
                {
                    "page_ids": page_ids,
                    "state": state,
                },
                connect_finalize_oauth_params.ConnectFinalizeOAuthParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ConnectFinalizeOAuthResponse,
        )

    async def handle_callback(
        self,
        *,
        code: Optional[str] | Omit = omit,
        error: Optional[str] | Omit = omit,
        error_description: Optional[str] | Omit = omit,
        error_reason: Optional[str] | Omit = omit,
        state: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Backend OAuth callback that exchanges code -> token and caches page list +
        tokens.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/facebook/connect/callback",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "code": code,
                        "error": error,
                        "error_description": error_description,
                        "error_reason": error_reason,
                        "state": state,
                    },
                    connect_handle_callback_params.ConnectHandleCallbackParams,
                ),
            ),
            cast_to=object,
        )

    async def start_oauth(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConnectStartOAuthResponse:
        """
        Start Facebook OAuth flow by creating a short-lived state and returning the auth
        URL.
        """
        return await self._get(
            "/facebook/connect/start",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ConnectStartOAuthResponse,
        )


class ConnectResourceWithRawResponse:
    def __init__(self, connect: ConnectResource) -> None:
        self._connect = connect

        self.finalize_oauth = to_raw_response_wrapper(
            connect.finalize_oauth,
        )
        self.handle_callback = to_raw_response_wrapper(
            connect.handle_callback,
        )
        self.start_oauth = to_raw_response_wrapper(
            connect.start_oauth,
        )

    @cached_property
    def pages(self) -> PagesResourceWithRawResponse:
        return PagesResourceWithRawResponse(self._connect.pages)


class AsyncConnectResourceWithRawResponse:
    def __init__(self, connect: AsyncConnectResource) -> None:
        self._connect = connect

        self.finalize_oauth = async_to_raw_response_wrapper(
            connect.finalize_oauth,
        )
        self.handle_callback = async_to_raw_response_wrapper(
            connect.handle_callback,
        )
        self.start_oauth = async_to_raw_response_wrapper(
            connect.start_oauth,
        )

    @cached_property
    def pages(self) -> AsyncPagesResourceWithRawResponse:
        return AsyncPagesResourceWithRawResponse(self._connect.pages)


class ConnectResourceWithStreamingResponse:
    def __init__(self, connect: ConnectResource) -> None:
        self._connect = connect

        self.finalize_oauth = to_streamed_response_wrapper(
            connect.finalize_oauth,
        )
        self.handle_callback = to_streamed_response_wrapper(
            connect.handle_callback,
        )
        self.start_oauth = to_streamed_response_wrapper(
            connect.start_oauth,
        )

    @cached_property
    def pages(self) -> PagesResourceWithStreamingResponse:
        return PagesResourceWithStreamingResponse(self._connect.pages)


class AsyncConnectResourceWithStreamingResponse:
    def __init__(self, connect: AsyncConnectResource) -> None:
        self._connect = connect

        self.finalize_oauth = async_to_streamed_response_wrapper(
            connect.finalize_oauth,
        )
        self.handle_callback = async_to_streamed_response_wrapper(
            connect.handle_callback,
        )
        self.start_oauth = async_to_streamed_response_wrapper(
            connect.start_oauth,
        )

    @cached_property
    def pages(self) -> AsyncPagesResourceWithStreamingResponse:
        return AsyncPagesResourceWithStreamingResponse(self._connect.pages)
