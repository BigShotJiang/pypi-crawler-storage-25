# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options

__all__ = ["BluejayResource", "AsyncBluejayResource"]


class BluejayResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> BluejayResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return BluejayResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BluejayResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return BluejayResourceWithStreamingResponse(self)

    def handle_outbound_simulation_started(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Handle outbound_simulation_started webhook from Bluejay.

        This endpoint is called by Bluejay when an outbound simulation has started. It
        validates the webhook signature using HMAC-SHA256 and enqueues call dispatch to
        digital humans for the allowed simulation ID as a background task.

        The endpoint returns immediately (202 Accepted) while call dispatch happens
        asynchronously. This prevents long-running HTTP connections and timeouts.

        Args: request: The request object containing the webhook payload

        Returns: 202: Accepted and processing started

        Raises: 400: Invalid request or validation error 401: Invalid webhook signature
        """
        return self._post(
            "/webhooks/bluejay/outbound_simulation_started",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncBluejayResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncBluejayResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncBluejayResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBluejayResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncBluejayResourceWithStreamingResponse(self)

    async def handle_outbound_simulation_started(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Handle outbound_simulation_started webhook from Bluejay.

        This endpoint is called by Bluejay when an outbound simulation has started. It
        validates the webhook signature using HMAC-SHA256 and enqueues call dispatch to
        digital humans for the allowed simulation ID as a background task.

        The endpoint returns immediately (202 Accepted) while call dispatch happens
        asynchronously. This prevents long-running HTTP connections and timeouts.

        Args: request: The request object containing the webhook payload

        Returns: 202: Accepted and processing started

        Raises: 400: Invalid request or validation error 401: Invalid webhook signature
        """
        return await self._post(
            "/webhooks/bluejay/outbound_simulation_started",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class BluejayResourceWithRawResponse:
    def __init__(self, bluejay: BluejayResource) -> None:
        self._bluejay = bluejay

        self.handle_outbound_simulation_started = to_raw_response_wrapper(
            bluejay.handle_outbound_simulation_started,
        )


class AsyncBluejayResourceWithRawResponse:
    def __init__(self, bluejay: AsyncBluejayResource) -> None:
        self._bluejay = bluejay

        self.handle_outbound_simulation_started = async_to_raw_response_wrapper(
            bluejay.handle_outbound_simulation_started,
        )


class BluejayResourceWithStreamingResponse:
    def __init__(self, bluejay: BluejayResource) -> None:
        self._bluejay = bluejay

        self.handle_outbound_simulation_started = to_streamed_response_wrapper(
            bluejay.handle_outbound_simulation_started,
        )


class AsyncBluejayResourceWithStreamingResponse:
    def __init__(self, bluejay: AsyncBluejayResource) -> None:
        self._bluejay = bluejay

        self.handle_outbound_simulation_started = async_to_streamed_response_wrapper(
            bluejay.handle_outbound_simulation_started,
        )
