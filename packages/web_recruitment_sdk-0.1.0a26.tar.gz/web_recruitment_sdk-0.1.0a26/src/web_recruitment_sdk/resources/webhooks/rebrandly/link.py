# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import strip_not_given
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options

__all__ = ["LinkResource", "AsyncLinkResource"]


class LinkResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> LinkResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return LinkResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LinkResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return LinkResourceWithStreamingResponse(self)

    def handle_clicked(
        self,
        *,
        apikey: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Handle booking link click webhook from external provider (e.g., Rebrandly).

        This endpoint acts as an orchestrator that receives webhook events from external
        link shortening providers when a booking link is clicked. It validates the
        webhook signature, extracts the necessary information (tenant, attempt ID), and
        enqueues the event for asynchronous processing by the system endpoint.

        The system endpoint (/system/{tenant_db_name}/outreach/booking_link/clicked)
        will then process the business logic of tracking the booking link click by
        creating an OutreachAction with BOOKING_LINK_CLICKED status.

        Args: request: The FastAPI request object containing the webhook payload

        Returns: 202: Accepted and queued for processing

        Raises: 400: Invalid request or validation error (e.g., missing tenant in URL)
        401: Invalid webhook signature/API key

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"apikey": apikey}), **(extra_headers or {})}
        return self._post(
            "/webhooks/rebrandly/link/clicked",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncLinkResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncLinkResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncLinkResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLinkResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncLinkResourceWithStreamingResponse(self)

    async def handle_clicked(
        self,
        *,
        apikey: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Handle booking link click webhook from external provider (e.g., Rebrandly).

        This endpoint acts as an orchestrator that receives webhook events from external
        link shortening providers when a booking link is clicked. It validates the
        webhook signature, extracts the necessary information (tenant, attempt ID), and
        enqueues the event for asynchronous processing by the system endpoint.

        The system endpoint (/system/{tenant_db_name}/outreach/booking_link/clicked)
        will then process the business logic of tracking the booking link click by
        creating an OutreachAction with BOOKING_LINK_CLICKED status.

        Args: request: The FastAPI request object containing the webhook payload

        Returns: 202: Accepted and queued for processing

        Raises: 400: Invalid request or validation error (e.g., missing tenant in URL)
        401: Invalid webhook signature/API key

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"apikey": apikey}), **(extra_headers or {})}
        return await self._post(
            "/webhooks/rebrandly/link/clicked",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class LinkResourceWithRawResponse:
    def __init__(self, link: LinkResource) -> None:
        self._link = link

        self.handle_clicked = to_raw_response_wrapper(
            link.handle_clicked,
        )


class AsyncLinkResourceWithRawResponse:
    def __init__(self, link: AsyncLinkResource) -> None:
        self._link = link

        self.handle_clicked = async_to_raw_response_wrapper(
            link.handle_clicked,
        )


class LinkResourceWithStreamingResponse:
    def __init__(self, link: LinkResource) -> None:
        self._link = link

        self.handle_clicked = to_streamed_response_wrapper(
            link.handle_clicked,
        )


class AsyncLinkResourceWithStreamingResponse:
    def __init__(self, link: AsyncLinkResource) -> None:
        self._link = link

        self.handle_clicked = async_to_streamed_response_wrapper(
            link.handle_clicked,
        )
