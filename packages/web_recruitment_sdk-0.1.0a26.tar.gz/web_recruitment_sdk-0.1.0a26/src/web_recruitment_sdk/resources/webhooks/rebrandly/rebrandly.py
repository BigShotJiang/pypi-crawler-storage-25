# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .link import (
    LinkResource,
    AsyncLinkResource,
    LinkResourceWithRawResponse,
    AsyncLinkResourceWithRawResponse,
    LinkResourceWithStreamingResponse,
    AsyncLinkResourceWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource

__all__ = ["RebrandlyResource", "AsyncRebrandlyResource"]


class RebrandlyResource(SyncAPIResource):
    @cached_property
    def link(self) -> LinkResource:
        return LinkResource(self._client)

    @cached_property
    def with_raw_response(self) -> RebrandlyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return RebrandlyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RebrandlyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return RebrandlyResourceWithStreamingResponse(self)


class AsyncRebrandlyResource(AsyncAPIResource):
    @cached_property
    def link(self) -> AsyncLinkResource:
        return AsyncLinkResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncRebrandlyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncRebrandlyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRebrandlyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncRebrandlyResourceWithStreamingResponse(self)


class RebrandlyResourceWithRawResponse:
    def __init__(self, rebrandly: RebrandlyResource) -> None:
        self._rebrandly = rebrandly

    @cached_property
    def link(self) -> LinkResourceWithRawResponse:
        return LinkResourceWithRawResponse(self._rebrandly.link)


class AsyncRebrandlyResourceWithRawResponse:
    def __init__(self, rebrandly: AsyncRebrandlyResource) -> None:
        self._rebrandly = rebrandly

    @cached_property
    def link(self) -> AsyncLinkResourceWithRawResponse:
        return AsyncLinkResourceWithRawResponse(self._rebrandly.link)


class RebrandlyResourceWithStreamingResponse:
    def __init__(self, rebrandly: RebrandlyResource) -> None:
        self._rebrandly = rebrandly

    @cached_property
    def link(self) -> LinkResourceWithStreamingResponse:
        return LinkResourceWithStreamingResponse(self._rebrandly.link)


class AsyncRebrandlyResourceWithStreamingResponse:
    def __init__(self, rebrandly: AsyncRebrandlyResource) -> None:
        self._rebrandly = rebrandly

    @cached_property
    def link(self) -> AsyncLinkResourceWithStreamingResponse:
        return AsyncLinkResourceWithStreamingResponse(self._rebrandly.link)
