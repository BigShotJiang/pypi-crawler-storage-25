# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.webhooks.facebook import lead_verify_params
from ....types.webhooks.facebook.lead_handle_lead_received_response import LeadHandleLeadReceivedResponse

__all__ = ["LeadsResource", "AsyncLeadsResource"]


class LeadsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> LeadsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return LeadsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LeadsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return LeadsResourceWithStreamingResponse(self)

    def handle_lead_received(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LeadHandleLeadReceivedResponse:
        """
        Receive Facebook lead webhook events.

        This endpoint is called by Facebook when a new lead is submitted through a Lead
        Ads form. The webhook signature is validated using HMAC-SHA256 with the app
        secret.

        For each leadgen event in the payload, the lead is enqueued to Cloud Tasks for
        asynchronous processing by the system endpoint.

        Args: request: The FastAPI request object containing the webhook payload

        Returns: 202: Accepted and queued for processing

        Raises: 400: Invalid request or validation error 401: Invalid webhook signature
        """
        return self._post(
            "/webhooks/facebook/leads",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LeadHandleLeadReceivedResponse,
        )

    def verify(
        self,
        *,
        hub: lead_verify_params.Hub | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Facebook webhook verification handshake.

        This endpoint is called by Facebook when setting up webhook subscriptions.
        Facebook sends a GET request with:

        - hub.mode: Should be "subscribe"
        - hub.verify_token: The verify token configured in the Facebook Developer
          Console
        - hub.challenge: A string that must be echoed back to verify the endpoint

        Returns: The hub.challenge value as plain text if verification succeeds

        Raises: 403: If verification fails (wrong mode or token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/webhooks/facebook/leads",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"hub": hub}, lead_verify_params.LeadVerifyParams),
            ),
            cast_to=object,
        )


class AsyncLeadsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncLeadsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncLeadsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLeadsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncLeadsResourceWithStreamingResponse(self)

    async def handle_lead_received(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LeadHandleLeadReceivedResponse:
        """
        Receive Facebook lead webhook events.

        This endpoint is called by Facebook when a new lead is submitted through a Lead
        Ads form. The webhook signature is validated using HMAC-SHA256 with the app
        secret.

        For each leadgen event in the payload, the lead is enqueued to Cloud Tasks for
        asynchronous processing by the system endpoint.

        Args: request: The FastAPI request object containing the webhook payload

        Returns: 202: Accepted and queued for processing

        Raises: 400: Invalid request or validation error 401: Invalid webhook signature
        """
        return await self._post(
            "/webhooks/facebook/leads",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LeadHandleLeadReceivedResponse,
        )

    async def verify(
        self,
        *,
        hub: lead_verify_params.Hub | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Facebook webhook verification handshake.

        This endpoint is called by Facebook when setting up webhook subscriptions.
        Facebook sends a GET request with:

        - hub.mode: Should be "subscribe"
        - hub.verify_token: The verify token configured in the Facebook Developer
          Console
        - hub.challenge: A string that must be echoed back to verify the endpoint

        Returns: The hub.challenge value as plain text if verification succeeds

        Raises: 403: If verification fails (wrong mode or token)

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/webhooks/facebook/leads",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"hub": hub}, lead_verify_params.LeadVerifyParams),
            ),
            cast_to=object,
        )


class LeadsResourceWithRawResponse:
    def __init__(self, leads: LeadsResource) -> None:
        self._leads = leads

        self.handle_lead_received = to_raw_response_wrapper(
            leads.handle_lead_received,
        )
        self.verify = to_raw_response_wrapper(
            leads.verify,
        )


class AsyncLeadsResourceWithRawResponse:
    def __init__(self, leads: AsyncLeadsResource) -> None:
        self._leads = leads

        self.handle_lead_received = async_to_raw_response_wrapper(
            leads.handle_lead_received,
        )
        self.verify = async_to_raw_response_wrapper(
            leads.verify,
        )


class LeadsResourceWithStreamingResponse:
    def __init__(self, leads: LeadsResource) -> None:
        self._leads = leads

        self.handle_lead_received = to_streamed_response_wrapper(
            leads.handle_lead_received,
        )
        self.verify = to_streamed_response_wrapper(
            leads.verify,
        )


class AsyncLeadsResourceWithStreamingResponse:
    def __init__(self, leads: AsyncLeadsResource) -> None:
        self._leads = leads

        self.handle_lead_received = async_to_streamed_response_wrapper(
            leads.handle_lead_received,
        )
        self.verify = async_to_streamed_response_wrapper(
            leads.verify,
        )
