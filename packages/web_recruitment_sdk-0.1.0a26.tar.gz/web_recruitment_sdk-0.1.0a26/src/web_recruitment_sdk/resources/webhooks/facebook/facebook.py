# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .leads import (
    LeadsResource,
    AsyncLeadsResource,
    LeadsResourceWithRawResponse,
    AsyncLeadsResourceWithRawResponse,
    LeadsResourceWithStreamingResponse,
    AsyncLeadsResourceWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource

__all__ = ["FacebookResource", "AsyncFacebookResource"]


class FacebookResource(SyncAPIResource):
    @cached_property
    def leads(self) -> LeadsResource:
        return LeadsResource(self._client)

    @cached_property
    def with_raw_response(self) -> FacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return FacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return FacebookResourceWithStreamingResponse(self)


class AsyncFacebookResource(AsyncAPIResource):
    @cached_property
    def leads(self) -> AsyncLeadsResource:
        return AsyncLeadsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncFacebookResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncFacebookResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFacebookResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncFacebookResourceWithStreamingResponse(self)


class FacebookResourceWithRawResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def leads(self) -> LeadsResourceWithRawResponse:
        return LeadsResourceWithRawResponse(self._facebook.leads)


class AsyncFacebookResourceWithRawResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def leads(self) -> AsyncLeadsResourceWithRawResponse:
        return AsyncLeadsResourceWithRawResponse(self._facebook.leads)


class FacebookResourceWithStreamingResponse:
    def __init__(self, facebook: FacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def leads(self) -> LeadsResourceWithStreamingResponse:
        return LeadsResourceWithStreamingResponse(self._facebook.leads)


class AsyncFacebookResourceWithStreamingResponse:
    def __init__(self, facebook: AsyncFacebookResource) -> None:
        self._facebook = facebook

    @cached_property
    def leads(self) -> AsyncLeadsResourceWithStreamingResponse:
        return AsyncLeadsResourceWithStreamingResponse(self._facebook.leads)
