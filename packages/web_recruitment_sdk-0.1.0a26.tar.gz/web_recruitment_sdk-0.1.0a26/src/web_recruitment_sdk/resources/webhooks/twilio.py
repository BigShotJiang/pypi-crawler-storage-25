# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NoneType, NotGiven, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options

__all__ = ["TwilioResource", "AsyncTwilioResource"]


class TwilioResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> TwilioResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return TwilioResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TwilioResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return TwilioResourceWithStreamingResponse(self)

    def handle_inbound_sms(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Handle inbound SMS webhook from Twilio.

        Each Twilio number is configured with a tenant-specific webhook URL:
        https://api.example.com/webhooks/twilio/inbound-sms/{tenant_db_name}

        Validates the Twilio signature, extracts From/To/Body, and enqueues the event
        for async processing by the system endpoint. Used for STOP/START opt-out
        handling in booking page abandonment SMS reminders.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            path_template("/webhooks/twilio/inbound-sms/{tenant_db_name}", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncTwilioResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncTwilioResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncTwilioResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTwilioResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncTwilioResourceWithStreamingResponse(self)

    async def handle_inbound_sms(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Handle inbound SMS webhook from Twilio.

        Each Twilio number is configured with a tenant-specific webhook URL:
        https://api.example.com/webhooks/twilio/inbound-sms/{tenant_db_name}

        Validates the Twilio signature, extracts From/To/Body, and enqueues the event
        for async processing by the system endpoint. Used for STOP/START opt-out
        handling in booking page abandonment SMS reminders.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            path_template("/webhooks/twilio/inbound-sms/{tenant_db_name}", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class TwilioResourceWithRawResponse:
    def __init__(self, twilio: TwilioResource) -> None:
        self._twilio = twilio

        self.handle_inbound_sms = to_raw_response_wrapper(
            twilio.handle_inbound_sms,
        )


class AsyncTwilioResourceWithRawResponse:
    def __init__(self, twilio: AsyncTwilioResource) -> None:
        self._twilio = twilio

        self.handle_inbound_sms = async_to_raw_response_wrapper(
            twilio.handle_inbound_sms,
        )


class TwilioResourceWithStreamingResponse:
    def __init__(self, twilio: TwilioResource) -> None:
        self._twilio = twilio

        self.handle_inbound_sms = to_streamed_response_wrapper(
            twilio.handle_inbound_sms,
        )


class AsyncTwilioResourceWithStreamingResponse:
    def __init__(self, twilio: AsyncTwilioResource) -> None:
        self._twilio = twilio

        self.handle_inbound_sms = async_to_streamed_response_wrapper(
            twilio.handle_inbound_sms,
        )
