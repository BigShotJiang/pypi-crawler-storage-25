# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system import concurrency_acquire_params, concurrency_release_params, concurrency_retrieve_status_params
from ...types.system.concurrency_acquire_response import ConcurrencyAcquireResponse
from ...types.system.concurrency_release_response import ConcurrencyReleaseResponse
from ...types.system.concurrency_retrieve_status_response import ConcurrencyRetrieveStatusResponse

__all__ = ["ConcurrencyResource", "AsyncConcurrencyResource"]


class ConcurrencyResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ConcurrencyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return ConcurrencyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ConcurrencyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return ConcurrencyResourceWithStreamingResponse(self)

    def acquire(
        self,
        tenant_db_name: str,
        *,
        workflow_id: str,
        concurrency_limit: int | Omit = omit,
        campaign_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyAcquireResponse:
        """
        Acquire a concurrency slot for a tenant.

        Atomically checks and increments the tenant's concurrency counter. Returns an
        error if the tenant has reached their concurrency limit.

        Args:
          workflow_id: Unique workflow ID for slot tracking

          campaign_id: Optional campaign ID for scoped concurrency

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/concurrency/acquire", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "workflow_id": workflow_id,
                    "campaign_id": campaign_id,
                },
                concurrency_acquire_params.ConcurrencyAcquireParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_acquire_params.ConcurrencyAcquireParams
                ),
            ),
            cast_to=ConcurrencyAcquireResponse,
        )

    def release(
        self,
        tenant_db_name: str,
        *,
        workflow_id: str,
        concurrency_limit: int | Omit = omit,
        campaign_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyReleaseResponse:
        """
        Release a concurrency slot for a tenant.

        Atomically decrements the tenant's concurrency counter. Safe to call even if the
        counter is already at 0.

        Args:
          workflow_id: Workflow ID that acquired the slot

          campaign_id: Optional campaign ID for scoped concurrency

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/concurrency/release", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "workflow_id": workflow_id,
                    "campaign_id": campaign_id,
                },
                concurrency_release_params.ConcurrencyReleaseParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_release_params.ConcurrencyReleaseParams
                ),
            ),
            cast_to=ConcurrencyReleaseResponse,
        )

    def retrieve_status(
        self,
        tenant_db_name: str,
        *,
        campaign_id: Optional[int] | Omit = omit,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyRetrieveStatusResponse:
        """
        Get the current concurrency status for a tenant.

        Returns the current count, limit, and available slots.

        Args:
          campaign_id: Optional campaign ID to scope concurrency status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/concurrency/status", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "campaign_id": campaign_id,
                        "concurrency_limit": concurrency_limit,
                    },
                    concurrency_retrieve_status_params.ConcurrencyRetrieveStatusParams,
                ),
            ),
            cast_to=ConcurrencyRetrieveStatusResponse,
        )


class AsyncConcurrencyResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncConcurrencyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncConcurrencyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncConcurrencyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncConcurrencyResourceWithStreamingResponse(self)

    async def acquire(
        self,
        tenant_db_name: str,
        *,
        workflow_id: str,
        concurrency_limit: int | Omit = omit,
        campaign_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyAcquireResponse:
        """
        Acquire a concurrency slot for a tenant.

        Atomically checks and increments the tenant's concurrency counter. Returns an
        error if the tenant has reached their concurrency limit.

        Args:
          workflow_id: Unique workflow ID for slot tracking

          campaign_id: Optional campaign ID for scoped concurrency

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/concurrency/acquire", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "workflow_id": workflow_id,
                    "campaign_id": campaign_id,
                },
                concurrency_acquire_params.ConcurrencyAcquireParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_acquire_params.ConcurrencyAcquireParams
                ),
            ),
            cast_to=ConcurrencyAcquireResponse,
        )

    async def release(
        self,
        tenant_db_name: str,
        *,
        workflow_id: str,
        concurrency_limit: int | Omit = omit,
        campaign_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyReleaseResponse:
        """
        Release a concurrency slot for a tenant.

        Atomically decrements the tenant's concurrency counter. Safe to call even if the
        counter is already at 0.

        Args:
          workflow_id: Workflow ID that acquired the slot

          campaign_id: Optional campaign ID for scoped concurrency

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/concurrency/release", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "workflow_id": workflow_id,
                    "campaign_id": campaign_id,
                },
                concurrency_release_params.ConcurrencyReleaseParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concurrency_limit": concurrency_limit}, concurrency_release_params.ConcurrencyReleaseParams
                ),
            ),
            cast_to=ConcurrencyReleaseResponse,
        )

    async def retrieve_status(
        self,
        tenant_db_name: str,
        *,
        campaign_id: Optional[int] | Omit = omit,
        concurrency_limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ConcurrencyRetrieveStatusResponse:
        """
        Get the current concurrency status for a tenant.

        Returns the current count, limit, and available slots.

        Args:
          campaign_id: Optional campaign ID to scope concurrency status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/concurrency/status", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "campaign_id": campaign_id,
                        "concurrency_limit": concurrency_limit,
                    },
                    concurrency_retrieve_status_params.ConcurrencyRetrieveStatusParams,
                ),
            ),
            cast_to=ConcurrencyRetrieveStatusResponse,
        )


class ConcurrencyResourceWithRawResponse:
    def __init__(self, concurrency: ConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire = to_raw_response_wrapper(
            concurrency.acquire,
        )
        self.release = to_raw_response_wrapper(
            concurrency.release,
        )
        self.retrieve_status = to_raw_response_wrapper(
            concurrency.retrieve_status,
        )


class AsyncConcurrencyResourceWithRawResponse:
    def __init__(self, concurrency: AsyncConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire = async_to_raw_response_wrapper(
            concurrency.acquire,
        )
        self.release = async_to_raw_response_wrapper(
            concurrency.release,
        )
        self.retrieve_status = async_to_raw_response_wrapper(
            concurrency.retrieve_status,
        )


class ConcurrencyResourceWithStreamingResponse:
    def __init__(self, concurrency: ConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire = to_streamed_response_wrapper(
            concurrency.acquire,
        )
        self.release = to_streamed_response_wrapper(
            concurrency.release,
        )
        self.retrieve_status = to_streamed_response_wrapper(
            concurrency.retrieve_status,
        )


class AsyncConcurrencyResourceWithStreamingResponse:
    def __init__(self, concurrency: AsyncConcurrencyResource) -> None:
        self._concurrency = concurrency

        self.acquire = async_to_streamed_response_wrapper(
            concurrency.acquire,
        )
        self.release = async_to_streamed_response_wrapper(
            concurrency.release,
        )
        self.retrieve_status = async_to_streamed_response_wrapper(
            concurrency.retrieve_status,
        )
