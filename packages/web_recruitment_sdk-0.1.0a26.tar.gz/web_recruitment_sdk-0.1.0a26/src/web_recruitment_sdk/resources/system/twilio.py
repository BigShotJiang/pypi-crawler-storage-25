# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system import twilio_process_inbound_sms_params

__all__ = ["TwilioResource", "AsyncTwilioResource"]


class TwilioResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> TwilioResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return TwilioResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TwilioResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return TwilioResourceWithStreamingResponse(self)

    def process_inbound_sms(
        self,
        tenant_db_name: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Process Twilio inbound SMS for STOP/START opt-out.

        Tenant is specified in the URL path (each Twilio number has a tenant-specific
        webhook URL). Parses Body for STOP/START keywords and updates
        Person.sms_opted_out accordingly.

        Args:
          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/twilio/inbound-sms", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "webhook_data": webhook_data,
                    "webhook_type": webhook_type,
                },
                twilio_process_inbound_sms_params.TwilioProcessInboundSMSParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncTwilioResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncTwilioResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncTwilioResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTwilioResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncTwilioResourceWithStreamingResponse(self)

    async def process_inbound_sms(
        self,
        tenant_db_name: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Process Twilio inbound SMS for STOP/START opt-out.

        Tenant is specified in the URL path (each Twilio number has a tenant-specific
        webhook URL). Parses Body for STOP/START keywords and updates
        Person.sms_opted_out accordingly.

        Args:
          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/twilio/inbound-sms", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "webhook_data": webhook_data,
                    "webhook_type": webhook_type,
                },
                twilio_process_inbound_sms_params.TwilioProcessInboundSMSParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class TwilioResourceWithRawResponse:
    def __init__(self, twilio: TwilioResource) -> None:
        self._twilio = twilio

        self.process_inbound_sms = to_raw_response_wrapper(
            twilio.process_inbound_sms,
        )


class AsyncTwilioResourceWithRawResponse:
    def __init__(self, twilio: AsyncTwilioResource) -> None:
        self._twilio = twilio

        self.process_inbound_sms = async_to_raw_response_wrapper(
            twilio.process_inbound_sms,
        )


class TwilioResourceWithStreamingResponse:
    def __init__(self, twilio: TwilioResource) -> None:
        self._twilio = twilio

        self.process_inbound_sms = to_streamed_response_wrapper(
            twilio.process_inbound_sms,
        )


class AsyncTwilioResourceWithStreamingResponse:
    def __init__(self, twilio: AsyncTwilioResource) -> None:
        self._twilio = twilio

        self.process_inbound_sms = async_to_streamed_response_wrapper(
            twilio.process_inbound_sms,
        )
