# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.booking import availability_get_time_slots_params, availability_get_available_dates_params
from ....types.system.booking.availability_get_time_slots_response import AvailabilityGetTimeSlotsResponse
from ....types.system.booking.availability_get_available_dates_response import AvailabilityGetAvailableDatesResponse

__all__ = ["AvailabilityResource", "AsyncAvailabilityResource"]


class AvailabilityResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AvailabilityResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AvailabilityResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AvailabilityResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AvailabilityResourceWithStreamingResponse(self)

    def get_available_dates(
        self,
        tenant_db_name: str,
        *,
        end_date: Union[str, date],
        start_date: Union[str, date],
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AvailabilityGetAvailableDatesResponse:
        """
        Get dates with available appointment slots.

        Validates JWT and returns dates that have at least one available slot. Max date
        range is 60 days. When `calendar_config_id` query param is provided, the
        scheduling provider is scoped to that single site.

        Returns: - available_dates: List of dates with available slots - timezone: The
        timezone for the dates

        Args:
          end_date: End of date range (max 60 days)

          start_date: Start of date range

          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/booking/availability/dates", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "calendar_config_id": calendar_config_id,
                    },
                    availability_get_available_dates_params.AvailabilityGetAvailableDatesParams,
                ),
            ),
            cast_to=AvailabilityGetAvailableDatesResponse,
        )

    def get_time_slots(
        self,
        tenant_db_name: str,
        *,
        date: Union[str, date],
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AvailabilityGetTimeSlotsResponse:
        """
        Get available time slots for a specific date.

        Validates JWT and returns available slots for the requested date. When
        `calendar_config_id` query param is provided, the scheduling provider is scoped
        to that single site.

        Returns: - date: The requested date - slots: List of available time slots with
        id, start_time, end_time - timezone: The timezone for the times

        Args:
          date: Date to get slots for

          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/booking/availability/slots", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "date": date,
                        "calendar_config_id": calendar_config_id,
                    },
                    availability_get_time_slots_params.AvailabilityGetTimeSlotsParams,
                ),
            ),
            cast_to=AvailabilityGetTimeSlotsResponse,
        )


class AsyncAvailabilityResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAvailabilityResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAvailabilityResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAvailabilityResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncAvailabilityResourceWithStreamingResponse(self)

    async def get_available_dates(
        self,
        tenant_db_name: str,
        *,
        end_date: Union[str, date],
        start_date: Union[str, date],
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AvailabilityGetAvailableDatesResponse:
        """
        Get dates with available appointment slots.

        Validates JWT and returns dates that have at least one available slot. Max date
        range is 60 days. When `calendar_config_id` query param is provided, the
        scheduling provider is scoped to that single site.

        Returns: - available_dates: List of dates with available slots - timezone: The
        timezone for the dates

        Args:
          end_date: End of date range (max 60 days)

          start_date: Start of date range

          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/booking/availability/dates", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "calendar_config_id": calendar_config_id,
                    },
                    availability_get_available_dates_params.AvailabilityGetAvailableDatesParams,
                ),
            ),
            cast_to=AvailabilityGetAvailableDatesResponse,
        )

    async def get_time_slots(
        self,
        tenant_db_name: str,
        *,
        date: Union[str, date],
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AvailabilityGetTimeSlotsResponse:
        """
        Get available time slots for a specific date.

        Validates JWT and returns available slots for the requested date. When
        `calendar_config_id` query param is provided, the scheduling provider is scoped
        to that single site.

        Returns: - date: The requested date - slots: List of available time slots with
        id, start_time, end_time - timezone: The timezone for the times

        Args:
          date: Date to get slots for

          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/booking/availability/slots", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "date": date,
                        "calendar_config_id": calendar_config_id,
                    },
                    availability_get_time_slots_params.AvailabilityGetTimeSlotsParams,
                ),
            ),
            cast_to=AvailabilityGetTimeSlotsResponse,
        )


class AvailabilityResourceWithRawResponse:
    def __init__(self, availability: AvailabilityResource) -> None:
        self._availability = availability

        self.get_available_dates = to_raw_response_wrapper(
            availability.get_available_dates,
        )
        self.get_time_slots = to_raw_response_wrapper(
            availability.get_time_slots,
        )


class AsyncAvailabilityResourceWithRawResponse:
    def __init__(self, availability: AsyncAvailabilityResource) -> None:
        self._availability = availability

        self.get_available_dates = async_to_raw_response_wrapper(
            availability.get_available_dates,
        )
        self.get_time_slots = async_to_raw_response_wrapper(
            availability.get_time_slots,
        )


class AvailabilityResourceWithStreamingResponse:
    def __init__(self, availability: AvailabilityResource) -> None:
        self._availability = availability

        self.get_available_dates = to_streamed_response_wrapper(
            availability.get_available_dates,
        )
        self.get_time_slots = to_streamed_response_wrapper(
            availability.get_time_slots,
        )


class AsyncAvailabilityResourceWithStreamingResponse:
    def __init__(self, availability: AsyncAvailabilityResource) -> None:
        self._availability = availability

        self.get_available_dates = async_to_streamed_response_wrapper(
            availability.get_available_dates,
        )
        self.get_time_slots = async_to_streamed_response_wrapper(
            availability.get_time_slots,
        )
