# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.booking import appointment_get_appointment_params, appointment_book_appointment_params
from ....types.system.booking.appointment_get_appointment_response import AppointmentGetAppointmentResponse
from ....types.system.booking.appointment_book_appointment_response import AppointmentBookAppointmentResponse

__all__ = ["AppointmentResource", "AsyncAppointmentResource"]


class AppointmentResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AppointmentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AppointmentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AppointmentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AppointmentResourceWithStreamingResponse(self)

    def book_appointment(
        self,
        tenant_db_name: str,
        *,
        selected_time: Union[str, datetime],
        slot_id: str,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentBookAppointmentResponse:
        """
        Book an appointment for the selected time slot.

        Validates JWT, books the appointment via the scheduling provider, and tracks
        analytics and outreach actions.

        Returns: - appointment_id: The created appointment ID - scheduled_datetime: The
        scheduled date/time - duration_minutes: Duration of the appointment - location:
        Appointment location (optional) - contact_phone: Site or landing-page contact
        phone when configured (optional)

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/booking/appointment", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "selected_time": selected_time,
                    "slot_id": slot_id,
                },
                appointment_book_appointment_params.AppointmentBookAppointmentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    appointment_book_appointment_params.AppointmentBookAppointmentParams,
                ),
            ),
            cast_to=AppointmentBookAppointmentResponse,
        )

    def get_appointment(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Optional[AppointmentGetAppointmentResponse]:
        """
        Get existing appointment for the candidate if any.

        Validates JWT and returns the appointment details if one exists.

        Returns: - AppointmentSummary with id, scheduled_datetime, duration_minutes,
        status - null if no appointment exists

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/booking/appointment", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    appointment_get_appointment_params.AppointmentGetAppointmentParams,
                ),
            ),
            cast_to=AppointmentGetAppointmentResponse,
        )


class AsyncAppointmentResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAppointmentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAppointmentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAppointmentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncAppointmentResourceWithStreamingResponse(self)

    async def book_appointment(
        self,
        tenant_db_name: str,
        *,
        selected_time: Union[str, datetime],
        slot_id: str,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AppointmentBookAppointmentResponse:
        """
        Book an appointment for the selected time slot.

        Validates JWT, books the appointment via the scheduling provider, and tracks
        analytics and outreach actions.

        Returns: - appointment_id: The created appointment ID - scheduled_datetime: The
        scheduled date/time - duration_minutes: Duration of the appointment - location:
        Appointment location (optional) - contact_phone: Site or landing-page contact
        phone when configured (optional)

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/booking/appointment", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "selected_time": selected_time,
                    "slot_id": slot_id,
                },
                appointment_book_appointment_params.AppointmentBookAppointmentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    appointment_book_appointment_params.AppointmentBookAppointmentParams,
                ),
            ),
            cast_to=AppointmentBookAppointmentResponse,
        )

    async def get_appointment(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Optional[AppointmentGetAppointmentResponse]:
        """
        Get existing appointment for the candidate if any.

        Validates JWT and returns the appointment details if one exists.

        Returns: - AppointmentSummary with id, scheduled_datetime, duration_minutes,
        status - null if no appointment exists

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/booking/appointment", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    appointment_get_appointment_params.AppointmentGetAppointmentParams,
                ),
            ),
            cast_to=AppointmentGetAppointmentResponse,
        )


class AppointmentResourceWithRawResponse:
    def __init__(self, appointment: AppointmentResource) -> None:
        self._appointment = appointment

        self.book_appointment = to_raw_response_wrapper(
            appointment.book_appointment,
        )
        self.get_appointment = to_raw_response_wrapper(
            appointment.get_appointment,
        )


class AsyncAppointmentResourceWithRawResponse:
    def __init__(self, appointment: AsyncAppointmentResource) -> None:
        self._appointment = appointment

        self.book_appointment = async_to_raw_response_wrapper(
            appointment.book_appointment,
        )
        self.get_appointment = async_to_raw_response_wrapper(
            appointment.get_appointment,
        )


class AppointmentResourceWithStreamingResponse:
    def __init__(self, appointment: AppointmentResource) -> None:
        self._appointment = appointment

        self.book_appointment = to_streamed_response_wrapper(
            appointment.book_appointment,
        )
        self.get_appointment = to_streamed_response_wrapper(
            appointment.get_appointment,
        )


class AsyncAppointmentResourceWithStreamingResponse:
    def __init__(self, appointment: AsyncAppointmentResource) -> None:
        self._appointment = appointment

        self.book_appointment = async_to_streamed_response_wrapper(
            appointment.book_appointment,
        )
        self.get_appointment = async_to_streamed_response_wrapper(
            appointment.get_appointment,
        )
