# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from datetime import date

import httpx

from .config import (
    ConfigResource,
    AsyncConfigResource,
    ConfigResourceWithRawResponse,
    AsyncConfigResourceWithRawResponse,
    ConfigResourceWithStreamingResponse,
    AsyncConfigResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from .appointment import (
    AppointmentResource,
    AsyncAppointmentResource,
    AppointmentResourceWithRawResponse,
    AsyncAppointmentResourceWithRawResponse,
    AppointmentResourceWithStreamingResponse,
    AsyncAppointmentResourceWithStreamingResponse,
)
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .availability import (
    AvailabilityResource,
    AsyncAvailabilityResource,
    AvailabilityResourceWithRawResponse,
    AsyncAvailabilityResourceWithRawResponse,
    AvailabilityResourceWithStreamingResponse,
    AsyncAvailabilityResourceWithStreamingResponse,
)
from ...._base_client import make_request_options
from ....types.system import (
    booking_get_status_params,
    booking_submit_intake_params,
    booking_get_visit_info_params,
    booking_submit_screening_params,
)
from ....types.system.booking_get_status_response import BookingGetStatusResponse
from ....types.system.booking_submit_intake_response import BookingSubmitIntakeResponse
from ....types.system.booking_get_visit_info_response import BookingGetVisitInfoResponse
from ....types.system.booking_submit_screening_response import BookingSubmitScreeningResponse

__all__ = ["BookingResource", "AsyncBookingResource"]


class BookingResource(SyncAPIResource):
    @cached_property
    def availability(self) -> AvailabilityResource:
        return AvailabilityResource(self._client)

    @cached_property
    def appointment(self) -> AppointmentResource:
        return AppointmentResource(self._client)

    @cached_property
    def config(self) -> ConfigResource:
        return ConfigResource(self._client)

    @cached_property
    def with_raw_response(self) -> BookingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return BookingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BookingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return BookingResourceWithStreamingResponse(self)

    def get_status(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        slug: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingGetStatusResponse:
        """
        Get booking page status for a given token.

        Validates JWT, checks site and attempt exist, and returns current status. Tracks
        BOOKING_PAGE_OPENED analytics event.

        When slug is provided, validates it matches the attempt's campaign's landing
        page in the database to prevent cross-study access.

        Returns: - status: "new" if intake is not completed - status: "intake_passed" if
        intake completed and ready for screening - status: "intake_failed" if intake
        completed but age gate failed - status: "screening_passed" if screening
        submitted and passed - status: "screening_failed" if screening submitted and
        failed - status: "booked" if candidate has an active appointment -
        tenant_calendar_url: Only included when status == "screening_passed"

        Raises: BadRequestError: If slug does not match the attempt's landing page

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          slug: Landing page slug for cross-study validation

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/booking/status", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "calendar_config_id": calendar_config_id,
                        "slug": slug,
                    },
                    booking_get_status_params.BookingGetStatusParams,
                ),
            ),
            cast_to=BookingGetStatusResponse,
        )

    def get_visit_info(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingGetVisitInfoResponse:
        """
        Get visit info for the booking widget.

        Returns the target visit details including duration for display.

        Returns: - visit_id: The visit type ID - visit_name: The visit name -
        duration_minutes: Configured appointment duration in minutes

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/booking/visit-info", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"calendar_config_id": calendar_config_id}, booking_get_visit_info_params.BookingGetVisitInfoParams
                ),
            ),
            cast_to=BookingGetVisitInfoResponse,
        )

    def submit_intake(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        bmi: Optional[booking_submit_intake_params.Bmi] | Omit = omit,
        dob: Union[str, date, None] | Omit = omit,
        family_name: Optional[str] | Omit = omit,
        given_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingSubmitIntakeResponse:
        """
        Submit intake demographics for a booking page.

        Validates JWT, validates intake fields against landing page config, updates
        Person demographics, and evaluates configured eligibility gates (age, BMI).

        Returns: - passed: True if all configured gates pass - gate_evaluations:
        Per-gate results with value and thresholds

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          bmi: Height/weight data submitted for BMI intake field.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/booking/intake", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "bmi": bmi,
                    "dob": dob,
                    "family_name": family_name,
                    "given_name": given_name,
                },
                booking_submit_intake_params.BookingSubmitIntakeParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"calendar_config_id": calendar_config_id}, booking_submit_intake_params.BookingSubmitIntakeParams
                ),
            ),
            cast_to=BookingSubmitIntakeResponse,
        )

    def submit_screening(
        self,
        tenant_db_name: str,
        *,
        answers: Dict[str, str],
        screening_passed: bool,
        calendar_config_id: Optional[int] | Omit = omit,
        candidate_email: Optional[str] | Omit = omit,
        candidate_name: Optional[str] | Omit = omit,
        candidate_phone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingSubmitScreeningResponse:
        """
        Submit screening result and contact info for a booking page.

        Validates JWT, checks site and attempt exist, saves the submission. If already
        submitted, returns existing status (idempotent). Tracks
        BOOKING_SCREENING_SUBMITTED analytics event.

        Returns: - screening_passed: True if candidate passed screening -
        tenant_calendar_url: Only included when screening_passed=True

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/booking/screening", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "answers": answers,
                    "screening_passed": screening_passed,
                    "candidate_email": candidate_email,
                    "candidate_name": candidate_name,
                    "candidate_phone": candidate_phone,
                },
                booking_submit_screening_params.BookingSubmitScreeningParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    booking_submit_screening_params.BookingSubmitScreeningParams,
                ),
            ),
            cast_to=BookingSubmitScreeningResponse,
        )


class AsyncBookingResource(AsyncAPIResource):
    @cached_property
    def availability(self) -> AsyncAvailabilityResource:
        return AsyncAvailabilityResource(self._client)

    @cached_property
    def appointment(self) -> AsyncAppointmentResource:
        return AsyncAppointmentResource(self._client)

    @cached_property
    def config(self) -> AsyncConfigResource:
        return AsyncConfigResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncBookingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncBookingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBookingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncBookingResourceWithStreamingResponse(self)

    async def get_status(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        slug: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingGetStatusResponse:
        """
        Get booking page status for a given token.

        Validates JWT, checks site and attempt exist, and returns current status. Tracks
        BOOKING_PAGE_OPENED analytics event.

        When slug is provided, validates it matches the attempt's campaign's landing
        page in the database to prevent cross-study access.

        Returns: - status: "new" if intake is not completed - status: "intake_passed" if
        intake completed and ready for screening - status: "intake_failed" if intake
        completed but age gate failed - status: "screening_passed" if screening
        submitted and passed - status: "screening_failed" if screening submitted and
        failed - status: "booked" if candidate has an active appointment -
        tenant_calendar_url: Only included when status == "screening_passed"

        Raises: BadRequestError: If slug does not match the attempt's landing page

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          slug: Landing page slug for cross-study validation

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/booking/status", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "calendar_config_id": calendar_config_id,
                        "slug": slug,
                    },
                    booking_get_status_params.BookingGetStatusParams,
                ),
            ),
            cast_to=BookingGetStatusResponse,
        )

    async def get_visit_info(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingGetVisitInfoResponse:
        """
        Get visit info for the booking widget.

        Returns the target visit details including duration for display.

        Returns: - visit_id: The visit type ID - visit_name: The visit name -
        duration_minutes: Configured appointment duration in minutes

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/booking/visit-info", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"calendar_config_id": calendar_config_id}, booking_get_visit_info_params.BookingGetVisitInfoParams
                ),
            ),
            cast_to=BookingGetVisitInfoResponse,
        )

    async def submit_intake(
        self,
        tenant_db_name: str,
        *,
        calendar_config_id: Optional[int] | Omit = omit,
        bmi: Optional[booking_submit_intake_params.Bmi] | Omit = omit,
        dob: Union[str, date, None] | Omit = omit,
        family_name: Optional[str] | Omit = omit,
        given_name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingSubmitIntakeResponse:
        """
        Submit intake demographics for a booking page.

        Validates JWT, validates intake fields against landing page config, updates
        Person demographics, and evaluates configured eligibility gates (age, BMI).

        Returns: - passed: True if all configured gates pass - gate_evaluations:
        Per-gate results with value and thresholds

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          bmi: Height/weight data submitted for BMI intake field.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/booking/intake", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "bmi": bmi,
                    "dob": dob,
                    "family_name": family_name,
                    "given_name": given_name,
                },
                booking_submit_intake_params.BookingSubmitIntakeParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"calendar_config_id": calendar_config_id}, booking_submit_intake_params.BookingSubmitIntakeParams
                ),
            ),
            cast_to=BookingSubmitIntakeResponse,
        )

    async def submit_screening(
        self,
        tenant_db_name: str,
        *,
        answers: Dict[str, str],
        screening_passed: bool,
        calendar_config_id: Optional[int] | Omit = omit,
        candidate_email: Optional[str] | Omit = omit,
        candidate_name: Optional[str] | Omit = omit,
        candidate_phone: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingSubmitScreeningResponse:
        """
        Submit screening result and contact info for a booking page.

        Validates JWT, checks site and attempt exist, saves the submission. If already
        submitted, returns existing status (idempotent). Tracks
        BOOKING_SCREENING_SUBMITTED analytics event.

        Returns: - screening_passed: True if candidate passed screening -
        tenant_calendar_url: Only included when screening_passed=True

        Args:
          calendar_config_id: Scope availability to a specific booking calendar (site). Omit to include all
              configured calendars.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/booking/screening", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "answers": answers,
                    "screening_passed": screening_passed,
                    "candidate_email": candidate_email,
                    "candidate_name": candidate_name,
                    "candidate_phone": candidate_phone,
                },
                booking_submit_screening_params.BookingSubmitScreeningParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"calendar_config_id": calendar_config_id},
                    booking_submit_screening_params.BookingSubmitScreeningParams,
                ),
            ),
            cast_to=BookingSubmitScreeningResponse,
        )


class BookingResourceWithRawResponse:
    def __init__(self, booking: BookingResource) -> None:
        self._booking = booking

        self.get_status = to_raw_response_wrapper(
            booking.get_status,
        )
        self.get_visit_info = to_raw_response_wrapper(
            booking.get_visit_info,
        )
        self.submit_intake = to_raw_response_wrapper(
            booking.submit_intake,
        )
        self.submit_screening = to_raw_response_wrapper(
            booking.submit_screening,
        )

    @cached_property
    def availability(self) -> AvailabilityResourceWithRawResponse:
        return AvailabilityResourceWithRawResponse(self._booking.availability)

    @cached_property
    def appointment(self) -> AppointmentResourceWithRawResponse:
        return AppointmentResourceWithRawResponse(self._booking.appointment)

    @cached_property
    def config(self) -> ConfigResourceWithRawResponse:
        return ConfigResourceWithRawResponse(self._booking.config)


class AsyncBookingResourceWithRawResponse:
    def __init__(self, booking: AsyncBookingResource) -> None:
        self._booking = booking

        self.get_status = async_to_raw_response_wrapper(
            booking.get_status,
        )
        self.get_visit_info = async_to_raw_response_wrapper(
            booking.get_visit_info,
        )
        self.submit_intake = async_to_raw_response_wrapper(
            booking.submit_intake,
        )
        self.submit_screening = async_to_raw_response_wrapper(
            booking.submit_screening,
        )

    @cached_property
    def availability(self) -> AsyncAvailabilityResourceWithRawResponse:
        return AsyncAvailabilityResourceWithRawResponse(self._booking.availability)

    @cached_property
    def appointment(self) -> AsyncAppointmentResourceWithRawResponse:
        return AsyncAppointmentResourceWithRawResponse(self._booking.appointment)

    @cached_property
    def config(self) -> AsyncConfigResourceWithRawResponse:
        return AsyncConfigResourceWithRawResponse(self._booking.config)


class BookingResourceWithStreamingResponse:
    def __init__(self, booking: BookingResource) -> None:
        self._booking = booking

        self.get_status = to_streamed_response_wrapper(
            booking.get_status,
        )
        self.get_visit_info = to_streamed_response_wrapper(
            booking.get_visit_info,
        )
        self.submit_intake = to_streamed_response_wrapper(
            booking.submit_intake,
        )
        self.submit_screening = to_streamed_response_wrapper(
            booking.submit_screening,
        )

    @cached_property
    def availability(self) -> AvailabilityResourceWithStreamingResponse:
        return AvailabilityResourceWithStreamingResponse(self._booking.availability)

    @cached_property
    def appointment(self) -> AppointmentResourceWithStreamingResponse:
        return AppointmentResourceWithStreamingResponse(self._booking.appointment)

    @cached_property
    def config(self) -> ConfigResourceWithStreamingResponse:
        return ConfigResourceWithStreamingResponse(self._booking.config)


class AsyncBookingResourceWithStreamingResponse:
    def __init__(self, booking: AsyncBookingResource) -> None:
        self._booking = booking

        self.get_status = async_to_streamed_response_wrapper(
            booking.get_status,
        )
        self.get_visit_info = async_to_streamed_response_wrapper(
            booking.get_visit_info,
        )
        self.submit_intake = async_to_streamed_response_wrapper(
            booking.submit_intake,
        )
        self.submit_screening = async_to_streamed_response_wrapper(
            booking.submit_screening,
        )

    @cached_property
    def availability(self) -> AsyncAvailabilityResourceWithStreamingResponse:
        return AsyncAvailabilityResourceWithStreamingResponse(self._booking.availability)

    @cached_property
    def appointment(self) -> AsyncAppointmentResourceWithStreamingResponse:
        return AsyncAppointmentResourceWithStreamingResponse(self._booking.appointment)

    @cached_property
    def config(self) -> AsyncConfigResourceWithStreamingResponse:
        return AsyncConfigResourceWithStreamingResponse(self._booking.config)
