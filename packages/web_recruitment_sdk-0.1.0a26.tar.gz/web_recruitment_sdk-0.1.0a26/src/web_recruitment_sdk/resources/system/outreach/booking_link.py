# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, cast
from typing_extensions import Literal

import httpx

from ...._types import Body, Query, Headers, NotGiven, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.outreach import booking_link_clicked_params
from ....types.system.outreach.booking_link_clicked_response import BookingLinkClickedResponse

__all__ = ["BookingLinkResource", "AsyncBookingLinkResource"]


class BookingLinkResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> BookingLinkResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return BookingLinkResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BookingLinkResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return BookingLinkResourceWithStreamingResponse(self)

    def clicked(
        self,
        tenant_db_name: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingLinkClickedResponse:
        """
        Process booking link click webhook.

        This endpoint receives webhook events when a booking link is clicked and tracks
        the click by creating an OutreachAction with BOOKING_LINK_CLICKED status.

        Args: tenant_db_name: The tenant database name webhook_payload: Webhook payload
        containing booking link click data outreach_service: Outreach campaign service

        Returns: OutreachActionRead: The created SMS action with BOOKING_LINK_CLICKED
        status

        Raises: 400: If webhook type is not BOOKING_LINK_CLICKED or missing required
        fields 404: If no SMS action found with the booking_url or attempt doesn't exist

        Args:
          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return cast(
            BookingLinkClickedResponse,
            self._post(
                path_template("/system/{tenant_db_name}/outreach/booking_link/clicked", tenant_db_name=tenant_db_name),
                body=maybe_transform(
                    {
                        "webhook_data": webhook_data,
                        "webhook_type": webhook_type,
                    },
                    booking_link_clicked_params.BookingLinkClickedParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, BookingLinkClickedResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class AsyncBookingLinkResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncBookingLinkResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncBookingLinkResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBookingLinkResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncBookingLinkResourceWithStreamingResponse(self)

    async def clicked(
        self,
        tenant_db_name: str,
        *,
        webhook_data: object,
        webhook_type: Literal["booking_link_clicked", "facebook_lead_received", "twilio_inbound_sms"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BookingLinkClickedResponse:
        """
        Process booking link click webhook.

        This endpoint receives webhook events when a booking link is clicked and tracks
        the click by creating an OutreachAction with BOOKING_LINK_CLICKED status.

        Args: tenant_db_name: The tenant database name webhook_payload: Webhook payload
        containing booking link click data outreach_service: Outreach campaign service

        Returns: OutreachActionRead: The created SMS action with BOOKING_LINK_CLICKED
        status

        Raises: 400: If webhook type is not BOOKING_LINK_CLICKED or missing required
        fields 404: If no SMS action found with the booking_url or attempt doesn't exist

        Args:
          webhook_type: Types of webhooks.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return cast(
            BookingLinkClickedResponse,
            await self._post(
                path_template("/system/{tenant_db_name}/outreach/booking_link/clicked", tenant_db_name=tenant_db_name),
                body=await async_maybe_transform(
                    {
                        "webhook_data": webhook_data,
                        "webhook_type": webhook_type,
                    },
                    booking_link_clicked_params.BookingLinkClickedParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, BookingLinkClickedResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class BookingLinkResourceWithRawResponse:
    def __init__(self, booking_link: BookingLinkResource) -> None:
        self._booking_link = booking_link

        self.clicked = to_raw_response_wrapper(
            booking_link.clicked,
        )


class AsyncBookingLinkResourceWithRawResponse:
    def __init__(self, booking_link: AsyncBookingLinkResource) -> None:
        self._booking_link = booking_link

        self.clicked = async_to_raw_response_wrapper(
            booking_link.clicked,
        )


class BookingLinkResourceWithStreamingResponse:
    def __init__(self, booking_link: BookingLinkResource) -> None:
        self._booking_link = booking_link

        self.clicked = to_streamed_response_wrapper(
            booking_link.clicked,
        )


class AsyncBookingLinkResourceWithStreamingResponse:
    def __init__(self, booking_link: AsyncBookingLinkResource) -> None:
        self._booking_link = booking_link

        self.clicked = async_to_streamed_response_wrapper(
            booking_link.clicked,
        )
