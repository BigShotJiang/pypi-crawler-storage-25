# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import typing_extensions

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system.matching_job_read import MatchingJobRead

__all__ = ["MatchingJobsResource", "AsyncMatchingJobsResource"]


class MatchingJobsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MatchingJobsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return MatchingJobsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MatchingJobsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return MatchingJobsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        matching_job_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MatchingJobRead:
        """
        Get Matching Job

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/matching_jobs/{matching_job_id}",
                tenant_db_name=tenant_db_name,
                matching_job_id=matching_job_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MatchingJobRead,
        )

    def cancel(
        self,
        matching_job_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MatchingJobRead:
        """
        Cancel a matching job and its pending tasks.

        This will:

        - Delete tasks from the queue
        - Mark tasks as CANCELLED in the database
        - Mark the job as CANCELLED

        If the job is already in a final state (SUCCESS, ERROR, CANCELLED), it will not
        be modified.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template(
                "/system/{tenant_db_name}/matching_jobs/{matching_job_id}/cancel",
                tenant_db_name=tenant_db_name,
                matching_job_id=matching_job_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MatchingJobRead,
        )

    @typing_extensions.deprecated("deprecated")
    def start_all(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """This endpoint is deprecated.

        Reason is that this creates matching jobs for
        larger patient populations Use the
        `/system/{tenant_db_name}/protocols/{protocol_id}/matching_jobs` and
        `/system/{tenant_db_name}/custom-searches/{custom_search_id}/matching_jobs`
        endpoints instead. Those endpoints are more efficient until we fix this
        endpoint.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/matching_jobs/start_all", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncMatchingJobsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMatchingJobsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncMatchingJobsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMatchingJobsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncMatchingJobsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        matching_job_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MatchingJobRead:
        """
        Get Matching Job

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/matching_jobs/{matching_job_id}",
                tenant_db_name=tenant_db_name,
                matching_job_id=matching_job_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MatchingJobRead,
        )

    async def cancel(
        self,
        matching_job_id: int,
        *,
        tenant_db_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MatchingJobRead:
        """
        Cancel a matching job and its pending tasks.

        This will:

        - Delete tasks from the queue
        - Mark tasks as CANCELLED in the database
        - Mark the job as CANCELLED

        If the job is already in a final state (SUCCESS, ERROR, CANCELLED), it will not
        be modified.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template(
                "/system/{tenant_db_name}/matching_jobs/{matching_job_id}/cancel",
                tenant_db_name=tenant_db_name,
                matching_job_id=matching_job_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MatchingJobRead,
        )

    @typing_extensions.deprecated("deprecated")
    async def start_all(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """This endpoint is deprecated.

        Reason is that this creates matching jobs for
        larger patient populations Use the
        `/system/{tenant_db_name}/protocols/{protocol_id}/matching_jobs` and
        `/system/{tenant_db_name}/custom-searches/{custom_search_id}/matching_jobs`
        endpoints instead. Those endpoints are more efficient until we fix this
        endpoint.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/matching_jobs/start_all", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class MatchingJobsResourceWithRawResponse:
    def __init__(self, matching_jobs: MatchingJobsResource) -> None:
        self._matching_jobs = matching_jobs

        self.retrieve = to_raw_response_wrapper(
            matching_jobs.retrieve,
        )
        self.cancel = to_raw_response_wrapper(
            matching_jobs.cancel,
        )
        self.start_all = (  # pyright: ignore[reportDeprecated]
            to_raw_response_wrapper(
                matching_jobs.start_all,  # pyright: ignore[reportDeprecated],
            )
        )


class AsyncMatchingJobsResourceWithRawResponse:
    def __init__(self, matching_jobs: AsyncMatchingJobsResource) -> None:
        self._matching_jobs = matching_jobs

        self.retrieve = async_to_raw_response_wrapper(
            matching_jobs.retrieve,
        )
        self.cancel = async_to_raw_response_wrapper(
            matching_jobs.cancel,
        )
        self.start_all = (  # pyright: ignore[reportDeprecated]
            async_to_raw_response_wrapper(
                matching_jobs.start_all,  # pyright: ignore[reportDeprecated],
            )
        )


class MatchingJobsResourceWithStreamingResponse:
    def __init__(self, matching_jobs: MatchingJobsResource) -> None:
        self._matching_jobs = matching_jobs

        self.retrieve = to_streamed_response_wrapper(
            matching_jobs.retrieve,
        )
        self.cancel = to_streamed_response_wrapper(
            matching_jobs.cancel,
        )
        self.start_all = (  # pyright: ignore[reportDeprecated]
            to_streamed_response_wrapper(
                matching_jobs.start_all,  # pyright: ignore[reportDeprecated],
            )
        )


class AsyncMatchingJobsResourceWithStreamingResponse:
    def __init__(self, matching_jobs: AsyncMatchingJobsResource) -> None:
        self._matching_jobs = matching_jobs

        self.retrieve = async_to_streamed_response_wrapper(
            matching_jobs.retrieve,
        )
        self.cancel = async_to_streamed_response_wrapper(
            matching_jobs.cancel,
        )
        self.start_all = (  # pyright: ignore[reportDeprecated]
            async_to_streamed_response_wrapper(
                matching_jobs.start_all,  # pyright: ignore[reportDeprecated],
            )
        )
