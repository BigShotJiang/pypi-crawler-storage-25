# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system.semantic_prefilter_validation_run_response import SemanticPrefilterValidationRunResponse

__all__ = ["SemanticPrefilterValidationResource", "AsyncSemanticPrefilterValidationResource"]


class SemanticPrefilterValidationResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SemanticPrefilterValidationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return SemanticPrefilterValidationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SemanticPrefilterValidationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return SemanticPrefilterValidationResourceWithStreamingResponse(self)

    def run(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SemanticPrefilterValidationRunResponse:
        """Run Semantic Prefilter Validation"""
        return self._post(
            "/system/semantic-prefilter-validation/run",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SemanticPrefilterValidationRunResponse,
        )


class AsyncSemanticPrefilterValidationResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSemanticPrefilterValidationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSemanticPrefilterValidationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSemanticPrefilterValidationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncSemanticPrefilterValidationResourceWithStreamingResponse(self)

    async def run(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SemanticPrefilterValidationRunResponse:
        """Run Semantic Prefilter Validation"""
        return await self._post(
            "/system/semantic-prefilter-validation/run",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SemanticPrefilterValidationRunResponse,
        )


class SemanticPrefilterValidationResourceWithRawResponse:
    def __init__(self, semantic_prefilter_validation: SemanticPrefilterValidationResource) -> None:
        self._semantic_prefilter_validation = semantic_prefilter_validation

        self.run = to_raw_response_wrapper(
            semantic_prefilter_validation.run,
        )


class AsyncSemanticPrefilterValidationResourceWithRawResponse:
    def __init__(self, semantic_prefilter_validation: AsyncSemanticPrefilterValidationResource) -> None:
        self._semantic_prefilter_validation = semantic_prefilter_validation

        self.run = async_to_raw_response_wrapper(
            semantic_prefilter_validation.run,
        )


class SemanticPrefilterValidationResourceWithStreamingResponse:
    def __init__(self, semantic_prefilter_validation: SemanticPrefilterValidationResource) -> None:
        self._semantic_prefilter_validation = semantic_prefilter_validation

        self.run = to_streamed_response_wrapper(
            semantic_prefilter_validation.run,
        )


class AsyncSemanticPrefilterValidationResourceWithStreamingResponse:
    def __init__(self, semantic_prefilter_validation: AsyncSemanticPrefilterValidationResource) -> None:
        self._semantic_prefilter_validation = semantic_prefilter_validation

        self.run = async_to_streamed_response_wrapper(
            semantic_prefilter_validation.run,
        )
