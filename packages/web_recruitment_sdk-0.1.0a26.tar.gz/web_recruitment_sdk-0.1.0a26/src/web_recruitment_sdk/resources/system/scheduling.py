# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import path_template
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.system.scheduling_list_providers_response import SchedulingListProvidersResponse

__all__ = ["SchedulingResource", "AsyncSchedulingResource"]


class SchedulingResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SchedulingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return SchedulingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SchedulingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return SchedulingResourceWithStreamingResponse(self)

    def list_providers(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListProvidersResponse:
        """
        Return available scheduling providers for the tenant with config status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template("/system/{tenant_db_name}/scheduling/providers", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SchedulingListProvidersResponse,
        )


class AsyncSchedulingResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSchedulingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSchedulingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSchedulingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncSchedulingResourceWithStreamingResponse(self)

    async def list_providers(
        self,
        tenant_db_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SchedulingListProvidersResponse:
        """
        Return available scheduling providers for the tenant with config status.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template("/system/{tenant_db_name}/scheduling/providers", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SchedulingListProvidersResponse,
        )


class SchedulingResourceWithRawResponse:
    def __init__(self, scheduling: SchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_providers = to_raw_response_wrapper(
            scheduling.list_providers,
        )


class AsyncSchedulingResourceWithRawResponse:
    def __init__(self, scheduling: AsyncSchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_providers = async_to_raw_response_wrapper(
            scheduling.list_providers,
        )


class SchedulingResourceWithStreamingResponse:
    def __init__(self, scheduling: SchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_providers = to_streamed_response_wrapper(
            scheduling.list_providers,
        )


class AsyncSchedulingResourceWithStreamingResponse:
    def __init__(self, scheduling: AsyncSchedulingResource) -> None:
        self._scheduling = scheduling

        self.list_providers = async_to_streamed_response_wrapper(
            scheduling.list_providers,
        )
