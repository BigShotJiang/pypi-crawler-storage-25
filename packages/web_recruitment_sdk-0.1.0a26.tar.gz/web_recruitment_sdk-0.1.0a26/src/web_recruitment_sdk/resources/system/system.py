# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Iterable, Optional
from typing_extensions import Literal

import httpx

from .bulk import (
    BulkResource,
    AsyncBulkResource,
    BulkResourceWithRawResponse,
    AsyncBulkResourceWithRawResponse,
    BulkResourceWithStreamingResponse,
    AsyncBulkResourceWithStreamingResponse,
)
from .cache import (
    CacheResource,
    AsyncCacheResource,
    CacheResourceWithRawResponse,
    AsyncCacheResourceWithRawResponse,
    CacheResourceWithStreamingResponse,
    AsyncCacheResourceWithStreamingResponse,
)
from .twilio import (
    TwilioResource,
    AsyncTwilioResource,
    TwilioResourceWithRawResponse,
    AsyncTwilioResourceWithRawResponse,
    TwilioResourceWithStreamingResponse,
    AsyncTwilioResourceWithStreamingResponse,
)
from ...types import (
    ExportStatus,
    system_search_entities_params,
    system_patch_patient_export_params,
    system_get_patient_match_data_params,
    system_create_entity_search_index_params,
    system_get_connection_pool_status_params,
    system_get_patient_match_data_vitals_params,
    system_bulk_search_patient_match_data_params,
    system_get_patient_match_data_lab_results_params,
)
from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from .facebook import (
    FacebookResource,
    AsyncFacebookResource,
    FacebookResourceWithRawResponse,
    AsyncFacebookResourceWithRawResponse,
    FacebookResourceWithStreamingResponse,
    AsyncFacebookResourceWithStreamingResponse,
)
from ..._compat import cached_property
from .scheduling import (
    SchedulingResource,
    AsyncSchedulingResource,
    SchedulingResourceWithRawResponse,
    AsyncSchedulingResourceWithRawResponse,
    SchedulingResourceWithStreamingResponse,
    AsyncSchedulingResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .concurrency import (
    ConcurrencyResource,
    AsyncConcurrencyResource,
    ConcurrencyResourceWithRawResponse,
    AsyncConcurrencyResourceWithRawResponse,
    ConcurrencyResourceWithStreamingResponse,
    AsyncConcurrencyResourceWithStreamingResponse,
)
from .lab_results import (
    LabResultsResource,
    AsyncLabResultsResource,
    LabResultsResourceWithRawResponse,
    AsyncLabResultsResourceWithRawResponse,
    LabResultsResourceWithStreamingResponse,
    AsyncLabResultsResourceWithStreamingResponse,
)
from .nylas.nylas import (
    NylasResource,
    AsyncNylasResource,
    NylasResourceWithRawResponse,
    AsyncNylasResourceWithRawResponse,
    NylasResourceWithStreamingResponse,
    AsyncNylasResourceWithStreamingResponse,
)
from .sites.sites import (
    SitesResource,
    AsyncSitesResource,
    SitesResourceWithRawResponse,
    AsyncSitesResourceWithRawResponse,
    SitesResourceWithStreamingResponse,
    AsyncSitesResourceWithStreamingResponse,
)
from .appointments import (
    AppointmentsResource,
    AsyncAppointmentsResource,
    AppointmentsResourceWithRawResponse,
    AsyncAppointmentsResourceWithRawResponse,
    AppointmentsResourceWithStreamingResponse,
    AsyncAppointmentsResourceWithStreamingResponse,
)
from .matching_jobs import (
    MatchingJobsResource,
    AsyncMatchingJobsResource,
    MatchingJobsResourceWithRawResponse,
    AsyncMatchingJobsResourceWithRawResponse,
    MatchingJobsResourceWithStreamingResponse,
    AsyncMatchingJobsResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from .booking.booking import (
    BookingResource,
    AsyncBookingResource,
    BookingResourceWithRawResponse,
    AsyncBookingResourceWithRawResponse,
    BookingResourceWithStreamingResponse,
    AsyncBookingResourceWithStreamingResponse,
)
from .criteria.criteria import (
    CriteriaResource,
    AsyncCriteriaResource,
    CriteriaResourceWithRawResponse,
    AsyncCriteriaResourceWithRawResponse,
    CriteriaResourceWithStreamingResponse,
    AsyncCriteriaResourceWithStreamingResponse,
)
from .outreach.outreach import (
    OutreachResource,
    AsyncOutreachResource,
    OutreachResourceWithRawResponse,
    AsyncOutreachResourceWithRawResponse,
    OutreachResourceWithStreamingResponse,
    AsyncOutreachResourceWithStreamingResponse,
)
from .patients.patients import (
    PatientsResource,
    AsyncPatientsResource,
    PatientsResourceWithRawResponse,
    AsyncPatientsResourceWithRawResponse,
    PatientsResourceWithStreamingResponse,
    AsyncPatientsResourceWithStreamingResponse,
)
from .protocols.protocols import (
    ProtocolsResource,
    AsyncProtocolsResource,
    ProtocolsResourceWithRawResponse,
    AsyncProtocolsResourceWithRawResponse,
    ProtocolsResourceWithStreamingResponse,
    AsyncProtocolsResourceWithStreamingResponse,
)
from ...types.export_status import ExportStatus
from .semantic_prefilter_validation import (
    SemanticPrefilterValidationResource,
    AsyncSemanticPrefilterValidationResource,
    SemanticPrefilterValidationResourceWithRawResponse,
    AsyncSemanticPrefilterValidationResourceWithRawResponse,
    SemanticPrefilterValidationResourceWithStreamingResponse,
    AsyncSemanticPrefilterValidationResourceWithStreamingResponse,
)
from .custom_searches.custom_searches import (
    CustomSearchesResource,
    AsyncCustomSearchesResource,
    CustomSearchesResourceWithRawResponse,
    AsyncCustomSearchesResourceWithRawResponse,
    CustomSearchesResourceWithStreamingResponse,
    AsyncCustomSearchesResourceWithStreamingResponse,
)
from .clinical_conductor.clinical_conductor import (
    ClinicalConductorResource,
    AsyncClinicalConductorResource,
    ClinicalConductorResourceWithRawResponse,
    AsyncClinicalConductorResourceWithRawResponse,
    ClinicalConductorResourceWithStreamingResponse,
    AsyncClinicalConductorResourceWithStreamingResponse,
)
from ...types.criteria_instance_create_param import CriteriaInstanceCreateParam
from ...types.system_search_entities_response import SystemSearchEntitiesResponse
from ...types.system_patch_patient_export_response import SystemPatchPatientExportResponse
from ...types.system_get_patient_match_data_response import SystemGetPatientMatchDataResponse
from ...types.system_create_criteria_instance_response import SystemCreateCriteriaInstanceResponse
from ...types.system_create_entity_search_index_response import SystemCreateEntitySearchIndexResponse
from ...types.system_get_connection_pool_status_response import SystemGetConnectionPoolStatusResponse
from ...types.system_get_patient_match_data_vitals_response import SystemGetPatientMatchDataVitalsResponse
from ...types.system_get_patient_match_data_lab_results_response import SystemGetPatientMatchDataLabResultsResponse

__all__ = ["SystemResource", "AsyncSystemResource"]


class SystemResource(SyncAPIResource):
    @cached_property
    def protocols(self) -> ProtocolsResource:
        return ProtocolsResource(self._client)

    @cached_property
    def criteria(self) -> CriteriaResource:
        return CriteriaResource(self._client)

    @cached_property
    def sites(self) -> SitesResource:
        return SitesResource(self._client)

    @cached_property
    def patients(self) -> PatientsResource:
        return PatientsResource(self._client)

    @cached_property
    def appointments(self) -> AppointmentsResource:
        return AppointmentsResource(self._client)

    @cached_property
    def bulk(self) -> BulkResource:
        return BulkResource(self._client)

    @cached_property
    def matching_jobs(self) -> MatchingJobsResource:
        return MatchingJobsResource(self._client)

    @cached_property
    def cache(self) -> CacheResource:
        return CacheResource(self._client)

    @cached_property
    def custom_searches(self) -> CustomSearchesResource:
        return CustomSearchesResource(self._client)

    @cached_property
    def outreach(self) -> OutreachResource:
        return OutreachResource(self._client)

    @cached_property
    def lab_results(self) -> LabResultsResource:
        return LabResultsResource(self._client)

    @cached_property
    def concurrency(self) -> ConcurrencyResource:
        return ConcurrencyResource(self._client)

    @cached_property
    def clinical_conductor(self) -> ClinicalConductorResource:
        return ClinicalConductorResource(self._client)

    @cached_property
    def semantic_prefilter_validation(self) -> SemanticPrefilterValidationResource:
        return SemanticPrefilterValidationResource(self._client)

    @cached_property
    def twilio(self) -> TwilioResource:
        return TwilioResource(self._client)

    @cached_property
    def facebook(self) -> FacebookResource:
        return FacebookResource(self._client)

    @cached_property
    def booking(self) -> BookingResource:
        return BookingResource(self._client)

    @cached_property
    def nylas(self) -> NylasResource:
        return NylasResource(self._client)

    @cached_property
    def scheduling(self) -> SchedulingResource:
        return SchedulingResource(self._client)

    @cached_property
    def with_raw_response(self) -> SystemResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return SystemResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SystemResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return SystemResourceWithStreamingResponse(self)

    def bulk_search_patient_match_data(
        self,
        tenant_db_name: str,
        *,
        search_text: str,
        trially_patient_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Search for patient match data based on a list of patient IDs and a search text.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/bulk-search", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "search_text": search_text,
                    "trially_patient_ids": trially_patient_ids,
                },
                system_bulk_search_patient_match_data_params.SystemBulkSearchPatientMatchDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    def create_criteria_instance(
        self,
        tenant_db_name: str,
        *,
        body: Iterable[CriteriaInstanceCreateParam],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemCreateCriteriaInstanceResponse:
        """
        Create Criteria Instances

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/criteria_instances", tenant_db_name=tenant_db_name),
            body=maybe_transform(body, Iterable[CriteriaInstanceCreateParam]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemCreateCriteriaInstanceResponse,
        )

    def create_entity_search_index(
        self,
        tenant_db_name: str,
        *,
        override_num_leaves: Optional[int] | Omit = omit,
        recreate: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemCreateEntitySearchIndexResponse:
        """
        Create or recreate ScaNN index on entity_search.embedding with dynamic
        num_leaves.

        Args:
          override_num_leaves: Override computed num_leaves

          recreate: Drop and recreate the index

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/entity-search/index", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "override_num_leaves": override_num_leaves,
                        "recreate": recreate,
                    },
                    system_create_entity_search_index_params.SystemCreateEntitySearchIndexParams,
                ),
            ),
            cast_to=SystemCreateEntitySearchIndexResponse,
        )

    def get_connection_pool_status(
        self,
        db_name: str,
        *,
        pool: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetConnectionPoolStatusResponse:
        """
        Get connection pool status for primary or read replica pool.

        Raises: InvalidPoolTypeError if invalid pool type is requested for the database.

        Args:
          pool: Pool to check: 'primary' or 'replica'

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not db_name:
            raise ValueError(f"Expected a non-empty value for `db_name` but received {db_name!r}")
        return self._get(
            path_template("/system/{db_name}/connection-pool-status", db_name=db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"pool": pool}, system_get_connection_pool_status_params.SystemGetConnectionPoolStatusParams
                ),
            ),
            cast_to=SystemGetConnectionPoolStatusResponse,
        )

    def get_patient_match_data(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataResponse:
        """
        Get patient match data based on a list of patient IDs and a criteria ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/patient-match-data", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_params.SystemGetPatientMatchDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataResponse,
        )

    def get_patient_match_data_lab_results(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataLabResultsResponse:
        """
        Get patient lab results data for a list of patient IDs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/lab-results", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_lab_results_params.SystemGetPatientMatchDataLabResultsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataLabResultsResponse,
        )

    def get_patient_match_data_vitals(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataVitalsResponse:
        """
        Get patient vitals data for a list of patient IDs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/vitals", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_vitals_params.SystemGetPatientMatchDataVitalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataVitalsResponse,
        )

    def patch_patient_export(
        self,
        patient_ctms_export_id: int,
        *,
        tenant_db_name: str,
        status: ExportStatus,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemPatchPatientExportResponse:
        """
        Update a patient CTMS export's status

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._patch(
            path_template(
                "/system/{tenant_db_name}/patient-ctms-exports/{patient_ctms_export_id}",
                tenant_db_name=tenant_db_name,
                patient_ctms_export_id=patient_ctms_export_id,
            ),
            body=maybe_transform({"status": status}, system_patch_patient_export_params.SystemPatchPatientExportParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemPatchPatientExportResponse,
        )

    def search_entities(
        self,
        tenant_db_name: str,
        *,
        search_text: str,
        entity_types: Optional[
            List[Literal["condition", "medication", "allergy", "procedure", "lab_result", "social_history"]]
        ]
        | Omit = omit,
        limit: int | Omit = omit,
        similarity_threshold: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemSearchEntitiesResponse:
        """
        Search for entities similar to the provided search text.

        Args:
          search_text: Text to search for similar entities

          entity_types: Restrict results to the provided entity types. Defaults to excluding lab results
              unless explicitly requested.

          limit: Maximum number of results to return

          similarity_threshold: Minimum similarity score for returned entities

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._post(
            path_template("/system/{tenant_db_name}/entity-search", tenant_db_name=tenant_db_name),
            body=maybe_transform(
                {
                    "search_text": search_text,
                    "entity_types": entity_types,
                    "limit": limit,
                    "similarity_threshold": similarity_threshold,
                },
                system_search_entities_params.SystemSearchEntitiesParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemSearchEntitiesResponse,
        )


class AsyncSystemResource(AsyncAPIResource):
    @cached_property
    def protocols(self) -> AsyncProtocolsResource:
        return AsyncProtocolsResource(self._client)

    @cached_property
    def criteria(self) -> AsyncCriteriaResource:
        return AsyncCriteriaResource(self._client)

    @cached_property
    def sites(self) -> AsyncSitesResource:
        return AsyncSitesResource(self._client)

    @cached_property
    def patients(self) -> AsyncPatientsResource:
        return AsyncPatientsResource(self._client)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResource:
        return AsyncAppointmentsResource(self._client)

    @cached_property
    def bulk(self) -> AsyncBulkResource:
        return AsyncBulkResource(self._client)

    @cached_property
    def matching_jobs(self) -> AsyncMatchingJobsResource:
        return AsyncMatchingJobsResource(self._client)

    @cached_property
    def cache(self) -> AsyncCacheResource:
        return AsyncCacheResource(self._client)

    @cached_property
    def custom_searches(self) -> AsyncCustomSearchesResource:
        return AsyncCustomSearchesResource(self._client)

    @cached_property
    def outreach(self) -> AsyncOutreachResource:
        return AsyncOutreachResource(self._client)

    @cached_property
    def lab_results(self) -> AsyncLabResultsResource:
        return AsyncLabResultsResource(self._client)

    @cached_property
    def concurrency(self) -> AsyncConcurrencyResource:
        return AsyncConcurrencyResource(self._client)

    @cached_property
    def clinical_conductor(self) -> AsyncClinicalConductorResource:
        return AsyncClinicalConductorResource(self._client)

    @cached_property
    def semantic_prefilter_validation(self) -> AsyncSemanticPrefilterValidationResource:
        return AsyncSemanticPrefilterValidationResource(self._client)

    @cached_property
    def twilio(self) -> AsyncTwilioResource:
        return AsyncTwilioResource(self._client)

    @cached_property
    def facebook(self) -> AsyncFacebookResource:
        return AsyncFacebookResource(self._client)

    @cached_property
    def booking(self) -> AsyncBookingResource:
        return AsyncBookingResource(self._client)

    @cached_property
    def nylas(self) -> AsyncNylasResource:
        return AsyncNylasResource(self._client)

    @cached_property
    def scheduling(self) -> AsyncSchedulingResource:
        return AsyncSchedulingResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSystemResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSystemResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSystemResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncSystemResourceWithStreamingResponse(self)

    async def bulk_search_patient_match_data(
        self,
        tenant_db_name: str,
        *,
        search_text: str,
        trially_patient_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Search for patient match data based on a list of patient IDs and a search text.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/bulk-search", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "search_text": search_text,
                    "trially_patient_ids": trially_patient_ids,
                },
                system_bulk_search_patient_match_data_params.SystemBulkSearchPatientMatchDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    async def create_criteria_instance(
        self,
        tenant_db_name: str,
        *,
        body: Iterable[CriteriaInstanceCreateParam],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemCreateCriteriaInstanceResponse:
        """
        Create Criteria Instances

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/criteria_instances", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(body, Iterable[CriteriaInstanceCreateParam]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemCreateCriteriaInstanceResponse,
        )

    async def create_entity_search_index(
        self,
        tenant_db_name: str,
        *,
        override_num_leaves: Optional[int] | Omit = omit,
        recreate: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemCreateEntitySearchIndexResponse:
        """
        Create or recreate ScaNN index on entity_search.embedding with dynamic
        num_leaves.

        Args:
          override_num_leaves: Override computed num_leaves

          recreate: Drop and recreate the index

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/entity-search/index", tenant_db_name=tenant_db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "override_num_leaves": override_num_leaves,
                        "recreate": recreate,
                    },
                    system_create_entity_search_index_params.SystemCreateEntitySearchIndexParams,
                ),
            ),
            cast_to=SystemCreateEntitySearchIndexResponse,
        )

    async def get_connection_pool_status(
        self,
        db_name: str,
        *,
        pool: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetConnectionPoolStatusResponse:
        """
        Get connection pool status for primary or read replica pool.

        Raises: InvalidPoolTypeError if invalid pool type is requested for the database.

        Args:
          pool: Pool to check: 'primary' or 'replica'

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not db_name:
            raise ValueError(f"Expected a non-empty value for `db_name` but received {db_name!r}")
        return await self._get(
            path_template("/system/{db_name}/connection-pool-status", db_name=db_name),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"pool": pool}, system_get_connection_pool_status_params.SystemGetConnectionPoolStatusParams
                ),
            ),
            cast_to=SystemGetConnectionPoolStatusResponse,
        )

    async def get_patient_match_data(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataResponse:
        """
        Get patient match data based on a list of patient IDs and a criteria ID.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/patient-match-data", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_params.SystemGetPatientMatchDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataResponse,
        )

    async def get_patient_match_data_lab_results(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataLabResultsResponse:
        """
        Get patient lab results data for a list of patient IDs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/lab-results", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_lab_results_params.SystemGetPatientMatchDataLabResultsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataLabResultsResponse,
        )

    async def get_patient_match_data_vitals(
        self,
        tenant_db_name: str,
        *,
        patient_ids: SequenceNotStr[str],
        criteria_id: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemGetPatientMatchDataVitalsResponse:
        """
        Get patient vitals data for a list of patient IDs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/patient-match-data/vitals", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "patient_ids": patient_ids,
                    "criteria_id": criteria_id,
                },
                system_get_patient_match_data_vitals_params.SystemGetPatientMatchDataVitalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemGetPatientMatchDataVitalsResponse,
        )

    async def patch_patient_export(
        self,
        patient_ctms_export_id: int,
        *,
        tenant_db_name: str,
        status: ExportStatus,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemPatchPatientExportResponse:
        """
        Update a patient CTMS export's status

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._patch(
            path_template(
                "/system/{tenant_db_name}/patient-ctms-exports/{patient_ctms_export_id}",
                tenant_db_name=tenant_db_name,
                patient_ctms_export_id=patient_ctms_export_id,
            ),
            body=await async_maybe_transform(
                {"status": status}, system_patch_patient_export_params.SystemPatchPatientExportParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemPatchPatientExportResponse,
        )

    async def search_entities(
        self,
        tenant_db_name: str,
        *,
        search_text: str,
        entity_types: Optional[
            List[Literal["condition", "medication", "allergy", "procedure", "lab_result", "social_history"]]
        ]
        | Omit = omit,
        limit: int | Omit = omit,
        similarity_threshold: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SystemSearchEntitiesResponse:
        """
        Search for entities similar to the provided search text.

        Args:
          search_text: Text to search for similar entities

          entity_types: Restrict results to the provided entity types. Defaults to excluding lab results
              unless explicitly requested.

          limit: Maximum number of results to return

          similarity_threshold: Minimum similarity score for returned entities

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._post(
            path_template("/system/{tenant_db_name}/entity-search", tenant_db_name=tenant_db_name),
            body=await async_maybe_transform(
                {
                    "search_text": search_text,
                    "entity_types": entity_types,
                    "limit": limit,
                    "similarity_threshold": similarity_threshold,
                },
                system_search_entities_params.SystemSearchEntitiesParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SystemSearchEntitiesResponse,
        )


class SystemResourceWithRawResponse:
    def __init__(self, system: SystemResource) -> None:
        self._system = system

        self.bulk_search_patient_match_data = to_raw_response_wrapper(
            system.bulk_search_patient_match_data,
        )
        self.create_criteria_instance = to_raw_response_wrapper(
            system.create_criteria_instance,
        )
        self.create_entity_search_index = to_raw_response_wrapper(
            system.create_entity_search_index,
        )
        self.get_connection_pool_status = to_raw_response_wrapper(
            system.get_connection_pool_status,
        )
        self.get_patient_match_data = to_raw_response_wrapper(
            system.get_patient_match_data,
        )
        self.get_patient_match_data_lab_results = to_raw_response_wrapper(
            system.get_patient_match_data_lab_results,
        )
        self.get_patient_match_data_vitals = to_raw_response_wrapper(
            system.get_patient_match_data_vitals,
        )
        self.patch_patient_export = to_raw_response_wrapper(
            system.patch_patient_export,
        )
        self.search_entities = to_raw_response_wrapper(
            system.search_entities,
        )

    @cached_property
    def protocols(self) -> ProtocolsResourceWithRawResponse:
        return ProtocolsResourceWithRawResponse(self._system.protocols)

    @cached_property
    def criteria(self) -> CriteriaResourceWithRawResponse:
        return CriteriaResourceWithRawResponse(self._system.criteria)

    @cached_property
    def sites(self) -> SitesResourceWithRawResponse:
        return SitesResourceWithRawResponse(self._system.sites)

    @cached_property
    def patients(self) -> PatientsResourceWithRawResponse:
        return PatientsResourceWithRawResponse(self._system.patients)

    @cached_property
    def appointments(self) -> AppointmentsResourceWithRawResponse:
        return AppointmentsResourceWithRawResponse(self._system.appointments)

    @cached_property
    def bulk(self) -> BulkResourceWithRawResponse:
        return BulkResourceWithRawResponse(self._system.bulk)

    @cached_property
    def matching_jobs(self) -> MatchingJobsResourceWithRawResponse:
        return MatchingJobsResourceWithRawResponse(self._system.matching_jobs)

    @cached_property
    def cache(self) -> CacheResourceWithRawResponse:
        return CacheResourceWithRawResponse(self._system.cache)

    @cached_property
    def custom_searches(self) -> CustomSearchesResourceWithRawResponse:
        return CustomSearchesResourceWithRawResponse(self._system.custom_searches)

    @cached_property
    def outreach(self) -> OutreachResourceWithRawResponse:
        return OutreachResourceWithRawResponse(self._system.outreach)

    @cached_property
    def lab_results(self) -> LabResultsResourceWithRawResponse:
        return LabResultsResourceWithRawResponse(self._system.lab_results)

    @cached_property
    def concurrency(self) -> ConcurrencyResourceWithRawResponse:
        return ConcurrencyResourceWithRawResponse(self._system.concurrency)

    @cached_property
    def clinical_conductor(self) -> ClinicalConductorResourceWithRawResponse:
        return ClinicalConductorResourceWithRawResponse(self._system.clinical_conductor)

    @cached_property
    def semantic_prefilter_validation(self) -> SemanticPrefilterValidationResourceWithRawResponse:
        return SemanticPrefilterValidationResourceWithRawResponse(self._system.semantic_prefilter_validation)

    @cached_property
    def twilio(self) -> TwilioResourceWithRawResponse:
        return TwilioResourceWithRawResponse(self._system.twilio)

    @cached_property
    def facebook(self) -> FacebookResourceWithRawResponse:
        return FacebookResourceWithRawResponse(self._system.facebook)

    @cached_property
    def booking(self) -> BookingResourceWithRawResponse:
        return BookingResourceWithRawResponse(self._system.booking)

    @cached_property
    def nylas(self) -> NylasResourceWithRawResponse:
        return NylasResourceWithRawResponse(self._system.nylas)

    @cached_property
    def scheduling(self) -> SchedulingResourceWithRawResponse:
        return SchedulingResourceWithRawResponse(self._system.scheduling)


class AsyncSystemResourceWithRawResponse:
    def __init__(self, system: AsyncSystemResource) -> None:
        self._system = system

        self.bulk_search_patient_match_data = async_to_raw_response_wrapper(
            system.bulk_search_patient_match_data,
        )
        self.create_criteria_instance = async_to_raw_response_wrapper(
            system.create_criteria_instance,
        )
        self.create_entity_search_index = async_to_raw_response_wrapper(
            system.create_entity_search_index,
        )
        self.get_connection_pool_status = async_to_raw_response_wrapper(
            system.get_connection_pool_status,
        )
        self.get_patient_match_data = async_to_raw_response_wrapper(
            system.get_patient_match_data,
        )
        self.get_patient_match_data_lab_results = async_to_raw_response_wrapper(
            system.get_patient_match_data_lab_results,
        )
        self.get_patient_match_data_vitals = async_to_raw_response_wrapper(
            system.get_patient_match_data_vitals,
        )
        self.patch_patient_export = async_to_raw_response_wrapper(
            system.patch_patient_export,
        )
        self.search_entities = async_to_raw_response_wrapper(
            system.search_entities,
        )

    @cached_property
    def protocols(self) -> AsyncProtocolsResourceWithRawResponse:
        return AsyncProtocolsResourceWithRawResponse(self._system.protocols)

    @cached_property
    def criteria(self) -> AsyncCriteriaResourceWithRawResponse:
        return AsyncCriteriaResourceWithRawResponse(self._system.criteria)

    @cached_property
    def sites(self) -> AsyncSitesResourceWithRawResponse:
        return AsyncSitesResourceWithRawResponse(self._system.sites)

    @cached_property
    def patients(self) -> AsyncPatientsResourceWithRawResponse:
        return AsyncPatientsResourceWithRawResponse(self._system.patients)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResourceWithRawResponse:
        return AsyncAppointmentsResourceWithRawResponse(self._system.appointments)

    @cached_property
    def bulk(self) -> AsyncBulkResourceWithRawResponse:
        return AsyncBulkResourceWithRawResponse(self._system.bulk)

    @cached_property
    def matching_jobs(self) -> AsyncMatchingJobsResourceWithRawResponse:
        return AsyncMatchingJobsResourceWithRawResponse(self._system.matching_jobs)

    @cached_property
    def cache(self) -> AsyncCacheResourceWithRawResponse:
        return AsyncCacheResourceWithRawResponse(self._system.cache)

    @cached_property
    def custom_searches(self) -> AsyncCustomSearchesResourceWithRawResponse:
        return AsyncCustomSearchesResourceWithRawResponse(self._system.custom_searches)

    @cached_property
    def outreach(self) -> AsyncOutreachResourceWithRawResponse:
        return AsyncOutreachResourceWithRawResponse(self._system.outreach)

    @cached_property
    def lab_results(self) -> AsyncLabResultsResourceWithRawResponse:
        return AsyncLabResultsResourceWithRawResponse(self._system.lab_results)

    @cached_property
    def concurrency(self) -> AsyncConcurrencyResourceWithRawResponse:
        return AsyncConcurrencyResourceWithRawResponse(self._system.concurrency)

    @cached_property
    def clinical_conductor(self) -> AsyncClinicalConductorResourceWithRawResponse:
        return AsyncClinicalConductorResourceWithRawResponse(self._system.clinical_conductor)

    @cached_property
    def semantic_prefilter_validation(self) -> AsyncSemanticPrefilterValidationResourceWithRawResponse:
        return AsyncSemanticPrefilterValidationResourceWithRawResponse(self._system.semantic_prefilter_validation)

    @cached_property
    def twilio(self) -> AsyncTwilioResourceWithRawResponse:
        return AsyncTwilioResourceWithRawResponse(self._system.twilio)

    @cached_property
    def facebook(self) -> AsyncFacebookResourceWithRawResponse:
        return AsyncFacebookResourceWithRawResponse(self._system.facebook)

    @cached_property
    def booking(self) -> AsyncBookingResourceWithRawResponse:
        return AsyncBookingResourceWithRawResponse(self._system.booking)

    @cached_property
    def nylas(self) -> AsyncNylasResourceWithRawResponse:
        return AsyncNylasResourceWithRawResponse(self._system.nylas)

    @cached_property
    def scheduling(self) -> AsyncSchedulingResourceWithRawResponse:
        return AsyncSchedulingResourceWithRawResponse(self._system.scheduling)


class SystemResourceWithStreamingResponse:
    def __init__(self, system: SystemResource) -> None:
        self._system = system

        self.bulk_search_patient_match_data = to_streamed_response_wrapper(
            system.bulk_search_patient_match_data,
        )
        self.create_criteria_instance = to_streamed_response_wrapper(
            system.create_criteria_instance,
        )
        self.create_entity_search_index = to_streamed_response_wrapper(
            system.create_entity_search_index,
        )
        self.get_connection_pool_status = to_streamed_response_wrapper(
            system.get_connection_pool_status,
        )
        self.get_patient_match_data = to_streamed_response_wrapper(
            system.get_patient_match_data,
        )
        self.get_patient_match_data_lab_results = to_streamed_response_wrapper(
            system.get_patient_match_data_lab_results,
        )
        self.get_patient_match_data_vitals = to_streamed_response_wrapper(
            system.get_patient_match_data_vitals,
        )
        self.patch_patient_export = to_streamed_response_wrapper(
            system.patch_patient_export,
        )
        self.search_entities = to_streamed_response_wrapper(
            system.search_entities,
        )

    @cached_property
    def protocols(self) -> ProtocolsResourceWithStreamingResponse:
        return ProtocolsResourceWithStreamingResponse(self._system.protocols)

    @cached_property
    def criteria(self) -> CriteriaResourceWithStreamingResponse:
        return CriteriaResourceWithStreamingResponse(self._system.criteria)

    @cached_property
    def sites(self) -> SitesResourceWithStreamingResponse:
        return SitesResourceWithStreamingResponse(self._system.sites)

    @cached_property
    def patients(self) -> PatientsResourceWithStreamingResponse:
        return PatientsResourceWithStreamingResponse(self._system.patients)

    @cached_property
    def appointments(self) -> AppointmentsResourceWithStreamingResponse:
        return AppointmentsResourceWithStreamingResponse(self._system.appointments)

    @cached_property
    def bulk(self) -> BulkResourceWithStreamingResponse:
        return BulkResourceWithStreamingResponse(self._system.bulk)

    @cached_property
    def matching_jobs(self) -> MatchingJobsResourceWithStreamingResponse:
        return MatchingJobsResourceWithStreamingResponse(self._system.matching_jobs)

    @cached_property
    def cache(self) -> CacheResourceWithStreamingResponse:
        return CacheResourceWithStreamingResponse(self._system.cache)

    @cached_property
    def custom_searches(self) -> CustomSearchesResourceWithStreamingResponse:
        return CustomSearchesResourceWithStreamingResponse(self._system.custom_searches)

    @cached_property
    def outreach(self) -> OutreachResourceWithStreamingResponse:
        return OutreachResourceWithStreamingResponse(self._system.outreach)

    @cached_property
    def lab_results(self) -> LabResultsResourceWithStreamingResponse:
        return LabResultsResourceWithStreamingResponse(self._system.lab_results)

    @cached_property
    def concurrency(self) -> ConcurrencyResourceWithStreamingResponse:
        return ConcurrencyResourceWithStreamingResponse(self._system.concurrency)

    @cached_property
    def clinical_conductor(self) -> ClinicalConductorResourceWithStreamingResponse:
        return ClinicalConductorResourceWithStreamingResponse(self._system.clinical_conductor)

    @cached_property
    def semantic_prefilter_validation(self) -> SemanticPrefilterValidationResourceWithStreamingResponse:
        return SemanticPrefilterValidationResourceWithStreamingResponse(self._system.semantic_prefilter_validation)

    @cached_property
    def twilio(self) -> TwilioResourceWithStreamingResponse:
        return TwilioResourceWithStreamingResponse(self._system.twilio)

    @cached_property
    def facebook(self) -> FacebookResourceWithStreamingResponse:
        return FacebookResourceWithStreamingResponse(self._system.facebook)

    @cached_property
    def booking(self) -> BookingResourceWithStreamingResponse:
        return BookingResourceWithStreamingResponse(self._system.booking)

    @cached_property
    def nylas(self) -> NylasResourceWithStreamingResponse:
        return NylasResourceWithStreamingResponse(self._system.nylas)

    @cached_property
    def scheduling(self) -> SchedulingResourceWithStreamingResponse:
        return SchedulingResourceWithStreamingResponse(self._system.scheduling)


class AsyncSystemResourceWithStreamingResponse:
    def __init__(self, system: AsyncSystemResource) -> None:
        self._system = system

        self.bulk_search_patient_match_data = async_to_streamed_response_wrapper(
            system.bulk_search_patient_match_data,
        )
        self.create_criteria_instance = async_to_streamed_response_wrapper(
            system.create_criteria_instance,
        )
        self.create_entity_search_index = async_to_streamed_response_wrapper(
            system.create_entity_search_index,
        )
        self.get_connection_pool_status = async_to_streamed_response_wrapper(
            system.get_connection_pool_status,
        )
        self.get_patient_match_data = async_to_streamed_response_wrapper(
            system.get_patient_match_data,
        )
        self.get_patient_match_data_lab_results = async_to_streamed_response_wrapper(
            system.get_patient_match_data_lab_results,
        )
        self.get_patient_match_data_vitals = async_to_streamed_response_wrapper(
            system.get_patient_match_data_vitals,
        )
        self.patch_patient_export = async_to_streamed_response_wrapper(
            system.patch_patient_export,
        )
        self.search_entities = async_to_streamed_response_wrapper(
            system.search_entities,
        )

    @cached_property
    def protocols(self) -> AsyncProtocolsResourceWithStreamingResponse:
        return AsyncProtocolsResourceWithStreamingResponse(self._system.protocols)

    @cached_property
    def criteria(self) -> AsyncCriteriaResourceWithStreamingResponse:
        return AsyncCriteriaResourceWithStreamingResponse(self._system.criteria)

    @cached_property
    def sites(self) -> AsyncSitesResourceWithStreamingResponse:
        return AsyncSitesResourceWithStreamingResponse(self._system.sites)

    @cached_property
    def patients(self) -> AsyncPatientsResourceWithStreamingResponse:
        return AsyncPatientsResourceWithStreamingResponse(self._system.patients)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResourceWithStreamingResponse:
        return AsyncAppointmentsResourceWithStreamingResponse(self._system.appointments)

    @cached_property
    def bulk(self) -> AsyncBulkResourceWithStreamingResponse:
        return AsyncBulkResourceWithStreamingResponse(self._system.bulk)

    @cached_property
    def matching_jobs(self) -> AsyncMatchingJobsResourceWithStreamingResponse:
        return AsyncMatchingJobsResourceWithStreamingResponse(self._system.matching_jobs)

    @cached_property
    def cache(self) -> AsyncCacheResourceWithStreamingResponse:
        return AsyncCacheResourceWithStreamingResponse(self._system.cache)

    @cached_property
    def custom_searches(self) -> AsyncCustomSearchesResourceWithStreamingResponse:
        return AsyncCustomSearchesResourceWithStreamingResponse(self._system.custom_searches)

    @cached_property
    def outreach(self) -> AsyncOutreachResourceWithStreamingResponse:
        return AsyncOutreachResourceWithStreamingResponse(self._system.outreach)

    @cached_property
    def lab_results(self) -> AsyncLabResultsResourceWithStreamingResponse:
        return AsyncLabResultsResourceWithStreamingResponse(self._system.lab_results)

    @cached_property
    def concurrency(self) -> AsyncConcurrencyResourceWithStreamingResponse:
        return AsyncConcurrencyResourceWithStreamingResponse(self._system.concurrency)

    @cached_property
    def clinical_conductor(self) -> AsyncClinicalConductorResourceWithStreamingResponse:
        return AsyncClinicalConductorResourceWithStreamingResponse(self._system.clinical_conductor)

    @cached_property
    def semantic_prefilter_validation(self) -> AsyncSemanticPrefilterValidationResourceWithStreamingResponse:
        return AsyncSemanticPrefilterValidationResourceWithStreamingResponse(self._system.semantic_prefilter_validation)

    @cached_property
    def twilio(self) -> AsyncTwilioResourceWithStreamingResponse:
        return AsyncTwilioResourceWithStreamingResponse(self._system.twilio)

    @cached_property
    def facebook(self) -> AsyncFacebookResourceWithStreamingResponse:
        return AsyncFacebookResourceWithStreamingResponse(self._system.facebook)

    @cached_property
    def booking(self) -> AsyncBookingResourceWithStreamingResponse:
        return AsyncBookingResourceWithStreamingResponse(self._system.booking)

    @cached_property
    def nylas(self) -> AsyncNylasResourceWithStreamingResponse:
        return AsyncNylasResourceWithStreamingResponse(self._system.nylas)

    @cached_property
    def scheduling(self) -> AsyncSchedulingResourceWithStreamingResponse:
        return AsyncSchedulingResourceWithStreamingResponse(self._system.scheduling)
