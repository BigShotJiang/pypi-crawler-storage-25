# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...._types import Body, Query, Headers, NotGiven, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from .instances import (
    InstancesResource,
    AsyncInstancesResource,
    InstancesResourceWithRawResponse,
    AsyncInstancesResourceWithRawResponse,
    InstancesResourceWithStreamingResponse,
    AsyncInstancesResourceWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .appointments import (
    AppointmentsResource,
    AsyncAppointmentsResource,
    AppointmentsResourceWithRawResponse,
    AsyncAppointmentsResourceWithRawResponse,
    AppointmentsResourceWithStreamingResponse,
    AsyncAppointmentsResourceWithStreamingResponse,
)
from .study_configs import (
    StudyConfigsResource,
    AsyncStudyConfigsResource,
    StudyConfigsResourceWithRawResponse,
    AsyncStudyConfigsResourceWithRawResponse,
    StudyConfigsResourceWithStreamingResponse,
    AsyncStudyConfigsResourceWithStreamingResponse,
)
from ...._base_client import make_request_options
from ....types.system import clinical_conductor_retrieve_params
from ....types.system.clinical_conductor_retrieve_response import ClinicalConductorRetrieveResponse

__all__ = ["ClinicalConductorResource", "AsyncClinicalConductorResource"]


class ClinicalConductorResource(SyncAPIResource):
    @cached_property
    def instances(self) -> InstancesResource:
        return InstancesResource(self._client)

    @cached_property
    def study_configs(self) -> StudyConfigsResource:
        return StudyConfigsResource(self._client)

    @cached_property
    def appointments(self) -> AppointmentsResource:
        return AppointmentsResource(self._client)

    @cached_property
    def with_raw_response(self) -> ClinicalConductorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return ClinicalConductorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ClinicalConductorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return ClinicalConductorResourceWithStreamingResponse(self)

    def retrieve(
        self,
        visit_id: int,
        *,
        tenant_db_name: str,
        study_config_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ClinicalConductorRetrieveResponse:
        """
        Get visit details including configured duration.

        Args:
          study_config_id: Study config ID for CC instance

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/visits/{visit_id}",
                tenant_db_name=tenant_db_name,
                visit_id=visit_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"study_config_id": study_config_id},
                    clinical_conductor_retrieve_params.ClinicalConductorRetrieveParams,
                ),
            ),
            cast_to=ClinicalConductorRetrieveResponse,
        )


class AsyncClinicalConductorResource(AsyncAPIResource):
    @cached_property
    def instances(self) -> AsyncInstancesResource:
        return AsyncInstancesResource(self._client)

    @cached_property
    def study_configs(self) -> AsyncStudyConfigsResource:
        return AsyncStudyConfigsResource(self._client)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResource:
        return AsyncAppointmentsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncClinicalConductorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncClinicalConductorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncClinicalConductorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncClinicalConductorResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        visit_id: int,
        *,
        tenant_db_name: str,
        study_config_id: int,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ClinicalConductorRetrieveResponse:
        """
        Get visit details including configured duration.

        Args:
          study_config_id: Study config ID for CC instance

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return await self._get(
            path_template(
                "/system/{tenant_db_name}/clinical-conductor/visits/{visit_id}",
                tenant_db_name=tenant_db_name,
                visit_id=visit_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"study_config_id": study_config_id},
                    clinical_conductor_retrieve_params.ClinicalConductorRetrieveParams,
                ),
            ),
            cast_to=ClinicalConductorRetrieveResponse,
        )


class ClinicalConductorResourceWithRawResponse:
    def __init__(self, clinical_conductor: ClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.retrieve = to_raw_response_wrapper(
            clinical_conductor.retrieve,
        )

    @cached_property
    def instances(self) -> InstancesResourceWithRawResponse:
        return InstancesResourceWithRawResponse(self._clinical_conductor.instances)

    @cached_property
    def study_configs(self) -> StudyConfigsResourceWithRawResponse:
        return StudyConfigsResourceWithRawResponse(self._clinical_conductor.study_configs)

    @cached_property
    def appointments(self) -> AppointmentsResourceWithRawResponse:
        return AppointmentsResourceWithRawResponse(self._clinical_conductor.appointments)


class AsyncClinicalConductorResourceWithRawResponse:
    def __init__(self, clinical_conductor: AsyncClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.retrieve = async_to_raw_response_wrapper(
            clinical_conductor.retrieve,
        )

    @cached_property
    def instances(self) -> AsyncInstancesResourceWithRawResponse:
        return AsyncInstancesResourceWithRawResponse(self._clinical_conductor.instances)

    @cached_property
    def study_configs(self) -> AsyncStudyConfigsResourceWithRawResponse:
        return AsyncStudyConfigsResourceWithRawResponse(self._clinical_conductor.study_configs)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResourceWithRawResponse:
        return AsyncAppointmentsResourceWithRawResponse(self._clinical_conductor.appointments)


class ClinicalConductorResourceWithStreamingResponse:
    def __init__(self, clinical_conductor: ClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.retrieve = to_streamed_response_wrapper(
            clinical_conductor.retrieve,
        )

    @cached_property
    def instances(self) -> InstancesResourceWithStreamingResponse:
        return InstancesResourceWithStreamingResponse(self._clinical_conductor.instances)

    @cached_property
    def study_configs(self) -> StudyConfigsResourceWithStreamingResponse:
        return StudyConfigsResourceWithStreamingResponse(self._clinical_conductor.study_configs)

    @cached_property
    def appointments(self) -> AppointmentsResourceWithStreamingResponse:
        return AppointmentsResourceWithStreamingResponse(self._clinical_conductor.appointments)


class AsyncClinicalConductorResourceWithStreamingResponse:
    def __init__(self, clinical_conductor: AsyncClinicalConductorResource) -> None:
        self._clinical_conductor = clinical_conductor

        self.retrieve = async_to_streamed_response_wrapper(
            clinical_conductor.retrieve,
        )

    @cached_property
    def instances(self) -> AsyncInstancesResourceWithStreamingResponse:
        return AsyncInstancesResourceWithStreamingResponse(self._clinical_conductor.instances)

    @cached_property
    def study_configs(self) -> AsyncStudyConfigsResourceWithStreamingResponse:
        return AsyncStudyConfigsResourceWithStreamingResponse(self._clinical_conductor.study_configs)

    @cached_property
    def appointments(self) -> AsyncAppointmentsResourceWithStreamingResponse:
        return AsyncAppointmentsResourceWithStreamingResponse(self._clinical_conductor.appointments)
